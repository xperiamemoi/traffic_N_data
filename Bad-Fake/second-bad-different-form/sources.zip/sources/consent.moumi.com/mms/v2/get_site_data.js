{
  "stage_message_limit" : 1,
  "site_id" : 22304,
  "public_campaign_type_priority" : [ 2, 1, 2 ],
  "multi_campaign_enabled" : true,
  "stage_campaign_type_priority" : [ 1 ],
  "public_message_limit" : 1
}
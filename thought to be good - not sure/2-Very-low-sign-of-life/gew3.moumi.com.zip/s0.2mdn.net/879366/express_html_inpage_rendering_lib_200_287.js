(function() {
    var h, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        da = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ea = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        fa = ea(this),
        m = function(a, b) {
            if (b) a: {
                var c = fa;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && da(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        };
    m("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.g = f;
            da(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.g
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    });
    m("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = fa[b[c]];
            typeof d === "function" && typeof d.prototype[a] != "function" && da(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return ha(aa(this))
                }
            })
        }
        return a
    });
    var ha = function(a) {
            a = {
                next: a
            };
            a[Symbol.iterator] = function() {
                return this
            };
            return a
        },
        ja = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ka;
    if (typeof Object.setPrototypeOf == "function") ka = Object.setPrototypeOf;
    else {
        var la;
        a: {
            var ma = {
                    a: !0
                },
                pa = {};
            try {
                pa.__proto__ = ma;
                la = pa.a;
                break a
            } catch (a) {}
            la = !1
        }
        ka = la ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var qa = ka,
        t = function(a, b) {
            a.prototype = ja(b.prototype);
            a.prototype.constructor = a;
            if (qa) qa(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.Y = b.prototype
        },
        ra = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: aa(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        sa = function(a) {
            if (!(a instanceof Array)) {
                a = ra(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        ua = function(a) {
            return ta(a, a)
        },
        ta = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        va = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    m("globalThis", function(a) {
        return a || fa
    });
    m("Promise", function(a) {
        function b() {
            this.g = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(k) {
                k(g)
            })
        }
        if (a) return a;
        b.prototype.j = function(g) {
            if (this.g == null) {
                this.g = [];
                var k = this;
                this.o(function() {
                    k.A()
                })
            }
            this.g.push(g)
        };
        var d = fa.setTimeout;
        b.prototype.o = function(g) {
            d(g, 0)
        };
        b.prototype.A = function() {
            for (; this.g && this.g.length;) {
                var g = this.g;
                this.g = [];
                for (var k = 0; k < g.length; ++k) {
                    var l = g[k];
                    g[k] = null;
                    try {
                        l()
                    } catch (p) {
                        this.v(p)
                    }
                }
            }
            this.g = null
        };
        b.prototype.v = function(g) {
            this.o(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.g = 0;
            this.o = void 0;
            this.j = [];
            this.F = !1;
            var k = this.v();
            try {
                g(k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        e.prototype.v = function() {
            function g(p) {
                return function(x) {
                    l || (l = !0, p.call(k, x))
                }
            }
            var k = this,
                l = !1;
            return {
                resolve: g(this.H),
                reject: g(this.A)
            }
        };
        e.prototype.H = function(g) {
            if (g === this) this.A(new TypeError("A Promise cannot resolve to itself"));
            else if (g instanceof e) this.N(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var k = g != null;
                        break a;
                    case "function":
                        k = !0;
                        break a;
                    default:
                        k = !1
                }
                k ?
                this.G(g) : this.B(g)
            }
        };
        e.prototype.G = function(g) {
            var k = void 0;
            try {
                k = g.then
            } catch (l) {
                this.A(l);
                return
            }
            typeof k == "function" ? this.O(k, g) : this.B(g)
        };
        e.prototype.A = function(g) {
            this.C(2, g)
        };
        e.prototype.B = function(g) {
            this.C(1, g)
        };
        e.prototype.C = function(g, k) {
            if (this.g != 0) throw Error("Cannot settle(" + g + ", " + k + "): Promise already settled in state" + this.g);
            this.g = g;
            this.o = k;
            this.g === 2 && this.K();
            this.D()
        };
        e.prototype.K = function() {
            var g = this;
            d(function() {
                    if (g.I()) {
                        var k = fa.console;
                        typeof k !== "undefined" && k.error(g.o)
                    }
                },
                1)
        };
        e.prototype.I = function() {
            if (this.F) return !1;
            var g = fa.CustomEvent,
                k = fa.Event,
                l = fa.dispatchEvent;
            if (typeof l === "undefined") return !0;
            typeof g === "function" ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : typeof k === "function" ? g = new k("unhandledrejection", {
                cancelable: !0
            }) : (g = fa.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.o;
            return l(g)
        };
        e.prototype.D = function() {
            if (this.j != null) {
                for (var g = 0; g < this.j.length; ++g) f.j(this.j[g]);
                this.j =
                    null
            }
        };
        var f = new b;
        e.prototype.N = function(g) {
            var k = this.v();
            g.Aa(k.resolve, k.reject)
        };
        e.prototype.O = function(g, k) {
            var l = this.v();
            try {
                g.call(k, l.resolve, l.reject)
            } catch (p) {
                l.reject(p)
            }
        };
        e.prototype.then = function(g, k) {
            function l(y, E) {
                return typeof y == "function" ? function(ia) {
                    try {
                        p(y(ia))
                    } catch (ca) {
                        x(ca)
                    }
                } : E
            }
            var p, x, F = new e(function(y, E) {
                p = y;
                x = E
            });
            this.Aa(l(g, p), l(k, x));
            return F
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.Aa = function(g, k) {
            function l() {
                switch (p.g) {
                    case 1:
                        g(p.o);
                        break;
                    case 2:
                        k(p.o);
                        break;
                    default:
                        throw Error("Unexpected state: " + p.g);
                }
            }
            var p = this;
            this.j == null ? f.j(l) : this.j.push(l);
            this.F = !0
        };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(k, l) {
                l(g)
            })
        };
        e.race = function(g) {
            return new e(function(k, l) {
                for (var p = ra(g), x = p.next(); !x.done; x = p.next()) c(x.value).Aa(k, l)
            })
        };
        e.all = function(g) {
            var k = ra(g),
                l = k.next();
            return l.done ? c([]) : new e(function(p, x) {
                function F(ia) {
                    return function(ca) {
                        y[ia] = ca;
                        E--;
                        E == 0 && p(y)
                    }
                }
                var y = [],
                    E = 0;
                do y.push(void 0), E++, c(l.value).Aa(F(y.length -
                    1), x), l = k.next(); while (!l.done)
            })
        };
        return e
    });
    m("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    });
    m("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) Object.prototype.hasOwnProperty.call(b, d) && c.push(b[d]);
            return c
        }
    });
    m("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(k) {
                return k
            };
            var e = [],
                f = typeof Symbol != "undefined" && Symbol.iterator && b[Symbol.iterator];
            if (typeof f == "function") {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    });
    m("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
        }
    });
    m("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    });
    m("Number.MIN_SAFE_INTEGER", function() {
        return -9007199254740991
    });
    var wa = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    };
    m("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return typeof b === "number" && isNaN(b)
        }
    });
    m("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return wa(this, function(b) {
                return b
            })
        }
    });
    m("Array.prototype.values", function(a) {
        return a ? a : function() {
            return wa(this, function(b, c) {
                return c
            })
        }
    });
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var u = this || self,
        xa = function(a, b) {
            var c = v("CLOSURE_FLAGS");
            a = c && c[a];
            return a != null ? a : b
        },
        v = function(a, b) {
            a = a.split(".");
            b = b || u;
            for (var c = 0; c < a.length; c++)
                if (b = b[a[c]], b == null) return null;
            return b
        },
        ya = function(a) {
            var b = typeof a;
            b = b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null";
            return b == "array" || b == "object" && typeof a.length == "number"
        },
        za = function(a) {
            var b = typeof a;
            return b == "object" && a != null || b == "function"
        },
        Aa = "closure_uid_" + (Math.random() * 1E9 >>> 0),
        Ba = 0,
        Ca = function(a, b, c) {
            return a.call.apply(a.bind,
                arguments)
        },
        Da = function(a, b, c) {
            if (!a) throw Error();
            if (arguments.length > 2) {
                var d = Array.prototype.slice.call(arguments, 2);
                return function() {
                    var e = Array.prototype.slice.call(arguments);
                    Array.prototype.unshift.apply(e, d);
                    return a.apply(b, e)
                }
            }
            return function() {
                return a.apply(b, arguments)
            }
        },
        w = function(a, b, c) {
            w = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? Ca : Da;
            return w.apply(null, arguments)
        },
        Ea = function(a, b) {
            var c = Array.prototype.slice.call(arguments, 1);
            return function() {
                var d =
                    c.slice();
                d.push.apply(d, arguments);
                return a.apply(this, d)
            }
        },
        z = function() {
            return Date.now()
        },
        B = function(a, b) {
            a = a.split(".");
            for (var c = u, d; a.length && (d = a.shift());) a.length || b === void 0 ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
        },
        C = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.Y = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.xd = function(d, e, f) {
                for (var g = Array(arguments.length - 2), k = 2; k < arguments.length; k++) g[k - 2] = arguments[k];
                return b.prototype[e].apply(d, g)
            }
        };

    function Fa(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, Fa);
        else {
            var c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        b !== void 0 && (this.cause = b)
    }
    C(Fa, Error);
    Fa.prototype.name = "CustomError";
    var Ga;
    var Ha = function(a, b) {
            if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
            for (var c = 0; c < a.length; c++)
                if (c in a && a[c] === b) return c;
            return -1
        },
        D = function(a, b, c) {
            for (var d = a.length, e = typeof a === "string" ? a.split("") : a, f = 0; f < d; f++) f in e && b.call(c, e[f], f, a)
        },
        Ka = function(a, b) {
            for (var c = a.length, d = [], e = 0, f = typeof a === "string" ? a.split("") : a, g = 0; g < c; g++)
                if (g in f) {
                    var k = f[g];
                    b.call(void 0, k, g, a) && (d[e++] = k)
                }
            return d
        },
        La = function(a, b) {
            for (var c = a.length, d = Array(c), e = typeof a === "string" ?
                    a.split("") : a, f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
            return d
        },
        Ma = function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) return !0;
            return !1
        },
        Na = function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && !b.call(void 0, d[e], e, a)) return !1;
            return !0
        };

    function Oa(a, b) {
        a: {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) {
                    b = e;
                    break a
                }
            b = -1
        }
        return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b]
    }

    function Pa(a, b) {
        b = Ha(a, b);
        var c;
        (c = b >= 0) && Array.prototype.splice.call(a, b, 1);
        return c
    }

    function Qa(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function Ra(a) {
        var b = a.length;
        if (b > 0) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function Sa(a, b) {
        D(a, function(c, d) {
            b.call(void 0, c, d, a)
        })
    };

    function Ta(a) {
        u.setTimeout(function() {
            throw a;
        }, 0)
    };

    function G(a) {
        return /^[\s\xa0]*$/.test(a)
    }
    var Ua = function(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    };

    function Wa(a, b) {
        var c = 0;
        a = Ua(String(a)).split(".");
        b = Ua(String(b)).split(".");
        for (var d = Math.max(a.length, b.length), e = 0; c == 0 && e < d; e++) {
            var f = a[e] || "",
                g = b[e] || "";
            do {
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                if (f[0].length == 0 && g[0].length == 0) break;
                c = Xa(f[1].length == 0 ? 0 : parseInt(f[1], 10), g[1].length == 0 ? 0 : parseInt(g[1], 10)) || Xa(f[2].length == 0, g[2].length == 0) || Xa(f[2], g[2]);
                f = f[3];
                g = g[3]
            } while (c == 0)
        }
        return c
    }

    function Xa(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };
    var Ya = xa(610401301, !1),
        Za = xa(748402147, xa(1, !0));

    function $a() {
        var a = u.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var ab, bb = u.navigator;
    ab = bb ? bb.userAgentData || null : null;

    function cb(a) {
        if (!Ya || !ab) return !1;
        for (var b = 0; b < ab.brands.length; b++) {
            var c = ab.brands[b].brand;
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function H(a) {
        return $a().indexOf(a) != -1
    };

    function db() {
        return Ya ? !!ab && ab.brands.length > 0 : !1
    }

    function eb() {
        return db() ? !1 : H("Opera")
    }

    function fb() {
        return H("Firefox") || H("FxiOS")
    }

    function gb() {
        return db() ? cb("Chromium") : (H("Chrome") || H("CriOS")) && !(db() ? 0 : H("Edge")) || H("Silk")
    };

    function hb() {
        return H("iPhone") && !H("iPod") && !H("iPad")
    };
    var jb = function(a) {
        var b = ib;
        return Object.prototype.hasOwnProperty.call(b, "10") ? b["10"] : b["10"] = a("10")
    };
    var kb = eb(),
        lb = db() ? !1 : H("Trident") || H("MSIE"),
        mb = H("Edge"),
        nb = H("Gecko") && !($a().toLowerCase().indexOf("webkit") != -1 && !H("Edge")) && !(H("Trident") || H("MSIE")) && !H("Edge"),
        ob = $a().toLowerCase().indexOf("webkit") != -1 && !H("Edge"),
        pb = Ya && ab && ab.platform ? ab.platform === "Android" : H("Android"),
        qb = function() {
            var a = u.document;
            return a ? a.documentMode : void 0
        },
        rb;
    a: {
        var sb = "",
            tb = function() {
                var a = $a();
                if (nb) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (mb) return /Edge\/([\d\.]+)/.exec(a);
                if (lb) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (ob) return /WebKit\/(\S+)/.exec(a);
                if (kb) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();tb && (sb = tb ? tb[1] : "");
        if (lb) {
            var vb = qb();
            if (vb != null && vb > parseFloat(sb)) {
                rb = String(vb);
                break a
            }
        }
        rb = sb
    }
    var wb = rb,
        ib = {},
        xb = function() {
            return jb(function() {
                return Wa(wb, "10") >= 0
            })
        },
        yb;
    if (u.document && lb) {
        var zb = qb();
        yb = zb ? zb : parseInt(wb, 10) || void 0
    } else yb = void 0;
    var Ab = yb;
    var Bb = fb(),
        Cb = hb() || H("iPod"),
        Db = H("iPad"),
        Eb = H("Android") && !(gb() || fb() || eb() || H("Silk")),
        Fb = gb(),
        Gb = H("Safari") && !(gb() || (db() ? 0 : H("Coast")) || eb() || (db() ? 0 : H("Edge")) || (db() ? cb("Microsoft Edge") : H("Edg/")) || (db() ? cb("Opera") : H("OPR")) || fb() || H("Silk") || H("Android")) && !(hb() || H("iPad") || H("iPod"));

    function Hb(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var Ib = void 0;

    function Jb() {
        var a = Error("int32");
        Hb(a, "warning");
        return a
    };
    var Kb = typeof Symbol === "function" && typeof Symbol() === "symbol";

    function Lb(a, b, c) {
        return typeof Symbol === "function" && typeof Symbol() === "symbol" ? (c === void 0 ? 0 : c) && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol() : b
    }
    var Mb = Lb("jas", void 0, !0),
        Nb = Lb(void 0, "0actk"),
        Ob = Lb("m_m", "zd", !0);
    Math.max.apply(Math, sa(Object.values({
        gd: 1,
        fd: 2,
        ed: 4,
        kd: 8,
        ud: 16,
        hd: 32,
        Kc: 64,
        Wc: 128,
        Rc: 256,
        qd: 512,
        Sc: 1024,
        Xc: 2048,
        jd: 4096
    })));
    var Tb = {
            jc: {
                value: 0,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        },
        Ub = Object.defineProperties,
        I = Kb ? Mb : "jc";

    function Vb(a, b) {
        Kb || I in a || Ub(a, Tb);
        a[I] |= b
    }

    function Wb(a, b) {
        Kb || I in a || Ub(a, Tb);
        a[I] = b
    };
    var Xb = {};

    function Yb(a, b) {
        return b === void 0 ? a.Ba !== Zb && !!(2 & (a.fa[I] | 0)) : !!(2 & b) && a.Ba !== Zb
    }
    var Zb = {};
    var $b = typeof u.BigInt === "function" && typeof u.BigInt(0) === "bigint";
    var ac = Number.MIN_SAFE_INTEGER.toString(),
        bc = $b ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
        cc = Number.MAX_SAFE_INTEGER.toString(),
        dc = $b ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;

    function ec(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (var c = 0; c < a.length; c++) {
            var d = a[c],
                e = b[c];
            if (d > e) return !1;
            if (d < e) return !0
        }
    };
    var fc = Number.isFinite;

    function hc(a) {
        if (typeof a !== "number") throw Jb();
        if (!fc(a)) throw Jb();
        return a | 0
    };

    function ic(a) {
        return a
    };

    function jc(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        var f = [],
            g = a.length,
            k = 4294967295,
            l = !1,
            p = !!(b & 64),
            x = p ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1)) {
            var F = g && a[g - 1];
            F != null && typeof F === "object" && F.constructor === Object ? (g--, k = g) : F = void 0;
            if (p && !(b & 128) && !e) {
                l = !0;
                var y;
                k = ((y = kc) != null ? y : ic)(k - x, x, a, F, void 0) + x
            }
        }
        b = void 0;
        for (e = 0; e < g; e++)
            if (y = a[e], y != null && (y = c(y, d)) != null)
                if (p && e >= k) {
                    var E = e - x,
                        ia = void 0;
                    ((ia = b) != null ? ia : b = {})[E] = y
                } else f[e] = y;
        if (F)
            for (var ca in F) Object.prototype.hasOwnProperty.call(F, ca) && (a = F[ca], a != null &&
                (a = c(a, d)) != null && (g = +ca, e = void 0, p && !Number.isNaN(g) && (e = g + x) < k ? f[e] = a : (g = void 0, ((g = b) != null ? g : b = {})[ca] = a)));
        b && (l ? f.push(b) : f[k] = b);
        return f
    }

    function lc(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return ($b ? a >= bc && a <= dc : a[0] === "-" ? ec(a, ac) : ec(a, cc)) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    var b = a[I] | 0;
                    return a.length === 0 && b & 1 ? void 0 : jc(a, b, lc)
                }
                if (a != null && a[Ob] === Xb) return mc(a);
                return
        }
        return a
    }
    var kc;

    function mc(a) {
        a = a.fa;
        return jc(a, a[I] | 0, lc)
    };

    function nc(a, b, c) {
        var d = d === void 0 ? 0 : d;
        if (a == null) {
            var e = 32;
            c ? (a = [c], e |= 128) : a = [];
            b && (e = e & -8380417 | (b & 1023) << 13)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[I] | 0;
            if (Za && 1 & e) throw Error("rfarr");
            2048 & e && !(2 & e) && oc();
            if (e & 256) throw Error("farr");
            if (e & 64) return d !== 0 || e & 2048 || Wb(a, e | 2048), a;
            if (c && (e |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;e |= 64;
                var f = c.length;
                if (f) {
                    var g = f - 1,
                        k = c[g];
                    if (k != null && typeof k === "object" && k.constructor === Object) {
                        b = e & 128 ? 0 : -1;
                        g -= b;
                        if (g >= 1024) throw Error("pvtlmt");
                        for (var l in k) Object.prototype.hasOwnProperty.call(k,
                            l) && (f = +l, f < g && (c[f + b] = k[l], delete k[l]));
                        e = e & -8380417 | (g & 1023) << 13;
                        break a
                    }
                }
                if (b) {
                    l = Math.max(b, f - (e & 128 ? 0 : -1));
                    if (l > 1024) throw Error("spvt");
                    e = e & -8380417 | (l & 1023) << 13
                }
            }
        }
        e |= 64;
        d === 0 && (e |= 2048);
        Wb(a, e);
        return a
    }

    function oc() {
        if (Za) throw Error("carr");
        if (Nb != null) {
            var a;
            var b = (a = Ib) != null ? a : Ib = {};
            a = b[Nb] || 0;
            a >= 5 || (b[Nb] = a + 1, b = Error(), Hb(b, "incident"), Ta(b))
        }
    };

    function pc(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[I] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = qc(a, c, !1, b && !(c & 16)) : (Vb(a, 34), c & 4 && Object.freeze(a)));
            return a
        }
        if (a != null && a[Ob] === Xb) {
            b = a.fa;
            c = b[I] | 0;
            if (!Yb(a, c)) {
                if (c & 2) var d = !0;
                else c & 32 && !(c & 4096) ? (Wb(b, c | 2), a.Ba = Zb, d = !0) : d = !1;
                d ? (a = new a.constructor(b), a.oc = Zb) : a = qc(b, c)
            }
            return a
        }
    }

    function qc(a, b, c, d) {
        d != null || (d = !!(34 & b));
        a = jc(a, b, pc, d);
        d = 32;
        c && (d |= 2);
        b = b & 8380609 | d;
        Wb(a, b);
        return a
    };
    var rc = function(a, b, c) {
            if (a.Ba === Zb) {
                var d = a.fa;
                d = qc(d, d[I] | 0);
                Vb(d, 2048);
                a.fa = d;
                a.Ba = void 0;
                a.oc = void 0;
                d = !0
            } else d = !1;
            if (!d && Yb(a, a.fa[I] | 0)) throw Error();
            a = a.fa;
            a: {
                var e = a[I] | 0;d = b + -1;
                var f = a.length - 1;
                if (f >= 0 && d >= f) {
                    var g = a[f];
                    if (g != null && typeof g === "object" && g.constructor === Object) {
                        g[b] = c;
                        break a
                    }
                }
                d <= f ? a[d] = c : c !== void 0 && (e = (e != null ? e : a[I] | 0) >> 13 & 1023 || 536870912, b >= e ? c != null && (d = {}, a[e + -1] = (d[b] = c, d)) : a[d] = c)
            }
        },
        sc = function(a, b, c) {
            if (c != null && typeof c !== "string") throw Error();
            rc(a, b, c)
        };
    var tc = function(a, b, c) {
        this.fa = nc(a, b, c)
    };
    tc.prototype.toJSON = function() {
        return mc(this)
    };
    var uc = function(a) {
        return JSON.stringify(mc(a))
    };
    tc.prototype[Ob] = Xb;
    tc.prototype.toString = function() {
        return this.fa.toString()
    };
    var vc = function(a) {
        this.fa = nc(a)
    };
    t(vc, tc);
    var wc = function(a) {
        this.fa = nc(a)
    };
    t(wc, tc);
    var xc = function(a) {
        var b = "&rmfb=" + (typeof window.vv).substr(0, 3);
        return a.substring(a.length - 7) == "&adurl=" ? a.substring(0, a.length - 7) + b + "&adurl=" : a + b
    };

    function yc(a) {
        return a = a === void 0 ? window : a
    };
    var zc = function() {},
        Ac = function(a) {
            var b = !1,
                c;
            return function() {
                b || (c = a(), b = !0);
                return c
            }
        };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var Bc = globalThis.trustedTypes,
        Cc;

    function Dc() {
        var a = null;
        if (!Bc) return a;
        try {
            var b = function(c) {
                return c
            };
            a = Bc.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {}
        return a
    }

    function Ec() {
        Cc === void 0 && (Cc = Dc());
        return Cc
    };
    var Fc = function(a) {
        this.g = a
    };
    Fc.prototype.toString = function() {
        return this.g + ""
    };

    function Gc(a) {
        var b = Ec();
        a = b ? b.createScriptURL(a) : a;
        return new Fc(a)
    }

    function Hc(a) {
        if (a instanceof Fc) return a.g;
        throw Error("");
    };
    var Ic = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
    var Jc = function(a) {
        this.g = a
    };
    Jc.prototype.toString = function() {
        return this.g + ""
    };

    function Kc(a) {
        var b = Ec();
        a = b ? b.createHTML(a) : a;
        return new Jc(a)
    }

    function Lc(a) {
        if (a instanceof Jc) return a.g;
        throw Error("");
    };

    function Mc(a, b) {
        a.src = Hc(b);
        var c;
        b = a.ownerDocument;
        b = b === void 0 ? document : b;
        var d;
        b = (d = (c = b).querySelector) == null ? void 0 : d.call(c, "script[nonce]");
        (c = b == null ? "" : b.nonce || b.getAttribute("nonce") || "") && a.setAttribute("nonce", c)
    };

    function Nc(a, b) {
        if (a.nodeType === 1 && /^(script|style)$/i.test(a.tagName)) throw Error("");
        a.innerHTML = Lc(b)
    };
    var J = function(a) {
            return a == null ? "" : String(a)
        },
        Oc = function(a) {
            return String(a).replace(/\-([a-z])/g, function(b, c) {
                return c.toUpperCase()
            })
        },
        Pc = function(a) {
            return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
                return c + d.toUpperCase()
            })
        };

    function Qc(a, b, c) {
        for (var d in a) b.call(c, a[d], d, a)
    }

    function Rc(a, b) {
        for (var c in a)
            if (!b.call(void 0, a[c], c, a)) return !1;
        return !0
    }

    function Sc(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    }
    var Tc = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function hd(a, b) {
        for (var c, d, e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (var f = 0; f < Tc.length; f++) c = Tc[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };

    function id(a) {
        if (a instanceof Jc) return a;
        a = String(a).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
        return Kc(a)
    }

    function jd(a) {
        return kd(a)
    }

    function kd(a) {
        var b = id("");
        return Kc(a.map(function(c) {
            return Lc(id(c))
        }).join(Lc(b).toString()))
    }
    var ld = /^[a-z][a-z\d-]*$/i,
        md = "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(" "),
        nd = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(" "),
        od = ["action", "formaction", "href"];

    function pd(a) {
        var b;
        if (!ld.test("div")) throw Error("");
        if (md.indexOf("DIV") !== -1) throw Error("");
        var c = "<div";
        a && (c += qd(a));
        Array.isArray(b) || (b = b === void 0 ? [] : [b]);
        nd.indexOf("DIV") !== -1 ? c += ">" : (a = jd(b.map(function(d) {
            return d instanceof Jc ? d : id(String(d))
        })), c += ">" + a.toString() + "</div>");
        return Kc(c)
    }

    function qd(a) {
        for (var b = "", c = Object.keys(a), d = 0; d < c.length; d++) {
            var e = c[d],
                f = a[e];
            if (!ld.test(e)) throw Error("");
            if (f !== void 0 && f !== null) {
                if (/^on./i.test(e)) throw Error("");
                od.indexOf(e.toLowerCase()) !== -1 && (f = String(f), f = Ic.test(f) ? f : void 0, f = f || "about:invalid#zClosurez");
                e = e + '="' + id(String(f)) + '"';
                b += " " + e
            }
        }
        return b
    };

    function rd(a) {
        var b = va.apply(1, arguments);
        if (b.length === 0) return Gc(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Gc(c)
    };
    var sd = function(a, b) {
        b = b === void 0 ? document : b;
        return b.createElement(String(a).toLowerCase())
    };

    function td() {
        var a = a === void 0 ? window : a;
        if (a.interstitialAdFrame) {
            var b;
            return (b = a.interstitialAdFrame) != null ? b : null
        }
        try {
            var c;
            return (c = a.parent.interstitialAdFrame) != null ? c : null
        } catch (d) {}
        return null
    };
    var ud = function(a, b) {
        this.x = a !== void 0 ? a : 0;
        this.y = b !== void 0 ? b : 0
    };
    ud.prototype.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    ud.prototype.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    ud.prototype.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    var L = function(a, b) {
            this.width = a;
            this.height = b
        },
        vd = function(a) {
            return new L(a.width, a.height)
        };
    L.prototype.aspectRatio = function() {
        return this.width / this.height
    };
    L.prototype.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    L.prototype.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    L.prototype.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var wd = function(a, b) {
            return typeof b === "string" ? a.getElementById(b) : b
        },
        yd = function(a, b) {
            Qc(b, function(c, d) {
                d == "style" ? a.style.cssText = c : d == "class" ? a.className = c : d == "for" ? a.htmlFor = c : xd.hasOwnProperty(d) ? a.setAttribute(xd[d], c) : d.lastIndexOf("aria-", 0) == 0 || d.lastIndexOf("data-", 0) == 0 ? a.setAttribute(d, c) : a[d] = c
            })
        },
        xd = {
            cellpadding: "cellPadding",
            cellspacing: "cellSpacing",
            colspan: "colSpan",
            frameborder: "frameBorder",
            height: "height",
            maxlength: "maxLength",
            nonce: "nonce",
            role: "role",
            rowspan: "rowSpan",
            type: "type",
            usemap: "useMap",
            valign: "vAlign",
            width: "width"
        },
        zd = function(a) {
            return a.scrollingElement ? a.scrollingElement : ob || a.compatMode != "CSS1Compat" ? a.body || a.documentElement : a.documentElement
        },
        Ad = function(a, b) {
            b = String(b);
            a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
            return a.createElement(b)
        },
        Bd = function(a) {
            a && a.parentNode && a.parentNode.removeChild(a)
        },
        Cd = function(a) {
            return a.nodeType == 9 ? a : a.ownerDocument || a.document
        },
        Dd = function(a) {
            this.g = a || u.document || document
        };
    Dd.prototype.R = function() {
        return wd(this.g)
    };
    var Ed = function(a, b) {
        return Ad(a.g, b)
    };
    Dd.prototype.appendChild = function(a, b) {
        a.appendChild(b)
    };
    Dd.prototype.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
        if (typeof a.compareDocumentPosition != "undefined") return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };
    var Fd = function(a, b) {
        this.A = Math.random() < a;
        this.F = b;
        this.o = null;
        this.v = ""
    };
    Fd.prototype.isActive = function() {
        return this.A
    };
    Fd.prototype.j = function() {
        return this.isActive() && null !== this.o ? (this.F + "//pagead2.googlesyndication.com/pagead/gen_204/?id=" + this.o + this.v).substring(0, 2E3) : ""
    };
    var Gd = function() {},
        Jd = function(a) {
            Hd |= a;
            Id(a)
        },
        Id = function(a) {
            Kd(a, 2, 1);
            Kd(a, 1, 2);
            Kd(a, 4, 8);
            Kd(a, 8, 4);
            Kd(a, 128, 64);
            Kd(a, 64, 128);
            Kd(a, 256, 2)
        },
        Kd = function(a, b, c) {
            (a & b) == b && (Hd |= b, Hd &= ~c)
        };
    B("studio.common.Environment", Gd);
    Gd.Type = {
        LIVE: 1,
        LOCAL: 2,
        BROWSER: 4,
        IN_APP: 8,
        LAYOUTS_PREVIEW: 16,
        CREATIVE_TOOLSET: 32,
        RENDERING_STUDIO: 64,
        RENDERING_TEST: 128,
        PREVIEW: 256
    };
    var Hd = 6;
    Gd.addType = Jd;
    Gd.setType = function(a) {
        Hd = a | 6;
        Id(Hd)
    };
    var Ld = function(a) {
        return (Hd & a) == a
    };
    Gd.hasType = Ld;
    Gd.getValue = function() {
        return Hd
    };
    var Md = function(a, b) {
        this.g = a[u.Symbol.iterator]();
        this.j = b
    };
    Md.prototype[Symbol.iterator] = function() {
        return this
    };
    Md.prototype.next = function() {
        var a = this.g.next();
        return {
            value: a.done ? void 0 : this.j.call(void 0, a.value),
            done: a.done
        }
    };
    var Nd = function(a, b) {
        return new Md(a, b)
    };
    var Od = function() {};
    Od.prototype.next = function() {
        return Pd
    };
    var Pd = {
        done: !0,
        value: void 0
    };
    Od.prototype.ia = function() {
        return this
    };
    var Td = function(a) {
            if (a instanceof Qd || a instanceof Rd || a instanceof Sd) return a;
            if (typeof a.next == "function") return new Qd(function() {
                return a
            });
            if (typeof a[Symbol.iterator] == "function") return new Qd(function() {
                return a[Symbol.iterator]()
            });
            if (typeof a.ia == "function") return new Qd(function() {
                return a.ia()
            });
            throw Error("Not an iterator or iterable.");
        },
        Qd = function(a) {
            this.g = a
        };
    Qd.prototype.ia = function() {
        return new Rd(this.g())
    };
    Qd.prototype[Symbol.iterator] = function() {
        return new Sd(this.g())
    };
    Qd.prototype.j = function() {
        return new Sd(this.g())
    };
    var Rd = function(a) {
        this.g = a
    };
    t(Rd, Od);
    Rd.prototype.next = function() {
        return this.g.next()
    };
    Rd.prototype[Symbol.iterator] = function() {
        return new Sd(this.g)
    };
    Rd.prototype.j = function() {
        return new Sd(this.g)
    };
    var Sd = function(a) {
        Qd.call(this, function() {
            return a
        });
        this.o = a
    };
    t(Sd, Qd);
    Sd.prototype.next = function() {
        return this.o.next()
    };
    var Ud = function(a, b) {
        this.j = {};
        this.g = [];
        this.o = this.size = 0;
        var c = arguments.length;
        if (c > 1) {
            if (c % 2) throw Error("Uneven number of arguments");
            for (var d = 0; d < c; d += 2) this.set(arguments[d], arguments[d + 1])
        } else if (a)
            if (a instanceof Ud)
                for (c = a.ua(), d = 0; d < c.length; d++) this.set(c[d], a.get(c[d]));
            else
                for (d in a) this.set(d, a[d])
    };
    h = Ud.prototype;
    h.ma = function() {
        Vd(this);
        for (var a = [], b = 0; b < this.g.length; b++) a.push(this.j[this.g[b]]);
        return a
    };
    h.ua = function() {
        Vd(this);
        return this.g.concat()
    };
    h.has = function(a) {
        return Wd(this.j, a)
    };
    h.clear = function() {
        this.j = {};
        this.o = this.size = this.g.length = 0
    };
    h.delete = function(a) {
        return Wd(this.j, a) ? (delete this.j[a], --this.size, this.o++, this.g.length > 2 * this.size && Vd(this), !0) : !1
    };
    var Vd = function(a) {
        if (a.size != a.g.length) {
            for (var b = 0, c = 0; b < a.g.length;) {
                var d = a.g[b];
                Wd(a.j, d) && (a.g[c++] = d);
                b++
            }
            a.g.length = c
        }
        if (a.size != a.g.length) {
            b = {};
            for (d = c = 0; c < a.g.length;) {
                var e = a.g[c];
                Wd(b, e) || (a.g[d++] = e, b[e] = 1);
                c++
            }
            a.g.length = d
        }
    };
    h = Ud.prototype;
    h.get = function(a, b) {
        return Wd(this.j, a) ? this.j[a] : b
    };
    h.set = function(a, b) {
        Wd(this.j, a) || (this.size += 1, this.g.push(a), this.o++);
        this.j[a] = b
    };
    h.forEach = function(a, b) {
        for (var c = this.ua(), d = 0; d < c.length; d++) {
            var e = c[d],
                f = this.get(e);
            a.call(b, f, e, this)
        }
    };
    h.keys = function() {
        return Td(this.ia(!0)).j()
    };
    h.values = function() {
        return Td(this.ia(!1)).j()
    };
    h.entries = function() {
        var a = this;
        return Nd(this.keys(), function(b) {
            return [b, a.get(b)]
        })
    };
    h.ia = function(a) {
        Vd(this);
        var b = 0,
            c = this.o,
            d = this,
            e = new Od;
        e.next = function() {
            if (c != d.o) throw Error("The map has changed since the iterator was created");
            if (b >= d.g.length) return Pd;
            var f = d.g[b++];
            return {
                value: a ? f : d.j[f],
                done: !1
            }
        };
        return e
    };
    var Wd = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
    var Xd = function(a) {
            if (a.ma && typeof a.ma == "function") return a.ma();
            if (typeof Map !== "undefined" && a instanceof Map || typeof Set !== "undefined" && a instanceof Set) return Array.from(a.values());
            if (typeof a === "string") return a.split("");
            if (ya(a)) {
                for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
                return b
            }
            return Sc(a)
        },
        Yd = function(a) {
            if (a.ua && typeof a.ua == "function") return a.ua();
            if (!a.ma || typeof a.ma != "function") {
                if (typeof Map !== "undefined" && a instanceof Map) return Array.from(a.keys());
                if (!(typeof Set !== "undefined" &&
                        a instanceof Set)) {
                    if (ya(a) || typeof a === "string") {
                        var b = [];
                        a = a.length;
                        for (var c = 0; c < a; c++) b.push(c);
                        return b
                    }
                    b = [];
                    c = 0;
                    for (var d in a) b[c++] = d;
                    return b
                }
            }
        },
        $d = function(a) {
            var b = Zd.contains,
                c = Zd;
            if (typeof a.every == "function") return a.every(b, c);
            if (ya(a) || typeof a === "string") return Array.prototype.every.call(a, b, c);
            for (var d = Yd(a), e = Xd(a), f = e.length, g = 0; g < f; g++)
                if (!b.call(c, e[g], d && d[g], a)) return !1;
            return !0
        };
    var ae = function() {
            this.g = new Ud;
            this.size = 0
        },
        be = function(a) {
            var b = typeof a;
            return b == "object" && a || b == "function" ? "o" + (Object.prototype.hasOwnProperty.call(a, Aa) && a[Aa] || (a[Aa] = ++Ba)) : b.slice(0, 1) + a
        };
    h = ae.prototype;
    h.add = function(a) {
        this.g.set(be(a), a);
        this.size = this.g.size
    };
    h.delete = function(a) {
        var b = this.g;
        a = be(a);
        b = b.delete(a);
        this.size = this.g.size;
        return b
    };
    h.clear = function() {
        this.g.clear();
        this.size = 0
    };
    h.has = function(a) {
        var b = this.g;
        a = be(a);
        return b.has(a)
    };
    h.contains = function(a) {
        var b = this.g;
        a = be(a);
        return b.has(a)
    };
    h.ma = function() {
        return this.g.ma()
    };
    h.values = function() {
        return this.g.values()
    };
    h.ia = function() {
        return this.g.ia(!1)
    };
    ae.prototype[Symbol.iterator] = function() {
        return this.values()
    };
    B("studio.common.Feature.Type", {
        pd: 1,
        SDK_EVENT_FORWARDER: 2,
        RL_EVENT_FORWARDER: 3
    });
    var Zd = new ae;
    B("studio.common.Feature.hasFeature", function(a) {
        return Zd.has(a)
    });
    B("studio.common.Feature.hasFeatures", function(a) {
        return $d(a)
    });
    var ce = function(a, b) {
        this.g = a;
        this.j = b != null ? b : 0
    };
    ce.prototype.Xb = function() {
        return this.g
    };
    ce.prototype.Ub = function() {
        return this.j
    };
    ce.prototype.toString = function() {
        return this.g
    };
    B("studio.common.Orientation", ce);
    ce.prototype.getDegrees = ce.prototype.Ub;
    ce.prototype.getMode = ce.prototype.Xb;
    ce.Mode = {
        PORTRAIT: "portrait",
        LANDSCAPE: "landscape"
    };
    var de = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        ee = function(a, b, c) {
            if (Array.isArray(b))
                for (var d = 0; d < b.length; d++) ee(a, String(b[d]), c);
            else b != null && c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))))
        },
        fe = function(a, b) {
            if (b += "") {
                var c = a.indexOf("#");
                c < 0 && (c = a.length);
                var d = a.indexOf("?");
                if (d < 0 || d > c) {
                    d = c;
                    var e = ""
                } else e = a.substring(d + 1, c);
                a = [a.slice(0, d), e, a.slice(c)];
                c = a[1];
                a[1] = b ? c ? c + "&" + b : b : c;
                b = a[0] + (a[1] ? "?" + a[1] : "") + a[2]
            } else b = a;
            return b
        },
        ge = /#|$/;

    function he(a, b, c, d, e) {
        if (!G(J(a)) && a.indexOf("?") > -1) {
            e = typeof e === "number" ? e : 1;
            for (var f = 0; f < e; f++) b = encodeURIComponent(b)
        }
        c && (a = c ? a.replace("[rm_exit_id]", c) : a, b = d ? encodeURIComponent(d + b) : b);
        return a + b
    };
    B("studio.common.Visibility.VISIBILITY_PARAMS_KEY", "visibilityParams");
    B("studio.common.Visibility.VISIBILITY_FRACTION_KEY", "visibilityFraction");
    B("studio.common.Visibility.VISIBLE_BOX_KEY", "visibleBox");
    B("studio.common.Visibility.createVisibilityParams", function(a, b) {
        return {
            visibilityFraction: a,
            visibleBox: b
        }
    });
    B("studio.common.WhitelistedExternalObject", {
        CREATIVETOOLSET_CONFIG: "creativeToolsetConfig",
        CREATIVETOOLSET_INTERNALS: "creativeToolsetInternals",
        CREATIVETOOLSET_INTERNALS_GEN204: "creativeToolsetInternalsGen204",
        CREATIVE_REPORTER: "creativeReporter",
        CREATIVE_INNOVATION: "gcreativeinnovation",
        GOOGLE_AFMA_SUPPORT: "googleAfmaSupport"
    });

    function ie(a) {
        a && typeof a.dispose == "function" && a.dispose()
    };

    function je(a) {
        for (var b = 0, c = arguments.length; b < c; ++b) {
            var d = arguments[b];
            ya(d) ? je.apply(null, d) : ie(d)
        }
    };
    var M = function() {
        this.I = this.I;
        this.F = this.F
    };
    M.prototype.I = !1;
    M.prototype.dispose = function() {
        this.I || (this.I = !0, this.J())
    };
    M.prototype[Symbol.dispose] = function() {
        this.dispose()
    };
    M.prototype.J = function() {
        if (this.F)
            for (; this.F.length;) this.F.shift()()
    };
    var N = function(a, b) {
        this.type = a;
        this.g = this.target = b;
        this.defaultPrevented = !1
    };
    N.prototype.v = function() {
        this.defaultPrevented = !0
    };
    var ke = function() {
        if (!u.addEventListener || !Object.defineProperty) return !1;
        var a = !1,
            b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
        try {
            var c = function() {};
            u.addEventListener("test", c, b);
            u.removeEventListener("test", c, b)
        } catch (d) {}
        return a
    }();
    var le = function(a, b) {
        N.call(this, a ? a.type : "");
        this.relatedTarget = this.g = this.target = null;
        this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
        this.key = "";
        this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
        this.state = null;
        this.pointerId = 0;
        this.pointerType = "";
        this.j = null;
        a && this.init(a, b)
    };
    C(le, N);
    le.prototype.init = function(a, b) {
        var c = this.type = a.type,
            d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
        this.target = a.target || a.srcElement;
        this.g = b;
        b = a.relatedTarget;
        b || (c == "mouseover" ? b = a.fromElement : c == "mouseout" && (b = a.toElement));
        this.relatedTarget = b;
        d ? (this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX, this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY = d.screenY || 0) : (this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX, this.clientY = a.clientY !==
            void 0 ? a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
        this.button = a.button;
        this.key = a.key || "";
        this.ctrlKey = a.ctrlKey;
        this.altKey = a.altKey;
        this.shiftKey = a.shiftKey;
        this.metaKey = a.metaKey;
        this.pointerId = a.pointerId || 0;
        this.pointerType = a.pointerType;
        this.state = a.state;
        this.j = a;
        a.defaultPrevented && le.Y.v.call(this)
    };
    le.prototype.v = function() {
        le.Y.v.call(this);
        var a = this.j;
        a.preventDefault ? a.preventDefault() : a.returnValue = !1
    };
    var me = "closure_listenable_" + (Math.random() * 1E6 | 0),
        ne = function(a) {
            return !(!a || !a[me])
        };
    var oe = 0;
    var pe = function(a, b, c, d, e) {
            this.listener = a;
            this.proxy = null;
            this.src = b;
            this.type = c;
            this.capture = !!d;
            this.handler = e;
            this.key = ++oe;
            this.xa = this.za = !1
        },
        qe = function(a) {
            a.xa = !0;
            a.listener = null;
            a.proxy = null;
            a.src = null;
            a.handler = null
        };

    function re(a) {
        this.src = a;
        this.g = {};
        this.j = 0
    }
    re.prototype.add = function(a, b, c, d, e) {
        var f = a.toString();
        a = this.g[f];
        a || (a = this.g[f] = [], this.j++);
        var g = se(a, b, d, e);
        g > -1 ? (b = a[g], c || (b.za = !1)) : (b = new pe(b, this.src, f, !!d, e), b.za = c, a.push(b));
        return b
    };
    var te = function(a, b) {
            var c = b.type;
            c in a.g && Pa(a.g[c], b) && (qe(b), a.g[c].length == 0 && (delete a.g[c], a.j--))
        },
        ue = function(a, b, c, d, e) {
            a = a.g[b.toString()];
            b = -1;
            a && (b = se(a, c, d, e));
            return b > -1 ? a[b] : null
        },
        se = function(a, b, c, d) {
            for (var e = 0; e < a.length; ++e) {
                var f = a[e];
                if (!f.xa && f.listener == b && f.capture == !!c && f.handler == d) return e
            }
            return -1
        };
    var ve = "closure_lm_" + (Math.random() * 1E6 | 0),
        we = {},
        xe = 0,
        ze = function(a, b, c, d, e) {
            if (d && d.once) return ye(a, b, c, d, e);
            if (Array.isArray(b)) {
                for (var f = 0; f < b.length; f++) ze(a, b[f], c, d, e);
                return null
            }
            c = Ae(c);
            return ne(a) ? a.v.add(String(b), c, !1, za(d) ? !!d.capture : !!d, e) : Be(a, b, c, !1, d, e)
        },
        Be = function(a, b, c, d, e, f) {
            if (!b) throw Error("Invalid event type");
            var g = za(e) ? !!e.capture : !!e,
                k = Ce(a);
            k || (a[ve] = k = new re(a));
            c = k.add(b, c, d, g, f);
            if (c.proxy) return c;
            d = De();
            c.proxy = d;
            d.src = a;
            d.listener = c;
            if (a.addEventListener) ke ||
                (e = g), e === void 0 && (e = !1), a.addEventListener(b.toString(), d, e);
            else if (a.attachEvent) a.attachEvent(kf(b.toString()), d);
            else if (a.addListener && a.removeListener) a.addListener(d);
            else throw Error("addEventListener and attachEvent are unavailable.");
            xe++;
            return c
        },
        De = function() {
            var a = lf,
                b = function(c) {
                    return a.call(b.src, b.listener, c)
                };
            return b
        },
        ye = function(a, b, c, d, e) {
            if (Array.isArray(b)) {
                for (var f = 0; f < b.length; f++) ye(a, b[f], c, d, e);
                return null
            }
            c = Ae(c);
            return ne(a) ? a.v.add(String(b), c, !0, za(d) ? !!d.capture :
                !!d, e) : Be(a, b, c, !0, d, e)
        },
        mf = function(a, b, c, d, e) {
            if (Array.isArray(b))
                for (var f = 0; f < b.length; f++) mf(a, b[f], c, d, e);
            else d = za(d) ? !!d.capture : !!d, c = Ae(c), ne(a) ? (a = a.v, b = String(b).toString(), b in a.g && (f = a.g[b], c = se(f, c, d, e), c > -1 && (qe(f[c]), Array.prototype.splice.call(f, c, 1), f.length == 0 && (delete a.g[b], a.j--)))) : a && (a = Ce(a)) && (c = ue(a, b, c, d, e)) && nf(c)
        },
        nf = function(a) {
            if (typeof a !== "number" && a && !a.xa) {
                var b = a.src;
                if (ne(b)) te(b.v, a);
                else {
                    var c = a.type,
                        d = a.proxy;
                    b.removeEventListener ? b.removeEventListener(c,
                        d, a.capture) : b.detachEvent ? b.detachEvent(kf(c), d) : b.addListener && b.removeListener && b.removeListener(d);
                    xe--;
                    (c = Ce(b)) ? (te(c, a), c.j == 0 && (c.src = null, b[ve] = null)) : qe(a)
                }
            }
        },
        kf = function(a) {
            return a in we ? we[a] : we[a] = "on" + a
        },
        lf = function(a, b) {
            if (a.xa) a = !0;
            else {
                b = new le(b, this);
                var c = a.listener,
                    d = a.handler || a.src;
                a.za && nf(a);
                a = c.call(d, b)
            }
            return a
        },
        Ce = function(a) {
            a = a[ve];
            return a instanceof re ? a : null
        },
        of = "__closure_events_fn_" + (Math.random() * 1E9 >>> 0),
        Ae = function(a) {
            if (typeof a === "function") return a;
            a[ of ] ||
                (a[ of ] = function(b) {
                    return a.handleEvent(b)
                });
            return a[ of ]
        };
    var pf = function(a) {
        M.call(this);
        this.j = a;
        this.g = {}
    };
    C(pf, M);
    var qf = [],
        O = function(a, b, c, d) {
            Array.isArray(c) || (c && (qf[0] = c.toString()), c = qf);
            for (var e = 0; e < c.length; e++) {
                var f = ze(b, c[e], d || a.handleEvent, !1, a.j || a);
                if (!f) break;
                a.g[f.key] = f
            }
        },
        rf = function(a, b, c, d, e, f) {
            if (Array.isArray(c))
                for (var g = 0; g < c.length; g++) rf(a, b, c[g], d, e, f);
            else(b = ye(b, c, d || a.handleEvent, e, f || a.j || a)) && (a.g[b.key] = b)
        },
        sf = function(a, b, c, d, e, f) {
            if (Array.isArray(c))
                for (var g = 0; g < c.length; g++) sf(a, b, c[g], d, e, f);
            else d = d || a.handleEvent, e = za(e) ? !!e.capture : !!e, f = f || a.j || a, d = Ae(d), e = !!e, c = ne(b) ?
                ue(b.v, String(c), d, e, f) : b ? (b = Ce(b)) ? ue(b, c, d, e, f) : null : null, c && (nf(c), delete a.g[c.key])
        },
        tf = function(a) {
            Qc(a.g, function(b, c) {
                this.g.hasOwnProperty(c) && nf(b)
            }, a);
            a.g = {}
        };
    pf.prototype.J = function() {
        pf.Y.J.call(this);
        tf(this)
    };
    pf.prototype.handleEvent = function() {
        throw Error("EventHandler.handleEvent not implemented");
    };
    var uf = typeof AsyncContext !== "undefined" && typeof AsyncContext.Snapshot === "function" ? function(a) {
        return a && AsyncContext.Snapshot.wrap(a)
    } : function(a) {
        return a
    };
    var vf = function(a, b) {
        this.o = a;
        this.v = b;
        this.j = 0;
        this.g = null
    };
    vf.prototype.get = function() {
        if (this.j > 0) {
            this.j--;
            var a = this.g;
            this.g = a.next;
            a.next = null
        } else a = this.o();
        return a
    };
    var wf = function(a, b) {
        a.v(b);
        a.j < 100 && (a.j++, b.next = a.g, a.g = b)
    };
    var xf = function() {
        this.j = this.g = null
    };
    xf.prototype.add = function(a, b) {
        var c = yf.get();
        c.set(a, b);
        this.j ? this.j.next = c : this.g = c;
        this.j = c
    };
    var Af = function() {
            var a = zf,
                b = null;
            a.g && (b = a.g, a.g = a.g.next, a.g || (a.j = null), b.next = null);
            return b
        },
        yf = new vf(function() {
            return new Bf
        }, function(a) {
            return a.reset()
        }),
        Bf = function() {
            this.next = this.g = this.j = null
        };
    Bf.prototype.set = function(a, b) {
        this.j = a;
        this.g = b;
        this.next = null
    };
    Bf.prototype.reset = function() {
        this.next = this.g = this.j = null
    };
    var Cf, Df = !1,
        zf = new xf,
        Ff = function(a, b) {
            Cf || Ef();
            Df || (Cf(), Df = !0);
            zf.add(a, b)
        },
        Ef = function() {
            var a = Promise.resolve(void 0);
            Cf = function() {
                a.then(Gf)
            }
        };

    function Gf() {
        for (var a; a = Af();) {
            try {
                a.j.call(a.g)
            } catch (b) {
                Ta(b)
            }
            wf(yf, a)
        }
        Df = !1
    };
    var Hf = function(a) {
        if (!a) return !1;
        try {
            return !!a.$goog_Thenable
        } catch (b) {
            return !1
        }
    };
    var P = function(a, b) {
            this.g = 0;
            this.F = void 0;
            this.v = this.j = this.o = null;
            this.A = this.B = !1;
            if (a != zc) try {
                var c = this;
                a.call(b, function(d) {
                    If(c, 2, d)
                }, function(d) {
                    If(c, 3, d)
                })
            } catch (d) {
                If(this, 3, d)
            }
        },
        Jf = function() {
            this.next = this.context = this.j = this.v = this.g = null;
            this.o = !1
        };
    Jf.prototype.reset = function() {
        this.context = this.j = this.v = this.g = null;
        this.o = !1
    };
    var Kf = new vf(function() {
            return new Jf
        }, function(a) {
            a.reset()
        }),
        Lf = function(a, b, c) {
            var d = Kf.get();
            d.v = a;
            d.j = b;
            d.context = c;
            return d
        },
        Nf = function(a, b, c) {
            Mf(a, b, c, null) || Ff(Ea(b, a))
        },
        Of = function(a) {
            return new P(function(b, c) {
                var d = a.length,
                    e = [];
                if (d)
                    for (var f = function(p, x) {
                            d--;
                            e[p] = x;
                            d == 0 && b(e)
                        }, g = function(p) {
                            c(p)
                        }, k, l = 0; l < a.length; l++) k = a[l], Nf(k, Ea(f, l), g);
                else b(e)
            })
        },
        Qf = function() {
            var a, b, c = new P(function(d, e) {
                a = d;
                b = e
            });
            return new Pf(c, a, b)
        };
    P.prototype.then = function(a, b, c) {
        return Rf(this, uf(typeof a === "function" ? a : null), uf(typeof b === "function" ? b : null), c)
    };
    P.prototype.$goog_Thenable = !0;
    var Tf = function(a, b, c) {
        b = uf(b);
        c = Lf(b, b, c);
        c.o = !0;
        Sf(a, c)
    };
    P.prototype.cancel = function(a) {
        if (this.g == 0) {
            var b = new Uf(a);
            Ff(function() {
                Vf(this, b)
            }, this)
        }
    };
    var Vf = function(a, b) {
            if (a.g == 0)
                if (a.o) {
                    var c = a.o;
                    if (c.j) {
                        for (var d = 0, e = null, f = null, g = c.j; g && (g.o || (d++, g.g == a && (e = g), !(e && d > 1))); g = g.next) e || (f = g);
                        e && (c.g == 0 && d == 1 ? Vf(c, b) : (f ? (d = f, d.next == c.v && (c.v = d), d.next = d.next.next) : Wf(c), Xf(c, e, 3, b)))
                    }
                    a.o = null
                } else If(a, 3, b)
        },
        Sf = function(a, b) {
            a.j || a.g != 2 && a.g != 3 || Yf(a);
            a.v ? a.v.next = b : a.j = b;
            a.v = b
        },
        Rf = function(a, b, c, d) {
            var e = Lf(null, null, null);
            e.g = new P(function(f, g) {
                e.v = b ? function(k) {
                    try {
                        var l = b.call(d, k);
                        f(l)
                    } catch (p) {
                        g(p)
                    }
                } : f;
                e.j = c ? function(k) {
                    try {
                        var l = c.call(d,
                            k);
                        l === void 0 && k instanceof Uf ? g(k) : f(l)
                    } catch (p) {
                        g(p)
                    }
                } : g
            });
            e.g.o = a;
            Sf(a, e);
            return e.g
        };
    P.prototype.D = function(a) {
        this.g = 0;
        If(this, 2, a)
    };
    P.prototype.I = function(a) {
        this.g = 0;
        If(this, 3, a)
    };
    var If = function(a, b, c) {
            a.g == 0 && (a === c && (b = 3, c = new TypeError("Promise cannot resolve to itself")), a.g = 1, Mf(c, a.D, a.I, a) || (a.F = c, a.g = b, a.o = null, Yf(a), b != 3 || c instanceof Uf || Zf(a, c)))
        },
        Mf = function(a, b, c, d) {
            if (a instanceof P) return Sf(a, Lf(b || zc, c || null, d)), !0;
            if (Hf(a)) return a.then(b, c, d), !0;
            if (za(a)) try {
                var e = a.then;
                if (typeof e === "function") return $f(a, e, b, c, d), !0
            } catch (f) {
                return c.call(d, f), !0
            }
            return !1
        },
        $f = function(a, b, c, d, e) {
            var f = !1,
                g = function(l) {
                    f || (f = !0, c.call(e, l))
                },
                k = function(l) {
                    f || (f = !0, d.call(e,
                        l))
                };
            try {
                b.call(a, g, k)
            } catch (l) {
                k(l)
            }
        },
        Yf = function(a) {
            a.B || (a.B = !0, Ff(a.C, a))
        },
        Wf = function(a) {
            var b = null;
            a.j && (b = a.j, a.j = b.next, b.next = null);
            a.j || (a.v = null);
            return b
        };
    P.prototype.C = function() {
        for (var a; a = Wf(this);) Xf(this, a, this.g, this.F);
        this.B = !1
    };
    var Xf = function(a, b, c, d) {
            if (c == 3 && b.j && !b.o)
                for (; a && a.A; a = a.o) a.A = !1;
            if (b.g) b.g.o = null, ag(b, c, d);
            else try {
                b.o ? b.v.call(b.context) : ag(b, c, d)
            } catch (e) {
                bg.call(null, e)
            }
            wf(Kf, b)
        },
        ag = function(a, b, c) {
            b == 2 ? a.v.call(a.context, c) : a.j && a.j.call(a.context, c)
        },
        Zf = function(a, b) {
            a.A = !0;
            Ff(function() {
                a.A && bg.call(null, b)
            })
        },
        bg = Ta,
        Uf = function(a) {
            Fa.call(this, a)
        };
    C(Uf, Fa);
    Uf.prototype.name = "cancel";
    var Pf = function(a, b, c) {
        this.promise = a;
        this.resolve = b;
        this.reject = c
    };
    /*

     Copyright 2005, 2007 Bob Ippolito. All Rights Reserved.
     Copyright The Closure Library Authors.
     SPDX-License-Identifier: MIT
    */
    var dg = function(a) {
        var b = cg;
        this.A = [];
        this.H = b;
        this.G = a || null;
        this.v = this.o = !1;
        this.j = void 0;
        this.D = this.K = this.F = !1;
        this.B = 0;
        this.g = null;
        this.C = 0
    };
    dg.prototype.cancel = function(a) {
        if (this.o) this.j instanceof dg && this.j.cancel();
        else {
            if (this.g) {
                var b = this.g;
                delete this.g;
                a ? b.cancel(a) : (b.C--, b.C <= 0 && b.cancel())
            }
            this.H ? this.H.call(this.G, this) : this.D = !0;
            this.o || (a = new eg(this), fg(this), gg(this, !1, a))
        }
    };
    dg.prototype.I = function(a, b) {
        this.F = !1;
        gg(this, a, b)
    };
    var gg = function(a, b, c) {
            a.o = !0;
            a.j = c;
            a.v = !b;
            hg(a)
        },
        fg = function(a) {
            if (a.o) {
                if (!a.D) throw new ig(a);
                a.D = !1
            }
        },
        jg = function(a, b, c, d) {
            var e = a.o;
            e || (b === c ? b = c = uf(b) : (b = uf(b), c = uf(c)));
            a.A.push([b, c, d]);
            e && hg(a)
        };
    dg.prototype.then = function(a, b, c) {
        var d, e, f = new P(function(g, k) {
            e = g;
            d = k
        });
        jg(this, e, function(g) {
            g instanceof eg ? f.cancel() : d(g);
            return kg
        }, this);
        return f.then(a, b, c)
    };
    dg.prototype.$goog_Thenable = !0;
    var lg = function(a) {
            return Ma(a.A, function(b) {
                return typeof b[1] === "function"
            })
        },
        kg = {},
        hg = function(a) {
            if (a.B && a.o && lg(a)) {
                var b = a.B,
                    c = mg[b];
                c && (u.clearTimeout(c.g), delete mg[b]);
                a.B = 0
            }
            a.g && (a.g.C--, delete a.g);
            b = a.j;
            for (var d = c = !1; a.A.length && !a.F;) {
                var e = a.A.shift(),
                    f = e[0],
                    g = e[1];
                e = e[2];
                if (f = a.v ? g : f) try {
                    var k = f.call(e || a.G, b);
                    k === kg && (k = void 0);
                    k !== void 0 && (a.v = a.v && (k == b || k instanceof Error), a.j = b = k);
                    if (Hf(b) || typeof u.Promise === "function" && b instanceof u.Promise) d = !0, a.F = !0
                } catch (l) {
                    b = l, a.v = !0,
                        lg(a) || (c = !0)
                }
            }
            a.j = b;
            d && (k = w(a.I, a, !0), d = w(a.I, a, !1), b instanceof dg ? (jg(b, k, d), b.K = !0) : b.then(k, d));
            c && (b = new ng(b), mg[b.g] = b, a.B = b.g)
        },
        ig = function() {
            Fa.call(this)
        };
    C(ig, Fa);
    ig.prototype.message = "Deferred has already fired";
    ig.prototype.name = "AlreadyCalledError";
    var eg = function() {
        Fa.call(this)
    };
    C(eg, Fa);
    eg.prototype.message = "Deferred was canceled";
    eg.prototype.name = "CanceledError";
    var ng = function(a) {
        this.g = u.setTimeout(w(this.o, this), 0);
        this.j = a
    };
    ng.prototype.o = function() {
        delete mg[this.g];
        throw this.j;
    };
    var mg = {};
    var Q = function() {
        M.call(this);
        this.v = new re(this);
        this.pa = this;
        this.Z = null
    };
    C(Q, M);
    Q.prototype[me] = !0;
    Q.prototype.addEventListener = function(a, b, c, d) {
        ze(this, a, b, c, d)
    };
    Q.prototype.removeEventListener = function(a, b, c, d) {
        mf(this, a, b, c, d)
    };
    var R = function(a, b) {
        var c = a.Z;
        if (c) {
            var d = [];
            for (var e = 1; c; c = c.Z) d.push(c), ++e
        }
        a = a.pa;
        c = b.type || b;
        typeof b === "string" ? b = new N(b, a) : b instanceof N ? b.target = b.target || a : (e = b, b = new N(c, a), hd(b, e));
        e = !0;
        var f;
        if (d)
            for (f = d.length - 1; f >= 0; f--) {
                var g = b.g = d[f];
                e = og(g, c, !0, b) && e
            }
        g = b.g = a;
        e = og(g, c, !0, b) && e;
        e = og(g, c, !1, b) && e;
        if (d)
            for (f = 0; f < d.length; f++) g = b.g = d[f], e = og(g, c, !1, b) && e
    };
    Q.prototype.J = function() {
        Q.Y.J.call(this);
        if (this.v) {
            var a = this.v,
                b = 0,
                c;
            for (c in a.g) {
                for (var d = a.g[c], e = 0; e < d.length; e++) ++b, qe(d[e]);
                delete a.g[c];
                a.j--
            }
        }
        this.Z = null
    };
    var og = function(a, b, c, d) {
        b = a.v.g[String(b)];
        if (!b) return !0;
        b = b.concat();
        for (var e = !0, f = 0; f < b.length; ++f) {
            var g = b[f];
            if (g && !g.xa && g.capture == c) {
                var k = g.listener,
                    l = g.handler || g.src;
                g.za && te(a.v, g);
                e = k.call(l, d) !== !1 && e
            }
        }
        return e && !d.defaultPrevented
    };
    var pg = function(a, b) {
        Q.call(this);
        this.A = a || 1;
        this.o = b || u;
        this.B = w(this.D, this);
        this.C = z()
    };
    C(pg, Q);
    pg.prototype.j = !1;
    pg.prototype.g = null;
    pg.prototype.D = function() {
        if (this.j) {
            var a = z() - this.C;
            a > 0 && a < this.A * .8 ? this.g = this.o.setTimeout(this.B, this.A - a) : (this.g && (this.o.clearTimeout(this.g), this.g = null), R(this, "tick"), this.j && (qg(this), this.start()))
        }
    };
    pg.prototype.start = function() {
        this.j = !0;
        this.g || (this.g = this.o.setTimeout(this.B, this.A), this.C = z())
    };
    var qg = function(a) {
        a.j = !1;
        a.g && (a.o.clearTimeout(a.g), a.g = null)
    };
    pg.prototype.J = function() {
        pg.Y.J.call(this);
        qg(this);
        delete this.o
    };
    var rg = function(a, b, c) {
        if (typeof a === "function") c && (a = w(a, c));
        else if (a && typeof a.handleEvent == "function") a = w(a.handleEvent, a);
        else throw Error("Invalid listener argument");
        return Number(b) > 2147483647 ? -1 : u.setTimeout(a, b || 0)
    };

    function sg(a, b, c, d) {
        this.top = a;
        this.j = b;
        this.g = c;
        this.left = d
    }
    sg.prototype.contains = function(a) {
        return this && a ? a instanceof sg ? a.left >= this.left && a.j <= this.j && a.top >= this.top && a.g <= this.g : a.x >= this.left && a.x <= this.j && a.y >= this.top && a.y <= this.g : !1
    };
    sg.prototype.ceil = function() {
        this.top = Math.ceil(this.top);
        this.j = Math.ceil(this.j);
        this.g = Math.ceil(this.g);
        this.left = Math.ceil(this.left);
        return this
    };
    sg.prototype.floor = function() {
        this.top = Math.floor(this.top);
        this.j = Math.floor(this.j);
        this.g = Math.floor(this.g);
        this.left = Math.floor(this.left);
        return this
    };
    sg.prototype.round = function() {
        this.top = Math.round(this.top);
        this.j = Math.round(this.j);
        this.g = Math.round(this.g);
        this.left = Math.round(this.left);
        return this
    };
    var tg = function(a) {
        this.g = a
    };
    tg.prototype.toString = function() {
        return (this.g & 2 ? "b" : "t") + (this.g & 1 ? "r" : "l")
    };
    B("google3.javascript.ads.studio.common.mde.Direction.Direction", tg);
    tg.Corner = {
        rd: 0,
        sd: 1,
        Gc: 2,
        Hc: 3
    };

    function ug(a, b, c, d, e) {
        this.name = a;
        this.reportingId = b;
        this.type = c;
        this.v = d;
        this.B = e;
        this.A = !1
    }
    var vg = function(a) {
        switch (a) {
            case "Exit":
                return "Exit";
            case "Count":
                return "Counter";
            case "Start":
            case "Stop":
                return "Timer";
            default:
                throw "Unsupported event action";
        }
    };
    var wg = {
            DISPLAY_TIMER: {
                id: null,
                type: "Timer",
                L: !0,
                M: !0
            },
            INTERACTION_TIMER: {
                id: null,
                type: "Timer",
                L: !0,
                M: !0
            },
            INTERACTIVE_IMPRESSION: {
                id: null,
                type: "Counter",
                L: !0,
                M: !1
            },
            MANUAL_CLOSE: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            EXPAND_TIMER: {
                id: null,
                type: "Timer",
                L: !0,
                M: !1
            },
            FULL_SCREEN: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            SCROLL: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            LARGE_SCROLL: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            SMALL_SCROLL: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            ENGAGEMENT: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            VIDEO_PLAY: {
                id: null,
                type: "Counter",
                L: !0,
                M: !1
            },
            VIDEO_VIEW_TIMER: {
                id: null,
                type: "Timer",
                L: !0,
                M: !0
            },
            VIDEO_COMPLETE: {
                id: null,
                type: "Counter",
                L: !0,
                M: !1
            },
            VIDEO_INTERACTION: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            VIDEO_PAUSE: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            VIDEO_MUTE: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            VIDEO_REPLAY: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            VIDEO_FIRST_QUARTILE: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            VIDEO_MIDPOINT: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            VIDEO_THIRD_QUARTILE: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            VIDEO_STOP: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            VIDEO_UNMUTE: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            BACKUP_IMAGE_IMPRESSION: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            },
            HTML5_CREATIVE_IMPRESSION: {
                id: null,
                type: "Counter",
                L: !0,
                M: !0
            }
        },
        xg = function(a) {
            var b = wg[a];
            return b ? new ug(a, b.id, b.type, b.L, b.M) : null
        };
    var yg = {
        3: "INTERACTION_TIMER",
        EVENT_USER_INTERACTION: "INTERACTIVE_IMPRESSION",
        EVENT_MANUAL_CLOSE: "MANUAL_CLOSE",
        EVENT_VIDEO_PLAY: "VIDEO_PLAY",
        EVENT_VIDEO_VIEW_TIMER: "VIDEO_VIEW_TIMER",
        EVENT_VIDEO_COMPLETE: "VIDEO_COMPLETE",
        EVENT_VIDEO_INTERACTION: "VIDEO_INTERACTION",
        EVENT_VIDEO_PAUSE: "VIDEO_PAUSE",
        EVENT_VIDEO_MUTE: "VIDEO_MUTE",
        EVENT_VIDEO_REPLAY: "VIDEO_REPLAY",
        EVENT_VIDEO_FIRSTQUARTILE: "VIDEO_FIRST_QUARTILE",
        EVENT_VIDEO_MIDPOINT: "VIDEO_MIDPOINT",
        EVENT_VIDEO_THIRDQUARTILE: "VIDEO_THIRD_QUARTILE",
        EVENT_VIDEO_STOP: "VIDEO_STOP",
        EVENT_VIDEO_UNMUTE: "VIDEO_UNMUTE",
        EVENT_FULLSCREEN: "FULL_SCREEN",
        DISPLAY_TIMER: "DISPLAY_TIMER",
        INTERACTION_TIMER: "INTERACTION_TIMER",
        INTERACTIVE_IMPRESSION: "INTERACTIVE_IMPRESSION",
        MANUAL_CLOSE: "MANUAL_CLOSE",
        EXPAND_TIMER: "EXPAND_TIMER",
        FULL_SCREEN: "FULL_SCREEN",
        SCROLL: "SCROLL",
        LARGE_SCROLL: "LARGE_SCROLL",
        SMALL_SCROLL: "SMALL_SCROLL",
        ENGAGEMENT: "ENGAGEMENT",
        VIDEO_PLAY: "VIDEO_PLAY",
        VIDEO_VIEW_TIMER: "VIDEO_VIEW_TIMER",
        VIDEO_COMPLETE: "VIDEO_COMPLETE",
        VIDEO_INTERACTION: "VIDEO_INTERACTION",
        VIDEO_PAUSE: "VIDEO_PAUSE",
        VIDEO_MUTE: "VIDEO_MUTE",
        VIDEO_REPLAY: "VIDEO_REPLAY",
        VIDEO_FIRST_QUARTILE: "VIDEO_FIRST_QUARTILE",
        VIDEO_MIDPOINT: "VIDEO_MIDPOINT",
        VIDEO_THIRD_QUARTILE: "VIDEO_THIRD_QUARTILE",
        VIDEO_STOP: "VIDEO_STOP",
        VIDEO_UNMUTE: "VIDEO_UNMUTE",
        BACKUP_IMAGE_IMPRESSION: "BACKUP_IMAGE_IMPRESSION",
        HTML5_CREATIVE_IMPRESSION: "HTML5_CREATIVE_IMPRESSION"
    };
    var zg = ua(["https://s0.2mdn.net/ads/richmedia/studio/mu/templates/hifi/hifi.js"]),
        Ag = ua(["https://s0.2mdn.net/ads/richmedia/studio_canary/mu/templates/hifi/hifi_canary.js"]);
    ({})[3] = rd(zg);
    ({})[3] = rd(Ag);
    var Bg = function(a) {
        return typeof a.className == "string" ? a.className : a.getAttribute && a.getAttribute("class") || ""
    };
    var Fg = function(a) {
            var b = {},
                c = b.document || document,
                d = Hc(a).toString(),
                e = Ed(new Dd(c), "SCRIPT"),
                f = {
                    lb: e,
                    ob: void 0
                },
                g = new dg(f),
                k = null,
                l = b.timeout != null ? b.timeout : 5E3;
            l > 0 && (k = window.setTimeout(function() {
                Cg(e, !0);
                var p = new Dg(1, "Timeout reached for loading script " + d);
                fg(g);
                gg(g, !1, p)
            }, l), f.ob = k);
            e.onload = e.onreadystatechange = function() {
                e.readyState && e.readyState != "loaded" && e.readyState != "complete" || (Cg(e, b.yd || !1, k), fg(g), gg(g, !0, null))
            };
            e.onerror = function() {
                Cg(e, !0, k);
                var p = new Dg(0, "Error while loading script " +
                    d);
                fg(g);
                gg(g, !1, p)
            };
            f = b.attributes || {};
            hd(f, {
                type: "text/javascript",
                charset: "UTF-8"
            });
            yd(e, f);
            Mc(e, a);
            Eg(c).appendChild(e)
        },
        Eg = function(a) {
            var b = (a || document).getElementsByTagName("HEAD");
            return b && b.length !== 0 ? b[0] : a.documentElement
        },
        cg = function() {
            if (this && this.lb) {
                var a = this.lb;
                a && a.tagName == "SCRIPT" && Cg(a, !0, this.ob)
            }
        },
        Cg = function(a, b, c) {
            c != null && u.clearTimeout(c);
            a.onload = function() {};
            a.onerror = function() {};
            a.onreadystatechange = function() {};
            b && window.setTimeout(function() {
                Bd(a)
            }, 0)
        },
        Dg = function(a,
            b) {
            var c = "Jsloader error (code #" + a + ")";
            b && (c += ": " + b);
            Fa.call(this, c);
            this.code = a
        };
    C(Dg, Fa);

    function Gg(a) {
        a = Hg(a);
        return Kc(a)
    }

    function Ig(a) {
        a = Hg(a);
        return Gc(a)
    }

    function Hg(a) {
        return a === null ? "null" : a === void 0 ? "undefined" : a
    };
    var Jg = function(a, b, c, d, e) {
            this.F = a;
            this.g = "";
            b && (this.g = /^(http[s]?:)?\/\//.test(b) ? b : "//pagead2.googlesyndication.com/activeview?avi=" + b);
            this.B = c || "";
            this.v = !1;
            this.A = d || "//www.googletagservices.com/activeview/js/current/lidar.js";
            this.j = e || null;
            this.o = e !== void 0 && !!e["data-google-av-turtlex"]
        },
        Kg = function(a, b) {
            b.setAttribute("id", "DfaVisibilityIdentifier_" + z());
            if (b.classList) b.classList.add("GoogleActiveViewClass");
            else {
                if (b.classList) var c = !b.classList.contains("GoogleActiveViewClass");
                else c =
                    b.classList ? b.classList : Bg(b).match(/\S+/g) || [], c = !(Ha(c, "GoogleActiveViewClass") >= 0);
                c && (c = Bg(b), c += c.length > 0 ? " GoogleActiveViewClass" : "GoogleActiveViewClass", typeof b.className == "string" ? b.className = c : b.setAttribute && b.setAttribute("class", c))
            }
            b._avicxn_ = a.g;
            b._avm_ = a.B;
            if (a.j) {
                b.classList.add(a.j.active_view_class_name);
                for (var d in a.j) a.j.hasOwnProperty(d) && d.indexOf("data-google-av") === 0 && b.setAttribute(d, a.j[d])
            }
            a.v || (Fg(Ig(a.A)), a.v = !0)
        },
        Mg = function(a) {
            (a.g || a.o) && Lg(a.F, a.g + "&id=lidar2&r=w&rs=5r&v=0")
        };
    var T = function(a, b, c) {
        N.call(this, a);
        this.data = c
    };
    C(T, N);
    var Ng = function(a, b, c, d) {
        N.call(this, a);
        this.j = b;
        this.F = c;
        this.I = !!d
    };
    C(Ng, N);
    var Og = function(a, b, c, d) {
        b == "Count" && (d = !0);
        Ng.call(this, a, b, !0, d);
        this.o = c
    };
    C(Og, Ng);
    var Pg = function(a, b, c, d) {
        Og.call(this, a, b, c);
        this.videoName = d
    };
    C(Pg, Og);
    var Qg = function(a, b, c, d, e) {
        Ng.call(this, a, b, !1, e);
        this.B = c;
        this.D = d
    };
    C(Qg, Ng);
    var Rg = function(a, b) {
        N.call(this, "reportCustomVariable");
        this.j = a;
        this.o = b
    };
    C(Rg, N);
    var Sg = function(a, b, c, d, e, f) {
        Qg.call(this, a, "Exit", b, !0);
        this.C = c != "null" ? c : null;
        this.o = d != "null" ? d : null;
        this.A = e;
        this.log = f
    };
    C(Sg, Qg);
    var Tg = function(a) {
        N.call(this, "invokeExternalJSFunction");
        this.j = a
    };
    C(Tg, N);
    var Ug = function(a, b, c) {
        N.call(this, "setTimerAdjustment");
        this.j = a;
        this.o = b;
        this.A = c
    };
    C(Ug, N);
    var Vg = function(a) {
        N.call(this, "registerChargeableEventName");
        this.j = a
    };
    C(Vg, N);
    var Wg = function(a, b) {
        N.call(this, "updateVideoProgress");
        this.duration = a;
        this.currentTime = b
    };
    C(Wg, N);

    function Xg(a, b) {
        switch (a) {
            case "logEvent":
                return Yg(b);
            case "logVideoEvent":
                return new Pg("logVideoEvent", b[0], yg[b[2]], b[1]);
            case "updateVideoProgress":
                return new Wg(b[1], b[2]);
            case "logEventFlushCounters":
                return b[0] = "Exit", Yg(b, !0);
            case "logExitFlushEventsOpenPopup":
                return Zg(b, !0);
            case "launchExit":
                return Zg(b, !1);
            case "TURTLEX_AD_CLICKED":
                return new T("TURTLEX_AD_CLICKED", null, b[0]);
            case "recordTimings":
                return new T("recordTimings", null, b[0]);
            case "reportCustomVariable":
                return new Rg(b[0], b[1]);
            case "flushCounters":
                return new N("flushCounters");
            case "conduitInitialized":
                return new T("conduitInitialized", null, {
                    features: b[1] && Array.isArray(b[1]) && b[1].length != 0 ? b[1] : null
                });
            case "expandAsset":
                return new T("expandAsset", null, b.length > 1 ? b[1] : null);
            case "expandRequested":
                return new T("expandRequested", null, b.length > 1 ? b[1] : null);
            case "expandFinished":
            case "collapseAsset":
            case "collapseRequested":
            case "collapseFinished":
            case "tellAssetHide":
                return new T(a);
            case "invokeExternalJSFunction":
                return new Tg(b[0]);
            case "setTimerAdjustment":
                return new Ug(yg[b[0]], parseFloat(b[1]), parseFloat(b[2]));
            case "registerChargeableEventName":
                return new Vg(b[0]);
            case "fullscreenExpandRequested":
                return new T(a, null, b);
            case "setResponsiveBehavior":
                return new T(a, null, {
                    behavior: b[0],
                    state: b[1]
                });
            case "responsiveResize":
                return new T(a, null, {
                    width: b[0],
                    height: b[1]
                });
            case "isFullscreenSupported":
            case "queryFullscreenDimensions":
            case "fullscreenExpandFinished":
            case "fullscreenCollapseRequested":
            case "fullscreenCollapseFinished":
                return new T(a);
            case "AD_CLICKED":
                return new N("AD_CLICKED");
            case "registerEventTypeListenerForType":
                return new T(a, null, {
                    type: b[0],
                    Ad: b[1]
                });
            case "getHostpageFeatures":
                return new T("getHostpageFeatures", null, {
                    type: b[0]
                })
        }
        return null
    }

    function Yg(a, b) {
        var c = a[0],
            d = a[1],
            e = $g(a[3]);
        return $g(a[4]) ? new Qg("logEvent", c, d, e, b) : new Og("logEvent", c, yg[d], b)
    }

    function Zg(a, b) {
        return new Sg("logExitFlushEventsOpenPopup", a[1], a[4], a[5] || null, a[6], b)
    }

    function $g(a) {
        return a != null ? a.toString().toLowerCase() == "true" : !1
    };
    var ah = function(a) {
        a = a ? a.toLowerCase() : "";
        switch (a) {
            case "normal":
                return "normal";
            case "lightbox":
                return "lightbox";
            case "push_down":
                return "push_down"
        }
        return null
    };
    var ch = function(a) {
            this.N = a.eventReportingUrl || "";
            this.B = a.clickUrl || "";
            this.K = a.clickUrlTimesToEscape || "1";
            this.g = a.clickEventTagUrl || "";
            this.o = a.impressionUrl || "";
            this.S = a.geoData || "";
            this.Z = a.siteName || "";
            this.W = a.siteId || "";
            this.I = a.adId || "";
            this.H = a.buyId || "";
            this.creativeId = a.creativeId || "";
            this.U = a.placementId || "";
            this.G = a.advertiserId || "";
            this.T = a.keyValueOrdinal || "";
            this.V = a.renderingId || "";
            this.randomNumber = a.randomNumber || "";
            this.X = a.stringReportingUrl || "";
            this.v = a.bookingTimeMetaData || {};
            this.C = new bh(a.tag || {});
            this.O = a.exitSuffix || "";
            this.F = a.dynamicData || "";
            this.P = a.exitUrlPatternMacroValues;
            this.j = a.placementDimensions || {
                w: "0",
                h: "0"
            };
            this.D = a.activeViewClkStr || "";
            this.A = a.activeViewUrlPrefix || ""
        },
        bh = function(a) {
            this.j = a.adContainerElementId;
            this.g = a.runtimeMetaData || {};
            this.o = !!a.renderFloatInplace
        };
    var dh = function(a, b) {
        this.g = a;
        this.j = b;
        this.o = b == "push_down"
    };

    function eh(a, b, c) {
        this.position = a;
        this.startTime = b;
        this.j = b > -1;
        this.endTime = c;
        this.g = c > -1
    };

    function fh(a, b) {
        this.j = a;
        this.g = G(J(b)) ? "0_0" : b
    };
    var gh = function() {
        this.g = !1
    };
    var ih = function(a, b) {
            this.top = parseInt(a, 10);
            this.j = hh(a);
            this.left = parseInt(b, 10);
            this.g = hh(b)
        },
        hh = function(a) {
            return Oa(jh, function(b) {
                var c = String(b).toLowerCase();
                b = String(a.slice(a.length - b.length)).toLowerCase();
                return (c < b ? -1 : c == b ? 0 : 1) == 0
            }) || "px"
        },
        jh = ["px", "%", "pxc"];
    var kh = {
        Lc: "ad_container_id",
        Yc: "hideObjects",
        md: "mtfTop",
        ld: "mtfLeft",
        wd: "zindex",
        Nc: "mtfDuration",
        vd: "wmode",
        nd: "preferFlash",
        Tc: "as_kw",
        Uc: "as_lat",
        Vc: "as_lng",
        Zc: "mtfIFPath",
        Qc: "expansionMode",
        od: "mtfRenderFloatInplace",
        Mc: "debugjs",
        cd: "dcapp",
        Ic: "breakoutiframe",
        dd: "inMobileAdSdk"
    };
    (function() {
        var a = {};
        Qc(kh, function(b) {
            a[b.toLowerCase()] = b
        });
        return a
    })();
    var lh = function(a, b, c, d) {
        this.left = a;
        this.top = b;
        this.width = c;
        this.height = d
    };
    lh.prototype.contains = function(a) {
        return a instanceof ud ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
    };
    lh.prototype.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    lh.prototype.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    lh.prototype.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var mh = function(a, b, c, d, e) {
            this.id = a;
            this.o = b;
            this.v = c;
            this.F = c == "BANNER" || c == "EXPANDABLE" || c == "VPAID_LINEAR" || c == "VPAID_NON_LINEAR";
            this.width = d.width;
            this.height = d.height;
            this.D = this.B = null;
            this.H = e;
            this.G = null;
            this.C = 0;
            this.layoutsConfig = this.I = this.g = this.j = this.A = null
        },
        nh = {
            adContainerElementId: "ad_container_id",
            zIndex: "zindex",
            expansionMode: "expansionMode",
            duration: "mtfDuration",
            wmode: "wmode",
            top: "mtfTop",
            left: "mtfLeft",
            renderFloatInplace: "mtfRenderFloatInplace"
        },
        oh = function(a) {
            var b = a.g && a.g.g;
            if (b) {
                var c = b.left,
                    d = b.top;
                Math.abs(c) <= 3 && (b.left = 0);
                Math.abs(d) <= 3 && (b.top = 0);
                Math.abs(c + b.width - a.width) <= 3 && (b.left == 0 ? b.width = a.width : b.left = a.width - b.width);
                Math.abs(d + b.height - a.height) <= 3 && (b.top == 0 ? b.height = a.height : b.top = a.height - b.height)
            }
        };
    mh.prototype.toString = function() {
        return "[PrimaryFile " + this.id + "]"
    };
    var ph = function(a, b) {
            var c = b.zindex;
            c != null && (c = parseInt(c, 10), isNaN(c) || (a.C = c));
            c = b.expansionMode;
            c == null || G(J(c)) || a.g === null || (c = ah(c), c !== null && (a.g.j = c));
            if (a.j !== null) {
                c = parseInt(b.mtfDuration, 10);
                isNaN(c) || (a.j.endTime = c, a.j.g = !0);
                c = [];
                var d = b.mtfLeft;
                c[0] = b.mtfTop;
                c[1] = d;
                2 <= c.length && (d = parseInt(c[0], 10), isNaN(d) || (a.j.position.top = d, a.j.position.j = hh(c[0])), d = parseInt(c[1], 10), isNaN(d) || (a.j.position.left = d, a.j.position.g = hh(c[1])))
            }
            c = b.mtfRenderFloatInplace;
            if (a.F || "true" == c) b = b.ad_container_id,
                G(J(b)) || (a.D = b)
        },
        qh = function(a) {
            return typeof a === "number" && !isNaN(a)
        };

    function rh(a, b, c) {
        this.g = a;
        this.j = b;
        this.mb = !!c
    }
    rh.prototype.ha = function() {
        return this.g
    };
    rh.prototype.ping = function() {
        Lg(this.j, this.g, this.mb)
    };
    var sh = {
            Jc: "CLICK",
            bd: "IMPRESSION_JS",
            ad: "IMPRESSION_IMG",
            Fc: "ARTWORK_IMPRESSION",
            Oc: "ENGAGEMENT_IMG",
            Pc: "EXPANSION"
        },
        th = ["IMPRESSION_IMG", "ARTWORK_IMPRESSION"];
    B("THIRD_PARTY_TYPES_TO_PING_AT_IMPRESSION_TIME", th);
    var uh = function(a) {
        a: {
            for (b in sh)
                if (sh[b] == a) {
                    var b = !0;
                    break a
                }
            b = !1
        }
        return b ? a : null
    };
    var vh = {},
        wh = function(a, b) {
            var c = vh[b];
            if (!c) {
                var d = Oc(b);
                c = d;
                a.style[d] === void 0 && (d = (ob ? "Webkit" : nb ? "Moz" : null) + Pc(d), a.style[d] !== void 0 && (c = d));
                vh[b] = c
            }
            return c
        },
        xh = function(a, b) {
            var c = a.style[Oc(b)];
            return typeof c !== "undefined" ? c : a.style[wh(a, b)] || ""
        },
        yh = function(a) {
            a: {
                var b = Cd(a);
                if (b.defaultView && b.defaultView.getComputedStyle && (b = b.defaultView.getComputedStyle(a, null))) {
                    b = b.position || b.getPropertyValue("position") || "";
                    break a
                }
                b = ""
            }
            b || (b = a.currentStyle ? a.currentStyle.position : null);
            return b ||
                a.style && a.style.position
        },
        Ah = function(a, b, c) {
            if (b instanceof L) c = b.height, b = b.width;
            else if (c == void 0) throw Error("missing height argument");
            a.style.width = zh(b, !0);
            a.style.height = zh(c, !0)
        },
        zh = function(a, b) {
            typeof a == "number" && (a = (b ? Math.round(a) : a) + "px");
            return a
        };

    function Bh(a, b, c) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, !1)
    }

    function Ch(a, b, c) {
        typeof a.removeEventListener === "function" && a.removeEventListener(b, c, !1)
    };

    function Dh(a, b, c, d, e) {
        e = e === void 0 ? !1 : e;
        a.google_image_requests || (a.google_image_requests = []);
        var f = sd("IMG", a.document);
        if (d) {
            var g = function() {
                d && Pa(a.google_image_requests, f);
                Ch(f, "load", g);
                Ch(f, "error", g)
            };
            Bh(f, "load", g);
            Bh(f, "error", g)
        }
        c && (f.referrerPolicy = "no-referrer");
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }
    var Eh = Ac(function() {
        return "referrerPolicy" in sd("IMG")
    });
    var Fh = function(a) {
            this.g = !!a
        },
        Lg = function(a, b, c) {
            if (c) {
                if (!a.g && !G(J(b)) && b !== null) {
                    var d = d === void 0 ? !1 : d;
                    var e = e === void 0 ? !1 : e;
                    Eh() ? Dh(window, b, !0, d, e) : (a = u.document, a.body ? (c = a.getElementById("goog-srcless-iframe"), c || (c = sd("IFRAME"), c.style.display = "none", c.id = "goog-srcless-iframe", a.body.appendChild(c)), a = c) : a = null, a && a.contentWindow && Dh(a.contentWindow, b, !0, d, e))
                }
            } else a.g || G(J(b)) || (window.studioV2_image_requests || (window.studioV2_image_requests = []), d = Ad(document, "img"), d.src = b, window.studioV2_image_requests.push(d))
        };

    function Gh() {
        this.o = this.v = this.B = this.height = this.width = this.j = this.target = this.g = "";
        this.A = []
    }
    var Hh = function(a) {
        var b = Oa(a.primaryFiles, function(f) {
            return "BACKUP_IMAGE" == f.renderAs
        });
        if (b === null) return null;
        var c = new Gh;
        c.j = b.url || c.j;
        c.width = b.width || c.width;
        c.height = b.height || c.height;
        c.B = a.impressionUrl;
        b = Oa(a.exitEvents, function(f) {
            return !!f.backUpExit
        });
        b !== null && (b.destinationUrl && (c.g = a.clickUrl ? he(a.clickUrl, b.destinationUrl, b.reportingId) : b.destinationUrl), c.target = b.targetWindow || c.target);
        b = Oa(a.thirdPartyUrls, function(f) {
            return "IMPRESSION_IMG" == f.type
        });
        b !== null && (c.o = b.url ||
            c.o);
        if (a.thirdPartyUrls != null) {
            b = a.thirdPartyUrls;
            for (var d = new Fh(a.previewMode || !1), e = 0; e < b.length; e++) uh(b[e].type) == "CLICK" && c.A.push(new rh(b[e].url, d, b[e].scrub == "true"))
        }
        a = a.eventTrackingBaseUrl;
        a != null && (";" != a.charAt(a.length - 1) && (a += ";"), c.v = a + "met=1;&timestamp=" + +new Date + ";eid1=9;ecn1=1;etm1=0;");
        return c
    };

    function Ih(a, b, c, d) {
        this.name = a;
        this.url = b;
        d != null && (this.url = this.url.indexOf("/") != 0 ? d + "/" + this.url : d + this.url);
        c && (this.url = this.url.replace(/^http:\/\//, "https://"));
        this.g = !1;
        this.j = null
    }
    var Jh = function(a, b) {
        b = new Ih(a.name, a.url, b);
        a.isVideo && (a = a.streamingUrl, b.g = !0, b.j = a || null);
        return b
    };
    var Kh = function(a) {
        this.id = a.id;
        this.uniqueId = a.uniqueId;
        this.j = new ch(a.adServerData || {});
        this.A = a.isPreviewEnvironment;
        this.g = a.thirdPartyImpressionUrls || [];
        this.F = a.thirdPartyArtworkImpressionUrl;
        this.D = a.hasHtmlAsset;
        this.B = a.requiresCss3Animations;
        this.K = a.renderingLibrary || "";
        this.I = a.httpMediaServer || "";
        this.G = a.httpsMediaServer || "";
        this.o = a.dimensions;
        this.H = a.preloaderUrl;
        this.v = a.html5FeatureChecks;
        var b;
        if (b = a.backupImage) {
            a = a.backupImage;
            b = this.A;
            var c = this.j.g,
                d = this.j.o;
            if (a == null) b =
                null;
            else {
                var e = new Gh;
                e.g = a.exitUrl || e.g;
                e.target = a.target || e.target;
                e.j = a.imageUrl || e.j;
                e.width = a.width || e.width;
                e.height = a.height || e.height;
                e.v = a.backupDisplayActivityUrl || e.v;
                e.o = a.thirdPartyBackupImpressionUrl || e.o;
                e.B = d;
                G(J(c)) || (e.A = [new rh(c, new Fh(b))]);
                b = e
            }
        }
        this.C = b || null
    };
    var Lh = function(a, b, c) {
        ug.call(this, a, b, "Exit", !1, !0);
        this.url = c;
        this.o = "_blank";
        this.F = this.j = null
    };
    C(Lh, ug);
    var Mh = function(a, b) {
            this.Ua = a;
            this.ya = b
        },
        Oh = function(a) {
            var b = a.split(":");
            if (b.length == 2 && (a = b[0], b = Nh[b[1]])) return new Mh(a, b)
        },
        Nh = {
            Complete: "VIDEO_COMPLETE",
            Interaction: "VIDEO_INTERACTION",
            MidPoint: "VIDEO_MIDPOINT",
            Mute: "VIDEO_MUTE",
            Pause: "VIDEO_PAUSE",
            Play: "VIDEO_PLAY",
            Replay: "VIDEO_REPLAY",
            Stop: "VIDEO_STOP",
            Unmute: "VIDEO_UNMUTE",
            ViewTime: "VIDEO_VIEW_TIMER"
        };

    function Ph(a, b, c, d) {
        this.g = d;
        d = !1;
        this.g && this.g.ya && (d = xg(this.g.ya).B);
        ug.call(this, a, b, c, !1, d)
    }
    C(Ph, ug);
    var Qh = function(a) {
        var b = a.toLowerCase();
        a = [];
        var c = 0;
        /^https?:\/\//.test(b) ? (a[0] = 0, c = "s" == b.charAt(4) ? 8 : 7) : a[0] = -1;
        a[1] = c;
        b = [b.indexOf(":", c), b.indexOf("/", c), b.indexOf("?", c), b.indexOf("#", c)];
        for (c = 0; c < b.length; ++c)
            if (-1 == b[c]) a[c + 2] = -1;
            else {
                for (var d = !0, e = c + 1; e < b.length; ++e) b[e] > -1 && b[c] > b[e] && (d = !1);
                a[c + 2] = d ? b[c] : -1
            }
        this.g = a
    };
    var Rh = function() {};

    function Sh(a, b) {
        if (typeof a === "boolean") return a;
        if (typeof a === "string") {
            if (a === "true") return !0;
            if (a === "false") return !1
        }
        return b ? b : !1
    };
    var Th = function() {
            this.qa = !1;
            this.F = this.v = this.hb = "";
            this.B = new L(0, 0);
            this.C = "";
            this.G = new L(0, 0);
            this.j = !1;
            this.Ma = "";
            this.ka = [];
            this.Ha = this.pa = !1;
            this.W = null;
            this.g = {};
            this.P = "";
            this.V = this.Ia = this.U = !1;
            this.O = "";
            this.I = {
                va: "",
                wa: ""
            };
            this.A = {};
            this.D = this.Z = this.ba = "";
            this.T = 1;
            this.ea = this.N = "";
            this.ja = null;
            this.o = [];
            this.aa = [];
            this.jb = [];
            this.Na = {};
            this.da = {};
            this.Da = {};
            this.ga = {};
            this.K = {};
            this.X = !1;
            var a = {};
            this.ib = (a.Exit = this.da, a.Timer = this.Da, a.Counter = this.ga, a);
            this.H = this.S = null;
            this.Ca = !1;
            this.gb = 0;
            this.eb = !1;
            this.fb = ""
        },
        Uh = function(a, b) {
            if (G(J(a))) return "";
            var c = new Qh(a);
            var d = c.g[3];
            if (-1 == d) return a;
            a: {
                for (var e = 4; e < c.g.length; ++e)
                    if (-1 != c.g[e]) {
                        c = c.g[e];
                        break a
                    }
                c = -1
            }
            e = -1 == c ? a.substring(d) : a.substring(d, c);
            if (-1 == e.toLowerCase().indexOf(";" + b.toLowerCase() + "=")) e += (";" == e.charAt(e.length - 1) ? "" : ";") + b + "=1;";
            else {
                var f = e.toLowerCase().indexOf(";" + b.toLowerCase() + "="),
                    g = e.indexOf("=", f),
                    k = e.indexOf(";", f + 1);
                e = e.replace(e.substring(f, g + 1) + (-1 == k ? e.substring(g + 1) : e.substring(g + 1,
                    k)), ";" + b + "=1")
            }
            return a.substring(0, d) + e + (-1 == c ? "" : a.substring(c))
        };
    Th.prototype.toString = function() {
        return "Creative_" + this.F
    };
    var Vh = function(a) {
            if (!a.g.CREATIVE_PARAMETER_NEWTON_OT2_TOKEN) return !1;
            try {
                var b = new URL(a.D);
                var c = (new URLSearchParams(b.search)).has("crd")
            } catch (f) {
                return !1
            }
            try {
                var d = new URL(a.N);
                var e = (new URLSearchParams(d.search)).has("crd")
            } catch (f) {
                return !1
            }
            return c && e
        },
        Wh = function(a) {
            return !!a.g.CREATIVE_PARAMETER_TURTLEX_AD_SIGNALS
        },
        Xh = function(a, b) {
            if (b !== void 0) return b in a.A ? Ra(a.A[b]) : [];
            b = [];
            for (var c in a.A) b = Qa(b, a.A[c]);
            return b
        },
        Yh = function(a) {
            var b = [];
            D(a.o, function(c) {
                c.o == "HTML5" && b.push(c)
            });
            return b
        },
        ai = function(a, b, c) {
            var d = Zh(a, b);
            d && (d.reportingId = c, a.Na[b] = d, $h(a, d))
        },
        ci = function(a, b) {
            var c = a.X;
            bi(a, "EXPAND_TIMER", b);
            a.X = c
        },
        bi = function(a, b, c) {
            return (b = a.K[di(b, "Counter") || ""] || a.K[di(b, "Timer") || ""] || Zh(a, b)) ? (b.A = c, a.X = !0) : !1
        },
        $h = function(a, b) {
            if (b) {
                var c;
                (c = b.v ? ei(a, b.name) : b.g ? fi(a, b.g.ya, b.g.Ua) : di(b.name, b.type)) && (a.K[c] = b)
            }
        },
        gi = function(a, b) {
            var c = b.url;
            for (f in a.ja) {
                var d = a.ja[f],
                    e = "(%pKEY=!;|%%PATTERN:KEY%%)".replace(/KEY/g, f);
                c = c.replace(new RegExp(e, "g"), d)
            }
            b.url = c;
            if (!a.j) {
                c =
                    a.ea;
                d = J(c);
                var f = RegExp("http.*http", "i");
                if (e = !G(d)) {
                    e = b.url;
                    a: {
                        for (var g = e.search(ge), k = 0, l = d.length;
                            (k = e.indexOf(d, k)) >= 0 && k < g;) {
                            var p = e.charCodeAt(k - 1);
                            if (p == 38 || p == 63)
                                if (p = e.charCodeAt(k + l), !p || p == 61 || p == 38 || p == 35) {
                                    d = k;
                                    break a
                                }
                            k += l + 1
                        }
                        d = -1
                    }
                    e = !(d >= 0)
                }
                e && !f.test(b.url) && (b.url = fe(b.url, c))
            }
            a.da[b.name] = b;
            $h(a, b)
        },
        ei = function(a, b) {
            return (a = Zh(a, b)) ? [b, escape(""), escape(""), a.type].join(":") : null
        },
        di = function(a, b) {
            return ["CUSTOM_EVENT", escape(a), escape(""), b].join(":")
        },
        fi = function(a, b, c) {
            return (a =
                Zh(a, b)) && [b, escape(""), escape(c), a.type].join(":")
        },
        ii = function(a, b) {
            if (!b) return null;
            if (b.type == "CUSTOM_EVENT" || b.videoName) {
                if (b.type == "CUSTOM_EVENT" && !b.videoName) {
                    var c = b.name;
                    b = b.trigger;
                    a.ib[b] ? (a = a.ib[b], a = a[c] && a[c].reportingId || null) : a = null;
                    return a
                }
                if (b.type != "CUSTOM_EVENT" && b.videoName) {
                    a: switch (c = b.videoName, b = Zh(a, b.type), b.type) {
                        case "Timer":
                            a = hi(a.Da, b, c);
                            a = a != null ? a.reportingId : null;
                            break a;
                        case "Counter":
                            a = hi(a.ga, b, c);
                            a = a != null ? a.reportingId : null;
                            break a;
                        default:
                            a = null
                    }
                    return a
                }
            } else return (a =
                Zh(a, b.type)) ? a.reportingId : null;
            return null
        },
        Zh = function(a, b) {
            return a.Na[b] || (a.Na[b] = xg(b))
        },
        hi = function(a, b, c) {
            for (var d in a) {
                var e = a[d];
                if (e.g && e.g.Ua == c && e.g.ya == b.name) return e
            }
            return null
        };
    Th.prototype.Ka = !1;

    function ji() {
        Q.call(this);
        this.A = new pf(this);
        var a = Ea(ie, this.A);
        this.I ? a() : (this.F || (this.F = []), this.F.push(a))
    }
    C(ji, Q);
    var li = function() {
        var a = ki,
            b = "oa";
        if (a.oa && a.hasOwnProperty(b)) return a.oa;
        var c = new a;
        a.oa = c;
        a.hasOwnProperty(b);
        return c
    };
    var ki = function() {
        ji.call(this);
        this.g = window.mraid || null;
        this.o = !1;
        this.j = null
    };
    t(ki, ji);
    h = ki.prototype;
    h.isVisible = function() {
        return this.g.isViewable()
    };
    h.close = function() {
        return this.g.close()
    };
    h.init = function() {
        this.g.getState() == "loading" ? this.g.addEventListener("ready", w(this.Ja, this)) : this.Ja()
    };
    h.Ja = function() {
        try {
            this.g.removeEventListener("ready", w(this.Ja, this))
        } catch (a) {
            this.g.removeEventListener("ready")
        }
        this.g.addEventListener("viewableChange", w(this.cb, this));
        this.g.addEventListener("stateChange", w(this.ec, this));
        R(this, "ready");
        this.g.isViewable() && this.cb()
    };
    h.ec = function() {
        R(this, "state_change")
    };
    h.cb = function() {
        this.g.isViewable() ? R(this, "show") : R(this, "hide");
        this.o || this.g == null || this.g.AFMA_LIDAR == null || (this.g.addEventListener(this.g.AFMA_LIDAR, w(this.fc, this)), this.o = !0)
    };
    h.fc = function(a) {
        var b = this.g.getCurrentPosition();
        b = a.width * a.height / (b.width * b.height);
        var c = new N("viewable_change");
        c.visibleBox = new sg(a.y, a.x + a.width, a.y + a.height, a.x);
        c.visibilityFraction = b;
        R(this, c)
    };
    var ni = function(a) {
            return !!u.AFMA_Communicator && !!u.AFMA_Communicator.sendMessage && ((a.j && a.j.enable_open_system_browser ? a.j.enable_open_system_browser : !1) || mi(a))
        },
        mi = function(a) {
            return a.j && a.j.enable_use_custom_tabs ? a.j.enable_use_custom_tabs : !1
        },
        oi = function(a, b) {
            return {
                a: "app",
                u: b,
                system_browser: !0,
                use_first_package: !0,
                use_running_process: !0,
                use_custom_tabs: mi(a)
            }
        };
    ki.prototype.J = function() {
        this.g = null;
        ji.prototype.J.call(this)
    };
    var pi = /doubleclick.net\/(pf)?ad/;
    var qi = Ac(function() {
        var a = Ad(document, "DIV"),
            b = ob ? "-webkit" : nb ? "-moz" : null,
            c = "transition:opacity 1s linear;";
        b && (c += b + "-transition:opacity 1s linear;");
        Nc(a, pd({
            style: c
        }));
        return xh(a.firstChild, "transition") != ""
    });
    var ri = function(a) {
            return (a = a.exec($a())) ? a[1] : ""
        },
        nj = function() {
            if (Bb) return ri(/Firefox\/([0-9.]+)/);
            if (lb || mb || kb) return wb;
            if (Fb) {
                if (hb() || H("iPad") || H("iPod") || (Ya && ab && ab.platform ? ab.platform === "macOS" : H("Macintosh"))) {
                    var a = ri(/CriOS\/([0-9.]+)/);
                    if (a) return a
                }
                return ri(/Chrome\/([0-9.]+)/)
            }
            if (Gb && !(hb() || H("iPad") || H("iPod"))) return ri(/Version\/([0-9.]+)/);
            if (Cb || Db) {
                if (a = /Version\/(\S+).*Mobile\/(\S+)/.exec($a())) return a[1] + "." + a[2]
            } else if (Eb) return (a = ri(/Android\s+([0-9.]+)/)) ? a : ri(/Version\/([0-9.]+)/);
            return ""
        }();
    var oj = document.createElement("VIDEO");
    oj && oj.canPlayType && oj.canPlayType("video/mp4").replace(/no/, "");
    var pj = document.createElement("VIDEO");
    pj && pj.canPlayType && pj.canPlayType("video/webm").replace(/no/, "");

    function qj(a, b) {
        if (!u.postMessage) return !1;
        a = Array.isArray(a) ? Ra(a) : [];
        Oa(a, function(c) {
            return c == "Modernizr.canvas"
        }) || a.push("Modernizr.canvas");
        b && !Oa(a, function(c) {
            return c == "Modernizr.cssanimations"
        }) && a.push("Modernizr.cssanimations");
        return Na(a, function(c) {
            if ("svgFilters" == c) {
                if (!(lb && xb() && Number(Ab) >= 10 || Fb && Wa(nj, "18") >= 0 || Bb && Wa(nj, "11") >= 0)) return !1
            } else if ("svgFeImage" == c) {
                if (!(lb && xb() && Number(Ab) >= 10 || Fb && Wa(nj, "29") >= 0)) return !1
            } else if (/Modernizr.canvas/.test(c)) {
                if (!document.createElement("canvas").getContext) return !1
            } else if (/Modernizr.cssanimations/.test(c)) {
                if (c =
                    zd(document).style, c.animationName === void 0 && c[(ob ? "Webkit" : nb ? "Moz" : null) + "AnimationName"] === void 0) return !1
            } else if (/Modernizr.cssgradients/.test(c)) {
                c = "";
                for (var d, e = ["", (ob ? "-webkit" : nb ? "-moz" : null) + "-"], f = 0; f < e.length; f++) d = f === 0 ? "to " : "", c += "background-image:" + e[f] + "linear-gradient(" + d + "left top, #9f9, white);";
                d = Ad(document, "A");
                d.style.cssText = c + "background-image:-webkit-gradient(linear,left top,right bottom,from(#9f9),to(white));";
                if (!(xh(d, "backgroundImage").indexOf("gradient") > -1)) return !1
            } else if (/Modernizr.csstransitions/.test(c) &&
                !qi()) return !1;
            return !0
        })
    };

    function rj(a, b, c, d, e, f, g, k, l, p) {
        if (b) {
            var x = wd(document, c);
            Nc(x, Gg((G(J(b.g)) ? ['<div style="width: ', b.width, "px; height: ", b.height, 'px;"></div>'] : ['<a target="', b.target, '" href="', b.g, '">', '<img src="', b.j, '" ', 'width="', b.width, '" height="', b.height, '" ', 'border="0"></a>']).join("")));
            d = new Fh(d);
            var F = J(b.B);
            G(F) || Lg(d, F);
            Lg(d, b.v);
            Lg(d, b.o);
            for (F = 0; F < e.length; F++) Lg(d, e[F]);
            sj(a);
            p != null && p.length > 0 && tj(p, c);
            a = new Jg(d, f, g, k, l);
            (a.g || a.o) && (a.g || a.o ? Kg(a, x) : a.v || Mg(a));
            G(J(b.g)) || ze(x, "click",
                function() {
                    for (var y = 0; y < b.A.length; y++) b.A[y].ping()
                })
        }
    }

    function tj(a, b) {
        var c = wd(document, b);
        if (c == null) {
            var d;
            (b = document.getElementsByTagName("HEAD")) && b.length > 0 ? d = b[0] : d = document.documentElement;
            D(a, function(e) {
                d.appendChild(uj(e))
            })
        } else D(a, function(e) {
            c.parentNode.insertBefore(uj(e), c.nextSibling)
        })
    }

    function uj(a) {
        var b = Ad(document, "SCRIPT");
        Mc(b, Ig(a));
        b.type = "text/javascript";
        b.async = !1;
        return b
    }

    function sj(a) {
        var b = window.DARTDebugEventHandler;
        if (b) {
            b = new b;
            try {
                b.handleEventActivity("BACKUP_IMAGE_IMPRESSION", "Counter", 1, 0, !1, a)
            } catch (c) {}
        }
    };
    var vj = function(a, b) {
        N.call(this, a);
        this.j = b
    };
    t(vj, N);
    var wj = "EXPAND EXPAND_REQUEST EXPAND_FINISH COLLAPSE COLLAPSE_REQUEST COLLAPSE_FINISH EXPAND_FULL_SCREEN COLLAPSE_FULL_SCREEN SHOW HIDE".split(" ");
    var U = function(a, b) {
        M.call(this);
        this.j = b;
        this.K = new pf(this);
        O(this.K, this.j, wj, this.N);
        this.g = a;
        this.H = [];
        this.G = [];
        this.B = [];
        this.o = [];
        this.D = [];
        this.C = [];
        this.A = [];
        this.v = []
    };
    t(U, M);
    U.prototype.J = function() {
        this.K.dispose();
        this.v = this.A = this.o = this.C = this.D = this.B = this.G = this.H = null;
        M.prototype.J.call(this)
    };
    U.prototype.N = function(a) {
        if (a.j == this.g) {
            var b = null;
            switch (a.type) {
                case "SHOW":
                    b = this.H;
                    break;
                case "HIDE":
                    b = this.G;
                    break;
                case "COLLAPSE_REQUEST":
                    b = this.A;
                    break;
                case "COLLAPSE_FINISH":
                    b = this.v;
                    break;
                case "COLLAPSE":
                    b = this.o;
                    break;
                case "EXPAND":
                    b = this.B;
                    break;
                case "EXPAND_REQUEST":
                    b = this.D;
                    break;
                case "EXPAND_FINISH":
                    b = this.C
            }
            b && xj(this, b)
        }
    };
    var xj = function(a, b) {
            D(b, function(c) {
                c(this)
            }, a)
        },
        yj = function(a) {
            return a.j.j[a.g] || null
        };
    h = U.prototype;
    h.tb = function() {
        return this.g.v
    };
    h.sb = function() {
        return this.g.id
    };
    h.Zb = function() {
        var a = yj(this);
        return a && (a = a.R()) ? (a = new ud(a.offsetLeft, a.offsetTop), {
            x: a.x,
            y: a.y
        }) : null
    };
    h.xb = function(a, b) {
        var c = yj(this);
        if (c) {
            c = c.R();
            if (a instanceof ud) {
                var d = a.x;
                a = a.y
            } else d = a, a = b;
            c.style.left = zh(d, !1);
            c.style.top = zh(a, !1)
        }
    };
    h.yb = function(a) {
        var b = yj(this);
        if (b)
            if (b = b.R(), typeof a === "string")(a = wh(b, a)) && (b.style[a] = void 0);
            else
                for (var c in a) {
                    var d = b,
                        e = a[c],
                        f = wh(d, c);
                    f && (d.style[f] = e)
                }
    };
    h.Yb = function() {
        var a = yj(this);
        if (a) {
            var b = a.R();
            if (b) {
                var c = Cd(b);
                a = new ud(0, 0);
                if (b != (c ? Cd(c) : document).documentElement) {
                    try {
                        var d = b.getBoundingClientRect()
                    } catch (e) {
                        d = {
                            left: 0,
                            top: 0,
                            right: 0,
                            bottom: 0
                        }
                    }
                    b = (c ? new Dd(Cd(c)) : Ga || (Ga = new Dd)).g;
                    c = zd(b);
                    b = b.defaultView;
                    c = new ud(b.pageXOffset || c.scrollLeft, b.pageYOffset || c.scrollTop);
                    a.x = d.left + c.x;
                    a.y = d.top + c.y
                }
                return {
                    x: a.x,
                    y: a.y
                }
            }
        }
        return null
    };
    h.Wa = function() {
        return {
            width: this.g.width,
            height: this.g.height
        }
    };
    h.sa = function(a, b) {
        var c = yj(this);
        c && c.sa(a, b)
    };
    h.Rb = function() {
        var a = this.g.g && this.g.g.g;
        return a ? {
            width: a.width,
            height: a.height
        } : this.Wa()
    };
    h.wb = function(a, b, c, d) {
        var e = yj(this);
        e && (e.R().style.clip = ["rect(", a, "px ", b, "px ", c, "px ", d, "px)"].join(""), e.R().style.position = "absolute")
    };
    h.Sb = function() {
        var a = yj(this);
        return a ? a.R() : null
    };
    h.rb = function() {
        var a = yj(this);
        return a ? a.o : null
    };
    h.Lb = function(a) {
        this.H.push(a)
    };
    h.Ac = function(a) {
        Pa(this.H, a)
    };
    h.Jb = function(a) {
        this.G.push(a)
    };
    h.zc = function(a) {
        Pa(this.G, a)
    };
    h.Gb = function(a) {
        this.B.push(a)
    };
    h.wc = function(a) {
        Pa(this.B, a)
    };
    h.Ib = function(a) {
        this.D.push(a)
    };
    h.yc = function(a) {
        Pa(this.D, a)
    };
    h.Hb = function(a) {
        this.C.push(a)
    };
    h.xc = function(a) {
        Pa(this.C, a)
    };
    h.Db = function(a) {
        this.o.push(a)
    };
    h.tc = function(a) {
        Pa(this.o, a)
    };
    h.Fb = function(a) {
        this.A.push(a)
    };
    h.vc = function(a) {
        Pa(this.A, a)
    };
    h.Eb = function(a) {
        this.v.push(a)
    };
    h.uc = function(a) {
        Pa(this.v, a)
    };
    h.zb = function() {
        zj(this.j, this.g)
    };
    h.ub = function() {
        this.j.P(this.g)
    };
    h.qb = function() {
        Aj(this.j, this.g)
    };
    h.pb = function() {
        Bj(this.j, this.g)
    };
    U.prototype.getType = U.prototype.tb;
    U.prototype.getId = U.prototype.sb;
    U.prototype.getPosition = U.prototype.Zb;
    U.prototype.setPosition = U.prototype.xb;
    U.prototype.setStyle = U.prototype.yb;
    U.prototype.getPagePosition = U.prototype.Yb;
    U.prototype.getDimension = U.prototype.Wa;
    U.prototype.setDimension = U.prototype.sa;
    U.prototype.getCollapsedDimension = U.prototype.Rb;
    U.prototype.setClip = U.prototype.wb;
    U.prototype.getContainerElement = U.prototype.Sb;
    U.prototype.getAssetElement = U.prototype.rb;
    U.prototype.addShowCallback = U.prototype.Lb;
    U.prototype.removeShowCallback = U.prototype.Ac;
    U.prototype.addHideCallback = U.prototype.Jb;
    U.prototype.removeHideCallback = U.prototype.zc;
    U.prototype.addExpandCallback = U.prototype.Gb;
    U.prototype.removeExpandCallback = U.prototype.wc;
    U.prototype.addExpandRequestCallback = U.prototype.Ib;
    U.prototype.removeExpandRequestCallback = U.prototype.yc;
    U.prototype.addExpandFinishCallback = U.prototype.Hb;
    U.prototype.removeExpandFinishCallback = U.prototype.xc;
    U.prototype.addCollapseCallback = U.prototype.Db;
    U.prototype.removeCollapseCallback = U.prototype.tc;
    U.prototype.addCollapseRequestCallback = U.prototype.Fb;
    U.prototype.removeCollapseRequestCallback = U.prototype.vc;
    U.prototype.addCollapseFinishCallback = U.prototype.Eb;
    U.prototype.removeCollapseFinishCallback = U.prototype.uc;
    U.prototype.show = U.prototype.zb;
    U.prototype.hide = U.prototype.ub;
    U.prototype.expand = U.prototype.qb;
    U.prototype.collapse = U.prototype.pb;
    var V = function(a, b) {
        M.call(this);
        this.g = a;
        this.v = b
    };
    t(V, M);
    V.prototype.j = function() {
        return this.g.name
    };
    V.prototype.ha = function() {
        var a = this.g.url;
        return (/^https?/.test(a) ? "" : this.v) + a
    };
    V.prototype.o = function() {
        return this.g.g
    };
    V.prototype.A = function() {
        return this.g.j
    };
    V.prototype.getName = V.prototype.j;
    V.prototype.getUrl = V.prototype.ha;
    V.prototype.isVideo = V.prototype.o;
    V.prototype.getStreamingUrl = V.prototype.A;

    function Cj(a, b) {
        this.g = a;
        this.j = b
    }
    Cj.prototype.o = function() {
        return this.g.name
    };
    Cj.prototype.getName = Cj.prototype.o;
    Cj.prototype.ha = function() {
        return this.g.url
    };
    Cj.prototype.getUrl = Cj.prototype.ha;
    Cj.prototype.v = function(a, b) {
        this.j.Oa(new Sg("logExitFlushEventsOpenPopup", this.g.name, a || null, b || null, null, !0))
    };
    Cj.prototype.fireExit = Cj.prototype.v;
    var X = function(a, b) {
        M.call(this);
        this.j = a;
        this.v = b;
        this.g = Dj(a.o, b);
        Sa(this.g, function(c) {
            return c.g.id
        });
        this.A = Ej(a.aa, (a.V ? a.I.wa : a.I.va) || "");
        this.o = Fj(a.da, b);
        this.AssetTypes = Gj;
        Hj(this)
    };
    t(X, M);
    var Dj = function(a, b) {
            return La(a, function(c) {
                return new U(c, b)
            })
        },
        Ej = function(a, b) {
            return La(a, function(c) {
                return new V(c, b)
            })
        },
        Fj = function(a, b) {
            return La(Sc(a), function(c) {
                return new Cj(c, b)
            })
        },
        Hj = function(a) {
            var b = v("studioV2.api.creatives") || [];
            B("studioV2.api.creatives", b);
            b.push(a)
        };
    h = X.prototype;
    h.J = function() {
        var a = v("studioV2.api.creatives");
        a && Array.isArray(a) && Pa(a, this);
        je(this.g, this.A, this.o);
        M.prototype.J.call(this)
    };
    h.Tb = function() {
        return this.j.F
    };
    h.Nb = function() {
        return this.j.g.cid || ""
    };
    h.Pb = function() {
        return this.g
    };
    h.Ob = function(a) {
        return this.g[a] || null
    };
    h.Wb = function(a) {
        return Oa(this.g, function(b) {
            return b.g.v == a
        })
    };
    h.Qb = function(a) {
        return Ka(this.g, function(b) {
            return b.g.v == a
        })
    };
    h.Vb = function() {
        return this.o
    };
    h.Ec = function() {
        this.v.dispose()
    };
    X.prototype.getApiVersion = function() {
        return ""
    };
    X.prototype.getCreativeId = X.prototype.Tb;
    X.prototype.getSiteId = function() {
        return ""
    };
    X.prototype.getSiteName = function() {
        return ""
    };
    X.prototype.getAdId = function() {
        return ""
    };
    X.prototype.getBuyId = function() {
        return ""
    };
    X.prototype.getAdserverCreativeId = X.prototype.Nb;
    X.prototype.getPlacementId = function() {
        return ""
    };
    X.prototype.getAdvertiserId = function() {
        return ""
    };
    X.prototype.getAssets = X.prototype.Pb;
    X.prototype.getChildAssets = function() {
        return []
    };
    X.prototype.getAssetAt = X.prototype.Ob;
    X.prototype.getAssetById = function() {
        return null
    };
    X.prototype.getFirstAssetByType = X.prototype.Wb;
    X.prototype.getAssetsByType = X.prototype.Qb;
    X.prototype.getExits = X.prototype.Vb;
    X.prototype.unload = X.prototype.Ec;
    var Gj = {
        INPAGE: "BANNER",
        EXPANDING: "EXPANDABLE",
        FLOAT: "FLOATING",
        OVERLAY: "OVERLAY"
    };
    var Ij = void 0,
        Lj = function() {
            Ij === void 0 && (Ij = Oa(Jj, Kj) || "none");
            return Ij
        },
        Kj = function(a) {
            switch (a) {
                case "msn":
                    a: {
                        try {
                            var b = window.$WLXRmAd || window.parent && window.parent.$WLXRmAd;
                            break a
                        } catch (c) {}
                        b = void 0
                    }
                    return !!b;
                case "safe":
                    return !!v("$sf.ext");
                case "mraid":
                    return !!window.mraid;
                default:
                    return !1
            }
        },
        Jj = ["gdn", "mraid", "safe", "msn", "none"];
    var Nj = function(a, b, c, d) {
        M.call(this);
        this.o = a;
        this.B = b;
        this.C = c;
        this.A = d;
        this.v = !1;
        this.g = {};
        this.g.l = !1;
        this.g.i = !1;
        this.g.x = !1;
        this.g.c = !1;
        this.g.r = !1;
        this.g.n = !1;
        this.g.t = !1;
        this.g.m = !1;
        this.j = Mj(this)
    };
    t(Nj, M);
    var Mj = function(a) {
        return a.o.isActive() && Wa(a.A.replace("_", "."), "01.226") != -1 ? ye(u, "unload", function() {
            Oj(this, "u")
        }, void 0, a) : null
    };
    Nj.prototype.J = function() {
        this.j && nf(this.j)
    };
    var Pj = function(a) {
            return Wa(a.A.replace("_", "."), "01.226") != -1 && !a.v && (a.g.u || Rc(a.g, function(b) {
                return b
            }))
        },
        Oj = function(a, b) {
            a.o.g[b] = z() - a.C;
            a.g[b] = !0;
            Pj(a) && (Lg(a.B, a.o.j()), a.v = !0, a.j && nf(a.j))
        };
    var Qj = "undefined_type",
        Rj = 0,
        Sj = null;
    var Uj = function(a) {
        Q.call(this);
        this.g = this.A = null;
        this.j = new pf(this);
        this.C = !1;
        Tj || (this.g = new pg(100), O(this.j, this.g, "tick", this.o), this.g.start(), O(this.j, document, "DOMContentLoaded", this.o), O(this.j, document, "readystatechange", this.o), O(this.j, window, "load", this.B), this.o(), a != null && typeof a === "number" && rg(this.B, a, this))
    };
    t(Uj, Q);
    Uj.prototype.o = function() {
        var a;
        if (a = lb) {
            a = !1;
            try {
                a = window.frameElement == null
            } catch (c) {}
        }
        if (a && document.documentElement.doScroll)
            if (document.documentElement.doScroll) try {
                document.documentElement.doScroll("left");
                var b = !0
            } catch (c) {
                b = !1
            } else b = !1;
            else document.readyState === "undefined" ? document.getElementsByTagName ? (b = document.getElementsByTagName("*"), b = b.length > 0 ? b[b.length - 1] : null, this.A && b && this.A == b ? b = !0 : (this.A = b, b = !1)) : b = !1 : b = document.readyState === "complete";
        b && this.B()
    };
    Uj.prototype.J = function() {
        Vj(this);
        Q.prototype.J.call(this)
    };
    var Vj = function(a) {
        a.j.dispose();
        a.g && (a.g.dispose(), a.g = null)
    };
    Uj.prototype.B = function() {
        this.C || (Tj = this.C = !0, Vj(this), R(this, new N("ready")))
    };
    var Tj = !1;

    function Wj(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    }

    function Xj(a, b) {
        if (b.prerendering) b = 3;
        else {
            var c;
            b = (c = {
                visible: 1,
                hidden: 2,
                prerender: 3,
                preview: 4,
                unloaded: 5,
                "": 0
            }[b.visibilityState || b.webkitVisibilityState || b.mozVisibilityState || ""]) != null ? c : 0
        }
        if (b === 3) return !1;
        a();
        return !0
    }

    function Yj(a) {
        function b() {
            !f && Xj(a, c) && (f = !0, Ch(c, g, b))
        }
        var c = document;
        var d = d === void 0 ? !1 : d;
        if (!Xj(a, c))
            if (d) {
                var e = function() {
                    Ch(c, "prerenderingchange", e);
                    a()
                };
                Bh(c, "prerenderingchange", e)
            } else {
                var f = !1,
                    g = Wj(c);
                g && Bh(c, g, b)
            }
    };
    var Zj = function() {};
    Zj.oa = void 0;
    Zj.g = function() {
        return Zj.oa ? Zj.oa : Zj.oa = new Zj
    };
    Zj.prototype.g = 0;
    var ak = function(a) {
        Q.call(this);
        this.N = a || Ga || (Ga = new Dd);
        this.G = null;
        this.na = !1;
        this.j = null;
        this.A = void 0;
        this.V = this.T = null
    };
    C(ak, Q);
    ak.prototype.ja = Zj.g();
    ak.prototype.U = function() {
        return this.G || (this.G = ":" + (this.ja.g++).toString(36))
    };
    ak.prototype.R = function() {
        return this.j
    };
    var bk = function(a) {
        a.A || (a.A = new pf(a));
        return a.A
    };
    ak.prototype.H = function() {
        this.j = Ed(this.N, "DIV")
    };
    ak.prototype.ra = function(a) {
        ck(this, a)
    };
    ak.prototype.aa = function(a) {
        ck(this, a.parentNode, a)
    };
    var ck = function(a, b, c) {
        if (a.na) throw Error("Component already rendered");
        a.j || a.H();
        b ? b.insertBefore(a.j, c || null) : a.N.g.body.appendChild(a.j);
        a.T && !a.T.na || a.la()
    };
    ak.prototype.ta = function(a) {
        this.j = a
    };
    ak.prototype.la = function() {
        this.na = !0;
        dk(this, function(a) {
            !a.na && a.R() && a.la()
        })
    };
    var ek = function(a) {
        dk(a, function(b) {
            b.na && ek(b)
        });
        a.A && tf(a.A);
        a.na = !1
    };
    ak.prototype.J = function() {
        this.na && ek(this);
        this.A && (this.A.dispose(), delete this.A);
        dk(this, function(a) {
            a.dispose()
        });
        this.j && Bd(this.j);
        this.T = this.j = this.V = null;
        ak.Y.J.call(this)
    };
    var dk = function(a, b) {
        a.V && a.V.forEach(b, void 0)
    };

    function fk(a, b) {
        ak.call(this, b);
        this.ga = a;
        this.ba = null
    }
    C(fk, ak);
    fk.prototype.ra = function(a) {
        this.ga && gk(this);
        fk.Y.ra.call(this, a)
    };
    fk.prototype.aa = function(a) {
        this.ga && gk(this);
        fk.Y.aa.call(this, a)
    };
    var gk = function(a) {
        a.R() || a.H();
        dk(a, function(b) {
            b.ra(a.R())
        })
    };
    fk.prototype.U = function() {
        return this.G || (this.G = (Sj || (Sj = "200_287_" + Qj)) + "_" + (Rj++).toString(36))
    };
    fk.prototype.toString = function() {
        return this.U()
    };
    var hk = function(a) {
            dk(a, function(b) {
                hk(b)
            })
        },
        ik = function(a) {
            dk(a, function(b) {
                ik(b)
            })
        },
        jk = function(a) {
            dk(a, function(b) {
                jk(b)
            })
        },
        kk = function(a) {
            dk(a, function(b) {
                kk(b)
            })
        };
    fk.prototype.sa = function(a, b) {
        Ah(this.R(), a, b);
        dk(this, function(c) {
            c.sa("100%", "100%")
        })
    };
    fk.prototype.Pa = function(a) {
        Yj(a.resolve)
    };

    function lk(a, b, c) {
        fk.call(this, !1, c);
        this.K = a;
        this.B = b;
        if (b = a.g && a.g.g) b = a.g.g, b = new L(b.width, b.height);
        this.qa = b || new L(a.width, a.height);
        this.W = !1;
        this.X = [];
        this.da = null
    }
    C(lk, fk);
    h = lk.prototype;
    h.sc = function() {
        for (this.W = !0; this.X.length > 0;) this.X.shift()
    };
    h.Bc = function() {
        this.W = !1
    };
    h.ta = function(a) {
        lk.Y.ta.call(this, a);
        a.style.position = "relative";
        var b = this.qa;
        if (b instanceof L) {
            var c = b.height;
            b = b.width
        } else throw Error("missing height argument");
        b = parseInt(b, 10) > 0 ? b : "100%";
        c = parseInt(c, 10) > 0 ? c : "100%";
        Ah(a, b, c);
        "boxSizing" in a.style && (a.style.boxSizing = "content-box");
        b = this.B.H;
        (null == b ? 0 : (b.g || b.o) && this.B.o.length == 1) ? Kg(b, a): b != null && (b.g || b.o) && !b.v && Mg(b)
    };
    h.la = function() {
        var a = bk(this);
        O(a, this, "conduitInitialized", this.sc);
        O(a, this, "RESET", this.Bc);
        lk.Y.la.call(this);
        var b = bk(this);
        this.da = new Uj(5E3);
        Tj ? this.Ya() : O(b, this.da, "ready", this.Ya);
        if (b = this.R()) O(a, b, "mouseover", this.dc), O(a, b, "mouseout", this.ab);
        O(a, this, "logEvent", this.Za);
        O(a, this, "logExitFlushEventsOpenPopup", this.Za)
    };
    h.dc = function() {
        mk(this, "1")
    };
    h.ab = function() {
        mk(this, "0")
    };
    h.Za = function(a) {
        vg(a.j) == "Exit" && this.ab()
    };
    var mk = function(a, b) {
            a.W || a.X.push({
                name: "isMouseOver",
                value: b
            })
        },
        nk = function(a, b, c) {
            (b = Xg(b, c)) && R(a, b)
        };
    var Y = function(a) {
        N.call(this, a)
    };
    t(Y, N);
    Y.prototype.Kb = function(a, b) {
        this[a] = b;
        return this
    };
    B("studio.events.StudioEvent", Y);
    Y.prototype.addProperty = Y.prototype.Kb;
    Y.INIT = "init";
    Y.VISIBLE = "visible";
    Y.HIDDEN = "hidden";
    Y.VISIBILITY_CHANGE = "visibilityChange";
    Y.VISIBILITY_CHANGE_WITH_INFO = "visibilityChangeWithInfo";
    Y.EXIT = "exit";
    Y.INTERACTION = "interaction";
    Y.PAGE_LOADED = "pageLoaded";
    Y.ORIENTATION = "orientation";
    Y.ABOUT_TO_EXPAND = "aboutToExpand";
    Y.EXPAND_START = "expandStart";
    Y.EXPAND_FAILED = "expandFailed";
    Y.EXPAND_FINISH = "expandFinish";
    Y.COLLAPSE_START = "collapseStart";
    Y.COLLAPSE_FINISH = "collapseFinish";
    Y.COLLAPSE = "collapse";
    Y.FULLSCREEN_SUPPORT = "fullscreenSupport";
    Y.HOSTPAGE_FEATURES_LOADED = "hostpageFeaturesLoaded";
    Y.FULLSCREEN_DIMENSIONS = "fullscreenDimensions";
    Y.FULLSCREEN_EXPAND_START = "fullscreenExpandStart";
    Y.FULLSCREEN_EXPAND_FINISH = "fullscreenExpandFinish";
    Y.FULLSCREEN_COLLAPSE_START = "fullscreenCollapseStart";
    Y.FULLSCREEN_COLLAPSE_FINISH = "fullscreenCollapseFinish";
    Y.HOSTPAGE_SCROLL = "hostpageScroll";
    Y.OPTIONAL_HOSTPAGE_SCROLL = "optHostpageScroll";
    Y.SCROLL_INTERACTION = "scrollInteraction";
    Y.ENTER_VIEWPORT = "enterViewport";
    Y.OPTIONAL_ENTER_VIEWPORT = "optEnterViewport";
    Y.EXIT_VIEWPORT = "exitViewport";
    Y.OPTIONAL_EXIT_VIEWPORT = "optExitViewport";
    Y.VIDEO_START = "videoStart";
    var ok = ua(["about:blank"]),
        pk = ua(["javascript:undefined"]),
        qk = rd(ok);
    Hc(qk);
    var rk = rd(pk);
    Hc(rk);
    var sk = function() {
        this.g = [];
        this.j = []
    };
    h = sk.prototype;
    h.addReporter = function(a) {
        D(this.g, function(b) {
            b.newReporterCallback(a);
            a.newReporterCallback(b)
        });
        D(this.j, function(b) {
            a.registerChargeableEventName(b)
        });
        this.g.push(a)
    };
    h.reportEvents = function(a) {
        D(this.g, function(b) {
            b.reportEvents(a)
        })
    };
    h.registerChargeableEventName = function(a) {
        D(this.g, function(b) {
            b.registerChargeableEventName(a)
        });
        this.j.push(a)
    };
    h.logCustomVariable = function(a, b) {
        D(this.g, function(c) {
            c.logCustomVariable(a, b)
        })
    };
    h.getType = function() {
        return "UNIFIED_DISPATCHER"
    };
    h.getConfig = function() {
        return {
            reportingApiVersion: 2
        }
    };
    h.newReporterCallback = function() {};
    h.supportsChargeableEvents = function() {
        var a = !1;
        D(this.g, function(b) {
            b.supportsChargeableEvents() && (a = !0)
        });
        return a
    };
    var tk = function(a, b) {
        this.v = a.ba;
        this.j = a.Z;
        this.g = a;
        this.o = b
    };
    tk.prototype.reportEvents = function(a) {
        a = uk(this, a);
        if (a.length)
            for (var b = z(), c = 0; c < a.length; c++) Ad(document, "img").src = this.v + "&timestamp=" + b + ";" + a[c]
    };
    tk.prototype.registerChargeableEventName = function(a) {
        var b = this.g.X;
        bi(this.g, a, !0) && !b && ci(this.g, !1)
    };
    var uk = function(a, b) {
        for (var c = [], d = 0; d < b.length; d++) {
            var e = b[d],
                f = ii(a.g, e.unifiedReportingEvent);
            if (f) {
                var g = c;
                e = ["eid", d + 1, "=", f, ";ecn", d + 1, "=", e.count, ";etm", d + 1, "=", e.time, ";"].join("");
                g.length == 0 && g.push("");
                f = g.pop();
                f.length + e.length > 950 && (g.push(f), f = "");
                g.push(f + e)
            }
        }
        return c
    };
    h = tk.prototype;
    h.logCustomVariable = function(a, b) {
        this.j && this.j.length > 0 && Lg(this.o, [this.j, "&timestamp=", z(), ";str=", a, ";strtype=", b].join(""))
    };
    h.getType = function() {
        return "STUDIO"
    };
    h.getConfig = function() {
        return {
            reportingApiVersion: 2
        }
    };
    h.newReporterCallback = function(a) {
        a.supportsChargeableEvents() && !this.g.X && ci(this.g, !0)
    };
    h.supportsChargeableEvents = function() {
        return !1
    };

    function vk(a) {
        this.v = {};
        this.g = {};
        this.o = {};
        this.G = {};
        this.j = this.Xa(a);
        this.B = a;
        this.C = {};
        this.D = {};
        this.A = {}
    }
    C(vk, M);
    var xk = function(a, b, c, d) {
            if (c || !a.G[b]) a.G[b] || (a.v[b] = 0, a.G[b] = !0), a.v[b]++, d && wk(a, d)
        },
        wk = function(a, b) {
            D(b, function(c) {
                D(Xh(this.B, c), function(d) {
                    d.ping()
                }, this)
            }, a)
        },
        yk = function(a, b, c, d) {
            if (!(b in a.o)) {
                for (var e = z(), f = a.C[b]; f && f.length > 0;) e += f.pop();
                a.o[b] = e;
                c && (a.A[c] = a.A[c] || [], a.A[c].push(b));
                xk(a, b, !1, d)
            }
        },
        zk = function(a, b, c) {
            if (b in a.o) {
                for (var d = a.o[b], e = z(), f = a.D[b]; f && f.length > 0;) e += f.pop();
                d = e - d;
                d < 0 && (d = 0);
                a.g[b] = a.g[b] || 0;
                a.g[b] += d;
                delete a.o[b];
                c && a.A[c] && Pa(a.A[c], b)
            }
        },
        Ak = function(a) {
            for (var b in a.o) zk(a,
                b)
        },
        Bk = function(a) {
            for (var b in a.o) zk(a, b), yk(a, b);
            b = [];
            for (var c in a.v) {
                var d = 0,
                    e = a.v[c];
                a.g[c] && (d = Math.floor(a.g[c] / 1E3), a.g[c] -= d * 1E3);
                a.v[c] = 0;
                if (e > 0 || d > 0) {
                    var f = b,
                        g = f.push,
                        k = c.match(/([^:]+):([^:]*):([^:]*):(.+)/);
                    g.call(f, {
                        unifiedReportingEvent: k && k.length == 5 ? {
                            type: k[1],
                            name: unescape(k[2]),
                            videoName: unescape(k[3]),
                            trigger: k[4]
                        } : null,
                        count: e,
                        time: d
                    })
                }
            }
            if (Wh(a.B)) {
                if (c = a.j, (a = a.B.g.CREATIVE_PARAMETER_TURTLEX_AD_SIGNALS) && b.length != 0) {
                    b = uk(c, b).join(";");
                    a = {
                        Ta: a,
                        label: "rm_html5_event",
                        kb: b
                    };
                    var l = l === void 0 ? u : l;
                    b = new wc;
                    a != null && (a.Ta != null && sc(b, 1, a.Ta), a.Dc != null && sc(b, 3, a.Dc), a.label != null && sc(b, 6, a.label), a.kc != null && sc(b, 7, a.kc), a.Mb != null && sc(b, 8, a.Mb), a.kb != null && sc(b, 11, a.kb));
                    var p;
                    (p = yc(l).fence) == null || p.reportEvent({
                        eventType: "interaction",
                        eventData: uc(b),
                        destination: ["buyer"]
                    })
                }
            } else a.j.reportEvents(b)
        };
    vk.prototype.J = function() {
        Ak(this);
        vk.Y.J.call(this)
    };
    var Ck = function(a) {
        this.o = a;
        this.j = !1;
        this.g = new ae
    };
    h = Ck.prototype;
    h.reportEvents = function(a) {
        this.j || D(a, function(b) {
            this.g.has(b.unifiedReportingEvent.name) && (this.j = !0, D(Xh(this.o, "ENGAGEMENT_IMG"), function(c) {
                c.ping()
            }))
        }, this)
    };
    h.registerChargeableEventName = function(a) {
        this.g.add(a)
    };
    h.logCustomVariable = function() {};
    h.getType = function() {
        return "THIRD_PARTY"
    };
    h.getConfig = function() {
        return {
            reportingApiVersion: 2
        }
    };
    h.newReporterCallback = function() {};
    h.supportsChargeableEvents = function() {
        return !1
    };

    function Dk(a, b) {
        this.H = b;
        vk.call(this, a)
    }
    C(Dk, vk);
    h = Dk.prototype;
    h.Xa = function(a) {
        if ("gdn" == Lj()) {
            var b = v("googlecreative.reporting.sharedReporter");
            b || (b = new sk, B("googlecreative.reporting.sharedReporter", b));
            b.addReporter(new tk(a, this.H));
            0 < Xh(a, "ENGAGEMENT_IMG").length && b.addReporter(new Ck(a))
        } else b = new tk(a, this.H);
        return b
    };
    h.Fa = function() {};
    h.Ea = function() {};
    h.Ra = function(a, b) {
        this.j.logCustomVariable(a, b)
    };
    h.Sa = function(a) {
        this.j.registerChargeableEventName(a)
    };
    var Ek = function(a) {
        M.call(this);
        this.A = a;
        this.v = null;
        this.C = !1;
        this.o = null;
        this.j = []
    };
    t(Ek, M);
    h = Ek.prototype;
    h.Qa = function() {};
    h.bb = function() {};
    h.ca = function() {
        var a;
        if (a = this.La()) {
            a: {
                a = this.A;
                for (c in a.v) {
                    var b = a.B.K[c];
                    if (b && b.B) {
                        var c = !0;
                        break a
                    }
                }
                c = !1
            }
            a = c || !this.Ga()
        }
        a && (Bk(this.A), this.o = z())
    };
    h.Ga = function() {
        return this.o != null && z() - this.o <= 5E3
    };
    h.La = function() {
        return this.v != null && z() - this.v <= 12E5
    };
    h.J = function() {
        for (this.ca(); this.j.length > 0;) {
            var a = this.j.pop();
            typeof a === "number" ? u.clearTimeout(a) : a.dispose()
        }
        M.prototype.J.call(this)
    };
    var Fk = function(a, b, c) {
        Ek.call(this, a);
        this.B = b;
        this.D = c;
        this.g = new pg(this.B * 1E3);
        ze(this.g, "tick", w(this.ca, this))
    };
    t(Fk, Ek);
    h = Fk.prototype;
    h.bb = function() {
        this.g.j || this.g.start()
    };
    h.ca = function() {
        qg(this.g);
        Ek.prototype.ca.call(this)
    };
    h.La = function() {
        return this.v != null && this.D || Ek.prototype.La.call(this)
    };
    h.Ga = function() {
        return !1
    };
    h.J = function() {
        qg(this.g);
        this.g.dispose();
        Ek.prototype.J.call(this)
    };
    var Gk = function(a, b, c) {
        Ek.call(this, a);
        this.g = b;
        this.B = c && this.g.length > 0 ? this.g.pop() : null
    };
    t(Gk, Ek);
    Gk.prototype.Qa = function() {
        for (var a = 0; a < this.g.length; a++) this.j.push(rg(w(this.ca, this), this.g[a] * 1E3));
        this.B != null && (a = new pg(this.B * 1E3), ze(a, "tick", w(this.ca, this)), a.start(), this.j.push(a))
    };
    var Hk = [10, 20, 50, 120];
    var Ik = function(a) {
        this.g = a;
        this.j = typeof DARTDebugEventHandler != "undefined" && DARTDebugEventHandler ? new DARTDebugEventHandler : null;
        G(J(this.g.Ma)) || DARTDebugEventHandler.initPreviewSession(this.g.Ma)
    };
    h = Ik.prototype;
    h.Fa = function(a, b, c) {
        a = this.g.K[a];
        if (this.j) try {
            this.j.handleEventAction(b, a.name, c, a.type, !a.v, this.g.v)
        } catch (d) {}
    };
    h.reportEvents = function(a) {
        if (this.j)
            for (var b = 0; b < a.length; ++b) {
                var c = a[b],
                    d = c.unifiedReportingEvent;
                d = this.g.K[[d.type, escape(d.name), escape(d.videoName), d.trigger].join(":")];
                try {
                    this.j.handleEventActivity(d.name, d.type, c.count, c.time, !d.v, this.g.v)
                } catch (e) {}
            }
    };
    h.registerChargeableEventName = function() {};
    h.Ea = function(a) {
        try {
            this.j.handleCustomJSExecution(a, this.g.v)
        } catch (b) {}
    };
    h.logCustomVariable = function(a, b) {
        try {
            this.j.handleCustomVariable(unescape(a), b, this.g.v)
        } catch (c) {}
    };
    h.getType = function() {
        return "OUTPUT_CONSOLE"
    };
    h.getConfig = function() {
        return {
            reportingApiVersion: 2
        }
    };
    h.newReporterCallback = function() {};
    h.supportsChargeableEvents = function() {
        return !1
    };
    var Jk = function(a) {
        vk.call(this, a)
    };
    t(Jk, vk);
    h = Jk.prototype;
    h.Xa = function(a) {
        return new Ik(a)
    };
    h.Fa = function(a, b, c) {
        this.j.Fa(a, b, c)
    };
    h.Ea = function(a) {
        this.j.Ea(a)
    };
    h.Ra = function(a, b) {
        this.j.logCustomVariable(a, b)
    };
    h.Sa = function() {};
    var Kk = function(a, b, c) {
        Ek.call(this, a);
        this.g = b;
        this.B = c
    };
    t(Kk, Ek);
    Kk.prototype.Ga = function() {
        return this.B && Ek.prototype.Ga.call(this)
    };
    Kk.prototype.Qa = function() {
        var a = new pg(this.g * 1E3);
        ze(a, "tick", w(this.ca, this));
        a.start();
        this.j.push(a)
    };
    var Lk = function(a, b, c, d, e, f, g) {
        var k = new wc;
        sc(k, 1, a);
        sc(k, 5, c);
        a = new vc;
        d !== void 0 && rc(a, 2, d == null ? d : hc(d));
        e !== void 0 && rc(a, 3, e == null ? e : hc(e));
        f && sc(a, 7, f);
        g && sc(a, 4, g);
        d = uc(a);
        sc(k, 4, d);
        if (Fb && Wa(nj, 116) >= 0) {
            var l;
            (l = window.fence) == null || l.setReportEventDataForAutomaticBeacons({
                eventType: "reserved.top_navigation",
                eventData: uc(k),
                destination: ["buyer"],
                once: !0
            })
        } else {
            var p;
            (p = window.fence) == null || p.setReportEventDataForAutomaticBeacons({
                eventType: "reserved.top_navigation",
                eventData: uc(k),
                destination: ["buyer"]
            })
        }
        var x;
        (x = window.fence) == null || x.setReportEventDataForAutomaticBeacons({
            eventType: "reserved.top_navigation_start",
            eventData: uc(k),
            destination: ["buyer"]
        });
        var F;
        (F = window.fence) == null || F.reportEvent({
            eventType: "click",
            eventData: uc(k),
            destination: ["buyer"]
        });
        b = b ? {
            eventType: "click",
            eventData: b,
            destination: ["component-seller"]
        } : {
            eventType: "click",
            destination: ["component-seller"]
        };
        var y;
        (y = window.fence) == null || y.reportEvent(b)
    };

    function Z(a, b, c, d) {
        Q.call(this);
        this.g = a;
        this.ka = b;
        this.B = c;
        this.j = {};
        this.K = {};
        this.G = new pf(this);
        this.S = this.T = !1;
        this.C = this.V = 0;
        this.D = [];
        this.N = {};
        this.X = new X(this.g, this);
        this.H = d;
        this.o = a.j ? new Jk(a) : new Dk(a, this.H);
        this.A = Mk(a, this.o);
        this.O = {};
        lb && O(this.G, self, "unload", this.dispose);
        O(this.G, u, "pagehide", w(this.A.ca, this.A));
        this.B.g != null && (this.B.init(), this.B.j = this.g.W);
        Jd(1);
        Jd(64);
        window.layoutsPreview && Jd(16);
        "gdn" == Lj() && Jd(32);
        this.g.j && Jd(256);
        this.B.g != null && Jd(8)
    }
    C(Z, Q);
    var Nk = {},
        Mk = function(a, b) {
            var c = !1;
            D(a.o, function(d) {
                d.g != null && d.g.j == "lightbox" && (c = !0)
            });
            return a.j ? new Kk(b, 2, !1) : c ? new Fk(b, 2, !0) : new Gk(b, Hk, !0)
        };
    Z.prototype.ea = function() {
        this.C++;
        Ok(this)
    };
    Z.prototype.ba = function() {
        Pk(this, new Og("logEvent", "Count", "FULL_SCREEN"))
    };
    Z.prototype.ga = function(a) {
        typeof a.F === "boolean" && a.F ? Pk(this, a) : Qk(this, a);
        a.I && this.A.ca()
    };
    Z.prototype.aa = function() {
        this.A.ca()
    };
    var Qk = function(a, b) {
            var c = vg(b.j);
            c = di(b.B, c);
            c != null && Rk(a, c, b.j, b.D, b.g)
        },
        Rk = function(a, b, c, d, e, f) {
            if (b !== null) switch (a.o.Fa(b, c, d), c) {
                case "Exit":
                    f || (f = []), f.push("CLICK");
                case "Count":
                    xk(a.o, b, d, f);
                    b = a.g.K[b];
                    c = !1;
                    b && b.A && (b = a.A, b.C ? c = !1 : (Bk(b.A), b.o = z(), c = b.C = !0));
                    c || a.A.bb();
                    break;
                case "Start":
                    yk(a.o, b, e, f);
                    break;
                case "Stop":
                    zk(a.o, b, e)
            }
        },
        Pk = function(a, b) {
            if (b.o == "DISPLAY_TIMER") b.j == "Start" && (a.T || (Sk(a).then(a.W, void 0, a), a.T = !0), a.V++ == 0 && (b = ei(a.g, "DISPLAY_TIMER")) && Rk(a, b, "Start", !1),
                a.C--);
            else {
                var c = ei(a.g, b.o);
                if (c) {
                    var d = [];
                    (b.o == "FULL_SCREEN" || b.o == "EXPAND_TIMER" && b.j == "Start") && d.push("EXPANSION");
                    Rk(a, c, b.j, !1, b.g, d)
                }
            }
        };
    h = Z.prototype;
    h.lc = function(a) {
        Pk(this, a);
        var b = fi(this.g, a.o, a.videoName);
        b != null && Rk(this, b, a.j, !1, a.g)
    };
    h.nb = function() {
        var a = ei(this.g, "DISPLAY_TIMER");
        a && Rk(this, a, "Stop", !1)
    };
    h.Oa = function(a) {
        var b = this.g.da[a.B] || {},
            c = a.C != null ? a.C : b.url;
        a.o == null || G(J(a.o)) || (c = fe(c, a.o));
        var d = this.g.T,
            e = Xh(this.g, "CLICK"),
            f = 1 == e.length ? e[0].ha() : "",
            g = c;
        e = a.A != null ? a.A : this.g.D;
        "market" == (c.match(de)[1] || null) && pb ? (c = he(this.g.D, "http://ad.doubleclick.net/viewad/817-grey.gif", b.reportingId || null, f, d), Lg(this.H, c)) : g = he(e, c, b.reportingId || null, f, d);
        c = g;
        d = b.o;
        b = b.j != null ? b.j : void 0;
        this.B.g != null ? (b = this.B, pi.test(c) ? b.g.expand(c) : ni(b) ? u.AFMA_Communicator.sendMessage("open", oi(b, c)) :
            b.g.open(c)) : window.open(c, d || "_blank", b || "");
        a.log && e.indexOf("[rm_exit_id]") == -1 && Qk(this, a);
        this.A.ca()
    };
    h.hc = function(a) {
        var b = this.K[a.g];
        switch (a.type) {
            case "expandAsset":
                Aj(this, b);
                break;
            case "expandRequested":
                Aj(this, b);
                break;
            case "expandFinished":
                if (a = this.j[b]) ik(a), R(this, new vj("EXPAND_FINISH", b));
                break;
            case "collapseAsset":
                Bj(this, b);
                break;
            case "collapseRequested":
                Bj(this, b);
                break;
            case "collapseFinished":
                if (a = this.j[b]) kk(a), R(this, new vj("COLLAPSE_FINISH", b));
                break;
            case "tellAssetHide":
                this.P(b)
        }
    };
    h.bc = function(a) {
        a = unescape(a.j);
        this.g.j && this.o.Ea(a);
        try {
            eval(a)
        } catch (b) {}
    };
    h.ac = function(a) {
        var b = ei(this.g, a.j);
        if (b) {
            var c = this.o,
                d = a.o;
            a = a.A;
            var e = c.C[b] || (c.C[b] = []);
            b = c.D[b] || (c.D[b] = []);
            d != 0 && e.push(d);
            a != 0 && b.push(a)
        }
    };
    h.cc = function(a) {
        this.o.Ra(a.j, a.o)
    };
    h.Ab = function(a) {
        var b = this.g.g.CREATIVE_PARAMETER_TURTLEX_AD_SIGNALS,
            c = this.g.g.CREATIVE_PARAMETER_TURTLEX_AD_METADATA,
            d = a.data.reportingId;
        b && d && Lk(b, c, d, a.data.clickX, a.data.clickY, a.data.creativeDims, a.data.bgResponse)
    };
    h.init = function() {
        var a = Xh(this.g, "IMPRESSION_JS");
        a.length > 0 && (a = La(a, function(b) {
            return b.ha()
        }), tj(a, this.g.P));
        Tk(this)
    };
    var Tk = function(a) {
            for (var b = a.g.o, c = 0; c < b.length; c++) {
                var d = b[c],
                    e = d.j;
                zj(a, d, e && !e.j ? -1 : (e && e.j && e.startTime > 0 && e.startTime || 0) * 1E3)
            }
        },
        zj = function(a, b, c) {
            c ? c > 0 && (a.C++, a.D.push(rg(w(a.U, a, b), c))) : (a.C++, a.U(b))
        };
    Z.prototype.U = function(a) {
        if (!(a in this.j)) {
            var b = this.ka.g(a) ? new Uk(a, this.g) : null;
            if (b) {
                this.j[a] = b;
                this.K[b] = a;
                b = this.j[a];
                var c = this.G;
                O(c, b, "logEvent", this.ga);
                O(c, b, "logVideoEvent", this.lc);
                O(c, b, "logExitFlushEventsOpenPopup", this.Oa);
                O(c, b, "launchExit", this.Oa);
                Wh(this.g) && O(c, b, "TURTLEX_AD_CLICKED", this.Ab);
                O(c, b, "expandAsset expandRequested expandFinished collapseAsset collapseRequested collapseFinished tellAssetHide".split(" "), this.hc);
                O(c, b, "invokeExternalJSFunction", this.bc);
                O(c, b,
                    "reportCustomVariable", this.cc);
                O(c, b, "setTimerAdjustment", this.ac);
                O(c, b, "flushCounters", this.aa);
                O(c, b, "RESET", this.ea);
                O(c, b, "registerChargeableEventName", this.da);
                O(c, b, "fullscreenExpandFinished", this.ba);
                if (a.F || this.g.U) {
                    if (b = a.D, c = null, b && (c = wd(document, b)), c) {
                        var d;
                        if (d = this.g.U) d = c, d = !(!G(J(yh(d))) && "static" != yh(d));
                        d && (c.style.position = "relative");
                        this.g.Ia && (c.style.display = "inline-block", c.style.verticalAlign = "top");
                        a.g && a.g.o && (this.O[b] = c.style.height, c.style.height = "auto");
                        this.j[a].ra(c)
                    }
                } else document.body &&
                    document.body.firstChild ? this.j[a].aa(document.body.firstChild) : document.body ? this.j[a].ra(document.body) : document.documentElement && this.j[a].ra(document.documentElement);
                R(this, new vj("SHOW", a))
            }
        }
        a.j && (b = a.j, b = (b && b.g && b.endTime > 0 && b.endTime || -1) * 1E3, b > 0 && (b = rg(w(this.P, this, a), b), this.D.push(b), this.N[a] = b));
        this.S || (Sk(this).then(this.ja, void 0, this), this.S = !0);
        this.g.eb && Vk(this)
    };
    var Vk = function(a) {
            var b = a.g.fb;
            b ? (b = u["bllsn" + b], typeof b !== "function" ? setTimeout(function() {
                throw Error("atw: blockListenCallback is not a function");
            }, 0) : b(function(c) {
                if (c && !c.block) {
                    c = a.g.o;
                    for (var d = 0; d < c.length; d++);
                }
            })) : setTimeout(function() {
                throw Error("atw: eeid is missing");
            }, 0)
        },
        Sk = function(a) {
            var b = [];
            Qc(a.j, function(d, e) {
                d = b.push;
                e = this.j[e];
                if (e.ba !== null) e = e.ba;
                else {
                    var f = Qf();
                    e.Pa(f);
                    e = e.ba = f.promise
                }
                d.call(b, e)
            }, a);
            if (a.g.gb === 8)
                if (a = td(), a == null) setTimeout(function() {
                    throw Error("vignette: no interstitial API");
                }, 0);
                else {
                    var c = Qf();
                    a.addViewListener(c.resolve);
                    b.push(c.promise)
                }
            return Of(b)
        };
    Z.prototype.P = function(a) {
        var b = this.j[a];
        if (b) {
            for (var c = this.o, d = c.A[b] || []; d.length > 0;) zk(c, d.pop(), b);
            delete this.K[b];
            b.dispose();
            delete this.j[a];
            this.N[a] && (u.clearTimeout(this.N[a]), delete this.N[a]);
            R(this, new vj("HIDE", a));
            Ok(this)
        }
    };
    var Aj = function(a, b) {
            var c = a.j[b];
            c && (hk(c), R(a, new vj("EXPAND", b)), R(a, new vj("EXPAND_REQUEST", b)))
        },
        Bj = function(a, b) {
            var c = a.j[b];
            c && (jk(c), R(a, new vj("COLLAPSE", b)), R(a, new vj("COLLAPSE_REQUEST", b)))
        };
    Z.prototype.ja = function() {
        Wk(this)
    };
    var Wk = function(a) {
        a.A.v = z();
        a.g.Ka && Pk(a, new Og("logEvent", "Count", "HTML5_CREATIVE_IMPRESSION"));
        Wh(a.g) ? typeof window.vv === "function" && window.vv() : a.g.Ha && (a.g.Ca && !a.g.j ? typeof window.vv === "function" ? window.vv() : Lg(a.H, xc(a.g.N)) : Lg(a.H, a.g.N));
        var b = [];
        th.forEach(function(c) {
            b.push.apply(b, sa(Xh(a.g, c)))
        });
        a.g.Ca && typeof window.pdib3 === "function" && !a.g.j ? b.forEach(function(c) {
            var d = c.ha();
            G(J(d)) || (c.mb ? yc().pdib3(d, !0) : yc().pdib3(d, !1))
        }) : b.forEach(function(c) {
            c.ping()
        })
    };
    Z.prototype.W = function() {
        this.A.Qa();
        this.D.push(rg(w(this.nb, this), 24E4))
    };
    var Ok = function(a) {
        --a.V == 0 && (a.nb(), Ak(a.o), a.C == 0 && a.dispose())
    };
    Z.prototype.da = function(a) {
        this.o.Sa(a.j)
    };
    Z.prototype.J = function() {
        for (var a in this.O) wd(document, a).style.height = this.O[a];
        this.G.dispose();
        for (this.X.dispose(); this.D.length > 0;) a = this.D.pop(), u.clearTimeout(a);
        a = this.g.o;
        for (var b = 0; b < a.length; b++) {
            var c = a[b];
            c in this.j && (this.j[c].dispose(), delete this.j[c])
        }
        this.K = null;
        this.o.dispose();
        this.o = null;
        a = this.g.F;
        Nk[a] !== void 0 && delete Nk[a];
        Z.Y.J.call(this)
    };
    var Xk = function(a, b, c, d) {
        Fd.call(this, a, b);
        this.g = {};
        this.C = c;
        this.B = d;
        this.o = "rmad_perf"
    };
    t(Xk, Fd);
    Xk.prototype.j = function() {
        var a = "&rl=" + this.C + "&en=" + this.B;
        a: {
            for (b in this.g) {
                var b = !1;
                break a
            }
            b = !0
        }
        if (!b) {
            b = this.g;
            var c = [],
                d;
            for (d in b) ee(d, b[d], c);
            a += "&" + c.join("&")
        }
        this.v = a;
        return Fd.prototype.j.call(this)
    };
    var Yk = function(a, b) {
        Fd.call(this, a, "");
        this.B = b;
        this.o = "studio-rl-error";
        this.g = null
    };
    t(Yk, Fd);
    Yk.prototype.j = function() {
        if (null === this.g) return "";
        var a = "&rl=" + this.B + "&err=",
            b = encodeURIComponent;
        if (typeof this.g === "string") var c = this.g;
        else if (this.g instanceof Error) {
            var d = this.g;
            c = d.toString();
            d.name && c.indexOf(d.name) == -1 && (c += ": " + d.name);
            d.message && c.indexOf(d.message) == -1 && (c += ": " + d.message);
            if (d.stack) a: {
                d = d.stack;
                var e = c;
                try {
                    d.indexOf(e) == -1 && (d = e + "\n" + d);
                    for (var f; d != f;) f = d, d = d.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                    c = d.replace(RegExp("\n *", "g"), "\n");
                    break a
                } catch (g) {
                    c =
                        e;
                    break a
                }
                c = void 0
            }
        } else c = "Failed to capture error message from: " + this.g.toString();
        this.v = a + b(c);
        return Fd.prototype.j.call(this)
    };
    var Zk = function(a) {
        M.call(this);
        this.A = a + ".js";
        this.j = new Yk(.001, a);
        this.g = this.o = null
    };
    t(Zk, M);
    Zk.prototype.isActive = function() {
        return this.j.isActive()
    };
    Zk.prototype.v = function(a) {
        var b;
        if (b = a instanceof ErrorEvent) {
            b = a.filename;
            var c = this.A,
                d = b.length - c.length;
            b = d >= 0 && b.indexOf(c, d) == d
        }
        b && (this.j.g = a.error instanceof Error ? a.error : a.message, a = this.j.j(), Dh(u, a, !1, !1, !1))
    };
    Zk.prototype.J = function() {
        this.g && this.o.removeEventListener("error", this.g, !1);
        M.prototype.J.call(this)
    };
    var $k = function(a) {
        this.g = a
    };
    var al = function() {
        M.call(this);
        this.C = {};
        this.j = this.g = null;
        this.o = [];
        this.v = !0
    };
    t(al, M);
    var bl = function(a, b, c) {
        a.v = !1;
        a.g === null && (a.g = new P(typeof(u.MutationObserver || u.WebKitMutationObserver) === "function" ? a.B : a.A, a));
        Tf(a.g.then(b, function() {}, c), function() {
            this.j !== null && this.j.disconnect();
            this.v = !0
        }, a)
    };
    al.prototype.B = function(a) {
        cl(this) ? a() : (this.j = new u.MutationObserver(w(function(b, c) {
            var d = !1;
            D(b, function(e) {
                "childList" == e.type && 0 != e.addedNodes.length && (d = !0)
            });
            d && cl(this) && (c.disconnect(), a())
        }, this)), this.j.observe(u.document.documentElement, {
            childList: !0,
            subtree: !0
        }))
    };
    al.prototype.A = function(a) {
        var b = new Uj(1500);
        Tj ? cl(this) && a() : ze(b, "ready", function() {
            cl(this) ? a() : rg(function() {
                cl(this) && a()
            }, 0, this)
        }, !1, this)
    };
    var cl = function(a) {
        for (var b = a.o.length - 1; b >= 0; --b) {
            var c = a.o[b];
            if (wd(document, c) === null) {
                b: {
                    var d = window;
                    try {
                        var e = d.parent.document;
                        break b
                    } catch (f) {}
                    e = void 0
                }
                c = e ? e.getElementById(c) !== null : !1
            }
            else c = !0;
            if (!c) return a.o.length = b + 1, !1
        }
        a.o = [];
        return !0
    };
    al.prototype.J = function() {
        this.g !== null && this.g.cancel();
        this.g = null;
        this.j !== null && this.j.disconnect();
        this.j = null
    };
    var dl = null,
        el = null,
        fl = function(a, b) {
            return La(Xh(a, b), function(c) {
                return c.ha()
            })
        },
        gl = function(a) {
            var b = Yh(a).length > 0,
                c = a.ka;
            a = a.pa;
            return b && qj(c, a)
        },
        il = function(a) {
            var b = "",
                c = v("dclkStudioV3.startTimes." + a.F),
                d = Yh(a);
            d.length > 0 && (b = (b = d[0].A) && b.g ? b.g : "");
            d = !G(b) && "0_0" !== b;
            c && d ? (a = hl(el, a.j), c = new Nj(new Xk(4E-5, "https:", "200_287", b), a, c, b)) : c = null;
            return c
        },
        kl = function(a) {
            if (gl(a)) {
                var b = il(a);
                b && Oj(b, "l");
                var c = new al;
                D(a.o, function(e) {
                    e = e.D;
                    e != null && c.v && (e = new $k(e), c.g = null, c.C["."] = e, c.o.push(e.g))
                });
                a = jl(a, b);
                bl(c, a.init, a)
            } else if (a.S) {
                b = fl(a, "IMPRESSION_IMG");
                var d = fl(a, "IMPRESSION_JS");
                rj(a.v, a.S, a.P, a.j, b, a.H.g, a.H.B, a.H.A, a.H.j, d)
            }
        },
        ml = function() {
            ll().then(function(a) {
                D(a, kl)
            })
        },
        nl = function(a) {
            Nk[a] && Nk[a].dispose()
        };
    var ol = function(a, b) {
        if (a.videoData) {
            var c = a.videoData;
            c = new Mh(c.associatedVideoEntryReportingIdentifier, c.associatedStandardVideoEvent)
        }
        return new Ph(a.name, a.reportingId, b, c)
    };
    var pl = function(a) {
        return JSON.parse(a.replace(/\\"/g, '"'))
    };

    function ql() {}
    var ll = function() {
        var a = rl();
        return new P(function(b) {
            var c = [],
                d = v("studioV2.creatives") || {},
                e;
            for (e in d) {
                var f = d[e],
                    g = f.creativeDefinition;
                if (g)
                    for (var k = f.adResponses; k.length > 0;) {
                        var l = k.shift(),
                            p = l.creativeDto;
                        if (p.rendererName == Qj && p.templateVersion == "200_287") {
                            var x = c,
                                F = x.push,
                                y = void 0,
                                E = new Th,
                                ia = new Kh(l.creativeDto),
                                ca = void 0,
                                Ee = void 0,
                                n = E,
                                K = ia;
                            if (!n.qa) {
                                n.qa = !0;
                                var A = K.j,
                                    Uc = A.C;
                                n.v = K.id || n.v;
                                n.F = K.uniqueId || n.v || n.F;
                                n.B = K.o ? new L(parseInt(K.o.width, 10) || n.B.width, parseInt(K.o.height, 10) ||
                                    n.B.height) : n.B;
                                n.C = A.F || n.C;
                                n.G = A.j ? new L(parseInt(A.j.w, 10) || n.G.width, parseInt(A.j.h, 10) || n.G.height) : n.G;
                                n.j = K.A || n.j;
                                n.ka = K.v || n.ka;
                                n.pa = K.B || n.pa;
                                for (Ee in A.v) n.g[Ee] = A.v[Ee];
                                n.g.sn = A.Z;
                                n.g.sid = A.W;
                                n.g.aid = A.I;
                                n.g.cid = A.creativeId;
                                n.g.buy = A.H;
                                n.g.pid = A.U;
                                n.g.adv = A.G;
                                n.g.kid = A.T;
                                n.g.rid = A.V;
                                n.g.geo = A.S;
                                n.g.randomNumber = A.randomNumber;
                                for (ca in Uc.g) n.g[ca] = Uc.g[ca];
                                n.P = Uc.j || n.P;
                                n.U = Uc.o || n.U;
                                n.O = K.H || n.O;
                                n.V = "https" == (K.K.match(de)[1] || null);
                                n.I = {
                                    va: K.I || n.I.va,
                                    wa: K.G || n.I.wa
                                };
                                var Vc = new Fh(n.j);
                                G(J(A.g)) || (n.A.CLICK = [new rh(A.g, Vc)]);
                                if (Array.isArray(K.g) && K.g.length > 0) {
                                    n.A.IMPRESSION_IMG = [];
                                    for (var Fe = 0; Fe < K.g.length; ++Fe) n.A.IMPRESSION_IMG.push(new rh(K.g[Fe], Vc))
                                }
                                G(J(K.F)) || (n.A.ARTWORK_IMPRESSION = [new rh(K.F, Vc)]);
                                n.ba = A.N || n.ba;
                                n.Z = A.X || n.Z;
                                n.D = A.B || n.D;
                                var si = parseInt(A.K, 10);
                                n.T = isNaN(si) ? n.T : si;
                                n.N = A.o || n.N;
                                n.ea = A.O || n.ea;
                                n.ja = A.P || n.ja;
                                n.S = K.C || n.S;
                                n.H = new Jg(Vc, A.A || A.D)
                            }
                            E.Ha = g.delayedImpression;
                            var ti = g.standardEventIds;
                            for (y in ti) ai(E, y, ti[y]);
                            for (var ui = g.exitEvents, Ge = 0; Ge <
                                ui.length; Ge++) {
                                var Pb = ui[Ge],
                                    He = new Lh(Pb.name, Pb.reportingId, Pb.url);
                                He.o = Pb.targetWindow;
                                He.j = Pb.windowProperties;
                                gi(E, He)
                            }
                            for (var vi = g.timerEvents, Ie = 0; Ie < vi.length; Ie++) {
                                var wi = E,
                                    Je = ol(vi[Ie], "Timer");
                                wi.Da[Je.name] = Je;
                                $h(wi, Je)
                            }
                            for (var xi = g.counterEvents, Ke = 0; Ke < xi.length; Ke++) {
                                var yi = E,
                                    Le = ol(xi[Ke], "Counter");
                                yi.ga[Le.name] = Le;
                                $h(yi, Le)
                            }
                            for (var zi = E.V, Ai = g.childFiles, Me = 0; Me < Ai.length; Me++) {
                                var Jl = E,
                                    Kl = Jh(Ai[Me], zi);
                                Jl.aa.push(Kl)
                            }
                            for (var Bi = g.videoFiles, Ne = 0; Ne < Bi.length; Ne++) {
                                var Ll = E,
                                    Ml =
                                    Jh(Bi[Ne], zi);
                                Ll.aa.push(Ml)
                            }
                            for (var Nl = g.videoEntries, Ci = 0; Ci < Nl.length; Ci++) E.jb.push(new Rh);
                            var Ol = ia.D,
                                Pl = qj(ia.v, ia.B);
                            var Ql = Ol && Pl ? "HTML5" : null;
                            for (var Di = g.primaryAssets, Oe = 0; Oe < Di.length; ++Oe) {
                                var ba = Di[Oe],
                                    Rl = l.creativeDto.adServerData.tag,
                                    na = new mh(ba.id, ba.artworkType, ba.displayType, new L(parseInt(ba.width, 10) || 0, parseInt(ba.height, 10) || 0), ((E.V ? E.I.wa : E.I.va) || "") + ba.servingPath);
                                na.C = ba.zIndex;
                                na.B = ba.location || na.B;
                                na.layoutsConfig = ba.layoutsConfig;
                                var Pe = ba.htmlArtworkTypeData;
                                Pe &&
                                    (na.A = new fh(Pe.isTransparent, Pe.sdkVersion));
                                var Wc = ba.floatingDisplayTypeData;
                                if (Wc) {
                                    var Xc = Wc.position,
                                        Sl = new ih(Xc.top + Xc.topUnit, Xc.left + Xc.leftUnit);
                                    na.j = new eh(Sl, Wc.startTime, Wc.endTime)
                                }
                                var Yc = ba.expandingDisplayTypeData;
                                if (Yc) {
                                    var Zc = Yc.collapsedRect;
                                    na.g = new dh(new lh(Zc.left, Zc.top, Zc.width, Zc.height), Yc.isPushdown ? "push_down" : ah(Yc.expansionMode) || "normal")
                                }
                                var Ei = ba.pageSettings,
                                    Fi = new gh;
                                Ei && (Fi.g = Ei.updateZIndex || !1);
                                na.I = Fi;
                                var Qe = void 0,
                                    Gi = Rl;
                                if (Gi == null) var Hi = {};
                                else {
                                    var Ii = {};
                                    for (Qe in nh) {
                                        var Ji = v(Qe, Gi);
                                        Ji !== null && (Ii[nh[Qe]] = Ji + "")
                                    }
                                    Hi = Ii
                                }
                                ph(na, Hi);
                                oh(na);
                                var Ki = na;
                                if (Ki.o == Ql) {
                                    var Li = E,
                                        Mi = Ki;
                                    Mi.o == "HTML5" && (Li.Ka = !0);
                                    Li.o.push(Mi)
                                }
                            }
                            F.call(x, E)
                        } else {
                            k.unshift(l);
                            break
                        }
                    }
            }
            for (var Ni = [], Re = v("window.dclkStudioV3.creatives") || [], $c = Re.length - 1; $c >= 0; --$c) {
                var r = Re[$c];
                if (r.previewMode) {
                    var Va = v("window.dclkStudioV3.creativeParametersOverrides");
                    r && Va && (Va.CREATIVE_PARAMETER_LAYOUT_CONFIG && (r.creativeParameters.CREATIVE_PARAMETER_LAYOUT_CONFIG = Va.CREATIVE_PARAMETER_LAYOUT_CONFIG),
                        Va.PREVIEW_FRAME_NAME && (r.creativeParameters.PREVIEW_FRAME_NAME = Va.PREVIEW_FRAME_NAME), Va.PREVIEW_FRAME_DEPTH && (r.creativeParameters.PREVIEW_FRAME_DEPTH = Va.PREVIEW_FRAME_DEPTH))
                }
                var Se = void 0,
                    S = new Th,
                    q = S;
                if (!q.qa) {
                    q.qa = !0;
                    q.hb = r.renderingLibraryData.version;
                    var Ia = r.creativeParameters;
                    q.v = Ia.cid || q.v;
                    q.F = Ia.creative_unique_id || q.F;
                    q.B = new L(parseInt(r.width, 10) || q.B.width, parseInt(r.height, 10) || q.B.height);
                    q.G = new L(parseInt(r.slotWidth, 10) || q.G.width, parseInt(r.slotHeight, 10) || q.G.height);
                    q.j = Sh(r.previewMode,
                        q.j);
                    q.Ma = q.j ? r.previewEventsUrl : "";
                    Array.isArray(r.html5Features) && (q.pa = Ha(r.html5Features, "Modernizr.cssanimations") >= 0, q.ka = r.html5Features);
                    q.g = Ia;
                    q.P = Ia.ad_container_id || q.P;
                    q.U = Sh(Ia.mtfRenderFloatInplace, q.U);
                    q.Ia = Sh(Ia.generate_ad_slot, q.Ia);
                    q.ea = Ia.exit_suffix || q.ea;
                    a: {
                        var ad = r.primaryFiles;
                        if (ad != null)
                            for (var bd = 0; bd < ad.length; ++bd)
                                if ("PRE_LOADER" == ad[bd].renderAs) {
                                    var Oi = ad[bd].url;
                                    break a
                                }
                        Oi = ""
                    }
                    q.O = Oi || q.O;
                    q.V = "https" == ((r.renderingLibraryData.renderingLibrary || "").match(de)[1] || null);
                    var Te = r.renderingLibraryData.renderingLibrary.match(de)[3] || null;
                    var Ue = Te ? decodeURI(Te) : Te;
                    q.I = {
                        va: "http://" + Ue,
                        wa: "https://" + Ue
                    };
                    G(J(r.dynamicData)) || (q.C = r.dynamicData.replace(/\\"/g, '"'), q.C = q.C.replace(/\\\\/g, "\\"), q.C = q.C.replace(/\\'/g, "'"), q.C = q.C.replace(/:\/\/s(0|1)\.2mdn\.net/g, "://" + Ue));
                    var Pi = new Fh(q.j);
                    if (r.thirdPartyUrls != null)
                        for (var cd = r.thirdPartyUrls, Qb = 0; Qb < cd.length; ++Qb) {
                            var dd = uh(cd[Qb].type);
                            dd != null && (dd in q.A || (q.A[dd] = []), q.A[dd].push(new rh(cd[Qb].url, Pi, cd[Qb].scrub ==
                                "true")))
                        }
                    q.ba = Uh(r.eventTrackingBaseUrl, "met") || q.ba;
                    q.Z = Uh(r.customEventTrackingBaseUrl, "stragg") || q.Z;
                    q.D = r.clickUrl || q.D;
                    var Qi = parseInt(Ia.clickN, 10);
                    q.T = isNaN(Qi) ? q.T : Qi;
                    q.N = r.impressionUrl || q.N;
                    q.S = Hh(r) || q.S;
                    q.H = new Jg(Pi, r.activeViewUrlPrefix || r.clickString, r.activeViewMetadata, r.lidarScriptUrl, r.activeViewAttributes);
                    r.reactiveAdType && (q.gb = r.reactiveAdType)
                }
                S.Ha = !G(J(r.impressionUrl));
                if (r.creativeParameters.CREATIVE_PARAMETER_EXPERIMENTS) {
                    var Tl = pl(r.creativeParameters.CREATIVE_PARAMETER_EXPERIMENTS);
                    S.W = Tl
                }
                S.Ca = Sh(r.creativeParameters.CREATIVE_PARAMETER_IS_B2R_ELIGIBLE);
                S.eb = Sh(r.creativeParameters.CREATIVE_PARAMETER_AUTO_TAG_WRAPPING_BEHAVIOR_REQUIRED);
                S.fb = J(r.creativeParameters.CREATIVE_PARAMETER_EEID);
                for (var Ve = 0; Ve < r.standardEvents.length; Ve++) {
                    var Ri = r.standardEvents[Ve];
                    ai(S, Ri.name, Ri.reportingId)
                }
                for (var We = 0; We < r.exitEvents.length; We++) {
                    var Ja = r.exitEvents[We];
                    if (!Ja.backUpExit) {
                        var ed = new Lh(Ja.name, Ja.reportingId, Ja.destinationUrl);
                        ed.o = Ja.targetWindow;
                        ed.j = Ja.windowProperties;
                        ed.F =
                            Ja.eTldPlusOne ? Ja.eTldPlusOne : "";
                        gi(S, ed)
                    }
                }
                for (var Xe = 0; Xe < r.timerEvents.length; Xe++) {
                    var Ye = r.timerEvents[Xe],
                        Si = S,
                        Ze = new Ph(Ye.name, Ye.reportingId, "Timer", Oh(Ye.name));
                    Si.Da[Ze.name] = Ze;
                    $h(Si, Ze)
                }
                for (var $e = 0; $e < r.counterEvents.length; $e++) {
                    var af = r.counterEvents[$e],
                        Ti = S,
                        bf = new Ph(af.name, af.reportingId, "Counter", Oh(af.name));
                    Ti.ga[bf.name] = bf;
                    $h(Ti, bf)
                }
                for (var Ul = r.primaryFiles, Ui = 0; Ui < Ul.length; Ui++);
                var fd = r.creativeParameters,
                    Vi = r.primaryFiles,
                    Wi = null;
                "CREATIVE_PARAMETER_LAYOUT_CONFIG" in fd &&
                    (Wi = fd.CREATIVE_PARAMETER_LAYOUT_CONFIG);
                for (var Xi = [], Vl = fd.cid || "", gd = 0; gd < Vi.length; gd++) {
                    var oa = Vi[gd],
                        Yi = fd,
                        Wl = Wi,
                        W = new mh(Vl + "_" + gd, oa.type, oa.renderAs, new L(parseInt(oa.width, 10) || 0, parseInt(oa.height, 10) || 0), oa.url);
                    W.G = oa.content;
                    W.C = parseInt(oa.zIndex, 10);
                    W.B = oa.location || W.B;
                    W.layoutsConfig = Wl || W.layoutsConfig;
                    var cf = oa.htmlProperties;
                    cf && (W.A = new fh(cf.transparent, cf.studioSdkVersion));
                    var Rb = oa.floatingDisplayProperties;
                    if (Rb) {
                        var Xl = new ih(Rb.top, Rb.left);
                        W.j = new eh(Xl, parseInt(Rb.startTime,
                            10), parseInt(Rb.duration, 10))
                    }
                    var ub = oa.expandingDisplayProperties;
                    if (ub) {
                        var Sb = new lh(parseInt(ub.collapsedRectLeft, 10), parseInt(ub.collapsedRectTop, 10), parseInt(ub.collapsedRectWidth, 10), parseInt(ub.collapsedRectHeight, 10)),
                            Yl = ah(ub.expansionMode) || "normal";
                        qh(Sb.left) && qh(Sb.top) && qh(Sb.width) && qh(Sb.height) && (W.g = new dh(Sb, Yl))
                    }
                    W.I = new gh;
                    W.I.g = !0;
                    Yi != null && ph(W, Yi);
                    oh(W);
                    Xi.push(W)
                }
                var Zi = Xi;
                for (var df = 0; df < Zi.length; df++) {
                    var $i = Zi[df];
                    if ("HTML5" == $i.o) {
                        var aj = S,
                            bj = $i;
                        bj.o == "HTML5" && (aj.Ka = !0);
                        aj.o.push(bj)
                    }
                }
                var cj = S.V,
                    dj = r.creativeParameters.CREATIVE_PARAMETER_ASSETS_DATA,
                    ej = dj ? pl(dj) : {};
                for (Se in ej) {
                    var Zl = S,
                        $l = new Ih(Se, ej[Se], cj, null);
                    Zl.aa.push($l)
                }
                for (var fj = r.creativeParameters.CREATIVE_PARAMETER_VIDEO_ASSETS_DATA, gj = fj ? pl(fj) : [], ef = 0; ef < gj.length; ++ef) {
                    var ff = gj[ef],
                        hj = new Ih(ff.name, ff.progressiveUrl, cj),
                        ij = hj,
                        am = ff.streamingUrl;
                    ij.g = !0;
                    ij.j = am || null;
                    S.aa.push(hj)
                }
                for (var jj = r.creativeParameters.CREATIVE_PARAMETER_VIDEO_DATA, bm = jj ? pl(jj) : [], kj = 0; kj < bm.length; ++kj) S.jb.push(new Rh);
                var gf = S;
                a: {
                    for (var lj = gf.o, hf = 0; hf < lj.length; hf++) {
                        var jf = lj[hf];
                        if (jf.v != "BACKUP_IMAGE" && jf.v != "PRE_LOADER" && !dl.g(jf)) {
                            var mj = !1;
                            break a
                        }
                    }
                    mj = gf.hb == "200_287"
                }
                mj && (Array.prototype.splice.call(Re, $c, 1), Ni.push(gf))
            }
            b(c.concat(Ni))
        }, a)
    };
    var sl = function() {
            this.g = null
        },
        hl = function(a, b) {
            a.g || (a.g = new Fh(b));
            return a.g
        };

    function tl() {
        this.o = new sl;
        this.j = null
    }
    var ul = function(a, b) {
        return Array.isArray(a) ? Ha(a, b) >= 0 : a == b
    };
    tl.prototype.g = function() {
        return !1
    };
    var jl = function(a, b) {
            var c = dl,
                d = hl(c.o, a.j),
                e = a.F;
            Nk[e] || (Nk[e] = new Z(a, c, li(), d, b));
            return Nk[e]
        },
        rl = function() {
            var a = dl;
            a.j || (a.j = new ql);
            return a.j
        };
    var vl = function(a, b, c) {
        lk.call(this, a, b, c);
        this.g = b;
        this.S = this.o = null;
        this.ea = this.O = !1;
        this.P = -1;
        this.D = null;
        this.C = li()
    };
    t(vl, lk);
    h = vl.prototype;
    h.la = function() {
        if (!G(J(this.g.O))) {
            var a = this.R(),
                b = this.N,
                c = new Image;
            c.width = vd(this.g.B).width;
            c.height = vd(this.g.B).height;
            c.src = this.g.O;
            b.appendChild(a, c);
            this.S = c
        }
        lk.prototype.la.call(this)
    };
    h.Ya = function() {
        this.S != null && (this.R().removeChild(this.S), this.S = null);
        this.o == null && wl(this);
        nk(this, "logEvent", ["Start", "DISPLAY_TIMER", null, "false", "false"]);
        O(bk(this), this.o, "mouseover", this.nc);
        O(bk(this), this.o, "mouseout", this.mc);
        var a = bk(this);
        this.D && (sf(a, this.D, "tick", this.Va), this.D.dispose());
        this.D = new pg(80);
        O(a, this.D, "tick", this.Va);
        this.D.start()
    };
    h.sa = function(a, b) {
        lk.prototype.sa.call(this, a, b);
        Ah(this.o, "100%", "100%")
    };
    h.Va = function() {
        this.P > 0 && !this.O && 1E3 < z() - this.P && (this.O = !0, nk(this, "setTimerAdjustment", ["INTERACTION_TIMER", -1E3, 0]), nk(this, "logEvent", ["Start", "INTERACTION_TIMER", null, "false", "false"]), this.ea || (nk(this, "logEvent", ["Count", "EVENT_USER_INTERACTION", null, "false", "false"]), nk(this, "flushCounters", []), this.ea = !0))
    };
    h.nc = function() {
        this.P = z()
    };
    h.mc = function() {
        this.O && (nk(this, "logEvent", ["Stop", "INTERACTION_TIMER", null, "false", "false"]), this.O = !1);
        this.P = -1
    };
    h.Pa = function(a) {
        if (this.C.g != null) {
            var b = this.B;
            if (b = b.W && void 0 !== b.W.disable_h5_mraid_imp_ping ? b.W.disable_h5_mraid_imp_ping : !0) a: {
                b = this.B;
                for (var c = 0; c < b.o.length; c++)
                    if (!b.o[c].F) {
                        b = !1;
                        break a
                    }
                b = !0
            }
            b ? a.resolve() : this.C.isVisible() ? a.resolve() : (b = bk(this), rf(b, this.C, "show", a.resolve))
        } else lk.prototype.Pa.call(this, a)
    };
    var Uk = function(a, b, c) {
        vl.call(this, a, b, c);
        this.ka = this.U() + ".if"
    };
    t(Uk, vl);
    Uk.prototype.la = function() {
        vl.prototype.la.call(this);
        O(bk(this), window, ["resize", "orientationchange"], this.Cb);
        this.C.g != null && O(bk(this), window, "message", this.rc);
        Wh(this.g) && O(bk(this), window, "message", this.Bb)
    };
    Uk.prototype.H = function() {
        vl.prototype.H.call(this);
        G(J(this.g.O)) && wl(this)
    };
    var wl = function(a) {
        var b = a.R(),
            c = a.N,
            d = Ed(c, "iframe");
        c.appendChild(b, d);
        a.ta(b);
        O(bk(a), d, "load", a.qc)
    };
    h = Uk.prototype;
    h.ta = function(a) {
        if (a) {
            vl.prototype.ta.call(this, a);
            this.j = a;
            var b = vd(this.g.G),
                c = this.K.width || b.width;
            b = this.K.height || b.height;
            Ah(a, c, b);
            a.style.position = "relative";
            a = a.firstChild;
            this.g.Ca && !this.g.j && typeof window.stcc === "function" && a && window.stcc(a);
            this.o = a;
            var d = this.g.g.CREATIVE_PARAMETER_ENABLER_VERSION,
                e = this.ka,
                f = this.K;
            d = d ? "?ev=" + d : "";
            d = d === void 0 ? "" : d;
            Ah(a, c, b);
            c = {
                id: e,
                src: f.H + d,
                width: c,
                height: b,
                frameborder: "0",
                scrolling: "no"
            };
            f.A && f.A.j && (c.allowtransparency = "true");
            yd(a, c);
            a.setAttribute("allowfullscreen",
                "true")
        }
    };
    h.Cb = function() {
        var a = this.K,
            b = this.o,
            c = this.R();
        Ld(8) && (a = new L(window.innerWidth || a.width, window.innerHeight || a.height), b.width = a.width.toString(), b.height = a.height.toString(), Ah(b, a), Ah(c, a))
    };
    h.qc = function() {
        var a = this.o.contentWindow,
            b = a.postMessage,
            c = this.g.da;
        var d = {};
        for (var e in c) d[e] = c[e];
        for (var f in d) {
            var g = d[f];
            c = d[f];
            var k = void 0;
            e = g.name;
            var l = g.reportingId,
                p = g = g.url;
            this.g.j ? window.DARTDebugEventHandler && (l = window.DARTDebugEventHandler, k = l.initPreviewSession(window.location.href), e = l.generateEventData("handleEventActivity", {
                    eventName: e,
                    eventType: "exit",
                    counterValue: 1,
                    durationValue: 0,
                    isCustomEvent: !0,
                    creativeId: this.g.v
                }, !0, Math.floor(Math.random() * 1E7)), p = k + "&eventData=" +
                encodeURIComponent(e) + "&_dc_redir=" + encodeURIComponent(g)) : (e = Xh(this.B, "CLICK"), e.length > 0 && (k = e[0].ha()), p = he(this.B.D, p, l, k, this.B.T));
            c.url = p
        }
        f = this.g;
        c = this.C.g != null;
        e = {};
        g = [];
        e.clickTags = [];
        for (var x in d) k = d[x], l = k.url, p = {
            name: k.name,
            url: l
        }, Wh(f) && (p.reportingId = k.reportingId), e.clickTags.push(p), g.push(encodeURIComponent(k.name) + "=" + encodeURIComponent(l));
        e.isInitClickTag = !0;
        c && (e.relegateNavigation = "parent");
        Vh(f) && (e.newtonOt2Token = f.g.CREATIVE_PARAMETER_NEWTON_OT2_TOKEN);
        Wh(f) && (e.isTurtleXAdClick = !0);
        d = JSON.stringify(e);
        b.call(a, d, "*")
    };
    h.rc = function(a) {
        var b = this.C;
        try {
            var c = JSON.parse(a.j.data);
            if (c.isPostClickTag && c.clickTag) {
                var d = [c.clickTag];
                ni(b) && d.length == 1 && typeof d[0] === "string" ? u.AFMA_Communicator.sendMessage("open", oi(b, d[0])) : b.g.open.apply(b.g, d)
            }
        } catch (e) {}
    };
    h.Bb = function(a) {
        try {
            var b = this.g.g.CREATIVE_PARAMETER_TURTLEX_AD_SIGNALS,
                c = this.g.g.CREATIVE_PARAMETER_TURTLEX_AD_METADATA,
                d = JSON.parse(a.j.data),
                e = d.reportingId;
            b && e && Lk(b, c, e, d.clickX, d.clickY, d.creativeDims, d.bgResponse)
        } catch (f) {}
    };
    var xl = function() {
        tl.call(this)
    };
    t(xl, tl);
    xl.prototype.g = function(a) {
        var b = ul("BANNER", a.v);
        a = ul("HTML5", a.o);
        return b && a
    };
    var yl = new xl,
        zl = yl.o;
    dl = yl;
    el = zl;
    for (var Al = document.getElementsByTagName("noscript"), Bl = 0; Bl < Al.length; Bl++) Al[Bl].style.display = "none";
    var Cl = v("studioV2.loadedLibraries.200_287.express_html_inpage");
    if (!Cl || !Cl.bootstrap) {
        B("studioV2.loadedLibraries.200_287.express_html_inpage.bootstrap", ml);
        B("studioV2.loadedLibraries.200_287.express_html_inpage.unload", nl);
        var Dl;
        a: {
            var El = v("dclkStudioV3.renderingLibraries");
            if (El)
                for (var Fl = 0; Fl < El.length; ++Fl) {
                    var Gl = El[Fl];
                    if (Gl.version == "200_287" && Gl.url.indexOf("/express_html_inpage") != -1) {
                        Dl = Gl;
                        break a
                    }
                }
            Dl = null
        }
        null !== Dl && (Dl.bootstrapFunction = ml, Dl.unload = nl);
        Qj = "express_html_inpage";
        var Hl = Qj === "undefined_type" ? null : Qj + "_rendering_lib_200_287";
        if (Hl !=
            null && !v("dclkStudioV3.rlErrorSampled") && !v("studioV2.rlErrorSampled")) {
            var Il = new Zk(Hl);
            if (Il.isActive()) {
                Il.g = w(Il.v, Il);
                Il.o = u;
                u.addEventListener("error", Il.g);
                var cm = v("dclkStudioV3");
                cm ? cm.Cc = Il : v("studioV2").Cc = Il
            }
        }
        var dm = v("studioV2.defer");
        dm && typeof dm === "function" ? dm(ml) : ml()
    };
}).call(this);
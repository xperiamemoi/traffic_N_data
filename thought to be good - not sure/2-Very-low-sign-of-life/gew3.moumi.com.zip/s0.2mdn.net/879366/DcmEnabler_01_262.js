(function() {
    var DEPS_GRAPH = {
        'dcmenablermodule': [],
        '$weak$': ['dcmenablermodule']
    };
    window.STUDIO_SDK_START = +new Date();
    var f, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        m = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ba = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        ca = ba(this),
        p = function(a, b) {
            if (b) a: {
                var c = ca;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && m(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        };
    p("Symbol", function(a) {
        if (a) return a;
        var b = function(g, n) {
            this.g = g;
            m(this, "description", {
                configurable: !0,
                writable: !0,
                value: n
            })
        };
        b.prototype.toString = function() {
            return this.g
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            d = 0,
            e = function(g) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (g || "") + "_" + d++, g)
            };
        return e
    });
    p("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = ca[b[c]];
            typeof d === "function" && typeof d.prototype[a] != "function" && m(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return da(aa(this))
                }
            })
        }
        return a
    });
    var da = function(a) {
            a = {
                next: a
            };
            a[Symbol.iterator] = function() {
                return this
            };
            return a
        },
        ea = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        fa;
    if (typeof Object.setPrototypeOf == "function") fa = Object.setPrototypeOf;
    else {
        var ha;
        a: {
            var ia = {
                    a: !0
                },
                ja = {};
            try {
                ja.__proto__ = ia;
                ha = ja.a;
                break a
            } catch (a) {}
            ha = !1
        }
        fa = ha ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var ka = fa,
        r = function(a, b) {
            a.prototype = ea(b.prototype);
            a.prototype.constructor = a;
            if (ka) ka(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.B = b.prototype
        },
        t = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: aa(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        ma = function(a) {
            return la(a,
                a)
        },
        la = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        u = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        na = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    p("globalThis", function(a) {
        return a || ca
    });
    p("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    });
    var oa = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var g = c++;
                        return {
                            value: b(g, a[g]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    };
    p("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return oa(this, function(b) {
                return b
            })
        }
    });
    p("WeakMap", function(a) {
        function b() {}

        function c(h) {
            var l = typeof h;
            return l === "object" && h !== null || l === "function"
        }

        function d(h) {
            if (!u(h, g)) {
                var l = new b;
                m(h, g, {
                    value: l
                })
            }
        }

        function e(h) {
            var l = Object[h];
            l && (Object[h] = function(q) {
                if (q instanceof b) return q;
                Object.isExtensible(q) && d(q);
                return l(q)
            })
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var h = Object.seal({}),
                        l = Object.seal({}),
                        q = new a([
                            [h, 2],
                            [l, 3]
                        ]);
                    if (q.get(h) != 2 || q.get(l) != 3) return !1;
                    q.delete(h);
                    q.set(l, 4);
                    return !q.has(h) && q.get(l) == 4
                } catch (E) {
                    return !1
                }
            }()) return a;
        var g = "$jscomp_hidden_" + Math.random();
        e("freeze");
        e("preventExtensions");
        e("seal");
        var n = 0,
            k = function(h) {
                this.g = (n += Math.random() + 1).toString();
                if (h) {
                    h = t(h);
                    for (var l; !(l = h.next()).done;) l = l.value, this.set(l[0], l[1])
                }
            };
        k.prototype.set = function(h, l) {
            if (!c(h)) throw Error("Invalid WeakMap key");
            d(h);
            if (!u(h, g)) throw Error("WeakMap key fail: " + h);
            h[g][this.g] = l;
            return this
        };
        k.prototype.get = function(h) {
            return c(h) && u(h, g) ? h[g][this.g] : void 0
        };
        k.prototype.has = function(h) {
            return c(h) && u(h, g) && u(h[g], this.g)
        };
        k.prototype.delete = function(h) {
            return c(h) && u(h, g) && u(h[g], this.g) ? delete h[g][this.g] : !1
        };
        return k
    });
    p("Map", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var k = Object.seal({
                            x: 4
                        }),
                        h = new a(t([
                            [k, "s"]
                        ]));
                    if (h.get(k) != "s" || h.size != 1 || h.get({
                            x: 4
                        }) || h.set({
                            x: 4
                        }, "t") != h || h.size != 2) return !1;
                    var l = h.entries(),
                        q = l.next();
                    if (q.done || q.value[0] != k || q.value[1] != "s") return !1;
                    q = l.next();
                    return q.done || q.value[0].x != 4 || q.value[1] != "t" || !l.next().done ? !1 : !0
                } catch (E) {
                    return !1
                }
            }()) return a;
        var b = new WeakMap,
            c = function(k) {
                this[0] = {};
                this[1] =
                    g();
                this.size = 0;
                if (k) {
                    k = t(k);
                    for (var h; !(h = k.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        c.prototype.set = function(k, h) {
            k = k === 0 ? 0 : k;
            var l = d(this, k);
            l.list || (l.list = this[0][l.id] = []);
            l.entry ? l.entry.value = h : (l.entry = {
                next: this[1],
                u: this[1].u,
                head: this[1],
                key: k,
                value: h
            }, l.list.push(l.entry), this[1].u.next = l.entry, this[1].u = l.entry, this.size++);
            return this
        };
        c.prototype.delete = function(k) {
            k = d(this, k);
            return k.entry && k.list ? (k.list.splice(k.index, 1), k.list.length || delete this[0][k.id], k.entry.u.next =
                k.entry.next, k.entry.next.u = k.entry.u, k.entry.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].u = g();
            this.size = 0
        };
        c.prototype.has = function(k) {
            return !!d(this, k).entry
        };
        c.prototype.get = function(k) {
            return (k = d(this, k).entry) && k.value
        };
        c.prototype.entries = function() {
            return e(this, function(k) {
                return [k.key, k.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(k) {
                return k.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(k) {
                return k.value
            })
        };
        c.prototype.forEach =
            function(k, h) {
                for (var l = this.entries(), q; !(q = l.next()).done;) q = q.value, k.call(h, q[1], q[0], this)
            };
        c.prototype[Symbol.iterator] = c.prototype.entries;
        var d = function(k, h) {
                var l = h && typeof h;
                l == "object" || l == "function" ? b.has(h) ? l = b.get(h) : (l = "" + ++n, b.set(h, l)) : l = "p_" + h;
                var q = k[0][l];
                if (q && u(k[0], l))
                    for (k = 0; k < q.length; k++) {
                        var E = q[k];
                        if (h !== h && E.key !== E.key || h === E.key) return {
                            id: l,
                            list: q,
                            index: k,
                            entry: E
                        }
                    }
                return {
                    id: l,
                    list: q,
                    index: -1,
                    entry: void 0
                }
            },
            e = function(k, h) {
                var l = k[1];
                return da(function() {
                    if (l) {
                        for (; l.head !=
                            k[1];) l = l.u;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: h(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            g = function() {
                var k = {};
                return k.u = k.next = k.head = k
            },
            n = 0;
        return c
    });
    p("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) u(b, d) && c.push(b[d]);
            return c
        }
    });
    p("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
        }
    });
    p("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                var g = d[c];
                if (g === b || Object.is(g, b)) return !0
            }
            return !1
        }
    });
    p("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            if (this == null) throw new TypeError("The 'this' value for String.prototype.includes must not be null or undefined");
            if (b instanceof RegExp) throw new TypeError("First argument to String.prototype.includes must not be a regular expression");
            return (this + "").indexOf(b, c || 0) !== -1
        }
    });
    p("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(k) {
                return k
            };
            var e = [],
                g = typeof Symbol != "undefined" && Symbol.iterator && b[Symbol.iterator];
            if (typeof g == "function") {
                b = g.call(b);
                for (var n = 0; !(g = b.next()).done;) e.push(c.call(d, g.value, n++))
            } else
                for (g = b.length, n = 0; n < g; n++) e.push(c.call(d, b[n], n));
            return e
        }
    });
    p("Array.prototype.values", function(a) {
        return a ? a : function() {
            return oa(this, function(b, c) {
                return c
            })
        }
    });
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var v = this || self,
        w = function(a, b, c) {
            a = a.split(".");
            c = c || v;
            for (var d; a.length && (d = a.shift());) a.length || b === void 0 ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
        },
        x = function(a) {
            var b = typeof a;
            return b == "object" && a != null || b == "function"
        },
        pa = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.B = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.wa = function(d, e, g) {
                for (var n = Array(arguments.length - 2), k = 2; k < arguments.length; k++) n[k - 2] = arguments[k];
                return b.prototype[e].apply(d, n)
            }
        };

    function qa(a, b, c) {
        for (var d in a) b.call(c, a[d], d, a)
    };
    var ra = function(a) {
        this.g = a
    };
    ra.prototype.toString = function() {
        return (this.g & 2 ? "b" : "t") + (this.g & 1 ? "r" : "l")
    };
    w("google3.javascript.ads.studio.common.mde.Direction.Direction", ra);
    ra.Corner = {
        ua: 0,
        va: 1,
        pa: 2,
        qa: 3
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var sa = globalThis.trustedTypes,
        ta;

    function ua() {
        var a = null;
        if (!sa) return a;
        try {
            var b = function(c) {
                return c
            };
            a = sa.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {}
        return a
    };
    var va = function(a) {
        this.g = a
    };
    va.prototype.toString = function() {
        return this.g + ""
    };

    function wa(a) {
        var b;
        ta === void 0 && (ta = ua());
        a = (b = ta) ? b.createScriptURL(a) : a;
        return new va(a)
    };
    var y = function(a) {
        this.g = a
    };
    y.prototype.toString = function() {
        return this.g
    };
    var xa = new y("about:invalid#zClosurez");
    var ya = function(a) {
        this.na = a
    };

    function z(a) {
        return new ya(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        })
    }
    var za = [z("data"), z("http"), z("https"), z("mailto"), z("ftp"), new ya(function(a) {
            return /^[^:]*([/?#]|$)/.test(a)
        })],
        Aa = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
    var Ba = ma(["https://www.google.com/recaptcha/api2/aframe"]);
    (function(a) {
        var b = na.apply(1, arguments);
        if (b.length === 0) return wa(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return wa(c)
    })(Ba);
    var Ca = Array.prototype.indexOf ? function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    } : function(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    };
    var Da = function() {
        if (!v.addEventListener || !Object.defineProperty) return !1;
        var a = !1,
            b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
        try {
            var c = function() {};
            v.addEventListener("test", c, b);
            v.removeEventListener("test", c, b)
        } catch (d) {}
        return a
    }();
    var Ea = function(a) {
        Ea[" "](a);
        return a
    };
    Ea[" "] = function() {};
    var A = function(a, b) {
        this.width = a;
        this.height = b
    };
    A.prototype.aspectRatio = function() {
        return this.width / this.height
    };
    A.prototype.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    A.prototype.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    A.prototype.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var B = function() {},
        Ga = function(a) {
            C = a | 6;
            Fa(C)
        },
        Fa = function(a) {
            D(a, 2, 1);
            D(a, 1, 2);
            D(a, 4, 8);
            D(a, 8, 4);
            D(a, 128, 64);
            D(a, 64, 128);
            D(a, 256, 2)
        },
        D = function(a, b, c) {
            (a & b) == b && (C |= b, C &= ~c)
        };
    w("studio.common.Environment", B);
    B.Type = {
        LIVE: 1,
        LOCAL: 2,
        BROWSER: 4,
        IN_APP: 8,
        LAYOUTS_PREVIEW: 16,
        CREATIVE_TOOLSET: 32,
        RENDERING_STUDIO: 64,
        RENDERING_TEST: 128,
        PREVIEW: 256
    };
    var C = 6;
    B.addType = function(a) {
        C |= a;
        Fa(a)
    };
    B.setType = Ga;
    B.hasType = function(a) {
        return (C & a) == a
    };
    B.getValue = function() {
        return C
    };
    var F = function() {
        this.m = this.m;
        this.o = this.o
    };
    F.prototype.m = !1;
    F.prototype.dispose = function() {
        this.m || (this.m = !0, this.g())
    };
    F.prototype[Symbol.dispose] = function() {
        this.dispose()
    };
    F.prototype.g = function() {
        if (this.o)
            for (; this.o.length;) this.o.shift()()
    };
    var G = function(a, b) {
        this.type = a;
        this.target = b;
        this.defaultPrevented = !1
    };
    G.prototype.h = function() {
        this.defaultPrevented = !0
    };
    var H = function(a, b) {
        G.call(this, a ? a.type : "");
        this.relatedTarget = this.target = null;
        this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
        this.key = "";
        this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
        this.state = null;
        this.pointerId = 0;
        this.pointerType = "";
        this.g = null;
        a && this.init(a, b)
    };
    pa(H, G);
    H.prototype.init = function(a) {
        var b = this.type = a.type,
            c = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
        this.target = a.target || a.srcElement;
        var d = a.relatedTarget;
        d || (b == "mouseover" ? d = a.fromElement : b == "mouseout" && (d = a.toElement));
        this.relatedTarget = d;
        c ? (this.clientX = c.clientX !== void 0 ? c.clientX : c.pageX, this.clientY = c.clientY !== void 0 ? c.clientY : c.pageY, this.screenX = c.screenX || 0, this.screenY = c.screenY || 0) : (this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX, this.clientY = a.clientY !== void 0 ?
            a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
        this.button = a.button;
        this.key = a.key || "";
        this.ctrlKey = a.ctrlKey;
        this.altKey = a.altKey;
        this.shiftKey = a.shiftKey;
        this.metaKey = a.metaKey;
        this.pointerId = a.pointerId || 0;
        this.pointerType = a.pointerType;
        this.state = a.state;
        this.g = a;
        a.defaultPrevented && H.B.h.call(this)
    };
    H.prototype.h = function() {
        H.B.h.call(this);
        var a = this.g;
        a.preventDefault ? a.preventDefault() : a.returnValue = !1
    };
    var I = "closure_listenable_" + (Math.random() * 1E6 | 0);
    var Ha = 0;
    var Ia = function(a, b, c, d, e) {
            this.listener = a;
            this.proxy = null;
            this.src = b;
            this.type = c;
            this.capture = !!d;
            this.handler = e;
            this.key = ++Ha;
            this.g = this.C = !1
        },
        Ja = function(a) {
            a.g = !0;
            a.listener = null;
            a.proxy = null;
            a.src = null;
            a.handler = null
        };

    function Ka(a) {
        this.src = a;
        this.g = {};
        this.h = 0
    }
    Ka.prototype.add = function(a, b, c, d, e) {
        var g = a.toString();
        a = this.g[g];
        a || (a = this.g[g] = [], this.h++);
        var n = La(a, b, d, e);
        n > -1 ? (b = a[n], c || (b.C = !1)) : (b = new Ia(b, this.src, g, !!d, e), b.C = c, a.push(b));
        return b
    };
    var Ma = function(a, b) {
            var c = b.type;
            if (c in a.g) {
                var d = a.g[c],
                    e = Ca(d, b),
                    g;
                (g = e >= 0) && Array.prototype.splice.call(d, e, 1);
                g && (Ja(b), a.g[c].length == 0 && (delete a.g[c], a.h--))
            }
        },
        La = function(a, b, c, d) {
            for (var e = 0; e < a.length; ++e) {
                var g = a[e];
                if (!g.g && g.listener == b && g.capture == !!c && g.handler == d) return e
            }
            return -1
        };
    var Na = "closure_lm_" + (Math.random() * 1E6 | 0),
        Oa = {},
        Pa = 0,
        J = function(a, b, c, d, e) {
            if (d && d.once) return Qa(a, b, c, d, e);
            if (Array.isArray(b)) {
                for (var g = 0; g < b.length; g++) J(a, b[g], c, d, e);
                return null
            }
            c = Ra(c);
            return a && a[I] ? a.h.add(String(b), c, !1, x(d) ? !!d.capture : !!d, e) : Sa(a, b, c, !1, d, e)
        },
        Sa = function(a, b, c, d, e, g) {
            if (!b) throw Error("Invalid event type");
            var n = x(e) ? !!e.capture : !!e,
                k = Ta(a);
            k || (a[Na] = k = new Ka(a));
            c = k.add(b, c, d, n, g);
            if (c.proxy) return c;
            d = Ua();
            c.proxy = d;
            d.src = a;
            d.listener = c;
            if (a.addEventListener) Da || (e =
                n), e === void 0 && (e = !1), a.addEventListener(b.toString(), d, e);
            else if (a.attachEvent) a.attachEvent(Va(b.toString()), d);
            else if (a.addListener && a.removeListener) a.addListener(d);
            else throw Error("addEventListener and attachEvent are unavailable.");
            Pa++;
            return c
        },
        Ua = function() {
            var a = Wa,
                b = function(c) {
                    return a.call(b.src, b.listener, c)
                };
            return b
        },
        Qa = function(a, b, c, d, e) {
            if (Array.isArray(b)) {
                for (var g = 0; g < b.length; g++) Qa(a, b[g], c, d, e);
                return null
            }
            c = Ra(c);
            return a && a[I] ? a.h.add(String(b), c, !0, x(d) ? !!d.capture :
                !!d, e) : Sa(a, b, c, !0, d, e)
        },
        Xa = function(a, b, c, d, e) {
            if (Array.isArray(b))
                for (var g = 0; g < b.length; g++) Xa(a, b[g], c, d, e);
            else(d = x(d) ? !!d.capture : !!d, c = Ra(c), a && a[I]) ? (a = a.h, b = String(b).toString(), b in a.g && (g = a.g[b], c = La(g, c, d, e), c > -1 && (Ja(g[c]), Array.prototype.splice.call(g, c, 1), g.length == 0 && (delete a.g[b], a.h--)))) : a && (a = Ta(a)) && (b = a.g[b.toString()], a = -1, b && (a = La(b, c, d, e)), (c = a > -1 ? b[a] : null) && Ya(c))
        },
        Ya = function(a) {
            if (typeof a !== "number" && a && !a.g) {
                var b = a.src;
                if (b && b[I]) Ma(b.h, a);
                else {
                    var c = a.type,
                        d = a.proxy;
                    b.removeEventListener ? b.removeEventListener(c, d, a.capture) : b.detachEvent ? b.detachEvent(Va(c), d) : b.addListener && b.removeListener && b.removeListener(d);
                    Pa--;
                    (c = Ta(b)) ? (Ma(c, a), c.h == 0 && (c.src = null, b[Na] = null)) : Ja(a)
                }
            }
        },
        Va = function(a) {
            return a in Oa ? Oa[a] : Oa[a] = "on" + a
        },
        Wa = function(a, b) {
            if (a.g) a = !0;
            else {
                b = new H(b, this);
                var c = a.listener,
                    d = a.handler || a.src;
                a.C && Ya(a);
                a = c.call(d, b)
            }
            return a
        },
        Ta = function(a) {
            a = a[Na];
            return a instanceof Ka ? a : null
        },
        Za = "__closure_events_fn_" + (Math.random() * 1E9 >>> 0),
        Ra = function(a) {
            if (typeof a ===
                "function") return a;
            a[Za] || (a[Za] = function(b) {
                return a.handleEvent(b)
            });
            return a[Za]
        };
    var K = function(a) {
        F.call(this);
        this.oa = a;
        this.j = {}
    };
    pa(K, F);
    var $a = [],
        ab = function(a, b, c) {
            var d = document.body || window,
                e = {
                    capture: !0,
                    passive: !0
                };
            Array.isArray(b) || (b && ($a[0] = b.toString()), b = $a);
            for (var g = 0; g < b.length; g++) {
                var n = J(d, b[g], c || a.handleEvent, e || !1, a.oa || a);
                if (!n) break;
                a.j[n.key] = n
            }
        },
        bb = function(a) {
            qa(a.j, function(b, c) {
                this.j.hasOwnProperty(c) && Ya(b)
            }, a);
            a.j = {}
        };
    K.prototype.g = function() {
        K.B.g.call(this);
        bb(this)
    };
    K.prototype.handleEvent = function() {
        throw Error("EventHandler.handleEvent not implemented");
    };
    var L = function() {
        K.call(this);
        this.h = new Map;
        this.l = !1;
        this.i = null;
        this.h.set("nx", null);
        this.h.set("ny", null);
        this.h.set("dim", null)
    };
    r(L, K);
    L.prototype.la = function() {
        return na.apply(0, arguments).reduce(function(a, b) {
            return a + b.length
        }, 0) < 2040
    };
    var cb = function() {
        var a = window.document;
        a = a.compatMode == "CSS1Compat" ? a.documentElement : a.body;
        a = new A(a.clientWidth, a.clientHeight);
        return a.width + "x" + a.height
    };
    L.prototype.v = function(a) {
        var b = a.clientX,
            c = a.clientY;
        a.changedTouches && a.changedTouches[0] && (b = a.changedTouches[0].clientX, c = a.changedTouches[0].clientY);
        this.h.set("nx", Math.round(b));
        this.h.set("ny", Math.round(c))
    };
    L.prototype.g = function() {
        this.l = !1;
        K.prototype.g.call(this)
    };
    var db = {
        sa: "dcm",
        ta: "studio",
        ra: "clicktag"
    };
    w("studio.sdk.ContainerState", {
        COLLAPSING: "collapsing",
        COLLAPSED: "collapsed",
        EXPANDING: "expanding",
        EXPANDED: "expanded",
        FS_COLLAPSING: "fs_collapsing",
        FS_EXPANDING: "fs_expanding",
        FS_EXPANDED: "fs_expanded"
    });
    w("studio.sdk.MraidMethod", {
        GET_CURRENT_POSITION: "getCurrentPosition",
        GET_DEFAULT_POSITION: "getDefaultPosition",
        GET_SCREEN_SIZE: "getScreenSize",
        CREATE_CALENDAR_EVENT: "createCalendarEvent",
        GET_MAX_SIZE: "getMaxSize",
        PLAY_VIDEO: "playVideo",
        STORE_PICTURE: "storePicture",
        SUPPORTS: "supports",
        USE_CUSTOM_CLOSE: "useCustomClose"
    });
    var eb = function() {};
    w("studio.sdk.IEnabler", eb);
    f = eb.prototype;
    f.ga = function() {};
    f.ba = function() {};
    f.aa = function() {};
    f.ia = function() {};
    f.ha = function() {};
    f.isVisible = function() {};
    f.W = function() {};
    f.V = function() {};
    f.U = function() {};
    f.H = function() {};
    f.getParameter = function() {};
    f.D = function() {};
    f.I = function() {};
    f.N = function() {};
    f.counter = function() {};
    f.ja = function() {};
    f.ka = function() {};
    f.O = function() {};
    f.P = function() {};
    f.da = function() {};
    f.K = function() {};
    f.ca = function() {};
    f.J = function() {};
    f.close = function() {};
    f.S = function() {};
    f.X = function() {};
    f.addEventListener = function() {};
    f.removeEventListener = function() {};
    f.Z = function() {};
    f.Y = function() {};
    f.fa = function() {};
    f.M = function() {};
    f.ea = function() {};
    f.L = function() {};
    f.R = function() {};
    f.T = function() {};
    var fb = function() {};
    fb.prototype.log = function() {};
    fb.prototype.info = function() {};
    fb.prototype.config = function() {};
    var gb = new fb;
    w("studio.sdk.logger", gb);
    w("studio.module.ModuleId", {
        ENABLER: "enabler",
        DCM_ENABLER: "dcmenabler",
        SSR_ENABLER: "ssrenabler",
        CLICK_TAG_ENABLER: "clicktagenabler",
        ENABLER_LOADER: "enablerloader",
        DCM_ENABLER_LOADER: "dcmenablerloader",
        CLICK_TAG_ENABLER_LOADER: "clicktagenablerloader",
        VIDEO: "video",
        CONFIGURABLE: "configurable",
        CONFIGURABLE_FILLER: "configurablefiller",
        LAYOUTS: "layouts",
        FILLER: "layoutsfiller",
        RAD_VIDEO: "rad_ui_video",
        GDN: "gdn"
    });
    var hb = function(a, b) {
        this.g = a[v.Symbol.iterator]();
        this.h = b
    };
    hb.prototype[Symbol.iterator] = function() {
        return this
    };
    hb.prototype.next = function() {
        var a = this.g.next();
        return {
            value: a.done ? void 0 : this.h.call(void 0, a.value),
            done: a.done
        }
    };
    var ib = function(a, b) {
        return new hb(a, b)
    };
    var jb = function() {};
    jb.prototype.next = function() {
        return kb
    };
    var kb = {
        done: !0,
        value: void 0
    };
    jb.prototype.A = function() {
        return this
    };
    var lb = function(a) {
            if (a instanceof M || a instanceof N || a instanceof O) return a;
            if (typeof a.next == "function") return new M(function() {
                return a
            });
            if (typeof a[Symbol.iterator] == "function") return new M(function() {
                return a[Symbol.iterator]()
            });
            if (typeof a.A == "function") return new M(function() {
                return a.A()
            });
            throw Error("Not an iterator or iterable.");
        },
        M = function(a) {
            this.g = a
        };
    M.prototype.A = function() {
        return new N(this.g())
    };
    M.prototype[Symbol.iterator] = function() {
        return new O(this.g())
    };
    M.prototype.h = function() {
        return new O(this.g())
    };
    var N = function(a) {
        this.g = a
    };
    r(N, jb);
    N.prototype.next = function() {
        return this.g.next()
    };
    N.prototype[Symbol.iterator] = function() {
        return new O(this.g)
    };
    N.prototype.h = function() {
        return new O(this.g)
    };
    var O = function(a) {
        M.call(this, function() {
            return a
        });
        this.i = a
    };
    r(O, M);
    O.prototype.next = function() {
        return this.i.next()
    };
    var P = function(a, b) {
        this.h = {};
        this.g = [];
        this.i = this.size = 0;
        var c = arguments.length;
        if (c > 1) {
            if (c % 2) throw Error("Uneven number of arguments");
            for (var d = 0; d < c; d += 2) this.set(arguments[d], arguments[d + 1])
        } else if (a)
            if (a instanceof P)
                for (c = a.F(), d = 0; d < c.length; d++) this.set(c[d], a.get(c[d]));
            else
                for (d in a) this.set(d, a[d])
    };
    P.prototype.G = function() {
        mb(this);
        for (var a = [], b = 0; b < this.g.length; b++) a.push(this.h[this.g[b]]);
        return a
    };
    P.prototype.F = function() {
        mb(this);
        return this.g.concat()
    };
    P.prototype.has = function(a) {
        return Object.prototype.hasOwnProperty.call(this.h, a)
    };
    var mb = function(a) {
        if (a.size != a.g.length) {
            for (var b = 0, c = 0; b < a.g.length;) {
                var d = a.g[b];
                Object.prototype.hasOwnProperty.call(a.h, d) && (a.g[c++] = d);
                b++
            }
            a.g.length = c
        }
        if (a.size != a.g.length) {
            b = {};
            for (d = c = 0; c < a.g.length;) {
                var e = a.g[c];
                Object.prototype.hasOwnProperty.call(b, e) || (a.g[d++] = e, b[e] = 1);
                c++
            }
            a.g.length = d
        }
    };
    f = P.prototype;
    f.get = function(a, b) {
        return Object.prototype.hasOwnProperty.call(this.h, a) ? this.h[a] : b
    };
    f.set = function(a, b) {
        Object.prototype.hasOwnProperty.call(this.h, a) || (this.size += 1, this.g.push(a), this.i++);
        this.h[a] = b
    };
    f.forEach = function(a, b) {
        for (var c = this.F(), d = 0; d < c.length; d++) {
            var e = c[d],
                g = this.get(e);
            a.call(b, g, e, this)
        }
    };
    f.keys = function() {
        return lb(this.A(!0)).h()
    };
    f.values = function() {
        return lb(this.A(!1)).h()
    };
    f.entries = function() {
        var a = this;
        return ib(this.keys(), function(b) {
            return [b, a.get(b)]
        })
    };
    f.A = function(a) {
        mb(this);
        var b = 0,
            c = this.i,
            d = this,
            e = new jb;
        e.next = function() {
            if (c != d.i) throw Error("The map has changed since the iterator was created");
            if (b >= d.g.length) return kb;
            var g = d.g[b++];
            return {
                value: a ? g : d.h[g],
                done: !1
            }
        };
        return e
    };
    var Q = function() {
        F.call(this);
        this.h = new Ka(this)
    };
    pa(Q, F);
    Q.prototype[I] = !0;
    Q.prototype.addEventListener = function(a, b, c, d) {
        J(this, a, b, c, d)
    };
    Q.prototype.removeEventListener = function(a, b, c, d) {
        Xa(this, a, b, c, d)
    };
    Q.prototype.g = function() {
        Q.B.g.call(this);
        if (this.h) {
            var a = this.h,
                b = 0,
                c;
            for (c in a.g) {
                for (var d = a.g[c], e = 0; e < d.length; e++) ++b, Ja(d[e]);
                delete a.g[c];
                a.h--
            }
        }
    };
    var R = new P;
    R.set("enabler", "enabler");
    R.set("dcmenabler", "dcm");
    R.set("video", "vid");
    R.set("configurable", "cfg");
    R.set("configurablefiller", "cfg_fill");
    R.set("layouts", "lay");
    R.set("layoutsfiller", "lay_fill");
    R.set("gdn", "gdn");
    R.set("rad_ui_video", "rad");
    w("goog.exportSymbol", function(a, b, c) {
        w(a, b, c)
    }, this);
    var nb = function(a) {
        a += "goog.exportSymbol('studioLoader.context.evalInContext', " + nb.toString() + ");";
        eval(a)
    };
    w("studioLoader.context.evalInContext", nb);
    var ob = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        pb = function(a, b) {
            if (a) {
                a = a.split("&");
                for (var c = 0; c < a.length; c++) {
                    var d = a[c].indexOf("="),
                        e = null;
                    if (d >= 0) {
                        var g = a[c].substring(0, d);
                        e = a[c].substring(d + 1)
                    } else g = a[c];
                    b(g, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "")
                }
            }
        };
    var S = function(a) {
        this.h = this.l = this.j = "";
        this.v = null;
        this.o = this.g = "";
        this.m = !1;
        var b;
        a instanceof S ? (this.m = a.m, qb(this, a.j), this.l = a.l, this.h = a.h, rb(this, a.v), this.g = a.g, sb(this, tb(a.i)), this.o = a.o) : a && (b = String(a).match(ob)) ? (this.m = !1, qb(this, b[1] || "", !0), this.l = T(b[2] || ""), this.h = T(b[3] || "", !0), rb(this, b[4]), this.g = T(b[5] || "", !0), sb(this, b[6] || "", !0), this.o = T(b[7] || "")) : (this.m = !1, this.i = new U(null, this.m))
    };
    S.prototype.toString = function() {
        var a = [],
            b = this.j;
        b && a.push(V(b, ub, !0), ":");
        var c = this.h;
        if (c || b == "file") a.push("//"), (b = this.l) && a.push(V(b, ub, !0), "@"), a.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.v, c != null && a.push(":", String(c));
        if (c = this.g) this.h && c.charAt(0) != "/" && a.push("/"), a.push(V(c, c.charAt(0) == "/" ? vb : wb, !0));
        (c = this.i.toString()) && a.push("?", c);
        (c = this.o) && a.push("#", V(c, xb));
        return a.join("")
    };
    S.prototype.resolve = function(a) {
        var b = new S(this),
            c = !!a.j;
        c ? qb(b, a.j) : c = !!a.l;
        c ? b.l = a.l : c = !!a.h;
        c ? b.h = a.h : c = a.v != null;
        var d = a.g;
        if (c) rb(b, a.v);
        else if (c = !!a.g) {
            if (d.charAt(0) != "/")
                if (this.h && !this.g) d = "/" + d;
                else {
                    var e = b.g.lastIndexOf("/");
                    e != -1 && (d = b.g.slice(0, e + 1) + d)
                }
            e = d;
            if (e == ".." || e == ".") d = "";
            else if (e.indexOf("./") != -1 || e.indexOf("/.") != -1) {
                d = e.lastIndexOf("/", 0) == 0;
                e = e.split("/");
                for (var g = [], n = 0; n < e.length;) {
                    var k = e[n++];
                    k == "." ? d && n == e.length && g.push("") : k == ".." ? ((g.length > 1 || g.length == 1 && g[0] !=
                        "") && g.pop(), d && n == e.length && g.push("")) : (g.push(k), d = !0)
                }
                d = g.join("/")
            } else d = e
        }
        c ? b.g = d : c = a.i.toString() !== "";
        c ? sb(b, tb(a.i)) : c = !!a.o;
        c && (b.o = a.o);
        return b
    };
    var qb = function(a, b, c) {
            a.j = c ? T(b, !0) : b;
            a.j && (a.j = a.j.replace(/:$/, ""))
        },
        rb = function(a, b) {
            if (b) {
                b = Number(b);
                if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
                a.v = b
            } else a.v = null
        },
        sb = function(a, b, c) {
            b instanceof U ? (a.i = b, yb(a.i, a.m)) : (c || (b = V(b, zb)), a.i = new U(b, a.m))
        },
        T = function(a, b) {
            return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : ""
        },
        V = function(a, b, c) {
            return typeof a === "string" ? (a = encodeURI(a).replace(b, Ab), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null
        },
        Ab = function(a) {
            a =
                a.charCodeAt(0);
            return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
        },
        ub = /[#\/\?@]/g,
        wb = /[#\?:]/g,
        vb = /[#\?]/g,
        zb = /[#\?@]/g,
        xb = /#/g,
        U = function(a, b) {
            this.h = this.g = null;
            this.i = a || null;
            this.j = !!b
        },
        W = function(a) {
            a.g || (a.g = new Map, a.h = 0, a.i && pb(a.i, function(b, c) {
                a.add(decodeURIComponent(b.replace(/\+/g, " ")), c)
            }))
        };
    U.prototype.add = function(a, b) {
        W(this);
        this.i = null;
        a = X(this, a);
        var c = this.g.get(a);
        c || this.g.set(a, c = []);
        c.push(b);
        this.h += 1;
        return this
    };
    var Bb = function(a, b) {
            W(a);
            b = X(a, b);
            a.g.has(b) && (a.i = null, a.h -= a.g.get(b).length, a.g.delete(b))
        },
        Cb = function(a, b) {
            W(a);
            b = X(a, b);
            return a.g.has(b)
        };
    f = U.prototype;
    f.forEach = function(a, b) {
        W(this);
        this.g.forEach(function(c, d) {
            c.forEach(function(e) {
                a.call(b, e, d, this)
            }, this)
        }, this)
    };
    f.F = function() {
        W(this);
        for (var a = Array.from(this.g.values()), b = Array.from(this.g.keys()), c = [], d = 0; d < b.length; d++)
            for (var e = a[d], g = 0; g < e.length; g++) c.push(b[d]);
        return c
    };
    f.G = function(a) {
        W(this);
        var b = [];
        if (typeof a === "string") Cb(this, a) && (b = b.concat(this.g.get(X(this, a))));
        else {
            a = Array.from(this.g.values());
            for (var c = 0; c < a.length; c++) b = b.concat(a[c])
        }
        return b
    };
    f.set = function(a, b) {
        W(this);
        this.i = null;
        a = X(this, a);
        Cb(this, a) && (this.h -= this.g.get(a).length);
        this.g.set(a, [b]);
        this.h += 1;
        return this
    };
    f.get = function(a, b) {
        if (!a) return b;
        a = this.G(a);
        return a.length > 0 ? String(a[0]) : b
    };
    f.toString = function() {
        if (this.i) return this.i;
        if (!this.g) return "";
        for (var a = [], b = Array.from(this.g.keys()), c = 0; c < b.length; c++) {
            var d = b[c],
                e = encodeURIComponent(String(d));
            d = this.G(d);
            for (var g = 0; g < d.length; g++) {
                var n = e;
                d[g] !== "" && (n += "=" + encodeURIComponent(String(d[g])));
                a.push(n)
            }
        }
        return this.i = a.join("&")
    };
    var tb = function(a) {
            var b = new U;
            b.i = a.i;
            a.g && (b.g = new Map(a.g), b.h = a.h);
            return b
        },
        X = function(a, b) {
            b = String(b);
            a.j && (b = b.toLowerCase());
            return b
        },
        yb = function(a, b) {
            b && !a.j && (W(a), a.i = null, a.g.forEach(function(c, d) {
                var e = d.toLowerCase();
                if (d != e && (Bb(this, d), Bb(this, e), c.length > 0)) {
                    this.i = null;
                    d = this.g;
                    var g = d.set;
                    e = X(this, e);
                    var n = c.length;
                    if (n > 0) {
                        for (var k = Array(n), h = 0; h < n; h++) k[h] = c[h];
                        n = k
                    } else n = [];
                    g.call(d, e, n);
                    this.h += c.length
                }
            }, a));
            a.j = b
        };

    function Db(a) {
        var b = !1;
        b = b === void 0 ? !1 : b;
        var c = c === void 0 ? v : c;
        for (var d = 0; c && d++ < 40;) {
            var e;
            if (!(e = b)) try {
                var g;
                if (g = !!c && c.location.href != null) b: {
                    try {
                        Ea(c.foo);
                        g = !0;
                        break b
                    } catch (k) {}
                    g = !1
                }
                e = g
            } catch (k) {
                e = !1
            }
            if (e && a(c)) break;
            a: {
                try {
                    var n = c.parent;
                    if (n && n != c) {
                        c = n;
                        break a
                    }
                } catch (k) {}
                c = null
            }
        }
    };
    var Y = function(a) {
            J(window, "message", Eb);
            gb.info("");
            if (a != Fb) return !1;
            Q.call(this);
            this.j = null;
            this.j || (this.j = new S((window.STUDIO_ORIGINAL_ASSET_URL ? window.STUDIO_ORIGINAL_ASSET_URL : window.location.href).replace(/%(?![A-Fa-f0-9][A-Fa-f0-9])/g, "%25")));
            (a = this.l = this.j.i) && (a = a.get("e", null)) && Ga(parseInt(a, 10) || 0);
            a = this.i = new L;
            a.l = !0;
            ab(a, "mousedown", a.v);
            ab(a, "touchstart", a.v)
        },
        Gb, Hb;
    pa(Y, Q);
    w("studio.DcmEnabler", Y);
    var Fb = Math.random(),
        Ib = null,
        Jb = {},
        Kb = new Map,
        Lb = !1,
        Mb = function() {
            Ib || (Ib = new Y(Fb));
            return Ib
        };
    Y.getInstance = Mb;
    var Eb = function(a) {
        if (typeof a.g.data === "string") {
            try {
                var b = JSON.parse(a.g.data)
            } catch (e) {
                return
            }
            if (b.isInitClickTag) {
                if (a = b.clickTags)
                    for (var c = 0; c < a.length; c++) {
                        var d = a[c];
                        Jb[d.name] = d.url;
                        Kb.set(d.name, d.reportingId)
                    }
                "newtonOt2Token" in b && Nb(b.newtonOt2Token);
                Hb = !!b.isTurtleXAdClick;
                Gb = b.relegateNavigation
            }
        }
    };
    Y.prototype.ba = function() {};
    Y.prototype.reportManualClose = Y.prototype.ba;
    Y.prototype.aa = function() {};
    Y.prototype.reportEngagement = Y.prototype.aa;
    Y.prototype.ga = function() {};
    Y.prototype.setExpandingPixelOffsets = Y.prototype.ga;
    Y.prototype.ia = function() {};
    Y.prototype.setStartExpanded = Y.prototype.ia;
    Y.prototype.ha = function() {};
    Y.prototype.setIsMultiDirectional = Y.prototype.ha;
    Y.prototype.isVisible = function() {
        return !0
    };
    Y.prototype.isVisible = Y.prototype.isVisible;
    Y.prototype.W = function() {
        return !0
    };
    Y.prototype.isServingInLiveEnvironment = Y.prototype.W;
    Y.prototype.V = function() {
        return !0
    };
    Y.prototype.isPageLoaded = Y.prototype.V;
    Y.prototype.U = function() {
        return !0
    };
    Y.prototype.isInitialized = Y.prototype.U;
    Y.prototype.H = function() {};
    Y.prototype.callAfterInitialized = Y.prototype.H;
    Y.prototype.getParameter = function(a) {
        return this.l.get(a, null)
    };
    Y.prototype.getParameter = Y.prototype.getParameter;
    Y.prototype.D = function(a, b) {
        var c = Jb[a] != null && Jb[a] != "null" ? Jb[a] : b === void 0 ? "" : b;
        if (c && (b = this.i, b.l)) {
            b.h.set("dim", cb());
            var d = "";
            for (var e = t(b.h), g = e.next(); !g.done; g = e.next()) {
                var n = t(g.value);
                g = n.next().value;
                n = n.next().value;
                d = n == null ? d + "&" + g + "=" : d + "&" + g + "=" + n
            }
            e = c.toLowerCase().indexOf("&adurl=");
            e > -1 && b.la(c, d) && (c = c.substr(0, e) + d + c.substr(e))
        }
        if (Gb === "parent") window.parent.postMessage(JSON.stringify({
            clickTag: c,
            isPostClickTag: !0
        }), "*");
        else {
            var k;
            if (Lb && ((k = document.featurePolicy) == null ?
                    0 : k.allowedFeatures().includes("attribution-reporting"))) {
                if (c) {
                    k = window;
                    b = c;
                    var h = h === void 0 ? za : h;
                    a: if (h = h === void 0 ? za : h, b instanceof y) h = b;
                        else {
                            for (c = 0; c < h.length; ++c)
                                if (d = h[c], d instanceof ya && d.na(b)) {
                                    h = new y(b);
                                    break a
                                }
                            h = void 0
                        }
                    h = h || xa;
                    if (h instanceof y)
                        if (h instanceof y) h = h.g;
                        else throw Error("");
                    else h = Aa.test(h) ? h : void 0;
                    h !== void 0 && k.open(h, "_blank", "attributionsrc")
                }
            } else window.open(c)
        }
        Hb && (a = Kb.get(a), h = this.i, h = {
                x: h.h.get("nx"),
                y: h.h.get("ny")
            }, k = cb(), b = this.i, b.i || (b.i = window.GoogleA13IjpGc),
            b = b.i && typeof b.i.snapshotSync === "function" ? b.i.snapshotSync() : null, window.parent.postMessage(JSON.stringify({
                reportingId: a,
                clickX: h.x,
                clickY: h.y,
                creativeDims: k,
                bgResponse: b
            }), "*"))
    };
    Y.prototype.exit = Y.prototype.D;
    Y.prototype.I = function(a, b) {
        this.D(a, b)
    };
    Y.prototype.exitOverride = Y.prototype.I;
    Y.prototype.N = function(a) {
        return a
    };
    Y.prototype.formExitUrlFromOverride = Y.prototype.N;
    Y.prototype.counter = function() {};
    Y.prototype.counter = Y.prototype.counter;
    Y.prototype.ja = function() {};
    Y.prototype.startTimer = Y.prototype.ja;
    Y.prototype.ka = function() {};
    Y.prototype.stopTimer = Y.prototype.ka;
    Y.prototype.O = function() {
        return "collapsed"
    };
    Y.prototype.getContainerState = Y.prototype.O;
    Y.prototype.P = function() {
        return null
    };
    Y.prototype.getExpandDirection = Y.prototype.P;
    Y.prototype.da = function() {};
    Y.prototype.requestExpand = Y.prototype.da;
    Y.prototype.K = function() {};
    Y.prototype.finishExpand = Y.prototype.K;
    Y.prototype.ca = function() {};
    Y.prototype.requestCollapse = Y.prototype.ca;
    Y.prototype.J = function() {};
    Y.prototype.finishCollapse = Y.prototype.J;
    Y.prototype.close = function() {};
    Y.prototype.close = Y.prototype.close;
    Y.prototype.S = function(a) {
        return a
    };
    Y.prototype.getUrl = Y.prototype.S;
    Y.prototype.X = function() {};
    Y.prototype.loadModule = Y.prototype.X;
    Y.prototype.addEventListener = function(a, b, c, d) {
        J(this, a, b, c, d)
    };
    Y.prototype.addEventListener = Y.prototype.addEventListener;
    Y.prototype.removeEventListener = function(a, b, c, d) {
        Xa(this, a, b, c, d)
    };
    Y.prototype.removeEventListener = Y.prototype.removeEventListener;
    Y.prototype.Z = function() {};
    Y.prototype.queryFullscreenSupport = Y.prototype.Z;
    Y.prototype.Y = function() {};
    Y.prototype.queryFullscreenDimensions = Y.prototype.Y;
    Y.prototype.fa = function() {};
    Y.prototype.requestFullscreenExpand = Y.prototype.fa;
    Y.prototype.M = function() {};
    Y.prototype.finishFullscreenExpand = Y.prototype.M;
    Y.prototype.ea = function() {};
    Y.prototype.requestFullscreenCollapse = Y.prototype.ea;
    Y.prototype.L = function() {};
    Y.prototype.finishFullscreenCollapse = Y.prototype.L;
    Y.prototype.T = function() {};
    Y.prototype.invokeMraidMethod = Y.prototype.T;
    Y.prototype.R = function() {
        a: {
            for (a in db)
                if (db[a] == "dcm") {
                    var a = "dcm";
                    break a
                }
            a = null
        }
        return a || "dcm"
    };
    Y.prototype.getSdk = Y.prototype.R;
    var Nb = function(a) {
        /Chrome/.test(window.navigator.userAgent) && (Db(function(b) {
            b = b.document;
            if (a && b.head) {
                var c = c === void 0 ? document : c;
                c = c.createElement("meta");
                b.head.appendChild(c);
                c.httpEquiv = "origin-trial";
                c.content = a
            }
            return !1
        }), Lb = !0)
    };
    Y.prototype.g = function() {
        var a = this.i;
        a && typeof a.dispose == "function" && a.dispose();
        Y.B.g.call(this)
    };
    var Ob = Mb();
    w("Enabler", Ob);
    var Z = function(a) {
        G.call(this, a)
    };
    r(Z, G);
    Z.prototype.ma = function(a, b) {
        this[a] = b;
        return this
    };
    w("studio.events.StudioEvent", Z);
    Z.prototype.addProperty = Z.prototype.ma;
    Z.INIT = "init";
    Z.VISIBLE = "visible";
    Z.HIDDEN = "hidden";
    Z.VISIBILITY_CHANGE = "visibilityChange";
    Z.VISIBILITY_CHANGE_WITH_INFO = "visibilityChangeWithInfo";
    Z.EXIT = "exit";
    Z.INTERACTION = "interaction";
    Z.PAGE_LOADED = "pageLoaded";
    Z.ORIENTATION = "orientation";
    Z.ABOUT_TO_EXPAND = "aboutToExpand";
    Z.EXPAND_START = "expandStart";
    Z.EXPAND_FAILED = "expandFailed";
    Z.EXPAND_FINISH = "expandFinish";
    Z.COLLAPSE_START = "collapseStart";
    Z.COLLAPSE_FINISH = "collapseFinish";
    Z.COLLAPSE = "collapse";
    Z.FULLSCREEN_SUPPORT = "fullscreenSupport";
    Z.HOSTPAGE_FEATURES_LOADED = "hostpageFeaturesLoaded";
    Z.FULLSCREEN_DIMENSIONS = "fullscreenDimensions";
    Z.FULLSCREEN_EXPAND_START = "fullscreenExpandStart";
    Z.FULLSCREEN_EXPAND_FINISH = "fullscreenExpandFinish";
    Z.FULLSCREEN_COLLAPSE_START = "fullscreenCollapseStart";
    Z.FULLSCREEN_COLLAPSE_FINISH = "fullscreenCollapseFinish";
    Z.HOSTPAGE_SCROLL = "hostpageScroll";
    Z.OPTIONAL_HOSTPAGE_SCROLL = "optHostpageScroll";
    Z.SCROLL_INTERACTION = "scrollInteraction";
    Z.ENTER_VIEWPORT = "enterViewport";
    Z.OPTIONAL_ENTER_VIEWPORT = "optEnterViewport";
    Z.EXIT_VIEWPORT = "exitViewport";
    Z.OPTIONAL_EXIT_VIEWPORT = "optExitViewport";
    Z.VIDEO_START = "videoStart";
})();
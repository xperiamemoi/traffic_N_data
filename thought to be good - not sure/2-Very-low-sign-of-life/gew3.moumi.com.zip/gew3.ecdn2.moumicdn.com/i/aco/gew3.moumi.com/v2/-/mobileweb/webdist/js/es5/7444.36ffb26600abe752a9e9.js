"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [7444], {
        1347: function(e, t, n) {
            var s = n(74848),
                a = n(96540);
            t.A = ({
                children: e
            }) => (0, s.jsx)("ul", {
                className: "csms-connections-list",
                children: a.Children.map(e, (e => (0, s.jsx)("li", {
                    className: "csms-connections-list__item",
                    "data-qa": "connections-list-item",
                    children: e
                })))
            })
        },
        1529: function(e, t, n) {
            var s = n(74848);
            t.A = ({
                children: e,
                onKeyUp: t,
                innerRef: n,
                a11y: a = {}
            }) => (0, s.jsx)("div", {
                className: "csms-chat-messages",
                "data-qa": "chat-messages",
                onKeyUp: t,
                role: "list",
                "aria-label": a ? .label,
                ref: n,
                children: e
            })
        },
        5005: function(e, t, n) {
            var s = n(74848),
                a = n(46942),
                i = n.n(a),
                o = n(93827);
            t.A = ({
                text: e,
                isElevated: t,
                isCurrent: n
            }) => {
                const a = i()({
                    "csms-chat-date": !0,
                    "csms-chat-date--elevated": t
                });
                return (0, s.jsx)("div", {
                    className: a,
                    "data-qa": "chat-date",
                    "data-id": "chat-date",
                    tabIndex: n ? 0 : -1,
                    role: "listitem",
                    children: (0, s.jsx)("div", {
                        className: "csms-chat-date__pill",
                        children: (0, s.jsx)(o.P3, {
                            children: e
                        })
                    })
                })
            }
        },
        5103: function(e, t, n) {
            var s = n(74848),
                a = n(46942),
                i = n.n(a),
                o = n(67805);
            t.A = ({
                direction: e,
                isContinuation: t,
                nesting: n,
                content: a,
                isLoading: c
            }) => {
                const r = i()({
                    "csms-chat-bubble": !0,
                    [`csms-chat-bubble--${e}`]: e,
                    "csms-chat-bubble--continuation": t,
                    [`csms-chat-bubble--nested-${n}`]: n,
                    "csms-chat-bubble-liquid": !0
                });
                return (0, s.jsx)("div", {
                    className: r,
                    children: (0, s.jsxs)("div", {
                        className: "csms-chat-bubble-liquid__content",
                        children: [a, c ? (0, s.jsx)(o.A, {}) : null]
                    })
                })
            }
        },
        5393: function(e, t, n) {
            var s = n(74848),
                a = n(93827),
                i = n(99315),
                o = n(38635);
            t.A = ({
                direction: e,
                isContinuation: t,
                status: n,
                isNested: c,
                isSelectable: r,
                isSelected: l,
                onSelect: d,
                onFocus: u,
                nesting: m,
                content: h,
                extra: p,
                isLoading: g,
                onClickContent: f,
                onTouchStartContent: v,
                onTouchEndContent: x,
                onTouchMoveContent: b,
                onTouchCancelContent: _,
                innerRef: y,
                a11y: j = {}
            }) => (0, s.jsx)(o.A, {
                direction: e,
                isContinuation: t,
                status: n,
                isNested: c,
                isSelectable: r,
                isSelected: l,
                onSelect: d,
                onFocus: u,
                innerRef: y,
                a11y: {
                    label: j.label,
                    name: j.name
                },
                children: (0, s.jsx)("button", {
                    className: "csms-chat-message-content-location",
                    onClick: f,
                    onTouchStart: v,
                    onTouchEnd: x,
                    onTouchMove: b,
                    onTouchCancel: _,
                    "data-qa-message-content-type": "location",
                    "aria-label": j ? .contentLabel,
                    type: "button",
                    children: (0, s.jsx)(i.A, {
                        direction: e,
                        isContinuation: t,
                        nesting: m,
                        content: h,
                        extra: p ? (0, s.jsxs)("span", {
                            className: "csms-chat-message-content-location__extra",
                            children: [(0, s.jsxs)("span", {
                                className: "csms-chat-message-content-location__extra-text",
                                children: [p.title ? (0, s.jsx)("span", {
                                    className: "csms-chat-message-content-location__title",
                                    children: (0, s.jsx)(a.P3, {
                                        weight: "bolder",
                                        children: p.title
                                    })
                                }) : null, p.note ? (0, s.jsx)("span", {
                                    className: "csms-chat-message-content-location__note",
                                    children: (0, s.jsx)(a.P3, {
                                        children: p.note
                                    })
                                }) : null]
                            }), p.icon ? (0, s.jsx)("span", {
                                className: "csms-chat-message-content-location__extra-icon",
                                children: p.icon
                            }) : null]
                        }) : null,
                        isLoading: g
                    })
                })
            })
        },
        8921: function(e, t, n) {
            var s = n(46518),
                a = n(8379);
            s({
                target: "Array",
                proto: !0,
                forced: a !== [].lastIndexOf
            }, {
                lastIndexOf: a
            })
        },
        9194: function(e, t, n) {
            var s = n(74848),
                a = n(96540),
                i = n(8483),
                o = n(5103),
                c = n(38635);
            const r = {
                giphy: "logo-provider-giphy",
                tenor: "logo-provider-tenor"
            };
            t.A = ({
                direction: e,
                isContinuation: t,
                extra: n,
                status: l,
                isNested: d,
                isSelectable: u,
                isSelected: m,
                onSelect: h,
                onFocus: p,
                nesting: g,
                image: f,
                isLoading: v,
                onClickContent: x,
                onTouchStartContent: b,
                onTouchEndContent: _,
                onTouchMoveContent: y,
                onTouchCancelContent: j,
                innerRef: C,
                a11y: N = {}
            }) => {
                const k = {
                    paddingBottom: f ? `${f.ratio}%` : "75%"
                };
                return (0, s.jsx)(c.A, {
                    direction: e,
                    isContinuation: t,
                    extra: n,
                    status: l,
                    isNested: d,
                    isSelectable: u,
                    isSelected: m,
                    onSelect: h,
                    onFocus: p,
                    innerRef: C,
                    a11y: {
                        label: N.label,
                        name: N.name
                    },
                    children: (0, s.jsx)(o.A, {
                        direction: e,
                        isContinuation: t,
                        nesting: g,
                        content: (0, s.jsx)("button", {
                            className: "csms-chat-message-content-gif",
                            style: k,
                            onClick: x,
                            onTouchStart: b,
                            onTouchEnd: _,
                            onTouchMove: y,
                            onTouchCancel: j,
                            "data-qa-message-content-type": "gif",
                            "aria-label": N ? .contentLabel,
                            type: "button",
                            children: f ? (0, s.jsxs)(a.Fragment, {
                                children: [(0, s.jsx)("img", {
                                    className: "csms-chat-message-content-gif__img",
                                    src: f.src,
                                    "data-qa": "chat-message-gif-img",
                                    alt: ""
                                }), f.provider ? (0, s.jsx)("span", {
                                    className: `csms-chat-message-content-gif__logo csms-chat-message-content-gif__logo--${f.provider}`,
                                    children: (0, s.jsx)(i.A, {
                                        name: r[f.provider]
                                    })
                                }) : null]
                            }) : null
                        }),
                        isLoading: v && !f
                    })
                })
            }
        },
        12297: function(e, t, n) {
            var s = n(74848),
                a = n(96540),
                i = n(46942),
                o = n.n(i);
            t.A = ({
                children: e,
                centered: t = !1,
                cols: n = 3,
                shape: i = "squared",
                spacing: c,
                tag: r = "ul"
            }) => {
                const l = o()({
                        "csms-grid-list": !0,
                        "csms-grid-list--centered": t,
                        [`csms-grid-list--cols-${n}`]: n,
                        [`csms-grid-list--shape-${i}`]: i,
                        [`csms-grid-list--spacing-${c}`]: c
                    }),
                    d = r,
                    u = "div" !== r ? "li" : "div";
                return (0, s.jsx)(d, {
                    className: l,
                    role: "div" !== d ? "list" : void 0,
                    children: a.Children.map(e, (e => (0, s.jsx)(u, {
                        className: "csms-grid-list__item",
                        children: (0, s.jsx)("div", {
                            className: "csms-grid-list__item-container",
                            children: e
                        })
                    })))
                })
            }
        },
        16303: function(e, t, n) {
            var s = n(74848),
                a = n(96540),
                i = n(46942),
                o = n.n(i),
                c = n(84362),
                r = n(32675),
                l = n(26914),
                d = n(31751),
                u = n(8483),
                m = n(53787),
                h = n(94767),
                p = n(45998),
                g = n(40745),
                f = n(87019),
                v = n(93827);
            const x = 200;
            t.A = ({
                user: e,
                badge: t,
                mediaOverlay: i,
                halo: b,
                tag: _,
                moodStatus: y,
                lastMessageStatus: j,
                message: C,
                isChecked: N,
                isLocked: k,
                isDisabled: A,
                isDisabledClickable: T,
                isDeleting: M,
                isFavouriteAllowed: E = !0,
                onClick: S,
                onFavourite: w,
                userRef: R,
                isAddedHACK: L,
                a11y: P,
                swipeMenuActions: I
            }) => {
                const U = o()({
                        "csms-connections-item": !0,
                        "csms-connections-item--user": !0,
                        "csms-connections-item--disabled": A,
                        "csms-connections-item--has-swipe-menu": I && I.length > 0,
                        "js-mw-connections-item": !0,
                        "js-mw-connections-item--is-checked": !A && N,
                        "mw-connections-item--is-added-hack": L,
                        "is-deleted": M
                    }),
                    q = o()({
                        "csms-connections-item__favourite": !0,
                        "csms-is-active": e.isFavourite
                    }),
                    [D, F] = (0, a.useState)(!1),
                    V = (0, a.useRef)(null),
                    [$, O] = (0, a.useState)(x),
                    H = D ? 1 : -1,
                    z = $ || x,
                    B = z * H,
                    K = .2 * z;
                let W;
                (N || i) && (W = {
                    children: (0, s.jsxs)(a.Fragment, {
                        children: [N ? (0, s.jsx)("span", {
                            className: "csms-connections-item__media-icon",
                            children: (0, s.jsx)(u.A, {
                                name: "generic-check"
                            })
                        }) : null, i]
                    }),
                    background: N ? "primary" : "transparent"
                });
                const G = `user${e.id}`,
                    X = (0, s.jsxs)(a.Fragment, {
                        children: [(0, s.jsx)("span", {
                            className: "csms-connections-item__profile",
                            children: (0, s.jsx)(v.ZS, {
                                color: "black",
                                children: (0, s.jsx)(m.A, {
                                    name: e.name,
                                    age: e.age,
                                    status: e.status,
                                    a11y: {
                                        label: P ? .profileInfoLabel
                                    }
                                })
                            })
                        }), y ? (0, s.jsx)("span", {
                            className: "csms-connections-item__mood-status",
                            "aria-hidden": !0,
                            children: (0, s.jsx)(d.A, {
                                size: "16px",
                                text: y,
                                visuallyCorrected: !0
                            })
                        }) : null, _ ? (0, s.jsxs)("span", {
                            className: "csms-connections-item__tag",
                            children: [(0, s.jsx)(c.A, {
                                children: ","
                            }), (0, s.jsx)(r.A, {
                                text: _.text,
                                size: "mini",
                                styling: _.styling
                            })]
                        }) : null]
                    });
                (0, a.useEffect)((() => {
                    F(n.g.document && "rtl" === n.g.document.dir)
                }), []), (0, a.useEffect)((() => {
                    const e = V.current;
                    if (!e) return;
                    const t = () => {
                        const t = e.offsetWidth || x;
                        O(t)
                    };
                    if (t(), void 0 === n.g.ResizeObserver) return;
                    const s = new n.g.ResizeObserver((() => {
                        t()
                    }));
                    return s.observe(e), () => {
                        s.disconnect()
                    }
                }), [I, D]);
                const Y = (0, a.useRef)(null),
                    Q = (0, a.useRef)(null),
                    [Z, J] = (0, a.useState)(0),
                    ee = (0, a.useRef)(0),
                    [te, ne] = (0, a.useState)(!1),
                    [se, ae] = (0, a.useState)(!1),
                    ie = (0, a.useRef)({
                        startX: 0,
                        startY: 0,
                        startOffset: 0,
                        isDragging: !1,
                        hasDragged: !1,
                        isHorizontalDrag: !1
                    });
                (0, a.useEffect)((() => {
                    ee.current = Z
                }), [Z]);
                const oe = (e, t) => {
                        I && 0 !== I.length && !A && (ie.current.startX = e, ie.current.startY = t ? ? e, ie.current.startOffset = ee.current, ie.current.isDragging = !0, ie.current.hasDragged = !1, ie.current.isHorizontalDrag = !1, ne(!0))
                    },
                    ce = (e, t) => {
                        if (!ie.current.isDragging || !I || 0 === I.length) return;
                        const n = e - ie.current.startX,
                            s = void 0 !== t ? t - ie.current.startY : 0;
                        if (!ie.current.isHorizontalDrag && (Math.abs(n) > 5 || Math.abs(s) > 5)) {
                            if (Math.abs(s) > Math.abs(n)) return ie.current.isDragging = !1, void ne(!1);
                            ie.current.isHorizontalDrag = !0
                        }
                        if (!ie.current.isHorizontalDrag) return;
                        Math.abs(n) > 5 && (ie.current.hasDragged = !0);
                        const a = D ? -n : n;
                        if (ie.current.startOffset === B && a > 10) return ie.current.hasDragged = !0, ne(!1), void requestAnimationFrame((() => {
                            ae(!1), J(0), ie.current.isDragging = !1, ie.current.isHorizontalDrag = !1, ne(!1), setTimeout((() => {
                                ie.current.hasDragged = !1
                            }), 300)
                        }));
                        const i = ie.current.startOffset + n,
                            o = (c = i, -1 === H ? Math.max(B, Math.min(0, c)) : Math.max(0, Math.min(B, c)));
                        var c;
                        J(o)
                    };
                (0, a.useEffect)((() => {
                    const e = Y.current;
                    if (!e || !I || 0 === I.length || A) return;
                    const t = D ? 1 : -1,
                        n = $ || x,
                        s = n * t,
                        a = .2 * n,
                        i = e => {
                            const t = e.touches[0];
                            t && oe(t.clientX, t.clientY)
                        },
                        o = e => {
                            if (!ie.current.isDragging) return;
                            const n = e.touches[0];
                            if (!n) return;
                            const a = n.clientX - ie.current.startX,
                                i = n.clientY - ie.current.startY;
                            if (!ie.current.isHorizontalDrag && (Math.abs(a) > 5 || Math.abs(i) > 5)) {
                                if (Math.abs(i) > Math.abs(a)) return ie.current.isDragging = !1, void ne(!1);
                                ie.current.isHorizontalDrag = !0
                            }
                            if (ie.current.isHorizontalDrag) {
                                e.preventDefault();
                                const n = 1 === t ? -a : a;
                                if (ie.current.startOffset === s && n > 10) return ie.current.hasDragged = !0, ne(!1), void requestAnimationFrame((() => {
                                    ae(!1), J(0), ie.current.isDragging = !1, ie.current.isHorizontalDrag = !1, ne(!1), setTimeout((() => {
                                        ie.current.hasDragged = !1
                                    }), 300)
                                }));
                                const i = ie.current.startOffset + a,
                                    c = (o = i, -1 === t ? Math.max(s, Math.min(0, o)) : Math.max(0, Math.min(s, o)));
                                J(c)
                            }
                            var o
                        },
                        c = () => {
                            if (!ie.current.isDragging) return;
                            ie.current.isDragging = !1, ie.current.isHorizontalDrag = !1, ne(!1);
                            const e = ee.current,
                                t = ie.current.startOffset,
                                n = a;
                            requestAnimationFrame((() => {
                                0 === t ? Math.abs(e - 0) > n ? (ae(!0), J(s)) : (ae(!1), J(0)) : Math.abs(e - s) > n ? (ae(!1), J(0)) : (ae(!0), J(s)), setTimeout((() => {
                                    ie.current.hasDragged = !1
                                }), 100)
                            }))
                        };
                    return e.addEventListener("touchstart", i, {
                        passive: !0
                    }), e.addEventListener("touchmove", o, {
                        passive: !1
                    }), e.addEventListener("touchend", c, {
                        passive: !0
                    }), () => {
                        e.removeEventListener("touchstart", i), e.removeEventListener("touchmove", o), e.removeEventListener("touchend", c)
                    }
                }), [I, A, D, $]);
                (0, a.useEffect)((() => {
                    if (!te) return;
                    const e = e => {
                            ce(e.clientX, e.clientY)
                        },
                        t = () => {
                            (() => {
                                if (!ie.current.isDragging) return;
                                ie.current.isDragging = !1, ie.current.isHorizontalDrag = !1, ne(!1);
                                const e = Z,
                                    t = ie.current.startOffset,
                                    n = K;
                                requestAnimationFrame((() => {
                                    0 === t ? Math.abs(e - 0) > n ? (ae(!0), J(B)) : (ae(!1), J(0)) : Math.abs(e - B) > n ? (ae(!1), J(0)) : (ae(!0), J(B)), setTimeout((() => {
                                        ie.current.hasDragged = !1
                                    }), 100)
                                }))
                            })()
                        };
                    return document.addEventListener("mousemove", e), document.addEventListener("mouseup", t), () => {
                        document.removeEventListener("mousemove", e), document.removeEventListener("mouseup", t)
                    }
                }), [te, Z]), (0, a.useEffect)((() => {
                    I && 0 !== I.length || (ae(!1), J(0))
                }), [I]), (0, a.useEffect)((() => {
                    if (!se) return;
                    const e = e => {
                        Q.current && !Q.current.contains(e.target) && (ae(!1), J(0))
                    };
                    return document.addEventListener("mousedown", e), document.addEventListener("touchstart", e), () => {
                        document.removeEventListener("mousedown", e), document.removeEventListener("touchstart", e)
                    }
                }), [se]);
                const re = {
                    transform: `translateX(${Z}px)`,
                    transition: te ? "none" : "transform 0.3s ease-out"
                };
                return (0, s.jsxs)("div", {
                    ref: Q,
                    className: U,
                    "data-qa": "connections-item",
                    "data-qa-connections-item-type": "user",
                    "data-qa-blocking-promo": k ? "locked" : null,
                    "aria-hidden": A && !T,
                    children: [I ? (0, s.jsx)("div", {
                        className: "csms-connections-item__swipe-menu",
                        ref: V,
                        children: I.map(((e, t) => (0, s.jsx)("button", {
                            className: o()("csms-connections-item__swipe-menu-button", {
                                "csms-connections-item__swipe-menu-button--dangerous": e.isDangerous
                            }),
                            onClick: () => {
                                e.onClick(), ae(!1), J(0)
                            },
                            children: e.text
                        }, `swipe-menu-action-${t}`)))
                    }) : null, (0, s.jsx)("div", {
                        ref: Y,
                        className: "csms-connections-item__content",
                        style: re,
                        onMouseDown: e => {
                            I && I.length > 0 && !A && (e.preventDefault(), oe(e.clientX, e.clientY))
                        },
                        children: (0, s.jsxs)(h.A, {
                            children: [(0, s.jsx)(f.A, {
                                children: (0, s.jsx)("div", {
                                    className: "csms-connections-item__media",
                                    children: (0, s.jsx)(l.A, {
                                        size: "sm",
                                        user: e,
                                        badge: t,
                                        halo: b,
                                        overlay: W
                                    })
                                })
                            }), (0, s.jsxs)(p.A, {
                                children: ["toggle" !== P ? .role ? (0, s.jsx)("button", {
                                    className: "csms-connections-item__user",
                                    onClick: () => {
                                        se || te || ie.current.hasDragged || S ? .()
                                    },
                                    disabled: A && !T,
                                    "data-qa": "connections-item-content",
                                    ref: R,
                                    "aria-describedby": C ? G : void 0,
                                    type: "button",
                                    children: X
                                }) : (0, s.jsxs)("label", {
                                    className: "csms-connections-item__user",
                                    "data-qa": "connections-item-content",
                                    ref: R,
                                    children: [X, (0, s.jsx)("input", {
                                        className: "csms-connections-item__checkbox",
                                        type: "checkbox",
                                        defaultChecked: N,
                                        onChange: e => {
                                            S ? .()
                                        },
                                        "aria-label": P ? .profileInfoLabel
                                    })]
                                }), C ? (0, s.jsxs)("div", {
                                    className: "csms-connections-item__message",
                                    "data-qa": "csms-connections-item__message",
                                    id: G,
                                    children: [j ? (0, s.jsx)("div", {
                                        className: "csms-connections-item__message-read-receipt-status",
                                        "aria-hidden": !0,
                                        children: (0, s.jsx)(u.A, {
                                            name: "generic-read-receipt",
                                            color: "seen" === j ? "feature-revenue" : "gray-30"
                                        })
                                    }) : null, (0, s.jsx)(v.P2, {
                                        ellipsis: !0,
                                        dangerous: !0,
                                        children: C
                                    }), (0, s.jsx)(c.A, {
                                        children: P ? .messageStatusLabel
                                    })]
                                }) : null]
                            }), E ? (0, s.jsx)(g.A, {
                                children: (0, s.jsx)("button", {
                                    className: q,
                                    onClick: w,
                                    "data-qa": "favourite",
                                    "data-qa-favourited": e.isFavourite ? "true" : "false",
                                    "aria-pressed": e.isFavourite,
                                    type: "button",
                                    children: (0, s.jsx)(u.A, {
                                        name: e.isFavourite ? "generic-star" : "generic-star-outlined",
                                        a11y: {
                                            label: P ? .favouriteLabel
                                        }
                                    })
                                })
                            }) : null]
                        })
                    })]
                })
            }
        },
        18707: function(e, t, n) {
            var s = n(74848),
                a = n(96540),
                i = n(46942),
                o = n.n(i);
            t.A = ({
                children: e,
                align: t = "left",
                spacing: n,
                hpadded: i,
                vpadded: c,
                onScroll: r,
                innerRef: l,
                tag: d = "ul",
                a11y: u
            }) => {
                const m = o()({
                        "csms-scroll-list": !0,
                        [`csms-scroll-list--align-${t}`]: t,
                        "csms-scroll-list--hpadded": i,
                        "csms-scroll-list--vpadded": c
                    }, void 0 !== n && [`csms-scroll-list--spacing-${n}`]),
                    h = d,
                    p = "div" !== d ? "li" : "div";
                return (0, s.jsx)("div", {
                    className: m,
                    onScroll: r,
                    ref: l,
                    tabIndex: 0,
                    role: u ? .label ? "region" : void 0,
                    "aria-label": u ? .label,
                    children: (0, s.jsx)(h, {
                        className: "csms-scroll-list__items",
                        role: "ul" === h ? "list" : void 0,
                        children: a.Children.map(e, (e => (0, s.jsx)(p, {
                            className: "csms-scroll-list__item",
                            "data-qa": "scroll-list-item",
                            children: e
                        })))
                    })
                })
            }
        },
        22001: function(e, t, n) {
            n.d(t, {
                C: function() {
                    return c
                },
                M: function() {
                    return d
                },
                U: function() {
                    return o
                },
                _: function() {
                    return i
                },
                a: function() {
                    return r
                },
                b: function() {
                    return u
                }
            });
            var s = n(96540),
                a = function(e, t) {
                    return a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                    }, a(e, t)
                };

            function i(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                function n() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            }
            var o, c, r = function() {
                    return r = Object.assign || function(e) {
                        for (var t, n = 1, s = arguments.length; n < s; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }, r.apply(this, arguments)
                },
                l = (0, s.createContext)({}),
                d = l,
                u = l.Provider;
            l.Consumer;
            ! function(e) {
                e[e.IS_BLACKLISTED = 0] = "IS_BLACKLISTED", e[e.IS_NOT_BLACKLISTED = 1] = "IS_NOT_BLACKLISTED", e[e.IS_PREVIEW = 2] = "IS_PREVIEW"
            }(o || (o = {})),
            function(e) {
                e[e.REGULAR = 0] = "REGULAR", e[e.GIF = 1] = "GIF"
            }(c || (c = {}))
        },
        22864: function(e, t, n) {
            var s = n(74848),
                a = n(96540),
                i = n(33815);
            t.A = ({
                children: e,
                isLoading: t = !0,
                onScroll: n
            }) => (0, s.jsx)("div", {
                className: "csms-chat-panel-drawer",
                onScroll: n,
                children: t ? (0, s.jsx)("div", {
                    className: "csms-chat-panel-drawer__loading-placeholder",
                    children: (0, s.jsx)("div", {
                        className: "csms-chat-panel-drawer__loader-wrapper",
                        children: (0, s.jsx)(i.A, {})
                    })
                }) : (0, s.jsx)(a.Fragment, {
                    children: e
                })
            })
        },
        25274: function(e, t, n) {
            var s = n(74848),
                a = n(96540),
                i = n(84362),
                o = n(40223),
                c = n(8483),
                r = n(33815),
                l = n(93827),
                d = n(32509),
                u = n(38635);
            const m = ({
                bars: e = [],
                percentage: t
            }) => {
                const {
                    tokens: n
                } = (0, a.useContext)(o.Ay), i = parseInt(n.TOKEN_CHAT_MESSAGE_AUDIO_BAR_WIDTH.replace(/px$/, ""), 10), c = i, r = parseInt(n.TOKEN_CHAT_MESSAGE_AUDIO_BAR_MAX_HEIGHT.replace(/px$/, ""), 10), l = parseFloat(n.TOKEN_CHAT_MESSAGE_AUDIO_BAR_RADIUS.replace(/px$/, "")), d = parseInt(n.TOKEN_CHAT_MESSAGE_AUDIO_BAR_GAP.replace(/px$/, ""), 10), u = i * e.length + d * (e.length - 1), m = r, h = n.TOKEN_CHAT_MESSAGE_AUDIO_BAR_OPACITY, p = `${t}%`, g = Math.random().toString(36).substr(2, 10);
                return (0, s.jsxs)("svg", {
                    width: u,
                    height: m,
                    viewBox: `0 0 ${u} ${m}`,
                    "aria-label": `${t}%`,
                    role: "img",
                    children: [(0, s.jsx)("defs", {
                        children: (0, s.jsx)("clipPath", {
                            id: `${g}-mask`,
                            children: e.map(((e, t) => {
                                const n = c + (r - c) * e / 7;
                                return (0, s.jsx)("rect", {
                                    x: (i + d) * t,
                                    y: r - n,
                                    width: i,
                                    height: n,
                                    rx: l,
                                    ry: l
                                }, `${g}-${t}`)
                            }))
                        })
                    }), (0, s.jsxs)("g", {
                        clipPath: `url(#${g}-mask)`,
                        children: [(0, s.jsx)("rect", {
                            x: "0",
                            y: "0",
                            width: "100%",
                            height: r,
                            fill: "currentColor",
                            fillOpacity: h
                        }), (0, s.jsx)("rect", {
                            x: "0",
                            y: "0",
                            width: p,
                            height: r,
                            fill: "currentColor"
                        })]
                    })]
                })
            };
            t.A = ({
                direction: e,
                isContinuation: t,
                extra: n,
                status: a,
                isNested: o,
                isSelectable: h,
                isSelected: p,
                onSelect: g,
                onFocus: f,
                nesting: v,
                playback: x = "paused",
                bars: b = [],
                percentage: _ = 0,
                time: y = "00:00",
                onClickContent: j,
                onTouchStartContent: C,
                onTouchEndContent: N,
                onTouchMoveContent: k,
                onTouchCancelContent: A,
                innerRef: T,
                a11y: M = {}
            }) => (0, s.jsx)(u.A, {
                direction: e,
                isContinuation: t,
                extra: n,
                status: a,
                isNested: o,
                isSelectable: h,
                isSelected: p,
                onSelect: g,
                onFocus: f,
                innerRef: T,
                a11y: {
                    label: M.label,
                    name: M.name
                },
                children: (0, s.jsx)(d.A, {
                    direction: e,
                    isContinuation: t,
                    nesting: v,
                    content: (0, s.jsxs)("button", {
                        className: "csms-chat-message-content-audio",
                        onClick: j,
                        onTouchStart: C,
                        onTouchEnd: N,
                        onTouchMove: k,
                        onTouchCancel: A,
                        "data-qa-message-content-type": "audio",
                        "aria-label": M.contentLabel,
                        type: "button",
                        children: [(0, s.jsx)(i.A, {
                            children: M ? .contentLabel
                        }), (0, s.jsx)("span", {
                            className: "csms-chat-message-content-audio__icon",
                            children: (() => {
                                switch (x) {
                                    case "loading":
                                        return (0, s.jsx)(r.A, {
                                            a11y: {
                                                label: M ? .iconLabel
                                            }
                                        });
                                    case "playing":
                                        return (0, s.jsx)(c.A, {
                                            name: "generic-pause",
                                            a11y: {
                                                label: M ? .iconLabel
                                            }
                                        });
                                    case "paused":
                                        return (0, s.jsx)(c.A, {
                                            name: "generic-play",
                                            a11y: {
                                                label: M ? .iconLabel
                                            }
                                        });
                                    default:
                                        return null
                                }
                            })()
                        }), (0, s.jsx)("span", {
                            className: "csms-chat-message-content-audio__bars",
                            children: (0, s.jsx)(m, {
                                bars: b,
                                percentage: _
                            })
                        }), y ? (0, s.jsx)("time", {
                            className: "csms-chat-message-content-audio__time",
                            children: (0, s.jsx)(l.P3, {
                                children: y
                            })
                        }) : null]
                    })
                })
            })
        },
        29639: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return l
                }
            });
            var s = n(74848),
                a = n(46942),
                i = n.n(a),
                o = n(8483);
            const c = {
                prev: "floating-action-prev",
                next: "floating-action-next"
            };
            var r = ({
                action: e,
                isPressed: t,
                isHidden: n,
                isReady: a,
                isAnimated: r,
                onClick: l,
                dataQA: d,
                a11y: u
            }) => {
                const m = i()({
                        "csms-pagination-bar__action": !0,
                        "csms-pagination-bar__action--is-pressed": t,
                        "csms-pagination-bar__action--is-hidden": n,
                        "csms-pagination-bar__action--is-animated": r
                    }),
                    h = a ? "floating-action-ok" : c[e];
                return (0, s.jsx)("button", {
                    className: m,
                    onClick: l,
                    "aria-hidden": n,
                    disabled: n,
                    type: "button",
                    ...d,
                    children: (0, s.jsx)(o.A, {
                        name: h,
                        supportsRtl: !0,
                        a11y: {
                            label: u.label
                        }
                    })
                })
            };
            var l = ({
                prev: e,
                next: t,
                content: n
            }) => (0, s.jsxs)("div", {
                className: "csms-pagination-bar",
                children: [(0, s.jsx)(r, {
                    action: "prev",
                    ...e
                }), (0, s.jsx)("div", {
                    className: "csms-pagination-bar__content",
                    children: n
                }), (0, s.jsx)(r, {
                    action: "next",
                    ...t
                })]
            })
        },
        30244: function(e, t, n) {
            var s = n(74848),
                a = n(33815);
            t.A = () => (0, s.jsx)("div", {
                className: "csms-chat-loading-indicator",
                children: (0, s.jsx)("div", {
                    className: "csms-chat-loading-indicator__loader-wrapper",
                    children: (0, s.jsx)(a.A, {})
                })
            })
        },
        31731: function(e, t, n) {
            var s = n(74848),
                a = n(12297);
            t.A = ({
                children: e
            }) => (0, s.jsx)(a.A, {
                cols: 4,
                shape: "content",
                children: e
            })
        },
        32509: function(e, t, n) {
            var s = n(74848),
                a = n(46942),
                i = n.n(a);
            t.A = ({
                direction: e,
                isContinuation: t,
                nesting: n,
                content: a
            }) => {
                const o = i()({
                    "csms-chat-bubble": !0,
                    [`csms-chat-bubble--${e}`]: e,
                    "csms-chat-bubble--continuation": t,
                    [`csms-chat-bubble--nested-${n}`]: n,
                    "csms-chat-bubble-simple": !0
                });
                return (0, s.jsx)("div", {
                    className: o,
                    children: (0, s.jsx)("div", {
                        className: "csms-chat-bubble-simple__content",
                        children: a
                    })
                })
            }
        },
        34923: function(e, t, n) {
            var s = n(74848),
                a = n(46942),
                i = n.n(a),
                o = n(8483),
                c = n(38635);
            t.A = ({
                direction: e,
                isContinuation: t,
                status: n,
                isSelectable: a,
                isSelected: r,
                onSelect: l,
                onFocus: d,
                emoji: u,
                isNew: m,
                onTouchStartContent: h,
                onTouchEndContent: p,
                onTouchMoveContent: g,
                onTouchCancelContent: f,
                innerRef: v,
                a11y: x = {}
            }) => {
                const b = i()({
                    "csms-chat-message-content-emoji-animated": !0,
                    [`csms-chat-message-content-emoji-animated--${u}`]: !0,
                    "is-new": m
                });
                return (0, s.jsx)(c.A, {
                    direction: e,
                    isContinuation: t,
                    status: n,
                    isSelectable: a,
                    isSelected: r,
                    onSelect: l,
                    onFocus: d,
                    innerRef: v,
                    a11y: x,
                    children: (0, s.jsx)("div", {
                        className: b,
                        onTouchStart: h,
                        onTouchEnd: p,
                        onTouchMove: g,
                        onTouchCancel: f,
                        "data-qa-message-content-type": "emoji-animated",
                        children: (() => {
                            if ("heart" === u) return (0, s.jsx)(o.A, {
                                name: "generic-heart",
                                a11y: {
                                    label: x ? .label
                                }
                            })
                        })()
                    })
                })
            }
        },
        35734: function(e, t, n) {
            var s = n(74848);
            t.A = ({
                children: e
            }) => (0, s.jsx)("div", {
                className: "csms-chat-composer-frame__action",
                children: e
            })
        },
        38635: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return m
                }
            });
            var s = n(74848),
                a = n(96540),
                i = n(46942),
                o = n.n(i),
                c = n(84362),
                r = n(17380),
                l = n(8483),
                d = n(93827);
            var u = ({
                icon: e,
                iconColor: t = "base",
                text: n = "base",
                textColor: a,
                onClick: i,
                isCurrent: c
            }) => {
                const r = o()({
                        "csms-chat-message-item-status": !0,
                        [`csms-chat-message-item-status--color-${a}`]: !0
                    }),
                    u = o()({
                        "csms-chat-message-item-status__icon": !0,
                        [`csms-chat-message-item-status--color-${t}`]: !0
                    }),
                    m = i ? "button" : "div";
                let h = c ? 0 : -1;
                return i || (h = void 0), (0, s.jsxs)(m, {
                    className: r,
                    onClick: i,
                    "data-qa": "chat-message-status",
                    tabIndex: h,
                    type: "button" === m ? "button" : void 0,
                    children: [e ? (0, s.jsx)("span", {
                        className: u,
                        children: (0, s.jsx)(l.A, {
                            name: e
                        })
                    }) : null, (0, s.jsx)("span", {
                        className: "csms-chat-message-item-status__text",
                        children: (0, s.jsx)(d.P3, {
                            children: n
                        })
                    })]
                })
            };
            var m = ({
                width: e,
                direction: t,
                isContinuation: n,
                children: i,
                extra: l,
                status: d,
                isNested: m,
                isSelectable: h,
                isSelected: p,
                onSelect: g,
                onFocus: f,
                innerRef: v,
                isCurrent: x,
                a11y: b = {}
            }) => {
                const _ = o()({
                    "csms-chat-message-item": !0,
                    [`csms-chat-message-item--${e}-width`]: e,
                    [`csms-chat-message-item--${t}`]: t,
                    "csms-chat-message-item--continuation": n,
                    "csms-chat-message-item--selectable": h
                });
                if (m) return (0, s.jsx)(a.Fragment, {
                    children: i
                });
                const y = h ? "label" : "div";
                return (0, s.jsxs)("div", {
                    className: _,
                    ref: v,
                    "data-id": "chat-message",
                    "data-qa": "chat-message",
                    "data-qa-message-direction": t,
                    role: "listitem",
                    tabIndex: x ? 0 : -1,
                    onFocus: f,
                    "aria-label": b ? .label,
                    children: [(0, s.jsxs)(y, {
                        className: "csms-chat-message-item__sub-container",
                        children: [h ? (0, s.jsx)("span", {
                            className: "csms-chat-message-item__select",
                            children: (0, s.jsx)(r.A, {
                                type: "checkbox",
                                isChecked: p,
                                onChange: g,
                                "aria-label": b ? .label
                            })
                        }) : null, (0, s.jsxs)("span", {
                            className: "csms-chat-message-item__content",
                            "aria-hidden": h || void 0,
                            inert: h ? "" : void 0,
                            children: [(0, s.jsx)(c.A, {
                                children: b ? .name
                            }), i, l]
                        })]
                    }), d ? (0, s.jsx)("div", {
                        className: "csms-chat-message-item__sub-container",
                        children: (0, s.jsx)(u, { ...d,
                            isCurrent: x
                        })
                    }) : null]
                })
            }
        },
        40178: function(e, t, n) {
            var s = n(74848),
                a = n(46942),
                i = n.n(a),
                o = n(8483);
            t.A = ({
                status: e,
                a11y: t = {}
            }) => {
                const n = i()({
                        "csms-chat-message-item-reaction": !0,
                        [`csms-chat-message-item-reaction--is-${e}`]: e
                    }),
                    a = i()({
                        "csms-chat-message-item-reaction__icon": !0,
                        [`csms-chat-message-item-reaction__icon--is-${e}`]: e
                    });
                return (0, s.jsx)("div", {
                    className: n,
                    children: (0, s.jsx)("div", {
                        className: a,
                        children: (0, s.jsx)(o.A, {
                            name: "badge-feature-liked-you",
                            a11y: t
                        })
                    })
                })
            }
        },
        40745: function(e, t, n) {
            var s = n(74848);
            t.A = ({
                children: e,
                tag: t = "div"
            }) => {
                const n = t;
                return (0, s.jsx)(n, {
                    className: "csms-spring-box__extra",
                    children: e
                })
            }
        },
        43968: function(e, t, n) {
            var s = n(74848),
                a = n(96540),
                i = n(46942),
                o = n.n(i),
                c = n(40223),
                r = n(5103),
                l = n(38635);
            const d = ({
                children: e,
                background: t
            }) => {
                const n = o()({
                    "csms-chat-message-content-media__overlay": !0,
                    [`csms-chat-message-content-media__overlay--${t}`]: t
                });
                return (0, s.jsx)("span", {
                    className: n,
                    children: e
                })
            };
            t.A = ({
                direction: e,
                isContinuation: t,
                extra: n,
                status: i,
                isNested: o,
                isSelectable: u,
                isSelected: m,
                onSelect: h,
                onFocus: p,
                nesting: g,
                image: f,
                overlay: v,
                isLoading: x,
                onClickContent: b,
                onTouchStartContent: _,
                onTouchEndContent: y,
                onTouchMoveContent: j,
                onTouchCancelContent: C,
                innerRef: N,
                a11y: k = {}
            }) => {
                const {
                    tokens: A
                } = (0, a.useContext)(c.Ay), T = parseInt(A.TOKEN_CHAT_BUBBLE_FIX_WIDTH.replace(/px$/, ""), 10), M = f.height / f.width, E = {};
                return M > 1 ? (E.width = T / M + "px", E.height = `${T}px`) : (E.width = `${T}px`, E.height = T * M + "px"), (0, s.jsx)(l.A, {
                    direction: e,
                    isContinuation: t,
                    extra: n,
                    status: i,
                    isNested: o,
                    isSelectable: u,
                    isSelected: m,
                    onSelect: h,
                    onFocus: p,
                    innerRef: N,
                    a11y: {
                        label: k.label,
                        name: k.name
                    },
                    children: (0, s.jsx)(r.A, {
                        direction: e,
                        isContinuation: t,
                        nesting: g,
                        content: (0, s.jsxs)("button", {
                            className: "csms-chat-message-content-media",
                            style: E,
                            onClick: b,
                            onTouchStart: _,
                            onTouchEnd: y,
                            onTouchMove: j,
                            onTouchCancel: C,
                            "data-qa-message-content-type": "media",
                            "aria-label": k ? .contentLabel,
                            type: "button",
                            children: [f.src ? (0, s.jsx)("img", {
                                className: "csms-chat-message-content-media__img",
                                src: f.src,
                                alt: "",
                                "data-qa": "chat-message-media-img"
                            }) : null, v ? (0, s.jsx)(d, {
                                background: v.background,
                                children: v.children
                            }) : null]
                        }),
                        isLoading: x && !f.src
                    })
                })
            }
        },
        47460: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return o
                }
            });
            var s = n(74848),
                a = n(70870);
            var i = ({
                id: e = "chat-controls-base-input-textarea",
                name: t,
                value: n,
                placeholder: a,
                onClick: i,
                onFocus: o,
                onKeyPress: c,
                onChange: r,
                onBlur: l,
                innerRef: d,
                a11y: u
            }) => (0, s.jsxs)("div", {
                className: "csms-chat-controls-base-input-message",
                children: [(0, s.jsx)("div", {
                    className: "csms-chat-controls-base-input-message__mirror",
                    "aria-hidden": !0,
                    children: n
                }), (0, s.jsx)("textarea", {
                    className: "csms-chat-controls-base-input-message__field",
                    id: e,
                    name: t,
                    value: n,
                    placeholder: a,
                    onKeyPress: c,
                    onClick: i,
                    onFocus: o,
                    onChange: r,
                    onBlur: l,
                    ref: d,
                    "data-qa": "chat-input-textarea",
                    "aria-label": u ? .label,
                    rows: 1
                })]
            });
            var o = ({
                id: e = "chat-composer-input-message",
                name: t,
                value: n,
                placeholder: o,
                extra: c,
                onClick: r,
                onFocus: l,
                onKeyPress: d,
                onChange: u,
                onBlur: m,
                innerRef: h,
                a11y: p
            }) => (0, s.jsx)(a.A, {
                type: "message",
                content: (0, s.jsx)(i, {
                    id: e,
                    name: t,
                    value: n,
                    placeholder: o,
                    onKeyPress: d,
                    onClick: r,
                    onFocus: l,
                    onChange: u,
                    onBlur: m,
                    innerRef: h,
                    a11y: p
                }),
                extra: c
            })
        },
        51917: function(e, t, n) {
            var s = n(74848),
                a = n(84362),
                i = n(93827);
            t.A = ({
                title: e,
                cost: t,
                action: n,
                onClickAction: o,
                a11y: c
            }) => {
                const r = o ? "button" : "div",
                    l = Boolean(c ? .headingLabel),
                    d = Boolean(c ? .actionLabel);
                return (0, s.jsxs)("div", {
                    className: "csms-showcase-heading",
                    children: [(0, s.jsxs)("div", {
                        className: "csms-showcase-heading__title",
                        children: [(0, s.jsx)(i.P2, {
                            weight: "bolder",
                            color: "black",
                            a11y: {
                                ariaHidden: l
                            },
                            children: e
                        }), (0, s.jsx)(a.A, {
                            children: c ? .headingLabel
                        })]
                    }), (0, s.jsxs)(r, {
                        className: "csms-showcase-heading__extra",
                        onClick: o,
                        type: "button" === r ? "button" : void 0,
                        children: [n ? (0, s.jsx)(i.P2, {
                            weight: "bolder",
                            color: "primary",
                            a11y: {
                                ariaHidden: d
                            },
                            children: n
                        }) : null, t ? (0, s.jsx)(i.P2, {
                            color: "gray-80",
                            a11y: {
                                ariaHidden: d || l
                            },
                            children: t
                        }) : null, (0, s.jsx)(a.A, {
                            children: c ? .actionLabel
                        })]
                    })]
                })
            }
        },
        58109: function(e, t, n) {
            n.d(t, {
                Ay: function() {
                    return C
                },
                Cq: function() {
                    return o
                },
                Wg: function() {
                    return x
                }
            });
            var s = n(22001),
                a = n(96540),
                i = n(57864);

            function o(e) {
                if (!/[a-z]+/i.test(e) || !/^[a-z0-9$&+,/:;=?@.\-!*'()%]+?\.[a-z0-9$&+,/:;=?@.\-!*'()%#]+?$/i.test(e)) return null;
                try {
                    var t = e;
                    t.startsWith("http") || (t = "http://".concat(t));
                    var n = new URL(t);
                    if (n && !n.username && -1 === n.host.indexOf("..") && !n.host.endsWith(".")) return n.toString()
                } catch (e) {
                    return null
                }
                return null
            }
            var c, r = {},
                l = [],
                d = [],
                u = !1,
                m = !1;

            function h(e) {
                var t = e.replace(/\*/g, "[^ ]+?").replace(/\./g, "\\.");
                return new RegExp("^(https?:\\/\\/)?".concat(t))
            }

            function p(e, t, n) {
                m = !0, new t(667, {
                    requests: [{
                        resource_type: 8,
                        reference: {
                            context: 10
                        }
                    }, {
                        resource_type: 9,
                        reference: {
                            context: 10
                        }
                    }]
                }).onResponse(668, (function(e) {
                    var t;
                    m = !1, null === (t = e.resources) || void 0 === t || t.forEach((function(e) {
                        var t, n, s = null === (t = e.payload) || void 0 === t ? void 0 : t.urls;
                        s && (9 === e.resource_type ? (n = s, u = !0, d = d.concat(n.map(h))) : 8 === e.resource_type && function(e) {
                            u = !0, l = l.concat(e.map(h))
                        }(s))
                    })), n(!0)
                })).onError((function(t) {
                    e && e.error("Failed to fetch URL configuration", t), n(!1)
                })).request()
            }

            function g() {
                return u
            }

            function f() {
                return r
            }

            function v(e, t) {
                r[e] = t
            }

            function x(e) {
                return l.some((function(t) {
                    return t.test(e)
                }))
            }

            function b(e) {
                var t = e.split(/\s/).map(o);
                if (!t) return null;
                var n = !1,
                    s = [],
                    a = [];
                return t.forEach((function(e, t) {
                    if ("string" == typeof e) {
                        var i = e.replace(/\s/g, ""),
                            o = x(i);
                        n = !0, o ? a.push({
                            url: i,
                            index: t
                        }) : s.push({
                            url: i,
                            index: t
                        })
                    }
                })), n ? {
                    cleanUrls: s,
                    badUrls: a
                } : null
            }

            function _(e) {
                return e.replace(/^https?:\/\//, "").split("/")[0]
            }

            function y(e) {
                return e.startsWith("http") ? e : "http://".concat(e)
            }
            var j = ((c = {})[s.U.IS_BLACKLISTED] = 1173, c[s.U.IS_NOT_BLACKLISTED] = 1174, c[s.U.IS_PREVIEW] = 1172, c),
                C = function(e) {
                    function t(t) {
                        var n = e.call(this, t) || this;
                        return n.state = {
                            urlToPreview: f()
                        }, n.setUrlPreview = n.setUrlPreview.bind(n), n.currentlyLoadingUrls = {}, n.urlsToLoad = [], n.trackedMessages = [], n
                    }
                    return (0, s._)(t, e), t.prototype.componentDidMount = function() {
                        this.fetchUrlConfig(), i.aV.onResponse(702, this.setUrlPreview), this.props.messageVisibilityEvent.subscribe(this.onMessageVisible, this)
                    }, t.prototype.componentWillUnmount = function() {
                        var e = this;
                        this.props.messageVisibilityEvent.unsubscribe(this.onMessageVisible, this), i.aV.offResponse(702, this.setUrlPreview), Object.keys(this.currentlyLoadingUrls).forEach((function(t) {
                            e.currentlyLoadingUrls[t].abort()
                        }))
                    }, t.prototype.onMessageVisible = function(e) {
                        var t = this.props.messages.find((function(t) {
                            return t.id === e
                        }));
                        t && t.messageType === s.C.REGULAR && this.loadUrlFromMessage(t)
                    }, t.prototype.setUrlPreview = function(e) {
                        var t = e.url_preview;
                        if (t) {
                            var n = t.url,
                                a = t.title,
                                i = t.image,
                                o = t.description;
                            if (n && (i || o)) v(n, {
                                url: y(n),
                                domain: _(n),
                                title: a,
                                image: i,
                                description: o
                            }), this.setState({
                                urlToPreview: (0, s.a)({}, f())
                            })
                        }
                    }, t.prototype.fetchUrlConfig = function() {
                        var e = this;
                        if (!g() && !m) {
                            var t = this.context;
                            p(t.Logger, t.RPC, (function(t) {
                                t && e.urlsToLoad.forEach((function(t) {
                                    return e.loadAndUpdateUrlPreview(t)
                                })), e.urlsToLoad.length = 0
                            }))
                        }
                    }, t.prototype.populateUrlsFromState = function() {
                        var e = this;
                        return this.props.messages.map((function(t) {
                            if (!t.id || !t.messageText) return t;
                            var n = b(t.messageText);
                            if (!n) return t;
                            var a = n.cleanUrls;
                            if (0 === a.length) return t;
                            var i = a[a.length - 1],
                                o = e.state.urlToPreview[i.url];
                            return o ? (0, s.a)((0, s.a)({}, t), {
                                urlInfo: o
                            }) : t
                        }))
                    }, t.prototype.loadUrlFromMessage = function(e) {
                        var t = this;
                        if (e.id && e.messageText) {
                            var n = b(e.messageText);
                            if (n) {
                                var s = n.cleanUrls,
                                    a = n.badUrls;
                                if (this.trackUrlViews(s, a, e), 0 !== s.length) {
                                    var i = s[s.length - 1];
                                    i.url in this.state.urlToPreview ? this.trackUrlPreview(i, e) : this.loadAndUpdateUrlPreview(i.url, (function() {
                                        t.trackUrlPreview(i, e)
                                    }))
                                }
                            }
                        }
                    }, t.prototype.trackUrlViews = function(e, t, n) {
                        if (!(!this.context.currentUser.id || n.id && this.trackedMessages.includes(n.id))) {
                            n.id && (this.trackedMessages = this.trackedMessages.concat(n.id));
                            var a = this.context,
                                i = a.trackEvent;
                            a.currentUser.id !== n.fromUserId && (e.forEach((function(e) {
                                var t = e.index;
                                i(258, {
                                    element: j[s.U.IS_NOT_BLACKLISTED],
                                    position: t
                                })
                            })), t.forEach((function(e) {
                                var t = e.index;
                                i(258, {
                                    element: j[s.U.IS_BLACKLISTED],
                                    position: t
                                })
                            })))
                        }
                    }, t.prototype.trackUrlPreview = function(e, t) {
                        if (this.context.currentUser.id) {
                            var n = this.context,
                                a = n.trackEvent;
                            n.currentUser.id !== t.fromUserId && a(258, {
                                element: j[s.U.IS_PREVIEW],
                                position: e.index
                            })
                        }
                    }, t.prototype.loadAndUpdateUrlPreview = function(e, t) {
                        var n = this;
                        if (!this.currentlyLoadingUrls[e])
                            if (g()) {
                                var a = this.context.RPC;
                                v(e, null), this.setState({
                                    urlToPreview: (0, s.a)({}, f())
                                }), this.currentlyLoadingUrls[e] = new a(701, {
                                    url: e
                                }).onResponse(702, (function(s) {
                                    delete n.currentlyLoadingUrls[e], n.setUrlPreview(s), t && t()
                                })), this.currentlyLoadingUrls[e].request()
                            } else this.urlsToLoad.push(e)
                    }, t.prototype.render = function() {
                        var e = this.populateUrlsFromState();
                        return this.props.children((0, s.a)((0, s.a)({}, this.props), {
                            messages: e
                        }))
                    }, t.contextType = s.M, t
                }(a.PureComponent)
        },
        59305: function(e, t, n) {
            var s = n(74848),
                a = n(93827),
                i = n(32509),
                o = n(38635);
            t.A = ({
                direction: e,
                isContinuation: t,
                extra: n,
                status: c,
                isNested: r,
                isSelectable: l,
                isSelected: d,
                onSelect: u,
                onFocus: m,
                nesting: h,
                message: p,
                onClickContent: g,
                onTouchStartContent: f,
                onTouchEndContent: v,
                onTouchMoveContent: x,
                onTouchCancelContent: b,
                innerRef: _,
                a11y: y = {}
            }) => (0, s.jsx)(o.A, {
                width: "relative",
                direction: e,
                isContinuation: t,
                extra: n,
                status: c,
                isNested: r,
                isSelectable: l,
                isSelected: d,
                onSelect: u,
                onFocus: m,
                innerRef: _,
                a11y: y,
                children: (0, s.jsx)(i.A, {
                    direction: e,
                    isContinuation: t,
                    nesting: h,
                    content: (0, s.jsx)("div", {
                        className: "csms-chat-message-content-text",
                        onClick: g,
                        onTouchStart: f,
                        onTouchEnd: v,
                        onTouchMove: x,
                        onTouchCancel: b,
                        "data-qa-message-content-type": "text",
                        children: (0, s.jsx)("div", {
                            className: "csms-chat-message-content-text__message",
                            children: (0, s.jsx)(a.P1, {
                                dangerous: !0,
                                breakWords: !0,
                                "data-qa": "chat-message-text",
                                children: p
                            })
                        })
                    })
                })
            })
        },
        60518: function(e, t, n) {
            var s = n(74848),
                a = n(84362),
                i = n(95002),
                o = n(8483);
            t.A = ({
                direction: e,
                title: t,
                description: n,
                media: c,
                onClickCancel: r,
                a11y: l
            }) => {
                const d = Boolean(l.previewLabel);
                return (0, s.jsxs)("div", {
                    className: "csms-chat-panel-preview-message",
                    children: [(0, s.jsx)(a.A, {
                        children: l.previewLabel
                    }), (0, s.jsx)("div", {
                        className: "csms-chat-panel-preview-message__main",
                        "aria-hidden": d,
                        children: (0, s.jsx)(i.A, {
                            direction: e,
                            title: t,
                            description: n,
                            media: c
                        })
                    }), (0, s.jsx)("button", {
                        className: "csms-chat-panel-preview-message__icon-button",
                        onClick: r,
                        type: "button",
                        children: (0, s.jsx)("span", {
                            className: "csms-chat-panel-preview-message__icon",
                            children: (0, s.jsx)(o.A, {
                                name: "generic-close-circle-hollow",
                                color: "gray-80",
                                a11y: {
                                    label: l.cancelLabel
                                }
                            })
                        })
                    })]
                })
            }
        },
        62498: function(e, t, n) {
            var s = n(74848),
                a = n(93827),
                i = n(99315),
                o = n(32509),
                c = n(38635);
            t.A = ({
                direction: e,
                isContinuation: t,
                extra: n,
                status: r,
                isNested: l,
                isSelectable: d,
                isSelected: u,
                onSelect: m,
                onFocus: h,
                message: p,
                preview: g,
                onTouchStartContent: f,
                onTouchEndContent: v,
                onTouchMoveContent: x,
                onTouchCancelContent: b,
                onClickPreviewImage: _,
                onClickPreviewText: y,
                innerRef: j,
                a11y: C = {}
            }) => (0, s.jsx)(c.A, {
                direction: e,
                isContinuation: t,
                extra: n,
                status: r,
                isNested: l,
                isSelectable: d,
                isSelected: u,
                onSelect: m,
                onFocus: h,
                innerRef: j,
                a11y: C,
                children: (0, s.jsxs)("div", {
                    className: "csms-chat-message-content-text-with-link",
                    onTouchStart: f,
                    onTouchEnd: v,
                    onTouchMove: x,
                    onTouchCancel: b,
                    children: [(0, s.jsx)(o.A, {
                        direction: e,
                        isContinuation: t,
                        nesting: l ? "middle" : "top",
                        content: (0, s.jsx)("div", {
                            className: "csms-chat-message-content-text",
                            "data-qa-message-content-type": "text",
                            children: (0, s.jsx)("div", {
                                className: "csms-chat-message-content-text__message",
                                children: (0, s.jsx)(a.P1, {
                                    dangerous: !0,
                                    breakWords: !0,
                                    "data-qa": "chat-message-text",
                                    children: p
                                })
                            })
                        })
                    }), (0, s.jsx)(i.A, {
                        direction: e,
                        isContinuation: t,
                        nesting: "bottom",
                        content: g.image ? (0, s.jsx)("a", {
                            className: "csms-chat-message-content-text-with-link__preview-link",
                            href: g.url,
                            target: "_blank",
                            rel: "noreferrer noopener external",
                            onClick: _,
                            children: (0, s.jsx)("div", {
                                className: "csms-chat-message-content-text-with-link__preview-image",
                                style: {
                                    backgroundImage: `url(${g.image})`
                                }
                            })
                        }) : null,
                        extra: (0, s.jsxs)("a", {
                            className: "csms-chat-message-content-text-with-link__preview-link",
                            href: g.url,
                            target: "_blank",
                            rel: "noreferrer noopener external",
                            onClick: y,
                            children: [g.title ? (0, s.jsx)("div", {
                                className: "csms-chat-message-content-text-with-link__preview-title",
                                children: (0, s.jsx)(a.P3, {
                                    weight: "bolder",
                                    children: g.title
                                })
                            }) : null, g.description ? (0, s.jsx)("div", {
                                className: "csms-chat-message-content-text-with-link__preview-description",
                                children: (0, s.jsx)(a.P3, {
                                    children: g.description
                                })
                            }) : null, (0, s.jsx)("div", {
                                className: "csms-chat-message-content-text-with-link__preview-domain",
                                children: (0, s.jsx)(a.P3, {
                                    breakWords: !0,
                                    children: g.domain
                                })
                            })]
                        })
                    })]
                })
            })
        },
        63108: function(e, t, n) {
            n.d(t, {
                E1: function() {
                    return r
                },
                MY: function() {
                    return s.b
                },
                _J: function() {
                    return s.C
                }
            });
            var s = n(22001),
                a = n(74848),
                i = n(96540),
                o = n(58544);

            function c(e) {
                var t, n = e.children,
                    s = e.components,
                    a = e.forwardProps,
                    o = s.slice();
                return function e(s) {
                    return o.length > 0 ? (t = o.shift(), (0, i.createElement)(t, s, (function(t) {
                        return e(t)
                    }))) : "function" == typeof n ? n(s) : null
                }(a)
            }
            var r = function(e) {
                function t() {
                    var t = null !== e && e.apply(this, arguments) || this;
                    return t.messageVisibilityEvent = (0, o.lh)(), t
                }
                return (0, s._)(t, e), t.prototype.componentDidMount = function() {
                    "function" == typeof this.props.onMessageVisible && this.props.onMessageVisible(this.messageVisibilityEvent.trigger)
                }, t.prototype.componentDidUpdate = function(e) {
                    "function" == typeof this.props.onMessageVisible && e.onMessageVisible !== this.props.onMessageVisible && this.props.onMessageVisible(this.messageVisibilityEvent.trigger)
                }, t.prototype.getMessagesForComponent = function() {
                    return this.props.messages.map((function(e) {
                        return {
                            id: e.id,
                            fromUserId: e.fromUserId,
                            messageText: e.messageText,
                            messageType: e.messageType || s.C.REGULAR,
                            originalMessageScaffold: e.originalMessageScaffold ? e.originalMessageScaffold : e
                        }
                    }))
                }, t.prototype.render = function() {
                    var e = this,
                        t = this.getMessagesForComponent(),
                        n = this.context.messagesListFeatures;
                    return n && 0 !== n.length ? (0, a.jsx)(c, (0, s.a)({
                        components: n,
                        forwardProps: {
                            messages: t,
                            messageVisibilityEvent: this.messageVisibilityEvent
                        }
                    }, {
                        children: function(t) {
                            var n = t.messages;
                            return e.props.children({
                                messages: n,
                                messageVisibilityEvent: e.messageVisibilityEvent
                            })
                        }
                    })) : this.props.children({
                        messages: t,
                        messageVisibilityEvent: this.messageVisibilityEvent
                    })
                }, t.contextType = s.M, t
            }(i.PureComponent)
        },
        63903: function(e, t, n) {
            var s = n(74848),
                a = n(96540),
                i = n(8483),
                o = n(56123),
                c = n(38635),
                r = n(67805);
            t.A = ({
                direction: e,
                isContinuation: t,
                extra: n,
                status: l,
                isNested: d,
                isSelectable: u,
                isSelected: m,
                onSelect: h,
                onFocus: p,
                content: g,
                isMuted: f = !0,
                percentage: v = 0,
                onTouchStartContent: x,
                onTouchEndContent: b,
                onTouchMoveContent: _,
                onTouchCancelContent: y,
                onClickContent: j,
                onClickVolume: C,
                innerRef: N,
                a11y: k = {}
            }) => (0, s.jsx)(c.A, {
                direction: e,
                isContinuation: t,
                extra: n,
                status: l,
                isNested: d,
                isSelectable: u,
                isSelected: m,
                onSelect: h,
                onFocus: p,
                innerRef: N,
                a11y: {
                    label: k.label,
                    name: k.name
                },
                children: (0, s.jsx)("div", {
                    className: "csms-chat-message-content-video",
                    onTouchStart: x,
                    onTouchEnd: b,
                    onTouchMove: _,
                    onTouchCancel: y,
                    "data-qa-message-content-type": "video",
                    children: g ? (0, s.jsxs)(a.Fragment, {
                        children: [(0, s.jsx)("div", {
                            className: "csms-chat-message-content-video__content",
                            children: g
                        }), (0, s.jsx)("div", {
                            className: "csms-chat-message-content-video__progress",
                            children: (0, s.jsx)(o.A, {
                                percentage: v,
                                color: "custom",
                                backgroundColorCustomValue: "transparent",
                                indicatorColorCustomValue: "rgba(255, 255, 255, 0.56)",
                                strokeRelativeWidth: .025,
                                rounded: !1
                            })
                        }), (0, s.jsx)("button", {
                            className: "csms-chat-message-content-video__play",
                            onClick: j,
                            "aria-label": k ? .playLabel,
                            type: "button"
                        }), (0, s.jsx)("button", {
                            className: "csms-chat-message-content-video__mute-indicator",
                            onClick: C,
                            type: "button",
                            children: (0, s.jsx)(i.A, {
                                name: f ? "generic-volume-mute" : "generic-volume-on",
                                color: "white",
                                a11y: {
                                    label: k ? .volumeLabel
                                }
                            })
                        })]
                    }) : (0, s.jsx)(r.A, {
                        background: "transparent"
                    })
                })
            })
        },
        64537: function(e, t, n) {
            var s = n(74848),
                a = n(46942),
                i = n.n(a);
            t.A = ({
                children: e,
                shadow: t
            }) => {
                const n = i()({
                    "csms-chat-controls": !0,
                    "csms-chat-controls--shadow": t
                });
                return (0, s.jsx)("div", {
                    className: n,
                    children: e
                })
            }
        },
        65507: function(e, t, n) {
            var s = n(74848),
                a = n(46942),
                i = n.n(a),
                o = n(32483),
                c = n(93827);
            t.A = ({
                title: e,
                media: t,
                mediaSize: n = "icon",
                text: a,
                action: r,
                hint: l,
                background: d = "default",
                dataQA: u
            }) => {
                const m = i()({
                        "csms-nudge": !0,
                        [`csms-nudge--${d}`]: d,
                        "csms-nudge--media-stretch": "stretch" === n
                    }),
                    h = i()({
                        "csms-nudge__media": !0,
                        [`csms-nudge__media--${n}`]: n
                    }),
                    p = {
                        "data-qa": "nudge",
                        ...u
                    };
                return (0, s.jsxs)("div", {
                    className: m,
                    ...p,
                    children: [(0, s.jsxs)("div", {
                        className: "csms-nudge__header",
                        children: [t ? (0, s.jsx)("div", {
                            className: h,
                            "data-qa": "nudge-media",
                            children: t
                        }) : null, (0, s.jsx)(c.Qi, {
                            breakWords: !0,
                            className: "csms-nudge__title",
                            dataQA: {
                                "data-qa": "nudge-title"
                            },
                            children: e
                        })]
                    }), a ? (0, s.jsx)(c.Qi, {
                        className: "csms-nudge__text",
                        breakWords: !0,
                        dataQA: {
                            "data-qa": "nudge-text"
                        },
                        children: a
                    }) : null, r ? (0, s.jsx)("div", {
                        className: "csms-nudge__action",
                        "data-qa": "nudge-action",
                        children: r
                    }) : null, l ? (0, s.jsx)("div", {
                        className: "csms-nudge__hint",
                        "data-qa": "nudge-hint",
                        children: (0, s.jsx)(o.A, {
                            children: l
                        })
                    }) : null]
                })
            }
        },
        67805: function(e, t, n) {
            var s = n(74848),
                a = n(46942),
                i = n.n(a),
                o = n(33815);
            t.A = ({
                background: e = "gray-10"
            }) => {
                const t = i()({
                    "csms-chat-message-loader": !0,
                    [`csms-chat-message-loader--${e}`]: !0
                });
                return (0, s.jsx)("div", {
                    className: t,
                    "data-qa": "chat-message-loader",
                    children: (0, s.jsx)("div", {
                        className: "csms-chat-message-loader__loader-wrapper",
                        children: (0, s.jsx)(o.A, {})
                    })
                })
            }
        },
        68438: function(e, t, n) {
            var s = n(74848),
                a = n(38635);
            t.A = ({
                direction: e,
                isContinuation: t,
                extra: n,
                status: i,
                isNested: o,
                isSelectable: c,
                isSelected: r,
                onSelect: l,
                onFocus: d,
                message: u,
                onTouchStartContent: m,
                onTouchEndContent: h,
                onTouchMoveContent: p,
                onTouchCancelContent: g,
                innerRef: f,
                a11y: v = {}
            }) => (0, s.jsx)(a.A, {
                direction: e,
                isContinuation: t,
                extra: n,
                status: i,
                isNested: o,
                isSelectable: c,
                isSelected: r,
                onSelect: l,
                onFocus: d,
                innerRef: f,
                a11y: v,
                children: (0, s.jsx)("div", {
                    className: "csms-chat-message-content-emoji",
                    onTouchStart: m,
                    onTouchEnd: h,
                    onTouchMove: p,
                    onTouchCancel: g,
                    "data-qa-message-content-type": "emoji",
                    children: u
                })
            })
        },
        70870: function(e, t, n) {
            var s = n(74848),
                a = n(46942),
                i = n.n(a);
            t.A = ({
                type: e,
                content: t,
                extra: n
            }) => {
                const a = i()({
                    "csms-chat-composer-input-wrapper": !0,
                    [`csms-chat-composer-input-wrapper--${e}`]: !0
                });
                return (0, s.jsxs)("div", {
                    className: a,
                    children: [(0, s.jsx)("div", {
                        className: "csms-chat-composer-input-wrapper__content",
                        children: t
                    }), n ? (0, s.jsx)("div", {
                        className: "csms-chat-composer-input-wrapper__extra",
                        children: n
                    }) : null, (0, s.jsx)("div", {
                        className: "csms-chat-composer-input-wrapper__focus-ring"
                    })]
                })
            }
        },
        72324: function(e, t, n) {
            var s = n(74848);
            t.A = ({
                children: e
            }) => (0, s.jsx)("div", {
                className: "csms-chat-composer-frame__content",
                children: e
            })
        },
        73033: function(e, t, n) {
            n.d(t, {
                Yz: function() {
                    return j
                },
                en: function() {
                    return A
                },
                lN: function() {
                    return m
                },
                oh: function() {
                    return _
                },
                y8: function() {
                    return u
                }
            });
            var s, a, i = n(22001),
                o = n(96540),
                c = n(58544),
                r = n(74848),
                l = n(82513),
                d = (0, c.lh)(),
                u = {
                    subscribe: function(e, t) {
                        d.subscribe(e, t)
                    },
                    unsubscribe: function(e, t) {
                        d.unsubscribe(e, t)
                    },
                    notifyMediaPlaying: function(e) {
                        d.trigger(e), s = e
                    },
                    stopMediaPlaying: function(e) {
                        e && e !== s || d.trigger(null)
                    }
                },
                m = function(e) {
                    function t(t) {
                        var n = e.call(this, t) || this;
                        return n.handleTimeUpdate = function() {
                            n.setState({
                                playback: 0 === n.audioRef.currentTime ? "paused" : "playing",
                                percentage: Math.floor(n.audioRef.currentTime / n.props.duration * 100),
                                time: h(n.props.duration - n.audioRef.currentTime)
                            })
                        }, n.handlePausePlayback = function() {
                            n.setState({
                                playback: "paused"
                            })
                        }, n.handleEndPlayback = function() {
                            n.audioRef.currentTime = 0, n.setState({
                                playback: "paused",
                                time: h(n.props.duration)
                            })
                        }, n.handleClickContent = function(e) {
                            n.props.onClickContent && n.props.onClickContent(e), n.audioRef.paused ? (n.setState({
                                playback: "loading"
                            }), n.playAudio()) : n.pauseAudio()
                        }, n.state = {
                            percentage: 0,
                            time: h(t.duration || 0),
                            playback: "paused"
                        }, n.audioRef = new Audio, n
                    }
                    return (0, i._)(t, e), t.prototype.componentDidMount = function() {
                        this.audioRef.preload = this.getPreloadValue(), this.audioRef.loop = !1, this.audioRef.volume = 1, this.audioRef.muted = !1, this.audioRef.addEventListener("timeupdate", this.handleTimeUpdate), this.audioRef.addEventListener("pause", this.handlePausePlayback), this.audioRef.addEventListener("ended", this.handleEndPlayback), u.subscribe(this.handleMediaPlayback, this), this.props.onAudioRef && this.props.onAudioRef(this.audioRef), this.audioRef.src = this.props.src
                    }, t.prototype.componentWillUnmount = function() {
                        this.audioRef.removeEventListener("timeupdate", this.handleTimeUpdate), this.audioRef.removeEventListener("pause", this.handlePausePlayback), this.audioRef.removeEventListener("ended", this.handleEndPlayback), u.unsubscribe(this.handleMediaPlayback, this), this.pauseAudio()
                    }, t.prototype.handleMediaPlayback = function(e) {
                        e !== this.props.id && this.pauseAudio()
                    }, t.prototype.playAudio = function() {
                        var e = this;
                        u.notifyMediaPlaying(this.props.id), this.audioRef.play().catch((function(t) {
                            e.props.onPlayError && (e.setState({
                                playback: "paused"
                            }), e.props.onPlayError(t))
                        }))
                    }, t.prototype.pauseAudio = function() {
                        var e = this;
                        this.audioRef.paused || (this.audioRef.muted = !0, this.audioRef.play().then((function() {
                            e.audioRef.pause(), e.audioRef.muted = !1
                        })))
                    }, t.prototype.getPreloadValue = function() {
                        return this.props.shouldPreload ? "auto" : "metadata"
                    }, t.prototype.render = function() {
                        return this.props.children({
                            percentage: this.state.percentage,
                            playback: this.state.playback,
                            time: this.state.time,
                            onClickContent: this.handleClickContent
                        })
                    }, t
                }(o.Component);

            function h(e) {
                var t = [],
                    n = Math.floor(e / 60),
                    s = Math.floor(n / 60);
                return s > 0 && t.push(s), t.push(n % 60), t.push(Math.floor(e % 60)), t.map(p).join(":")
            }

            function p(e) {
                return (e < 10 ? "0" : "") + e
            }

            function g(e) {
                return (t = e.apiKey, n = e.nonce, a || (a = new Promise((function(e, s) {
                    var a = document.createElement("script");
                    a.onload = function() {
                        return e()
                    }, a.onerror = function(e) {
                        return s(e)
                    }, a.src = "https://maps.googleapis.com/maps/api/js?key=".concat(t), a.async = !0, a.defer = !0, n && a.setAttribute("nonce", n), document.body.appendChild(a)
                })))).then((function() {
                    if (!(e.mapContainer instanceof Element)) throw new TypeError("mapContainer must be an element");
                    return new window.google.maps.Map(e.mapContainer, (0, i.a)({}, e.mapOptions))
                }));
                var t, n
            }
            var f = "OK",
                v = "OVER_QUERY_LIMIT";

            function x(e) {
                return "latlng-".concat(e.lat, "-").concat(e.lng)
            }
            var b = new(function() {
                function e() {
                    this.queue = [], this.currentRequest = null, this.cachedResults = {}, this.triggerNextRequest = (0, l.throttle)(this._triggerNextRequest, e.THROTTLE_REQUEST_TIME, this)
                }
                return e.prototype.addRequest = function(e) {
                    if (e) {
                        var t = x(e.latLng),
                            n = this.cachedResults[t];
                        n ? e.handler(n.results, n.status) : (this.queue.unshift(e), this.triggerNextRequest())
                    }
                }, e.prototype._triggerNextRequest = function() {
                    var t, n, s = this;
                    this.currentRequest || (this.currentRequest = this.queue.shift() || null, this.currentRequest && (t = this.currentRequest.latLng, n = function(t, n) {
                        var a = s.currentRequest;
                        if (s.currentRequest = null, a.retries || (a.retries = 0), n === v && a.retries < e.MAX_RETRIES) return a.retries++, void setTimeout((function() {
                            s.addRequest(a)
                        }), e.RETRY_TIMEOUT);
                        s.cacheResults(a, {
                            results: t,
                            status: n
                        }), a.handler(t, n), s.triggerNextRequest()
                    }, (new window.google.maps.Geocoder).geocode({
                        location: t
                    }, n)))
                }, e.prototype.cacheResults = function(e, t) {
                    var n = x(e.latLng);
                    this.cachedResults[n] = t
                }, e.MAX_RETRIES = 5, e.RETRY_TIMEOUT = 2e3, e.THROTTLE_REQUEST_TIME = 333, e
            }());
            var _, y = {
                clickableIcons: !1,
                disableDefaultUI: !0,
                fullscreenControl: !1,
                zoom: 15
            };
            ! function(e) {
                e.FIXED = "fixed", e.FIXED_LIVE = "fixed_live", e.INTERACTIVE = "interactive", e.INTERACTIVE_LIVE = "interactive_live"
            }(_ || (_ = {}));
            var j = function(e) {
                function t(t) {
                    var n = e.call(this, t) || this;
                    return n.centerMapOnUpdate = !1, n.eventsListeners = [], n.initMap = function(e) {
                        var t, s = n.context.Logger;
                        n.map = e, n.props.getAddressDetails && (t = N(n.props.coordinates), function(e) {
                            return new Promise((function(t, n) {
                                b.addRequest({
                                    latLng: e,
                                    handler: function(e, s) {
                                        s === f ? e && e[0] ? t(e) : n(new Error("Error: Geocoder found no results")) : n(new Error("Error: Geocoder failed due to: ".concat(s)))
                                    }
                                })
                            }))
                        }(t).then((function(e) {
                            return function(e) {
                                var t = e[0],
                                    n = {};
                                return t ? (n.title = function(e) {
                                    var t = k(e.address_components, "route");
                                    return t || (t = k(e.address_components, "locality")), null == t ? void 0 : t.long_name
                                }(t), n.note = t.formatted_address, n) : n
                            }(e)
                        }))).then((function(e) {
                            n.setState({
                                addressDetails: e
                            })
                        })).catch((function(e) {
                            s && s.error(e, {
                                coordinates: n.props.coordinates
                            })
                        })), n.isInteractiveMap() && n.addCenterMapControl(), n.addMarkerToMap(), n.setState({
                            isLoading: !1
                        })
                    }, n.centerMap = function() {
                        var e;
                        null === (e = n.map) || void 0 === e || e.setCenter(N(n.props.coordinates))
                    }, n.toggleCenterMapCta = function() {
                        n.map && n.props.centerMapCta && (n.props.centerMapCta.style.display = n.isMapCentered() ? "none" : "block")
                    }, n.state = {
                        isLoading: !0
                    }, n.mapRef = (0, o.createRef)(), n
                }
                return (0, i._)(t, e), t.prototype.componentDidMount = function() {
                    if (!this.context.Location) throw new Error("Location is not set in Context");
                    g({
                        apiKey: this.context.Location.GoogleMapsApiKey,
                        mapContainer: this.mapRef.current,
                        mapOptions: this.getMapOptions(),
                        nonce: this.context.Location.nonce
                    }).then(this.initMap)
                }, t.prototype.componentDidUpdate = function(e) {
                    if (e.customMarker && !this.props.customMarker && this.updateMarker(), this.isInteractiveLiveMap() && this.map) {
                        var t = new window.google.maps.LatLng(e.coordinates.latitude, e.coordinates.longitude);
                        this.centerMapOnUpdate = t.equals(this.map.getCenter() || null)
                    }
                }, t.prototype.componentWillUnmount = function() {
                    this.eventsListeners.forEach((function(e) {
                        return e.remove()
                    }))
                }, t.prototype.updateMarker = function() {
                    this.marker && (this.marker.setMap(null), this.marker = void 0), this.customMarker && (this.customMarker.setMap(null), this.customMarker = void 0), this.addMarkerToMap()
                }, t.prototype.addMarkerToMap = function() {
                    var e = this;
                    if (this.map) {
                        var t = this.props,
                            s = t.coordinates,
                            a = t.markerOptions,
                            o = t.customMarker,
                            c = t.onClickMarker;
                        if (o) n.e(5605).then(n.bind(n, 85605)).then((function(t) {
                            var n = t.default;
                            e.customMarker = new n(o, e.props.coordinates, e.map)
                        }));
                        else {
                            var r = function(e, t) {
                                void 0 === t && (t = {});
                                var n = {
                                        position: N(e)
                                    },
                                    s = t.url,
                                    a = t.size;
                                if (s) {
                                    var i = {
                                        url: s
                                    };
                                    a && (i.size = new window.google.maps.Size(a.width, a.height)), n.icon = i
                                }
                                return n
                            }(s, a);
                            r && (this.marker = new window.google.maps.Marker((0, i.a)((0, i.a)({}, r), {
                                map: this.map
                            })), c && this.eventsListeners.push(this.marker.addListener("click", c)))
                        }
                    }
                }, t.prototype.addCenterMapControl = function() {
                    this.map && this.isInteractiveMap() && this.props.centerMapCta && (this.eventsListeners.push(this.map.addListener("center_changed", this.toggleCenterMapCta)), this.props.centerMapCta.style.zIndex = "1", this.props.centerMapCta.style.display = this.isMapCentered() ? "none" : "block", this.props.centerMapCta.addEventListener("click", this.centerMap), this.map.controls[window.google.maps.ControlPosition.TOP_RIGHT].push(this.props.centerMapCta))
                }, t.prototype.isMapCentered = function() {
                    return !!this.map && new window.google.maps.LatLng(this.props.coordinates.latitude, this.props.coordinates.longitude).equals(this.map.getCenter() || null)
                }, t.prototype.isInteractiveMap = function() {
                    return this.props.type === _.INTERACTIVE || this.props.type === _.INTERACTIVE_LIVE
                }, t.prototype.isFixedLiveMap = function() {
                    return this.props.type === _.FIXED_LIVE
                }, t.prototype.isInteractiveLiveMap = function() {
                    return this.props.type === _.INTERACTIVE_LIVE
                }, t.prototype.isLiveMap = function() {
                    return this.props.type === _.FIXED_LIVE || this.props.type === _.INTERACTIVE_LIVE
                }, t.prototype.getMapOptions = function() {
                    return this.isInteractiveMap() ? function(e, t) {
                        void 0 === t && (t = {});
                        return C(e, (0, i.a)({
                            gestureHandling: "auto",
                            zoomControl: !1
                        }, t))
                    }(this.props.coordinates) : function(e, t) {
                        void 0 === t && (t = {});
                        return C(e, (0, i.a)({
                            gestureHandling: "none",
                            zoomControl: !1
                        }, t))
                    }(this.props.coordinates)
                }, t.prototype.updateMap = function() {
                    var e;
                    this.isFixedLiveMap() && !this.isMapCentered() ? this.centerMap() : this.isInteractiveLiveMap() && this.centerMapOnUpdate && (this.centerMapOnUpdate = !1, this.centerMap()), null === (e = this.customMarker) || void 0 === e || e.setCoordinates(this.props.coordinates)
                }, t.prototype.getMapComponent = function() {
                    return (0, r.jsx)("map", {
                        className: this.props.mapClassName,
                        ref: this.mapRef
                    })
                }, t.prototype.render = function() {
                    return this.isLiveMap() && this.updateMap(), this.props.children({
                        mapElement: this.getMapComponent(),
                        isLoading: this.state.isLoading,
                        details: this.state.addressDetails
                    })
                }, t.contextType = i.M, t
            }(o.Component);

            function C(e, t) {
                void 0 === t && (t = {});
                var n = (0, i.a)((0, i.a)({}, y), t);
                return e && (n.center = N(e)), n
            }

            function N(e) {
                return {
                    lat: e.latitude,
                    lng: e.longitude
                }
            }

            function k(e, t) {
                return null == e ? void 0 : e.find((function(e) {
                    var n;
                    return null === (n = e.types) || void 0 === n ? void 0 : n.includes(t)
                }))
            }
            var A = function(e) {
                function t(t) {
                    var n = e.call(this, t) || this;
                    return n.handleLoadedMetadata = function() {
                        var e = n.videoRef.current;
                        e && e.videoHeight > e.videoWidth && n.setState({
                            isPortrait: !0
                        })
                    }, n.handleTimeUpdate = function() {
                        var e = n.videoRef.current;
                        e && n.setState({
                            percentage: Math.floor(e.currentTime / e.duration * 100)
                        })
                    }, n.handleEndPlayback = function() {
                        var e = n.videoRef.current;
                        e && (e.currentTime = 0, e.muted = !0, n.setState({
                            isMuted: !0
                        }))
                    }, n.handleClickContent = function(e) {
                        e && (e.preventDefault(), e.stopPropagation());
                        var t = n.videoRef.current;
                        n.props.onClickContent && n.props.onClickContent(e), t && (t.paused ? (t.muted && (t.muted = !1, n.setState({
                            isMuted: !1
                        })), n.playVideo()) : n.pauseVideo())
                    }, n.handleClickVolume = function(e) {
                        e && (e.preventDefault(), e.stopPropagation());
                        var t = n.videoRef.current;
                        n.props.onClickVolume && n.props.onClickVolume(e), t && (t.muted = !t.muted, n.setState({
                            isMuted: t.muted
                        }), t.paused && n.playVideo())
                    }, n.state = {
                        isMuted: !0,
                        isPortrait: !1,
                        percentage: 0
                    }, n.videoRef = (0, o.createRef)(), n
                }
                return (0, i._)(t, e), t.prototype.componentDidMount = function() {
                    var e = this.videoRef.current;
                    e && (this.props.onVideoRef && this.props.onVideoRef(e), e.volume = 1, e.addEventListener("loadedmetadata", this.handleLoadedMetadata), e.addEventListener("timeupdate", this.handleTimeUpdate), e.addEventListener("ended", this.handleEndPlayback), u.subscribe(this.handleMediaPlayback, this))
                }, t.prototype.componentWillUnmount = function() {
                    var e = this.videoRef.current;
                    e && (e.removeEventListener("loadedmetadata", this.handleLoadedMetadata), e.removeEventListener("timeupdate", this.handleTimeUpdate), e.removeEventListener("ended", this.handleEndPlayback), u.unsubscribe(this.handleMediaPlayback, this), e.muted = !0, this.pauseVideo())
                }, t.prototype.handleMediaPlayback = function(e) {
                    e !== this.props.id && this.pauseVideo()
                }, t.prototype.playVideo = function() {
                    var e = this;
                    u.notifyMediaPlaying(this.props.id);
                    var t = this.videoRef.current;
                    t && t.play().catch((function(t) {
                        e.props.onPlayError && e.props.onPlayError(t)
                    }))
                }, t.prototype.pauseVideo = function() {
                    var e = this.videoRef.current;
                    e && !e.paused && e.play().then((function() {
                        e.pause()
                    }))
                }, t.prototype.getPreloadValue = function() {
                    return this.props.shouldPreload ? "auto" : "metadata"
                }, t.prototype.getVideoComponent = function() {
                    var e = this.props,
                        t = e.src,
                        n = e.poster;
                    return (0, r.jsx)("video", {
                        ref: this.videoRef,
                        src: t,
                        poster: n,
                        muted: this.state.isMuted,
                        loop: !1,
                        preload: this.getPreloadValue(),
                        playsInline: !0
                    })
                }, t.prototype.render = function() {
                    return this.props.children({
                        videoElement: this.getVideoComponent(),
                        mute: this.state.isMuted,
                        percentage: this.state.percentage,
                        isPortrait: this.state.isPortrait,
                        onClickContent: this.handleClickContent,
                        onClickVolume: this.handleClickVolume
                    })
                }, t
            }(o.Component)
        },
        73920: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return r
                }
            });
            var s = n(74848),
                a = n(46942),
                i = n.n(a),
                o = n(8483);
            var c = ({
                variant: e = "default",
                a11y: t
            }) => {
                const n = i()({
                    "csms-gift-wrap": !0,
                    [`csms-gift-wrap--variant-${e}`]: e
                });
                return (0, s.jsx)("span", {
                    className: n,
                    children: (0, s.jsx)(o.A, {
                        name: "generic-gift-wrap",
                        a11y: {
                            label: t ? .label
                        }
                    })
                })
            };
            var r = ({
                src: e,
                onClick: t,
                innerRef: n,
                a11y: a
            }) => {
                const i = t ? "button" : "span";
                return (0, s.jsx)(i, {
                    className: "csms-gift",
                    onClick: t,
                    "data-qa": "gift",
                    ref: n,
                    type: "button" === i ? "button" : void 0,
                    children: e ? (0, s.jsx)("img", {
                        className: "csms-gift__image",
                        src: e,
                        "data-qa": "gift-img",
                        alt: a ? .label || ""
                    }) : (0, s.jsx)("span", {
                        className: "csms-gift__loader",
                        children: (0, s.jsx)(c, {
                            a11y: a
                        })
                    })
                })
            }
        },
        73939: function(e, t, n) {
            var s = n(74848),
                a = n(46942),
                i = n.n(a),
                o = n(8483),
                c = n(93827);
            t.A = ({
                icon: e,
                text: t,
                color: n = "dark",
                onClick: a
            }) => {
                const r = i()({
                        "csms-snackpill": !0,
                        [`csms-snackpill--${n}`]: n
                    }),
                    l = a ? "button" : "div";
                return (0, s.jsxs)(l, {
                    className: r,
                    onClick: a,
                    type: "button" === l ? "button" : void 0,
                    children: [e ? (0, s.jsx)("span", {
                        className: "csms-snackpill__icon",
                        children: (0, s.jsx)(o.A, {
                            name: e
                        })
                    }) : null, (0, s.jsx)(c.P2, {
                        children: t
                    })]
                })
            }
        },
        74785: function(e, t, n) {
            var s = n(74848),
                a = n(93827),
                i = n(99315),
                o = n(38635);
            t.A = ({
                direction: e,
                isContinuation: t,
                status: n,
                notice: c,
                message: r,
                meta: l,
                actions: d,
                innerRef: u,
                a11y: m = {}
            }) => (0, s.jsx)(o.A, {
                direction: e,
                isContinuation: t,
                status: n,
                innerRef: u,
                a11y: m,
                children: (0, s.jsx)("div", {
                    className: "csms-chat-message-content-notification",
                    "data-qa-message-content-type": "notification",
                    children: (0, s.jsx)(i.A, {
                        direction: e,
                        isContinuation: t,
                        content: (0, s.jsxs)("div", {
                            className: "csms-chat-message-content-notification__content",
                            children: [c ? (0, s.jsx)("div", {
                                className: "csms-chat-message-content-notification__notice",
                                "data-qa": "message-notification-notice",
                                children: (0, s.jsx)(a.P1, {
                                    dangerous: !0,
                                    children: c
                                })
                            }) : null, r ? (0, s.jsx)("div", {
                                className: "csms-chat-message-content-notification__message",
                                "data-qa": "message-notification-message",
                                children: (0, s.jsx)(a.P1, {
                                    dangerous: !0,
                                    breakWords: !0,
                                    children: r
                                })
                            }) : null, l ? (0, s.jsx)("div", {
                                className: "csms-chat-message-content-notification__meta",
                                "data-qa": "message-notification-meta",
                                children: (0, s.jsx)(a.P2, {
                                    children: l
                                })
                            }) : null]
                        }),
                        actions: d
                    })
                })
            })
        },
        75308: function(e, t, n) {
            var s = n(74848),
                a = n(73920),
                i = n(93827),
                o = n(99315),
                c = n(38635);
            t.A = ({
                direction: e,
                isContinuation: t,
                extra: n,
                status: r,
                isNested: l,
                isSelectable: d,
                isSelected: u,
                onSelect: m,
                onFocus: h,
                nesting: p,
                image: g,
                message: f,
                actions: v,
                innerRef: x,
                onClickContent: b,
                onTouchStartContent: _,
                onTouchEndContent: y,
                onTouchMoveContent: j,
                onTouchCancelContent: C,
                a11y: N = {}
            }) => (0, s.jsx)(c.A, {
                direction: e,
                isContinuation: t,
                extra: n,
                status: r,
                isNested: l,
                isSelectable: d,
                isSelected: u,
                onSelect: m,
                onFocus: h,
                innerRef: x,
                a11y: {
                    label: N.label,
                    name: N.name
                },
                children: (0, s.jsx)("div", {
                    className: "csms-chat-message-content-gift",
                    children: (0, s.jsx)(o.A, {
                        direction: e,
                        isContinuation: t,
                        nesting: p,
                        content: (0, s.jsxs)("button", {
                            className: "csms-chat-message-content-gift__content",
                            onClick: b,
                            onTouchStart: _,
                            onTouchEnd: y,
                            onTouchMove: j,
                            onTouchCancel: C,
                            "data-qa-message-content-type": "gift",
                            "aria-label": N ? .contentLabel,
                            type: "button",
                            children: [(0, s.jsx)("span", {
                                className: "csms-chat-message-content-gift__image",
                                children: (0, s.jsx)(a.A, {
                                    src: g ? .src
                                })
                            }), (0, s.jsx)("span", {
                                className: "csms-chat-message-content-gift__message",
                                "data-qa": "message-gift-message",
                                children: (0, s.jsx)(i.P1, {
                                    align: "center",
                                    color: "black",
                                    breakWords: !0,
                                    children: f
                                })
                            })]
                        }),
                        actions: v
                    })
                })
            })
        },
        77650: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return l
                }
            });
            var s = n(74848),
                a = n(46942),
                i = n.n(a),
                o = n(8483),
                c = n(33815);
            var r = ({
                src: e,
                format: t = "image",
                onClick: n,
                innerVideoRef: a,
                a11y: o
            }) => {
                const r = i()({
                        "csms-sticker__content": !0,
                        "csms-sticker__content--invisible": !e
                    }),
                    l = i()({
                        "csms-sticker__loader": !0,
                        "csms-sticker__loader--invisible": e
                    });
                return (0, s.jsxs)("div", {
                    className: "csms-sticker",
                    "data-qa": "sticker",
                    children: [(0, s.jsx)("div", {
                        className: l,
                        children: (0, s.jsx)(c.A, {})
                    }), "video" === t ? (0, s.jsx)("video", {
                        className: r,
                        src: e,
                        muted: !0,
                        loop: !0,
                        autoPlay: !0,
                        playsInline: !0,
                        ref: a,
                        "data-qa": "sticker-video",
                        "aria-hidden": !0,
                        tabIndex: -1,
                        "aria-label": n ? void 0 : o ? .label
                    }) : (0, s.jsx)("img", {
                        className: r,
                        src: e,
                        alt: n ? "" : o ? .label,
                        "data-qa": "sticker-img"
                    }), n ? (0, s.jsx)("button", {
                        className: "csms-sticker__action",
                        "aria-label": o ? .label,
                        onClick: n,
                        "data-qa": "sticker-action",
                        type: "button"
                    }) : null]
                })
            };
            var l = ({
                icon: e,
                sticker: t,
                isActive: n,
                onClick: a,
                elementRef: c,
                a11y: l
            }) => {
                const d = i()({
                    "csms-chat-panel-pills__item": !0,
                    "csms-chat-panel-pills__item--is-active": n
                });
                return (0, s.jsxs)("button", {
                    className: d,
                    onClick: a,
                    ref: c,
                    role: "tab",
                    tabIndex: n ? 0 : -1,
                    "aria-selected": n,
                    "aria-label": l ? .label,
                    type: "button",
                    children: [e ? (0, s.jsx)("span", {
                        className: "csms-chat-panel-pills__item-media",
                        children: (0, s.jsx)(o.A, {
                            name: e.name,
                            color: e.color
                        })
                    }) : null, t ? (0, s.jsx)("span", {
                        className: "csms-chat-panel-pills__item-media",
                        children: (0, s.jsx)(r, {
                            src: t.src
                        })
                    }) : null]
                })
            }
        },
        79760: function(e, t, n) {
            var s = n(74848),
                a = n(84362),
                i = n(8483),
                o = n(93827);
            t.A = ({
                children: e,
                extra: t,
                onClick: n,
                a11y: c
            }) => {
                const r = Boolean(c ? .label),
                    l = n ? "button" : "div";
                return (0, s.jsxs)(l, {
                    className: "csms-showcase-item",
                    onClick: n,
                    type: "button" === l ? "button" : void 0,
                    children: [(0, s.jsx)("span", {
                        className: "csms-showcase-item__content",
                        "aria-hidden": r,
                        children: (0, s.jsx)("span", {
                            className: "csms-showcase-item__content-inner",
                            children: e
                        })
                    }), t ? (0, s.jsxs)("span", {
                        className: "csms-showcase-item__extra",
                        "aria-hidden": r,
                        children: [t.icon ? (0, s.jsx)("span", {
                            className: "csms-showcase-item__extra-icon",
                            children: (0, s.jsx)(i.A, {
                                name: t.icon
                            })
                        }) : null, t.text ? (0, s.jsx)("span", {
                            className: "csms-showcase-item__extra-text",
                            children: (0, s.jsx)(o.P3, {
                                children: t.text
                            })
                        }) : null]
                    }) : null, (0, s.jsx)(a.A, {
                        children: c ? .label
                    })]
                })
            }
        },
        80871: function(e, t, n) {
            var s = n(74848),
                a = n(96540),
                i = n(33815),
                o = n(18707),
                c = n(93827);
            t.A = ({
                results: e,
                noResultsText: t,
                isLoading: n = !0,
                onScroll: r
            }) => {
                let l;
                return l = e && e.length > 0 ? (0, s.jsx)(o.A, {
                    spacing: "md",
                    onScroll: r,
                    children: e.map((e => (0, s.jsx)("button", {
                        className: "csms-chat-panel-search-results__button",
                        onClick: e.onClick,
                        type: "button",
                        children: (0, s.jsx)("img", {
                            className: "csms-chat-panel-search-results__image",
                            src: e.src,
                            "data-qa": "gif-container-preview",
                            alt: e.a11y ? .label
                        })
                    }, e.key)))
                }) : (0, s.jsx)("div", {
                    className: "csms-chat-panel-search-results__no-results",
                    "data-qa": "gif-container-no-results",
                    children: (0, s.jsx)(c.P1, {
                        children: t
                    })
                }), (0, s.jsx)("div", {
                    className: "csms-chat-panel-search-results",
                    children: n ? (0, s.jsx)("div", {
                        className: "csms-chat-panel-search-results__loading-placeholder",
                        "data-qa": "gif-container-loading",
                        children: (0, s.jsx)("div", {
                            className: "csms-chat-panel-search-results__loader-wrapper",
                            children: (0, s.jsx)(i.A, {})
                        })
                    }) : (0, s.jsx)(a.Fragment, {
                        children: l
                    })
                })
            }
        },
        84084: function(e, t, n) {
            var s = n(74848),
                a = n(96540),
                i = n(46942),
                o = n.n(i),
                c = n(32509),
                r = n(38635),
                l = n(95002);
            t.A = ({
                direction: e,
                isContinuation: t,
                extra: n,
                status: i,
                isSelectable: d,
                isSelected: u,
                onSelect: m,
                onFocus: h,
                header: p,
                message: g,
                onTouchStartContent: f,
                onTouchEndContent: v,
                onTouchMoveContent: x,
                onTouchCancelContent: b,
                innerRef: _,
                a11y: y = {}
            }) => {
                let j, C, N;
                g && (j = a.Children.map(g, (n => (0, a.cloneElement)(n, {
                    direction: e,
                    isContinuation: t,
                    isNested: !0,
                    nesting: "bottom"
                }))), 1 === a.Children.count(g) && (C = g.type.displayName || g.type.name)), "ChatMessageEmoji" !== C && "ChatMessageSticker" !== C && "ChatMessageVideoTelescope" !== C || (N = !0);
                const k = o()({
                    "csms-chat-message-content-reply": !0,
                    [`csms-chat-message-content-reply--${e}`]: e,
                    [`csms-chat-message-content-reply--with-${C?.replace(/^ChatMessage/,"").replace(/([a-z])([A-Z])/g,"$1-$2").toLowerCase()}`]: C
                });
                return (0, s.jsx)(r.A, {
                    direction: e,
                    isContinuation: t,
                    extra: n,
                    status: i,
                    isSelectable: d,
                    isSelected: u,
                    onSelect: m,
                    onFocus: h,
                    innerRef: _,
                    a11y: y,
                    children: (0, s.jsxs)("div", {
                        className: k,
                        onTouchStart: f,
                        onTouchEnd: v,
                        onTouchMove: x,
                        onTouchCancel: b,
                        "data-qa-message-content-type": "reply",
                        children: [(0, s.jsx)("div", {
                            className: "csms-chat-message-content-reply__header",
                            children: (0, s.jsx)(c.A, {
                                direction: e,
                                isContinuation: t,
                                nesting: "top",
                                content: (0, s.jsx)(l.A, {
                                    direction: e,
                                    title: p.title,
                                    description: p.description,
                                    media: p.media
                                })
                            })
                        }), (0, s.jsx)("div", {
                            className: "csms-chat-message-content-reply__message-container",
                            children: N ? (0, s.jsx)(c.A, {
                                direction: e,
                                isContinuation: t,
                                nesting: "bottom",
                                content: j
                            }) : j
                        })]
                    })
                })
            }
        },
        85001: function(e, t, n) {
            var s = n(74848),
                a = n(96540),
                i = n(46942),
                o = n.n(i),
                c = n(26914),
                r = n(33815),
                l = n(94767),
                d = n(45998),
                u = n(87019),
                m = n(93827);
            t.A = ({
                image: e,
                icon: t,
                user: n,
                badge: i,
                mediaOverlay: h,
                title: p,
                message: g,
                action: f,
                isProcessing: v,
                isDisabled: x,
                onClick: b,
                innerRef: _,
                isAddedHACK: y
            }) => {
                const j = o()({
                    "csms-connections-item": !0,
                    "csms-connections-item--promo": !0,
                    "csms-connections-item--disabled": x,
                    "js-mw-connections-item": !0,
                    "mw-connections-item--is-added-hack": y
                });
                let C;
                return (v || h) && (C = {
                    children: (0, s.jsxs)(a.Fragment, {
                        children: [v ? (0, s.jsx)("span", {
                            className: "csms-connections-item__loader-wrapper",
                            children: (0, s.jsx)(r.A, {})
                        }) : null, h]
                    }),
                    background: v ? "dark" : "transparent"
                }), (0, s.jsx)("button", {
                    className: j,
                    onClick: b,
                    "data-qa": "connections-item",
                    "data-qa-connections-item-type": "promo",
                    ref: _,
                    disabled: x,
                    "aria-hidden": x,
                    type: "button",
                    children: (0, s.jsx)("div", {
                        className: "csms-connections-item__content",
                        children: (0, s.jsxs)(l.A, {
                            tag: "span",
                            children: [(0, s.jsx)(u.A, {
                                tag: "span",
                                children: (0, s.jsx)("span", {
                                    className: "csms-connections-item__media",
                                    children: (0, s.jsx)(c.A, {
                                        size: "sm",
                                        image: e,
                                        icon: t,
                                        user: n,
                                        badge: i,
                                        overlay: C
                                    })
                                })
                            }), (0, s.jsxs)(d.A, {
                                tag: "span",
                                children: [p ? (0, s.jsx)("span", {
                                    className: "csms-connections-item__title",
                                    children: (0, s.jsx)(m.P2, {
                                        dangerous: !0,
                                        children: p
                                    })
                                }) : null, g ? (0, s.jsx)("span", {
                                    className: "csms-connections-item__message",
                                    "data-qa": "csms-connections-item__message",
                                    children: (0, s.jsx)(m.P2, {
                                        dangerous: !0,
                                        children: g
                                    })
                                }) : null, f ? (0, s.jsx)("span", {
                                    className: "csms-connections-item__action",
                                    children: (0, s.jsx)(m.P2, {
                                        children: f
                                    })
                                }) : null]
                            })]
                        })
                    })
                })
            }
        },
        90959: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return c
                }
            });
            var s = n(74848),
                a = n(70870),
                i = n(8483);
            var o = ({
                id: e,
                name: t,
                value: n,
                onFocus: a,
                onChange: o,
                onBlur: c,
                innerRef: r,
                a11y: l
            }) => (0, s.jsxs)("div", {
                className: "csms-chat-controls-base-input-search",
                children: [(0, s.jsx)("div", {
                    className: "csms-chat-controls-base-input-search__icon",
                    children: (0, s.jsx)(i.A, {
                        name: "generic-search"
                    })
                }), n ? null : (0, s.jsx)("label", {
                    className: "csms-chat-controls-base-input-search__label",
                    "aria-hidden": !0,
                    htmlFor: e,
                    children: l ? .inputLabel
                }), (0, s.jsx)("input", {
                    className: "csms-chat-controls-base-input-search__field",
                    type: "search",
                    id: e,
                    name: t,
                    value: n,
                    autoComplete: "off",
                    autoCorrect: "off",
                    inputMode: "search",
                    spellCheck: !1,
                    onFocus: a,
                    onChange: o,
                    onBlur: c,
                    ref: r,
                    "aria-label": l ? .inputLabel
                }), (0, s.jsx)("div", {
                    className: "csms-chat-controls-base-input-search__focus-ring"
                })]
            });
            var c = ({
                id: e = "chat-composer-input-search",
                name: t,
                value: n,
                extra: i,
                onFocus: c,
                onChange: r,
                onBlur: l,
                innerRef: d,
                a11y: u
            }) => (0, s.jsx)(a.A, {
                type: "search",
                content: (0, s.jsx)(o, {
                    id: e || "chat-composer-input-search",
                    name: t,
                    value: n,
                    onFocus: c,
                    onChange: r,
                    onBlur: l,
                    innerRef: d,
                    a11y: u
                }),
                extra: i
            })
        },
        91076: function(e, t, n) {
            var s = n(74848);
            t.A = ({
                children: e,
                onSubmit: t,
                a11y: n
            }) => (0, s.jsx)("form", {
                className: "csms-chat-composer-frame",
                onSubmit: t,
                "aria-label": n ? .label,
                noValidate: !0,
                children: e
            })
        },
        95002: function(e, t, n) {
            var s = n(74848),
                a = n(46942),
                i = n.n(a),
                o = n(93827);
            const c = ({
                src: e,
                shape: t
            }) => {
                const n = i()({
                        "csms-chat-message-preview__media": !0,
                        [`csms-chat-message-preview__media--${t}`]: t
                    }),
                    a = {};
                return e && (a.backgroundImage = `url(${e})`), (0, s.jsx)("div", {
                    className: n,
                    style: a
                })
            };
            t.A = ({
                direction: e,
                title: t,
                description: n,
                media: a
            }) => {
                const r = i()({
                    "csms-chat-message-preview": !0,
                    [`csms-chat-message-preview--${e}`]: e
                });
                return (0, s.jsxs)("blockquote", {
                    className: r,
                    children: [(0, s.jsxs)("div", {
                        className: "csms-chat-message-preview__text",
                        children: [(0, s.jsx)(o.P3, {
                            weight: "bolder",
                            ellipsis: !0,
                            children: t
                        }), (0, s.jsx)(o.P3, {
                            dangerous: !0,
                            ellipsis: !0,
                            children: n
                        })]
                    }), a ? (0, s.jsx)(c, {
                        src: a.src,
                        shape: a.shape
                    }) : null]
                })
            }
        },
        95511: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return a
                }
            });
            var s = n(22001),
                a = function(e) {
                    function t() {
                        return null !== e && e.apply(this, arguments) || this
                    }
                    return (0, s._)(t, e), t.prototype.render = function() {
                        var e = this.context.currentUser;
                        if (!e.id) return this.props.children((0, s.a)({}, this.props));
                        var t = this.props.messages,
                            n = e ? e.id : "",
                            a = !1,
                            i = t.map((function(e, i) {
                                var o = e.fromUserId === n,
                                    c = !(0 === i) && a === o;
                                a = o;
                                var r = i === t.length - 1;
                                r || (r = t[i + 1].fromUserId === n !== o);
                                return (0, s.a)((0, s.a)({}, e), {
                                    isContinuation: c,
                                    isLastMessageInGroup: r,
                                    isMessageFromCurrentUser: o
                                })
                            }));
                        return this.props.children((0, s.a)((0, s.a)({}, this.props), {
                            messages: i
                        }))
                    }, t.contextType = s.M, t
                }(n(96540).PureComponent)
        },
        97803: function(e, t, n) {
            var s = n(74848),
                a = n(46942),
                i = n.n(a),
                o = n(8483);
            const c = {
                "add-photos": "floating-action-add-photos",
                chat: "floating-action-chat",
                crush: "floating-action-crush",
                "edit-profile": "floating-action-edit-profile",
                match: "floating-action-match",
                next: "floating-action-next",
                no: "floating-action-no",
                "no-inverted": "floating-action-no-inverted",
                ok: "floating-action-ok",
                prev: "floating-action-prev",
                smile: "floating-action-smile",
                yes: "floating-action-yes",
                "yes-inverted": "floating-action-yes-inverted"
            };
            t.A = ({
                type: e,
                isHidden: t,
                isPressed: n,
                onClick: a,
                dataQA: r,
                a11y: l
            }) => {
                const d = i()({
                        "csms-profile-action": !0,
                        "csms-profile-action--next": "next" === e,
                        "csms-profile-action--prev": "prev" === e,
                        "is-hidden": t,
                        "is-pressed": n
                    }),
                    u = {
                        "data-qa-profile-action": e,
                        ...r
                    };
                return (0, s.jsx)("button", {
                    className: d,
                    onClick: a,
                    "aria-hidden": t,
                    "aria-pressed": n,
                    disabled: n,
                    type: "button",
                    ...u,
                    children: (0, s.jsx)(o.A, {
                        name: c[e],
                        a11y: {
                            label: l.label
                        }
                    })
                })
            }
        },
        98845: function(e, t, n) {
            var s = n(74848);
            t.A = ({
                children: e,
                onScroll: t,
                onKeyUp: n,
                a11y: a
            }) => (0, s.jsx)("div", {
                className: "csms-chat-panel-pills",
                onScroll: t,
                role: "tablist",
                "aria-label": a ? .label,
                onKeyUp: n,
                tabIndex: 0,
                children: e
            })
        },
        99315: function(e, t, n) {
            var s = n(74848),
                a = n(46942),
                i = n.n(a),
                o = n(93827),
                c = n(67805);
            t.A = ({
                direction: e,
                isContinuation: t,
                nesting: n,
                content: a,
                extra: r,
                actions: l,
                isLoading: d
            }) => {
                const u = i()({
                    "csms-chat-bubble": !0,
                    [`csms-chat-bubble--${e}`]: e,
                    "csms-chat-bubble--continuation": t,
                    [`csms-chat-bubble--nested-${n}`]: n,
                    "csms-chat-bubble-complex": !0
                });
                return (0, s.jsxs)("div", {
                    className: u,
                    children: [(0, s.jsxs)("div", {
                        className: "csms-chat-bubble-complex__content",
                        children: [a, d ? (0, s.jsx)(c.A, {}) : null]
                    }), r ? (0, s.jsx)("div", {
                        className: "csms-chat-bubble-complex__footer",
                        children: (0, s.jsx)("div", {
                            className: "csms-chat-bubble-complex__extra",
                            "data-qa": "chat-message-extra",
                            children: r
                        })
                    }) : null, l ? (0, s.jsx)("div", {
                        className: "csms-chat-bubble-complex__footer",
                        children: (0, s.jsxs)("div", {
                            className: "csms-chat-bubble-complex__actions",
                            children: [l.primary ? (0, s.jsx)("button", {
                                onClick: l.onClickPrimary,
                                className: "csms-chat-bubble-complex__action csms-chat-bubble-complex__action--primary",
                                "data-qa": "chat-message-action-primary",
                                type: "button",
                                children: (0, s.jsx)(o.P1, {
                                    ellipsis: !0,
                                    children: l.primary
                                })
                            }) : null, l.secondary ? (0, s.jsx)("button", {
                                onClick: l.onClickSecondary,
                                className: "csms-chat-bubble-complex__action csms-chat-bubble-complex__action--secondary",
                                "data-qa": "chat-message-action-secondary",
                                type: "button",
                                children: (0, s.jsx)(o.P1, {
                                    ellipsis: !0,
                                    children: l.secondary
                                })
                            }) : null]
                        })
                    }) : null]
                })
            }
        },
        99845: function(e, t, n) {
            var s = n(74848),
                a = n(46942),
                i = n.n(a);
            t.A = ({
                children: e,
                color: t = "gray-10",
                direction: n = "in",
                isContinuation: a,
                onClick: o,
                innerRef: c,
                dataQA: r
            }) => {
                const l = i()({
                        "csms-bubble-wrapper": !0,
                        [`csms-bubble-wrapper--${n}`]: !0
                    }),
                    d = i()({
                        "csms-bubble": !0,
                        [`csms-bubble--${n}`]: !0,
                        "csms-bubble--continuation": a,
                        [`csms-bubble--color-${t}`]: !0
                    }),
                    u = o ? "button" : "span";
                return (0, s.jsx)("div", {
                    className: l,
                    "data-qa": "bubble",
                    ...r,
                    children: (0, s.jsx)(u, {
                        className: d,
                        onClick: o,
                        ref: c,
                        type: "button" === u ? "button" : void 0,
                        children: e
                    })
                })
            }
        }
    }
]);
//# sourceMappingURL=7444.36ffb26600abe752a9e9.js.map
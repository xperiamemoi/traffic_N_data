"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [8399], {
        38399: function(e, t, n) {
            n.r(t);
            var s = n(99417);
            ! function(e, t, n, s, a, i, c) {
                function u(n, s) {
                    t[e]._Q.push([n, s])
                }
                t[e] || (t[e] = {
                    init: function() {
                        u("i", arguments)
                    },
                    fetchBids: function() {
                        u("f", arguments)
                    },
                    setDisplayBids: function() {},
                    targetingKeys: function() {
                        return []
                    },
                    _Q: []
                }, (i = n.createElement(s)).async = !0, i.src = "//c.amazon-adsystem.com/aax2/apstag.js", (c = n.getElementsByTagName(s)[0]).parentNode.insertBefore(i, c))
            }("apstag", s.A, s.A.document, "script"), t.default = !0
        }
    }
]);
//# sourceMappingURL=8399.2b32ddc140c293bb19f1.js.map
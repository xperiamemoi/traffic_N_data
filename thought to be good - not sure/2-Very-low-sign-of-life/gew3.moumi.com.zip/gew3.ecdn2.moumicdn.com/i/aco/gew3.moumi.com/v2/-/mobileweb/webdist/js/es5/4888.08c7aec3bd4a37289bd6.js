"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [4888], {
        12102: function(e, r, t) {
            t.d(r, {
                A: function() {
                    return ue
                }
            });
            var n = t(22080);
            var c = function(e, r) {
                    for (var t = -1, n = null == e ? 0 : e.length; ++t < n && !1 !== r(e[t], t, e););
                    return e
                },
                a = t(52851),
                o = t(22031),
                s = t(27422);
            var i = function(e, r) {
                    return e && (0, o.A)(r, (0, s.A)(r), e)
                },
                u = t(79999);
            var l = function(e, r) {
                    return e && (0, o.A)(r, (0, u.A)(r), e)
                },
                d = t(41917),
                b = "object" == typeof exports && exports && !exports.nodeType && exports,
                v = b && "object" == typeof module && module && !module.nodeType && module,
                f = v && v.exports === b ? d.A.Buffer : void 0,
                j = f ? f.allocUnsafe : void 0;
            var m = function(e, r) {
                    if (r) return e.slice();
                    var t = e.length,
                        n = j ? j(t) : new e.constructor(t);
                    return e.copy(n), n
                },
                p = t(39759),
                A = t(14792);
            var h = function(e, r) {
                    return (0, o.A)(e, (0, A.A)(e), r)
                },
                y = t(76912),
                g = t(15647),
                x = t(13153),
                w = Object.getOwnPropertySymbols ? function(e) {
                    for (var r = []; e;)(0, y.A)(r, (0, A.A)(e)), e = (0, g.A)(e);
                    return r
                } : x.A;
            var k = function(e, r) {
                    return (0, o.A)(e, w(e), r)
                },
                _ = t(19042),
                C = t(33831);
            var N = function(e) {
                    return (0, C.A)(e, u.A, w)
                },
                S = t(9137),
                U = Object.prototype.hasOwnProperty;
            var O = function(e) {
                    var r = e.length,
                        t = new e.constructor(r);
                    return r && "string" == typeof e[0] && U.call(e, "index") && (t.index = e.index, t.input = e.input), t
                },
                F = t(43988);
            var $ = function(e) {
                var r = new e.constructor(e.byteLength);
                return new F.A(r).set(new F.A(e)), r
            };
            var I = function(e, r) {
                    var t = r ? $(e.buffer) : e.buffer;
                    return new e.constructor(t, e.byteOffset, e.byteLength)
                },
                B = /\w*$/;
            var E = function(e) {
                    var r = new e.constructor(e.source, B.exec(e));
                    return r.lastIndex = e.lastIndex, r
                },
                R = t(241),
                D = R.A ? R.A.prototype : void 0,
                M = D ? D.valueOf : void 0;
            var q = function(e) {
                return M ? Object(M.call(e)) : {}
            };
            var L = function(e, r) {
                var t = r ? $(e.buffer) : e.buffer;
                return new e.constructor(t, e.byteOffset, e.length)
            };
            var V = function(e, r, t) {
                    var n = e.constructor;
                    switch (r) {
                        case "[object ArrayBuffer]":
                            return $(e);
                        case "[object Boolean]":
                        case "[object Date]":
                            return new n(+e);
                        case "[object DataView]":
                            return I(e, t);
                        case "[object Float32Array]":
                        case "[object Float64Array]":
                        case "[object Int8Array]":
                        case "[object Int16Array]":
                        case "[object Int32Array]":
                        case "[object Uint8Array]":
                        case "[object Uint8ClampedArray]":
                        case "[object Uint16Array]":
                        case "[object Uint32Array]":
                            return L(e, t);
                        case "[object Map]":
                        case "[object Set]":
                            return new n;
                        case "[object Number]":
                        case "[object String]":
                            return new n(e);
                        case "[object RegExp]":
                            return E(e);
                        case "[object Symbol]":
                            return q(e)
                    }
                },
                K = t(23149),
                P = Object.create,
                Q = function() {
                    function e() {}
                    return function(r) {
                        if (!(0, K.A)(r)) return {};
                        if (P) return P(r);
                        e.prototype = r;
                        var t = new e;
                        return e.prototype = void 0, t
                    }
                }(),
                T = t(97271);
            var G = function(e) {
                    return "function" != typeof e.constructor || (0, T.A)(e) ? {} : Q((0, g.A)(e))
                },
                W = t(92049),
                z = t(41200),
                H = t(53098);
            var J = function(e) {
                    return (0, H.A)(e) && "[object Map]" == (0, S.A)(e)
                },
                X = t(52789),
                Y = t(64841),
                Z = Y.A && Y.A.isMap,
                ee = Z ? (0, X.A)(Z) : J;
            var re = function(e) {
                    return (0, H.A)(e) && "[object Set]" == (0, S.A)(e)
                },
                te = Y.A && Y.A.isSet,
                ne = te ? (0, X.A)(te) : re,
                ce = "[object Arguments]",
                ae = "[object Function]",
                oe = "[object Object]",
                se = {};
            se[ce] = se["[object Array]"] = se["[object ArrayBuffer]"] = se["[object DataView]"] = se["[object Boolean]"] = se["[object Date]"] = se["[object Float32Array]"] = se["[object Float64Array]"] = se["[object Int8Array]"] = se["[object Int16Array]"] = se["[object Int32Array]"] = se["[object Map]"] = se["[object Number]"] = se[oe] = se["[object RegExp]"] = se["[object Set]"] = se["[object String]"] = se["[object Symbol]"] = se["[object Uint8Array]"] = se["[object Uint8ClampedArray]"] = se["[object Uint16Array]"] = se["[object Uint32Array]"] = !0, se["[object Error]"] = se[ae] = se["[object WeakMap]"] = !1;
            var ie = function e(r, t, o, d, b, v) {
                var f, j = 1 & t,
                    A = 2 & t,
                    y = 4 & t;
                if (o && (f = b ? o(r, d, b, v) : o(r)), void 0 !== f) return f;
                if (!(0, K.A)(r)) return r;
                var g = (0, W.A)(r);
                if (g) {
                    if (f = O(r), !j) return (0, p.A)(r, f)
                } else {
                    var x = (0, S.A)(r),
                        w = x == ae || "[object GeneratorFunction]" == x;
                    if ((0, z.A)(r)) return m(r, j);
                    if (x == oe || x == ce || w && !b) {
                        if (f = A || w ? {} : G(r), !j) return A ? k(r, l(f, r)) : h(r, i(f, r))
                    } else {
                        if (!se[x]) return b ? r : {};
                        f = V(r, x, j)
                    }
                }
                v || (v = new n.A);
                var C = v.get(r);
                if (C) return C;
                v.set(r, f), ne(r) ? r.forEach((function(n) {
                    f.add(e(n, t, o, n, r, v))
                })) : ee(r) && r.forEach((function(n, c) {
                    f.set(c, e(n, t, o, c, r, v))
                }));
                var U = y ? A ? N : _.A : A ? u.A : s.A,
                    F = g ? void 0 : U(r);
                return c(F || r, (function(n, c) {
                    F && (n = r[c = n]), (0, a.A)(f, c, e(n, t, o, c, r, v))
                })), f
            };
            var ue = function(e) {
                return ie(e, 5)
            }
        },
        17559: function(e, r, t) {
            var n = t(74848),
                c = t(47639);
            r.A = ({
                value: e,
                onChange: r,
                onSubmit: t,
                showClear: a,
                onClear: o,
                innerRef: s,
                a11y: i
            }) => (0, n.jsx)("div", {
                className: "csms-navigation-bar__search",
                children: (0, n.jsx)(c.A, {
                    value: e,
                    onChange: r,
                    onSubmit: t,
                    showClear: a,
                    onClear: o,
                    innerRef: s,
                    a11y: i
                })
            })
        },
        31023: function(e, r, t) {
            t.d(r, {
                A: function() {
                    return d
                }
            });
            var n = t(74848),
                c = t(96540),
                a = t(46942),
                o = t.n(a);
            var s = ({
                children: e,
                variant: r
            }) => {
                const t = o()({
                        "csms-brick-group": !0,
                        "csms-brick-group--cascade": !0,
                        [`csms-brick-group--cascade-${r}`]: !0
                    }),
                    a = c.Children.map(e, (e => (0, n.jsx)("div", {
                        className: "csms-brick-group__item",
                        children: e
                    })));
                return (0, n.jsx)("div", {
                    className: t,
                    children: a
                })
            };
            var i = ({
                children: e,
                variant: r
            }) => {
                const t = o()({
                        "csms-brick-group": !0,
                        "csms-brick-group--double": !0,
                        [`csms-brick-group--double-${r}`]: !0
                    }),
                    a = c.Children.map(e, (e => (0, n.jsx)("div", {
                        className: "csms-brick-group__item",
                        children: e
                    })));
                return (0, n.jsx)("div", {
                    className: t,
                    children: a
                })
            };
            var u = ({
                    children: e
                }) => {
                    let r;
                    const t = c.Children.toArray(e)[0].props.badge;
                    t && "bc" === t.position && (t.mark && (r = "mark"), t.icon && (r = "icon"));
                    const a = o()({
                        "csms-brick-group": !0,
                        "csms-brick-group--single": !0
                    }, void 0 !== r && `csms-brick-group--padded-${r}`);
                    return (0, n.jsx)("div", {
                        className: a,
                        children: (0, n.jsx)("div", {
                            className: "csms-brick-group__item",
                            children: e
                        })
                    })
                },
                l = t(91473);
            var d = ({
                children: e,
                layout: r,
                variant: t
            }) => {
                switch (r) {
                    case "single":
                        return (0, n.jsx)(u, {
                            children: e
                        });
                    case "double":
                        return (0, n.jsx)(i, {
                            variant: t,
                            children: e
                        });
                    case "triple":
                        return (0, n.jsx)(l.A, {
                            variant: t,
                            children: e
                        });
                    case "cascade":
                        return (0, n.jsx)(s, {
                            variant: t,
                            children: e
                        })
                }
            }
        },
        84395: function(e, r, t) {
            var n = t(74848),
                c = t(46942),
                a = t.n(c),
                o = t(8483);
            r.A = ({
                id: e,
                name: r,
                options: t,
                value: c,
                allowEmptyState: s = !0,
                selectedLabel: i,
                dir: u = "auto",
                isFocused: l,
                docked: d,
                status: b,
                onFocus: v,
                onChange: f,
                onBlur: j,
                onKeyUp: m,
                selectRef: p,
                dataQA: A,
                dataQASelect: h,
                a11y: y = {}
            }) => {
                const g = a()({
                        "csms-select": !0,
                        "csms-select--is-focused": l,
                        [`csms-select--status-${b}`]: b,
                        "csms-select--has-label": i,
                        [`csms-select--docked-${d}`]: d,
                        [`csms-select--dir-${u}`]: u
                    }),
                    x = {
                        "data-qa": "csms-select",
                        ...A
                    };
                return (0, n.jsxs)("div", {
                    className: g,
                    ...x,
                    children: [(0, n.jsx)("span", {
                        className: "csms-select__icon",
                        children: (0, n.jsx)(o.A, {
                            name: "generic-chevron-down"
                        })
                    }), (0, n.jsxs)("select", {
                        className: "csms-select__field",
                        id: e,
                        name: r,
                        value: f ? c : void 0,
                        defaultValue: f ? void 0 : c,
                        onFocus: v,
                        onChange: f,
                        onKeyUp: m,
                        onBlur: j,
                        ref: p,
                        dir: u,
                        "data-qa": h || "csms-select-dropdown",
                        "aria-describedby": y.ariaDescribedby,
                        "aria-required": y.ariaRequired,
                        "aria-invalid": "error" === b || void 0,
                        "aria-label": y.label,
                        children: [s ? (0, n.jsx)("option", {}) : void 0, t.map(((e, r) => (0, n.jsx)("option", {
                            value: e.value,
                            children: e.label
                        }, r)))]
                    }), i ? (0, n.jsx)("div", {
                        className: "csms-select__label",
                        dir: u,
                        "aria-hidden": !0,
                        children: i
                    }) : null, (0, n.jsx)("div", {
                        className: "csms-select__focus-ring"
                    })]
                })
            }
        },
        91473: function(e, r, t) {
            var n = t(74848),
                c = t(96540),
                a = t(46942),
                o = t.n(a);
            r.A = ({
                children: e,
                variant: r
            }) => {
                let t;
                const a = e[1].props.badge;
                a && "bc" === a.position && (a.mark && (t = "mark"), a.icon && (t = "icon"));
                const s = o()({
                        "csms-brick-group": !0,
                        "csms-brick-group--triple": !0,
                        [`csms-brick-group--triple-${r}`]: !0
                    }, void 0 !== t && `csms-brick-group--padded-${t}`),
                    i = c.Children.map(e, (e => (0, n.jsx)("div", {
                        className: "csms-brick-group__item",
                        children: e
                    })));
                return (0, n.jsx)("div", {
                    className: s,
                    children: i
                })
            }
        }
    }
]);
//# sourceMappingURL=4888.08c7aec3bd4a37289bd6.js.map
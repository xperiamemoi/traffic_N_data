/*! For license information please see 340.cfa83743574cc59d54dc.js.LICENSE.txt */
"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [340], {
        10730: function(e, n, t) {
            var a = t(74848);
            n.A = ({
                children: e
            }) => (0, a.jsx)("div", {
                className: "csms-navigation-bar__content",
                children: e
            })
        },
        12554: function(e, n, t) {
            var a = t(74848),
                s = t(84362),
                i = t(26914),
                o = t(53787),
                c = t(93827);
            n.A = ({
                user: e,
                additional: n,
                onClick: t,
                innerRef: l,
                a11y: r
            }) => {
                const d = t ? "button" : "div";
                return (0, a.jsxs)(d, {
                    className: "csms-navigation-bar__profile",
                    onClick: t,
                    ref: l,
                    type: "button" === d ? "button" : void 0,
                    children: [(0, a.jsx)(s.A, {
                        children: r ? .label
                    }), (0, a.jsx)("span", {
                        className: "csms-navigation-bar__profile-avatar",
                        "aria-hidden": Boolean(r ? .label) || void 0,
                        children: (0, a.jsx)(i.A, {
                            user: e
                        })
                    }), e ? .name ? (0, a.jsxs)("span", {
                        className: "csms-navigation-bar__profile-info",
                        children: [(0, a.jsx)(s.A, {
                            tag: "h1",
                            children: e.name
                        }), (0, a.jsx)(c.ZS, {
                            a11y: {
                                ariaHidden: Boolean(r ? .label) || void 0
                            },
                            children: (0, a.jsx)(o.A, {
                                name: e.name,
                                age: e.age,
                                status: e.status,
                                a11y: {
                                    label: r ? .profileInfoLabel
                                }
                            })
                        })]
                    }) : null, n ? (0, a.jsx)("span", {
                        className: "csms-navigation-bar__profile-additional",
                        "aria-hidden": Boolean(r ? .label) || void 0,
                        children: (0, a.jsx)(c.P3, {
                            ellipsis: !0,
                            children: n
                        })
                    }) : null]
                })
            }
        },
        15279: function(e, n, t) {
            var a = t(74848);
            n.A = ({
                text: e
            }) => (0, a.jsx)("div", {
                className: "csms-navigation-bar__sub-title",
                children: e
            })
        },
        17380: function(e, n, t) {
            var a = t(74848),
                s = t(46942),
                i = t.n(s),
                o = t(8483);
            n.A = ({
                type: e,
                color: n = "default",
                id: t,
                name: s,
                value: c,
                isChecked: l,
                isInvalid: r,
                isDisabled: d,
                onChange: u,
                onClick: m,
                dataQA: h,
                a11y: p
            }) => {
                let b = l ? "checked" : "unchecked";
                r && !l && (b = "error");
                const x = i()({
                        "csms-choice": !0,
                        "csms-choice--is-checked": l,
                        ["csms-choice--" + ("checkbox" === e ? "checkbox" : "radiobutton")]: !0,
                        "csms-choice--disabled": d,
                        [`csms-choice--${n}-${b}-${"checkbox"===e?"checkbox":"radiobutton"}`]: !0
                    }),
                    f = "checkbox" === e ? "checkbox" : "radio",
                    _ = {
                        "data-qa": `csms-${f}`,
                        ...h
                    };
                return (0, a.jsxs)("span", {
                    className: x,
                    ..._,
                    children: [(0, a.jsx)("input", {
                        className: "csms-choice__input",
                        id: t,
                        name: s,
                        value: c,
                        type: f,
                        checked: l,
                        onChange: u,
                        disabled: d,
                        onClick: m,
                        "aria-label": p ? .label,
                        "aria-invalid": r && !l
                    }), (0, a.jsx)("span", {
                        className: "csms-choice__icon",
                        children: (0, a.jsx)(o.A, {
                            name: "checkbox" === e ? "elements-checkbox-selected-indicator" : "elements-radiobutton-selected-indicator"
                        })
                    }), (0, a.jsx)("span", {
                        className: "csms-choice__border"
                    })]
                })
            }
        },
        21020: function(e, n, t) {
            t(45228);
            var a = t(96540),
                s = 60103;
            if (n.Fragment = 60107, "function" == typeof Symbol && Symbol.for) {
                var i = Symbol.for;
                s = i("react.element"), n.Fragment = i("react.fragment")
            }
            var o = a.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
                c = Object.prototype.hasOwnProperty,
                l = {
                    key: !0,
                    ref: !0,
                    __self: !0,
                    __source: !0
                };

            function r(e, n, t) {
                var a, i = {},
                    r = null,
                    d = null;
                for (a in void 0 !== t && (r = "" + t), void 0 !== n.key && (r = "" + n.key), void 0 !== n.ref && (d = n.ref), n) c.call(n, a) && !l.hasOwnProperty(a) && (i[a] = n[a]);
                if (e && e.defaultProps)
                    for (a in n = e.defaultProps) void 0 === i[a] && (i[a] = n[a]);
                return {
                    $$typeof: s,
                    type: e,
                    key: r,
                    ref: d,
                    props: i,
                    _owner: o.current
                }
            }
            n.jsx = r, n.jsxs = r
        },
        26443: function(e, n, t) {
            var a = t(74848),
                s = t(46942),
                i = t.n(s),
                o = t(84362);
            n.A = ({
                status: e = "hidden",
                a11y: n
            }) => {
                const t = i()({
                    "csms-online-status": !0,
                    [`csms-online-status--${e}`]: !0
                });
                return (0, a.jsx)("span", {
                    className: t,
                    "data-qa-online-status": e,
                    children: (0, a.jsx)(o.A, {
                        children: n ? .label
                    })
                })
            }
        },
        43349: function(e, n, t) {
            t.r(n), t.d(n, {
                default: function() {
                    return k
                }
            });
            t(28706), t(10287);
            var a, s = t(85558),
                i = (t(51629), t(26099), t(98992), t(3949), t(23500), t(96540)),
                o = t(58385),
                c = t(74389),
                l = (t(62062), t(81454), t(40075)),
                r = t(39904),
                d = t(47901),
                u = t(87184),
                m = t(15376),
                h = t(95299),
                p = t(74848),
                b = function(e) {
                    var n = e.sections,
                        t = e.onClickBack;
                    return (0, p.jsxs)(d.A, {
                        children: [(0, p.jsx)(m.A, {
                            children: (0, p.jsx)(r.Ay, {
                                actions: [{
                                    type: r.X2.BACK,
                                    onClick: t
                                }],
                                title: l.Ay.get(977),
                                position: "sticky",
                                hasShadow: !0
                            })
                        }), (0, p.jsxs)(u.A, {
                            children: [n.map((function(e, n) {
                                return (0, p.jsxs)(i.Fragment, {
                                    children: [(0, p.jsx)("div", {
                                        className: "settings-divider"
                                    }), e.map((function(e) {
                                        return (0, p.jsx)(h.A, {
                                            title: {
                                                text: e.label
                                            },
                                            action: {
                                                action: "chevron"
                                            },
                                            onClick: e.onClick,
                                            dataQA: {
                                                "data-destination": e.key
                                            }
                                        }, e.key)
                                    }))]
                                }, "settings-section-" + n)
                            })), (0, p.jsx)("div", {
                                className: "settings-divider"
                            })]
                        })]
                    })
                },
                x = (t(15086), t(37550), t(72537)),
                f = t(20387),
                _ = t(64928),
                v = t(79860);
            ! function(e) {
                e[e.INTERFACE_LANGUAGE = 100] = "INTERFACE_LANGUAGE"
            }(a || (a = {}));
            var g = function() {
                    var e = (0, i.useState)(!1),
                        n = e[0],
                        t = e[1],
                        a = (0, i.useState)(!1),
                        s = a[0],
                        o = a[1],
                        c = (0, i.useState)(!1),
                        l = c[0],
                        r = c[1];
                    return (0, i.useEffect)((function() {
                        new f.A({
                            folderId: f.A.TYPES.BLOCKED
                        }).get().then((function(e) {
                            var n = e[0].getTotalCount() > 0;
                            t(n)
                        })).catch((function() {}));
                        var e = x.A.getSync(37).enabled;
                        o(e), _.A.getInstance().get().then((function(e) {
                            var n, t = ((null == e || null == (n = e.menu) ? void 0 : n.sections) || []).some((function(e) {
                                var n;
                                return null == (n = e.items) ? void 0 : n.some((function(e) {
                                    return 17 === e.type
                                }))
                            }));
                            r(t), t && (0, v.sx)(258, {
                                element: 1401
                            })
                        }))
                    }), []), {
                        showBlockedUsers: n,
                        showPaymentSettings: s,
                        showSecurityWalkthrough: l
                    }
                },
                y = function() {
                    var e = g(),
                        n = e.showBlockedUsers,
                        t = e.showPaymentSettings,
                        s = e.showSecurityWalkthrough,
                        r = (0, i.useState)([]),
                        d = r[0],
                        u = r[1],
                        m = function(e) {
                            var n, t = e.route,
                                a = {};
                            17 === e.type && (a.securityWalkthroughSource = c.x.SETTINGS), n = e.element, (0, v.sx)(332, {
                                element: n
                            }), o.A.navigate(t, a)
                        },
                        h = (0, i.useCallback)((function(e) {
                            return !(13 === e && !n) && (!(14 === e && !t) && !(17 === e && !s))
                        }), [n, t, s]);
                    return (0, i.useEffect)((function() {
                        var e = [];
                        [
                            [{
                                type: 3,
                                route: c.x.SETTINGS_BASIC_INFO,
                                label: l.Ay.get(1040),
                                element: 1288
                            }, {
                                type: 8,
                                route: c.x.SETTINGS_NOTIFICATIONS,
                                label: l.Ay.get(844),
                                element: 333
                            }, {
                                type: 9,
                                route: c.x.SETTINGS_PRIVACY,
                                label: l.Ay.get(845),
                                element: 332
                            }, {
                                type: 15,
                                route: c.x.SETTINGS_INVISIBLE_MODE,
                                label: l.Ay.get(843),
                                element: 701
                            }, {
                                type: a.INTERFACE_LANGUAGE,
                                route: c.x.SETTINGS_INTERFACE_LANGUAGE,
                                label: l.Ay.get(598),
                                element: 28
                            }, {
                                type: 11,
                                route: c.x.SETTINGS_VERIFICATION,
                                label: l.Ay.get(860),
                                element: 31
                            }, {
                                type: 12,
                                route: c.x.SETTINGS_ACCOUNT,
                                label: l.Ay.get(833),
                                element: 125
                            }, {
                                type: 17,
                                route: c.x.SECURITY_WALKTHROUGH_REDIRECT,
                                label: l.Ay.get(51),
                                element: 1401
                            }, {
                                type: 14,
                                route: c.x.SETTINGS_PAYMENTS,
                                label: l.Ay.get(488),
                                element: 778
                            }],
                            [{
                                type: 5,
                                route: c.x.SETTINGS_ABOUT,
                                label: l.Ay.get(832),
                                element: 331
                            }, {
                                type: 6,
                                route: c.x.HELP,
                                label: l.Ay.get(838),
                                element: 688
                            }, {
                                type: 7,
                                route: c.x.FEEDBACK,
                                label: l.Ay.get(835),
                                element: 199
                            }],
                            [{
                                type: 13,
                                route: c.x.SETTINGS_BLOCKED_USERS,
                                label: l.Ay.get(1041),
                                element: 524
                            }]
                        ].forEach((function(n) {
                            var t = [];
                            n.forEach((function(e) {
                                h(e.type) && t.push({
                                    label: e.label,
                                    key: e.route,
                                    onClick: function() {
                                        return m(e)
                                    }
                                })
                            })), t.length > 0 && e.push(t)
                        })), u(e)
                    }), [h]), (0, p.jsx)(b, {
                        sections: d,
                        onClickBack: function() {
                            o.A.back()
                        }
                    })
                };

            function A(e, n) {
                return A = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, n) {
                    return e.__proto__ = n, e
                }, A(e, n)
            }
            var j = function(e) {
                    function n() {
                        for (var n, t = arguments.length, a = new Array(t), s = 0; s < t; s++) a[s] = arguments[s];
                        return (n = e.call.apply(e, [this].concat(a)) || this).activationPlace = 26, n.screenName = 8, n.clientSource = 25, n
                    }
                    var t, a;
                    return a = e, (t = n).prototype = Object.create(a.prototype), t.prototype.constructor = t, A(t, a), n.prototype.render = function() {
                        return this.addPageWrapper((0, p.jsx)(y, {}))
                    }, n
                }(s.A),
                k = j
        },
        46449: function(e, n, t) {
            var a = t(46518),
                s = t(70259),
                i = t(48981),
                o = t(26198),
                c = t(91291),
                l = t(1469);
            a({
                target: "Array",
                proto: !0
            }, {
                flat: function() {
                    var e = arguments.length ? arguments[0] : void 0,
                        n = i(this),
                        t = o(n),
                        a = l(n, 0);
                    return a.length = s(a, n, n, t, 0, void 0 === e ? 1 : c(e)), a
                }
            })
        },
        47360: function(e, n) {
            n.A = function(e) {
                return e && e.length ? e[0] : void 0
            }
        },
        53787: function(e, n, t) {
            var a = t(74848),
                s = t(84362),
                i = t(26443);
            n.A = ({
                name: e,
                age: n,
                status: t,
                a11y: o
            }) => {
                const c = Boolean(o ? .label);
                return (0, a.jsxs)("span", {
                    className: "csms-profile-info",
                    children: [(0, a.jsx)("span", {
                        className: "csms-profile-info__name",
                        "data-qa": "profile-info__name",
                        "aria-hidden": c,
                        children: (0, a.jsx)("span", {
                            className: "csms-profile-info__name-inner",
                            children: e
                        })
                    }), n ? (0, a.jsx)("span", {
                        className: "csms-profile-info__age",
                        "aria-hidden": c,
                        children: (0, a.jsxs)("span", {
                            children: [", ", (0, a.jsx)("span", {
                                "data-qa": "profile-info__age",
                                children: n
                            })]
                        })
                    }) : null, t ? .online && "hidden" !== t ? .online ? (0, a.jsx)("span", {
                        className: "csms-profile-info__status",
                        "aria-hidden": c,
                        children: (0, a.jsx)(i.A, {
                            status: t.online
                        })
                    }) : null, (0, a.jsx)(s.A, {
                        children: o ? .label
                    })]
                })
            }
        },
        56535: function(e, n, t) {
            var a = t(74848),
                s = t(46942),
                i = t.n(s);
            n.A = ({
                id: e,
                isChecked: n,
                isDisabled: t,
                onChange: s,
                isDecorative: o,
                tag: c = "input",
                onClick: l
            }) => {
                const r = i()({
                        "csms-toggle": !0,
                        "csms-toggle--disabled": t,
                        "csms-toggle--checked": n
                    }),
                    d = "button" === c ? "button" : "span";
                return (0, a.jsxs)(d, {
                    className: r,
                    "data-qa": "toggle",
                    "data-qa-state": n ? "on" : "off",
                    "aria-checked": "button" !== c || o ? void 0 : Boolean(n),
                    type: "button" !== c || o ? void 0 : "button",
                    role: "button" !== c || o ? void 0 : "switch",
                    onClick: l,
                    children: [o || "input" !== c ? null : (0, a.jsx)("input", {
                        className: "csms-toggle__input",
                        id: e,
                        type: "checkbox",
                        checked: n,
                        onChange: s,
                        disabled: t
                    }), (0, a.jsx)("span", {
                        className: "csms-toggle__surrogate"
                    })]
                })
            }
        },
        68072: function(e, n, t) {
            var a = t(74848),
                s = t(84362);
            n.A = ({
                children: e,
                onClick: n,
                tag: t = "div",
                a11y: i
            }) => {
                const o = t,
                    c = n ? "button" : "span";
                return (0, a.jsx)(o, {
                    className: "csms-navigation-bar__logo",
                    "aria-hidden": i ? .ariaHidden || void 0,
                    id: "navigation-logo",
                    children: (0, a.jsxs)(c, {
                        className: "csms-navigation-bar__logo-action",
                        onClick: n,
                        "aria-hidden": i ? .ariaHidden || void 0,
                        "data-qa": "navbar-logo",
                        type: "button" === c ? "button" : void 0,
                        children: [e, (0, a.jsx)(s.A, {
                            children: i ? .label
                        })]
                    })
                })
            }
        },
        70259: function(e, n, t) {
            var a = t(34376),
                s = t(26198),
                i = t(96837),
                o = t(76080),
                c = function(e, n, t, l, r, d, u, m) {
                    for (var h, p, b = r, x = 0, f = !!u && o(u, m); x < l;) x in t && (h = f ? f(t[x], x, n) : t[x], d > 0 && a(h) ? (p = s(h), b = c(e, n, h, p, b, d - 1) - 1) : (i(b + 1), e[b] = h), b++), x++;
                    return b
                };
            e.exports = c
        },
        83852: function(e, n, t) {
            var a = t(74848),
                s = t(46942),
                i = t.n(s),
                o = t(93827);
            n.A = ({
                text: e,
                isDisabled: n,
                onClick: t,
                innerRef: s,
                dataQA: c
            }) => {
                const l = i()({
                    "csms-navigation-bar__button-text": !0,
                    "csms-navigation-bar__button-text--is-disabled": n
                });
                return (0, a.jsx)("button", {
                    className: l,
                    onClick: n ? void 0 : t,
                    ref: s,
                    "data-qa": "navbar-link",
                    "aria-disabled": n,
                    type: "button",
                    ...c,
                    children: (0, a.jsx)(o.Qi, {
                        children: e
                    })
                })
            }
        },
        93514: function(e, n, t) {
            t(6469)("flat")
        },
        95299: function(e, n, t) {
            var a = t(74848),
                s = t(46942),
                i = t.n(s),
                o = t(84362),
                c = t(20017),
                l = t(17380),
                r = t(56535),
                d = t(8483),
                u = t(93827);
            n.A = ({
                media: e,
                title: n,
                description: t,
                label: s,
                action: m = {
                    action: "none"
                },
                variant: h = "default",
                onClick: p,
                isPressed: b,
                tag: x,
                innerRef: f,
                a11y: _,
                dataQA: v
            }) => {
                const g = i()({
                        "csms-action-row": !0,
                        "csms-action-row--compact": "compact" === h,
                        "csms-action-row--no-action": "none" === m ? .action,
                        "is-pressed": b
                    }),
                    y = i()({
                        "csms-action-row__content": !0,
                        "csms-action-row__content--no-label": !s
                    }),
                    A = i()({
                        "csms-action-row__title": !0,
                        [`csms-action-row__title--color-${n.color}`]: n.color,
                        [`csms-action-row__title--size-${n.size||"small"}`]: !0
                    }),
                    j = i()({
                        "csms-action-row__media": !0,
                        "csms-action-row__media--size-medium": "medium" === e ? .size
                    }),
                    k = Boolean(_ ? .contentLabel),
                    N = p ? "button" : x || "span",
                    S = {
                        "data-qa": "action-row",
                        ...v
                    };
                return (0, a.jsxs)(N, {
                    className: g,
                    onClick: p,
                    type: "button" === N ? "button" : void 0,
                    ref: f,
                    "aria-describedby": p ? _ ? .descriptionHintId : void 0,
                    "aria-selected": _ ? .ariaSelected,
                    "aria-checked": _ ? .ariaChecked,
                    "aria-pressed": _ ? .ariaPressed,
                    role: _ ? .role,
                    ...S,
                    children: [e ? (0, a.jsx)("span", {
                        className: j,
                        children: e.content
                    }) : null, (0, a.jsx)(o.A, {
                        children: _ ? .contentLabel
                    }), (0, a.jsxs)("span", {
                        className: y,
                        "aria-hidden": k,
                        children: [(0, a.jsx)("span", {
                            className: A,
                            "data-qa": "action-row-title",
                            children: "medium" === n.size ? (0, a.jsx)(u.Qi, {
                                ellipsis: !0,
                                children: n.text
                            }) : (0, a.jsx)(u.Qi, {
                                ellipsis: n.ellipsis,
                                breakWords: !n.ellipsis,
                                children: n.text
                            })
                        }), t ? .text ? (0, a.jsx)("span", {
                            className: "csms-action-row__hint",
                            "data-qa": "action-row-hint",
                            "aria-hidden": Boolean(_ ? .descriptionHintId),
                            id: _ ? .descriptionHintId,
                            children: (0, a.jsx)(u.Qi, {
                                ellipsis: t.ellipsis,
                                children: t.text
                            })
                        }) : null]
                    }), s ? (0, a.jsx)("span", {
                        className: "csms-action-row__label",
                        "aria-hidden": k,
                        children: (0, a.jsx)("span", {
                            className: "csms-action-row__label-text",
                            "data-qa": "action-row-value-text",
                            children: (0, a.jsx)(u.Qi, {
                                ellipsis: !0,
                                children: s
                            })
                        })
                    }) : null, "none" !== m ? .action && "label" !== m ? .action ? (0, a.jsx)("span", {
                        className: "csms-action-row__extra-placeholder",
                        "data-qa": "action-row-extra",
                        children: (0, a.jsxs)("span", {
                            className: "csms-action-row__extra",
                            "data-qa": "action-row-extra",
                            children: ["custom" === m.action && m.content ? m.content : null, "chevron" === m.action && (0, a.jsx)(d.A, {
                                name: "generic-chevron-right",
                                supportsRtl: !0
                            }), "checkbox" === m.action && m.checkbox ? (0, a.jsx)(l.A, { ...m.checkbox
                            }) : null, "toggle" === m.action && m.toggle ? (0, a.jsx)(r.A, { ...m.toggle
                            }) : null, "button" === m.action && m.button ? (0, a.jsx)(c.A, { ...m.button,
                                size: "micro"
                            }) : null]
                        })
                    }) : null]
                })
            }
        }
    }
]);
//# sourceMappingURL=340.cfa83743574cc59d54dc.js.map
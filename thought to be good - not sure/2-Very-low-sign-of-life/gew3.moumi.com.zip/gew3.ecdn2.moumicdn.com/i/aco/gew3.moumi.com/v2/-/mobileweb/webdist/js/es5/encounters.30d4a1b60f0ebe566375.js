"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [9649], {
        17399: function(e, t, n) {
            var o;
            n.d(t, {
                    q: function() {
                        return o
                    }
                }),
                function(e) {
                    e.ENCOUNTERS_VOTE_COMPLETE = "ENCOUNTERS_VOTE_COMPLETE", e.CRUSH_VOTE_COMPLETE = "CRUSH_VOTE_COMPLETE", e.UNDO_VOTE = "UNDO_VOTE", e.QUOTA_PROCESSING = "QUOTA_PROCESSING", e.QUOTA_PROCESSED = "QUOTA_PROCESSED", e.UPDATE_SETTINGS_MESSAGE = "UPDATE_SETTINGS_MESSAGE"
                }(o || (o = {}))
        },
        20015: function(e, t, n) {
            var o = n(74848),
                r = n(46942),
                i = n.n(r);
            t.A = ({
                percentage: e = 0,
                color: t = "default",
                rounded: n = !0,
                a11y: r
            }) => {
                const a = i()({
                        "csms-progress-bar": !0,
                        [`csms-progress-bar--${t}`]: !0,
                        "csms-progress-bar--rounded": n
                    }),
                    s = {
                        minWidth: `${e}%`
                    };
                return (0, o.jsx)("div", {
                    className: a,
                    role: "progressbar",
                    "aria-valuenow": e,
                    "aria-valuemin": 0,
                    "aria-valuemax": 100,
                    "aria-valuetext": r ? .label,
                    children: e ? (0, o.jsx)("div", {
                        className: "csms-progress-bar__indicator",
                        style: s
                    }) : null
                })
            }
        },
        20816: function(e, t, n) {
            n(51629), n(25276), n(23792), n(79432), n(10287), n(26099), n(3362), n(98992), n(3949), n(23500), n(62953);
            var o = n(58544),
                r = n(73090),
                i = n(27378),
                a = n(75248),
                s = n(31709),
                c = n(84230);

            function u(e, t) {
                return u = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, u(e, t)
            }
            var l = [8, 0, 6, 4, 53, 54],
                d = function(e) {
                    function t() {
                        var t;
                        return (t = e.call(this) || this).EVENTS = {
                            CHANGE: 1,
                            UPDATE: 2,
                            INVALIDATED: "invalidated"
                        }, t.cache = void 0, t.trackNextRequest = !1, t.cache = c.A.getInstance("BadgeCounters"), t.cache.on(c.A.EVENTS.INVALIDATED, (function(e) {
                            t.trigger(t.EVENTS.INVALIDATED, e)
                        })), a.A.getInstance().on(a.A.Type.PERSON_NOTICE, (function(e) {
                            t.cacheResponse(e)
                        })).on(a.A.Type.CHAT_MESSAGE, (function() {
                            t.invalidateAll()
                        })), t
                    }
                    var n, o;
                    o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, u(n, o);
                    var d = t.prototype;
                    return d.getCached = function() {
                        var e = this,
                            t = this.cache.getKeys() || [],
                            n = {},
                            o = [];
                        return t.length > 0 && t.forEach((function(t) {
                            var r = e.cache.get(t);
                            r && "badoo.bma.PersonNotice" === r.$gpb && void 0 !== r.folder && (n[r.folder] = r.int_value, o.push(r))
                        })), {
                            values: n,
                            notices: o
                        }
                    }, d.get = function() {
                        var e = this.getCached();
                        return 0 === Object.keys(e.values).length ? this.fetch() : Promise.resolve(e)
                    }, d.fetch = function() {
                        var e = this;
                        return r.A.isLoggedIn() ? new Promise((function(t) {
                            var n = new s.Ay(157, {
                                folder_id: l,
                                person_notice_type: [1]
                            }).onResponse(138, e.cacheResponse, e).onSpecialEvent(s.SE.REQ_FINISHED, (function() {
                                t(e.getCached())
                            }));
                            e.trackNextRequest && (i.A.trackRPC(n), e.trackNextRequest = !1), n.request()
                        })) : Promise.resolve(void 0)
                    }, d.trackNext = function() {
                        return this.trackNextRequest = !0, this
                    }, d.invalidateAll = function() {
                        this.cache.invalidateAll()
                    }, d.cacheResponse = function(e) {
                        if (void 0 !== e.folder && -1 !== l.indexOf(e.folder) && (1 === e.type || 3 === e.type || 5 === e.type)) {
                            var t = function(e) {
                                    var t = void 0 !== e.folder ? e.folder : "-";
                                    return "" + (e.type || "-") + t
                                }(e),
                                n = this.cache.get(t);
                            this.trigger(this.EVENTS.UPDATE, e, n), this.cache.put(t, e, {
                                ttl: 36e5
                            });
                            var o = e.int_value || 0,
                                r = (null == n ? void 0 : n.int_value) || 0;
                            if (!n || o !== r) {
                                var i = n ? o - r : o;
                                this.trigger(this.EVENTS.CHANGE, e, i)
                            }
                        }
                    }, t
                }(o.sV);
            t.A = new d
        },
        20931: function(e, t, n) {
            var o, r = n(57917),
                i = n(18084),
                a = n(15566),
                s = i.A.getLogger("UserSubstituteModel"),
                c = r.A.extend({
                    name: "UserSubstitute",
                    getRequestMessageType: 696,
                    getResponseMessageType: 697,
                    setRequestMessageType: 582,
                    setResponseMessageType: 387,
                    preventMultiple: !0,
                    commitCache: !1,
                    get: function(e) {
                        var t = e.id,
                            n = (new a.lQW).setId(t);
                        return c._super.get.call(this, n)
                    },
                    skipPromo: function(e) {
                        var t = e.id,
                            n = e.context;
                        this.set({
                            id: t,
                            context: n,
                            action: 1
                        })
                    },
                    acceptPromo: function(e) {
                        var t = e.id,
                            n = e.context;
                        this.set({
                            id: t,
                            context: n,
                            action: 2
                        })
                    },
                    set: function(e) {
                        var t = e.id,
                            n = e.context,
                            o = e.action;
                        t && n && o || s.error("Missing some of the properties for ServerUserSubstituteAction", {
                            id: t,
                            context: n,
                            action: o
                        });
                        var r = (new a.Pie).setId(t).setContext(n).setAction(o);
                        return c._super.set.call(this, r)
                    },
                    shouldCache_: function() {
                        return !1
                    }
                }, "UserSubstituteModel");
            c.getInstance = function() {
                return o || (o = new c)
            }, t.A = c
        },
        25085: function(e, t, n) {
            n.d(t, {
                Gq: function() {
                    return c
                },
                Iu: function() {
                    return p
                },
                Mm: function() {
                    return d
                },
                kw: function() {
                    return l
                },
                n$: function() {
                    return u
                }
            });
            n(15086), n(26099), n(98992), n(37550);
            var o, r = n(79860),
                i = ((o = {})[1] = 1, o[2] = 2, o[3] = 3, o[5] = 5, o[7] = 6, o),
                a = function(e, t) {
                    return e.getSystemBadges([]).some((function(e) {
                        return e.getType() === t
                    }))
                },
                s = function(e, t) {
                    return e ? 3 : 2 === t ? 2 : 1
                },
                c = function(e) {
                    var t = e.profileData,
                        n = e.voteType,
                        o = e.activationPlace,
                        c = e.isButtonVote,
                        u = t.user,
                        l = t.id,
                        d = u.hasMoodStatus();
                    (0, r.sx)(39, {
                        vote_result: i[n],
                        activation_place: o,
                        encrypted_user_id: l,
                        gesture: s(c, n),
                        mood_status: d,
                        liked_you_badge: a(u, 6),
                        crush_badge: a(u, 7)
                    })
                },
                u = function() {
                    (0, r.sx)(38, {
                        button_name: 76
                    })
                },
                l = function() {
                    (0, r.sx)(332, {
                        element: 75
                    })
                },
                d = function(e) {
                    var t = {
                        activation_place: 2,
                        encrypted_user_id: e.id
                    };
                    e.vote.yourVote && (t.vote_result = i[e.vote.yourVote]), (0, r.sx)(173, t)
                },
                p = function(e) {
                    (0, r.sx)(8, {
                        activation_place: 10,
                        encrypted_user_id: e,
                        message_first: !0,
                        send_smile: !0,
                        length: 0
                    })
                }
        },
        26172: function(e, t, n) {
            n(28706), n(2008), n(25276), n(62062), n(72712), n(26910), n(26099), n(98992), n(54520), n(81454), n(8872);
            var o = n(85608),
                r = n(47632),
                i = n(18084),
                a = i.A.getLogger("PromotionPageHelper"),
                s = [50],
                c = function() {
                    function e() {}
                    return e.getTitle = function(e) {
                        return e
                    }, e.getDataFromNotification = function(e) {
                        var t, n = null == e ? void 0 : e.image_urls,
                            o = null == n ? void 0 : n[0],
                            r = null == e ? void 0 : e.import_providers,
                            i = null == r || null == (t = r.providers) ? void 0 : t[0];
                        return {
                            avatars: [{
                                significance: 1,
                                src: o
                            }],
                            imageUrl: o,
                            providerType: null == i ? void 0 : i.type,
                            buttons: [{
                                actionText: (null == e ? void 0 : e.action_text) || "",
                                actionType: null == e ? void 0 : e.action,
                                type: 1
                            }],
                            notificationId: null == e ? void 0 : e.id,
                            titleText: (null == e ? void 0 : e.title) || "",
                            messageText: (null == e ? void 0 : e.message) || "",
                            actionType: null == e ? void 0 : e.action,
                            cancelActionText: null == e ? void 0 : e.cancel_action_text,
                            actionText: null == e ? void 0 : e.action_text,
                            empathizedText: null == e ? void 0 : e.display_comment
                        }
                    }, e.getDataFromPrePurchaseInfo = function(e) {
                        if (e) {
                            var t = e.application_feature || {},
                                n = null == t ? void 0 : t.feature,
                                i = e.album,
                                a = (null == i ? void 0 : i.photos) || [],
                                s = Boolean(i) ? a.map((function(e) {
                                    var t = l(e);
                                    return {
                                        src: e.large_url,
                                        badgeType: t,
                                        badgeName: r.A.getBadgeName(t),
                                        significance: 2
                                    }
                                })) : [],
                                c = (t.display_images || []).map((function(e) {
                                    var t = l(e);
                                    return {
                                        src: e.display_images,
                                        badgeType: t,
                                        badgeName: r.A.getBadgeName(t),
                                        significance: 2
                                    }
                                })),
                                u = t.product_type,
                                d = s.concat(c),
                                p = o.A.getPromoBlockForProduct(u),
                                f = d.slice(0, 3),
                                h = null;
                            return 3 === f.length && ((h = f[1]).badgeName = r.A.getBadgeTypeFromPromoBlock(p), h.significance = 1), {
                                avatars: f,
                                buttons: [{
                                    actionText: t.display_action || "",
                                    actionType: t.required_action,
                                    type: 1
                                }],
                                featureName: o.A.getFeatureName(p),
                                costOfService: e.cost,
                                cost: t.payment_amount,
                                featureType: n,
                                messageText: t.display_message || "",
                                pageTitle: e.header,
                                productType: u,
                                sharingPicture: h ? h.src : void 0,
                                titleText: t.display_title || ""
                            }
                        }
                    }, e.getDataFromPromoBlock = function(e, t) {
                        var n;
                        void 0 === t && (t = !1);
                        var i = function(e) {
                                var t = (e.pictures || []).sort(u).map((function(e) {
                                    var t = e.badge_type || 1;
                                    return {
                                        badgeName: r.A.getBadgeName(t),
                                        badgeType: t,
                                        significance: e.significance || -1,
                                        src: e.display_images
                                    }
                                }));
                                3 === t.length && (t = [t[2], t[0], t[1]]);
                                return t
                            }(e),
                            a = e.promo_block_type,
                            s = e.ok_payment_product_type,
                            c = function(e) {
                                var t = e.buttons || [];
                                if (t.length) return t.filter((function(e) {
                                    return 4 !== e.type
                                })).map((function(t) {
                                    var n = t.product_type || e.ok_payment_product_type,
                                        o = t.redirect_page;
                                    return {
                                        actionText: t.text || "",
                                        actionType: t.action,
                                        type: t.type,
                                        productType: n,
                                        redirectPage: null == o ? void 0 : o.redirect_page,
                                        isPremiumPlus: 47 === n
                                    }
                                }));
                                var n = [];
                                n.push({
                                    actionText: e.action || "",
                                    actionType: e.ok_action
                                }), e.other_text && e.other_action && n.push({
                                    actionText: e.other_text,
                                    actionType: e.other_action
                                });
                                return n
                            }(e),
                            l = (e.extra_texts || []).reduce((function(e, t) {
                                switch (t.type) {
                                    case 11:
                                        e.inBetweenText = t.text;
                                        break;
                                    case 28:
                                        e.offerText = t.text;
                                        break;
                                    case 31:
                                        e.disclaimerText = t.text
                                }
                                return e
                            }), {});
                        return {
                            avatars: i,
                            buttonName: o.A.getButtonName(a),
                            buttons: c,
                            cost: e.payment_amount,
                            costOfService: e.credits_cost,
                            extraTexts: l,
                            featureName: o.A.getFeatureName(a, t),
                            featureType: s && o.A.getFeatureFromPaymentProductType(s),
                            messageText: e.mssg || "",
                            pageTitle: e.screen_header || e.header,
                            productType: s,
                            sharingPicture: i.length ? (i[1] || i[0]).src : void 0,
                            titleText: e.header || "",
                            promoBlockType: a,
                            redirectPage: null == (n = e.redirect_page) ? void 0 : n.redirect_page
                        }
                    }, e.getDataFromCorrectSource = function(t) {
                        var n = t.clientNotification,
                            o = t.prePurchaseInfo,
                            r = t.promoBlock,
                            i = t.twoTiersIsAvailable;
                        if (n || o || r) {
                            if (n) {
                                var c = n.type;
                                return 81 === c || 89 === c ? e.getDataFromPromoBlock(n.promo_block) : c && -1 === s.indexOf(c) ? e.getDataFromPrePurchaseInfo(n.purchase_info) : e.getDataFromNotification(n)
                            }
                            return o ? e.getDataFromPrePurchaseInfo(o) : r ? e.getDataFromPromoBlock(r, i) : void 0
                        }
                        a.error("Invalid arguments, expected Notification, PrePurchaseInfo or PromoBlock object")
                    }, e
                }();

            function u(e, t) {
                return (e.significance || -1) < (t.significance || -1) ? -1 : (e.significance || -1) > (t.significance || -1) ? 1 : 0
            }

            function l(e) {
                return (null == e ? void 0 : e.badge_type) || 1
            }
            t.A = c
        },
        27041: function(e, t, n) {
            n.d(t, {
                X: function() {
                    return l
                }
            });
            n(52675), n(45700), n(2008), n(51629), n(74423), n(60739), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(3949), n(23500), n(72537), n(7714);
            var o = n(74389),
                r = n(58385),
                i = n(73090);

            function a(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, o)
                }
                return n
            }

            function s(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? a(Object(n), !0).forEach((function(t) {
                        c(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function c(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var o = n.call(e, t || "default");
                            if ("object" != typeof o) return o;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var u, l = 1e3,
                d = [o.x.MUTUAL_ATTRACTION, o.x.MESSAGES, o.x.GIFT_STORE, o.x.SEND_GIFT, o.x.PAY_OVERLAY, o.x.CHAT_PROFILE],
                p = [];
            t.A = function(e) {
                var t = function(e) {
                        if (e) {
                            var t = e.profileData,
                                n = e.theirPicture,
                                i = e.isCrushMatch,
                                a = e.canChat,
                                s = e.canSmile;
                            r.A.navigate(o.x.MUTUAL_ATTRACTION, {
                                back: r.A.getUrl(),
                                profileData: t,
                                matchDetails: {
                                    theirPicture: n,
                                    isCrushMatch: i
                                },
                                canChat: a,
                                canSmile: s
                            })
                        }
                    },
                    n = function() {
                        u || (t(p.shift()), u = setInterval((function() {
                            var e;
                            (e = r.A.getLocation(), d.includes(e.routeName)) || (p.length ? t(p.shift()) : u = clearInterval(u))
                        }), l))
                    },
                    a = function(e) {
                        return Boolean(!1)
                    },
                    c = function(t) {
                        var n, o = 211 === e,
                            r = 2 === (null == i.A || null == (n = i.A.getUser()) ? void 0 : n.gender);
                        return o && r && !a()
                    },
                    f = function(e) {
                        return 1 === e || 3 === e
                    };
                return {
                    canClientMatch: f,
                    isForceMatch: a,
                    isClientMatch: function(e, t, n) {
                        var o = 2 === t || 7 === t,
                            r = 2 === e.vote.theirVote || 7 === e.vote.theirVote;
                        return !c() && (f(n) && o && r)
                    },
                    isServerMatch: function(e, t) {
                        var n = 3 === t.vote_response_type;
                        return !c() && (n || a())
                    },
                    getProcessedProfileData: function(e) {
                        return s(s({}, e), {}, {
                            vote: s(s({}, e.vote), {}, {
                                allowChat: !0,
                                allowNo: !1,
                                isMatch: !0,
                                theirVote: 2,
                                yourVote: 2
                            })
                        })
                    },
                    showMatchScreen: function(e) {
                        var t, o, r = e.profileData,
                            i = e.voteType,
                            a = e.photo,
                            s = e.response,
                            c = a || (null == (t = r.firstPhotoSection) || null == t.toJSON ? void 0 : t.toJSON()),
                            u = 7 === i || 7 === r.vote.theirVote,
                            l = r.vote.allowChatFromMatchScreen,
                            d = r.vote.allowSmile;
                        o = {
                            profileData: r,
                            isCrushMatch: (null == s ? void 0 : s.is_crush_match) || u,
                            canChat: (null == s ? void 0 : s.allow_chat_from_match_screen) || l,
                            canSmile: (null == s ? void 0 : s.can_smile) || d,
                            theirPicture: null == c ? void 0 : c.large_url
                        }, p.push(o), n()
                    }
                }
            }
        },
        45850: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return C
                }
            });
            n(60739), n(26099), n(3362);
            var o = n(78029),
                r = n(58544),
                i = n(73090),
                a = n(58385),
                s = n(27378),
                c = n(74389),
                u = n(88651),
                l = n(74787),
                d = n(25085),
                p = n(3208),
                f = n(65297),
                h = n(32411),
                v = n(41025),
                m = n(13315),
                g = n(17399),
                y = n(63620),
                A = function(e, t) {
                    var n = [],
                        o = !1,
                        r = function() {
                            a.A.navigate(c.x.OWN_PROFILE_EDIT, {
                                feature: 15,
                                anchor: y.l.ADD_PHOTOS
                            })
                        },
                        i = function(i) {
                            var s, d = i.actionType,
                                f = i.productType,
                                y = i.photoUrl,
                                A = i.userId,
                                x = i.messageText,
                                T = i.featureType;
                            if (o) n.push({
                                actionType: d,
                                productType: f,
                                photoUrl: y,
                                userId: A,
                                messageText: x,
                                featureType: T
                            });
                            else switch (p.A.generate(), d) {
                                case 2:
                                    r();
                                    break;
                                case 17:
                                    (s = x) && (o = !0, t.trigger(g.q.UPDATE_SETTINGS_MESSAGE, s));
                                    break;
                                case 6:
                                    ! function(t, n) {
                                        var o;
                                        t && (100 === n && (o = 43), v.A.navigateToPayment({
                                            back: a.A.getUrl(),
                                            hotPanelData: {
                                                activationPlace: e
                                            },
                                            productType: 1,
                                            promoBlockType: o,
                                            userId: t
                                        }))
                                    }(A, T);
                                    break;
                                case 9:
                                case 4:
                                    ! function(t, n) {
                                        m.A.getInstance().setBackRoute(a.A.getUrl()), m.A.getInstance().setBackAction("quota"), 4 === t ? (u.A.getInstance().invalidate(), 2 !== e && h.A.getInstance().getProductExplanation({
                                            productType: t
                                        }).then((function(e) {
                                            a.A.navigate(c.x.VOTE_QUOTA_REACHED, {
                                                promoBlock: e.promo,
                                                source: a.A.getUrl()
                                            })
                                        })).catch(l.Qg)) : a.A.navigate(c.x.CREDIT_INTRO, {
                                            productType: t,
                                            photo: n || "",
                                            source: a.A.getUrl()
                                        })
                                    }(f, y);
                                    break;
                                case 0:
                                    break;
                                default:
                                    return void l.Rm.error("Unhandled required action " + d + ", feature " + T)
                            }
                        },
                        s = function() {
                            o = !1;
                            for (var e = 0, t = n.length; e < t; e++) i(n.shift())
                        };
                    return {
                        getIsInterrupted: function() {
                            return o
                        },
                        onRequiredAction: i,
                        addPhotos: r,
                        onEditFilter: function() {
                            t.trigger(g.q.UPDATE_SETTINGS_MESSAGE, ""), s(), f.A.trigger(f.A.ENCOUNTERS_FILTERS_OPEN)
                        },
                        onDenyFilter: function() {
                            t.trigger(g.q.UPDATE_SETTINGS_MESSAGE, ""), s()
                        }
                    }
                },
                x = function(e) {
                    var t = null,
                        n = function() {
                            t && (setTimeout((function() {
                                return e.trigger(g.q.QUOTA_PROCESSED)
                            }), 1e3), t.stop(), t = null)
                        },
                        o = function(t) {
                            if (t) return t === m.A.RESULTS.PENDING ? (e.trigger(g.q.QUOTA_PROCESSING), void setTimeout(n, 4e4)) : void n()
                        };
                    return function() {
                        if (!t && "quota" === m.A.getInstance().getBackAction()) {
                            var n = m.A.getInstance().getObservable("result");
                            t = e.observe(n, o, {
                                leading: !1,
                                once: !1
                            }), m.A.getInstance().clear()
                        }
                    }
                },
                T = n(27041),
                P = n(25093),
                _ = (0, o.tG)(r.sV),
                C = function(e) {
                    var t = new s.A("Encounters/vote", 11),
                        n = new _,
                        o = A(e, n),
                        r = o.getIsInterrupted,
                        p = o.onRequiredAction,
                        f = o.addPhotos,
                        h = o.onEditFilter,
                        v = o.onDenyFilter,
                        m = x(n),
                        g = (0, T.A)(e),
                        y = g.canClientMatch,
                        C = g.isForceMatch,
                        S = g.isClientMatch,
                        b = g.isServerMatch,
                        E = g.getProcessedProfileData,
                        O = g.showMatchScreen;
                    m();
                    return {
                        events: n,
                        initVote: function(n) {
                            var o = n.profileData,
                                s = n.voteType,
                                u = n.isButtonVote;
                            if (r()) throw l.Rm.error("Tried to vote when we were interrupted", {
                                profileData: o,
                                voteType: s
                            }), (0, l.Qg)(), o;
                            if (!i.A.isLoggedIn()) throw a.A.navigate(c.x.LANDING), (0, l.Qg)(), l.Rm.error("Tried to vote when we weren't logged in", {
                                profileData: o,
                                voteType: s
                            }), o;
                            (0, d.Gq)({
                                profileData: o,
                                voteType: s,
                                activationPlace: e,
                                isButtonVote: u
                            }), t.start()
                        },
                        sendVote: function(e) {
                            var t, n = e.profileData,
                                o = e.voteType,
                                r = e.isEngagedVote,
                                i = e.photo,
                                a = e.clientSource,
                                s = n.id,
                                c = n.isCached,
                                d = C(o) ? E(n) : n;
                            ! function(e) {
                                var t = e.profileData,
                                    n = e.voteType,
                                    o = e.clientSource,
                                    r = e.photo;
                                S(t, n, o) && O({
                                    profileData: t,
                                    voteType: n,
                                    photo: r
                                })
                            }({
                                profileData: d,
                                voteType: o,
                                clientSource: a,
                                photo: i
                            });
                            var f = null == (t = d.albums) || null == (t = t[0].getPhotos([])[0]) ? void 0 : t.getId(),
                                h = d.hiddenPhotoIds;
                            return u.A.getInstance().set({
                                voteType: o,
                                isEngagedVote: r,
                                id: s,
                                cached: c,
                                source: a,
                                photoId: (null == i ? void 0 : i.id) || "",
                                firstPhotoId: f || "",
                                hiddenPhotoIds: h || [],
                                canClientMatch: y(a)
                            }).then((function(e) {
                                var t = e.toJSON();
                                return function(e) {
                                    var t = e.response,
                                        n = e.profileData,
                                        o = e.voteType,
                                        r = e.clientSource,
                                        i = e.photo;
                                    !S(n, o, r) && b(o, t) && O({
                                        profileData: n,
                                        voteType: o,
                                        photo: i,
                                        response: t
                                    })
                                }({
                                    response: t,
                                    profileData: d,
                                    voteType: o,
                                    clientSource: a,
                                    photo: i
                                }), {
                                    response: t,
                                    profileData: d,
                                    voteType: o,
                                    photo: i
                                }
                            })).catch((function(e) {
                                return function(e, t) {
                                    var n = function(t) {
                                            return (0, l.Qg)(), (0, P.A)(t) && l.Rm.error("Unexpected error sending vote", {
                                                error: t
                                            }), Promise.reject(e)
                                        },
                                        o = null == t.toJSON ? void 0 : t.toJSON();
                                    if (!o) return n(t);
                                    var r = o.feature;
                                    if (r) {
                                        var i = r.display_images,
                                            a = null != i && i.length ? i[0].display_images : "";
                                        return p({
                                            actionType: r.required_action,
                                            productType: r.product_type,
                                            photoUrl: a
                                        }), Promise.reject(e)
                                    }
                                    return 6 === o.vote_response_type ? (p({
                                        actionType: 17,
                                        messageText: o.message
                                    }), Promise.reject(e)) : n(t)
                                }(n, e)
                            }))
                        },
                        onRequiredAction: p,
                        addPhotos: f,
                        onEditFilter: h,
                        onDenyFilter: v
                    }
                }
        },
        48259: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return y
                }
            });
            n(52675), n(45700), n(2008), n(51629), n(60739), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(10287), n(26099), n(98992), n(54520), n(3949), n(23500);
            var o = n(96540),
                r = n(5586),
                i = n(99417),
                a = n(58385),
                s = n(79860),
                c = n(26914),
                u = n(74848),
                l = function(e) {
                    var t = e.logoUrl,
                        n = e.title,
                        o = e.subtitle,
                        r = e.onLogoClick,
                        i = e.onSubtitleClick;
                    return (0, u.jsxs)("div", {
                        className: "campaign-header",
                        children: [t ? (0, u.jsx)("div", {
                            className: "campaign-header__media",
                            children: (0, u.jsx)(c.A, {
                                size: "xxsm",
                                image: {
                                    src: t
                                },
                                onClick: r
                            })
                        }) : null, (0, u.jsxs)("div", {
                            className: "campaign-header__content",
                            children: [(0, u.jsx)("div", {
                                className: "campaign-header__title",
                                children: n
                            }), o ? (0, u.jsx)("div", {
                                className: "campaign-header__subtitle",
                                children: (0, u.jsx)("button", {
                                    onClick: i,
                                    children: o
                                })
                            }) : null]
                        })]
                    })
                },
                d = n(65736),
                p = n(33736);

            function f(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, o)
                }
                return n
            }

            function h(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? f(Object(n), !0).forEach((function(t) {
                        v(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : f(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function v(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var o = n.call(e, t || "default");
                            if ("object" != typeof o) return o;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function m(e, t) {
                return m = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, m(e, t)
            }

            function g(e, t) {
                return t ? h(h({}, e.hotpanelData), {}, {
                    context: t
                }) : e.hotpanelData
            }
            var y = function(e) {
                function t(t) {
                    var n;
                    return (n = e.call(this, t) || this).state = {
                        showSponsoredModal: !1
                    }, n.onLogoClick = n.onLogoClick.bind(n), n.onSponsoredClick = n.onSponsoredClick.bind(n), n.onDismissModalClick = n.onDismissModalClick.bind(n), n
                }
                var n, c;
                c = e, (n = t).prototype = Object.create(c.prototype), n.prototype.constructor = n, m(n, c);
                var f = t.prototype;
                return f.render = function() {
                    var e = this.props.data,
                        t = e.header,
                        n = e.sponsoredAlert;
                    return t ? (0, u.jsxs)(o.Fragment, {
                        children: [(0, u.jsx)(l, {
                            logoUrl: t.logo,
                            title: t.title,
                            subtitle: t.subtitle,
                            onLogoClick: this.onLogoClick,
                            onSubtitleClick: this.onSponsoredClick
                        }), this.state.showSponsoredModal ? (0, u.jsx)(d.A, {
                            isDismissible: !1,
                            wrapperType: d.T.ACTION_SHEET,
                            header: {
                                title: n.header,
                                text: n.text
                            },
                            children: (0, u.jsx)(p.A, {
                                text: n.ctaText,
                                onClick: this.onDismissModalClick
                            })
                        }) : null]
                    }) : null
                }, f.onLogoClick = function(e) {
                    e.stopPropagation();
                    var t, n = this.props.data.header;
                    63 === (t = n).action && function(e) {
                        if (e)
                            if (e.getUrl()) i.A.open(e.getUrl(), "_blank", "noopener");
                            else {
                                var t = r.A.getRouteFromRedirectPage(e.toJSON());
                                a.A.navigate(t)
                            }
                    }(t.redirectPage)
                }, f.onSponsoredClick = function(e) {
                    e.stopPropagation(), this.setState({
                        showSponsoredModal: !0
                    });
                    var t = this.props,
                        n = t.data,
                        o = t.context;
                    ! function(e, t) {
                        (0, s.sx)(139, g(e, t))
                    }(n.sponsoredAlert, o),
                    function(e, t) {
                        (0, s.sx)(138, g(e, t))
                    }(n.sponsoredAlert, o)
                }, f.onDismissModalClick = function(e) {
                    e.stopPropagation(), this.setState({
                        showSponsoredModal: !1
                    })
                }, t
            }(o.Component)
        },
        49893: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return C
                }
            });
            n(10287);
            var o = n(96540),
                r = n(48259),
                i = n(46942),
                a = n.n(i),
                s = n(4571),
                c = n(96506),
                u = n(46770),
                l = n(40578),
                d = n(30784),
                p = n(20017),
                f = n(8483),
                h = n(93827),
                v = n(36528),
                m = n(48628),
                g = n(74848),
                y = function(e) {
                    var t = e.isCardMode,
                        n = e.innerRef,
                        r = e.headerBlock,
                        i = e.title,
                        y = e.text,
                        A = e.photoUrl,
                        x = e.onClick,
                        T = e.ctaText,
                        P = e.onCtaClick,
                        _ = e.swipeText,
                        C = e.isLoading,
                        S = e.isDisabled,
                        b = e.a11y,
                        E = a()({
                            "promo-card": !0,
                            "promo-card--card-mode": t
                        }),
                        O = !!i || !!y || !!_,
                        k = T && P;
                    return (0, g.jsxs)("div", {
                        className: E,
                        ref: n,
                        onClick: x,
                        children: [(0, g.jsx)(v.Ay, {
                            children: (0, g.jsx)(m.Ay, {
                                src: A,
                                hasPreload: !0,
                                a11y: {
                                    label: null == b ? void 0 : b.imageLabel
                                }
                            })
                        }), O ? (0, g.jsx)("div", {
                            className: "promo-card__media-shadow"
                        }) : null, (0, g.jsxs)("div", {
                            className: "promo-card__inner",
                            children: [r ? (0, g.jsxs)(o.Fragment, {
                                children: [(0, g.jsx)("div", {
                                    className: "promo-card__top-shadow"
                                }), (0, g.jsx)("div", {
                                    className: "promo-card__header",
                                    children: r
                                })]
                            }) : null, (0, g.jsx)("div", {
                                className: "promo-card__content",
                                children: (0, g.jsxs)(s.A, {
                                    color: "inverse",
                                    children: [(0, g.jsx)(l.A, {
                                        text: i
                                    }), (0, g.jsx)(d.A, {
                                        text: y
                                    }), k ? (0, g.jsx)(u.A, {
                                        children: (0, g.jsx)(p.A, {
                                            styling: "inverse",
                                            text: T,
                                            isLoading: C,
                                            isDisabled: S,
                                            onClick: P,
                                            dataQA: {
                                                "data-qa": "promo-card-cta"
                                            }
                                        })
                                    }) : null, _ ? (0, g.jsx)(c.A, {
                                        children: (0, g.jsxs)("div", {
                                            className: "promo-card__swipe",
                                            children: [k ? null : (0, g.jsx)(f.A, {
                                                name: "generic-chevron-up",
                                                size: "md"
                                            }), (0, g.jsx)(h.P3, {
                                                children: _
                                            })]
                                        })
                                    }) : null]
                                })
                            })]
                        })]
                    })
                },
                A = (n(62062), n(26099), n(98992), n(81454), n(31023)),
                x = n(26914),
                T = n(842),
                P = function(e) {
                    var t, n = e.isCardMode,
                        o = e.innerRef,
                        r = e.title,
                        i = e.text,
                        s = e.avatars,
                        c = e.ctaText,
                        u = e.onClick,
                        l = e.onCtaClick;
                    t = s.length < 2 ? "single" : "triple";
                    var d = {
                            position: s.length < 2 ? "br" : "bc",
                            icon: {
                                name: "badge-like",
                                size: s.length < 2 ? void 0 : "lg"
                            }
                        },
                        f = a()({
                            "promo-card": !0,
                            "promo-card--card-mode": n,
                            "promo-card--feature-liked-you": !0
                        });
                    return (0, g.jsxs)("div", {
                        className: f,
                        ref: o,
                        children: [(0, g.jsx)(T.A, {
                            onClick: u,
                            a11y: {
                                tabIndex: -1,
                                ariaHidden: !0
                            }
                        }), (0, g.jsxs)("div", {
                            className: "promo-card__inner",
                            children: [(0, g.jsxs)("div", {
                                className: "promo-card__media",
                                children: [null != s && s.length ? (0, g.jsx)(A.A, {
                                    layout: t,
                                    variant: "s-m-s",
                                    children: s.map((function(e, n) {
                                        var o = "single" === t ? "md" : void 0,
                                            r = {},
                                            i = "single" === t || 1 === n;
                                        return e.url && (r.photo = {
                                            src: e.url
                                        }), (0, g.jsx)(x.A, {
                                            size: o,
                                            user: r,
                                            badge: i ? d : void 0
                                        }, n)
                                    }))
                                }) : null, (0, g.jsx)("div", {
                                    className: "promo-card__media-title",
                                    children: r
                                })]
                            }), (0, g.jsxs)("div", {
                                className: "promo-card__content",
                                children: [(0, g.jsx)(h.P1, {
                                    breakWords: !0,
                                    align: "center",
                                    children: i
                                }), c && l ? (0, g.jsx)("div", {
                                    className: "promo-card__action",
                                    children: (0, g.jsx)(p.A, {
                                        text: c,
                                        onClick: l,
                                        dataQA: {
                                            "data-qa": "promo-card-cta"
                                        }
                                    })
                                }) : null]
                            })]
                        })]
                    })
                };

            function _(e, t) {
                return _ = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, _(e, t)
            }
            var C = function(e) {
                function t(t) {
                    var n;
                    return (n = e.call(this, t) || this).onCtaClick = n.onCtaClick.bind(n), n
                }
                var n, o;
                o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, _(n, o);
                var i = t.prototype;
                return i.render = function() {
                    var e = this.props,
                        t = e.context,
                        n = e.cardMode,
                        o = e.cardRef,
                        i = e.headerData,
                        a = e.onPhotoClick,
                        s = this.getCardData(),
                        c = s.photo,
                        u = s.title,
                        l = s.text,
                        d = s.ctaText,
                        p = s.swipeText,
                        f = s.promoBlockType,
                        h = s.avatars;
                    return 421 === f ? (0, g.jsx)(P, {
                        isCardMode: n,
                        innerRef: o,
                        avatars: h,
                        title: u,
                        text: l,
                        ctaText: d,
                        onClick: this.onCtaClick,
                        onCtaClick: this.onCtaClick
                    }) : (0, g.jsx)(y, {
                        isCardMode: n,
                        innerRef: o,
                        headerBlock: i ? (0, g.jsx)(r.A, {
                            data: i,
                            context: t
                        }) : null,
                        photoUrl: c,
                        title: u,
                        text: l,
                        swipeText: p,
                        ctaText: d,
                        onClick: a,
                        onCtaClick: this.onCtaClick
                    })
                }, i.getCardData = function() {
                    var e = this.props.promoCard || {},
                        t = e.key,
                        n = e.photo,
                        o = e.title,
                        r = e.text,
                        i = e.primaryCta,
                        a = e.swipeUp,
                        s = {
                            key: t,
                            photo: n,
                            title: o,
                            text: r,
                            promoBlockType: e.promoBlockType,
                            avatars: e.avatars
                        };
                    return i && (s.ctaText = i.text), a && (s.swipeText = a.text), s
                }, i.onCtaClick = function(e) {
                    var t, n;
                    e.stopPropagation(), null == (t = (n = this.props).onCtaClick) || t.call(n)
                }, t
            }(o.Component)
        },
        59678: function(e, t, n) {
            n(2008), n(50113), n(51629), n(74423), n(25276), n(62062), n(60739), n(79432), n(26099), n(21699), n(98992), n(54520), n(72577), n(3949), n(81454), n(23500);
            var o = n(23735),
                r = n(99417),
                i = n(23149),
                a = n(42302),
                s = n(40075),
                c = n(5586),
                u = n(58385),
                l = n(35837),
                d = n(15566),
                p = n(74389),
                f = n(88651),
                h = n(3208),
                v = n(41025),
                m = 193,
                g = [113, 112],
                y = l.A.Message;

            function A(e) {
                var t = e.userSubstitute;
                this.id = t.getId(), this.encountersPromoCard = function(e) {
                    var t = P({
                        promos: e.getPromos([]),
                        position: 21,
                        type: x
                    })[0];
                    if (4 === e.getType() && 421 !== t.getPromoBlockType()) return t;
                    return T(t)
                }(t), this.connectionPromoCard = function(e) {
                    var t = P({
                        promos: e.getPromos([]),
                        position: 1,
                        type: m
                    })[0];
                    return T(t)
                }(t), this.contentModePromoCards = function(e) {
                    var t = P({
                        promos: e.getPromos([]),
                        position: 13,
                        type: m
                    });
                    return t.map((function(e) {
                        return T(e)
                    }))
                }(t), this.sponsoredAlert = function(e) {
                    var t = P({
                        promos: e.getPromos([]),
                        position: 22,
                        type: 194
                    })[0];
                    if (!t) return;
                    var n = P({
                        promos: e.getPromos([]),
                        position: 21,
                        type: m
                    })[0];
                    if (!n) return;
                    var o = _({
                        ctas: n.getButtons([]),
                        type: 3
                    });
                    if (o) return {
                        ctaText: o.getText(),
                        hotpanelData: b(t),
                        popup: {
                            header: t.getHeader(),
                            text: t.getMssg(),
                            buttons: t.getButtons([]).map((function(e) {
                                return {
                                    text: e.getText(),
                                    action: e.getAction()
                                }
                            }))
                        }
                    }
                }(t)
            }
            A.prototype = {
                getHeaderData: function() {
                    var e = this.encountersPromoCard;
                    e || (e = this.contentModePromoCards[0]);
                    var t = this.sponsoredAlert,
                        n = e.header,
                        o = {};
                    if (n && (o.header = n, null != t && t.ctaText)) {
                        o.header.subtitle = t.ctaText;
                        var r = t.popup,
                            i = r.buttons[0];
                        o.sponsoredAlert = {
                            hotpanelData: t.hotpanelData,
                            header: r.header,
                            text: r.text,
                            ctaText: i ? i.text : s.Ay.get(451)
                        }
                    }
                    return o
                },
                performPrimaryCta: function(e) {
                    var t = e.promoCard,
                        n = e.context,
                        o = e.replaceNavigation,
                        i = e.callback;
                    ! function(e, t) {
                        var n = (e || {}).action,
                            o = t || {},
                            i = o.callback,
                            s = void 0 === i ? a.A : i,
                            l = o.bannerId;
                        switch (n) {
                            case 63:
                                ! function(e, t) {
                                    if (!e) return;
                                    if (e.getUrl()) return void r.A.open(e.getUrl(), "_blank", "noopener");
                                    var n = c.A.getRouteFromRedirectPage(e.toJSON());
                                    u.A.navigate(n, t.replaceNavigation)
                                }(e.redirectPage, t);
                                break;
                            case 60:
                                s(e);
                                break;
                            case 4:
                                ! function(e) {
                                    h.A.generate(), v.A.navigateToPayment({
                                        back: p.x.LIKED_YOU,
                                        productType: 1,
                                        promoBlockType: 7,
                                        hotPanelData: {
                                            activationPlace: 105,
                                            isOneClickPayment: !1,
                                            bannerId: e
                                        },
                                        callback: function(e) {
                                            e.success && f.A.getInstance().invalidate()
                                        }
                                    })
                                }(l)
                        }
                    }(t.primaryCta, {
                        replaceNavigation: o,
                        callback: i,
                        bannerId: t.promoBlockType
                    }), C({
                        promoCard: t,
                        context: n
                    })
                },
                toJSON: function() {
                    return E(this, (function(e) {
                        return e instanceof y && e.toJSON()
                    }))
                }
            }, A.reportEventShow = function(e) {
                var t = e.promoCard,
                    n = e.context;
                S({
                    promoCard: t,
                    context: n,
                    event: 2
                })
            }, A.reportEventClick = C, A.reportEventSkip = function(e) {
                var t = e.promoCard,
                    n = e.context;
                S({
                    promoCard: t,
                    context: n,
                    event: 8,
                    avoidStatsRequired: !0
                })
            }, A.reportEventDismiss = function(e) {
                var t = e.promoCard,
                    n = e.context;
                S({
                    promoCard: t,
                    context: n,
                    event: 4,
                    avoidStatsRequired: !0
                })
            }, A.fromJSON = function(e) {
                return E(e, (function(e) {
                    return !(!(0, i.A)(e) || "string" != typeof e.$gpb) && (0, l.A)(e)
                }))
            };
            var x = [193, 10, 421];

            function T(e) {
                if (!e) return null;
                var t = e.getButtons([]),
                    n = _({
                        ctas: t,
                        type: 1
                    }),
                    o = n && n.getAction(),
                    r = n && n.getText() || "";
                n = [63, 60, 4].includes(o) ? {
                    action: o,
                    text: r,
                    redirectPage: n.getRedirectPage()
                } : null;
                var i = _({
                        ctas: t,
                        type: 2
                    }),
                    a = null;
                if (i) {
                    var s = i.getIcon();
                    a = {
                        title: i.getText(),
                        logo: s ? s.getDisplayImages() : null,
                        action: i.getAction(),
                        redirectPage: i.getRedirectPage()
                    }
                }
                var c = _({
                        ctas: t,
                        type: 9
                    }),
                    u = _({
                        ctas: t,
                        type: 8
                    }),
                    l = _({
                        ctas: t,
                        type: 14
                    }),
                    d = _({
                        ctas: t,
                        type: 15
                    }),
                    p = e.getId(),
                    f = e.getVariantId(),
                    h = function(e) {
                        var t = e.getPictures([]);
                        return t.length > 0 ? t.map((function(e) {
                            return {
                                url: e.getDisplayImages()
                            }
                        })) : void 0
                    }(e);
                return {
                    key: p + "-" + f,
                    id: p,
                    variantId: f,
                    hotpanelData: b(e),
                    promoBlockType: e.getPromoBlockType(),
                    promoBlockPosition: e.getPromoBlockPosition(),
                    statsRequired: e.getStatsRequired(),
                    header: a,
                    title: e.getHeader(),
                    text: e.getMssg(),
                    photo: e.getImageId([])[0],
                    avatars: h,
                    primaryCta: n,
                    showOnTap: d && g.includes(d.getAction()),
                    swipeLeft: c ? {
                        action: c.getAction()
                    } : null,
                    swipeRight: u ? {
                        action: u.getAction()
                    } : null,
                    swipeUp: l ? {
                        text: l.getText(),
                        action: l.getAction()
                    } : null
                }
            }

            function P(e) {
                var t = e.promos,
                    n = e.position,
                    o = e.type,
                    r = Array.isArray(o) ? o : [o];
                return t.filter((function(e) {
                    var t = e.getPromoBlockPosition(),
                        o = e.getPromoBlockType();
                    return t === n && r.includes(o)
                }))
            }

            function _(e) {
                var t = e.ctas,
                    n = e.type;
                return t.find((function(e) {
                    return e.getType() === n
                }))
            }

            function C(e) {
                S({
                    promoCard: e.promoCard,
                    context: e.context,
                    event: 1
                })
            }

            function S(e) {
                var t = e.promoCard,
                    n = e.context,
                    r = e.event,
                    i = e.avoidStatsRequired;
                if (t.statsRequired) {
                    if (!i) {
                        var a = t.statsRequired.indexOf(r);
                        if (-1 === a) return;
                        t.statsRequired.splice(a, 1)
                    }
                    var s = (new d.BEm).setEvent(r).setContext(n);
                    t.promoBlockType && s.setPromoBlockType(t.promoBlockType), t.promoBlockPosition && s.setPromoBlockPosition(t.promoBlockPosition), t.id && s.setPromoId(t.id), t.variantId && s.setVariantId(t.variantId),
                        function(e) {
                            new o.Ay(278, (new d.YDi).setPromoBannerStats(e)).request()
                        }(s)
                }
            }

            function b(e) {
                var t = {
                    banner_id: e.getPromoBlockType()
                };
                return e.hasPromoBlockPosition() && (t.position_id = e.getPromoBlockPosition()), e.hasStatsVariationId() && (t.variation_id = e.getStatsVariationId()), t
            }

            function E(e, t) {
                var n = t(e);
                return !1 !== n ? n : e && Array.isArray(e) ? function(e, t) {
                    var n = e.length,
                        o = [],
                        r = -1;
                    for (; ++r < n;) o[r] = E(e[r], t);
                    return o
                }(e, t) : (0, i.A)(e) ? function(e, t) {
                    var n = {};
                    return Object.keys(e).forEach((function(o) {
                        n[o] = E(e[o], t)
                    })), n
                }(e, t) : e
            }
            t.A = A
        },
        74377: function(e, t, n) {
            n.r(t), n.d(t, {
                default: function() {
                    return zn
                }
            });
            n(28706), n(10287);
            var o = n(85558),
                r = n(56368),
                i = n(96540),
                a = n(99417),
                s = n(75248),
                c = n(40075),
                u = (n(60739), n(26099), n(3362), n(72537)),
                l = n(69705),
                d = n(58385),
                p = n(15566),
                f = n(88651),
                h = n(31087),
                v = n(79458),
                m = n(61155),
                g = n(85608),
                y = n(26935),
                A = n(17399),
                x = n(74787),
                T = n(25085),
                P = n(45850),
                _ = n(76854);
            var C = function() {
                    var e = null,
                        t = !1,
                        n = null,
                        o = (0, P.A)(2),
                        r = o.events,
                        i = o.initVote,
                        a = o.sendVote,
                        s = o.onRequiredAction,
                        p = o.addPhotos,
                        C = o.onEditFilter,
                        S = o.onDenyFilter,
                        b = function(e, n) {
                            var o = {
                                voteType: 2,
                                profileData: n,
                                notification: e.notification
                            };
                            t = !1, r.trigger(A.q.CRUSH_VOTE_COMPLETE, o), (0, T.Gq)({
                                profileData: n,
                                voteType: 7,
                                activationPlace: 2,
                                isButtonVote: !0
                            })
                        },
                        E = function(e) {
                            var o, i, a, s = e.response,
                                u = e.profileData,
                                d = e.voteType,
                                p = u.user,
                                g = u.vote,
                                y = u.name,
                                x = 2 === d,
                                T = s.can_chat || g.allowChat,
                                P = 3 === s.vote_response_type;
                            return x && (p.setAllowCrush(!1).setMyVote(d).setIsMatch(P).setAllowChat(T), h.A.getInstance().updateCache(p.getUserId(), p), f.A.getInstance().decreaseYesVoteQuota(), o = y, n || null == (a = n = new v.A({
                                place: l.A.PLACE_ENCOUNTERS,
                                activationPlace: 2
                            })) || a.start(), null == (i = n) || i.obtainPermission(c.Ay.get(500, {
                                str: o
                            })), m.A.update(s.goal_progress)), t = !1, r.trigger(A.q.ENCOUNTERS_VOTE_COMPLETE, {
                                profileData: u,
                                voteType: d
                            }), p
                        };
                    return {
                        events: r,
                        handleVote: function(n) {
                            var o = n.profileData,
                                r = n.voteType,
                                c = n.isEngagedVote,
                                l = n.isButtonVote,
                                d = n.photo,
                                f = n.clientSource,
                                h = void 0 === f ? 1 : f,
                                v = null == d || null == d.toJSON ? void 0 : d.toJSON(),
                                m = u.A.getSync(100),
                                g = t && !m.enabled && 2 === r;
                            try {
                                i({
                                    profileData: o,
                                    voteType: r,
                                    isButtonVote: l
                                }), g && function(e) {
                                    var t = u.A.getSync(15),
                                        n = u.A.getSync(100),
                                        o = 2 === t.required_action,
                                        r = n.feature,
                                        i = n.product_type,
                                        a = n.required_action;
                                    if (o) throw p(), e;
                                    throw 0 === a ? (0, x.Qg)() : s({
                                        userId: e.id,
                                        featureType: r,
                                        productType: i,
                                        actionType: a
                                    }), e
                                }(o)
                            } catch (e) {
                                return Promise.reject(e)
                            }
                            return e = o, a({
                                profileData: o,
                                voteType: r,
                                isEngagedVote: c,
                                photo: v,
                                clientSource: h
                            }).then(E)
                        },
                        crushVote: function(e) {
                            var t = e.profileData,
                                n = e.photo,
                                o = _.A.getInstance().getCurrentCrushes(),
                                r = {
                                    activationPlace: t.activationPlace
                                };
                            return (0, T.n$)(), (o > 0 ? function(e, t) {
                                return new Promise((function(n, o) {
                                    y.A.purchase({
                                        back: d.A.getUrl(),
                                        cost: t.cost,
                                        hotPanelData: t,
                                        userId: e.id,
                                        productType: 25,
                                        success: function(e) {
                                            return n(e)
                                        },
                                        error: o
                                    })
                                }))
                            }(t, r) : g.A.buyCrush(t.id, r, n)).then((function(e) {
                                return function(e) {
                                    return "transaction_identifier" in e
                                }(e) && b(e, t), e
                            })).catch((function(e) {
                                return Promise.resolve({
                                    vote: 1
                                })
                            }))
                        },
                        undoVote: function() {
                            if (e) return (0, T.kw)(), (0, T.Mm)(e), t = !0, r.trigger(A.q.UNDO_VOTE, e), e
                        },
                        onEditFilter: C,
                        onDenyFilter: S,
                        handleCrushSuccess: b
                    }
                },
                S = n(27041),
                b = n(39778),
                E = n(47901),
                O = n(15376),
                k = n(87184),
                j = n(74848),
                N = function(e) {
                    var t = e.header,
                        n = e.content;
                    return (0, j.jsxs)(E.A, {
                        children: [(0, j.jsx)(O.A, {
                            children: t
                        }), (0, j.jsx)(k.A, {
                            align: "stretch",
                            children: n
                        })]
                    })
                },
                D = n(37905),
                w = n(73090),
                I = n(3208),
                R = n(27378),
                M = n(18084),
                L = n(26035),
                V = n(59678),
                B = n(16720),
                U = {
                    RIGHT: 1,
                    LEFT: -1
                },
                F = U;
            var q = n(42333),
                Y = n(46942),
                H = n.n(Y),
                G = n(8483);

            function X(e) {
                var t = {};
                if (!e) return t;
                var n = e.indicatorOpacityAndScale;
                return n && (t.opacity = String(n), t.transform = "scale3d(" + n + "," + n + ",1)"), t
            }
            var W = function(e) {
                var t = e.isCardMoving,
                    n = e.cardPosition,
                    o = (null == n ? void 0 : n.voteType) || "yes",
                    r = H()({
                        "encounters-vote-indicator": !0,
                        "is-hidden": !t
                    });
                return (0, j.jsxs)("div", {
                    className: r,
                    "data-type": o,
                    style: X(n),
                    children: [(0, j.jsx)("div", {
                        className: "encounters-vote-indicator__icon encounters-vote-indicator__icon--yes",
                        children: (0, j.jsx)(G.A, {
                            name: "floating-action-yes"
                        })
                    }), (0, j.jsx)("div", {
                        className: "encounters-vote-indicator__icon encounters-vote-indicator__icon--no",
                        children: (0, j.jsx)(G.A, {
                            name: "floating-action-no"
                        })
                    })]
                })
            };

            function Q(e, t) {
                return Q = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, Q(e, t)
            }

            function J(e) {
                e.preventDefault(), e.stopPropagation()
            }
            var z = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).skeletonRef = void 0, n.disableTouchMove = n.disableTouchMove.bind(n), n.skeletonRef = void 0, n
                    }
                    var n, o;
                    o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, Q(n, o);
                    var r = t.prototype;
                    return r.disableTouchMove = function(e) {
                        !this.skeletonRef && e && (this.skeletonRef = e, e.addEventListener("touchmove", J))
                    }, r.componentWillUnmount = function() {
                        this.skeletonRef && (this.skeletonRef.removeEventListener("touchmove", J), this.skeletonRef = void 0)
                    }, r.render = function() {
                        return (0, j.jsx)("div", {
                            className: "profile-card is-skeleton",
                            ref: this.disableTouchMove,
                            children: (0, j.jsxs)("div", {
                                className: "profile-card-extra",
                                children: [(0, j.jsx)("div", {
                                    className: "profile-card-extra__content",
                                    children: (0, j.jsx)("div", {
                                        className: "profile-card-extra__content-skeleton",
                                        children: (0, j.jsxs)("svg", {
                                            "aria-hidden": !0,
                                            viewBox: "0 0 300 120",
                                            children: [(0, j.jsx)("rect", {
                                                width: "300",
                                                height: "18",
                                                y: "102",
                                                rx: "9"
                                            }), (0, j.jsx)("rect", {
                                                width: "300",
                                                height: "18",
                                                y: "62",
                                                rx: "9"
                                            }), (0, j.jsx)("rect", {
                                                width: "240",
                                                height: "28",
                                                x: "30",
                                                y: "0",
                                                rx: "16"
                                            })]
                                        })
                                    })
                                }), (0, j.jsx)("div", {
                                    className: "profile-card-extra__actions",
                                    children: (0, j.jsx)("div", {
                                        className: "profile-card-content__actions-stub"
                                    })
                                })]
                            })
                        })
                    }, t
                }(i.Component),
                K = (n(2892), n(74389)),
                Z = n(8054),
                $ = n(53010),
                ee = n(5598),
                te = 0,
                ne = 10;
            (0, Z.A)({
                updateVoteLimitPerAd: function(e) {
                    ne = Number(e)
                }
            });
            var oe = function() {
                    $.A.isEnabled() && ++te === ne && (te = 0, ee.A.hit(), ee.A.isActive() || d.A.navigate(K.x.FULLSCREEN_AD))
                },
                re = n(5556),
                ie = n.n(re),
                ae = n(42302),
                se = n(80093),
                ce = n(36521),
                ue = n(84914),
                le = n(13614),
                de = n(41562),
                pe = function(e) {
                    var t = e.userId,
                        n = e.gender,
                        o = e.cardRef,
                        r = e.isDummy,
                        i = e.isSkeleton,
                        a = e.isSwipingLeft,
                        s = e.isSwipingRight,
                        c = e.children,
                        u = H()({
                            "encounters-card": !0,
                            "encounters-card--swipe-right": s,
                            "encounters-card--swipe-left": a
                        });
                    return i ? (0, j.jsx)("div", {
                        className: u,
                        ref: o,
                        children: (0, j.jsx)("div", {
                            className: "encounters-card is-skeleton",
                            children: c
                        })
                    }) : (0, j.jsx)("div", {
                        className: u,
                        ref: o,
                        "data-qa": r ? "second-card" : "first-card",
                        "data-qa-user-id": t,
                        "data-qa-user-gender": n,
                        "aria-hidden": r,
                        inert: r ? "" : void 0,
                        children: c
                    })
                },
                fe = n(19266);

            function he(e, t) {
                return he = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, he(e, t)
            }
            var ve = "is-dragged",
                me = .2,
                ge = 35,
                ye = .95,
                Ae = 300,
                xe = {
                    onUpdateCardPosition: ie().func,
                    onTouchStart: ie().func,
                    onTouchEnd: ie().func,
                    onSwipeYes: ie().func,
                    onSwipeNo: ie().func,
                    playSwipeRightAnimation: ie().bool,
                    playSwipeLeftAnimation: ie().bool
                },
                Te = {
                    onUpdateCardPosition: ae.A,
                    onTouchStart: ae.A,
                    onTouchEnd: ae.A,
                    onSwipeYes: ae.A,
                    onSwipeNo: ae.A,
                    playSwipeRightAnimation: !1,
                    playSwipeLeftAnimation: !1
                },
                Pe = function(e) {
                    function t(t) {
                        var n;
                        (n = e.call(this, t) || this).handleTouchStart = function(e) {
                            if ((0, de.Z)(e)) {
                                var t = ce.A.supportsTouch ? e.touches[0] : e;
                                n.didMove = !1, n.mouseDown = !0, n.startX = 0, n.currX = 0, n.startY = 0, n.currY = 0, n.pointX = t.pageX, n.pointY = t.pageY, n.cardRef.current.style.transition = "none", ce.A.supportsTouch && n.cardRef.current.classList.add(ve), n.touchStartTime = Date.now(), n.movingHorizontally = !1, n.props.onTouchStart(e)
                            }
                        }, n.handleTouchMove = function(e, t) {
                            if (ce.A.supportsTouch || n.mouseDown) {
                                ce.A.supportsTouch || n.cardRef.current.classList.add(ve), n.transformDistance += t.x - e.x;
                                var o = t.x - n.pointX,
                                    r = t.y - n.pointY;
                                n.currX += o, n.currY += r, n.pointX = t.x, n.pointY = t.y;
                                var i = n.currX - n.startX,
                                    s = n.currY - n.startY;
                                n.updateStateAndDetermineIfPreventAnimation(i, s) ? n.transformDistance = 0 : a.A.requestAnimationFrame((function() {
                                    n.updateCardPosition()
                                }))
                            }
                        }, n.handleTouchEnd = function(e) {
                            n.mouseDown && (n.mouseDown = !1, n.cardRef.current.classList.remove(ve), n.cardRef.current.style.transition = "transform " + Ae / 1e3 + "s", n.props.onTouchEnd(e), n.resetMoveBuffer(), n.doSwipeIfNeeded(e) || (n.transformDistance = 0, n.updateCardPosition()))
                        }, n.cardRef = (0, i.createRef)(), n.touchStartTime = 0, n.startX = 0, n.currX = 0, n.startY = 0, n.currY = 0, n.pointX = 0, n.pointY = 0, n.transformDistance = 0, n.didMove = !1, n.movingHorizontally = !1, n.mouseDown = !1;
                        var o, r = (0, ue.A)(n.handleTouchMove);
                        return n.handleTouchMove = (o = r.callback, function(e) {
                            var t;
                            e.preventDefault();
                            var n = null == (t = e.touches) ? void 0 : t[0];
                            n || (n = {
                                pageX: e.pageX,
                                pageY: e.pageY
                            }), o({
                                x: Math.max(0, n.pageX),
                                y: Math.max(0, n.pageY)
                            })
                        }), n.resetMoveBuffer = r.reset, n
                    }
                    var n, o;
                    o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, he(n, o);
                    var r = t.prototype;
                    return r.componentDidMount = function() {
                        var e = this;
                        if (fe.Ay.hit(), fe.Ay.isBadoo() ? (me = .3, ge = 45, Ae = 300) : fe.Ay.isBumble() ? (me = .2, ge = 35, Ae = 150) : fe.Ay.isWebOptimised() && (me = .1, ge = 18, Ae = 150), this.props.isDummy) this.updateDummyZoom(0);
                        else {
                            var t = this.cardRef.current;
                            ce.A.supportsTouch ? (t.addEventListener("touchstart", this.handleTouchStart), t.addEventListener("touchmove", this.handleTouchMove), t.addEventListener("touchend", this.handleTouchEnd)) : (t.addEventListener("mousedown", this.handleTouchStart), a.A.document.addEventListener("mousemove", this.handleTouchMove), a.A.document.addEventListener("mouseup", this.handleTouchEnd)), this.props.moveCardIn ? (this.cardRef.current.classList.add(ve), this.transformDistance = this.props.moveCardIn * Ce(), this.updateCardPosition(), new Promise((function(e) {
                                return a.A.requestAnimationFrame(e)
                            })).then((function() {
                                e.resetPosition()
                            }))) : this.props.moveCardOut && this.doSwipe(null, this.props.moveCardOut)
                        }
                    }, r.componentDidUpdate = function(e) {
                        !e.moveCardOut && this.props.moveCardOut && this.doSwipe(null, this.props.moveCardOut), this.props.isDummy && this.updateDummyZoom(this.props.dummyZoomIn)
                    }, r.componentWillUnmount = function() {
                        if (!this.props.isDummy) {
                            var e = this.cardRef.current;
                            ce.A.supportsTouch ? (e.removeEventListener("touchstart", this.handleTouchStart), e.removeEventListener("touchmove", this.handleTouchMove), e.removeEventListener("touchend", this.handleTouchEnd)) : (e.removeEventListener("mousedown", this.handleTouchStart), a.A.document.removeEventListener("mousemove", this.handleTouchMove), a.A.document.removeEventListener("mouseup", this.handleTouchEnd))
                        }
                    }, r.moveStarted = function(e, t) {
                        return this.didMove ? this.didMove : Math.sqrt(e * e + t * t) > 7
                    }, r.updateStateAndDetermineIfPreventAnimation = function(e, t) {
                        return !this.moveStarted(e, t) || (this.didMove || (this.movingHorizontally = Math.abs(e) > Math.abs(t)), this.didMove = !0, !this.movingHorizontally)
                    }, r.updateCardPosition = function() {
                        if (this.cardRef.current) {
                            var e = this.transformDistance / Ce(),
                                t = Math.abs(e),
                                n = _e(ge * e, -60, 60);
                            this.cardRef.current.style.transform = "translate3d(" + this.transformDistance + "px,0,0) rotate(" + n + "deg)";
                            var o = _e(3 * t, 0, 1);
                            this.props.onUpdateCardPosition({
                                indicatorOpacityAndScale: o,
                                voteType: e < 0 ? "no" : "yes"
                            })
                        }
                    }, r.updateDummyZoom = function(e) {
                        if (this.cardRef.current && this.props.isDummy) {
                            var t = .93 + e * (1 - .93),
                                n = ye + .050000000000000044 * e,
                                o = 5.000000000000004 * (1 - e) / 2;
                            this.cardRef.current.style.transform = "scale(" + t + ", " + n + ") translate3d(0, -" + o + "%, 0)"
                        }
                    }, r.doSwipe = function(e, t) {
                        var n = this;
                        this.cardRef.current.classList.remove(ve), this.cardRef.current.style.transition = "transform " + Ae / 1e3 + "s", this.transformDistance = t * Ce(), a.A.requestAnimationFrame((function() {
                            n.updateCardPosition()
                        })), (0, le.Yn)(this.cardRef.current, (function() {
                            t === F.RIGHT ? n.props.onSwipeYes(e) : n.props.onSwipeNo(e), n.resetPosition()
                        }))
                    }, r.doSwipeIfNeeded = function(e) {
                        var t = this.transformDistance / Ce(),
                            n = Math.abs(t),
                            o = function(e) {
                                if (0 === (e = +e) || isNaN(e)) return F.RIGHT;
                                return e > 0 ? F.RIGHT : F.LEFT
                            }(t),
                            r = Math.abs(this.transformDistance) / (Date.now() - this.touchStartTime);
                        return (n >= me || r > 1) && (this.doSwipe(e, o), !0)
                    }, r.resetPosition = function() {
                        var e = this.cardRef.current;
                        e && (e.classList.remove(ve), this.cardRef.current.style.transition = "transform " + Ae / 1e3 + "s", e.style.transform = null), this.props.onUpdateCardPosition({}), this.transformDistance = 0
                    }, r.render = function() {
                        var e = this.props,
                            t = e.userId,
                            n = e.gender,
                            o = e.isDummy,
                            r = e.isSkeleton,
                            i = e.playSwipeRightAnimation,
                            a = e.playSwipeLeftAnimation,
                            s = e.children;
                        return (0, j.jsx)(pe, {
                            userId: t,
                            gender: n,
                            isDummy: o,
                            isSkeleton: r,
                            isSwipingLeft: a,
                            isSwipingRight: i,
                            cardRef: this.cardRef,
                            children: s
                        })
                    }, t
                }(i.Component);

            function _e(e, t, n) {
                return Math.min(n, Math.max(t, e))
            }

            function Ce() {
                return Math.min(a.A.innerWidth, se.g)
            }
            Pe.propTypes = xe, Pe.defaultProps = Te;
            var Se = Pe,
                be = (n(52675), n(45700), n(2008), n(51629), n(89572), n(67945), n(84185), n(83851), n(81278), n(79432), n(98992), n(54520), n(3949), n(23500), n(79860)),
                Ee = n(20931),
                Oe = n(49893);

            function ke(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, o)
                }
                return n
            }

            function je(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? ke(Object(n), !0).forEach((function(t) {
                        Ne(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : ke(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function Ne(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var o = n.call(e, t || "default");
                            if ("object" != typeof o) return o;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function De(e, t) {
                return De = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, De(e, t)
            }

            function we(e) {
                var t, n = null == (t = e.touches) ? void 0 : t[0];
                return n || (n = {
                    pageX: e.pageX,
                    pageY: e.pageY
                }), n
            }

            function Ie(e) {
                (0, be.sx)(139, Re(e))
            }

            function Re(e) {
                return je(je({}, e.hotpanelData), {}, {
                    context: 1
                })
            }
            var Me = function(e) {
                    function t(t) {
                        var n;
                        (n = e.call(this, t) || this).handleSwipeYes = function(e) {
                            var t = n.props.profileData,
                                o = t.encountersPromoCard;
                            421 === o.promoBlockType && (Ie(o), t.performPrimaryCta({
                                promoCard: o,
                                context: 1
                            })), n.acceptPromo(), n.props.onSwipeYes && n.props.onSwipeYes(e)
                        }, n.handleSwipeNo = function(e) {
                            n.skipPromo(), n.props.onSwipeNo && n.props.onSwipeNo(e)
                        };
                        var o = t.profileData,
                            r = void 0 === o ? {} : o;
                        n.state = {
                            isRawPromoBlock: r.encountersPromoCard instanceof p.d4N && 421 !== r.encountersPromoCard.getPromoBlockType()
                        }, n.cardRef = (0, i.createRef)(), n.onCtaClick = n.onCtaClick.bind(n), n.onPhotoClick = n.onPhotoClick.bind(n), n.onTouchStart = n.onTouchStart.bind(n), n.onTouchMove = n.onTouchMove.bind(n), n.onTouchEnd = n.onTouchEnd.bind(n);
                        var a, s = (0, ue.A)(n.onTouchMove);
                        return n.onTouchMove = (a = s.callback, function(e) {
                            e.preventDefault();
                            var t = we(e);
                            a({
                                x: Math.max(0, t.pageX),
                                y: Math.max(0, t.pageY)
                            })
                        }), n.resetMoveBuffer = s.reset, n
                    }
                    var n, o;
                    o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, De(n, o);
                    var r = t.prototype;
                    return r.componentDidMount = function() {
                        var e, t = this.state,
                            n = t.isRawPromoBlock,
                            o = t.profileData;
                        n ? this.showCustomPromoBlock() : (o && 421 !== o.encountersPromoCard.promoBlockType && this.bindTouchEvents(), e = this.props.profileData.encountersPromoCard, (0, be.sx)(138, Re(e)))
                    }, r.componentWillUnmount = function() {
                        this.state.isRawPromoBlock || this.unbindTouchEvents()
                    }, r.showCustomPromoBlock = function() {
                        var e = this.props,
                            t = e.profileData,
                            n = void 0 === t ? {} : t,
                            o = e.onDisplayGenericPromo;
                        if (!e.isDummy) {
                            var r = n.encountersPromoCard,
                                i = r.getPromoBlockType();
                            if ("function" == typeof o) o(n.id || n.getId && n.getId(""));
                            if (10 === i) d.A.navigate(K.x.ENCOUNTERS_EXTRA_SHOWS, !1, {
                                promoBlock: r.toJSON()
                            })
                        }
                    }, r.render = function() {
                        var e = this.props,
                            t = e.profileData,
                            n = e.isDummy,
                            o = e.onTouchStartCard,
                            r = e.onTouchEndCard,
                            i = e.onUpdateCardPosition;
                        return this.state.isRawPromoBlock ? null : (0, j.jsx)(Se, {
                            isDummy: n,
                            onTouchStart: o,
                            onTouchEnd: r,
                            onUpdateCardPosition: i,
                            onSwipeYes: this.handleSwipeYes,
                            onSwipeNo: this.handleSwipeNo,
                            children: (0, j.jsx)(Oe.A, {
                                context: 1,
                                cardMode: !0,
                                cardRef: this.cardRef,
                                headerData: t.getHeaderData(),
                                promoCard: t.encountersPromoCard,
                                onCtaClick: this.onCtaClick,
                                onPhotoClick: this.onPhotoClick
                            })
                        })
                    }, r.skipPromo = function() {
                        Ee.A.getInstance().skipPromo({
                            id: this.props.profileData.id,
                            context: 1
                        }), V.A.reportEventSkip({
                            promoCard: this.props.profileData.encountersPromoCard,
                            context: 1
                        })
                    }, r.acceptPromo = function() {
                        Ee.A.getInstance().acceptPromo({
                            id: this.props.profileData.id,
                            context: 1
                        })
                    }, r.onCtaClick = function() {
                        var e = this.props.profileData,
                            t = e.encountersPromoCard,
                            n = this.getCallbackForCtaClick_(t);
                        Ie(t), e.performPrimaryCta({
                            promoCard: t,
                            context: 1,
                            callback: n
                        }), 421 === t.promoBlockType && (this.acceptPromo(), this.props.onSwipeYes && this.props.onSwipeYes())
                    }, r.onPhotoClick = function() {
                        this.goToPromoCardsGallery()
                    }, r.goToPromoCardsGallery = function() {
                        d.A.navigate(K.x.PROMO_CARDS_GALLERY, {
                            userSubstitute: this.props.profileData,
                            context: 1
                        })
                    }, r.onTouchStart = function(e) {
                        var t = we(e);
                        this.didMove = !1, this.isSwipedUp = !1, this.distX = this.startX = this.currX = 0, this.distY = this.startY = this.currY = 0, this.pointX = t.pageX, this.pointY = t.pageY
                    }, r.onTouchMove = function(e, t) {
                        var n = t.x - this.pointX,
                            o = t.y - this.pointY;
                        this.currX += n, this.currY += o, this.pointX = t.x, this.pointY = t.y;
                        var r = this.currX - this.startX,
                            i = this.currY - this.startY;
                        this.navigateIfSwipedUp(r, i) || (this.distX = r, this.distY = i)
                    }, r.onTouchEnd = function() {
                        this.resetMoveBuffer()
                    }, r.navigateIfSwipedUp = function(e, t) {
                        return this.didMove || (this.isSwipedUp = Math.abs(e) < 50 && Math.abs(t) > 50 && t < 0), !!this.isSwipedUp && (this.didMove = !0, this.unbindTouchEvents(), this.goToPromoCardsGallery(), !0)
                    }, r.setIsSwiping = function(e) {
                        e ? this.unbindTouchEvents() : this.bindTouchEvents()
                    }, r.bindTouchEvents = function() {
                        if (!this.state.isRawPromoBlock) {
                            var e = this.cardRef.current;
                            e.addEventListener("touchstart", this.onTouchStart), e.addEventListener("touchmove", this.onTouchMove), e.addEventListener("touchend", this.onTouchEnd)
                        }
                    }, r.unbindTouchEvents = function() {
                        if (!this.state.isRawPromoBlock) {
                            var e = this.cardRef.current;
                            e.removeEventListener("touchstart", this.onTouchStart), e.removeEventListener("touchmove", this.onTouchMove), e.removeEventListener("touchend", this.onTouchEnd)
                        }
                    }, r.getCallbackForCtaClick_ = function(e) {
                        var t = this,
                            n = (e || {}).primaryCta;
                        if (60 === (void 0 === n ? {} : n).action) {
                            return function() {
                                t.handleSwipeYes()
                            }
                        }
                    }, t
                }(i.Component),
                Le = (n(50113), n(15086), n(42781), n(72577), n(37550), n(46632)),
                Ve = n(74022),
                Be = (n(74423), n(25276), n(21699), n(5586), n(19420)),
                Ue = function(e, t) {
                    var n = [],
                        o = [],
                        r = 0,
                        i = 0,
                        a = !1;
                    (e.getProfileFields([]).forEach((function(e) {
                        var t = e.getType();
                        Be.sj.includes(t) && e.getDisplayValue() && n.push(e), 29 === t && (a = !0)
                    })), r = n.length, n.forEach((function(e) {
                        if (11 === e.getType()) {
                            var n = e.getValue("").split(",");
                            if (n.length > 1 && (r += n.length - 1), t) t.getProfileFields([]).forEach((function(e) {
                                11 === e.getType() && e.getValue("").split(",").forEach((function(e) {
                                    -1 !== n.indexOf(e) && (i += 1)
                                }))
                            }))
                        }
                    })), t) && (o = t.getProfileFields([]).filter((function(e) {
                        return n.some((function(t) {
                            return t.getType() === e.getType() && 11 !== t.getType() && 13 !== t.getType() && t.getDisplayValue() === e.getDisplayValue() && t.getDisplayValue()
                        }))
                    })), i += o.length);
                    return {
                        shownBadgeCount: r,
                        mutualBadgeCount: i,
                        hasSocialCampaignBadge: a
                    }
                },
                Fe = n(36721),
                qe = n(79069),
                Ye = n(21354),
                He = function(e) {
                    var t = e.dummyZoomIn,
                        n = e.profileData,
                        o = e.renderWidth,
                        r = e.renderHeight,
                        i = e.profileActionHandlers;
                    return (0, j.jsx)(Se, {
                        isDummy: !0,
                        dummyZoomIn: t,
                        userId: n.id,
                        gender: n.gender,
                        children: (0, j.jsx)(Ye.A, {
                            renderHeight: r,
                            renderWidth: o,
                            scaleButtons: 1,
                            profileActionHandlers: i,
                            onScroll: ae.A,
                            onScrollerRef: ae.A,
                            onScreenNameChange: ae.A,
                            user: n.user,
                            mode: qe._.ENCOUNTERS,
                            isDummy: !0
                        })
                    })
                };

            function Ge(e, t) {
                return Ge = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, Ge(e, t)
            }
            var Xe = (0, Le.A)((function(e) {
                var t = e.user.getProfileFields([]);
                return {
                    profileData: e,
                    work: We(t, 12),
                    education: We(t, 10),
                    profilePhoto: e.profilePhoto && e.profilePhoto.toJSON(),
                    user: e.user.toJSON(),
                    interestsForPreview: q.Ay.getInterestsForPhoto(e.user.getInterests([]))
                }
            }));

            function We(e, t) {
                var n = e.find((function(e) {
                    return e.getType() === t && (!e.getRequiredAction() || 0 === e.getRequiredAction())
                }));
                return n && n.getDisplayValue()
            }

            function Qe(e, t) {
                return e.getSystemBadges([]).some((function(e) {
                    return e.getType() === t
                }))
            }

            function Je(e) {
                (0, be.sx)(195, {
                    direction: 5,
                    reached_end: e || !1,
                    parent_element: 40
                })
            }
            var ze = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).getProfileActionHandlers = function() {
                            return {
                                onVoteYes: function() {
                                    return n.handleVote(2)
                                },
                                onVoteNo: function() {
                                    return n.handleVote(3)
                                },
                                onCrush: n.props.onClickCrush
                            }
                        }, n.handleScrollerRef = function(e) {
                            n.setState({
                                renderWidth: e.offsetWidth,
                                renderHeight: e.offsetHeight
                            })
                        }, n.handleScroll = function(e) {
                            var t, o = e.scrollTop,
                                r = e.scrollBottom,
                                i = n.props.onScroll,
                                a = 100 - Math.min(100, Math.round(100 * o / 130)),
                                s = Math.max(0, Math.round(100 * (70 - r) / 70));
                            n.seenProfileInfo || (t = n.props.profileData.user.getUserId(), (0, be.sx)(14, {
                                encrypted_user_id: t,
                                gesture: 4,
                                activation_place: 2,
                                mode_connection: 6
                            }), n.seenProfileInfo = !0), 100 === s ? (n.reachedBottom || ((0, be.sx)(94), n.reachedBottom = !0), n.trackScroll(!0)) : n.trackScroll();
                            var c = Math.round(Math.min(a, 100) / 10) / 10,
                                u = Math.round(Math.min(Math.max(a, s), 100) / 10) / 10;
                            c === n.state.titleOpacity && u === n.state.scaleButtons || n.setState({
                                titleOpacity: c,
                                scaleButtons: Fe.A.isDesktop ? 1 : u
                            }), i && i()
                        }, n.handleVote = function(e) {
                            var t, o = n.props,
                                r = o.onVoteBeforeSwipe,
                                i = o.onVoteYes,
                                a = o.onVoteNo;
                            r();
                            var s = 2 === e ? i : a,
                                c = 2 === e ? "isSwipeRightAnimated" : "isSwipeLeftAnimated";
                            n.setState(((t = {})[c] = !0, t), (function() {
                                setTimeout(s, 300)
                            }))
                        }, n.handleKeyPress = function(e) {
                            if (!e.repeat) {
                                var t = n.getProfileActionHandlers(),
                                    o = t.onVoteYes,
                                    r = t.onVoteNo,
                                    i = t.onCrush;
                                switch (e.key) {
                                    case "1":
                                        o();
                                        break;
                                    case "2":
                                        r();
                                        break;
                                    case "3":
                                        i()
                                }
                            }
                        }, n.state = {
                            titleOpacity: 1,
                            scaleButtons: 1,
                            renderWidth: 1,
                            renderHeight: 1,
                            isSwipeRightAnimated: !1,
                            isSwipeLeftAnimated: !1
                        }, n.trackScroll = (0, Ve.A)(Je, 300), n.seenProfileInfo = !1, n.reachedBottom = !1, n
                    }
                    var n, o;
                    o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, Ge(n, o);
                    var r = t.prototype;
                    return r.componentDidMount = function() {
                        this.props.isDummy || (! function(e) {
                            var t = e.user;
                            if (!t) return;
                            var n = t.getProfileFields([]);

                            function o(e) {
                                return function(t) {
                                    return t.getType() === e && (!t.getRequiredAction() || 0 === t.getRequiredAction())
                                }
                            }
                            var r = t.hasInterests() && t.getInterests().length > 0,
                                i = t.hasInterestsInCommon() && t.getInterestsInCommon() > 0,
                                a = {
                                    encrypted_user_id: t.getUserId(),
                                    verified: t.getIsVerified(!1),
                                    photo_count: t.getPhotoCount(0),
                                    activation_place: e.activationPlace,
                                    chat_button_available: !1,
                                    education_shown: n.some(o(10)),
                                    job_shown: n.some(o(12)),
                                    mood_status: t.hasMoodStatus(),
                                    interests_shown: r,
                                    common_interests_shown: i
                                },
                                s = Ue(t, e.sessionUser),
                                c = s.shownBadgeCount,
                                u = s.mutualBadgeCount,
                                l = s.hasSocialCampaignBadge;
                            a.lifestyle_badges_count = c, a.mutual_badges_count = u, a.event_badge = l, a.liked_you_badge = Qe(t, 6), a.crush_badge = Qe(t, 7), Qe(t, 5) && (a.indicator_badge = 5);
                            (0, be.sx)(56, a)
                        }(this.props.profileData), Fe.A.isDesktop && a.A.document.addEventListener("keydown", this.handleKeyPress))
                    }, r.componentWillUnmount = function() {
                        a.A.document.removeEventListener("keydown", this.handleKeyPress)
                    }, r.render = function() {
                        var e = this.props,
                            t = e.isDummy,
                            n = e.dummyZoomIn,
                            o = e.moveCardIn,
                            r = e.moveCardOut,
                            i = e.onTouchStartCard,
                            a = e.onTouchEndCard,
                            s = e.onSwipeYes,
                            c = e.onSwipeNo,
                            u = e.onUpdateCardPosition,
                            l = e.onScreenNameChange,
                            d = this.state,
                            p = d.renderWidth,
                            f = d.renderHeight,
                            h = d.scaleButtons,
                            v = d.titleOpacity;
                        if (!this.props.profileData) return null;
                        var m = Xe(this.props.profileData).profileData,
                            g = this.getProfileActionHandlers();
                        return t ? (0, j.jsx)(He, {
                            dummyZoomIn: n,
                            profileData: m,
                            renderWidth: this.state.renderWidth,
                            renderHeight: this.state.renderHeight,
                            profileActionHandlers: g
                        }) : (0, j.jsx)(Se, {
                            moveCardIn: o,
                            moveCardOut: r,
                            userId: m.id,
                            gender: m.gender,
                            onUpdateCardPosition: u,
                            onTouchStart: i,
                            onTouchEnd: a,
                            onSwipeYes: s,
                            onSwipeNo: c,
                            playSwipeRightAnimation: this.state.isSwipeRightAnimated,
                            playSwipeLeftAnimation: this.state.isSwipeLeftAnimated,
                            children: (0, j.jsx)(Ye.A, {
                                renderHeight: f,
                                renderWidth: p,
                                scaleButtons: h,
                                titleOpacity: v,
                                profileActionHandlers: g,
                                onScroll: this.handleScroll,
                                onScrollerRef: this.handleScrollerRef,
                                onScreenNameChange: l,
                                user: m.user,
                                mode: qe._.ENCOUNTERS
                            })
                        })
                    }, t
                }(i.Component),
                Ke = function(e) {
                    var t = e.profileData,
                        n = e.isDummy,
                        o = e.dummyZoomIn,
                        r = e.moveCardIn,
                        a = e.moveCardOut,
                        s = e.onVoteBeforeSwipe,
                        c = e.onVoteNo,
                        u = e.onVoteYes,
                        l = e.onSwipeYes,
                        d = e.onSwipeNo,
                        p = e.onClickCrush,
                        f = e.onTouchStartCard,
                        h = e.onTouchEndCard,
                        v = e.onUpdateCardPosition,
                        m = e.onScroll,
                        g = e.onScreenNameChange,
                        y = e.onDisplayGenericPromo;
                    if ((0, i.useEffect)((function() {
                            !n && t instanceof V.A && V.A.reportEventShow({
                                promoCard: t.encountersPromoCard,
                                context: 1
                            })
                        }), [n, t]), !t) return null;
                    return n ? function() {
                        if (t instanceof V.A) return (0, j.jsx)(Me, {
                            profileData: t,
                            isDummy: !0
                        }, "promo-card");
                        var e, n = (null == t || null == (e = t.vote) ? void 0 : e.allowCrush) && ae.A;
                        return (0, j.jsx)(ze, {
                            profileData: t,
                            isDummy: !0,
                            dummyZoomIn: o,
                            onClickCrush: n
                        }, t.id)
                    }() : t instanceof V.A ? (V.A.reportEventShow({
                        promoCard: t.encountersPromoCard,
                        context: 1
                    }), (0, j.jsx)(Me, {
                        profileData: t,
                        onVoteNo: c,
                        onVoteYes: u,
                        onSwipeYes: l,
                        onSwipeNo: d,
                        onTouchStartCard: f,
                        onTouchEndCard: h,
                        onUpdateCardPosition: v,
                        onDisplayGenericPromo: y
                    }, "promo-card")) : (0, j.jsx)(ze, {
                        profileData: t,
                        moveCardIn: r,
                        moveCardOut: a,
                        onVoteBeforeSwipe: s,
                        onVoteNo: c,
                        onVoteYes: u,
                        onSwipeYes: l,
                        onSwipeNo: d,
                        onClickCrush: p,
                        onTouchStartCard: f,
                        onTouchEndCard: h,
                        onUpdateCardPosition: v,
                        onScroll: m,
                        onScreenNameChange: g
                    }, t.id)
                },
                Ze = n(20017),
                $e = n(4571),
                et = n(46770),
                tt = n(40578),
                nt = n(27895),
                ot = n(30784),
                rt = n(36528),
                it = n(48628),
                at = function(e) {
                    return (0, j.jsx)("div", {
                        className: "encounters-card",
                        children: e.children
                    })
                },
                st = function(e) {
                    var t = e.picturePath,
                        n = e.title,
                        o = e.message,
                        r = e.primaryAction,
                        i = e.secondaryAction,
                        a = e.onPrimaryClick,
                        s = e.onSecondaryClick;
                    return (0, j.jsx)(at, {
                        children: (0, j.jsx)("div", {
                            className: "encounters-card-no-results",
                            children: (0, j.jsxs)($e.A, {
                                children: [t ? (0, j.jsx)(nt.A, {
                                    children: (0, j.jsx)("div", {
                                        className: "encounters-card-no-results__image",
                                        children: (0, j.jsx)(rt.Ay, {
                                            shape: rt.QJ.SQUARE,
                                            children: (0, j.jsx)(it.Ay, {
                                                src: t
                                            })
                                        })
                                    })
                                }) : (0, j.jsx)(nt.A, {
                                    size: "icon",
                                    children: (0, j.jsx)(G.A, {
                                        name: "badge-encounters"
                                    })
                                }), (0, j.jsx)(tt.A, {
                                    text: n
                                }), (0, j.jsx)(ot.A, {
                                    text: o
                                }), (0, j.jsxs)(et.A, {
                                    children: [(0, j.jsx)(Ze.A, {
                                        text: r.text,
                                        onClick: a,
                                        dataQA: {
                                            "data-qa": "action-primary"
                                        }
                                    }), i ? (0, j.jsx)(Ze.A, {
                                        semantic: "tertiary",
                                        text: i.text,
                                        onClick: s,
                                        dataQA: {
                                            "data-qa": "action-secondary"
                                        }
                                    }) : null]
                                })]
                            })
                        })
                    })
                };
            var ct = function(e) {
                    var t, n = e.promoBlock,
                        o = null == (t = n.buttons) ? void 0 : t.find((function(e) {
                            return 1 === e.type
                        }));
                    return (0, i.useEffect)((function() {
                        (0, be.sx)(138, {
                            banner_id: n.promo_block_type,
                            position_id: n.promo_block_position,
                            context: n.context,
                            variation_id: 1,
                            screen_name: 11
                        })
                    }), [n]), (0, j.jsx)(st, {
                        title: n.header,
                        message: n.mssg,
                        primaryAction: {
                            text: null == o ? void 0 : o.text
                        },
                        onPrimaryClick: function() {
                            var e, t, o;
                            e = n.promo_block_type, t = n.promo_block_position, o = n.context, (0, be.sx)(139, {
                                banner_id: e,
                                position_id: t,
                                context: o,
                                call_to_action_type: 1,
                                variation_id: 1,
                                screen_name: 11
                            }), g.A.handlePromoSelected({
                                banner: n.promo_block_type,
                                productType: n.ok_payment_product_type,
                                action: n.ok_action,
                                screenName: 11,
                                destination: d.A.getUrl()
                            }, {
                                from: d.A.getUrl()
                            })
                        }
                    })
                },
                ut = n(65297);

            function lt(e, t) {
                if (t) {
                    var n = t.promo_block_type,
                        o = t.promo_block_position,
                        r = t.context,
                        i = t.stats_variation_id;
                    (0, be.sx)(139, {
                        banner_id: n,
                        position_id: o,
                        context: r,
                        call_to_action_type: e,
                        variation_id: i
                    })
                } else(0, be.sx)(332, {
                    element: 69
                })
            }
            var dt = function(e) {
                var t = e.noMoreSearchResults,
                    n = function(e) {
                        return e.can_filter_expand ? function(e) {
                            var t, n, o = e.promo,
                                r = null == o ? void 0 : o.buttons,
                                i = null == r ? void 0 : r.find((function(e) {
                                    return 1 === e.type
                                })),
                                a = null == r ? void 0 : r.find((function(e) {
                                    return 2 === e.type
                                })),
                                s = null == o || null == (t = o.pictures) ? void 0 : t[0].display_images,
                                c = null == i || null == (n = i.redirect_page) ? void 0 : n.redirect_page;
                            return {
                                title: null == o ? void 0 : o.header,
                                message: null == o ? void 0 : o.mssg,
                                primaryAction: {
                                    text: null == i ? void 0 : i.text,
                                    path: 3 === c ? K.x.LIKED_YOU : K.x.PEOPLE_NEARBY
                                },
                                secondaryAction: {
                                    text: null == a ? void 0 : a.text
                                },
                                picturePath: s
                            }
                        }(e) : {
                            title: c.Ay.get(499),
                            message: c.Ay.get(503),
                            primaryAction: {
                                text: c.Ay.get(504),
                                path: K.x.PEOPLE_NEARBY
                            }
                        }
                    }(t);
                return (0, i.useEffect)((function() {
                    if (t.promo) {
                        var e = t.promo,
                            n = e.promo_block_type,
                            o = e.promo_block_position,
                            r = e.context,
                            i = e.stats_variation_id;
                        (0, be.sx)(138, {
                            banner_id: n,
                            position_id: o,
                            context: r,
                            variation_id: i
                        })
                    }
                }), [t]), (0, j.jsx)(st, {
                    title: n.title,
                    message: n.message,
                    primaryAction: n.primaryAction,
                    secondaryAction: n.secondaryAction,
                    picturePath: n.picturePath,
                    onPrimaryClick: function() {
                        lt(1, t.promo), t.can_filter_expand ? d.A.navigate(n.primaryAction.path) : ut.A.trigger(ut.A.ENCOUNTERS_FILTERS_OPEN)
                    },
                    onSecondaryClick: function() {
                        lt(2, t.promo), ut.A.trigger(ut.A.ENCOUNTERS_FILTERS_OPEN)
                    }
                })
            };

            function pt(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, o)
                }
                return n
            }

            function ft(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? pt(Object(n), !0).forEach((function(t) {
                        ht(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : pt(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function ht(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var o = n.call(e, t || "default");
                            if ("object" != typeof o) return o;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var vt = function(e, t) {
                    return "rollback" === t.type ? ft(ft({}, e), {}, {
                        firstProfile: t.nextState.firstProfile,
                        secondProfile: e.firstProfile
                    }) : ft(ft({}, e), t.nextState)
                },
                mt = function(e) {
                    var t = e.event,
                        n = e.voteType;
                    return {
                        isButtonVote: Boolean("click" === (null == t ? void 0 : t.type)),
                        voteType: n
                    }
                },
                gt = (n(88431), n(23215), n(49952)),
                yt = n(32483),
                At = n(96506),
                xt = n(65736),
                Tt = (n(62062), n(81454), n(74026)),
                Pt = n(36693),
                _t = function(e) {
                    var t = e.inBetweenText,
                        n = e.offerText;
                    return (0, j.jsxs)(i.Fragment, {
                        children: [t ? (0, j.jsx)(Pt.A, {
                            top: "md",
                            children: (0, j.jsx)(Tt.A, {
                                text: t
                            })
                        }) : null, n ? (0, j.jsx)(Pt.A, {
                            top: "lg",
                            children: (0, j.jsx)(yt.A, {
                                children: n
                            })
                        }) : null]
                    })
                };

            function Ct(e) {
                return void 0 === e && (e = !1), e ? "continue-premium-button" : "continue-button"
            }
            var St = function(e) {
                    var t = e.buttons,
                        n = e.extraTexts,
                        o = e.isLoading,
                        r = void 0 !== o && o,
                        a = e.onClickClose,
                        s = e.onClickButton;
                    return (0, j.jsxs)(et.A, {
                        children: [t.map((function(e, t) {
                            return (0, j.jsxs)(i.Fragment, {
                                children: [(0, j.jsx)(Ze.A, {
                                    isLoading: r,
                                    text: e.actionText,
                                    onClick: function() {
                                        return s(t)
                                    },
                                    dataQA: {
                                        "data-qa": Ct(e.isPremiumPlus)
                                    },
                                    semantic: 0 === t && null != n && n.inBetweenText ? "secondary" : "primary"
                                }), 0 === t && n ? (0, j.jsx)(_t, {
                                    inBetweenText: n.inBetweenText,
                                    offerText: n.offerText
                                }) : null]
                            }, e.actionText)
                        })), (0, j.jsx)(Ze.A, {
                            isLoading: r,
                            text: c.Ay.get(650),
                            semantic: "tertiary",
                            onClick: a,
                            dataQA: {
                                "data-qa": "close-button"
                            }
                        })]
                    })
                },
                bt = n(26914),
                Et = n(31023);

            function Ot(e) {
                var t = {};
                return e.src && (t.photo = {
                    src: e.src
                }), t
            }

            function kt(e) {
                if (e.badgeName) return {
                    position: "bc",
                    icon: {
                        name: e.badgeName
                    }
                }
            }
            var jt = function(e) {
                    var t = e.avatars,
                        n = e.mediaVariant,
                        o = e.mediaLayout;
                    return t.length < 1 ? null : (0, j.jsx)(Et.A, {
                        layout: o,
                        variant: n,
                        children: t.map((function(e) {
                            return (0, j.jsx)(bt.A, {
                                size: "single" === o ? "md" : void 0,
                                user: Ot(e),
                                badge: kt(e)
                            }, e.src)
                        }))
                    })
                },
                Nt = function(e) {
                    var t = e.avatars,
                        n = e.buttons,
                        o = e.extraTexts,
                        r = e.hasSameSignificance,
                        i = e.isLoading,
                        a = e.messageText,
                        s = e.titleText,
                        c = e.onClickButton,
                        u = e.onClickClose;
                    return (0, j.jsx)(xt.A, {
                        isPadded: !0,
                        onDismiss: u,
                        hasDefaultDismissButton: !1,
                        children: (0, j.jsxs)($e.A, {
                            isCompact: !0,
                            align: "start",
                            children: [(0, j.jsx)(nt.A, {
                                align: t.length > 1 ? "center" : "start",
                                children: (0, j.jsx)(jt, {
                                    avatars: t,
                                    mediaLayout: t.length > 1 ? "triple" : "single",
                                    mediaVariant: r ? "m-m-m" : "s-m-s"
                                })
                            }), (0, j.jsx)(tt.A, {
                                text: s,
                                tag: "h2"
                            }), (0, j.jsx)(ot.A, {
                                text: a
                            }), (0, j.jsx)(St, {
                                buttons: n,
                                extraTexts: o,
                                isLoading: i,
                                onClickClose: u,
                                onClickButton: c
                            }), null != o && o.disclaimerText ? (0, j.jsx)(At.A, {
                                children: (0, j.jsx)(yt.A, {
                                    children: o.disclaimerText
                                })
                            }) : null]
                        })
                    })
                },
                Dt = n(41025),
                wt = n(63826),
                It = n(26172),
                Rt = function(e) {
                    var t = e.profileData,
                        n = e.promoBlock,
                        o = e.onClose,
                        r = e.onCrushSuccess,
                        a = (0, i.useState)(!1),
                        s = a[0],
                        c = a[1],
                        u = (0, i.useMemo)((function() {
                            return It.A.getDataFromCorrectSource({
                                promoBlock: n,
                                twoTiersIsAvailable: (0, wt.X)()
                            })
                        }), [n]),
                        l = u.avatars,
                        p = u.buttons,
                        f = u.extraTexts,
                        h = u.messageText,
                        v = u.titleText,
                        m = (0, i.useMemo)((function() {
                            return l.every((function(e) {
                                return e.significance === l[0].significance
                            }))
                        }), [l]);

                    function g(e) {
                        e.success && r(e.purchaseReceipt, t), o()
                    }
                    return (0, j.jsx)(Nt, {
                        avatars: l,
                        buttons: p,
                        extraTexts: f,
                        hasSameSignificance: m,
                        isLoading: s,
                        messageText: h,
                        titleText: v,
                        onClickClose: o,
                        onClickButton: function(e) {
                            var i, a = null == (i = n.buttons) ? void 0 : i[e];
                            4 === (null == a ? void 0 : a.action) ? function(e) {
                                c(!0);
                                var o = e.product_type,
                                    r = n.promo_block_type,
                                    i = n.credits_cost,
                                    a = {
                                        back: K.x.ENCOUNTERS,
                                        callback: function(e) {
                                            d.A.getCurrentNavigation().routeName === K.x.ENCOUNTERS ? g(e) : (0, gt.cj)((function() {
                                                return g(e)
                                            }))
                                        },
                                        cost: i,
                                        hotPanelData: {
                                            activationPlace: 2,
                                            bannerId: r,
                                            cost: i,
                                            promoBlockType: r
                                        },
                                        productToActivate: n.ok_payment_product_type,
                                        productType: o,
                                        promoBlockType: r,
                                        userId: t.id
                                    };
                                Dt.A.navigateToPayment(a)
                            }(a) : 9 === (null == a ? void 0 : a.action) && function() {
                                c(!0);
                                var e = {
                                    activationPlace: 2,
                                    cost: n.credits_cost,
                                    promoBlockType: n.promo_block_type
                                };
                                y.A.purchase({
                                    back: K.x.ENCOUNTERS,
                                    hotPanelData: e,
                                    paymentTransitionInFlow: !0,
                                    productType: 25,
                                    userId: t.id,
                                    success: function(e) {
                                        e && (r(e, t), o())
                                    }
                                })
                            }()
                        }
                    })
                },
                Mt = function(e, t) {
                    var n = (0, i.useCallback)((function(n) {
                        var o = n.fromWatchdog;
                        e({
                            nextState: {
                                isLoading: !0,
                                noMoreResults: void 0,
                                voteLimitPromo: void 0,
                                isErrorData: !1
                            }
                        }), t(o)
                    }), [t, e]);
                    (0, i.useEffect)((function() {
                        return f.A.getInstance().on(f.A.EVENTS.INVALIDATED, n),
                            function() {
                                f.A.getInstance().off(f.A.EVENTS.INVALIDATED, n)
                            }
                    }), [e, n])
                },
                Lt = function() {
                    var e = (0, i.useRef)(!1),
                        t = function(t) {
                            t.routeName === K.x.COMPLETE_REGISTRATION || t.routeName === K.x.NEVER_LOOSE_ACCOUNT ? e.current = !0 : e.current && t.routeName === K.x.ENCOUNTERS && (e.current = !1, f.A.getInstance().invalidate())
                        };
                    (0, i.useEffect)((function() {
                        return d.A.navigationEvent.subscribe(t),
                            function() {
                                d.A.navigationEvent.unsubscribe(t)
                            }
                    }), [])
                },
                Vt = function(e, t, n, o) {
                    (0, i.useEffect)((function() {
                        var e = function() {
                            o({
                                voteType: 3,
                                isButtonVote: !1,
                                isBlocked: !0
                            })
                        };
                        return ut.A.on(ut.A.USER_BLOCKED, e),
                            function() {
                                ut.A.off(ut.A.USER_BLOCKED, e)
                            }
                    }), [o]), (0, i.useEffect)((function() {
                        var o = function(t) {
                                ! function(t, o) {
                                    var r;
                                    f.A.getInstance().undoVote(t.id), null == (r = n.current) || r.rollback(), e({
                                        type: "rollback",
                                        nextState: {
                                            firstProfile: t
                                        }
                                    }), e({
                                        nextState: {
                                            moveFirstCardIn: o,
                                            moveFirstCardOut: void 0
                                        }
                                    })
                                }(t, F.LEFT)
                            },
                            r = function() {
                                e({
                                    nextState: {
                                        isLoading: !1
                                    }
                                })
                            },
                            i = function() {
                                e({
                                    nextState: {
                                        isLoading: !0
                                    }
                                })
                            },
                            a = function(t) {
                                2 === t.voteType && e({
                                    nextState: {
                                        moveFirstCardOut: F.RIGHT
                                    }
                                })
                            };
                        return t.events.on(A.q.UNDO_VOTE, o).on(A.q.QUOTA_PROCESSING, i).on(A.q.QUOTA_PROCESSED, r).on(A.q.CRUSH_VOTE_COMPLETE, a),
                            function() {
                                t.events.off(A.q.UNDO_VOTE, o).off(A.q.QUOTA_PROCESSING, i).off(A.q.QUOTA_PROCESSED, r).off(A.q.CRUSH_VOTE_COMPLETE, a)
                            }
                    }), [t, e, n])
                },
                Bt = n(35837),
                Ut = (n(48980), n(72712), n(8872), n(58544)),
                Ft = n(28030),
                qt = n(95773);

            function Yt(e, t) {
                return Yt = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, Yt(e, t)
            }
            var Ht;

            function Gt(e) {
                (0, le.am)(e.slice(0, 3).reduce((function(e, t) {
                    if (t instanceof V.A) {
                        var n = t.encountersPromoCard,
                            o = null == n ? void 0 : n.photo;
                        o && e.push(o);
                        var r = null == n ? void 0 : n.header,
                            i = null == r ? void 0 : r.logo;
                        i && e.push(i)
                    } else if (null != t && t.getFirstPhotoUrlEncounters) e.push(t.getFirstPhotoUrlEncounters());
                    else {
                        var a = null == t ? void 0 : t.albums;
                        if (null != a && a.length) {
                            var s = a.find((function(e) {
                                return 7 === e.getAlbumType()
                            }));
                            if (s) {
                                var c = s.getPhotos();
                                null != c && c.length && e.push(c[0].getLargeUrl())
                            }
                        }
                    }
                    return e
                }), [])).catch((function(e) {
                    return (0, qt.gf)(e, "Encounters queue images")
                }))
            }

            function Xt(e, t) {
                return e.map((function(e) {
                    return (new p.U3K).setUserId(e.id).setState(t)
                }))
            }

            function Wt(e) {
                var t;
                return (null == e || null == (t = e.encounters_queue_settings) ? void 0 : t.num_of_completed_votes_to_report) || null
            }! function(e) {
                e.NEED_MORE = "NEED_MORE"
            }(Ht || (Ht = {}));
            var Qt = function(e) {
                    function t() {
                        var t;
                        (t = e.call(this) || this).queue = [], t.pendingVotes = [], t.completedVotes = [], t.completedVotesCountLimit = void 0, t.previousShiftedProfile = null;
                        var n = Ft.A.getSettings();
                        return t.completedVotesCountLimit = Wt(n), Ft.A.onChange((function(e) {
                            t.completedVotesCountLimit = Wt(e)
                        })), t
                    }
                    var n, o;
                    o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, Yt(n, o);
                    var r = t.prototype;
                    return r.set = function(e) {
                        Array.isArray(e) && (this.previousShiftedProfile = null, this.queue = e.slice(0), Gt(this.queue))
                    }, r.rollback = function() {
                        var e = this;
                        if (this.previousShiftedProfile) {
                            this.queue.unshift(this.previousShiftedProfile);
                            var t = this.completedVotes.findIndex((function(t) {
                                var n;
                                return t.id === (null == (n = e.previousShiftedProfile) ? void 0 : n.id)
                            }));
                            t > -1 && this.completedVotes.splice(t, 1)
                        }
                        this.previousShiftedProfile = null
                    }, r.shift = function(e) {
                        void 0 === e && (e = 2);
                        var t = this.queue.shift();
                        return t && (2 === e ? this.pendingVotes.push(t) : this.pushCompletedVote(t)), this.queue.length <= 10 && this.trigger(Ht.NEED_MORE), Gt(this.queue), !t || t instanceof V.A || (this.previousShiftedProfile = t), t
                    }, r.get = function(e) {
                        return this.queue[e]
                    }, r.length = function() {
                        return this.queue.length
                    }, r.pushCompletedVote = function(e) {
                        null !== this.completedVotesCountLimit && this.completedVotes.length >= this.completedVotesCountLimit && this.completedVotes.shift(), this.completedVotes.push(e)
                    }, r.addCompletedVote = function(e) {
                        this.pendingVotes = this.pendingVotes.filter((function(t) {
                            return t.id !== e.id
                        })), this.pushCompletedVote(e)
                    }, r.getState = function() {
                        var e = Xt(this.completedVotes, 3),
                            t = Xt(this.pendingVotes, 2),
                            n = Xt(this.queue, 1);
                        return e.concat(t, n)
                    }, t
                }(Ut.sV),
                Jt = n(41298),
                zt = n(28431),
                Kt = function(e, t, n) {
                    var o = (0, i.useRef)(),
                        r = (0, i.useRef)(),
                        a = (0, i.useRef)(!1),
                        s = (0, i.useCallback)((function(i, s) {
                            var u;
                            e.current = !1, o.current = (0, Jt.A)(f.A.getInstance().trackNext().get({
                                context: 1,
                                queueState: null == (u = r.current) ? void 0 : u.getState()
                            })), o.current.then((function(e) {
                                return function(e, o, i) {
                                    var s, c, u;
                                    if (!i || i instanceof p.nsU) {
                                        var l, d = null == i ? void 0 : i.toJSON();
                                        return t({
                                            nextState: {
                                                noMoreResults: d,
                                                isLoading: !1
                                            }
                                        }), null != (l = r.current) && l.length() || o || t({
                                            nextState: {
                                                firstProfile: void 0,
                                                secondProfile: void 0
                                            }
                                        }), void(0, be.sx)(258, {
                                            element: 70,
                                            screen_name: 11
                                        })
                                    }
                                    if (i instanceof p.mBm) {
                                        var f = i.toJSON();
                                        return void t({
                                            nextState: {
                                                voteLimitPromo: f.promo_block,
                                                isLoading: !1
                                            }
                                        })
                                    }
                                    var h = i.encounters,
                                        v = i.isCached,
                                        m = h.map((function(e) {
                                            return e instanceof p.mBm ? new V.A({
                                                userSubstitute: e
                                            }) : new B.Ay({
                                                activationPlace: 2,
                                                clientSource: 1,
                                                isCached: v,
                                                searchResult: e,
                                                sessionUser: (0, Bt.A)(w.A.getUser(), p.KJW)
                                            })
                                        }));
                                    e && n && m[0] && n.id !== m[0].id && m.unshift(n);
                                    null == (s = r.current) || s.set(m);
                                    var g = null == (c = r.current) ? void 0 : c.shift();
                                    a.current = !0, t({
                                        nextState: {
                                            firstProfile: g,
                                            secondProfile: null == (u = r.current) ? void 0 : u.get(0),
                                            isLoading: !1,
                                            noMoreResults: void 0,
                                            voteLimitPromo: void 0
                                        }
                                    })
                                }(i, s, e)
                            })).catch(c)
                        }), []);

                    function c(e) {
                        e instanceof Error && e.isCanceled || (zt.A.handleError({
                            error: e,
                            screenName: 11,
                            navigationBar: {
                                logo: !0,
                                actions: {}
                            }
                        }, (function() {
                            t({
                                nextState: {
                                    isLoading: !0
                                }
                            }), s()
                        })), t({
                            nextState: {
                                isLoading: !0,
                                noMoreResults: void 0,
                                voteLimitPromo: void 0,
                                isErrorData: !0
                            }
                        }))
                    }
                    return (0, i.useEffect)((function() {
                        return s(),
                            function() {
                                var e;
                                null == (e = o.current) || e.cancel()
                            }
                    }), [s]), (0, i.useEffect)((function() {
                        r.current = new Qt
                    }), []), (0, i.useEffect)((function() {
                        var t, n = function() {
                            e.current && s(void 0, !0)
                        };
                        return null == (t = r.current) || t.on(Ht.NEED_MORE, n),
                            function() {
                                var e;
                                null == (e = r.current) || e.off(Ht.NEED_MORE, n)
                            }
                    }), [s, e]), {
                        queueManager: r,
                        shouldReportJinba: a,
                        fetchEncounters: s
                    }
                },
                Zt = M.A.getLogger("EncountersCardsContainer"),
                $t = function(e) {
                    var t = e.profileActionHandler,
                        n = e.trackHotPanelScreen,
                        o = e.onScreenNameChange,
                        r = (0, i.useReducer)(vt, {
                            isLoading: !0,
                            isCardMoving: !1,
                            isVoteEngaged: !1,
                            isErrorData: !1,
                            firstProfile: void 0,
                            secondProfile: void 0,
                            noMoreResults: void 0,
                            voteLimitPromo: void 0,
                            crushPromoBlock: void 0,
                            cardPosition: {},
                            moveFirstCardIn: void 0,
                            moveFirstCardOut: void 0,
                            secondCardScale: 0
                        }),
                        a = r[0],
                        s = r[1],
                        c = (0, i.useRef)(!1),
                        u = (0, i.useRef)(),
                        l = (0, i.useRef)(),
                        d = Kt(c, s, a.firstProfile),
                        h = d.queueManager,
                        v = d.shouldReportJinba,
                        m = d.fetchEncounters,
                        g = (0, i.useCallback)((function(e, t) {
                            var n;
                            f.A.getInstance().undoVote(e.id), null == (n = h.current) || n.rollback(), s({
                                type: "rollback",
                                nextState: {
                                    firstProfile: e
                                }
                            }), s({
                                nextState: {
                                    moveFirstCardIn: t,
                                    moveFirstCardOut: void 0
                                }
                            })
                        }), [h]),
                        y = (0, i.useCallback)((function(e) {
                            var t, n;
                            void 0 === e && (e = 2), s({
                                nextState: {
                                    firstProfile: null == (t = h.current) ? void 0 : t.shift(e),
                                    secondProfile: null == (n = h.current) ? void 0 : n.get(0)
                                }
                            })
                        }), [h]),
                        A = (0, i.useCallback)((function(e) {
                            var o, r, i = e.voteType,
                                u = e.isButtonVote,
                                d = e.isBlocked;
                            if (c.current = !0, !a.isLoading && a.firstProfile) {
                                var p;
                                if (a.firstProfile instanceof V.A || d) null == (p = h.current) || p.addCompletedVote(a.firstProfile), f.A.getInstance().markUserAsVoted(a.firstProfile.id);
                                if (a.firstProfile.isAnonymous && w.A.isLoggedIn()) {
                                    var v;
                                    null == (v = l.current) || v.abort()
                                } else {
                                    null == (o = l.current) || o.start();
                                    var A, x, T = null == (r = h.current) ? void 0 : r.get(0);
                                    if (D.A.regenerateId(), n(), s({
                                            nextState: {
                                                moveFirstCardIn: void 0,
                                                moveFirstCardOut: void 0,
                                                isVoteEngaged: !1
                                            }
                                        }), T) y(), null == (A = l.current) || A.waitForImage(T.largeProfilePhoto).stop();
                                    else null == (x = l.current) || x.abort(), a.noMoreResults ? s({
                                        nextState: {
                                            firstProfile: void 0
                                        }
                                    }) : (s({
                                        nextState: {
                                            isLoading: !0,
                                            firstProfile: void 0
                                        }
                                    }), h.current && h.current.length() < 1 && m(void 0, !0));
                                    a.firstProfile instanceof V.A || d || (t.handleVote({
                                        profileData: a.firstProfile,
                                        voteType: i,
                                        isEngagedVote: a.isVoteEngaged,
                                        isButtonVote: u,
                                        photo: q.Ay.visiblePhoto.get()
                                    }).then((function() {
                                        var e;
                                        null == (e = h.current) || e.addCompletedVote(a.firstProfile)
                                    })).catch((function(e) {
                                        var t;
                                        null == (t = l.current) || t.abort(), e instanceof B.Ay ? g(e, 3 === i ? U.LEFT : U.RIGHT) : Zt.error("Error voting in Encounters", {
                                            error: e
                                        })
                                    })), oe())
                                }
                            }
                        }), [a.isLoading, a.isVoteEngaged, a.firstProfile, a.noMoreResults, m, t, g, n, h, y]),
                        x = function(e) {
                            var t = mt({
                                event: e,
                                voteType: 3
                            });
                            A(t)
                        },
                        T = function(e) {
                            var t = mt({
                                event: e,
                                voteType: 2
                            });
                            A(t)
                        };
                    return (0, i.useEffect)((function() {
                        u.current = new R.A("Encounters", 8), l.current = new R.A("Encounters/vote", 11)
                    }), []), Mt(s, m), Lt(), Vt(s, t, h, A), (0, i.useEffect)((function() {
                        var e;
                        null == (e = u.current) || e.start()
                    }), []), (0, i.useEffect)((function() {
                        if (v.current) {
                            var e;
                            if (a.firstProfile instanceof B.Ay) null == (e = u.current) || e.waitForImage(a.firstProfile.getFirstPhotoUrlEncounters()).stop().then((function() {
                                (0, L.A)("Encounters interactive", 9)
                            }));
                            else(0, L.A)("Encounters interactive", 9);
                            v.current = !1
                        }
                    })), a.isLoading ? (0, j.jsx)(Se, {
                        isSkeleton: !0,
                        children: (0, j.jsx)(z, {})
                    }) : a.isErrorData ? (0, j.jsx)(z, {}) : !a.firstProfile && a.noMoreResults ? (0, j.jsx)(dt, {
                        noMoreSearchResults: a.noMoreResults
                    }) : a.voteLimitPromo ? (0, j.jsx)(ct, {
                        promoBlock: a.voteLimitPromo
                    }) : (0, j.jsxs)(i.Fragment, {
                        children: [(0, j.jsx)(Ke, {
                            profileData: a.secondProfile,
                            dummyZoomIn: a.secondCardScale,
                            isDummy: !0
                        }), (0, j.jsx)(Ke, {
                            profileData: a.firstProfile,
                            moveCardIn: a.moveFirstCardIn,
                            moveCardOut: a.moveFirstCardOut,
                            onVoteBeforeSwipe: function() {
                                setTimeout((function() {
                                    s({
                                        nextState: {
                                            secondCardScale: 1
                                        }
                                    })
                                }))
                            },
                            onVoteNo: x,
                            onVoteYes: T,
                            onSwipeYes: T,
                            onSwipeNo: x,
                            onClickCrush: function() {
                                I.A.generate(), t.crushVote({
                                    profileData: a.firstProfile,
                                    photo: q.Ay.visiblePhoto.get()
                                }).then((function(e) {
                                    e instanceof p.d4N && s({
                                        nextState: {
                                            crushPromoBlock: e.toJSON()
                                        }
                                    })
                                }))
                            },
                            onTouchStartCard: function() {
                                s({
                                    nextState: {
                                        isCardMoving: !0
                                    }
                                })
                            },
                            onTouchEndCard: function() {
                                s({
                                    nextState: {
                                        isCardMoving: !1
                                    }
                                })
                            },
                            onUpdateCardPosition: function(e) {
                                s({
                                    nextState: {
                                        cardPosition: e,
                                        secondCardScale: e.indicatorOpacityAndScale
                                    }
                                })
                            },
                            onScroll: function() {
                                if (!a.isVoteEngaged) {
                                    var e;
                                    s({
                                        nextState: {
                                            isVoteEngaged: !0
                                        }
                                    });
                                    var t = null == (e = a.firstProfile) ? void 0 : e.id;
                                    t && (n = t, (0, be.sx)(195, {
                                        element: 40,
                                        screen_name: 11,
                                        encrypted_user_id: n
                                    }))
                                }
                                var n
                            },
                            onScreenNameChange: o,
                            onDisplayGenericPromo: function(e) {
                                y(3), f.A.getInstance().markUserAsVoted(e)
                            }
                        }), (0, j.jsx)(W, {
                            isCardMoving: a.isCardMoving,
                            cardPosition: a.cardPosition
                        }), a.crushPromoBlock && (0, j.jsx)(Rt, {
                            profileData: a.firstProfile,
                            promoBlock: a.crushPromoBlock,
                            onClose: function() {
                                return s({
                                    nextState: {
                                        crushPromoBlock: void 0
                                    }
                                })
                            },
                            onCrushSuccess: t.handleCrushSuccess
                        })]
                    })
                },
                en = (n(23792), n(62953), n(20816)),
                tn = n(87351);

            function nn() {
                I.A.generate(), (0, be.sx)(332, {
                    element: 5
                }), d.A.navigate(K.x.LIKED_YOU)
            }
            var on = n(52668),
                rn = n(20015),
                an = n(94318),
                sn = function(e) {
                    var t = e.getLikedYouIcon,
                        n = e.isHidden,
                        o = void 0 !== n && n,
                        r = e.likedYouText,
                        i = e.onClickLikedYou;
                    return o ? null : t ? t((0, j.jsx)(an.A, {
                        name: "navigation-bar-liked-you",
                        notification: {
                            status: "visible",
                            counterText: r,
                            counterStatus: "visible"
                        },
                        onClick: i,
                        a11y: {
                            iconLabel: c.Ay.get(617, {
                                num: Number(r) || 0
                            })
                        }
                    })) : (0, j.jsx)(an.A, {
                        name: "navigation-bar-liked-you",
                        onClick: i,
                        a11y: {
                            iconLabel: c.Ay.get(274)
                        }
                    })
                },
                cn = function(e) {
                    var t = e.progress,
                        n = void 0 === t ? 0 : t,
                        o = e.children;
                    return (0, j.jsx)("div", {
                        className: H()("encounters-navigation-bar-progress", {
                            "has-progress-bar": n > 0
                        }),
                        children: o
                    })
                },
                un = function(e) {
                    var t = e.tooltip,
                        n = e.onClickOutside;
                    return (0, j.jsxs)("div", {
                        className: "search-criteria-tips search-criteria-tips--position-filter",
                        children: [(0, j.jsx)("button", {
                            className: "search-criteria-tips__fade",
                            onClick: n,
                            "aria-label": c.Ay.get(454)
                        }), (0, j.jsx)("div", {
                            className: "search-criteria-tips__tooltip",
                            children: t
                        })]
                    })
                },
                ln = n(39904),
                dn = function(e) {
                    var t = e.header,
                        n = e.subHeader,
                        o = e.extraShowsCta,
                        r = e.extraShowsHeaderTitle,
                        a = e.voteGoalProgress,
                        s = e.likedYouText,
                        c = e.hideLikeYou,
                        u = e.searchCriteriaTooltip,
                        l = e.undoVoteTooltip,
                        d = e.getLikedYouIcon,
                        p = e.filtersTooltip,
                        f = e.getProgressBar,
                        h = e.onClickUndoVote,
                        v = e.onClickLikedYou,
                        m = e.onClickFilter,
                        g = e.onClickOutsideTooltip,
                        y = a ? 100 * a.progress / a.goal : 0,
                        A = [{
                            type: ln.X2.FILTER,
                            tooltip: p,
                            onClick: m
                        }];
                    return u && (null == A || A.unshift({
                        type: ln.TN.CUSTOM_COMPONENT,
                        component: (0, j.jsx)(un, {
                            tooltip: u,
                            onClickOutside: g
                        })
                    })), l && (null == A || A.unshift({
                        type: ln.X2.UNDO,
                        tooltip: l,
                        onClick: h,
                        a11y: {
                            ariaDescribedby: "" + on.R + 1464
                        }
                    })), c || null == A || A.unshift({
                        type: ln.TN.CUSTOM_COMPONENT,
                        component: (0, j.jsx)(sn, {
                            getLikedYouIcon: d,
                            isHidden: c,
                            likedYouText: s,
                            onClickLikedYou: v
                        })
                    }), o && (null == A || A.unshift({
                        type: ln.TN.CUSTOM_COMPONENT,
                        component: o
                    })), r && (null == A || A.unshift({
                        type: ln.TN.CUSTOM_COMPONENT,
                        component: r
                    })), (0, j.jsxs)(i.Fragment, {
                        children: [(0, j.jsx)(ln.Ay, {
                            actions: A,
                            title: {
                                text: t,
                                variant: "primary"
                            },
                            subTitle: n,
                            isBalanced: !1
                        }), r ? null : (0, j.jsx)(cn, {
                            progress: y,
                            children: y && f ? f((0, j.jsx)(rn.A, {
                                percentage: y
                            })) : null
                        })]
                    })
                },
                pn = (n(89463), n(93827)),
                fn = n(36422),
                hn = function(e) {
                    var t = e.buttonText,
                        n = e.description,
                        o = e.onButtonClick;
                    return (0, j.jsxs)(fn.A, {
                        placement: "bottom-end",
                        children: [(0, j.jsx)(pn.P1, {
                            color: "black",
                            align: "center",
                            children: n
                        }), (0, j.jsx)(Pt.A, {
                            top: "md",
                            children: (0, j.jsx)(Ze.A, {
                                narrow: !0,
                                text: t,
                                onClick: o
                            })
                        })]
                    })
                },
                vn = n(41296),
                mn = n(10357),
                gn = n(63553),
                yn = n(53416),
                An = n(12187),
                xn = n(7572),
                Tn = n(88029);

            function Pn(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, o)
                }
                return n
            }

            function _n(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Pn(Object(n), !0).forEach((function(t) {
                        Cn(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Pn(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function Cn(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var o = n.call(e, t || "default");
                            if ("object" != typeof o) return o;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var Sn = {
                showUndo: !1,
                undoTooltipText: void 0,
                missedMatch: !1
            };

            function bn(e) {
                return function(t) {
                    return (0, j.jsx)(vn.A, _n(_n({}, e), {}, {
                        children: t
                    }))
                }
            }
            var En = function(e) {
                    var t, n, o = e.profileActionHandler,
                        a = (0, i.useState)(),
                        l = a[0],
                        p = a[1],
                        h = (0, i.useState)(null),
                        v = h[0],
                        g = h[1],
                        y = (0, i.useState)(Sn),
                        x = y[0],
                        T = y[1],
                        P = (0, i.useState)({
                            likedYouCount: 0
                        }),
                        _ = P[0],
                        C = P[1],
                        S = (0, i.useState)(!1),
                        b = S[0],
                        E = S[1],
                        O = (0, i.useRef)(0),
                        k = (0, i.useRef)(!1),
                        N = (0, i.useRef)(0),
                        D = (0, An.H)(),
                        I = D.headerTitle,
                        R = D.isEncountersEntryPointVisible,
                        M = (0, i.useCallback)((function() {
                            (0, be.sx)(332, {
                                element: 488,
                                parent_element: 94
                            }), E(!0)
                        }), []),
                        L = (null == (t = r.A.getInstance().getTooltipByType(16)) ? void 0 : t.conditions) || [],
                        B = O.current === (null == (n = L[0]) ? void 0 : n.number);
                    (0, i.useEffect)((function() {
                        mn.F4.getIsActive() && M()
                    }), [M]), (0, i.useEffect)((function() {
                        return ut.A.on(ut.A.ENCOUNTERS_FILTERS_OPEN, M), m.A.subscribeOnChange(p),
                            function() {
                                ut.A.off(ut.A.ENCOUNTERS_FILTERS_OPEN, M), m.A.unsubscribeFromChange(p)
                            }
                    }), [M]), (0, i.useEffect)((function() {
                        function e(e) {
                            var t = e.voteType,
                                n = e.profileData;
                            if (n instanceof V.A || 3 !== t) 2 === t && null != x && x.showUndo && T(Sn);
                            else if (k.current) k.current = !1;
                            else {
                                O.current++;
                                var o = function(e) {
                                    var t, n = e.yourVote,
                                        o = e.theirVote,
                                        r = u.A.getSync(100),
                                        i = Boolean(r && 3 === n),
                                        a = 2 === o && 1 === (null == (t = w.A.getUser()) ? void 0 : t.gender),
                                        s = c.Ay.get(1048);
                                    return {
                                        showUndo: i,
                                        undoTooltipText: i && a ? s : void 0,
                                        missedMatch: a
                                    }
                                }({
                                    yourVote: t,
                                    theirVote: n.vote.theirVote
                                });
                                T(o)
                            }
                        }

                        function t(e) {
                            e.routeName === K.x.ENCOUNTERS && null != x && x.showUndo && T(Sn)
                        }

                        function n() {
                            k.current = !0, T(Sn)
                        }

                        function r() {
                            T(Sn)
                        }
                        return d.A.navigationEvent.subscribe(t), ut.A.on(ut.A.USER_BLOCKED, n), o.events.on(A.q.ENCOUNTERS_VOTE_COMPLETE, e), f.A.getInstance().on(f.A.EVENTS.INVALIDATED, r),
                            function() {
                                d.A.navigationEvent.unsubscribe(t), ut.A.off(ut.A.USER_BLOCKED, n), o.events.off(A.q.ENCOUNTERS_VOTE_COMPLETE, e), f.A.getInstance().off(f.A.EVENTS.INVALIDATED, r)
                            }
                    }), [x, o]), (0, i.useEffect)((function() {
                        function e() {
                            clearTimeout(N.current), T(Sn)
                        }
                        return o.events.on(A.q.UNDO_VOTE, e),
                            function() {
                                o.events.off(A.q.UNDO_VOTE, e)
                            }
                    }), [o]), (0, i.useEffect)((function() {
                        function e(e) {
                            6 === e.folder && C((function(t) {
                                return _n(_n({}, t), {}, {
                                    likedYouCount: e.int_value || 0
                                })
                            }))
                        }
                        return tn.A.hit(), en.A.get().then((function(e) {
                                var t = null == e ? void 0 : e.values;
                                t && C((function(e) {
                                    return _n(_n({}, e), {}, {
                                        likedYouCount: t[6] || 0
                                    })
                                }))
                            })), en.A.on(en.A.EVENTS.CHANGE, e),
                            function() {
                                en.A.off(en.A.EVENTS.CHANGE, e)
                            }
                    }), []), (0, i.useEffect)((function() {
                        function e(e) {
                            var t;
                            g(e), t = e.promo_block_type, (0, be.sx)(138, {
                                banner_id: t,
                                position_id: 15,
                                context: 45
                            })
                        }

                        function t(t) {
                            if (119 === t.type) {
                                var n = t.promo_block;
                                400 === (null == n ? void 0 : n.promo_block_type) && e(n)
                            }
                        }
                        return s.A.getInstance().on(s.A.Type.NOTIFICATION, t),
                            function() {
                                s.A.getInstance().off(s.A.Type.NOTIFICATION, t)
                            }
                    }), []);
                    var U, F, q = function() {
                            var e = _.likedYouCount;
                            if (!(e < 1)) return e <= 99 ? String(e) : "99+"
                        }(),
                        Y = (0, Tn.A)(1),
                        H = Y.header_text,
                        G = Y.subheader_text;
                    return (0, j.jsxs)(i.Fragment, {
                        children: [(0, j.jsx)(dn, {
                            header: H,
                            subHeader: G,
                            voteGoalProgress: l,
                            likedYouText: q,
                            searchCriteriaTooltip: v ? (0, j.jsx)(hn, {
                                buttonText: (U = v, null == (F = U.buttons) ? void 0 : F[0].text),
                                onButtonClick: function() {
                                    var e;
                                    e = null == v ? void 0 : v.promo_block_type, (0, be.sx)(139, {
                                        banner_id: e,
                                        position_id: 15,
                                        context: 45,
                                        call_to_action_type: 1
                                    }), g(null), M()
                                },
                                description: v.mssg
                            }) : null,
                            undoVoteTooltip: null != x && x.showUndo ? {
                                type: 10
                            } : void 0,
                            getLikedYouIcon: q ? bn({
                                type: 14,
                                onClick: nn
                            }) : void 0,
                            filtersTooltip: {
                                type: 16,
                                condition: B
                            },
                            getProgressBar: bn({
                                type: 39
                            }),
                            extraShowsHeaderTitle: R && I ? (0, j.jsx)(gn.A, {
                                context: 1
                            }) : null,
                            extraShowsCta: R ? (0, j.jsx)(yn.A, {
                                context: 1
                            }) : null,
                            hideLikeYou: R && !q || tn.A.isActive(),
                            onClickUndoVote: o.undoVote,
                            onClickFilter: M,
                            onClickLikedYou: nn,
                            onClickOutsideTooltip: function() {
                                g(null)
                            }
                        }), b ? (0, j.jsx)(xn.A, {
                            searchType: 1,
                            onClose: function() {
                                return E(!1)
                            },
                            onSaveSuccess: function() {
                                return f.A.getInstance().invalidate()
                            }
                        }) : null]
                    })
                },
                On = n(47632),
                kn = n(31190);
            const jn = ({
                image: e,
                position: t,
                size: n
            }) => {
                const o = H()({
                    "csms-match-photos__image": !0,
                    [`csms-match-photos__image--position-${t}`]: !0,
                    [`csms-match-photos__image--size-${n}`]: !0
                });
                let r;
                return e && (r = {
                    backgroundImage: `url(${e})`
                }), (0, j.jsx)("div", {
                    className: o,
                    style: r
                })
            };
            var Nn = ({
                size: e,
                icon: t,
                leftImage: n,
                rightImage: o,
                a11y: r
            }) => {
                const i = H()({
                    "csms-match-photos": !0,
                    [`csms-match-photos--size-${e}`]: !0
                });
                return (0, j.jsxs)("div", {
                    className: i,
                    role: "img",
                    "aria-label": r ? .label,
                    children: [(0, j.jsx)(jn, {
                        image: n,
                        size: e,
                        position: "left"
                    }), (0, j.jsx)(jn, {
                        image: o,
                        size: e,
                        position: "right"
                    }), (0, j.jsx)("div", {
                        className: "csms-match-photos__icon",
                        children: (0, j.jsx)(G.A, {
                            name: t,
                            shadow: !0
                        })
                    })]
                })
            };

            function Dn(e, t) {
                return Dn = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, Dn(e, t)
            }
            var wn = function(e) {
                function t(t) {
                    var n;
                    return (n = e.call(this, t) || this).state = {
                        leftImage: null,
                        rightImage: null
                    }, n
                }
                var n, o;
                o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, Dn(n, o);
                var r = t.prototype;
                return r.componentDidMount = function() {
                    var e = this;
                    this.preloadLeftImagePromise = (0, le.NN)(this.props.leftImage), this.preloadLeftImagePromise.then((function() {
                        return e.setState({
                            leftImage: e.props.leftImage
                        })
                    })).catch((function(e) {
                        e instanceof Error && !e.isCanceled && (0, qt.gf)(e, "Match photos container")
                    })), this.preloadRightImagePromise = (0, le.NN)(this.props.rightImage), this.preloadRightImagePromise.then((function() {
                        return e.setState({
                            rightImage: e.props.rightImage
                        })
                    })).catch((function(e) {
                        e instanceof Error && !e.isCanceled && (0, qt.gf)(e, "Match photos container")
                    }))
                }, r.componentWillUnmount = function() {
                    this.preloadLeftImagePromise.cancel(), this.preloadRightImagePromise.cancel()
                }, r.render = function() {
                    var e = this.props,
                        t = e.size,
                        n = e.icon,
                        o = this.state,
                        r = o.leftImage,
                        i = o.rightImage;
                    return (0, j.jsx)(Nn, {
                        size: t,
                        leftImage: r,
                        rightImage: i,
                        icon: n
                    })
                }, t
            }(i.Component);

            function In(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, o)
                }
                return n
            }

            function Rn(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? In(Object(n), !0).forEach((function(t) {
                        Mn(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : In(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function Mn(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var o = n.call(e, t || "default");
                            if ("object" != typeof o) return o;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var Ln, Vn = function(e) {
                    var t = e.photos,
                        n = e.titleText,
                        o = e.messageText,
                        r = e.primaryButton,
                        i = e.secondaryButton;
                    return (0, j.jsxs)($e.A, {
                        isCompact: !0,
                        align: "start",
                        children: [(0, j.jsx)(nt.A, {
                            children: t
                        }), (0, j.jsx)(tt.A, {
                            text: n,
                            tag: "h2"
                        }), (0, j.jsx)(ot.A, {
                            text: o
                        }), (0, j.jsxs)(et.A, {
                            children: [(0, j.jsx)(Ze.A, Rn({}, r)), (0, j.jsx)(Ze.A, Rn({
                                semantic: "tertiary"
                            }, i))]
                        })]
                    })
                },
                Bn = ((Ln = {})[1] = 288, Ln[2] = 65, Ln);

            function Un(e) {
                return Fn(1, e)
            }

            function Fn(e, t) {
                var n, o = null == t || null == (n = t.pictures) ? void 0 : n[e];
                return o ? On.A.getImageUrlForSize(o.display_images, 200, 200) : null
            }

            function qn(e) {
                var t = Hn(1, e);
                return null == t ? void 0 : t.text
            }

            function Yn(e) {
                var t = Hn(2, e);
                return null == t ? void 0 : t.text
            }

            function Hn(e, t) {
                var n;
                return null == t || null == (n = t.buttons) ? void 0 : n.find((function(t) {
                    return t.type === e
                }))
            }
            var Gn = function(e) {
                    var t, n = e.notification,
                        o = e.onClosed,
                        r = (0, i.useState)(!0),
                        a = r[0],
                        s = r[1],
                        c = n.promo_block,
                        u = function(e) {
                            var t = Bn[e];
                            t && (0, be.sx)(332, {
                                element: t
                            }), kn.A.getInstance().notificationHandled(n.id), s(!1)
                        };
                    return (0, j.jsx)(xt.A, {
                        isDismissible: !1,
                        isVisible: a,
                        onAnimationOutComplete: o,
                        isPadded: !0,
                        hasDefaultDismissButton: !1,
                        children: (0, j.jsx)(Vn, {
                            photos: (0, j.jsx)(wn, {
                                size: "md",
                                leftImage: (t = c, Fn(0, t)),
                                rightImage: Un(c),
                                icon: "badge-feature-match"
                            }),
                            titleText: null == c ? void 0 : c.header,
                            messageText: null == c ? void 0 : c.mssg,
                            primaryButton: {
                                text: qn(c),
                                onClick: function() {
                                    return u(1)
                                }
                            },
                            secondaryButton: {
                                text: Yn(c),
                                onClick: function() {
                                    return u(2)
                                }
                            }
                        })
                    })
                },
                Xn = C(),
                Wn = function(e) {
                    var t = e.trackHotPanelScreen,
                        n = e.onScreenNameChange,
                        o = (0, i.useState)(null),
                        r = o[0],
                        u = o[1],
                        l = (0, i.useState)(""),
                        d = l[0],
                        p = l[1],
                        f = (0, i.useRef)(),
                        h = (0, i.useCallback)((function(e) {
                            f.current = e
                        }), []);
                    return (0, i.useEffect)((function() {
                        n((function() {
                            return f.current ? f.current : r ? 618 : 11
                        }))
                    }), [n, r, f]), (0, i.useEffect)((function() {
                        var e, t = function(t) {
                            if (81 === t.type) {
                                var n = t.promo_block;
                                61 === (null == n ? void 0 : n.promo_block_type) && function(t) {
                                    e = a.A.setTimeout((function() {
                                        return u(t)
                                    }), S.X + 1e3)
                                }(t)
                            }
                        };
                        return s.A.getInstance().on(s.A.Type.NOTIFICATION, t),
                            function() {
                                s.A.getInstance().off(s.A.Type.NOTIFICATION, t), clearTimeout(e)
                            }
                    }), []), (0, i.useEffect)((function() {
                        var e = function(e) {
                            p(e)
                        };
                        return Xn.events.on(A.q.UPDATE_SETTINGS_MESSAGE, e),
                            function() {
                                Xn.events.off(A.q.UPDATE_SETTINGS_MESSAGE, e)
                            }
                    }), []), (0, j.jsxs)(i.Fragment, {
                        children: [(0, j.jsx)(N, {
                            header: (0, j.jsx)(En, {
                                profileActionHandler: Xn
                            }),
                            content: (0, j.jsx)($t, {
                                trackHotPanelScreen: t,
                                onScreenNameChange: h,
                                profileActionHandler: Xn
                            })
                        }), r ? (0, j.jsx)(Gn, {
                            notification: r,
                            onClosed: function() {
                                return u(null)
                            }
                        }) : null, (0, j.jsx)(b.A, {
                            message: d,
                            isOpen: Boolean(d),
                            confirmLabel: c.Ay.get(373),
                            cancelLabel: c.Ay.get(330),
                            onConfirm: Xn.onEditFilter,
                            onCancel: Xn.onDenyFilter
                        })]
                    })
                };

            function Qn(e, t) {
                return Qn = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, Qn(e, t)
            }
            var Jn = function(e) {
                function t() {
                    for (var t, n = arguments.length, o = new Array(n), i = 0; i < n; i++) o[i] = arguments[i];
                    return (t = e.call.apply(e, [this].concat(o)) || this).activationPlace = 2, t.clientSource = 1, t.screenName = 11, t.onboardingTipsController_ = r.A.getInstance(), t.handleChangeScreenName = function(e) {
                        t.getScreenName = e
                    }, t
                }
                var n, o;
                o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, Qn(n, o);
                var i = t.prototype;
                return i.componentDidMount = function() {
                    e.prototype.componentDidMount.call(this), this.onboardingTipsController_.on(r.A.ACTIONS.TOOLTIP_SHOWN, this.preventNotifications_, this), this.onboardingTipsController_.on(r.A.ACTIONS.TOOLTIP_DISMISSED, this.allowNotifications_, this), this.onboardingTipsController_.setContext(1), this.trackHotPanelScreen = this.trackHotPanelScreen.bind(this)
                }, i.componentWillUnmount = function() {
                    this.onboardingTipsController_.off(r.A.ACTIONS.TOOLTIP_SHOWN, this.preventNotifications_, this), this.onboardingTipsController_.off(r.A.ACTIONS.TOOLTIP_DISMISSED, this.allowNotifications_, this)
                }, i.preventNotifications_ = function() {
                    this.notificationScreenAccess = 3
                }, i.allowNotifications_ = function() {
                    this.notificationScreenAccess = 1
                }, i.render = function() {
                    return this.addPageWrapper((0, j.jsx)(Wn, {
                        trackHotPanelScreen: this.trackHotPanelScreen,
                        onScreenNameChange: this.handleChangeScreenName
                    }), "encounters")
                }, t
            }(o.A);
            Jn.transition = !1, Jn.hasTabBar = !0;
            var zn = Jn
        },
        79458: function(e, t, n) {
            var o = n(13264),
                r = n(69705),
                i = n(79860),
                a = n(39778),
                s = n(88309),
                c = n(74848),
                u = o.A.extend({
                    construct: function(e) {
                        u._super.construct.call(this), this.place_ = e.place, this.activationPlace_ = e.activationPlace
                    },
                    obtainPermission: function(e) {
                        r.A.inited && void 0 === r.A.getCurrentChoice(this.place_) && this.showConfirmationPopup_(e)
                    },
                    showConfirmationPopup_: function(e) {
                        var t = this,
                            n = (0, s.A)();
                        this.renderReactView((0, c.jsx)(a.A, {
                            message: e,
                            isOpen: !0,
                            isPortal: !1,
                            onConfirm: function() {
                                t.requestPermission_(), t.removeReactView(n)
                            },
                            onCancel: function() {
                                t.denyPermission_(), t.removeReactView(n)
                            }
                        }), n), this.trackConfirmationPopupView_()
                    },
                    trackConfirmationPopupView_: function() {
                        (0, i.sx)(20, {
                            alert_type: 7,
                            activation_place: this.activationPlace_
                        })
                    },
                    requestPermission_: function() {
                        var e = this;
                        r.A.userWantsPushes(this.place_).then((function(t) {
                            return e.trackPermissionRequest_(t)
                        }))
                    },
                    denyPermission_: function() {
                        r.A.userDeniesPushes(this.place_), this.trackPermissionRequest_(!1)
                    },
                    trackPermissionRequest_: function(e) {
                        (0, i.sx)(47, {
                            permission_type: 2,
                            permission_granted: e,
                            activation_place: this.activationPlace_
                        })
                    }
                }, "NotificationPermissionController");
            t.A = u
        },
        84914: function(e, t) {
            t.A = function(e) {
                var t = null;
                return {
                    callback: function(n) {
                        null !== t ? (e(t, n), t = n) : t = n
                    },
                    reset: function() {
                        t = null
                    }
                }
            }
        }
    }
]);
//# sourceMappingURL=encounters.30d4a1b60f0ebe566375.js.map
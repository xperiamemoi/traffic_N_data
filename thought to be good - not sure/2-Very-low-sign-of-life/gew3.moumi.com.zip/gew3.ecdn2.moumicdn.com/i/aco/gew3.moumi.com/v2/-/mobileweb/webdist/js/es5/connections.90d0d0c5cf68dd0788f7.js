"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [1178], {
        13736: function(e, t, n) {
            n(52675), n(89463), n(62062), n(26099), n(98992), n(81454);
            var i = n(8323),
                o = n(20017),
                r = n(8483),
                s = n(93827),
                a = n(74848);
            t.A = function(e) {
                var t = e.title,
                    n = e.description,
                    c = e.costOfService,
                    l = e.timeLimit,
                    u = e.icon,
                    d = e.actions;
                return (0, a.jsxs)("div", {
                    className: "nudge-banner",
                    children: [(0, a.jsxs)("div", {
                        className: "nudge-banner__title",
                        children: [(0, a.jsx)("div", {
                            className: "nudge-banner__title-icon",
                            children: (0, a.jsx)(r.A, {
                                name: u,
                                size: "stretch"
                            })
                        }), (0, a.jsx)(s.Sz, {
                            children: t
                        })]
                    }), (0, a.jsx)("div", {
                        className: "nudge-banner__description",
                        children: (0, a.jsx)(s.P2, {
                            color: "black",
                            children: n
                        })
                    }), c && (0, a.jsx)("div", {
                        className: "nudge-banner__cost-of-service",
                        children: (0, a.jsxs)(s.P3, {
                            children: [c, " ", (0, a.jsx)("span", {
                                className: "nudge-banner__cost-of-service-icon",
                                children: (0, a.jsx)(r.A, {
                                    name: "generic-coin",
                                    size: "sm"
                                })
                            })]
                        })
                    }), l && (0, a.jsx)("div", {
                        className: "nudge-banner__time-limit",
                        children: (0, a.jsxs)(s.P3, {
                            children: [l, " ", (0, a.jsx)("span", {
                                className: "nudge-banner__time-limit-icon",
                                children: (0, a.jsx)(r.A, {
                                    name: "generic-timer",
                                    size: "sm"
                                })
                            })]
                        })
                    }), (0, a.jsx)("div", {
                        className: "nudge-banner__actions",
                        children: (0, a.jsx)(i.A, {
                            children: d.map((function(e, t) {
                                return (0, a.jsx)(o.A, {
                                    semantic: e.semantic,
                                    text: e.text,
                                    onClick: e.onClick,
                                    size: "small"
                                }, "nudge-banner-button-" + t)
                            }))
                        })
                    })]
                })
            }
        },
        13884: function(e, t, n) {
            n.d(t, {
                Ay: function() {
                    return I
                },
                Cd: function() {
                    return P
                },
                gm: function() {
                    return T
                }
            });
            n(2892);
            var i = n(96540),
                o = n(65297),
                r = n(99417),
                s = n(58385),
                a = n(40075),
                c = n(98819),
                l = n(13614),
                u = n(84230),
                d = n(18084),
                p = n(90982),
                f = n(93529),
                h = n(91110),
                g = n(39904),
                m = n(47901),
                v = n(15376),
                A = n(87184),
                y = n(36528),
                b = n(48628),
                x = n(57556),
                S = n(50060),
                C = n(74848),
                _ = function(e) {
                    var t = e.viewType,
                        n = e.imageSrc,
                        i = e.showDelete,
                        o = e.mediaContainerRef,
                        r = e.mediaRef,
                        s = e.onClose,
                        c = e.onSend,
                        l = e.onDelete,
                        u = e.a11y,
                        d = [{
                            type: g.X2.CLOSE,
                            onClick: s
                        }];
                    return t === h.D.SHARE && d.push({
                        type: g.$4.BUTTON,
                        text: a.Ay.get(473),
                        onClick: function() {
                            return c(n)
                        }
                    }), (0, C.jsxs)(m.A, {
                        dataQA: {
                            "data-qa-page": "overlay-page"
                        },
                        children: [(0, C.jsx)(v.A, {
                            children: (0, C.jsx)(g.Ay, {
                                actions: d,
                                position: "fixed"
                            })
                        }), (0, C.jsx)(A.A, {
                            align: "stretch",
                            children: (0, C.jsxs)(y.Ay, {
                                background: y.KB.BLACK,
                                containerRef: o,
                                dataQa: "multimedia-page-media",
                                children: [(0, C.jsx)(b.Ay, {
                                    src: n,
                                    isCustom: !0,
                                    mediaRef: r,
                                    fit: b.Kj.CONTAIN,
                                    a11y: {
                                        label: null == u ? void 0 : u.imageLabel
                                    }
                                }), i ? (0, C.jsx)(S.Ay, {
                                    children: (0, C.jsx)(x.A, {
                                        type: x._.DELETE,
                                        onClick: l
                                    })
                                }) : null]
                            })
                        })]
                    })
                },
                k = n(95773),
                j = n(39778),
                E = d.A.getLogger("MultimediaPage"),
                O = u.A.getInstance("Multimedia"),
                T = function() {
                    O.invalidate("multimedia")
                },
                P = function() {
                    return O.get("multimedia")
                },
                I = function(e) {
                    var t = e.viewType,
                        n = e.multimediaVisibility,
                        u = e.chatUserId,
                        d = e.chatUserName,
                        g = e.id,
                        m = e.imageSrc,
                        v = void 0 === m ? "" : m,
                        A = (0, i.useState)(""),
                        y = A[0],
                        b = A[1],
                        x = (0, i.useState)(!1),
                        S = x[0],
                        T = x[1],
                        P = (0, i.useState)(!0),
                        I = P[0],
                        w = P[1],
                        R = (0, i.useRef)(0),
                        M = (0, i.useRef)(0),
                        N = (0, i.useRef)(null),
                        U = (0, i.useRef)(null),
                        D = (0, i.useRef)(null),
                        B = function(e) {
                            e && c.A.deleteChatMessage(u, g, 0).catch((function(e) {
                                E.error(e), f.A.showNotification({
                                    type: f.A.TYPES.ERROR
                                })
                            })), T(!1), s.A.back()
                        },
                        L = function() {
                            var e, t;
                            if (N.current && U.current) {
                                var n = null == (e = N.current) ? void 0 : e.clientWidth,
                                    i = null == (t = N.current) ? void 0 : t.clientHeight,
                                    o = R.current,
                                    r = M.current,
                                    s = n / (o >= r ? 100 : 100 * o / r),
                                    a = i / (r >= o ? 100 : 100 * r / o),
                                    c = "";
                                c += "scale(" + Math.min(s, a) + ")", U.current.style.transform = c, U.current.style.webkitTransform = c
                            }
                        },
                        F = (0, i.useCallback)((function() {
                            r.A.setTimeout((function() {
                                return L()
                            }), 100)
                        }), []),
                        G = function(e) {
                            w(!(1 !== e))
                        };
                    (0, i.useEffect)((function() {
                        if (g && v.length) return (0, l.NN)(v).then((function(e) {
                                var t = e[0],
                                    n = e[1],
                                    i = e[2];
                                R.current = n, M.current = i, L(), b(t)
                            })).catch((function(e) {
                                return (0, k.gf)(e, "Multimedia container image preload")
                            })), o.A.on(o.A.ORIENTATION_CHANGE, F), D.current = (new p.A).on(p.A.EVENTS.ZOOM, G).enable(),
                            function() {
                                var e;
                                o.A.off(o.A.ORIENTATION_CHANGE, F), null == (e = D.current) || e.disable()
                            };
                        s.A.back()
                    }), [g, v, F]);
                    var V = d ? a.Ay.get(642, {
                        name: d
                    }) : a.Ay.get(643);
                    return (0, C.jsxs)(i.Fragment, {
                        children: [(0, C.jsx)(_, {
                            viewType: t,
                            imageSrc: y,
                            showDelete: I && t === h.D.VIEW && 4 === Number(n),
                            mediaContainerRef: N,
                            mediaRef: U,
                            onClose: function() {
                                s.A.back()
                            },
                            onSend: function(e) {
                                (0, l.NN)(e).then((function(e) {
                                    var t = e[0],
                                        n = e[1],
                                        i = e[2];
                                    O.put("multimedia", {
                                        height: i,
                                        src: t,
                                        visibility: 4,
                                        width: n
                                    }, {
                                        ttl: 1e4
                                    }), s.A.back()
                                })).catch((function(e) {
                                    return (0, k.gf)(e, "Multimedia container image sent preload")
                                }))
                            },
                            onDelete: function() {
                                T(!0)
                            },
                            a11y: {
                                imageLabel: V || ""
                            }
                        }), (0, C.jsx)(j.A, {
                            header: a.Ay.get(458),
                            message: a.Ay.get(561),
                            confirmLabel: a.Ay.get(373),
                            cancelLabel: a.Ay.get(451),
                            isOpen: S,
                            onConfirm: function() {
                                return B(!0)
                            },
                            onCancel: B
                        })]
                    })
                }
        },
        16230: function(e, t) {
            var n, i, o = ((n = {})[0] = 12, n[1] = 26, n[2] = 27, n[3] = 28, n[4] = 23, n[5] = 25, n),
                r = ((i = {})[0] = 12, i[1] = 28, i[5] = 25, i),
                s = {
                    getErrorFromFieldErrorType: function(e) {
                        return r[e] || 16
                    },
                    getErrorFieldValidationErrorType: function(e) {
                        return o[e] || 16
                    }
                };
            t.A = s
        },
        19543: function(e, t, n) {
            n(51629), n(15086), n(26099);
            var i, o = n(96540),
                r = n(99417),
                s = n(1270),
                a = n(13614);
            ! function(e) {
                e.FORWARD = "forward", e.BACKWARD = "backward", e.NONE = "none"
            }(i || (i = {}));
            t.A = function(e, t, n) {
                void 0 === n && (n = {});
                var c = (0, o.useRef)(!1);
                (0, o.useEffect)((function() {
                    if (e) {
                        var o = e.current,
                            l = n.activeIndex || 0,
                            u = n.activeIndex || 0,
                            d = [],
                            p = {},
                            f = 0,
                            h = 0,
                            g = 0,
                            m = 0,
                            v = 0,
                            A = 0,
                            y = null,
                            b = null,
                            x = !1,
                            S = !1,
                            C = !1,
                            _ = !1,
                            k = 0,
                            j = "rtl" === r.A.language_direction,
                            E = function() {
                                null != o && o.offsetWidth && (k = o.children[e.current.children.length - 1].offsetLeft, Array.prototype.forEach.call(o.children, (function(e, t) {
                                    d[t] || (d[t] = {});
                                    var n = e.getAttribute("data-id");
                                    p[n] = t;
                                    var i = d[t],
                                        o = e.offsetLeft;
                                    i.el = e, i.id = n, i.index = t, i.position = o, i.width = e.offsetWidth
                                })))
                            },
                            O = function() {
                                return 1 === d.length || d.some((function(e) {
                                    return 0 !== e.position
                                }))
                            },
                            T = function(e) {
                                var t = function(e) {
                                    var t = e < 0,
                                        n = "rtl" === r.A.language_direction;
                                    return t && e < -50 ? n ? i.BACKWARD : i.FORWARD : !t && e > 50 ? n ? i.FORWARD : i.BACKWARD : i.NONE
                                }(e);
                                if (t === i.BACKWARD) {
                                    for (var n = e, s = l - 1; s >= 0 && !((n -= (null == o ? void 0 : o.children[s]).offsetWidth) < 50);) s--;
                                    return Math.max(s, 0)
                                }
                                if (t === i.FORWARD) {
                                    for (var a = -e, c = l + 1; c < d.length && !((a -= (null == o ? void 0 : o.children[c]).offsetWidth) - 50 < 50);) c++;
                                    return Math.min(c, d.length - 1)
                                }
                                return l
                            },
                            P = function(e) {
                                var t = A > 0;
                                return t && (j ? e < 0 : e > 0) ? e = 0 : !t && (j ? e <= k : e <= -k) && (e = -k), !!o && (o.style.transform = "translate3d(" + e + "px, 0, 0)", v = e, !0)
                            },
                            I = function(e, n) {
                                y = e, l = e.index, n && (null == o || o.classList.add("is-animated")), P(-e.position), n ? (0, a.Yn)((0, s.A)(o), (function() {
                                    return null == o || o.classList.remove("is-animated"), t && y && t(y.index), void(S = !1)
                                })) : S = !1
                            },
                            w = function(e) {
                                if (O() || E(), !(d.length < 2 || S)) {
                                    var t = e.touches[0];
                                    x = !1, f = h = 0, g = t.pageX, m = t.pageY, y && (u = y.index), C = !0
                                }
                            },
                            R = function(e) {
                                if (!(d.length < 2 || x || S)) {
                                    if (!C) return C = !1, void w(e);
                                    var t = e.touches[0],
                                        i = t.pageX - g,
                                        o = t.pageY - m;
                                    h += i, g = t.pageX, m = t.pageY;
                                    var r = h - f;
                                    _ || (_ = Math.abs(i) > Math.abs(o)), _ ? (e.preventDefault(), A = i, P(v + i)) : x = !0;
                                    var s, a = T(r) || l;
                                    s = d[a], b !== s && n.activeClassName && (b && b.el.classList.remove(n.activeClassName), s && (s.el.classList.add(n.activeClassName), b = s))
                                }
                            },
                            M = function() {
                                if (!(d.length < 2 || !_ || S)) {
                                    S = !0, C = !1;
                                    var e = T(h - f),
                                        t = d[e];
                                    I(t, !0), _ = !1
                                }
                            };
                        return E(), O() && (I(d[u], c.current), c.current = !0), null == o || o.addEventListener("touchstart", w), null == o || o.addEventListener("touchmove", R), null == o || o.addEventListener("touchend", M),
                            function() {
                                null == o || o.removeEventListener("touchstart", w), null == o || o.removeEventListener("touchmove", R), null == o || o.removeEventListener("touchend", M)
                            }
                    }
                }), [e, t, n])
            }
        },
        20931: function(e, t, n) {
            var i, o = n(57917),
                r = n(18084),
                s = n(15566),
                a = r.A.getLogger("UserSubstituteModel"),
                c = o.A.extend({
                    name: "UserSubstitute",
                    getRequestMessageType: 696,
                    getResponseMessageType: 697,
                    setRequestMessageType: 582,
                    setResponseMessageType: 387,
                    preventMultiple: !0,
                    commitCache: !1,
                    get: function(e) {
                        var t = e.id,
                            n = (new s.lQW).setId(t);
                        return c._super.get.call(this, n)
                    },
                    skipPromo: function(e) {
                        var t = e.id,
                            n = e.context;
                        this.set({
                            id: t,
                            context: n,
                            action: 1
                        })
                    },
                    acceptPromo: function(e) {
                        var t = e.id,
                            n = e.context;
                        this.set({
                            id: t,
                            context: n,
                            action: 2
                        })
                    },
                    set: function(e) {
                        var t = e.id,
                            n = e.context,
                            i = e.action;
                        t && n && i || a.error("Missing some of the properties for ServerUserSubstituteAction", {
                            id: t,
                            context: n,
                            action: i
                        });
                        var o = (new s.Pie).setId(t).setContext(n).setAction(i);
                        return c._super.set.call(this, o)
                    },
                    shouldCache_: function() {
                        return !1
                    }
                }, "UserSubstituteModel");
            c.getInstance = function() {
                return i || (i = new c)
            }, t.A = c
        },
        21204: function(e, t, n) {
            function i(e, t) {
                return "https://mlink." + e + "/aa/landto?install_ref=" + t
            }
            n.d(t, {
                A: function() {
                    return i
                }
            })
        },
        23318: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return i
                }
            });
            n(50113), n(26099), n(27495), n(98992), n(72577);

            function i(e, t) {
                var n, i = ((null == e ? void 0 : e.external_endpoints) || []).find((function(e) {
                    return e.type === t
                }));
                return null == i || null == (n = i.url) ? void 0 : n.replace("http://", "https://")
            }
        },
        23336: function(e, t, n) {
            n.d(t, {
                F: function() {
                    return o
                }
            });
            var i, o, r = n(46942),
                s = n.n(r),
                a = n(74848);
            ! function(e) {
                e.DEFAULT = "DEFAULT", e.SQUARE = "SQUARE"
            }(o || (o = {}));
            var c = ((i = {})[o.DEFAULT] = "", i[o.SQUARE] = "external-ads-banner--square", i);
            t.A = function(e) {
                var t, n = e.adSlot,
                    i = e.dataQa,
                    r = e.type,
                    l = void 0 === r ? o.DEFAULT : r,
                    u = e.innerRef,
                    d = e.disabled,
                    p = s()(((t = {
                        "external-ads-banner": !0
                    })[c[l]] = !0, t["external-ads-banner--no-events"] = d, t));
                return (0, a.jsx)("div", {
                    className: p,
                    children: (0, a.jsx)("div", {
                        id: n,
                        "data-qa-ads": i,
                        ref: u
                    })
                })
            }
        },
        24537: function(e, t, n) {
            n(23792), n(10287), n(26099), n(3362), n(47764), n(62953);
            var i = n(23715),
                o = n(20387);

            function r(e, t) {
                return r = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, r(e, t)
            }
            var s = function(e) {
                function t() {
                    var t;
                    return (t = e.call(this) || this).EVENTS = {
                        USER_CHANGED: "change",
                        USER_CHANGED_TS: "change_ts",
                        ONLINE: "online"
                    }, t.savedUsersToChangeFavourite = {}, i.A.on(i.A.EVENTS.ONLINE, t.backOnline, t), t
                }
                var n, o;
                o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, r(n, o);
                var s = t.prototype;
                return s.backOnline = function() {
                    var e = [];
                    for (var t in this.savedUsersToChangeFavourite) {
                        var n = this.savedUsersToChangeFavourite[t];
                        e.push(a(n.data, n.callback))
                    }
                    this.savedUsersToChangeFavourite = {}, this.trigger(this.EVENTS.ONLINE, Promise.all(e))
                }, s.saveUser = function(e, t) {
                    this.savedUsersToChangeFavourite[e.user.user_id] = {
                        data: e,
                        callback: t
                    }
                }, s.toggleFavouriteStatus = function(e, t) {
                    var n = e.user;
                    n.is_favourite = !n.is_favourite, this.trigger(this.EVENTS.USER_CHANGED_TS, n), i.A.isOnline() ? a(e, t) : this.saveUser(e, t)
                }, t
            }(n(58544).sV);

            function a(e, t) {
                var n = e.user,
                    i = e.context,
                    r = {
                        uid: n.user_id,
                        folder: o.A.TYPES.FAVOURITES,
                        context: i
                    },
                    s = null;
                return !0 === n.is_favourite ? s = o.A.getInstance().addUserToFolder(r) : (s = o.A.getInstance().removeUserFromFolder(r), t && s.then(t)), s
            }
            t.A = new s
        },
        24711: function(e, t, n) {
            n.d(t, {
                z: function() {
                    return s
                }
            });
            n(50113), n(26099), n(98992), n(72577);
            var i = n(16230),
                o = n(82637),
                r = n(98666);

            function s(e, t) {
                var n = ((null == e ? void 0 : e.user_field_errors) || []).find((function(e) {
                    return e.user_field === t
                }));
                return n ? {
                    errorMessage: n.error_message,
                    errorType: i.A.getErrorFromFieldErrorType(n.error_type),
                    errorField: r.i[t],
                    isInvalid: !0
                } : (0, o.L)()
            }
        },
        33527: function(e, t, n) {
            var i = n(20387),
                o = n(58544),
                r = n(31087),
                s = (0, o.lh)(),
                a = i.A.EVENTS,
                c = a.USER_ADDED,
                l = a.USER_REMOVED,
                u = i.A.TYPES.FAVOURITES,
                d = i.A.getInstance();

            function p(e, t) {
                r.A.getInstance().updateCache(e, "isFavourite", t), s.trigger(e, t)
            }

            function f(e) {
                var t = e.uid;
                e.folder === u && p(t, !0)
            }

            function h(e) {
                var t = e.uid;
                e.folder === u && p(t, !1)
            }
            t.A = {
                start: function() {
                    d.on(c, f), d.on(l, h)
                },
                stop: function() {
                    d.off(c, f), d.off(l, h)
                },
                onFavoriteStateChange: s.subscribe
            }
        },
        35299: function(e, t, n) {
            n(52675), n(45700), n(2008), n(50113), n(51629), n(74423), n(62062), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(21699), n(98992), n(54520), n(72577), n(3949), n(81454), n(23500);
            var i = n(96540),
                o = n(93765),
                r = n(78979),
                s = n(74848),
                a = ["value", "isChecked", "onChange", "name", "dataQA"];

            function c(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function l(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? c(Object(n), !0).forEach((function(t) {
                        u(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function u(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            t.A = function(e) {
                var t, n = e.options,
                    c = e.name,
                    u = e.onGroupChange,
                    d = (0, i.useState)(null == (t = n.find((function(e) {
                        return e.isChecked
                    }))) ? void 0 : t.value),
                    p = d[0],
                    f = d[1];
                return (0, s.jsx)(r.A, {
                    dataQA: e.dataQA,
                    spacing: "compact",
                    children: n.map((function(e, t) {
                        var n = e.value,
                            i = (e.isChecked, e.onChange),
                            r = e.name,
                            d = e.dataQA,
                            h = function(e, t) {
                                if (null == e) return {};
                                var n = {};
                                for (var i in e)
                                    if ({}.hasOwnProperty.call(e, i)) {
                                        if (t.includes(i)) continue;
                                        n[i] = e[i]
                                    }
                                return n
                            }(e, a);
                        return (0, s.jsx)(o.A, l({
                            value: n,
                            name: r || c,
                            isChecked: Boolean(n && n === p),
                            onChange: function(e) {
                                return function(e, t) {
                                    var n = e.target.value;
                                    f(n), t && t(e), u && u(n)
                                }(e, i)
                            },
                            dataQA: l({
                                "data-qa": "radio-group-item"
                            }, d)
                        }, h), t)
                    }))
                })
            }
        },
        46875: function(e, t, n) {
            var i;
            n.d(t, {
                    X: function() {
                        return i
                    }
                }),
                function(e) {
                    e.DELIVERED = "DELIVERED", e.FAILED = "FAILED", e.READ = "READ", e.SENDING = "SENDING", e.UPLOADING = "UPLOADING", e.PROMO = "PROMO"
                }(i || (i = {}))
        },
        51700: function(e, t, n) {
            n.r(t), n.d(t, {
                default: function() {
                    return dl
                }
            });
            n(2892), n(10287);
            var i = n(96540),
                o = n(72537),
                r = n(85558),
                s = (n(52675), n(45700), n(2008), n(50113), n(48980), n(51629), n(74423), n(25276), n(62062), n(15086), n(60739), n(89572), n(33110), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(3362), n(38781), n(98992), n(54520), n(72577), n(3949), n(81454), n(37550), n(23500), n(99417)),
                a = n(58385),
                c = n(74389),
                l = n(79860),
                u = n(26666),
                d = n(49952),
                p = n(98819),
                f = n(20931),
                h = n(31087),
                g = n(20387),
                m = n(40075),
                v = n(24537),
                A = n(13614),
                y = n(47632),
                b = n(65609),
                x = n(39904),
                S = n(74848);

            function C(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function _(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? C(Object(n), !0).forEach((function(t) {
                        k(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : C(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function k(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var j = function(e) {
                    var t, n, o, r, s, u, d, p = e.user,
                        f = e.promos,
                        h = e.clientSource,
                        g = e.isHeaderProfileHidden,
                        C = e.isHidingVideoCall,
                        k = e.isFavourite,
                        j = e.isUserSubstitute,
                        E = e.isSelectable,
                        O = e.isShowingBlockingTip,
                        T = e.onDeleteChat,
                        P = e.onFavouriteUser,
                        I = e.onOpenProfile,
                        w = e.onToggleReport,
                        R = e.scrollRef,
                        M = (0, i.useState)(!1),
                        N = M[0],
                        U = M[1],
                        D = function() {
                            var e = f.find((function(e) {
                                return 10017 === e.getPromoBlockType()
                            }));
                            if (e) {
                                var t = e.getButtons([])[0];
                                a.A.navigate(c.x.VIDEO_CHAT_EXPLANATION, {
                                    promoBlock: e.toJSON(),
                                    src: (0, A.Yz)(p),
                                    externalUrl: null == t ? void 0 : t.getRedirectPage().getUrl()
                                })
                            }
                        };
                    return (0, S.jsxs)(i.Fragment, {
                        children: [(0, S.jsx)(x.Ay, _({
                            position: "sticky",
                            hasShadow: !0,
                            shadowRef: R,
                            isShowingBlockingTip: O
                        }, (t = p.hasProfilePhoto() && (0, A.S$)(p.getProfilePhoto().getLargeUrl()), n = t && y.A.getImageUrlForSize(t, 36), o = p.getIsDeleted(), r = 4 !== p.getOnlineStatus(), s = E || g, u = E ? {
                            type: x.$4.BUTTON,
                            text: m.Ay.get(451),
                            isActive: !0,
                            onClick: function() {
                                return w(!1)
                            }
                        } : {
                            type: x.X2.ELLIPSIS,
                            onClick: function() {
                                return U(!0)
                            }
                        }, d = [{
                            type: x.X2.BACK,
                            onClick: E ? function() {
                                return w(!1)
                            } : function() {
                                return a.A.back()
                            }
                        }, u], C || E || d.unshift({
                            type: x.X2.VIDEO_CALL,
                            onClick: D
                        }), {
                            profile: E ? void 0 : {
                                user: {
                                    name: p.getName(),
                                    status: {
                                        online: (0, A.fI)(p.getOnlineStatus())
                                    },
                                    disguise: o ? "deleted" : void 0,
                                    photo: n ? {
                                        src: n
                                    } : void 0,
                                    gender: (0, A.v4)(p.getGender())
                                },
                                additional: !o && r ? p.getOnlineStatusText() : void 0,
                                onClick: I
                            },
                            isProfileHidden: s,
                            title: E ? m.Ay.get(436) : void 0,
                            actions: d,
                            onClick: I
                        }))), N && (0, S.jsx)(b.A, {
                            user: {
                                userId: p.getUserId(),
                                isFavourite: k,
                                isMatch: p.getIsMatch(),
                                isDeleted: p.getIsDeleted(),
                                isSubstitute: j,
                                gender: p.getGender()
                            },
                            showUnmatchSkip: 2 !== h,
                            onDeleteChat: T,
                            onFavouriteToggle: function() {
                                P(), v.A.toggleFavouriteStatus({
                                    user: p.toJSON(),
                                    context: h
                                }, (function() {})), (0, l.sx)(332, {
                                    element: 181
                                }), (0, l.sx)(123, {
                                    action_type: p.getIsFavourite() ? 6 : 7,
                                    activation_place: 96,
                                    encrypted_user_id: p.getUserId()
                                })
                            },
                            onViewProfile: I,
                            onAnimationOutComplete: function() {
                                return U(!1)
                            }
                        })]
                    })
                },
                E = n(74362),
                O = n(65297),
                T = {};
            O.A.on(O.A.Session.SESSION_CHANGED, (function() {
                T = {}
            }));
            var P, I = function(e) {
                    return T[e]
                },
                w = function(e, t) {
                    T[e] = t
                },
                R = function(e) {
                    delete T[e]
                },
                M = (n(69085), n(27495), n(1270)),
                N = n(66392),
                U = n(93529),
                D = n(13884),
                B = n(28030),
                L = n(27378),
                F = n(254),
                G = n(46875),
                V = n(23318),
                q = n(23715),
                H = n(91110),
                Q = n(36521);

            function Y(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function W(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Y(Object(n), !0).forEach((function(t) {
                        z(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Y(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function z(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function K(e) {
                var t, n, i, o, r = e.onBeforeUpload,
                    u = e.onSendMessage,
                    d = e.getClientSource,
                    f = e.getStreamId,
                    h = N.Ay.$satisfy("form[id=photo-form][class=photo-form][action=photoUpload][method=post][enctype=multipart/form-data] input[type=file][accept=image/*][name=file]"),
                    g = h.get(0),
                    m = h.find("input").on("change", (function() {
                        var e = m.get(0).files[0];
                        if (e) {
                            var n = new s.A.FileReader;
                            n.onload = b, n.onerror = S, y.A.getOrientation(e).then((function(i) {
                                t = i, n.readAsDataURL(e)
                            })).catch(S)
                        } else S()
                    })),
                    v = new L.A("photo-upload", 23);
                return P = {
                    zepto: h,
                    uploadMultimedia: function(e) {
                        o = e, n = void 0;
                        var t = null;
                        return Q.A.ios || Q.A.windowsPhone ? (C(), m.get(0).click()) : t = {
                            onCaptureOptionClick: function() {
                                return A("capture")
                            },
                            onChooseOptionClick: function() {
                                return A("choose")
                            }
                        }, t
                    },
                    uploadFromCamera: function(e, t) {
                        o = e, n = t, A()
                    },
                    checkPendingMultimedia: function(e) {
                        var t = function() {
                            var e = (0, D.Cd)();
                            if (null != e && e.visibility && e.src) return (0, D.gm)(), e;
                            return null
                        }();
                        if (!t) return;
                        var n = i || {},
                            r = p.A.isReplyFeatureAllowed(o),
                            s = e || {},
                            a = s.replyToUid,
                            c = s.replyToMessage,
                            l = new F.Ay({
                                context: d(),
                                image: t,
                                messageType: n.messageType || 19,
                                replyToUid: n.replyToUid || a,
                                repliedMessage: c,
                                streamId: f(),
                                toPersonId: o
                            }, null, {
                                isReplyFeatureAllowed: r
                            });
                        return i = {}, _(l, t), !0
                    },
                    uploadAudio: function(e, t) {
                        var n = p.A.isReplyFeatureAllowed(e);
                        o = e,
                            function(e, t) {
                                var n = new s.A.FormData;
                                for (var i in t) "waveform" !== i && "waveformSrv" !== i && n.append(i, t[i]);
                                e.setStatus(G.X.SENDING), p.A.add(e), J(n, t, (function(t, n) {
                                    t ? u(t) : null != n && n.id && (e.audio.id = n.id, function(e, t, n) {
                                        p.A.send(e, t).then((function(e) {
                                            n(null, e)
                                        }), n)
                                    }(o, e, (function(e, t) {
                                        u(e, t)
                                    })))
                                }), 33)
                            }(new F.Ay({
                                context: d(),
                                audio: {
                                    waveform: t.waveform,
                                    waveformSrv: t.waveformSrv,
                                    format: {
                                        type: t.type,
                                        sample_rate_hz: t.sample_rate_hz,
                                        bit_rate_kbps: t.bit_rate_kbps,
                                        audio_stereo: t.audio_stereo,
                                        vbr_enable: t.vbr_enable
                                    },
                                    duration: t.duration / 1e3
                                },
                                messageType: 19,
                                streamId: f(),
                                toPersonId: o,
                                replyToUid: t.replyToUid,
                                repliedMessage: t.replyToMessage
                            }, null, {
                                isReplyFeatureAllowed: n
                            }), t)
                    }
                };

                function A(e) {
                    "choose" === e ? m.removeAttr("capture") : m.attr("capture", "camera"), C(), m.get(0).click()
                }

                function b(e) {
                    var n;
                    null != (n = e.target) && n.result ? y.A.rotateBase64(e.target.result, t, !0).then(x).catch(S) : S()
                }

                function x(e) {
                    var t = e.substr(0, 12);
                    "data:base64," === t && (e = e.replace(t, "data:image/jpeg;base64,"));
                    var r, s = Object.assign({
                        result: e
                    }, n);
                    i = r = s, a.A.navigate(c.x.MULTIMEDIA, {
                        id: o,
                        source: r.result,
                        viewType: H.D.SHARE
                    }), n = void 0
                }

                function S() {
                    U.A.showNotification({
                        type: U.A.TYPES.ERROR
                    })
                }

                function C() {
                    null != g && g.file && (g.file.value = "")
                }

                function _(e, t) {
                    var n = new s.A.FormData(g);
                    C(), v.start(Date.now()), r && r(e), e.setStatus(G.X.SENDING), p.A.add(e), J(n, t, (function(t, n) {
                        if (t) return v.stop(), void u(t);
                        ! function(e, t) {
                            t && (e.image = t);
                            ! function(e, t, n) {
                                p.A.send(e, t).then((function(e) {
                                    var t;
                                    (0, l.sx)(73, {
                                        encrypted_user_id: null == (t = e.toPersonId) ? void 0 : t.toString(),
                                        is_selfie: 30 === e.messageType,
                                        photo_id: e.image.id
                                    }), n(null, e)
                                }), n)
                            }(o, e, (function(e, t) {
                                v.stop(), u(e, t)
                            }))
                        }(e, n)
                    }))
                }
            }

            function J(e, t, n, i) {
                void 0 === i && (i = 5);
                var o = (0, V.A)(B.A.getSettings(), i);
                o ? M.A.ajax({
                    contentType: !1,
                    data: e,
                    dataType: "json",
                    error: function() {
                        q.A.whenOnline((function() {
                            return J(e, t, n)
                        }))
                    },
                    processData: !1,
                    success: function(e) {
                        if (!e || "string" != typeof e.photo_id && "number" != typeof e.audio_id) return void n(new Error("Invalid id provided in multimedia."));
                        n(null, W(W({}, t), {}, {
                            id: e.photo_id || e.audio_id
                        }))
                    },
                    type: "POST",
                    url: o
                }) : n(new Error("No upload endpoint provided."))
            }
            n(76201);
            var X = n(18084),
                Z = n(25093),
                $ = (n(21699), [439, 459, 460, 458, 461, 514, 477, 467, 476, 473, 472, 471, 468, 469, 470, 466, 465]),
                ee = [463, 564],
                te = [458, 561];

            function ne(e) {
                var t, n = (null == e ? void 0 : e.promoBanners) || [],
                    i = e.messages,
                    o = e.dismissedPromoBanners || [],
                    r = function(e) {
                        void 0 === e && (e = []);
                        for (var t, n = function(t) {
                                var n = e.find((function(e) {
                                    return e.getPromoBlockType() === $[t]
                                }));
                                if (n) return {
                                    v: n
                                }
                            }, i = 0; i < $.length; i += 1)
                            if (t = n(i)) return t.v;
                        return null
                    }(n),
                    s = i.length ? i[i.length - 1].banner : void 0;
                return r && !o.includes(r.getPromoBlockType()) && (t = r.toJSON()), s && $.includes(s.promo_block_type) && !o.includes(s.promo_block_type) && (t = s), t
            }
            var ie = n(13315),
                oe = n(75248),
                re = n(41298),
                se = n(74787),
                ae = n(54462),
                ce = n(17369),
                le = n(46169),
                ue = n(59678),
                de = n(5586),
                pe = n(36721),
                fe = n(28431),
                he = (n(72712), n(58940), n(71761), n(8872), n(73090)),
                ge = n(15566),
                me = n(44851);

            function ve(e, t, n) {
                if (e) return 6;
                var i = p.A.getBlockingFeature(t),
                    o = p.A.getInitialChatScreen(t);
                return Boolean(o) ? i ? 10 : 9 : i || p.A.getMaxUnansweredMessages(t) <= 0 || n.find((function(e) {
                    return 42 === e.messageType
                })) ? 3 : n.find((function(e) {
                    return e.isYours()
                })) ? 5 : 2
            }

            function Ae(e) {
                var t = e.forceTrack,
                    n = e.id,
                    i = e.activationPlace,
                    o = e.isUserSubstitute,
                    r = e.clientSource;
                if (t) {
                    (function(e) {
                        var t = p.A.getCachedClientOpenChat(e);
                        return 1 === t.initialScreenType && t.isMatch
                    })(n) && function(e, t) {
                        (0, l.sx)(49, {
                            activation_place: t
                        }), (0, l.sx)(266, {
                            encrypted_user_id: e.toString(),
                            match_status: 2
                        })
                    }(n, i);
                    var s, a = p.A.getCachedClientOpenChat(n),
                        c = a.chatUser,
                        u = a.initialScreen,
                        d = a.initialScreenType,
                        f = a.isMatch,
                        h = a.messages,
                        g = a.userId,
                        m = function(e, t) {
                            var n = p.A.getCachedClientOpenChat(t).initialScreen;
                            return (null == e ? void 0 : e.getPaymentAmount()) || n && parseInt(n.message.match(/[0-9]+/g), 10) || 0
                        }(null == u ? void 0 : u.blockingFeature, n);
                    if (o) {
                        var v = h.reduce((function(e, t) {
                            return e + (t.isRead ? 0 : 1)
                        }), 0);
                        s = {
                            chat_screen_type: ve(o, n, h),
                            encrypted_user_id: g,
                            mode_connection: 6,
                            activation_place: 191,
                            num_unread: v
                        }
                    } else s = {
                        activation_place: i,
                        blocker_type: d || 0,
                        chat_screen_type: ve(o, n, h),
                        client_source: r,
                        credits_cost: m,
                        encrypted_user_id: g,
                        is_favourite: c.getIsFavourite(!1),
                        match_status: f ? 2 : 3,
                        mode_connection: 6,
                        recepient_online_status: c.getOnlineStatus()
                    };
                    (0, l.sx)(53, s),
                    function(e) {
                        switch (e) {
                            case 1:
                                (0, l.sx)(258, {
                                    element: 32
                                });
                                break;
                            case 13:
                            case 15:
                                (0, l.sx)(258, {
                                    element: 304
                                });
                                break;
                            case 25:
                            case 21:
                            case 14:
                                (0, l.sx)(258, {
                                    element: 299
                                });
                                break;
                            case 11:
                                (0, l.sx)(258, {
                                    element: 360
                                })
                        }
                    }(d)
                }
            }

            function ye(e) {
                var t = he.A.getUserId();
                return e.reduce((function(e, n) {
                    return e + Number(n.fromPersonId === t)
                }), 0)
            }
            var be = "quota";

            function xe(e, t, n) {
                if (e) return 396;
                var i = p.A.getBlockingFeature(n),
                    o = i || p.A.getMaxUnansweredMessages(n) <= 0;
                return p.A.getInitialChatScreen(n) ? function(e) {
                    return e ? 85 : 94
                }(o) : o ? 85 : p.A.isContactsForCreditsFeature(i) ? 66 : t
            }
            var Se, Ce = n(91532);

            function _e(e) {
                U.A.showNotification({
                    type: U.A.TYPES.ERROR,
                    text: e
                })
            }! function(e) {
                e.MULTIMEDIA = "MULTIMEDIA", e.MESSAGE = "MESSAGE"
            }(Se || (Se = {}));
            var ke = ["UNKNOWN", "XHR", "PARSE_ERROR", "UNKNOWN", "SERVER_ERROR", "HANDLER_UNSATISFIED", "INVALID_PROTO_ERROR", "OFFLINE", "ABORTED"],
                je = X.A.getLogger("Chat"),
                Ee = [];
            var Oe = {
                    add: function(e) {
                        Ee.includes(e) || Ee.push(e)
                    },
                    remove: function(e) {
                        var t = Ee.indexOf(e); - 1 !== t && Ee.splice(t, 1)
                    },
                    has: function(e) {
                        return -1 !== Ee.indexOf(e)
                    }
                },
                Te = [565, 432, 479, 433];
            n(28706);
            var Pe = n(31709),
                Ie = n(99644),
                we = n(13011),
                Re = (n(88431), n(23215), n(46942)),
                Me = n.n(Re),
                Ne = n(84914),
                Ue = n(73510),
                De = n(64741),
                Be = n(38795),
                Le = (n(48598), n(84864), n(57465), n(87745), n(10901)),
                Fe = new RegExp(/<\/?(?=\w)(br|a).*?>/gi),
                Ge = function(e, t) {
                    return e.filter((function(e) {
                        return void 0 !== e && "" !== e
                    })).map((function(e) {
                        return (0, Le.A)(e).replace(Fe, " ")
                    })).join(t || ", ")
                },
                Ve = n(63108),
                qe = n(73033),
                He = n(5005),
                Qe = n(30244),
                Ye = n(40178),
                We = n(74785),
                ze = n(1529),
                Ke = n(68451),
                Je = n(84654),
                Xe = n(58109),
                Ze = n(95511);

            function $e(e, t) {
                return $e = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, $e(e, t)
            }
            var et = X.A.getLogger("NewChatComponent"),
                tt = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).isUrlPreviewEnabled = !1, n.urlPreviewObserver = void 0, n.urlPreviewObserver = null, n.isUrlPreviewEnabled = o.A.isAllowed(o.A.getSync(248)), n.state = n.getContextValue(), n
                    }
                    var n, i;
                    i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, $e(n, i);
                    var r = t.prototype;
                    return r.componentDidMount = function() {
                        var e = this,
                            t = o.A.getObservable(248);
                        this.urlPreviewObserver = o.A.observe(t, (function(t) {
                            e.isUrlPreviewEnabled = o.A.isAllowed(t), e.setState(e.getContextValue())
                        }), {
                            leading: !1
                        })
                    }, r.componentWillUnmount = function() {
                        this.urlPreviewObserver.stop()
                    }, r.getContextValue = function() {
                        return {
                            currentUser: {
                                id: he.A.getUserId()
                            },
                            RPC: Pe.Ay,
                            messagesListFeatures: [Ze.A, this.isUrlPreviewEnabled ? Xe.Ay : null].filter(it),
                            Logger: {
                                error: function(e) {
                                    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) n[i - 1] = arguments[i];
                                    et.error(e, n)
                                },
                                warn: function(e) {
                                    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) n[i - 1] = arguments[i];
                                    et.warn(e, n)
                                },
                                debug: function(e) {
                                    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) n[i - 1] = arguments[i];
                                    et.debug(e, n)
                                }
                            },
                            trackEvent: l.sx,
                            Location: {
                                GoogleMapsApiKey: "AIzaSyDCqI1zhbIDfhr9bbym1ovQAlhH9w3Ir9M",
                                nonce: s.A._nonce
                            }
                        }
                    }, r.render = function() {
                        return (0, S.jsx)(Ve.MY, {
                            value: this.state,
                            children: this.props.children
                        })
                    }, t
                }(i.Component),
                nt = tt;

            function it(e) {
                return null != e
            }
            var ot = n(25274),
                rt = n(84084);

            function st(e) {
                return (0, i.useMemo)((function() {
                    if (e) return {
                        title: p.A.getSenderName(e),
                        description: at(e),
                        media: ct(e)
                    }
                }), [e])
            }

            function at(e) {
                if (!e) return "";
                switch (e.messageType) {
                    case 7:
                        return m.Ay.get(35);
                    case 47:
                        return m.Ay.get(34);
                    case 36:
                        return m.Ay.get(32);
                    case 23:
                        return m.Ay.get(36);
                    case 19:
                        if (e.audio) return m.Ay.get(31);
                        if (e.video) return m.Ay.get(37);
                        if (e.image) return m.Ay.get(33);
                        break;
                    case "EMOJI":
                    case "ANIMATED_EMOJI":
                    case 1:
                        return e.message || ""
                }
                return ""
            }

            function ct(e) {
                var t, n, i, o;
                if (e) {
                    var r, s = "squared";
                    switch (e.messageType) {
                        case 47:
                        case 7:
                            return;
                        case 36:
                            r = null == (t = e.gif) ? void 0 : t.url;
                            break;
                        case 22:
                        case 23:
                            r = null == (n = e.image) ? void 0 : n.src;
                            break;
                        case 19:
                            null != (i = e.video) && i.previewUrl ? (r = e.video.previewUrl, s = "circle") : null != (o = e.image) && o.src && (r = e.image.src)
                    }
                    return r ? {
                        src: r,
                        shape: s
                    } : void 0
                }
            }
            var lt = function(e) {
                var t = e.repliedMessage,
                    n = e.direction,
                    o = e.isContinuation,
                    r = e.message,
                    s = e.extra,
                    a = e.messageSenderUserName,
                    c = st(t);
                return (0, i.useEffect)((function() {
                    t && (0, l.sx)(258, {
                        element: 1234
                    })
                }), [t]), t ? c ? (0, S.jsx)(rt.A, {
                    header: c,
                    direction: n,
                    isContinuation: o,
                    message: r,
                    extra: s,
                    a11y: {
                        label: Ge([a, m.Ay.get(430)]),
                        name: a
                    }
                }) : null : r
            };

            function ut(e) {
                var t = e.message,
                    n = e.customLongTapDelay,
                    i = e.onShowOptions,
                    o = e.onMessageLike,
                    r = -1,
                    a = null,
                    c = 0,
                    l = "number" == typeof n ? n : 800;

                function u(e) {
                    return e.preventDefault(), e.stopPropagation(), !1
                }

                function d() {
                    a = null, s.A.clearTimeout(r)
                }
                return {
                    onTouchStart: function(e) {
                        if (s.A.addEventListener("contextmenu", u), e)
                            if (1 === e.touches.length) {
                                a = e.touches[0], r = s.A.setTimeout((function() {
                                    null == i || i(t)
                                }), l);
                                var n = (new Date).getTime();
                                c ? o && c && (n - c <= 300 ? (o(t), c = 0) : c = n) : c = n
                            } else d()
                    },
                    onTouchMove: function(e) {
                        a && e && (e.touches.length > 2 || function(e) {
                            if (!a) return !0;
                            var t = e.touches[0];
                            return Math.abs(t.pageX - a.pageX) > 7 || Math.abs(t.pageY - a.pageY) > 7
                        }(e)) && (d(), c = 0)
                    },
                    onTouchEnd: function() {
                        d(), s.A.removeEventListener("contextmenu", u)
                    },
                    onTouchCancel: function() {
                        d()
                    }
                }
            }
            var dt = function(e) {
                    var t = e.message,
                        n = e.direction,
                        o = e.isContinuation,
                        r = e.messageVisibilityEvent,
                        s = e.messageSenderUserName,
                        a = t.audio,
                        c = void 0 === a ? {} : a,
                        u = t.id,
                        d = t.repliedMessage,
                        p = t.status,
                        f = c.id,
                        h = c.src,
                        g = c.waveform,
                        v = c.duration,
                        A = (0, i.useRef)(null),
                        y = (0, i.useRef)(!1),
                        b = ut({
                            message: t,
                            onShowOptions: e.onShowOptions
                        }),
                        x = b.onTouchStart,
                        C = b.onTouchMove,
                        _ = b.onTouchEnd,
                        k = b.onTouchCancel;
                    return (0, i.useEffect)((function() {
                        if (r && !y.current) return r.subscribe(e, null),
                            function() {
                                return r.unsubscribe(e, null)
                            };

                        function e(n) {
                            u === n && (y.current = !0, r.unsubscribe(e, null), (0, l.sx)(258, {
                                element: 1201
                            }), t.isLiked && t.isYours() && (0, l.sx)(258, {
                                element: 1581
                            }))
                        }
                    }), [t, r, y, u]), (0, S.jsx)(qe.lN, {
                        onAudioRef: function(e) {
                            A.current = e
                        },
                        id: f,
                        src: h,
                        duration: v,
                        onClickContent: function() {
                            var e, t;
                            A.current && (!(t = A.current) || t.paused) ? (A.current.currentTime > 0 && (e = 742), e = 1134) : e = 741, (0, l.sx)(332, {
                                element: e,
                                parent_element: "in" === n ? 1203 : 1202
                            })
                        },
                        onPlayError: function() {
                            U.A.showNotification({
                                type: U.A.TYPES.ERROR
                            })
                        },
                        children: function(e) {
                            var t = e.percentage,
                                i = e.playback,
                                r = e.time,
                                a = e.onClickContent;
                            return (0, S.jsx)(lt, {
                                repliedMessage: d,
                                direction: n,
                                isContinuation: o,
                                messageSenderUserName: s,
                                message: (0, S.jsx)(ot.A, {
                                    percentage: t,
                                    bars: g,
                                    playback: i,
                                    time: r,
                                    direction: n,
                                    isContinuation: o,
                                    status: null != p && p.text ? {
                                        text: p.text
                                    } : void 0,
                                    onClickContent: a,
                                    onTouchStartContent: x,
                                    onTouchMoveContent: C,
                                    onTouchEndContent: _,
                                    onTouchCancelContent: k,
                                    a11y: {
                                        label: Ge([s, m.Ay.get(387), m.Ay.get(388, {
                                            time: r
                                        })]),
                                        contentLabel: Ge([m.Ay.get(387), m.Ay.get(388, {
                                            time: r
                                        }), "playing" === i ? m.Ay.get(629) : m.Ay.get(630)]),
                                        name: s
                                    }
                                })
                            })
                        }
                    })
                },
                pt = n(3508),
                ft = n(21204),
                ht = n(33926),
                gt = function(e) {
                    var t = e.message,
                        n = (0, ft.A)(pt.A.get("partner_url"), "message-type:" + t.messageType),
                        i = (0, ht.P)(m.Ay.get(412)),
                        o = 28 === t.messageType && function(e) {
                            if (!e) return;
                            var t = e.getName();
                            return 2 === e.getGender() ? m.Ay.get(445, {
                                str: t
                            }) : m.Ay.get(446, {
                                str: t
                            })
                        }(e.chatUser) || t.message;
                    return (0, S.jsx)(We.A, {
                        message: o,
                        notice: '<a href="' + n + '" target="_blank">' + i + "</a><br>",
                        direction: e.direction,
                        a11y: {}
                    })
                };
            var mt = n(34923);

            function vt(e, t) {
                return vt = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, vt(e, t)
            }
            var At = {
                    HEART: "heart"
                },
                yt = function(e) {
                    function t() {
                        for (var t, n = arguments.length, i = new Array(n), o = 0; o < n; o++) i[o] = arguments[o];
                        return (t = e.call.apply(e, [this].concat(i)) || this).trackViewElement = function() {
                            t.props.emoji === At.HEART && (0, l.sx)(258, {
                                element: 625
                            })
                        }, t
                    }
                    var n, i;
                    return i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, vt(n, i), t.prototype.render = function() {
                        var e = this.props,
                            t = e.message,
                            n = e.direction,
                            i = e.emoji,
                            o = e.isContinuation,
                            r = e.messageSenderUserName;
                        return (0, S.jsx)(Je.A, {
                            onIntersect: this.trackViewElement,
                            children: (0, S.jsx)(lt, {
                                repliedMessage: t.repliedMessage,
                                direction: n,
                                isContinuation: o,
                                messageSenderUserName: r,
                                message: (0, S.jsx)(mt.A, {
                                    direction: n,
                                    emoji: i,
                                    isContinuation: o,
                                    size: t.size,
                                    status: t.status,
                                    a11y: {
                                        label: Ge([r, this.props.emoji]),
                                        name: r
                                    }
                                })
                            })
                        })
                    }, t
                }(i.Component);
            yt.SUPPORTED_EMOJI = At;
            var bt, xt = yt,
                St = n(68438),
                Ct = function(e) {
                    var t, n = e.message,
                        i = e.extra,
                        o = e.direction,
                        r = e.isContinuation,
                        s = e.a11y,
                        a = ut({
                            message: n,
                            onShowOptions: e.onShowOptions,
                            onMessageLike: e.onMessageLike
                        }),
                        c = a.onTouchStart,
                        l = a.onTouchMove,
                        u = a.onTouchEnd,
                        d = a.onTouchCancel;
                    return (0, S.jsx)(lt, {
                        repliedMessage: n.repliedMessage,
                        direction: o,
                        isContinuation: r,
                        messageSenderUserName: s.name,
                        message: (0, S.jsx)(St.A, {
                            direction: o,
                            isContinuation: r,
                            message: n.message || "",
                            extra: i,
                            status: {
                                text: (null == (t = n.status) ? void 0 : t.text) || ""
                            },
                            onTouchStartContent: c,
                            onTouchMoveContent: l,
                            onTouchEndContent: u,
                            onTouchCancelContent: d,
                            a11y: s
                        })
                    })
                },
                _t = (n(42762), (bt = {})[1] = {
                    KEY: "3otOKQTJB2NH4V6iHK",
                    KEY_DEBUG: "dc6zaTOxFJmzC",
                    DEFAULT: function(e) {
                        return "https://api.giphy.com/v1/gifs/trending?api_key=" + e.key + "&limit=" + e.limit
                    },
                    SEARCH: function(e) {
                        var t = e.key,
                            n = e.limit;
                        return "https://api.giphy.com/v1/gifs/search?q=" + e.value + "&api_key=" + t + "&limit=" + n
                    },
                    SEARCH_BY_ID: function(e) {
                        return "https://api.giphy.com/v1/gifs?api_key=" + e.key + "&ids=" + e.value
                    }
                }, bt[2] = {
                    DEFAULT: function(e) {
                        return "https://g.tenor.com/v1/trending?key=" + e.key + "&media_filter=minimal&limit=" + e.limit
                    },
                    SEARCH: function(e) {
                        var t = e.key,
                            n = e.limit;
                        return "https://g.tenor.com/v1/search?q=" + e.value + "&key=" + t + "&media_filter=minimal&limit=" + n
                    },
                    SEARCH_BY_ID: function(e) {
                        var t = e.key;
                        return "https://g.tenor.com/v1/gifs?ids=" + e.value + "&key=" + t + "&media_filter=minimal"
                    }
                }, bt),
                kt = {
                    GIF_API_REQUEST_TYPE: {
                        DEFAULT: "DEFAULT",
                        SEARCH_BY_ID: "SEARCH_BY_ID",
                        SEARCH: "SEARCH"
                    },
                    getGifApiKeys: function(e, t, n, i) {
                        var o = _t[e],
                            r = {
                                key: o.KEY,
                                limit: i || 30,
                                value: n || ""
                            };
                        return 2 === e && (r.key = this.getTenorAppKey()), o[t](r)
                    },
                    getTenorAppKey: function() {
                        var e;
                        return ((null == (e = B.A.getSettings()) ? void 0 : e.sdk_integrations) || []).find((function(e) {
                            return 9 === e.type
                        })).app_key
                    }
                },
                jt = n(84230),
                Et = n(32308),
                Ot = n(7929),
                Tt = n(85208),
                Pt = n(97286),
                It = X.A.getLogger("GifCollection");

            function wt(e, t) {
                this.count = 0, this.page = null, this.provider = t, this.results = [], this.setup_(e)
            }
            wt.fromJSON = function(e) {
                var t = new wt;
                return (0, Tt.A)(t, (0, Pt.A)(e, Object.keys(t))), Array.isArray(e.results) && e.results.forEach((function(e, n) {
                    t.results[n] = Ot.A.fromJSON(e)
                })), t
            }, wt.prototype.setup_ = function(e) {
                var t = this;
                if (e)
                    if (1 === this.provider) {
                        if (!e.pagination) return void It.error("Incorrect response in GifCollection", {
                            response: e
                        });
                        this.count = e.pagination.count, this.page = e.pagination.offset, this.results = e.data.map((function(e) {
                            return new Ot.A(e, t.provider)
                        }))
                    } else 2 === this.provider && (this.results = e.results.map((function(e) {
                        return new Ot.A(e, t.provider)
                    })))
            };
            var Rt = wt,
                Mt = {},
                Nt = {},
                Ut = null,
                Dt = null,
                Bt = null,
                Lt = null;

            function Ft() {
                var e = "GifsModel";
                Ut = jt.A.getInstance(e), Bt = X.A.getLogger(e)
            }

            function Gt(e) {
                var t = Ht(e.providerType),
                    n = (e.id || e.ids || e.query || "").trim(),
                    i = null;
                return i = e.query && n ? kt.GIF_API_REQUEST_TYPE.SEARCH : (e.id || e.ids) && n ? kt.GIF_API_REQUEST_TYPE.SEARCH_BY_ID : kt.GIF_API_REQUEST_TYPE.DEFAULT, kt.getGifApiKeys(t, i, n)
            }

            function Vt(e) {
                return new Promise((function(t, n) {
                    M.A.ajax({
                        dataType: "json",
                        fail: n,
                        success: t,
                        url: e
                    })
                }))
            }

            function qt(e) {
                var t = Ut.get(e);
                return t ? t instanceof Ot.A || t instanceof Rt ? t : t.image ? Ot.A.fromJSON(t) : Rt.fromJSON(t) : null
            }

            function Ht(e) {
                return e = Number(e), (0, Et.Rg)(e) ? e : 1
            }

            function Qt(e) {
                for (var t in Nt) delete Nt[t];
                return Bt.error(e), Promise.reject(new Error(e))
            }

            function Yt(e, t) {
                return new Rt(e, Ht(t.providerType))
            }
            Ft.prototype = {
                cacheGif: function(e) {
                    return Ut.put(e.id, e, {
                        ttl: 1728e5,
                        noCommit: !1
                    }), e
                },
                cacheGifCollection_: function(e, t) {
                    return t.length < 3 || Ut.put(t, e, {
                        ttl: 6e5,
                        noCommit: !0
                    }), e
                },
                get: function(e) {
                    var t = (e = e || {}).query || "empty_request",
                        n = qt(t);
                    return n ? Promise.resolve(n) : (Nt[t] || (Nt[t] = Vt(Gt(e)).then((function(n) {
                        var i = Yt(n, e);
                        return function(e, t) {
                            if (t instanceof Ot.A) return Dt.cacheGif(t);
                            if (t instanceof Rt) Dt.cacheGifCollection_(t, e)
                        }(t, i), delete Nt[t], i
                    })).catch(Qt)), Nt[t])
                },
                getById: function(e) {
                    var t = qt((e = e || {}).id);
                    return t ? Promise.resolve(t) : function(e) {
                        Mt[e.providerType] || (Mt[e.providerType] = {});
                        if (!Mt[e.providerType][e.id]) {
                            var t = new Promise((function(t, n) {
                                Mt[e.providerType][e.id] = {
                                    resolve: t,
                                    reject: n
                                }
                            }));
                            Mt[e.providerType][e.id].promise = t
                        }
                        return clearTimeout(Lt), Lt = setTimeout((function() {
                            var e = function(e) {
                                (function(e) {
                                    return Vt(Gt({
                                        ids: e.ids.join(","),
                                        providerType: e.providerType
                                    })).then((function(t) {
                                        var n = Yt(t, e);
                                        return n.results.forEach((function(e) {
                                            return Dt.cacheGif(e)
                                        })), n
                                    })).catch(Qt)
                                })({
                                    ids: Object.keys(Mt[e]),
                                    providerType: Ht(e)
                                }).then((function(t) {
                                    t.results.forEach((function(t) {
                                        var n = Mt[e][t.id];
                                        n && (n.resolve(t), delete Mt[e][t.id])
                                    }))
                                })).catch((function(t) {
                                    for (var n in Mt[e]) Mt[e][n].promise.reject(t), delete Mt[e][n]
                                }))
                            };
                            for (var t in Mt) e(t)
                        }), 100), Mt[e.providerType][e.id].promise
                    }(e).catch(Qt)
                }
            };
            var Wt = function() {
                    return Dt || (Dt = new Ft), Dt
                },
                zt = n(9194);

            function Kt(e, t) {
                return Kt = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, Kt(e, t)
            }
            var Jt, Xt = function(e) {
                    function t(t) {
                        var n;
                        (n = e.call(this, t) || this).onSelect = function() {
                            n.props.onSelect && n.props.onSelect(n.props.message)
                        }, n.lastHeight = void 0;
                        var i = ut({
                                message: t.message,
                                onShowOptions: t.onShowOptions,
                                onMessageLike: t.onMessageLike
                            }),
                            o = i.onTouchStart,
                            r = i.onTouchMove,
                            s = i.onTouchEnd,
                            a = i.onTouchCancel;
                        return n.onTouchStart = o, n.onTouchMove = r, n.onTouchEnd = s, n.onTouchCancel = a, n
                    }
                    var n, i;
                    i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, Kt(n, i);
                    var o = t.prototype;
                    return o.onClick = function() {
                        var e = this.props.message;
                        e.isMasked ? this.props.onUnmask(e) : this.props.onReport(e)
                    }, o.getUpdatedMessage = function() {
                        var e = this.props.message;
                        return e.status && !e.isYours() && (e.status.onClick = this.onClick.bind(this)), e
                    }, t
                }(i.Component),
                Zt = n(95773);

            function $t(e, t) {
                return $t = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, $t(e, t)
            }
            var en = ((Jt = {})[1] = "giphy", Jt[2] = "tenor", Jt),
                tn = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).loadImage = function() {
                            var e = n.props.message,
                                t = e.gif.id,
                                i = e.gif.provider;
                            n.setState({
                                isLoading: !0
                            }), Wt().getById({
                                id: t,
                                providerType: i
                            }).then((function(t) {
                                (0, A.NN)(t.image.preview).then((function(o) {
                                    var r = o[0],
                                        s = o[1],
                                        a = o[2];
                                    e.gif = t, e.image = {
                                        height: a,
                                        ratio: Number(t.image.ratio),
                                        src: r,
                                        width: s,
                                        provider: en[i]
                                    }, n.setState({
                                        image: e.image
                                    })
                                })).catch((function(e) {
                                    return (0, Zt.gf)(e, "Chat message gif preload")
                                }))
                            }))
                        }, n.state = {
                            image: null,
                            isLoading: !1
                        }, n
                    }
                    var n, i;
                    i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, $t(n, i);
                    var o = t.prototype;
                    return o.viewPhoto = function() {
                        var e = this.props.message,
                            t = this.state.image,
                            n = !e.isYours() ? e.fromPersonId : e.toPersonId;
                        a.A.navigate(c.x.MULTIMEDIA, {
                            chatUserId: n,
                            id: e.id,
                            source: t.src,
                            viewType: H.D.VIEW,
                            multimediaVisibility: t.visibility,
                            chatUserName: this.props.messageSenderUserName
                        })
                    }, o.handleClick = function() {
                        this._delayedClick || (this._delayedClick = (0, De.A)(this.viewPhoto, 300)), this.clickedOnce ? (this._delayedClick.cancel(), this.clickedOnce = !1) : (this._delayedClick(), this.clickedOnce = !0)
                    }, o.render = function() {
                        var e = this.getUpdatedMessage(),
                            t = this.props,
                            n = t.direction,
                            i = t.isContinuation,
                            o = t.extra,
                            r = t.messageSenderUserName;
                        return (0, S.jsx)(Je.A, {
                            onIntersect: this.loadImage,
                            children: (0, S.jsx)(lt, {
                                repliedMessage: e.repliedMessage,
                                direction: n,
                                isContinuation: i,
                                messageSenderUserName: r,
                                message: (0, S.jsx)(zt.A, {
                                    direction: n,
                                    image: this.state.image,
                                    isContinuation: i,
                                    isLoading: this.state.isLoading,
                                    message: e.message,
                                    extra: o,
                                    status: e.status,
                                    isSelectable: e.isSelectable && !e.isYours(),
                                    isSelected: e.isSelected,
                                    onSelect: this.onSelect,
                                    onClickContent: this.handleClick.bind(this),
                                    onTouchStartContent: this.onTouchStart,
                                    onTouchMoveContent: this.onTouchMove,
                                    onTouchEndContent: this.onTouchEnd,
                                    onTouchCancelContent: this.onTouchCancel,
                                    a11y: {
                                        label: Ge([r, m.Ay.get(397)]),
                                        contentLabel: Ge([m.Ay.get(397), m.Ay.get(413)]),
                                        name: r
                                    }
                                })
                            })
                        })
                    }, t
                }(Xt),
                nn = n(75308),
                on = n(67533);

            function rn(e, t) {
                return rn = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, rn(e, t)
            }
            var sn = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).loadImage = function() {
                            var e = n.getSrc();
                            n.preloadImagePromise_ = (0, A.NN)(e), n.preloadImagePromise_.then((function(e) {
                                var t = e[0];
                                n.setState({
                                    src: t
                                })
                            })).catch((function(e) {
                                return (0, Zt.gf)(e, "Chat message gift image preload")
                            }))
                        }, n.state = {
                            isBoxed: t.message.gift.getIsBoxed(),
                            src: null
                        }, n
                    }
                    var n, i;
                    i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, rn(n, i);
                    var o = t.prototype;
                    return o.componentWillUnmount = function() {
                        this.preloadImagePromise_ && this.preloadImagePromise_.cancel()
                    }, o.getSrc = function() {
                        return this.state.isBoxed ? this.props.message.image.srcBox : this.props.message.image.src
                    }, o.openGift = function() {
                        var e = this.props.message,
                            t = e.gift.toJSON();
                        this.state.isBoxed && (e.gift.setIsBoxed(!1), this.setState({
                            isBoxed: !1,
                            src: e.image.src
                        })), a.A.navigate(c.x.GIFT, {
                            back: a.A.getUrl(),
                            fromChat: this.props.fromChat,
                            purchasedGift: t
                        })
                    }, o.handleClick = function() {
                        this._delayedClick || (this._delayedClick = (0, De.A)(this.openGift, 300)), this.clickedOnce ? (this._delayedClick.cancel(), this.clickedOnce = !1) : (this._delayedClick(), this.clickedOnce = !0)
                    }, o.render = function() {
                        var e = this.getUpdatedMessage(),
                            t = this.props,
                            n = t.direction,
                            i = t.isContinuation,
                            o = t.extra,
                            r = t.messageSenderUserName,
                            s = "out" === n,
                            a = this.handleClick.bind(this),
                            c = s || !this.state.isBoxed ? null : {
                                primary: m.Ay.get(593),
                                onClickPrimary: a
                            };
                        return (0, S.jsx)(Je.A, {
                            onIntersect: this.loadImage,
                            children: (0, S.jsx)(lt, {
                                repliedMessage: e.repliedMessage,
                                direction: n,
                                isContinuation: i,
                                messageSenderUserName: r,
                                message: (0, S.jsx)(nn.A, {
                                    actions: c,
                                    direction: n,
                                    image: {
                                        src: this.state.src
                                    },
                                    isContinuation: i,
                                    message: e.message,
                                    onClickContent: this.state.isBoxed ? null : a,
                                    extra: o,
                                    status: e.status,
                                    a11y: {
                                        label: Ge([r, m.Ay.get(398), this.state.src ? (0, on.b)(this.state.src) : void 0, e.message]),
                                        contentLabel: Ge([m.Ay.get(398), this.state.src ? (0, on.b)(this.state.src) : void 0, e.message, m.Ay.get(413)]),
                                        name: r
                                    },
                                    isSelectable: e.isSelectable && !e.isYours(),
                                    isSelected: e.isSelected,
                                    onSelect: this.onSelect,
                                    onTouchStartContent: this.onTouchStart,
                                    onTouchMoveContent: this.onTouchMove,
                                    onTouchEndContent: this.onTouchEnd,
                                    onTouchCancelContent: this.onTouchCancel
                                })
                            })
                        })
                    }, t
                }(Xt),
                an = n(5393),
                cn = n(8483),
                ln = n(33815),
                un = n(93827),
                dn = function(e) {
                    var t = e.children,
                        n = e.address,
                        i = e.caption,
                        o = e.isLoading,
                        r = e.isModal,
                        s = e.onClick,
                        a = Me()({
                            "location-wrapper": !0,
                            "is-loading": o,
                            "is-modal": r
                        });
                    return (0, S.jsxs)("div", {
                        className: a,
                        children: [(0, S.jsxs)("div", {
                            className: "location-wrapper__map",
                            children: [(0, S.jsx)("div", {
                                className: "location-wrapper__map-content",
                                children: t
                            }), o ? (0, S.jsx)("div", {
                                className: "location-wrapper-loader",
                                children: (0, S.jsx)("div", {
                                    className: "location-wrapper-loader__loader-wrapper",
                                    children: (0, S.jsx)(ln.A, {})
                                })
                            }) : null]
                        }), o && r ? (0, S.jsxs)("div", {
                            className: "location-wrapper__footer",
                            children: [(0, S.jsxs)("div", {
                                className: "location-wrapper__footer-content",
                                children: [(0, S.jsx)("div", {
                                    className: "location-wrapper__footer-address is-placeholder"
                                }), (0, S.jsx)("div", {
                                    className: "location-wrapper__footer-caption is-placeholder"
                                })]
                            }), (0, S.jsx)("div", {
                                className: "location-wrapper__footer-icon",
                                children: (0, S.jsx)("div", {
                                    className: "location-wrapper__footer-icon is-placeholder"
                                })
                            })]
                        }) : null, n && i ? (0, S.jsxs)("button", {
                            className: "location-wrapper__footer",
                            onClick: s,
                            children: [(0, S.jsxs)("span", {
                                className: "location-wrapper__footer-content",
                                children: [(0, S.jsx)("span", {
                                    className: "location-wrapper__footer-address",
                                    children: (0, S.jsx)(un.P2, {
                                        children: n
                                    })
                                }), (0, S.jsx)("span", {
                                    className: "location-wrapper__footer-caption",
                                    children: (0, S.jsx)(un.P3, {
                                        color: "gray-80",
                                        children: i
                                    })
                                })]
                            }), (0, S.jsx)("span", {
                                className: "location-wrapper__footer-icon",
                                children: (0, S.jsx)(cn.A, {
                                    name: "navigation-bar-location",
                                    size: "md"
                                })
                            })]
                        }) : null]
                    })
                },
                pn = n(65848),
                fn = n(40223),
                hn = n(45016);

            function gn() {
                var e = s.A.document.createElement("div");
                return e.innerHTML = pn.renderToStaticMarkup((0, S.jsx)(fn.Kq, {
                    value: hn.Ay.getValue(),
                    children: i.createElement.apply(void 0, arguments)
                })), e.firstChild
            }
            var mn, vn, An = function(e) {
                    var t = e.avatarSrc;
                    return (0, S.jsx)("div", {
                        className: "location-pin-user",
                        children: t ? (0, S.jsx)("div", {
                            className: "location-pin-user__avatar",
                            style: {
                                backgroundImage: "url(" + t + ")"
                            }
                        }) : null
                    })
                },
                yn = 32,
                bn = 32;
            ! function(e) {
                e.BADOO = "badoo", e.HOTORNOT = "hotornot"
            }(vn || (vn = {}));
            var xn = ((mn = {})[vn.BADOO] = "%23783bf9", mn[vn.HOTORNOT] = "%231f63dc", mn);

            function Sn(e) {
                var t, n = pt.A.get("partner_id");
                return e ? "data:image/svg+xml,%3Csvg viewBox='0 0 32 32' xmlns='http://www.w3.org/2000/svg'%3E%3Cg transform='translate(10 3)' fill='none' fill-rule='evenodd'%3E%3Cellipse fill='" + (t = xn[n]) + "' opacity='.3' cx='6' cy='26' rx='3' ry='1'/%3E%3Cpath d='M6 2a1 1 0 011 1v22a1 1 0 01-2 0V3a1 1 0 011-1z' fill='" + t + "'/%3E%3Ccircle fill='" + t + "' cx='6' cy='6' r='6'/%3E%3Ccircle fill='%23fff' cx='5' cy='5' r='2'/%3E%3C/g%3E%3C/svg%3E%0A" : function(e) {
                    switch (e) {
                        case vn.BADOO:
                            return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgBAMAAACBVGfHAAAAJ1BMVEUAAAB5PPp4O/p5Pfp5PPp4Pvd5PPh6Pf93Pfh4O/nw6f7///+ec/r+shfsAAAACXRSTlMAyL1l80ImGUu7+8bDAAAAYklEQVQoz2MgGzCLOBog89k1Z86cVIAkwDQTCBSQBCznrDo5czKSgOSs3StnTkQS8AQJTEEWAGpBEZAEmomixRIkMBnDWnwOY2CWnGiA6hnOCQzDVoAtcmoCqkBEK1SAMAAAaAkpgjauxZgAAAAASUVORK5CYII=";
                        case vn.HOTORNOT:
                            return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgBAMAAACBVGfHAAAAJ1BMVEUAAAAgY90fZN0hZd4fZNwfZNgiZd0pZuAfZtofY9zm7fv///9fj+YbX7FxAAAACXRSTlMAyL1l80ImGUu7+8bDAAAAYklEQVQoz2MgGzCLOBog89k1Z86cVIAkwDQTCBSQBCznrDo5czKSgOSs3StnTkQS8AQJTEEWAGpBEZAEmomixRIkMBnDWnwOY2CWnGiA6hnOCQzDVoAtcmoCqkBEK1SAMAAAaAkpgjauxZgAAAAASUVORK5CYII="
                    }
                }(n)
            }

            function Cn(e) {
                return gn(An, {
                    avatarSrc: e
                })
            }
            var _n = n(65736),
                kn = function() {
                    return (0, S.jsx)("div", {
                        className: "location-wrapper__center-map",
                        children: (0, S.jsx)(cn.A, {
                            name: "chat-control-action-location-current",
                            size: "xlg"
                        })
                    })
                };

            function jn() {
                return gn(kn)
            }

            function En(e) {
                return e ? qe.oh.INTERACTIVE_LIVE : qe.oh.INTERACTIVE
            }
            var On = function(e) {
                    var t = e.customDetails,
                        n = e.isLiveLocation,
                        o = e.markerOptions,
                        r = e.location,
                        a = e.userPhoto,
                        c = e.onClickOutside,
                        l = (0, i.useMemo)(jn, []),
                        u = (0, i.useMemo)((function() {
                            if (n && !o) return Cn(y.A.getImageUrlForSize(a, 64))
                        }), [n, o, a]);

                    function d() {
                        var e;
                        e = Q.A.ios ? "maps:?t=m&sll=" + r.latitude + "," + r.longitude : "https://www.google.com/maps/dir/?api=1&destination=" + r.latitude + "," + r.longitude, s.A.open(e, "__blank")
                    }
                    return (0, S.jsx)(_n.A, {
                        onDismiss: c,
                        children: (0, S.jsx)(qe.Yz, {
                            centerMapCta: l,
                            coordinates: r,
                            customMarker: u,
                            getAddressDetails: !n,
                            mapClassName: "location-wrapper-google-map",
                            markerOptions: o,
                            type: En(n),
                            children: function(e) {
                                var n = e.mapElement,
                                    i = e.isLoading,
                                    o = e.details;
                                return (0, S.jsx)(dn, {
                                    address: t ? t.title : null == o ? void 0 : o.title,
                                    caption: t ? t.note : null == o ? void 0 : o.note,
                                    isLoading: i,
                                    isModal: !0,
                                    onClick: d,
                                    children: n
                                })
                            }
                        })
                    })
                },
                Tn = n(20175);

            function Pn(e) {
                return e ? qe.oh.FIXED_LIVE : qe.oh.FIXED
            }

            function In(e) {
                return e.locationExpiresAt - Math.floor(Date.now() / 1e3)
            }
            var wn = function(e) {
                    var t = e.message,
                        n = e.direction,
                        o = e.isContinuation,
                        r = e.onShowOptions,
                        a = e.messageSenderUserName,
                        c = t.location,
                        l = void 0 === c ? {} : c,
                        u = t.repliedMessage,
                        d = (0, i.useRef)(0),
                        f = (0, i.useRef)(!1),
                        h = (0, i.useState)(l),
                        g = h[0],
                        v = h[1],
                        A = (0, i.useState)(!1),
                        b = A[0],
                        x = A[1],
                        C = (0, i.useState)(In(t)),
                        _ = C[0],
                        k = C[1];

                    function j() {
                        f.current = !0
                    }

                    function E() {
                        f.current = !1
                    }(0, i.useEffect)((function() {
                        return O.A.on(O.A.SHOW_MODAL, j), O.A.on(O.A.HIDE_MODAL, E),
                            function() {
                                O.A.off(O.A.SHOW_MODAL, j), O.A.off(O.A.HIDE_MODAL, E)
                            }
                    }), []);
                    var T = ut({
                            customLongTapDelay: 2e3,
                            message: t,
                            onShowOptions: function(e) {
                                f.current || b || r(e)
                            }
                        }),
                        P = T.onTouchStart,
                        I = T.onTouchMove,
                        w = T.onTouchEnd,
                        R = T.onTouchCancel,
                        M = (0, i.useMemo)((function() {
                            return Boolean(47 === t.messageType)
                        }), [t]),
                        N = M && _ > 0,
                        U = (0, i.useMemo)((function() {
                            return p.A.getCachedClientOpenChat(t.fromPersonId).largePhoto || ""
                        }), [t]);
                    (0, i.useEffect)((function() {
                        function e(e) {
                            e.id === t.id && (v(e.location), k(In(e)))
                        }
                        return M && p.A.on(p.A.EVENTS.MESSAGE_FROM_ME, e).on(p.A.EVENTS.MESSAGE_FROM_USER, e),
                            function() {
                                M && p.A.off(p.A.EVENTS.MESSAGE_FROM_ME, e).off(p.A.EVENTS.MESSAGE_FROM_USER, e)
                            }
                    }), [M, t]), (0, i.useEffect)((function() {
                        if (N) return d.current = s.A.setTimeout((function() {
                                k(_ - 1)
                            }), 1e3),
                            function() {
                                return s.A.clearTimeout(d.current)
                            }
                    }), [N, _]);
                    var D = (0, i.useMemo)((function() {
                            if (N) return {
                                title: m.Ay.get(34),
                                note: (0, Tn.At)(_)
                            }
                        }), [N, _]),
                        B = (0, i.useMemo)((function() {
                            if (!N) return {
                                url: Sn(),
                                size: {
                                    width: yn,
                                    height: bn
                                }
                            }
                        }), [N]),
                        L = (0, i.useMemo)((function() {
                            if (N) return Cn(y.A.getImageUrlForSize(U, 64))
                        }), [N, U]);

                    function F() {
                        f.current || (R(), x(!0))
                    }
                    return (0, S.jsxs)(i.Fragment, {
                        children: [(0, S.jsx)(qe.Yz, {
                            coordinates: g,
                            customMarker: L,
                            getAddressDetails: !M,
                            mapClassName: "location-wrapper-google-map",
                            markerOptions: B,
                            type: Pn(M),
                            onClickMarker: F,
                            children: function(e) {
                                var t = e.mapElement,
                                    i = e.isLoading,
                                    r = e.details;
                                return (0, S.jsx)(lt, {
                                    repliedMessage: u,
                                    direction: n,
                                    isContinuation: o,
                                    messageSenderUserName: a,
                                    message: (0, S.jsx)(an.A, {
                                        content: (0, S.jsx)(dn, {
                                            children: t
                                        }),
                                        isLoading: i,
                                        direction: n,
                                        isContinuation: o,
                                        extra: M ? D : r,
                                        onClickContent: F,
                                        onTouchStartContent: P,
                                        onTouchMoveContent: I,
                                        onTouchEndContent: w,
                                        onTouchCancelContent: R,
                                        a11y: {
                                            label: Ge([a, M ? m.Ay.get(410) : m.Ay.get(411)]),
                                            contentLabel: Ge([M ? m.Ay.get(410) : m.Ay.get(411), M ? null == D ? void 0 : D.title : null == r ? void 0 : r.title, M ? null == D ? void 0 : D.note : null == r ? void 0 : r.note, m.Ay.get(409)]),
                                            name: a
                                        }
                                    })
                                })
                            }
                        }), b ? (0, S.jsx)(On, {
                            location: g,
                            isLiveLocation: M,
                            userPhoto: U,
                            markerOptions: B,
                            customDetails: D,
                            onClickOutside: function() {
                                x(!1)
                            }
                        }) : null]
                    })
                },
                Rn = n(43968),
                Mn = n(36693),
                Nn = function() {
                    return (0, S.jsx)("div", {
                        className: "private-detector-badge-view",
                        style: {
                            position: "absolute",
                            top: 0,
                            right: 0
                        },
                        children: (0, S.jsx)(Mn.A, {
                            top: "md",
                            right: "md",
                            children: (0, S.jsx)(cn.A, {
                                name: "badge-alert",
                                size: "md"
                            })
                        })
                    })
                },
                Un = function(e) {
                    var t = e.text,
                        n = e.ctaText;
                    return (0, S.jsxs)("div", {
                        className: "private-detector-chat-message-view",
                        children: [(0, S.jsx)(cn.A, {
                            name: "generic-search-attention",
                            size: "lg",
                            color: "white"
                        }), (0, S.jsx)(Mn.A, {
                            top: "md",
                            bottom: "md",
                            children: (0, S.jsx)(un.P3, {
                                color: "white",
                                align: "center",
                                children: t
                            })
                        }), (0, S.jsx)(un.P3, {
                            color: "white",
                            align: "center",
                            children: n
                        })]
                    })
                };

            function Dn(e, t) {
                return Dn = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, Dn(e, t)
            }
            var Bn = function(e) {
                function t(t) {
                    var n;
                    (n = e.call(this, t) || this).preloadImage = function(e) {
                        n.setState({
                            isLoading: !0
                        }), n._preloadingSrc = e.image.src, (0, A.NN)(e.image.src).then((function(t) {
                            var i = t[0],
                                o = t[1],
                                r = t[2];
                            p.A.markMultimediaView(e), e.isMasked && (0, l.sx)(258, {
                                element: 522
                            }), n.setState({
                                image: {
                                    src: i,
                                    width: o,
                                    height: r,
                                    ratio: Ln(o, r)
                                }
                            })
                        })).catch((function(t) {
                            e.image.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAUEBAAAACwAAAAAAQABAAACAkQBADs=", n.setState({
                                image: e.image
                            }), (0, Zt.gf)(t, "Chat message media preload")
                        }))
                    }, n.loadImage = function() {
                        var e = n.props.message;
                        n.preloadImage(e)
                    }, n.viewPhoto = function() {
                        var e = n.props.message,
                            t = e.image,
                            i = !e.isYours() ? e.fromPersonId : e.toPersonId;
                        e.isMasked ? n.props.onUnmask(n.props.message) : e.isInappropriate ? n.props.onWarnInappropriate(n.props.message) : ((0, l.sx)(76, {
                            encryptedUser_id: e.fromPersonId,
                            photo_id: e.id,
                            time_limit: 4
                        }), a.A.navigate(c.x.MULTIMEDIA, {
                            chatUserId: i,
                            id: e.id,
                            source: t.src,
                            viewType: H.D.VIEW,
                            multimediaVisibility: t.visibility,
                            chatUserName: n.props.messageSenderUserName
                        }))
                    }, n.handleClick = function() {
                        n._delayedClick || (n._delayedClick = (0, De.A)(n.viewPhoto, 300)), n.clickedOnce ? (n._delayedClick.cancel(), n.clickedOnce = !1) : (n._delayedClick(), n.clickedOnce = !0)
                    };
                    var i = t.message.image || {};
                    return n.state = {
                        image: {
                            height: i.height,
                            ratio: i.ratio,
                            width: i.width
                        },
                        isLoading: !1
                    }, n._preloadingSrc = null, n
                }
                var n, i;
                i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, Dn(n, i);
                var o = t.prototype;
                return o.componentWillReceiveProps = function(e) {
                    e.message.image && this.state.image.src && this.state.image.src !== e.message.image.src && this._preloadingSrc !== e.message.image.src && this.preloadImage(e.message)
                }, o.render = function() {
                    var e, t, n = this.props.message,
                        i = null;
                    n.isMasked && n.hasLewdPhoto ? (i = {
                        children: (0, S.jsx)(Un, {
                            text: m.Ay.get(13),
                            ctaText: m.Ay.get(14)
                        }),
                        background: "dark"
                    }, t = m.Ay.get(13), e = [m.Ay.get(13), m.Ay.get(14)].join(",")) : n.isInappropriate && (i = {
                        children: (0, S.jsx)(Nn, {}),
                        background: "dark"
                    });
                    var o = this.props,
                        r = o.direction,
                        s = o.isContinuation,
                        a = o.extra,
                        c = o.messageSenderUserName;
                    return (0, S.jsx)(Je.A, {
                        onIntersect: this.loadImage,
                        children: (0, S.jsx)(lt, {
                            repliedMessage: n.repliedMessage,
                            direction: r,
                            isContinuation: s,
                            messageSenderUserName: c,
                            message: (0, S.jsx)(Rn.A, {
                                direction: r,
                                image: this.state.image,
                                isContinuation: s,
                                isLoading: this.state.isLoading,
                                message: n.message,
                                extra: a,
                                status: n.status,
                                overlay: i,
                                a11y: {
                                    label: Ge([c, n.message || m.Ay.get(642, {
                                        name: c
                                    }), t]),
                                    contentLabel: Ge([n.message || m.Ay.get(642, {
                                        name: c
                                    }), e || m.Ay.get(413)]),
                                    name: c
                                },
                                isSelectable: n.isSelectable && !n.isYours(),
                                isSelected: n.isSelected,
                                onSelect: this.onSelect,
                                onClickContent: this.handleClick,
                                onTouchStartContent: this.onTouchStart,
                                onTouchMoveContent: this.onTouchMove,
                                onTouchEndContent: this.onTouchEnd,
                                onTouchCancelContent: this.onTouchCancel
                            })
                        })
                    })
                }, t
            }(Xt);

            function Ln(e, t) {
                return Math.max(e, t) / Math.min(e, t)
            }
            var Fn = n(33736);

            function Gn(e) {
                return e.isYours() ? 1151 : 1152
            }
            var Vn = function(e) {
                    var t = e.message,
                        n = e.isReplyFeatureAllowed,
                        o = e.onClickUnlike,
                        r = e.onClickReply,
                        s = e.onClickCopy,
                        a = e.onClose;
                    (0, i.useEffect)((function() {
                        (0, l.sx)(258, {
                            element: Gn(t)
                        })
                    }), [t]);
                    var c = (0, i.useCallback)((function() {
                            (0, l.sx)(332, {
                                element: 1582,
                                parent_element: Gn(t)
                            }), o(t)
                        }), [t, o]),
                        u = (0, i.useCallback)((function() {
                            (0, l.sx)(332, {
                                element: 289,
                                parent_element: Gn(t)
                            }), r(t)
                        }), [t, r]),
                        d = (0, i.useCallback)((function() {
                            (0, l.sx)(332, {
                                element: 695,
                                parent_element: Gn(t)
                            }), s(t)
                        }), [t, s]),
                        p = (0, i.useMemo)((function() {
                            var e = [];
                            return t.allowLike && t.isLiked && !t.isYours() && e.push((0, S.jsx)(Fn.A, {
                                dataQA: {
                                    "data-qa": "unlike-message"
                                },
                                text: m.Ay.get(30),
                                onClick: c
                            }, "unlike-message")), n && t.allowReply && !t.isTemporary() && e.push((0, S.jsx)(Fn.A, {
                                dataQA: {
                                    "data-qa": "reply-message"
                                },
                                text: m.Ay.get(29),
                                onClick: u
                            }, "reply-message")), 1 === t.messageType && e.push((0, S.jsx)(Fn.A, {
                                dataQA: {
                                    "data-qa": "copy-message"
                                },
                                text: m.Ay.get(28),
                                onClick: d
                            }, "copy-message")), e
                        }), [t, n, c, u, d]);
                    return 0 === p.length ? null : (0, S.jsx)(_n.A, {
                        onAnimationOutComplete: a,
                        wrapperType: _n.T.ACTION_SHEET,
                        children: p
                    })
                },
                qn = n(38635),
                Hn = n(26914),
                Qn = n(99845),
                Yn = n(84362),
                Wn = function(e) {
                    var t, n, o = e.direction,
                        r = e.status,
                        s = e.userAvatar,
                        a = void 0 === s ? {} : s,
                        c = e.chatUserAvatar,
                        l = void 0 === c ? {} : c,
                        u = e.chatUserGender,
                        d = e.header,
                        p = e.question,
                        f = e.ownAnswer,
                        h = e.ownUserName,
                        g = e.otherAnswer,
                        v = e.otherUserName,
                        A = e.footer,
                        y = e.onClickAskQuestion,
                        b = e.onClickAddAnswer,
                        x = g && f,
                        C = x ? "Button" : "div",
                        _ = g && !f,
                        k = g || m.Ay.get(118, {
                            other_user: u
                        });
                    return (0, S.jsx)(qn.A, {
                        width: "full",
                        direction: o,
                        status: r,
                        a11y: {
                            name: f ? h : v,
                            label: Ge([f ? h : v, m.Ay.get(428), p])
                        },
                        children: (0, S.jsxs)("section", {
                            className: "questions-game-card-container",
                            children: [(0, S.jsx)("div", {
                                className: "questions-game-card-container__body",
                                children: (0, S.jsxs)("div", {
                                    className: "questions-game-card",
                                    children: [(0, S.jsx)("div", {
                                        className: "questions-game-card__header",
                                        children: (0, S.jsx)(un.P2, {
                                            align: "center",
                                            color: "black",
                                            children: d
                                        })
                                    }), (0, S.jsx)("div", {
                                        className: "questions-game-card__question",
                                        children: (0, S.jsx)(un.Zb, {
                                            align: "center",
                                            color: "black",
                                            dangerous: !0,
                                            children: p
                                        })
                                    }), (0, S.jsx)("div", {
                                        className: "questions-game-card__content",
                                        children: (0, S.jsxs)("div", {
                                            className: "questions-game-messages",
                                            children: [(0, S.jsxs)("div", {
                                                className: "questions-game-message-item questions-game-message-item--in",
                                                children: [(0, S.jsx)(Yn.A, {
                                                    children: Ge([v, "" + (_ ? m.Ay.get(396, {
                                                        other_user: Ie.ko.for("other_user", u)
                                                    }) : k)])
                                                }), (0, S.jsx)("div", {
                                                    className: "questions-game-message-item__avatar",
                                                    children: (0, S.jsx)(Hn.A, {
                                                        user: l
                                                    })
                                                }), (0, S.jsx)("div", {
                                                    className: "questions-game-message-item__content",
                                                    "aria-hidden": "true",
                                                    children: (t = k, n = null, _ && (t = (0, S.jsx)("span", {
                                                        style: {
                                                            textShadow: "0 0 6px #000000",
                                                            color: "transparent"
                                                        },
                                                        "aria-hidden": "true",
                                                        children: t
                                                    })), f || (n = (0, S.jsx)("div", {
                                                        className: "questions-game-badge",
                                                        children: (0, S.jsx)(cn.A, {
                                                            name: "generic-lock-circle"
                                                        })
                                                    })), (0, S.jsxs)(i.Fragment, {
                                                        children: [(0, S.jsx)(Qn.A, {
                                                            direction: "in",
                                                            color: g ? "question" : "white",
                                                            children: (0, S.jsx)(un.P1, {
                                                                color: "black",
                                                                children: t
                                                            })
                                                        }), n]
                                                    }))
                                                })]
                                            }), (0, S.jsxs)("div", {
                                                className: "questions-game-message-item questions-game-message-item--out",
                                                children: [(0, S.jsx)("div", {
                                                    className: "questions-game-message-item__avatar",
                                                    children: (0, S.jsx)(Hn.A, {
                                                        user: a
                                                    })
                                                }), (0, S.jsx)("div", {
                                                    className: "questions-game-message-item__content",
                                                    "aria-hidden": "true",
                                                    children: f ? (0, S.jsx)(Qn.A, {
                                                        direction: "out",
                                                        color: "question",
                                                        children: (0, S.jsx)(un.P1, {
                                                            color: "black",
                                                            children: f
                                                        })
                                                    }) : (0, S.jsx)(Qn.A, {
                                                        direction: "out",
                                                        color: "white",
                                                        onClick: b,
                                                        children: (0, S.jsxs)("span", {
                                                            className: "questions-game-card-button",
                                                            children: [(0, S.jsx)("span", {
                                                                className: "questions-game-card-button__icon",
                                                                children: (0, S.jsx)(cn.A, {
                                                                    name: "badge-plus-hollow",
                                                                    size: "md"
                                                                })
                                                            }), (0, S.jsxs)("span", {
                                                                className: "questions-game-card-button__text",
                                                                children: [(0, S.jsx)(un.P1, {
                                                                    color: "black",
                                                                    children: m.Ay.get(140)
                                                                }), (0, S.jsx)(Yn.A, {
                                                                    children: p
                                                                })]
                                                            })]
                                                        })
                                                    })
                                                })]
                                            })]
                                        })
                                    })]
                                })
                            }), (0, S.jsx)("div", {
                                className: "questions-game-card-container__footer",
                                children: (0, S.jsxs)(C, {
                                    className: "questions-game-card-tip",
                                    onClick: x ? y : void 0,
                                    children: [x ? (0, S.jsx)("span", {
                                        className: "questions-game-card-tip__icon",
                                        children: (0, S.jsx)(cn.A, {
                                            name: "generic-questions-game",
                                            size: "sm",
                                            color: "gray-80"
                                        })
                                    }) : null, (0, S.jsx)("span", {
                                        className: "questions-game-card-tip__text",
                                        children: (0, S.jsx)(un.P3, {
                                            align: "center",
                                            color: "gray-80",
                                            children: A
                                        })
                                    })]
                                })
                            })]
                        })
                    })
                };

            function zn(e, t) {
                return zn = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, zn(e, t)
            }
            var Kn = function(e) {
                function t() {
                    for (var t, n = arguments.length, i = new Array(n), o = 0; o < n; o++) i[o] = arguments[o];
                    return (t = e.call.apply(e, [this].concat(i)) || this).handleAskQuestion = function() {
                        t.props.onQuestionsGameStart()
                    }, t.handleAddAnswer = function(e) {
                        t.props.onQuestionsGameAnswer(e), (0, l.sx)(332, {
                            element: 1289,
                            parent_element: 1359
                        })
                    }, t
                }
                var n, i;
                return i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, zn(n, i), t.prototype.render = function() {
                    var e, t, n = this,
                        i = this.getUpdatedMessage(),
                        o = this.props,
                        r = o.direction,
                        s = o.user,
                        a = o.chatUser,
                        c = a.getName(),
                        l = s.name,
                        u = (0, m.Bt)(s.gender),
                        d = (0, m.Bt)(a.getGender()),
                        p = i.fromPersonId === s.user_id,
                        f = p ? m.Ay.get(142) : m.Ay.get(113, {
                            name: Ie.ko.for(c, d)
                        }),
                        h = i.question;
                    h && (e = p ? h.other_answer : h.own_answer, t = p ? h.own_answer : h.other_answer);
                    var g, v = (null == h ? void 0 : h.text) || " \n ";
                    return g = e && t ? m.Ay.get(141) : e && !t ? m.Ay.get(116, {
                        name: Ie.ko.for(c, d)
                    }) : m.Ay.get(117, {
                        me: Ie.ko.for("me", u),
                        other_user: Ie.ko.for("other_user", d)
                    }), (0, S.jsx)(Je.A, {
                        onIntersect: Xn,
                        children: (0, S.jsx)(Wn, {
                            direction: r,
                            status: i.status,
                            userAvatar: Jn(s),
                            chatUserAvatar: Jn(a),
                            chatUserGender: d,
                            header: f,
                            question: v,
                            otherAnswer: e,
                            otherUserName: c,
                            ownAnswer: t,
                            ownUserName: l,
                            footer: g,
                            onClickAskQuestion: this.handleAskQuestion,
                            onClickAddAnswer: function() {
                                return n.handleAddAnswer(i)
                            }
                        })
                    })
                }, t
            }(Xt);

            function Jn(e) {
                var t = e.profile_photo;
                return {
                    gender: (0, A.v4)(e.gender),
                    photo: t ? {
                        src: y.A.getImageUrlForSize(t.large_url, 40)
                    } : void 0
                }
            }

            function Xn() {
                (0, l.sx)(258, {
                    element: 1359
                })
            }
            var Zn = Kn,
                $n = n(31751),
                ei = n(32509),
                ti = function(e) {
                    var t, n = e.emoji,
                        i = e.userPhotoSrc,
                        o = e.messageText,
                        r = e.direction,
                        s = void 0 === r ? "in" : r,
                        a = Me()(((t = {
                            "chat-message-reaction": !0
                        })["chat-message-reaction--" + s] = s, t));
                    return (0, S.jsxs)("div", {
                        className: a,
                        children: [(0, S.jsx)("div", {
                            className: "chat-message-reaction__user-photo",
                            children: (0, S.jsx)(Hn.A, {
                                size: "stretch",
                                image: {
                                    src: i
                                }
                            })
                        }), (0, S.jsx)("div", {
                            className: "chat-message-reaction__message-text",
                            "aria-hidden": !0,
                            children: (0, S.jsx)(ei.A, {
                                content: (0, S.jsx)(un.P1, {
                                    breakWords: !0,
                                    children: o
                                }),
                                direction: s
                            })
                        }), (0, S.jsx)("div", {
                            className: "chat-message-reaction__reaction-emoji",
                            "aria-hidden": !0,
                            children: (0, S.jsx)($n.A, {
                                size: "38px",
                                text: n
                            })
                        }), (0, S.jsxs)(Yn.A, {
                            children: [o, " ", n]
                        })]
                    })
                };

            function ni(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function ii(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? ni(Object(n), !0).forEach((function(t) {
                        oi(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : ni(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function oi(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var ri = function(e) {
                    return (0, i.useEffect)((function() {
                        (0, l.sx)(258, {
                            element: 1129
                        })
                    }), []), (0, S.jsx)(qn.A, {
                        direction: e.direction,
                        a11y: e.a11y,
                        children: (0, S.jsx)(ti, ii({}, e))
                    })
                },
                si = function(e) {
                    var t = e.message,
                        n = e.direction,
                        i = e.isContinuation,
                        o = e.messageSenderUserName;
                    return 30 === t.messageType ? (0, S.jsx)(Bn, {
                        message: t,
                        direction: n,
                        isContinuation: i,
                        messageSenderUserName: o
                    }) : (0, S.jsx)(We.A, {
                        direction: n,
                        isContinuation: i,
                        message: t.message,
                        status: t.status,
                        a11y: {
                            label: t.message
                        }
                    })
                },
                ai = n(59305);

            function ci(e, t) {
                return ci = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, ci(e, t)
            }
            var li = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).loadImage = function() {
                            var e = n.props.message;
                            n.setState({
                                isLoading: !0
                            }), (0, A.NN)(e.image.src).then((function(e) {
                                var t = e[0],
                                    i = e[1],
                                    o = e[2];
                                n.setState({
                                    image: {
                                        src: t,
                                        width: i,
                                        height: o
                                    },
                                    isLoading: !1
                                })
                            })).catch((function(e) {
                                return (0, Zt.gf)(e, "Chat message sticker preload")
                            }))
                        }, n.state = {
                            isLoading: !1
                        }, n
                    }
                    var n, i;
                    return i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, ci(n, i), t.prototype.render = function() {
                        var e = this.getUpdatedMessage(),
                            t = this.props,
                            n = t.direction,
                            i = t.isContinuation,
                            o = t.extra,
                            r = t.messageSenderUserName,
                            s = m.Ay.get(60);
                        return (0, S.jsx)(Je.A, {
                            onIntersect: this.loadImage,
                            children: (0, S.jsx)(lt, {
                                repliedMessage: e.repliedMessage,
                                direction: n,
                                isContinuation: i,
                                messageSenderUserName: r,
                                message: (0, S.jsx)(ai.A, {
                                    direction: n,
                                    isContinuation: i,
                                    isLoading: this.state.isLoading,
                                    message: s,
                                    extra: o,
                                    status: e.status,
                                    isSelectable: e.isSelectable && !e.isYours(),
                                    isSelected: e.isSelected,
                                    onSelect: this.onSelect,
                                    onTouchStartContent: this.onTouchStart,
                                    onTouchMoveContent: this.onTouchMove,
                                    onTouchEndContent: this.onTouchEnd,
                                    onTouchCancelContent: this.onTouchCancel,
                                    a11y: {
                                        label: Ge([r, s]),
                                        name: r
                                    }
                                })
                            })
                        })
                    }, t
                }(Xt),
                ui = (n(79978), n(23792), n(47764), n(5746), n(62953), n(27208), n(48408), ["badoo.com", "badoo.eu", "badoo.us", "badoo.shot", "s.badoo.com", "m.badoo.com", "mqa.badoo.com", "mlink.badoo.com", "mqalink.badoo.com", "hotornot.com", "s.hotornot.com", "m.hotornot.com", "mqa.hotornot.com", "mlink.hotornot.com", "mqalink.hotornot.com", "chatdate.app", "s.chatdate.app", "m.chatdate.app", "mqa.chatdate.app", "mlink.chatdate.app"]);
            var di = n(62498);

            function pi(e, t) {
                return pi = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, pi(e, t)
            }
            var fi = Boolean(s.A.URL),
                hi = />/g,
                gi = /</g,
                mi = /\n{3,}/g,
                vi = /\n/g;

            function Ai(e, t) {
                var n = e.message;
                return e.isTemporary() && n ? yi(n.replace(hi, "&gt;").replace(gi, "&lt;")) : n ? (t && (n = n.replaceAll(/<a href="([^"]+)">((?:.(?!\<\/a\>))*.)<\/a>/g, (function(e, t, n) {
                    var i = function(e) {
                        var t = new URL(e),
                            n = t.hostname;
                        return ui.find((function(e) {
                            return -1 !== n.indexOf(e) && 0 === t.pathname.indexOf("/aa/")
                        })) ? "" + t.pathname + t.search : null
                    }(t);
                    return i ? '<a class="js-highlighted-link js-deep-link" href="' + i + '" data-blacklisted="' + (0, Xe.Wg)(t) + '">' + n + "</a>" : '<a class="js-highlighted-link" target="_blank" rel="noreferrer noopener" href="' + t + '" data-blacklisted="' + (0, Xe.Wg)(t) + '">' + (0, ht.P)(n) + "</a>"
                }))), yi(function(e) {
                    if (!fi) return e;
                    return e.split(/(\s)/).map((function(e) {
                        var t = (0, Xe.Cq)(e);
                        return "string" != typeof t || function(e) {
                            if (!e) return !1;
                            var t = new s.A.URL(e),
                                n = e.indexOf(t.hostname);
                            return -1 !== e.substring(0, n).indexOf("@")
                        }(t) ? e : '<a class="js-highlighted-link" target="_blank" rel="noreferrer noopener" href="' + t + '" data-blacklisted="' + (0, Xe.Wg)(e) + '">' + (0, ht.P)(e) + "</a>"
                    })).join("")
                }(n))) : ""
            }

            function yi(e) {
                return e && e.replace(mi, "\n\n").replace(vi, "<br>")
            }
            var bi = function(e) {
                function t(t) {
                    var n;
                    return (n = e.call(this, t) || this).handleInnerRef = function(e) {
                        if (e && (n.el = e, n.bindClickEventLinks(e), !(0, A.Qt)())) {
                            var t = e.clientHeight,
                                i = n.lastHeight;
                            n.lastHeight = t;
                            var o = s.A.document.scrollingElement;
                            if (void 0 !== i && o) {
                                var r = t - i,
                                    a = o.scrollTop - e.offsetHeight,
                                    c = o.scrollTop + s.A.innerHeight,
                                    l = e.offsetTop;
                                (l > a && l < c || !pe.A.supportsChangePositionDuringScroll) && n.props.scrollPosition.scrollBy(r)
                            }
                        }
                    }, n.handleClickUrlMessage = function(e) {
                        !n.isMessageFromCurrentUser() && n.props.onClickUrlMessage && n.props.onClickUrlMessage(e)
                    }, n.handleClickUrlPreviewImage = function() {
                        !n.isMessageFromCurrentUser() && n.props.onClickUrlPreviewImage && n.props.onClickUrlPreviewImage()
                    }, n.handleClickUrlPreviewText = function() {
                        !n.isMessageFromCurrentUser() && n.props.onClickUrlPreviewText && n.props.onClickUrlPreviewText()
                    }, n.lastHeight = void 0, n
                }
                var n, i;
                i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, pi(n, i);
                var o = t.prototype;
                return o.componentDidUpdate = function() {
                    this.props.isAllowUrlParsing && this.bindClickEventLinks(this.el)
                }, o.getPreview = function() {
                    var e = this.props.chatComponentMessage;
                    return null == e ? void 0 : e.urlInfo
                }, o.render = function() {
                    var e, t = this.getUpdatedMessage(),
                        n = this.getPreview(),
                        i = this.props,
                        o = i.direction,
                        r = i.isContinuation,
                        s = i.isAllowUrlParsing,
                        a = i.extra,
                        c = i.onClick,
                        l = i.messageSenderUserName;
                    if (n) {
                        var u = Ai(t);
                        e = (0, S.jsx)(di.A, {
                            innerRef: this.handleInnerRef,
                            direction: o,
                            isContinuation: r,
                            isSelectable: t.isSelectable && !t.isYours(),
                            isSelected: t.isSelected,
                            message: Ai(t),
                            extra: a,
                            status: t.isSelectable ? null : t.status,
                            preview: n,
                            onClickPreviewImage: this.handleClickUrlPreviewImage,
                            onClickPreviewText: this.handleClickUrlPreviewText,
                            onSelect: this.onSelect,
                            onTouchStartContent: this.onTouchStart,
                            onTouchMoveContent: this.onTouchMove,
                            onTouchEndContent: this.onTouchEnd,
                            onTouchCancelContent: this.onTouchCancel,
                            a11y: {
                                label: Ge([l, u]),
                                name: l
                            }
                        })
                    } else {
                        var d = Ai(t, s);
                        e = (0, S.jsx)(ai.A, {
                            innerRef: this.handleInnerRef,
                            direction: t.direction,
                            isContinuation: r,
                            isSelectable: t.isSelectable && !t.isYours(),
                            isSelected: t.isSelected,
                            message: d,
                            extra: a,
                            status: t.isSelectable ? null : t.status,
                            onSelect: this.onSelect,
                            onClickContent: c,
                            onTouchStartContent: this.onTouchStart,
                            onTouchMoveContent: this.onTouchMove,
                            onTouchEndContent: this.onTouchEnd,
                            onTouchCancelContent: this.onTouchCancel,
                            a11y: {
                                label: Ge([l, d]),
                                name: l
                            }
                        })
                    }
                    return (0, S.jsx)(lt, {
                        repliedMessage: t.repliedMessage,
                        direction: o,
                        isContinuation: r,
                        message: e,
                        extra: a,
                        messageSenderUserName: l
                    })
                }, o.isMessageFromCurrentUser = function() {
                    var e = this.props.chatComponentMessage;
                    return null == e ? void 0 : e.isMessageFromCurrentUser
                }, o.bindClickEventLinks = function(e) {
                    for (var t = e.querySelectorAll(".js-highlighted-link"), n = 0; n < t.length; n++) {
                        var i = t[n];
                        i.removeEventListener("click", this.handleClickUrlMessage, this), i.addEventListener("click", this.handleClickUrlMessage, !0)
                    }
                }, t
            }(Xt);

            function xi(e, t) {
                return xi = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, xi(e, t)
            }
            var Si = function(e) {
                function t(t) {
                    var n, i;
                    return (i = e.call(this, t) || this).state = {
                        showActions: null == (n = t.message.request) ? void 0 : n.canAnswer
                    }, i
                }
                var n, i;
                i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, xi(n, i);
                var o = t.prototype;
                return o.onClickPrimary = function() {
                    this.setState({
                        showActions: !1
                    }), _i(this.props.message, !0, 1), Ci(this.props.message, !0).catch(this.onAccessResponseError.bind(this))
                }, o.onClickSecondary = function() {
                    this.setState({
                        showActions: !1
                    }), _i(this.props.message, !1, 1), Ci(this.props.message, !1).catch(this.onAccessResponseError.bind(this))
                }, o.onAccessResponseError = function(e) {
                    U.A.showNotification({
                        text: null == e || null == e.getErrorMessage ? void 0 : e.getErrorMessage(),
                        type: U.A.TYPES.ERROR
                    }), this.setState({
                        showActions: !0
                    })
                }, o.render = function() {
                    var e = this.props,
                        t = e.messageSenderUserName,
                        n = e.message;
                    return (0, S.jsx)(We.A, {
                        actions: this.state.showActions ? {
                            onClickPrimary: this.onClickPrimary.bind(this),
                            onClickSecondary: this.onClickSecondary.bind(this),
                            primary: m.Ay.get(392),
                            secondary: m.Ay.get(393)
                        } : null,
                        direction: this.props.direction,
                        isContinuation: this.props.isContinuation,
                        message: n.message,
                        status: n.status,
                        a11y: {
                            name: t,
                            label: Ge([t, n.message])
                        }
                    })
                }, t
            }(i.Component);

            function Ci(e, t) {
                var n = (new ge.ve9).setType(e.request.type);
                return e.request.providerType && n.setProviderType(e.request.providerType), _i(e, t, 1), p.A.accessResponse({
                    userId: e.fromPersonId,
                    accessObject: 1,
                    grant: t,
                    uid: e.id,
                    verificationAccessObject: n
                })
            }

            function _i(e, t, n) {
                (0, l.sx)(427, {
                    access_type: n,
                    action_type: t ? 2 : 5,
                    encrypted_user_id: e.fromPersonId
                })
            }
            var ki = n(63903),
                ji = n(36528),
                Ei = function(e) {
                    return (0, S.jsx)("span", {
                        className: "multimedia-video",
                        children: (0, S.jsx)("span", {
                            className: "multimedia-video__custom-video",
                            children: e.children
                        })
                    })
                },
                Oi = function(e) {
                    var t = e.videoElement,
                        n = e.isMuted,
                        i = void 0 !== n && n,
                        o = e.percentage,
                        r = e.direction,
                        s = e.isContinuation,
                        a = e.onClickContent,
                        c = e.onClickVolume,
                        l = e.onTouchStart,
                        u = e.onTouchMove,
                        d = e.onTouchEnd,
                        p = e.onTouchCancel,
                        f = e.a11y;
                    return (0, S.jsx)(ki.A, {
                        content: (0, S.jsx)(ji.Ay, {
                            children: (0, S.jsx)(Ei, {
                                children: t
                            })
                        }),
                        isMuted: i,
                        percentage: o,
                        direction: r,
                        isContinuation: s,
                        onClickContent: a,
                        onClickVolume: c,
                        onTouchStartContent: l,
                        onTouchMoveContent: u,
                        onTouchEndContent: d,
                        onTouchCancelContent: p,
                        a11y: f
                    })
                };

            function Ti(e) {
                return "in" === e ? 1225 : 1224
            }
            var Pi, Ii = function(e) {
                var t = e.message,
                    n = e.direction,
                    o = e.isContinuation,
                    r = e.messageVisibilityEvent,
                    s = e.messageSenderUserName,
                    a = t.video,
                    c = void 0 === a ? {} : a,
                    u = t.id,
                    d = t.isRead,
                    p = t.repliedMessage,
                    f = c.id,
                    h = c.src,
                    g = c.previewUrl,
                    v = (0, i.useRef)(null),
                    A = (0, i.useRef)(!1),
                    y = ut({
                        message: t,
                        onShowOptions: e.onShowOptions
                    }),
                    b = y.onTouchStart,
                    x = y.onTouchMove,
                    C = y.onTouchEnd,
                    _ = y.onTouchCancel;

                function k() {
                    var e = v.current;
                    return !e || e.paused
                }

                function j() {
                    var e = v.current;
                    return !e || e.muted
                }
                return (0, i.useEffect)((function() {
                    if (r && !A.current) return r.subscribe(e, null),
                        function() {
                            return r.unsubscribe(e, null)
                        };

                    function e(i) {
                        u === i && (A.current = !0, r.unsubscribe(e, null), (0, l.sx)(258, {
                            element: Ti(n)
                        }), t.isLiked && t.isYours() && (0, l.sx)(258, {
                            element: 1581
                        }))
                    }
                }), [t, n, r, A, u]), (0, S.jsx)(qe.en, {
                    onVideoRef: function(e) {
                        v.current = e,
                            function() {
                                var e = v.current;
                                e && e.setAttribute("aria-label", m.Ay.get(439))
                            }()
                    },
                    id: f,
                    src: h,
                    poster: g,
                    shouldPreload: !d,
                    onClickContent: function() {
                        var e, t = v.current;
                        t && k() ? (t.currentTime > 0 && (e = 742), e = 1134) : e = 741, (0, l.sx)(332, {
                            element: e,
                            parent_element: Ti(n)
                        })
                    },
                    onClickVolume: function() {
                        (0, l.sx)(332, {
                            element: j() ? 1222 : 1226,
                            parent_element: Ti(n)
                        })
                    },
                    onPlayError: function() {
                        U.A.showNotification({
                            type: U.A.TYPES.ERROR
                        })
                    },
                    children: function(e) {
                        var t = e.videoElement,
                            i = e.mute,
                            r = e.percentage,
                            a = e.onClickContent,
                            c = e.onClickVolume;
                        return (0, S.jsx)(lt, {
                            repliedMessage: p,
                            direction: n,
                            isContinuation: o,
                            messageSenderUserName: s,
                            message: (0, S.jsx)(Oi, {
                                videoElement: t,
                                isMuted: i,
                                percentage: r,
                                direction: n,
                                isContinuation: o,
                                onClickContent: a,
                                onClickVolume: c,
                                onTouchStart: b,
                                onTouchMove: x,
                                onTouchEnd: C,
                                onTouchCancel: _,
                                a11y: {
                                    label: Ge([s, m.Ay.get(439)]),
                                    playLabel: k() ? m.Ay.get(630) : m.Ay.get(629),
                                    volumeLabel: j() ? m.Ay.get(631) : m.Ay.get(628),
                                    name: s
                                }
                            })
                        })
                    }
                })
            };
            n(23418), n(16034);

            function wi(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var i = t[n];
                    i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, Ri(i.key), i)
                }
            }

            function Ri(e) {
                var t = function(e, t) {
                    if ("object" != typeof e || !e) return e;
                    var n = e[Symbol.toPrimitive];
                    if (void 0 !== n) {
                        var i = n.call(e, t || "default");
                        if ("object" != typeof i) return i;
                        throw new TypeError("@@toPrimitive must return a primitive value.")
                    }
                    return ("string" === t ? String : Number)(e)
                }(e, "string");
                return "symbol" == typeof t ? t : t + ""
            }! function(e) {
                e.ARROW_UP = "ArrowUp", e.ARROW_DOWN = "ArrowDown"
            }(Pi || (Pi = {}));
            var Mi = function() {
                function e(e) {
                    this.listRef = void 0, this.currentFocusIndex = void 0, this.listRef = e.listRef, this.currentFocusIndex = null
                }
                var t, n, i, o = e.prototype;
                return o.updateTabIndex = function() {
                    var e = this;
                    this.focusableElements.forEach((function(t, n) {
                        var i = n === e.currentFocusIndex ? 0 : -1;
                        t.setAttribute("tabindex", i.toString())
                    })), this.focusableElements[this.currentFocusIndex || 0].focus()
                }, o.handleKeyUp = function(e) {
                    Object.values(Pi).includes(e.key) && (this.updateCurrentFocusIndex(e), this.updateTabIndex())
                }, o.updateCurrentFocusIndex = function(e) {
                    var t = this.prevFocus,
                        n = this.focusableElements.length - 1 || null;
                    if (-1 === this.prevFocus) t = 0;
                    else switch (e.key) {
                        case Pi.ARROW_DOWN:
                            t = this.prevFocus === n ? 0 : this.prevFocus + 1;
                            break;
                        case Pi.ARROW_UP:
                            t = 0 === this.prevFocus ? 0 : this.prevFocus - 1
                    }
                    this.currentFocusIndex = t
                }, t = e, (n = [{
                    key: "prevFocus",
                    get: function() {
                        return Array.from(this.focusableElements).findIndex((function(e) {
                            return e === s.A.document.activeElement
                        }))
                    }
                }, {
                    key: "focusableElements",
                    get: function() {
                        var e;
                        return (null == (e = this.listRef.current) ? void 0 : e.querySelectorAll('[data-id="chat-message"], [data-id="chat-date"]')) || []
                    }
                }]) && wi(t.prototype, n), i && wi(t, i), Object.defineProperty(t, "prototype", {
                    writable: !1
                }), t
            }();

            function Ni(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function Ui(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Ni(Object(n), !0).forEach((function(t) {
                        Di(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Ni(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function Di(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function Bi(e, t) {
                return Bi = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, Bi(e, t)
            }
            var Li = X.A.getLogger("ChatMessagesListContainer"),
                Fi = [36, 10, 19, 1, 22, 23],
                Gi = [F.XQ.DELIVERED, F.XQ.READ],
                Vi = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).handleChangeMessageVisible = function(e, t, i) {
                            var o;
                            (function(e) {
                                return Boolean(e.video || e.audio)
                            })(e) ? t.isIntersecting ? n.updateMessageVisibility(e) : qe.y8.stopMediaPlaying(function(e) {
                                var t, n;
                                return (null == (t = e.video) ? void 0 : t.id) || (null == (n = e.audio) ? void 0 : n.id)
                            }(e)): t.isIntersecting && (i(), n.updateMessageVisibility(e), e.isLiked && e.isYours() ? (0, l.sx)(258, {
                                element: 1581
                            }) : 463 === (null == (o = e.status) ? void 0 : o.promoType) ? (0, l.sx)(258, {
                                element: 1350
                            }) : e.isYours() && (0, l.sx)(258, {
                                element: e.statusType === F.XQ.READ ? 1651 : 1652
                            }))
                        }, n.handleShowMessageOptions = function(e) {
                            (0, l.sx)(446, {
                                gesture: 9,
                                element: 970,
                                position: e.position
                            }), n.setState({
                                showMessageOptions: e
                            })
                        }, n.handleClickLike = function(e) {
                            n.props.onClickLike(e)
                        }, n.handleClickUnlike = function() {
                            n.props.onClickUnlike(n.state.showMessageOptions), n.setState({
                                showMessageOptions: null
                            })
                        }, n.handleClickReply = function() {
                            n.props.onClickReply(n.state.showMessageOptions), n.setState({
                                showMessageOptions: null
                            })
                        }, n.handleClickCopy = function(e) {
                            (0, A.lW)(e.message), n.setState({
                                showMessageOptions: null
                            })
                        }, n.handleCloseMessageOptions = function() {
                            n.setState({
                                showMessageOptions: null
                            })
                        }, n.listRef = (0, i.createRef)(), n.performFirstScroll = !0, n.state = {
                            isLoadingPage: !1,
                            messages: t.messages,
                            showMessageOptions: null
                        }, n.updateScroll = (0, De.A)(n.updateScroll.bind(n), 200), n.onReachTop = n.onReachTop.bind(n), n.onSelect = n.onSelect.bind(n), n.onUnmask = n.onUnmask.bind(n), n.scrollBottom = n.scrollBottom.bind(n), n.rovingTabIndex = new Mi({
                            listRef: n.listRef
                        }), n.fetchOlderMessages = (0, Ne.A)(n.fetchOlderMessages.bind(n)).callback, n.oldestUnreadTimestamp_ = function(e) {
                            var t = Hi(e),
                                n = (0, u.A)(e),
                                i = t && t.dateCreated - 1,
                                o = null == n ? void 0 : n.dateCreated;
                            return i || o || 0
                        }(t.messages), n.isModalOpened = !1, n.isNavigating = !1, n.hasScrolledToOffensiveMessage = !1, n.offsensiveMessagesElements = [], n
                    }
                    var n, o;
                    o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, Bi(n, o);
                    var r = t.prototype;
                    return r.onUnmask = function(e) {
                        var t = this;
                        (0, l.sx)(332, {
                            element: 522
                        }), p.A.getMaskedMessage(e.fromPersonId, [e.id]).then((function(n) {
                            Yi({
                                messages: n,
                                isSelectable: !1,
                                onDecline: t.props.onDecline,
                                onReport: t.props.onReport
                            }), t.setState({
                                messages: n
                            }), t.props.onUnmasked(e)
                        }))
                    }, r.onSelect = function(e) {
                        e.isSelected = !e.isSelected, (0, l.sx)(332, {
                            element: 514,
                            position: Math.max(this.state.messages.indexOf(e) || 0)
                        }), this.setState({
                            messages: this.state.messages
                        }), this.props.onSelect(e)
                    }, r.componentDidMount = function() {
                        var e = this.props,
                            t = e.oldScrollPosition,
                            n = e.scrollPosition;
                        O.A.on(O.A.BEFORE_SHOW_MODAL, this.handleShowModal, this), O.A.on(O.A.HIDE_MODAL, this.handleHideModal, this), a.A.navigationEvent.subscribe(this.handleNavigation, this), p.A.on(p.A.EVENTS.MESSAGE_DELETED, this.onChanges, this).on(p.A.EVENTS.MESSAGE_FROM_USER, this.handleNewMessage, this).on(p.A.EVENTS.MESSAGE_FROM_ME, this.handleNewMessage, this).on(p.A.EVENTS.MESSAGES_READ, this.onChanges, this), void 0 !== t && (this.performFirstScroll = n.isFirstScroll = !1, n.scrollTo(t, !1))
                    }, r.componentDidUpdate = function() {
                        !this.props.oldScrollPosition && this.performFirstScroll && (this.performFirstScroll = !1, this.updateScroll())
                    }, r.componentWillUnmount = function() {
                        O.A.off(O.A.BEFORE_SHOW_MODAL, this.handleShowModal, this), O.A.off(O.A.HIDE_MODAL, this.handleHideModal, this), a.A.navigationEvent.unsubscribe(this.handleNavigation, this), this.firstUnreadMessageElement = null, this.performFirstScroll = !1, this.isNavigating = !1, this.isModalOpened = !1, p.A.off(p.A.EVENTS.MESSAGE_DELETED, this.onChanges, this).off(p.A.EVENTS.MESSAGE_FROM_USER, this.handleNewMessage, this).off(p.A.EVENTS.MESSAGE_FROM_ME, this.handleNewMessage, this).off(p.A.EVENTS.MESSAGES_READ, this.onChanges, this)
                    }, r.handleNavigation = function() {
                        this.isNavigating = !0
                    }, r.handleShowModal = function() {
                        this.isModalOpened = !0
                    }, r.handleHideModal = function() {
                        this.isModalOpened = !1
                    }, r.updateMessageVisibility = function(e) {
                        var t;
                        "function" == typeof this.markMessageInView && this.markMessageInView(e.id), (t = e).isYours() || t.isRead || (this.props.onMessageViewed(e), p.A.markMessageRead(e))
                    }, r.isReplyFeatureAllowed = function() {
                        return p.A.isReplyFeatureAllowed(this.props.chatInstanceId)
                    }, r.render = function() {
                        var e = this;
                        if (!he.A.getUser()) return null;
                        var t = function(e) {
                                var t = e.props,
                                    n = Ki(t.chatInstanceId),
                                    i = n.length,
                                    o = t.isSelectable,
                                    r = n.map((function(e, t) {
                                        var r = i - ++t,
                                            s = e.statusType === G.X.FAILED ? e.status : function(e, t, n) {
                                                if (!e.isYours()) return;
                                                var i = n.length ? n[n.length - 1] : void 0;
                                                return i === e && i.isYours() ? e.status : void 0
                                            }(e, 0, n);
                                        return Object.assign(e, {
                                            isSelectable: o,
                                            isSelected: o && e.isSelected,
                                            status: s,
                                            id: e.id,
                                            fromUserId: e.fromPersonId,
                                            messageText: e.message,
                                            position: r
                                        })
                                    })),
                                    s = n.filter((function(e) {
                                        return e.replyToUid
                                    }));
                                return s.forEach((function(e) {
                                        var t = r.find((function(t) {
                                            return t.id === e.replyToUid
                                        }));
                                        t && (t.request = null)
                                    })), Yi(Ui(Ui({}, t), {}, {
                                        messages: r
                                    })),
                                    function(e) {
                                        for (var t, n = e.messages, i = null == (t = he.A.getUser()) ? void 0 : t.gender, o = [], r = n.length - 1; r >= 0; r--) {
                                            var s = n[r],
                                                a = n[r - 1];
                                            s.isOffensive && (o.push(n[r]), s.message = Wi(o, i), null != a && a.isOffensive ? n[r].isHidden = !0 : o = [])
                                        }
                                    }({
                                        messages: r
                                    }),
                                    function(e) {
                                        var t = e.messages,
                                            n = e.promos,
                                            i = e.dismissedPromos,
                                            o = e.onClickReadReceiptsPromoLink,
                                            r = n.find((function(e) {
                                                return ee.includes(e.getPromoBlockType())
                                            })),
                                            s = function(e) {
                                                var t = e.filter((function(e) {
                                                    return e.isYours()
                                                }));
                                                return t.slice(-1).pop()
                                            }(t);
                                        if (!r) {
                                            var a;
                                            return void(null != s && s.originalStatus && null != (a = s.status) && a.promoType && ee.includes(s.status.promoType) && (s.status = s.originalStatus))
                                        }
                                        if (s && 50 === s.messageType && "" !== s.question.other_answer) return void(s.status = s.originalStatus);
                                        var c = n.find((function(e) {
                                            return te.includes(e.getPromoBlockType())
                                        }));
                                        if (s && s === t[t.length - 1] && Gi.includes(s.statusType)) {
                                            var l, u, d = s.status;
                                            if (te.every((function(e) {
                                                    return !i.includes(e)
                                                })) && (c || null != (l = s.banner) && l.promo_block_type && te.includes(null == (u = s.banner) ? void 0 : u.promo_block_type))) s.status = {
                                                text: s._isFemale ? m.Ay.get(423) : m.Ay.get(421)
                                            };
                                            else {
                                                var p = r && r.getExtraTexts([])[0].getText();
                                                s.status = {
                                                    text: p,
                                                    textColor: "read-receipt",
                                                    promoType: r.getPromoBlockType(),
                                                    onClick: function() {
                                                        o(s)
                                                    }
                                                }
                                            }
                                            d && !d.promoType && (s.originalStatus = d)
                                        }
                                    }(Ui(Ui({}, t), {}, {
                                        messages: r
                                    })), r
                            }({
                                props: this.props
                            }),
                            n = Hi(t),
                            i = t.map((function(e) {
                                return {
                                    id: e.id,
                                    fromUserId: e.fromPersonId,
                                    messageText: e.message,
                                    messageType: Ve._J.REGULAR,
                                    originalMessageScaffold: e
                                }
                            })),
                            o = this.props,
                            r = o.messageLikeOnboarding,
                            s = o.isAllowUrlParsing,
                            a = o.isShowingOffensiveMessagesPrompt,
                            c = this.state,
                            l = c.showMessageOptions,
                            u = c.isLoadingPage,
                            d = t.some((function(e) {
                                return e.isHighlighted
                            }));
                        if (r.isActive && !d && t.filter((function(e) {
                                return e.allowLike
                            })).length) {
                            var p = Hi(t) || function(e) {
                                var t = e.filter((function(e) {
                                    return !e.isYours()
                                }));
                                return t.slice(-1).pop()
                            }(t);
                            if (p) {
                                var f = t.findIndex((function(e) {
                                    return e.id === p.id
                                }));
                                t[f].isHighlighted = !0
                            }
                        }
                        return (0, S.jsxs)(nt, {
                            children: [(0, S.jsx)(Ve.E1, {
                                messages: i,
                                onMessageVisible: function(t) {
                                    e.markMessageInView = t
                                },
                                children: function(t) {
                                    var i = t.messages,
                                        o = t.messageVisibilityEvent;
                                    return (0, S.jsxs)(ze.A, {
                                        onKeyUp: function(t) {
                                            return e.rovingTabIndex.handleKeyUp(t)
                                        },
                                        innerRef: e.listRef,
                                        a11y: {
                                            label: m.Ay.get(424)
                                        },
                                        children: [(0, S.jsx)(Je.A, {
                                            rootMargin: "0px 0px 80px 0px",
                                            onChange: e.onReachTop,
                                            children: (0, S.jsx)("div", {})
                                        }), u ? (0, S.jsx)(Qe.A, {}) : null, i.map((function(t, i) {
                                            return e.mapMessageComponent(n, t, o, r, s, a, i)
                                        }))]
                                    })
                                }
                            }), l ? (0, S.jsx)(Vn, {
                                message: l,
                                isReplyFeatureAllowed: this.isReplyFeatureAllowed(),
                                onClickUnlike: this.handleClickUnlike,
                                onClickReply: this.handleClickReply,
                                onClickCopy: this.handleClickCopy,
                                onClose: this.handleCloseMessageOptions
                            }) : null]
                        })
                    }, r.onReachTop = function(e) {
                        !e.isIntersecting || this.isModalOpened || this.isNavigating || (this.props.scrollPosition.prepare(), this.fetchOlderMessages())
                    }, r.scrollBottom = function() {
                        this.props.scrollPosition.scrollToBottom(this.allowAnimate())
                    }, r.onChanges = function(e) {
                        var t = this,
                            n = this.props.chatUser.getUserId(),
                            i = this.props.chatInstanceId;
                        [i, e.fromPersonId || e, e.toPersonId || e].includes(n) && this.setState({
                            messages: Ki(i)
                        }, (function() {
                            t.updateScroll()
                        }))
                    }, r.handleNewMessage = function(e) {
                        "out" === e.direction && e.isTemporary() ? this.sendingMessage = e : "in" === e.direction && this.updateScroll()
                    }, r.allowAnimate = function(e) {
                        return (!e || 19 !== e.messageType) && (this.props.scrollPosition.isFirstScroll ? this.state.messages.length < 25 : this.props.scrollPosition.scrollBottom < 2 * this.props.scrollPosition.wrapper.clientHeight)
                    }, r.firstScroll = function() {
                        return !!this.props.scrollPosition.isFirstScroll && (this.firstUnreadMessageElement ? this.props.scrollPosition.scrollIntoView(this.firstUnreadMessageElement, 65, !1) : this.props.scrollPosition.scrollToBottom(!1), this.props.scrollPosition.isFirstScroll = !1, this.firstUnreadMessageElement = null, !0)
                    }, r.scrollToUnreadMessage = function() {
                        var e = Hi(this.state.messages);
                        return e && e.dateCreated > this.oldestUnreadTimestamp_ ? (this.oldestUnreadTimestamp_ = e.dateCreated, this.props.onNewUnreadMessage(e)) : e && e.isYours() && this.props.scrollPosition.scrollToBottom(!0), Boolean(e)
                    }, r.scrollToSendingMessage = function() {
                        this.sendingMessage && (this.props.scrollPosition.scrollToBottom(this.allowAnimate(this.sendingMessage)), this.sendingMessage = null)
                    }, r.scrollToOffensiveMessage = function() {
                        if (this.props.isShowingOffensiveMessagesPrompt && !this.hasScrolledToOffensiveMessage && this.offsensiveMessagesElements[0]) return this.props.scrollPosition.scrollIntoView(this.offsensiveMessagesElements[0], 65, !1), !0
                    }, r.updateScroll = function() {
                        this.state.messages.length && !this.state.isLoadingPage && (this.scrollToOffensiveMessage() || this.firstScroll() || this.scrollToUnreadMessage())
                    }, r.fetchOlderMessages = function() {
                        var e = this,
                            t = this.state.messages,
                            n = this.props.counter > t.length;
                        if (!this.state.isLoadingPage && n) {
                            var i;
                            this.setState({
                                isLoadingPage: !0
                            });
                            var o = Number(null == (i = t[0]) ? void 0 : i.id),
                                r = this.props.chatUser.getUserId(),
                                s = {
                                    count: 25,
                                    direction: 1,
                                    inclusive: !1,
                                    messageId: isNaN(o) ? void 0 : o
                                };
                            p.A.getMessages(r, s).then((function(t) {
                                e.props.scrollPosition.prepare(), e.setState({
                                    isLoadingPage: !1,
                                    messages: t
                                })
                            })).catch((function(t) {
                                e.setState({
                                    isLoadingPage: !1
                                }), Li.error("fetchOlderMessages::SERVER_GET_CHAT_MESSAGES", t, {
                                    userId: r
                                }, s)
                            }))
                        }
                    }, r.mapMessageComponent = function(e, t, n, o, r, a, c) {
                        var u = this,
                            d = t.originalMessageScaffold,
                            p = a && d.isLikelyOffensive,
                            f = o.isActive && d.isHighlighted;
                        if (d.isHidden) return null;
                        var h = function(e) {
                                var t, n, o, r, a, c = e.user,
                                    u = e.chatUser,
                                    d = e.chatComponentMessage,
                                    p = e.messageLikeTooltip,
                                    f = e.isMessageLikeOnboarding,
                                    h = e.onLike,
                                    g = e.isAllowUrlParsing,
                                    v = e.onReport,
                                    A = e.onSelect,
                                    y = e.onUnmask,
                                    b = e.onWarnInappropriate,
                                    x = e.handleShowMessageOptions,
                                    C = e.scrollPosition,
                                    _ = e.onClickMessage,
                                    k = e.messageVisibilityEvent,
                                    j = e.onQuestionsGameStart,
                                    E = e.onQuestionsGameAnswer,
                                    O = d.originalMessageScaffold,
                                    T = d.isMessageFromCurrentUser ? "out" : "in",
                                    P = d.isContinuation,
                                    I = O.isLiked,
                                    w = f,
                                    R = u.getUserId() === d.fromUserId ? u.getName() : c.name,
                                    M = gt;
                                I && (a = (0, S.jsx)(Ye.A, {
                                    status: "visible"
                                }));
                                w && (a = (0, S.jsx)(Ue.A, {
                                    appear: !0,
                                    in: !0,
                                    timeout: 200,
                                    children: function(e) {
                                        var t, n;
                                        if ("entered" === e) t = "animated", n = "visible";
                                        else t = "hidden", n = "idle";
                                        return (0, S.jsxs)(i.Fragment, {
                                            children: [(0, S.jsx)(Ye.A, {
                                                status: t
                                            }), (0, S.jsx)("div", {
                                                style: {
                                                    position: "absolute",
                                                    top: 0,
                                                    left: 0,
                                                    width: 37
                                                },
                                                children: (0, S.jsx)(Ke.A, {
                                                    placement: "top-start",
                                                    color: "white",
                                                    animationStatus: n,
                                                    text: p
                                                })
                                            })]
                                        })
                                    }
                                }), (0, l.sx)(258, {
                                    element: 1580
                                }));
                                var N = {
                                    label: Ge([R, O.message]),
                                    name: R
                                };
                                switch (O.messageType) {
                                    case "REPORTED_XP":
                                    case 42:
                                        return (0, S.jsx)(We.A, {
                                            direction: T,
                                            isContinuation: P,
                                            message: O.message,
                                            chatComponentMessage: d,
                                            meta: 42 === O.messageType ? m.Ay.get(38) : void 0,
                                            a11y: N
                                        });
                                    case 52:
                                        return (0, S.jsx)(ri, {
                                            emoji: null == (t = O.reaction) ? void 0 : t.emoji,
                                            messageText: O.message,
                                            userPhotoSrc: null == (n = O.reaction) ? void 0 : n.reactedPhotoSrc,
                                            direction: O.direction,
                                            a11y: {
                                                label: Ge([O.message, null == (o = O.reaction) ? void 0 : o.emoji])
                                            }
                                        });
                                    case "EMOJI":
                                        return (0, S.jsx)(Ct, {
                                            message: O,
                                            extra: a,
                                            direction: T,
                                            isContinuation: P,
                                            onShowOptions: x,
                                            onMessageLike: h,
                                            a11y: N
                                        });
                                    case "ANIMATED_EMOJI":
                                        M = xt;
                                        break;
                                    case 39:
                                        return (0, S.jsx)(bi, {
                                            fromChat: !0,
                                            message: O,
                                            isAllowUrlParsing: g,
                                            onClick: _,
                                            onClickUrlMessage: Ji,
                                            onClickUrlPreviewImage: Xi,
                                            onClickUrlPreviewText: Zi,
                                            messageSenderUserName: R
                                        });
                                    case 1:
                                        M = bi;
                                        break;
                                    case 19:
                                        M = O.image ? Bn : O.video ? Ii : O.audio ? dt : gt;
                                        break;
                                    case 23:
                                        M = li;
                                        break;
                                    case 36:
                                        M = tn;
                                        break;
                                    case 10:
                                        M = sn;
                                        break;
                                    case 22:
                                        M = O.image ? li : bi;
                                        break;
                                    case 28:
                                        M = null != (r = s.A.navigator.mediaDevices) && r.getUserMedia ? si : gt;
                                        break;
                                    case 29:
                                    case 30:
                                        M = si;
                                        break;
                                    case 25:
                                    case 27:
                                        M = Si;
                                        break;
                                    case 7:
                                    case 47:
                                        M = wn;
                                        break;
                                    case 50:
                                        M = Zn
                                }
                                return (0, S.jsx)(M, {
                                    user: c,
                                    chatUser: u,
                                    scrollPosition: C,
                                    isContinuation: P,
                                    isAllowUrlParsing: g,
                                    direction: T,
                                    emoji: xt.SUPPORTED_EMOJI.HEART,
                                    fromChat: !0,
                                    chatComponentMessage: d,
                                    message: O,
                                    extra: a,
                                    onClickUrlMessage: Ji,
                                    onClickUrlPreviewImage: Xi,
                                    onClickUrlPreviewText: Zi,
                                    messageVisibilityEvent: k,
                                    onReport: v,
                                    onSelect: A,
                                    onMessageLike: h,
                                    onShowOptions: x,
                                    onUnmask: y,
                                    onWarnInappropriate: b,
                                    onQuestionsGameStart: j,
                                    onQuestionsGameAnswer: E,
                                    messageSenderUserName: R
                                })
                            }({
                                user: he.A.getUser(),
                                chatUser: this.props.chatUser,
                                chatComponentMessage: t,
                                messageLikeTooltip: null == o ? void 0 : o.text,
                                isMessageLikeOnboarding: f,
                                onLike: this.handleClickLike,
                                isAllowUrlParsing: r,
                                onReport: this.props.onReport,
                                onDecline: this.props.onDecline,
                                onSelect: this.onSelect,
                                onUnmask: this.onUnmask,
                                onWarnInappropriate: this.props.onWarnInappropriate,
                                handleShowMessageOptions: this.handleShowMessageOptions,
                                scrollPosition: this.props.scrollPosition,
                                onClickMessage: this.props.onClickMessage,
                                messageVisibilityEvent: n,
                                onQuestionsGameStart: this.props.onQuestionsGameStart,
                                onQuestionsGameAnswer: this.props.onQuestionsGameAnswer
                            }),
                            g = f || p,
                            v = 0 === c;
                        return (0, S.jsx)(i.Fragment, {
                            children: (0, S.jsx)(Je.A, {
                                rootMargin: "10px 0px 0px 0px",
                                onChange: function(e, t) {
                                    return u.handleChangeMessageVisible(d, e, t)
                                },
                                children: (0, S.jsxs)("div", {
                                    className: Me()("chat-message", {
                                        "is-highlighted": g
                                    }),
                                    ref: this.onInnerRef.bind(this, {
                                        message: d,
                                        firstUnreadMessage: e
                                    }),
                                    "data-qa": g ? "chat-message-highlighted" : void 0,
                                    children: [d.chatDate ? (0, S.jsx)(He.A, {
                                        text: d.chatDate,
                                        isCurrent: v
                                    }) : null, h]
                                })
                            }, d.id)
                        }, d.id)
                    }, r.onInnerRef = function(e, t) {
                        var n = e.message;
                        e.firstUnreadMessage === n && (this.firstUnreadMessageElement = t), n.promoType && Qi(n), n === this.sendingMessage && this.scrollToSendingMessage(), n.isLikelyOffensive && !n.isYours() && this.offsensiveMessagesElements.push(t)
                    }, t
                }(i.Component),
                qi = Vi;

            function Hi(e) {
                return e.find((function(e) {
                    return !e.isRead && !e.isYours()
                }))
            }

            function Qi(e) {
                Qi.trackedMessages || (Qi.trackedMessages = []), e.isRead || -1 !== Qi.trackedMessages.indexOf(e.id) || (Qi.trackedMessages.push(e.id), (0, l.sx)(138, {
                    banner_id: e.promoType
                }))
            }

            function Yi(e) {
                var t = e.messages,
                    n = e.isSelectable,
                    i = e.onDecline,
                    o = e.onReport;
                t.forEach((function(e) {
                    e.isMasked && !e.isYours() && e.hasLewdPhoto && (e.status = {
                        text: m.Ay.get(15),
                        icon: "generic-forbidden",
                        iconColor: "error",
                        textColor: "error",
                        onClick: function() {
                            i(e)
                        }
                    })
                }));
                var r = (0, Be.A)(t, (function(e) {
                    return e.isMasked && !e.isYours() && !e.status
                }));
                if (r && (r.status = {
                        text: m.Ay.get(476),
                        icon: "generic-tap"
                    }), !n) {
                    var s = (0, Be.A)(t, zi);
                    s && (s.status = {
                        text: m.Ay.get(468),
                        icon: "generic-report",
                        onClick: o
                    })
                }
            }

            function Wi(e, t) {
                var n = e.length,
                    i = Ie.K6;
                2 === t ? i = Ie.Vk : void 0 === t && (i = Ie.Ah);
                var o = e.some((function(e) {
                        return 19 === e.originalMessageType
                    })),
                    r = e.some((function(e) {
                        return 19 !== e.originalMessageType
                    }));
                return o && r ? m.Ay.get(22, {
                    you: Ie.ko.for("you", i)
                }) : o ? m.Ay.get(24, {
                    num: n,
                    photo: Ie._Q.for("photo", n),
                    you: Ie.ko.for("you", i)
                }) : r ? m.Ay.get(23, {
                    num: n,
                    messages: Ie._Q.for("messages", n),
                    you: Ie.ko.for("you", i)
                }) : void 0
            }

            function zi(e) {
                return !e.isMasked && !e.isYours() && Fi.includes(e.messageType)
            }

            function Ki(e) {
                return p.A.getCachedClientOpenChat(e).messages
            }

            function Ji(e) {
                var t = e.target;
                if (t.classList.contains("js-deep-link")) {
                    var n = new s.A.URL(t.href);
                    n.searchParams.has("flow_id") && (e.preventDefault(), O.A.trigger(O.A.SCREEN_STORY_DEEP_LINK_CLICK, n.searchParams.get("flow_id")))
                }(0, l.sx)(332, {
                    element: 660,
                    parent_element: "true" === t.dataset.blacklisted ? 1173 : 1174
                })
            }

            function Xi() {
                (0, l.sx)(332, {
                    element: 1171,
                    parent_element: 1172
                })
            }

            function Zi() {
                (0, l.sx)(332, {
                    element: 1170,
                    parent_element: 1172
                })
            }
            var $i = n(87952);

            function eo(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function to(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var no = function(e) {
                var t = e.actions,
                    n = e.cancelLabel,
                    i = e.onCancel;
                return (0, S.jsxs)(_n.A, {
                    isDismissible: !1,
                    wrapperType: _n.T.ACTION_SHEET,
                    hasDefaultDismissButton: !1,
                    children: [t.map((function(e) {
                        return (0, S.jsx)(Fn.A, function(e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var n = null != arguments[t] ? arguments[t] : {};
                                t % 2 ? eo(Object(n), !0).forEach((function(t) {
                                    to(e, t, n[t])
                                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : eo(Object(n)).forEach((function(t) {
                                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                                }))
                            }
                            return e
                        }({}, e))
                    })), (0, S.jsx)(Fn.A, {
                        text: n || m.Ay.get(451),
                        onClick: i
                    })]
                })
            };

            function io(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function oo(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var ro = function(e) {
                    var t = e.header,
                        n = e.text,
                        i = e.actions,
                        o = e.isDismissible,
                        r = void 0 !== o && o,
                        s = e.onDismiss;
                    return (0, S.jsx)(_n.A, {
                        wrapperType: _n.T.ACTION_SHEET,
                        header: {
                            title: t,
                            text: n
                        },
                        isDismissible: r,
                        onDismiss: s,
                        children: i.map((function(e) {
                            return (0, S.jsx)(Fn.A, function(e) {
                                for (var t = 1; t < arguments.length; t++) {
                                    var n = null != arguments[t] ? arguments[t] : {};
                                    t % 2 ? io(Object(n), !0).forEach((function(t) {
                                        oo(e, t, n[t])
                                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : io(Object(n)).forEach((function(t) {
                                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                                    }))
                                }
                                return e
                            }({}, e))
                        }))
                    })
                },
                so = n(55632),
                ao = n(51709),
                co = n(4571),
                lo = n(27895),
                uo = n(40578),
                po = n(30784),
                fo = n(46770),
                ho = n(51634),
                go = n(20017),
                mo = n(73616),
                vo = n(84932),
                Ao = function(e) {
                    var t = e.errorMessage,
                        n = e.inputValue,
                        i = e.onInputChange,
                        o = e.onAcceptButtonClick,
                        r = e.onCancelButtonClick;
                    return (0, S.jsxs)(co.A, {
                        isCompact: !0,
                        align: "start",
                        children: [(0, S.jsx)(lo.A, {
                            size: "icon",
                            children: (0, S.jsx)(cn.A, {
                                name: "badge-email"
                            })
                        }), (0, S.jsx)(uo.A, {
                            text: m.Ay.get(20),
                            tag: "h2"
                        }), (0, S.jsx)(po.A, {
                            text: m.Ay.get(19)
                        }), (0, S.jsx)(ho.A, {
                            children: (0, S.jsx)(mo.A, {
                                onSubmit: function(e) {
                                    return (0, ao.Y4)(e, o)
                                },
                                children: (0, S.jsx)(vo.A, {
                                    type: "email",
                                    value: n,
                                    label: m.Ay.get(18),
                                    errorMessage: t,
                                    onChange: i,
                                    dataQa: {
                                        "data-qa": "name-input"
                                    },
                                    fieldId: "name-input"
                                })
                            })
                        }), (0, S.jsxs)(fo.A, {
                            children: [(0, S.jsx)(go.A, {
                                text: m.Ay.get(17),
                                onClick: o
                            }), (0, S.jsx)(go.A, {
                                semantic: "tertiary",
                                text: m.Ay.get(16),
                                onClick: r
                            })]
                        })]
                    })
                },
                yo = n(52864),
                bo = n(35837),
                xo = n(24711);

            function So(e, t) {
                return So = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, So(e, t)
            }
            var Co = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).handleAcceptButtonClick = function() {
                            n.validateEmail(n.state.email, (function(e) {
                                if (e) {
                                    var t = (0, bo.A)(he.A.getUser(), ge.KJW),
                                        i = t.getEmail();
                                    return t.setEmail(n.state.email), h.A.getInstance().set(t, [10], 231).then((function() {
                                        n.props.onEmailSaved(), n.setState({
                                            isVisible: !1
                                        })
                                    })).catch((function(e) {
                                        var n = (0, xo.z)(e instanceof ge.beZ ? e.toJSON() : void 0, 230);
                                        return U.A.showNotification({
                                            text: n.errorMessage,
                                            type: U.A.TYPES.ERROR
                                        }), t.setEmail(i), n
                                    }))
                                }
                            }))
                        }, n.handleCancelButtonClick = function() {
                            n.setState({
                                isVisible: !1
                            }), n.props.onClickCancel()
                        }, n.handleInputChange = function(e) {
                            n.setState({
                                email: e.target.value
                            })
                        }, n.validateEmail = function(e, t) {
                            yo.A.getInstance().getValidateUserField({
                                field_type: 10,
                                value: e,
                                context: 190
                            }).then((function(e) {
                                if (e) {
                                    var i = n.onValidateEmail(e);
                                    t && t(i)
                                }
                            }))
                        }, n.onValidateEmail = function(e) {
                            var t = "";
                            return !e.valid && (t = e.error_message), n.setState({
                                errorMessage: t
                            }), Boolean(e.valid)
                        }, n.state = {
                            isVisible: !0,
                            errorMessage: "",
                            email: ""
                        }, n
                    }
                    var n, i;
                    return i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, So(n, i), t.prototype.render = function() {
                        return (0, S.jsx)(_n.A, {
                            isVisible: this.state.isVisible,
                            isDismissible: !1,
                            isPadded: !0,
                            hasDefaultDismissButton: !1,
                            children: (0, S.jsx)(Ao, {
                                inputValue: this.state.email,
                                errorMessage: this.state.errorMessage,
                                onAcceptButtonClick: this.handleAcceptButtonClick,
                                onCancelButtonClick: this.handleCancelButtonClick,
                                onInputChange: this.handleInputChange
                            })
                        })
                    }, t
                }(i.Component),
                _o = n(60414),
                ko = n(5974);

            function jo(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function Eo(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? jo(Object(n), !0).forEach((function(t) {
                        Oo(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : jo(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function Oo(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var To = {
                UserDislike: 1,
                UserScam: 2,
                SpamScamOther: 3,
                RudeOther: 4,
                HateSpeech: 5,
                UserSpammer: 9,
                UserRude: 10,
                IllegalActivity: 11,
                InappropriateContentPhoto: 12,
                UserAgainstLaw: 13,
                NotInterested: 14
            };

            function Po() {
                U.A.showNotification({
                    type: U.A.TYPES.ERROR
                })
            }
            var Io = function(e) {
                var t = e.otherUserId,
                    n = e.selectedMessages,
                    o = e.promo,
                    r = e.isSelectable,
                    s = e.isDeleted,
                    u = e.isShowingModal,
                    d = e.isReportingContent,
                    p = e.blockUser,
                    f = e.onReportContent,
                    h = e.onCancel,
                    v = e.onReportResponse,
                    A = e.onSetIsReportingContent,
                    y = (0, i.useState)(""),
                    b = y[0],
                    x = y[1],
                    C = (0, i.useState)(!1),
                    _ = C[0],
                    k = C[1],
                    j = (0, i.useState)(!1),
                    E = j[0],
                    O = j[1],
                    T = (0, i.useState)([]),
                    P = T[0],
                    I = T[1],
                    w = (0, i.useRef)(!1),
                    R = function() {
                        (0, l.sx)(332, {
                            element: 513,
                            parent_element: 512
                        }), f(), A(!1)
                    },
                    M = function() {
                        (0, l.sx)(332, {
                            element: 106,
                            parent_element: 512
                        }), p(), A(!1)
                    },
                    N = function() {
                        var e;
                        if (w.current || null != (e = he.A.getUser()) && e.email) {
                            var t = 3;
                            return n.some((function(e) {
                                return e.hasLewdPhoto
                            })) && (t = 4), O(!0), $i.A.getInstance().getChatReportingReasons(t).then((function(e) {
                                var t, n, i = (t = e.getReportType([]), n = Math.floor(t.length / 2), t.map((function(e, t) {
                                    return {
                                        id: e.getUid(),
                                        content: e.getText(),
                                        isPrimary: t < n
                                    }
                                })));
                                (0, l.sx)(258, {
                                    element: 512
                                }), I(i), O(!1)
                            }))
                        }
                        k(!0)
                    },
                    U = function() {
                        d && (0, l.sx)(332, {
                            element: 65,
                            parent_element: 512
                        }), h()
                    };
                (0, i.useEffect)((function() {
                    var e = m.Ay.get(468),
                        t = n.length;
                    x(t ? e + " (" + t + ")" : e)
                }), [n.length]);
                var D = d && P.length ? P.map((function(e) {
                        return {
                            text: e.content,
                            type: e.isPrimary ? "generic" : "destructive",
                            onClick: function() {
                                return i = e.id, o = {
                                    reportTypeId: i,
                                    userId: t,
                                    context: 10,
                                    messageIdList: n.map((function(e) {
                                        return e.id
                                    }))
                                }, (0, l.sx)(332, {
                                    element: 1372,
                                    parent_element: 512
                                }), (0, l.sx)(485, {
                                    encrypted_user_id: t,
                                    count_of_content: n.length
                                }), O(!0), void we.A.getInstance().set(o).then((function(e) {
                                    var n;
                                    v(e, i), (0, l.sx)(485, {
                                        report_reason: (n = i, To[n] || 0),
                                        encrypted_user_id: t
                                    }), O(!1), A(!1)
                                }));
                                var i, o
                            },
                            dataQA: {
                                "data-qa-type": e.isPrimary ? "primary" : "danger"
                            }
                        }
                    })) : [{
                        key: "report",
                        text: m.Ay.get(21),
                        onClick: R,
                        dataQA: {
                            "data-qa": "report",
                            "data-qa-type": "primary"
                        }
                    }, {
                        key: "block",
                        text: m.Ay.get(40),
                        type: "destructive",
                        onClick: M,
                        dataQA: {
                            "data-qa": "block"
                        }
                    }],
                    B = n.map((function(e) {
                        return e.id
                    })),
                    L = ko.A.isActive() && !u ? (0, S.jsx)(_o.A, {
                        clientSource: 10,
                        otherUserId: t,
                        isDeleted: s,
                        onClose: U,
                        onReport: function(e) {
                            v(e, null), A(!1)
                        },
                        onBlock: function() {
                            g.A.getInstance().unmatchUser({
                                personId: t,
                                folderId: 31
                            }).then((function() {
                                a.A.navigate(c.x.CONNECTIONS)
                            })).catch(Po)
                        },
                        messageIdList: B
                    }) : (0, S.jsx)(no, {
                        actions: D,
                        cancelLabel: m.Ay.get(451),
                        onCancel: U
                    });
                return (0, S.jsxs)(i.Fragment, {
                    children: [!u && !d || o ? null : L, o ? (0, S.jsx)(ro, Eo({}, o)) : null, _ ? (0, S.jsx)(Co, {
                        onClickCancel: function() {
                            O(!1)
                        },
                        onEmailSaved: function() {
                            w.current = !0, N()
                        }
                    }) : null, (0, S.jsx)(so.A, {
                        text: b,
                        isActive: r,
                        isDisabled: !n.length || E,
                        isLoading: E,
                        onClick: function() {
                            O(!0), (0, l.sx)(332, {
                                element: 49
                            }), N().then((function() {
                                ko.A.hit(), A(!0)
                            }))
                        },
                        dataQA: {
                            "data-qa": "report-content"
                        }
                    })]
                })
            };

            function wo(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function Ro(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var Mo = function(e) {
                    var t = e.title,
                        n = e.message,
                        i = e.yesAction,
                        o = e.noAction,
                        r = e.backdropColor;
                    return (0, S.jsx)(_n.A, {
                        wrapperType: _n.T.ACTION_SHEET,
                        isDismissible: !1,
                        header: {
                            title: t,
                            text: n
                        },
                        backdropColor: r,
                        children: [i, o].map((function(e, t) {
                            return (0, S.jsx)(Fn.A, function(e) {
                                for (var t = 1; t < arguments.length; t++) {
                                    var n = null != arguments[t] ? arguments[t] : {};
                                    t % 2 ? wo(Object(n), !0).forEach((function(t) {
                                        Ro(e, t, n[t])
                                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : wo(Object(n)).forEach((function(t) {
                                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                                    }))
                                }
                                return e
                            }({}, e), "modal-action-button-" + t)
                        }))
                    })
                },
                No = n(97547);

            function Uo(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function Do(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Uo(Object(n), !0).forEach((function(t) {
                        Bo(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Uo(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function Bo(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var Lo, Fo, Go = function(e) {
                    var t = e.chatInstanceId,
                        n = e.otherUserId,
                        o = e.chatUser,
                        r = e.counter,
                        a = e.messageLikeOnboarding,
                        c = e.isSelectable,
                        u = e.isAllowUrlParsing,
                        d = e.isUserSubstitute,
                        f = e.isDummy,
                        h = e.messages,
                        v = e.promoBanners,
                        A = e.dismissedPromoBanners,
                        y = e.scrollingContainerRef,
                        b = e.scroller,
                        x = e.oldScrollPosition,
                        C = e.isShowingOffensiveMessagesPrompt,
                        _ = e.onTogglePd,
                        k = e.onToggleReport,
                        j = e.onShowPromoCards,
                        E = e.onUpdateInput,
                        O = e.onUpdateChat,
                        T = e.onClickReadReceiptsPromoLink,
                        P = e.onConfirmResendInappropriate,
                        I = e.onNewMessageNotification,
                        R = e.onSetScroller,
                        M = e.onUserBlocked,
                        N = e.onQuestionsGameStart,
                        U = e.onQuestionsGameAnswer,
                        D = e.onDismissOffensiveMessagesModal,
                        B = (0, i.useState)(),
                        L = B[0],
                        F = B[1],
                        G = (0, i.useState)([]),
                        V = G[0],
                        q = G[1],
                        H = (0, i.useState)(),
                        Q = H[0],
                        Y = H[1],
                        W = (0, i.useState)(!1),
                        z = W[0],
                        K = W[1],
                        J = (0, i.useState)(!1),
                        X = J[0],
                        Z = J[1],
                        $ = (0, i.useRef)(0),
                        ee = function() {
                            (0, l.sx)(332, {
                                element: 511
                            }), K(!0)
                        },
                        te = function() {
                            M(), (0, l.sx)(258, {
                                element: 520
                            })
                        },
                        ne = function() {
                            g.A.getInstance().addUserToFolder({
                                uid: n,
                                folder: 9,
                                context: 10
                            }).then((function() {
                                (0, l.sx)(258, {
                                    element: 520
                                }), s.A.setTimeout((function() {
                                    F({
                                        text: m.Ay.get(431),
                                        actions: [{
                                            text: m.Ay.get(467),
                                            onClick: te,
                                            dataQA: {
                                                "data-qa": "block-user-confirmation"
                                            }
                                        }],
                                        isDismissible: !0,
                                        onDismiss: te
                                    })
                                }), 500)
                            }))
                        },
                        ie = function(e) {
                            switch (Number(e)) {
                                case 77:
                                    (0, l.sx)(332, {
                                        element: 65,
                                        parent_element: 518
                                    });
                                    break;
                                case 102:
                                    (0, l.sx)(332, {
                                        element: 197,
                                        parent_element: 518
                                    }), ne()
                            }
                            Z(!1), F(void 0), k(!1)
                        },
                        oe = function(e, t) {
                            var n = ko.A.isActive();
                            null == e || e.forEach((function(e) {
                                if (!n && null != e && e.getPromo) {
                                    var i = e.getPromo();
                                    F({
                                        actions: i.getButtons([]).map((function(e) {
                                            return {
                                                text: e.getText(),
                                                action: e.getAction(),
                                                type: 77 === e.getAction() ? "generic" : "destructive",
                                                onClick: function() {
                                                    return ie(e.getAction())
                                                }
                                            }
                                        })),
                                        header: i.getHeader(),
                                        text: i.getMssg()
                                    });
                                    var o = 518;
                                    "UserDislike" === t && (o = 519), (0, l.sx)(258, {
                                        element: o
                                    })
                                }
                                e && e instanceof ge.mSF && (p.A.updateChatMessages(e).length && O())
                            })), n && (Z(!1), F(void 0), k(!1))
                        };
                    return (0, i.useEffect)((function() {
                        if (y.current) {
                            var e = new No.A(y.current);
                            f || (e.isFirstScroll = !0), R(e)
                        }
                    }), [f, y, R]), (0, i.useEffect)((function() {
                        c || q([])
                    }), [c]), (0, i.useEffect)((function() {
                        return function() {
                            s.A.clearTimeout($.current)
                        }
                    }), []), (0, i.useEffect)((function() {
                        var e;
                        C ? ((0, l.sx)(258, {
                            element: 1798
                        }), Y({
                            title: m.Ay.get(147, {
                                name: null == (e = he.A.getUser()) ? void 0 : e.name
                            }),
                            message: m.Ay.get(391, {
                                other_user: Ie.ko.for("other_user", (0, m.Bt)(o.getGender()))
                            }),
                            yesAction: {
                                text: m.Ay.get(146),
                                dataQA: {
                                    "data-qa": "confirm-keep-chatting"
                                },
                                onClick: function() {
                                    (0, l.sx)(332, {
                                        element: 51,
                                        parent_element: 1798
                                    }), Y(void 0), D(!0)
                                }
                            },
                            noAction: {
                                text: m.Ay.get(145),
                                dataQA: {
                                    "data-qa": "confirm-block-report"
                                },
                                type: "destructive",
                                onClick: function() {
                                    (0, l.sx)(332, {
                                        element: 87,
                                        parent_element: 1798
                                    }), Y(void 0), ee(), D(!1)
                                }
                            },
                            backdropColor: "transparent"
                        }), new Pe.Ay(278, {
                            common_stats: {
                                source: 16,
                                event: 2,
                                context: 10,
                                chat_instance_id: t
                            }
                        }).request()) : Y(void 0)
                    }), [C, t, o, D]), (0, S.jsxs)(i.Fragment, {
                        children: [b ? (0, S.jsx)(qi, {
                            chatInstanceId: t,
                            chatUser: o,
                            counter: r,
                            messageLikeOnboarding: a,
                            isSelectable: c,
                            isAllowUrlParsing: u,
                            messages: h,
                            promos: v,
                            dismissedPromos: A,
                            onMessageViewed: function() {
                                I(!1)
                            },
                            onNewUnreadMessage: function(e) {
                                I(!0, (null == e ? void 0 : e.displayMessage) || (null == e ? void 0 : e.message))
                            },
                            onDecline: function(e) {
                                (0, l.sx)(332, {
                                    element: 1266
                                });
                                var t = (0, se.nV)();
                                Y({
                                    title: m.Ay.get(9, {
                                        you: Ie.ko.for("you", t)
                                    }),
                                    message: m.Ay.get(8),
                                    yesAction: {
                                        text: m.Ay.get(7),
                                        onClick: function() {
                                            (0, l.sx)(332, {
                                                element: 288,
                                                parent_element: 1268
                                            }),
                                            function(e) {
                                                we.A.getInstance().set({
                                                    reportTypeId: "",
                                                    context: 10,
                                                    blockUser: !1,
                                                    userId: e.fromPersonId,
                                                    messageIdList: [e.id],
                                                    reportType: 13
                                                }).then((function(e) {
                                                    oe(e, null), k(!1), null == e || e.forEach((function(e) {
                                                        if (null != e && e.getPromo) {
                                                            var t = e.getPromo();
                                                            F({
                                                                actions: t.getButtons([]).map((function(e) {
                                                                    return {
                                                                        text: e.getText(),
                                                                        action: e.getAction(),
                                                                        type: 77 === e.getAction() ? "generic" : "destructive",
                                                                        onClick: function() {
                                                                            return ie(e.getAction())
                                                                        }
                                                                    }
                                                                })),
                                                                header: t.getHeader(),
                                                                text: t.getMssg()
                                                            }), (0, l.sx)(258, {
                                                                element: 518
                                                            })
                                                        }
                                                    }))
                                                }))
                                            }(e), Y(void 0)
                                        }
                                    },
                                    noAction: {
                                        text: m.Ay.get(6),
                                        type: "destructive",
                                        onClick: function() {
                                            (0, l.sx)(332, {
                                                element: 113,
                                                parent_element: 1268
                                            }), Y(void 0)
                                        }
                                    }
                                })
                            },
                            onReport: ee,
                            onUnmasked: function() {
                                p.A.getCachedClientOpenChat(n).allowDisablingPrivateDetector && _(!0)
                            },
                            onWarnInappropriate: function(e) {
                                var t = (0, m.Bt)(o.getGender());
                                Y({
                                    message: m.Ay.get(26, {
                                        name: Ie.ko.for(o.getName(), t)
                                    }),
                                    yesAction: {
                                        text: m.Ay.get(25),
                                        onClick: function() {
                                            (0, l.sx)(332, {
                                                element: 253,
                                                parent_element: 1274
                                            }), e.isInappropriate = !1, e.isResentAfterInappropriateMark = !0, P(e), Y(void 0)
                                        }
                                    },
                                    noAction: {
                                        text: m.Ay.get(6),
                                        type: "destructive",
                                        onClick: function() {
                                            (0, l.sx)(332, {
                                                element: 113,
                                                parent_element: 1274
                                            }), p.A.removeChatMessageFromStore(n, e.id), Y(void 0)
                                        }
                                    }
                                })
                            },
                            onSelect: function(e) {
                                var t = V.findIndex((function(t) {
                                    return t.id === e.id
                                }));
                                q(t > -1 ? [].concat(V.slice(0, t), V.slice(t + 1)) : [].concat(V, [e]))
                            },
                            onClickMessage: function(e) {
                                if (e.target) {
                                    var t = e.target,
                                        n = "a" === ("string" == typeof t.nodeName ? t.nodeName.toLowerCase() : null) && !t.href;
                                    d && n && j()
                                }
                            },
                            onClickLike: function(e) {
                                !e.allowLike || e.isLiked || e.isYours() || ((0, l.sx)(446, {
                                    gesture: 10,
                                    element: 970,
                                    position: e.position
                                }), p.A.likeMessage(e))
                            },
                            onClickUnlike: function(e) {
                                p.A.likeMessage(e)
                            },
                            onClickReply: function(e) {
                                w(n, e), E(), $.current = s.A.setTimeout((function() {
                                    null == b || b.scrollBy(60, !0)
                                }), 100)
                            },
                            onClickReadReceiptsPromoLink: T,
                            scrollPosition: b,
                            oldScrollPosition: x,
                            onQuestionsGameStart: N,
                            onQuestionsGameAnswer: U,
                            isShowingOffensiveMessagesPrompt: C
                        }, t) : null, (0, S.jsx)(Io, {
                            otherUserId: n,
                            onCancel: function() {
                                K(!1), k(!1), Y(void 0), Z(!1), q([])
                            },
                            selectedMessages: V,
                            promo: L,
                            isSelectable: c,
                            isDeleted: o.getIsDeleted(!1),
                            isShowingModal: z,
                            isReportingContent: X,
                            blockUser: ne,
                            onReportContent: function() {
                                K(!1), k(!0)
                            },
                            onUserBlocked: M,
                            onUpdateChat: O,
                            onReportResponse: oe,
                            onSetIsReportingContent: Z
                        }), Q ? (0, S.jsx)(Mo, Do({}, Q)) : null]
                    })
                },
                Vo = function(e) {
                    var t = e.text,
                        n = e.isActive,
                        i = e.onClick;
                    return (0, S.jsx)(Ue.A, { in: n,
                        timeout: 150,
                        mountOnEnter: !0,
                        unmountOnExit: !0,
                        children: (0, S.jsx)("div", {
                            className: "chat-new-message-notification-container",
                            children: (0, S.jsxs)("button", {
                                className: "chat-new-message-notification",
                                "data-qa": "chat-new-message-notification",
                                onClick: i,
                                children: [(0, S.jsx)("span", {
                                    className: "chat-new-message-notification__text",
                                    children: (0, S.jsx)(un.P3, {
                                        dangerous: !0,
                                        tag: "span",
                                        children: t
                                    })
                                }), (0, S.jsx)("span", {
                                    className: "chat-new-message-notification__icon",
                                    children: (0, S.jsx)(cn.A, {
                                        name: "generic-chevron-up",
                                        size: "sm"
                                    })
                                })]
                            })
                        })
                    })
                },
                qo = (n(89463), n(80851));
            ! function(e) {
                e.RECORDING = "RECORDING", e.RECORDING_LOCKED = "RECORDING_LOCKED", e.PREVIEW = "PREVIEW"
            }(Lo || (Lo = {})),
            function(e) {
                e.MESSAGE = "MESSAGE", e.GIFT = "GIFT", e.GIF = "GIF", e.AUDIO_RECORDING = "AUDIO_RECORDING", e.AUDIO_RECORDING_LOCKED = "AUDIO_RECORDING_LOCKED", e.AUDIO_PREVIEW = "AUDIO_PREVIEW"
            }(Fo || (Fo = {}));
            var Ho = n(31731),
                Qo = n(51917),
                Yo = n(79760),
                Wo = function(e) {
                    var t = e.children,
                        n = e.title,
                        o = e.cost,
                        r = e.action,
                        s = e.onClickAction;
                    return (0, S.jsxs)(i.Fragment, {
                        children: [(0, S.jsx)(Qo.A, {
                            title: n,
                            cost: o,
                            action: r,
                            onClickAction: s
                        }), (0, S.jsx)(Ho.A, {
                            children: i.Children.map(t, (function(e) {
                                return (0, S.jsx)(Yo.A, {
                                    children: e
                                })
                            }))
                        })]
                    })
                },
                zo = n(72324),
                Ko = n(47460),
                Jo = n(90959),
                Xo = n(25275),
                Zo = function(e) {
                    var t = e.currentMode,
                        n = e.gifSearchText,
                        i = e.gifSearchInputPlaceholder,
                        o = e.gifInputRef,
                        r = e.touchDeltaX,
                        s = e.isAudioPreview,
                        a = e.isAudioRecording,
                        c = e.isAudioRecordingLocked,
                        l = e.isPanelOpen,
                        u = e.audioPreviewContainer,
                        d = e.hideExtraControlsButton,
                        p = e.messageText,
                        f = void 0 === p ? "" : p,
                        h = e.messageInputPlaceholder,
                        g = e.onCloseGifSearch,
                        v = e.onFocusGifSearchInput,
                        A = e.onChangeGifSearchText,
                        y = e.onBlurGifSearchInput,
                        b = e.onCancelRecording,
                        x = e.onClickExtraControls,
                        C = e.onCloseExtraControls,
                        _ = e.onClickMessageInput,
                        k = e.onFocusMessageInput,
                        j = e.onKeyPressMessageInput,
                        E = e.onChangeMessageText,
                        O = e.onBlurMessageInput,
                        T = e.messageInputRef;
                    if (t !== Fo.GIF || a || c) {
                        if (s) return (0, S.jsx)(zo.A, {
                            children: (0, S.jsx)("div", {
                                className: "chat-audio__preview",
                                children: u
                            })
                        });
                        if (a) return (0, S.jsxs)("div", {
                            className: "chat-audio-cancel__wrapper",
                            style: {
                                transform: "translate3d(-" + r + "px, 0, 0)"
                            },
                            children: [(0, S.jsx)("span", {
                                className: "chat-audio-cancel__icon",
                                children: (0, S.jsx)(cn.A, {
                                    name: "generic-chevron-left",
                                    size: "sm",
                                    color: "gray-80"
                                })
                            }), (0, S.jsx)("span", {
                                className: "chat-audio-cancel__text",
                                children: m.Ay.get(390)
                            })]
                        });
                        if (c) return (0, S.jsx)("button", {
                            className: "chat-audio-cancel__wrapper",
                            onClick: b,
                            type: "button",
                            children: m.Ay.get(394)
                        });
                        var P = null;
                        return l ? P = (0, S.jsx)(Xo.A, {
                            icon: "generic-close-circle-hollow",
                            onClick: C,
                            a11y: {
                                label: m.Ay.get(404),
                                role: "toggle",
                                ariaPressed: !0
                            }
                        }) : d || (P = (0, S.jsx)(Xo.A, {
                            icon: "chat-control-action-sticker",
                            onClick: x,
                            a11y: {
                                label: m.Ay.get(404),
                                role: "toggle",
                                ariaPressed: !1
                            }
                        })), (0, S.jsx)(zo.A, {
                            children: (0, S.jsx)(Ko.A, {
                                value: f,
                                placeholder: h,
                                extra: P,
                                onClick: _,
                                onFocus: k,
                                onKeyPress: j,
                                onChange: E,
                                onBlur: O,
                                innerRef: T
                            })
                        })
                    }
                    return (0, S.jsx)(zo.A, {
                        children: (0, S.jsx)(Jo.A, {
                            value: n,
                            extra: (0, S.jsx)(Xo.A, {
                                icon: "generic-close-circle-hollow",
                                onClick: g,
                                a11y: {
                                    label: m.Ay.get(472)
                                }
                            }),
                            onFocus: v,
                            onChange: A,
                            onBlur: y,
                            innerRef: o,
                            a11y: {
                                inputLabel: i
                            }
                        })
                    })
                },
                $o = n(35734),
                er = {
                    "data-qa": "messenger-chat-record-audio"
                },
                tr = {
                    "data-qa": "messenger-chat-send-circle"
                },
                nr = function(e) {
                    var t = e.messageText,
                        n = e.touchDeltaY,
                        i = e.isAudioSupported,
                        o = e.isSendButtonDisabled,
                        r = e.isAudioRecordingLocked,
                        s = e.isAudioRecording,
                        a = e.isAudioPreview,
                        c = e.onTouchRecordingStart,
                        l = e.onEndRecording,
                        u = e.onSendRecording,
                        d = t || !i ? (0, S.jsx)(Xo.A, {
                            icon: "chat-action-send-circle",
                            color: o ? "disabled" : "active",
                            dataQA: tr,
                            a11y: {
                                label: m.Ay.get(408)
                            },
                            isDisabled: o,
                            buttonAttrs: {
                                type: "submit"
                            }
                        }) : (0, S.jsxs)("div", {
                            onTouchStart: r ? void 0 : c,
                            onMouseDown: r ? void 0 : c,
                            onContextMenu: function(e) {
                                e.preventDefault()
                            },
                            children: [s || r ? (0, S.jsxs)("button", {
                                className: "chat-audio__lock",
                                style: {
                                    transform: "translate3d(0, -" + n + "px, 0)"
                                },
                                onClick: r ? l : void 0,
                                type: "button",
                                children: [s ? (0, S.jsxs)("div", {
                                    children: [(0, S.jsx)(cn.A, {
                                        name: "generic-lock",
                                        size: "sm",
                                        color: "gray-80",
                                        a11y: {
                                            label: "FIXME_LABEL"
                                        }
                                    }), (0, S.jsx)(Mn.A, {
                                        bottom: "sm"
                                    }), (0, S.jsx)(cn.A, {
                                        name: "generic-chevron-up",
                                        size: "sm",
                                        color: "gray-80"
                                    })]
                                }) : null, r ? (0, S.jsx)(cn.A, {
                                    name: "generic-stop",
                                    size: "sm",
                                    color: "gray-80",
                                    a11y: {
                                        label: m.Ay.get(394)
                                    }
                                }) : null]
                            }) : null, (0, S.jsx)("button", {
                                className: Me()("chat-audio__action", {
                                    "has-overlay": s || r
                                }),
                                onClick: a ? u : r ? l : void 0,
                                type: "button",
                                children: (0, S.jsx)(Xo.A, {
                                    icon: a || r ? "chat-action-send-circle" : "chat-control-action-audio",
                                    color: a || r ? "active" : s ? "custom" : "base",
                                    dataQA: er,
                                    colorCustomValue: s || a || r ? "#fff" : void 0,
                                    a11y: {
                                        label: a || r ? m.Ay.get(407) : m.Ay.get(406)
                                    }
                                })
                            })]
                        });
                    return (0, S.jsx)($o.A, {
                        children: d
                    })
                },
                ir = n(98845),
                or = n(77650),
                rr = function(e) {
                    var t = e.inputItems;
                    return null != t && t.length ? (0, S.jsx)(ir.A, {
                        children: t.map((function(e) {
                            switch (e.type) {
                                case Fo.GIF:
                                    return (0, S.jsx)(or.A, {
                                        icon: {
                                            name: "chat-control-action-gif"
                                        },
                                        isActive: e.isActive,
                                        onClick: e.onClick,
                                        a11y: {
                                            label: m.Ay.get(402)
                                        }
                                    }, e.type);
                                case Fo.GIFT:
                                    return (0, S.jsx)(or.A, {
                                        icon: {
                                            name: "chat-control-action-gift"
                                        },
                                        isActive: e.isActive,
                                        onClick: e.onClick,
                                        a11y: {
                                            label: m.Ay.get(403)
                                        }
                                    }, e.type);
                                default:
                                    return null
                            }
                        }))
                    }) : null
                },
                sr = n(91076),
                ar = n(64537),
                cr = n(22864),
                lr = n(80871),
                ur = n(73920),
                dr = n(60518),
                pr = {
                    "data-qa": "messenger-chat-control-switcher-multimedia"
                },
                fr = {
                    "data-qa": "messenger-chat-control-delete-audio"
                };

            function hr(e) {
                return e !== Fo.MESSAGE && e !== Fo.GIF
            }

            function gr(e) {
                return e !== Fo.MESSAGE
            }
            var mr = function(e) {
                var t = e.currentMode,
                    n = e.controlsRef,
                    o = e.messageInputRef,
                    r = e.messageInputPlaceholder,
                    s = e.messageText,
                    a = e.onClickMessageInput,
                    c = e.onFocusMessageInput,
                    l = e.onBlurMessageInput,
                    u = e.onKeyPressMessageInput,
                    d = e.onChangeMessageText,
                    p = e.onSubmitMessage,
                    f = e.inputSettingsItems,
                    h = e.questionsGameTooltipText,
                    g = e.isSendButtonDisabled,
                    v = e.showQuestionsGameButton,
                    A = e.showQuestionsGameTooltip,
                    y = e.hideExtraControlsButton,
                    b = e.isCameraButtonDisabled,
                    x = e.onClickCamera,
                    C = e.onClickQuestionsGameButton,
                    _ = e.onViewQuestionsGameTooltip,
                    k = e.onClickExtraControls,
                    j = e.onCloseExtraControls,
                    E = e.onCloseGifSearch,
                    O = e.gifSearchInputPlaceholder,
                    T = e.noGifsResults,
                    P = e.gifSearchText,
                    I = e.onScrollGifs,
                    w = e.gifInputRef,
                    R = e.onFocusGifSearchInput,
                    M = e.onBlurGifSearchInput,
                    N = e.onChangeGifSearchText,
                    U = e.gifs,
                    D = e.isGifsLoading,
                    B = e.giftSections,
                    L = e.isGiftsLoading,
                    F = e.onScrollGifts,
                    G = e.replyToMessage,
                    V = e.onClickCancelReply,
                    q = e.recordingTime,
                    H = e.onEndRecording,
                    Q = e.onCancelRecording,
                    Y = e.onDeleteRecording,
                    W = e.onSendRecording,
                    z = e.audioPreviewContainer,
                    K = e.isAudioRecording,
                    J = e.isAudioRecordingLocked,
                    X = e.isAudioPreview,
                    Z = e.isAudioSupported,
                    $ = e.onTouchRecordingStart,
                    ee = e.onTouchRecordingMove,
                    te = e.onTouchRecordingEnd,
                    ne = e.touchDeltaX,
                    ie = e.touchDeltaY,
                    oe = (0, i.useState)(!1),
                    re = oe[0],
                    se = oe[1],
                    ae = st(G);
                return (0, S.jsx)("div", {
                    className: "chat-v3",
                    ref: n,
                    onTouchEnd: te,
                    onTouchMove: ee,
                    onMouseUp: te,
                    onMouseMove: ee,
                    children: (0, S.jsxs)(ar.A, {
                        shadow: !1,
                        children: [t === Fo.GIF ? (0, S.jsx)(lr.A, {
                            results: U,
                            isLoading: D,
                            noResultsText: T,
                            onScroll: I
                        }) : null, ae ? (0, S.jsx)(dr.A, {
                            direction: "in",
                            title: ae.title,
                            description: ae.description,
                            media: ae.media,
                            onClickCancel: V,
                            a11y: {
                                cancelLabel: m.Ay.get(454)
                            }
                        }) : null, (0, S.jsx)("div", {
                            style: {
                                position: "relative",
                                zIndex: 1
                            },
                            children: (0, S.jsxs)(sr.A, {
                                onSubmit: p,
                                children: [K || J ? (0, S.jsxs)("div", {
                                    className: "chat-audio-timer__wrapper",
                                    "data-qa": "chat-audio-timer",
                                    children: [(0, S.jsx)("span", {
                                        className: "chat-audio-timer__dot"
                                    }), (0, S.jsx)("span", {
                                        children: q
                                    })]
                                }) : (0, S.jsx)($o.A, {
                                    children: X ? (0, S.jsx)(Xo.A, {
                                        icon: "generic-trash",
                                        dataQA: fr,
                                        onClick: Y,
                                        a11y: {
                                            label: "FIXME_LABEL"
                                        }
                                    }) : (0, S.jsx)(Xo.A, {
                                        icon: "chat-control-action-multimedia",
                                        color: b ? "disabled" : "base",
                                        dataQA: pr,
                                        onClick: x,
                                        a11y: {
                                            label: m.Ay.get(401)
                                        },
                                        isDisabled: b
                                    })
                                }), (0, S.jsx)(Zo, {
                                    currentMode: t,
                                    gifSearchText: P,
                                    gifSearchInputPlaceholder: O,
                                    gifInputRef: w,
                                    touchDeltaX: ne,
                                    isAudioPreview: X,
                                    isAudioRecording: K,
                                    isAudioRecordingLocked: J,
                                    isPanelOpen: hr(t),
                                    audioPreviewContainer: z,
                                    hideExtraControlsButton: !(null != f && f.length) || y,
                                    messageText: s,
                                    messageInputPlaceholder: r,
                                    onCloseGifSearch: E,
                                    onFocusGifSearchInput: R,
                                    onChangeGifSearchText: N,
                                    onBlurGifSearchInput: M,
                                    onCancelRecording: Q,
                                    onClickExtraControls: k,
                                    onCloseExtraControls: j,
                                    onClickMessageInput: a,
                                    onFocusMessageInput: c,
                                    onKeyPressMessageInput: u,
                                    onChangeMessageText: d,
                                    onBlurMessageInput: l,
                                    messageInputRef: o
                                }), !s && v ? (0, S.jsx)($o.A, {
                                    children: (0, S.jsxs)("div", {
                                        style: {
                                            position: "relative",
                                            width: "100%",
                                            height: "100%"
                                        },
                                        children: [(0, S.jsx)(Xo.A, {
                                            icon: "chat-control-action-questions-game",
                                            color: "active",
                                            onClick: C,
                                            a11y: {
                                                label: m.Ay.get(405)
                                            }
                                        }), (0, S.jsx)(qo.Ay, { in: A,
                                            timeout: 300,
                                            mountOnEnter: !0,
                                            unmountOnExit: !0,
                                            onEntered: _,
                                            onExited: re ? C : void 0,
                                            children: function(e) {
                                                return (0, S.jsx)(Ke.A, {
                                                    text: h,
                                                    placement: "top-end",
                                                    animationStatus: "entered" === e ? "visible" : "idle",
                                                    onClick: function() {
                                                        return se(!0)
                                                    }
                                                })
                                            }
                                        })]
                                    })
                                }) : null, (0, S.jsx)(nr, {
                                    messageText: s,
                                    touchDeltaY: ie,
                                    isAudioSupported: Z,
                                    isSendButtonDisabled: g,
                                    isAudioRecordingLocked: J,
                                    isAudioRecording: K,
                                    isAudioPreview: X,
                                    onTouchRecordingStart: $,
                                    onEndRecording: H,
                                    onSendRecording: W
                                })]
                            })
                        }), gr(t) ? (0, S.jsx)(rr, {
                            inputItems: f
                        }) : null, hr(t) && t === Fo.GIFT ? (0, S.jsx)(cr.A, {
                            isLoading: L,
                            children: (0, S.jsx)("div", {
                                className: "chat-drawer__wrapper",
                                onScroll: F,
                                children: B.map((function(e) {
                                    return (0, S.jsx)(Wo, {
                                        title: e.name,
                                        cost: e.cost,
                                        children: e.gifts.map((function(e) {
                                            return (0, S.jsx)(ur.A, {
                                                src: e.src,
                                                onClick: e.onClick,
                                                a11y: {
                                                    label: e.src ? (0, on.b)(e.src) : void 0
                                                }
                                            }, e.id)
                                        }))
                                    }, e.id)
                                }))
                            })
                        }) : null]
                    })
                })
            };

            function vr(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function Ar(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var yr, br = function(e) {
                var t = e.text,
                    n = e.actions;
                return (0, S.jsx)(_n.A, {
                    isDismissible: !1,
                    wrapperType: _n.T.ACTION_SHEET,
                    header: {
                        text: t
                    },
                    children: n.map((function(e) {
                        return (0, S.jsx)(Fn.A, function(e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var n = null != arguments[t] ? arguments[t] : {};
                                t % 2 ? vr(Object(n), !0).forEach((function(t) {
                                    Ar(e, t, n[t])
                                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : vr(Object(n)).forEach((function(t) {
                                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                                }))
                            }
                            return e
                        }({}, e))
                    }))
                })
            };

            function xr(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function Sr(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }! function(e) {
                e.MAX_LENGTH = "MAX_LENGTH", e.STOP_RECORDING = "STOP_RECORDING", e.HOLD_TO_RECORD = "HOLD_TO_RECORD"
            }(yr || (yr = {}));

            function Cr(e, t) {
                (0, l.sx)(20, {
                    alert_type: e,
                    action_type: t
                })
            }
            var _r, kr = function(e) {
                    var t = e.type,
                        n = e.onDismiss,
                        o = e.onCancelRecording;
                    return (0, i.useEffect)((function() {
                        var e;
                        switch (t) {
                            case yr.MAX_LENGTH:
                                e = 144;
                                break;
                            case yr.STOP_RECORDING:
                                e = 145
                        }
                        e && Cr(e, 12)
                    }), [t]), (0, S.jsx)(br, function(e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var n = null != arguments[t] ? arguments[t] : {};
                            t % 2 ? xr(Object(n), !0).forEach((function(t) {
                                Sr(e, t, n[t])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : xr(Object(n)).forEach((function(t) {
                                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                            }))
                        }
                        return e
                    }({}, function() {
                        switch (t) {
                            case yr.MAX_LENGTH:
                                return {
                                    text: m.Ay.get(389),
                                    actions: [{
                                        key: "chat_max_recording_dismiss",
                                        text: m.Ay.get(454),
                                        onClick: function() {
                                            Cr(144, 11), n()
                                        }
                                    }]
                                };
                            case yr.STOP_RECORDING:
                                return {
                                    text: m.Ay.get(433),
                                    actions: [{
                                        key: "chat_stop_recording",
                                        text: m.Ay.get(435),
                                        type: "destructive",
                                        onClick: function() {
                                            Cr(145, 2), n(), o()
                                        }
                                    }, {
                                        key: "chat_keep_recording",
                                        text: m.Ay.get(434),
                                        onClick: function() {
                                            Cr(145, 11), n()
                                        }
                                    }]
                                };
                            case yr.HOLD_TO_RECORD:
                                return {
                                    text: m.Ay.get(429),
                                    actions: [{
                                        key: "chat_max_recording_dismiss",
                                        text: m.Ay.get(454),
                                        onClick: n
                                    }]
                                }
                        }
                    }()))
                },
                jr = n(68507),
                Er = X.A.getLogger("ChatKeyboardHacks"),
                Or = Q.A.ios ? function() {
                    var e = null,
                        t = !1,
                        n = !0;
                    return {
                        onFocus: function() {
                            t || (n = !0)
                        },
                        onBlur: function() {
                            n = !1
                        },
                        onInput: function() {
                            setTimeout(this.scrollToBottom_, 10)
                        },
                        lockScrollPosition_: function() {
                            if (s.A.document.activeElement !== s.A.document.body) {
                                var e = (0, jr.A)().scrollHeight - i();
                                Q.A.ipad || s.A.scrollY === e || this.scrollToBottom_()
                            } else this.onBlur()
                        },
                        scrollToBottom_: function() {
                            var e = (0, jr.A)().scrollHeight;
                            s.A.scrollTo(0, e - i())
                        },
                        activateIosDeviceWakeHack: function() {
                            n && (t = !0, setTimeout((function() {
                                t = !1
                            }), 1e3), s.A.document.activeElement.blur())
                        }
                    };

                    function i() {
                        if (null !== e) return e;
                        var t = [
                                [812, 330],
                                [736, 360],
                                [667, 300],
                                [568, 210],
                                [480, 120],
                                [1024, 610],
                                [896, 415]
                            ],
                            n = s.A.screen.height,
                            i = t.find((function(e) {
                                return e[0] === n
                            }));
                        return i ? e = i[1] : (e = 0, Er.warn("Unknown iOS screen height: " + n)), e
                    }
                }() : Q.A.android && Q.A.chrome && Q.A.chromeVersion >= 60 ? {
                    onFocus: function() {
                        var e = (0, jr.A)().scrollHeight - s.A.innerHeight,
                            t = s.A.scrollY;
                        Math.abs(t - e) < 10 && setTimeout(Tr, 500)
                    },
                    onBlur: function() {},
                    onInput: function() {}
                } : {
                    onFocus: function() {},
                    onBlur: function() {},
                    onInput: function() {}
                };

            function Tr() {
                var e = (0, jr.A)();
                s.A.scrollTo(0, e.scrollHeight - s.A.innerHeight + 1)
            }
            var Pr = {
                    supportsAudio: (null == (_r = s.A.navigator.mediaDevices) ? void 0 : _r.getUserMedia) && s.A.MediaRecorder,
                    requestAccess: function() {
                        if (!Pr.supportsAudio) return Promise.reject(new Error("Audio recording not supported"));
                        return new Promise((function(e, t) {
                            var n = !1;
                            setTimeout((function() {
                                n || t(new Error("Audio recording permission timed out"))
                            }), Ir), s.A.navigator.mediaDevices.getUserMedia({
                                audio: !0
                            }).then((function(t) {
                                n = !0, e(t)
                            })).catch((function(e) {
                                n = !0, t(e)
                            }))
                        }))
                    }
                },
                Ir = 2e4;
            var wr = Pr;

            function Rr(e, t) {
                var n = function(e, t) {
                        for (var n = t.getChannelData(0), i = 10 * e, o = Math.floor(n.length / i), r = [], s = 0; s < i; s++) {
                            for (var a = o * s, c = 0, l = 0; l < o; l++) c += Math.abs(n[a + l]);
                            r.push(c / o)
                        }
                        return r
                    }(e, t),
                    i = function(e, t) {
                        for (var n = Math.max.apply(Math, t) / 7, i = t.map((function(e) {
                                return Math.round(e / n)
                            })), o = [], r = 0; r < e; r++) {
                            for (var s = 0, a = 0; a < 10; a++) s += Math.pow(i[10 * r + a], a);
                            o.push(s)
                        }
                        return o
                    }(e, n);
                return i
            }

            function Mr(e) {
                return ("0" + e).slice(-2)
            }

            function Nr(e, t) {
                var n = Math.round((Date.now() - t) / 100);
                (0, l.sx)(446, {
                    gesture: e,
                    element: 1197,
                    duration: n
                })
            }

            function Ur(e, t) {
                (0, l.sx)(332, {
                    element: e,
                    parent_element: t
                })
            }

            function Dr() {
                U.A.showNotification({
                    type: U.A.TYPES.ERROR
                })
            }
            var Br, Lr, Fr = ((Lr = s.A.AudioContext || s.A.webkitAudioContext) && (Br = new Lr), function() {
                return Br
            });

            function Gr(e) {
                return function(e) {
                    return void 0 !== e.touches
                }(e) ? {
                    x: e.touches[0].clientX,
                    y: e.touches[0].clientY
                } : {
                    x: e.pageX,
                    y: e.pageY
                }
            }

            function Vr(e, t, n) {
                return e ? Math.min((t || 0) - (n || 0), 80) : 0
            }
            var qr = n(98234);

            function Hr(e, t) {
                return Hr = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, Hr(e, t)
            }
            var Qr = [6, 3],
                Yr = X.A.getLogger("ChatonInputContainer"),
                Wr = 0,
                zr = 0,
                Kr = {
                    x: 0,
                    y: 0
                },
                Jr = (0, De.A)((function(e, t, n) {
                    (0, l.sx)(195, {
                        direction: e,
                        element: t,
                        position: n
                    })
                }), 350),
                Xr = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).controlsRef = (0, i.createRef)(), n.viewElementGifsTracked = !1, n.viewElementGiftsTracked = !1, n.audioCtx = void 0, n.supportsAudioRecording = void 0, n.messageInputRef = void 0, n.gifInputRef = void 0, n.recordingInterval = void 0, n.audioChunks = [], n.audioRecordingSettings = void 0, n.isCancellingRecord = void 0, n.recordingDelayPassed = !1, n.isAccidentalRecord = !1, n.recordingTimeout = void 0, n.mediaRecorder = void 0, n.touchStartTime = void 0, n.audioRef = void 0, n.screenName = 20, n.handleSendRecording = function() {
                            var e = n.props,
                                t = e.replyToMessage,
                                i = e.onUploadAudio;
                            if (n.state.recordedAudio) {
                                var o = n.state.recordedAudio,
                                    r = o.file,
                                    s = o.type,
                                    a = o.sampleRate,
                                    c = o.bitRate,
                                    l = o.isStereo,
                                    u = o.isVbr,
                                    d = o.duration,
                                    p = o.waveform,
                                    f = o.waveformSrv;
                                n.state.recordingMode === Lo.RECORDING_LOCKED ? Ur(253, 1200) : Ur(253, 1199), i({
                                    file: r,
                                    type: s,
                                    sample_rate_hz: a,
                                    bit_rate_kbps: c,
                                    audio_stereo: l,
                                    vbr_enable: u,
                                    duration: 1e3 * d,
                                    waveform: p,
                                    waveformSrv: f,
                                    replyToUid: null == t ? void 0 : t.id,
                                    repliedMessage: t
                                })
                            }
                        }, n.handleMediaRecorderStop = function() {
                            var e, t = new s.A.Blob(n.audioChunks, {
                                    type: "audio/mp4; codecs=aac"
                                }),
                                i = new s.A.FileReader;
                            i.onloadend = function() {
                                var o;
                                (e = i.result, t.size) ? null == (o = n.audioCtx) || o.decodeAudioData(e, (function(e) {
                                    var i, o = Rr((null == (i = n.audioRecordingSettings) ? void 0 : i.waveform_length) || 3, e),
                                        r = (0, F.qD)(o);
                                    e.duration >= 1 ? n.setState({
                                        recordedAudio: {
                                            file: t,
                                            type: 1,
                                            sampleRate: 22050,
                                            bitRate: 32e3,
                                            isStereo: !1,
                                            isVbr: !0,
                                            src: s.A.URL.createObjectURL(n.audioChunks[0]),
                                            waveformSrv: o,
                                            waveform: r,
                                            duration: Math.ceil(e.duration)
                                        }
                                    }) : n.handleCancelRecording(), n.audioChunks = []
                                })): n.handleCancelRecording()
                            }, i.readAsArrayBuffer(t)
                        }, n.getMediaRecorder = function(e) {
                            var t = new s.A.MediaRecorder(e);
                            return t.addEventListener("dataavailable", (function(e) {
                                n.audioChunks.push(e.data)
                            })), t.addEventListener("stop", (function() {
                                e.getTracks().forEach((function(e) {
                                    return e.stop()
                                })), n.isCancellingRecord || n.handleMediaRecorderStop(), n.isCancellingRecord = !1
                            })), t.addEventListener("start", (function() {
                                n.recordingInterval = s.A.setInterval((function() {
                                    var e, t = n.state.recordingTime + 1,
                                        i = ((null == (e = n.audioRecordingSettings) ? void 0 : e.max_recording_length_ms) || 1 / 0) / 1e3;
                                    n.setState({
                                        recordingTime: t
                                    }), t > i && (n.handleEndRecording(), n.setState({
                                        recordingWarning: yr.MAX_LENGTH
                                    }))
                                }), 1e3)
                            })), t
                        }, n.handleStartRecording = function() {
                            var e, t = (null == (e = n.audioRecordingSettings) ? void 0 : e.start_recording_delay_ms) || 1e3;
                            n.recordingDelayPassed = !1, n.isAccidentalRecord = !1, n.recordingTimeout = s.A.setTimeout((function() {
                                if (n.recordingDelayPassed = !0, !n.isAccidentalRecord && wr.supportsAudio) {
                                    var e = Date.now();
                                    wr.requestAccess().then((function(t) {
                                        n.audioChunks = [], n.setState({
                                            recordingMode: Lo.RECORDING,
                                            recordingTime: 0
                                        }), n.mediaRecorder = n.getMediaRecorder(t), n.mediaRecorder.start(), Date.now() - e > 1e3 && n.handleCancelRecording()
                                    })).catch((function(e) {
                                        n.handleCancelRecording(), Yr.error("Failed while requesting the audio access", {
                                            errMessage: e.message || "Unknown error message",
                                            errName: e.name || "Unknown error name",
                                            errCode: void 0 !== e.code ? e.code : -1
                                        })
                                    }))
                                }
                            }), t)
                        }, n.stopRecording = function() {
                            n.mediaRecorder && "inactive" !== n.mediaRecorder.state && "paused" !== n.mediaRecorder.state && n.mediaRecorder.stop(), n.recordingInterval && s.A.clearInterval(n.recordingInterval), n.recordingTimeout && s.A.clearTimeout(n.recordingTimeout)
                        }, n.handleCancelRecording = function(e) {
                            void 0 === e && (e = !0), e ? (n.isCancellingRecord = !0, n.stopRecording()) : Ur(106, 1199), n.setState({
                                isHoldingRecord: !1,
                                recordingMode: void 0,
                                recordingTime: 0,
                                recordedAudio: null
                            }), n.audioChunks = []
                        }, n.setAudioRecordingSettings = function() {
                            var e, t = B.A.getSettings();
                            n.audioRecordingSettings = null == t || null == (e = t.chat_settings) ? void 0 : e.audio_recording_settings
                        }, n.handleEndRecording = function() {
                            n.setState({
                                recordingMode: void 0,
                                isHoldingRecord: !1
                            }), n.stopRecording()
                        }, n.handleLockRecording = function() {
                            n.setState({
                                recordingMode: Lo.RECORDING_LOCKED
                            })
                        }, n.handleUserLeavingApp = function(e) {
                            if (n.state.recordingMode === Lo.RECORDING_LOCKED) return e.preventDefault(), e.returnValue = !1, ""
                        }, n.handleClickOutside = function(e) {
                            n.state.recordingMode === Lo.RECORDING_LOCKED && n.controlsRef.current && !n.controlsRef.current.contains(e.target) && n.setState({
                                recordingWarning: yr.STOP_RECORDING
                            }), n.props.showQuestionsGameTooltip && n.props.onClickQuestionsGameTooltip()
                        }, n.handleTouchRecordingStart = function(e) {
                            e.preventDefault();
                            var t = Gr(e);
                            n.touchStartTime = Date.now(), n.setState({
                                recordingTouchStartPosition: t,
                                recordingTouchEndPosition: t,
                                isHoldingRecord: !0
                            }), n.handleStartRecording()
                        }, n.handleTouchRecordingEnd = function(e) {
                            if (e.preventDefault(), Nr(29, n.touchStartTime), n.recordingDelayPassed) {
                                if (n.state.recordingMode === Lo.RECORDING || n.state.recordingMode === Lo.RECORDING_LOCKED) {
                                    n.handleEndRecording();
                                    var t = Kr;
                                    n.setState({
                                        recordingTouchStartPosition: t,
                                        recordingTouchEndPosition: t,
                                        isHoldingRecord: !1
                                    })
                                }
                            } else n.isAccidentalRecord = !0, n.setState({
                                recordingWarning: yr.HOLD_TO_RECORD
                            }), n.handleEndRecording()
                        }, n.handleTouchRecordingMove = function(e) {
                            e.preventDefault();
                            var t = Gr(e),
                                i = n.state.recordingTouchStartPosition;
                            t.y - i.y <= -60 ? (Nr(27, n.touchStartTime), n.handleLockRecording()) : t.x - i.x <= -100 && (Nr(26, n.touchStartTime), n.handleCancelRecording()), n.setState({
                                recordingTouchEndPosition: t
                            })
                        }, n.handleDismissRecordingWarning = function() {
                            n.setState({
                                recordingWarning: void 0
                            })
                        }, n.handleLockEndRecording = function() {
                            Ur(1199, 1200), n.handleEndRecording()
                        }, n.handleLockCancelRecording = function() {
                            Ur(113, 1200), n.handleCancelRecording()
                        }, n.isAudioPause = function() {
                            return !n.audioRef || n.audioRef.paused
                        }, n.handleClickPlayer = function() {
                            var e, t;
                            n.audioRef && n.isAudioPause() ? ((null == (t = n.audioRef) ? void 0 : t.currentTime) > 0 && (e = 742), e = 1134) : e = 741;
                            (0, l.sx)(332, {
                                element: e,
                                parent_element: 1199
                            })
                        }, n.handleFocusInput = function() {
                            var e;
                            null == (e = n.messageInputRef) || e.focus()
                        }, n.state = {
                            currentMode: Fo.MESSAGE,
                            messageText: E.A.getMessage(n.props.userId),
                            gifSearchText: "",
                            gifs: [],
                            isGifsLoading: !0,
                            giftSections: [],
                            isGiftsLoading: !1,
                            isHoldingRecord: !1,
                            recordingTime: 0,
                            recordedAudio: null,
                            recordingTouchStartPosition: Kr,
                            recordingTouchEndPosition: Kr
                        }, n.bindMethods(), n.audioCtx = Fr(), n.supportsAudioRecording = n.audioCtx && pe.A.supportsAudioRecording, n
                    }
                    var n, o;
                    o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, Hr(n, o);
                    var r = t.prototype;
                    return r.componentDidMount = function() {
                        this.setAudioRecordingSettings(), q.A.on(q.A.EVENTS.ONLINE, this.onOnline), E.A.on(E.q.MESSAGE_REMOVED, this.handleUnsentTextRemoved, this), s.A.addEventListener("beforeunload", this.handleUserLeavingApp), s.A.document.addEventListener("mousedown", this.handleClickOutside), p.A.on(p.A.EVENTS.INPUT_FOCUSED, this.handleFocusInput), this.props.isExtraControlsVisible && this.showExtraControls()
                    }, r.componentDidUpdate = function(e, t) {
                        if (t.currentMode !== this.state.currentMode) {
                            var n, i;
                            if (this.state.currentMode === Fo.MESSAGE && this.state.messageText) null == (n = this.messageInputRef) || n.focus();
                            if (this.state.currentMode === Fo.GIF) this.getGifs(), null == (i = this.gifInputRef) || i.focus()
                        }
                        var o;
                        (t.gifSearchText !== this.state.gifSearchText && this.getGifs(), this.state.recordedAudio && t.recordedAudio !== this.state.recordedAudio && this.handleSendRecording(), this.props.replyToMessage && this.props.replyToMessage !== e.replyToMessage) && (null == (o = this.messageInputRef) || o.focus());
                        this.props.isExtraControlsVisible !== e.isExtraControlsVisible && this.props.isExtraControlsVisible && this.showExtraControls()
                    }, r.componentWillUnmount = function() {
                        E.A.off(E.q.MESSAGE_REMOVED, this.handleUnsentTextRemoved, this), q.A.off(q.A.EVENTS.ONLINE, this.onOnline), this.recordingInterval && s.A.clearInterval(this.recordingInterval), s.A.removeEventListener("beforeunload", this.handleUserLeavingApp), s.A.document.removeEventListener("mousedown", this.handleClickOutside), p.A.off(p.A.EVENTS.INPUT_FOCUSED, this.handleFocusInput), this.stopRecording()
                    }, r.render = function() {
                        var e = this;
                        if (!this.isAllowSendChat()) return null;
                        var t, n, o, r = this.props,
                            s = r.replyToMessage,
                            a = r.showQuestionsGameButton,
                            c = r.onClickCancelReply,
                            l = this.state,
                            u = l.currentMode,
                            d = l.recordingMode,
                            p = l.recordedAudio,
                            f = l.recordingWarning,
                            h = l.messageText,
                            g = l.gifSearchText,
                            v = l.gifs,
                            A = l.isGifsLoading,
                            y = l.isGiftsLoading,
                            b = l.isHoldingRecord,
                            x = l.giftSections,
                            C = l.recordingTime,
                            _ = l.recordingTouchStartPosition,
                            k = l.recordingTouchEndPosition,
                            j = d === Lo.RECORDING,
                            E = d === Lo.RECORDING_LOCKED,
                            O = d === Lo.PREVIEW;
                        return d === Lo.PREVIEW && null != p && p.src && (t = (0, S.jsx)(qe.lN, {
                            onAudioRef: function(t) {
                                e.audioRef = t
                            },
                            id: "preview-recording",
                            src: p.src,
                            duration: p.duration,
                            onPlayError: Dr,
                            onClickContent: this.handleClickPlayer,
                            children: function(e) {
                                var t = e.percentage,
                                    n = e.playback,
                                    i = e.time,
                                    o = e.onClickContent;
                                return (0, S.jsx)(ot.A, {
                                    percentage: t,
                                    bars: p.waveform,
                                    playback: n,
                                    time: i,
                                    onClickContent: o,
                                    direction: "out",
                                    a11y: {
                                        contentLabel: Ge([m.Ay.get(387), "playing" === n ? m.Ay.get(629) : m.Ay.get(630)])
                                    }
                                })
                            }
                        })), (0, S.jsxs)(i.Fragment, {
                            children: [f ? (0, S.jsx)(kr, {
                                type: f,
                                onDismiss: this.handleDismissRecordingWarning,
                                onCancelRecording: this.handleCancelRecording
                            }) : null, (0, S.jsx)(mr, {
                                replyToMessage: s,
                                onClickCancelReply: c,
                                currentMode: u,
                                controlsRef: this.controlsRef,
                                messageInputRef: function(t) {
                                    e.messageInputRef = t
                                },
                                messageInputPlaceholder: m.Ay.get(444),
                                messageText: h,
                                inputSettingsItems: this.getInputSettingsItems(),
                                questionsGameTooltipText: this.props.questionsGameTooltipText,
                                isSendButtonDisabled: this.getIsSendButtonDisabled(),
                                showQuestionsGameButton: a,
                                showQuestionsGameTooltip: this.props.showQuestionsGameTooltip,
                                onClickMessageInput: Zr,
                                onFocusMessageInput: this.onFocusMessageInput,
                                onBlurMessageInput: this.onBlurMessageInput,
                                onKeyPressMessageInput: this.onKeyPressMessageInput,
                                onChangeMessageText: this.onChangeMessageText,
                                onSubmitMessage: this.onSubmitMessage,
                                isCameraButtonDisabled: this.getIsCameraButtonDisabled(),
                                onClickCamera: this.onClickCamera,
                                onClickQuestionsGameButton: this.props.onClickQuestionsGameButton,
                                onViewQuestionsGameTooltip: $r,
                                hideExtraControlsButton: this.getHideExtraControlsButton(),
                                onClickExtraControls: this.onClickExtraControls,
                                onCloseExtraControls: this.onCloseExtraControls,
                                onCloseGifSearch: this.onCloseGifSearch,
                                gifSearchInputPlaceholder: m.Ay.get(400),
                                noGifsResults: this.getNoGifsResultsText(),
                                gifSearchText: g,
                                gifs: v,
                                isGifsLoading: A,
                                onScrollGifs: this.onScrollGifs,
                                gifInputRef: function(t) {
                                    e.gifInputRef = t
                                },
                                onFocusGifSearchInput: this.onFocusGifSearchInput,
                                onBlurGifSearchInput: this.onBlurGifSearchInput,
                                onChangeGifSearchText: this.onChangeGifSearchText,
                                giftSections: x,
                                isGiftsLoading: y,
                                onScrollGifts: this.onScrollGifts,
                                recordingTime: (n = C, o = Mr(Math.floor(n / 60)), o + ":" + Mr(n - 60 * parseInt(o, 10))),
                                onEndRecording: this.handleLockEndRecording,
                                onCancelRecording: this.handleLockCancelRecording,
                                onDeleteRecording: function() {
                                    return e.handleCancelRecording(!1)
                                },
                                onSendRecording: this.handleSendRecording,
                                onTouchRecordingStart: O ? void 0 : this.handleTouchRecordingStart,
                                onTouchRecordingMove: j ? this.handleTouchRecordingMove : void 0,
                                onTouchRecordingEnd: b && !E ? this.handleTouchRecordingEnd : void 0,
                                touchDeltaX: Vr(j, _.x, k.x),
                                touchDeltaY: Vr(j, _.y, k.y),
                                audioPreviewContainer: t,
                                isAudioRecording: j,
                                isAudioRecordingLocked: E,
                                isAudioPreview: O,
                                isAudioSupported: wr.supportsAudio && this.supportsAudioRecording
                            })]
                        })
                    }, r.isAllowSendChat = function() {
                        var e = (this.props.inputFeatures || []).find((function(e) {
                            return 18 === e.feature
                        }));
                        return null == e ? void 0 : e.enabled
                    }, r.getInputSettingsItems = function() {
                        var e = this;
                        if (!this.props.inputSettingsItems) return [];
                        var t = [];
                        return Qr.forEach((function(n) {
                            var i, o = null == (i = e.props.inputSettingsItems) ? void 0 : i.find((function(e) {
                                return e.type === n
                            }));
                            void 0 !== o && t.push(o)
                        })), t.map((function(t) {
                            var n = {};
                            switch (t.type) {
                                case 3:
                                    n.type = Fo.GIF, n.onClick = e.onClickGifMode;
                                    break;
                                case 6:
                                    n.type = Fo.GIFT, n.onClick = e.onClickGiftMode, n.isDefault = !0
                            }
                            return n.isActive = e.state.currentMode === n.type, n
                        })).filter((function(e) {
                            return !!e
                        }))
                    }, r.getHeight = function() {
                        var e;
                        return (null == (e = this.controlsRef.current) ? void 0 : e.offsetHeight) || 0
                    }, r.showLoading = function() {
                        var e, t;
                        null == (e = (t = this.props).onShowLoading) || e.call(t)
                    }, r.hideLoading = function() {
                        var e, t;
                        null == (e = (t = this.props).onHideLoading) || e.call(t)
                    }, r.onMessageSent = function() {
                        var e;
                        this.resetInputState(), null == (e = this.messageInputRef) || e.focus()
                    }, r.resetInputState = function() {
                        this.setState({
                            currentMode: Fo.MESSAGE,
                            messageText: "",
                            gifSearchText: "",
                            gifs: []
                        })
                    }, r.handleUnsentTextRemoved = function(e) {
                        e === this.props.userId && "" !== this.state.messageText && this.resetInputState()
                    }, r.getHideExtraControlsButton = function() {
                        return Boolean(this.state.messageText)
                    }, r.getIsSendButtonDisabled = function() {
                        return this.state.currentMode !== Fo.MESSAGE || !this.state.messageText.trim()
                    }, r.onFocusMessageInput = function(e) {
                        var t, n;
                        this.onCloseExtraControls(), Or.onFocus(), null == (t = (n = this.props).onFocusInput) || t.call(n, e)
                    }, r.onBlurMessageInput = function(e) {
                        var t, n;
                        Or.onBlur(), null == (t = (n = this.props).onBlurInput) || t.call(n, e)
                    }, r.onKeyPressMessageInput = function(e) {
                        if (pe.A.isDesktop && "Enter" === (null == e ? void 0 : e.key) && (null == e || !e.shiftKey)) {
                            var t = e;
                            this.onSubmitMessage(t)
                        }
                    }, r.onChangeMessageText = function(e) {
                        var t = e.target.value;
                        E.A.saveMessage(this.props.userId, t), this.setState({
                            messageText: t
                        }), Or.onInput()
                    }, r.onSubmitMessage = function(e) {
                        this.getIsSendButtonDisabled() || (e.preventDefault(), this.props.onSendTextMessage(this.state.messageText.trim(), {
                            onMessageSent: this.onMessageSent
                        }), (0, l.sx)(332, {
                            element: 253
                        }))
                    }, r.showExtraControls = function() {
                        (0, l.sx)(332, {
                            element: 227
                        });
                        var e = this.getInputSettingsItems(),
                            t = (e || []).find((function(e) {
                                return null == e ? void 0 : e.isDefault
                            }));
                        if (t) null == t.onClick || t.onClick();
                        else {
                            var n = e[0];
                            null == n || null == n.onClick || n.onClick()
                        }
                    }, r.onClickExtraControls = function() {
                        this.showExtraControls()
                    }, r.onClickGifMode = function() {
                        this.setState({
                            currentMode: Fo.GIF
                        }), (0, l.sx)(332, {
                            element: 250,
                            parent_element: 252
                        }), this.viewElementGifsTracked || ((0, l.sx)(258, {
                            element: 358
                        }), this.viewElementGifsTracked = !0)
                    }, r.onClickGiftMode = function() {
                        this.setState({
                            currentMode: Fo.GIFT
                        }), 0 === this.state.giftSections.length && this.setState({
                            isGiftsLoading: !0
                        }), this.getGifsByCurrentUserId(), this.viewElementGiftsTracked || ((0, l.sx)(258, {
                            element: 32
                        }), this.viewElementGiftsTracked = !0)
                    }, r.onOnline = function() {
                        this.state.isGiftsLoading && this.getGifsByCurrentUserId()
                    }, r.getGifsByCurrentUserId = function() {
                        var e = this;
                        qr.A.getInstance().getGifts(this.props.userId).then((function(t) {
                            var n = t.sections || [];
                            e.setState({
                                isGiftsLoading: !1,
                                giftSections: n.map(e.giftSectionToState)
                            })
                        })).catch((function(t) {
                            e.setState({
                                isGiftsLoading: !q.A.isOnline()
                            }), (0, Z.A)(t) && Yr.error("Error retrieving the Gifts", t)
                        }))
                    }, r.giftSectionToState = function(e) {
                        return {
                            id: e.id,
                            name: e.name,
                            cost: m.Ay.get(486, {
                                num: e.credits_cost
                            }),
                            gifts: (e.gift_products || []).map(this.giftProductToState)
                        }
                    }, r.giftProductToState = function(e) {
                        var t = {
                            id: e.product_id,
                            src: e.thumb_url
                        };
                        return t.onClick = this.onClickGift.bind(this, t), t
                    }, r.onCloseExtraControls = function() {
                        this.setState({
                            currentMode: Fo.MESSAGE,
                            gifSearchText: "",
                            gifs: []
                        })
                    }, r.onCloseGifSearch = function() {
                        this.onCloseExtraControls(), this.setState({
                            gifSearchText: "",
                            gifs: []
                        })
                    }, r.onChangeGifSearchText = function(e) {
                        this.setState({
                            gifSearchText: (null == e ? void 0 : e.target.value) || "",
                            isGifsLoading: !0
                        })
                    }, r.getNoGifsResultsText = function() {
                        return this.state.gifSearchText ? m.Ay.get(399) : ""
                    }, r.onFocusGifSearchInput = function(e) {
                        var t, n;
                        null == (t = (n = this.props).onFocusInput) || t.call(n, e)
                    }, r.onBlurGifSearchInput = function(e) {
                        var t, n;
                        null == (t = (n = this.props).onBlurInput) || t.call(n, e)
                    }, r.getIsCameraButtonDisabled = function() {
                        if (this.props.hasReceivedMessage) return !1;
                        var e = (this.props.inputFeatures || []).find((function(e) {
                            return 70 === e.feature
                        }));
                        return e && !e.enabled
                    }, r.onClickCamera = function() {
                        var e, t;
                        this.props.needsPayment() || this.getIsCameraButtonDisabled() || (this.onCloseExtraControls(), null == (e = (t = this.props).onClickCamera) || e.call(t))
                    }, r.getGifs = function() {
                        var e = this;
                        this.setState({
                            isGifsLoading: !0
                        }), Wt().get({
                            query: this.state.gifSearchText
                        }).then((function(t) {
                            e.setState({
                                gifs: e.gifResponseToResults(t),
                                isGifsLoading: !1
                            })
                        }))
                    }, r.gifResponseToResults = function(e) {
                        var t = this;
                        return Array.isArray(e.results) ? e.results.map((function(e, n) {
                            var i;
                            return {
                                key: e.id,
                                src: null == (i = e.image) ? void 0 : i.preview,
                                onClick: t.onClickGifResult.bind(t, e, n)
                            }
                        })) : []
                    }, r.onClickGifResult = function(e, t) {
                        if (!this.props.needsPayment()) {
                            var n = this.props,
                                i = n.context,
                                o = n.onSelectGif,
                                r = n.streamId,
                                s = n.userId,
                                a = this.props.replyToMessage,
                                c = new F.Ay({
                                    context: i,
                                    gif: e,
                                    message: e.url,
                                    messageType: 36,
                                    streamId: r,
                                    toPersonId: s,
                                    replyToUid: null == a ? void 0 : a.id,
                                    repliedMessage: a
                                }, null, {
                                    isReplyFeatureAllowed: p.A.isReplyFeatureAllowed(s)
                                });
                            Wt().cacheGif(e), o(c), (0, l.sx)(332, {
                                element: 250,
                                parent_element: 358,
                                position: t
                            })
                        }
                    }, r.onClickGift = function(e) {
                        var t = this.props,
                            n = t.context,
                            i = t.onSendGift,
                            o = t.streamId,
                            r = t.userId;
                        a.A.navigate(c.x.SEND_GIFT, {
                            back: a.A.getUrl(),
                            context: n,
                            giftProductId: e.id,
                            onSendMessage: i,
                            streamId: o,
                            userId: r
                        }), (0, l.sx)(332, {
                            element: 350,
                            parent_element: 32
                        })
                    }, r.onScrollGifs = function(e) {
                        var t, n = function(e, t) {
                            var n = e.target,
                                i = n.scrollWidth - n.offsetWidth;
                            return Math.max(1, Math.round(n.scrollLeft * t / i))
                        }(e, (null == (t = this.state.gifs) ? void 0 : t.length) || 0);
                        Wr < n && Jr(6, 358, Wr = n)
                    }, r.onScrollGifts = function(e) {
                        var t = function(e, t) {
                            var n = e.target,
                                i = n.scrollHeight - n.offsetHeight;
                            return Math.max(1, Math.round(n.scrollTop * t / i))
                        }(e, this.state.giftSections.reduce((function(e, t) {
                            return t.gifts.length + e
                        }), 0));
                        zr < t && Jr(5, 32, zr = t)
                    }, r.bindMethods = function() {
                        this.getGifs = (0, De.A)(this.getGifs.bind(this), 666), this.onSubmitMessage = this.onSubmitMessage.bind(this), this.onMessageSent = this.onMessageSent.bind(this), this.onChangeMessageText = this.onChangeMessageText.bind(this), this.onFocusMessageInput = this.onFocusMessageInput.bind(this), this.onBlurMessageInput = this.onBlurMessageInput.bind(this), this.onClickCamera = this.onClickCamera.bind(this), this.onChangeGifSearchText = this.onChangeGifSearchText.bind(this), this.onFocusGifSearchInput = this.onFocusGifSearchInput.bind(this), this.onBlurGifSearchInput = this.onBlurGifSearchInput.bind(this), this.onKeyPressMessageInput = this.onKeyPressMessageInput.bind(this), this.onClickExtraControls = this.onClickExtraControls.bind(this), this.onCloseExtraControls = this.onCloseExtraControls.bind(this), this.onCloseGifSearch = this.onCloseGifSearch.bind(this), this.onClickGifMode = this.onClickGifMode.bind(this), this.onClickGiftMode = this.onClickGiftMode.bind(this), this.giftSectionToState = this.giftSectionToState.bind(this), this.giftProductToState = this.giftProductToState.bind(this), this.onScrollGifs = this.onScrollGifs.bind(this), this.onScrollGifts = this.onScrollGifts.bind(this), this.onOnline = this.onOnline.bind(this)
                    }, t
                }(i.Component);

            function Zr() {
                (0, l.sx)(332, {
                    element: 251
                })
            }

            function $r() {
                (0, l.sx)(258, {
                    element: 1729
                })
            }
            var es = Xr,
                ts = n(3208),
                ns = n(41025),
                is = n(30922);

            function os(e) {
                var t = p.A.getBlockingFeature(e);
                return p.A.isContactsForCreditsFeature(t) && null !== t.getCreditsForProduct(null)
            }
            var rs = function(e) {
                    var t = e.context,
                        n = e.streamId,
                        i = e.otherUserId,
                        o = e.inputFeatures,
                        r = e.inputSettingsItems,
                        s = e.replyToMessage,
                        c = e.hasReceivedMessage,
                        u = e.scroller,
                        d = e.chatUser,
                        f = e.notificationPermissionController,
                        h = e.activationPlace,
                        g = e.questionsGameTooltipText,
                        v = e.showQuestionsGameTooltip,
                        A = e.showQuestionsGameButton,
                        y = e.onHideAddBanner,
                        b = e.onBlurInput,
                        x = e.onFocusInput,
                        C = e.onUpdateInput,
                        _ = e.onClickCamera,
                        k = e.onClickQuestionsGameButton,
                        j = e.onClickQuestionsGameTooltip,
                        E = e.onToggleLoading,
                        O = e.onToggleTopup,
                        T = e.onSendMessage,
                        P = e.onChatRefresh,
                        I = e.onUploadAudio,
                        w = e.isExtraControlsVisible,
                        M = function(e, t) {
                            var n = p.A.getBlockingFeature(i),
                                o = function(e, t) {
                                    var n = p.A.getCachedClientOpenChat(t).initialScreen,
                                        i = null == e ? void 0 : e.getPaymentAmount(),
                                        o = i || n && parseInt(n.message.match(/[0-9]+/g), 10) || 0;
                                    return o
                                }(n, i);
                            ns.A.navigateToPayment({
                                back: a.A.getUrl(),
                                newNavigation: t,
                                userId: i,
                                productType: n.getCreditsForProduct(),
                                hotPanelData: {
                                    activationPlace: h
                                },
                                callback: e,
                                cost: o
                            })
                        },
                        N = function() {
                            if (os(i)) return M(), !0;
                            if (p.A.getMaxUnansweredMessages(i) <= 0) {
                                var e = null == d ? void 0 : d.getName(),
                                    t = 2 === (null == d ? void 0 : d.getGender()) ? m.Ay.get(426, {
                                        str: e
                                    }) : m.Ay.get(427, {
                                        str: e
                                    });
                                return U.A.showNotification({
                                    type: U.A.TYPES.ERROR,
                                    text: t
                                }), !0
                            }
                            return !1
                        },
                        D = function(e, t) {
                            var n = p.A.isReplyFeatureAllowed(i),
                                o = new F.Ay({
                                    isNew: !0,
                                    message: e,
                                    messageType: 1,
                                    replyToUid: null == s ? void 0 : s.id
                                }, d, {
                                    isReplyFeatureAllowed: n
                                });
                            T(o), t && t(), p.A.getMaxUnansweredMessages(i) <= 0 && (0, l.sx)(49, {
                                screen_option: 16
                            }), f.obtainPermission(m.Ay.get(448, {
                                str: null == d ? void 0 : d.getName()
                            }))
                        },
                        B = function(e) {
                            if (os(i)) P().then((function() {
                                os(i) || D(e)
                            })).catch((function() {}));
                            else {
                                var t = a.A.getLocation().parameters;
                                "3" === (null == t ? void 0 : t.paymentFlow) ? P().then((function() {
                                    p.A.deleteInitialChatScreen(i), D(e)
                                })).catch((function() {})): D(e)
                            }
                        };
                    return (0, S.jsx)(es, {
                        context: t,
                        streamId: n,
                        onShowLoading: function() {
                            return E(!0)
                        },
                        onHideLoading: function() {
                            return E(!1)
                        },
                        needsPayment: N,
                        questionsGameTooltipText: g,
                        showQuestionsGameTooltip: v,
                        showQuestionsGameButton: A,
                        onFocusInput: function(e) {
                            os(i) ? y(e) : (N() && (e.preventDefault(), e.target.blur(), e.stopPropagation()), y(e), x())
                        },
                        onBlurInput: b,
                        onSendGift: function() {
                            null == u || u.reset()
                        },
                        onSendTextMessage: function(e, t) {
                            if (os(i)) {
                                ts.A.generate(), B(e);
                                var n = de.A.encodeRoute(a.A.getUrl(), {
                                    paymentFlow: pe.A.isTWA() ? "3" : "1"
                                });
                                return O(!0), void M((function(t) {
                                    var n = t.success,
                                        i = t.purchaseReceipt;
                                    n && i ? (E(!0), is.A.subscribeToNotificationShow(i, (function() {
                                        O(!1), E(!1), B(e)
                                    }))) : O(!1)
                                }), n)
                            }
                            D(e, null == t ? void 0 : t.onMessageSent)
                        },
                        onClickCamera: _,
                        onClickQuestionsGameButton: k,
                        onClickQuestionsGameTooltip: j,
                        onSelectGif: T,
                        userId: i,
                        inputFeatures: o,
                        inputSettingsItems: r,
                        hasReceivedMessage: c,
                        replyToMessage: s,
                        onClickCancelReply: function() {
                            (0, l.sx)(332, {
                                element: 113,
                                parent_element: 289
                            }), R(i), C()
                        },
                        onUploadAudio: I,
                        isExtraControlsVisible: w
                    })
                },
                ss = n(53010),
                as = n(69110),
                cs = function(e) {
                    var t = e.isEnabled,
                        n = (0, i.useState)(""),
                        o = n[0],
                        r = n[1];
                    return (0, i.useEffect)((function() {
                        if (t && ss.A.isEnabled()) {
                            var e = ss.A.create(ss.A.placements.CHAT);
                            r(e), ss.A.render(), (0, l.sx)(475, {
                                activation_place: 11,
                                ad_aggregator: 12,
                                element: 442,
                                ad_placement: 2,
                                ad_unit_id: e
                            }), (0, l.sx)(258, {
                                element: 442
                            })
                        }
                        return function() {
                            ss.A.destroy(ss.A.placements.CHAT)
                        }
                    }), [t]), t && o.length ? (0, S.jsx)(as.A, {
                        adSlot: o,
                        dataQa: "chat"
                    }) : null
                },
                ls = n(55105),
                us = (n(9868), function(e) {
                    var t = e.isActive,
                        n = e.minSize,
                        o = void 0 === n ? 40 : n,
                        r = e.maxSize,
                        s = void 0 === r ? 65 : r,
                        a = e.maxDelay,
                        c = void 0 === a ? 600 : a,
                        l = e.icon,
                        u = function(e, t) {
                            return (e + Math.random() * (t - e)).toFixed(2)
                        },
                        d = (0, S.jsx)("div", {
                            className: "chat-balloon-icons-item",
                            children: (0, S.jsx)(cn.A, {
                                name: l.name,
                                color: l.color
                            })
                        });
                    return t ? (0, S.jsx)("div", {
                        className: "chat-balloon-icons-container",
                        children: function(e, t) {
                            for (var n = [], r = 0; r < e; r++) {
                                var a = (5 + 95 / e * r).toFixed(2),
                                    l = u(o, s),
                                    d = {
                                        left: a + "%",
                                        width: l + "px",
                                        height: l + "px",
                                        animationDuration: u(900, 1100) + "ms",
                                        animationDelay: u(0, c) + "ms"
                                    };
                                n.push((0, i.cloneElement)(t, {
                                    style: d,
                                    key: "chat_balloon_icons_" + r
                                }))
                            }
                            return n
                        }(12, d)
                    }) : null
                }),
                ds = n(47901),
                ps = n(87184),
                fs = n(11734),
                hs = n(15376),
                gs = n(73969),
                ms = function(e) {
                    var t = e.navigation,
                        n = e.miniProfile,
                        i = e.messages,
                        o = e.chatNudgePromo,
                        r = e.newMessageNotification,
                        s = e.input,
                        a = e.ads,
                        c = e.initialScreen,
                        l = e.scrollingContainerRef,
                        u = e.isHidingMessages,
                        d = e.isShowingCrushAnimation,
                        p = e.isShowingC4CUnlockAnimation,
                        f = e.isLoading,
                        h = e.isOnboarding,
                        g = e.onDismissOnboarding,
                        m = e.giftPushMessage;
                    return (0, S.jsxs)(ds.A, {
                        children: [(0, S.jsx)(hs.A, {
                            children: t
                        }), (0, S.jsxs)(ps.A, {
                            align: "stretch",
                            children: [f ? (0, S.jsx)(ls.A, {}) : null, (0, S.jsxs)("div", {
                                className: "chat-content",
                                ref: l,
                                children: [n, u ? null : i, c, (0, S.jsx)(Ue.A, {
                                    appear: !0,
                                    in: h,
                                    timeout: 300,
                                    mountOnEnter: !0,
                                    unmountOnExit: !0,
                                    children: (0, S.jsx)("button", {
                                        className: "chat-content-fader",
                                        onClick: g,
                                        "aria-label": (0, gs.m)("Skip onboarding")
                                    })
                                })]
                            })]
                        }), m ? (0, S.jsx)(ps.A, {
                            hpadded: !0,
                            vpadded: !0,
                            children: m
                        }) : null, (0, S.jsx)(fs.A, {
                            children: (0, S.jsxs)("div", {
                                className: "chat-footer",
                                children: [u ? null : r, o, s, a]
                            })
                        }), (0, S.jsx)(us, {
                            isActive: d || p,
                            icon: {
                                name: d ? "badge-feature-crush" : "badge-feature-premium-lock-opened"
                            }
                        })]
                    })
                },
                vs = (n(94490), function(e) {
                    var t = e.gallery,
                        n = e.userInfo,
                        i = e.chatBaloon,
                        o = e.scrollingContainerRef,
                        r = e.sourceOfMessage;
                    return (0, S.jsxs)("div", {
                        className: "mini-profile",
                        children: [t || n ? (0, S.jsxs)("div", {
                            ref: o,
                            className: "mini-profile__scroller js-scroller-element",
                            children: [t ? (0, S.jsx)("div", {
                                className: "mini-profile__gallery",
                                children: t
                            }) : null, n ? (0, S.jsx)("div", {
                                className: "mini-profile__user-info",
                                children: n
                            }) : null]
                        }) : null, r ? (0, S.jsx)("div", {
                            className: "mini-profile__source-of-message",
                            children: r
                        }) : null, i]
                    })
                }),
                As = function(e) {
                    var t = e.text,
                        n = e.iconName,
                        i = e.isLight,
                        o = t.split(/\[\/|\]/g),
                        r = o[0],
                        s = o[2],
                        a = i ? "white" : "gray-80",
                        c = Me()("source-of-message", {
                            "source-of-message--light": i
                        });
                    return (0, S.jsx)("div", {
                        className: c,
                        children: (0, S.jsx)(un.P2, {
                            color: a,
                            children: (0, S.jsxs)("span", {
                                className: "source-of-message__text",
                                children: [(0, S.jsx)("span", {
                                    className: "source-of-message__text-start",
                                    children: r
                                }), (0, S.jsxs)("span", {
                                    className: "source-of-message__text-end",
                                    children: [(0, S.jsx)("span", {
                                        className: "source-of-message__text-icon",
                                        children: (0, S.jsx)(cn.A, {
                                            name: n,
                                            size: "md"
                                        })
                                    }), s]
                                })]
                            })
                        })
                    })
                },
                ys = {
                    trackViewElement: function(e) {
                        (0, l.sx)(258, {
                            element: 661
                        }), (0, l.sx)(56, {
                            activation_place: 11,
                            encrypted_user_id: e,
                            profile_type: 3
                        })
                    },
                    trackPhotoClick: function() {
                        (0, l.sx)(332, {
                            element: 21,
                            parent_element: 661
                        })
                    },
                    trackOtherProfileClick: function() {
                        (0, l.sx)(332, {
                            element: 219,
                            parent_element: 661
                        })
                    },
                    trackScrollElement: function(e, t, n, i) {
                        n.current && (0, l.sx)(195, {
                            element: 661,
                            direction: 6,
                            position: i ? t.length - 1 - e : e
                        })
                    }
                },
                bs = ys,
                xs = n(1064),
                Ss = n(842),
                Cs = n(53787),
                _s = n(31528),
                ks = n(31247),
                js = function(e) {
                    var t = e.age,
                        n = e.name,
                        o = e.description,
                        r = e.moodStatus,
                        s = e.status,
                        a = e.hasShownHeadingIcon,
                        c = e.gender,
                        l = e.isCrush,
                        u = e.isLike,
                        d = e.isMatch,
                        p = e.isVerified,
                        f = e.onClick,
                        h = (0, i.useState)(a),
                        g = h[0],
                        v = h[1];
                    (0, i.useEffect)((function() {
                        a || setTimeout((function() {
                            v(!0)
                        }), 1500)
                    }), [a]);
                    var A = l ? "badge-feature-crush" : d ? "badge-feature-match" : u ? "badge-feature-liked-you" : void 0,
                        y = [t ? m.Ay.get(811, {
                            name: n,
                            age: t
                        }) : n, "online" === (null == s ? void 0 : s.online) ? m.Ay.get(848) : void 0, p ? m.Ay.get(807) : void 0, l ? m.Ay.get(803, {
                            other_user: Ie.ko.for("other_user", c)
                        }) : void 0, d ? m.Ay.get(806) : void 0, u ? m.Ay.get(805, {
                            other_user: Ie.ko.for("other_user", c)
                        }) : void 0];
                    return (0, S.jsxs)("div", {
                        className: "mini-profile-user-info js-profile",
                        "data-qa": "mini-profile-user-info",
                        children: [(0, S.jsxs)("div", {
                            className: "mini-profile-user-info__content",
                            children: [(0, S.jsxs)("span", {
                                className: "mini-profile-user-info__heading",
                                "data-qa": "mini-profile-user-info__heading",
                                children: [A ? (0, S.jsx)("div", {
                                    className: Me()({
                                        "mini-profile-user-info__heading-icon": !0,
                                        "show-icon": g
                                    }),
                                    children: (0, S.jsx)(cn.A, {
                                        name: A
                                    })
                                }) : null, p ? (0, S.jsx)("div", {
                                    className: "mini-profile-user-info__heading-icon show-icon",
                                    children: (0, S.jsx)(cn.A, {
                                        name: "badge-feature-verification"
                                    })
                                }) : null, (0, S.jsx)("div", {
                                    className: "mini-profile-user-info__heading-info",
                                    children: (0, S.jsx)(un.Sz, {
                                        color: "black",
                                        children: (0, S.jsx)(Cs.A, {
                                            name: n,
                                            age: t,
                                            status: s,
                                            a11y: {
                                                label: (0, ks.b)(y)
                                            }
                                        })
                                    })
                                })]
                            }), r ? (0, S.jsx)("span", {
                                className: "mini-profile-user-info__mood-status",
                                children: (0, S.jsx)(_s.A, {
                                    text: r.name,
                                    emoji: r.emoji
                                })
                            }) : null, null == o ? void 0 : o.map((function(e, t) {
                                return e ? (0, S.jsxs)("span", {
                                    className: "mini-profile-user-info__description",
                                    children: [(0, S.jsx)(un.P2, {
                                        color: "gray-80",
                                        ellipsis: !0,
                                        a11y: {
                                            ariaHidden: !0
                                        },
                                        dataQA: {
                                            "data-qa": "mini-profile-user-info__description"
                                        },
                                        children: e.value
                                    }), (0, S.jsx)(Yn.A, {
                                        children: (0, ks.b)([e.label, e.value], ": ")
                                    })]
                                }, "description-" + t) : null
                            }))]
                        }), (0, S.jsx)("div", {
                            className: "mini-profile-user-info__chevron",
                            children: (0, S.jsx)(Ss.A, {
                                onClick: f,
                                dataQA: {
                                    "data-qa": "mini-profile-user-info-open"
                                },
                                children: (0, S.jsx)(cn.A, {
                                    name: "generic-chevron-right",
                                    size: "sm",
                                    color: "gray-30",
                                    supportsRtl: !0,
                                    a11y: {
                                        label: m.Ay.get(808),
                                        role: "text"
                                    }
                                })
                            })
                        })]
                    })
                },
                Es = n(38462),
                Os = function(e) {
                    return (0, S.jsx)("div", {
                        className: "mini-profile-gallery",
                        children: i.Children.map(e.children, (function(e, t) {
                            return (0, S.jsx)("div", {
                                className: "mini-profile-gallery__photo",
                                children: e
                            }, "mini-profile-gallery-photo-" + t)
                        }))
                    })
                },
                Ts = n(48628),
                Ps = n(24162),
                Is = function(e) {
                    var t = e.src,
                        n = e.centerPercentages,
                        i = e.onClick,
                        o = e.onOpenProfile,
                        r = e.isLoading,
                        s = e.isProfilePhoto,
                        a = e.hasOpenProfileOverlay,
                        c = e.a11y,
                        l = Me()("mini-profile-gallery-photo", {
                            "is-profile-photo": s
                        }),
                        u = (0, S.jsx)(Ts.Ay, {
                            src: t,
                            positionX: null == n ? void 0 : n.x,
                            positionY: null == n ? void 0 : n.y,
                            hasPreload: !0,
                            a11y: c
                        });
                    return (0, S.jsx)("div", {
                        className: l,
                        children: (0, S.jsx)(ji.Ay, {
                            onClick: a ? o : i,
                            isLoading: r,
                            children: r ? null : a ? (0, S.jsx)(Ps.A, {
                                overlayContent: (0, S.jsx)(un.P3, {
                                    align: "center",
                                    color: "white",
                                    children: m.Ay.get(808)
                                }),
                                children: u
                            }) : u
                        })
                    })
                },
                ws = n(42616),
                Rs = 75,
                Ms = 100,
                Ns = function(e) {
                    var t = e.userId,
                        n = e.photos,
                        i = e.onPhotoViewed,
                        o = e.onOpenProfile,
                        r = e.name;
                    return (0, S.jsx)(Es.A, {
                        userId: t,
                        photos: n,
                        showToolbar: !1,
                        a11y: {
                            modalLabel: m.Ay.get(715, {
                                name: r
                            })
                        },
                        children: function(e) {
                            return (0, S.jsx)(Os, {
                                children: n.map((function(t, s) {
                                    if (!t.large_url) return null;
                                    var a = y.A.getImageUrlForSize(t.large_url, Rs, Ms),
                                        c = Boolean(n.length >= 6 && 0 === s),
                                        l = (0, ws.h)({
                                            userName: r,
                                            position: s + 1,
                                            total: n.length,
                                            isProfilePhoto: t.is_profile_photo,
                                            type: t.video ? "video" : "photo"
                                        });
                                    return (0, S.jsx)(Je.A, {
                                        onIntersect: function() {
                                            return i(s)
                                        },
                                        children: (0, S.jsx)(Is, {
                                            src: a,
                                            onClick: function() {
                                                bs.trackPhotoClick(), e(s)
                                            },
                                            onOpenProfile: o,
                                            isProfilePhoto: t.is_profile_photo,
                                            hasOpenProfileOverlay: c,
                                            a11y: {
                                                label: l
                                            }
                                        })
                                    }, t.id)
                                }))
                            })
                        }
                    })
                };

            function Us(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function Ds(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Us(Object(n), !0).forEach((function(t) {
                        Bs(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Us(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function Bs(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function Ls(e) {
                return e ? (0, S.jsx)(As, {
                    text: e.text,
                    iconName: xs.UH[e.id]
                }) : null
            }

            function Fs(e) {
                return 2 === e.getTheirVote()
            }

            function Gs(e) {
                var t = !1,
                    n = e.getVerifiedInformation();
                if (n) {
                    var i = n.getMethods([]).find((function(e) {
                        return 5 === e.getType()
                    }));
                    t = (null == i ? void 0 : i.getIsConnected()) && i.getIsConfirmed()
                }
                return t
            }

            function Vs(e) {
                if ((0, se.El)() && e.hasMoodStatus()) return {
                    emoji: e.getMoodStatus().getEmoji(),
                    name: e.getMoodStatus().getName()
                }
            }

            function qs(e, t) {
                var n = e.getProfileFields();
                if (n) {
                    var i = n.find((function(e) {
                        return e.getType() === t && !e.getRequiredAction()
                    }));
                    return null == i ? void 0 : i.getDisplayValue()
                }
            }

            function Hs(e) {
                var t = e.getPlacesInCommon([]).length;
                return t ? 1 === t ? m.Ay.get(478) : m.Ay.get(477, {
                    num: t
                }) : null
            }

            function Qs(e) {
                var t = e.getPhotoCount(),
                    n = e.getVideoCount();
                if (!t && !n) return null;
                var i = null;
                1 === t ? i = m.Ay.get(943) : t && (i = m.Ay.get(942, {
                    num: t
                }));
                var o = n ? m.Ay.get(1022, {
                    num: n
                }) : null;
                return t && n ? i + ", " + o : i || o
            }

            function Ys(e) {
                var t = e.getInterestsInCommon();
                return t ? 1 === t ? m.Ay.get(941) : m.Ay.get(940, {
                    num: t
                }) : null
            }

            function Ws() {
                return "ltr" === s.A.document.getElementsByTagName("html")[0].getAttribute("dir")
            }
            var zs, Ks, Js = function(e) {
                    var t = e.user,
                        n = e.onProfileClick,
                        o = e.sourceOfMessage,
                        r = (0, i.createRef)(),
                        a = (0, i.useRef)(0),
                        c = (0, i.useRef)(!1),
                        l = function(e) {
                            var t, n = e.albums || [],
                                i = n.find((function(e) {
                                    return 2 === e.album_type
                                }));
                            return (null == i || null == (t = i.photos) ? void 0 : t.reverse()) || []
                        }(t.toJSON()),
                        u = function(e) {
                            var t = e.getOnlineStatus(4),
                                n = function(e) {
                                    var t = [qs(e, 12), qs(e, 10), Qs(e), Ys(e), Hs(e), qs(e, 1)];
                                    return t.filter((function(e) {
                                        return e
                                    }))
                                }(e);
                            return {
                                id: e.getUserId(),
                                name: e.getName(),
                                age: e.getAge(),
                                gender: (0, m.Bt)(e.getGender()),
                                status: {
                                    online: (0, A.fI)(t)
                                },
                                description: [{
                                    label: m.Ay.get(892),
                                    value: n[0]
                                }, {
                                    label: m.Ay.get(795),
                                    value: n[1]
                                }, {
                                    value: e.getDisplayMessage()
                                }],
                                moodStatus: Vs(e),
                                isLike: Fs(e),
                                isMatch: e.getIsMatch(),
                                isUnread: e.getIsUnread(),
                                isCrush: e.getIsCrush(),
                                isVerified: Gs(e)
                            }
                        }(t),
                        d = function() {
                            n(t)
                        },
                        p = function() {
                            bs.trackOtherProfileClick(), d()
                        },
                        f = function(e) {
                            return function() {
                                bs.trackScrollElement(e, l, c, Ws())
                            }
                        };
                    (0, i.useEffect)((function() {
                        bs.trackViewElement(t.getUserId())
                    }), []), (0, i.useEffect)((function() {
                        if (r.current) {
                            var e = 0;
                            Array.from(r.current.children).forEach((function(t) {
                                e += null == t ? void 0 : t.offsetWidth
                            }));
                            var t = Ws() ? e : -1 * e;
                            r.current.scrollLeft = t
                        }
                    }), [t, r]), (0, i.useEffect)((function() {
                        var e = function() {
                                s.A.clearTimeout(a.current), c.current = !0, a.current = s.A.setTimeout((function() {
                                    c.current = !1
                                }), 100)
                            },
                            t = r.current;
                        return null == t || t.addEventListener("scroll", e),
                            function() {
                                null == t || t.removeEventListener("scroll", e), s.A.clearTimeout(a.current)
                            }
                    }), [r, c]);
                    return (0, S.jsx)(vs, {
                        userInfo: (0, S.jsx)(js, Ds(Ds({}, u), {}, {
                            onClick: p
                        })),
                        gallery: (0, S.jsx)(Ns, {
                            photos: l,
                            onPhotoViewed: f,
                            onOpenProfile: d,
                            userId: u.id,
                            name: u.name
                        }),
                        chatBaloon: (0, S.jsx)(us, {
                            isActive: u.isUnread && (u.isLike || u.isMatch),
                            minSize: 18,
                            maxSize: 40,
                            maxDelay: 1200,
                            icon: {
                                name: "generic-heart",
                                color: "generic-red"
                            }
                        }),
                        sourceOfMessage: Ls(o),
                        scrollingContainerRef: r
                    })
                },
                Xs = n(47294),
                Zs = n(96506),
                $s = n(32483);

            function ea(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function ta(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? ea(Object(n), !0).forEach((function(t) {
                        na(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : ea(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function na(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }! function(e) {
                e.ADD_PHOTO = "ADD_PHOTO", e.LIMIT_REACHED = "LIMIT_REACHED", e.SEARCH_CONDITIONS = "SEARCH_CONDITIONS", e.VERY_POPULAR = "VERY_POPULAR", e.NEWBIE = "NEWBIE"
            }(Ks || (Ks = {}));
            var ia = ((zs = {})[Ks.ADD_PHOTO] = {}, zs[Ks.LIMIT_REACHED] = {}, zs[Ks.SEARCH_CONDITIONS] = {
                    icon: "generic-chat"
                }, zs[Ks.VERY_POPULAR] = {
                    icon: "generic-chat"
                }, zs[Ks.NEWBIE] = {
                    icon: "generic-chat"
                }, zs),
                oa = function(e) {
                    var t = e.variant,
                        n = e.type,
                        i = e.header,
                        o = e.text,
                        r = e.action,
                        s = e.cost,
                        a = e.hasMessages,
                        c = e.isFake;
                    return (0, S.jsx)("div", {
                        className: Me()("initial-chat-blocker", "qa-blocker", {
                            "initial-chat-blocker--fixed": a && !c,
                            "initial-chat-blocker initial-chat-blocker--fake": c
                        }),
                        children: (0, S.jsxs)(co.A, {
                            children: [t === Ks.ADD_PHOTO ? (0, S.jsx)(lo.A, {
                                children: (0, S.jsx)(Hn.A, {
                                    size: "sm",
                                    icon: {
                                        name: "badge-camera"
                                    },
                                    badge: {
                                        position: "tr",
                                        mark: {
                                            text: "!",
                                            styling: "notification"
                                        }
                                    }
                                })
                            }) : null, t !== Ks.ADD_PHOTO && i ? (0, S.jsx)(uo.A, {
                                text: i
                            }) : null, (0, S.jsx)(po.A, {
                                text: o
                            }), (0, S.jsx)(fo.A, {
                                children: (0, S.jsx)(go.A, ta({
                                    text: r.text,
                                    onClick: r.onClick,
                                    dataQA: n ? {
                                        "data-promo-type": String(n)
                                    } : void 0
                                }, t ? ia[t] : {}))
                            }), s ? (0, S.jsx)(Zs.A, {
                                children: (0, S.jsx)($s.A, {
                                    children: s
                                })
                            }) : null]
                        })
                    })
                },
                ra = n(47667),
                sa = n(8323);

            function aa(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function ca(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? aa(Object(n), !0).forEach((function(t) {
                        la(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : aa(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function la(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function ua(e) {
                var t = e.invitation,
                    n = e.match,
                    i = e.onSendSmile,
                    o = e.onSendGiftDirect;
                if (!t) return null;
                var r = t.gifts,
                    s = t.message,
                    a = t.subtitle,
                    c = t.smile;
                return c ? (0, S.jsxs)(co.A, {
                    isCompact: !0,
                    children: [(0, S.jsx)(po.A, {
                        text: c.subtitle
                    }), (0, S.jsx)(fo.A, {
                        children: (0, S.jsx)(go.A, {
                            icon: "generic-smiley",
                            text: c.button,
                            onClick: i
                        })
                    })]
                }) : r && r.length > 0 || s || a ? (0, S.jsxs)(co.A, {
                    isCompact: !0,
                    children: [a ? (0, S.jsx)(uo.A, {
                        text: n ? m.Ay.get(590) : a,
                        tag: "h2"
                    }) : null, s ? (0, S.jsx)(po.A, {
                        text: s
                    }) : null, null != r && r.length ? (0, S.jsx)(ho.A, {
                        children: (0, S.jsx)("div", {
                            className: "initial-chat-screen__gifts",
                            children: r.map((function(e, t) {
                                return (0, S.jsx)("div", {
                                    className: "initial-chat-screen__gift",
                                    children: (0, S.jsx)("button", {
                                        className: "gift",
                                        onClick: function() {
                                            return o(e.product_id.toString(), t)
                                        },
                                        children: (0, S.jsx)("div", {
                                            className: "gift__image",
                                            children: (0, S.jsx)("img", {
                                                src: e.thumb_url,
                                                alt: ""
                                            })
                                        })
                                    })
                                }, e.product_id)
                            }))
                        })
                    }) : null]
                }) : void 0
            }

            function da(e) {
                var t = e.blocker,
                    n = e.simpleText,
                    i = e.subtitle,
                    o = e.verificationButton,
                    r = e.hasMessages,
                    s = e.isFake;
                return t && !t.external ? (0, S.jsx)(oa, ca(ca({}, t), {}, {
                    header: i,
                    hasMessages: r,
                    isFake: s
                })) : t && n && !s ? (0, S.jsx)(Mn.A, {
                    top: "sm",
                    bottom: "sm",
                    children: (0, S.jsxs)(co.A, {
                        children: [n.header ? (0, S.jsx)(uo.A, {
                            text: n.header
                        }) : null, (0, S.jsx)(po.A, {
                            text: n.text
                        }), (0, S.jsx)(fo.A, {
                            children: (0, S.jsx)("div", {
                                className: "qa-blocker",
                                children: o
                            })
                        })]
                    })
                }) : null
            }
            var pa = function(e) {
                    var t = e.blocker,
                        n = e.invitation,
                        o = e.match,
                        r = e.simpleText,
                        s = e.subtitle,
                        a = e.textMessage,
                        c = e.bozo,
                        l = e.giftMessage,
                        u = e.verificationButton,
                        d = e.hasMessages,
                        p = e.dataQA,
                        f = e.onDismiss,
                        h = e.onOpenGift,
                        g = e.onSendSmile,
                        v = e.onBlockUser,
                        A = e.onSendGiftDirect;
                    return (0, S.jsxs)(i.Fragment, {
                        children: [da({
                            blocker: t,
                            simpleText: r,
                            subtitle: s,
                            verificationButton: u,
                            hasMessages: d,
                            isFake: !0
                        }), (0, S.jsxs)(ds.A, {
                            dataQA: p,
                            children: [a || l ? (0, S.jsxs)(ps.A, {
                                hpadded: !0,
                                align: "center",
                                children: [a ? (0, S.jsx)("div", {
                                    className: "initial-chat-screen__message",
                                    children: (0, S.jsx)("div", {
                                        className: "chat-message-initial-standalone",
                                        children: (0, S.jsxs)("div", {
                                            className: "chat-message-initial-standalone__container",
                                            children: [(0, S.jsx)("svg", {
                                                viewBox: "0 0 21 31",
                                                className: "chat-message-initial-standalone__tail",
                                                children: (0, S.jsx)("path", {
                                                    fill: "currentColor",
                                                    d: "M0,2.83203336 C0,0.139254197 1.79044819,-0.803582444 4.0117599,0.734932499 L21,12.501251 L21,31 L0,31 L0,2.83203336 Z"
                                                })
                                            }), (0, S.jsx)("div", {
                                                className: "chat-message-initial-standalone__text qa-text-message",
                                                dangerouslySetInnerHTML: {
                                                    __html: a
                                                }
                                            })]
                                        })
                                    })
                                }) : null, l ? (0, S.jsx)("div", {
                                    className: "initial-chat-screen__gift-message",
                                    children: (0, S.jsx)(ra.A, {
                                        media: (0, S.jsx)("div", {
                                            className: "gift",
                                            children: (0, S.jsxs)("div", {
                                                className: "gift__image",
                                                children: [(0, S.jsx)("div", {
                                                    className: "gift__image-loader",
                                                    children: (0, S.jsx)(cn.A, {
                                                        name: "generic-gift-wrap",
                                                        size: "stretch"
                                                    })
                                                }), (0, S.jsx)("img", {
                                                    src: l.image,
                                                    className: "js-image",
                                                    alt: ""
                                                })]
                                            })
                                        }),
                                        content: (0, S.jsxs)(i.Fragment, {
                                            children: [l.text ? (0, S.jsx)("div", {
                                                className: "initial-chat-screen__gift-message-text",
                                                children: (0, S.jsx)(un.P2, {
                                                    children: l.text
                                                })
                                            }) : null, (0, S.jsx)("div", {
                                                className: "initial-chat-screen__gift-message-action",
                                                children: (0, S.jsx)(Ss.A, {
                                                    onClick: h,
                                                    children: (0, S.jsx)("span", {
                                                        className: "initial-chat-screen__gift-message-action-link",
                                                        children: (0, S.jsx)(un.P2, {
                                                            children: m.Ay.get(593)
                                                        })
                                                    })
                                                })
                                            })]
                                        }),
                                        color: "white",
                                        hasBorder: !0
                                    })
                                }) : null]
                            }) : null, (0, S.jsxs)(fs.A, {
                                vpadded: !0,
                                hpadded: !0,
                                children: [null != t && t.external || !r ? null : (0, S.jsx)(Mn.A, {
                                    top: "sm",
                                    bottom: "sm",
                                    children: (0, S.jsxs)(co.A, {
                                        children: [(0, S.jsx)(uo.A, {
                                            text: r.header
                                        }), (0, S.jsx)(po.A, {
                                            text: (0, S.jsx)("span", {
                                                className: "qa-simple-text",
                                                children: r.text
                                            })
                                        })]
                                    })
                                }), ua({
                                    invitation: n,
                                    match: o,
                                    onSendSmile: g,
                                    onSendGiftDirect: A
                                }), da({
                                    blocker: t,
                                    simpleText: r,
                                    subtitle: s,
                                    verificationButton: u,
                                    hasMessages: d,
                                    isFake: !1
                                }), c ? (0, S.jsx)(Mn.A, {
                                    top: "sm",
                                    bottom: "sm",
                                    children: (0, S.jsx)("div", {
                                        className: "qa-bozo",
                                        children: (0, S.jsxs)(sa.A, {
                                            children: [(0, S.jsx)(go.A, {
                                                text: m.Ay.get(395),
                                                onClick: f,
                                                dataQA: {
                                                    "data-qa": "chat-reply"
                                                }
                                            }), (0, S.jsx)(go.A, {
                                                semantic: "tertiary",
                                                text: m.Ay.get(374),
                                                onClick: v,
                                                dataQA: {
                                                    "data-qa": "chat-skip"
                                                }
                                            })]
                                        })
                                    })
                                }) : null, l ? (0, S.jsx)(Mn.A, {
                                    top: "sm",
                                    bottom: "sm",
                                    children: (0, S.jsx)("div", {
                                        className: "qa-open-gift",
                                        children: (0, S.jsxs)(sa.A, {
                                            children: [(0, S.jsx)(go.A, {
                                                text: m.Ay.get(395),
                                                onClick: f,
                                                dataQA: {
                                                    "data-qa": "chat-reply"
                                                }
                                            }), (0, S.jsx)(go.A, {
                                                semantic: "tertiary",
                                                text: m.Ay.get(374),
                                                onClick: v,
                                                dataQA: {
                                                    "data-qa": "chat-skip"
                                                }
                                            })]
                                        })
                                    })
                                }) : null]
                            })]
                        })]
                    })
                },
                fa = n(65507),
                ha = n(74026);

            function ga(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function ma(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? ga(Object(n), !0).forEach((function(t) {
                        va(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : ga(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function va(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var Aa = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.mediaIcon,
                        o = e.hint,
                        r = e.primaryButton,
                        s = e.secondaryButton,
                        a = e.betweenButtonsText,
                        c = e.customButtons,
                        l = e.onClickClose,
                        u = r || s || o || c || l ? (0, S.jsxs)(sa.A, {
                            spacing: "compact",
                            children: [r ? (0, S.jsx)(go.A, ma(ma({
                                size: "small"
                            }, r), {}, {
                                dataQA: {
                                    "data-qa": "chat-nudge-primary-button"
                                },
                                semantic: a ? "secondary" : "primary"
                            })) : null, a ? (0, S.jsx)(ha.A, {
                                text: a
                            }) : null, s ? (0, S.jsx)(go.A, ma(ma({
                                size: "small"
                            }, s), {}, {
                                semantic: s.semantic || "secondary",
                                dataQA: {
                                    "data-qa": "chat-nudge-secondary-button"
                                }
                            })) : null, c, l ? (0, S.jsx)(go.A, {
                                size: "small",
                                semantic: "tertiary",
                                text: m.Ay.get(67),
                                onClick: l,
                                dataQA: {
                                    "data-qa": "chat-nudge-close"
                                }
                            }) : null]
                        }) : void 0;
                    return (0, S.jsx)(fa.A, {
                        title: t,
                        text: n,
                        media: i ? (0, S.jsx)("div", {
                            style: {
                                width: 48,
                                height: 48
                            },
                            children: (0, S.jsx)(cn.A, {
                                name: i
                            })
                        }) : void 0,
                        action: u,
                        hint: o
                    })
                },
                ya = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.primaryButton,
                        o = e.secondaryButton,
                        r = e.betweenButtonsText,
                        s = e.isPremiumPlus,
                        a = e.dataQA;
                    return (0, S.jsx)(ds.A, {
                        dataQA: a,
                        children: (0, S.jsx)(ps.A, {
                            align: "bottom",
                            children: (0, S.jsx)(Mn.A, {
                                left: "gap",
                                right: "gap",
                                bottom: "gap",
                                children: (0, S.jsx)("div", {
                                    "data-qa": "chat-initial-contacts-for-credits",
                                    children: (0, S.jsx)(Aa, {
                                        title: t,
                                        text: n,
                                        primaryButton: {
                                            text: i.text,
                                            isLoading: i.isLoading,
                                            onClick: i.onClick,
                                            icon: s ? "generic-chat" : "generic-lock"
                                        },
                                        secondaryButton: o ? {
                                            text: o.text,
                                            semantic: s ? "primary" : void 0,
                                            icon: s ? "generic-premium-plus" : void 0,
                                            isLoading: o.isLoading,
                                            onClick: o.onClick
                                        } : void 0,
                                        betweenButtonsText: r
                                    })
                                })
                            })
                        })
                    })
                },
                ba = n(1765),
                xa = function(e) {
                    var t = e.message,
                        n = e.isProcessing,
                        i = e.onClick;
                    return (0, S.jsx)("div", {
                        className: "verification-block-simple",
                        children: n ? (0, S.jsxs)("div", {
                            className: "verification-block-loader",
                            children: [(0, S.jsx)("div", {
                                className: "verification-block-loader__icon",
                                children: (0, S.jsx)("div", {
                                    className: "icon-spinning-arrows-animated",
                                    children: (0, S.jsx)(cn.A, {
                                        name: "generic-spinning-arrows",
                                        size: "md"
                                    })
                                })
                            }), (0, S.jsx)("div", {
                                className: "verification-block-loader__text js-verification-loader-text",
                                children: t
                            })]
                        }) : (0, S.jsx)("div", {
                            className: "verification-block-button",
                            children: (0, S.jsx)(go.A, {
                                icon: "generic-verification-hollow",
                                text: t,
                                onClick: i
                            })
                        })
                    })
                };

            function Sa() {
                ba.A.verifyByPhoto(), (0, l.sx)(332, {
                    element: 31,
                    position: 1
                })
            }
            var Ca = function(e) {
                    var t = e.method,
                        n = e.onRefresh,
                        o = e.onSuccess,
                        r = (0, i.useState)(t.message),
                        a = r[0],
                        c = r[1],
                        l = (0, i.useRef)(),
                        u = (0, i.useRef)(t.secondsToWait);
                    return (0, i.useEffect)((function() {
                        return ba.A.on(ba.A.ACTIONS.SUCCESS, o),
                            function() {
                                ba.A.off(ba.A.ACTIONS.SUCCESS, o)
                            }
                    }), [o]), (0, i.useEffect)((function() {
                        t.isProcessing && (c(t.message + " " + u.current), l.current || (l.current = s.A.setInterval((function() {
                            u.current = u.current - 1, c(t.message + " " + u.current), u.current <= 0 && (c(t.message), u.current = t.secondsToWait, n())
                        }), 1e3)))
                    }), [t, l, n]), (0, i.useEffect)((function() {
                        return function() {
                            l.current && s.A.clearInterval(l.current)
                        }
                    }), []), (0, S.jsx)(xa, {
                        message: a,
                        isProcessing: t.isProcessing,
                        onClick: Sa
                    })
                },
                _a = n(26935),
                ka = n(63826),
                ja = n(37225),
                Ea = n(18826),
                Oa = n(96956);

            function Ta(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function Pa(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Ta(Object(n), !0).forEach((function(t) {
                        Ia(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Ta(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function Ia(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var wa = "EMOJI",
                Ra = "ANIMATED_EMOJI",
                Ma = (0, De.A)((function(e) {
                    (0, l.sx)(138, {
                        banner_id: e.promo_block_type,
                        position_id: e.promo_block_position,
                        context: 89
                    })
                }), 1e3),
                Na = function(e) {
                    var t, n = e.openChatData,
                        o = e.otherUserId,
                        r = e.clientSource,
                        s = e.log,
                        d = e.messages,
                        f = e.streamId,
                        h = e.chatUser,
                        v = e.onDismiss,
                        A = e.onChatRefresh,
                        y = e.onSendMessage,
                        b = e.onUserBlocked,
                        x = function(e, t) {
                            (0, l.sx)(332, {
                                element: 350,
                                parent_element: 32,
                                position: t
                            }), a.A.navigate(c.x.SEND_GIFT, {
                                userId: o,
                                back: a.A.getUrl(),
                                context: r,
                                giftProductId: parseInt(e, 10),
                                streamId: f
                            })
                        },
                        C = (0, i.useState)(),
                        _ = C[0],
                        k = C[1],
                        j = (0, i.useState)(!1),
                        E = j[0],
                        O = j[1],
                        T = (0, i.useState)(!1),
                        P = T[0],
                        I = T[1],
                        w = function() {
                            (0, l.sx)(332, {
                                element: 1302
                            });
                            var e = new F.Ay({
                                messageType: 22
                            }, h);
                            y(e)
                        },
                        R = function() {
                            var e = (0, Be.A)(d, {
                                messageType: 10
                            });
                            if (null != e && e.gift) {
                                var t = e.gift;
                                t.setIsBoxed(!1), a.A.navigate(c.x.GIFT, {
                                    purchasedGift: t.toJSON(),
                                    fromChat: !0,
                                    back: a.A.getUrl()
                                })
                            }
                        },
                        M = function(e, t) {
                            ! function(e, t) {
                                (0, l.sx)(139, {
                                    banner_id: e.promo_block_type,
                                    position_id: e.promo_block_position,
                                    context: 89,
                                    call_to_action_type: t
                                })
                            }(e, t.type), (1 === t.type ? O : I)(!0), 9 === (null == t ? void 0 : t.action) ? _a.A.purchase({
                                back: a.A.getUrl(),
                                cost: null == e ? void 0 : e.payment_amount,
                                hotPanelData: {
                                    activationPlace: 11,
                                    promoBlockType: null == e ? void 0 : e.promo_block_type
                                },
                                productType: null == e ? void 0 : e.ok_payment_product_type,
                                userId: o,
                                success: function() {
                                    p.A.invalidate(o), A()
                                }
                            }) : 4 === (null == t ? void 0 : t.action) && (47 === t.product_type || 1 === e.ok_payment_product_type ? ns.A.navigateToPayment({
                                back: a.A.getUrl(),
                                hotPanelData: {
                                    activationPlace: 11,
                                    promoBlockType: null == e ? void 0 : e.promo_block_type
                                },
                                productToActivate: null == e ? void 0 : e.ok_payment_product_type,
                                productType: null == t ? void 0 : t.product_type,
                                promoBlockType: null == e ? void 0 : e.promo_block_type,
                                userId: o
                            }) : 46 === (null == e ? void 0 : e.ok_payment_product_type) && A({
                                allowConsumeChatUnblocker: !0
                            }))
                        },
                        N = function(e) {
                            var t, i, u = p.A.getBlockingFeature(o);
                            if (ts.A.generate(), !u && p.A.getMaxUnansweredMessages(o) <= 0) "initial" === (t = "blocker") ? i = 2 : "blocker" === t && (i = 10), i && (0, l.sx)(100, {
                                encrypted_user_id: o,
                                gift_button: i,
                                message_first: !d || 0 === d.length
                            }), a.A.navigate(c.x.GIFT_STORE, {
                                context: r,
                                streamId: f,
                                id: o,
                                back: a.A.getUrl()
                            });
                            else {
                                if (u) {
                                    var h = u.getFeature(),
                                        g = u.getRequiredAction(),
                                        m = u.getProductType(),
                                        v = null;
                                    if (2 === g) v = 126;
                                    else if (4 === g || 9 === g) {
                                        var A = p.A.getInitialChatScreen(o),
                                            y = [13, 15].includes(A.type);
                                        3 === m ? v = 360 : A && 1 === m && y && (v = 304)
                                    }
                                    v && (0, l.sx)(332, {
                                        element: v
                                    });
                                    var b = (new Oa.A).setBack(a.A.getUrl()).setAction(g).setCost(u.getPaymentAmount()).setFeature(h).setProductType(u.getProductType()).setPromoBlockType(e).setHotPanelData({
                                        activationPlace: 93,
                                        feature: h
                                    });
                                    return ja.A.handleAction(b).then((function(e) {
                                        e instanceof ge.DYM ? is.A.subscribeToNotificationShow(e.toJSON(), (function() {
                                            p.A.invalidate(o)
                                        })) : e && p.A.invalidate(o)
                                    })).catch((function(e) {
                                        (0, Z.A)(e) && s.error("Error trying to buy blocking feature on chat.", {
                                            error: e,
                                            feature: h
                                        })
                                    }))
                                }
                                try {
                                    var x = Ea.A.save(o),
                                        S = {
                                            isInitialVisible: !(null == n || !n.initialScreen),
                                            isBlocking: null == n ? void 0 : n.isChatBlocked,
                                            isInitialScreen: !(null == n || !n.initialScreen),
                                            promoBlockType: e
                                        };
                                    s.error("Unexpected application chat state:", {
                                        clientOpenChat: x,
                                        extraStuff: S
                                    }), Ea.A.save()
                                } catch (e) {
                                    s.error("PARSE_ERROR: Unexpected application chat state:", {
                                        error: e,
                                        theirId: o
                                    })
                                }
                            }
                        },
                        U = function() {
                            var e;
                            e = 52, (0, l.sx)(332, {
                                element: e
                            }), p.A.deleteInitialChatScreen(o), v()
                        },
                        D = function() {
                            g.A.getInstance().addUserToFolder({
                                uid: o,
                                folder: 9,
                                context: 89
                            }).then(b)
                        };
                    (0, i.useEffect)((function() {
                        var e = p.A.getBlockingFeature(o);
                        13 === (null == e ? void 0 : e.getRequiredAction()) && Xs.A.getInstance().get({
                            context: r
                        }).then((function(e) {
                            var t = e[0],
                                n = (t instanceof ge.yGP ? t.getVerifiedSource() : t).getMethods([]).find((function(e) {
                                    return 5 === e.getType()
                                }));
                            k(ba.A.createContextForMethod(n, !1, !1))
                        }))
                    }), [o, r]);
                    var B, L, G, V, q, H, Q, Y, W, z, K = _ ? (0, S.jsx)(Ca, {
                            method: _,
                            onRefresh: A,
                            onSuccess: function() {
                                return k(void 0)
                            }
                        }) : null,
                        J = d.find((function(e) {
                            return e.isYours()
                        })) ? void 0 : {
                            "data-qa": "chat-first-time"
                        };
                    return 19 === n.initialScreenType && null != (t = n.initialScreen) && t.promo ? (0, S.jsx)(ya, Pa(Pa({}, (q = n.initialScreen, H = null == q ? void 0 : q.promo.toJSON(), Q = null == H || null == (B = H.buttons) ? void 0 : B.find((function(e) {
                        return 1 === e.type
                    })), Y = null == H || null == (L = H.buttons) ? void 0 : L.find((function(e) {
                        return 2 === e.type
                    })), W = null == H || null == (G = H.extra_texts) ? void 0 : G.find((function(e) {
                        return 11 === e.type
                    })), z = {
                        title: H.header,
                        text: H.mssg,
                        primaryButton: {
                            text: null == Q ? void 0 : Q.text,
                            isLoading: E,
                            onClick: function() {
                                return M(H, Q)
                            }
                        },
                        secondaryButton: Y ? {
                            text: null == Y ? void 0 : Y.text,
                            isLoading: P,
                            onClick: function() {
                                M(H, Y)
                            }
                        } : void 0,
                        betweenButtonsText: null == W ? void 0 : W.text,
                        badgeText: null == H || null == (V = H.pictures) || null == (V = V[0]) ? void 0 : V.badge_text,
                        isPremiumPlus: (0, ka.X)()
                    }, H && Ma(H), z)), {}, {
                        dataQA: J
                    })) : (0, S.jsx)(pa, Pa(Pa({}, function() {
                        var e = function(e) {
                                var t = e.initialScreen,
                                    n = e.initialScreenType,
                                    i = e.maxUnansweredMessages,
                                    o = e.chatBlockedGiftPromo;
                                if (i <= 0 && o) return {
                                    external: !1,
                                    text: o.getMssg(),
                                    action: {
                                        text: o.getAction(),
                                        onClick: function() {
                                            return N()
                                        }
                                    }
                                };
                                var r = null == t ? void 0 : t.blockingFeature;
                                if (r && 19 !== n) {
                                    if (13 === r.getRequiredAction()) return {
                                        external: !0
                                    };
                                    var s = {
                                        variant: Ks.ADD_PHOTO,
                                        text: (null == t ? void 0 : t.message) || r.getDisplayMessage(""),
                                        action: {
                                            text: r.getDisplayAction()
                                        }
                                    };
                                    switch (n) {
                                        case 13:
                                            s.variant = Ks.SEARCH_CONDITIONS;
                                            break;
                                        case 16:
                                            s.variant = Ks.NEWBIE, s.type = 4;
                                            break;
                                        case 15:
                                            s.variant = Ks.VERY_POPULAR, s.type = 5;
                                            break;
                                        case 11:
                                            s.variant = Ks.LIMIT_REACHED, s.cost = r.getDisplayComment() || void 0
                                    }
                                    return s.action.onClick = function() {
                                        return N(s.type)
                                    }, s
                                }
                            }(n),
                            t = 0 !== n.maxUnansweredMessages,
                            i = n.initialScreen,
                            o = t ? function(e) {
                                var t, n, i, o, r;
                                if (null == (t = e.initialScreen) || !t.blockingFeature) {
                                    var s = 2 === (null == (n = he.A.getUser()) ? void 0 : n.gender),
                                        a = 18 === e.initialScreenType;
                                    if (s && !e.hasReceivedMessage || a) {
                                        (0, l.sx)(258, {
                                            element: 227
                                        });
                                        var c = m.Ay.get(565);
                                        return a ? c = e.initialScreen.message : "male" === e.gender && (c = m.Ay.get(566)), {
                                            smile: {
                                                subtitle: c,
                                                button: m.Ay.get(957)
                                            }
                                        }
                                    }
                                    var u = ((null == (i = e.initialScreen) ? void 0 : i.gifts) || []).map((function(e) {
                                            return {
                                                product_id: e.product_id || "",
                                                thumb_url: e.thumb_url || "",
                                                large_url: e.large_url || ""
                                            }
                                        })),
                                        d = {
                                            gifts: null == u ? void 0 : u.slice(0, 3),
                                            message: null == (o = e.initialScreen) ? void 0 : o.message,
                                            subtitle: null == (r = e.initialScreen) ? void 0 : r.subtitle
                                        };
                                    if (d.message || d.subtitle || d.gifts) return d;
                                    var p = e.promoBanners.find((function(e) {
                                        return 24 === e.getPromoBlockType() && 5 === e.getPromoBlockPosition()
                                    }));
                                    return p ? {
                                        gift: p.getMssg()
                                    } : void 0
                                }
                            }(n) : void 0,
                            r = h.getIsMatch(!1),
                            s = function(e) {
                                var t = function(e) {
                                    if (e.initialScreen) {
                                        var t = e.initialScreen.blockingFeature,
                                            n = 7 === e.initialScreenType;
                                        if (t || n || 0 === e.messages.length) return null;
                                        var i = (0, u.A)(e.messages),
                                            o = "male" === e.gender ? m.Ay.get(592, {
                                                str: e.chatUser.getName()
                                            }) : m.Ay.get(591, {
                                                str: e.chatUser.getName()
                                            });
                                        switch (i.messageType) {
                                            case 1:
                                            case 23:
                                            case 22:
                                            case wa:
                                            case Ra:
                                                return {
                                                    type: "textMessage",
                                                    body: i.message
                                                };
                                            case 10:
                                                return {
                                                    type: "giftMessage",
                                                    body: {
                                                        label: o,
                                                        image: i.image.srcBox || i.image.src,
                                                        text: i.message
                                                    }
                                                };
                                            default:
                                                return {
                                                    body: m.Ay.get(1094),
                                                    type: "textMessage"
                                                }
                                        }
                                    }
                                }(e);
                                if (t) {
                                    var n, i = "textMessage" === t.type || "gifMessage" === t.type;
                                    return (n = {})[t.type] = t.body, n.bozo = i ? {
                                        replyLexeme: m.Ay.get(395),
                                        skipLexeme: m.Ay.get(374)
                                    } : null, n
                                }
                            }(n),
                            a = !(!t || o || e && !e.external),
                            c = {
                                blocker: e,
                                invitation: o,
                                match: r,
                                simpleText: i && a ? {
                                    text: i.message,
                                    header: i.title || i.subtitle || ""
                                } : void 0,
                                subtitle: null == i ? void 0 : i.subtitle,
                                onDismiss: U,
                                onOpenGift: R,
                                onSendSmile: w,
                                onBlockUser: D,
                                onSendGiftDirect: x
                            };
                        return s && Object.assign(c, s), c
                    }()), {}, {
                        hasMessages: d.length > 0,
                        verificationButton: K,
                        dataQA: J
                    }))
                };
            var Ua, Da = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.buttonText,
                        o = e.onClickPrimary;
                    return (0, S.jsx)(Aa, {
                        title: t,
                        text: n,
                        primaryButton: {
                            onClick: o,
                            text: i,
                            icon: "generic-add-photos"
                        }
                    })
                },
                Ba = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.buttonText,
                        o = e.onClickPrimary;
                    return (0, S.jsx)(Aa, {
                        title: t,
                        text: n,
                        primaryButton: {
                            onClick: o,
                            text: i,
                            icon: "generic-chat"
                        }
                    })
                },
                La = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.hint,
                        o = e.buttonText,
                        r = e.onClickPrimary,
                        s = e.onClickClose;
                    return (0, S.jsx)(Aa, {
                        title: t,
                        text: n,
                        hint: i,
                        mediaIcon: r ? void 0 : "badge-feature-premium-lock-opened",
                        primaryButton: r && o ? {
                            onClick: r,
                            text: o,
                            styling: "revenue",
                            icon: "generic-lock"
                        } : void 0,
                        onClickClose: s
                    })
                },
                Fa = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.buttonText,
                        o = e.onClickClose,
                        r = e.onClickPrimary;
                    return (0, S.jsx)(Aa, {
                        title: t,
                        text: n,
                        primaryButton: {
                            onClick: r,
                            text: i,
                            styling: "revenue",
                            icon: "generic-crush"
                        },
                        onClickClose: o
                    })
                },
                Ga = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.buttonText,
                        o = e.onClickClose,
                        r = e.onClickPrimary;
                    return (0, S.jsx)(Aa, {
                        title: t,
                        text: n,
                        primaryButton: {
                            onClick: r,
                            text: i,
                            icon: "generic-notification"
                        },
                        onClickClose: o
                    })
                },
                Va = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.buttonText,
                        o = e.secondaryButtonText,
                        r = e.onClickPrimary,
                        s = e.onClickSecondary;
                    return (0, S.jsx)(Aa, {
                        title: t,
                        text: n,
                        primaryButton: {
                            onClick: r,
                            text: i,
                            icon: "generic-chat"
                        },
                        secondaryButton: {
                            onClick: s,
                            text: o
                        }
                    })
                };
            ! function(e) {
                e[e.NEWBIE = 0] = "NEWBIE", e[e.POPULAR = 1] = "POPULAR", e[e.SELECTIVE = 2] = "SELECTIVE"
            }(Ua || (Ua = {}));
            var qa, Ha = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.buttonText,
                        o = e.nudgeType,
                        r = e.onClickPrimary;
                    return (0, S.jsx)(Aa, {
                        title: t,
                        text: n,
                        primaryButton: {
                            onClick: r,
                            text: i,
                            styling: o === Ua.NEWBIE ? "default" : "revenue",
                            icon: o === Ua.NEWBIE ? "generic-newbies" : "generic-premium"
                        }
                    })
                },
                Qa = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.buttonText,
                        o = e.onClickPrimary,
                        r = e.onClickClose;
                    return (0, S.jsx)(Aa, {
                        title: t,
                        text: n,
                        mediaIcon: "badge-feature-questions-game",
                        primaryButton: {
                            text: i,
                            onClick: o
                        },
                        onClickClose: r
                    })
                },
                Ya = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.buttonText,
                        o = e.secondaryButtonText,
                        r = e.onClickClose,
                        s = e.onClickPrimary,
                        a = e.onClickSecondary,
                        c = o ? {
                            text: o,
                            onClick: a
                        } : void 0;
                    return (0, S.jsx)(Aa, {
                        title: t,
                        text: n,
                        primaryButton: {
                            onClick: s,
                            text: i,
                            icon: "generic-camera"
                        },
                        secondaryButton: c,
                        onClickClose: r
                    })
                },
                Wa = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.buttonText,
                        o = e.onClickClose,
                        r = e.onClickPrimary;
                    return (0, S.jsx)(Aa, {
                        title: t,
                        text: n,
                        primaryButton: {
                            onClick: r,
                            text: i,
                            icon: "generic-chat"
                        },
                        onClickClose: o
                    })
                },
                za = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.buttonText,
                        o = e.isPremiumPlus,
                        r = e.onClickClose,
                        s = e.onClickPrimary;
                    return (0, S.jsx)(Aa, {
                        title: t,
                        text: n,
                        primaryButton: {
                            onClick: s,
                            text: i,
                            icon: o ? "generic-premium-plus" : "generic-special-delivery",
                            styling: o ? void 0 : "revenue"
                        },
                        onClickClose: r
                    })
                };
            ! function(e) {
                e[e.PENDING = 0] = "PENDING", e[e.FAILED = 1] = "FAILED", e[e.REQUIRED = 2] = "REQUIRED"
            }(qa || (qa = {}));
            var Ka = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.buttonText,
                        o = e.mode,
                        r = void 0 === o ? qa.REQUIRED : o,
                        s = e.onClickPrimary,
                        a = r !== qa.PENDING && s && i ? {
                            icon: r === qa.FAILED ? "generic-error" : "generic-verification-hollow",
                            text: i,
                            onClick: s
                        } : void 0;
                    return (0, S.jsx)(Aa, {
                        title: t,
                        text: n,
                        mediaIcon: r === qa.PENDING ? "badge-feature-verification" : void 0,
                        primaryButton: a
                    })
                },
                Ja = n(97803),
                Xa = function(e) {
                    var t = e.title,
                        n = e.text,
                        i = e.onClickClose,
                        o = e.onClickYes,
                        r = e.onClickNo;
                    return (0, S.jsx)(Aa, {
                        title: t,
                        text: n,
                        customButtons: (0, S.jsxs)("div", {
                            className: "chat-nudge-vote__actions",
                            children: [(0, S.jsx)("div", {
                                className: "chat-nudge-vote__action",
                                children: (0, S.jsx)(Ja.A, {
                                    type: "no",
                                    onClick: r,
                                    dataQA: {
                                        "data-qa": "vote-no"
                                    },
                                    a11y: {
                                        label: m.Ay.get(301)
                                    }
                                })
                            }), (0, S.jsx)("div", {
                                className: "chat-nudge-vote__action",
                                children: (0, S.jsx)(Ja.A, {
                                    type: "yes",
                                    onClick: o,
                                    dataQA: {
                                        "data-qa": "vote-yes"
                                    },
                                    a11y: {
                                        label: m.Ay.get(305)
                                    }
                                })
                            })]
                        }),
                        onClickClose: i
                    })
                },
                Za = n(88651),
                $a = n(41051);
            var ec = n(69705),
                tc = n(45141),
                nc = n(17380),
                ic = function(e) {
                    var t = e.title,
                        n = e.subtitle,
                        i = e.options,
                        o = e.onDismiss;
                    return (0, S.jsx)(_n.A, {
                        onAnimationOutComplete: o,
                        isPadded: !0,
                        children: (0, S.jsxs)(co.A, {
                            isCompact: !0,
                            align: "start",
                            children: [(0, S.jsx)(uo.A, {
                                text: t,
                                tag: "h2"
                            }), (0, S.jsx)(po.A, {
                                text: n
                            }), (0, S.jsx)(ho.A, {
                                children: (0, S.jsx)(sa.A, {
                                    spacing: "compact",
                                    children: i.map((function(e) {
                                        return (0, S.jsx)(tc.A, {
                                            title: e.name,
                                            extra: (0, S.jsx)(nc.A, {
                                                type: "radio",
                                                isChecked: e.isChecked,
                                                onChange: e.onClick
                                            }),
                                            dataQA: {
                                                "data-qa": "letdown-feedback-item"
                                            },
                                            tag: "label"
                                        }, e.id)
                                    }))
                                })
                            })]
                        })
                    })
                },
                oc = function(e) {
                    var t, n = e.promo,
                        o = e.chatInstanceId,
                        r = e.onDismiss,
                        a = e.onSubmit,
                        c = (0, i.useState)(),
                        l = c[0],
                        u = c[1],
                        d = null == (t = n.survey) || null == (t = t.questions) ? void 0 : t[0].answers,
                        p = (0, i.useRef)(!0);
                    if ((0, i.useEffect)((function() {
                            var e = function(e) {
                                $a.A.sendPromoBannerStats({
                                    chatInstanceId: o,
                                    event: e,
                                    context: 10,
                                    promoBlockType: 575,
                                    promoBlockPosition: 18
                                })
                            };
                            return e(2),
                                function() {
                                    p.current && e(4)
                                }
                        }), [o]), null == d || !d.length) return null;
                    var f = d.map((function(e) {
                        return {
                            id: e.answer_id,
                            name: e.answer_text,
                            isChecked: l === e.answer_id,
                            onClick: function() {
                                l || (u(e.answer_id), new Pe.Ay(450, {
                                    context: 209,
                                    chat_instance_id: o,
                                    answers: [{
                                        question_id: e.question_id,
                                        answer_id: e.answer_id
                                    }]
                                }).request(), s.A.setTimeout((function() {
                                    r(), a()
                                }), 300), p.current = !1)
                            }
                        }
                    }));
                    return (0, S.jsx)(ic, {
                        title: n.header,
                        subtitle: n.mssg,
                        options: f,
                        onDismiss: r
                    })
                },
                rc = n(63620);

            function sc(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function ac(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? sc(Object(n), !0).forEach((function(t) {
                        cc(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : sc(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function cc(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function lc(e, t) {
                var n;
                return null == (n = e.buttons) ? void 0 : n.find((function(e) {
                    return e.type === t
                }))
            }

            function uc(e, t) {
                void 0 === t && (t = 4);
                var n = new F.Ay({
                    context: t,
                    messageType: 22,
                    toPersonId: e
                });
                return p.A.send(e, n)
            }

            function dc(e, t) {
                (0, l.sx)(20, {
                    alert_type: e,
                    activation_place: 11,
                    action_type: t
                })
            }
            var pc = function(e) {
                    var t = e.promoBlock,
                        n = e.chatInstanceId,
                        o = e.feedbackPromo,
                        r = e.chatUser,
                        u = e.clientSource,
                        d = e.isBlocker,
                        f = e.onClickQuestionsGame,
                        h = e.onCloseQuestionsGame,
                        v = e.onReloadClientOpenChat,
                        y = e.onCloseChat,
                        b = (0, i.useState)(!!t),
                        x = b[0],
                        C = b[1],
                        _ = (0, i.useState)(t),
                        k = _[0],
                        j = _[1],
                        E = (0, i.useState)(!1),
                        O = E[0],
                        T = E[1],
                        P = (0, i.useState)(),
                        I = P[0],
                        w = P[1],
                        R = (0, i.useState)(!1),
                        N = R[0],
                        D = R[1];
                    (0, i.useEffect)((function() {
                        function e(e) {
                            var t;
                            $.includes(null == (t = e.banner) ? void 0 : t.promo_block_type) && (j(e.banner), C(!0))
                        }
                        return p.A.on(p.A.EVENTS.MESSAGE_FROM_USER, e),
                            function() {
                                p.A.off(p.A.EVENTS.MESSAGE_FROM_USER, e)
                            }
                    }), []), (0, i.useEffect)((function() {
                        t || !k ? (j(t), C(!0)) : k && !t && (C(!1), s.A.setTimeout((function() {
                            j(void 0)
                        }), 400))
                    }), [t, k]);
                    var L = null == k ? void 0 : k.promo_block_type,
                        G = null == k ? void 0 : k.header,
                        q = null == k ? void 0 : k.mssg,
                        H = function() {
                            k && p.A.markChatPromoHandled(n, null == k ? void 0 : k.promo_block_type)
                        },
                        Q = function() {
                            H(), C(!1)
                        },
                        Y = function() {
                            var e;
                            k && ($a.A.sendPromoBannerStats({
                                event: 439 === L ? 4 : 1,
                                context: 10,
                                promoBlockType: k.promo_block_type,
                                promoBlockPosition: k.promo_block_position,
                                promoId: k.id,
                                variantId: k.variant_id,
                                chatInstanceId: n
                            }), (0, l.sx)(139, {
                                banner_id: k.promo_block_type,
                                position_id: k.promo_block_position,
                                context: 10,
                                variation_id: k.stats_variation_id,
                                call_to_action_type: 1
                            }), 459 === L ? function(e) {
                                var t = new F.Ay({
                                    messageType: 28,
                                    toPersonId: e
                                });
                                (0, l.sx)(166, {
                                    activation_place: 11,
                                    chat_msg_type: 1,
                                    encrypted_user_id: e,
                                    inchat_action_type: 2
                                }), (0, l.sx)(426, {
                                    activation_place: 11,
                                    access_type: 2,
                                    encrypted_user_id: e
                                }), p.A.send(e, t).catch((function(e) {
                                    U.A.showNotification({
                                        text: null == e || null == e.getErrorMessage ? void 0 : e.getErrorMessage(),
                                        type: U.A.TYPES.ERROR
                                    })
                                }))
                            }(n) : 460 === L ? function(e, t) {
                                (0, l.sx)(166, {
                                    activation_place: 11,
                                    chat_msg_type: 2,
                                    encrypted_user_id: e,
                                    inchat_action_type: 2
                                }), (0, l.sx)(427, {
                                    activation_place: 11,
                                    access_type: 2,
                                    action_type: 2,
                                    encrypted_user_id: e
                                });
                                var n = p.A.getCachedClientOpenChat(e).messages,
                                    i = n.find((function(t) {
                                        return 28 === t.messageType && t.fromPersonId === e
                                    }));
                                a.A.navigate(c.x.CAMERA, {
                                    facingMode: "user",
                                    onTakePicture: function(e) {
                                        var n = new s.A.FileReader;
                                        n.readAsDataURL(e), n.onload = function(n) {
                                            var o = new s.A.FormData;
                                            (function(e, t, n) {
                                                return (0, A.NN)(t).then((function(t) {
                                                    var i = t[0],
                                                        o = t[1],
                                                        r = t[2];
                                                    return new F.Ay({
                                                        messageType: 30,
                                                        replyToUid: e.id,
                                                        toPersonId: e.fromPersonId,
                                                        image: {
                                                            height: r,
                                                            id: n,
                                                            src: i,
                                                            visibility: 4,
                                                            width: o
                                                        }
                                                    })
                                                })).catch((function(e) {
                                                    return (0, Zt.gf)(e, "Chat message selfie preload")
                                                }))
                                            })(i, n.target.result, "TEMP").then((function(n) {
                                                n.setStatus(n.STATUS.SENDING), p.A.add(n), a.A.back(), o.append("file", e), M.A.ajax({
                                                    contentType: !1,
                                                    data: o,
                                                    dataType: "json",
                                                    processData: !1,
                                                    type: "POST",
                                                    url: (0, V.A)(B.A.getSettings(), 5),
                                                    success: function(e) {
                                                        var o = e.photo_id;
                                                        n.image.id = o, p.A.send(n.toPersonId, n).then((function() {
                                                            (0, l.sx)(73, {
                                                                encrypted_user_id: i.fromPersonId,
                                                                is_selfie: !0,
                                                                photo_id: o
                                                            }), t()
                                                        }))
                                                    }
                                                })
                                            }))
                                        }
                                    },
                                    onCameraError: function() {
                                        a.A.back()
                                    }
                                })
                            }(n, (function() {
                                H()
                            })) : 461 === L ? (e = Q, ec.A.userWantsPushes(ec.A.PLACE_CHAT).then((function(t) {
                                ! function(e) {
                                    (0, l.sx)(47, {
                                        permission_type: 2,
                                        permission_granted: e,
                                        activation_place: 11
                                    })
                                }(t), e()
                            }))) : 477 === L ? uc(n).then(Q) : 439 === L ? (Q(), s.A.setTimeout((function() {
                                p.A.focusInput()
                            }), 400)) : 514 === L ? (Q(), f()) : 467 === L ? a.A.navigate(c.x.OWN_PROFILE_EDIT, {
                                destination: a.A.getUrl(),
                                anchor: rc.l.ADD_PHOTOS
                            }) : 476 === L || 466 === L ? uc(n, u).then(Q) : 473 === L ? (ba.A.verifyByPhoto(), (0, l.sx)(332, {
                                element: 31,
                                position: 1
                            })) : 472 === L ? function(e, t) {
                                _a.A.purchase({
                                    back: a.A.getUrl(),
                                    cost: t.payment_amount,
                                    hotPanelData: {
                                        activationPlace: 11,
                                        promoBlockType: t.promo_block_type
                                    },
                                    productType: t.ok_payment_product_type,
                                    userId: e
                                })
                            }(n, k) : 471 === L ? function(e, t) {
                                ie.A.getInstance().setBackRoute(a.A.getUrl()), ie.A.getInstance().setBackAction(be), _a.A.purchase({
                                    back: a.A.getUrl(),
                                    hotPanelData: {
                                        activationPlace: 11,
                                        promoBlockType: 471
                                    },
                                    productType: 3,
                                    promoBlockType: 471,
                                    userId: e,
                                    success: t
                                })
                            }(n, (function() {
                                H(), v()
                            })) : 458 !== L && 470 !== L && 469 !== L && 468 !== L || function(e) {
                                var t = 1;
                                47 === e.ok_payment_product_type && (t = e.ok_payment_product_type);
                                ns.A.navigateToPayment({
                                    back: a.A.getUrl(),
                                    hotPanelData: {
                                        activationPlace: 11,
                                        promoBlockType: e.promo_block_type
                                    },
                                    productType: t,
                                    promoBlockType: e.promo_block_type
                                })
                            }(k))
                        },
                        W = function() {
                            T(!1)
                        },
                        z = function() {
                            Q(), a.A.navigate(c.x.CONNECTIONS)
                        },
                        K = function() {
                            g.A.getInstance().markAsGentleLetdownBlocked(n).then(z)
                        },
                        J = function() {
                            o ? D(!0) : K()
                        },
                        X = function() {
                            if (k)
                                if ($a.A.sendPromoBannerStats({
                                        event: 1,
                                        context: 10,
                                        promoBlockType: k.promo_block_type,
                                        promoBlockPosition: k.promo_block_position,
                                        promoId: k.id,
                                        variantId: k.variant_id,
                                        chatInstanceId: n
                                    }), (0, l.sx)(139, {
                                        banner_id: k.promo_block_type,
                                        position_id: k.promo_block_position,
                                        context: 10,
                                        variation_id: k.stats_variation_id,
                                        call_to_action_type: 2
                                    }), 460 === L) ! function(e) {
                                    var t = p.A.getCachedClientOpenChat(e).messages,
                                        n = t.find((function(t) {
                                            return 28 === t.messageType && t.fromPersonId === e
                                        })),
                                        i = new F.Ay({
                                            messageType: 29,
                                            replyToUid: n.id,
                                            toPersonId: e
                                        });
                                    (0, l.sx)(166, {
                                        activation_place: 11,
                                        chat_msg_type: 2,
                                        encrypted_user_id: e,
                                        inchat_action_type: 3
                                    }), (0, l.sx)(427, {
                                        activation_place: 11,
                                        access_type: 2,
                                        action_type: 5,
                                        encrypted_user_id: e
                                    }), p.A.send(e, i)
                                }(n), Q();
                                else if (439 === L) {
                                var e = lc(k, 2);
                                118 === (null == e ? void 0 : e.action) ? (w({
                                    title: m.Ay.get(10, {
                                        me: Ie.ko.for("me", (0, se.nV)())
                                    }),
                                    message: m.Ay.get(11, {
                                        other_user: Ie.ko.for("other_user", (0, m.Bt)(r.getGender())),
                                        name: r.getName()
                                    }),
                                    yesAction: {
                                        text: m.Ay.get(373),
                                        dataQA: {
                                            "data-qa": "gentle-letdown-confirm"
                                        },
                                        onClick: function() {
                                            dc(159, 24), W(), J()
                                        }
                                    },
                                    noAction: {
                                        text: m.Ay.get(451),
                                        dataQA: {
                                            "data-qa": "gentle-letdown-cancel"
                                        },
                                        onClick: function() {
                                            dc(159, 5), W()
                                        }
                                    }
                                }), T(!0)) : J()
                            }
                        },
                        Z = function() {
                            var e;
                            (Q(), k) && ((0, l.sx)(139, {
                                banner_id: k.promo_block_type,
                                position_id: k.promo_block_position,
                                context: 10,
                                variation_id: k.stats_variation_id,
                                call_to_action_type: 4
                            }), null != (e = k.stats_required) && e.includes(4) && $a.A.sendPromoBannerStats({
                                event: 4,
                                context: 10,
                                promoBlockType: k.promo_block_type,
                                promoBlockPosition: k.promo_block_position,
                                promoId: k.id,
                                variantId: k.variant_id,
                                chatInstanceId: n
                            }), 514 === k.promo_block_type && h())
                        },
                        ee = function(e, t) {
                            k && ($a.A.sendPromoBannerStats({
                                event: 1,
                                context: 10,
                                promoBlockType: k.promo_block_type,
                                promoBlockPosition: k.promo_block_position,
                                promoId: k.id,
                                chatInstanceId: n
                            }), (0, l.sx)(332, {
                                element: e ? 619 : 618,
                                parent_element: 1584
                            }), Za.A.getInstance().set({
                                id: n,
                                photoId: "",
                                source: 10,
                                voteType: e ? 2 : 3
                            }).then(t))
                        };
                    (0, i.useEffect)((function() {
                        var e, t, i = [];

                        function o(e) {
                            77 === e && Z()
                        }
                        return null != k && null != (e = k.stats_required) && e.includes(2) && $a.A.sendPromoBannerStats({
                                event: 2,
                                context: 10,
                                promoBlockType: k.promo_block_type,
                                promoBlockPosition: k.promo_block_position,
                                promoId: k.id,
                                variantId: k.variant_id,
                                chatInstanceId: n
                            }), k && (0, l.sx)(138, {
                                banner_id: k.promo_block_type,
                                position_id: k.promo_block_position,
                                context: 10,
                                variation_id: k.stats_variation_id
                            }), null == k || null == (t = k.chat_triggers) || t.forEach((function(e) {
                                i.push(function(e, t) {
                                    var n, i = 0,
                                        o = [];

                                    function r() {
                                        i += 1, e.num === i && (t(e.action), a())
                                    }

                                    function a() {
                                        o.forEach((function(e) {
                                            p.A.off(e.event, e.handler)
                                        })), n && (s.A.clearTimeout(n), n = void 0)
                                    }
                                    return 2 === e.type ? (p.A.on(p.A.EVENTS.MESSAGE_FROM_USER, r), o.push({
                                        event: p.A.EVENTS.MESSAGE_FROM_USER,
                                        handler: r
                                    })) : 1 === e.type ? (p.A.on(p.A.EVENTS.MESSAGE_FROM_USER, r), p.A.on(p.A.EVENTS.MESSAGE_FROM_ME, r), o.push({
                                        event: p.A.EVENTS.MESSAGE_FROM_USER,
                                        handler: r
                                    }), o.push({
                                        event: p.A.EVENTS.MESSAGE_FROM_ME,
                                        handler: r
                                    })) : 3 === e.type ? (p.A.on(p.A.EVENTS.MESSAGE_FROM_ME, r), o.push({
                                        event: p.A.EVENTS.MESSAGE_FROM_ME,
                                        handler: r
                                    })) : 4 === e.type && (n = s.A.setTimeout((function() {
                                        t(e.action), n = void 0
                                    }), 1e3 * e.num)), a
                                }(e, o))
                            })),
                            function() {
                                i.forEach((function(e) {
                                    return e()
                                }))
                            }
                    }), [L, n]);
                    var te = null;
                    if (k) {
                        var ne = lc(k, 1),
                            oe = lc(k, 2),
                            re = {
                                title: G,
                                text: q,
                                buttonText: null == ne ? void 0 : ne.text,
                                onClickPrimary: Y
                            },
                            ae = ac(ac({}, re), {}, {
                                onClickClose: Z
                            });
                        if (458 === L) te = (0, S.jsx)(za, ac({}, ae));
                        else if (459 === L || 460 === L) te = (0, S.jsx)(Ya, ac(ac({}, ae), {}, {
                            secondaryButtonText: null == oe ? void 0 : oe.text,
                            onClickSecondary: X
                        }));
                        else if (461 === L) te = (0, S.jsx)(Ga, ac({}, ae));
                        else if (477 === L) te = (0, S.jsx)(Fa, ac({}, ae));
                        else if (439 === L) te = (0, S.jsx)(Va, ac(ac({}, re), {}, {
                            secondaryButtonText: null == oe ? void 0 : oe.text,
                            onClickSecondary: X
                        }));
                        else if (514 === L) te = (0, S.jsx)(Qa, ac({}, ae));
                        else if (467 === L) te = (0, S.jsx)(Da, ac({}, re));
                        else if (476 === L || 466 === L) te = (0, S.jsx)(Wa, ac({}, ae));
                        else if (473 === L) {
                            var ce = qa.REQUIRED;
                            2 === k.stats_variation_id ? ce = qa.PENDING : 3 === k.stats_variation_id && (ce = qa.FAILED), te = (0, S.jsx)(Ka, ac(ac({}, re), {}, {
                                mode: ce
                            }))
                        } else 472 === L ? te = (0, S.jsx)(La, {
                            title: G,
                            text: q,
                            buttonText: null == ne ? void 0 : ne.text,
                            onClickPrimary: ne ? Y : void 0,
                            hint: k.credits_cost
                        }) : 471 === L ? te = (0, S.jsx)(Ba, ac({}, re)) : 470 === L ? te = (0, S.jsx)(Ha, ac({
                            nudgeType: Ua.SELECTIVE
                        }, re)) : 469 === L ? te = (0, S.jsx)(Ha, ac({
                            nudgeType: Ua.POPULAR
                        }, re)) : 468 === L ? te = (0, S.jsx)(Ha, ac({
                            nudgeType: Ua.NEWBIE
                        }, re)) : 465 === L && (te = (0, S.jsx)(Xa, ac(ac({}, ae), {}, {
                            onClickYes: function() {
                                ee(!0, (function() {
                                    (0, l.sx)(39, {
                                        activation_place: 11,
                                        vote_result: 2
                                    }), H(), v()
                                }))
                            },
                            onClickNo: function() {
                                ee(!1, (function() {
                                    (0, l.sx)(39, {
                                        activation_place: 11,
                                        vote_result: 3
                                    }), H(), y()
                                }))
                            }
                        })))
                    }
                    return (0, S.jsxs)(i.Fragment, {
                        children: [te ? (0, S.jsx)(Ue.A, { in: x,
                            appear: !0,
                            timeout: 400,
                            unmountOnExit: !0,
                            children: (0, S.jsx)("div", {
                                className: "chat-nudge-container",
                                "data-qa": "chat-nudge-container",
                                "data-qa-chat-nudge-type": null == k ? void 0 : k.promo_block_type,
                                children: (0, S.jsx)(Mn.A, {
                                    top: "sm",
                                    right: "lg",
                                    left: "lg",
                                    bottom: d ? "lg" : "sm",
                                    children: te
                                })
                            })
                        }) : null, O && I ? (0, S.jsx)(Mo, ac({}, I)) : null, N && o ? (0, S.jsx)(oc, {
                            promo: o,
                            chatInstanceId: n,
                            onDismiss: function() {
                                D(!1)
                            },
                            onSubmit: K
                        }) : null]
                    })
                },
                fc = function(e) {
                    var t = e.title,
                        n = e.buttonText,
                        i = e.onClick;
                    return (0, S.jsx)(Aa, {
                        title: t,
                        primaryButton: {
                            onClick: i,
                            text: n
                        }
                    })
                },
                hc = function(e) {
                    var t = e.chatUser,
                        n = e.onDelete;
                    return (0, i.useEffect)((function() {
                        (0, l.sx)(258, {
                            element: 1556
                        })
                    }), []), (0, S.jsx)(fc, {
                        title: m.Ay.get(12, {
                            name: t.getName(),
                            other_user: Ie.ko.for("other_user", (0, m.Bt)(t.getGender()))
                        }),
                        buttonText: m.Ay.get(238),
                        onClick: function() {
                            (0, l.sx)(332, {
                                element: 106,
                                parent_element: 1556
                            }), n()
                        }
                    })
                },
                gc = function(e) {
                    var t = e.isOpen,
                        n = e.onCaptureClick,
                        o = e.onChooseClick,
                        r = e.onCancelClick,
                        s = (0, i.useState)(t),
                        a = s[0],
                        c = s[1],
                        l = (0, i.useRef)("cancel"),
                        u = function(e) {
                            c(!1), l.current = e
                        };
                    return (0, i.useEffect)((function() {
                        c(t)
                    }), [t]), t ? (0, S.jsxs)(_n.A, {
                        wrapperType: _n.T.ACTION_SHEET,
                        isVisible: a,
                        isDismissible: !1,
                        onAnimationOutComplete: function() {
                            switch (l.current) {
                                case "capture":
                                    n();
                                    break;
                                case "choose":
                                    o();
                                    break;
                                default:
                                    r()
                            }
                        },
                        hasDefaultDismissButton: !1,
                        children: [(0, S.jsx)(Fn.A, {
                            text: m.Ay.get(748),
                            icon: (0, S.jsx)(cn.A, {
                                name: "generic-camera"
                            }),
                            onClick: function() {
                                return u("capture")
                            }
                        }), (0, S.jsx)(Fn.A, {
                            text: m.Ay.get(599),
                            icon: (0, S.jsx)(cn.A, {
                                name: "generic-photo-gallery"
                            }),
                            onClick: function() {
                                return u("choose")
                            }
                        }), (0, S.jsx)(Fn.A, {
                            text: m.Ay.get(451),
                            onClick: function() {
                                return u("cancel")
                            }
                        })]
                    }) : null
                },
                mc = function(e) {
                    var t = e.headerText,
                        n = e.text,
                        i = e.acceptButtonText,
                        o = e.cancelButtonText,
                        r = e.onAcceptButtonClick,
                        s = e.onCancelButtonClick;
                    return (0, S.jsxs)(co.A, {
                        isCompact: !0,
                        align: "start",
                        children: [(0, S.jsx)(lo.A, {
                            size: "icon",
                            children: (0, S.jsx)(cn.A, {
                                name: "generic-search-attention"
                            })
                        }), (0, S.jsx)(uo.A, {
                            text: t,
                            tag: "h2"
                        }), (0, S.jsx)(po.A, {
                            text: n
                        }), (0, S.jsxs)(fo.A, {
                            children: [(0, S.jsx)(go.A, {
                                text: i,
                                onClick: r,
                                dataQA: {
                                    "data-qa": "private-detector-keep-filtering"
                                }
                            }), (0, S.jsx)(go.A, {
                                semantic: "tertiary",
                                text: o,
                                onClick: s,
                                dataQA: {
                                    "data-qa": "private-detector-show-photos"
                                }
                            })]
                        })]
                    })
                };

            function vc(e, t) {
                return vc = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, vc(e, t)
            }
            var Ac = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).createButtonClickHandler = function(e) {
                            return function() {
                                (0, l.sx)(332, {
                                    element: e ? 67 : 629,
                                    parent_element: 1273
                                }), p.A.updatePrivateDetectorStatus(n.props.chatInstanceId, e).then((function() {
                                    n.setState({
                                        isVisible: !1
                                    })
                                }))
                            }
                        }, n.state = {
                            isVisible: !0
                        }, n
                    }
                    var n, i;
                    return i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, vc(n, i), t.prototype.render = function() {
                        return (0, S.jsx)(_n.A, {
                            isVisible: this.state.isVisible,
                            isDismissible: !1,
                            onAnimationOutComplete: this.props.onAnimationOutComplete,
                            isPadded: !0,
                            hasDefaultDismissButton: !1,
                            children: (0, S.jsx)(mc, {
                                headerText: m.Ay.get(5),
                                text: m.Ay.get(4, {
                                    name: this.props.name
                                }),
                                acceptButtonText: m.Ay.get(2),
                                cancelButtonText: m.Ay.get(3),
                                onAcceptButtonClick: this.createButtonClickHandler(!0),
                                onCancelButtonClick: this.createButtonClickHandler(!1)
                            })
                        })
                    }, t
                }(i.Component),
                yc = n(84935),
                bc = function(e) {
                    var t = e.headerText,
                        n = e.text,
                        i = e.additionalText,
                        o = e.betweenButtonsText,
                        r = e.mediaImageSrc,
                        s = e.primaryButton,
                        a = e.secondaryButton,
                        c = e.dismissButton,
                        l = e.isLoading;
                    return (0, S.jsxs)(co.A, {
                        isCompact: !0,
                        align: "start",
                        dataQA: {
                            "data-qa": "read_receipts_modal"
                        },
                        children: [(0, S.jsx)(lo.A, {
                            children: (0, S.jsx)(Hn.A, {
                                badge: {
                                    icon: {
                                        name: "badge-feature-read-receipt"
                                    }
                                },
                                image: {
                                    src: r
                                },
                                shape: "circle",
                                size: "md"
                            })
                        }), (0, S.jsx)(uo.A, {
                            text: t,
                            tag: "h2"
                        }), (0, S.jsx)(po.A, {
                            text: n
                        }), (0, S.jsxs)(fo.A, {
                            children: [(0, S.jsx)(go.A, {
                                text: s.buttonText,
                                onClick: s.onClick,
                                styling: "revenue",
                                isLoading: l,
                                isDisabled: l,
                                dataQA: s.dataQA,
                                semantic: o ? "secondary" : "primary"
                            }), o ? (0, S.jsx)(ha.A, {
                                text: o
                            }) : null, a ? (0, S.jsx)(go.A, {
                                text: a.buttonText,
                                icon: a.icon,
                                styling: a.styling,
                                onClick: a.onClick,
                                dataQA: a.dataQA
                            }) : null, (0, S.jsx)(go.A, {
                                text: c.buttonText,
                                icon: c.icon,
                                styling: c.styling,
                                semantic: "tertiary",
                                onClick: c.onClick,
                                dataQA: c.dataQA
                            })]
                        }), i ? (0, S.jsx)(Zs.A, {
                            children: (0, S.jsx)($s.A, {
                                children: i
                            })
                        }) : null]
                    })
                };

            function xc(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function Sc(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? xc(Object(n), !0).forEach((function(t) {
                        Cc(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : xc(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function Cc(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function _c(e, t, n) {
                void 0 === n && (n = {}), new Pe.Ay(278, {
                    promo_banner_stats: Sc({
                        event: e,
                        context: t.context,
                        promo_block_type: t.promo_block_type,
                        promo_block_position: t.promo_block_position
                    }, n)
                }).request()
            }
            var kc = function(e) {
                return (0, i.useEffect)((function() {
                    var t; - 1 !== (null == e || null == (t = e.stats_required) ? void 0 : t.indexOf(2)) && _c(2, e)
                }), [e]), {
                    trackShow: function() {
                        var t; - 1 !== (null == e || null == (t = e.stats_required) ? void 0 : t.indexOf(2)) && _c(2, e)
                    },
                    trackDismiss: function() {
                        var t; - 1 !== (null == e || null == (t = e.stats_required) ? void 0 : t.indexOf(4)) && _c(4, e)
                    },
                    trackClick: function(t) {
                        var n; - 1 !== (null == e || null == (n = e.stats_required) ? void 0 : n.indexOf(1)) && _c(1, e, t)
                    }
                }
            };

            function jc(e, t) {
                var n;
                return {
                    buttonText: e.text,
                    icon: 75 === (null == (n = e.icon) ? void 0 : n.badge_type) ? "generic-premium-plus" : void 0,
                    dataQA: 47 === e.product_type ? {
                        "data-qa": "premium-plus-button"
                    } : void 0,
                    onClick: t
                }
            }
            var Ec = function(e) {
                    var t, n, o, r, s, c = e.promo,
                        u = e.chatUser,
                        d = e.chatInstanceId,
                        p = e.onAnimationOutComplete,
                        f = e.onPaymentSuccess,
                        h = (0, i.useState)(!0),
                        g = h[0],
                        m = h[1],
                        v = (0, i.useState)(!1),
                        A = v[0],
                        b = v[1],
                        x = kc(c),
                        C = x.trackDismiss,
                        _ = x.trackClick;
                    (0, i.useEffect)((function() {
                        g && (0, l.sx)(138, {
                            banner_id: 463,
                            position_id: 18,
                            context: 10
                        })
                    }), [g]);
                    var k = null == (t = c.buttons) ? void 0 : t.find((function(e) {
                            return 1 === e.type
                        })),
                        j = null == (n = c.buttons) ? void 0 : n.find((function(e) {
                            return 2 === e.type
                        })),
                        E = null == (o = c.buttons) ? void 0 : o.find((function(e) {
                            return 4 === e.type
                        }));
                    463 === c.promo_block_type && (E = j, j = void 0);
                    var O = null == (r = c.extra_texts) || null == (r = r.find((function(e) {
                        return 11 === e.type
                    }))) ? void 0 : r.text;
                    return (0, S.jsx)(_n.A, {
                        isVisible: g,
                        isDismissible: !1,
                        onAnimationOutComplete: p,
                        isPadded: !0,
                        children: (0, S.jsx)(bc, {
                            headerText: c.header,
                            text: c.mssg,
                            additionalText: c.credits_cost,
                            betweenButtonsText: O,
                            mediaImageSrc: y.A.getImageUrlForSize(null == (s = u.profile_photo) ? void 0 : s.large_url, 100, 100),
                            primaryButton: {
                                buttonText: null == k ? void 0 : k.text,
                                onClick: function() {
                                    b(!0), _(), (0, l.sx)(139, {
                                        banner_id: c.promo_block_type,
                                        position_id: c.promo_block_position,
                                        context: 10,
                                        call_to_action_type: 1
                                    }), _a.A.purchase({
                                        back: a.A.getUrl(),
                                        cost: c.payment_amount,
                                        hotPanelData: {
                                            activationPlace: 11,
                                            bannerId: 463,
                                            product: 47,
                                            cost: c.payment_amount
                                        },
                                        productType: c.ok_payment_product_type,
                                        purchaseTransactionSetup: {
                                            promoBlockType: c.promo_block_type
                                        },
                                        userId: d,
                                        success: f,
                                        error: function(e) {
                                            U.A.showNotification({
                                                text: e,
                                                type: U.A.TYPES.ERROR
                                            }), m(!1), b(!1)
                                        }
                                    })
                                },
                                dataQA: {
                                    "data-qa": "accept-button"
                                }
                            },
                            secondaryButton: j ? jc(j, (function() {
                                var e;
                                _(), (0, l.sx)(139, {
                                    banner_id: c.promo_block_type,
                                    position_id: c.promo_block_position,
                                    context: 10,
                                    call_to_action_type: 2
                                }), ns.A.navigateToPayment({
                                    back: a.A.getUrl(),
                                    hotPanelData: {
                                        activationPlace: 11,
                                        promoBlockType: c.promo_block_type
                                    },
                                    productToActivate: c.ok_payment_product_type,
                                    productType: null == (e = j) ? void 0 : e.product_type,
                                    promoBlockType: c.promo_block_type,
                                    userId: u.user_id
                                })
                            })) : void 0,
                            dismissButton: {
                                buttonText: E.text,
                                onClick: function() {
                                    var e;
                                    C(), (0, l.sx)(139, {
                                        banner_id: c.promo_block_type,
                                        position_id: c.promo_block_position,
                                        context: 10,
                                        call_to_action_type: null == (e = E) ? void 0 : e.type
                                    }), m(!1)
                                },
                                dataQA: {
                                    "data-qa": "decline-button"
                                }
                            },
                            isLoading: A
                        })
                    })
                },
                Oc = n(79069),
                Tc = n(32675),
                Pc = function(e) {
                    var t = e.question,
                        n = e.onClickGetQuestion,
                        o = e.onClickSendQuestion,
                        r = e.onClickClose,
                        s = e.onAnimationInComplete,
                        a = e.onAnimationOutComplete,
                        c = (0, i.useState)(!0),
                        l = c[0],
                        u = c[1];
                    return (0, S.jsx)(_n.A, {
                        isVisible: l,
                        onDismiss: r,
                        onAnimationInComplete: s,
                        onAnimationOutComplete: a,
                        hasDefaultDismissButton: !1,
                        children: (0, S.jsxs)("div", {
                            className: "questions-game",
                            children: [(0, S.jsx)("div", {
                                className: "questions-game__header",
                                children: (0, S.jsx)(un.P2, {
                                    align: "center",
                                    color: "black",
                                    children: m.Ay.get(127)
                                })
                            }), (0, S.jsx)("div", {
                                className: "questions-game__question",
                                children: (0, S.jsx)(un.Zb, {
                                    align: "center",
                                    color: "black",
                                    dangerous: !0,
                                    children: t
                                })
                            }), (0, S.jsx)("div", {
                                className: "questions-game__button",
                                children: (0, S.jsxs)(sa.A, {
                                    children: [(0, S.jsx)(Tc.A, {
                                        icon: "generic-spinning-arrows",
                                        text: m.Ay.get(125),
                                        styling: "alt",
                                        onClick: n
                                    }), (0, S.jsx)(go.A, {
                                        icon: "generic-send",
                                        text: m.Ay.get(126),
                                        onClick: function() {
                                            o(), u(!1)
                                        },
                                        dataQA: {
                                            "data-qa": "action-send"
                                        }
                                    }), (0, S.jsx)(go.A, {
                                        text: m.Ay.get(270),
                                        onClick: function() {
                                            r(), u(!1)
                                        },
                                        semantic: "tertiary",
                                        dataQA: {
                                            "data-qa": "modal-close"
                                        }
                                    })]
                                })
                            })]
                        })
                    })
                },
                Ic = function(e) {
                    var t, n, o, r, s = e.userGender,
                        a = e.chatUserGender,
                        c = e.chatUserName,
                        l = e.isReceiver,
                        u = e.onClose,
                        d = e.onAnimationInComplete,
                        p = (0, i.useState)(!0),
                        f = p[0],
                        h = p[1],
                        g = (0, i.useState)("close"),
                        v = g[0],
                        A = g[1],
                        y = function(e) {
                            e && A("continue"), h(!1)
                        };
                    return l ? (t = m.Ay.get(123, {
                        str: c
                    }), n = m.Ay.get(121, {
                        me: Ie.ko.for("me", s),
                        other_user: Ie.ko.for("other_user", a)
                    }), o = m.Ay.get(119), r = y) : (t = m.Ay.get(124), n = m.Ay.get(122, {
                        name: c
                    }), o = m.Ay.get(120), r = function() {
                        return y(!0)
                    }), (0, S.jsx)(_n.A, {
                        isVisible: f,
                        onAnimationInComplete: d,
                        onAnimationOutComplete: function() {
                            return u(v)
                        },
                        isPadded: !0,
                        children: (0, S.jsxs)(co.A, {
                            isCompact: !0,
                            align: "start",
                            children: [(0, S.jsx)(lo.A, {
                                size: "icon",
                                children: (0, S.jsx)(cn.A, {
                                    name: "badge-feature-questions-game"
                                })
                            }), (0, S.jsx)(uo.A, {
                                text: t,
                                tag: "h2"
                            }), (0, S.jsx)(po.A, {
                                text: n
                            }), (0, S.jsx)(fo.A, {
                                children: (0, S.jsx)(go.A, {
                                    narrow: !0,
                                    text: o,
                                    onClick: r
                                })
                            })]
                        })
                    })
                },
                wc = n(40289),
                Rc = n(71859),
                Mc = n(7960),
                Nc = n(66130),
                Uc = function(e) {
                    var t, n = e.chatUserName,
                        o = e.chatUserGender,
                        r = e.question,
                        s = e.altNavigation,
                        a = e.isInstant,
                        c = e.isMessageFromCurrentUser,
                        l = e.onFocusInput,
                        u = e.onBlurInput,
                        d = e.onClickClose,
                        p = e.onClickSend,
                        f = e.onAnimationInComplete,
                        h = e.onAnimationOutComplete,
                        g = e.appear,
                        v = void 0 === g || g,
                        A = (0, i.useRef)(null),
                        y = m.Ay.get(110),
                        b = m.Ay.get(109),
                        C = (0, i.useRef)(new wc.A),
                        _ = (0, i.useRef)(null),
                        k = (0, i.useState)(!0),
                        j = k[0],
                        E = k[1],
                        O = (0, i.useState)(!1),
                        T = O[0],
                        P = O[1],
                        I = (0, i.useState)(""),
                        w = I[0],
                        R = I[1],
                        M = (0, i.useState)(""),
                        N = M[0],
                        U = M[1];
                    t = c ? a ? m.Ay.get(115) : m.Ay.get(114) : m.Ay.get(113, {
                        name: Ie.ko.for(n, o)
                    });
                    var D = (0, i.useCallback)((function() {
                            d(), E(!1)
                        }), [d]),
                        B = function() {
                            var e;
                            T ? (p(w), E(!1)) : (U(m.Ay.get(111)), null == A || null == (e = A.current) || e.focus())
                        },
                        L = function(e) {
                            var t = e.target.value;
                            P(t.length > 0), R(t)
                        },
                        F = [{
                            type: x.X2.CLOSE,
                            onClick: D
                        }];
                    s && F.push({
                        type: x.$4.BUTTON,
                        text: y,
                        onClick: B
                    }), (0, i.useEffect)((function() {
                        var e = C.current;
                        return e && null != _ && _.current && (e.update({
                                onDismiss: D,
                                contentWrapper: _.current
                            }), e.modalize(), e.updateFocusableElements(), e.toggleFocusTrap(!0)),
                            function() {
                                null == e || e.unmount()
                            }
                    }), [D, C]);
                    return (0, S.jsx)(Rc.A, {
                        children: (0, S.jsx)(Ue.A, {
                            appear: v,
                            in: j,
                            timeout: 300,
                            classNames: j ? "forward" : "backward",
                            mountOnEnter: !0,
                            unmountOnExit: !0,
                            onEntered: function() {
                                var e;
                                null == A || null == (e = A.current) || e.focus(), f && f()
                            },
                            onExited: h,
                            children: function() {
                                return (0, S.jsx)("div", {
                                    className: "page-container",
                                    id: "page-container",
                                    children: (0, S.jsx)("div", {
                                        className: "page overlay-page questions-game-answer",
                                        ref: _,
                                        role: "dialog",
                                        "aria-modal": !0,
                                        tabIndex: -1,
                                        "aria-label": t,
                                        children: (0, S.jsxs)(ds.A, {
                                            children: [(0, S.jsx)(hs.A, {
                                                children: (0, S.jsx)(x.Ay, {
                                                    actions: F,
                                                    position: "absolute",
                                                    transparent: !0
                                                })
                                            }), (0, S.jsxs)(ps.A, {
                                                vpadded: !0,
                                                align: "stretch",
                                                hpadded: !0,
                                                children: [(0, S.jsx)("div", {
                                                    className: "questions-game-answer-title",
                                                    children: (0, S.jsx)(un.P1, {
                                                        align: "center",
                                                        color: "black",
                                                        tag: "h2",
                                                        children: t
                                                    })
                                                }), (0, S.jsx)("div", {
                                                    className: "questions-game-answer-question",
                                                    children: (0, S.jsx)(un.Zb, {
                                                        align: "center",
                                                        color: "black",
                                                        children: r
                                                    })
                                                }), (0, S.jsx)("div", {
                                                    className: "questions-game-answer-input",
                                                    children: (0, S.jsxs)(mo.A, {
                                                        onSubmit: function(e) {
                                                            return (0, ao.Y4)(e, B)
                                                        },
                                                        isFixed: !0,
                                                        children: [(0, S.jsx)(Mc.A, {
                                                            label: m.Ay.get(112),
                                                            onChange: L,
                                                            onFocus: l,
                                                            onBlur: u,
                                                            autoResize: !0,
                                                            value: w,
                                                            fieldId: "feedback-input",
                                                            textareaRef: A,
                                                            maxHeight: 200,
                                                            errorMessage: N,
                                                            a11y: {
                                                                ariaRequired: !0
                                                            }
                                                        }), s ? null : (0, S.jsx)(Nc.A, {
                                                            children: (0, S.jsx)(go.A, {
                                                                buttonAttrs: {
                                                                    type: "submit"
                                                                },
                                                                text: b
                                                            })
                                                        })]
                                                    })
                                                })]
                                            })]
                                        })
                                    })
                                })
                            }
                        })
                    })
                },
                Dc = function() {
                    (0, l.sx)(258, {
                        element: 1381
                    })
                },
                Bc = function() {
                    (0, l.sx)(258, {
                        element: 1382
                    })
                },
                Lc = function() {
                    (0, l.sx)(258, {
                        element: 1377
                    })
                },
                Fc = {
                    send: 253,
                    question: 1360,
                    close: 51
                },
                Gc = function(e) {
                    (0, l.sx)(332, {
                        element: Fc[e],
                        parent_element: 1377
                    })
                },
                Vc = function() {
                    (0, l.sx)(258, {
                        element: 1289
                    })
                },
                qc = function(e) {
                    (0, l.sx)(332, {
                        element: "close" === e ? 51 : 253,
                        parent_element: 1289
                    })
                },
                Hc = X.A.getLogger("Questions Game"),
                Qc = function(e) {
                    var t = e.message,
                        n = e.chatUser,
                        o = e.isAnswer,
                        r = e.isAnswerInstant,
                        s = e.isOnboarding,
                        a = e.isOnboardingReceiver,
                        c = e.onDismissOnboarding,
                        u = e.onShowAnswer,
                        d = e.onCloseAnswer,
                        f = e.onClose,
                        h = (0, i.useState)({
                            text: " \n "
                        }),
                        g = h[0],
                        v = h[1],
                        A = (0, i.useState)(s),
                        y = A[0],
                        b = A[1],
                        x = (0, i.useRef)([]),
                        C = he.A.getUser(),
                        _ = (0, m.Bt)(C.gender),
                        k = (0, m.Bt)(n.getGender()),
                        j = n.getName(),
                        E = (0, i.useCallback)((function() {
                            var e = x.current.length - 1,
                                t = x.current.findIndex((function(e) {
                                    return e.id === g.id
                                })); - 1 !== t && t < e ? v(x.current[t + 1]) : t === e && v(x.current[0]), Gc("question")
                        }), [g.id]),
                        O = function() {
                            return (null == t ? void 0 : t.fromPersonId) === C.user_id
                        };
                    (0, i.useEffect)((function() {
                        new Pe.Ay(537, {
                            context: 264,
                            other_user_id: n.getUserId()
                        }).onResponse(538, (function(e) {
                            Array.isArray(e.questions) && e.questions.length && (x.current = e.questions, v(e.questions[0]))
                        })).onError((function(e) {
                            (0, Z.A)(e) && Hc.error("Error while getting questions", {
                                error: e
                            })
                        })).request()
                    }), []);
                    var T = (0, S.jsx)(Pc, {
                        question: g.text,
                        onClickGetQuestion: E,
                        onClickSendQuestion: function() {
                            var e = new F.Ay({
                                messageType: 50,
                                question: {
                                    id: g.id
                                }
                            }, n);
                            p.A.send(n.getUserId(), e).then((function(e) {
                                setTimeout((function() {
                                    u(e, !0)
                                }), 400)
                            })).catch((function(e) {
                                (0, Z.A)(e) && Hc.error("Error while sending questions game message", {
                                    error: e
                                })
                            })), Gc("send")
                        },
                        onClickClose: function() {
                            return Gc("close")
                        },
                        onAnimationInComplete: Lc,
                        onAnimationOutComplete: f
                    });
                    return y && (T = (0, S.jsx)(Ic, {
                        userGender: _,
                        chatUserGender: k,
                        chatUserName: j,
                        isReceiver: a,
                        onClose: function(e) {
                            "continue" === e ? (b(!1), c()) : f(), a ? function(e) {
                                (0, l.sx)(332, {
                                    element: "continue" === e ? 395 : 51,
                                    parent_element: 1382
                                })
                            }(e) : function(e) {
                                (0, l.sx)(332, {
                                    element: "continue" === e ? 395 : 51,
                                    parent_element: 1381
                                })
                            }(e)
                        },
                        onAnimationInComplete: a ? Bc : Dc
                    })), t && o && (T = (0, S.jsx)(Uc, {
                        question: t.question.text,
                        chatUserName: j,
                        chatUserGender: k,
                        altNavigation: pe.A.isIOs,
                        isInstant: r,
                        isMessageFromCurrentUser: O(),
                        onFocusInput: function() {
                            setTimeout((function() {
                                (0, M.A)(".page.questions-game-answer").addClass("not-stretched-layout")
                            }))
                        },
                        onBlurInput: function() {
                            setTimeout((function() {
                                (0, M.A)(".page.questions-game-answer").removeClass("not-stretched-layout")
                            }))
                        },
                        onClickClose: function() {
                            qc("close")
                        },
                        onClickSend: function(e) {
                            p.A.sendQuestionsGameAnswer(t, e, O()), qc("send")
                        },
                        onAnimationInComplete: Vc,
                        onAnimationOutComplete: d
                    })), T
                },
                Yc = n(16720),
                Wc = n(13736),
                zc = function(e) {
                    var t = e.lexemes,
                        n = e.actions,
                        i = [{
                            text: t.acceptButton,
                            semantic: "primary",
                            onClick: n.onAcceptClick
                        }, {
                            text: t.cancelButton,
                            semantic: "tertiary",
                            onClick: n.onCancelClick
                        }];
                    return (0, S.jsx)(Wc.A, {
                        title: t.title,
                        description: t.description,
                        icon: "badge-gift",
                        actions: i
                    })
                },
                Kc = function(e) {
                    var t = e.name,
                        n = e.onAcceptClick,
                        i = e.onCancelClick,
                        o = {
                            title: m.Ay.get(241),
                            description: m.Ay.get(242, {
                                name: t
                            }),
                            acceptButton: m.Ay.get(239),
                            cancelButton: m.Ay.get(240)
                        };
                    return (0, S.jsx)(zc, {
                        lexemes: o,
                        actions: {
                            onAcceptClick: n,
                            onCancelClick: i
                        }
                    })
                };

            function Jc(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function Xc(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Jc(Object(n), !0).forEach((function(t) {
                        Zc(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Jc(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function Zc(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var $c = X.A.getLogger("Chat"),
                el = "gift_push_",
                tl = (0, ae.A)(11);

            function nl(e) {
                return 3 === (null == e ? void 0 : e.getType())
            }

            function il(e) {
                var t = ne(e);
                return 19 === e.initialScreenType || 472 === (null == t ? void 0 : t.promo_block_type)
            }

            function ol(e) {
                var t = (null == e ? void 0 : e.getAlbums([])) || [];
                return t.length > 0 && !!t[0].getPhotos() && !nl(e)
            }

            function rl(e, t) {
                var n = null == t ? void 0 : t.some((function(e) {
                    return 10017 === e.getPromoBlockType()
                }));
                return nl(e) || pe.A.isTWA() || pe.A.isHuaweiQuickApp() || !n
            }
            var sl = function(e) {
                    var t, n = e.user,
                        o = e.chatUserId,
                        r = e.folderId,
                        v = e.streamId,
                        y = e.userSubstitute,
                        b = e.hotPanelData,
                        x = e.clientSource,
                        C = e.activationPlace,
                        _ = e.screenName,
                        k = e.wasBack,
                        T = e.notificationPermissionController,
                        w = e.scrollableElement,
                        M = e.onboardingTipsController,
                        N = e.onPreventNotifications,
                        D = e.onAllowNotifications,
                        B = e.jinba,
                        L = e.scrollPosition,
                        F = e.navigatedBack,
                        G = (0, i.useState)(!1),
                        V = G[0],
                        q = G[1],
                        H = (0, i.useState)(!1),
                        Q = H[0],
                        Y = H[1],
                        W = (0, i.useState)(!1),
                        z = W[0],
                        J = W[1],
                        X = (0, i.useState)(!0),
                        $ = X[0],
                        te = X[1],
                        ae = (0, i.useState)(!1),
                        he = ae[0],
                        ve = ae[1],
                        Ee = (0, i.useState)(!0),
                        Pe = Ee[0],
                        Ie = Ee[1],
                        we = (0, i.useState)([]),
                        Re = we[0],
                        Me = we[1],
                        Ne = (0, i.useState)([]),
                        Ue = Ne[0],
                        De = Ne[1],
                        Be = (0, i.useState)(),
                        Le = Be[0],
                        Fe = Be[1],
                        Ge = (0, i.useState)(),
                        Ve = Ge[0],
                        qe = Ge[1],
                        He = (0, i.useState)(!0),
                        Qe = He[0],
                        Ye = He[1],
                        We = (0, i.useState)(n),
                        ze = We[0],
                        Ke = We[1],
                        Xe = (0, i.useState)(!1),
                        Ze = Xe[0],
                        $e = Xe[1],
                        et = (0, i.useState)(""),
                        tt = et[0],
                        nt = et[1],
                        it = (0, i.useState)(),
                        ot = it[0],
                        rt = it[1],
                        st = (0, i.useState)(!1),
                        at = st[0],
                        ct = st[1],
                        lt = (0, i.useState)(C),
                        ut = lt[0],
                        dt = lt[1],
                        pt = (0, i.useState)({}),
                        ft = pt[0],
                        ht = pt[1],
                        gt = (0, i.useState)(),
                        mt = gt[0],
                        vt = gt[1],
                        At = (0, i.useState)(!1),
                        yt = At[0],
                        bt = At[1],
                        xt = (0, i.useState)(),
                        St = xt[0],
                        Ct = xt[1],
                        _t = (0, i.useState)(!1),
                        kt = _t[0],
                        jt = _t[1],
                        Et = (0, i.useState)(!1),
                        Ot = Et[0],
                        Tt = Et[1],
                        Pt = (0, i.useState)(!1),
                        It = Pt[0],
                        wt = Pt[1],
                        Rt = (0, i.useState)(!1),
                        Mt = Rt[0],
                        Nt = Rt[1],
                        Ut = (0, i.useState)(!1),
                        Dt = Ut[0],
                        Bt = Ut[1],
                        Lt = (0, i.useState)(!1),
                        Ft = Lt[0],
                        Gt = Lt[1],
                        Vt = (0, i.useState)(!1),
                        qt = Vt[0],
                        Ht = Vt[1],
                        Qt = (0, i.useState)(),
                        Yt = Qt[0],
                        Wt = Qt[1],
                        zt = (0, i.useState)(!1),
                        Kt = zt[0],
                        Jt = zt[1],
                        Xt = (0, i.useState)(!1),
                        Zt = Xt[0],
                        $t = Xt[1],
                        en = (0, i.useState)(!1),
                        tn = en[0],
                        nn = en[1],
                        on = (0, i.useState)(!1),
                        rn = on[0],
                        sn = on[1],
                        an = (0, i.useRef)(""),
                        cn = (0, i.useRef)(0),
                        ln = (0, i.useRef)(0),
                        un = (0, i.useRef)(0),
                        dn = (0, i.useRef)(),
                        pn = (0, i.useRef)(null),
                        fn = (0, i.useRef)(!1),
                        hn = (0, i.useRef)(!1),
                        gn = (0, i.useRef)(null),
                        mn = (0, i.useRef)(null),
                        vn = (0, i.useRef)(!1),
                        An = (0, i.useRef)(!1),
                        yn = (0, i.useRef)(!1),
                        bn = (0, i.useCallback)((function(e) {
                            var t, n, i, r, s, a, c, l, u, d, f, h = e.messages,
                                g = p.A.isUserReported(e.chatInstanceId),
                                m = h.some((function(e) {
                                    return e.isYours() || p.A.isYours(e)
                                })),
                                y = Xc(Xc({}, e), {}, {
                                    context: x,
                                    streamId: v,
                                    chatBlockedGiftPromo: (i = e.promoBanners, i.find((function(e) {
                                        return 24 === e.getPromoBlockType() && 6 === e.getPromoBlockPosition()
                                    })) || (null == Ve ? void 0 : Ve.chatBlockedGiftPromo)),
                                    gender: (0, A.v4)(e.gender),
                                    hasReceivedMessage: h.some((function(e) {
                                        return !e.isYours() || !p.A.isYours(e)
                                    })),
                                    initialScreen: g ? void 0 : e.initialScreen,
                                    sourceOfMessage: (0, xs.$1)(e),
                                    isSelectable: z,
                                    dismissInitialScreen: !1,
                                    isShowingCrushAnimation: !m && e.isShowingCrushAnimation,
                                    feedbackPromo: (t = e.promoBanners, n = t.find((function(e) {
                                        return 575 === e.getPromoBlockType()
                                    })), null == n ? void 0 : n.toJSON())
                                });
                            if (o) {
                                var b = I(o);
                                b && (y.replyToMessage = b)
                            }
                            return y.initialScreen || (y.dismissInitialScreen = !0), y.isChatBlocked = (c = (r = y).initialScreenType, l = !(null == (s = r.initialScreen) || !s.blockingFeature), u = null == (a = r.initialScreen) ? void 0 : a.promo, d = Te.includes(null == u ? void 0 : u.getPromoBlockType()), f = r.initialScreen && r.messages.length > 0, (0 === r.maxUnansweredMessages && r.chatBlockedGiftPromo || l || f || d) && !(7 === c)), y
                        }), [o, x, z, null == Ve ? void 0 : Ve.chatBlockedGiftPromo, v]),
                        xn = function() {
                            var e = p.A.getCachedClientOpenChat(o);
                            qe(bn(e))
                        },
                        Sn = (0, i.useCallback)((function(e) {
                            var t = bn(e),
                                n = e.counter > e.messages.length,
                                i = !yn.current && !t.isChatBlocked && !!e.isShowingOffensiveMessagesPrompt;
                            (an.current = e.chatInstanceId.toString(), i && (yn.current = !0), An.current) && (e.messages.some((function(e) {
                                return 50 === e.messageType
                            })) && (Nt(!0), setTimeout((function() {
                                Bt(!0)
                            }), 400)));
                            if (Ke(e.chatUser), Me(e.messages), De(e.promoBanners), ve(e.chatUser.getIsFavourite()), qe(t), Jt(i), n && (Ie(!1), te(!1)), le.A.hit(), le.A.isActive()) {
                                var o, r = t.isChatBlocked || t.deletedMember || il(t) || Boolean(ne(t)),
                                    s = 1e3 * Math.max.apply(null, e.messages.map((function(e) {
                                        return e.dateCreated
                                    }))),
                                    a = 0 === e.messages.length || (new Date).getTime() - s > 864e5,
                                    c = "1" === ce.Ay.get("" + el + t.userId),
                                    u = !t.isChatBlocked && !t.deletedMember && !t.isSelectable && !t.isNotInterested && (null == (o = t.inputSettingsItems) ? void 0 : o.length);
                                !r && a && !c && u ? (sn(!0), (0, l.sx)(138, {
                                    banner_id: 464,
                                    position_id: 8,
                                    context: 10
                                })) : sn(!1)
                            }
                            null == B || B.stop({
                                nameOverride: t.initialScreen ? "Chat/InitialScreen" : "Chat",
                                hotpanelTimerOverride: t.initialScreen ? 3 : 2
                            })
                        }), [bn, B]),
                        Cn = function() {
                            vt(void 0), a.A.updateLocation(c.x.MESSAGES, {
                                id: o
                            })
                        },
                        _n = function() {
                            Cn(), a.A.back()
                        },
                        kn = function(e) {
                            e && Ke(e)
                        },
                        jn = function(e) {
                            e && (Ke(e), ve(e.getIsFavourite()))
                        },
                        En = (0, i.useCallback)((function() {
                            var e = p.A.getCachedClientOpenChat(o);
                            e.dummy && ze && (e.chatUser = ze), Sn(e)
                        }), [ze, o, Sn]),
                        On = function(e, t) {
                            ! function(e, t) {
                                if (void 0 === t && (t = Se.MESSAGE), !Boolean(e.serverErrorMessage) || (0, Z.A)(e))
                                    if (e instanceof Ce.Qc) je.error("Rpc error on send chat message", {
                                        error: e,
                                        errorSource: t,
                                        RPCErrorType: ke[e.getType()] || ke[0]
                                    });
                                    else if (e.serverErrorMessage) {
                                    var n = "toJSON" in e.serverErrorMessage ? e.serverErrorMessage.toJSON() : e.serverErrorMessage;
                                    je.error("Server error on send chat message", {
                                        error: JSON.stringify(n),
                                        errorSource: t
                                    })
                                } else je.error("Unknown error on send chat message", {
                                    error: e,
                                    errorSource: t
                                })
                            }(e, t),
                            function(e) {
                                if (e instanceof Error) {
                                    var t = "" + e.message;
                                    (0, l.sx)(125, {
                                        event_type: 1,
                                        error_type: 12,
                                        error_message: "string" == typeof e ? e : t
                                    })
                                } else if (e instanceof ge.beZ) {
                                    var n = e.getErrorMessage();
                                    (0, l.sx)(125, {
                                        event_type: 1,
                                        error_type: me.A.getType(e.getType()),
                                        error_message: n
                                    })
                                }
                            }(e), En()
                        },
                        Tn = (0, i.useCallback)((function(e, t) {
                            if (!(e instanceof Error)) {
                                var n = null == e ? void 0 : e.getType();
                                return 14 === n || 42 === n ? (k || _e(e.getErrorMessage()), void a.A.back()) : 82 === n ? (k || _e(function(e, t) {
                                    var n = e.getErrorMessage();
                                    if (!n) {
                                        var i = t.getName();
                                        i && (n = 2 === t.getGender() ? m.Ay.get(482, {
                                            str: i
                                        }) : m.Ay.get(483, {
                                            str: i
                                        }))
                                    }
                                    return n
                                }(e, ze)), void a.A.back()) : void fe.A.handleError({
                                    error: e,
                                    screenName: xe(z, _, o),
                                    navigationBar: {
                                        logo: !0,
                                        actions: {}
                                    }
                                }, t)
                            }(0, Z.A)(e) && $c.error(e.message)
                        }), [ze, o, z, _, k]),
                        Pn = (0, i.useCallback)((function(e) {
                            void 0 === e && (e = {
                                allowConsumeChatUnblocker: !1
                            });
                            var t = {
                                allowConsumeChatUnblocker: e.allowConsumeChatUnblocker,
                                context: x,
                                folderId: r,
                                streamId: v,
                                user: y ? 3 : void 0
                            };
                            return p.A.getCachedClientOpenChat(o).dummy && q(!0), gn.current = (0, re.A)(p.A.getClientOpenChat(o, t)), gn.current.then((function(e) {
                                vn.current = !!M.getTooltipByType(46), An.current = !!M.getTooltipByType(53), Sn(e), q(!1)
                            })).catch((function(e) {
                                e instanceof re.k || Tn(e, Pn)
                            })), gn.current
                        }), [x, r, v, y, o, M, Sn, Tn]),
                        In = function() {
                            Za.A.getInstance().invalidate(), E.A.removeMessage(o), R(o.toString()), xn()
                        },
                        wn = function(e) {
                            var t = de.A.encodeRoute(a.A.getUrl(), {
                                paymentFlow: "2"
                            });
                            return e.context = x, e.streamId = v, e.repliedMessage = I(o.toString()), mn.current = (0, re.A)(p.A.send(o, e, t)), mn.current.then(In).catch((function(e) {
                                return e instanceof re.k || On(e), e
                            })), mn.current
                        },
                        Rn = function() {
                            var e;
                            y ? e = Promise.resolve(y) : (q(!0), e = f.A.getInstance().get({
                                id: o
                            }).then((function(e) {
                                var t = e[0];
                                return q(!1), new ue.A({
                                    userSubstitute: t.getUserSubstitute()
                                })
                            }))), e.then((function(e) {
                                a.A.navigate(c.x.PROMO_CARDS_GALLERY, {
                                    userSubstitute: e,
                                    context: 26
                                })
                            })).catch((function() {
                                q(!1), _e()
                            }))
                        },
                        Mn = (0, i.useCallback)((function() {
                            if (p.A.getCachedClientOpenChat(o).messages.some((function(e) {
                                    return e.allowLike
                                })) && !Kt) {
                                var e = M.getTooltipByType(46).text;
                                N(), ht({
                                    isActive: !0,
                                    text: e
                                })
                            }
                        }), [o, N, Kt, M]),
                        Nn = (0, i.useCallback)((function() {
                            h.A.getUserById({
                                id: o,
                                clientSource: 10,
                                folderType: 0
                            }).then((function(e) {
                                setTimeout(vt, 100, e)
                            })).catch((function(e) {
                                (0, Z.A)(e) && $c.error("Failed to get user by id", e), U.A.showNotification({
                                    type: U.A.TYPES.ERROR
                                })
                            })), a.A.updateLocation(c.x.CHAT_PROFILE, {
                                id: o
                            })
                        }), [o]),
                        Un = function() {
                            null != Ve && Ve.deletedMember || (nl(ze) ? Rn() : (p.A.hasInitialChatScreen(o) && p.A.invalidate(o), Nn()))
                        },
                        Dn = function(e) {
                            J(e), e && (0, l.sx)(49, {})
                        },
                        Bn = function() {
                            (0, l.sx)(425, {
                                activation_place: ut,
                                encrypted_user_id: o
                            }), a.A.back()
                        },
                        Ln = function() {
                            g.A.getInstance().removeUserFromFolder({
                                folder: 56,
                                uid: o
                            }).then((function() {
                                a.A.navigate(c.x.CONNECTIONS)
                            }))
                        };
                    (0, i.useEffect)((function() {
                        return function() {
                            var e;
                            null == (e = pn.current) || null == e.dismiss || e.dismiss(), ln.current && s.A.clearTimeout(ln.current), un.current && s.A.clearTimeout(un.current), cn.current && s.A.clearTimeout(cn.current)
                        }
                    }), []), (0, i.useEffect)((function() {
                        (!o || o.length < 20) && ($c.error("Cannot load chat page without a valid id", {
                            id: o
                        }), _e(), a.A.back())
                    }), [o]), (0, i.useEffect)((function() {
                        if (!C) {
                            var e = {
                                id: o,
                                clientSource: x,
                                streamId: v,
                                folderId: r,
                                userSubstitute: y,
                                activationPlace: null != b && b.inappId ? 165 : 1
                            };
                            a.A.updateLocation(c.x.MESSAGES, e)
                        }
                    }), [C, x, r, null == b ? void 0 : b.inappId, v, y, o]), (0, i.useEffect)((function() {
                        dt(function(e, t) {
                            return 4 === e ? 5 : 9 === e ? 10 : 94 === e ? 165 : 26 === e ? 191 : t
                        }(x, C))
                    }), [x, C]), (0, i.useEffect)((function() {
                        var e = function(e, t, n) {
                                ol(ze) && te(n >= t)
                            },
                            t = function(e) {
                                e.toPersonId && ![o, an.current].includes(e.toPersonId.toString()) || ((o ? I(o) : null) && ((0, l.sx)(332, {
                                    element: 288,
                                    parent_element: 289
                                }), o && R(o)), ol(ze) || e !== Re[0] || Ie(!0), e.isTemporary() || function(e, t, n) {
                                    var i, o;
                                    (0, l.sx)(8, {
                                        activation_place: t,
                                        encrypted_user_id: null == (i = e.toPersonId) ? void 0 : i.toString(),
                                        length: 1 === e.messageType && (null == (o = e.message) ? void 0 : o.length) || 0,
                                        message_first: 1 === n.length,
                                        message_first_replied: n.length > 1 && 1 === ye(n),
                                        send_giphy: 36 === e.messageType,
                                        send_heart: "ANIMATED_XP" === e.messageType,
                                        send_location: !1,
                                        send_photo: 19 === e.messageType,
                                        send_smile: 22 === e.messageType,
                                        send_sticker: 23 === e.messageType
                                    })
                                }(e, ut, Re), En())
                            },
                            n = function(e) {
                                e.fromPersonId && ![o, an.current].includes(e.fromPersonId.toString()) || (42 === e.messageType && bt(!0), e.isLikelyOffensive && null != Ve && Ve.isShowingOffensiveMessagesPrompt && Jt(!0), En())
                            },
                            i = function(e) {
                                46 !== e.type && 49 !== e.type || Pn()
                            };
                        return oe.A.getInstance().on(oe.A.Type.NOTIFICATION, i), p.A.on(p.A.EVENTS.FLUSH, Pn).on(p.A.EVENTS.HISTORY_UPDATED, e).on(p.A.EVENTS.MESSAGE_FROM_ME, t).on(p.A.EVENTS.MESSAGE_FROM_USER, n).on(p.A.EVENTS.CHAT_PROMO_HANDLED, En).on(p.A.EVENTS.SETTINGS_UPDATED, (function(e) {
                                e.show_offensive_messages_prompt && Jt(!0)
                            })),
                            function() {
                                p.A.off(p.A.EVENTS.FLUSH, Pn).off(p.A.EVENTS.HISTORY_UPDATED, e).off(p.A.EVENTS.MESSAGE_FROM_ME, t).off(p.A.EVENTS.MESSAGE_FROM_USER, n).off(p.A.EVENTS.CHAT_PROMO_HANDLED, En), oe.A.getInstance().off(oe.A.Type.NOTIFICATION, i)
                            }
                    }), [ut, ze, o, Pn, Re, En, D, M]), (0, i.useEffect)((function() {
                        var e, t;
                        return dn.current = (e = {
                                getClientSource: function() {
                                    return x
                                },
                                getStreamId: function() {
                                    return v
                                },
                                onSendMessage: function(e) {
                                    e && !e.isCanceled && On(e, Se.MULTIMEDIA)
                                }
                            }, t = P || K(e), document.getElementById("photo-form") || document.body.appendChild(t.zepto[0]), t), (0, d.cj)((function() {
                                var e, t = p.A.getCachedClientOpenChat(o),
                                    n = (0, u.A)(a.A.getHistory()),
                                    i = n && [c.x.GIFT, c.x.MULTIMEDIA].includes(n.routeName),
                                    r = t && !t.dummy && k && i;
                                En(),
                                    function() {
                                        var e = a.A.getLocation(),
                                            t = e.routeName,
                                            n = e.parameters;
                                        if ("2" === (null == n ? void 0 : n.paymentFlow)) {
                                            var i = Xc({}, n);
                                            delete i.paymentFlow, a.A.updateLocation(t, i), In()
                                        }
                                    }(),
                                    function() {
                                        var e = a.A.getLocation(),
                                            t = e.routeName,
                                            n = e.parameters;
                                        if ("1" === (null == n ? void 0 : n.paymentFlow) || "3" === (null == n ? void 0 : n.paymentFlow)) {
                                            if (!at) {
                                                var i = Xc({}, n);
                                                delete i.paymentFlow, a.A.updateLocation(t, i)
                                            }
                                        } else q(!1)
                                    }();
                                var l, d = I(o.toString());
                                if (null == (e = dn.current) || e.checkPendingMultimedia({
                                        replyToUid: null == d ? void 0 : d.id,
                                        replyToMessage: d
                                    }), ie.A.getInstance().getBackAction() === be && (ie.A.getInstance().getResult() === ie.A.RESULTS.PENDING && (q(!0), s.A.setTimeout(Pn, 4e4), l = !0), ie.A.getInstance().clear()), !l) {
                                    var f = {
                                        forceTrack: !0,
                                        id: o,
                                        activationPlace: C,
                                        clientSource: x,
                                        isUserSubstitute: nl(ze)
                                    };
                                    r ? Ae(f) : Pn().then((function() {
                                        return Ae(f)
                                    })).catch((function(e) {
                                        e instanceof re.k || (0, Z.A)(e) && $c.error("Error calling getClientOpenChat", {
                                            error: e
                                        })
                                    }))
                                }
                            })),
                            function() {
                                var e, t;
                                null == (e = gn.current) || e.cancel(), null == (t = mn.current) || t.cancel()
                            }
                    }), []), (0, i.useEffect)((function() {
                        null != Ve && Ve.isShowingCrushAnimation && !fn.current && ((0, l.sx)(258, {
                            element: 1711
                        }), fn.current = !0)
                    }), [null == Ve ? void 0 : Ve.isShowingCrushAnimation]), (0, i.useEffect)((function() {
                        !V && Ve && (!Oe.has(Ve.chatInstanceId) || Ve.isChatBlocked || il(Ve) ? il(Ve) && Oe.add(Ve.chatInstanceId) : Oe.remove(null == Ve ? void 0 : Ve.chatInstanceId))
                    }), [Ve, V]), (0, i.useEffect)((function() {
                        var e = null == Ve ? void 0 : Ve.inputSettingsItems;
                        if (null != e && e.length) {
                            var t = e.findIndex((function(e) {
                                return 13 === e.type
                            }));
                            wt(-1 !== t && !!Ve && !il(Ve))
                        }
                    }), [Ve]), (0, i.useEffect)((function() {
                        var e = !Ve || Boolean(Ve.initialScreen) && 0 !== Ve.maxUnansweredMessages;
                        vn.current && !e && (Mn(), vn.current = !1)
                    }), [Ve, Mn]), (0, i.useEffect)((function() {
                        a.A.getLocation().routeName === c.x.CHAT_PROFILE && Nn()
                    }), [Nn]), (0, i.useEffect)((function() {
                        return O.A.on(O.A.USER_BLOCKED, _n), O.A.on(O.A.USER_UNBLOCKED, kn), O.A.on(O.A.USER_REPORTED, kn), O.A.on(O.A.USER_FAVOURITED, jn), O.A.on(O.A.USER_QUICK_MESSAGE_SENT, kn),
                            function() {
                                O.A.off(O.A.USER_BLOCKED, _n), O.A.off(O.A.USER_UNBLOCKED, kn), O.A.off(O.A.USER_REPORTED, kn), O.A.off(O.A.USER_FAVOURITED, jn), O.A.off(O.A.USER_QUICK_MESSAGE_SENT, kn)
                            }
                    }));
                    var Fn = xe(z, _, o),
                        Gn = Ve ? ne(Ve) : void 0,
                        Vn = Ve ? function(e) {
                            var t, n = (null == e ? void 0 : e.promoBanners) || [],
                                i = e.dismissedPromoBanners || [],
                                o = n.find((function(e) {
                                    return ee.includes(e.getPromoBlockType())
                                }));
                            return o && !i.includes(o.getPromoBlockType()) && (t = o.toJSON()), t
                        }(Ve) : void 0,
                        qn = (null == Ve ? void 0 : Ve.dismissedPromoBanners) || [],
                        Hn = Ue.filter((function(e) {
                            return -1 === qn.indexOf(e.getPromoBlockType())
                        })),
                        Qn = yt || (null == Ve ? void 0 : Ve.isNotInterested),
                        Yn = (null == ze ? void 0 : ze.getName()) || "";

                    function Wn() {
                        jt(!1)
                    }
                    var zn = function() {
                            An.current = !1, M.dismissTooltip(10, 53)
                        },
                        Kn = function() {
                            void 0 !== ze && Bt(!0)
                        },
                        Jn = function(e, t) {
                            Wt(e), Gt(!0), Ht(Boolean(t)), Bt(!0)
                        };
                    return (0, S.jsxs)(i.Fragment, {
                        children: [Ve && ze ? (0, S.jsx)(ms, {
                            giftPushMessage: rn && !V ? (0, S.jsx)(Kc, {
                                name: Yn,
                                onAcceptClick: function() {
                                    nn(!0), sn(!1), (0, l.sx)(139, {
                                        banner_id: 464,
                                        position_id: 8,
                                        context: 10,
                                        call_to_action_type: 1
                                    })
                                },
                                onCancelClick: function() {
                                    sn(!1), ce.Ay.set("" + el + o, "1", {
                                        expiryDays: 1
                                    }), (0, l.sx)(139, {
                                        banner_id: 464,
                                        position_id: 8,
                                        context: 10,
                                        call_to_action_type: 4
                                    })
                                }
                            }) : null,
                            navigation: (0, S.jsx)(j, {
                                user: ze,
                                promos: Ue,
                                clientSource: x,
                                isHeaderProfileHidden: Pe && ol(ze),
                                isHidingVideoCall: rl(ze, Ue),
                                isFavourite: he,
                                isSelectable: z,
                                isUserSubstitute: nl(ze),
                                isShowingBlockingTip: Zt,
                                onDeleteChat: Ln,
                                onFavouriteUser: function() {
                                    ve(!he)
                                },
                                onOpenProfile: Un,
                                onToggleReport: Dn,
                                scrollRef: w
                            }),
                            miniProfile: $ && ol(ze) && !Ve.deletedMember ? (0, S.jsx)(Je.A, {
                                onChange: function(e) {
                                    Ie(e.isIntersecting)
                                },
                                children: (0, S.jsx)(Js, {
                                    user: ze,
                                    screenName: Fn,
                                    activationPlace: ut,
                                    onProfileClick: Un,
                                    sourceOfMessage: Ve.sourceOfMessage
                                })
                            }) : null,
                            messages: (0, S.jsx)(Go, {
                                chatInstanceId: Ve.chatInstanceId,
                                otherUserId: o,
                                chatUser: ze,
                                counter: Ve.counter,
                                isSelectable: z,
                                isAllowUrlParsing: Ve.isAllowUrlParsing,
                                isUserSubstitute: nl(ze),
                                isDummy: Ve.dummy,
                                messageLikeOnboarding: ft,
                                messages: Re,
                                promoBanners: Hn,
                                dismissedPromoBanners: qn,
                                scrollingContainerRef: w,
                                scroller: ot,
                                oldScrollPosition: F ? L : void 0,
                                isShowingOffensiveMessagesPrompt: !ft.isActive && Kt,
                                onTogglePd: Y,
                                onToggleReport: Dn,
                                onShowPromoCards: Rn,
                                onClickReadReceiptsPromoLink: function(e) {
                                    Fe(e), (0, l.sx)(332, {
                                        element: 1350
                                    })
                                },
                                onUpdateInput: xn,
                                onUpdateChat: En,
                                onConfirmResendInappropriate: wn,
                                onNewMessageNotification: function(e, t) {
                                    $e(e), t && nt(t)
                                },
                                onSetScroller: rt,
                                onUserBlocked: Bn,
                                onQuestionsGameStart: Kn,
                                onQuestionsGameAnswer: Jn,
                                onDismissOffensiveMessagesModal: function(e) {
                                    Jt(!1), p.A.setShowLikelyOffensivePrompt(o, !1), e && $t(!0)
                                }
                            }),
                            chatNudgePromo: Qn ? (0, S.jsx)(hc, {
                                chatUser: ze,
                                onDelete: Ln
                            }) : !Boolean(Ve.initialScreen) && (0, S.jsx)(pc, {
                                promoBlock: Gn,
                                chatInstanceId: Ve.chatInstanceId,
                                feedbackPromo: Ve.feedbackPromo,
                                chatUser: ze,
                                clientSource: x,
                                isBlocker: !Boolean(Ve.inputSettingsItems),
                                onClickQuestionsGame: Kn,
                                onCloseQuestionsGame: function() {
                                    if (An.current) {
                                        var e = M.getTooltipByType(53).text;
                                        Ct(e), Tt(!0)
                                    }
                                },
                                onReloadClientOpenChat: Pn,
                                onCloseChat: a.A.back
                            }),
                            newMessageNotification: (0, S.jsx)(Vo, {
                                text: tt,
                                isActive: Ze,
                                onClick: function() {
                                    null == ot || ot.scrollToBottom(!0), $e(!1)
                                }
                            }),
                            input: Ve.isChatBlocked || Ve.deletedMember || z || Qn || null == (t = Ve.inputSettingsItems) || !t.length ? null : (0, S.jsx)(rs, {
                                context: Ve.context,
                                streamId: Ve.streamId,
                                otherUserId: o,
                                inputFeatures: Ve.inputFeatures,
                                inputSettingsItems: Ve.inputSettingsItems,
                                replyToMessage: Ve.replyToMessage,
                                hasReceivedMessage: Ve.hasReceivedMessage,
                                scroller: ot,
                                chatUser: ze,
                                notificationPermissionController: T,
                                activationPlace: ut,
                                questionsGameTooltipText: St,
                                showQuestionsGameTooltip: Ot,
                                showQuestionsGameButton: It,
                                onHideAddBanner: function(e) {
                                    cn.current && (s.A.clearTimeout(cn.current), cn.current = 0), "focus" === e.type && Ye(!1)
                                },
                                onBlurInput: function() {
                                    cn.current = s.A.setTimeout((function() {
                                        return Ye(!0)
                                    }), 1e3), ln.current = s.A.setTimeout((function() {
                                        hn.current = !1
                                    }), 700)
                                },
                                onFocusInput: function() {
                                    hn.current = !0
                                },
                                onUpdateInput: xn,
                                onClickCamera: function() {
                                    un.current = s.A.setTimeout((function() {
                                        var e;
                                        pn.current = (null == (e = dn.current) ? void 0 : e.uploadMultimedia(o)) || null, pn.current && jt(!0)
                                    }), pe.A.isIphoneContextualMenu && hn.current ? 700 : 0)
                                },
                                onClickQuestionsGameButton: Kn,
                                onClickQuestionsGameTooltip: function() {
                                    Tt(!1), zn()
                                },
                                onToggleLoading: q,
                                onSendMessage: wn,
                                onChatRefresh: Pn,
                                onToggleTopup: ct,
                                onUploadAudio: function(e) {
                                    var t;
                                    null == (t = dn.current) || t.uploadAudio(o, e)
                                },
                                isExtraControlsVisible: tn
                            }),
                            ads: (0, S.jsx)(cs, {
                                isEnabled: Qe
                            }),
                            initialScreen: Ve && Boolean(Ve.initialScreen) || Ve.isChatBlocked ? (0, S.jsx)(Na, {
                                openChatData: Ve,
                                otherUserId: o,
                                clientSource: x,
                                log: $c,
                                messages: Re,
                                streamId: v,
                                chatUser: ze,
                                onDismiss: function() {
                                    En(), ol(ze) || Ie(!0)
                                },
                                onChatRefresh: Pn,
                                onSendMessage: wn,
                                onUserBlocked: Bn
                            }) : void 0,
                            scrollingContainerRef: w,
                            isLoading: V,
                            isHidingMessages: Boolean(Ve.initialScreen) && 0 !== Ve.maxUnansweredMessages,
                            isShowingCrushAnimation: Ve.isShowingCrushAnimation,
                            onDismissOnboarding: function() {
                                D(), ht({
                                    isActive: !1
                                }), M.dismissTooltip(10, 46)
                            },
                            isOnboarding: ft.isActive || Kt
                        }) : null, (0, S.jsx)(gc, {
                            isOpen: kt,
                            onCaptureClick: function() {
                                var e;
                                null == (e = pn.current) || e.onCaptureOptionClick(), Wn()
                            },
                            onChooseClick: function() {
                                var e;
                                null == (e = pn.current) || e.onChooseOptionClick(), Wn()
                            },
                            onCancelClick: Wn
                        }), Q ? (0, S.jsx)(Ac, {
                            chatInstanceId: o,
                            name: Yn,
                            onAnimationOutComplete: function() {
                                return Y(!1)
                            }
                        }) : null, Le && Vn ? (0, S.jsx)(Ec, {
                            promo: Vn,
                            chatUser: null == ze ? void 0 : ze.toJSON(),
                            chatInstanceId: o,
                            onAnimationOutComplete: function() {
                                return Fe(void 0)
                            },
                            onPaymentSuccess: function() {
                                Le && (Le.setStatus(Le.statusType), p.A.markChatPromoHandled(o, 463))
                            }
                        }) : null, mt ? (0, S.jsx)(yc.A, {
                            user: mt,
                            mode: Oc._.CHAT,
                            onVoteYes: function() {
                                if (mt) {
                                    var e = {
                                        user: mt,
                                        voteType: 2
                                    };
                                    tl.handleVote(e).then((function() {
                                        h.A.getUserById({
                                            id: mt.getUserId(),
                                            clientSource: 10,
                                            folderType: 0
                                        }).then(vt).catch((function(e) {
                                            return (0, se.ot)("Failed to get user by id", e)
                                        }))
                                    })).catch((function(e) {
                                        Yc.Ay
                                    }))
                                }
                            },
                            onSmile: function() {
                                tl.handleSmileSendChatMessage(mt).then(vt).catch((function(e) {
                                    return (0, se.ot)("Error when sending smile from Chat Profile", e)
                                }))
                            },
                            onChat: Cn,
                            onClose: Cn
                        }) : null, Dt ? (0, S.jsx)(Qc, {
                            message: Yt,
                            chatUser: ze,
                            isAnswer: Ft,
                            isAnswerInstant: qt,
                            isOnboarding: An.current,
                            isOnboardingReceiver: Mt,
                            onDismissOnboarding: zn,
                            onShowAnswer: Jn,
                            onCloseAnswer: function() {
                                Bt(!1), Gt(!1), Ht(!1), Wt(void 0)
                            },
                            onClose: function() {
                                Bt(!1)
                            }
                        }) : null]
                    })
                },
                al = n(79458),
                cl = n(56368);

            function ll(e, t) {
                return ll = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, ll(e, t)
            }
            var ul = function(e) {
                function t(t) {
                    var n;
                    return (n = e.call(this, t) || this).screenName = 20, n.activationPlace = 11, n.notificationPermissionController = new al.A({
                        place: ec.A.PLACE_CHAT,
                        activationPlace: 11
                    }), n.onboardingTipsController = cl.A.getInstance(), n.scrollableElement = void 0, n.preventNotifications = function() {
                        n.notificationScreenAccess = 3
                    }, n.allowNotifications = function() {
                        n.notificationScreenAccess = 1
                    }, n.jinba = new L.A("Chat", 2), n.notificationPermissionController.start(), n.scrollableElement = (0, i.createRef)(), n
                }
                var n, r;
                r = e, (n = t).prototype = Object.create(r.prototype), n.prototype.constructor = n, ll(n, r);
                var s = t.prototype;
                return s.componentDidMount = function() {
                    e.prototype.componentDidMount.call(this), this.onboardingTipsController.start(), this.onboardingTipsController.setContext(this.clientSource)
                }, s.componentWillUnmount = function() {
                    this.onboardingTipsController.stop(), this.scrollableElement.current && this.props.saveScrollPosition(this.scrollableElement.current.scrollTop)
                }, s.getClientSource = function() {
                    var e = 6 === Number(this.getParameter("folderId")),
                        t = !0 === o.A.getSync(163).enabled;
                    return e && t ? 127 : Number(this.getParameter("context")) || 10
                }, s.render = function() {
                    var e = this.getParameters(),
                        t = e.folderId,
                        n = e.streamId,
                        i = e.userSubstitute,
                        o = e.id,
                        r = e.hotPanelData,
                        s = e.chatUser,
                        a = this.props,
                        c = a.scrollPosition,
                        l = a.navigatedBack;
                    return this.addPageWrapper((0, S.jsx)(sl, {
                        scrollPosition: c,
                        navigatedBack: l,
                        user: s,
                        chatUserId: o || "",
                        folderId: Number(t) || 0,
                        streamId: n,
                        userSubstitute: i,
                        hotPanelData: r,
                        clientSource: this.getClientSource(),
                        activationPlace: this.activationPlace,
                        screenName: this.screenName,
                        wasBack: this.wasBack(),
                        notificationPermissionController: this.notificationPermissionController,
                        scrollableElement: this.scrollableElement,
                        onboardingTipsController: this.onboardingTipsController,
                        onPreventNotifications: this.preventNotifications,
                        onAllowNotifications: this.allowNotifications,
                        jinba: this.jinba
                    }), "chat")
                }, t
            }(r.A);
            ul.transition = !1, ul.notificationScreenAccess = void 0;
            var dl = ul
        },
        54433: function(e, t, n) {
            var i, o = n(57917),
                r = n(15566),
                s = o.A.extend({
                    useCache_: !1,
                    getRequestMessageType: 460,
                    getResponseMessageType: 461,
                    get: function(e) {
                        var t = (new r.agq).setPosition(e.position).setCount(e.count);
                        e.shownPromoBlocks && t.setShownPromoBlocks(e.shownPromoBlocks), e.excludePromoBlocks && t.setExcludePromoBlocks(e.excludePromoBlocks);
                        var n = (new r.qu1).setContext(e.context).setPromoBlockRequestParams([t]);
                        return s._super.get.call(this, n)
                    }
                }, "NextPromoBlocksModel");
            s.getInstance = function() {
                return i || (i = new s)
            }, t.A = s
        },
        69110: function(e, t, n) {
            n(52675), n(45700), n(2008), n(51629), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(3949), n(23500);
            var i = n(96540),
                o = n(65297),
                r = n(23336),
                s = n(74848);

            function a(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function c(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? a(Object(n), !0).forEach((function(t) {
                        l(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function l(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            t.A = function(e) {
                var t = (0, i.useState)(!1),
                    n = t[0],
                    a = t[1];

                function l() {
                    a(!0)
                }

                function u() {
                    a(!1)
                }
                return (0, i.useEffect)((function() {
                    return o.A.on(o.A.SHOW_MODAL, l), o.A.on(o.A.HIDE_MODAL, u),
                        function() {
                            o.A.off(o.A.SHOW_MODAL, l), o.A.off(o.A.HIDE_MODAL, u)
                        }
                }), []), (0, s.jsx)(r.A, c(c({}, e), {}, {
                    disabled: n
                }))
            }
        },
        73969: function(e, t, n) {
            n.d(t, {
                m: function() {
                    return i
                }
            });
            n(25276), n(27495);

            function i(e) {
                return e && e.toUpperCase().indexOf("FIXME_") < 0 ? e : ""
            }
        },
        84787: function(e, t, n) {
            n.r(t), n.d(t, {
                default: function() {
                    return Si
                }
            });
            n(52675), n(45700), n(89572), n(67945), n(84185), n(83851), n(81278), n(10287), n(28706), n(2008), n(50113), n(48980), n(51629), n(74423), n(25276), n(23792), n(62062), n(15086), n(26910), n(60739), n(2892), n(79432), n(26099), n(3362), n(21699), n(47764), n(98992), n(54520), n(72577), n(3949), n(81454), n(37550), n(23500), n(62953);
            var i = n(96540),
                o = n(64741),
                r = n(89610),
                s = n(74022),
                a = n(99417),
                c = n(85558),
                l = n(41476),
                u = n(46942),
                d = n.n(u),
                p = n(1270),
                f = n(40075),
                h = n(73939),
                g = n(74848),
                m = function(e) {
                    var t = e.isVisible,
                        n = e.isFixed,
                        i = e.fixedHeight,
                        o = e.onClick,
                        r = d()({
                            "connections-update-button": !0,
                            "is-hidden": !t,
                            "is-fixed": n
                        }),
                        s = n ? {
                            top: i
                        } : void 0;
                    return (0, g.jsx)("div", {
                        className: r,
                        style: s,
                        "data-qa": "connections-update-button",
                        children: (0, g.jsx)("div", {
                            className: "connections-update-button__snackpill",
                            children: (0, g.jsx)(h.A, {
                                icon: "generic-chevron-down",
                                text: f.Ay.get(466),
                                onClick: o
                            })
                        })
                    })
                };

            function v(e, t) {
                return v = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, v(e, t)
            }
            var A = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).state = {
                            isFixed: !1
                        }, n.onScroll = n.onScroll.bind(n), n
                    }
                    var n, i;
                    i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, v(n, i);
                    var o = t.prototype;
                    return o.getSnapshotBeforeUpdate = function(e) {
                        return !e.isVisible && this.props.isVisible ? this.getButtonPosition() : null
                    }, o.componentDidUpdate = function(e, t, n) {
                        !e.isVisible && this.props.isVisible ? (null !== n && this.updatePosition(n), a.A.addEventListener("scroll", this.onScroll)) : !this.props.isVisible && e.isVisible && a.A.removeEventListener("scroll", this.onScroll)
                    }, o.componentWillUnmount = function() {
                        a.A.removeEventListener("scroll", this.onScroll)
                    }, o.onScroll = function() {
                        this.updatePosition(this.getButtonPosition())
                    }, o.getButtonPosition = function() {
                        return (0, p.A)(this.props.containerRef.current).offset().top - a.A.scrollY
                    }, o.updatePosition = function(e) {
                        var t = e <= this.props.fixedHeight;
                        this.setState({
                            isFixed: t
                        })
                    }, o.render = function() {
                        return (0, g.jsx)(m, {
                            isVisible: this.props.isVisible,
                            isFixed: this.state.isFixed,
                            fixedHeight: this.props.fixedHeight,
                            onClick: this.props.onClick
                        })
                    }, t
                }(i.Component),
                y = n(60414),
                b = n(33815),
                x = n(47901),
                S = n(87184),
                C = n(15376),
                _ = n(36693),
                k = function(e) {
                    var t = d()({
                            "chat-connections-fader": !0,
                            "is-dark": e.isDark
                        }),
                        n = e.onClick ? "button" : "div";
                    return (0, g.jsx)(n, {
                        className: t,
                        onClick: e.onClick
                    })
                },
                j = function(e) {
                    var t, n = e.emptyPromo,
                        o = e.showFullscreenPromo,
                        r = e.deleteButton,
                        s = e.hasUsers,
                        a = e.isLoading,
                        c = e.isEditing,
                        l = e.isFrozen,
                        u = e.hasMatchBarStories,
                        p = e.matchBar,
                        h = e.connectionsList,
                        m = e.containerRef,
                        v = e.screenRef,
                        j = e.onClickNewActivityButton,
                        E = e.navigation,
                        O = e.sortOptionsButton,
                        T = e.securityWalkthroughModal,
                        P = e.currentTab,
                        I = e.modalRef,
                        w = e.isReporting,
                        R = e.reportingId,
                        M = e.reportAction,
                        N = void 0 === M ? "report" : M,
                        U = e.onReportingClose,
                        D = e.onReportingSuccess,
                        B = (0, i.useRef)(null),
                        L = (0, i.useRef)(null),
                        F = !s && n;
                    return (0, g.jsxs)("div", {
                        ref: m,
                        children: [w ? (0, g.jsx)(y.A, {
                            clientSource: 253,
                            otherUserId: R,
                            action: N,
                            onClose: U,
                            onReport: D,
                            onBlock: D
                        }) : null, (0, g.jsx)("div", {
                            role: c ? "dialog" : void 0,
                            "aria-modal": c,
                            "aria-label": f.Ay.get(440),
                            ref: I,
                            tabIndex: -1,
                            children: (0, g.jsxs)(x.A, {
                                innerRef: v,
                                children: [(0, g.jsx)(C.A, {
                                    isSticky: !0,
                                    children: (0, g.jsxs)("div", {
                                        ref: B,
                                        children: [E, o ? null : (0, g.jsx)(i.Fragment, {
                                            children: (0, g.jsxs)("div", {
                                                className: d()("connections__match-bar", {
                                                    "connections__match-bar--stories": u
                                                }),
                                                inert: c ? "" : void 0,
                                                children: [p, c ? (0, g.jsx)(k, {}) : null]
                                            })
                                        })]
                                    })
                                }), (0, g.jsxs)(S.A, {
                                    align: "stretch",
                                    children: [n && F ? (0, g.jsx)("div", {
                                        className: "connections-empty-container",
                                        "data-qa": "connections-empty",
                                        id: P + "_TABPANEL",
                                        tabIndex: -1,
                                        role: "tabpanel",
                                        "aria-labelledby": P + "_TAB",
                                        children: (0, g.jsxs)("div", {
                                            style: {
                                                margin: "auto 0"
                                            },
                                            children: [(0, g.jsx)(_.A, {
                                                top: "md",
                                                right: "gap",
                                                bottom: "md",
                                                left: "gap",
                                                children: n
                                            }), (0, g.jsx)("div", {
                                                className: "connections-gap"
                                            })]
                                        })
                                    }) : null, a ? (0, g.jsx)("div", {
                                        className: "connections__loader",
                                        children: (0, g.jsx)("div", {
                                            style: {
                                                width: 46,
                                                height: 46
                                            },
                                            children: (0, g.jsx)(b.A, {})
                                        })
                                    }) : null, F ? null : (0, g.jsxs)("div", {
                                        className: "connections__content",
                                        id: P + "_TABPANEL",
                                        tabIndex: -1,
                                        role: "tabpanel",
                                        "data-qa": "connections-content",
                                        "aria-labelledby": P + "_TAB",
                                        children: [O, (0, g.jsxs)("div", {
                                            className: "connections__items",
                                            children: [(0, g.jsx)("div", {
                                                ref: L,
                                                children: (0, g.jsx)(A, {
                                                    isVisible: l,
                                                    fixedHeight: null == (t = B.current) ? void 0 : t.clientHeight,
                                                    onClick: j,
                                                    containerRef: L
                                                })
                                            }), (0, g.jsx)("div", {
                                                className: "connections-items",
                                                children: h
                                            })]
                                        }), (0, g.jsx)("div", {
                                            className: "connections-gap"
                                        })]
                                    }), r]
                                })]
                            })
                        }), T]
                    })
                },
                E = (n(72712), n(69085), n(8872), n(47344)),
                O = n(58385),
                T = n(73090),
                P = n(74389),
                I = n(13264),
                w = n(47632),
                R = n(85608),
                M = n(41025),
                N = n(41051),
                U = n(53010),
                D = n(54433),
                B = n(20387),
                L = n(93529),
                F = n(23149),
                G = n(38337),
                V = n(44762),
                q = (n(27495), n(92065)),
                H = n(94767),
                Q = n(45998),
                Y = n(87019),
                W = n(26914),
                z = n(93827),
                K = Number(q.TOKEN_BRICK_SIZE_SM.replace("px", ""));

            function J(e) {
                var t, n, i, o, r, s, a = e.picture,
                    c = e.icon,
                    l = e.badgeType,
                    u = e.mark,
                    d = e.isGift;
                if (a && !a.disableMasking && (n = {
                        src: w.A.getImageUrlForSize(a.url, K)
                    }), null != a && a.disableMasking && (t = "squared", i = (0, g.jsx)("img", {
                        src: a.url,
                        alt: "",
                        width: K,
                        height: K
                    })), !a && c) switch (c) {
                    case "avatar-placeholder-male":
                        o = {
                            gender: "male"
                        };
                        break;
                    case "avatar-placeholder-female":
                        o = {
                            gender: "female"
                        };
                        break;
                    case "avatar-placeholder-unknown":
                        o = {
                            gender: "unknown"
                        };
                        break;
                    case "avatar-placeholder-invisible":
                        o = {
                            disguise: "invisible"
                        };
                        break;
                    default:
                        r = {
                            name: c
                        }
                }
                return l && !d && (s = {
                    icon: {
                        name: l
                    }
                }), "double-credits-badge" !== (null == u ? void 0 : u.type) || d || (s = {
                    mark: {
                        text: u.text
                    }
                }), (0, g.jsx)(W.A, {
                    shape: t,
                    size: "sm",
                    image: n,
                    icon: r,
                    user: o,
                    content: i,
                    badge: s
                })
            }

            function X(e) {
                var t = e.titleText,
                    n = e.descriptionText,
                    o = e.smallText,
                    r = e.cost,
                    s = e.action,
                    a = e.isGift;
                return (0, g.jsxs)(i.Fragment, {
                    children: [t ? (0, g.jsx)("div", {
                        className: "people-nearby-feature-card__title",
                        children: (0, g.jsx)(z.P2, {
                            breakWords: !0,
                            children: t
                        })
                    }) : null, n ? (0, g.jsx)("div", {
                        className: "people-nearby-feature-card__text",
                        children: o && !a ? (0, g.jsx)(z.P3, {
                            breakWords: !0,
                            dangerous: !0,
                            children: n
                        }) : (0, g.jsx)(z.P2, {
                            breakWords: !0,
                            dangerous: !0,
                            children: n
                        })
                    }) : null, r && !a ? (0, g.jsx)("div", {
                        className: "people-nearby-feature-card__cost",
                        children: (0, g.jsx)(z.P3, {
                            color: "gray-80",
                            children: r
                        })
                    }) : null, s ? (0, g.jsx)("div", {
                        className: "people-nearby-feature-card__action js-action",
                        children: (0, g.jsx)(z.P2, {
                            color: "primary",
                            children: s.text
                        })
                    }) : null]
                })
            }
            var Z = function(e) {
                    var t = e.picture,
                        n = e.icon,
                        i = e.badgeType,
                        o = e.mark,
                        r = e.titleText,
                        s = e.descriptionText,
                        a = e.smallText,
                        c = e.cost,
                        l = e.action,
                        u = e.isGift;
                    return e.isSkeleton ? (0, g.jsx)("div", {
                        className: "people-nearby-feature-card",
                        children: (0, g.jsxs)(H.A, {
                            children: [(0, g.jsx)(Y.A, {
                                children: (0, g.jsx)("div", {
                                    className: "people-nearby-feature-card__skeleton-media"
                                })
                            }), (0, g.jsx)(Q.A, {
                                children: (0, g.jsx)("div", {
                                    className: "people-nearby-feature-card__skeleton-text"
                                })
                            })]
                        })
                    }) : (0, g.jsx)("div", {
                        className: "people-nearby-feature-card js-click-action",
                        "data-qa-feature-card": "",
                        children: (0, g.jsxs)(H.A, {
                            children: [(0, g.jsx)(Y.A, {
                                children: J({
                                    picture: t,
                                    icon: n,
                                    badgeType: i,
                                    mark: o,
                                    isGift: u
                                })
                            }), (0, g.jsx)(Q.A, {
                                children: X({
                                    titleText: r,
                                    descriptionText: s,
                                    smallText: a,
                                    cost: c,
                                    action: l,
                                    isGift: u
                                })
                            })]
                        })
                    })
                },
                $ = n(69110),
                ee = {
                    CLICK: "CLICK"
                },
                te = G.A.extend({
                    events: {
                        "click .js-click-action": "onClick_"
                    },
                    update: function(e) {
                        if (te._super.update.apply(this, arguments), (0, F.A)(e.picture))
                            if (e.externalAd) {
                                var t = U.A.create(U.A.placements.CONNECTIONS);
                                this._reactViewId = this.renderReactView((0, g.jsx)($.A, {
                                    adSlot: t,
                                    dataQa: "connections",
                                    innerRef: this.renderExternalAds
                                }), this.el)
                            } else this.render({
                                picture: e.picture,
                                icon: e.icon,
                                titleText: e.title,
                                descriptionText: e.text,
                                badgeType: e.badgeType,
                                mark: e.mark,
                                ready: e.ready,
                                isGift: e.isGift,
                                processing: e.processing
                            })
                    },
                    render: function(e) {
                        this.$el.html((0, V.A)("PeopleNearbyFeatureCard", Z).render(e))
                    },
                    onClick_: function() {
                        this.trigger(ee.CLICK)
                    },
                    reset: function() {
                        return this.reactViewId_ && this.removeReactView(this.reactViewId_), te._super.reset.apply(this, arguments)
                    },
                    renderExternalAds: function(e) {
                        e && U.A.render()
                    }
                }, "SimplePromoBlockView");
            te.EVENTS = ee;
            var ne = te,
                ie = n(3208),
                oe = ne.EVENTS,
                re = {
                    MAIN: "main"
                },
                se = I.A.extend({
                    construct: function(e, t) {
                        se._super.construct.call(this), this.name = e, this.data_ = t;
                        var n = new ne;
                        n.on(ne.EVENTS.CLICK, this.onClick_, this), this.registerView(re.MAIN, n), this.render()
                    },
                    getPromoBlock: function() {
                        return this.data_.promoBlock
                    },
                    isExternalAd: function() {
                        return this.data_.externalAd
                    },
                    render: function() {
                        var e = Object.assign({}, this.data_, {
                            processing: this.processing_
                        });
                        this.updateView(re.MAIN, e)
                    },
                    setParent: function(e) {
                        this.parent = e, this.getView(re.MAIN).appendTo(e)
                    },
                    onClick_: function() {
                        this.processing_ || (ie.A.generate(), this.trigger(oe.CLICK, this.getPromoBlock()))
                    },
                    setProcessing: function(e) {
                        this.processing_ = e, this.render()
                    }
                }, "SimplePromoBlockController");
            se.EVENTS = oe, se.VIEWS = re;
            var ae, ce = se,
                le = n(79860);

            function ue(e, t) {
                return ue = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, ue(e, t)
            }
            var de = [131, 129, 130, 326, 346],
                pe = ((ae = {})[B.A.TYPES.MESSAGES] = 26, ae[B.A.TYPES.FAVOURITES] = 23, ae[B.A.TYPES.WANT_TO_MEET_YOU] = 6, ae[B.A.TYPES.VISITORS] = 22, ae),
                fe = function(e) {
                    function t(t) {
                        var n, i = t.onPromoClick,
                            r = t.getActivationPlace,
                            s = t.getElementType,
                            a = t.getFolderType,
                            c = t.setIsShowingSecurityWalkthrough;
                        return (n = e.call(this, {}) || this).onPromoClick = void 0, n.getActivationPlace = void 0, n.getElementType = void 0, n.getFolderType = void 0, n.setIsShowingSecurityWalkthrough = void 0, n.nextPromoControllerId = 0, n.nextPromoIndex = 0, n.batchedActivities = {}, n.promos = [], n.resetPromoBlockControllers = !0, n.shouldResetShownBlocks = !1, n.usersBeforeNextPromo = 2, n.invisiblePromo = void 0, n.onPromoClick = i, n.getActivationPlace = r, n.getElementType = s, n.getFolderType = a, n.setIsShowingSecurityWalkthrough = c, n._onPromoClick = (0, o.A)(n._onPromoClick, 500, {
                            leading: !0,
                            trailing: !1
                        }), n
                    }
                    var n, i;
                    i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, ue(n, i), t.sendStatisticsOnBannerPushed_ = function(e) {
                        if (me(e)) {
                            var t = {
                                variantId: e.variant_id,
                                event: 2,
                                context: 127,
                                promoBlockPosition: 1
                            };
                            N.A.sendProfileQuestionsBannerStats(t)
                        }
                    };
                    var r = t.prototype;
                    return r.reset = function() {
                        this.batchedActivities = {}, this.promos = [], this.nextPromoIndex = 0, this.usersBeforeNextPromo = 2, this.resetPromoBlockControllers = !0
                    }, r.getInvisiblePromo = function() {
                        return this.invisiblePromo
                    }, r.getShownPromoBlocks = function() {
                        return this.shouldResetShownBlocks && (this.promos = [], this.nextPromoIndex = 0, this.shouldResetShownBlocks = !1), l.Ay.getControllers().filter((function(e) {
                            return e.object.getPromoBlock()
                        })).map((function(e) {
                            return e.object.getPromoBlock().promo_block_type
                        }))
                    }, r.setPromoBlocks = function(e) {
                        var t = e.promos;
                        null != t && t.length && this.setPromos(t)
                    }, r.process = function(e) {
                        var t, n = this,
                            i = e.items,
                            o = e.clientUserList,
                            r = e.isUpdates,
                            s = o.getPromoBlockResponseParams();
                        null != s && null != (t = s[0]) && t.getResetShownPromoBlocks() && (this.shouldResetShownBlocks = !0);
                        var a = o.toJSON().promo_banners;
                        if (null != a && a.length) {
                            var c = a.find((function(e) {
                                return 4 === e.promo_block_position
                            }));
                            c && (r && l.Ay.hasTopMostPromo() ? l.Ay.replaceTopMostPromo(c) : this.addPromoBlock(i, c)), r || a.forEach((function(e) {
                                var t = e.promo_block_type;
                                de.includes(t) && n.addPromoBlock(i, e)
                            }));
                            var u = a.find((function(e) {
                                return 37 === e.promo_block_type
                            }));
                            this.invisiblePromo = u || this.invisiblePromo
                        }
                    }, r.processUsers = function(e) {
                        var t = this,
                            n = e.items;
                        e.users.forEach((function(e) {
                            n.push(e), t.batchedActivities[e.user_id] && n.push(t.batchedActivities[e.user_id])
                        }))
                    }, r.prependBanner = function(e) {
                        var t = l.Ay.getControllers()[0];
                        if (!t) return e;
                        var n = l.Ay.findIndex(t.object);
                        if (n + e.length > 9) {
                            var i = n + e.length - 9;
                            e = [].concat(e.slice(0, i), [this.registerPromoController(this.getNextPromo())], e.slice(i))
                        }
                        return e
                    }, r.appendBanners = function() {
                        var e = this;
                        this.nextPromoIndex = 0, this.usersBeforeNextPromo = 2;
                        var t = this.resetPromoBlockControllers ? [] : l.Ay.getControllers().map((function(e) {
                            return e.object
                        }));
                        this.resetPromoBlockControllers = !1;
                        var n = l.Ay.getItems().reduce((function(n, i) {
                            return i.object instanceof I.A || (n.push(i.object), e.insertBannerIfNecessary(n, t)), n
                        }), []);
                        l.Ay.addPage(n, !0)
                    }, r.insertBannerIfNecessary = function(e, t) {
                        var n, i = e[e.length - 1];
                        if (i && (i.user_id || (n = i).promo_block_position && 1 === n.promo_block_position && 326 === n.promo_block_type) && this.usersBeforeNextPromo--, this.usersBeforeNextPromo <= 0) {
                            if (this.promos) {
                                var o = this.getNextPromo();
                                if (o)
                                    if (t.length) {
                                        var r = t.shift();
                                        e.push(r), null == r || r.start()
                                    } else e.push(this.registerPromoController(o))
                            }
                            this.usersBeforeNextPromo = 9
                        }
                    }, r.addPromoBlock = function(e, n) {
                        if (n.place_after_user) this.batchedActivities[n.place_after_user] = n;
                        else {
                            var i = function(e, t) {
                                var n = !me(t);
                                if (!n) {
                                    n = !e.some((function(e) {
                                        return 346 === e.promo_block_type
                                    }))
                                }
                                return n
                            }(e, n);
                            i && (t.sendStatisticsOnBannerPushed_(n), e.push(n)), this.usersBeforeNextPromo--
                        }
                        var o, r;
                        (r = function(e) {
                            switch (e.promo_block_type) {
                                case 131:
                                    return 10;
                                case 129:
                                    return 100;
                                case 130:
                                    return 101;
                                case 165:
                                    return 14
                            }
                            return null
                        }(o = n)) && ((0, le.sx)(258, {
                            element: r
                        }), (0, le.sx)(333, {
                            element: r,
                            count: he(o)
                        }))
                    }, r.setPromos = function(e) {
                        var t = e.filter((function(e) {
                            return 1 === e.promo_block_position && !de.includes(e.promo_block_type)
                        }));
                        this.promos = U.A.isEnabled() ? [{
                            externalAd: !0
                        }] : this.promos.concat(t)
                    }, r.getNextPromo = function() {
                        var e;
                        return this.promos && (e = this.promos[this.nextPromoIndex++], this.nextPromoIndex === this.promos.length && (this.nextPromoIndex = 0)), e
                    }, r.registerPromoController = function(e) {
                        var t, n = T.A.getUser(),
                            i = n ? n.gender : 3;
                        t = e && "externalAd" in e ? {
                            externalAd: !0,
                            picture: {}
                        } : function(e, t) {
                            var n = e.promo_block_type,
                                i = function(e) {
                                    var t = e.credits_cost,
                                        n = t || e.mssg,
                                        i = e.header || t && n;
                                    return {
                                        title: i,
                                        text: n
                                    }
                                }(e),
                                o = Object.assign({
                                    promoBlock: e,
                                    isGift: 5 === e.ok_payment_product_type,
                                    mark: ge(e),
                                    badgeType: R.A.getBadgeTypeForPromoBlock(n)
                                }, i),
                                r = R.A.getPictureForPromoBlockTS(e, {
                                    gender: t
                                });
                            r.type === w.A.IMAGE_TYPE.URL && (o.picture = {
                                url: r.value,
                                disableMasking: r.disableMasking
                            });
                            r.type === w.A.IMAGE_TYPE.SYMBOL && (o.icon = r.value);
                            return o.gender = t, o
                        }(e, i);
                        var o = "promo-" + this.nextPromoControllerId++,
                            r = new ce(o, t);
                        return r.on(ce.EVENTS.CLICK, this._onPromoClick.bind(this, r)), this.registerController(o, r), r.start(), r
                    }, r._onPromoClick = function(e, t, n) {
                        if (t) {
                            switch (this.onPromoClick(), e.setProcessing(!0), this.trackClickBannerEvent(t), t.promo_block_type) {
                                case 65:
                                    (0, le.sx)(332, {
                                        element: 547
                                    }), O.A.navigate(P.x.SPP_TRIAL, !1, {
                                        returnTo: O.A.getUrl(),
                                        context: 26,
                                        activationPlace: 191,
                                        fromBanner: !0
                                    });
                                    break;
                                case 195:
                                    this.setIsShowingSecurityWalkthrough();
                                    break;
                                default:
                                    (0, le.sx)(332, {
                                        element: 95,
                                        parent_element: this.getElementType()
                                    }), this.performAction(t.ok_action, t, n)
                            }
                            var i = (0, E.A)(this.rotatePromoControllers.bind(this, e));
                            R.A.once(R.A.EVENTS.END_PAYMENT, i)
                        }
                    }, r.performAction = function(e, t, n) {
                        switch (e) {
                            case 9:
                            case 4:
                            case 2:
                                R.A.handlePromoSelected({
                                    action: e,
                                    activationPlace: this.getActivationPlace(),
                                    banner: t.promo_block_type,
                                    cost: t.payment_amount,
                                    productType: t.ok_payment_product_type
                                }, {
                                    from: O.A.getUrl()
                                });
                                break;
                            case 6:
                                this.navigateToSppPayment(t, n);
                                break;
                            default:
                                L.A.showNotification({
                                    type: L.A.TYPES.ERROR
                                })
                        }
                    }, r.navigateToSppPayment = function(e, t) {
                        var n = e.ok_payment_product_type,
                            i = e.promo_block_type,
                            o = {
                                activationPlace: this.getActivationPlace(),
                                bannerId: e.promo_block_type
                            },
                            r = {
                                back: O.A.getUrl(),
                                hotPanelData: o,
                                productType: n,
                                promoBlockType: i
                            };
                        null != t && t.userId && (r.userId = t.userId), M.A.navigateToPayment(r)
                    }, r.rotatePromoControllers = function(e) {
                        var t = this;
                        e.setProcessing(!1);
                        var n = l.Ay.findIndex(e);
                        this.fetch({
                            shownPromoBlocks: this.getShownPromoBlocks(),
                            excludePromoBlocks: [e.getPromoBlock().promo_block_type],
                            count: l.Ay.getControllers().length
                        }).then((function(e) {
                            var i = e[0].toJSON().promo_blocks;
                            if (i) {
                                var o = l.Ay.getControllers().map((function(e) {
                                    return l.Ay.findIndex(e.object)
                                }));
                                o = [].concat(o.slice(o.indexOf(n)), o.slice(0, o.indexOf(n))).slice(0, i.length), i.forEach((function(e, n) {
                                    if (void 0 !== o[n]) {
                                        var i = t.registerPromoController(e);
                                        l.Ay.replaceItem({
                                            object: i,
                                            key: "promoController" + n
                                        }, o[n])
                                    }
                                }))
                            }
                        }))
                    }, r.fetch = function(e) {
                        var t = e.shownPromoBlocks,
                            n = e.excludePromoBlocks,
                            i = e.count;
                        return D.A.getInstance().get({
                            context: this.getClientSource(),
                            position: 1,
                            shownPromoBlocks: t,
                            excludePromoBlocks: n,
                            count: i || 4
                        })
                    }, r.getClientSource = function() {
                        return pe[this.getFolderType()] || 127
                    }, r.trackClickBannerEvent = function(e) {
                        var t = {
                                banner_id: e.promo_block_type,
                                position_id: e.promo_block_position,
                                context: this.getClientSource()
                            },
                            n = e.stats_variation_id;
                        n && (t.variation_id = n), (0, le.sx)(139, t)
                    }, t
                }(I.A);

            function he(e) {
                var t = e.pictures,
                    n = null == t ? void 0 : t.find((function(e) {
                        return 2 === e.badge_type
                    }));
                return n && Number(n.badge_text) || 0
            }

            function ge(e) {
                var t, n = null == (t = e.pictures) ? void 0 : t[0],
                    i = e.counter || (null == n ? void 0 : n.badge_text);
                return i ? {
                    text: i,
                    type: 41 === e.promo_block_type ? "double-credits-badge" : null
                } : null
            }

            function me(e) {
                return 346 === e.promo_block_type
            }
            var ve = fe,
                Ae = n(4571),
                ye = n(27895),
                be = n(46770),
                xe = n(40578),
                Se = n(30784),
                Ce = n(20017),
                _e = n(8483);

            function ke(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function je(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? ke(Object(n), !0).forEach((function(t) {
                        Ee(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : ke(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function Ee(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var Oe = function(e) {
                    var t, n, o, r, s = e.promoBlock,
                        a = e.onClick,
                        c = e.sendTrackingOnMount;
                    (0, i.useEffect)((function() {
                        c()
                    }), []);
                    var l, u = null == (t = s.pictures) ? void 0 : t[0].badge_type;
                    u && (r = 7 === u ? "badge-feature-extra-shows" : void 0), 20 === s.promo_block_position && (r = 12 === s.promo_block_type ? "badge-add-photos" : "badge-email");
                    var d, p = null == (n = s.buttons) ? void 0 : n[0];
                    p && (l = {
                        text: p.text,
                        onClick: function() {
                            return a(s, 0)
                        },
                        dataQA: {
                            "data-qa": "continue-button"
                        }
                    });
                    var f = null == (o = s.buttons) ? void 0 : o[1];
                    return f && (d = {
                        semantic: "tertiary",
                        text: f.text,
                        onClick: function() {
                            return a(s, 1)
                        },
                        dataQA: {
                            "data-qa": "continue-secondary-button"
                        }
                    }), (0, g.jsxs)(Ae.A, {
                        align: "start",
                        children: [r ? (0, g.jsx)(ye.A, {
                            size: "icon",
                            children: (0, g.jsx)(_e.A, {
                                name: r
                            })
                        }) : null, (0, g.jsx)(xe.A, {
                            text: s.header
                        }), (0, g.jsx)(Se.A, {
                            text: s.mssg
                        }), (0, g.jsxs)(be.A, {
                            children: [l ? (0, g.jsx)(Ce.A, je({}, l)) : null, d ? (0, g.jsx)(Ce.A, je({}, d)) : null]
                        })]
                    })
                },
                Te = n(68507);

            function Pe(e, t) {
                return Pe = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, Pe(e, t)
            }
            var Ie = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).scrollsSkipped_ = 0, n.hasStarted = !1, n.onScroll = (0, s.A)(n.onScroll.bind(n), 250), n
                    }
                    var n, o;
                    o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, Pe(n, o);
                    var r = t.prototype;
                    return r.componentDidMount = function() {
                        a.A.addEventListener("scroll", this.onScroll, !1)
                    }, r.componentWillUnmount = function() {
                        clearTimeout(this.scrollHandlerTimeout_), a.A.removeEventListener("scroll", this.onScroll, !1)
                    }, r.componentDidUpdate = function() {
                        if (!this.hasStarted && this.props.items.length > 0) {
                            this.hasStarted = !0;
                            var e = a.A.document.body.pageYOffset || (0, Te.A)().scrollTop;
                            this.props.scrollHandler(e)
                        }
                    }, r.onScroll = function() {
                        var e = this,
                            t = a.A.document.body.pageYOffset || (0, Te.A)().scrollTop,
                            n = a.A.document.body.innerHeight || a.A.document.body.clientHeight,
                            i = (0, Te.A)().scrollHeight - n - .5 * n;
                        t >= i && this.props.fetchNewPage(), clearTimeout(this.scrollHandlerTimeout_), this.scrollsSkipped_ += 1, this.props.scrollHandler && this.scrollsSkipped_ > 5 ? (this.scrollsSkipped_ = 0, this.props.scrollHandler(t)) : this.scrollHandlerTimeout_ = setTimeout((function() {
                            e.props.scrollHandler(t)
                        }), 500)
                    }, r.render = function() {
                        return i.Children.only(this.props.children)
                    }, t
                }(i.Component),
                we = n(23350),
                Re = (n(58940), n(72537)),
                Me = n(18084),
                Ne = n(53210),
                Ue = n(16303),
                De = n(85001),
                Be = function(e) {
                    var t = e.icon,
                        n = e.title,
                        i = e.onClick,
                        o = d()({
                            "csms-connections-item": !0,
                            "csms-connections-item--promo-video": !0
                        });
                    return (0, g.jsx)("button", {
                        className: o,
                        "data-qa": "connections-item",
                        "data-qa-connections-item-type": "promo-video",
                        "data-qa-feature-card": !0,
                        onClick: i,
                        "aria-label": n,
                        children: (0, g.jsxs)(H.A, {
                            tag: "span",
                            children: [(0, g.jsx)(Y.A, {
                                tag: "span",
                                children: (0, g.jsx)("span", {
                                    className: "liked-you-media",
                                    children: (0, g.jsx)(W.A, {
                                        size: "sm",
                                        icon: t
                                    })
                                })
                            }), (0, g.jsx)(Q.A, {
                                tag: "span",
                                children: (0, g.jsx)("span", {
                                    "data-qa": "connections-item__title",
                                    children: (0, g.jsx)(z.P1, {
                                        color: "black",
                                        dangerous: !0,
                                        tag: "span",
                                        children: n
                                    })
                                })
                            })]
                        })
                    })
                },
                Le = (n(38781), n(82195)),
                Fe = function(e) {
                    var t = e.images,
                        n = e.counter,
                        i = e.title,
                        o = e.isDisabled,
                        r = e.onClick,
                        s = d()({
                            "csms-connections-item": !0,
                            "csms-connections-item--disabled": o
                        }),
                        a = d()({
                            "liked-you-media__image": !0,
                            "liked-you-media__image--multiple": t.length > 3
                        }),
                        c = t.length > 3 ? t.map((function(e) {
                            return "url(" + e + ")"
                        })).toString() : "url(" + t[0] + ")";
                    return (0, g.jsx)("button", {
                        className: s,
                        "data-qa": "connections-item",
                        "data-qa-connections-item-type": "liked-you",
                        "data-qa-feature-card": !0,
                        onClick: r,
                        disabled: o,
                        "aria-hidden": o,
                        "aria-label": i,
                        children: (0, g.jsxs)(H.A, {
                            tag: "span",
                            children: [(0, g.jsx)(Y.A, {
                                tag: "span",
                                children: (0, g.jsxs)("div", {
                                    className: "liked-you-media",
                                    children: [(0, g.jsx)("span", {
                                        className: a,
                                        style: {
                                            backgroundImage: c
                                        }
                                    }), (0, g.jsx)("span", {
                                        className: "liked-you-media__badge",
                                        children: (0, g.jsx)(Le.A, {
                                            icon: "generic-heart",
                                            text: n,
                                            shadow: !0
                                        })
                                    })]
                                })
                            }), (0, g.jsx)(Q.A, {
                                tag: "span",
                                children: (0, g.jsx)("span", {
                                    "data-qa": "connections-item__title",
                                    children: (0, g.jsx)(z.P1, {
                                        color: "black",
                                        dangerous: !0,
                                        tag: "span",
                                        children: i
                                    })
                                })
                            })]
                        })
                    })
                },
                Ge = function(e) {
                    var t, n = e.position,
                        i = void 0 === n ? "tr" : n,
                        o = e.children,
                        r = d()(((t = {
                            petal: !0
                        })["petal--" + i] = !0, t));
                    return (0, g.jsx)("div", {
                        className: r,
                        children: o
                    })
                },
                Ve = n(78064),
                qe = n(13614),
                He = n(83503),
                Qe = n.n(He);

            function Ye(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function We(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Ye(Object(n), !0).forEach((function(t) {
                        ze(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Ye(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function ze(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var Ke = ["", Ve.WC.CHATS, Ve.WC.CONVERSATIONS, Ve.WC.UNREPLIED, Ve.WC.FAVOURITES, Ve.WC.ONLINE];

            function Je(e) {
                switch (e.connection_status_indicator) {
                    case 2:
                        return {
                            text: f.Ay.get(485).toUpperCase(),
                            styling: "selected"
                        };
                    case 4:
                        return {
                            text: f.Ay.get(156).toUpperCase(),
                            styling: "default"
                        };
                    default:
                        return
                }
            }

            function Xe(e) {
                switch (e.last_message_status) {
                    case 1:
                        return "delivered";
                    case 2:
                        return "seen";
                    default:
                        return
                }
            }

            function Ze(e) {
                var t, n = e.item,
                    i = e.isEditing,
                    o = e.isUpdate,
                    r = n.promo_block_type || n.experimentType,
                    s = n.pictures,
                    a = s ? s[0].badge_text : null,
                    c = s ? s[0].display_images : null;
                a && (t = Number(a.replace(/\D/g, "")) <= 99 ? a : "99+");
                var l = n.header,
                    u = n.mssg;
                return 346 === r && (l = u), {
                    imgSrc: c,
                    counter: t,
                    title: l,
                    message: u,
                    isDisabled: i,
                    isAddedHACK: o
                }
            }

            function $e(e) {
                return e.is_conversation || e.unread_messages_count > 0 ? 15 : e.is_match ? 11 : e.is_crush ? 22 : 2 === e.their_vote ? 4 : e.favourited_you ? 23 : e.is_favourite ? 24 : e.is_visitor ? 25 : void 0
            }

            function et(e, t) {
                var n = e.is_crush;
                if (n && t.param === Ve.WC.FAVOURITES) return 1;
                var i = e.is_unread,
                    o = e.unread_messages_count || 0,
                    r = o > 0 && Ke.indexOf(t.param) > -1,
                    s = !r && !n && i && e.is_match;
                return s || n || !r ? s || n || !i ? 0 : 1 : o
            }

            function tt(e) {
                switch (e) {
                    case 21:
                        return "generic-play-circle-hollow";
                    case 346:
                        return "badge-feature-icebreaker";
                    default:
                        return "badge-feature-liked-you"
                }
            }
            var nt = n(74787),
                it = n(51709),
                ot = n(31247);

            function rt(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function st(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? rt(Object(n), !0).forEach((function(t) {
                        at(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : rt(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function at(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function ct(e, t) {
                return ct = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, ct(e, t)
            }
            var lt = Me.A.getLogger("ConnectionsItemContainer"),
                ut = function(e) {
                    function t(n) {
                        var i;
                        return (i = e.call(this, n) || this).handleClick = function() {
                            var e = i.props;
                            (0, e.onClick)(e.item)
                        }, i.handleLikedYouClick = function(e) {
                            return function() {
                                var t;
                                i.handleClick(), t = parseInt(e, 10), (0, le.sx)(333, {
                                    element: 5,
                                    count: t
                                })
                            }
                        }, i.handleClickUnmatch = function() {
                            i.props.onUnmatch(i.props.item)
                        }, i.handleClickBlock = function() {
                            i.props.onBlock(i.props.item)
                        }, i.handleClickReport = function() {
                            i.props.onReport(i.props.item)
                        }, i.handleClick = i.handleClick.bind(i), i.handleLikedYouClick = i.handleLikedYouClick.bind(i), i.handleFavourite = i.handleFavourite.bind(i), i.state = t.getState(n), i
                    }
                    var n, i;
                    i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, ct(n, i), t.getState = function(e) {
                        var t = (e || {}).item,
                            n = (0, l.QY)(t),
                            i = (0, l.vf)(t) && 1 === t.promo_block_position && 2 === t.stats_variation_id,
                            o = (0, l.vf)(t) && 1 === t.promo_block_position && 326 === t.promo_block_type,
                            r = (0, l.vf)(t) && 20 === t.promo_block_position && 326 === t.promo_block_type,
                            s = (0, l.vf)(t) && 4 === t.promo_block_position && 21 === t.promo_block_type,
                            a = (0, l.vf)(t) && 1 === t.promo_block_position && 346 === t.promo_block_type;
                        return {
                            isUser: n,
                            isLikedYou: i,
                            isMoreLikesPromo: o,
                            isVideoPromo: s,
                            isPromo: o || s || a,
                            isConnectionItem: (0, l.vf)(t) && !r
                        }
                    };
                    var o = t.prototype;
                    return o.handleFavourite = function(e) {
                        e.stopPropagation();
                        var t = this.props;
                        (0, t.onFavourite)(t.item)
                    }, o.renderUser = function() {
                        var e, t = this,
                            n = function(e) {
                                var t, n, i, o, r = e.item,
                                    s = e.isChecked,
                                    a = e.isEditing,
                                    c = e.isUpdate,
                                    l = r,
                                    u = (null == (t = l.profile_photo) ? void 0 : t.large_url) && w.A.getImageUrlForSize(null == (n = l.profile_photo) ? void 0 : n.large_url, 70),
                                    d = l.is_deleted,
                                    p = l.is_invisible,
                                    f = l.is_unread,
                                    h = !p && 30 !== l.access_level,
                                    g = parseInt(Qe()(l.user_id), 16),
                                    m = String(g % 9 + 1),
                                    v = u || d ? null : {
                                        letter: l.name ? l.name.charAt(0) : "",
                                        variant: m
                                    };
                                return d ? o = "deleted" : p && (o = "invisible"), {
                                    user: {
                                        name: l.name,
                                        age: l.age,
                                        gender: (0, qe.v4)(l.gender),
                                        isFavourite: l.is_favourite,
                                        disguise: o,
                                        photo: u ? {
                                            src: u
                                        } : null,
                                        placeholder: v,
                                        status: {
                                            online: (0, qe.fI)(l.online_status)
                                        },
                                        moodStatusEmoji: null == (i = l.mood_status) ? void 0 : i.emoji,
                                        isMatch: l.is_match,
                                        id: l.user_id
                                    },
                                    connectionStatusIndicator: Je(l),
                                    message: l.display_message,
                                    lastMessageStatus: Xe(l),
                                    isChecked: s,
                                    isLocked: !!l.profile_blocker_promo,
                                    isDisabled: a && !h || l.is_not_interested,
                                    isDisabledClickable: l.is_not_interested,
                                    isFavouriteAllowed: !a && l.allow_add_to_favourites,
                                    isAddedHACK: c,
                                    isNew: f
                                }
                            }(this.props),
                            i = n.user,
                            o = n.message,
                            r = n.lastMessageStatus,
                            s = n.isChecked,
                            a = n.isLocked,
                            c = n.isDisabled,
                            l = n.isDisabledClickable,
                            u = n.isFavouriteAllowed,
                            d = n.isAddedHACK,
                            p = n.connectionStatusIndicator,
                            h = n.isNew;
                        return (0, g.jsx)(Ne.A, {
                            src: null == (e = i.photo) ? void 0 : e.src,
                            render: function(e) {
                                var n, m = e.src,
                                    v = st(st({}, i), {}, {
                                        id: (0, it.JU)(i.id),
                                        photo: m ? {
                                            src: m
                                        } : null
                                    }),
                                    A = [i.age ? f.Ay.get(811, {
                                        name: i.name,
                                        age: i.age
                                    }) : i.name, "online" === (null == (n = i.status) ? void 0 : n.online) ? f.Ay.get(848) : void 0],
                                    y = Re.A.getSync(1004).enabled ? [i.isMatch ? {
                                        text: f.Ay.get(144),
                                        onClick: t.handleClickUnmatch
                                    } : {
                                        text: f.Ay.get(1117),
                                        onClick: t.handleClickBlock
                                    }, {
                                        text: f.Ay.get(1118),
                                        isDangerous: !0,
                                        onClick: t.handleClickReport
                                    }] : void 0;
                                return (0, g.jsx)(Ue.A, {
                                    user: v,
                                    message: o,
                                    lastMessageStatus: r,
                                    isChecked: s,
                                    isLocked: a,
                                    isDisabled: c,
                                    isDisabledClickable: l,
                                    isDeleting: t.props.isDeleting,
                                    isFavouriteAllowed: u,
                                    onClick: t.handleClick,
                                    onFavourite: t.handleFavourite,
                                    tag: p,
                                    moodStatus: (0, nt.El)() ? i.moodStatusEmoji : void 0,
                                    isAddedHACK: d,
                                    mediaOverlay: h ? (0, g.jsx)(Ge, {
                                        children: (0, g.jsx)("div", {
                                            className: "connections-dot-counter-notification"
                                        })
                                    }) : void 0,
                                    a11y: {
                                        favouriteLabel: f.Ay.get(157) + ", " + v.name,
                                        role: t.props.isEditing ? "toggle" : "cta",
                                        profileInfoLabel: (0, ot.b)(A)
                                    },
                                    swipeMenuActions: y
                                })
                            }
                        })
                    }, o.renderLikedYou = function() {
                        var e, t = this.props.item,
                            n = Ze(this.props),
                            i = n.title,
                            o = n.isDisabled,
                            r = null == (e = t.extra_texts) ? void 0 : e[0].text,
                            s = t.pictures.map((function(e) {
                                return e.display_images
                            }));
                        return (0, g.jsx)(Fe, {
                            counter: r,
                            title: i,
                            images: s,
                            isDisabled: o,
                            onClick: this.handleLikedYouClick(r)
                        })
                    }, o.renderPromo = function() {
                        var e, t = this.props.item,
                            n = Ze(this.props),
                            i = n.title,
                            o = n.isDisabled,
                            r = t.promo_block_type,
                            s = 21 === r,
                            a = 346 === r,
                            c = {
                                name: tt(r)
                            },
                            l = s || a ? void 0 : {
                                mark: {
                                    text: null == (e = t.extra_texts) ? void 0 : e[0].text
                                }
                            },
                            u = s ? Be : De.A;
                        return (0, g.jsx)(u, {
                            icon: c,
                            badge: l,
                            title: i,
                            isDisabled: o,
                            onClick: this.handleClick
                        })
                    }, o.renderConnectionItem = function() {
                        var e = Ze(this.props),
                            t = e.imgSrc,
                            n = e.counter,
                            i = e.title,
                            o = e.message,
                            r = e.isDisabled,
                            s = e.isAddedHACK;
                        return (0, g.jsx)(De.A, {
                            image: {
                                src: t
                            },
                            title: i,
                            message: o,
                            isDisabled: r,
                            isAddedHACK: s,
                            onClick: this.handleClick,
                            mediaOverlay: Boolean(n) ? (0, g.jsx)(Ge, {
                                children: (0, g.jsx)("div", {
                                    className: "connections-dot-counter-notification"
                                })
                            }) : void 0
                        })
                    }, o.render = function() {
                        var e = this.state,
                            t = e.isUser,
                            n = e.isLikedYou,
                            i = e.isPromo,
                            o = e.isConnectionItem;
                        return t ? this.renderUser() : n ? this.renderLikedYou() : i ? this.renderPromo() : o ? this.renderConnectionItem() : (lt.error("Connections - trying to render an unexpected item: " + this.props.item), null)
                    }, t
                }(i.Component),
                dt = ut,
                pt = n(1347);

            function ft(e, t) {
                return ft = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, ft(e, t)
            }
            var ht = function(e) {
                    function t() {
                        for (var t, n = arguments.length, i = new Array(n), o = 0; o < n; o++) i[o] = arguments[o];
                        return (t = e.call.apply(e, [this].concat(i)) || this).element = null, t
                    }
                    var n, i;
                    i = e, (n = t).prototype = Object.create(i.prototype), n.prototype.constructor = n, ft(n, i);
                    var o = t.prototype;
                    return o.componentDidMount = function() {
                        this.props.controller.setParent((0, p.A)(this.element))
                    }, o.render = function() {
                        var e = this,
                            t = this.props.controller.isExternalAd(),
                            n = d()({
                                "chat-connections-list-banner": !0,
                                "is-external-ad": t
                            });
                        return (0, g.jsxs)("div", {
                            className: n,
                            "data-qa": "connections-item",
                            "data-qa-connections-item-type": "promo",
                            ref: function(t) {
                                e.element = t
                            },
                            "aria-hidden": this.props.isEditing,
                            inert: this.props.isEditing ? "" : void 0,
                            children: [this.props.isEditing ? (0, g.jsx)(k, {}) : null, (0, g.jsx)("div", {
                                className: "b-link"
                            })]
                        })
                    }, t
                }(i.Component),
                gt = ht,
                mt = n(84654),
                vt = Me.A.getLogger("ConnectionsList"),
                At = function(e) {
                    var t = e.containerRef,
                        n = e.items,
                        i = e.currentFilter,
                        o = e.isEditing,
                        r = e.isLoading,
                        s = e.onSelectItem,
                        a = e.onFavouriteItem,
                        c = e.onItemVisible,
                        u = e.onBannerVisible,
                        d = e.getUserSubstitute,
                        p = e.onBlock,
                        f = e.onReport,
                        h = e.onUnmatch;
                    if (!n) return null;
                    var m = function(e) {
                            if (e instanceof I.A && u(e), (0, l.QY)(e)) {
                                var t = e;
                                if (3 === t.type) ! function(e) {
                                    if (e) {
                                        var t = e.connectionPromoCard;
                                        (0, le.sx)(138, We(We({}, t.hotpanelData), {}, {
                                            context: 127
                                        }))
                                    }
                                }(d(t.user_id));
                                else {
                                    var n = i;
                                    (0, le.sx)(623, {
                                        encrypted_user_id: t.user_id,
                                        activation_place: n.activationPlace || 1,
                                        badge_count: et(t, n),
                                        connection_status: $e(t)
                                    })
                                }
                                var o = e.is_unread,
                                    r = !0 === e.is_visitor;
                                o && r && c(e)
                            } else(0, l.vf)(e) && u && u(e)
                        },
                        v = function(e) {
                            var t = e.object,
                                n = e.isUpdate,
                                i = e.isChecked,
                                r = e.isDeleting,
                                c = void 0 !== r && r,
                                u = t instanceof I.A,
                                d = (0, l.QY)(t) || (0, l.vf)(t);
                            return u ? (0, g.jsx)(gt, {
                                controller: t,
                                isEditing: o
                            }) : d ? (0, g.jsx)(dt, {
                                item: t,
                                isChecked: i,
                                isEditing: o,
                                isUpdate: n,
                                isDeleting: c,
                                onClick: s,
                                onFavourite: a,
                                onBlock: p,
                                onReport: f,
                                onUnmatch: h
                            }) : (vt.error("Connections - trying to render an unexpected item: " + t), null)
                        };
                    return (0, g.jsxs)("div", {
                        ref: t,
                        children: [(0, g.jsx)(pt.A, {
                            children: n.map((function(e) {
                                return (0, g.jsx)(mt.A, {
                                    onIntersect: function() {
                                        return m(e.object)
                                    },
                                    children: v(e)
                                }, e.key)
                            }))
                        }), r ? (0, g.jsx)(we.Ay, {
                            relative: !0,
                            size: we.On.SMALL,
                            color: we.Ac.DARK,
                            extraClass: "js-loader"
                        }) : null]
                    })
                };

            function yt(e, t) {
                return yt = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, yt(e, t)
            }
            var bt, xt = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).divContainer = void 0, n.lastVisibleElement = void 0, n.handleSelectItem = function(e) {
                            var t = l.Ay.findIndex(e),
                                i = l.Ay.get(t);
                            if (void 0 !== i) {
                                if (n.props.isEditing) {
                                    if (!(0, l.QY)(i.object) || i.object.is_invisible || 30 === i.object.access_level) return;
                                    i.isChecked = !i.isChecked, l.Ay.replaceItem(i, t), n.setState({
                                        items: l.Ay.getItems(n.props.currentTab, n.props.currentPromoContext, n.props.currentSortOption)
                                    })
                                } else i.isChecked || n.props.onSelectItem(e, t);
                                return !1
                            }
                        }, n.handleScroll = function(e) {
                            var t = n.calculateLastVisibleItemIndex(e);
                            t > -1 && n.props.onTrackScroll(t)
                        }, n.divContainer = (0, i.createRef)(), n.state = {
                            markedUserIds: [],
                            items: l.Ay.getItems(n.props.currentTab, n.props.currentPromoContext, n.props.currentSortOption)
                        }, n
                    }
                    var n, o;
                    o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, yt(n, o);
                    var r = t.prototype;
                    return r.componentDidUpdate = function() {
                        (0, qe.Yn)((0, p.A)(this.divContainer.current).find(".js-mw-connections-item.mw-connections-item--is-added-hack"), (function() {
                            l.Ay.removeUpdatedFlags()
                        }))
                    }, r.calculateLastVisibleItemIndex = function(e) {
                        var t, n = this.lastVisibleElement || (0, p.A)(this.divContainer.current).children().first();
                        if (null == (t = n) || !t.length) return -1;
                        for (e += a.A.document.documentElement.offsetHeight; null != (i = n) && i.length;) {
                            var i, o = n.next();
                            if (o.index() < 0 || (0, p.A)(o).hasClass("js-loader")) break;
                            var r = o.offset();
                            if (r.top + r.height > e) break;
                            n = o
                        }
                        return this.lastVisibleElement = n, n.index()
                    }, r.render = function() {
                        var e = l.Ay.getItems(this.props.currentTab, this.props.currentPromoContext, this.props.currentSortOption);
                        return (0, g.jsx)(Ie, {
                            items: e,
                            scrollHandler: this.handleScroll,
                            fetchNewPage: this.props.onNeedPage,
                            children: (0, g.jsx)(At, {
                                containerRef: this.divContainer,
                                items: e,
                                currentFilter: this.props.currentFilter,
                                isLoading: this.props.isLoading,
                                isEditing: this.props.isEditing,
                                onSelectItem: this.handleSelectItem,
                                onFavouriteItem: this.props.onFavouriteItem,
                                onItemVisible: this.props.onItemVisible,
                                onBannerVisible: this.props.onBannerVisible,
                                getUserSubstitute: this.props.getUserSubstitute,
                                onBlock: this.props.onBlock,
                                onReport: this.props.onReport,
                                onUnmatch: this.props.onUnmatch
                            })
                        })
                    }, t
                }(i.Component),
                St = n(73260),
                Ct = n(39904),
                _t = function(e) {
                    var t = e.header,
                        n = e.subHeader,
                        i = e.popularityLevel,
                        o = void 0 === i ? St.s7.VERY_LOW : i,
                        r = e.hasUsers,
                        s = e.showFullscreenPromo,
                        a = e.isEditButtonHidden,
                        c = e.isEditing,
                        l = e.onClickEdit,
                        u = e.onClickPopularity,
                        d = e.onClickNotifications,
                        p = [{
                            type: Ct.TN.POPULARITY,
                            level: o,
                            onClick: u,
                            dataQA: {
                                "data-qa": "popularity-level"
                            }
                        }, {
                            type: Ct.X2.NOTIFICATION,
                            onClick: d,
                            dataQA: {
                                "data-qa": "activity-inbox"
                            }
                        }];
                    return s || a || !r || null == p || p.unshift({
                        type: Ct.$4.BUTTON,
                        text: c ? f.Ay.get(460) : f.Ay.get(461),
                        onClick: l,
                        dataQA: {
                            "data-qa": "connections-edit-button"
                        }
                    }), (0, g.jsx)(Ct.Ay, {
                        actions: p,
                        title: {
                            text: t,
                            variant: "primary"
                        },
                        subTitle: n,
                        isBalanced: !1
                    })
                },
                kt = n(31709),
                jt = n(41298),
                Et = n(25093),
                Ot = n(80851),
                Tt = n(18707),
                Pt = n(99766),
                It = n(69873),
                wt = n(33014);

            function Rt(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function Mt(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Rt(Object(n), !0).forEach((function(t) {
                        Nt(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Rt(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function Nt(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }! function(e) {
                e[e.CONTROL = 0] = "CONTROL", e[e.STORIES = 1] = "STORIES"
            }(bt || (bt = {}));
            var Ut = "sm",
                Dt = 70,
                Bt = function(e) {
                    var t = e.pictures;
                    return (0, g.jsx)("div", {
                        className: "match-bar-banner-likes-container",
                        children: (0, g.jsx)("div", {
                            className: "match-bar-banner-likes",
                            "data-qa": "match-bar-likes",
                            children: null == t ? void 0 : t.map((function(e, t) {
                                var n = {
                                        width: 0,
                                        transition: "width 300ms ease-in-out 0s"
                                    },
                                    i = {
                                        entered: {
                                            width: Dt
                                        }
                                    };
                                return (0, g.jsx)(Ot.Ay, {
                                    appear: !0,
                                    in: !0,
                                    timeout: 300,
                                    children: function(t) {
                                        return (0, g.jsx)("div", {
                                            "data-qa": "match-bar-banner-likes-item",
                                            className: "match-bar-banner-likes__item",
                                            style: Mt(Mt({}, n), i[t]),
                                            children: (0, g.jsx)("img", {
                                                src: w.A.getImageUrlForSize(e.src, Dt),
                                                alt: "",
                                                width: Dt,
                                                height: Dt
                                            })
                                        })
                                    }
                                }, "match-bar-likes-item-" + (e.index || t))
                            }))
                        })
                    })
                },
                Lt = function(e) {
                    var t, n, i, o, r = e.pictures,
                        s = e.message,
                        a = e.text,
                        c = e.mode,
                        l = e.showIcon,
                        u = e.onClick;
                    return r && !l && (t = (0, g.jsx)(Bt, {
                        pictures: r
                    }), n = a ? {
                        mark: {
                            icon: "generic-heart",
                            text: a
                        }
                    } : void 0, i = {
                        position: "outside",
                        color: "liked-you"
                    }), r && !l || (o = {
                        name: "badge-feature-liked-you"
                    }), (0, g.jsxs)(Pt.A, {
                        dataQA: {
                            "data-qa": "match-bar-banner"
                        },
                        children: [(0, g.jsx)(It.A, {
                            children: (0, g.jsx)(W.A, {
                                size: Ut,
                                icon: o,
                                content: t,
                                badge: n,
                                halo: i,
                                onClick: u,
                                a11y: {
                                    actionLabel: a ? f.Ay.get(617, {
                                        num: Number(a) || 0
                                    }) : void 0
                                }
                            })
                        }), c === bt.CONTROL ? (0, g.jsx)(wt.A, {
                            children: (0, g.jsx)("div", {
                                style: {
                                    width: Dt
                                },
                                children: (0, g.jsx)(z.P3, {
                                    color: "black",
                                    ellipsis: !0,
                                    children: s
                                })
                            })
                        }) : null]
                    })
                },
                Ft = function(e) {
                    var t = e.name,
                        n = e.photo,
                        i = e.gender,
                        o = e.isCrush,
                        r = e.isNew,
                        s = e.mode,
                        a = e.onClick,
                        c = e.onView,
                        l = e.index,
                        u = {
                            gender: i
                        };
                    n && (u.photo = {
                        src: w.A.getImageUrlForSize(n, Dt)
                    });
                    var d = {};
                    return r && (s === bt.CONTROL ? d.overlay = {
                        children: (0, g.jsx)(Ge, {
                            children: (0, g.jsx)("div", {
                                className: "match-bar-dot-counter-notification"
                            })
                        })
                    } : d.halo = {
                        position: "inside",
                        color: "primary"
                    }), (0, g.jsx)(mt.A, {
                        onIntersect: c ? c(!!r, !!o, l) : function() {},
                        children: (0, g.jsxs)(Pt.A, {
                            dataQA: {
                                "data-qa": "match-bar-user"
                            },
                            children: [(0, g.jsx)(It.A, {
                                children: (0, g.jsx)(W.A, Mt({
                                    size: Ut,
                                    user: u,
                                    onClick: a
                                }, d))
                            }), s === bt.CONTROL ? (0, g.jsx)(wt.A, {
                                children: (0, g.jsx)("div", {
                                    style: {
                                        width: Dt
                                    },
                                    children: (0, g.jsx)(z.P3, {
                                        color: "black",
                                        ellipsis: !0,
                                        children: t
                                    })
                                })
                            }) : null]
                        })
                    })
                },
                Gt = function(e) {
                    var t = e.mode;
                    return (0, g.jsxs)(Pt.A, {
                        children: [(0, g.jsx)(It.A, {
                            children: (0, g.jsx)(W.A, {
                                size: Ut,
                                content: (0, g.jsx)("div", {
                                    className: "match-bar-placeholder"
                                })
                            })
                        }), t === bt.CONTROL ? (0, g.jsx)(wt.A, {
                            children: (0, g.jsx)(z.P3, {
                                color: "black",
                                children: " "
                            })
                        }) : null]
                    })
                },
                Vt = function(e) {
                    var t = e.title,
                        n = void 0 === t ? " " : t,
                        o = e.banner,
                        r = e.users,
                        s = e.mode,
                        a = void 0 === s ? bt.CONTROL : s,
                        c = e.isEmpty,
                        l = e.isSkeleton,
                        u = e.onScroll,
                        d = e.onItemViewed;
                    return c ? (0, g.jsxs)(_.A, {
                        top: "md",
                        bottom: "md",
                        children: [(0, g.jsx)(_.A, {
                            bottom: "lg",
                            right: "gap",
                            left: "gap",
                            children: (0, g.jsx)(z.gT, {
                                color: "black",
                                children: n
                            })
                        }), (0, g.jsxs)(Tt.A, {
                            spacing: "xlg",
                            hpadded: !0,
                            vpadded: !0,
                            children: [(0, g.jsx)(Lt, Mt(Mt({}, o), {}, {
                                showIcon: !0,
                                mode: a
                            })), [].concat(new Array(3)).map((function(e, t) {
                                return (0, g.jsx)(Gt, {
                                    mode: a
                                }, "match-bar-placeholder-" + t)
                            }))]
                        })]
                    }) : l ? (0, g.jsxs)(_.A, {
                        top: "md",
                        bottom: "md",
                        children: [(0, g.jsx)(_.A, {
                            bottom: "lg",
                            right: "gap",
                            left: "gap",
                            children: (0, g.jsx)(z.gT, {
                                color: "black",
                                children: n
                            })
                        }), (0, g.jsx)(Tt.A, {
                            spacing: "xlg",
                            hpadded: !0,
                            vpadded: !0,
                            children: [].concat(new Array(4)).map((function(e, t) {
                                return (0, g.jsx)(Gt, {
                                    mode: a
                                }, "match-bar-placeholder-" + t)
                            }))
                        })]
                    }) : (0, g.jsxs)(_.A, {
                        top: "md",
                        bottom: "md",
                        children: [(0, g.jsx)(_.A, {
                            bottom: "lg",
                            right: "gap",
                            left: "gap",
                            children: (0, g.jsx)(z.gT, {
                                color: "black",
                                children: n
                            })
                        }), (0, g.jsxs)(Tt.A, {
                            spacing: "xlg",
                            hpadded: !0,
                            vpadded: !0,
                            onScroll: u,
                            children: [(0, g.jsx)(Lt, Mt(Mt({}, o), {}, {
                                mode: a
                            })), null == r ? void 0 : r.map((function(e, t) {
                                return (0, i.createElement)(Ft, Mt(Mt({}, e), {}, {
                                    mode: a,
                                    onView: d,
                                    index: t,
                                    key: "match-bar-user-" + t
                                }))
                            }))]
                        })]
                    })
                },
                qt = n(15566);

            function Ht(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function Qt(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Ht(Object(n), !0).forEach((function(t) {
                        Yt(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Ht(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function Yt(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var Wt = Me.A.getLogger("MatchBarContainer");

            function zt() {
                (0, le.sx)(195, {
                    element: 1252,
                    direction: 6
                })
            }
            var Kt, Jt, Xt, Zt = function(e) {
                    var t = e.hasMatchBarStories,
                        n = (0, i.useState)(!0),
                        o = n[0],
                        r = n[1],
                        c = (0, i.useState)([]),
                        l = c[0],
                        u = c[1],
                        d = (0, i.useState)(),
                        p = d[0],
                        h = d[1],
                        m = (0, i.useState)(0),
                        v = m[0],
                        A = m[1],
                        y = (0, i.useRef)(l),
                        b = (0, i.useRef)(v),
                        x = (0, i.useRef)(),
                        S = (0, i.useRef)(null),
                        C = (0, i.useRef)(""),
                        _ = (0, i.useRef)(!0),
                        k = (0, i.useRef)(!1),
                        j = (0, i.useRef)(!1),
                        E = (0, i.useRef)(!1),
                        T = (0, i.useCallback)((function(e) {
                            var t = {};
                            return (y.current || []).forEach((function(e) {
                                t[e.getUserId()] = e
                            })), e.forEach((function(e) {
                                var n = e.getUserId();
                                e.getIsRemoved() ? delete t[n] : t[n] = e
                            })), Object.keys(t).map((function(e) {
                                return t[e]
                            }))
                        }), [y]),
                        I = (0, i.useCallback)((function() {
                            var e = {
                                clientSource: 127,
                                sectionRequests: [Qt({
                                    type: 1
                                }, C && {
                                    pageToken: C.current
                                })],
                                folderId: 49,
                                userFieldFilter: (new qt.KkJ).setProjection([280, 200, 583, 580, 340, 230, 810, 830]),
                                preferredCount: 50,
                                direction: 1
                            };
                            return S.current = (0, jt.A)(B.A.getInstance().fetch(e, !0, !0)), S.current.then((function(e) {
                                var n = e[0];
                                if (!n) return Wt.error("Server returned no data for match bar"), [null, null];
                                var i = function(e) {
                                        var t = ((null == e ? void 0 : e.getSection()) || [])[0];
                                        return _.current = null == t ? void 0 : t.getLastBlock(), {
                                            users: (null == t ? void 0 : t.getUsers()) || [],
                                            pageToken: (null == t ? void 0 : t.getPageToken()) || ""
                                        }
                                    }(n),
                                    o = function(e) {
                                        var t = (null == e ? void 0 : e.getPromoBanners()) || [];
                                        if (!t.length) return;
                                        var n = t[0],
                                            i = n.getPromoBlockType(),
                                            o = n.getPromoBlockPosition(),
                                            r = n.getContext(),
                                            s = n.getMssg();
                                        return 129 === i ? {
                                            type: i,
                                            message: s,
                                            pictures: n.getPictures().map((function(e) {
                                                return e.getDisplayImages()
                                            })),
                                            variation: n.getStatsVariationId(),
                                            text: n.getExtraTexts()[0].getText(),
                                            position: o,
                                            context: r
                                        } : 326 === i ? {
                                            type: i,
                                            position: o,
                                            context: r,
                                            message: s
                                        } : void 0
                                    }(n),
                                    r = i.users;
                                return null != C && C.current && (r = T(i.users)), r = t ? r.sort((function(e, t) {
                                    var n = e.getSortTimestamp() + (e.getIsUnread() ? 1e8 : 0);
                                    return t.getSortTimestamp() + (t.getIsUnread() ? 1e8 : 0) - n
                                })) : r.sort((function(e, t) {
                                    return t.getSortTimestamp() - e.getSortTimestamp()
                                })), u(r), o && h(o), C.current = i.pageToken, _.current || I(), [r, o]
                            })).catch((function(e) {
                                return (0, Et.A)(e) && Wt.error("Error requesting match bar folder", {
                                    error: e
                                }), [null, null]
                            }))
                        }), [C, T, _, t]);
                    (0, i.useEffect)((function() {
                        y.current = l
                    }), [l]), (0, i.useEffect)((function() {
                        var e;
                        p && ((0, le.sx)(333, {
                            element: 1253,
                            count: (null == p || null == (e = p.pictures) ? void 0 : e.length) || 0
                        }), (0, le.sx)(138, {
                            banner_id: p.type,
                            position_id: p.position,
                            context: p.context,
                            variation_id: p.variation
                        }))
                    }), [p]), (0, i.useEffect)((function() {
                        var e = S.current;
                        return function() {
                            return null == e ? void 0 : e.cancel()
                        }
                    }), []), (0, i.useEffect)((function() {
                        var e = function() {
                                r(Re.A.getSync(268).enabled)
                            },
                            t = function(e) {
                                var t;
                                21 === e.id && null != (t = e.folders) && t.includes(49) && I()
                            },
                            n = function(e) {
                                49 === e.folder && I()
                            },
                            i = function(e) {
                                var t = e.from_person_id,
                                    n = e.to_person_id;
                                if (l.length) {
                                    var i = l.findIndex((function(e) {
                                        return [t, n].includes(e.getUserId())
                                    }));
                                    i > -1 && u([].concat(l.slice(0, i), l.slice(i + 1)))
                                }
                            };
                        return Re.A.on(Re.A.EVENTS.UPDATE, e), kt.aV.onResponse(361, t), kt.aV.onResponse(138, n), kt.aV.onResponse(105, i), o && I().then((function(e) {
                                var t, n;
                                e && (e[1] && 129 === e[1].type && e[1].pictures && (n = e[1].pictures.length, x.current = a.A.setInterval((function() {
                                    10 === b.current || n - 1 === b.current ? a.A.clearInterval(x.current) : (b.current = b.current + 1, A(b.current))
                                }), 3e3)), (0, le.sx)(258, {
                                    element: 1252,
                                    count: (null == (t = e[0]) ? void 0 : t.length) || 0
                                }))
                            })),
                            function() {
                                Re.A.off(Re.A.EVENTS.UPDATE, e), kt.aV.offResponse(361, t), kt.aV.offResponse(138, n), kt.aV.offResponse(105, i), x.current && a.A.clearInterval(x.current)
                            }
                    }), [o]);
                    var w = function() {
                            p && (O.A.navigate(P.x.LIKED_YOU, !1, {
                                activationPlace: 401
                            }), (0, le.sx)(139, {
                                banner_id: p.type,
                                position_id: p.position,
                                context: p.context,
                                variation_id: p.variation
                            }))
                        },
                        R = function(e, n) {
                            return function() {
                                if (function(e, t) {
                                        var n;
                                        n = e.getIsMatch() ? e.getIsUnread() ? 1255 : 1254 : 1256;
                                        (0, le.sx)(332, {
                                            element: n,
                                            parent_element: 1252,
                                            position: t
                                        })
                                    }(e, n), t) {
                                    var i = l.map((function(e) {
                                        return e.getUserId()
                                    }));
                                    O.A.navigate(P.x.MATCH_STORIES, {
                                        matchId: e.getUserId(),
                                        matchIds: i
                                    })
                                } else O.A.navigate(P.x.MESSAGES, {
                                    id: e.getUserId(),
                                    userInitiated: !0,
                                    folderId: 49,
                                    context: 127,
                                    activationPlace: 401
                                })
                            }
                        },
                        M = (0, i.useCallback)((function(e, t, n) {
                            return function() {
                                var i = 1254;
                                k.current && j.current && E.current || (t ? (i = 1256, E.current = !0) : e ? (i = 1255, j.current = !0) : k.current = !0, (0, le.sx)(258, {
                                    element: i,
                                    position: n
                                }))
                            }
                        }), [k, j, E]),
                        N = (0, i.useCallback)((function() {
                            if (l.length) {
                                var e = l.filter((function(e) {
                                        return !e.getIsCrush()
                                    })),
                                    t = e.filter((function(e) {
                                        return e.getIsUnread()
                                    }));
                                return t.length ? f.Ay.get(624, {
                                    num: t.length
                                }) : f.Ay.get(623, {
                                    num: e.length
                                })
                            }
                            return f.Ay.get(625)
                        }), [l]);
                    return o ? (0, g.jsx)("div", {
                        "data-qa": "match-bar",
                        children: (0, g.jsx)(Vt, Qt(Qt({
                            title: N()
                        }, p ? 129 === p.type ? {
                            banner: {
                                pictures: p.pictures ? p.pictures.slice(0, v + 1).map((function(e, t) {
                                    return {
                                        src: e,
                                        index: t
                                    }
                                })) : void 0,
                                message: p.message || "",
                                text: p.text || 0,
                                onClick: w
                            }
                        } : {
                            banner: {
                                message: p.message || "",
                                onClick: w
                            },
                            isEmpty: !l.length
                        } : null), {}, {
                            users: l.length ? l.map((function(e, t) {
                                var n;
                                return {
                                    id: e.getUserId(),
                                    name: e.getName(),
                                    photo: null == (n = e.getProfilePhoto()) ? void 0 : n.getLargeUrl(),
                                    gender: (0, qe.v4)(e.getGender()),
                                    isCrush: e.getIsCrush(),
                                    isNew: e.getIsUnread(),
                                    onClick: R(e, t)
                                }
                            })) : void 0,
                            mode: t ? bt.STORIES : bt.CONTROL,
                            isSkeleton: !l.length && !p,
                            onScroll: (0, s.A)(zt, 300),
                            onItemViewed: l.length ? M : void 0
                        }))
                    }) : null
                },
                $t = n(73510),
                en = function(e) {
                    var t = e.isActive,
                        n = e.onClick,
                        o = (0, i.useRef)(null),
                        r = (0, i.useState)({}),
                        s = r[0],
                        a = r[1];
                    return (0, g.jsx)($t.A, { in: t,
                        timeout: 300,
                        mountOnEnter: !0,
                        unmountOnExit: !0,
                        onEntering: function() {
                            o.current && a({
                                width: o.current.offsetWidth,
                                height: o.current.offsetHeight
                            })
                        },
                        children: function(e) {
                            var t = d()({
                                "floating-action": !0,
                                "js-connections-actions-edit": !0,
                                "is-inactive": "entered" !== e
                            });
                            return (0, g.jsxs)(i.Fragment, {
                                children: [(0, g.jsx)("div", {
                                    className: t,
                                    ref: o,
                                    children: (0, g.jsx)("div", {
                                        className: "floating-action__button",
                                        children: (0, g.jsx)(Ce.A, {
                                            text: f.Ay.get(494),
                                            onClick: n,
                                            dataQA: {
                                                "data-qa": "connections-button-remove"
                                            }
                                        })
                                    })
                                }), (0, g.jsx)("div", {
                                    className: "fake",
                                    style: s
                                })]
                            })
                        }
                    })
                },
                tn = n(65736),
                nn = n(33736),
                on = function(e) {
                    var t = e.header,
                        n = e.text,
                        i = e.onReport,
                        o = e.onDelete,
                        r = e.onCancel;
                    return (0, g.jsxs)(tn.A, {
                        wrapperType: tn.T.ACTION_SHEET,
                        header: {
                            title: t,
                            text: n
                        },
                        onDismiss: r,
                        children: [(0, g.jsx)(nn.A, {
                            text: f.Ay.get(143),
                            type: "destructive",
                            onClick: i
                        }), (0, g.jsx)(nn.A, {
                            text: f.Ay.get(153),
                            onClick: o
                        })]
                    })
                },
                rn = ((Xt = {})[Ve.n7.ALL_MESSAGES] = ((Kt = {})[Ve.ku.RECENT] = 1388, Kt[Ve.ku.UNREAD] = 224, Kt[Ve.ku.CHAT_REQUEST] = 1385, Kt[Ve.ku.ONLINE] = 406, Kt[Ve.ku.MY_FAVOURITES] = 1390, Kt), Xt[Ve.n7.ACTIVITY] = ((Jt = {})[Ve.ku.RECENT] = 1389, Jt[Ve.ku.UNREAD] = 224, Jt[Ve.ku.MATCH] = 354, Jt[Ve.ku.VISIT] = 6, Jt[Ve.ku.FAVOURITED_YOU] = 9, Jt[Ve.ku.MY_FAVOURITES] = 1391, Jt), Xt);

            function sn() {
                (0, le.sx)(258, {
                    element: 1386
                })
            }
            var an = function(e) {
                    var t = e.text,
                        n = e.onClick;
                    return (0, g.jsxs)("button", {
                        className: "connections-sort-options",
                        onClick: n,
                        "data-qa": "connections-sort-options-button",
                        children: [(0, g.jsx)("span", {
                            className: "connections-sort-options__icon",
                            children: (0, g.jsx)(_e.A, {
                                name: "generic-filter",
                                size: "md",
                                color: "black"
                            })
                        }), (0, g.jsx)("span", {
                            className: "connections-sort-options__text",
                            children: (0, g.jsx)(z.rc, {
                                tag: "span",
                                children: t
                            })
                        })]
                    })
                },
                cn = function(e) {
                    var t = e.currentTab,
                        n = e.currentSortOption,
                        i = e.onClick;
                    return (0, g.jsx)(an, {
                        text: n.name,
                        onClick: function() {
                            var e, o;
                            i(), e = t.type, o = n.variant, (0, le.sx)(332, {
                                element: 1132,
                                parent_element: rn[e][o]
                            })
                        }
                    })
                },
                ln = n(35299),
                un = function(e) {
                    var t = e.options;
                    return (0, g.jsx)(ln.A, {
                        options: t
                    })
                },
                dn = function(e) {
                    var t = e.currentTab,
                        n = e.onSelectOption,
                        o = e.hideSortOptions,
                        r = (0, i.useState)(!0),
                        s = r[0],
                        a = r[1],
                        c = function(e) {
                            n(e),
                                function(e, t) {
                                    (0, le.sx)(332, {
                                        element: rn[e][t],
                                        parent_element: 1386
                                    })
                                }(t.type, e), setTimeout((function() {
                                    a(!1)
                                }), 300)
                        },
                        l = t.sortOptions.map((function(e) {
                            return {
                                label: e.name,
                                name: e.variant,
                                value: e.id.toString(),
                                isChecked: e.isCurrent,
                                onChange: function() {
                                    return c(e.variant)
                                },
                                onClick: function() {
                                    return t = e.isCurrent, void a(!t);
                                    var t
                                },
                                dataQA: {
                                    "data-qa-connections-sort-option": e.variant.toString()
                                }
                            }
                        }));
                    return (0, g.jsx)(tn.A, {
                        isVisible: s,
                        onAnimationInComplete: sn,
                        onAnimationOutComplete: o,
                        isPadded: !0,
                        children: (0, g.jsx)(un, {
                            options: l
                        })
                    })
                },
                pn = n(254),
                fn = n(65297),
                hn = n(99644),
                gn = n(28431),
                mn = n(28030),
                vn = n(20816),
                An = n(98819),
                yn = n(31087),
                bn = n(96956),
                xn = n(59678),
                Sn = n(23715),
                Cn = n(27378),
                _n = n(75248),
                kn = n(26035),
                jn = n(37225),
                En = n(33527),
                On = n(24537),
                Tn = (0, n(58544).lh)(),
                Pn = {
                    update: function(e, t) {
                        Tn.trigger(e, t)
                    },
                    subscribe: Tn.subscribe,
                    unsubscribe: Tn.unsubscribe
                },
                In = n(97547),
                wn = n(32411),
                Rn = n(84220),
                Mn = n(35837),
                Nn = n(23735),
                Un = n(5974),
                Dn = n(60090),
                Bn = n(40961),
                Ln = n(77409),
                Fn = n(71859),
                Gn = function(e) {
                    var t = e.connectionsList,
                        n = e.emptyPromo,
                        o = e.matchBar,
                        r = e.sortOptionsButton,
                        s = e.deleteButton,
                        a = e.hasUsers,
                        c = e.hasMatchBarStories,
                        l = e.showFullscreenPromo,
                        u = e.isLoading,
                        p = e.isEditButtonHidden,
                        h = e.isEditing,
                        m = e.onBackClick,
                        v = e.onEditButtonClick,
                        A = (0, i.useState)(!0),
                        y = A[0],
                        j = A[1],
                        E = [{
                            type: Ct.X2.BACK,
                            onClick: function() {
                                j(!1)
                            }
                        }];
                    l || p || !a || null == E || E.unshift({
                        type: Ct.$4.BUTTON,
                        text: h ? f.Ay.get(460) : f.Ay.get(461),
                        onClick: v
                    });
                    var O = !a && n;
                    return (0, g.jsx)(Fn.A, {
                        children: (0, g.jsx)($t.A, {
                            appear: !0,
                            in: y,
                            timeout: 300,
                            classNames: y ? "forward" : "backward",
                            mountOnEnter: !0,
                            unmountOnExit: !0,
                            onExited: function() {
                                m()
                            },
                            children: function() {
                                return (0, g.jsx)("div", {
                                    className: "page-container",
                                    id: "activity-inbox",
                                    children: (0, g.jsx)("div", {
                                        className: "page",
                                        children: (0, g.jsxs)(x.A, {
                                            children: [(0, g.jsxs)(C.A, {
                                                children: [(0, g.jsx)(Ct.Ay, {
                                                    actions: E,
                                                    title: f.Ay.get(155),
                                                    position: "sticky",
                                                    hasShadow: !0
                                                }), l ? null : (0, g.jsxs)("div", {
                                                    className: d()("connections__match-bar", {
                                                        "connections__match-bar--stories": c
                                                    }),
                                                    inert: h ? "" : void 0,
                                                    children: [o, h ? (0, g.jsx)(k, {}) : null]
                                                })]
                                            }), (0, g.jsxs)(S.A, {
                                                align: "stretch",
                                                children: [n && O ? (0, g.jsx)("div", {
                                                    className: "connections-empty-container",
                                                    "data-qa": "connections-empty",
                                                    children: (0, g.jsxs)("div", {
                                                        style: {
                                                            margin: "auto 0"
                                                        },
                                                        children: [(0, g.jsx)(_.A, {
                                                            top: "md",
                                                            right: "gap",
                                                            bottom: "md",
                                                            left: "gap",
                                                            children: n
                                                        }), (0, g.jsx)("div", {
                                                            className: "connections-gap"
                                                        })]
                                                    })
                                                }) : null, u ? (0, g.jsx)("div", {
                                                    className: "connections__loader",
                                                    children: (0, g.jsx)("div", {
                                                        style: {
                                                            width: 46,
                                                            height: 46
                                                        },
                                                        children: (0, g.jsx)(b.A, {})
                                                    })
                                                }) : null, O ? null : (0, g.jsxs)("div", {
                                                    className: "connections__content",
                                                    children: [r, (0, g.jsx)("div", {
                                                        className: "connections__items",
                                                        children: (0, g.jsx)("div", {
                                                            className: "connections-items",
                                                            children: t
                                                        })
                                                    }), (0, g.jsx)("div", {
                                                        className: "connections-gap"
                                                    })]
                                                }), s]
                                            })]
                                        })
                                    })
                                })
                            }
                        })
                    })
                },
                Vn = ["isVisible"];

            function qn(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function Hn(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var Qn, Yn, Wn, zn, Kn = function(e) {
                    var t = (0, i.useContext)(Ln.Ay).appRef,
                        n = null == t ? void 0 : t.current,
                        o = e.isVisible,
                        r = function(e, t) {
                            if (null == e) return {};
                            var n = {};
                            for (var i in e)
                                if ({}.hasOwnProperty.call(e, i)) {
                                    if (t.includes(i)) continue;
                                    n[i] = e[i]
                                }
                            return n
                        }(e, Vn);
                    return (0, i.useEffect)((function() {
                        var e = a.A.document.getElementById("page-container");
                        o ? setTimeout((function() {
                            (0, p.A)(e).hide()
                        }), 300) : (0, p.A)(e).show()
                    }), [o]), n && o ? Bn.createPortal((0, g.jsx)(Gn, function(e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var n = null != arguments[t] ? arguments[t] : {};
                            t % 2 ? qn(Object(n), !0).forEach((function(t) {
                                Hn(e, t, n[t])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : qn(Object(n)).forEach((function(t) {
                                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                            }))
                        }
                        return e
                    }({}, r)), n) : null
                },
                Jn = n(40289),
                Xn = n(88029),
                Zn = n(15419);

            function $n(e, t) {
                (0, le.sx)(332, {
                    element: e,
                    parent_element: t
                })
            }

            function ei(e) {
                (0, le.sx)(258, {
                    element: e
                })
            }

            function ti(e, t) {
                (0, le.sx)(139, {
                    banner_id: e.promo_block_type,
                    position_id: e.promo_block_position,
                    context: 127,
                    call_to_action_type: t
                })
            }

            function ni(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function ii(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? ni(Object(n), !0).forEach((function(t) {
                        oi(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : ni(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function oi(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function ri(e, t) {
                return ri = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, ri(e, t)
            }
            var si = {
                    clientSource: 127,
                    preferredCount: 36,
                    userFieldFilter: (new qt.KkJ).setProjection([200, 230, 700, 340, 650, 640, 280, 583, 580, 250, 610, 560, 611, 759, 630, 270, 330, 871, 920, 820, 830, 1120, 1423, 1436, 643, 1435, 1434])
                },
                ai = [B.A.TYPES.VISITORS, B.A.TYPES.MESSAGES, B.A.TYPES.WANT_TO_MEET_YOU, B.A.TYPES.FAVOURITES],
                ci = ((Qn = {})[8] = 187, Qn[6] = 188, Qn[4] = 190, Qn[0] = 189, Qn),
                li = ((Yn = {})[31] = 245, Yn[4] = 249, Yn[8] = 247, Yn[6] = 248, Yn[0] = 246, Yn),
                ui = [57, 1, 10, 56],
                di = ((Wn = {})[12] = 68, Wn[61] = 57, Wn[66] = 56, Wn[88] = 63, Wn[8] = 130, Wn),
                pi = ((zn = {})[B.A.TYPES.MESSAGES] = 26, zn[B.A.TYPES.FAVOURITES] = 23, zn[B.A.TYPES.WANT_TO_MEET_YOU] = 3, zn[B.A.TYPES.VISITORS] = 22, zn),
                fi = [1, 2],
                hi = 0,
                gi = [],
                mi = {},
                vi = function(e) {
                    function t(t) {
                        var n;
                        (n = e.call(this, t) || this).activationPlace = 191, n.screenName = 243, n.clientSource = 127, n.containerRef = void 0, n.modalRef = void 0, n.timeoutId = void 0, n.modally = void 0, n.screenRef = void 0, n.log = Me.A.getLogger("ConnectionsPage"), n.resetCount = (0, o.A)(xi, 1e4), n.previousFilter = void 0, n.selectedFilter = Ve.WC.ALL, n.readItems = [], n.hasSpp = !1, n.hasPhoto = null, n.hasMatchBar = null, n.hasMatchBarStories = !1, n.isLoading = !1, n.isStarted = !1, n.isFinished = !1, n.mostRecentSortTimestamp = void 0, n.forceFetch = !1, n.visibleUserIds = {}, n.userIds = {}, n.usersToRemove = [], n.userSubstitutes = {}, n.folderSyncActive = !1, n.lastBlock = !1, n.pageToken = null, n.syncToken = null, n.savedRemoveUserIds = [], n.banners = void 0, n.deletingUserGender = void 0, n.deletingIds = [], n.reportingUserId = void 0, n.reportAction = "report", n.handleAdsEnabledChange = function() {
                            T.A.isLoggedIn() && n.fetchFolder()
                        }, n.handleItem = function(e) {
                            (0, l.QY)(e) && n.handleUserItem(e), (0, l.vf)(e) && n.handlePromoBlockItem(e)
                        }, n.handleNavigation = function(e) {
                            if (n.isStarted) {
                                var t = n.props.saveScrollPosition;
                                t && !e.backInHistory && t()
                            }
                        }, n.handlePromoButtonClick = function(e, t) {
                            var i = n.getSelectedFilter();
                            n.trackBlockingScreenClick(e, t || 0, null == i ? void 0 : i.folderType), n.applyServerActionHelper(e, t || 0)
                        }, n.handleDismissModally = function() {
                            var e;
                            n.enableFolderSync(), null == (e = n.modally) || e.unmount(), n.setState({
                                isEditing: !1
                            })
                        }, n.turnDeleteModeOff = function() {
                            var e;
                            null == (e = n.modally) || e.unmount()
                        }, n.handleEditModeToggle = function(e, t) {
                            var i;
                            null == (i = n.modally) || i.update({
                                onDismiss: n.handleDismissModally,
                                contentWrapper: n.modalRef.current
                            });
                            var o = n.state.isEditing;
                            if (o ? (l.Ay.getItems().forEach((function(e) {
                                    Object.prototype.hasOwnProperty.call(e, "isChecked") && delete e.isChecked
                                })), n.enableFolderSync()) : n.disableFolderSync(), n.setState({
                                    isEditing: !e && !o
                                }, t), o || e) a.A.clearTimeout(n.timeoutId), n.turnDeleteModeOff();
                            else {
                                var r, s;
                                null == (r = n.modally) || r.modalize(), null == (s = n.modally) || s.focusWrapper();
                                var c = n;
                                n.timeoutId = a.A.setTimeout((function() {
                                    var e, t;
                                    null == (e = c.modally) || e.updateFocusableElements(c.modalRef.current), null == (t = c.modally) || t.toggleFocusTrap(!0)
                                }), 500)
                            }
                        }, n.handleDelete = function() {
                            n.setState({
                                isShowingDeleteModal: !1
                            }), a.A.setTimeout((function() {
                                n.onRemoveUsers(n.deletingIds), n.turnDeleteModeOff()
                            }), 500)
                        }, n.handleClickDelete = function() {
                            var e = Un.A.isActive();
                            n.deletingIds = [], l.Ay.getItems().forEach((function(e) {
                                e.isChecked && (n.deletingIds.push(e.object.user_id), n.deletingUserGender = (0, f.Bt)(e.object.gender))
                            })), Un.A.hit(), e && n.deletingIds.length > 1 && l.Ay.getItems().forEach((function(e) {
                                Object.prototype.hasOwnProperty.call(e, "isChecked") && (e.isDeleting = !0)
                            })), e && 1 === n.deletingIds.length ? (ei(649), n.setState({
                                isShowingDeleteModal: !0
                            })) : n.handleDelete()
                        }, n.handleClickPopularity = function() {
                            n.handleEditModeToggle(!0, (function() {
                                $n(63), O.A.navigate(P.x.POPULARITY)
                            }))
                        }, n.handleClickNewActivityButton = function() {
                            n.unfreeze(), xi(), n.fetchFolder(), (0, le.sx)(332, {
                                element: li[n.getSelectedFilter().folderType]
                            })
                        }, n.handleItemVisible = function(e) {
                            var t = e.origin_folder;
                            n.visibleUserIds[t] || (n.visibleUserIds[t] = []), -1 === n.visibleUserIds[t].indexOf(e.user_id) && n.visibleUserIds[t].push(e.user_id), n.readItems.push(e)
                        }, n.handleBannerVisible = function(e) {
                            ! function(e) {
                                if (e) {
                                    var t = e.promo_block_type,
                                        n = e.promo_block_position,
                                        i = function(e) {
                                            var t = e.promo_block_type,
                                                n = e.context;
                                            return n || 21 !== t || (n = 127), n
                                        }(e);
                                    t && (0, le.sx)(138, {
                                        banner_id: t,
                                        position_id: n,
                                        context: i
                                    })
                                }
                            }(e.getPromoBlock ? e.getPromoBlock() : e)
                        }, n.handleSuperPowersEnabledChange = function(e) {
                            n.hasSpp = e, n.fetchFolder()
                        }, n.handleUserItem = function(e) {
                            var t = e.user_id,
                                i = n.userSubstitutes[t];
                            if (i) {
                                var o;
                                if (function(e) {
                                        if (!e) return;
                                        (0, le.sx)(139, ii(ii({}, e.hotpanelData), {}, {
                                            context: 127
                                        }))
                                    }(i.connectionPromoCard), null != (o = i.connectionPromoCard) && o.showOnTap) return void O.A.navigate(P.x.PROMO_CARDS_GALLERY, {
                                    userSubstitute: i,
                                    context: 26
                                })
                            } else {
                                var r = 4 === e.connection_status_indicator;
                                (0, le.sx)(197, {
                                    activation_place: n.getActivationPlace_(),
                                    encrypted_user_id: t,
                                    is_chat_request: r,
                                    has_mood_status: Boolean(e.mood_status),
                                    has_read_receipt: Boolean(1 === e.last_message_status || 2 === e.last_message_status)
                                })
                            }
                            if (e.is_invisible) O.A.navigate(P.x.INVISIBLE_EXPLANATION, {
                                promoBlock: n.banners.getInvisiblePromo(),
                                activationPlace: 106
                            });
                            else if (e.profile_blocker_promo) {
                                var s = e.profile_blocker_promo;
                                120 === s.ok_action ? n.revealUser(e) : n.applyServerActionHelper(s)
                            } else n.chatWithUser(e)
                        }, n.handlePromoBlockItem = function(e) {
                            ! function(e, t) {
                                var n = function(e) {
                                    switch (e.promo_block_type) {
                                        case 131:
                                            return 10;
                                        case 129:
                                            return 100;
                                        case 130:
                                            return 101;
                                        case 165:
                                            return 14
                                    }
                                    return null
                                }(e);
                                n && (0, le.sx)(332, {
                                    element: n,
                                    parent_element: t || 97
                                })
                            }(e, n.getElementType());
                            var t = function(e) {
                                var t = e.buttons || [];
                                return (t[0] || {}).type || 1
                            }(e);
                            ti(e, t);
                            var i = e.promo_block_type,
                                o = e.promo_block_position,
                                r = e.stats_variation_id,
                                s = 326 === i && 1 === o,
                                a = 346 === i && 1 === o;
                            if (129 === i && 1 === o && 2 === r) O.A.navigate(P.x.LIKED_YOU);
                            else if (s) wn.A.getInstance().getProductExplanation({
                                productType: e.ok_payment_product_type,
                                userId: T.A.getUserId(),
                                clientSource: n.clientSource,
                                promoBlockType: i
                            }).then((function(e) {
                                O.A.navigate(P.x.GET_MORE_LIKES, {
                                    promoBlock: e.promo,
                                    resolve: function() {
                                        return n.fetchFolder({
                                            preventLoading: !0
                                        })
                                    }
                                })
                            })).catch((function(e) {
                                e && (0, Et.A)(e) && n.log.error("Error retrieving product explanation in connections", {
                                    error: e
                                })
                            }));
                            else {
                                if (a) {
                                    var c = {
                                        variantId: e.variant_id,
                                        event: 2,
                                        context: 127,
                                        promoBlockPosition: o
                                    };
                                    return N.A.sendProfileQuestionsBannerStats(c), void O.A.navigate(P.x.PROFILE_QUESTIONS, {
                                        redirectTo: P.x.OWN_PROFILE_EDIT,
                                        preloadQuestions: !0
                                    })
                                }
                                if (e.redirect_page) {
                                    var l = e.redirect_page.redirect_page,
                                        u = Number(Object.keys(pi).find((function(e) {
                                            return pi[Number(e)] === l
                                        }))),
                                        d = Ve.SC.findIndex((function(e) {
                                            return e.folderType === u
                                        })); - 1 !== d && (n.setFilter(Ve.SC[d].param), n.fetchFolder())
                                }
                                n.applyServerActionHelper(e)
                            }
                        }, n.handleSelectTab = function(e) {
                            n.handleEditModeToggle(!0, (function() {
                                n.setCurrentTab(e)
                            }))
                        }, n.setIsShowingSecurityWalkthrough = function(e) {
                            n.setState({
                                isShowingSecurityWalkthroughModal: e
                            })
                        }, n.onAdsEnabledChange = function() {
                            T.A.isLoggedIn() && n.fetchFolder()
                        }, n.onBackOnline = function(e) {
                            n.resendStoredRequests(), n.folderSyncActive && e && e.then(n.fetchFolderUpdates.bind(n))
                        }, n.onBadgeChanged = function(e) {
                            var t = bi([e]);
                            if (n.state.emptyPromo.length && n.fetchFolder({
                                    preventLoading: !0
                                }), t) {
                                var i, o = (null == (i = n.state.badgeUpdates) ? void 0 : i.map((function(e) {
                                    return t.find((function(t) {
                                        return t.folder === e.folder
                                    })) || e
                                }))) || [];
                                t.forEach((function(e) {
                                    null != o && o.find((function(t) {
                                        return t.folder === e.folder
                                    })) || o.push(e)
                                })), n.setState({
                                    badgeUpdates: o
                                })
                            }
                        }, n.onBadgeInvalidated = function() {
                            vn.A.fetch()
                        }, n.onPushChatMessage = function(e) {
                            var t = (0, Mn.A)(e, qt.cMz),
                                i = t.getFromUser(),
                                o = new pn.Ay(t),
                                r = !o.isRead;
                            n.onChatMessage({
                                chatUser: i,
                                userId: o.fromPersonId,
                                id: o.id,
                                displayMessage: o.displayMessage,
                                increaseUnreadMessages: r,
                                showYourMoveBadge: o.isRead
                            })
                        }, n.onChatMessageFromMe = function(e) {
                            n.onChatMessage({
                                userId: String(e.toPersonId),
                                id: e.id,
                                displayMessage: e.displayMessage,
                                increaseUnreadMessages: !1,
                                showYourMoveBadge: !1
                            })
                        }, n.onChatMessage = function(e) {
                            var t = e.userId,
                                i = e.id,
                                o = e.displayMessage,
                                r = e.increaseUnreadMessages,
                                s = e.chatUser,
                                a = e.showYourMoveBadge;
                            if (l.Ay.updateYourMoveBadge(t, a), s && (a ? s.setConnectionStatusIndicator(2) : s.setConnectionStatusIndicator(0)), l.Ay.findIndex(t) > -1) n.updateUser(r, t, o);
                            else {
                                if (i) {
                                    if (gi.includes(i)) return;
                                    gi.push(i)
                                }
                                n.tryFreezeOrUpdate([0, 41])
                            }
                        }, n.onPersonNotice = function(e) {
                            var t = e.folder,
                                i = e.int_value;
                            1 === e.type && void 0 !== t && -1 !== ai.indexOf(t) && (void 0 === mi[t] && (mi[t] = 0), void 0 !== i && (mi[t] < i && n.tryFreezeOrUpdate([t]), mi[t] = i))
                        }, n.onNewMessageRead = function(e, t) {
                            if (e !== T.A.getUserId()) {
                                var i = t.isRead ? "" : t.displayMessage;
                                n.onChatMessage({
                                    userId: e,
                                    id: t.id,
                                    displayMessage: i,
                                    increaseUnreadMessages: !1,
                                    showYourMoveBadge: Boolean(t.isRead)
                                })
                            }
                        }, n.handleFavouriteItem = function(e) {
                            var t = l.Ay.findIndex(e),
                                i = n.isRemoveFromFolderAction(e);
                            On.A.toggleFavouriteStatus({
                                user: e,
                                context: n.clientSource
                            }, (function() {
                                i && n.removeUser(e.user_id)
                            })), (0, le.sx)(123, {
                                action_type: e.is_favourite ? 6 : 7,
                                activation_place: n.getActivationPlace_(),
                                encrypted_user_id: e.user_id
                            }), (0, le.sx)(332, {
                                element: e.is_favourite ? 85 : 86,
                                parent_element: n.getElementType(),
                                position: t
                            })
                        }, n.onFavoriteStateChange = function(e, t) {
                            if (!n.isStarted) {
                                var i = l.Ay.findIndex(e);
                                if (-1 !== i)
                                    if (n.getSelectedFilter().folderType !== B.A.TYPES.FAVOURITES || t) l.Ay.get(i).object.is_favourite = t, n.setState({});
                                    else n.removeUserWhenOpened(e)
                            }
                        }, n.onFeatureUpdate = function(e) {
                            19 === e.feature && n.fetchFolderUpdates()
                        }, n.onFolderResult = function(e) {
                            var t = e.previousFilter,
                                i = e.clientUserList,
                                o = e.shouldGetNextPage,
                                r = void 0 !== o && o,
                                s = e.isUpdates,
                                c = void 0 !== s && s;
                            if (n.isStarted) {
                                if (!n.isFinished && !n.state.isFrozen && t === n.selectedFilter) {
                                    var u = n.getSelectedFilter();
                                    r || c || (n.userIds = {}, (0, le.sx)(258, {
                                        element: n.getElementType()
                                    }), u && u.folderType === B.A.TYPES.COMBINED_CONNECTIONS_ALL && function(e) {
                                        var t = e.toJSON().section || [],
                                            n = 0,
                                            i = 0;
                                        t.forEach((function(e) {
                                            (e.users || []).forEach((function(e) {
                                                e.is_removed || 2 !== (e.last_message_status || 0) || n++, e.is_not_interested && i++
                                            }))
                                        })), (0, le.sx)(29, {
                                            num_admirers_unread: yi(6),
                                            num_favourited_you_unread: yi(4),
                                            num_matches_unread: yi(15),
                                            num_visited_you_unread: yi(8),
                                            num_with_read_receipts: n,
                                            num_letdowns: i,
                                            total_unread: yi(0)
                                        })
                                    }(i));
                                    var d = [];
                                    n.banners.process({
                                        items: d,
                                        clientUserList: i,
                                        isUpdates: c
                                    }), i.getSection([]).forEach((function(e) {
                                        n.addUserSubstitutes_(e.getUserSubstitutes([]));
                                        var t = e.getUsers([]).filter((function(e) {
                                            return !n.userIds[e.getUserId()] && !e.getIsRemoved()
                                        })).map((function(e) {
                                            return e.toJSON()
                                        }));
                                        if (t.sort((function(e, t) {
                                                return t.sort_timestamp - e.sort_timestamp
                                            })), c) {
                                            t = t.filter((function(e) {
                                                return e.sort_timestamp >= n.mostRecentSortTimestamp
                                            }));
                                            var i = e.getUsers([]).filter((function(e) {
                                                    return n.userIds[e.getUserId()]
                                                })).map((function(e) {
                                                    return e.toJSON()
                                                })),
                                                o = i.filter((function(e) {
                                                    return e.is_removed && e.user_id
                                                }));
                                            n.removeUsers(o);
                                            var r = i.filter((function(e) {
                                                return !e.is_removed
                                            }));
                                            l.Ay.getItems().length > 0 && l.Ay.updateUsers(r)
                                        }
                                        t.forEach((function(e) {
                                            n.setTimestamps(e), n.userIds[e.user_id] = !0
                                        })), n.banners.processUsers({
                                            items: d,
                                            users: t
                                        }), c || (n.lastBlock = e.getLastBlock())
                                    })), c || (n.pageToken = i.getPageToken(), n.syncToken = i.getSyncToken());
                                    var p = i.toJSON().promo_banners,
                                        f = [];
                                    p && !r && (f = p.filter((function(e) {
                                        var t = e.promo_block_position;
                                        return 13 === t || 20 === t
                                    }))), f && n.setState({
                                        emptyPromo: f
                                    }), c ? l.Ay.addUpdates(n.banners.prependBanner(d)) : (l.Ay.addPage(d, !r), n.banners.appendBanners()), n.jinba.stop();
                                    var h = n.props,
                                        g = h.navigatedBack,
                                        m = h.scrollPosition;
                                    n.setState({
                                        isLoading: !1
                                    }, (function() {
                                        var e;
                                        g && m && (0, In.V)(a.A, m), null == (e = n.modally) || e.updateFocusableElements(n.modalRef.current)
                                    })), n.isLoading = !1, (0, kn.A)("Connections interactive", 5)
                                }
                            } else n.isLoading = !1
                        }, n.onFolderError = function(e) {
                            n.setState({
                                isLoading: !1
                            }), n.isLoading = !1, n.isStarted && (e && (0, r.A)(e.getType) && e.getType() === Nn.a5.OFFLINE || gn.A.handleError({
                                error: e,
                                screenName: n.getScreenName()
                            }))
                        }, n.onNewOfflineMessage = function(e, t) {
                            var i = l.Ay.findIndex(t.getUserId());
                            l.Ay.get(i).object.display_message = e, n.setState({})
                        }, n.onRemoveUsers = function(e) {
                            var t, i;
                            if (null != e && e.length) {
                                n.removeUsers(e), n.setState({
                                    isEditing: !1
                                });
                                var o, r = null == (t = n.getSelectedFilter()) ? void 0 : t.activationPlace;
                                if (e.forEach((function(e) {
                                        (0, le.sx)(580, {
                                            encrypted_user_id: e,
                                            activation_place: r,
                                            mode_connection: 6
                                        })
                                    })), !Sn.A.isOnline())(o = n.savedRemoveUserIds).push.apply(o, e);
                                var s = n.getCurrentTab().context,
                                    a = [B.A.getInstance().removeUsers({
                                        activationPlace: r,
                                        folderId: 56,
                                        ids: e,
                                        context: s
                                    })];
                                (null == (i = n.getSelectedFilter()) ? void 0 : i.folderType) === B.A.TYPES.FAVOURITES && a.push(B.A.getInstance().removeUsers({
                                    activationPlace: r,
                                    folderId: 4,
                                    ids: e,
                                    avoidHotpanelTracking: !0,
                                    context: s
                                })), Promise.all(a).then(n.updateFolderIfEmpty.bind(n))
                            }
                        }, n.handleSelectItem = function(e, t) {
                            var i = 99;
                            (0, l.QY)(e) && (e.is_conversation ? i = 11 : e.is_crush ? i = 18 : e.favourited_you ? i = 9 : e.is_invisible ? i = 93 : 6 === e.origin_folder ? i = 5 : e.is_match ? i = 354 : e.is_visitor ? i = 6 : e.is_favourite && (i = 13)), ie.A.generate(), (0, le.sx)(332, {
                                element: i,
                                parent_element: n.getElementType(),
                                position: t
                            }), n.handleItem(e)
                        }, n.handleUnmatch = function(e) {
                            n.reportAction = "unmatch", n.reportingUserId = e.user_id, n.setState({
                                isReporting: !0
                            })
                        }, n.handleReport = function(e) {
                            n.reportAction = "report", n.reportingUserId = e.user_id, n.setState({
                                isReporting: !0
                            })
                        }, n.handleBlock = function(e) {
                            n.reportAction = "block", n.reportingUserId = e.user_id, n.setState({
                                isReporting: !0
                            })
                        }, n.handleTrackScroll = function(e) {
                            var t = l.Ay.getItems();
                            (0, le.sx)(195, {
                                direction: 5,
                                element: n.getElementType(),
                                reached_end: e > t.length - 1,
                                position: e
                            })
                        }, n.handleNeedPage = function() {
                            n.isLoading || n.lastBlock || n.fetchFolder({
                                shouldGetNextPage: !0
                            })
                        }, n.onSystemNotification = function(e) {
                            var t = e.id;
                            21 === t ? n.fetchFolderUpdates() : 25 === t && n.onUserIdExchanged(e.previous_id, e.current_id)
                        }, n.onUserIdExchanged = function(e, t) {
                            if (void 0 !== n.userIds[e]) {
                                n.userIds[t] = n.userIds[e], delete n.userIds[e];
                                var i = l.Ay.findIndex(e);
                                if (-1 === i) return;
                                l.Ay.get(i).object.user_id = t, n.isStarted && n.setState({})
                            }
                        }, n.tryFreezeOrUpdate = function(e) {
                            var t, i;
                            0 !== n.getCurrentTab().connectionTypes.filter((function(t) {
                                return e.includes(t)
                            })).length && (hi += 1, t = a.A.innerHeight || (0, Te.A)().clientHeight, i = (0, Te.A)().scrollHeight > t, hi > 3 && i ? n.freeze() : n.folderSyncActive && n.fetchFolderUpdates(), n.resetCount())
                        }, n.freeze = function() {
                            n.setState({
                                isFrozen: !0
                            }), n.disableFolderSync()
                        }, n.unfreeze = function() {
                            n.setState({
                                isFrozen: !1
                            }), n.enableFolderSync()
                        }, n.handleModalReport = function() {
                            $n(87, 649), n.reportAction = "report", n.reportingUserId = n.deletingIds[0], n.setState({
                                isReporting: !0,
                                isShowingDeleteModal: !1
                            })
                        }, n.handleModalDelete = function() {
                            $n(106, 649), n.handleDelete()
                        }, n.renderDeleteModal = function() {
                            return n.state.isShowingDeleteModal ? (0, g.jsx)(on, {
                                header: f.Ay.get(154),
                                text: f.Ay.get(385, {
                                    other_user: hn.ko.for("other_user", n.deletingUserGender)
                                }),
                                onReport: n.handleModalReport,
                                onDelete: n.handleModalDelete,
                                onCancel: function() {
                                    n.setState({
                                        isShowingDeleteModal: !1
                                    })
                                }
                            }) : null
                        }, n.handleReportingSuccess = function() {
                            var e = n.reportingUserId || n.deletingIds[0];
                            n.setState({
                                isReporting: !1,
                                isShowingDeleteModal: !1,
                                isEditing: !1
                            }), e && n.removeUser(e), n.reportingUserId = void 0
                        }, n.handleSelectSortOption = function(e) {
                            n.setCurrentSortOption(e)
                        }, n.handleToggleSortOptionsModal = function() {
                            n.setState({
                                isShowingSortOptionsModal: !n.state.isShowingSortOptionsModal
                            })
                        }, n.renderSortOptionsModal = function() {
                            return n.state.isShowingSortOptionsModal ? (0, g.jsx)(dn, {
                                currentTab: n.getCurrentTab(),
                                onSelectOption: n.handleSelectSortOption,
                                hideSortOptions: n.handleToggleSortOptionsModal
                            }) : null
                        }, n.renderSortOptionsButton = function() {
                            return (0, g.jsx)(cn, {
                                currentTab: n.getCurrentTab(),
                                currentSortOption: n.getCurrentSortOption(),
                                onClick: n.handleToggleSortOptionsModal
                            })
                        }, n.getEmptyPromoFlags = function(e) {
                            var t = n.getTab(e);
                            return {
                                hasUsers: l.Ay.getUsers(t.connectionTypes).length > 0,
                                showFullscreenPromo: n.state.emptyPromo.some((function(e) {
                                    return 20 === e.promo_block_position
                                })),
                                isEditButtonHidden: n.state.emptyPromo.some((function(e) {
                                    return e.context === t.context && 13 === e.promo_block_position
                                }))
                            }
                        }, n.renderEmptyPromo = function(e) {
                            var t, i = n.getTab(e),
                                o = n.state.emptyPromo.filter((function(e) {
                                    return e.context === i.context
                                })),
                                r = [],
                                s = [];
                            if (null == (t = o) || t.forEach((function(e) {
                                    20 === e.promo_block_position ? r.push(e) : s.push(e)
                                })), (o = [].concat(r, s)).length) {
                                var a = o[0];
                                return (0, g.jsx)(Oe, {
                                    promoBlock: a,
                                    onClick: n.handlePromoButtonClick,
                                    sendTrackingOnMount: function() {
                                        n.trackBlockingScreenView(a, i.type)
                                    }
                                })
                            }
                        }, n.getTab = function(e) {
                            return n.state.tabConfig.find((function(t) {
                                return t.type === e
                            }))
                        }, n.getCurrentTab = function() {
                            return n.state.tabConfig.find((function(e) {
                                return e.isCurrent
                            }))
                        }, n.setCurrentTab = function(e) {
                            var t = n.state.tabConfig.map((function(t) {
                                    return ii(ii({}, t), {}, {
                                        isCurrent: t.type === e
                                    })
                                })),
                                i = t.find((function(e) {
                                    return e.isCurrent
                                }));
                            n.setState({
                                tabConfig: t,
                                currentTab: e
                            }), O.A.navigate(P.x.CONNECTIONS, !0, {
                                filter: i.route
                            })
                        }, n.getCurrentSortOption = function() {
                            return n.getCurrentTab().sortOptions.find((function(e) {
                                return e.isCurrent
                            }))
                        }, n.setCurrentSortOption = function(e) {
                            var t = n.getCurrentTab().type,
                                i = n.state.tabConfig.map((function(n) {
                                    if (n.type === t) {
                                        var i = n.sortOptions.map((function(t) {
                                            return ii(ii({}, t), {}, {
                                                isCurrent: t.variant === e
                                            })
                                        }));
                                        return ii(ii({}, n), {}, {
                                            sortOptions: i
                                        })
                                    }
                                    return n
                                }));
                            n.setState({
                                tabConfig: i,
                                currentSortOption: e
                            })
                        };
                        var c = t.parameters.filter ? t.parameters.filter : Ve.WC.ALL;
                        Ve.SC.some((function(e) {
                            return e.param === c
                        })) || (c = Ve.WC.ALL);
                        var u = mn.A.getSettings(),
                            d = (0, Zn.gW)(u, t.parameters.filter),
                            p = d.find((function(e) {
                                return e.isCurrent
                            })),
                            h = p.sortOptions.find((function(e) {
                                return e.isCurrent
                            }));
                        return n.state = {
                            tabConfig: d,
                            currentTab: p.type,
                            currentSortOption: h.variant,
                            currentFilter: c,
                            isEditing: !1,
                            isLoading: !1,
                            isFrozen: !1,
                            isShowingSortOptionsModal: !1,
                            isShowingDeleteModal: !1,
                            isReporting: !1,
                            emptyPromo: [],
                            isShowingSecurityWalkthroughModal: !1
                        }, n.fetchFolderUpdates = (0, s.A)(n.fetchFolderUpdates, 1e3, {
                            leading: !0
                        }), _n.A.getInstance().on(_n.A.Type.PERSON_NOTICE, n.onPersonNotice, n).on(_n.A.Type.CHAT_MESSAGE, n.onPushChatMessage, n), An.A.on(An.A.EVENTS.MESSAGE_FROM_ME, n.onChatMessageFromMe, n).on(An.A.EVENTS.NEW_MESSAGE_READ, n.onNewMessageRead, n), n.banners = new ve({
                            onPromoClick: n.unfreeze,
                            getActivationPlace: n.getActivationPlace_.bind(n),
                            getElementType: n.getElementType.bind(n),
                            getFolderType: function() {
                                var e;
                                return null == (e = n.getSelectedFilter()) ? void 0 : e.folderType
                            },
                            setIsShowingSecurityWalkthrough: function() {
                                n.setIsShowingSecurityWalkthrough(!0)
                            }
                        }), n.hasMatchBarStories = Re.A.getSync(333).enabled, n.containerRef = (0, i.createRef)(), n.screenRef = (0, i.createRef)(), n.modalRef = (0, i.createRef)(), n.modally = new Jn.A, n
                    }
                    var n, c;
                    c = e, (n = t).prototype = Object.create(c.prototype), n.prototype.constructor = n, ri(n, c);
                    var u = t.prototype;
                    return u.componentDidMount = function() {
                        var t = this;
                        e.prototype.componentDidMount.call(this), this.isStarted = !0, En.A.onFavoriteStateChange(this.onFavoriteStateChange), On.A.on(On.A.EVENTS.USER_CHANGED_TS, this.updateCurrentUser, this).on(On.A.EVENTS.ONLINE, this.onBackOnline, this), Pn.subscribe(this.onUserIdExchanged, this), An.A.on(An.A.EVENTS.NEW_OFFLINE_MESSAGE, this.onNewOfflineMessage, this), this.jinba = new Cn.A("CombinedConnections", 4), fn.A.on(fn.A.USER_BLOCKED, (function(e) {
                            return t.removeBlockedUser(e)
                        })).on(fn.A.VOTED_NO, (function(e) {
                            return t.removeUserWhenOpened(e)
                        })).on(fn.A.USER_CONVERSATION_DELETED, (function(e) {
                            var n, i = null == (n = t.getSelectedFilter()) ? void 0 : n.param;
                            i && i !== Ve.WC.CHATS || t.removeUserWhenOpened(e)
                        })), O.A.navigationEvent.subscribe(this.handleNavigation, this), vn.A.on(vn.A.EVENTS.CHANGE, this.onBadgeChanged, this).on(vn.A.EVENTS.INVALIDATED, this.onBadgeInvalidated, this);
                        var n = this.getParameter("filter");
                        n || (n = Ve.SC[0].param);
                        var i = Boolean(Rn.v.value),
                            o = Re.A.getSync(1).enabled,
                            r = Re.A.getSync(268).enabled,
                            s = !this.forceFetch && i === this.hasSpp && o === this.hasPhoto && r === this.hasMatchBar && (n === this.selectedFilter || this.wasBack() && this.previousFilter);
                        this.hasSpp = i, this.hasPhoto = o, this.forceFetch = !1, this.hasMatchBar = r, s || this.previousFilter && (this.previousFilter = void 0), this.fetchPopularity();
                        var a = this.usersToRemove.splice(0);
                        this.shouldFetchOnStart(Boolean(s)) ? (this.setFilter(n), this.fetchFolder()) : (a.forEach((function(e) {
                            return t.removeUser(e)
                        })), this.wasBack() && !this.state.isFrozen && (xi(), this.fetchFolderUpdates())), this.readItems.length > 0 && (this.readItems.forEach((function(e) {
                            e.is_unread = !1, e.unread_messages_count = 0
                        })), this.readItems = []), vn.A.trackNext().get().then(this.setBadgeCounters.bind(this)), Rn.v.changeEvent.subscribe(this.handleSuperPowersEnabledChange, this), this.enableFolderSync(), U.A.enabledChangeEvent.subscribe(this.handleAdsEnabledChange), this.selectedFilter !== this.state.currentFilter && this.setFilter(this.state.currentFilter)
                    }, u.componentWillUnmount = function() {
                        e.prototype.componentWillUnmount.call(this), this.isFinished = !0, this.resetCount.cancel(), O.A.navigationEvent.unsubscribe(this.handleNavigation, this), this.markPeopleViewed(), vn.A.off(vn.A.EVENTS.CHANGE, this.onBadgeChanged, this).off(vn.A.EVENTS.INVALIDATED, this.onBadgeInvalidated, this), Rn.v.changeEvent.unsubscribe(this.handleSuperPowersEnabledChange, this), this.folderSyncActive && this.disableFolderSync(), U.A.enabledChangeEvent.unsubscribe(this.handleAdsEnabledChange), U.A.destroy(U.A.placements.CONNECTIONS), _n.A.getInstance().off(_n.A.Type.PERSON_NOTICE, this.onPersonNotice, this).off(_n.A.Type.CHAT_MESSAGE, this.onPushChatMessage, this), An.A.off(An.A.EVENTS.MESSAGE_FROM_ME, this.onChatMessageFromMe, this).off(An.A.EVENTS.NEW_MESSAGE_READ, this.onNewMessageRead, this)
                    }, u.getElementType = function() {
                        var e;
                        return null == (e = this.getSelectedFilter()) ? void 0 : e.elementType
                    }, u.getActivationPlace_ = function() {
                        return this.getSelectedFilter().activationPlace
                    }, u.getSelectedFilter = function() {
                        var e = this;
                        return Ve.SC.find((function(t) {
                            return t.param === e.selectedFilter
                        }))
                    }, u.setFilter = function(e) {
                        if (e !== this.selectedFilter) {
                            var t = Ve.SC.find((function(t) {
                                return t.param === e
                            }));
                            t && (this.selectedFilter = e, this.activationPlace = t.activationPlace, this.setState({
                                currentFilter: e
                            }), this.enableFolderSync())
                        }
                    }, u.isRemoveFromFolderAction = function(e) {
                        var t = this.getSelectedFilter();
                        return t && t.folderType === B.A.TYPES.FAVOURITES && !e.favourited_you
                    }, u.applyServerActionHelper = function(e, t) {
                        var n, i = this;
                        void 0 === t && (t = 0), e.promo_block_type || this.log.error("I cannot handle the promo block after block action because promo_block_type does not exist", {
                            typeOfPromoBlock: typeof e,
                            promoBlock: e
                        }), this.unfreeze();
                        var o, r = null == (n = e.buttons) ? void 0 : n[t],
                            s = r ? r.action : e.ok_action,
                            a = r ? r.redirect_page : e.redirect_page;
                        a && (a = (new qt.gGJ).setRedirectPage(null == (o = a) ? void 0 : o.redirect_page));
                        var c = e.promo_block_type;
                        this.forceFetch = 165 === c;
                        var l = (new bn.A).setAction(s).setRedirectPage(a).setProductType(e.ok_payment_product_type).setPromoBlockType(c).setPromoBlock(e).setBack(O.A.getUrl()).setHotPanelData({
                            activationPlace: this.getActivationPlace_()
                        });
                        12 === c && l.setCallback(this.fetchFolder.bind(this)), jn.A.handleAction(l).then((function() {
                            418 === c && i.fetchFolder({
                                preventLoading: !0
                            })
                        }))
                    }, u.clearFolderSyncVariables = function() {
                        this.mostRecentSortTimestamp = void 0
                    }, u.chatWithUser = function(e) {
                        var t = e.origin_folder,
                            n = pi[t];
                        e.is_unread = !1, e.unread_messages_count = 0, this.setState({
                            isEditing: !1
                        });
                        var i = e.user_id,
                            o = this.userSubstitutes[i];
                        !Number(i) && i.length < 20 && this.log.error("WRONG USER ID: " + i + " from chatWithUser_"), O.A.navigate(P.x.MESSAGES, {
                            id: i,
                            folderId: t,
                            context: 26,
                            clientSource: n,
                            toClientSource: n,
                            fromConnectionsList: !0,
                            userSubstitute: o
                        })
                    }, u.markPeopleViewed = function() {
                        var e = this;
                        Object.keys(this.visibleUserIds).forEach((function(t) {
                            var n = e.visibleUserIds[t];
                            B.A.getInstance().markPeopleViewed({
                                context: 22,
                                folderId: Number(t),
                                peopleIds: n
                            }, !0)
                        })), this.visibleUserIds = {}
                    }, u.removeUser = function(e) {
                        -1 !== l.Ay.findIndex(e) ? (this.userIds[e] = !1, l.Ay.removeItem(e), this.setState({
                            isLoading: !1
                        }), this.updateFolderIfEmpty()) : this.log.error("Connections - Removing a user which doesnt exist in our connections (userIds value is " + this.userIds[e] + ")")
                    }, u.removeUsers = function(e) {
                        var t = this;
                        e.forEach((function(e) {
                            t.userIds[e] = !1, l.Ay.removeItem(e), An.A.invalidate(e), t.userSubstitutes[e] && xn.A.reportEventDismiss({
                                promoCard: t.userSubstitutes[e].contentModePromoCards[0],
                                context: 26
                            })
                        }))
                    }, u.removeBlockedUser = function(e) {
                        -1 !== l.Ay.findIndex(e) && this.removeUserWhenOpened(e)
                    }, u.removeUserWhenOpened = function(e) {
                        this.isStarted ? this.removeUser(e) : this.usersToRemove.push(e)
                    }, u.resendStoredRequests = function() {
                        this.savedRemoveUserIds.length > 0 && (this.onRemoveUsers(this.savedRemoveUserIds.concat([])), this.savedRemoveUserIds = [])
                    }, u.revealUser = function(e) {
                        var t, n = this,
                            i = null == e ? void 0 : e.user_id;
                        B.A.getInstance().revealUser({
                            personId: i,
                            folderId: null == (t = this.getSelectedFilter()) ? void 0 : t.folderType
                        }).then((function(e) {
                            var t = e[0],
                                o = null == t ? void 0 : t.getSection();
                            if (o) {
                                var r = o[0],
                                    s = ((null == r ? void 0 : r.getUsers()) || [])[0];
                                n.replaceRevealedUser(i, null == s ? void 0 : s.getUserId())
                            } else n.log.error("Error revealing user: Server did not return any sections")
                        })).catch((function(e) {
                            n.log.error("Error revealing user:", e), L.A.showNotification({
                                type: L.A.TYPES.ERROR
                            })
                        }))
                    }, u.replaceRevealedUser = function(e, t) {
                        var n = this;
                        return this.fetchFolderRequest().then((function(i) {
                            var o = i[0],
                                r = ((null == o ? void 0 : o.getSection()) || [])[0],
                                s = null == r ? void 0 : r.getUsers(),
                                a = null == s ? void 0 : s.find((function(e) {
                                    return e.getUserId() === t
                                }));
                            if (a) {
                                var c = l.Ay.findIndex(e),
                                    u = l.Ay.get(c);
                                u && (u.object = a, l.Ay.replaceItem(u, c), n.setState({
                                    isLoading: !1
                                }))
                            }
                        }))
                    }, u.setBadgeCounters = function(e) {
                        if (e) {
                            var t = e.notices,
                                n = e.values,
                                i = bi(t);
                            mi = n, this.setState({
                                badgeUpdates: i
                            })
                        }
                    }, u.shouldFetchOnStart = function(e) {
                        var t = !(this.wasBack() && e || this.previousFilter),
                            n = 0 === l.Ay.getItems().length && !this.state.emptyPromo.length && !this.isLoading;
                        return t || n
                    }, u.trackBlockingScreenView = function(e, t) {
                        var n;
                        (e.promo_block_type || this.log.error("I cannot track ViewElement event after block show because getPromoBlockType is not a function", {
                            typeOfPromoBlock: typeof e,
                            promoBlock: e
                        }), 418 === e.promo_block_type) && (t === Ve.n7.ALL_MESSAGES ? n = 189 : t === Ve.n7.ACTIVITY && (n = 1387), n && ei(n))
                    }, u.trackBlockingScreenClick = function(e, t, n) {
                        var i;
                        e.promo_block_type || this.log.error("I cannot track Click event after block action because getPromoBlockType is not a function", {
                            typeOfPromoBlock: typeof e,
                            promoBlock: e
                        });
                        var o = e.promo_block_type;
                        ui.includes(o) && 2 === (null == (i = e.buttons) ? void 0 : i.length) && void 0 !== t && fi[t] && ti(e, fi[t]);
                        var r = di[o];
                        if (r) {
                            var s = function(e, t) {
                                if (12 === e) return 41;
                                if (t && ci[t]) return ci[t];
                                return 71
                            }(o, n);
                            $n(r, s)
                        }
                    }, u.addUserSubstitutes_ = function(e) {
                        var t = this;
                        e.forEach((function(e) {
                            t.userSubstitutes[e.getId()] = new xn.A({
                                userSubstitute: e
                            })
                        }))
                    }, u.getUserSubstitute = function(e) {
                        return this.userSubstitutes[e]
                    }, u.updateCurrentUser = function(e) {
                        this.isRemoveFromFolderAction(e) || this.setState({
                            isLoading: !1
                        })
                    }, u.updateUser = function(e, t, n) {
                        var i = l.Ay.findIndex(t);
                        if (i > -1) {
                            var o = l.Ay.get(i),
                                r = o.object;
                            n && (r.display_message = n), e && (r.unread_messages_count = (r.unread_messages_count || 0) + 1), o.object = r;
                            var s = l.Ay.hasTopMostPromo(),
                                a = 0 === i || 1 === i && s;
                            this.state.isFrozen || a ? l.Ay.replaceItem(o, i) : (o.isUpdate = !0, l.Ay.moveItemToTop(o, i)), this.setState({})
                        }
                    }, u.updateFolderIfEmpty = function() {
                        var e = this.getCurrentTab();
                        l.Ay.getUsers(e.connectionTypes).length > 0 || this.fetchFolder()
                    }, u.enableFolderSync = function() {
                        this.folderSyncActive || (this.folderSyncActive = !0, _n.A.getInstance().on(_n.A.Type.SYSTEM_NOTIFICATION, this.onSystemNotification, this), Re.A.on(Re.A.EVENTS.UPDATE, this.onFeatureUpdate, this))
                    }, u.disableFolderSync = function() {
                        this.folderSyncActive && (this.folderSyncActive = !1, _n.A.getInstance().off(_n.A.Type.SYSTEM_NOTIFICATION, this.onSystemNotification, this), Re.A.off(Re.A.EVENTS.UPDATE, this.onFeatureUpdate, this))
                    }, u.fetchFolder = function(e) {
                        var t = this;
                        void 0 === e && (e = {});
                        var n = e.shouldGetNextPage;
                        this.isLoading = !0, e.preventLoading || n || this.setState({
                            isLoading: !0
                        }), this.fetchFolderRequest(n).then((function(e) {
                            var i = e[0];
                            t.onFolderResult({
                                shouldGetNextPage: n,
                                previousFilter: t.selectedFilter,
                                clientUserList: i
                            })
                        })).catch(this.onFolderError), this.fetchBanners()
                    }, u.fetchBanners = function() {
                        var e = this,
                            t = this.banners.getShownPromoBlocks();
                        this.banners.fetch({
                            shownPromoBlocks: t
                        }).then((function(t) {
                            var n = t[0];
                            e.banners.setPromoBlocks({
                                promos: n.toJSON().promo_blocks || []
                            }), e.banners.appendBanners()
                        }))
                    }, u.fetchFolderRequest = function(e) {
                        e || (this.clearFolderSyncVariables(), this.setState({
                            emptyPromo: []
                        }), this.banners.reset(), U.A.destroy(U.A.placements.CONNECTIONS));
                        var t = {
                            promoBlockRequestParams: [{
                                shownPromoBlocks: this.banners.getShownPromoBlocks(),
                                position: 1,
                                count: 2
                            }, !e && {
                                position: 8,
                                count: 1
                            }].filter(Boolean)
                        };
                        e && (t.pageToken = this.pageToken), t.direction = 1;
                        var n = ii(ii(ii({}, t), si), {
                            folderId: B.A.TYPES.MESSAGES_AND_ACTIVITY
                        });
                        return B.A.getInstance().fetch(n, !0, !0)
                    }, u.fetchFolderUpdates = function() {
                        var e = this;
                        if (!this.isLoading && !this.state.isFrozen)
                            if (this.syncToken) {
                                this.isLoading = !0;
                                var t = ii(ii(ii({}, {
                                    direction: 2,
                                    includeTransient: !1,
                                    syncToken: this.syncToken
                                }), si), {
                                    folderId: B.A.TYPES.MESSAGES_AND_ACTIVITY
                                });
                                B.A.getInstance().fetch(t, !0, !0).then((function(t) {
                                    var n = t[0];
                                    e.state.isFrozen || e.onFolderResult({
                                        previousFilter: e.selectedFilter,
                                        clientUserList: n,
                                        isUpdates: !0
                                    })
                                })).catch(this.onFolderError)
                            } else this.fetchFolder()
                    }, u.fetchPopularity = function() {
                        var e = this;
                        yn.A.getInstance().get({
                            id: T.A.getUserId(),
                            clientSource: 127,
                            requestedFields: [690]
                        }).then((function(t) {
                            e.setState({
                                popularityLevel: Ai(t.getPopularityLevel())
                            })
                        }))
                    }, u.setTimestamps = function(e) {
                        var t = e.sort_timestamp;
                        (!this.mostRecentSortTimestamp || t > this.mostRecentSortTimestamp) && (this.mostRecentSortTimestamp = t)
                    }, u.renderNavigation = function() {
                        var e = this,
                            t = (0, Xn.A)(253),
                            n = t.header_text,
                            i = t.subheader_text;
                        return (0, g.jsx)(_t, ii({
                            header: n,
                            subHeader: i,
                            popularityLevel: this.state.popularityLevel,
                            isEditing: this.state.isEditing,
                            onClickEdit: function() {
                                return e.handleEditModeToggle()
                            },
                            onClickPopularity: this.handleClickPopularity,
                            onClickNotifications: function() {
                                return e.handleSelectTab(Ve.n7.ACTIVITY)
                            }
                        }, this.getEmptyPromoFlags(Ve.n7.ALL_MESSAGES)))
                    }, u.renderMatchBar = function() {
                        return (0, g.jsx)(Zt, {
                            hasMatchBarStories: this.hasMatchBarStories
                        })
                    }, u.renderSecurityWalkthroughModal = function() {
                        var e = this;
                        return (0, g.jsx)(Dn.A, {
                            onDismissModal: function() {
                                e.setIsShowingSecurityWalkthrough(!1)
                            },
                            context: 127
                        })
                    }, u.renderConnectionsList = function(e) {
                        var t = this.getTab(e);
                        return (0, g.jsx)(xt, {
                            currentFilter: this.getSelectedFilter(),
                            currentTab: t.connectionTypes,
                            currentPromoContext: t.context,
                            currentSortOption: this.getCurrentSortOption().variant,
                            isLoading: this.state.isLoading,
                            isEditing: this.state.isEditing,
                            getUserSubstitute: this.getUserSubstitute.bind(this),
                            onSelectItem: this.handleSelectItem,
                            onFavouriteItem: this.handleFavouriteItem,
                            onTrackScroll: this.handleTrackScroll,
                            onItemVisible: this.handleItemVisible,
                            onBannerVisible: this.handleBannerVisible,
                            onNeedPage: this.handleNeedPage,
                            onBlock: this.handleBlock,
                            onReport: this.handleReport,
                            onUnmatch: this.handleUnmatch
                        })
                    }, u.renderDeleteButton = function() {
                        return (0, g.jsx)(en, {
                            isActive: this.state.isEditing,
                            onClick: this.handleClickDelete
                        })
                    }, u.render = function() {
                        var e = this,
                            t = (0, g.jsx)(j, ii({
                                emptyPromo: this.renderEmptyPromo(Ve.n7.ALL_MESSAGES),
                                navigation: this.renderNavigation(),
                                matchBar: this.renderMatchBar(),
                                connectionsList: this.renderConnectionsList(Ve.n7.ALL_MESSAGES),
                                deleteButton: this.renderDeleteButton(),
                                isLoading: this.state.isLoading,
                                isEditing: this.state.isEditing,
                                isFrozen: this.state.isFrozen,
                                hasMatchBarStories: this.hasMatchBarStories,
                                containerRef: this.containerRef,
                                screenRef: this.screenRef,
                                onClickNewActivityButton: this.handleClickNewActivityButton,
                                sortOptionsButton: this.renderSortOptionsButton(),
                                securityWalkthroughModal: this.state.isShowingSecurityWalkthroughModal ? this.renderSecurityWalkthroughModal() : void 0,
                                currentTab: this.state.currentTab,
                                modalRef: this.modalRef,
                                isReporting: this.state.isReporting,
                                reportAction: this.reportAction,
                                onReportingClose: function() {
                                    return e.setState({
                                        isReporting: !1
                                    })
                                },
                                onReportingSuccess: this.handleReportingSuccess,
                                reportingId: this.reportingUserId || this.deletingIds[0]
                            }, this.getEmptyPromoFlags(Ve.n7.ALL_MESSAGES))),
                            n = (0, g.jsx)(Kn, ii({
                                connectionsList: this.renderConnectionsList(Ve.n7.ACTIVITY),
                                emptyPromo: this.renderEmptyPromo(Ve.n7.ACTIVITY),
                                matchBar: this.renderMatchBar(),
                                sortOptionsButton: this.renderSortOptionsButton(),
                                deleteButton: this.renderDeleteButton(),
                                hasMatchBarStories: this.hasMatchBarStories,
                                isLoading: !1,
                                isEditing: this.state.isEditing,
                                isVisible: this.state.currentTab === Ve.n7.ACTIVITY,
                                onBackClick: function() {
                                    return e.handleSelectTab(Ve.n7.ALL_MESSAGES)
                                },
                                onEditButtonClick: function() {
                                    return e.handleEditModeToggle()
                                }
                            }, this.getEmptyPromoFlags(Ve.n7.ACTIVITY)));
                        return this.addPageWrapper((0, g.jsxs)(i.Fragment, {
                            children: [t, n, this.renderSortOptionsModal(), this.renderDeleteModal()]
                        }), "connections")
                    }, t
                }(c.A);

            function Ai(e) {
                switch (e) {
                    case 10:
                    default:
                        return St.s7.VERY_LOW;
                    case 20:
                        return St.s7.LOW;
                    case 30:
                        return St.s7.AVERAGE;
                    case 40:
                        return St.s7.HIGH;
                    case 50:
                        return St.s7.VERY_HIGH
                }
            }

            function yi(e) {
                return vn.A.getCached().values[e] || 0
            }

            function bi(e) {
                var t = [];
                return e.forEach((function(e) {
                    if (e) {
                        var n = e.filter_display_values;
                        n && n.forEach((function(n) {
                            t.push({
                                folder: e.folder,
                                value: n.int_value,
                                filter: n.filter
                            })
                        })), t.push({
                            folder: e.folder,
                            value: e.int_value
                        })
                    }
                })), t
            }

            function xi() {
                hi = 0, gi = []
            }
            vi.hasTabBar = !0, vi.transition = !1;
            var Si = vi
        },
        91110: function(e, t, n) {
            var i;
            n.d(t, {
                    D: function() {
                        return i
                    }
                }),
                function(e) {
                    e.VIEW = "VIEW", e.SHARE = "SHARE"
                }(i || (i = {}))
        },
        93765: function(e, t, n) {
            n(52675), n(45700), n(2008), n(51629), n(74423), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(21699), n(98992), n(54520), n(3949), n(23500);
            var i = n(17380),
                o = n(45141),
                r = n(74848),
                s = ["media", "label", "isChecked", "dataQA"];

            function a(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function c(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            t.A = function(e) {
                var t = e.media,
                    n = e.label,
                    l = e.isChecked,
                    u = e.dataQA,
                    d = function(e, t) {
                        if (null == e) return {};
                        var n = {};
                        for (var i in e)
                            if ({}.hasOwnProperty.call(e, i)) {
                                if (t.includes(i)) continue;
                                n[i] = e[i]
                            }
                        return n
                    }(e, s),
                    p = (0, r.jsx)(i.A, function(e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var n = null != arguments[t] ? arguments[t] : {};
                            t % 2 ? a(Object(n), !0).forEach((function(t) {
                                c(e, t, n[t])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach((function(t) {
                                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                            }))
                        }
                        return e
                    }({
                        type: "radio",
                        isChecked: l
                    }, d));
                return n ? (0, r.jsx)(o.A, {
                    media: t,
                    title: n,
                    extra: p,
                    tag: "label",
                    isSelected: l,
                    dataQA: u
                }) : p
            }
        },
        98666: function(e, t, n) {
            var i;
            n.d(t, {
                i: function() {
                    return o
                }
            });
            var o = ((i = {})[200] = 39, i[220] = 8, i[10] = 7, i[230] = 9, i[20] = 12, i)
        }
    }
]);
//# sourceMappingURL=connections.90d0d0c5cf68dd0788f7.js.map
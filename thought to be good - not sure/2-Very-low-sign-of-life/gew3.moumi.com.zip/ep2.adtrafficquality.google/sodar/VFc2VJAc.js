(function() {
    var n, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ca = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        da = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        q = da(this),
        r = function(a, b) {
            if (b) a: {
                var c = q;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && ca(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        };
    r("Symbol", function(a) {
        if (a) return a;
        var b = function(g, f) {
            this.Ja = g;
            ca(this, "description", {
                configurable: !0,
                writable: !0,
                value: f
            })
        };
        b.prototype.toString = function() {
            return this.Ja
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            d = 0,
            e = function(g) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (g || "") + "_" + d++, g)
            };
        return e
    });
    r("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = q[b[c]];
            typeof d === "function" && typeof d.prototype[a] != "function" && ca(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return ea(aa(this))
                }
            })
        }
        return a
    });
    var ea = function(a) {
            a = {
                next: a
            };
            a[Symbol.iterator] = function() {
                return this
            };
            return a
        },
        fa = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ha;
    if (typeof Object.setPrototypeOf == "function") ha = Object.setPrototypeOf;
    else {
        var ia;
        a: {
            var ja = {
                    a: !0
                },
                ka = {};
            try {
                ka.__proto__ = ja;
                ia = ka.a;
                break a
            } catch (a) {}
            ia = !1
        }
        ha = ia ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var la = ha,
        u = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: aa(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        ma = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    r("globalThis", function(a) {
        return a || q
    });
    r("Promise", function(a) {
        function b() {
            this.D = null
        }

        function c(f) {
            return f instanceof e ? f : new e(function(h) {
                h(f)
            })
        }
        if (a) return a;
        b.prototype.va = function(f) {
            if (this.D == null) {
                this.D = [];
                var h = this;
                this.wa(function() {
                    h.Qa()
                })
            }
            this.D.push(f)
        };
        var d = q.setTimeout;
        b.prototype.wa = function(f) {
            d(f, 0)
        };
        b.prototype.Qa = function() {
            for (; this.D && this.D.length;) {
                var f = this.D;
                this.D = [];
                for (var h = 0; h < f.length; ++h) {
                    var k = f[h];
                    f[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.La(l)
                    }
                }
            }
            this.D = null
        };
        b.prototype.La = function(f) {
            this.wa(function() {
                throw f;
            })
        };
        var e = function(f) {
            this.h = 0;
            this.H = void 0;
            this.T = [];
            this.za = !1;
            var h = this.la();
            try {
                f(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        };
        e.prototype.la = function() {
            function f(l) {
                return function(m) {
                    k || (k = !0, l.call(h, m))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: f(this.eb),
                reject: f(this.ra)
            }
        };
        e.prototype.eb = function(f) {
            if (f === this) this.ra(new TypeError("A Promise cannot resolve to itself"));
            else if (f instanceof e) this.gb(f);
            else {
                a: switch (typeof f) {
                    case "object":
                        var h = f != null;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.cb(f) : this.xa(f)
            }
        };
        e.prototype.cb = function(f) {
            var h = void 0;
            try {
                h = f.then
            } catch (k) {
                this.ra(k);
                return
            }
            typeof h == "function" ? this.hb(h, f) : this.xa(f)
        };
        e.prototype.ra = function(f) {
            this.Fa(2, f)
        };
        e.prototype.xa = function(f) {
            this.Fa(1, f)
        };
        e.prototype.Fa = function(f, h) {
            if (this.h != 0) throw Error("Cannot settle(" + f + ", " + h + "): Promise already settled in state" + this.h);
            this.h = f;
            this.H = h;
            this.h === 2 && this.fb();
            this.Sa()
        };
        e.prototype.fb = function() {
            var f = this;
            d(function() {
                if (f.Za()) {
                    var h = q.console;
                    typeof h !==
                        "undefined" && h.error(f.H)
                }
            }, 1)
        };
        e.prototype.Za = function() {
            if (this.za) return !1;
            var f = q.CustomEvent,
                h = q.Event,
                k = q.dispatchEvent;
            if (typeof k === "undefined") return !0;
            typeof f === "function" ? f = new f("unhandledrejection", {
                cancelable: !0
            }) : typeof h === "function" ? f = new h("unhandledrejection", {
                cancelable: !0
            }) : (f = q.document.createEvent("CustomEvent"), f.initCustomEvent("unhandledrejection", !1, !0, f));
            f.promise = this;
            f.reason = this.H;
            return k(f)
        };
        e.prototype.Sa = function() {
            if (this.T != null) {
                for (var f = 0; f < this.T.length; ++f) g.va(this.T[f]);
                this.T = null
            }
        };
        var g = new b;
        e.prototype.gb = function(f) {
            var h = this.la();
            f.Z(h.resolve, h.reject)
        };
        e.prototype.hb = function(f, h) {
            var k = this.la();
            try {
                f.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        e.prototype.then = function(f, h) {
            function k(t, v) {
                return typeof t == "function" ? function(x) {
                    try {
                        l(t(x))
                    } catch (K) {
                        m(K)
                    }
                } : v
            }
            var l, m, p = new e(function(t, v) {
                l = t;
                m = v
            });
            this.Z(k(f, l), k(h, m));
            return p
        };
        e.prototype.catch = function(f) {
            return this.then(void 0, f)
        };
        e.prototype.Z = function(f, h) {
            function k() {
                switch (l.h) {
                    case 1:
                        f(l.H);
                        break;
                    case 2:
                        h(l.H);
                        break;
                    default:
                        throw Error("Unexpected state: " + l.h);
                }
            }
            var l = this;
            this.T == null ? g.va(k) : this.T.push(k);
            this.za = !0
        };
        e.resolve = c;
        e.reject = function(f) {
            return new e(function(h, k) {
                k(f)
            })
        };
        e.race = function(f) {
            return new e(function(h, k) {
                for (var l = u(f), m = l.next(); !m.done; m = l.next()) c(m.value).Z(h, k)
            })
        };
        e.all = function(f) {
            var h = u(f),
                k = h.next();
            return k.done ? c([]) : new e(function(l, m) {
                function p(x) {
                    return function(K) {
                        t[x] = K;
                        v--;
                        v == 0 && l(t)
                    }
                }
                var t = [],
                    v = 0;
                do t.push(void 0), v++, c(k.value).Z(p(t.length -
                    1), m), k = h.next(); while (!k.done)
            })
        };
        return e
    });
    var w = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
    r("WeakMap", function(a) {
        function b() {}

        function c(k) {
            var l = typeof k;
            return l === "object" && k !== null || l === "function"
        }

        function d(k) {
            if (!w(k, g)) {
                var l = new b;
                ca(k, g, {
                    value: l
                })
            }
        }

        function e(k) {
            var l = Object[k];
            l && (Object[k] = function(m) {
                if (m instanceof b) return m;
                Object.isExtensible(m) && d(m);
                return l(m)
            })
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var k = Object.seal({}),
                        l = Object.seal({}),
                        m = new a([
                            [k, 2],
                            [l, 3]
                        ]);
                    if (m.get(k) != 2 || m.get(l) != 3) return !1;
                    m.delete(k);
                    m.set(l, 4);
                    return !m.has(k) && m.get(l) == 4
                } catch (p) {
                    return !1
                }
            }()) return a;
        var g = "$jscomp_hidden_" + Math.random();
        e("freeze");
        e("preventExtensions");
        e("seal");
        var f = 0,
            h = function(k) {
                this.W = (f += Math.random() + 1).toString();
                if (k) {
                    k = u(k);
                    for (var l; !(l = k.next()).done;) l = l.value, this.set(l[0], l[1])
                }
            };
        h.prototype.set = function(k, l) {
            if (!c(k)) throw Error("Invalid WeakMap key");
            d(k);
            if (!w(k, g)) throw Error("WeakMap key fail: " + k);
            k[g][this.W] = l;
            return this
        };
        h.prototype.get = function(k) {
            return c(k) && w(k, g) ? k[g][this.W] : void 0
        };
        h.prototype.has = function(k) {
            return c(k) && w(k, g) && w(k[g], this.W)
        };
        h.prototype.delete = function(k) {
            return c(k) && w(k, g) && w(k[g], this.W) ? delete k[g][this.W] : !1
        };
        return h
    });
    r("Map", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(u([
                            [h, "s"]
                        ]));
                    if (k.get(h) != "s" || k.size != 1 || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || k.size != 2) return !1;
                    var l = k.entries(),
                        m = l.next();
                    if (m.done || m.value[0] != h || m.value[1] != "s") return !1;
                    m = l.next();
                    return m.done || m.value[0].x != 4 || m.value[1] != "t" || !l.next().done ? !1 : !0
                } catch (p) {
                    return !1
                }
            }()) return a;
        var b = new WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] =
                    g();
                this.size = 0;
                if (h) {
                    h = u(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = h === 0 ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.i ? l.i.value = k : (l.i = {
                next: this[1],
                B: this[1].B,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.i), this[1].B.next = l.i, this[1].B = l.i, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.i && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.i.B.next = h.i.next, h.i.next.B = h.i.B, h.i.head =
                null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].B = g();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).i
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).i) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, k) {
            for (var l = this.entries(), m; !(m = l.next()).done;) m =
                m.value, h.call(k, m[1], m[0], this)
        };
        c.prototype[Symbol.iterator] = c.prototype.entries;
        var d = function(h, k) {
                var l = k && typeof k;
                l == "object" || l == "function" ? b.has(k) ? l = b.get(k) : (l = "" + ++f, b.set(k, l)) : l = "p_" + k;
                var m = h[0][l];
                if (m && w(h[0], l))
                    for (h = 0; h < m.length; h++) {
                        var p = m[h];
                        if (k !== k && p.key !== p.key || k === p.key) return {
                            id: l,
                            list: m,
                            index: h,
                            i: p
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    i: void 0
                }
            },
            e = function(h, k) {
                var l = h[1];
                return ea(function() {
                    if (l) {
                        for (; l.head != h[1];) l = l.B;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            g = function() {
                var h = {};
                return h.B = h.next = h.head = h
            },
            f = 0;
        return c
    });
    var na = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var g = c++;
                        return {
                            value: b(g, a[g]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    };
    r("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return na(this, function(b) {
                return b
            })
        }
    });
    r("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            if (this == null) throw new TypeError("The 'this' value for String.prototype.startsWith must not be null or undefined");
            if (b instanceof RegExp) throw new TypeError("First argument to String.prototype.startsWith must not be a regular expression");
            var d = this + "";
            b += "";
            var e = d.length,
                g = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var f = 0; f < g && c < e;)
                if (d[c++] != b[f++]) return !1;
            return f >= g
        }
    });
    r("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
        }
    });
    r("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) w(b, d) && c.push(b[d]);
            return c
        }
    });
    r("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(h) {
                return h
            };
            var e = [],
                g = typeof Symbol != "undefined" && Symbol.iterator && b[Symbol.iterator];
            if (typeof g == "function") {
                b = g.call(b);
                for (var f = 0; !(g = b.next()).done;) e.push(c.call(d, g.value, f++))
            } else
                for (g = b.length, f = 0; f < g; f++) e.push(c.call(d, b[f], f));
            return e
        }
    });
    r("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return Number.isFinite(b) ? b === Math.floor(b) : !1
        }
    });
    r("Array.prototype.values", function(a) {
        return a ? a : function() {
            return na(this, function(b, c) {
                return c
            })
        }
    });
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var y = this || self,
        z = function(a) {
            var b = typeof a;
            b = b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null";
            return b == "array" || b == "object" && typeof a.length == "number"
        },
        oa = function(a) {
            var b = typeof a;
            return b == "object" && a != null || b == "function"
        },
        pa = function(a, b, c) {
            return a.call.apply(a.bind, arguments)
        },
        qa = function(a, b, c) {
            if (!a) throw Error();
            if (arguments.length > 2) {
                var d = Array.prototype.slice.call(arguments, 2);
                return function() {
                    var e = Array.prototype.slice.call(arguments);
                    Array.prototype.unshift.apply(e, d);
                    return a.apply(b,
                        e)
                }
            }
            return function() {
                return a.apply(b, arguments)
            }
        },
        ra = function(a, b, c) {
            ra = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? pa : qa;
            return ra.apply(null, arguments)
        },
        sa = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.ea = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.lb = function(d, e, g) {
                for (var f = Array(arguments.length - 2), h = 2; h < arguments.length; h++) f[h - 2] = arguments[h];
                return b.prototype[e].apply(d, f)
            }
        };

    function A(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, A);
        else {
            var c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        b !== void 0 && (this.cause = b)
    }
    sa(A, Error);
    A.prototype.name = "CustomError";
    var ta = Array.prototype.indexOf ? function(a, b) {
            return Array.prototype.indexOf.call(a, b, void 0)
        } : function(a, b) {
            if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
            for (var c = 0; c < a.length; c++)
                if (c in a && a[c] === b) return c;
            return -1
        },
        ua = Array.prototype.forEach ? function(a, b) {
            Array.prototype.forEach.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
        };

    function va(a) {
        var b = wa(document.querySelectorAll(".GoogleActiveViewClass"));
        a: {
            for (var c = b.length, d = typeof b === "string" ? b.split("") : b, e = 0; e < c; e++)
                if (e in d && a.call(void 0, d[e], e, b)) {
                    a = e;
                    break a
                }
            a = -1
        }
        return a < 0 ? null : typeof b === "string" ? b.charAt(a) : b[a]
    }

    function xa(a, b) {
        b = ta(a, b);
        var c;
        (c = b >= 0) && Array.prototype.splice.call(a, b, 1);
        return c
    }

    function wa(a) {
        var b = a.length;
        if (b > 0) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };

    function ya(a, b) {
        for (var c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var za = globalThis.trustedTypes,
        Aa;

    function Ba() {
        var a = null;
        if (!za) return a;
        try {
            var b = function(c) {
                return c
            };
            a = za.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {}
        return a
    };
    var Ca = function(a) {
        this.Da = a
    };
    Ca.prototype.toString = function() {
        return this.Da + ""
    };

    function Da() {
        var a = "//ep2.adtrafficquality.google/sodar/Klz6NWr5.html";
        Aa === void 0 && (Aa = Ba());
        var b = Aa;
        return new Ca(b ? b.createScriptURL(a) : a)
    };
    var Ea = function() {
            return "opacity".replace(/\-([a-z])/g, function(a, b) {
                return b.toUpperCase()
            })
        },
        Fa = function(a) {
            return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
                return c + d.toUpperCase()
            })
        };
    var Ga, Ha;
    a: {
        for (var Ia = ["CLOSURE_FLAGS"], Ja = y, Ka = 0; Ka < Ia.length; Ka++)
            if (Ja = Ja[Ia[Ka]], Ja == null) {
                Ha = null;
                break a
            }
        Ha = Ja
    }
    var La = Ha && Ha[610401301];
    Ga = La != null ? La : !1;

    function Ma() {
        var a = y.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var B, Na = y.navigator;
    B = Na ? Na.userAgentData || null : null;

    function Oa(a) {
        if (!Ga || !B) return !1;
        for (var b = 0; b < B.brands.length; b++) {
            var c = B.brands[b].brand;
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function C(a) {
        return Ma().indexOf(a) != -1
    };

    function D() {
        return Ga ? !!B && B.brands.length > 0 : !1
    };
    var Pa = function(a) {
        Pa[" "](a);
        return a
    };
    Pa[" "] = function() {};
    var Qa = function(a, b) {
        try {
            return Pa(a[b]), !0
        } catch (c) {}
        return !1
    };
    var Ra = C("Gecko") && !(Ma().toLowerCase().indexOf("webkit") != -1 && !C("Edge")) && !(C("Trident") || C("MSIE")) && !C("Edge"),
        Sa = Ma().toLowerCase().indexOf("webkit") != -1 && !C("Edge");
    var Ta = function(a) {
            return a.nodeType == 9 ? a : a.ownerDocument || a.document
        },
        Ua = function(a) {
            try {
                var b;
                if (!(b = a.contentWindow)) {
                    if (a.contentDocument) {
                        var c = a.contentDocument;
                        var d = c ? c.defaultView : window
                    } else d = null;
                    b = d
                }
                return b
            } catch (e) {}
            return null
        };
    var Va = function(a) {
        return !C("Safari") || (D() ? Oa("Chromium") : (C("Chrome") || C("CriOS")) && (D() || !C("Edge")) || C("Silk")) || (D() ? 0 : C("Coast")) || (D() ? 0 : C("Opera")) || (D() ? 0 : C("Edge")) || (D() ? Oa("Microsoft Edge") : C("Edg/")) || (D() ? Oa("Opera") : C("OPR")) || C("Firefox") || C("FxiOS") || C("Silk") || C("Android") ? !0 : (a = (a = Ta(a)) && (a ? a.defaultView : window), !!(a && a.location && a.location.ancestorOrigins && a.location.ancestorOrigins.length > 0 && a.location.origin == a.location.ancestorOrigins[0]))
    };
    var Wa = function() {},
        Xa = function(a) {
            var b = !1,
                c;
            return function() {
                b || (c = a(), b = !0);
                return c
            }
        };
    var E = function() {};
    E.prototype.next = function() {
        return F
    };
    var F = {
        done: !0,
        value: void 0
    };
    E.prototype.ua = function() {
        return this
    };
    var Ya = function(a) {
            if (a instanceof E) return a;
            if (typeof a.ua == "function") return a.ua(!1);
            if (z(a)) {
                var b = 0,
                    c = new E;
                c.next = function() {
                    for (;;) {
                        if (b >= a.length) return F;
                        if (b in a) return {
                            value: a[b++],
                            done: !1
                        };
                        b++
                    }
                };
                return c
            }
            throw Error("Not implemented");
        },
        Za = function(a, b) {
            if (z(a)) ua(a, b);
            else
                for (a = Ya(a);;) {
                    var c = a.next();
                    if (c.done) break;
                    b.call(void 0, c.value, void 0, a)
                }
        },
        $a = function(a, b) {
            var c = 1;
            Za(a, function(d) {
                c = b.call(void 0, c, d)
            });
            return c
        },
        ab = function(a, b) {
            var c = Ya(a);
            a = new E;
            a.next = function() {
                var d =
                    c.next(),
                    e = d.value;
                return d.done ? F : b.call(void 0, e, void 0, c) ? {
                    value: e,
                    done: !1
                } : F
            };
            return a
        },
        db = function(a) {
            var b = Ya(a);
            a = new E;
            var c = 100;
            a.next = function() {
                return c-- > 0 ? b.next() : F
            };
            return a
        };
    var G = function(a, b) {
        this.Va = b;
        this.Ea = a == null;
        this.Ba = a
    };
    G.prototype = fa(E.prototype);
    G.prototype.constructor = G;
    if (la) la(G, E);
    else
        for (var H in E)
            if (H != "prototype")
                if (Object.defineProperties) {
                    var eb = Object.getOwnPropertyDescriptor(E, H);
                    eb && Object.defineProperty(G, H, eb)
                } else G[H] = E[H];
    G.ea = E.prototype;
    G.prototype.next = function() {
        if (this.Ea) return F;
        var a = this.Ba || null;
        this.Ea = a == null;
        var b;
        if (b = a) {
            b = this.Va;
            if (Qa(a, "parentElement") && a.parentElement != null && a != a.parentElement) var c = a.parentElement;
            else if (b) {
                var d = d === void 0 ? Va : d;
                if (d(a)) try {
                    var e = Ta(a),
                        g = e && (e ? e.defaultView : window),
                        f = g && g.frameElement;
                    c = f == null ? null : f
                } catch (h) {
                    c = null
                } else c = null
            } else c = null;
            b = c
        }
        this.Ba = b;
        return {
            value: a,
            done: !1
        }
    };
    var fb = {};
    var gb = function(a) {
        var b = 1;
        a = db(new G(a, !0));
        a = ab(a, function() {
            return b > 0
        });
        return $a(a, function(c, d) {
            var e = 1;
            if (Qa(d, "style") && d.style) {
                var g = parseFloat;
                a: {
                    var f = Ta(d);
                    if (f.defaultView && f.defaultView.getComputedStyle && (f = f.defaultView.getComputedStyle(d, null))) {
                        f = f.opacity || f.getPropertyValue("opacity") || "";
                        break a
                    }
                    f = ""
                }
                if (!f) {
                    f = d.style[Ea()];
                    if (typeof f !== "undefined") d = f;
                    else {
                        f = d.style;
                        var h = fb.opacity;
                        if (!h) {
                            var k = Ea();
                            h = k;
                            d.style[k] === void 0 && (k = (Sa ? "Webkit" : Ra ? "Moz" : null) + Fa(k), d.style[k] !==
                                void 0 && (h = k));
                            fb.opacity = h
                        }
                        d = f[h] || ""
                    }
                    f = d
                }
                g = g(f);
                typeof g !== "number" || isNaN(g) || (e = g)
            }
            return b = c * e
        })
    };

    function hb(a) {
        y.setTimeout(function() {
            throw a;
        }, 0)
    };
    var ib = document,
        jb = window;
    var kb = Xa(function() {
        var a = !1;
        try {
            var b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
            y.addEventListener("test", null, b)
        } catch (c) {}
        return a
    });

    function lb(a) {
        return a ? a.passive && kb() ? a : a.capture || !1 : !1
    }
    var mb = function(a, b, c, d) {
            a.addEventListener && a.addEventListener(b, c, lb(d))
        },
        nb = function(a, b, c, d) {
            a.removeEventListener && a.removeEventListener(b, c, lb(d))
        };
    var ob = function(a, b) {
        var c = c === void 0 ? {} : c;
        this.error = a;
        this.context = b.context;
        this.msg = b.message || "";
        this.id = b.id || "jserror";
        this.meta = c
    };

    function pb(a) {
        var b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        if (a.stack) a: {
            a = a.stack;
            var c = b;
            try {
                a.indexOf(c) == -1 && (a = c + "\n" + a);
                for (var d; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n");
                break a
            } catch (e) {
                b = c;
                break a
            }
            b = void 0
        }
        return b
    };
    var qb = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        rb = function(a, b) {
            if (a) {
                a = a.split("&");
                for (var c = 0; c < a.length; c++) {
                    var d = a[c].indexOf("="),
                        e = null;
                    if (d >= 0) {
                        var g = a[c].substring(0, d);
                        e = a[c].substring(d + 1)
                    } else g = a[c];
                    b(g, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "")
                }
            }
        };
    var sb = function(a, b) {
            if (a)
                for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
        },
        tb = function(a) {
            a = a === void 0 ? document : a;
            return a.createElement("img")
        };
    var J = function(a, b, c, d) {
        ub(a, b, c === void 0 ? null : c, d === void 0 ? !1 : d)
    };

    function ub(a, b, c, d) {
        var e = !1;
        e = e === void 0 ? !1 : e;
        a.google_image_requests || (a.google_image_requests = []);
        var g = tb(a.document);
        if (c || d) {
            var f = function(h) {
                c && c(h);
                d && xa(a.google_image_requests, g);
                nb(g, "load", f);
                nb(g, "error", f)
            };
            mb(g, "load", f);
            mb(g, "error", f)
        }
        e && (g.attributionSrc = "");
        g.src = b;
        a.google_image_requests.push(g)
    }

    function vb(a) {
        var b = b === void 0 ? !1 : b;
        var c;
        if (c = y.navigator) c = y.navigator.userAgent, c = /Chrome/.test(c) && !/Edge/.test(c) ? !0 : !1;
        c && y.navigator.sendBeacon ? y.navigator.sendBeacon(a) : J(y, a, void 0, b)
    };
    var wb = typeof AsyncContext !== "undefined" && typeof AsyncContext.Snapshot === "function" ? function(a) {
        return a && AsyncContext.Snapshot.wrap(a)
    } : function(a) {
        return a
    };
    var xb = function(a, b) {
        this.Wa = 100;
        this.Ma = a;
        this.bb = b;
        this.ca = 0;
        this.ba = null
    };
    xb.prototype.get = function() {
        if (this.ca > 0) {
            this.ca--;
            var a = this.ba;
            this.ba = a.next;
            a.next = null
        } else a = this.Ma();
        return a
    };
    xb.prototype.put = function(a) {
        this.bb(a);
        this.ca < this.Wa && (this.ca++, a.next = this.ba, this.ba = a)
    };
    var yb = function() {
        this.ia = this.V = null
    };
    yb.prototype.add = function(a, b) {
        var c = zb.get();
        c.set(a, b);
        this.ia ? this.ia.next = c : this.V = c;
        this.ia = c
    };
    yb.prototype.remove = function() {
        var a = null;
        this.V && (a = this.V, this.V = this.V.next, this.V || (this.ia = null), a.next = null);
        return a
    };
    var zb = new xb(function() {
            return new Ab
        }, function(a) {
            return a.reset()
        }),
        Ab = function() {
            this.next = this.scope = this.na = null
        };
    Ab.prototype.set = function(a, b) {
        this.na = a;
        this.scope = b;
        this.next = null
    };
    Ab.prototype.reset = function() {
        this.next = this.scope = this.na = null
    };
    var Bb, Cb = !1,
        Db = new yb,
        Fb = function(a, b) {
            Bb || Eb();
            Cb || (Bb(), Cb = !0);
            Db.add(a, b)
        },
        Eb = function() {
            var a = Promise.resolve(void 0);
            Bb = function() {
                a.then(Gb)
            }
        };

    function Gb() {
        for (var a; a = Db.remove();) {
            try {
                a.na.call(a.scope)
            } catch (b) {
                hb(b)
            }
            zb.put(a)
        }
        Cb = !1
    };
    var M = function(a) {
            this.h = 0;
            this.H = void 0;
            this.O = this.F = this.M = null;
            this.aa = this.ma = !1;
            if (a != Wa) try {
                var b = this;
                a.call(void 0, function(c) {
                    L(b, 2, c)
                }, function(c) {
                    L(b, 3, c)
                })
            } catch (c) {
                L(this, 3, c)
            }
        },
        Hb = function() {
            this.next = this.context = this.S = this.X = this.J = null;
            this.Y = !1
        };
    Hb.prototype.reset = function() {
        this.context = this.S = this.X = this.J = null;
        this.Y = !1
    };
    var Ib = new xb(function() {
            return new Hb
        }, function(a) {
            a.reset()
        }),
        Jb = function(a, b, c) {
            var d = Ib.get();
            d.X = a;
            d.S = b;
            d.context = c;
            return d
        };
    M.prototype.then = function(a, b, c) {
        return Kb(this, wb(typeof a === "function" ? a : null), wb(typeof b === "function" ? b : null), c)
    };
    M.prototype.$goog_Thenable = !0;
    var Mb = function(a, b, c, d) {
        Lb(a, Jb(b || Wa, c || null, d))
    };
    M.prototype.finally = function(a) {
        var b = this;
        a = wb(a);
        return new Promise(function(c, d) {
            Mb(b, function(e) {
                a();
                c(e)
            }, function(e) {
                a();
                d(e)
            })
        })
    };
    M.prototype.ib = function(a, b) {
        return Kb(this, null, wb(a), b)
    };
    M.prototype.catch = M.prototype.ib;
    M.prototype.cancel = function(a) {
        if (this.h == 0) {
            var b = new N(a);
            Fb(function() {
                Nb(this, b)
            }, this)
        }
    };
    var Nb = function(a, b) {
            if (a.h == 0)
                if (a.M) {
                    var c = a.M;
                    if (c.F) {
                        for (var d = 0, e = null, g = null, f = c.F; f && (f.Y || (d++, f.J == a && (e = f), !(e && d > 1))); f = f.next) e || (g = f);
                        e && (c.h == 0 && d == 1 ? Nb(c, b) : (g ? (d = g, d.next == c.O && (c.O = d), d.next = d.next.next) : Ob(c), Pb(c, e, 3, b)))
                    }
                    a.M = null
                } else L(a, 3, b)
        },
        Lb = function(a, b) {
            a.F || a.h != 2 && a.h != 3 || Qb(a);
            a.O ? a.O.next = b : a.F = b;
            a.O = b
        },
        Kb = function(a, b, c, d) {
            var e = Jb(null, null, null);
            e.J = new M(function(g, f) {
                e.X = b ? function(h) {
                    try {
                        var k = b.call(d, h);
                        g(k)
                    } catch (l) {
                        f(l)
                    }
                } : g;
                e.S = c ? function(h) {
                    try {
                        var k = c.call(d,
                            h);
                        k === void 0 && h instanceof N ? f(h) : g(k)
                    } catch (l) {
                        f(l)
                    }
                } : f
            });
            e.J.M = a;
            Lb(a, e);
            return e.J
        };
    M.prototype.jb = function(a) {
        this.h = 0;
        L(this, 2, a)
    };
    M.prototype.kb = function(a) {
        this.h = 0;
        L(this, 3, a)
    };
    var L = function(a, b, c) {
            if (a.h == 0) {
                a === c && (b = 3, c = new TypeError("Promise cannot resolve to itself"));
                a.h = 1;
                a: {
                    var d = c,
                        e = a.jb,
                        g = a.kb;
                    if (d instanceof M) {
                        Mb(d, e, g, a);
                        var f = !0
                    } else {
                        if (d) try {
                            var h = !!d.$goog_Thenable
                        } catch (l) {
                            h = !1
                        } else h = !1;
                        if (h) d.then(e, g, a), f = !0;
                        else {
                            if (oa(d)) try {
                                var k = d.then;
                                if (typeof k === "function") {
                                    Rb(d, k, e, g, a);
                                    f = !0;
                                    break a
                                }
                            } catch (l) {
                                g.call(a, l);
                                f = !0;
                                break a
                            }
                            f = !1
                        }
                    }
                }
                f || (a.H = c, a.h = b, a.M = null, Qb(a), b != 3 || c instanceof N || Sb(a, c))
            }
        },
        Rb = function(a, b, c, d, e) {
            var g = !1,
                f = function(k) {
                    g || (g = !0,
                        c.call(e, k))
                },
                h = function(k) {
                    g || (g = !0, d.call(e, k))
                };
            try {
                b.call(a, f, h)
            } catch (k) {
                h(k)
            }
        },
        Qb = function(a) {
            a.ma || (a.ma = !0, Fb(a.Ra, a))
        },
        Ob = function(a) {
            var b = null;
            a.F && (b = a.F, a.F = b.next, b.next = null);
            a.F || (a.O = null);
            return b
        };
    M.prototype.Ra = function() {
        for (var a; a = Ob(this);) Pb(this, a, this.h, this.H);
        this.ma = !1
    };
    var Pb = function(a, b, c, d) {
            if (c == 3 && b.S && !b.Y)
                for (; a && a.aa; a = a.M) a.aa = !1;
            if (b.J) b.J.M = null, Tb(b, c, d);
            else try {
                b.Y ? b.X.call(b.context) : Tb(b, c, d)
            } catch (e) {
                Ub.call(null, e)
            }
            Ib.put(b)
        },
        Tb = function(a, b, c) {
            b == 2 ? a.X.call(a.context, c) : a.S && a.S.call(a.context, c)
        },
        Sb = function(a, b) {
            a.aa = !0;
            Fb(function() {
                a.aa && Ub.call(null, b)
            })
        },
        Ub = hb,
        N = function(a) {
            A.call(this, a)
        };
    sa(N, A);
    N.prototype.name = "cancel";
    var Vb = function(a, b, c) {
        this.promise = a;
        this.resolve = b;
        this.reject = c
    };
    var Wb = function(a) {
            if (a.L && typeof a.L == "function") return a.L();
            if (typeof Map !== "undefined" && a instanceof Map || typeof Set !== "undefined" && a instanceof Set) return Array.from(a.values());
            if (typeof a === "string") return a.split("");
            if (z(a)) {
                for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
                return b
            }
            b = [];
            c = 0;
            for (d in a) b[c++] = a[d];
            return b
        },
        Xb = function(a) {
            if (a.oa && typeof a.oa == "function") return a.oa();
            if (!a.L || typeof a.L != "function") {
                if (typeof Map !== "undefined" && a instanceof Map) return Array.from(a.keys());
                if (!(typeof Set !== "undefined" && a instanceof Set)) {
                    if (z(a) || typeof a === "string") {
                        var b = [];
                        a = a.length;
                        for (var c = 0; c < a; c++) b.push(c);
                        return b
                    }
                    b = [];
                    c = 0;
                    for (var d in a) b[c++] = d;
                    return b
                }
            }
        },
        Yb = function(a, b, c) {
            if (a.forEach && typeof a.forEach == "function") a.forEach(b, c);
            else if (z(a) || typeof a === "string") Array.prototype.forEach.call(a, b, c);
            else
                for (var d = Xb(a), e = Wb(a), g = e.length, f = 0; f < g; f++) b.call(c, e[f], d && d[f], a)
        };
    var O = function(a) {
        this.u = this.N = this.I = "";
        this.U = null;
        this.K = this.o = "";
        this.m = this.Ua = !1;
        if (a instanceof O) {
            this.m = a.m;
            Zb(this, a.I);
            var b = a.N;
            P(this);
            this.N = b;
            b = a.u;
            P(this);
            this.u = b;
            $b(this, a.U);
            b = a.o;
            P(this);
            this.o = b;
            ac(this, a.s.clone());
            a = a.K;
            P(this);
            this.K = a
        } else a && (b = String(a).match(qb)) ? (this.m = !1, Zb(this, b[1] || "", !0), a = b[2] || "", P(this), this.N = Q(a), a = b[3] || "", P(this), this.u = Q(a, !0), $b(this, b[4]), a = b[5] || "", P(this), this.o = Q(a, !0), ac(this, b[6] || "", !0), a = b[7] || "", P(this), this.K = Q(a)) : (this.m = !1,
            this.s = new R(null, this.m))
    };
    O.prototype.toString = function() {
        var a = [],
            b = this.I;
        b && a.push(S(b, bc, !0), ":");
        var c = this.u;
        if (c || b == "file") a.push("//"), (b = this.N) && a.push(S(b, bc, !0), "@"), a.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.U, c != null && a.push(":", String(c));
        if (c = this.o) this.u && c.charAt(0) != "/" && a.push("/"), a.push(S(c, c.charAt(0) == "/" ? cc : dc, !0));
        (c = this.s.toString()) && a.push("?", c);
        (c = this.K) && a.push("#", S(c, ec));
        return a.join("")
    };
    O.prototype.resolve = function(a) {
        var b = this.clone(),
            c = !!a.I;
        c ? Zb(b, a.I) : c = !!a.N;
        if (c) {
            var d = a.N;
            P(b);
            b.N = d
        } else c = !!a.u;
        c ? (d = a.u, P(b), b.u = d) : c = a.U != null;
        d = a.o;
        if (c) $b(b, a.U);
        else if (c = !!a.o) {
            if (d.charAt(0) != "/")
                if (this.u && !this.o) d = "/" + d;
                else {
                    var e = b.o.lastIndexOf("/");
                    e != -1 && (d = b.o.slice(0, e + 1) + d)
                }
            e = d;
            if (e == ".." || e == ".") d = "";
            else if (e.indexOf("./") != -1 || e.indexOf("/.") != -1) {
                d = e.lastIndexOf("/", 0) == 0;
                e = e.split("/");
                for (var g = [], f = 0; f < e.length;) {
                    var h = e[f++];
                    h == "." ? d && f == e.length && g.push("") : h == ".." ?
                        ((g.length > 1 || g.length == 1 && g[0] != "") && g.pop(), d && f == e.length && g.push("")) : (g.push(h), d = !0)
                }
                d = g.join("/")
            } else d = e
        }
        c ? (P(b), b.o = d) : c = a.s.toString() !== "";
        c ? ac(b, a.s.clone()) : c = !!a.K;
        c && (a = a.K, P(b), b.K = a);
        return b
    };
    O.prototype.clone = function() {
        return new O(this)
    };
    var Zb = function(a, b, c) {
            P(a);
            a.I = c ? Q(b, !0) : b;
            a.I && (a.I = a.I.replace(/:$/, ""))
        },
        $b = function(a, b) {
            P(a);
            if (b) {
                b = Number(b);
                if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
                a.U = b
            } else a.U = null
        },
        ac = function(a, b, c) {
            P(a);
            b instanceof R ? (a.s = b, a.s.sa(a.m)) : (c || (b = S(b, fc)), a.s = new R(b, a.m))
        };
    O.prototype.getQuery = function() {
        return this.s.toString()
    };
    var T = function(a, b, c) {
        P(a);
        a.s.set(b, c);
        return a
    };
    O.prototype.removeParameter = function(a) {
        P(this);
        this.s.remove(a);
        return this
    };
    var P = function(a) {
        if (a.Ua) throw Error("Tried to modify a read-only Uri");
    };
    O.prototype.sa = function(a) {
        this.m = a;
        this.s && this.s.sa(a)
    };
    var Q = function(a, b) {
            return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : ""
        },
        S = function(a, b, c) {
            return typeof a === "string" ? (a = encodeURI(a).replace(b, gc), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null
        },
        gc = function(a) {
            a = a.charCodeAt(0);
            return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
        },
        bc = /[#\/\?@]/g,
        dc = /[#\?:]/g,
        cc = /[#\?]/g,
        fc = /[#\?@]/g,
        ec = /#/g,
        R = function(a, b) {
            this.j = this.g = null;
            this.l = a || null;
            this.m = !!b
        },
        U = function(a) {
            a.g || (a.g = new Map, a.j = 0, a.l && rb(a.l, function(b, c) {
                a.add(decodeURIComponent(b.replace(/\+/g,
                    " ")), c)
            }))
        };
    R.prototype.add = function(a, b) {
        U(this);
        this.l = null;
        a = V(this, a);
        var c = this.g.get(a);
        c || this.g.set(a, c = []);
        c.push(b);
        this.j += 1;
        return this
    };
    R.prototype.remove = function(a) {
        U(this);
        a = V(this, a);
        return this.g.has(a) ? (this.l = null, this.j -= this.g.get(a).length, this.g.delete(a)) : !1
    };
    R.prototype.clear = function() {
        this.g = this.l = null;
        this.j = 0
    };
    var lc = function(a, b) {
        U(a);
        b = V(a, b);
        return a.g.has(b)
    };
    n = R.prototype;
    n.forEach = function(a, b) {
        U(this);
        this.g.forEach(function(c, d) {
            c.forEach(function(e) {
                a.call(b, e, d, this)
            }, this)
        }, this)
    };
    n.oa = function() {
        U(this);
        for (var a = Array.from(this.g.values()), b = Array.from(this.g.keys()), c = [], d = 0; d < b.length; d++)
            for (var e = a[d], g = 0; g < e.length; g++) c.push(b[d]);
        return c
    };
    n.L = function(a) {
        U(this);
        var b = [];
        if (typeof a === "string") lc(this, a) && (b = b.concat(this.g.get(V(this, a))));
        else {
            a = Array.from(this.g.values());
            for (var c = 0; c < a.length; c++) b = b.concat(a[c])
        }
        return b
    };
    n.set = function(a, b) {
        U(this);
        this.l = null;
        a = V(this, a);
        lc(this, a) && (this.j -= this.g.get(a).length);
        this.g.set(a, [b]);
        this.j += 1;
        return this
    };
    n.get = function(a, b) {
        if (!a) return b;
        a = this.L(a);
        return a.length > 0 ? String(a[0]) : b
    };
    n.toString = function() {
        if (this.l) return this.l;
        if (!this.g) return "";
        for (var a = [], b = Array.from(this.g.keys()), c = 0; c < b.length; c++) {
            var d = b[c],
                e = encodeURIComponent(String(d));
            d = this.L(d);
            for (var g = 0; g < d.length; g++) {
                var f = e;
                d[g] !== "" && (f += "=" + encodeURIComponent(String(d[g])));
                a.push(f)
            }
        }
        return this.l = a.join("&")
    };
    n.clone = function() {
        var a = new R;
        a.l = this.l;
        this.g && (a.g = new Map(this.g), a.j = this.j);
        return a
    };
    var V = function(a, b) {
        b = String(b);
        a.m && (b = b.toLowerCase());
        return b
    };
    R.prototype.sa = function(a) {
        a && !this.m && (U(this), this.l = null, this.g.forEach(function(b, c) {
            var d = c.toLowerCase();
            c != d && (this.remove(c), this.remove(d), b.length > 0 && (this.l = null, this.g.set(V(this, d), wa(b)), this.j += b.length))
        }, this));
        this.m = a
    };
    R.prototype.extend = function(a) {
        for (var b = 0; b < arguments.length; b++) Yb(arguments[b], function(c, d) {
            this.add(d, c)
        }, this)
    };

    function oc(a) {
        return T(T(T(new O("//ep1.adtrafficquality.google/pagead/gen_204"), "id", "sodar"), "v", 46), "t", a)
    }

    function W(a, b, c, d, e) {
        var g = oc(1);
        T(g, "e", a);
        c && T(g, "li", c);
        d && T(g, "cv", d);
        e && T(g, "sq", e);
        b && T(g, "bgai", b);
        J(window, g.toString())
    }

    function pc(a, b, c, d, e, g) {
        c = c === void 0 ? null : c;
        d = d === void 0 ? null : d;
        e = e === void 0 ? null : e;
        g = g === void 0 ? null : g;
        Math.random() > "0.01" || (a = T(T(T(T(T(new O("//ep1.adtrafficquality.google/pagead/gen_204"), "id", "sodarir"), "v", 46), "d", a ? 1 : 0), "s", b ? 1 : 0), "f", "0.01"), d && T(a, "li", d), e && T(a, "cv", e), g && T(a, "sq", g), c && T(a, "bgai", c), J(window, a.toString()))
    }
    var sc = function(a) {
            qc === void 0 && (qc = rc(a === void 0 ? !1 : a))
        },
        qc, tc = function() {
            return qc || null
        },
        rc = function(a) {
            a = a === void 0 ? !1 : a;
            var b = window.GoogleTyFxhY;
            if (!b) return W(13), null;
            if (b.length == 0) return W(1), null;
            b = b.shift();
            return ((a === void 0 ? 0 : a) || b._isfl_ === "true" || b._scs_ || b._cv_ || b._sid_) && (b._upb_ || b._bgu_ && b._bgp_) ? b : (W(2), null)
        };

    function uc(a, b) {
        return function() {
            try {
                return a.apply(this, arguments)
            } catch (f) {
                if (!(vc.count >= 1)) {
                    var c = f,
                        d = oc(3),
                        e = tc(new sc)._scs_,
                        g = tc(new sc)._sid_;
                    e && T(d, "bgai", e);
                    g && T(d, "sq", g);
                    T(d, "c", b);
                    T(d, "ex", pb(c));
                    c = d.toString();
                    c.length > 6E4 ? W(11, e) : J(window, c);
                    vc.count += 1
                }
            }
        }
    }

    function wc(a, b) {
        var c = uc(a, b),
            d = c.apply,
            e = ma.apply(2, arguments);
        if (!(e instanceof Array)) {
            e = u(e);
            for (var g, f = []; !(g = e.next()).done;) f.push(g.value);
            e = f
        }
        d.call(c, null, e)
    }
    var vc = {
        count: 0
    };

    function xc(a, b, c, d) {
        c = uc(c, d);
        mb(a, b, c, {
            capture: void 0
        });
        return c
    }

    function yc(a, b) {
        var c = b;
        var d = xc(a, "load", function() {
            if (c) {
                var e = c;
                c = null;
                nb(a, "load", d, {
                    capture: void 0
                });
                return e.apply(this, arguments)
            }
        }, "i:lh")
    }

    function zc() {
        return va(function(a) {
            return a.tagName == "DIV" && a.id.lastIndexOf("DfaVisibilityIdentifier_", 0) == 0
        })
    }

    function Ac(a) {
        switch (a) {
            case void 0:
                return 0;
            case !0:
                return 1;
            case !1:
                return 2;
            default:
                return -1
        }
    };
    var Bc = function(a, b) {
        this.type = a;
        this.currentTarget = this.target = b;
        this.defaultPrevented = !1
    };
    Bc.prototype.stopPropagation = function() {};
    Bc.prototype.preventDefault = function() {
        this.defaultPrevented = !0
    };
    var Cc = function() {
        if (!y.addEventListener || !Object.defineProperty) return !1;
        var a = !1,
            b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
        try {
            var c = function() {};
            y.addEventListener("test", c, b);
            y.removeEventListener("test", c, b)
        } catch (d) {}
        return a
    }();
    var X = function(a, b) {
        Bc.call(this, a ? a.type : "");
        this.relatedTarget = this.currentTarget = this.target = null;
        this.button = this.screenY = this.screenX = this.clientY = this.clientX = this.offsetY = this.offsetX = 0;
        this.key = "";
        this.charCode = this.keyCode = 0;
        this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
        this.state = null;
        this.pointerId = 0;
        this.pointerType = "";
        this.timeStamp = 0;
        this.G = null;
        if (a) {
            var c = this.type = a.type,
                d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
            this.target = a.target || a.srcElement;
            this.currentTarget = b;
            b = a.relatedTarget;
            b || (c == "mouseover" ? b = a.fromElement : c == "mouseout" && (b = a.toElement));
            this.relatedTarget = b;
            d ? (this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX, this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY = d.screenY || 0) : (this.offsetX = Sa || a.offsetX !== void 0 ? a.offsetX : a.layerX, this.offsetY = Sa || a.offsetY !== void 0 ? a.offsetY : a.layerY, this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX, this.clientY = a.clientY !== void 0 ? a.clientY : a.pageY, this.screenX =
                a.screenX || 0, this.screenY = a.screenY || 0);
            this.button = a.button;
            this.keyCode = a.keyCode || 0;
            this.key = a.key || "";
            this.charCode = a.charCode || (c == "keypress" ? a.keyCode : 0);
            this.ctrlKey = a.ctrlKey;
            this.altKey = a.altKey;
            this.shiftKey = a.shiftKey;
            this.metaKey = a.metaKey;
            this.pointerId = a.pointerId || 0;
            this.pointerType = a.pointerType;
            this.state = a.state;
            this.timeStamp = a.timeStamp;
            this.G = a;
            a.defaultPrevented && X.ea.preventDefault.call(this)
        }
    };
    sa(X, Bc);
    X.prototype.stopPropagation = function() {
        X.ea.stopPropagation.call(this);
        this.G.stopPropagation ? this.G.stopPropagation() : this.G.cancelBubble = !0
    };
    X.prototype.preventDefault = function() {
        X.ea.preventDefault.call(this);
        var a = this.G;
        a.preventDefault ? a.preventDefault() : a.returnValue = !1
    };
    var Dc = "closure_listenable_" + (Math.random() * 1E6 | 0);
    var Ec = 0;
    var Fc = function(a, b, c, d, e) {
            this.listener = a;
            this.proxy = null;
            this.src = b;
            this.type = c;
            this.capture = !!d;
            this.pa = e;
            this.key = ++Ec;
            this.da = this.ka = !1
        },
        Gc = function(a) {
            a.da = !0;
            a.listener = null;
            a.proxy = null;
            a.src = null;
            a.pa = null
        };

    function Y(a) {
        this.src = a;
        this.v = {};
        this.ha = 0
    }
    Y.prototype.add = function(a, b, c, d, e) {
        var g = a.toString();
        a = this.v[g];
        a || (a = this.v[g] = [], this.ha++);
        var f = Hc(a, b, d, e);
        f > -1 ? (b = a[f], c || (b.ka = !1)) : (b = new Fc(b, this.src, g, !!d, e), b.ka = c, a.push(b));
        return b
    };
    Y.prototype.remove = function(a, b, c, d) {
        a = a.toString();
        if (!(a in this.v)) return !1;
        var e = this.v[a];
        b = Hc(e, b, c, d);
        return b > -1 ? (Gc(e[b]), Array.prototype.splice.call(e, b, 1), e.length == 0 && (delete this.v[a], this.ha--), !0) : !1
    };
    Y.prototype.hasListener = function(a, b) {
        var c = a !== void 0,
            d = c ? a.toString() : "",
            e = b !== void 0;
        return ya(this.v, function(g) {
            for (var f = 0; f < g.length; ++f)
                if (!(c && g[f].type != d || e && g[f].capture != b)) return !0;
            return !1
        })
    };
    var Hc = function(a, b, c, d) {
        for (var e = 0; e < a.length; ++e) {
            var g = a[e];
            if (!g.da && g.listener == b && g.capture == !!c && g.pa == d) return e
        }
        return -1
    };
    var Ic = "closure_lm_" + (Math.random() * 1E6 | 0),
        Jc = {},
        Kc = 0,
        Mc = function(a, b, c, d, e) {
            if (d && d.once) Lc(a, b, c, d, e);
            else if (Array.isArray(b))
                for (var g = 0; g < b.length; g++) Mc(a, b[g], c, d, e);
            else c = Nc(c), a && a[Dc] ? a.listen(b, c, oa(d) ? !!d.capture : !!d, e) : Oc(a, b, c, !1, d, e)
        },
        Oc = function(a, b, c, d, e, g) {
            if (!b) throw Error("Invalid event type");
            var f = oa(e) ? !!e.capture : !!e,
                h = Pc(a);
            h || (a[Ic] = h = new Y(a));
            c = h.add(b, c, d, f, g);
            if (!c.proxy) {
                d = Qc();
                c.proxy = d;
                d.src = a;
                d.listener = c;
                if (a.addEventListener) Cc || (e = f), e === void 0 && (e = !1), a.addEventListener(b.toString(),
                    d, e);
                else if (a.attachEvent) a.attachEvent(Rc(b.toString()), d);
                else if (a.addListener && a.removeListener) a.addListener(d);
                else throw Error("addEventListener and attachEvent are unavailable.");
                Kc++
            }
        },
        Qc = function() {
            var a = Sc,
                b = function(c) {
                    return a.call(b.src, b.listener, c)
                };
            return b
        },
        Lc = function(a, b, c, d, e) {
            if (Array.isArray(b))
                for (var g = 0; g < b.length; g++) Lc(a, b[g], c, d, e);
            else c = Nc(c), a && a[Dc] ? a.mb(b, c, oa(d) ? !!d.capture : !!d, e) : Oc(a, b, c, !0, d, e)
        },
        Rc = function(a) {
            return a in Jc ? Jc[a] : Jc[a] = "on" + a
        },
        Sc = function(a,
            b) {
            if (a.da) a = !0;
            else {
                b = new X(b, this);
                var c = a.listener,
                    d = a.pa || a.src;
                if (a.ka && typeof a !== "number" && a && !a.da) {
                    var e = a.src;
                    if (e && e[Dc]) e.nb(a);
                    else {
                        var g = a.type,
                            f = a.proxy;
                        e.removeEventListener ? e.removeEventListener(g, f, a.capture) : e.detachEvent ? e.detachEvent(Rc(g), f) : e.addListener && e.removeListener && e.removeListener(f);
                        Kc--;
                        (g = Pc(e)) ? (f = a.type, f in g.v && xa(g.v[f], a) && (Gc(a), g.v[f].length == 0 && (delete g.v[f], g.ha--)), g.ha == 0 && (g.src = null, e[Ic] = null)) : Gc(a)
                    }
                }
                a = c.call(d, b)
            }
            return a
        },
        Pc = function(a) {
            a = a[Ic];
            return a instanceof Y ? a : null
        },
        Tc = "__closure_events_fn_" + (Math.random() * 1E9 >>> 0),
        Nc = function(a) {
            if (typeof a === "function") return a;
            a[Tc] || (a[Tc] = function(b) {
                return a.handleEvent(b)
            });
            return a[Tc]
        };
    var Uc = function(a) {
        var b = a._scs_,
            c = a._li_,
            d = zc();
        if (d && d.getBoundingClientRect) {
            var e = 0;
            Mc(d, "mouseover", function() {
                ++e
            });
            Mc(d, "mousedown", function(g) {
                var f = d.getBoundingClientRect(),
                    h = 0;
                g.G.button == 0 ? h = 1 : g.G.button == 2 ? h = 4 : g.G.button == 1 && (h = 2);
                h && g.shiftKey && (h |= 8);
                h && g.altKey && (h |= 16);
                h && g.ctrlKey && (h |= 32);
                var k = Math.floor(100 * gb(d)),
                    l = Math.floor(g.clientX - f.left);
                f = Math.floor(g.clientY - f.top);
                var m = e;
                g = g.isTrusted;
                var p = document.defaultView && document.defaultView.mozPaintCount;
                p = p === void 0 ? -1 : typeof p ===
                    "number" && Number.isInteger(p) ? p < 0 ? -3 : p : -2;
                k = T(T(T(T(T(T(T(T(T(T(new O("//ep1.adtrafficquality.google/pagead/gen_204"), "id", "sodarde"), "v", 46), "nx", l), "ny", f), "bgai", b), "mb", h), "ox", k), "nm", m), "tr", Ac(g)), "mz", p);
                c && T(k, "li", c);
                J(window, k.toString())
            })
        }
    };
    var Vc = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)"),
        Wc = function(a, b) {
            this.ga = a;
            this.Ia = b
        },
        Xc = function(a, b) {
            this.url = a;
            this.ya = !!b;
            this.depth = null
        };
    var Yc = null;

    function Zc() {
        var a = a === void 0 ? y : a;
        return (a = a.performance) && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function $c() {
        var a = a === void 0 ? y : a;
        return (a = a.performance) && a.now ? a.now() : null
    };
    var ad = function(a, b) {
        var c = $c() || Zc();
        this.label = a;
        this.type = b;
        this.value = c;
        this.duration = 0;
        this.taskId = this.slotId = void 0;
        this.uniqueId = Math.random()
    };
    var Z = y.performance,
        bd = !!(Z && Z.mark && Z.measure && Z.clearMarks),
        cd = Xa(function() {
            var a;
            if (a = bd) {
                var b = b === void 0 ? window : b;
                if (Yc === null) {
                    Yc = "";
                    try {
                        a = "";
                        try {
                            a = b.top.location.hash
                        } catch (d) {
                            a = b.location.hash
                        }
                        if (a) {
                            var c = a.match(/\bdeid=([\d,]+)/);
                            Yc = c ? c[1] : ""
                        }
                    } catch (d) {}
                }
                b = Yc;
                a = !!b.indexOf && b.indexOf("1337") >= 0
            }
            return a
        }),
        dd = function() {
            var a = window;
            this.R = [];
            this.Ta = a || y;
            var b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.R = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.P = cd() || (b != null ? b : Math.random() < 1)
        };
    dd.prototype.disable = function() {
        this.P = !1;
        this.R !== this.Ta.google_js_reporting_queue && (cd() && ua(this.R, ed), this.R.length = 0)
    };
    var ed = function(a) {
        a && Z && cd() && (Z.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"), Z.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"))
    };
    dd.prototype.start = function(a, b) {
        if (!this.P) return null;
        a = new ad(a, b);
        b = "goog_" + a.label + "_" + a.uniqueId + "_start";
        Z && cd() && Z.mark(b);
        return a
    };
    dd.prototype.end = function(a) {
        if (this.P && typeof a.value === "number") {
            a.duration = ($c() || Zc()) - a.value;
            var b = "goog_" + a.label + "_" + a.uniqueId + "_end";
            Z && cd() && Z.mark(b);
            !this.P || this.R.length > 2048 || this.R.push(a)
        }
    };
    var fd = function() {
            this.Xa = 4E3;
            this.qa = "&";
            this.C = {};
            this.Ya = 0;
            this.A = []
        },
        gd = function(a, b) {
            var c = {};
            c[a] = b;
            return [c]
        },
        id = function(a, b, c, d, e) {
            var g = [];
            sb(a, function(f, h) {
                (f = hd(f, b, c, d, e)) && g.push(h + "=" + f)
            });
            return g.join(b)
        },
        hd = function(a, b, c, d, e) {
            if (a == null) return "";
            b = b || "&";
            c = c || ",$";
            typeof c === "string" && (c = c.split(""));
            if (a instanceof Array) {
                if (d || (d = 0), d < c.length) {
                    for (var g = [], f = 0; f < a.length; f++) g.push(hd(a[f], b, c, d + 1, e));
                    return g.join(c[d])
                }
            } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(id(a,
                b, c, d, e + 1)) : "...";
            return encodeURIComponent(String(a))
        },
        kd = function(a, b, c, d) {
            b = b + "//" + c + d;
            var e = jd(a) - d.length;
            if (e < 0) return "";
            a.A.sort(function(m, p) {
                return m - p
            });
            d = null;
            c = "";
            for (var g = 0; g < a.A.length; g++)
                for (var f = a.A[g], h = a.C[f], k = 0; k < h.length; k++) {
                    if (!e) {
                        d = d == null ? f : d;
                        break
                    }
                    var l = id(h[k], a.qa, ",$");
                    if (l) {
                        l = c + l;
                        if (e >= l.length) {
                            e -= l.length;
                            b += l;
                            c = a.qa;
                            break
                        }
                        d = d == null ? f : d
                    }
                }
            a = "";
            d != null && (a = "" + c + "trn=" + d);
            return b + a
        },
        jd = function(a) {
            var b = 1,
                c;
            for (c in a.C) c.length > b && (b = c.length);
            return a.Xa - 3 - b - a.qa.length -
                1
        };
    var nd = function() {
            var a = ld;
            this.Ca = md;
            this.Pa = "jserror";
            this.Ga = !0;
            this.fa = a === void 0 ? null : a;
            this.ja = null;
            this.ta = !1;
            this.Oa = this.Aa
        },
        pd = function(a) {
            var b = od;
            try {
                if (b.fa && b.fa.P) {
                    var c = b.fa.start((374).toString(), 3);
                    var d = a();
                    b.fa.end(c)
                } else d = a()
            } catch (f) {
                a = b.Ga;
                try {
                    ed(c), a = b.Oa(374, new ob(f, {
                        message: pb(f)
                    }), void 0, void 0)
                } catch (h) {
                    b.Aa(217, h)
                }
                if (a) {
                    var e, g;
                    (e = window.console) == null || (g = e.error) == null || g.call(e, f)
                } else throw f;
            }
            return d
        },
        qd = function(a) {
            return function() {
                var b = ma.apply(0, arguments);
                return pd(function() {
                    return a.apply(void 0, b)
                })
            }
        };
    nd.prototype.Aa = function(a, b, c, d, e) {
        e = e || this.Pa;
        var g = void 0;
        try {
            var f = new fd;
            f.A.push(1);
            f.C[1] = gd("context", a);
            b.error && b.meta && b.id || (b = new ob(b, {
                message: pb(b)
            }));
            if (b.msg) {
                var h = b.msg.substring(0, 512);
                f.A.push(2);
                f.C[2] = gd("msg", h)
            }
            var k = b.meta || {};
            if (this.ja) try {
                this.ja(k)
            } catch (ba) {}
            if (d) try {
                d(k)
            } catch (ba) {}
            d = [k];
            f.A.push(3);
            f.C[3] = d;
            h = y;
            d = [];
            k = null;
            do {
                var l = h;
                try {
                    var m = !!l && l.location.href != null && Qa(l, "foo")
                } catch (ba) {
                    m = !1
                }
                if (m) {
                    var p = l.location.href;
                    k = l.document && l.document.referrer || null
                } else p =
                    k, k = null;
                d.push(new Xc(p || ""));
                try {
                    h = l.parent
                } catch (ba) {
                    h = null
                }
            } while (h && l != h);
            p = 0;
            for (var t = d.length - 1; p <= t; ++p) d[p].depth = t - p;
            l = y;
            if (l.location && l.location.ancestorOrigins && l.location.ancestorOrigins.length == d.length - 1)
                for (t = 1; t < d.length; ++t) {
                    var v = d[t];
                    v.url || (v.url = l.location.ancestorOrigins[t - 1] || "", v.ya = !0)
                }
            var x = new Xc(y.location.href, !1);
            l = null;
            var K = d.length - 1;
            for (v = K; v >= 0; --v) {
                var I = d[v];
                !l && Vc.test(I.url) && (l = I);
                if (I.url && !I.ya) {
                    x = I;
                    break
                }
            }
            I = null;
            var ud = d.length && d[K].url;
            x.depth != 0 && ud &&
                (I = d[K]);
            g = new Wc(x, I);
            if (g.Ia) {
                var vd = g.Ia.url || "";
                f.A.push(4);
                f.C[4] = gd("top", vd)
            }
            var bb = {
                url: g.ga.url || ""
            };
            if (g.ga.url) {
                var cb = g.ga.url.match(qb),
                    hc = cb[1],
                    ic = cb[3],
                    jc = cb[4];
                x = "";
                hc && (x += hc + ":");
                ic && (x += "//", x += ic, jc && (x += ":" + jc));
                var kc = x
            } else kc = "";
            bb = [bb, {
                url: kc
            }];
            f.A.push(5);
            f.C[5] = bb;
            rd(this.Ca, e, f, this.ta, c)
        } catch (ba) {
            try {
                var mc, nc;
                rd(this.Ca, e, {
                    context: "ecmserr",
                    rctx: a,
                    msg: pb(ba),
                    url: (nc = (mc = g) == null ? void 0 : mc.ga.url) != null ? nc : ""
                }, this.ta, c)
            } catch (Bd) {}
        }
        return this.Ga
    };
    var sd = function() {
            this.u = "pagead2.googlesyndication.com";
            this.o = "/pagead/gen_204?id=";
            this.Na = .01;
            this.Ka = !1;
            this.ab = "https:";
            this.Ha = Math.random()
        },
        td = function() {
            var a = md,
                b = window.google_srt;
            b >= 0 && b <= 1 && (a.Ha = b)
        },
        rd = function(a, b, c, d, e) {
            if (((d === void 0 ? 0 : d) ? a.Ha : Math.random()) < (e || a.Na)) try {
                if (c instanceof fd) var g = c;
                else g = new fd, sb(c, function(h, k) {
                    var l = g,
                        m = l.Ya++;
                    h = gd(k, h);
                    l.A.push(m);
                    l.C[m] = h
                });
                var f = kd(g, a.ab, a.u, a.o + b + "&");
                f && (a.Ka ? vb(f) : J(y, f))
            } catch (h) {}
        };
    var md, od, ld = new dd;
    (function(a) {
        md = a != null ? a : new sd;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        td();
        od = new nd;
        od.ja = function() {};
        od.ta = !0;
        window.document.readyState === "complete" ? window.google_measure_js_timing || ld.disable() : ld.P && mb(window, "load", function() {
            window.google_measure_js_timing || ld.disable()
        })
    })();
    var wd = function() {
        var a, b, c = new M(function(d, e) {
            a = d;
            b = e
        });
        return new Vb(c, a, b)
    }();

    function xd(a) {
        wd.resolve([(a.src.indexOf("https:") == 0 ? "https" : "http") + "://" + "ep2.adtrafficquality.google".toString(), Ua(a)])
    }

    function yd(a) {
        var b = Da(),
            c = document.createElement("IFRAME".toString());
        yc(c, ra(xd, null, c));
        if (b instanceof Ca) b = b.Da;
        else throw Error("");
        c.src = b.toString();
        c.width = "0";
        c.height = "0";
        c.style.display = "none";
        a && xc(window, "message", function(d) {
            if (d.source === Ua(c)) {
                var e = d.data;
                if (d.data && e.startsWith("__FledgeSodar__")) {
                    d = e.replace("__FledgeSodar__", "");
                    var g;
                    e = y;
                    e = e === void 0 ? window : e;
                    e == null || (g = e.fence) == null || g.reportEvent({
                        eventType: "sodar",
                        eventData: d,
                        destination: ["buyer"]
                    })
                }
            }
        }, "i:fl");
        document.body.appendChild(c)
    }

    function zd() {
        wd.promise.then(function(a) {
            var b = u(a);
            a = b.next().value;
            b = b.next().value;
            var c = tc(new sc(!1));
            var d = c._scs_;
            var e = c._bgu_,
                g = c._bgp_,
                f = c._li_,
                h = c._cv_,
                k = c._sid_;
            c = c._isfl_;
            var l = document.location.origin,
                m = {};
            d = (m["0"] = "0", m["1"] = d || "", m["2"] = e.split("/").pop().replace(/\.js/g, ""), m["3"] = g, m["4"] = f || "", m["5"] = h || "", m["8"] = l && l != "null" ? l : "*", m["9"] = k || "", m["13"] = c || "", m);
            b ? b.postMessage(d, a) : W(3)
        })
    }
    var Ad = function() {
        wc(function() {
            var a = !!window.postMessage,
                b = !1,
                c = null,
                d = null,
                e = null,
                g = null,
                f = !1,
                h = tc(new sc(!1));
            h && (b = !0, c = h._scs_, d = h._li_, e = h._cv_, g = h._sid_, f = h._isfl_ == "true", a ? (yd(f), zd()) : W(8, c, d, e, g), setTimeout(qd(function() {
                return Uc(h)
            }), 0));
            pc(b, a, c, d, e, g)
        }, "i:i")
    };
    jb.GoogleTyFxhYEET || (jb.GoogleTyFxhYEET = {});
    jb.GoogleTyFxhYEET[(ib.currentScript || {}).src] = Ad;
    Ad();
}).call(this);
(function() {
    'use strict';
    var aa = Object.defineProperty,
        ba = globalThis;

    function ca(a, b) {
        if (b) a: {
            var c = ba;a = a.split(".");
            for (var d = 0; d < a.length - 1; d++) {
                var e = a[d];
                if (!(e in c)) break a;
                c = c[e]
            }
            a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && aa(c, a, {
                configurable: !0,
                writable: !0,
                value: b
            })
        }
    }
    ca("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    });
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var n = this || self;

    function da(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function t(a, b, c) {
        t = da;
        return t.apply(null, arguments)
    }

    function ea(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.N = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.O = function(d, e, k) {
            for (var f = Array(arguments.length - 2), g = 2; g < arguments.length; g++) f[g - 2] = arguments[g];
            return b.prototype[e].apply(d, f)
        }
    };

    function fa(a) {
        n.setTimeout(() => {
            throw a;
        }, 0)
    };
    var ha, u;
    a: {
        for (var ia = ["CLOSURE_FLAGS"], v = n, ja = 0; ja < ia.length; ja++)
            if (v = v[ia[ja]], v == null) {
                u = null;
                break a
            }
        u = v
    }
    var ka = u && u[748402147];
    ha = ka != null ? ka : !0;

    function x(a, b) {
        Array.prototype.forEach.call(a, b, void 0)
    };
    var la = void 0;

    function ma(a, b = !1) {
        return b && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol()
    }
    var na = ma(),
        y = ma("m_m", !0);
    var z = ma("jas", !0),
        oa, pa = [];
    pa[z] = 7;
    oa = Object.freeze(pa);
    var A = {};

    function C(a, b) {
        return b === void 0 ? a.h !== E && !!(2 & (a.g[z] | 0)) : !!(2 & b) && a.h !== E
    }
    var E = {},
        qa = Object.freeze({});

    function F(a) {
        a.P = !0;
        return a
    };
    var ra = F(a => typeof a === "number"),
        sa = F(a => typeof a === "string"),
        ta = F(a => typeof a === "function");
    var wa = F(a => a >= ua && a <= va),
        ua = BigInt(Number.MIN_SAFE_INTEGER),
        va = BigInt(Number.MAX_SAFE_INTEGER);
    var xa = Number.isFinite;

    function ya(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return xa(a) ? a | 0 : void 0
    }

    function Aa(a, b, c) {
        if (a != null && a[y] === A) return a;
        if (Array.isArray(a)) {
            var d = a[z] | 0;
            c = d | c & 32 | c & 2;
            c !== d && (a[z] = c);
            return new b(a)
        }
    };

    function Ba(a) {
        return a
    };

    function Ca(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        var k = [],
            f = a.length,
            g = 4294967295,
            h = !1,
            m = !!(b & 64),
            l = m ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1)) {
            var q = f && a[f - 1];
            q != null && typeof q === "object" && q.constructor === Object ? (f--, g = f) : q = void 0;
            !m || b & 128 || e || (h = !0, g = (Da ? ? Ba)(g - l, l, a, q, void 0) + l)
        }
        b = void 0;
        for (e = 0; e < f; e++) {
            let p = a[e];
            if (p != null && (p = c(p, d)) != null)
                if (m && e >= g) {
                    let r = e - l;
                    (b ? ? (b = {}))[r] = p
                } else k[e] = p
        }
        if (q)
            for (let p in q) {
                a = q[p];
                if (a == null || (a = c(a, d)) == null) continue;
                f = +p;
                let r;
                m && !Number.isNaN(f) && (r = f + l) < g ? k[r] = a : (b ? ?
                    (b = {}))[p] = a
            }
        b && (h ? k.push(b) : k[g] = b);
        return k
    }

    function Ea(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return wa(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    let b = a[z] | 0;
                    return a.length === 0 && b & 1 ? void 0 : Ca(a, b, Ea)
                }
                if (a != null && a[y] === A) return Fa(a);
                return
        }
        return a
    }
    var Da;

    function Fa(a) {
        a = a.g;
        return Ca(a, a[z] | 0, Ea)
    };

    function Ga(a, b, c, d = 0) {
        if (a == null) {
            var e = 32;
            c ? (a = [c], e |= 128) : a = [];
            b && (e = e & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[z] | 0;
            if (ha && 1 & e) throw Error("rfarr");
            2048 & e && !(2 & e) && Ha();
            if (e & 256) throw Error("farr");
            if (e & 64) return (e | d) !== e && (a[z] = e | d), a;
            if (c && (e |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;e |= 64;
                var k = c.length;
                if (k) {
                    var f = k - 1;
                    let h = c[f];
                    if (h != null && typeof h === "object" && h.constructor === Object) {
                        b = e & 128 ? 0 : -1;
                        f -= b;
                        if (f >= 1024) throw Error("pvtlmt");
                        for (var g in h)
                            if (k = +g,
                                k < f) c[k + b] = h[g], delete h[g];
                            else break;
                        e = e & -16760833 | (f & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    g = Math.max(b, k - (e & 128 ? 0 : -1));
                    if (g > 1024) throw Error("spvt");
                    e = e & -16760833 | (g & 1023) << 14
                }
            }
        }
        a[z] = e | 64 | d;
        return a
    }

    function Ha() {
        if (ha) throw Error("carr");
        if (na != null) {
            var a = la ? ? (la = {});
            var b = a[na] || 0;
            b >= 5 || (a[na] = b + 1, a = Error(), a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {}), a.__closure__error__context__984382.severity = "incident", fa(a))
        }
    };

    function Ia(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[z] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = G(a, c, !1, b && !(c & 16)) : (a[z] |= 34, c & 4 && Object.freeze(a)));
            return a
        }
        if (a != null && a[y] === A) return b = a.g, c = b[z] | 0, C(a, c) ? a : Ja(a, b, c) ? Ka(a, b) : G(b, c)
    }

    function Ka(a, b, c) {
        a = new a.constructor(b);
        c && (a.h = E);
        a.i = E;
        return a
    }

    function G(a, b, c, d) {
        d ? ? (d = !!(34 & b));
        a = Ca(a, b, Ia, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        a[z] = b;
        return a
    }

    function La(a) {
        var b = a.g,
            c = b[z] | 0;
        if (C(a, c)) {
            var d;
            Ja(a, b, c) ? d = Ka(a, b, !0) : d = new a.constructor(G(b, c, !1));
            a = d
        }
        return a
    }

    function Ma(a) {
        if (a.h !== E) return !1;
        var b = a.g;
        b = G(b, b[z] | 0);
        b[z] |= 2048;
        a.g = b;
        a.h = void 0;
        a.i = void 0;
        return !0
    }

    function Na(a, b) {
        b === void 0 && (b = a[z] | 0);
        b & 32 && !(b & 4096) && (a[z] = b | 4096)
    }

    function Ja(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (b[z] = c | 2, a.h = E, !0) : !1
    };

    function I(a, b) {
        a = Oa(a.g, b);
        if (a !== null) return a
    }

    function Oa(a, b, c, d) {
        if (b === -1) return null;
        var e = b + (c ? 0 : -1),
            k = a.length - 1;
        if (!(k < 1 + (c ? 0 : -1))) {
            if (e >= k) {
                var f = a[k];
                if (f != null && typeof f === "object" && f.constructor === Object) {
                    c = f[b];
                    var g = !0
                } else if (e === k) c = f;
                else return
            } else c = a[e];
            if (d && c != null) {
                d = d(c);
                if (d == null) return d;
                if (!Object.is(d, c)) return g ? f[b] = d : a[e] = d, d
            }
            return c
        }
    }

    function Pa(a, b, c) {
        var d = a.length - 1;
        if (d >= 0 && 0 >= d) {
            let e = a[d];
            if (e != null && typeof e === "object" && e.constructor === Object) return e[1] = c, b
        }
        if (0 <= d) return a[0] = c, b;
        c !== void 0 && (d = (b ? ? (b = a[z] | 0)) >> 14 & 1023 || 536870912, 1 >= d ? c != null && (a[d + -1] = {
            [1]: c
        }) : a[0] = c);
        return b
    }

    function Qa(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function Ra(a, b) {
        var c = Sa,
            d = !1,
            e = Oa(a, 1, void 0, k => {
                var f = Aa(k, c, b);
                d = f !== k && f != null;
                return f
            });
        if (e != null) return d && !C(e) && Na(a, b), e
    }

    function Ta(a) {
        var b = a.g,
            c = b[z] | 0,
            d = Ra(b, c);
        if (d == null) return d;
        c = b[z] | 0;
        if (!C(a, c)) {
            let e = La(d);
            e !== d && (Ma(a) && (b = a.g, c = b[z] | 0), d = e, c = Pa(b, c, d), Na(b, c))
        }
        return d
    }

    function Ua(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function J(a) {
        a = I(a, 1);
        return a == null || typeof a === "string" ? a : void 0
    }

    function K(a, b) {
        a = I(a, b);
        return (a == null || typeof a === "boolean" ? a : typeof a === "number" ? !!a : void 0) ? ? !1
    }

    function L(a, b) {
        return ya(I(a, b)) ? ? 0
    }

    function M(a, b) {
        a = I(a, b);
        return (a == null ? a : xa(a) ? a | 0 : void 0) ? ? 1
    };
    var N = class {
        constructor(a) {
            this.g = Ga(a, void 0, void 0, 2048)
        }
        toJSON() {
            return Fa(this)
        }
    };
    N.prototype[y] = A;
    N.prototype.toString = function() {
        return this.g.toString()
    };
    var Va = class extends N {};

    function Wa(a) {
        var b = a.g,
            c = b,
            d = b[z] | 0;
        b = void 0 === qa ? 2 : 4;
        var e = C(a, d),
            k = e ? 1 : b;
        b = k === 3;
        var f = !e;
        (k === 2 || f) && Ma(a) && (c = a.g, d = c[z] | 0);
        a = Oa(c, 1);
        e = Array.isArray(a) ? a : oa;
        var g = e === oa ? 7 : e[z] | 0;
        a = g;
        2 & d && (a |= 2);
        var h = a | 1;
        if (a = !(4 & h)) {
            var m = e,
                l = d;
            let q = !!(2 & h);
            q && (l |= 2);
            let p = !q,
                r = !0,
                D = 0,
                H = 0;
            for (; D < m.length; D++) {
                let B = Aa(m[D], Va, l);
                if (B instanceof Va) {
                    if (!q) {
                        let w = C(B);
                        p && (p = !w);
                        r && (r = w)
                    }
                    m[H++] = B
                }
            }
            H < D && (m.length = H);
            h |= 4;
            h = r ? h & -4097 : h | 4096;
            h = p ? h | 8 : h & -9
        }
        h !== g && (e[z] = h, 2 & h && Object.freeze(e));
        if (f && !(8 & h || !e.length &&
                (k === 1 || (k !== 4 ? 0 : 2 & h || !(16 & h) && 32 & d)))) {
            Qa(h) && (e = [...e], h = Ua(h, d), d = Pa(c, d, e));
            f = e;
            g = h;
            for (m = 0; m < f.length; m++) h = f[m], l = La(h), h !== l && (f[m] = l);
            g |= 8;
            h = g = f.length ? g | 4096 : g & -4097;
            e[z] = h
        }
        g = f = h;
        k === 1 || (k !== 4 ? 0 : 2 & f || !(16 & f) && 32 & d) ? Qa(f) || (f |= !e.length || a && !(4096 & f) || 32 & d && !(4096 & f || 16 & f) ? 2 : 256, f !== g && (e[z] = f), Object.freeze(e)) : (k === 2 && Qa(f) && (e = [...e], g = 0, f = Ua(f, d), d = Pa(c, d, e)), Qa(f) || (b || (f |= 16), f !== g && (e[z] = f)));
        2 & f || !(4096 & f || 16 & f) || Na(c, d);
        return e
    }
    var Sa = class extends N {};
    var Xa = class extends N {};

    function Ya(a, b) {
        if (a)
            for (let c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function Za() {}

    function $a(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    var ab = class {
            constructor(a) {
                this.g = a
            }
            toString() {
                return this.g
            }
        },
        bb = new ab("about:invalid#zClosurez");
    class cb {
        constructor(a) {
            this.M = a
        }
    }

    function O(a) {
        return new cb(b => b.substr(0, a.length + 1).toLowerCase() === a + ":")
    }
    var db = new cb(a => /^[^:]*([/?#]|$)/.test(a)),
        eb = O("http"),
        fb = O("https"),
        gb = O("ftp"),
        hb = O("mailto"),
        ib = [O("data"), eb, fb, hb, gb, db];

    function jb(a = ib) {
        for (let b = 0; b < a.length; ++b) {
            let c = a[b];
            if (c instanceof cb && c.M("#")) return new ab("#")
        }
    }

    function kb(a = ib) {
        return jb(a) || bb
    }
    var lb = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function mb(a = document) {
        return a.createElement("img")
    };
    var nb = [];

    function ob() {
        var a = nb;
        nb = [];
        for (let b of a) try {
            b()
        } catch {}
    };
    var pb = {
            capture: !0
        },
        qb = {
            passive: !0
        },
        rb = $a(() => {
            var a = !1;
            try {
                let b = Object.defineProperty({}, "passive", {
                    get() {
                        a = !0
                    }
                });
                n.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function sb(a) {
        return a ? a.passive && rb() ? a : a.capture || !1 : !1
    }

    function P(a, b, c, d) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, sb(d))
    }

    function tb(a) {
        var b = R;
        b.readyState === "complete" || b.readyState === "interactive" ? (nb.push(a), nb.length === 1 && (window.Promise ? Promise.resolve().then(ob) : (a = window.setImmediate, ta(a) ? a(ob) : setTimeout(ob, 0)))) : b.addEventListener("DOMContentLoaded", a)
    };

    function ub(a, b, c = null, d = !1) {
        vb(a, b, c, d)
    }

    function vb(a, b, c, d) {
        a.google_image_requests || (a.google_image_requests = []);
        var e = mb(a.document);
        if (c || d) {
            let k = f => {
                c && c(f);
                if (d) {
                    f = a.google_image_requests;
                    var g = Array.prototype.indexOf.call(f, e, void 0);
                    g >= 0 && Array.prototype.splice.call(f, g, 1)
                }
                typeof e.removeEventListener === "function" && e.removeEventListener("load", k, sb());
                typeof e.removeEventListener === "function" && e.removeEventListener("error", k, sb())
            };
            P(e, "load", k);
            P(e, "error", k)
        }
        e.src = b;
        a.google_image_requests.push(e)
    };

    function wb(a = null) {
        return a && a.getAttribute("data-jc") === "23" ? a : document.querySelector('[data-jc="23"]')
    }

    function xb() {
        if (!(Math.random() > .01)) {
            var a = wb(document.currentScript);
            a = a && a.getAttribute("data-jc-rcd") === "true" ? "pagead2.googlesyndication-cn.com" : "pagead2.googlesyndication.com";
            var b = (b = wb(document.currentScript)) && b.getAttribute("data-jc-version") || "unknown";
            a = `https://${a}/pagead/gen_204?id=jca&jc=23&version=${b}&sample=0.01`;
            b = window;
            var c;
            if (c = b.navigator) c = b.navigator.userAgent, c = /Chrome/.test(c) && !/Edge/.test(c) ? !0 : !1;
            c && typeof b.navigator.sendBeacon === "function" ? b.navigator.sendBeacon(a) :
                ub(b, a, void 0, !1)
        }
    };
    var R = document,
        S = window;
    var yb = (a = []) => {
        n.google_logging_queue || (n.google_logging_queue = []);
        n.google_logging_queue.push([12, a])
    };
    var zb = null;

    function Ab() {
        var a = n.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function Bb() {
        var a = n.performance;
        return a && a.now ? a.now() : null
    };
    var Cb = class {
        constructor(a, b) {
            var c = Bb() || Ab();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    var T = n.performance,
        Db = !!(T && T.mark && T.measure && T.clearMarks),
        U = $a(() => {
            var a;
            if (a = Db) {
                var b;
                a = window;
                if (zb === null) {
                    zb = "";
                    try {
                        let c = "";
                        try {
                            c = a.top.location.hash
                        } catch (d) {
                            c = a.location.hash
                        }
                        c && (zb = (b = c.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (c) {}
                }
                b = zb;
                a = !!b.indexOf && b.indexOf("1337") >= 0
            }
            return a
        });

    function Eb(a) {
        a && T && U() && (T.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), T.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    };

    function Fb(a, b, c, d, e) {
        var k = [];
        Ya(a, (f, g) => {
            (f = Gb(f, b, c, d, e)) && k.push(`${g}=${f}`)
        });
        return k.join(b)
    }

    function Gb(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        sa(c) && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                let k = [];
                for (let f = 0; f < a.length; f++) k.push(Gb(a[f], b, c, d + 1, e));
                return k.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(Fb(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function Hb(a) {
        var b = 1;
        for (let c in a.h) c.length > b && (b = c.length);
        return 3997 - b - a.i.length - 1
    }

    function Ib(a, b, c) {
        b = "https://" + b + c;
        var d = Hb(a) - c.length;
        if (d < 0) return "";
        a.g.sort((k, f) => k - f);
        c = null;
        var e = "";
        for (let k = 0; k < a.g.length; k++) {
            let f = a.g[k],
                g = a.h[f];
            for (let h = 0; h < g.length; h++) {
                if (!d) {
                    c = c == null ? f : c;
                    break
                }
                let m = Fb(g[h], a.i, ",$");
                if (m) {
                    m = e + m;
                    if (d >= m.length) {
                        d -= m.length;
                        b += m;
                        e = a.i;
                        break
                    }
                    c = c == null ? f : c
                }
            }
        }
        a = "";
        c != null && (a = `${e}trn=${c}`);
        return b + a
    }
    var Jb = class {
        constructor() {
            this.i = "&";
            this.h = {};
            this.l = 0;
            this.g = []
        }
    };

    function Kb(a, b, c) {
        if (Array.isArray(b))
            for (let d = 0; d < b.length; d++) Kb(a, String(b[d]), c);
        else b != null && c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))))
    };
    class Lb {};

    function Mb() {
        var a = Nb,
            b = window.google_srt;
        b >= 0 && b <= 1 && (a.g = b)
    }

    function Ob(a) {
        var b = Nb;
        if (b.g < 1) try {
            let c;
            a instanceof Jb ? c = a : (c = new Jb, Ya(a, (e, k) => {
                var f = c,
                    g = f.l++,
                    h = {};
                h[k] = e;
                e = [h];
                f.g.push(g);
                f.h[g] = e
            }));
            let d = Ib(c, b.domain, b.path + "fccs&");
            d && ub(n, d)
        } catch (c) {}
    }
    var Pb = class {
        constructor() {
            this.domain = "pagead2.googlesyndication.com";
            this.path = "/pagead/gen_204?id=";
            this.g = Math.random()
        }
    };
    var Qb = [eb, fb, hb, gb, db, O("market"), O("itms"), O("intent"), O("itms-appss")];

    function Rb() {
        return a => {
            a = {
                id: "unsafeurl",
                ctx: 625,
                url: a
            };
            var b = [];
            for (c in a) Kb(c, a[c], b);
            var c = b.join("&");
            if (c) {
                a = -1;
                a < 0 && (a = 52);
                b = -1;
                let d;
                b < 0 || b > a ? (b = a, d = "") : d = "https://pagead2.googlesyndication.com/pagead/gen_204".substring(b + 1, a);
                a = ["https://pagead2.googlesyndication.com/pagead/gen_204".slice(0, b), d, "https://pagead2.googlesyndication.com/pagead/gen_204".slice(a)];
                b = a[1];
                a[1] = c ? b ? b + "&" + c : c : b;
                c = a[0] + (a[1] ? "?" + a[1] : "") + a[2]
            } else c = "https://pagead2.googlesyndication.com/pagead/gen_204";
            navigator.sendBeacon &&
                navigator.sendBeacon(c, "")
        }
    };
    var Nb, V = new class {
        constructor(a, b) {
            this.g = [];
            this.i = b || n;
            var c = null;
            b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.g = b.google_js_reporting_queue, c = b.google_measure_js_timing);
            this.h = U() || (c != null ? c : Math.random() < a)
        }
        start(a, b) {
            if (!this.h) return null;
            a = new Cb(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            T && U() && T.mark(b);
            return a
        }
        end(a) {
            if (this.h && ra(a.value)) {
                a.duration = (Bb() || Ab()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                T && U() && T.mark(b);
                !this.h || this.g.length > 2048 ||
                    this.g.push(a)
            }
        }
    }(1, window);

    function Sb() {
        window.google_measure_js_timing || (V.h = !1, V.g !== V.i.google_js_reporting_queue && (U() && x(V.g, Eb), V.g.length = 0))
    }(function(a) {
        Nb = a ? ? new Pb;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        Mb();
        window.document.readyState === "complete" ? Sb() : V.h && P(window, "load", () => {
            Sb()
        })
    })();
    var Tb = () => {
            var a = R;
            try {
                return a.querySelectorAll("*[data-ifc]")
            } catch (b) {
                return []
            }
        },
        Ub = (a, b) => {
            a && Ya(b, (c, d) => {
                a.style[d] = c
            })
        },
        Vb = a => {
            var b = R.body,
                c = document.createDocumentFragment(),
                d = a.length;
            for (let e = 0; e < d; ++e) c.appendChild(a[e]);
            b.appendChild(c)
        };

    function Wb(a) {
        P(S, "message", b => {
            try {
                var c = JSON.parse(b.data)
            } catch (d) {
                return
            }!c || c.googMsgType !== "ig" || a(c, b)
        })
    };

    function W() {
        this.h = this.h;
        this.i = this.i
    }
    W.prototype.h = !1;
    W.prototype.dispose = function() {
        this.h || (this.h = !0, this.l())
    };
    W.prototype[Symbol.dispose] = function() {
        this.dispose()
    };
    W.prototype.l = function() {
        if (this.i)
            for (; this.i.length;) this.i.shift()()
    };

    function X(a, b, c) {
        W.call(this);
        this.m = a;
        this.C = b || 0;
        this.o = c;
        this.u = t(this.v, this)
    }
    ea(X, W);
    X.prototype.g = 0;
    X.prototype.l = function() {
        X.N.l.call(this);
        this.isActive() && n.clearTimeout(this.g);
        this.g = 0;
        delete this.m;
        delete this.o
    };
    X.prototype.start = function(a) {
        this.isActive() && n.clearTimeout(this.g);
        this.g = 0;
        var b = this.u;
        a = a !== void 0 ? a : this.C;
        if (typeof b !== "function")
            if (b && typeof b.handleEvent == "function") b = t(b.handleEvent, b);
            else throw Error("Invalid listener argument");
        this.g = Number(a) > 2147483647 ? -1 : n.setTimeout(b, a || 0)
    };
    X.prototype.isActive = function() {
        return this.g != 0
    };
    X.prototype.v = function() {
        this.g = 0;
        this.m && this.m.call(this.o)
    };
    var Xb = {
            display: "inline-block",
            position: "absolute"
        },
        Yb = {
            display: "none",
            width: "100%",
            height: "100%",
            top: "0",
            left: "0"
        };

    function Y(a, b) {
        a && (a.style.display = b ? "inline-block" : "none")
    }

    function Zb(a, b) {
        if (a) return S.getComputedStyle(a).getPropertyValue(b)
    }

    function $b({
        width: a,
        height: b
    }, {
        x: c,
        y: d,
        width: e,
        height: k
    }, {
        top: f,
        right: g,
        bottom: h,
        left: m
    }) {
        return {
            top: Math.max(0, f - d),
            right: Math.max(0, c + e - (a - g)),
            bottom: Math.max(0, d + k - (b - h)),
            left: Math.max(0, m - c)
        }
    }

    function ac(a = "") {
        var b = {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        };
        a && (a = a.split(","), a.length === 4 && a.reduce((c, d) => c && !isNaN(+d), !0) && ([b.top, b.right, b.bottom, b.left] = a.map(c => +c)));
        return b
    }

    function bc(a, b, c = 2147483647) {
        var d = R.createElement("div");
        Ub(d, { ...Xb,
            "z-index": String(c),
            ...b
        });
        K(a.data, 10) && P(d, "click", Za);
        if (K(a.data, 11)) {
            a = R.createElement("a");
            b = Rb();
            c = kb(Qb);
            c === bb && b("#");
            if (c instanceof ab)
                if (c instanceof ab) b = c.g;
                else throw Error("");
            else b = lb.test(c) ? c : void 0;
            b !== void 0 && (a.href = b);
            a.appendChild(d);
            return a
        }
        return d
    }

    function cc(a, b) {
        switch (M(b.j, 5)) {
            case 2:
                S.AFMA_Communicator ? .addEventListener ? .("onshow", () => {
                    Z(a, b)
                });
                break;
            case 10:
                P(S, "i-creative-view", () => {
                    Z(a, b)
                });
                break;
            case 4:
                P(R, "DOMContentLoaded", () => {
                    Z(a, b)
                });
                break;
            case 8:
                Wb(c => {
                    c.rr && Z(a, b)
                });
                break;
            case 9:
                if ("IntersectionObserver" in S) {
                    let c = new IntersectionObserver(d => {
                        for (let e of d)
                            if (e.intersectionRatio > 0) {
                                Z(a, b);
                                break
                            }
                    });
                    c.observe(R.body);
                    a.L.push(c)
                }
                break;
            case 11:
                S.AFMA_Communicator ? .addEventListener ? .("onAdVisibilityChanged", () => {
                    Z(a, b)
                })
        }
    }

    function dc(a, b) {
        b = ac(b);
        var c = L(a.data, 9);
        a.m = [{
            width: "100%",
            height: b.top + c + "px",
            top: -c + "px",
            left: "0"
        }, {
            width: b.right + c + "px",
            height: "100%",
            top: "0",
            right: -c + "px"
        }, {
            width: "100%",
            height: b.bottom + c + "px",
            bottom: -c + "px",
            left: "0"
        }, {
            width: b.left + c + "px",
            height: "100%",
            top: "0",
            left: -c + "px"
        }].map(d => bc(a, d, 9019))
    }

    function ec(a) {
        var b = n.oneAfmaInstance;
        b && b.getNativeClickMeta().then(c => {
            if (c) {
                var d = c.adViewRectangle;
                c = c.mediaViewRectangle;
                if (d && c && (d = JSON.parse(d), c = JSON.parse(c), d && c)) {
                    c = $b(d, c, ac(J(a.j) ? ? ""));
                    d = a.j;
                    c = `${c.top},${c.right},${c.bottom},${c.left}`;
                    if (c != null && typeof c !== "string") throw Error();
                    if (!Ma(d) && C(d, d.g[z] | 0)) throw Error();
                    d = d.g;
                    Pa(d, d[z] | 0, c)
                }
            }
        })
    }

    function fc(a) {
        var b = 0;
        for (let d of a.G) {
            let e = d.j,
                k = a.v[M(e, 5)];
            d.A || k === void 0 || (b = Math.max(b, k + L(e, 2)))
        }
        a.o && a.o.dispose();
        b -= Date.now();
        var c = a.h;
        b > 0 ? (Y(c, !0), a.o = new X(() => {
            Y(c, !1)
        }, b), a.o.start()) : Y(c, !1)
    }

    function Z(a, b) {
        if (!b.A) {
            var c = M(b.j, 5);
            a.v[c] = Date.now();
            K(b.j, 9) && (a.G.push(b), fc(a))
        }
    }

    function hc(a, b, c, d, e) {
        var [k, f] = [a / d - c.left, b / d - c.top];
        if (isNaN(k) || isNaN(f) || k < 0 || f < 0) return !1;
        a = c.width;
        c = c.height;
        return !(k >= e.left && a - k > e.right && f >= e.top && c - f > e.bottom)
    }

    function ic(a, b, c) {
        if (!a.g || !a.i || b.timeStamp - a.g.timeStamp >= 300) return !1;
        var d = new Map;
        x(a.i.changedTouches, e => {
            d.set(e.identifier, {
                x: e.clientX,
                y: e.clientY
            })
        });
        b = L(c.j, 11) || 10;
        for (let e of a.g.changedTouches)
            if (a = d.get(e.identifier), !a || Math.abs(a.x - e.clientX) > b || Math.abs(a.y - e.clientY) > b) return !0;
        return !1
    }
    var kc = class {
        constructor() {
            var a = jc;
            this.m = [];
            this.o = this.h = null;
            this.G = [];
            this.data = null;
            this.C = [];
            this.l = [];
            this.u = [];
            this.v = {};
            this.L = [];
            this.i = this.g = null;
            this.I = "";
            this.H = !1;
            this.J = a["send-fccs"] === "true";
            this.I = a.qid || "";
            this.H = a["is-fsn"] === "true"
        }
        init(a) {
            yb([a]);
            this.data = new Xa(a);
            a = Ta(this.data);
            x(Wa(a), g => {
                this.u.push({
                    D: 0,
                    A: !1,
                    F: 0,
                    j: g,
                    B: -1
                })
            });
            this.l = Tb();
            var b = !1;
            a = this.l.length;
            for (let g = 0; g < a; ++g) {
                var c = new Sa(JSON.parse(this.l[g].getAttribute("data-ifc") || "[]"));
                x(Wa(c), h => {
                    this.u.push({
                        D: 0,
                        A: !1,
                        F: 0,
                        j: h,
                        B: g
                    });
                    M(h, 4) === 1 && (b = !0)
                })
            }
            var d = c = a = !1,
                e = K(this.data, 12),
                k = !1;
            for (var f of this.u) {
                let g = f.j;
                L(g, 2) > 0 && M(g, 5) > 0 ? (!this.h && K(g, 9) && (this.h = bc(this, Yb)), cc(this, f)) : (J(g) ? ? "") && K(g, 9) && dc(this, J(g) ? ? "");
                (J(g) ? ? "") && (a = !0, this.H && K(g, 13) && ec(f));
                L(g, 11) > 0 && (c = !0);
                K(g, 12) && (e = !0);
                K(g, 14) && (k = !0);
                M(g, 4) === 3 && (d = !0)
            }
            f = [];
            this.h && f.push(this.h);
            !b && f.push(...this.m);
            R.body && Vb(f);
            K(this.data, 13) && tb(() => {
                var g = R.body.querySelectorAll(".amp-fcp, .amp-bcp");
                for (let h = 0; h < g.length; ++h) Zb(g[h],
                    "position") === "absolute" && Y(g[h], !1)
            });
            P(R, "click", g => {
                if (this.J) {
                    var h = {
                        cx: g.clientX,
                        cy: g.clientY,
                        et: Date.now(),
                        qid: this.I
                    };
                    var m = Lb;
                    var l = "K";
                    m.K && m.hasOwnProperty(l) || (l = new m, m.K = l);
                    m = [];
                    !h.eid && m.length && (h.eid = m.toString());
                    Ob(h);
                    this.J = !1
                }
                h = L(this.data, 15);
                if (h > 0 && (g.isTrusted === !1 && h & 1 || navigator.userActivation.hasBeenActive === !1 && h & 2 || navigator.userActivation.isActive === !1 && h & 4)) g.preventDefault ? g.preventDefault() : g.returnValue = !1, g.stopImmediatePropagation(), xb();
                else {
                    h = -1;
                    m = [];
                    for (var q of this.u) {
                        l =
                            q.B;
                        var p = l !== -1;
                        if (L(q.j, 3) <= h || q.A || p && m[l] === !1) continue;
                        var r = !p || m[l] || this.l[l].contains(g.target);
                        p && r && (m[l] = !0);
                        if (l = r)
                            if (l = g, p = q.j, L(p, 2) > 0 && M(p, 5) > 0) l = this.v[M(p, 5)], l = l !== void 0 && Date.now() < l + L(p, 2);
                            else if (J(p) ? ? "") {
                            {
                                r = (q.B >= 0 ? this.l[q.B] : R.body).getBoundingClientRect();
                                let Q = Number(Zb(R.body, "zoom") || "1");
                                p = r.height;
                                if (r.width > 0 && p > 0) {
                                    var D = ac(J(q.j) ? ? "");
                                    p = hc(l.clientX, l.clientY, r, Q, D);
                                    var H = K(q.j, 12);
                                    if (this.g && (K(this.data, 12) || H) && l.timeStamp - this.g.timeStamp < 300) {
                                        var B = this.g.changedTouches[0];
                                        B = hc(B.clientX, B.clientY, r, Q, D);
                                        p = K(this.data, 16) || H ? p || B : B
                                    }
                                    this.i && this.g && H && K(q.j, 14) && l.timeStamp - this.g.timeStamp < 300 && (l = this.i.changedTouches[0], l = hc(l.clientX, l.clientY, r, Q, D), p = p || l);
                                    l = p
                                } else l = !1
                            }
                        } else l = L(p, 11) > 0 ? ic(this, l, q) : !0;
                        if (l) {
                            var w = q;
                            h = L(q.j, 3)
                        }
                    }
                    if (w) switch (q = w.j, M(q, 4)) {
                        case 2:
                        case 3:
                            g.preventDefault ? g.preventDefault() : g.returnValue = !1;
                            h = Date.now();
                            h - w.F > 500 && (w.F = h, ++w.D);
                            h = w.j;
                            if (L(h, 8) && w.D >= L(h, 8))
                                if (w.A = !0, this.h && L(h, 2) > 0) fc(this);
                                else if (this.m.length > 0 && (J(h) ? ? ""))
                                for (var za of this.m) Y(za, !1);
                            xb();
                            za = Fa(q);
                            q = w = null;
                            this.g && g.timeStamp - this.g.timeStamp < 300 && (w = this.i, q = this.g);
                            for (let Q of this.C) Q(g, za, w, q, this.v)
                    }
                }
            }, pb);
            (c || k || d) && P(R, "touchstart", g => {
                this.i = g
            }, qb);
            (a && e || c || d) && P(R, "touchend", g => {
                this.g = g
            }, qb)
        }
        registerCallback(a) {
            this.C.push(a)
        }
    };
    var lc = wb(document.currentScript);
    if (lc == null) throw Error("JSC not found 23");
    var jc, mc = {},
        nc = lc.attributes;
    for (let a = nc.length - 1; a >= 0; a--) {
        let b = nc[a].name;
        b.indexOf("data-jcp-") === 0 && (mc[b.substring(9)] = nc[a].value)
    }
    jc = mc;
    var oc = window;
    oc.googqscp = new kc;
    jc["init-data"] && oc.googqscp.init(JSON.parse(jc["init-data"]));
}).call(this);
(function() {
    var n, aa = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("a");
        },
        da = ca(this),
        ea = "Int8 Uint8 Uint8Clamped Int16 Uint16 Int32 Uint32 Float32 Float64".split(" ");
    da.BigInt64Array && (ea.push("BigInt64"), ea.push("BigUint64"));
    var ia = function(a, b) {
            if (b)
                for (var c = 0; c < ea.length; c++) ha(ea[c] + "Array.prototype." + a, b)
        },
        p = function(a, b) {
            b && ha(a, b)
        },
        ha = function(a, b) {
            var c = da;
            a = a.split(".");
            for (var d = 0; d < a.length - 1; d++) {
                var e = a[d];
                if (!(e in c)) return;
                c = c[e]
            }
            a = a[a.length - 1];
            d = c[a];
            b = b(d);
            b != d && b != null && ba(c, a, {
                configurable: !0,
                writable: !0,
                value: b
            })
        },
        ja;
    if (typeof Object.setPrototypeOf == "function") ja = Object.setPrototypeOf;
    else {
        var ka;
        a: {
            var la = {
                    a: !0
                },
                ma = {};
            try {
                ma.__proto__ = la;
                ka = ma.a;
                break a
            } catch (a) {}
            ka = !1
        }
        ja = ka ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError("b`" + a);
            return a
        } : null
    }
    var na = ja,
        q = function(a, b) {
            a.prototype = aa(b.prototype);
            a.prototype.constructor = a;
            if (na) na(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.xj = b.prototype
        },
        pa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        x = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: pa(a)
            };
            throw Error("c`" + String(a));
        },
        y = function(a) {
            if (!(a instanceof Array)) {
                a = x(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        ra = function(a) {
            return qa(a, a)
        },
        qa = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        sa = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        ta = typeof Object.assign == "function" ? Object.assign : function(a, b) {
            if (a == null) throw new TypeError("d");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) sa(d,
                        e) && (a[e] = d[e])
            }
            return a
        };
    p("Object.assign", function(a) {
        return a || ta
    });
    var ua = function(a) {
            if (!(a instanceof Object)) throw new TypeError("e`" + a);
        },
        A = function() {
            this.Oc = !1;
            this.Wa = null;
            this.V = void 0;
            this.A = 1;
            this.Qa = this.ob = 0;
            this.Ee = this.ha = null
        };
    A.prototype.Ua = function() {
        if (this.Oc) throw new TypeError("f");
        this.Oc = !0
    };
    A.prototype.Xc = function(a) {
        this.V = a
    };
    A.prototype.jd = function(a) {
        this.ha = {
            fg: a,
            Cg: !0
        };
        this.A = this.ob || this.Qa
    };
    A.prototype.getNextAddressJsc = function() {
        return this.A
    };
    A.prototype.getYieldResultJsc = function() {
        return this.V
    };
    A.prototype.return = function(a) {
        this.ha = {
            return: a
        };
        this.A = this.Qa
    };
    A.prototype["return"] = A.prototype.return;
    A.prototype.Bi = function(a) {
        this.ha = {
            ba: a
        };
        this.A = this.Qa
    };
    A.prototype.jumpThroughFinallyBlocks = A.prototype.Bi;
    A.prototype.u = function(a, b) {
        this.A = b;
        return {
            value: a
        }
    };
    A.prototype.yield = A.prototype.u;
    A.prototype.Ij = function(a, b) {
        a = x(a);
        var c = a.next();
        ua(c);
        if (c.done) this.V = c.value, this.A = b;
        else return this.Wa = a, this.u(c.value, b)
    };
    A.prototype.yieldAll = A.prototype.Ij;
    A.prototype.ba = function(a) {
        this.A = a
    };
    A.prototype.jumpTo = A.prototype.ba;
    A.prototype.Eb = function() {
        this.A = 0
    };
    A.prototype.jumpToEnd = A.prototype.Eb;
    A.prototype.Lb = function(a, b) {
        this.ob = a;
        b != void 0 && (this.Qa = b)
    };
    A.prototype.setCatchFinallyBlocks = A.prototype.Lb;
    A.prototype.qf = function(a) {
        this.ob = 0;
        this.Qa = a || 0
    };
    A.prototype.setFinallyBlock = A.prototype.qf;
    A.prototype.Pc = function(a, b) {
        this.A = a;
        this.ob = b || 0
    };
    A.prototype.leaveTryBlock = A.prototype.Pc;
    A.prototype.sb = function(a) {
        this.ob = a || 0;
        a = this.ha.fg;
        this.ha = null;
        return a
    };
    A.prototype.enterCatchBlock = A.prototype.sb;
    A.prototype.Bd = function(a, b, c) {
        c ? this.Ee[c] = this.ha : this.Ee = [this.ha];
        this.ob = a || 0;
        this.Qa = b || 0
    };
    A.prototype.enterFinallyBlock = A.prototype.Bd;
    A.prototype.Nd = function(a, b) {
        b = this.Ee.splice(b || 0)[0];
        (b = this.ha = this.ha || b) ? b.Cg ? this.A = this.ob || this.Qa : b.ba != void 0 && this.Qa < b.ba ? (this.A = b.ba, this.ha = null) : this.A = this.Qa: this.A = a
    };
    A.prototype.leaveFinallyBlock = A.prototype.Nd;
    A.prototype.forIn = function(a) {
        return new va(a)
    };
    A.prototype.forIn = A.prototype.forIn;
    var va = function(a) {
        this.Si = a;
        this.Td = [];
        for (var b in a) this.Td.push(b);
        this.Td.reverse()
    };
    va.prototype.ci = function() {
        for (; this.Td.length > 0;) {
            var a = this.Td.pop();
            if (a in this.Si) return a
        }
        return null
    };
    va.prototype.getNext = va.prototype.ci;
    var wa = function(a) {
        this.B = new A;
        this.aj = a
    };
    wa.prototype.Xc = function(a) {
        this.B.Ua();
        if (this.B.Wa) return xa(this, this.B.Wa.next, a, this.B.Xc);
        this.B.Xc(a);
        return ya(this)
    };
    var za = function(a, b) {
        a.B.Ua();
        var c = a.B.Wa;
        if (c) return xa(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.B.return);
        a.B.return(b);
        return ya(a)
    };
    wa.prototype.jd = function(a) {
        this.B.Ua();
        if (this.B.Wa) return xa(this, this.B.Wa["throw"], a, this.B.Xc);
        this.B.jd(a);
        return ya(this)
    };
    var xa = function(a, b, c, d) {
            try {
                var e = b.call(a.B.Wa, c);
                ua(e);
                if (!e.done) return a.B.Oc = !1, e;
                var f = e.value
            } catch (g) {
                return a.B.Wa = null, a.B.jd(g), ya(a)
            }
            a.B.Wa = null;
            d.call(a.B, f);
            return ya(a)
        },
        ya = function(a) {
            for (; a.B.A;) try {
                var b = a.aj(a.B);
                if (b) return a.B.Oc = !1, {
                    value: b.value,
                    done: !1
                }
            } catch (c) {
                a.B.V = void 0, a.B.jd(c)
            }
            a.B.Oc = !1;
            if (a.B.ha) {
                b = a.B.ha;
                a.B.ha = null;
                if (b.Cg) throw b.fg;
                return {
                    value: b.return,
                    done: !0
                }
            }
            return {
                value: void 0,
                done: !0
            }
        },
        Aa = function(a) {
            this.next = function(b) {
                return a.Xc(b)
            };
            this.throw = function(b) {
                return a.jd(b)
            };
            this.return = function(b) {
                return za(a, b)
            };
            this[Symbol.iterator] = function() {
                return this
            }
        },
        Ba = function(a) {
            function b(d) {
                return a.next(d)
            }

            function c(d) {
                return a.throw(d)
            }
            return new Promise(function(d, e) {
                function f(g) {
                    g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e)
                }
                f(a.next())
            })
        },
        Ca = function(a) {
            return Ba(new Aa(new wa(a)))
        };
    p("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.th = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.th
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("g");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    });
    p("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        ba(Array.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return Da(pa(this))
            }
        });
        return a
    });
    p("Symbol.asyncIterator", function(a) {
        return a ? a : Symbol("Symbol.asyncIterator")
    });
    var Da = function(a) {
            a = {
                next: a
            };
            a[Symbol.iterator] = function() {
                return this
            };
            return a
        },
        Ea = function(a) {
            this[Symbol.asyncIterator] = function() {
                return this
            };
            this[Symbol.iterator] = function() {
                return a
            };
            this.next = function(b) {
                return Promise.resolve(a.next(b))
            };
            this["throw"] = function(b) {
                return new Promise(function(c, d) {
                    var e = a["throw"];
                    e !== void 0 ? c(e.call(a, b)) : (c = a["return"], c !== void 0 && c.call(a), d(new TypeError("h")))
                })
            };
            a["return"] !== void 0 && (this["return"] = function(b) {
                return Promise.resolve(a["return"](b))
            })
        },
        E = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    p("globalThis", function(a) {
        return a || da
    });
    p("Reflect.setPrototypeOf", function(a) {
        return a ? a : na ? function(b, c) {
            try {
                return na(b, c), !0
            } catch (d) {
                return !1
            }
        } : null
    });
    p("Promise", function(a) {
        function b() {
            this.Xa = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(h) {
                h(g)
            })
        }
        if (a) return a;
        b.prototype.Rf = function(g) {
            if (this.Xa == null) {
                this.Xa = [];
                var h = this;
                this.Sf(function() {
                    h.Wh()
                })
            }
            this.Xa.push(g)
        };
        var d = da.setTimeout;
        b.prototype.Sf = function(g) {
            d(g, 0)
        };
        b.prototype.Wh = function() {
            for (; this.Xa && this.Xa.length;) {
                var g = this.Xa;
                this.Xa = [];
                for (var h = 0; h < g.length; ++h) {
                    var k = g[h];
                    g[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.Ch(l)
                    }
                }
            }
            this.Xa = null
        };
        b.prototype.Ch = function(g) {
            this.Sf(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.wc = 0;
            this.ed = void 0;
            this.nc = [];
            this.Hg = !1;
            var h = this.we();
            try {
                g(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        };
        e.prototype.we = function() {
            function g(l) {
                return function(m) {
                    k || (k = !0, l.call(h, m))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: g(this.mj),
                reject: g(this.jf)
            }
        };
        e.prototype.mj = function(g) {
            if (g === this) this.jf(new TypeError("i"));
            else if (g instanceof e) this.rj(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var h = g != null;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.lj(g) : this.ig(g)
            }
        };
        e.prototype.lj = function(g) {
            var h = void 0;
            try {
                h = g.then
            } catch (k) {
                this.jf(k);
                return
            }
            typeof h == "function" ? this.sj(h, g) : this.ig(g)
        };
        e.prototype.jf = function(g) {
            this.Zg(2, g)
        };
        e.prototype.ig = function(g) {
            this.Zg(1, g)
        };
        e.prototype.Zg = function(g, h) {
            if (this.wc != 0) throw Error("j`" + g + "`" + h + "`" + this.wc);
            this.wc = g;
            this.ed = h;
            this.wc === 2 && this.oj();
            this.Xh()
        };
        e.prototype.oj = function() {
            var g = this;
            d(function() {
                if (g.Qi()) {
                    var h = da.console;
                    typeof h !== "undefined" && h.error(g.ed)
                }
            }, 1)
        };
        e.prototype.Qi = function() {
            if (this.Hg) return !1;
            var g = da.CustomEvent,
                h = da.Event,
                k = da.dispatchEvent;
            if (typeof k === "undefined") return !0;
            typeof g === "function" ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : typeof h === "function" ? g = new h("unhandledrejection", {
                cancelable: !0
            }) : (g = da.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.ed;
            return k(g)
        };
        e.prototype.Xh = function() {
            if (this.nc != null) {
                for (var g = 0; g < this.nc.length; ++g) f.Rf(this.nc[g]);
                this.nc = null
            }
        };
        var f = new b;
        e.prototype.rj = function(g) {
            var h =
                this.we();
            g.td(h.resolve, h.reject)
        };
        e.prototype.sj = function(g, h) {
            var k = this.we();
            try {
                g.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        e.prototype.then = function(g, h) {
            function k(t, r) {
                return typeof t == "function" ? function(w) {
                    try {
                        l(t(w))
                    } catch (v) {
                        m(v)
                    }
                } : r
            }
            var l, m, u = new e(function(t, r) {
                l = t;
                m = r
            });
            this.td(k(g, l), k(h, m));
            return u
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.td = function(g, h) {
            function k() {
                switch (l.wc) {
                    case 1:
                        g(l.ed);
                        break;
                    case 2:
                        h(l.ed);
                        break;
                    default:
                        throw Error("k`" +
                            l.wc);
                }
            }
            var l = this;
            this.nc == null ? f.Rf(k) : this.nc.push(k);
            this.Hg = !0
        };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(h, k) {
                k(g)
            })
        };
        e.race = function(g) {
            return new e(function(h, k) {
                for (var l = x(g), m = l.next(); !m.done; m = l.next()) c(m.value).td(h, k)
            })
        };
        e.all = function(g) {
            var h = x(g),
                k = h.next();
            return k.done ? c([]) : new e(function(l, m) {
                function u(w) {
                    return function(v) {
                        t[w] = v;
                        r--;
                        r == 0 && l(t)
                    }
                }
                var t = [],
                    r = 0;
                do t.push(void 0), r++, c(k.value).td(u(t.length - 1), m), k = h.next(); while (!k.done)
            })
        };
        return e
    });
    p("Object.setPrototypeOf", function(a) {
        return a || na
    });
    p("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    });
    p("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) sa(b, d) && c.push(b[d]);
            return c
        }
    });
    var Fa = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    };
    p("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Fa(this, function(b) {
                return b
            })
        }
    });
    p("WeakMap", function(a) {
        function b() {}

        function c(k) {
            var l = typeof k;
            return l === "object" && k !== null || l === "function"
        }

        function d(k) {
            if (!sa(k, f)) {
                var l = new b;
                ba(k, f, {
                    value: l
                })
            }
        }

        function e(k) {
            var l = Object[k];
            l && (Object[k] = function(m) {
                if (m instanceof b) return m;
                Object.isExtensible(m) && d(m);
                return l(m)
            })
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var k = Object.seal({}),
                        l = Object.seal({}),
                        m = new a([
                            [k, 2],
                            [l, 3]
                        ]);
                    if (m.get(k) != 2 || m.get(l) != 3) return !1;
                    m.delete(k);
                    m.set(l, 4);
                    return !m.has(k) && m.get(l) == 4
                } catch (u) {
                    return !1
                }
            }()) return a;
        var f = "$jscomp_hidden_" + Math.random();
        e("freeze");
        e("preventExtensions");
        e("seal");
        var g = 0,
            h = function(k) {
                this.Nc = (g += Math.random() + 1).toString();
                if (k) {
                    k = x(k);
                    for (var l; !(l = k.next()).done;) l = l.value, this.set(l[0], l[1])
                }
            };
        h.prototype.set = function(k, l) {
            if (!c(k)) throw Error("l");
            d(k);
            if (!sa(k, f)) throw Error("m`" + k);
            k[f][this.Nc] = l;
            return this
        };
        h.prototype.get = function(k) {
            return c(k) && sa(k, f) ? k[f][this.Nc] : void 0
        };
        h.prototype.has = function(k) {
            return c(k) && sa(k, f) && sa(k[f], this.Nc)
        };
        h.prototype.delete = function(k) {
            return c(k) &&
                sa(k, f) && sa(k[f], this.Nc) ? delete k[f][this.Nc] : !1
        };
        return h
    });
    p("Map", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(x([
                            [h, "s"]
                        ]));
                    if (k.get(h) != "s" || k.size != 1 || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || k.size != 2) return !1;
                    var l = k.entries(),
                        m = l.next();
                    if (m.done || m.value[0] != h || m.value[1] != "s") return !1;
                    m = l.next();
                    return m.done || m.value[0].x != 4 || m.value[1] != "t" || !l.next().done ? !1 : !0
                } catch (u) {
                    return !1
                }
            }()) return a;
        var b = new WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] =
                    f();
                this.size = 0;
                if (h) {
                    h = x(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = h === 0 ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.entry ? l.entry.value = k : (l.entry = {
                next: this[1],
                Ta: this[1].Ta,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.entry), this[1].Ta.next = l.entry, this[1].Ta = l.entry, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.entry && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.entry.Ta.next =
                h.entry.next, h.entry.next.Ta = h.entry.Ta, h.entry.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].Ta = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).entry
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).entry) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach =
            function(h, k) {
                for (var l = this.entries(), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
            };
        c.prototype[Symbol.iterator] = c.prototype.entries;
        var d = function(h, k) {
                var l = k && typeof k;
                l == "object" || l == "function" ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var m = h[0][l];
                if (m && sa(h[0], l))
                    for (h = 0; h < m.length; h++) {
                        var u = m[h];
                        if (k !== k && u.key !== u.key || k === u.key) return {
                            id: l,
                            list: m,
                            index: h,
                            entry: u
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    entry: void 0
                }
            },
            e = function(h, k) {
                var l = h[1];
                return Da(function() {
                    if (l) {
                        for (; l.head !=
                            h[1];) l = l.Ta;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.Ta = h.next = h.head = h
            },
            g = 0;
        return c
    });
    p("Set", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(x([c]));
                    if (!d.has(c) || d.size != 1 || d.add(c) != d || d.size != 1 || d.add({
                            x: 4
                        }) != d || d.size != 2) return !1;
                    var e = d.entries(),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || f.value[0].x != 4 || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.Ha = new Map;
            if (c) {
                c =
                    x(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.Ha.size
        };
        b.prototype.add = function(c) {
            c = c === 0 ? 0 : c;
            this.Ha.set(c, c);
            this.size = this.Ha.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.Ha.delete(c);
            this.size = this.Ha.size;
            return c
        };
        b.prototype.clear = function() {
            this.Ha.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.Ha.has(c)
        };
        b.prototype.entries = function() {
            return this.Ha.entries()
        };
        b.prototype.values = function() {
            return this.Ha.values()
        };
        b.prototype.keys = b.prototype.values;
        b.prototype[Symbol.iterator] = b.prototype.values;
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.Ha.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    });
    p("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Fa(this, function(b, c) {
                return [b, c]
            })
        }
    });
    var Ga = function(a, b, c) {
        if (a == null) throw new TypeError("n`" + c);
        if (b instanceof RegExp) throw new TypeError("o`" + c);
        return a + ""
    };
    p("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Ga(this, b, "startsWith");
            b += "";
            var e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    });
    p("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
        }
    });
    p("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = Ga(this, null, "repeat");
            if (b < 0 || b > 1342177279) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    });
    p("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
        }
    });
    p("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || Object.is(f, b)) return !0
            }
            return !1
        }
    });
    p("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return Ga(this, b, "includes").indexOf(b, c || 0) !== -1
        }
    });
    p("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) sa(b, d) && c.push([d, b[d]]);
            return c
        }
    });
    p("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(h) {
                return h
            };
            var e = [],
                f = typeof Symbol != "undefined" && Symbol.iterator && b[Symbol.iterator];
            if (typeof f == "function") {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    });
    p("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || b === Infinity || b === -Infinity || b === 0) return b;
            var c = Math.floor(Math.abs(b));
            return b < 0 ? -c : c
        }
    });
    p("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    });
    p("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = Ga(this, null, "padStart");
            b -= d.length;
            c = c !== void 0 ? String(c) : " ";
            return (b > 0 && c ? c.repeat(Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    });
    p("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    });
    p("Number.MIN_SAFE_INTEGER", function() {
        return -9007199254740991
    });
    p("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return Number.isFinite(b) ? b === Math.floor(b) : !1
        }
    });
    p("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER
        }
    });
    p("Math.log2", function(a) {
        return a ? a : function(b) {
            return Math.log(b) / Math.LN2
        }
    });
    p("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return typeof b === "number" && isNaN(b)
        }
    });
    p("Array.prototype.values", function(a) {
        return a ? a : function() {
            return Fa(this, function(b, c) {
                return c
            })
        }
    });
    p("Array.prototype.fill", function(a) {
        return a ? a : function(b, c, d) {
            var e = this.length || 0;
            c < 0 && (c = Math.max(0, e + c));
            if (d == null || d > e) d = e;
            d = Number(d);
            d < 0 && (d = Math.max(0, e + d));
            for (c = Number(c || 0); c < d; c++) this[c] = b;
            return this
        }
    });
    ia("fill", function(a) {
        return a ? a : Array.prototype.fill
    });
    p("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = b === void 0 ? 1 : b;
            var c = [];
            Array.prototype.forEach.call(this, function(d) {
                Array.isArray(d) && b > 0 ? (d = Array.prototype.flat.call(d, b - 1), c.push.apply(c, d)) : c.push(d)
            });
            return c
        }
    });
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var Ha = this || self,
        Ia = function(a, b) {
            a: {
                var c = ["CLOSURE_FLAGS"];
                for (var d = Ha, e = 0; e < c.length; e++)
                    if (d = d[c[e]], d == null) {
                        c = null;
                        break a
                    }
                c = d
            }
            a = c && c[a];
            return a != null ? a : b
        },
        Ja = function(a) {
            var b = typeof a;
            return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
        },
        Ka = function(a) {
            var b = Ja(a);
            return b == "array" || b == "object" && typeof a.length == "number"
        },
        La = function(a) {
            var b = typeof a;
            return b == "object" && a != null || b == "function"
        },
        Ma = function(a) {
            return a
        },
        Na = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.xj = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.qk = function(d, e, f) {
                for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
                return b.prototype[e].apply(d, g)
            }
        };
    var Oa = function() {
        this.xf = 0
    };
    Oa.prototype.yc = function(a, b) {
        var c = this;
        return function() {
            var d = E.apply(0, arguments);
            c.xf = a;
            return b.apply(null, y(d))
        }
    };
    var Pa = function() {
            var a = {};
            this.Ja = (a[3] = [], a[2] = [], a[1] = [], a);
            this.Ve = !1
        },
        Ta = function(a, b, c) {
            var d = Sa(a, c);
            a.Ja[c].push(b);
            d && a.Ja[c].length === 1 && a.flush()
        },
        Sa = function(a, b) {
            return Object.keys(a.Ja).map(function(c) {
                return Number(c)
            }).filter(function(c) {
                return !isNaN(c) && c > b
            }).every(function(c) {
                return a.Ja[c].length === 0
            })
        };
    Pa.prototype.flush = function() {
        if (!this.Ve) {
            this.Ve = !0;
            try {
                for (; Object.values(this.Ja).some(function(a) {
                        return a.length > 0
                    });) Ua(this, 3), Ua(this, 2), Ua(this, 1)
            } catch (a) {
                throw Object.values(this.Ja).forEach(function(b) {
                    return void b.splice(0, b.length)
                }), a;
            } finally {
                this.Ve = !1
            }
        }
    };
    var Ua = function(a, b) {
        for (; Sa(a, b) && a.Ja[b].length > 0;) a.Ja[b][0](), a.Ja[b].shift()
    };
    da.Object.defineProperties(Pa.prototype, {
        Sg: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Object.values(this.Ja).some(function(a) {
                    return a.length > 0
                })
            }
        }
    });

    function Va(a, b) {
        return a.toLowerCase().indexOf(b.toLowerCase()) != -1
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var Wa = {};
    var Xa = globalThis.trustedTypes,
        $a;

    function ab() {
        var a = null;
        if (!Xa) return a;
        try {
            var b = function(c) {
                return c
            };
            a = Xa.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {
            throw c;
        }
        return a
    };
    var bb = function(a) {
        if (Wa !== Wa) throw Error("p");
        this.Qg = a
    };
    bb.prototype.toString = function() {
        return this.Qg + ""
    };

    function cb(a) {
        var b;
        $a === void 0 && ($a = ab());
        a = (b = $a) ? b.createScriptURL(a) : a;
        return new bb(a)
    };
    var db = ra([""]),
        eb = qa(["\x00"], ["\\0"]),
        fb = qa(["\n"], ["\\n"]),
        hb = qa(["\x00"], ["\\u0000"]),
        ib = ra([""]),
        jb = qa(["\x00"], ["\\0"]),
        kb = qa(["\n"], ["\\n"]),
        lb = qa(["\x00"], ["\\u0000"]);

    function mb(a) {
        return Object.isFrozen(a) && Object.isFrozen(a.raw)
    }

    function nb(a) {
        return a.toString().indexOf("`") === -1
    }
    var ob = nb(function(a) {
            return a(db)
        }) || nb(function(a) {
            return a(eb)
        }) || nb(function(a) {
            return a(fb)
        }) || nb(function(a) {
            return a(hb)
        }),
        pb = mb(ib) && mb(jb) && mb(kb) && mb(lb);
    var qb = function(a) {
        if (Wa !== Wa) throw Error("p");
        this.Zi = a
    };
    qb.prototype.toString = function() {
        return this.Zi
    };
    new qb("about:blank");
    new qb("about:invalid#zClosurez");
    var rb = [],
        sb = function(a) {
            console.warn("r`" + a)
        };
    rb.indexOf(sb) === -1 && rb.push(sb);

    function tb(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, tb);
        else {
            var c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        b !== void 0 && (this.cause = b)
    }
    Na(tb, Error);
    tb.prototype.name = "CustomError";
    var ub;

    function vb(a, b) {
        var c = tb.call;
        a = a.split("%s");
        for (var d = "", e = a.length - 1, f = 0; f < e; f++) d += a[f] + (f < b.length ? b[f] : "%s");
        c.call(tb, this, d + a[e])
    }
    Na(vb, tb);
    vb.prototype.name = "AssertionError";

    function wb(a, b, c, d) {
        var e = "Assertion failed";
        if (c) {
            e += ": " + c;
            var f = d
        } else a && (e += ": " + a, f = b);
        throw new vb("" + e, f || []);
    }
    var F = function(a, b, c) {
            a || wb("", null, b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        G = function(a, b, c) {
            a == null && wb("Expected to exist: %s.", [a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        xb = function(a, b) {
            throw new vb("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
        },
        yb = function(a, b, c) {
            typeof a !== "number" && wb("Expected number but got %s: %s.", [Ja(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        zb = function(a, b, c) {
            typeof a !== "string" && wb("Expected string but got %s: %s.", [Ja(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        Ab = function(a, b, c) {
            typeof a !== "function" && wb("Expected function but got %s: %s.", [Ja(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Cb = function(a, b, c) {
            La(a) || wb("Expected object but got %s: %s.", [Ja(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        I = function(a, b, c) {
            Array.isArray(a) || wb("Expected array but got %s: %s.", [Ja(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Eb = function(a, b, c, d) {
            a instanceof b || wb("Expected instanceof %s but got %s.", [Db(b), Db(a)], c, Array.prototype.slice.call(arguments, 3));
            return a
        };

    function Db(a) {
        return a instanceof Function ? a.displayName || a.name || "unknown type name" : a instanceof Object ? a.constructor.displayName || a.constructor.name || Object.prototype.toString.call(a) : a === null ? "null" : typeof a
    };
    var Fb = Array.prototype.forEach ? function(a, b) {
            F(a.length != null);
            Array.prototype.forEach.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
        },
        Gb = Array.prototype.map ? function(a, b) {
            F(a.length != null);
            return Array.prototype.map.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = Array(c), e = typeof a === "string" ? a.split("") : a, f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
            return d
        },
        Hb = Array.prototype.some ? function(a, b) {
            F(a.length !=
                null);
            return Array.prototype.some.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) return !0;
            return !1
        };

    function Ib(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function Jb(a) {
        var b = a.length;
        if (b > 0) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function Kb(a, b, c) {
        if (!Ka(a) || !Ka(b) || a.length != b.length) return !1;
        var d = a.length;
        c = c || Lb;
        for (var e = 0; e < d; e++)
            if (!c(a[e], b[e])) return !1;
        return !0
    }

    function Lb(a, b) {
        return a === b
    }

    function Mb(a, b) {
        return Ib.apply([], Gb(a, b))
    };

    function Nb(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var Ob = function(a, b) {
        this.name = a;
        this.value = b
    };
    Ob.prototype.toString = function() {
        return this.name
    };
    var Pb = new Ob("OFF", Infinity),
        Qb = new Ob("WARNING", 900),
        Rb = new Ob("INFO", 800),
        Sb = new Ob("CONFIG", 700),
        Tb = function() {
            this.ud = 0;
            this.clear()
        },
        Ub;
    Tb.prototype.clear = function() {
        this.J = Array(this.ud);
        this.Zf = -1;
        this.Dg = !1
    };
    var Vb = function(a, b, c) {
        this.reset(a || Pb, b, c, void 0, void 0)
    };
    Vb.prototype.reset = function(a, b, c, d) {
        d || Date.now();
        this.Oi = b
    };
    Vb.prototype.getMessage = function() {
        return this.Oi
    };
    var Wb = function(a, b) {
            this.level = null;
            this.gi = [];
            this.parent = (b === void 0 ? null : b) || null;
            this.children = [];
            this.Fi = {
                getName: function() {
                    return a
                }
            }
        },
        Xb = function(a) {
            if (a.level) return a.level;
            if (a.parent) return Xb(a.parent);
            xb("Root logger has no level set.");
            return Pb
        },
        Yb = function(a, b) {
            for (; a;) a.gi.forEach(function(c) {
                c(b)
            }), a = a.parent
        },
        Zb = function() {
            this.entries = {};
            var a = new Wb("");
            a.level = Sb;
            this.entries[""] = a
        },
        $b, ac = function(a, b, c) {
            var d = a.entries[b];
            if (d) return c !== void 0 && (d.level = c), d;
            d = b.lastIndexOf(".");
            d = b.slice(0, Math.max(d, 0));
            d = ac(a, d);
            var e = new Wb(b, d);
            a.entries[b] = e;
            d.children.push(e);
            c !== void 0 && (e.level = c);
            return e
        },
        bc = function() {
            $b || ($b = new Zb);
            return $b
        },
        dc = function(a) {
            var b = cc;
            if (b) {
                var c = a,
                    d = Qb;
                if (a = b)
                    if (a = b && d) {
                        a = d.value;
                        var e = b ? Xb(ac(bc(), b.getName())) : Pb;
                        a = a >= e.value
                    }
                if (a) {
                    d = d || Pb;
                    a = ac(bc(), b.getName());
                    typeof c === "function" && (c = c());
                    Ub || (Ub = new Tb);
                    e = Ub;
                    b = b.getName();
                    if (e.ud > 0) {
                        var f = (e.Zf + 1) % e.ud;
                        e.Zf = f;
                        e.Dg ? (e = e.J[f], e.reset(d, c, b), b = e) : (e.Dg = f == e.ud - 1, b = e.J[f] = new Vb(d, c, b))
                    } else b =
                        new Vb(d, c, b);
                    Yb(a, b)
                }
            }
        };
    var ec = function() {
        this.names = new Map
    };
    ec.prototype.getName = function(a) {
        var b = this.names.get(a);
        if (b) return b;
        var c;
        b = (c = a.description) != null ? c : Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ Date.now()).toString(36);
        this.names.set(a, b);
        return b
    };
    /*


     Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors
     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at
         http://www.apache.org/licenses/LICENSE-2.0
     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
    */
    var fc = function(a) {
        var b = Error.call(this, a ? a.length + " errors occurred during unsubscription:\n" + a.map(function(c, d) {
            return d + 1 + ") " + c.toString()
        }).join("\n  ") : "");
        this.message = b.message;
        "stack" in b && (this.stack = b.stack);
        this.errors = a;
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "UnsubscriptionError"
    };
    q(fc, Error);

    function hc(a, b) {
        a && (b = a.indexOf(b), 0 <= b && a.splice(b, 1))
    };

    function J(a) {
        return typeof a === "function"
    };
    var ic = function(a) {
        this.mi = a;
        this.closed = !1;
        this.Ac = this.Vb = null
    };
    n = ic.prototype;
    n.unsubscribe = function() {
        if (!this.closed) {
            this.closed = !0;
            var a = this.Vb;
            if (Array.isArray(a))
                for (var b = x(a), c = b.next(); !c.done; c = b.next()) c.value.remove(this);
            else a == null || a.remove(this);
            b = this.mi;
            if (J(b)) try {
                b()
            } catch (f) {
                var d = f instanceof fc ? f.errors : [f]
            }
            var e = this.Ac;
            if (e)
                for (this.Ac = null, b = x(e), c = b.next(); !c.done; c = b.next()) {
                    c = c.value;
                    try {
                        J(c) ? c() : c.unsubscribe()
                    } catch (f) {
                        c = void 0, d = (c = d) != null ? c : [], f instanceof fc ? d = [].concat(y(d), y(f.errors)) : d.push(f)
                    }
                }
            if (d) throw new fc(d);
        }
    };
    n.add = function(a) {
        if (a && a !== this)
            if (this.closed) J(a) ? a() : a.unsubscribe();
            else {
                if (a instanceof ic) {
                    if (a.closed || a.wh(this)) return;
                    a.uh(this)
                }
                var b;
                (this.Ac = (b = this.Ac) != null ? b : []).push(a)
            }
    };
    n.wh = function(a) {
        var b = this.Vb;
        return b === a || Array.isArray(b) && b.includes(a)
    };
    n.uh = function(a) {
        var b = this.Vb;
        this.Vb = Array.isArray(b) ? (b.push(a), b) : b ? [b, a] : a
    };
    n.xh = function(a) {
        var b = this.Vb;
        b === a ? this.Vb = null : Array.isArray(b) && hc(b, a)
    };
    n.remove = function(a) {
        var b = this.Ac;
        b && hc(b, a);
        a instanceof ic && a.xh(this)
    };
    var jc = new ic;
    jc.closed = !0;
    ic.EMPTY = jc;

    function kc(a) {
        return a instanceof ic || a && "closed" in a && J(a.remove) && J(a.add) && J(a.unsubscribe)
    };
    var lc = function() {
        setTimeout.apply(null, y(E.apply(0, arguments)))
    };

    function mc() {};

    function nc(a) {
        lc(function() {
            throw a;
        })
    };
    var oc = function(a) {
        ic.call(this);
        this.U = !1;
        this.destination = a instanceof oc ? a : new qc(!a || J(a) ? {
            next: a != null ? a : void 0
        } : a);
        kc(a) && a.add(this)
    };
    q(oc, ic);
    oc.EMPTY = ic.EMPTY;
    oc.create = function(a, b, c) {
        return new rc(a, b, c)
    };
    n = oc.prototype;
    n.next = function(a) {
        this.U || this.ie(a)
    };
    n.error = function(a) {
        this.U || (this.U = !0, this.Lf(a))
    };
    n.complete = function() {
        this.U || (this.U = !0, this.nd())
    };
    n.unsubscribe = function() {
        this.closed || (this.U = !0, ic.prototype.unsubscribe.call(this))
    };
    n.ie = function(a) {
        this.destination.next(a)
    };
    n.Lf = function(a) {
        this.destination.error(a);
        this.unsubscribe()
    };
    n.nd = function() {
        this.destination.complete();
        this.unsubscribe()
    };
    var qc = function(a) {
        this.df = a
    };
    qc.prototype.next = function(a) {
        var b = this.df;
        if (b.next) try {
            b.next(a)
        } catch (c) {
            nc(c)
        }
    };
    qc.prototype.error = function(a) {
        var b = this.df;
        if (b.error) try {
            b.error(a)
        } catch (c) {
            nc(c)
        } else nc(a)
    };
    qc.prototype.complete = function() {
        var a = this.df;
        if (a.complete) try {
            a.complete()
        } catch (b) {
            nc(b)
        }
    };
    var rc = function(a, b, c) {
        oc.call(this);
        this.destination = new qc(J(a) || !a ? {
            next: a != null ? a : void 0,
            error: b != null ? b : void 0,
            complete: c != null ? c : void 0
        } : a)
    };
    q(rc, oc);
    rc.EMPTY = oc.EMPTY;
    rc.create = oc.create;
    var sc = typeof Symbol === "function" && Symbol.observable || "@@observable";

    function tc(a) {
        return a
    };

    function K() {
        return uc(E.apply(0, arguments))
    }

    function uc(a) {
        return a.length === 0 ? tc : a.length === 1 ? a[0] : function(b) {
            return a.reduce(function(c, d) {
                return d(c)
            }, b)
        }
    };
    var L = function(a) {
        a && (this.La = a)
    };
    n = L.prototype;
    n.Gb = function(a) {
        var b = new L;
        b.source = this;
        b.operator = a;
        return b
    };
    n.subscribe = function(a, b, c) {
        a = a && a instanceof oc || a && J(a.next) && J(a.error) && J(a.complete) && kc(a) ? a : new rc(a, b, c);
        b = this.operator;
        c = this.source;
        a.add(b ? b.call(a, c) : c ? this.La(a) : this.ke(a));
        return a
    };
    n.ke = function(a) {
        try {
            return this.La(a)
        } catch (b) {
            a.error(b)
        }
    };
    n.forEach = function(a, b) {
        var c = this;
        b = vc(b);
        return new b(function(d, e) {
            var f = c.subscribe(function(g) {
                try {
                    a(g)
                } catch (h) {
                    e(h), f == null || f.unsubscribe()
                }
            }, e, d)
        })
    };
    n.La = function(a) {
        var b;
        return (b = this.source) == null ? void 0 : b.subscribe(a)
    };
    L.prototype[sc] = function() {
        return this
    };
    L.prototype.g = function() {
        var a = E.apply(0, arguments);
        return a.length ? uc(a)(this) : this
    };
    L.create = function(a) {
        return new L(a)
    };

    function vc(a) {
        var b;
        return (b = a != null ? a : void 0) != null ? b : Promise
    };
    var wc = function() {
        var a = Error.call(this, "object unsubscribed");
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "ObjectUnsubscribedError"
    };
    q(wc, Error);
    var xc = function() {
        this.lc = [];
        this.Gd = this.U = this.closed = !1;
        this.wf = null
    };
    q(xc, L);
    n = xc.prototype;
    n.Gb = function(a) {
        var b = new yc(this, this);
        b.operator = a;
        return b
    };
    n.kb = function() {
        if (this.closed) throw new wc;
    };
    n.next = function(a) {
        this.kb();
        if (!this.U) {
            var b = this.lc.slice();
            b = x(b);
            for (var c = b.next(); !c.done; c = b.next()) c.value.next(a)
        }
    };
    n.error = function(a) {
        this.kb();
        if (!this.U) {
            this.Gd = this.U = !0;
            this.wf = a;
            for (var b = this.lc; b.length;) b.shift().error(a)
        }
    };
    n.complete = function() {
        this.kb();
        if (!this.U) {
            this.U = !0;
            for (var a = this.lc; a.length;) a.shift().complete()
        }
    };
    n.unsubscribe = function() {
        this.U = this.closed = !0;
        this.lc = null
    };
    n.ke = function(a) {
        this.kb();
        return L.prototype.ke.call(this, a)
    };
    n.La = function(a) {
        this.kb();
        this.Kf(a);
        return this.Nf(a)
    };
    n.Nf = function(a) {
        var b = this,
            c = this.U,
            d = this.lc;
        return this.Gd || c ? ic.EMPTY : (d.push(a), new ic(function() {
            return hc(b.lc, a)
        }))
    };
    n.Kf = function(a) {
        var b = this.wf,
            c = this.U;
        this.Gd ? a.error(b) : c && a.complete()
    };
    n.X = function() {
        var a = new L;
        a.source = this;
        return a
    };
    xc.create = function(a, b) {
        return new yc(a, b)
    };
    var yc = function(a, b) {
        xc.call(this);
        this.destination = a;
        this.source = b
    };
    q(yc, xc);
    yc.create = xc.create;
    yc.prototype.next = function(a) {
        var b, c;
        (b = this.destination) == null || (c = b.next) == null || c.call(b, a)
    };
    yc.prototype.error = function(a) {
        var b, c;
        (b = this.destination) == null || (c = b.error) == null || c.call(b, a)
    };
    yc.prototype.complete = function() {
        var a, b;
        (a = this.destination) == null || (b = a.complete) == null || b.call(a)
    };
    yc.prototype.La = function(a) {
        var b, c;
        return (c = (b = this.source) == null ? void 0 : b.subscribe(a)) != null ? c : ic.EMPTY
    };
    var zc = function(a) {
        xc.call(this);
        this.le = a
    };
    q(zc, xc);
    zc.create = xc.create;
    zc.prototype.La = function(a) {
        var b = xc.prototype.La.call(this, a);
        !b.closed && a.next(this.le);
        return b
    };
    zc.prototype.getValue = function() {
        var a = this.wf,
            b = this.le;
        if (this.Gd) throw a;
        this.kb();
        return b
    };
    zc.prototype.next = function(a) {
        xc.prototype.next.call(this, this.le = a)
    };
    da.Object.defineProperties(zc.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.getValue()
            }
        }
    });
    var Ac = new L(function(a) {
        return a.complete()
    });

    function Bc(a, b) {
        return new L(function(c) {
            var d = 0;
            return b.M(function() {
                d === a.length ? c.complete() : (c.next(a[d++]), c.closed || this.M())
            })
        })
    };

    function Cc(a, b) {
        if (!a) throw Error("s");
        return new L(function(c) {
            var d = new ic;
            d.add(b.M(function() {
                var e = a[Symbol.asyncIterator]();
                d.add(b.M(function() {
                    var f = this;
                    e.next().then(function(g) {
                        g.done ? c.complete() : (c.next(g.value), f.M())
                    })
                }))
            }));
            return d
        })
    };
    var Dc = typeof Symbol === "function" && Symbol.iterator ? Symbol.iterator : "@@iterator";

    function Ec(a, b, c) {
        b = b.M(function() {
            try {
                c.call(this)
            } catch (d) {
                a.error(d)
            }
        }, 0);
        a.add(b)
    };

    function Fc(a, b) {
        return new L(function(c) {
            var d;
            c.add(b.M(function() {
                d = a[Dc]();
                Ec(c, b, function() {
                    var e = d.next(),
                        f = e.value;
                    e.done ? c.complete() : (c.next(f), this.M())
                })
            }));
            return function() {
                var e;
                return J((e = d) == null ? void 0 : e.return) && d.return()
            }
        })
    };

    function Gc(a, b) {
        return new L(function(c) {
            var d = new ic;
            d.add(b.M(function() {
                var e = a[sc]();
                d.add(e.subscribe({
                    next: function(f) {
                        d.add(b.M(function() {
                            return c.next(f)
                        }))
                    },
                    error: function(f) {
                        d.add(b.M(function() {
                            return c.error(f)
                        }))
                    },
                    complete: function() {
                        d.add(b.M(function() {
                            return c.complete()
                        }))
                    }
                }))
            }));
            return d
        })
    };

    function Hc(a, b) {
        return new L(function(c) {
            return b.M(function() {
                return a.then(function(d) {
                    c.add(b.M(function() {
                        c.next(d);
                        c.add(b.M(function() {
                            return c.complete()
                        }))
                    }))
                }, function(d) {
                    c.add(b.M(function() {
                        return c.error(d)
                    }))
                })
            })
        })
    };
    var Ic = function(a) {
        return a && typeof a.length === "number" && typeof a !== "function"
    };

    function Jc(a) {
        return new TypeError("t`" + (a !== null && typeof a === "object" ? "an invalid object" : "'" + a + "'"))
    };

    function Kc(a, b) {
        if (a != null) {
            if (J(a[sc])) return Gc(a, b);
            if (Ic(a)) return Bc(a, b);
            if (J(a == null ? void 0 : a.then)) return Hc(a, b);
            if (Symbol.asyncIterator && J(a == null ? void 0 : a[Symbol.asyncIterator])) return Cc(a, b);
            if (J(a == null ? void 0 : a[Dc])) return Fc(a, b)
        }
        throw Jc(a);
    };

    function Mc(a, b) {
        return b ? Kc(a, b) : Nc(a)
    }

    function Nc(a) {
        if (a instanceof L) return a;
        if (a != null) {
            if (J(a[sc])) return Qc(a);
            if (Ic(a)) return Rc(a);
            if (J(a == null ? void 0 : a.then)) return Sc(a);
            if (Symbol.asyncIterator && J(a == null ? void 0 : a[Symbol.asyncIterator])) return Tc(a);
            if (J(a == null ? void 0 : a[Dc])) return Uc(a)
        }
        throw Jc(a);
    }

    function Qc(a) {
        return new L(function(b) {
            var c = a[sc]();
            if (J(c.subscribe)) return c.subscribe(b);
            throw new TypeError("u");
        })
    }

    function Rc(a) {
        return new L(function(b) {
            for (var c = 0; c < a.length && !b.closed; c++) b.next(a[c]);
            b.complete()
        })
    }

    function Sc(a) {
        return new L(function(b) {
            a.then(function(c) {
                b.closed || (b.next(c), b.complete())
            }, function(c) {
                return b.error(c)
            }).then(null, nc)
        })
    }

    function Uc(a) {
        return new L(function(b) {
            for (var c = a[Dc](); !b.closed;) {
                var d = c.next(),
                    e = d.value;
                d.done ? b.complete() : b.next(e)
            }
            return function() {
                return J(c == null ? void 0 : c.return) && c.return()
            }
        })
    }

    function Tc(a) {
        return new L(function(b) {
            Vc(a, b).catch(function(c) {
                return b.error(c)
            })
        })
    }

    function Vc(a, b) {
        var c, d, e, f, g, h;
        return Ca(function(k) {
            switch (k.A) {
                case 1:
                    k.Lb(2, 3);
                    var l = a[Symbol.asyncIterator];
                    f = l !== void 0 ? l.call(a) : new Ea(x(a));
                case 5:
                    return k.u(f.next(), 8);
                case 8:
                    d = k.V;
                    if (d.done) {
                        k.ba(3);
                        break
                    }
                    g = d.value;
                    b.next(g);
                    k.ba(5);
                    break;
                case 3:
                    k.Bd();
                    k.qf(9);
                    if (!d || d.done || !(e = f.return)) {
                        k.ba(9);
                        break
                    }
                    return k.u(e.call(f), 9);
                case 9:
                    k.Bd(0, 0, 1);
                    if (c) throw c.error;
                    k.Nd(10, 1);
                    break;
                case 10:
                    k.Nd(4);
                    break;
                case 2:
                    h = k.sb();
                    c = {
                        error: h
                    };
                    k.ba(3);
                    break;
                case 4:
                    b.complete(), k.Eb()
            }
        })
    };

    function Wc(a, b) {
        return b ? Bc(a, b) : Rc(a)
    };

    function Xc(a) {
        return J(a[a.length - 1]) ? a.pop() : void 0
    }

    function Yc(a) {
        var b = a[a.length - 1];
        return b && J(b.M) ? a.pop() : void 0
    };

    function Zc() {
        var a = E.apply(0, arguments),
            b = Yc(a);
        return b ? Bc(a, b) : Wc(a)
    };

    function $c(a) {
        var b = J(a) ? a : function() {
            return a
        };
        return new L(function(c) {
            return c.error(b())
        })
    };
    var ad = {
        now: function() {
            return (ad.Qh || Date).now()
        },
        Qh: void 0
    };
    var bd = function(a, b, c) {
        a = a === void 0 ? Infinity : a;
        b = b === void 0 ? Infinity : b;
        c = c === void 0 ? ad : c;
        xc.call(this);
        this.bufferSize = a;
        this.oh = b;
        this.hh = c;
        this.buffer = [];
        this.Pe = b === Infinity;
        this.bufferSize = Math.max(1, a);
        this.oh = Math.max(1, b)
    };
    q(bd, xc);
    bd.create = xc.create;
    bd.prototype.next = function(a) {
        var b = this.buffer,
            c = this.Pe,
            d = this.hh,
            e = this.oh;
        this.U || (b.push(a), !c && b.push(d.now() + e));
        cd(this);
        xc.prototype.next.call(this, a)
    };
    bd.prototype.La = function(a) {
        this.kb();
        cd(this);
        for (var b = this.Nf(a), c = this.Pe, d = this.buffer.slice(), e = 0; e < d.length && !a.closed; e += c ? 1 : 2) a.next(d[e]);
        this.Kf(a);
        return b
    };
    var cd = function(a) {
        var b = a.bufferSize,
            c = a.hh,
            d = a.buffer;
        a = a.Pe;
        var e = (a ? 1 : 2) * b;
        b < Infinity && e < d.length && d.splice(0, d.length - e);
        if (!a) {
            b = c.now();
            c = 0;
            for (a = 1; a < d.length && d[a] <= b; a += 2) c = a;
            c && d.splice(0, c + 1)
        }
    };
    var ed = function(a, b) {
        b = b === void 0 ? dd : b;
        this.pj = a;
        this.now = b
    };
    ed.prototype.M = function(a, b, c) {
        b = b === void 0 ? 0 : b;
        return (new this.pj(this, a)).M(c, b)
    };
    var dd = ad.now;
    var fd = function() {
        var a = Error.call(this, "no elements in sequence");
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "EmptyError"
    };
    q(fd, Error);

    function gd(a) {
        return new Promise(function(b, c) {
            var d = new rc({
                next: function(e) {
                    b(e);
                    d.unsubscribe()
                },
                error: c,
                complete: function() {
                    c(new fd)
                }
            });
            a.subscribe(d)
        })
    };
    var M = function(a, b, c, d, e) {
        oc.call(this, a);
        this.Wi = e;
        b && (this.ie = function(f) {
            try {
                b(f)
            } catch (g) {
                this.destination.error(g)
            }
        });
        c && (this.Lf = function(f) {
            try {
                c(f)
            } catch (g) {
                this.destination.error(g)
            }
            this.unsubscribe()
        });
        d && (this.nd = function() {
            try {
                d()
            } catch (f) {
                this.destination.error(f)
            }
            this.unsubscribe()
        })
    };
    q(M, oc);
    M.EMPTY = oc.EMPTY;
    M.create = oc.create;
    M.prototype.unsubscribe = function() {
        var a;
        this.closed || (a = this.Wi) != null && a.call(this);
        oc.prototype.unsubscribe.call(this)
    };

    function hd(a) {
        return function(b) {
            if (J(b == null ? void 0 : b.Gb)) return b.Gb(function(c) {
                try {
                    return a(c, this)
                } catch (d) {
                    this.error(d)
                }
            });
            throw new TypeError("v");
        }
    };

    function id() {
        return hd(function(a, b) {
            var c = null;
            a.od++;
            var d = new M(b, void 0, void 0, void 0, function() {
                if (!a || a.od <= 0 || 0 < --a.od) c = null;
                else {
                    var e = a.Ub,
                        f = c;
                    c = null;
                    !e || f && e !== f || e.unsubscribe();
                    b.unsubscribe()
                }
            });
            a.subscribe(d);
            d.closed || (c = a.connect())
        })
    };
    var jd = function(a, b) {
        this.source = a;
        this.bh = b;
        this.pd = null;
        this.od = 0;
        this.Ub = null
    };
    q(jd, L);
    jd.create = L.create;
    jd.prototype.La = function(a) {
        return kd(this).subscribe(a)
    };
    var kd = function(a) {
        var b = a.pd;
        if (!b || b.U) a.pd = a.bh();
        return a.pd
    };
    jd.prototype.je = function() {
        this.od = 0;
        var a = this.Ub;
        this.pd = this.Ub = null;
        a == null || a.unsubscribe()
    };
    jd.prototype.connect = function() {
        var a = this,
            b = this.Ub;
        if (!b) {
            b = this.Ub = new ic;
            var c = kd(this);
            b.add(this.source.subscribe(new M(c, void 0, function(d) {
                a.je();
                c.error(d)
            }, function() {
                a.je();
                c.complete()
            }, function() {
                return a.je()
            })));
            b.closed && (this.Ub = null, b = ic.EMPTY)
        }
        return b
    };

    function ld() {
        var a = md;
        var b = b === void 0 ? 0 : b;
        return hd(function(c, d) {
            d.add(a.M(function() {
                return c.subscribe(d)
            }, b))
        })
    };

    function N(a) {
        return hd(function(b, c) {
            var d = 0;
            b.subscribe(new M(c, function(e) {
                c.next(a.call(void 0, e, d++))
            }))
        })
    };
    var nd = Array.isArray;

    function od(a) {
        return N(function(b) {
            return nd(b) ? a.apply(null, y(b)) : a(b)
        })
    };
    var pd = Array.isArray,
        qd = Object,
        rd = qd.getPrototypeOf,
        sd = qd.prototype,
        td = qd.keys;

    function ud(a) {
        if (a.length === 1) {
            var b = a[0];
            if (pd(b)) return {
                args: b,
                keys: null
            };
            if (b && typeof b === "object" && rd(b) === sd) return a = td(b), {
                args: a.map(function(c) {
                    return b[c]
                }),
                keys: a
            }
        }
        return {
            args: a,
            keys: null
        }
    };

    function vd() {
        var a = E.apply(0, arguments),
            b = Yc(a),
            c = Xc(a);
        a = ud(a);
        var d = a.args,
            e = a.keys;
        if (d.length === 0) return Mc([], b);
        b = new L(wd(d, b, e ? function(f) {
            for (var g = {}, h = 0; h < f.length; h++) g[e[h]] = f[h];
            return g
        } : tc));
        return c ? b.g(od(c)) : b
    }
    var xd = function(a, b, c) {
        oc.call(this, a);
        this.ie = b;
        this.uj = c
    };
    q(xd, oc);
    xd.EMPTY = oc.EMPTY;
    xd.create = oc.create;
    xd.prototype.nd = function() {
        this.uj() ? oc.prototype.nd.call(this) : this.unsubscribe()
    };

    function wd(a, b, c) {
        c = c === void 0 ? tc : c;
        return function(d) {
            zd(b, function() {
                for (var e = a.length, f = Array(e), g = e, h = a.map(function() {
                        return !1
                    }), k = !0, l = {
                        zb: 0
                    }; l.zb < e; l = {
                        zb: l.zb
                    }, l.zb++) zd(b, function(m) {
                    return function() {
                        Mc(a[m.zb], b).subscribe(new xd(d, function(u) {
                            f[m.zb] = u;
                            k && (h[m.zb] = !0, k = !h.every(tc));
                            k || d.next(c(f.slice()))
                        }, function() {
                            return --g === 0
                        }))
                    }
                }(l), d)
            }, d)
        }
    }

    function zd(a, b, c) {
        a ? c.add(a.M(b)) : b()
    };

    function Ad(a, b, c, d) {
        var e = [],
            f = 0,
            g = 0,
            h = !1,
            k = function(l) {
                f++;
                Nc(c(l, g++)).subscribe(new M(b, function(m) {
                    b.next(m)
                }, void 0, function() {
                    f--;
                    for (var m = {}; e.length && f < d; m = {
                            Uf: void 0
                        }) m.Uf = e.shift(), k(m.Uf);
                    !h || e.length || f || b.complete()
                }))
            };
        a.subscribe(new M(b, function(l) {
            return f < d ? k(l) : e.push(l)
        }, void 0, function() {
            h = !0;
            !h || e.length || f || b.complete()
        }));
        return function() {
            e = null
        }
    };

    function Bd(a, b) {
        var c = c === void 0 ? Infinity : c;
        if (J(b)) return Bd(function(d, e) {
            return N(function(f, g) {
                return b(d, f, e, g)
            })(Nc(a(d, e)))
        }, c);
        typeof b === "number" && (c = b);
        return hd(function(d, e) {
            return Ad(d, e, a, c)
        })
    };

    function Cd(a) {
        a = a === void 0 ? Infinity : a;
        return Bd(tc, a)
    };

    function Dd() {
        var a = E.apply(0, arguments);
        return Cd(1)(Wc(a, Yc(a)))
    };

    function Ed(a) {
        return new L(function(b) {
            Nc(a()).subscribe(b)
        })
    };
    var Fd = ["addListener", "removeListener"],
        Gd = ["addEventListener", "removeEventListener"],
        Hd = ["on", "off"];

    function Id(a, b, c) {
        if (J(c)) {
            var d = c;
            c = void 0
        }
        if (d) return Id(a, b, c).g(od(d));
        d = x(J(a.addEventListener) && J(a.removeEventListener) ? Gd.map(function(g) {
            return function(h) {
                return a[g](b, h, c)
            }
        }) : J(a.addListener) && J(a.removeListener) ? Fd.map(Jd(a, b)) : J(a.Nk) && J(a.Ak) ? Hd.map(Jd(a, b)) : []);
        var e = d.next().value,
            f = d.next().value;
        return !e && Ic(a) ? Bd(function(g) {
            return Id(g, b, c)
        })(Wc(a)) : new L(function(g) {
            if (!e) throw new TypeError("w");
            var h = function() {
                var k = E.apply(0, arguments);
                return g.next(1 < k.length ? k : k[0])
            };
            e(h);
            return function() {
                return f(h)
            }
        })
    }

    function Jd(a, b) {
        return function(c) {
            return function(d) {
                return a[c](b, d)
            }
        }
    };
    var Kd = function() {
        ic.call(this)
    };
    q(Kd, ic);
    Kd.EMPTY = ic.EMPTY;
    Kd.prototype.M = function() {
        return this
    };
    var Ld = function(a, b) {
        return setInterval.apply(null, [a, b].concat(y(E.apply(2, arguments))))
    };
    var Md = function(a, b) {
        ic.call(this);
        this.scheduler = a;
        this.Ef = b;
        this.pending = !1
    };
    q(Md, Kd);
    Md.EMPTY = Kd.EMPTY;
    Md.prototype.M = function(a, b) {
        b = b === void 0 ? 0 : b;
        if (this.closed) return this;
        this.state = a;
        a = this.id;
        var c = this.scheduler;
        a != null && (this.id = Nd(this, a, b));
        this.pending = !0;
        this.delay = b;
        this.id = this.id || this.lf(c, this.id, b);
        return this
    };
    Md.prototype.lf = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        return Ld(a.flush.bind(a, this), c)
    };
    var Nd = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        if (c != null && a.delay === c && a.pending === !1) return b;
        clearInterval(b)
    };
    Md.prototype.execute = function(a, b) {
        if (this.closed) return Error("x");
        this.pending = !1;
        if (a = this.Mf(a, b)) return a;
        this.pending === !1 && this.id != null && (this.id = Nd(this, this.id, null))
    };
    Md.prototype.Mf = function(a) {
        var b = !1;
        try {
            this.Ef(a)
        } catch (d) {
            b = !0;
            var c = !!d && d || Error(d)
        }
        if (b) return this.unsubscribe(), c
    };
    Md.prototype.unsubscribe = function() {
        if (!this.closed) {
            var a = this.id,
                b = this.scheduler.actions;
            this.Ef = this.state = this.scheduler = null;
            this.pending = !1;
            hc(b, this);
            a != null && (this.id = Nd(this, a, null));
            this.delay = null;
            Kd.prototype.unsubscribe.call(this)
        }
    };
    var Od = function(a, b) {
        b = b === void 0 ? dd : b;
        ed.call(this, a, b);
        this.actions = [];
        this.active = !1
    };
    q(Od, ed);
    Od.prototype.flush = function(a) {
        var b = this.actions;
        if (this.active) b.push(a);
        else {
            var c;
            this.active = !0;
            do
                if (c = a.execute(a.state, a.delay)) break; while (a = b.shift());
            this.active = !1;
            if (c) {
                for (; a = b.shift();) a.unsubscribe();
                throw c;
            }
        }
    };

    function Pd() {
        var a = E.apply(0, arguments),
            b = Yc(a);
        var c = typeof a[a.length - 1] === "number" ? a.pop() : Infinity;
        return a.length ? a.length === 1 ? Nc(a[0]) : Cd(c)(Wc(a, b)) : Ac
    };
    var Qd = new L(mc);
    var Rd = Array.isArray;

    function Sd(a) {
        return a.length === 1 && Rd(a[0]) ? a[0] : a
    };

    function Td() {
        var a = Sd(E.apply(0, arguments));
        return hd(function(b, c) {
            var d = [b].concat(y(a)),
                e = function() {
                    if (!c.closed)
                        if (d.length > 0) {
                            try {
                                var f = Nc(d.shift())
                            } catch (h) {
                                e();
                                return
                            }
                            var g = new M(c, void 0, mc, mc);
                            c.add(f.subscribe(g));
                            g.add(e)
                        } else c.complete()
                };
            e()
        })
    };

    function O(a) {
        return hd(function(b, c) {
            var d = 0;
            b.subscribe(new M(c, function(e) {
                return a.call(void 0, e, d++) && c.next(e)
            }))
        })
    };

    function Ud() {
        var a = E.apply(0, arguments);
        a = Sd(a);
        return a.length === 1 ? Nc(a[0]) : new L(Vd(a))
    }

    function Vd(a) {
        return function(b) {
            for (var c = [], d = {
                    Zb: 0
                }; c && !b.closed && d.Zb < a.length; d = {
                    Zb: d.Zb
                }, d.Zb++) c.push(Nc(a[d.Zb]).subscribe(new M(b, function(e) {
                return function(f) {
                    if (c) {
                        for (var g = 0; g < c.length; g++) g !== e.Zb && c[g].unsubscribe();
                        c = null
                    }
                    b.next(f)
                }
            }(d))))
        }
    };

    function Wd() {
        var a = E.apply(0, arguments),
            b = Xc(a),
            c = Sd(a);
        return c.length ? new L(function(d) {
            var e = c.map(function() {
                    return []
                }),
                f = c.map(function() {
                    return !1
                });
            d.add(function() {
                e = f = null
            });
            for (var g = {
                    ib: 0
                }; !d.closed && g.ib < c.length; g = {
                    ib: g.ib
                }, g.ib++) Nc(c[g.ib]).subscribe(new M(d, function(h) {
                    return function(k) {
                        e[h.ib].push(k);
                        e.every(function(l) {
                            return l.length
                        }) && (k = e.map(function(l) {
                            return l.shift()
                        }), d.next(b ? b.apply(null, y(k)) : k), e.some(function(l, m) {
                            return !l.length && f[m]
                        }) && d.complete())
                    }
                }(g), void 0,
                function(h) {
                    return function() {
                        f[h.ib] = !0;
                        !e[h.ib].length && d.complete()
                    }
                }(g)));
            return function() {
                e = f = null
            }
        }) : Ac
    };
    var Xd = function(a, b) {
        Md.call(this, a, b);
        this.scheduler = a;
        this.Ef = b
    };
    q(Xd, Md);
    Xd.EMPTY = Md.EMPTY;
    Xd.prototype.M = function(a, b) {
        b = b === void 0 ? 0 : b;
        if (b > 0) return Md.prototype.M.call(this, a, b);
        this.delay = b;
        this.state = a;
        this.scheduler.flush(this);
        return this
    };
    Xd.prototype.execute = function(a, b) {
        return b > 0 || this.closed ? Md.prototype.execute.call(this, a, b) : this.Mf(a, b)
    };
    Xd.prototype.lf = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        return c != null && c > 0 || c == null && this.delay > 0 ? Md.prototype.lf.call(this, a, b, c) : a.flush(this)
    };
    var Yd = function() {
        Od.apply(this, arguments)
    };
    q(Yd, Od);
    var md = new Yd(Xd);
    var Zd = function() {
        this.L = new Oa;
        this.i = new Pa;
        this.si = Symbol();
        this.Ic = new ec
    };
    Zd.prototype.Ie = function() {
        return Qd
    };
    var $d = function(a, b) {
            a.Na !== null && a.Na.next(b)
        },
        ae = function(a) {
            if ((typeof a === "bigint" || typeof a === "number" || typeof a === "string") && typeof BigInt === "function") return BigInt(a)
        };
    da.Object.defineProperties(Zd.prototype, {
        Pb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.si
            }
        }
    });
    var be = function(a, b) {
        b = Error.call(this, b ? a + ": " + b : String(a));
        this.message = b.message;
        "stack" in b && (this.stack = b.stack);
        this.code = a;
        this.__proto__ = be.prototype;
        this.name = String(a)
    };
    q(be, Error);
    var ce = function(a) {
        be.call(this, 1E3, 'sfr:"' + a + '"');
        this.Ji = a;
        this.__proto__ = ce.prototype
    };
    q(ce, be);
    var de = function() {
        be.call(this, 1003);
        this.__proto__ = de.prototype
    };
    q(de, be);
    var ee = function() {
        be.call(this, 1009);
        this.__proto__ = ee.prototype
    };
    q(ee, be);
    var fe = function() {
        be.call(this, 1011);
        this.__proto__ = fe.prototype
    };
    q(fe, be);
    var ge = function() {
        be.call(this, 1007);
        this.__proto__ = de.prototype
    };
    q(ge, be);
    var he = function() {
        be.call(this, 1008);
        this.__proto__ = de.prototype
    };
    q(he, be);
    var ie = function() {
        be.call(this, 1001);
        this.__proto__ = ie.prototype
    };
    q(ie, be);
    var je = function(a) {
        be.call(this, 1004, String(a));
        this.ni = a;
        this.__proto__ = je.prototype
    };
    q(je, be);
    var le = function(a) {
        be.call(this, 1010, a);
        this.__proto__ = ke.prototype
    };
    q(le, be);
    var ke = function(a) {
        be.call(this, 1005, a);
        this.__proto__ = ke.prototype
    };
    q(ke, be);
    var me = function(a) {
        var b = E.apply(1, arguments),
            c = this;
        this.oc = [];
        this.oc.push(a);
        b.forEach(function(d) {
            c.oc.push(d)
        })
    };
    me.prototype.P = function(a) {
        return this.oc.some(function(b) {
            return b.P(a)
        })
    };
    me.prototype.K = function(a, b) {
        for (var c = 0; c < this.oc.length; c++)
            if (this.oc[c].P(b)) return this.oc[c].K(a, b);
        throw new ee;
    };

    function ne(a) {
        var b, c, d;
        return !!a && typeof a.active === "boolean" && typeof((b = a.clock) == null ? void 0 : b.now) === "function" && ((c = a.clock) == null ? void 0 : c.timeline) !== void 0 && !((d = a.H) == null || !d.timestamp) && typeof a.ea === "function" && typeof a.fa === "function" && typeof a.Aa === "function" && typeof a.map === "function" && typeof a.Ca === "function"
    };
    var oe = Symbol("time-origin"),
        pe = Symbol("date"),
        qe = function(a, b) {
            this.value = a;
            this.timeline = b
        },
        re = function(a, b) {
            if (b.timeline !== a.timeline) throw new ge;
        },
        se = function(a, b) {
            re(a, b);
            return a.value - b.value
        };
    n = qe.prototype;
    n.equals = function(a) {
        return se(this, a) === 0
    };
    n.maximum = function(a) {
        re(this, a);
        return this.value >= a.value ? this : a
    };
    n.round = function() {
        return new qe(Math.round(this.value), this.timeline)
    };
    n.add = function(a) {
        return new qe(this.value + a, this.timeline)
    };
    n.toString = function() {
        return String(this.value)
    };

    function te(a) {
        function b(c) {
            return typeof c === "boolean" || typeof c === "string" || typeof c === "number" || c === void 0 || c === null
        }
        return b(a) ? !0 : Array.isArray(a) ? a.every(b) : typeof a === "object" ? Object.keys(a).every(function(c) {
            return typeof c === "string"
        }) && Object.values(a).every(function(c) {
            return Array.isArray(c) ? c.every(b) : b(c)
        }) : !1
    }

    function ue(a) {
        if (te(a)) return a;
        if (ne(a)) return {
            H: {
                value: ue(a.H.value),
                timestamp: se(a.H.timestamp, new qe(0, a.H.timestamp.timeline))
            },
            active: a.active
        };
        try {
            return JSON.parse(JSON.stringify(a))
        } catch (b) {}
        return String(a)
    };
    var ve = {
        Mj: "app",
        lk: "web"
    };
    var we = ["sessionStart", "sessionError", "sessionFinish"],
        xe = function(a, b) {
            this.na = a;
            this.de = b;
            this.ready = !1;
            this.Hb = [];
            this.Ug = function() {};
            this.mh = function() {};
            this.jg = function() {};
            this.ug = function() {};
            this.Ud = function() {}
        },
        ye = function(a, b) {
            a.Ug = b
        },
        ze = function(a, b) {
            a.mh = b
        },
        Ae = function(a, b) {
            a.jg = b
        },
        Be = function(a, b) {
            a.ug = b
        },
        Ce = function(a, b) {
            a.Ud = b;
            a.Ud(a.Hb.length)
        },
        He = function(a) {
            for (var b = x("geometryChange impression loaded start firstQuartile midpoint thirdQuartile complete pause resume bufferStart bufferFinish skipped volumeChange playerStateChange adUserInteraction".split(" ")),
                    c = b.next(); !c.done; c = b.next()) a.na.addEventListener(c.value, function(d) {
                De(a, d)
            });
            Ee(a.na, function(d) {
                d.type !== "sessionStart" && De(a, d)
            }, a.de);
            Ee(a.na, function(d) {
                d.type === "sessionStart" && (De(a, d), Fe(a), Ge(a))
            }, a.de)
        },
        De = function(a, b) {
            a.Hb.push(b);
            a.Ud(a.Hb.length);
            Ge(a)
        },
        Ge = function(a) {
            if (a.ready)
                for (; a.Hb.length > 0;) {
                    var b = a.Hb.pop();
                    b !== void 0 && (b.type === "geometryChange" ? a.jg(b) : b.type === "impression" ? a.ug(b) : we.includes(b.type) ? a.Ug(b) : a.mh(b));
                    a.Ud(a.Hb.length)
                }
        },
        Fe = function(a) {
            a.ready || (a.ready = !0, a.Hb.sort(function(b, c) {
                return c.timestamp - b.timestamp
            }))
        };

    function Ie(a) {
        return hd(function(b, c) {
            var d = null,
                e = !1,
                f;
            d = b.subscribe(new M(c, void 0, function(g) {
                f = Nc(a(g, Ie(a)(b)));
                d ? (d.unsubscribe(), d = null, f.subscribe(c)) : e = !0
            }));
            e && (d.unsubscribe(), d = null, f.subscribe(c))
        })
    };

    function Je(a, b, c) {
        return function(d, e) {
            var f = c,
                g = b,
                h = 0;
            d.subscribe(new M(e, function(k) {
                var l = h++;
                g = f ? a(g, k, l) : (f = !0, k);
                e.next(g)
            }, void 0, void 0))
        }
    };

    function Ke() {
        var a = E.apply(0, arguments),
            b = Xc(a);
        return b ? K(Ke.apply(null, y(a)), od(b)) : hd(function(c, d) {
            wd([c].concat(y(Sd(a))))(d)
        })
    }

    function Ne() {
        return Ke.apply(null, y(E.apply(0, arguments)))
    };

    function Oe(a) {
        a = a === void 0 ? null : a;
        return hd(function(b, c) {
            var d = !1;
            b.subscribe(new M(c, function(e) {
                d = !0;
                c.next(e)
            }, void 0, function() {
                d || c.next(a);
                c.complete()
            }))
        })
    };

    function Pe() {
        return hd(function(a, b) {
            a.subscribe(new M(b, mc))
        })
    };

    function Qe(a) {
        return hd(function(b, c) {
            b.subscribe(new M(c, function() {
                return c.next(a)
            }))
        })
    };

    function Re(a) {
        return a <= 0 ? function() {
            return Ac
        } : hd(function(b, c) {
            var d = 0;
            b.subscribe(new M(c, function(e) {
                ++d <= a && (c.next(e), a <= d && c.complete())
            }))
        })
    };

    function Se(a) {
        return Bd(function(b, c) {
            return a(b, c).g(Re(1), Qe(b))
        })
    };

    function Te(a) {
        return hd(function(b, c) {
            var d = new Set;
            b.subscribe(new M(c, function(e) {
                var f = a ? a(e) : e;
                d.has(f) || (d.add(f), c.next(e))
            }))
        })
    };

    function P(a) {
        var b = b === void 0 ? tc : b;
        var c;
        a = (c = a) != null ? c : Ue;
        return hd(function(d, e) {
            var f, g = !0;
            d.subscribe(new M(e, function(h) {
                var k = b(h);
                if (g || !a(f, k)) g = !1, f = k, e.next(h)
            }))
        })
    }

    function Ue(a, b) {
        return a === b
    };

    function Ve(a) {
        a = a === void 0 ? We : a;
        return hd(function(b, c) {
            var d = !1;
            b.subscribe(new M(c, function(e) {
                d = !0;
                c.next(e)
            }, void 0, function() {
                return d ? c.complete() : c.error(a())
            }))
        })
    }

    function We() {
        return new fd
    };

    function Xe() {
        var a = E.apply(0, arguments);
        return function(b) {
            return Dd(b, Zc.apply(null, y(a)))
        }
    };

    function Ye(a) {
        return hd(function(b, c) {
            var d = 0;
            b.subscribe(new M(c, function(e) {
                a.call(void 0, e, d++, b) || (c.next(!1), c.complete())
            }, void 0, function() {
                c.next(!0);
                c.complete()
            }))
        })
    };

    function Ze() {
        return hd(function(a, b) {
            var c = [];
            a.subscribe(new M(b, function(d) {
                c.push(d);
                1 < c.length && c.shift()
            }, void 0, function() {
                for (var d = x(c), e = d.next(); !e.done; e = d.next()) b.next(e.value);
                b.complete()
            }, function() {
                c = null
            }))
        })
    };

    function $e(a, b) {
        var c = arguments.length >= 2;
        return function(d) {
            return d.g(a ? O(function(e, f) {
                return a(e, f, d)
            }) : tc, Ze(), c ? Oe(b) : Ve(function() {
                return new fd
            }))
        }
    };

    function af(a) {
        var b = J(a) ? a : function() {
            return a
        };
        return J() ? hd(function(c, d) {
            var e = b();
            (void 0)(e).subscribe(d).add(c.subscribe(e))
        }) : function(c) {
            var d = new jd(c, b);
            J(c == null ? void 0 : c.Gb) && (d.Gb = c.Gb);
            d.source = c;
            d.bh = b;
            return d
        }
    };

    function bf() {
        return hd(function(a, b) {
            var c, d = !1;
            a.subscribe(new M(b, function(e) {
                var f = c;
                c = e;
                d && b.next([f, e]);
                d = !0
            }))
        })
    };

    function cf(a) {
        var b = new bd(a, void 0, void 0);
        return function(c) {
            return af(function() {
                return b
            })(c)
        }
    };

    function df() {
        var a = a === void 0 ? Infinity : a;
        return a <= 0 ? function() {
            return Ac
        } : hd(function(b, c) {
            var d = 0,
                e, f = function() {
                    var g = !1;
                    e = b.subscribe(new M(c, void 0, void 0, function() {
                        ++d < a ? e ? (e.unsubscribe(), e = null, f()) : g = !0 : c.complete()
                    }));
                    g && (e.unsubscribe(), e = null, f())
                };
            f()
        })
    };

    function ef(a, b) {
        return hd(Je(a, b, arguments.length >= 2))
    };

    function ff() {
        var a = a || {};
        var b = a.Jh === void 0 ? function() {
                return new xc
            } : a.Jh,
            c = a.ij === void 0 ? !0 : a.ij,
            d = a.jj === void 0 ? !0 : a.jj,
            e = a.kj === void 0 ? !0 : a.kj;
        return function(f) {
            var g = null,
                h = null,
                k = 0,
                l = !1,
                m = !1,
                u = function() {
                    g = h = null;
                    l = m = !1
                };
            return hd(function(t, r) {
                k++;
                var w;
                h = (w = h) != null ? w : b();
                r.add(function() {
                    k--;
                    if (e && !k && !m && !l) {
                        var v = g;
                        u();
                        v == null || v.unsubscribe()
                    }
                });
                h.subscribe(r);
                !g && k > 0 && (g = new rc({
                    next: function(v) {
                        return h.next(v)
                    },
                    error: function(v) {
                        m = !0;
                        var z = h;
                        d && u();
                        z.error(v)
                    },
                    complete: function() {
                        l = !0;
                        var v = h;
                        c && u();
                        v.complete()
                    }
                }), Mc(t).subscribe(g))
            })(f)
        }
    };

    function gf(a) {
        return hd(function(b, c) {
            var d = !1,
                e = 0;
            b.subscribe(new M(c, function(f) {
                return (d || (d = !a(f, e++))) && c.next(f)
            }))
        })
    };

    function R() {
        var a = E.apply(0, arguments),
            b = Yc(a);
        return hd(function(c, d) {
            (b ? Dd(a, c, b) : Dd(a, c)).subscribe(d)
        })
    };

    function S(a) {
        return hd(function(b, c) {
            var d = null,
                e = 0,
                f = !1;
            b.subscribe(new M(c, function(g) {
                var h;
                (h = d) == null || h.unsubscribe();
                h = e++;
                Nc(a(g, h)).subscribe(d = new M(c, function(k) {
                    return c.next(k)
                }, void 0, function() {
                    d = null;
                    f && !d && c.complete()
                }))
            }, void 0, function() {
                (f = !0, !d) && c.complete()
            }))
        })
    };

    function hf(a, b) {
        b = b === void 0 ? !1 : b;
        return hd(function(c, d) {
            var e = 0;
            c.subscribe(new M(d, function(f) {
                var g = a(f, e++);
                (g || b) && d.next(f);
                !g && d.complete()
            }))
        })
    };

    function jf(a, b, c) {
        var d = J(a) || b || c ? {
            next: a,
            error: b,
            complete: c
        } : a;
        return d ? hd(function(e, f) {
            e.subscribe(new M(f, function(g) {
                var h;
                (h = d.next) == null || h.call(d, g);
                f.next(g)
            }, function(g) {
                var h;
                (h = d.error) == null || h.call(d, g);
                f.error(g)
            }, function() {
                var g;
                (g = d.complete) == null || g.call(d);
                f.complete()
            }))
        }) : tc
    };

    function kf() {
        var a = E.apply(0, arguments),
            b = Xc(a);
        return hd(function(c, d) {
            for (var e = a.length, f = Array(e), g = a.map(function() {
                    return !1
                }), h = !1, k = {
                    bb: 0
                }; k.bb < e; k = {
                    bb: k.bb
                }, k.bb++) Nc(a[k.bb]).subscribe(new M(d, function(l) {
                return function(m) {
                    f[l.bb] = m;
                    h || g[l.bb] || (g[l.bb] = !0, (h = g.every(tc)) && (g = null))
                }
            }(k), void 0, mc));
            c.subscribe(new M(d, function(l) {
                h && (l = [l].concat(y(f)), d.next(b ? b.apply(null, y(l)) : l))
            }))
        })
    };
    var lf = function(a) {
        this.na = a
    };
    lf.prototype.P = function(a) {
        return (a == null ? 0 : a.Bc) ? !0 : (a == null ? void 0 : a.ia) === "POST" || (a == null ? 0 : a.rb) || (a == null ? 0 : a.zd) ? !1 : this.na.P()
    };
    lf.prototype.ping = function() {
        var a = this,
            b = Zc.apply(null, y(E.apply(0, arguments))).g(Bd(function(c) {
                return mf(a, c)
            }), Ye(function(c) {
                return c
            }), cf(1));
        b.connect();
        return b
    };
    var mf = function(a, b) {
        var c = new bd(1);
        nf(a.na, b, function() {
            c.next(!0);
            c.complete()
        }, function() {
            c.next(!1);
            c.complete()
        });
        return c
    };
    lf.prototype.Sd = function(a, b, c) {
        this.ping.apply(this, y(E.apply(3, arguments)))
    };

    function of (a, b) {
        var c = !1;
        return new L(function(d) {
            var e = a.setTimeout(function() {
                c = !0;
                d.next(!0);
                d.complete()
            }, b);
            return function() {
                c || a.clearTimeout(e)
            }
        })
    };
    var pf = function(a) {
        this.na = a;
        this.timeline = pe
    };
    n = pf.prototype;
    n.setTimeout = function(a, b) {
        return Number(this.na.setTimeout(function() {
            return a()
        }, b))
    };
    n.clearTimeout = function(a) {
        this.na.clearTimeout(a)
    };
    n.now = function() {
        return new qe(Date.now(), this.timeline)
    };
    n.interval = function(a, b) {
        var c = this.Ga(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ga = function(a) {
        return of(this, a).g(df(), ef(function(b) {
            return b + 1
        }, -1))
    };
    n.pa = function() {
        return !0
    };
    var qf = function(a, b) {
        this.context = a;
        this.qc = b
    };
    qf.prototype.P = function(a) {
        return this.qc.P(a)
    };
    qf.prototype.K = function(a, b) {
        if (!this.P(b)) throw new ee;
        return new rf(this.context, this.qc, b != null ? b : void 0, a)
    };
    var rf = function(a, b, c, d) {
        var e = this;
        this.qc = b;
        this.properties = c;
        this.url = d;
        this.Jd = !0;
        this.rb = new Map;
        this.body = void 0;
        var f;
        this.method = (f = c == null ? void 0 : c.ia) != null ? f : "GET";
        this.Dh = a.Ie().subscribe(function() {
            e.sendNow()
        })
    };
    rf.prototype.deactivate = function() {
        this.Jd = !1
    };
    rf.prototype.sendNow = function() {
        if (this.Jd)
            if (this.Dh.unsubscribe(), this.qc.P(this.properties)) try {
                if (this.rb.size > 0 || this.body !== void 0) {
                    var a, b;
                    this.qc.Sd((a = this.properties) != null ? a : {}, this.rb, (b = this.body) != null ? b : "", this.url)
                } else this.qc.ping(this.url);
                this.Jd = !1
            } catch (c) {} else this.Jd = !1
    };
    var tf = function(a, b, c, d, e, f) {
            this.mode = a;
            this.l = b;
            this.setTime = c;
            this.dd = d;
            this.Aj = e;
            this.Ih = f;
            this.completed = !1;
            this.id = this.mode === 0 ? sf(this) : 0
        },
        sf = function(a) {
            return a.l.setTimeout(function() {
                uf(a)
            }, a.dd)
        },
        vf = function(a, b) {
            var c = se(b, a.setTime);
            c >= a.dd ? uf(a) : (a.setTime = b, a.dd -= c)
        },
        uf = function(a) {
            try {
                a.Aj(a.setTime.add(a.dd))
            } finally {
                a.completed = !0, a.Ih()
            }
        };
    tf.prototype.Bf = function(a, b) {
        this.completed || (this.mode === 1 && a === 1 ? vf(this, b) : this.mode === 1 && a === 0 ? (this.mode = a, vf(this, this.l.now()), this.completed || (this.id = sf(this))) : this.mode === 0 && a === 1 && (this.mode = a, this.clear(), vf(this, b)))
    };
    tf.prototype.clear = function() {
        this.completed || this.l.clearTimeout(this.id)
    };
    var wf = function(a) {
        this.Ad = a;
        this.pi = this.mode = 0;
        this.fc = {};
        this.timeline = a.timeline;
        this.Fb = a.now()
    };
    n = wf.prototype;
    n.Bf = function(a, b) {
        this.mode = a;
        re(this.Fb, b);
        this.Fb = b;
        Object.values(this.fc).forEach(function(c) {
            return void c.Bf(a, b)
        })
    };
    n.now = function() {
        return this.mode === 1 ? this.Fb : this.Ad.now()
    };
    n.setTimeout = function(a, b) {
        var c = this,
            d = ++this.pi,
            e = this.mode === 1 ? this.Fb : this.Ad.now();
        this.fc[d] = new tf(this.mode, this.Ad, e, b, function(f) {
            var g = c.Fb;
            c.mode === 1 && (c.Fb = f);
            a();
            c.Fb = g
        }, function() {
            delete c.fc[d]
        });
        return d
    };
    n.clearTimeout = function(a) {
        this.fc[a] && (this.fc[a].clear(), delete this.fc[a])
    };
    n.interval = function() {
        throw Error("y");
    };
    n.Ga = function() {
        throw Error("z");
    };
    n.pa = function() {
        return this.Ad.pa()
    };

    function xf(a, b) {
        var c = new wf(a);
        a = b.subscribe(function(d) {
            c.Bf(d.value ? 1 : 0, d.timestamp)
        });
        return {
            l: c,
            zk: a
        }
    };

    function yf(a) {
        var b = Object.assign({}, a);
        delete b.timestamp;
        return {
            timestamp: new qe(a.timestamp, pe),
            value: b
        }
    };

    function zf(a) {
        return a !== void 0 && typeof a.x === "number" && typeof a.y === "number" && typeof a.width === "number" && typeof a.height === "number"
    };
    "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT".split(" ").concat(["BUTTON",
        "INPUT"
    ]);

    function Af(a) {
        var b = E.apply(1, arguments),
            c = b.length;
        if (!Array.isArray(a) || !Array.isArray(a.raw) || a.length !== a.raw.length || !ob && a === a.raw || !(ob && !pb || mb(a)) || c + 1 !== a.length) throw new TypeError("q");
        if (b.length === 0) return cb(a[0]);
        c = a[0].toLowerCase();
        if (/^data:/.test(c)) throw Error("G");
        if (/^https:\/\//.test(c) || /^\/\//.test(c)) {
            var d = c.indexOf("//") + 2;
            var e = c.indexOf("/", d);
            if (e <= d) throw Error("A");
            d = c.substring(d, e);
            if (!/^[0-9a-z.:-]+$/i.test(d)) throw Error("B");
            if (!/^[^:]*(:[0-9]+)?$/i.test(d)) throw Error("C");
            if (!/(^|\.)[a-z][^.]*$/i.test(d)) throw Error("D");
            d = !0
        } else d = !1;
        if (!d)
            if (/^\//.test(c))
                if (c === "/" || c.length > 1 && c[1] !== "/" && c[1] !== "\\") d = !0;
                else throw Error("F");
        else d = !1;
        if (!(d = d || RegExp("^[^:\\s\\\\/]+/").test(c)))
            if (/^about:blank/.test(c)) {
                if (c !== "about:blank" && !/^about:blank#/.test(c)) throw Error("E");
                d = !0
            } else d = !1;
        if (!d) throw Error("H");
        c = a[0];
        for (d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return cb(c)
    };
    var Bf = ra(["https://www.googleadservices.com/pagead/managed/js/activeview/", "/reach_worklet.html"]),
        Cf = ra(["./reach_worklet.js"]),
        Df = ra(["./reach_worklet.js"]),
        Ef = ra(["./reach_worklet.html"]),
        Ff = ra(["./reach_worklet.js"]),
        Gf = ra(["./reach_worklet.js"]);

    function Hf(a) {
        var b = {};
        return b[0] = Af(Bf, a), b[1] = Af(Cf), b[2] = Af(Df), b
    }
    Af(Ef);
    Af(Ff);
    Af(Gf);
    var Jf = function(a, b, c, d) {
        c = c === void 0 ? null : c;
        d = d === void 0 ? Hf("current") : d;
        Zd.call(this);
        this.na = a;
        this.de = b;
        this.Na = c;
        this.uf = d;
        this.eb = null;
        this.pf = new bd(3);
        this.pf.g(O(function(e) {
            return e.value.type === "sessionStart"
        }));
        this.qj = this.pf.g(O(function(e) {
            return e.value.type === "sessionFinish"
        }));
        this.vg = new bd(1);
        this.Ej = new bd;
        this.kg = new bd(10);
        this.I = new qf(this, new lf(a));
        this.zi = this.na.P();
        this.l = If(this, new pf(this.na))
    };
    q(Jf, Zd);
    var Kf = function(a) {
        a.eb !== null && He(a.eb)
    };
    Jf.prototype.validate = function() {
        return this.zi
    };
    var If = function(a, b) {
        a.eb = new xe(a.na, a.de);
        var c = new bd;
        ye(a.eb, function(f) {
            f = yf(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.pf.next(f)
        });
        Ae(a.eb, function(f) {
            if (f === void 0) var g = !1;
            else {
                g = f.data;
                var h;
                (h = g === void 0) || (h = g.viewport, h = h === void 0 || h !== void 0 && typeof h.width === "number" && typeof h.height === "number");
                h ? (g = g.adView, g = g !== void 0 && typeof g.percentageInView === "number" && (g.geometry === void 0 || zf(g.geometry)) && (g.onScreenGeometry === void 0 || zf(g.onScreenGeometry))) : g = !1
            }
            g ? (f = yf(f), c.next({
                timestamp: f.timestamp,
                value: !0
            }), a.kg.next(f)) : .01 >= Math.random() && (f = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&name=invalid_geo&context=1092&msg=" + JSON.stringify(f), a.I.K(f).sendNow())
        });
        ze(a.eb, function(f) {
            f = yf(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.Ej.next(f)
        });
        Be(a.eb, function(f) {
            f = yf(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.vg.next(f)
        });
        var d = 0;
        Ce(a.eb, function(f) {
            d += f;
            d > 0 && f === 0 && c.next({
                timestamp: a.l.now(),
                value: !1
            })
        });
        var e = c.g(hf(function(f) {
            return f.value
        }, !0));
        return xf(b,
            e).l
    };
    da.Object.defineProperties(Jf.prototype, {
        global: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Lf
            }
        }
    });
    var Lf = {};

    function Mf(a, b) {
        if (!b) throw Error("I`" + a);
        if (typeof b !== "string" && !(b instanceof String)) throw Error("J`" + a);
        if (b.trim() === "") throw Error("K`" + a);
    }

    function Nf(a) {
        if (!a) throw Error("N`functionToExecute");
    }

    function Of(a, b) {
        if (b == null) throw Error("L`" + a);
        if (typeof b !== "number" || isNaN(b)) throw Error("M`" + a);
        if (b < 0) throw Error("O`" + a);
    };

    function Pf() {
        return /\d+\.\d+\.\d+(-.*)?/.test("1.6.5-google_20260406")
    }

    function Qf() {
        for (var a = ["1", "6", "5"], b = ["1", "0", "3"], c = 0; c < 3; c++) {
            var d = parseInt(a[c], 10),
                e = parseInt(b[c], 10);
            if (d > e) break;
            else if (d < e) return !1
        }
        return !0
    };
    var Rf = function(a, b, c, d) {
            this.tg = a;
            this.method = b;
            this.version = c;
            this.args = d
        },
        Sf = function(a) {
            return !!a && a.omid_message_guid !== void 0 && a.omid_message_method !== void 0 && a.omid_message_version !== void 0 && typeof a.omid_message_guid === "string" && typeof a.omid_message_method === "string" && typeof a.omid_message_version === "string" && (a.omid_message_args === void 0 || a.omid_message_args !== void 0)
        },
        Tf = function(a) {
            return new Rf(a.omid_message_guid, a.omid_message_method, a.omid_message_version, a.omid_message_args)
        };
    Rf.prototype.hb = function() {
        var a = {};
        a = (a.omid_message_guid = this.tg, a.omid_message_method = this.method, a.omid_message_version = this.version, a);
        this.args !== void 0 && (a.omid_message_args = this.args);
        return a
    };
    var Uf = function(a) {
        this.to = a
    };
    Uf.prototype.hb = function() {
        return JSON.stringify(void 0)
    };

    function Vf(a, b) {
        try {
            return a.frames && !!a.frames[b]
        } catch (c) {
            return !1
        }
    }
    var Wf = function(a) {
            return ["omid_v1_present", "omid_v1_present_web", "omid_v1_present_app"].some(function(b) {
                return Vf(a, b)
            })
        },
        Xf = function(a) {
            for (var b = x(Object.values(ve)), c = b.next(); !c.done; c = b.next()) {
                c = c.value;
                var d = {};
                d = (d.app = "omid_v1_present_app", d.web = "omid_v1_present_web", d)[c];
                if (Vf(a, d)) return c
            }
            return null
        };

    function Yf(a, b) {
        return a && (a[b] || (a[b] = {}))
    };

    function Zf() {
        return typeof crypto !== "undefined" && typeof crypto.getRandomValues === "function"
    }

    function $f() {
        var a = new Uint8Array(16);
        crypto.getRandomValues(a);
        a[6] = a[6] & 15 | 64;
        a[8] = a[8] & 63 | 128;
        for (var b = [], c = 0; c < 16; c++) b.push(a[c].toString(16).padStart(2, "0"));
        return b[0] + b[1] + b[2] + b[3] + "-" + b[4] + b[5] + "-" + b[6] + b[7] + "-" + b[8] + b[9] + "-" + b[10] + b[11] + b[12] + b[13] + b[14] + b[15]
    }

    function ag() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
            var b = Math.random() * 16 | 0;
            return a === "y" ? (b & 3 | 8).toString(16) : b.toString(16)
        })
    };

    function bg() {
        var a = E.apply(0, arguments);
        cg(function() {
            throw new(Function.prototype.bind.apply(Error, [null, "Could not complete the test successfully - "].concat(y(a))));
        }, function() {
            return console.error.apply(console, y(a))
        })
    }

    function cg(a, b) {
        typeof jasmine !== "undefined" && jasmine ? a() : typeof console !== "undefined" && console && console.error && b()
    };
    var dg = function() {
        if (typeof omidGlobal !== "undefined" && omidGlobal) return omidGlobal;
        if (typeof global !== "undefined" && global) return global;
        if (typeof window !== "undefined" && window) return window;
        if (typeof globalThis !== "undefined" && globalThis) return globalThis;
        var a = Function("return this")();
        if (a) return a;
        throw Error("P");
    }();
    var eg = function(a) {
        this.to = a;
        this.handleExportedMessage = eg.prototype.ei.bind(this)
    };
    q(eg, Uf);
    eg.prototype.sendMessage = function(a, b) {
        b = b === void 0 ? this.to : b;
        if (!b) throw Error("Q");
        b.handleExportedMessage(a.hb(), this)
    };
    eg.prototype.ei = function(a, b) {
        if (Sf(a) && this.onMessage) this.onMessage(Tf(a), b)
    };

    function fg(a) {
        return a != null && typeof a.top !== "undefined" && a.top != null
    }

    function gg(a) {
        if (a === dg) return !1;
        try {
            if (typeof a.location.hostname === "undefined") return !0
        } catch (b) {
            return !0
        }
        return !1
    }

    function hg() {
        var a;
        typeof a === "undefined" && typeof window !== "undefined" && window && (a = window);
        return fg(a) ? a : dg
    };
    var ig = function(a, b) {
        this.to = b = b === void 0 ? dg : b;
        var c = this;
        a.addEventListener("message", function(d) {
            if (typeof d.data === "object") {
                var e = d.data;
                if (Sf(e) && d.source && c.onMessage) c.onMessage(Tf(e), d.source)
            }
        })
    };
    q(ig, Uf);
    ig.prototype.sendMessage = function(a, b) {
        b = b === void 0 ? this.to : b;
        if (!b) throw Error("Q");
        b.postMessage(a.hb(), "*")
    };
    var jg = ["omid", "v1_VerificationServiceCommunication"],
        kg = ["omidVerificationProperties", "serviceWindow"];

    function lg(a, b) {
        return b.reduce(function(c, d) {
            return c && c[d]
        }, a)
    };
    var mg = function(a) {
        if (!a) {
            a = hg();
            var b = b === void 0 ? Wf : b;
            var c = [],
                d = lg(a, kg);
            d && c.push(d);
            c.push(fg(a) ? a.top : dg);
            a: {
                c = x(c);
                for (var e = c.next(); !e.done; e = c.next()) {
                    b: {
                        d = a;e = e.value;
                        var f = b;
                        if (!gg(e)) try {
                            var g = lg(e, jg);
                            if (g) {
                                var h = new eg(g);
                                break b
                            }
                        } catch (k) {}
                        h = f(e) ? new ig(d, e) : null
                    }
                    if (d = h) {
                        a = d;
                        break a
                    }
                }
                a = null
            }
        }
        if (this.Fc = a) this.Fc.onMessage = this.fi.bind(this);
        else if (b = (b = dg.omid3p) && typeof b.registerSessionObserver === "function" && typeof b.addEventListener === "function" ? b : null) this.Yc = b;
        this.ej = this.fj =
            0;
        this.qe = {};
        this.Me = [];
        (this.dc = (b = dg.omidVerificationProperties) ? b.injectionId : void 0) || (Zf() ? $f() : ag())
    };
    mg.prototype.P = function() {
        var a = hg();
        var b = (b = dg.omidVerificationProperties) && b.injectionSource ? b.injectionSource : void 0;
        return (b || Xf(a) || Xf(fg(a) ? a.top : dg)) !== "web" || this.dc ? !(!this.Fc && !this.Yc) : !1
    };
    var Ee = function(a, b, c) {
        Nf(b);
        a.Yc ? a.Yc.registerSessionObserver(b, c, a.dc) : a.uc("addSessionListener", b, c, a.dc)
    };
    mg.prototype.addEventListener = function(a, b) {
        Mf("eventType", a);
        Nf(b);
        this.Yc ? this.Yc.addEventListener(a, b, this.dc) : this.uc("addEventListener", b, a, this.dc)
    };
    var nf = function(a, b, c, d) {
            Mf("url", b);
            dg.document && dg.document.createElement ? ng(a, b, c, d) : a.uc("sendUrl", function(e) {
                e && c ? c() : !e && d && d()
            }, b)
        },
        ng = function(a, b, c, d) {
            var e = dg.document.createElement("img");
            a.Me.push(e);
            var f = function(g) {
                var h = a.Me.indexOf(e);
                h >= 0 && a.Me.splice(h, 1);
                g && g()
            };
            e.addEventListener("load", f.bind(a, c));
            e.addEventListener("error", f.bind(a, d));
            e.src = b
        };
    mg.prototype.setTimeout = function(a, b) {
        Nf(a);
        Of("timeInMillis", b);
        if (og()) return dg.setTimeout(a, b);
        var c = this.fj++;
        this.uc("setTimeout", a, c, b);
        return c
    };
    mg.prototype.clearTimeout = function(a) {
        Of("timeoutId", a);
        og() ? dg.clearTimeout(a) : this.Tg("clearTimeout", a)
    };
    mg.prototype.setInterval = function(a, b) {
        Nf(a);
        Of("timeInMillis", b);
        if (pg()) return dg.setInterval(a, b);
        var c = this.ej++;
        this.uc("setInterval", a, c, b);
        return c
    };
    mg.prototype.clearInterval = function(a) {
        Of("intervalId", a);
        pg() ? dg.clearInterval(a) : this.Tg("clearInterval", a)
    };
    var og = function() {
            return typeof dg.setTimeout === "function" && typeof dg.clearTimeout === "function"
        },
        pg = function() {
            return typeof dg.setInterval === "function" && typeof dg.clearInterval === "function"
        };
    mg.prototype.fi = function(a) {
        var b = a.method,
            c = a.tg;
        a = a.args;
        if (b === "response" && this.qe[c]) {
            var d = Pf() && Qf() ? a ? a : [] : a && typeof a === "string" ? JSON.parse(a) : [];
            this.qe[c].apply(this, d)
        }
        b === "error" && window.console && bg(a)
    };
    mg.prototype.Tg = function(a) {
        this.uc.apply(this, [a, null].concat(y(E.apply(1, arguments))))
    };
    mg.prototype.uc = function(a, b) {
        var c = E.apply(2, arguments);
        if (this.Fc) {
            var d = Zf() ? $f() : ag();
            b && (this.qe[d] = b);
            var e = "VerificationService." + a;
            c = Pf() && Qf() ? c : JSON.stringify(c);
            this.Fc.sendMessage(new Rf(d, e, "1.6.5-google_20260406", c))
        }
    };
    var qg = void 0;
    if (qg = qg === void 0 ? typeof omidExports === "undefined" ? null : omidExports : qg) {
        var rg = ["OmidVerificationClient"];
        rg.slice(0, rg.length - 1).reduce(Yf, qg)[rg[rg.length - 1]] = mg
    };

    function sg(a, b) {
        return function(c) {
            return new L(function(d) {
                return c.subscribe(function(e) {
                    a.yc(b, function() {
                        d.next(e)
                    })()
                }, function(e) {
                    a.yc(b, function() {
                        d.error(e)
                    })()
                }, function() {
                    a.yc(b, function() {
                        d.complete()
                    })()
                })
            })
        }
    };
    var ug = function() {
        for (var a = x(E.apply(0, arguments)), b = a.next(); !b.done; b = a.next())
            if (b = b.value, b.pa()) {
                this.l = b;
                return
            }
        this.l = new tg
    };
    n = ug.prototype;
    n.pa = function() {
        return this.l.pa()
    };
    n.now = function() {
        return this.l.now()
    };
    n.setTimeout = function(a, b) {
        return this.l.setTimeout(a, b)
    };
    n.clearTimeout = function(a) {
        this.l.clearTimeout(a)
    };
    n.interval = function(a, b) {
        var c = this.Ga(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ga = function(a) {
        return this.l.Ga(a)
    };
    da.Object.defineProperties(ug.prototype, {
        timeline: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.l.timeline
            }
        }
    });
    var tg = function() {
        this.timeline = Symbol()
    };
    n = tg.prototype;
    n.pa = function() {
        return !1
    };
    n.now = function() {
        return new qe(0, this.timeline)
    };
    n.setTimeout = function() {
        return 0
    };
    n.clearTimeout = function() {};
    n.interval = function() {
        return function() {}
    };
    n.Ga = function() {
        return Qd
    };
    var vg = function(a, b) {
        this.S = a;
        this.L = b
    };
    n = vg.prototype;
    n.setTimeout = function(a, b) {
        return this.S.setTimeout(this.L.yc(734, a), b)
    };
    n.clearTimeout = function(a) {
        this.S.clearTimeout(a)
    };
    n.interval = function(a, b) {
        var c = this.Ga(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ga = function(a) {
        var b = this;
        return new L(function(c) {
            var d = 0,
                e = b.S.setInterval(function() {
                    c.next(d++)
                }, a);
            return function() {
                b.S.clearInterval(e)
            }
        })
    };
    n.pa = function() {
        return !!this.S.clearTimeout && "setTimeout" in this.S && "setInterval" in this.S && !!this.S.clearInterval
    };
    var wg = function(a, b) {
        vg.call(this, a, b);
        this.timeline = pe
    };
    q(wg, vg);
    wg.prototype.now = function() {
        return new qe(this.S.Date.now(), this.timeline)
    };
    wg.prototype.pa = function() {
        return !!this.S.Date && !!this.S.Date.now && vg.prototype.pa.call(this)
    };
    var xg = function(a, b) {
        vg.call(this, a, b);
        this.timeline = oe
    };
    q(xg, vg);
    xg.prototype.now = function() {
        return new qe(this.S.performance.now(), this.timeline)
    };
    xg.prototype.pa = function() {
        return !!this.S.performance && !!this.S.performance.now && vg.prototype.pa.call(this)
    };

    function yg(a) {
        a = a.global;
        if (a.fetchLater) return a.fetchLater.bind(a)
    }

    function zg(a) {
        var b, c, d = (b = a.global) == null ? void 0 : (c = b.document) == null ? void 0 : c.createElement("meta");
        if (d) try {
            return d.httpEquiv = "origin-trial", d.content = "AxjhRadLCARYRJawRjMjq4U8V8okQvSnrBIJWdMajuEkN3/DfVAcLcFhMVrUWnOXagwlI8dQD84FwJDGj9ohqAYAAABveyJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJGZXRjaExhdGVyQVBJIiwiZXhwaXJ5IjoxNzI1NDA3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9", a.global.document.head.append(d), d
        } catch (e) {}
    }
    var Bg = function(a) {
            this.context = a;
            Ag === void 0 && (Ag = zg(a))
        },
        Ag;
    Bg.prototype.P = function(a) {
        return yg(this.context) !== void 0 && !(a == null || !a.cg) && !Cg(this.context) && !(a == null ? 0 : a.Bc) && !(a == null ? 0 : a.rb) && !(a == null ? 0 : a.zd)
    };
    Bg.prototype.K = function(a, b) {
        if (!this.P(b)) throw new ee;
        return new Dg(this.context, a, b)
    };
    var Dg = function(a, b, c) {
            this.context = a;
            this.properties = c;
            this.Sb = b;
            var d;
            this.ia = (d = c == null ? void 0 : c.ia) != null ? d : "GET";
            a = yg(this.context);
            if (a === void 0) throw Error();
            this.fetchLater = a;
            Hg(this, this.Sc())
        },
        Hg = function(a, b) {
            a.Ya && a.Ya.activated || (a.Cc = new AbortController, a.Ya = a.fetchLater(b, {
                method: a.ia,
                cache: "no-cache",
                mode: "no-cors",
                signal: a.Cc.signal,
                activateAfter: 96E4
            }))
        };
    Dg.prototype.Sc = function() {
        var a = this.Sb;
        return (a.slice(-1)[0] === "&" ? a : a + "&") + "flapi=1"
    };
    Dg.prototype.deactivate = function() {
        this.Ya && !this.Ya.activated && this.Cc && (this.Cc.abort(), this.Ya = void 0)
    };
    Dg.prototype.sendNow = function() {};
    da.Object.defineProperties(Dg.prototype, {
        url: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Sb
            },
            set: function(a) {
                this.Sb = a;
                a = this.Sc();
                this.Ya && this.Ya.activated || !this.Cc || (this.Cc.abort(), this.Ya = void 0);
                Hg(this, a)
            }
        },
        method: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.ia
            }
        }
    });
    var Ig = function(a) {
        this.context = a
    };
    Ig.prototype.P = function() {
        return !Cg(this.context) && !!this.context.global.fetch
    };
    Ig.prototype.ping = function() {
        var a = this;
        return Pd.apply(null, y(E.apply(0, arguments).map(function(b) {
            return Mc(a.context.global.fetch(b, {
                method: "GET",
                cache: "no-cache",
                keepalive: !0,
                mode: "no-cors"
            })).g(N(function(c) {
                return c.status === 200
            }))
        }))).g(Ye(function(b) {
            return b
        }), $e())
    };
    Ig.prototype.Sd = function(a, b, c) {
        for (var d = E.apply(3, arguments), e = this, f = new Headers, g = x(b.entries()), h = g.next(); !h.done; h = g.next()) {
            var k = x(h.value);
            h = k.next().value;
            k = k.next().value;
            f.set(h, k)
        }
        var l, m = (l = a.keepAlive) != null ? l : !1;
        Pd.apply(null, y(d.map(function(u) {
            return Mc(e.context.global.fetch(u, Object.assign({}, {
                method: String(a.ia),
                cache: "no-cache"
            }, m ? {
                keepalive: !0
            } : {}, {
                mode: "no-cors",
                headers: f,
                body: c
            }))).g(N(function(t) {
                return t.status === 200
            }))
        }))).g(Ye(function(u) {
            return u
        }), $e())
    };
    var Jg = function(a) {
        Jg[" "](a);
        return a
    };
    Jg[" "] = function() {};
    var Kg = function(a, b) {
        try {
            return Jg(a[b]), !0
        } catch (c) {}
        return !1
    };

    function Lg(a) {
        try {
            return !!a && a.location.href != null && Kg(a, "foo")
        } catch (b) {
            return !1
        }
    };
    var Mg = Ia(1, !0),
        Ng = Ia(610401301, !1);
    Ia(899588437, !1);
    Ia(772657768, !0);
    Ia(513659523, !0);
    Ia(568333945, !0);
    Ia(1331761403, !1);
    Ia(651175828, !0);
    Ia(722764542, !0);
    Ia(748402145, !0);
    Ia(748402146, !0);
    var Og = Ia(748402147, !0);
    Ia(333098724, !1);
    Ia(861377723, !0);
    Ia(861377724, Mg);
    Ia(869336903, !0);
    Ia(882674507, !0);
    Ia(869336904, Mg);
    Ia(869336905, Mg);
    Ia(1675845485, !1);
    Ia(907842688, !1);
    Ia(909324564, !1);
    Ia(2147483644, !1);
    Ia(2147483645, !0);
    Ia(2147483646, Mg);
    Ia(2147483647, !0);

    function Pg() {
        var a = Ha.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Qg, Rg = Ha.navigator;
    Qg = Rg ? Rg.userAgentData || null : null;

    function Sg(a) {
        if (!Ng || !Qg) return !1;
        for (var b = 0; b < Qg.brands.length; b++) {
            var c = Qg.brands[b].brand;
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function U(a) {
        return Pg().indexOf(a) != -1
    };

    function Tg() {
        return Ng ? !!Qg && Qg.brands.length > 0 : !1
    }

    function Ug() {
        return Tg() ? !1 : U("Opera")
    }

    function Vg() {
        return U("Firefox") || U("FxiOS")
    }

    function Wg() {
        return U("Safari") && !(Xg() || (Tg() ? 0 : U("Coast")) || Ug() || (Tg() ? 0 : U("Edge")) || (Tg() ? Sg("Microsoft Edge") : U("Edg/")) || (Tg() ? Sg("Opera") : U("OPR")) || Vg() || U("Silk") || U("Android"))
    }

    function Xg() {
        return Tg() ? Sg("Chromium") : (U("Chrome") || U("CriOS")) && !(Tg() ? 0 : U("Edge")) || U("Silk")
    }

    function Yg() {
        return U("Android") && !(Xg() || Vg() || Ug() || U("Silk"))
    };

    function Zg() {
        return Ng && Qg ? Qg.mobile : !$g() && (U("iPod") || U("iPhone") || U("Android") || U("IEMobile"))
    }

    function $g() {
        return Ng && Qg ? !Qg.mobile && (U("iPad") || U("Android") || U("Silk")) : U("iPad") || U("Android") && !U("Mobile") || U("Silk")
    };

    function ah() {
        return Ng ? !!Qg && !!Qg.platform : !1
    }

    function bh() {
        return U("iPhone") && !U("iPod") && !U("iPad")
    }

    function ch() {
        bh() || U("iPad") || U("iPod")
    };
    Ug();
    var dh = Tg() ? !1 : U("Trident") || U("MSIE");
    U("Edge");
    var eh = U("Gecko") && !(Va(Pg(), "WebKit") && !U("Edge")) && !(U("Trident") || U("MSIE")) && !U("Edge"),
        fh = Va(Pg(), "WebKit") && !U("Edge");
    fh && U("Mobile");
    ah() || U("Macintosh");
    ah() || U("Windows");
    (ah() ? Qg.platform === "Linux" : U("Linux")) || ah() || U("CrOS");
    ah() || U("Android");
    bh();
    U("iPad");
    U("iPod");
    ch();
    Va(Pg(), "KaiOS");

    function gh(a, b) {
        b = b === void 0 ? new Set : b;
        if (b.has(a)) return "(Recursive reference)";
        switch (typeof a) {
            case "object":
                if (a) {
                    var c = Object.getPrototypeOf(a);
                    switch (c) {
                        case Map.prototype:
                        case Set.prototype:
                        case Array.prototype:
                            b.add(a);
                            var d = "[" + Array.from(a, function(e) {
                                return gh(e, b)
                            }).join(", ") + "]";
                            b.delete(a);
                            c !== Array.prototype && (d = hh(c.constructor) + "(" + d + ")");
                            return d;
                        case Object.prototype:
                            return b.add(a), c = "{" + Object.entries(a).map(function(e) {
                                var f = x(e);
                                e = f.next().value;
                                f = f.next().value;
                                return e +
                                    ": " + gh(f, b)
                            }).join(", ") + "}", b.delete(a), c;
                        default:
                            return d = "Object", c && c.constructor && (d = hh(c.constructor)), typeof a.toString === "function" && a.toString !== Object.prototype.toString ? d + "(" + String(a) + ")" : "(object " + d + ")"
                    }
                }
                break;
            case "function":
                return "function " + hh(a);
            case "number":
                if (!Number.isFinite(a)) return String(a);
                break;
            case "bigint":
                return a.toString(10) + "n";
            case "symbol":
                return a.toString()
        }
        return JSON.stringify(a)
    }

    function hh(a) {
        var b = a.displayName;
        return b && typeof b === "string" || (b = a.name) && typeof b === "string" ? b : (a = /function\s+([^\(]+)/m.exec(String(a))) ? a[1] : "(Anonymous)"
    };

    function ih(a, b) {
        var c = jh,
            d = [];
        kh(b, a, d) || lh.apply(null, [void 0, c, "Guard " + b.Ke().trim() + " failed:"].concat(y(d.reverse())))
    }

    function mh(a, b) {
        a.uk = !0;
        a.Ke = typeof b === "function" ? b : function() {
            return b
        };
        return a
    }

    function kh(a, b, c) {
        var d = a(b, c);
        d || nh(c, function() {
            var e = "";
            e.length > 0 && (e += ": ");
            return e + "Expected " + a.Ke().trim() + ", got " + gh(b)
        });
        return d
    }

    function nh(a, b) {
        a == null || a.push((typeof b === "function" ? b() : b).trim())
    }
    var jh = void 0;

    function oh(a) {
        return typeof a === "function" ? a() : a
    }

    function lh() {
        throw Error(E.apply(0, arguments).map(oh).filter(Boolean).join("\n").trim().replace(/:$/, ""));
    };
    var ph = mh(function(a) {
            return typeof a === "number"
        }, "number"),
        qh = mh(function(a) {
            return typeof a === "string"
        }, "string"),
        rh = mh(function(a) {
            return typeof a === "boolean"
        }, "boolean"),
        sh = mh(function(a) {
            return typeof a === "bigint"
        }, "bigint");

    function th() {
        var a = Error;
        return mh(function(b) {
            return b instanceof a
        }, function() {
            return hh(a)
        })
    }

    function uh() {
        var a = E.apply(0, arguments);
        return mh(function(b) {
            return a.some(function(c) {
                return c(b)
            })
        }, function() {
            return "" + a.map(function(b) {
                return b.Ke().trim()
            }).join(" | ")
        })
    };

    function vh(a, b) {
        this.x = a !== void 0 ? a : 0;
        this.y = b !== void 0 ? b : 0
    }
    n = vh.prototype;
    n.clone = function() {
        return new vh(this.x, this.y)
    };
    n.toString = function() {
        return "(" + this.x + ", " + this.y + ")"
    };
    n.equals = function(a) {
        return a instanceof vh && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    n.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    n.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    n.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    n.translate = function(a, b) {
        a instanceof vh ? (this.x += a.x, this.y += a.y) : (this.x += Number(a), typeof b === "number" && (this.y += b));
        return this
    };
    n.scale = function(a, b) {
        this.x *= a;
        this.y *= typeof b === "number" ? b : a;
        return this
    };

    function wh(a, b) {
        this.width = a;
        this.height = b
    }
    n = wh.prototype;
    n.clone = function() {
        return new wh(this.width, this.height)
    };
    n.toString = function() {
        return "(" + this.width + " x " + this.height + ")"
    };
    n.aspectRatio = function() {
        return this.width / this.height
    };
    n.isEmpty = function() {
        return !(this.width * this.height)
    };
    n.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    n.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    n.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    n.scale = function(a, b) {
        this.width *= a;
        this.height *= typeof b === "number" ? b : a;
        return this
    };
    var zh = function(a) {
            return a ? new xh(yh(a)) : ub || (ub = new xh)
        },
        Ah = function(a) {
            var b = a.scrollingElement ? a.scrollingElement : fh || a.compatMode != "CSS1Compat" ? a.body || a.documentElement : a.documentElement;
            a = a.defaultView;
            return new vh((a == null ? void 0 : a.pageXOffset) || b.scrollLeft, (a == null ? void 0 : a.pageYOffset) || b.scrollTop)
        },
        Bh = function(a, b, c) {
            function d(h) {
                h && b.appendChild(typeof h === "string" ? a.createTextNode(h) : h)
            }
            for (var e = 1; e < c.length; e++) {
                var f = c[e];
                if (!Ka(f) || La(f) && f.nodeType > 0) d(f);
                else {
                    a: {
                        if (f && typeof f.length ==
                            "number") {
                            if (La(f)) {
                                var g = typeof f.item == "function" || typeof f.item == "string";
                                break a
                            }
                            if (typeof f === "function") {
                                g = typeof f.item == "function";
                                break a
                            }
                        }
                        g = !1
                    }
                    Fb(g ? Jb(f) : f, d)
                }
            }
        },
        yh = function(a) {
            F(a, "Node cannot be null or undefined.");
            return a.nodeType == 9 ? a : a.ownerDocument || a.document
        },
        Ch = function(a, b) {
            a && (a = a.parentNode);
            for (var c = 0; a;) {
                F(a.name != "parentNode");
                if (b(a)) return a;
                a = a.parentNode;
                c++
            }
            return null
        },
        xh = function(a) {
            this.Jc = a || Ha.document || document
        };
    n = xh.prototype;
    n.getElementsByTagName = function(a, b) {
        return (b || this.Jc).getElementsByTagName(String(a))
    };
    n.createElement = function(a) {
        var b = this.Jc;
        a = String(a);
        b.contentType === "application/xhtml+xml" && (a = a.toLowerCase());
        return b.createElement(a)
    };
    n.createTextNode = function(a) {
        return this.Jc.createTextNode(String(a))
    };
    n.appendChild = function(a, b) {
        F(a != null && b != null, "goog.dom.appendChild expects non-null arguments");
        a.appendChild(b)
    };
    n.append = function(a, b) {
        Bh(yh(a), a, arguments)
    };
    n.canHaveChildren = function(a) {
        if (a.nodeType != 1) return !1;
        switch (a.tagName) {
            case "APPLET":
            case "AREA":
            case "BASE":
            case "BR":
            case "COL":
            case "COMMAND":
            case "EMBED":
            case "FRAME":
            case "HR":
            case "IMG":
            case "INPUT":
            case "IFRAME":
            case "ISINDEX":
            case "KEYGEN":
            case "LINK":
            case "NOFRAMES":
            case "NOSCRIPT":
            case "META":
            case "OBJECT":
            case "PARAM":
            case "SCRIPT":
            case "SOURCE":
            case "STYLE":
            case "TRACK":
            case "WBR":
                return !1
        }
        return !0
    };
    n.removeNode = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    n.isElement = function(a) {
        return La(a) && a.nodeType == 1
    };
    n.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
        if (typeof a.compareDocumentPosition != "undefined") return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };

    function Dh(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    }
    n = Dh.prototype;
    n.sg = function() {
        return this.right - this.left
    };
    n.pg = function() {
        return this.bottom - this.top
    };
    n.clone = function() {
        return new Dh(this.top, this.right, this.bottom, this.left)
    };
    n.toString = function() {
        return "(" + this.top + "t, " + this.right + "r, " + this.bottom + "b, " + this.left + "l)"
    };
    n.contains = function(a) {
        return this && a ? a instanceof Dh ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    n.expand = function(a, b, c, d) {
        La(a) ? (this.top -= a.top, this.right += a.right, this.bottom += a.bottom, this.left -= a.left) : (this.top -= a, this.right += Number(b), this.bottom += Number(c), this.left -= Number(d));
        return this
    };
    n.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    n.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    n.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    n.translate = function(a, b) {
        a instanceof vh ? (this.left += a.x, this.right += a.x, this.top += a.y, this.bottom += a.y) : (yb(a), this.left += a, this.right += a, typeof b === "number" && (this.top += b, this.bottom += b));
        return this
    };
    n.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.right *= a;
        this.top *= b;
        this.bottom *= b;
        return this
    };
    var Eh = function(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    };

    function Fh(a, b, c) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, !1)
    };
    var Gh = function(a) {
        this.context = a
    };
    Gh.prototype.P = function(a) {
        return (a == null ? 0 : a.Bc) || (a == null ? void 0 : a.ia) === "POST" || (a == null ? 0 : a.rb) || (a == null ? 0 : a.zd) || (a == null ? 0 : a.keepAlive) ? !1 : !Cg(this.context)
    };
    Gh.prototype.ping = function() {
        var a = this;
        return Zc(E.apply(0, arguments).map(function(b) {
            try {
                var c = a.context.global;
                c.google_image_requests || (c.google_image_requests = []);
                var d = c.document;
                d = d === void 0 ? document : d;
                var e = d.createElement("img");
                e.src = b;
                c.google_image_requests.push(e);
                return !0
            } catch (f) {
                return !1
            }
        }).every(function(b) {
            return b
        }))
    };
    Gh.prototype.Sd = function(a, b, c) {
        this.ping.apply(this, y(E.apply(3, arguments)))
    };

    function Hh(a) {
        a = a.global;
        if (a.PendingGetBeacon) return a.PendingGetBeacon
    }
    var Ih = function(a) {
        this.context = a
    };
    Ih.prototype.P = function(a) {
        return Jh && !Cg(this.context) && Hh(this.context) !== void 0 && !(a == null ? 0 : a.Bc) && (a == null ? void 0 : a.ia) !== "POST" && !(a == null ? 0 : a.rb) && !(a == null ? 0 : a.zd)
    };
    Ih.prototype.K = function(a, b) {
        if (!this.P(b)) throw new ee;
        return new Kh(this.context, a)
    };
    var Jh = !1,
        Kh = function(a, b) {
            this.context = a;
            this.Sb = b;
            a = Hh(this.context);
            if (a === void 0) throw Error();
            this.Ff = new a(this.Sc(), {})
        };
    Kh.prototype.Sc = function() {
        var a = this.Sb;
        return (a.slice(-1)[0] === "&" ? a : a + "&") + "pbapi=1"
    };
    Kh.prototype.deactivate = function() {
        this.Ff.deactivate()
    };
    Kh.prototype.sendNow = function() {
        this.Ff.sendNow()
    };
    da.Object.defineProperties(Kh.prototype, {
        url: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Sb
            },
            set: function(a) {
                this.Sb = a;
                this.Ff.setURL(this.Sc())
            }
        },
        method: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return "GET"
            },
            set: function(a) {
                if (a !== "GET") throw new ee;
            }
        }
    });
    var Lh = function(a) {
        this.context = a
    };
    Lh.prototype.P = function(a) {
        if ((a == null ? 0 : a.Bc) || (a == null ? void 0 : a.ia) === "GET" || (a == null ? 0 : a.rb) || (a == null ? 0 : a.zd) || (a == null ? 0 : a.keepAlive)) return !1;
        var b;
        return !Cg(this.context) && ((b = this.context.global.navigator) == null ? void 0 : b.sendBeacon) !== void 0
    };
    Lh.prototype.ping = function() {
        var a = this;
        return Zc(E.apply(0, arguments).map(function(b) {
            var c;
            return (c = a.context.global.navigator) == null ? void 0 : c.sendBeacon(b)
        }).every(function(b) {
            return b
        }))
    };
    Lh.prototype.Sd = function(a, b, c) {
        this.ping.apply(this, y(E.apply(3, arguments)))
    };

    function Mh(a) {
        return function(b) {
            return b.g(Nh(a, af(new xc)))
        }
    }

    function V(a, b) {
        return function(c) {
            return c.g(Nh(a, cf(b)))
        }
    }

    function Nh(a, b) {
        function c(d) {
            return new L(function(e) {
                return d.subscribe(function(f) {
                    Ta(a, function() {
                        return void e.next(f)
                    }, 3)
                }, function(f) {
                    Ta(a, function() {
                        return void e.error(f)
                    }, 3)
                }, function() {
                    Ta(a, function() {
                        return void e.complete()
                    }, 3)
                })
            })
        }
        return K(c, ld(), b, id(), c)
    };
    var W = function(a) {
        this.value = a
    };
    W.prototype.X = function(a) {
        return Zc(this.value).g(V(a, 1))
    };
    var Oh = new W(!1);

    function Ph(a) {
        Ha.setTimeout(function() {
            throw a;
        }, 0)
    };
    Vg();
    bh() || U("iPod");
    U("iPad");
    Yg();
    Xg();
    Wg() && ch();
    var Qh = {},
        Rh = null,
        Sh = eh || fh || typeof Ha.btoa == "function";

    function Th(a) {
        var b;
        F(Ka(a), "encodeByteArray takes an array as a parameter");
        b === void 0 && (b = 0);
        Uh();
        b = Qh[b];
        for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
            var g = a[e],
                h = a[e + 1],
                k = a[e + 2],
                l = b[g >> 2];
            g = b[(g & 3) << 4 | h >> 4];
            h = b[(h & 15) << 2 | k >> 6];
            k = b[k & 63];
            c[f++] = "" + l + g + h + k
        }
        l = 0;
        k = d;
        switch (a.length - e) {
            case 2:
                l = a[e + 1], k = b[(l & 15) << 2] || d;
            case 1:
                a = a[e], c[f] = "" + b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
        }
        return c.join("")
    }

    function Vh(a) {
        var b = a.length,
            c = b * 3 / 4;
        c % 3 ? c = Math.floor(c) : "=.".indexOf(a[b - 1]) != -1 && (c = "=.".indexOf(a[b - 2]) != -1 ? c - 2 : c - 1);
        var d = new Uint8Array(c),
            e = 0;
        Wh(a, function(f) {
            d[e++] = f
        });
        return e !== c ? d.subarray(0, e) : d
    }

    function Wh(a, b) {
        function c(k) {
            for (; d < a.length;) {
                var l = a.charAt(d++),
                    m = Rh[l];
                if (m != null) return m;
                if (!/^[\s\xa0]*$/.test(l)) throw Error("S`" + l);
            }
            return k
        }
        Uh();
        for (var d = 0;;) {
            var e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (h === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
        }
    }

    function Uh() {
        if (!Rh) {
            Rh = {};
            for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; c < 5; c++) {
                var d = a.concat(b[c].split(""));
                Qh[c] = d;
                for (var e = 0; e < d.length; e++) {
                    var f = d[e],
                        g = Rh[f];
                    g === void 0 ? Rh[f] = e : F(g === e)
                }
            }
        }
    };

    function Xh(a) {
        var b = Yh(a);
        return b === null ? new W(null) : b.g(N(function(c) {
            c = c.hb();
            if (Sh) c = Ha.btoa(c);
            else {
                for (var d = [], e = 0, f = 0; f < c.length; f++) {
                    var g = c.charCodeAt(f);
                    if (g > 255) throw Error("R");
                    d[e++] = g
                }
                c = Th(d)
            }
            return c
        }), Re(1), V(a.i, 1))
    };

    function Zh(a) {
        var b = b === void 0 ? {} : b;
        if (typeof Event === "function") return new Event(a, b);
        if (typeof document !== "undefined") {
            var c = document.createEvent("CustomEvent");
            c.initCustomEvent(a, b.bubbles || !1, b.cancelable || !1, b.detail);
            return c
        }
        throw Error();
    };
    var $h = function(a) {
        this.value = a;
        this.kf = new xc
    };
    $h.prototype.release = function() {
        this.kf.next();
        this.kf.complete();
        this.value = void 0
    };
    da.Object.defineProperties($h.prototype, {
        j: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.value
            }
        },
        released: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.kf
            }
        }
    });
    var ai = ["FRAME", "IMG", "IFRAME"],
        bi = /^[01](px)?$/,
        ci = function() {
            this.Ci = this.Pf = this.Pg = this.Yf = !1
        },
        di = function() {
            var a = new ci;
            a.Yf = !0;
            a.Pg = !0;
            return a
        };

    function ei(a) {
        return qh(a) ? document.getElementById(a) : a
    }

    function fi(a, b) {
        b = b === void 0 ? !1 : b;
        if (a.tagName === "IMG") {
            if (a.complete && (!a.naturalWidth || !a.naturalHeight)) return !0;
            var c;
            if (b && ((c = a.style) == null ? void 0 : c.display) === "none") return !0
        }
        var d, e;
        return bi.test((d = a.getAttribute("width")) != null ? d : "") && bi.test((e = a.getAttribute("height")) != null ? e : "")
    }

    function gi(a, b) {
        if (a.tagName === "IMG") return a.naturalWidth && a.naturalHeight ? !0 : !1;
        try {
            if (a.readyState) var c = a.readyState;
            else {
                var d, e;
                c = (d = a.contentWindow) == null ? void 0 : (e = d.document) == null ? void 0 : e.readyState
            }
            return c === "complete"
        } catch (f) {
            return b === void 0 ? !1 : b
        }
    }

    function hi(a) {
        a || (a = function(b, c, d) {
            b.addEventListener(c, d)
        });
        return a
    }

    function ii(a, b) {
        var c = di();
        c = c === void 0 ? new ci : c;
        if (a = ei(a)) {
            var d = hi(d);
            for (var e = !1, f = function(z) {
                    e || (e = !0, b(z))
                }, g, h = 2, k = 0; k < ai.length; ++k)
                if (ai[k] === a.tagName) {
                    h = 3;
                    g = [a];
                    break
                }
            g || (g = a.querySelectorAll(ai.join(",")));
            var l = 0,
                m = 0,
                u = !c.Pf,
                t = a = !1;
            k = {};
            for (var r = 0; r < g.length; k = {
                    Kd: void 0
                }, r++) {
                var w = g[r];
                if (!fi(w, c.Pf))
                    if (k.Kd = w.tagName === "IMG", gi(w, c.Yf)) a = !0, k.Kd && (u = !0);
                    else {
                        l++;
                        var v = function(z) {
                            return function(C) {
                                l--;
                                !l && u && f(h);
                                z.Kd && (C = C && C.type === "error", m--, C || (u = !0), !m && t && u && f(h))
                            }
                        }(k);
                        d(w, "load", v);
                        k.Kd && (m++, d(w, "error", v))
                    }
            }
            m === 0 && (u = !0);
            g = null;
            g = Ha.document.readyState === "complete";
            if (c.Ci && g) {
                if (m > 0) {
                    t = !0;
                    return
                }
                h = 5
            } else if (l === 0 && !a && g) h = 5;
            else if (l || !a) {
                d(Ha, "load", function() {
                    !c.Pg || !m && u ? f(4) : t = !0
                });
                return
            }
            f(h)
        }
    };

    function ji(a, b, c) {
        if (a)
            for (var d = 0; a != null && d < 500 && !c(a); ++d) a = b(a)
    }

    function ki(a, b) {
        ji(a, function(c) {
            try {
                return c === c.parent ? null : c.parent
            } catch (d) {}
            return null
        }, b)
    }

    function li(a, b) {
        if (a.tagName == "IFRAME") b(a);
        else {
            a = a.querySelectorAll("IFRAME");
            for (var c = 0; c < a.length && !b(a[c]); ++c);
        }
    }

    function mi(a) {
        return (a = a.ownerDocument) && (a.parentWindow || a.defaultView) || null
    }

    function ni(a, b, c) {
        try {
            var d = JSON.parse(c.data)
        } catch (g) {}
        if (typeof d === "object" && d && d.type === "creativeLoad") {
            var e = mi(a);
            if (c.source && e) {
                var f;
                ki(c.source, function(g) {
                    try {
                        if (g.parent === e) return f = g, !0
                    } catch (h) {}
                });
                f && li(a, function(g) {
                    if (g.contentWindow === f) return b(d), !0
                })
            }
        }
    }

    function oi(a) {
        return typeof a === "string" ? document.getElementById(a) : a
    }
    var pi = function(a, b) {
        var c = oi(a);
        if (c)
            if (c.onCreativeLoad) c.onCreativeLoad(b);
            else {
                var d = b ? [b] : [],
                    e = function(f) {
                        for (var g = 0; g < d.length; ++g) try {
                            d[g](1, f)
                        } catch (h) {}
                        d = {
                            push: function(h) {
                                h(1, f)
                            }
                        }
                    };
                c.onCreativeLoad = function(f) {
                    d.push(f)
                };
                c.setAttribute("data-creative-load-listener", "");
                c.addEventListener("creativeLoad", function(f) {
                    e(f.detail)
                });
                Ha.addEventListener("message", function(f) {
                    ni(c, e, f)
                })
            }
    };
    var qi = function(a, b) {
            var c = this;
            this.global = a;
            this.Rd = b;
            this.Xi = this.document ? Pd(Zc(!0), Id(this.document, "visibilitychange")).g(sg(this.Rd.L, 748), N(function() {
                return c.document ? c.document.visibilityState : "visible"
            }), P()) : Zc("visible");
            this.Ui = this.document ? Id(this.document, "DOMContentLoaded").g(sg(this.Rd.L, 739), Re(1)) : Zc(Zh("DOMContentLoaded"))
        },
        ri = function(a) {
            return a.document ? a.document.readyState : "complete"
        },
        si = function(a) {
            return a.document !== null && a.document.visibilityState !== void 0
        };
    qi.prototype.querySelector = function(a) {
        return this.document ? this.document.querySelector(a) : null
    };
    qi.prototype.querySelectorAll = function(a) {
        return this.document ? Jb(this.document.querySelectorAll(a)) : []
    };
    qi.prototype.elementFromPoint = function(a, b) {
        if (!this.document || this.document === null || typeof this.document.elementFromPoint !== "function") return null;
        a = this.document.elementFromPoint(a, b);
        return a === null ? null : new $h(a)
    };
    var ti = function(a, b, c) {
            c = c === void 0 ? !1 : c;
            if (b.j === void 0 || !a.document) return Zc(b).g(sg(a.Rd.L, 749));
            var d = new bd(1),
                e = function() {
                    d.next(b)
                };
            c || pi(b.j, e);
            ii(b.j, e);
            return d.g(sg(a.Rd.L, 749), Re(1))
        },
        ui = function(a, b) {
            a = a.document;
            if (!a) return Zc(!1);
            var c = Pd(Zc(null), Id(a, "DOMContentLoaded", {
                    once: !0
                }), Id(a, "load", {
                    once: !0
                })),
                d = new $h({
                    document: a,
                    element: b
                });
            return c.g(N(function() {
                if (!d.j) return !1;
                var e = d.j,
                    f = e.document;
                e = e.element;
                var g, h, k = (h = (g = f.body) != null ? g : f.children[0]) != null ? h : f;
                try {
                    k.appendChild(e),
                        d.release()
                } catch (l) {}
                return !d.j
            }), O(function(e) {
                return e
            }), Re(1), Oe(!1), jf({
                complete: function() {
                    return void d.release()
                }
            }))
        },
        vi = function(a, b, c) {
            var d, e, f;
            return Ca(function(g) {
                if (g.A == 1) {
                    d = a.global.document.createElement("iframe");
                    e = new Promise(function(k) {
                        d.onload = k;
                        d.onerror = k
                    });
                    if (b instanceof bb) var h = b.Qg;
                    else throw Error("Unexpected type when unwrapping TrustedResourceUrl");
                    d.src = h.toString();
                    return g.u(gd(ui(a, d)), 2)
                }
                if (g.A != 3) {
                    if (!g.V) return g.return();
                    d.style.display = "none";
                    return g.u(e,
                        3)
                }
                f = d.contentWindow;
                if (!f) return g.return();
                f.postMessage(c, "*");
                return g.return(d)
            })
        };
    da.Object.defineProperties(qi.prototype, {
        document: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Kg(this.global, "document") ? this.global.document || null : null
            }
        }
    });
    var wi = {
        left: 0,
        top: 0,
        width: 0,
        height: 0
    };

    function xi(a, b) {
        return a.left === b.left && a.top === b.top && a.width === b.width && a.height === b.height
    }

    function yi(a, b) {
        return {
            left: Math.max(a.left, b.left),
            top: Math.max(a.top, b.top),
            width: Math.max(0, Math.min(a.left + a.width, b.left + b.width) - Math.max(a.left, b.left)),
            height: Math.max(0, Math.min(a.top + a.height, b.top + b.height) - Math.max(a.top, b.top))
        }
    }

    function zi(a, b) {
        return {
            left: Math.round(a.left + b.x),
            top: Math.round(a.top + b.y),
            width: a.width,
            height: a.height
        }
    };
    var Ai = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function Bi(a, b) {
        if (a) {
            a = a.split("&");
            for (var c = 0; c < a.length; c++) {
                var d = a[c].indexOf("="),
                    e = null;
                if (d >= 0) {
                    var f = a[c].substring(0, d);
                    e = a[c].substring(d + 1)
                } else f = a[c];
                b(f, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "")
            }
        }
    };

    function Ci(a, b) {
        var c = $g() || Zg();
        try {
            if (a) {
                if (!b.top) return new Dh(-12245933, -12245933, -12245933, -12245933);
                b = b.top
            }
            a: {
                var d = b;
                if (a && d !== null && d != d.top) {
                    if (!d.top) {
                        var e = new wh(-12245933, -12245933);
                        break a
                    }
                    d = d.top
                }
                try {
                    if (c === void 0 ? 0 : c) var f = (new wh(d.innerWidth, d.innerHeight)).round();
                    else {
                        var g = (d || window).document,
                            h = g.compatMode == "CSS1Compat" ? g.documentElement : g.body;
                        f = (new wh(h.clientWidth, h.clientHeight)).round()
                    }
                    e = f
                } catch (w) {
                    e = new wh(-12245933, -12245933)
                }
            }
            a = e;
            var k = a.height,
                l = a.width;
            if (l ===
                -12245933) return new Dh(l, l, l, l);
            var m = zh(b.document);
            var u = Ah(m.Jc);
            var t = u.x,
                r = u.y;
            return new Dh(r, t + l, r + k, t)
        } catch (w) {
            return new Dh(-12245933, -12245933, -12245933, -12245933)
        }
    };

    function Di(a, b) {
        if (a) throw Error("T");
        b.push(65533)
    }

    function Ei(a, b) {
        b = String.fromCharCode.apply(null, b);
        return a == null ? b : a + b
    }
    var Fi = void 0,
        Gi, Hi, Ii = typeof TextDecoder !== "undefined",
        Ji, Ki = typeof String.prototype.isWellFormed === "function",
        Li = typeof TextEncoder !== "undefined";
    var Mi = typeof Uint8Array !== "undefined",
        Ni = !dh && typeof btoa === "function",
        Oi = /[-_.]/g,
        Pi = {
            "-": "+",
            _: "/",
            ".": "="
        };

    function Qi(a) {
        return Pi[a] || ""
    }

    function Ri(a) {
        if (!Ni) return Vh(a);
        var b = Oi.test(a) ? a.replace(Oi, Qi) : a;
        try {
            var c = atob(b)
        } catch (d) {
            throw Error("V`" + a + "`" + d);
        }
        a = new Uint8Array(c.length);
        for (b = 0; b < c.length; b++) a[b] = c.charCodeAt(b);
        return a
    }
    var Si = {};
    var Ui = function(a, b) {
        if (b !== Si) throw Error("X");
        this.ld = a;
        if (a != null && a.length === 0) throw Error("W");
        this.dontPassByteStringToStructuredClone = Ti
    };
    Ui.prototype.isEmpty = function() {
        return this.ld == null
    };
    var Vi;

    function Ti() {};

    function Wi(a) {
        Eb(a, Ui);
        if (Si !== Si) throw Error("X");
        var b = a.ld;
        b == null || Mi && b != null && b instanceof Uint8Array || (typeof b === "string" ? b = Ri(b) : (xb("Cannot coerce to Uint8Array: " + Ja(b)), b = null));
        return (b == null ? b : a.ld = b) || new Uint8Array(0)
    };
    var Xi = function(a, b, c) {
        this.buffer = a;
        if (c && !b) throw Error("fa");
        this.Eg = b
    };

    function Zi(a, b) {
        if (typeof a === "string") return new Xi(Ri(a), b);
        if (Array.isArray(a)) return new Xi(new Uint8Array(a), b);
        if (a.constructor === Uint8Array) return new Xi(a, !1);
        if (a.constructor === ArrayBuffer) return a = new Uint8Array(a), new Xi(a, !1);
        if (a.constructor === Ui) return b = Wi(a), new Xi(b, !0, a);
        if (a instanceof Uint8Array) return a = a.constructor === Uint8Array ? a : new Uint8Array(a.buffer, a.byteOffset, a.byteLength), new Xi(a, !1);
        throw Error("ga");
    };

    function $i() {
        return typeof BigInt === "function"
    };
    var aj = typeof Ha.BigInt === "function" && typeof Ha.BigInt(0) === "bigint";

    function bj(a) {
        var b = a;
        if (qh(b)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error("ha`" + b);
        } else if (ph(b) && !Number.isSafeInteger(b)) throw Error("ia`" + b);
        if (aj) {
            sh(a) || (ih(a, uh(qh, rh, ph)), a = BigInt(a));
            b = a % BigInt(2);
            var c = BigInt,
                d = typeof Window === "function" && globalThis.top instanceof Window ? globalThis.top : globalThis;
            d.gbigintUseStrInDebugToggleVal == null && Object.defineProperties(d, {
                gbigintUseStrInDebugToggleVal: {
                    value: Math.round(Math.random())
                }
            });
            return b === c(d.gbigintUseStrInDebugToggleVal) ? a.toString() :
                a
        }
        return a = rh(a) ? a ? "1" : "0" : qh(a) ? a.trim() || "0" : String(a)
    }
    var hj = mh(function(a) {
            if (aj) return ih(cj, sh), ih(dj, sh), a = BigInt(a), a >= cj && a <= dj;
            ih(a, qh);
            return a[0] === "-" ? ej(a, fj) : ej(a, gj)
        }, "isSafeInt52"),
        fj = Number.MIN_SAFE_INTEGER.toString(),
        cj = aj ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
        gj = Number.MAX_SAFE_INTEGER.toString(),
        dj = aj ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;

    function ej(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (var c = 0; c < a.length; c++) {
            var d = a[c],
                e = b[c];
            if (d > e) return !1;
            if (d < e) return !0
        }
        c = jh;
        lh("Assertion fail:", "isInRange weird case. Value was: " + a + ". Boundary was: " + b + "." || c)
    };
    var ij = typeof Uint8Array.prototype.slice === "function",
        jj = 0,
        kj = 0,
        lj;

    function mj(a) {
        var b = a >>> 0;
        jj = b;
        kj = (a - b) / 4294967296 >>> 0
    }

    function nj(a) {
        if (a < 0) {
            mj(0 - a);
            var b = x(oj(jj, kj));
            a = b.next().value;
            b = b.next().value;
            jj = a >>> 0;
            kj = b >>> 0
        } else mj(a)
    }

    function pj(a) {
        F(a <= 8);
        return lj || (lj = new DataView(new ArrayBuffer(8)))
    }

    function qj(a, b) {
        var c = b * 4294967296 + (a >>> 0);
        return Number.isSafeInteger(c) ? c : rj(a, b)
    }

    function sj(a, b) {
        return bj($i() ? BigInt.asUintN(64, (BigInt(b >>> 0) << BigInt(32)) + BigInt(a >>> 0)) : rj(a, b))
    }

    function tj(a, b) {
        return $i() ? bj(BigInt.asIntN(64, (BigInt.asUintN(32, BigInt(b)) << BigInt(32)) + BigInt.asUintN(32, BigInt(a)))) : bj(uj(a, b))
    }

    function rj(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (b <= 2097151) var c = "" + (4294967296 * b + a);
        else $i() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + c * 6777216 + b * 6710656, c += b * 8147497, b *= 2, a >= 1E7 && (c += a / 1E7 >>> 0, a %= 1E7), c >= 1E7 && (b += c / 1E7 >>> 0, c %= 1E7), F(b), c = b + vj(c) + vj(a));
        return c
    }

    function vj(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    }

    function uj(a, b) {
        b & 2147483648 ? $i() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = x(oj(a, b)), a = b.next().value, b = b.next().value, a = "-" + rj(a, b)) : a = rj(a, b);
        return a
    }

    function wj(a) {
        F(a.length > 0);
        if (a.length < 16) nj(Number(a));
        else if ($i()) a = BigInt(a), jj = Number(a & BigInt(4294967295)) >>> 0, kj = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            F(a.length > 0);
            var b = +(a[0] === "-");
            kj = jj = 0;
            for (var c = a.length, d = 0 + b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), kj *= 1E6, jj = jj * 1E6 + d, jj >= 4294967296 && (kj += Math.trunc(jj / 4294967296), kj >>>= 0, jj >>>= 0);
            b && (b = x(oj(jj, kj)), a = b.next().value, b = b.next().value, jj = a, kj = b)
        }
    }

    function oj(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };
    var xj = function(a, b, c, d) {
        this.J = this.Ea = null;
        this.pe = !1;
        this.T = this.Pa = this.Ua = 0;
        this.init(a, b, c, d)
    };
    n = xj.prototype;
    n.init = function(a, b, c, d) {
        var e = d === void 0 ? {} : d;
        d = e.sd === void 0 ? !1 : e.sd;
        e = e.be === void 0 ? !1 : e.be;
        this.sd = d;
        this.be = e;
        a && (this.J = a = Zi(a, this.be), this.Ea = a.buffer, this.pe = a.Eg, this.Ua = b || 0, this.Pa = c !== void 0 ? this.Ua + c : this.Ea.length, this.T = this.Ua)
    };
    n.Fe = function() {
        this.clear();
        yj.length < 100 && yj.push(this)
    };
    n.clear = function() {
        this.J = this.Ea = null;
        this.pe = !1;
        this.T = this.Pa = this.Ua = 0;
        this.sd = !1
    };
    n.setEnd = function(a) {
        this.Pa = a
    };
    n.reset = function() {
        this.T = this.Ua
    };
    n.ga = function() {
        return this.T
    };
    n.advance = function(a) {
        zj(this, this.T + a)
    };
    var Aj = function(a, b) {
            var c = 0,
                d = 0,
                e = 0,
                f = a.Ea,
                g = a.T;
            do {
                var h = f[g++];
                c |= (h & 127) << e;
                e += 7
            } while (e < 32 && h & 128);
            if (e > 32)
                for (d |= (h & 127) >> 4, e = 3; e < 32 && h & 128; e += 7) h = f[g++], d |= (h & 127) << e;
            zj(a, g);
            if (!(h & 128)) return b(c >>> 0, d >>> 0);
            throw Error("ca");
        },
        zj = function(a, b) {
            a.T = b;
            if (b > a.Pa) throw Error("da`" + b + "`" + a.Pa);
        },
        Bj = function(a) {
            var b = a.Ea,
                c = a.T,
                d = b[c++],
                e = d & 127;
            if (d & 128 && (d = b[c++], e |= (d & 127) << 7, d & 128 && (d = b[c++], e |= (d & 127) << 14, d & 128 && (d = b[c++], e |= (d & 127) << 21, d & 128 && (d = b[c++], e |= d << 28, d & 128 && b[c++] & 128 && b[c++] & 128 &&
                    b[c++] & 128 && b[c++] & 128 && b[c++] & 128))))) throw Error("ca");
            zj(a, c);
            return e
        },
        Cj = function(a) {
            return Bj(a) >>> 0
        },
        Dj = function(a) {
            return Aj(a, sj)
        },
        Ej = function(a) {
            var b = a.Ea,
                c = a.T,
                d = b[c + 0],
                e = b[c + 1],
                f = b[c + 2];
            b = b[c + 3];
            a.advance(4);
            return (d << 0 | e << 8 | f << 16 | b << 24) >>> 0
        },
        Fj = function(a) {
            for (var b = 0, c = a.T, d = c + 10, e = a.Ea; c < d;) {
                var f = e[c++];
                b |= f;
                if ((f & 128) === 0) return zj(a, c), !!(b & 127)
            }
            throw Error("ca");
        },
        Gj = function(a) {
            return Bj(a)
        },
        Hj = function(a, b) {
            if (b < 0) throw Error("ea`" + b);
            var c = a.T,
                d = c + b;
            if (d > a.Pa) throw Error("da`" +
                (a.Pa - c) + "`" + b);
            a.T = d;
            return c
        };
    xj.prototype.Rg = function(a, b) {
        var c = Hj(this, a),
            d = F(this.Ea);
        if (Ii) {
            var e;
            b ? (e = Gi) || (e = Gi = new TextDecoder("utf-8", {
                fatal: !0
            })) : (e = Hi) || (e = Hi = new TextDecoder("utf-8", {
                fatal: !1
            }));
            var f = c + a;
            d = c === 0 && f === d.length ? d : d.subarray(c, f);
            try {
                var g = e.decode(d)
            } catch (m) {
                if (b) {
                    if (Fi === void 0) {
                        try {
                            e.decode(new Uint8Array([128]))
                        } catch (u) {}
                        try {
                            e.decode(new Uint8Array([97])), Fi = !0
                        } catch (u) {
                            Fi = !1
                        }
                    }
                    b = !Fi
                }
                b && (Gi = void 0);
                throw m;
            }
        } else {
            a = c + a;
            g = [];
            for (var h = null, k, l; c < a;) k = d[c++], k < 128 ? g.push(k) : k < 224 ? c >= a ? Di(b, g) : (l =
                d[c++], k < 194 || (l & 192) !== 128 ? (c--, Di(b, g)) : (k = (k & 31) << 6 | l & 63, F(k >= 128 && k <= 2047), g.push(k))) : k < 240 ? c >= a - 1 ? Di(b, g) : (l = d[c++], (l & 192) !== 128 || k === 224 && l < 160 || k === 237 && l >= 160 || ((e = d[c++]) & 192) !== 128 ? (c--, Di(b, g)) : (k = (k & 15) << 12 | (l & 63) << 6 | e & 63, F(k >= 2048 && k <= 65535), F(k < 55296 || k > 57343), g.push(k))) : k <= 244 ? c >= a - 2 ? Di(b, g) : (l = d[c++], (l & 192) !== 128 || (k << 28) + (l - 144) >> 30 !== 0 || ((e = d[c++]) & 192) !== 128 || ((f = d[c++]) & 192) !== 128 ? (c--, Di(b, g)) : (k = (k & 7) << 18 | (l & 63) << 12 | (e & 63) << 6 | f & 63, F(k >= 65536 && k <= 1114111), k -= 65536, g.push((k >>
                10 & 1023) + 55296, (k & 1023) + 56320))) : Di(b, g), g.length >= 8192 && (h = Ei(h, g), g.length = 0);
            F(c === a, "expected " + c + " === " + a);
            g = Ei(h, g)
        }
        return g
    };
    xj.prototype.hf = function(a) {
        if (a == 0) return Vi || (Vi = new Ui(null, Si));
        var b = Hj(this, a);
        if (this.sd && this.pe) b = this.Ea.subarray(b, b + a);
        else {
            var c = F(this.Ea);
            a = b + a;
            b = b === a ? new Uint8Array(0) : ij ? c.slice(b, a) : new Uint8Array(c.subarray(b, a))
        }
        Eb(b, Uint8Array);
        return b.length == 0 ? Vi || (Vi = new Ui(null, Si)) : new Ui(b, Si)
    };
    var yj = [];
    F(!0);
    var Jj = function(a, b, c, d) {
            if (yj.length) {
                var e = yj.pop();
                e.init(a, b, c, d);
                a = e
            } else a = new xj(a, b, c, d);
            this.o = a;
            this.tb = this.o.ga();
            this.m = this.Qd = this.kc = -1;
            Ij(this, d)
        },
        Ij = function(a, b) {
            b = b === void 0 ? {} : b;
            a.ze = b.ze === void 0 ? !1 : b.ze
        },
        Lj = function(a, b, c, d) {
            if (Kj.length) {
                var e = Kj.pop();
                Ij(e, d);
                e.o.init(a, b, c, d);
                return e
            }
            return new Jj(a, b, c, d)
        };
    Jj.prototype.Fe = function() {
        this.o.clear();
        this.m = this.kc = this.Qd = -1;
        Kj.length < 100 && Kj.push(this)
    };
    Jj.prototype.ga = function() {
        return this.o.ga()
    };
    Jj.prototype.reset = function() {
        this.o.reset();
        this.tb = this.o.ga();
        this.m = this.kc = this.Qd = -1
    };
    Jj.prototype.advance = function(a) {
        this.o.advance(a)
    };
    var Mj = function(a) {
            var b = a.o;
            if (b.T == b.Pa) return !1;
            a.Qd !== -1 && (b = a.o.ga(), a.o.T = a.tb, Cj(a.o), a.m === 4 || a.m === 3 ? F(b === a.o.ga(), "Expected to not advance the cursor.  Group tags do not have values.") : F(b > a.o.ga(), "Expected to read the field, did you forget to call a read or skip method?"), a.o.T = b);
            a.tb = a.o.ga();
            b = Cj(a.o);
            var c = b >>> 3,
                d = b & 7;
            if (!(d >= 0 && d <= 5)) throw Error("Z`" + d + "`" + a.tb);
            if (c < 1) throw Error("$`" + c + "`" + a.tb);
            a.Qd = b;
            a.kc = c;
            a.m = d;
            return !0
        },
        Nj = function(a) {
            switch (a.m) {
                case 0:
                    a.m != 0 ? (xb("Invalid wire type for skipVarintField"),
                        Nj(a)) : Fj(a.o);
                    break;
                case 1:
                    F(a.m === 1);
                    a.o.advance(8);
                    break;
                case 2:
                    if (a.m != 2) xb("Invalid wire type for skipDelimitedField"), Nj(a);
                    else {
                        var b = Cj(a.o);
                        a.o.advance(b)
                    }
                    break;
                case 5:
                    F(a.m === 5);
                    a.o.advance(4);
                    break;
                case 3:
                    b = a.kc;
                    do {
                        if (!Mj(a)) throw Error("aa");
                        if (a.m == 4) {
                            if (a.kc != b) throw Error("ba");
                            break
                        }
                        Nj(a)
                    } while (1);
                    break;
                default:
                    throw Error("Z`" + a.m + "`" + a.tb);
            }
        },
        Oj = function(a, b, c) {
            F(a.m == 2);
            var d = a.o.Pa,
                e = Cj(a.o),
                f = a.o.ga() + e,
                g = f - d;
            g <= 0 && (a.o.setEnd(f), c(b, a, void 0, void 0, void 0), g = f - a.o.ga());
            if (g) throw Error("Y`" +
                e + "`" + (e - g));
            a.o.T = f;
            a.o.setEnd(d)
        },
        Pj = function(a) {
            F(a.m == 0);
            return Bj(a.o)
        },
        Qj = function(a) {
            F(a.m == 0);
            return Cj(a.o)
        },
        Rj = function(a) {
            F(a.m == 0);
            return Dj(a.o)
        },
        Sj = function(a) {
            F(a.m == 0);
            return Bj(a.o)
        };
    Jj.prototype.Rg = function() {
        return Tj(this)
    };
    var Tj = function(a) {
        F(a.m == 2);
        var b = Cj(a.o);
        return a.o.Rg(b, !0)
    };
    Jj.prototype.hf = function() {
        F(this.m == 2);
        var a = Cj(this.o);
        return this.o.hf(a)
    };
    var Uj = function(a, b, c) {
            F(a.m == 2);
            var d = Cj(a.o);
            for (d = a.o.ga() + d; a.o.ga() < d;) c.push(b(a.o))
        },
        Kj = [];
    var Vj = typeof Symbol === "function" && typeof Symbol() === "symbol";

    function Wj(a, b, c) {
        return typeof Symbol === "function" && typeof Symbol() === "symbol" ? (c === void 0 ? 0 : c) && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol() : b
    }
    var Xj = Wj("jas", void 0, !0),
        Yj = Wj("defaultInstance", "0di"),
        Zj = Wj("unknownBinaryFields", Symbol()),
        ak = Wj("unknownBinaryThrottleKey", "0ub"),
        bk = Wj("unknownBinaryThrottleKey", "0ubs"),
        ck = Wj("unknownBinarySerializeBinaryThrottleKey", "0ubsb"),
        dk = Wj("m_m", "xk", !0),
        ek = Wj("validPivotSelector", "vps"),
        fk = Wj("lazilyParseLateLoadedExtensions"),
        gk = Wj("knownMessageType", "knownMessageType"),
        hk = Wj("destroyedStructure", "destroyedStructure");
    F(Math.round(Math.log2(Math.max.apply(Math, y(Object.values({
        bk: 1,
        ak: 2,
        Zj: 4,
        gk: 8,
        jk: 16,
        ek: 32,
        Nj: 64,
        Xj: 128,
        Rj: 256,
        ik: 512,
        Sj: 1024,
        Yj: 2048,
        fk: 4096,
        dk: 8192
    }))))) === 13);
    var ik = {
            oi: {
                value: 0,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        },
        jk = Object.defineProperties,
        X = Vj ? G(Xj) : "oi",
        kk, lk = [];
    mk(lk, 7);
    kk = Object.freeze(lk);

    function nk(a) {
        return I(a, "state is only maintained on arrays.")[X] | 0
    }

    function ok(a, b) {
        F((b & 16777215) === b);
        I(a, "state is only maintained on arrays.");
        Vj || X in a || jk(a, ik);
        a[X] |= b
    }

    function mk(a, b) {
        F((b & 16777215) === b);
        I(a, "state is only maintained on arrays.");
        Vj || X in a || jk(a, ik);
        a[X] = b
    }

    function Y(a, b, c) {
        (c === void 0 || !c || b & 2048) && F(b & 64, "state for messages must be constructed");
        F((b & 5) === 0, "state for messages should not contain repeated field state");
        F((b & 8192) === 0, "state for messages should not contain map field state");
        if (b & 64) {
            F(b & 64);
            c = b >> 14 & 1023 || 536870912;
            var d = a.length;
            F(b & 64);
            F(c + (b & 128 ? 0 : -1) >= d - 1, "pivot %s is pointing at an index earlier than the last index of the array, length: %s", c, d);
            b & 128 && F(typeof a[0] === "string", "arrays with a message_id bit must have a string in the first position, got: %s",
                a[0])
        }
    }

    function pk(a) {
        var b = I(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, b);
        return b
    }

    function qk(a) {
        var b = I(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, b);
        return b
    }

    function rk(a) {
        return !!((I(a, "state is only maintained on arrays.")[X] | 0) & 2)
    }

    function sk(a, b) {
        yb(b);
        F(b > 0 && b <= 1023 || 536870912 === b, "pivot must be in the range [1, 1024) or NO_PIVOT got %s", b);
        return a & -16760833 | (b & 1023) << 14
    }

    function tk(a) {
        F(a & 64);
        return a & 128 ? 0 : -1
    }
    var uk = Object.getOwnPropertyDescriptor(Array.prototype, "Ai");
    Object.defineProperties(Array.prototype, {
        Ai: {
            get: function() {
                var a = vk(this);
                return uk ? uk.get.call(this) + "|" + a : a
            },
            configurable: !0,
            enumerable: !1
        }
    });

    function vk(a) {
        function b(e, f) {
            e & c && d.push(f)
        }
        var c = I(a, "state is only maintained on arrays.")[X] | 0,
            d = [];
        b(1, "IS_REPEATED_FIELD");
        b(2, "IS_IMMUTABLE_ARRAY");
        b(4, "IS_API_FORMATTED");
        b(512, "STRING_FORMATTED");
        b(1024, "GBIGINT_FORMATTED");
        b(1024, "BINARY");
        b(8, "ONLY_MUTABLE_VALUES");
        b(16, "UNFROZEN_SHARED");
        b(32, "MUTABLE_REFERENCES_ARE_OWNED");
        b(64, "CONSTRUCTED");
        b(128, "HAS_MESSAGE_ID");
        b(256, "FROZEN_ARRAY");
        b(2048, "HAS_WRAPPER");
        b(4096, "MUTABLE_SUBSTRUCTURES");
        b(8192, "KNOWN_MAP_ARRAY");
        c & 64 && (F(c & 64), a =
            c >> 14 & 1023 || 536870912, a !== 536870912 && d.push("pivot: " + a));
        return d.join(",")
    };
    var wk = Vj && Math.random() < .5,
        xk = wk ? Symbol() : void 0;

    function yk(a) {
        F(Z(a));
        return wk ? a[G(xk)] : a.C
    }
    var zk, Ak = typeof dk === "symbol",
        Bk = {};

    function Z(a) {
        var b = a[dk],
            c = b === Bk;
        F(!zk || c === a instanceof zk);
        if (Ak && b && !c) throw Error("ja");
        return c
    }

    function Ck(a) {
        return a != null && Z(a)
    }

    function Dk(a, b) {
        yb(a);
        F(a > 0);
        F(b === 0 || b === -1);
        return a + b
    }

    function Ek(a, b) {
        F(b === Fk || b === void 0);
        return a + (b ? 0 : -1)
    }

    function Gk(a, b) {
        yb(a);
        F(a >= 0);
        F(b === 0 || b === -1);
        return a - b
    }

    function Hk(a, b) {
        if (b === void 0) {
            if (b = !Ik(a)) F(Z(a)), a = wk ? a[G(xk)] : a.C, b = I(a, "state is only maintained on arrays.")[X] | 0, Y(a, b), b = !!(2 & b);
            return b
        }
        F(Z(a));
        var c = wk ? a[G(xk)] : a.C;
        var d = I(c, "state is only maintained on arrays.")[X] | 0;
        Y(c, d);
        F(b === d);
        return !!(2 & b) && !Ik(a)
    }
    var Jk = {};

    function Ik(a) {
        var b = a.Lh,
            c;
        (c = !b) || (F(Z(a)), a = wk ? a[G(xk)] : a.C, c = I(a, "state is only maintained on arrays.")[X] | 0, Y(a, c), c = !!(2 & c));
        F(c);
        F(b === void 0 || b === Jk);
        return b === Jk
    }

    function Kk(a, b) {
        F(Z(a));
        var c = wk ? a[G(xk)] : a.C;
        var d = I(c, "state is only maintained on arrays.")[X] | 0;
        Y(c, d);
        F(b === !!(2 & d));
        a.Lh = b ? Jk : void 0
    }
    var Lk = Symbol("exempted jspb subclass"),
        Mk = typeof Symbol != "undefined" && typeof Symbol.hasInstance != "undefined";

    function Nk() {}

    function Ok(a, b) {
        var c = nk(I(a));
        b || F(!(c & 2 && c & 4 || c & 256) || Object.isFrozen(a));
        Pk(a)
    }

    function Pk(a) {
        a = I(a, "state is only maintained on arrays.")[X] | 0;
        var b = a & 4,
            c = (512 & a ? 1 : 0) + (1024 & a ? 1 : 0);
        F(b && c <= 1 || !b && c === 0, "Expected at most 1 type-specific formatting bit, but got " + c + " with state: " + a)
    }
    var Qk = Object.freeze({}),
        Rk = Symbol("debugExtensions");

    function Sk(a, b, c) {
        F(b & 64);
        F(b & 64);
        var d = b & 128 ? 0 : -1;
        var e = a.length,
            f;
        if (f = !!e) f = a[e - 1], f = f != null && typeof f === "object" && !f[hk] && f.constructor === Object;
        var g = e + (f ? -1 : 0),
            h = a[e - 1];
        F(!!f === (h != null && typeof h === "object" && !h[hk] && h.constructor === Object));
        for (b = b & 128 ? 1 : 0; b < g; b++) h = a[b], c(Gk(b, d), h);
        if (f) {
            a = a[e - 1];
            for (var k in a) !isNaN(k) && c(+k, a[k])
        }
    }
    var Fk = {};

    function Tk(a, b) {
        a = I(a, "state is only maintained on arrays.")[X] | 0;
        F(a & 64);
        a & 128 ? F(b === Fk) : F(b === void 0)
    }

    function Uk(a) {
        F(a & 64);
        return a & 128 ? Fk : void 0
    };
    var Vk = {};

    function Wk(a) {
        a = Error(a);
        Nb(a, "warning");
        return a
    }

    function Xk(a, b, c) {
        if (a != null) {
            var d;
            var e = (d = Vk) != null ? d : Vk = {};
            d = e[a] || 0;
            d >= b || (e[a] = d + 1, a = Error(c), Nb(a, "incident"), Ph(a))
        }
    };

    function Yk(a) {
        return Array.prototype.slice.call(a)
    };
    var Zk = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        $k = typeof BigInt === "function" ? BigInt.asUintN : void 0,
        al = Number.isSafeInteger,
        bl = Number.isFinite,
        cl = Math.trunc,
        dl = Number.MAX_SAFE_INTEGER;

    function el(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function fl(a) {
        return a.displayName || a.name || "unknown type name"
    }

    function gl(a) {
        if (a == null || typeof a === "boolean") return a;
        if (typeof a === "number") return !!a
    }
    var hl = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function il(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return bl(a);
            case "string":
                return hl.test(a);
            default:
                return !1
        }
    }

    function jl(a) {
        if (!bl(a)) throw a = "Expected enum as finite number but got " + Ja(a) + ": " + a, Wk(a);
        return a | 0
    }

    function kl(a) {
        return a == null ? a : bl(a) ? a | 0 : void 0
    }

    function ll(a) {
        return "Expected int32 as finite number but got " + Ja(a) + ": " + a
    }

    function ml(a) {
        if (typeof a !== "number") throw Wk(ll(a));
        if (!bl(a)) throw Wk(ll(a));
        return a | 0
    }

    function nl(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return bl(a) ? a | 0 : void 0
    }

    function ol(a) {
        return "Expected uint32 as finite number but got " + Ja(a) + ": " + a
    }

    function pl(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return bl(a) ? a >>> 0 : void 0
    }

    function ql(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String(Zk(64, a));
        if (il(a)) {
            if (b === "string") return F(il(a)), F(!0), b = cl(Number(a)), al(b) ? a = String(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), F(a.indexOf(".") === -1), b = a.length, (a[0] === "-" ? b < 20 || b === 20 && a <= "-9223372036854775808" : b < 19 || b === 19 && a <= "9223372036854775807") || (wj(a), a = uj(jj, kj))), a;
            if (b === "number") {
                F(il(a));
                F(!0);
                a = cl(a);
                if (!al(a)) {
                    F(!al(a));
                    F(Number.isInteger(a));
                    nj(a);
                    b = jj;
                    var c = kj;
                    if (a = c & 2147483648) b = ~b + 1 >>> 0,
                        c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
                    b = qj(b, c);
                    a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
                }
                return a
            }
        }
    }

    function rl(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String($k(64, a));
        if (il(a)) {
            if (b === "string") return F(il(a)), F(!0), b = cl(Number(a)), al(b) && b >= 0 ? a = String(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), F(a.indexOf(".") === -1), a[0] === "-" ? b = !1 : (b = a.length, b = b < 20 ? !0 : b === 20 && a <= "18446744073709551615"), b || (wj(a), a = rj(jj, kj))), a;
            if (b === "number") return F(il(a)), F(!0), a = cl(a), a >= 0 && al(a) || (F(a < 0 || a > dl), F(Number.isInteger(a)), nj(a), a = qj(jj, kj)), a
        }
    }

    function sl(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function tl(a, b) {
        if (!(a instanceof b)) throw Error("oa`" + fl(b) + "`" + (a && fl(a.constructor)));
    }

    function ul(a, b, c) {
        if (Ck(a)) return a;
        if (Array.isArray(a)) {
            var d = nk(a);
            c = d | c & 32 | c & 2;
            c !== d && mk(a, c);
            return new b(a)
        }
    };
    var vl = function(a, b) {
            this.Qc = a >>> 0;
            this.Mc = b >>> 0
        },
        xl = function(a) {
            if (!a) return wl || (wl = new vl(0, 0));
            if (!/^\d+$/.test(a)) return null;
            wj(a);
            return new vl(jj, kj)
        },
        wl, yl = function(a, b) {
            this.Qc = a >>> 0;
            this.Mc = b >>> 0
        },
        Al = function(a) {
            if (!a) return zl || (zl = new yl(0, 0));
            if (!/^-?\d+$/.test(a)) return null;
            wj(a);
            return new yl(jj, kj)
        },
        zl;
    var Bl = function() {
        this.J = []
    };
    Bl.prototype.length = function() {
        return this.J.length
    };
    Bl.prototype.end = function() {
        var a = this.J;
        this.J = [];
        return a
    };
    Bl.prototype.jb = function(a, b) {
        F(a == Math.floor(a));
        F(b == Math.floor(b));
        F(a >= 0 && a < 4294967296);
        for (F(b >= 0 && b < 4294967296); b > 0 || a > 127;) this.J.push(a & 127 | 128), a = (a >>> 7 | b << 25) >>> 0, b >>>= 7;
        this.J.push(a)
    };
    Bl.prototype.Jf = function(a, b) {
        F(a == Math.floor(a));
        F(b == Math.floor(b));
        F(a >= 0 && a < 4294967296);
        F(b >= 0 && b < 4294967296);
        this.Ka(a);
        this.Ka(b)
    };
    var Cl = function(a, b) {
            F(b == Math.floor(b));
            for (F(b >= 0 && b < 4294967296); b > 127;) a.J.push(b & 127 | 128), b >>>= 7;
            a.J.push(b)
        },
        Dl = function(a, b) {
            F(b == Math.floor(b));
            F(b >= -2147483648 && b < 2147483648);
            if (b >= 0) Cl(a, b);
            else {
                for (var c = 0; c < 9; c++) a.J.push(b & 127 | 128), b >>= 7;
                a.J.push(1)
            }
        };
    n = Bl.prototype;
    n.Ka = function(a) {
        F(a == Math.floor(a));
        F(a >= 0 && a < 4294967296);
        this.J.push(a >>> 0 & 255);
        this.J.push(a >>> 8 & 255);
        this.J.push(a >>> 16 & 255);
        this.J.push(a >>> 24 & 255)
    };
    n.rh = function(a) {
        F(a == Math.floor(a));
        F(a >= 0 && a < 1.8446744073709552E19);
        mj(a);
        this.Ka(jj);
        this.Ka(kj)
    };
    n.ph = function(a) {
        F(a == Math.floor(a));
        F(a >= -2147483648 && a < 2147483648);
        this.J.push(a >>> 0 & 255);
        this.J.push(a >>> 8 & 255);
        this.J.push(a >>> 16 & 255);
        this.J.push(a >>> 24 & 255)
    };
    n.qh = function(a) {
        F(a == Math.floor(a));
        F(a >= -0x7fffffffffffffff && a < 0x7fffffffffffffff);
        nj(a);
        this.Jf(jj, kj)
    };
    n.If = function(a) {
        F(a == Infinity || a == -Infinity || isNaN(a) || typeof a === "number" && a >= -3.4028234663852886E38 && a <= 3.4028234663852886E38);
        var b = pj(4);
        b.setFloat32(0, +a, !0);
        kj = 0;
        jj = b.getUint32(0, !0);
        this.Ka(jj)
    };
    n.Hf = function(a) {
        F(typeof a === "number" || a === "Infinity" || a === "-Infinity" || a === "NaN");
        var b = pj(8);
        b.setFloat64(0, +a, !0);
        jj = b.getUint32(0, !0);
        kj = b.getUint32(4, !0);
        this.Ka(jj);
        this.Ka(kj)
    };
    n.Gf = function(a) {
        F(typeof a === "boolean" || typeof a === "number");
        this.J.push(a ? 1 : 0)
    };
    n.fe = function(a) {
        F(a == Math.floor(a));
        F(a >= -2147483648 && a < 2147483648);
        Dl(this, a)
    };
    var El = function() {
            this.ne = [];
            this.Qb = 0;
            this.G = new Bl
        },
        Fl = function(a, b) {
            b.length !== 0 && (a.ne.push(b), a.Qb += b.length)
        },
        Hl = function(a, b) {
            Gl(a, b, 2);
            b = a.G.end();
            Fl(a, b);
            b.push(a.Qb);
            return b
        },
        Il = function(a, b) {
            var c = b.pop();
            c = a.Qb + a.G.length() - c;
            for (F(c >= 0); c > 127;) b.push(c & 127 | 128), c >>>= 7, a.Qb++;
            b.push(c);
            a.Qb++
        },
        Gl = function(a, b, c) {
            F(b >= 1 && b == Math.floor(b));
            Cl(a.G, b * 8 + c)
        },
        Jl = function(a, b, c) {
            if (c != null) switch (Gl(a, b, 0), typeof c) {
                case "number":
                    a = a.G;
                    F(c == Math.floor(c));
                    F(c >= 0 && c < 1.8446744073709552E19);
                    nj(c);
                    a.jb(jj, kj);
                    break;
                case "bigint":
                    c = BigInt.asUintN(64, c);
                    c = new vl(Number(c & BigInt(4294967295)), Number(c >> BigInt(32)));
                    a.G.jb(c.Qc, c.Mc);
                    break;
                default:
                    c = xl(c), a.G.jb(c.Qc, c.Mc)
            }
        };
    n = El.prototype;
    n.ph = function(a, b) {
        b != null && (Kl(a, b, b >= -2147483648 && b < 2147483648), b != null && (Ll(a, b), Gl(this, a, 0), Dl(this.G, b)))
    };
    n.qh = function(a, b) {
        if (b != null) {
            switch (typeof b) {
                case "string":
                    Kl(a, b, Al(b));
                    break;
                case "number":
                    Kl(a, b, b >= -0x7fffffffffffffff && b < 0x7fffffffffffffff);
                    break;
                default:
                    Kl(a, b, b >= BigInt(-0x7fffffffffffffff) && b < BigInt(0x7fffffffffffffff))
            }
            if (b != null) switch (Gl(this, a, 0), typeof b) {
                case "number":
                    a = this.G;
                    F(b == Math.floor(b));
                    F(b >= -0x7fffffffffffffff && b < 0x7fffffffffffffff);
                    nj(b);
                    a.jb(jj, kj);
                    break;
                case "bigint":
                    b = BigInt.asUintN(64, b);
                    b = new yl(Number(b & BigInt(4294967295)), Number(b >> BigInt(32)));
                    this.G.jb(b.Qc,
                        b.Mc);
                    break;
                default:
                    b = Al(b), this.G.jb(b.Qc, b.Mc)
            }
        }
    };
    n.Ka = function(a, b) {
        b != null && (Kl(a, b, b >= 0 && b < 4294967296), b != null && (Gl(this, a, 0), Cl(this.G, b)))
    };
    n.rh = function(a, b) {
        if (b != null) {
            switch (typeof b) {
                case "string":
                    Kl(a, b, xl(b));
                    break;
                case "number":
                    Kl(a, b, b >= 0 && b < 1.8446744073709552E19);
                    break;
                default:
                    Kl(a, b, b >= BigInt(0) && b < BigInt(1.8446744073709552E19))
            }
            Jl(this, a, b)
        }
    };
    n.If = function(a, b) {
        b != null && (Gl(this, a, 5), this.G.If(b))
    };
    n.Hf = function(a, b) {
        b != null && (Gl(this, a, 1), this.G.Hf(b))
    };
    n.Gf = function(a, b) {
        b != null && (Kl(a, b, typeof b === "boolean" || typeof b === "number"), Gl(this, a, 0), this.G.Gf(b))
    };
    n.fe = function(a, b) {
        b != null && (b = parseInt(b, 10), Ll(a, b), Gl(this, a, 0), Dl(this.G, b))
    };
    n.Jf = function(a, b) {
        Gl(this, a, 1);
        this.G.Jf(b)
    };
    n.jb = function(a, b) {
        Gl(this, a, 0);
        this.G.jb(b)
    };

    function Ll(a, b) {
        Kl(a, b, b === Math.floor(b));
        Kl(a, b, b >= -2147483648 && b < 2147483648)
    }

    function Kl(a, b, c) {
        c || xb("for [" + b + "] at [" + a + "]")
    };

    function Ml() {
        var a = function() {
            throw Error("pa");
        };
        Object.setPrototypeOf(a, a.prototype);
        return a
    }
    var Nl = Ml(),
        Ol = Ml(),
        Pl = Ml(),
        Ql = Ml(),
        Rl = Ml(),
        Sl = Ml(),
        Tl = Ml(),
        Ul = Ml(),
        Vl = Ml(),
        Wl = Ml(),
        Xl = Ml(),
        Yl = Ml();

    function Zl(a) {
        return a
    }
    Zl[ek] = {};

    function $l(a) {
        return a
    };
    var am = function() {
        throw Error("qa");
    };
    if (Mk) {
        var bm = function() {
                throw Error("ra");
            },
            cm = {};
        Object.defineProperties(am, (cm[Symbol.hasInstance] = {
            value: bm,
            configurable: !1,
            writable: !1,
            enumerable: !1
        }, cm));
        F(am[Symbol.hasInstance] === bm, "defineProperties did not work: was it monkey-patched?")
    };

    function dm(a) {
        var b = Ma(Zj);
        return b ? I(a)[b] : void 0
    }
    var em = function() {},
        fm = function(a, b) {
            for (var c in a) !isNaN(c) && b(a, +c, I(a[c]))
        },
        gm = function(a) {
            var b = new em;
            fm(a, function(c, d, e) {
                b[d] = Yk(e)
            });
            b.nf = a.nf;
            return b
        },
        hm = {
            nj: !0
        };

    function im(a, b, c) {
        var d = d === void 0 ? !1 : d;
        if (Ma(fk) && Ma(Zj) && c === fk) {
            F(Z(a));
            c = wk ? a[G(xk)] : a.C;
            var e = c[Zj];
            if (!e) return;
            if (e = e.nf) try {
                e(c, b, hm);
                return
            } catch (f) {
                throw Error("sa`" + b);
            }
        }
        d && (F(Z(a)), a = yk(a), I(a), (d = Ma(Zj)) && d in a && (a = a[d]) && delete a[b])
    }

    function jm(a, b) {
        F(Z(a));
        F(Z(a));
        a = wk ? a[G(xk)] : a.C;
        I(a);
        var c = Ma(Zj),
            d;
        Vj && c && ((d = a[c]) == null ? void 0 : d[b]) != null && Xk(ak, 3, "0ub:" + b)
    }

    function km(a, b) {
        b < 100 || Xk(bk, 1, "0ubs:" + b)
    };

    function lm(a, b, c, d, e) {
        var f = d !== void 0;
        d = !!d;
        var g = Ma(Zj),
            h;
        !f && Vj && g && (h = a[g]) && fm(h, km);
        g = [];
        var k = a.length;
        h = 4294967295;
        var l = !1,
            m = !!(b & 64);
        if (m) {
            F(b & 64);
            var u = b & 128 ? 0 : -1
        } else u = void 0;
        if (!(b & 1)) {
            var t = k && a[k - 1];
            t == null || typeof t !== "object" || t[hk] || t.constructor !== Object ? t = void 0 : (k--, h = k);
            if (m && !(b & 128) && !f) {
                l = !0;
                var r;
                b = (r = mm) != null ? r : Zl;
                h = Dk(b(Gk(h, G(u)), G(u), a, t, e), G(u))
            }
        }
        e = void 0;
        for (r = 0; r < k; r++)
            if (b = a[r], b != null && (b = c(b, d)) != null)
                if (m && r >= h) {
                    nm();
                    var w = Gk(r, G(u)),
                        v = void 0;
                    ((v = e) != null ? v :
                        e = {})[w] = b
                } else g[r] = b;
        if (t)
            for (var z in t) k = t[z], k != null && (k = c(k, d)) != null && (r = +z, b = void 0, m && !Number.isNaN(r) && (b = Dk(r, G(u))) < h ? (nm(), g[G(b)] = k) : (r = void 0, ((r = e) != null ? r : e = {})[z] = k));
        e && (l ? g.push(e) : (F(h < 4294967295), g[h] = e));
        f && Ma(Zj) && (I(g), I(a), F(g[Zj] === void 0), (a = dm(a)) && a instanceof em && (g[Zj] = gm(a)));
        return g
    }

    function om(a) {
        G(a);
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return hj(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    Ok(a);
                    var b = I(a, "state is only maintained on arrays.")[X] | 0;
                    return a.length === 0 && b & 1 ? void 0 : lm(a, b, om)
                }
                if (Ck(a)) return pm(a);
                if (a instanceof Ui) {
                    b = a.ld;
                    if (b == null) a = "";
                    else if (typeof b === "string") a = b;
                    else {
                        if (Ni) {
                            for (var c = "", d = 0, e = b.length - 10240; d < e;) c += String.fromCharCode.apply(null, b.subarray(d, d += 10240));
                            c +=
                                String.fromCharCode.apply(null, d ? b.subarray(d) : b);
                            b = btoa(c)
                        } else b = Th(b);
                        a = a.ld = b
                    }
                    return a
                }
                F(!(a instanceof Uint8Array));
                return
        }
        return a
    }
    var mm;

    function qm(a) {
        F(!mm);
        return pm(a)
    }

    function pm(a) {
        F(Z(a));
        var b = wk ? a[G(xk)] : a.C;
        var c = I(b, "state is only maintained on arrays.")[X] | 0;
        Y(b, c);
        return lm(b, c, om, void 0, a.constructor)
    }

    function nm() {
        var a, b = (a = mm) != null ? a : Zl;
        F(b !== $l)
    };
    if (typeof Proxy !== "undefined") {
        var sm = rm;
        new Proxy({}, {
            getPrototypeOf: sm,
            setPrototypeOf: sm,
            isExtensible: sm,
            preventExtensions: sm,
            getOwnPropertyDescriptor: sm,
            defineProperty: sm,
            has: sm,
            get: sm,
            set: sm,
            deleteProperty: sm,
            apply: sm,
            construct: sm
        })
    }

    function rm(a, b) {
        if (b === hk) return !0;
        throw Error("xa");
    };
    var tm, um;

    function vm(a) {
        switch (typeof a) {
            case "boolean":
                return tm || (tm = [0, void 0, !0]);
            case "number":
                return a > 0 ? void 0 : a === 0 ? um || (um = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return I(a), F(a.length === 2 || a.length === 3 && a[2] === !0), F(a[0] == null || typeof a[0] === "number" && a[0] >= 0), F(a[1] == null || typeof a[1] === "string"), a
        }
    }

    function wm(a, b) {
        I(b);
        return xm(a, b[0], b[1])
    }

    function xm(a, b, c, d) {
        d = d === void 0 ? 0 : d;
        if (a != null)
            for (var e = 0; e < a.length; e++) {
                var f = a[e];
                Array.isArray(f) && Ok(f)
            }
        if (a == null) e = 32, c ? (a = [c], e |= 128) : a = [], b && (e = sk(e, b));
        else {
            if (!Array.isArray(a)) throw Error("za`" + JSON.stringify(a) + "`" + Ja(a));
            e = I(a, "state is only maintained on arrays.")[X] | 0;
            if (Og && 1 & e) throw Error("Aa");
            2048 & e && !(2 & e) && ym();
            if (Object.isFrozen(a) || !Object.isExtensible(a) || Object.isSealed(a)) throw Error("Ba");
            if (e & 256) throw Error("Ca");
            if (e & 64) return (e | d) !== e && mk(a, e |= d), Y(a, e), a;
            if (c &&
                (e |= 128, c !== a[0])) throw Error("Da`" + c + "`" + JSON.stringify(a[0]) + "`" + Ja(a[0]));
            a: {
                c = a;e |= 64;
                var g = c.length;
                if (g) {
                    var h = g - 1;
                    f = c[h];
                    if (f != null && typeof f === "object" && !f[hk] && f.constructor === Object) {
                        b = tk(e);
                        g = Gk(h, b);
                        if (g >= 1024) throw Error("Fa`" + g);
                        for (var k in f) h = +k, h < g && (h = Dk(h, b), F(c[h] == null), c[h] = f[k], delete f[k]);
                        e = sk(e, g);
                        break a
                    }
                }
                if (b) {
                    k = Math.max(b, Gk(g, tk(e)));
                    if (k > 1024) throw Error("Ga`" + g);
                    e = sk(e, k)
                }
            }
        }
        mk(a, e | 64 | d);
        return a
    }

    function ym() {
        if (Og) throw Error("Ea");
    };

    function zm(a) {
        F(!(2 & a));
        F(!(2048 & a));
        return !(4096 & a) && !(16 & a)
    }

    function Am(a, b) {
        G(a);
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            Ok(a);
            var c = I(a, "state is only maintained on arrays.")[X] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (b && zm(c) ? (ok(a, 34), c & 4 && Object.freeze(a)) : a = Bm(a, c, !1, b && !(c & 16)));
            return a
        }
        if (Ck(a)) return F(Ck(a)), b = yk(a), c = qk(b), Hk(a, c) ? a : Cm(a, b, c) ? Dm(a, b) : Bm(b, c);
        if (a instanceof Ui) return a;
        F(!(a instanceof Uint8Array))
    }

    function Dm(a, b, c) {
        a = new a.constructor(b);
        c && Kk(a, !0);
        a.Pi = Jk;
        return a
    }

    function Bm(a, b, c, d) {
        F(b === (I(a, "state is only maintained on arrays.")[X] | 0));
        d != null || (d = !!(34 & b));
        a = lm(a, b, Am, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        mk(a, b);
        return a
    }

    function Em(a) {
        if (!Ik(a)) return !1;
        var b;
        F(Z(a));
        var c = b = wk ? a[G(xk)] : a.C,
            d = I(c, "state is only maintained on arrays.")[X] | 0;
        Y(c, d);
        F(d & 2);
        b = Bm(b, d);
        ok(b, 2048);
        F(Z(a));
        I(b);
        wk ? a[G(xk)] = b : a.C = b;
        Kk(a, !1);
        a.Pi = void 0;
        return !0
    }

    function Fm(a) {
        var b;
        if (b = !Em(a)) {
            F(Z(a));
            b = wk ? a[G(xk)] : a.C;
            var c = I(b, "state is only maintained on arrays.")[X] | 0;
            Y(b, c);
            b = Hk(a, c)
        }
        if (b) throw Error("ka");
    }

    function Gm(a, b) {
        if (b === void 0) b = I(a, "state is only maintained on arrays.")[X] | 0, Y(a, b, !0);
        else {
            var c = I(a, "state is only maintained on arrays.")[X] | 0;
            Y(a, c, !0);
            F(b === c)
        }
        F(!(b & 2));
        b & 32 && !(b & 4096) && mk(a, b | 4096)
    }

    function Cm(a, b, c) {
        return Lk && a[Lk] ? !1 : c & 2 ? !0 : c & 32 && !(c & 4096) ? (mk(b, c | 2), Kk(a, !0), !0) : !1
    };
    var Im = function(a, b) {
            F(Object.isExtensible(a));
            F(Z(a));
            a = wk ? a[G(xk)] : a.C;
            b = Hm(a, b);
            (a = b !== null) || (a = void 0);
            if (a) return b
        },
        Hm = function(a, b, c, d) {
            Tk(a, c);
            if (b === -1) return null;
            var e = Ek(b, c);
            F(e === Dk(b, tk(I(a, "state is only maintained on arrays.")[X] | 0)));
            F(e >= 0);
            var f = a.length - 1;
            if (!(f < Ek(1, c))) {
                if (e >= f) {
                    var g = a[f];
                    if (g == null || typeof g !== "object" || g[hk] || g.constructor !== Object)
                        if (e === f) c = g;
                        else return;
                    else {
                        c = g[b];
                        var h = !0
                    }
                } else c = a[e];
                if (d && c != null) {
                    d = d(c);
                    if (d == null) return d;
                    if (!Object.is(d, c)) return h ?
                        g[b] = d : a[e] = d, d
                }
                return c
            }
        },
        Km = function(a, b, c) {
            Fm(a);
            F(Z(a));
            var d = wk ? a[G(xk)] : a.C;
            var e = I(d, "state is only maintained on arrays.")[X] | 0;
            Y(d, e);
            Jm(d, e, b, c);
            return a
        };

    function Jm(a, b, c, d, e) {
        Tk(a, e);
        var f = Ek(c, e);
        F(f === Dk(c, tk(I(a, "state is only maintained on arrays.")[X] | 0)));
        F(f >= 0);
        var g = a.length - 1;
        if (g >= Ek(1, e) && f >= g) {
            var h = a[g];
            if (h != null && typeof h === "object" && !h[hk] && h.constructor === Object) return h[c] = d, b
        }
        if (f <= g) return a[f] = d, b;
        d !== void 0 && ((g = b) == null && (b = I(a, "state is only maintained on arrays.")[X] | 0, Y(a, b), g = b), F(g & 64), g = g >> 14 & 1023 || 536870912, c >= g ? (F(g !== 536870912), d != null && (f = {}, a[Ek(g, e)] = (f[c] = d, f))) : a[f] = d);
        return b
    }
    var Mm = function(a, b, c, d) {
        F(Z(a));
        a = wk ? a[G(xk)] : a.C;
        var e = I(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, e);
        return Lm(a, e, b, c, d) !== void 0
    };

    function Nm(a, b) {
        if (!a) return a;
        F(rk(b) ? Hk(a) : !0);
        return a
    }

    function Om(a, b, c) {
        c = c === void 0 ? !1 : c;
        Ok(a, c);
        var d = I(a, "state is only maintained on arrays.")[X] | 0;
        F(d & 1);
        c || (F(Object.isFrozen(a) || d & 16), F(rk(b) ? Object.isFrozen(a) : !0))
    }

    function Pm(a, b, c, d, e) {
        F(Z(a));
        var f = wk ? a[G(xk)] : a.C;
        var g = I(f, "state is only maintained on arrays.")[X] | 0;
        Y(f, g);
        d = Hk(a, g) ? 1 : d;
        e = !!e || d === 3;
        d === 2 && Em(a) && (F(Z(a)), f = wk ? a[G(xk)] : a.C, g = I(f, "state is only maintained on arrays.")[X] | 0, Y(f, g));
        a = Qm(f, b);
        var h = a === kk ? 7 : I(a, "state is only maintained on arrays.")[X] | 0,
            k = Rm(h, g);
        Pk(a);
        var l = 4 & k ? !1 : !0;
        if (l) {
            4 & k && (a = Yk(a), h = 0, k = Sm(k, g), g = G(Jm(f, g, b, a)));
            for (var m = 0, u = 0; m < a.length; m++) {
                var t = c(a[m]);
                t != null && (a[u++] = t)
            }
            u < m && (a.length = u);
            c = (k | 4) & -513;
            k = c &= -1025;
            k &= -4097
        }
        k !== h && (mk(a, k), 2 & k && Object.freeze(a));
        a = Tm(a, k, f, g, b, d, l, e);
        Pk(a);
        e || Om(a, f);
        return a
    }

    function Tm(a, b, c, d, e, f, g, h) {
        var k = b;
        f === 1 || (f !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? Um(b) || (e = !a.length || g && !(4096 & b) || !!(32 & d) && zm(b), b |= e ? 2 : 256, b !== k && mk(a, b), Object.freeze(a)) : (f === 2 && Um(b) && (a = Yk(a), k = 0, b = Sm(b, d), d = G(Jm(c, d, e, a))), Um(b) || (h || (b |= 16), b !== k && mk(a, b)));
        2 & b || zm(b) || Gm(c, d);
        return a
    }

    function Qm(a, b, c) {
        a = Hm(a, b, c);
        return Array.isArray(a) ? a : kk
    }

    function Rm(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }

    function Um(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function Vm(a, b, c) {
        if (b & 2) throw Error("ka");
        var d = Uk(b),
            e = Qm(a, c, d),
            f = e === kk ? 7 : I(e, "state is only maintained on arrays.")[X] | 0,
            g = Rm(f, b);
        if (2 & g || Um(g) || 16 & g) g === f || Um(g) || mk(e, g), e = Yk(e), f = 0, g = Sm(g, b), G(Jm(a, b, c, e, d));
        g &= -13;
        g !== f && mk(e, g);
        return e
    }
    var Wm = function(a, b, c) {
        var d = I(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, d, !0);
        var e = Uk(d),
            f = Hm(a, c, e);
        if (Ck(f)) {
            if (!Hk(f)) return Em(f), F(Z(f)), wk ? f[G(xk)] : f.C;
            F(Z(f));
            var g = wk ? f[G(xk)] : f.C;
            F((I(g, "state is only maintained on arrays.")[X] | 0) & 2)
        } else Array.isArray(f) && (g = f);
        if (g) {
            var h = I(g, "state is only maintained on arrays.")[X] | 0;
            h & 2 && (g = Bm(g, h))
        }
        g = wm(g, b);
        g !== f && Jm(a, d, c, g, e);
        return g
    };

    function Lm(a, b, c, d, e) {
        var f = !1;
        d = Hm(a, d, e, function(g) {
            var h = ul(g, c, b);
            f = h !== g && h != null;
            return h
        });
        if (d != null) return f && !Hk(d) && Gm(a, b), Nm(d, a)
    }
    var Ym = function(a) {
            var b = Xm;
            F(Z(a));
            a = wk ? a[G(xk)] : a.C;
            var c = I(a, "state is only maintained on arrays.")[X] | 0;
            Y(a, c);
            (a = Lm(a, c, b, 2)) || (a = b[Yj]) || (a = new b, F(Z(a)), c = wk ? a[G(xk)] : a.C, ok(c, 34), a = b[Yj] = a);
            return a
        },
        Zm = function(a, b, c, d) {
            F(Z(a));
            var e = wk ? a[G(xk)] : a.C;
            var f = I(e, "state is only maintained on arrays.")[X] | 0;
            Y(e, f);
            b = Lm(e, f, b, c, d);
            if (b == null) return b;
            f = I(e, "state is only maintained on arrays.")[X] | 0;
            Y(e, f);
            if (!Hk(a, f)) {
                var g = b;
                F(Z(g));
                var h = wk ? g[G(xk)] : g.C;
                var k = I(h, "state is only maintained on arrays.")[X] |
                    0;
                Y(h, k);
                g = Hk(g, k) ? Cm(g, h, k) ? Dm(g, h, !0) : new g.constructor(Bm(h, k, !1)) : g;
                g !== b && (Em(a) && (F(Z(a)), e = wk ? a[G(xk)] : a.C, a = I(e, "state is only maintained on arrays.")[X] | 0, Y(e, a), f = a), b = g, f = Jm(e, f, c, b, d), Gm(e, f))
            }
            return Nm(b, e)
        },
        an = function(a) {
            var b = $m;
            F(Z(a));
            var c = wk ? a[G(xk)] : a.C;
            var d = I(c, "state is only maintained on arrays.")[X] | 0;
            Y(c, d);
            Hk(a, d);
            var e = !!e || !1;
            a = Qm(c, 10);
            var f = a === kk ? 7 : I(a, "state is only maintained on arrays.")[X] | 0,
                g = Rm(f, d),
                h = !(4 & g);
            if (h) {
                var k = a,
                    l = d,
                    m = !!(2 & g);
                m && (l |= 2);
                for (var u = !m,
                        t = !0, r = 0, w = 0; r < k.length; r++) {
                    var v = ul(k[r], b, l);
                    if (v instanceof b) {
                        if (!m) {
                            var z = Hk(v);
                            u && (u = !z);
                            t && (t = z)
                        }
                        k[w++] = v
                    }
                }
                w < r && (k.length = w);
                g |= 4;
                g = t ? g & -4097 : g | 4096;
                g = u ? g | 8 : g & -9
            }
            g !== f && (mk(a, g), 2 & g && Object.freeze(a));
            a = Tm(a, g, c, d, 10, 1, h, e);
            if (!e) {
                b = a;
                d = !1;
                d = d === void 0 ? !1 : d;
                e = rk(c);
                f = rk(b);
                h = Object.isFrozen(b) && f;
                Om(b, c, d);
                if (e || f) d ? F(f) : F(h);
                F(!!((I(b, "state is only maintained on arrays.")[X] | 0) & 4));
                if (f && b.length)
                    for (d = 0; d < 1; d++) Nm(b[d], c)
            }
            return a
        },
        bn = function(a, b, c, d) {
            d != null ? tl(d, G(b)) : d = void 0;
            Km(a,
                c, d);
            d && !Hk(d) && (F(Z(a)), b = wk ? a[G(xk)] : a.C, Gm(b));
            return a
        };

    function Sm(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }
    var cn = function(a, b, c) {
            c = c === void 0 ? !1 : c;
            var d;
            return (d = gl(Im(a, b))) != null ? d : c
        },
        dn = function(a, b) {
            var c = c === void 0 ? 0 : c;
            var d;
            return (d = nl(Im(a, b))) != null ? d : c
        },
        en = function(a, b) {
            var c = c === void 0 ? "" : c;
            a = sl(Im(a, b));
            return a != null ? a : c
        },
        fn = function(a, b, c) {
            if (c != null && typeof c !== "boolean") throw Error("ma`" + Ja(c) + "`" + c);
            return Km(a, b, c)
        },
        gn = function(a, b, c) {
            if (c != null) {
                if (typeof c !== "number") throw Wk(ol(c));
                if (!bl(c)) throw Wk(ol(c));
                c >>>= 0
            }
            return Km(a, b, c)
        },
        hn = function(a, b, c) {
            if (c != null && typeof c !== "string") throw Error("na`" +
                c + "`" + Ja(c));
            return Km(a, b, c)
        },
        jn = function(a, b, c) {
            return Km(a, b, c == null ? c : jl(c))
        },
        kn = function(a, b, c) {
            Fm(a);
            b = Pm(a, b, kl, 2, !0);
            b === kk || I(b, "state is only maintained on arrays.");
            if (Array.isArray(c))
                for (var d = c.length, e = 0; e < d; e++) b.push(jl(c[e]));
            else
                for (c = x(c), d = c.next(); !d.done; d = c.next()) b.push(jl(d.value));
            Pk(b);
            return a
        };
    var ln = function(a, b, c) {
        this.preventPassingToStructuredClone = Nk;
        Eb(this, ln, "The message constructor should only be used by subclasses");
        F(this.constructor !== ln, "Message is an abstract class and cannot be directly constructed");
        var d = this.constructor,
            e;
        if (a && ((e = a[gk]) != null ? e : a[gk] = d) !== d) throw Error("Ha");
        a = xm(a, b, c, 2048);
        F(Z(this));
        I(a);
        wk ? this[G(xk)] = a : this.C = a;
        F(Z(this));
        a = wk ? this[G(xk)] : this.C;
        b = I(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, b);
        F(b & 64);
        F(b & 2048)
    };
    n = ln.prototype;
    n.toJSON = function() {
        return qm(this)
    };
    n.hb = function() {
        return JSON.stringify(qm(this))
    };
    n.getExtension = function(a) {
        Eb(this, a.gg);
        var b = Eb(this, ln);
        jm(b, a.ka);
        im(b, a.ka, a.Ze);
        return a.qb ? a.Ld ? a.Xb(b, a.qb, a.ka, void 0 === Qk ? 2 : 4, a.yb) : a.Xb(b, a.qb, a.ka, a.yb) : a.Ld ? a.Xb(b, a.ka, void 0 === Qk ? 2 : 4, a.yb) : a.Xb(b, a.ka, a.defaultValue, a.yb)
    };
    n.hasExtension = function(a) {
        F(!a.Ld, "repeated extensions don't support hasExtension");
        var b = Eb(this, ln);
        jm(b, a.ka);
        im(b, a.ka, a.Ze);
        a.qb ? a = Mm(b, a.qb, a.ka, a.yb) : (F(!a.Ld, "repeated extensions don't support getExtensionOrUndefined"), Eb(b, a.gg), b = Eb(b, ln), jm(b, a.ka), im(b, a.ka, a.Ze), a = a.qb ? a.Xb(b, a.qb, a.ka, a.yb) : a.Xb(b, a.ka, null, a.yb), a = (a === null ? void 0 : a) !== void 0);
        return a
    };
    n.clone = function() {
        var a = Eb(this, ln);
        F(Ck(a));
        var b = yk(a),
            c = qk(b);
        return Cm(a, b, c) ? Dm(a, b, !0) : new a.constructor(Bm(b, c, !1))
    };
    n.Eg = function() {
        return Hk(this)
    };
    zk = ln;
    ln.prototype[dk] = Bk;
    ln.prototype.toString = function() {
        F(Z(this));
        return (wk ? this[G(xk)] : this.C).toString()
    };
    var mn = function(a, b, c, d) {
        this.ge = a;
        this.he = b;
        a = Ma(Ol);
        this.sh = !!a && d === a || !1
    };

    function nn(a) {
        var b = on;
        var c = c === void 0 ? Ol : c;
        return new mn(a, b, !1, c)
    }

    function on(a, b, c, d, e) {
        b = pn(b, d);
        b != null && (c = Hl(a, c), e(b, a), Il(a, c))
    }
    var qn = nn(function(a, b, c, d, e) {
            if (a.m !== 2) return !1;
            Oj(a, Wm(b, d, c), e);
            return !0
        }),
        rn = nn(function(a, b, c, d, e) {
            if (a.m !== 2) return !1;
            Oj(a, Wm(b, d, c), e);
            return !0
        }),
        sn = Symbol(),
        tn = Symbol(),
        un = Symbol(),
        vn = Symbol(),
        wn = Symbol(),
        xn, yn;

    function zn(a, b, c, d) {
        var e = d[a];
        if (e) return e;
        e = {};
        e.Eh = d;
        e.Wc = F(vm(d[0]));
        var f = d[1],
            g = 1;
        f && f.constructor === Object && (e.De = f, f = d[++g], typeof f === "function" && (xn != null && (F(xn === f), F(yn === d[1 + g])), e.Gg = !0, xn != null || (xn = f), yn != null || (yn = Ab(d[g + 1])), f = d[g += 2]));
        for (var h = {}; f && An(f);) {
            for (var k = 0; k < f.length; k++) h[f[k]] = f;
            f = d[++g]
        }
        for (k = 1; f !== void 0;) {
            typeof f === "number" && (F(f > 0), k += f, f = d[++g]);
            var l = void 0;
            if (f instanceof mn) var m = f;
            else m = qn, g--;
            f = void 0;
            if ((f = m) == null ? 0 : f.sh) {
                f = d[++g];
                l = d;
                var u = g;
                typeof f ===
                    "function" && (F(f.length === 0), f = f(), l[u] = f);
                Bn(f);
                l = f
            }
            f = d[++g];
            u = k + 1;
            typeof f === "number" && f < 0 && (u -= f, f = d[++g]);
            for (; k < u; k++) {
                var t = h[k];
                l ? c(e, k, F(m), l, t) : b(e, k, F(m), t)
            }
        }
        return d[a] = e
    }

    function An(a) {
        return Array.isArray(a) && !!a.length && typeof a[0] === "number" && a[0] > 0
    }

    function Bn(a) {
        if (Array.isArray(a) && a.length) {
            var b = a[0];
            var c = vm(b);
            c != null && c !== b && (a[0] = c);
            b = c != null
        } else b = !1;
        F(b);
        return a
    }

    function Cn(a) {
        return Array.isArray(a) ? a[0] instanceof mn ? (F(a.length === 2), Bn(a[1]), a) : [rn, Bn(a)] : [Eb(a, mn), void 0]
    }

    function pn(a, b) {
        if (a instanceof ln) return F(Z(a)), wk ? a[G(xk)] : a.C;
        if (Array.isArray(a)) return wm(a, b)
    };

    function Dn(a) {
        return zn(tn, En, Fn, a)
    }

    function En(a, b, c, d) {
        var e = c.ge;
        a[b] = d ? function(f, g, h) {
            return e(f, g, h, d)
        } : e
    }

    function Fn(a, b, c, d, e) {
        var f = c.ge,
            g, h;
        a[b] = function(k, l, m) {
            return f(k, l, m, h || (h = Dn(d).Wc), g || (g = Gn(d)), e)
        }
    }

    function Gn(a) {
        var b = a[un];
        if (b != null) return b;
        var c = Dn(a);
        b = c.Gg ? function(d, e) {
            return F(xn)(d, e, c)
        } : function(d, e) {
            var f = I(d, "state is only maintained on arrays.")[X] | 0;
            Y(d, f, !0);
            for (F(!(f & 2)); Mj(e) && e.m != 4;) {
                f = e.kc;
                var g = c[f];
                if (g == null) {
                    var h = c.De;
                    h && (h = h[f]) && (h = Hn(h), h != null && (g = c[f] = h))
                }
                if (g == null || !g(e, d, f)) {
                    h = e;
                    g = h.tb;
                    Nj(h);
                    if (h.ze) var k = void 0;
                    else {
                        var l = h.o.ga(),
                            m = l - g;
                        h.o.T = g;
                        g = h.o.hf(m);
                        F(l == h.o.ga());
                        k = g
                    }
                    l = h = g = void 0;
                    m = d;
                    I(m);
                    k && ((g = (h = (l = m[Zj]) != null ? l : m[Zj] = new em)[f]) != null ? g : h[f] = []).push(k)
                }
            }
            if (d =
                dm(d)) d.nf = G(c.Eh[wn]);
            return !0
        };
        a[un] = b;
        a[wn] = In.bind(a);
        return b
    }

    function In(a, b, c, d) {
        var e = this[tn],
            f = this[un],
            g = wm(void 0, e.Wc),
            h = dm(a);
        if (h) {
            var k = !1,
                l = e.De;
            if (l) {
                e = function(w, v, z) {
                    if (z.length !== 0)
                        if (l[v])
                            for (w = x(z), v = w.next(); !v.done; v = w.next()) {
                                v = Lj(v.value);
                                try {
                                    k = !0, f(g, v)
                                } finally {
                                    v.Fe()
                                }
                            } else d == null || d(a, v, z)
                };
                if (b == null) fm(h, e);
                else if (h != null) {
                    var m = h[b];
                    m && e(h, b, m)
                }
                if (k) {
                    var u = pk(a);
                    if (u & 2 && u & 2048 && (c == null || !c.nj)) throw Error("Ja");
                    var t = Uk(u),
                        r = function(w, v) {
                            if (Hm(a, w, t) != null) switch (c == null ? void 0 : c.Sk) {
                                case 1:
                                    return;
                                default:
                                    throw Error("Ka`" + w);
                            }
                            v != null && (u = G(Jm(a, u, w, v, t)));
                            delete h[w]
                        };
                    b == null ? Sk(g, pk(g), function(w, v) {
                        r(w, v)
                    }) : r(b, Hm(g, b, t))
                }
            }
        }
    }

    function Hn(a) {
        a = Cn(a);
        var b = Eb(a[0], mn).ge;
        if (a = a[1]) {
            var c = Gn(Bn(a)),
                d = Dn(Bn(a)).Wc;
            return function(e, f, g) {
                return b(e, f, g, d, c)
            }
        }
        return b
    };

    function On(a, b, c) {
        a[b] = c.he
    }

    function Pn(a, b, c, d) {
        var e, f, g = c.he;
        a[b] = function(h, k, l) {
            return g(h, k, l, f || (f = zn(sn, On, Pn, d).Wc), e || (e = Qn(d)))
        }
    }

    function Qn(a) {
        var b = a[vn];
        if (!b) {
            var c = zn(sn, On, Pn, a);
            b = function(d, e) {
                return Rn(d, e, c)
            };
            a[vn] = b
        }
        return b
    }

    function Rn(a, b, c) {
        Sk(a, I(a, "state is only maintained on arrays.")[X] | 0, function(e, f) {
            if (f != null) {
                var g = Sn(c, e);
                g ? g(b, f, e) : (I(a), e < 500 || Xk(ck, 3, "0ubsb:" + e))
            }
        });
        var d = dm(a);
        d && fm(d, function(e, f, g) {
            Fl(b, b.G.end());
            for (e = 0; e < g.length; e++) Fl(b, Wi(g[e]))
        })
    }

    function Sn(a, b) {
        var c = a[b];
        if (c) return c;
        if (c = a.De)
            if (c = c[b]) {
                c = Cn(c);
                var d = Eb(c[0], mn).he;
                if (c = c[1]) {
                    c = Bn(c);
                    var e = Qn(c),
                        f = zn(sn, On, Pn, c).Wc;
                    c = a.Gg ? F(yn)(f, e) : function(g, h, k) {
                        return d(g, h, k, f, e)
                    }
                } else c = d;
                return a[b] = c
            }
    };

    function Tn(a, b, c) {
        if (Array.isArray(b)) {
            var d = I(b, "state is only maintained on arrays.")[X] | 0;
            if (d & 4) return b;
            for (var e = 0, f = 0; e < b.length; e++) {
                var g = a(b[e]);
                g != null && (F(typeof g !== "object" || g instanceof Ui), b[f++] = g)
            }
            f < e && (b.length = f);
            a = d | 1;
            c && (a = (a | 4) & -1537);
            a !== d && mk(b, a);
            c && a & 2 && Object.freeze(b);
            return b
        }
    }
    var Un = function(a, b) {
        var c = new El;
        Rn(yk(Eb(a, ln)), c, zn(sn, On, Pn, b));
        Fl(c, c.G.end());
        a = new Uint8Array(c.Qb);
        b = c.ne;
        for (var d = b.length, e = 0, f = 0; f < d; f++) {
            var g = b[f];
            a.set(g, e);
            e += g.length
        }
        F(e == a.length);
        c.ne = [a];
        return a
    };

    function Vn(a, b, c) {
        return new mn(a, b, !1, c)
    }

    function Wn(a, b, c) {
        return new mn(a, b, Nl, c)
    }

    function Xn(a, b, c) {
        var d = I(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, d, !0);
        Jm(a, d, b, c, Uk(I(a, "state is only maintained on arrays.")[X] | 0))
    }

    function Yn(a, b, c) {
        if (a.m !== 0 && a.m !== 2) return !1;
        var d = I(b, "state is only maintained on arrays.")[X] | 0;
        Y(b, d, !0);
        b = Vm(b, d, c);
        a.m == 2 ? Uj(a, Gj, b) : b.push(Sj(a));
        return !0
    }
    var Zn = Vn(function(a, b, c) {
            if (a.m !== 1) return !1;
            F(a.m == 1);
            var d = a.o;
            a = Ej(d);
            var e = Ej(d);
            d = (e >> 31) * 2 + 1;
            var f = e >>> 20 & 2047;
            a = 4294967296 * (e & 1048575) + a;
            Xn(b, c, f == 2047 ? a ? NaN : d * Infinity : f == 0 ? d * 4.9E-324 * a : d * Math.pow(2, f - 1075) * (a + 4503599627370496));
            return !0
        }, function(a, b, c) {
            a.Hf(c, el(b))
        }, Xl),
        $n = Vn(function(a, b, c) {
            if (a.m !== 5) return !1;
            F(a.m == 5);
            var d = Ej(a.o);
            a = (d >> 31) * 2 + 1;
            var e = d >>> 23 & 255;
            d &= 8388607;
            Xn(b, c, e == 255 ? d ? NaN : a * Infinity : e == 0 ? a * 1.401298464324817E-45 * d : a * Math.pow(2, e - 150) * (d + 8388608));
            return !0
        }, function(a,
            b, c) {
            a.If(c, el(b))
        }, Wl),
        ao = Vn(function(a, b, c) {
            a.m !== 0 ? b = !1 : (F(a.m == 0), a = Aj(a.o, tj), Xn(b, c, a), b = !0);
            return b
        }, function(a, b, c) {
            a.qh(c, ql(b))
        }, Ul),
        bo = Vn(function(a, b, c) {
            a.m !== 0 ? a = !1 : (Xn(b, c, Rj(a)), a = !0);
            return a
        }, function(a, b, c) {
            a.rh(c, rl(b))
        }, Vl),
        co = Wn(function(a, b, c) {
                if (a.m !== 0 && a.m !== 2) a = !1;
                else {
                    var d = I(b, "state is only maintained on arrays.")[X] | 0;
                    Y(b, d, !0);
                    b = Vm(b, d, c);
                    a.m == 2 ? Uj(a, Dj, b) : b.push(Rj(a));
                    a = !0
                }
                return a
            }, function(a, b, c) {
                b = Tn(rl, b, !1);
                if (b != null)
                    for (var d = 0; d < b.length; d++) Jl(a, c, b[d])
            },
            Vl),
        eo = Vn(function(a, b, c) {
            if (a.m !== 0) return !1;
            Xn(b, c, Pj(a));
            return !0
        }, function(a, b, c) {
            a.ph(c, nl(b))
        }, Rl),
        fo = Wn(function(a, b, c) {
            if (a.m !== 0 && a.m !== 2) return !1;
            var d = I(b, "state is only maintained on arrays.")[X] | 0;
            Y(b, d, !0);
            b = Vm(b, d, c);
            a.m == 2 ? Uj(a, Bj, b) : b.push(Pj(a));
            return !0
        }, function(a, b, c) {
            b = Tn(nl, b, !0);
            if (b != null)
                for (var d = 0; d < b.length; d++) {
                    var e = a,
                        f = c,
                        g = b[d];
                    g != null && (Ll(f, g), Gl(e, f, 0), Dl(e.G, g))
                }
        }, Rl),
        go = Vn(function(a, b, c) {
            if (a.m !== 5) return !1;
            F(a.m == 5);
            a = Ej(a.o);
            Xn(b, c, a);
            return !0
        }, function(a, b,
            c) {
            b = pl(b);
            b != null && (Kl(c, b, b >= 0 && b < 4294967296), Gl(a, c, 5), a.G.Ka(b))
        }, Tl),
        ho = Vn(function(a, b, c) {
            if (a.m !== 0) return !1;
            F(a.m == 0);
            a = Fj(a.o);
            Xn(b, c, a);
            return !0
        }, function(a, b, c) {
            a.Gf(c, gl(b))
        }, Pl),
        io = Vn(function(a, b, c) {
            if (a.m !== 2) return !1;
            Xn(b, c, Tj(a));
            return !0
        }, function(a, b, c) {
            b = sl(b);
            if (b != null) {
                var d = !0;
                d = d === void 0 ? !1 : d;
                zb(b);
                if (Li) {
                    if (d && (Ki ? !b.isWellFormed() : /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(b))) throw Error("U");
                    b = (Ji || (Ji = new TextEncoder)).encode(b)
                } else {
                    for (var e =
                            0, f = new Uint8Array(3 * b.length), g = 0; g < b.length; g++) {
                        var h = b.charCodeAt(g);
                        if (h < 128) f[e++] = h;
                        else {
                            if (h < 2048) f[e++] = h >> 6 | 192;
                            else {
                                F(h < 65536);
                                if (h >= 55296 && h <= 57343) {
                                    if (h <= 56319 && g < b.length) {
                                        var k = b.charCodeAt(++g);
                                        if (k >= 56320 && k <= 57343) {
                                            h = (h - 55296) * 1024 + k - 56320 + 65536;
                                            f[e++] = h >> 18 | 240;
                                            f[e++] = h >> 12 & 63 | 128;
                                            f[e++] = h >> 6 & 63 | 128;
                                            f[e++] = h & 63 | 128;
                                            continue
                                        } else g--
                                    }
                                    if (d) throw Error("U");
                                    h = 65533
                                }
                                f[e++] = h >> 12 | 224;
                                f[e++] = h >> 6 & 63 | 128
                            }
                            f[e++] = h & 63 | 128
                        }
                    }
                    b = e === f.length ? f : f.subarray(0, e)
                }
                Gl(a, c, 2);
                Cl(a.G, b.length);
                Fl(a,
                    a.G.end());
                Fl(a, b)
            }
        }, Ql),
        jo, ko = void 0;
    ko = ko === void 0 ? Ol : ko;
    jo = new mn(function(a, b, c, d, e) {
        if (a.m !== 2) return !1;
        d = wm(void 0, d);
        var f = I(b, "state is only maintained on arrays.")[X] | 0;
        Y(b, f, !0);
        Vm(b, f, c).push(d);
        Oj(a, d, e);
        return !0
    }, function(a, b, c, d, e) {
        if (Array.isArray(b)) {
            for (var f = 0; f < b.length; f++) {
                var g = a,
                    h = c,
                    k = e,
                    l = pn(b[f], d);
                l != null && (h = Hl(g, h), k(l, g), Il(g, h))
            }
            a = nk(b);
            a & 1 || mk(b, a | 1)
        }
    }, Nl, ko);
    var lo = Vn(function(a, b, c) {
            if (a.m !== 0) return !1;
            Xn(b, c, Qj(a));
            return !0
        }, function(a, b, c) {
            a.Ka(c, pl(b))
        }, Sl),
        mo = Wn(function(a, b, c) {
            if (a.m !== 0 && a.m !== 2) return !1;
            var d = I(b, "state is only maintained on arrays.")[X] | 0;
            Y(b, d, !0);
            b = Vm(b, d, c);
            a.m == 2 ? Uj(a, Cj, b) : b.push(Qj(a));
            return !0
        }, function(a, b, c) {
            b = Tn(pl, b, !0);
            if (b != null && b.length) {
                c = Hl(a, c);
                for (var d = 0; d < b.length; d++) Cl(a.G, b[d]);
                Il(a, c)
            }
        }, Sl),
        no = Vn(function(a, b, c) {
            if (a.m !== 0) return !1;
            Xn(b, c, Sj(a));
            return !0
        }, function(a, b, c) {
            a.fe(c, nl(b))
        }, Yl),
        oo = Wn(Yn, function(a,
            b, c) {
            b = Tn(nl, b, !0);
            if (b != null)
                for (var d = 0; d < b.length; d++) a.fe(c, b[d])
        }, Yl),
        po = Wn(Yn, function(a, b, c) {
            b = Tn(nl, b, !0);
            if (b != null && b.length) {
                c = Hl(a, c);
                for (var d = 0; d < b.length; d++) a.G.fe(b[d]);
                Il(a, c)
            }
        }, Yl);
    var so = function() {
        var a = qo,
            b = ro;
        F(!0);
        this.ka = 4156379;
        this.gg = a;
        this.qb = b;
        this.Ld = 0;
        this.Xb = Zm;
        this.defaultValue = void 0;
        this.yb = a.wk != null ? Fk : void 0;
        this.Ze = void 0;
        F(!0, "lazyParse must be undefined or LAZILY_PARSE_LATE_LOADED_EXTENSIONS_SYMBOL")
    };
    so.prototype.register = function() {
        Jg(this)
    };

    function to(a) {
        if (a instanceof ln) return a.constructor.W
    };
    (function() {
        var a = Ha.jspbGetTypeName;
        Ha.jspbGetTypeName = a ? function(b) {
            return a(b) || to(b)
        } : to
    })();
    var uo = ln;

    function vo(a, b) {
        return function(c, d) {
            var e = {
                be: !0
            };
            d && Object.assign(e, d);
            c = Lj(c, void 0, void 0, e);
            try {
                var f = new a,
                    g = yk(f);
                Gn(b)(g, c);
                var h = f
            } finally {
                c.Fe()
            }
            return h
        }
    }

    function wo(a) {
        return function() {
            return Un(this, a)
        }
    }

    function xo(a) {
        return function(b) {
            Ab(a);
            if (b == null || b == "") b = Eb(new a, ln);
            else {
                zb(b);
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("Ia`" + Ja(b) + "`" + b);
                ok(b, 32);
                b = new a(b)
            }
            return b
        }
    };
    var $m = function(a) {
        uo.call(this, a)
    };
    q($m, uo);
    $m.prototype.rg = function() {
        return en(this, 2)
    };
    $m.W = "wireless.mdl.UserAgentClientHints.BrandAndVersion";
    var yo = [0, io, -1];
    $m.prototype.R = wo(yo);
    var zo = function(a) {
        uo.call(this, a)
    };
    q(zo, uo);
    var Ao = function(a, b) {
            return hn(a, 2, b)
        },
        Bo = function(a, b) {
            return hn(a, 3, b)
        },
        Co = function(a, b) {
            return hn(a, 4, b)
        },
        Do = function(a, b) {
            return hn(a, 5, b)
        },
        Eo = function(a, b) {
            return hn(a, 9, b)
        },
        Fo = function(a, b) {
            var c = $m;
            Fm(a);
            F(Z(a));
            var d = wk ? a[G(xk)] : a.C;
            var e = I(d, "state is only maintained on arrays.")[X] | 0;
            Y(d, e);
            if (b == null) Jm(d, e, 10);
            else {
                var f = b;
                if (!Array.isArray(f)) throw a = "Expected array but got " + Ja(f) + ": " + f, Wk(a);
                for (var g = f = b === kk ? 7 : I(b, "state is only maintained on arrays.")[X] | 0, h = Um(f), k = h || Object.isFrozen(b),
                        l = !0, m = !0, u = 0; u < b.length; u++) {
                    var t = b[u];
                    tl(t, G(c));
                    h || (t = Hk(t), l && (l = !t), m && (m = t))
                }
                h || (f = l ? 13 : 5, f = m ? f & -4097 : f | 4096);
                k && f === g || (b = Yk(b), g = 0, f = Sm(f, e));
                f !== g && mk(b, f);
                Ok(b);
                e = Jm(d, e, 10, b);
                2 & f || zm(f) || Gm(d, e)
            }
            return a
        },
        Go = function(a, b) {
            return fn(a, 11, b)
        },
        Ho = function(a, b) {
            return hn(a, 1, b)
        },
        Io = function(a, b) {
            return fn(a, 7, b)
        };
    zo.W = "wireless.mdl.UserAgentClientHints";
    zo.prototype.R = wo([0, io, -4, jo, yo, ho, no, io, jo, yo, ho]);
    var Jo = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function Ko(a) {
        var b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function Lo(a) {
        var b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function Mo(a) {
        if (!Lo(a)) return null;
        var b = Ko(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(Jo).then(function(c) {
            b.uach != null || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function No(a) {
        var b;
        return Go(Fo(Do(Ao(Ho(Co(Io(Eo(Bo(new zo, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), ((b = a.fullVersionList) == null ? void 0 : b.map(function(c) {
            var d = new $m;
            d = hn(d, 1, c.brand);
            return hn(d, 2, c.version)
        })) || []), a.wow64 || !1)
    }

    function Oo(a) {
        var b, c;
        return (c = (b = Mo(a)) == null ? void 0 : b.then(function(d) {
            return No(d)
        })) != null ? c : null
    };
    var Po = function(a, b, c, d) {
        a = a === void 0 ? window : a;
        b = b === void 0 ? null : b;
        c = c === void 0 ? new Oa : c;
        d = d === void 0 ? Hf("current") : d;
        Zd.call(this);
        var e = this;
        this.global = a;
        this.Na = b;
        this.L = c;
        this.uf = d;
        this.Og = Ed(function() {
            return Id(e.global, "pagehide")
        }).g(sg(this.L, 941));
        this.Ng = Ed(function() {
            return Id(e.global, "load")
        }).g(sg(this.L, 738), Re(1));
        this.Vi = Ed(function() {
            return Id(e.global, "resize")
        }).g(sg(this.L, 741));
        this.onMessage = Ed(function() {
            return Id(e.global, "message")
        }).g(sg(this.L, 740));
        this.document = new qi(this.global,
            this);
        this.l = new ug(new xg(this.S, this.L), new wg(this.S, this.L));
        this.I = new me(new Bg(this), new Ih(this), new qf(this, new Ig(this)), new qf(this, new Lh(this)), new qf(this, new Gh(this)))
    };
    q(Po, Zd);
    var Qo = function(a) {
            try {
                return !!a.global.sharedStorage
            } catch (b) {
                return b
            }
        },
        Ro = function(a, b) {
            try {
                return !!a.global.localStorage
            } catch (c) {
                return (b === void 0 ? function() {} : b)(c), !1
            }
        };
    Po.prototype.Lc = function() {
        var a;
        return !((a = this.global.navigator) == null || !a.locks)
    };
    Po.prototype.mf = function(a, b) {
        var c = this;
        return Ca(function(d) {
            return c.Lc() ? d.u(c.global.navigator.locks.request(a, b), 0) : d.return()
        })
    };
    var Cg = function(a) {
        var b = a.global;
        return !!a.global.HTMLFencedFrameElement && !!b.fence && typeof b.fence.reportEvent === "function"
    };
    Po.prototype.sc = function(a) {
        Cg(this) && this.global.fence.reportEvent(a)
    };
    Po.prototype.Ie = function() {
        return this.Og.g(sg(this.L, 942), V(this.i, 1), N(function() {}))
    };
    var So = function(a) {
            var b = new Po(a.global.top, a.Na);
            b.I = a.I;
            return b
        },
        To = function(a, b) {
            b.start();
            return Id(b, "message").g(sg(a.L, 740))
        };
    Po.prototype.postMessage = function(a, b, c) {
        c = c === void 0 ? [] : c;
        this.global.postMessage(a, b, c)
    };
    Po.prototype.sg = function() {
        return Lg(this.global) ? this.global.width : 0
    };
    Po.prototype.pg = function() {
        return Lg(this.global) ? this.global.height : 0
    };
    var Uo = function(a, b) {
        try {
            var c = Ci(b, a.global);
            return {
                left: c.left,
                top: c.top,
                width: c.sg(),
                height: c.pg()
            }
        } catch (d) {
            return wi
        }
    };
    Po.prototype.validate = function() {
        var a = this.I.P() || Cg(this);
        return this.global && this.l.pa() && a
    };
    var Yh = function(a) {
        return (a = Oo(a.global)) ? Mc(a) : null
    };
    da.Object.defineProperties(Po.prototype, {
        sharedStorage: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                try {
                    return this.global.sharedStorage
                } catch (a) {}
            }
        },
        localStorage: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                try {
                    return this.global.localStorage
                } catch (a) {}
            }
        },
        S: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return window
            }
        },
        Cb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return !Lg(this.global.top)
            }
        },
        Oe: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Cb || this.global.top !== this.global
            }
        },
        scrollY: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.global.scrollY
            }
        },
        MutationObserver: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.S.MutationObserver
            }
        },
        ResizeObserver: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.S.ResizeObserver
            }
        },
        Gh: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return "vu" in this.global || "vv" in this.global
            }
        }
    });
    var Vo = !dh && !Wg();

    function Wo(a, b) {
        if (/-[a-z]/.test(b)) return null;
        if (Vo && a.dataset) {
            if (Yg() && !(b in a.dataset)) return null;
            a = a.dataset[b];
            return a === void 0 ? null : a
        }
        return a.getAttribute("data-" + String(b).replace(/([A-Z])/g, "-$1").toLowerCase())
    };
    var Xo = {},
        Yo = (Xo["data-google-av-cxn"] = "_avicxn_", Xo["data-google-av-cpmav"] = "_cvu_", Xo["data-google-av-metadata"] = "_avm_", Xo["data-google-av-adk"] = "_adk_", Xo["data-google-av-btr"] = void 0, Xo["data-google-av-override"] = void 0, Xo["data-google-av-dm"] = void 0, Xo["data-google-av-immediate"] = void 0, Xo["data-google-av-aid"] = void 0, Xo["data-google-av-naid"] = void 0, Xo["data-google-av-inapp"] = void 0, Xo["data-google-av-slift"] = void 0, Xo["data-google-av-itpl"] = void 0, Xo["data-google-av-ext-cxn"] = void 0, Xo["data-google-av-rs"] =
            void 0, Xo["data-google-av-flags"] = void 0, Xo["data-google-av-turtlex"] = void 0, Xo["data-google-av-ufs-integrator-metadata"] = void 0, Xo["data-google-av-vattr"] = void 0, Xo["data-google-av-vrus"] = void 0, Xo),
        Zo = {},
        $o = (Zo["data-google-av-adk"] = "googleAvAdk", Zo["data-google-av-btr"] = "googleAvBtr", Zo["data-google-av-cpmav"] = "googleAvCpmav", Zo["data-google-av-dm"] = "googleAvDm", Zo["data-google-av-ext-cxn"] = "googleAvExtCxn", Zo["data-google-av-immediate"] = "googleAvImmediate", Zo["data-google-av-inapp"] = "googleAvInapp",
            Zo["data-google-av-itpl"] = "googleAvItpl", Zo["data-google-av-metadata"] = "googleAvMetadata", Zo["data-google-av-naid"] = "googleAvNaid", Zo["data-google-av-override"] = "googleAvOverride", Zo["data-google-av-rs"] = "googleAvRs", Zo["data-google-av-slift"] = "googleAvSlift", Zo["data-google-av-cxn"] = "googleAvCxn", Zo["data-google-av-aid"] = void 0, Zo["data-google-av-flags"] = "googleAvFlags", Zo["data-google-av-turtlex"] = "googleAvTurtlex", Zo["data-google-av-ufs-integrator-metadata"] = "googleAvUfsIntegratorMetadata", Zo["data-google-av-vattr"] =
            "googleAvVattr", Zo["data-google-av-vrus"] = "googleAvVurs", Zo);

    function ap(a, b) {
        if (a.j === void 0) return null;
        try {
            var c;
            var d = (c = a.j.getAttribute(b)) != null ? c : null;
            if (d !== null) return d
        } catch (g) {}
        try {
            var e = Yo[b];
            if (e && (d = a.j[e], d !== void 0)) return d
        } catch (g) {}
        try {
            var f = $o[b];
            if (f) return Wo(a.j, f)
        } catch (g) {}
        return null
    }

    function bp(a) {
        return N(function(b) {
            return ap(b, a)
        })
    };
    var cp = K(function(a) {
        return N(function(b) {
            return a.map(function(c) {
                return ap(b, c)
            })
        })
    }(["data-google-av-cxn", "data-google-av-turtlex"]), N(function(a) {
        var b = x(a);
        a = b.next().value;
        b = b.next().value;
        if (!a) {
            if (b !== null) return [];
            throw new ie;
        }
        return a.split("|")
    }));
    var dp = function() {
        return K(Bd(function(a) {
            return a.element.g(cp, Ie(function() {
                return Zc([""])
            })).g(N(function(b) {
                return {
                    va: b,
                    xd: a
                }
            }))
        }), Te(function(a) {
            return a.va.sort().join(";")
        }), N(function(a) {
            return a.xd
        }))
    };

    function ep() {
        return Bd(function(a) {
            return Mc(fp(a)).g(Mh(a.i))
        })
    }

    function fp(a) {
        return a.document.querySelectorAll(".GoogleActiveViewElement,.GoogleActiveViewClass").map(function(b) {
            return new $h(b)
        })
    };

    function gp(a) {
        var b = a.Ng,
            c = a.document.Ui;
        return Pd(Zc({}), c, b).g(N(function() {
            return a
        }))
    };
    var ip = N(hp);

    function hp(a) {
        var b = Number(ap(a, "data-google-av-rs"));
        if (!isNaN(b) && b !== 0) return b;
        var c;
        return (a = (c = a.j) == null ? void 0 : c.id) ? a.startsWith("DfaVisibilityIdentifier") ? 6 : a.startsWith("YtKevlarVisibilityIdentifier") ? 15 : a.startsWith("YtSparklesVisibilityIdentifier") ? 17 : a.startsWith("YtKabukiVisibilityIdentifier") ? 18 : 0 : 0
    };

    function jp() {
        return K(O(function(a) {
            return a !== void 0
        }), N(function(a) {
            return a
        }))
    };

    function kp() {
        return function(a) {
            var b = [];
            return a.g(O(function(c) {
                if (c.j === void 0 || b.some(function(d) {
                        return d.j === c.j
                    })) return !1;
                b.push(c);
                return !0
            }))
        }
    };

    function lp(a, b) {
        b = b === void 0 ? Ac : b;
        return Pd(gp(a), b).g(ep(), kp(), jp(), V(a.i, 1))
    };

    function mp(a, b) {
        return new L(function(c) {
            var d = !1,
                e = Array(b.length);
            e.fill(void 0);
            var f = new Set,
                g = new Set,
                h = function(u, t) {
                    a.Sg ? (e[t] = u, f.add(t), d || (d = !0, Ta(a, function() {
                        d = !1;
                        c.next(Jb(e))
                    }, 1))) : c.error(new je(t))
                },
                k = function(u, t) {
                    g.add(t);
                    f.add(t);
                    Ta(a, function() {
                        c.error(u)
                    }, 1)
                },
                l = function(u) {
                    g.add(u);
                    Ta(a, function() {
                        g.size === b.length && c.complete()
                    }, 1)
                },
                m = b.map(function(u, t) {
                    return u.subscribe(function(r) {
                        return void h(r, t)
                    }, function(r) {
                        return void k(r, t)
                    }, function() {
                        return void l(t)
                    })
                });
            return function() {
                m.forEach(function(u) {
                    return void u.unsubscribe()
                })
            }
        })
    };

    function np(a, b, c) {
        function d() {
            if (b.Na) {
                var z = b.Na,
                    C = z.next;
                var Q = {
                    creativeId: b.Ic.getName(c),
                    requiredSignals: e,
                    signals: Object.assign({}, f),
                    hasPrematurelyCompleted: g,
                    errorMessage: h,
                    erroredSignalKey: k
                };
                Q = {
                    specMajor: 2,
                    specMinor: 0,
                    specPatch: 0,
                    timestamp: se(b.l.now(), new qe(0, b.l.timeline)),
                    instanceId: b.Ic.getName(b.Pb),
                    creativeState: Q
                };
                C.call(z, Q)
            }
        }
        for (var e = Object.keys(a), f = {}, g = !1, h = null, k = null, l = {}, m = new Set, u = [], t = [], r = x(e), w = r.next(), v = {}; !w.done; v = {
                sa: void 0
            }, w = r.next()) v.sa = w.value, w = a[v.sa],
            w instanceof W ? (l[v.sa] = w.value, m.add(v.sa), b.Na && (f[String(v.sa)] = ue(w.value))) : (w = w.g(P(function(z, C) {
                    return ne(z) || ne(C) ? !1 : z === C
                }), N(function(z) {
                    return function(C) {
                        b.Na && (f[String(z.sa)] = ue(C), d());
                        var Q = {};
                        return Q[z.sa] = C, Q
                    }
                }(v)), Ie(function(z) {
                    return function(C) {
                        if (C instanceof je) throw new le(String(z.sa));
                        throw C;
                    }
                }(v)), jf(function(z) {
                    return function() {
                        m.add(z.sa)
                    }
                }(v), function(z) {
                    return function(C) {
                        k = String(z.sa);
                        h = String(C);
                        d()
                    }
                }(v), function(z) {
                    return function() {
                        m.has(z.sa) || (g = !0, d())
                    }
                }(v))),
                t.push(v.sa), u.push(w));
        (a = Object.keys(f).length > 0) && d();
        r = mp(b.i, u).g(Ie(function(z) {
            if (z instanceof je) throw new ke(String(t[z.ni]));
            throw z;
        }), N(function(z) {
            return Object.freeze(Object.assign.apply(Object, [{}, l].concat(y(z))))
        }));
        return (u = u.length > 0) && a ? Pd(Zc(Object.freeze(l)), r) : u ? r : Zc(Object.freeze(l))
    };

    function op(a, b, c, d, e) {
        return a.L.yc.bind(a.L)(733, function() {
            var f = {};
            try {
                return b.g(Ie(function(g) {
                    d(Object.assign({}, f, {
                        error: g
                    }));
                    return Ac
                }), Bd(function(g) {
                    try {
                        var h = c(a, g)
                    } catch (l) {
                        return d(Object.assign({}, f, {
                            error: l instanceof Error ? l : String(l)
                        })), Ac
                    }
                    var k = {};
                    return np(h, a, g.Pb).g(jf(function(l) {
                        k = l
                    }), cf(1), id()).g(e, Ie(function(l) {
                        d(Object.assign({}, k, {
                            error: l
                        }));
                        return Ac
                    }), Xe(void 0), N(function() {
                        return !0
                    }))
                })).g(ef(function(g) {
                    return g + 1
                }, 0), Ie(function(g) {
                    d(Object.assign({}, f, {
                        error: g
                    }));
                    return Ac
                }))
            } catch (g) {
                return d(Object.assign({}, f, {
                    error: g
                })), Ac
            }
        })()
    };

    function pp(a, b) {
        return K(S(function(c) {
            var d = a(c),
                e = b(c),
                f = {};
            return d && e && f ? new L(function(g) {
                e(d, f, function(h) {
                    g.next(Object.assign({}, c, {
                        nb: h
                    }));
                    g.complete()
                });
                return function() {}
            }) : Qd
        }), O(function(c) {
            return c.nb
        }))
    };
    var qp = K(O(function(a) {
        var b = a.I;
        var c = a.Ec;
        var d = a.zc;
        var e = a.sc;
        var f = a.Db;
        var g = a.ab;
        a = a.Dc;
        return g !== void 0 && a !== void 0 && b !== void 0 && c !== void 0 && d !== void 0 && (!f || e !== void 0)
    }), hf(function(a) {
        return !(a.Bg === !1 && a.Be !== void 0)
    }, !1), O(function(a) {
        var b = a.Bg;
        var c = a.Kc;
        var d = a.Gj;
        a = a.Ec;
        return d ? !!c && a !== void 0 && (a == null ? void 0 : a.length) > 0 : !!b
    }), pp(function(a) {
        return a.Dc
    }, function(a) {
        return a.ab
    }), N(function(a) {
        a.Db || a.zc(a.Ec, a).forEach(function(b) {
            a.I.K(b).sendNow()
        })
    }), Re(1), Pe());
    var rp = function(a) {
            var b = b === void 0 ? {} : b;
            this.Sa = a;
            this.config = {
                maxAdKeys: b.maxAdKeys || 50,
                maxHourlyEvents: b.maxHourlyEvents || 2,
                maxDailyEvents: b.maxDailyEvents || 2,
                maxWeeklyEvents: b.maxWeeklyEvents || 2
            };
            this.ya = new Map
        },
        sp = function(a) {
            try {
                var b = JSON.stringify(Array.from(a.ya.entries()));
                a.Sa.setItem("adStatsCache", b)
            } catch (c) {
                a.Sa.reportError(c)
            }
        },
        up = function(a, b, c) {
            return Ca(function(d) {
                return d.u(a.Sa.performExclusiveLockedOperation("avOmakaseLock", function() {
                    a: {
                        var e = a.Sa.getItem("adStatsCache");
                        if (e) try {
                            var f = new Map(JSON.parse(e));
                            break a
                        } catch (h) {
                            a.Sa.reportError(h)
                        }
                        f = new Map
                    }
                    a.ya = f;f = a.ya.get(b) || {
                        h: {},
                        d: {},
                        w: {}
                    };e = f.h;
                    var g = new Date;g.setMinutes(0, 0, 0);tp(e, Math.floor(g.getTime() / 1E3).toString(), c, a.config.maxHourlyEvents);e = f.d;g = new Date;g.setHours(0, 0, 0, 0);tp(e, Math.floor(g.getTime() / 1E3).toString(), c, a.config.maxDailyEvents);e = f.w;g = new Date;g = new Date(g.setDate(g.getDate() - g.getDay()));g.setHours(0, 0, 0, 0);tp(e, Math.floor(g.getTime() / 1E3).toString(), c, a.config.maxWeeklyEvents);a.ya.has(b) ?
                    a.ya.delete(b) : a.ya.size >= a.config.maxAdKeys && a.ya.size >= a.config.maxAdKeys && (e = a.ya.keys().next().value, a.ya.delete(e));f.ts = Date.now();a.ya.set(b, f);sp(a)
                }), 0)
            })
        },
        vp = function(a, b) {
            var c = c === void 0 ? 1 : c;
            return Ca(function(d) {
                return d.u(up(a, b, {
                    c: c,
                    v: 0,
                    cTos: 0
                }), 0)
            })
        },
        wp = function(a, b) {
            var c = c === void 0 ? 1 : c;
            return Ca(function(d) {
                return d.u(up(a, b, {
                    c: 0,
                    v: c,
                    cTos: 0
                }), 0)
            })
        },
        xp = function(a, b, c) {
            return Ca(function(d) {
                return d.u(up(a, b, {
                    c: 0,
                    v: 0,
                    cTos: c
                }), 0)
            })
        },
        tp = function(a, b, c, d) {
            a[b] ? (a[b].c += c.c, a[b].cTos +=
                c.cTos, a[b].v += c.v) : a[b] = {
                c: c.c,
                cTos: c.cTos,
                v: c.v
            };
            b = Object.keys(a);
            b.length > d && delete a[b[0]]
        },
        yp = function(a, b) {
            var c;
            return Ca(function(d) {
                if (d.A == 1) {
                    if (!a.Sa.hasLocalStorageAccess()) return d.return(4);
                    c = 0;
                    return d.u(a.Sa.performExclusiveLockedOperation("avOmakaseLock", function() {
                        var e = a.Sa.getItem("adStatsReset");
                        b > Number(e || "0") ? (e !== null ? (a.ya.clear(), sp(a), c = 1) : c = 3, a.Sa.setItem("adStatsReset", b.toString())) : c = 2
                    }), 2)
                }
                return d.return(c)
            })
        };

    function zp(a) {
        a = a.fa().value.slice(0, 3).reduce(function(b, c) {
            return b + c
        }, 0);
        return Math.min(a, 61500)
    }

    function Ap(a) {
        var b;
        return function(c) {
            var d = c.g(hf(function(g) {
                return g.Be === void 0
            }), gf(function(g) {
                return g.sf === void 0
            }), jf(function(g) {
                g.sf && b === void 0 && (b = new rp(a))
            }), hf(function(g) {
                return !!g.sf
            }), cf(1), id());
            c = d.g(N(function(g) {
                return g.hj
            }), O(function(g) {
                return g !== void 0
            }), Re(1), Bd(function(g) {
                var h, k;
                return Ca(function(l) {
                    if (l.A == 1) return l.u((h = b) == null ? void 0 : yp(h, g), 2);
                    k = l.V;
                    var m = {
                        rk: g.toString(),
                        outcome: k.toString()
                    };
                    m = m === void 0 ? {} : m;
                    var u = a.D;
                    m = m === void 0 ? {} : m;
                    m = Object.assign({}, {
                        reason: "cache_reset_check"
                    }, m);
                    var t = new Bp("https://pagead2.googlesyndication.com/pagead/gen_204");
                    Cp(t, "id", "av-js");
                    Cp(t, "type", "omakase");
                    Cp(t, "jp", JSON.stringify(m));
                    Cp(t, "v", Dp);
                    u.I.K(t.toString()).sendNow();
                    l.Eb()
                })
            }));
            var e = d.g(O(function(g) {
                    return !!g.Kc
                }), Re(1), Bd(function(g) {
                    var h = g.xa;
                    var k;
                    return Ca(function(l) {
                        return h ? l.u((k = b) == null ? void 0 : vp(k, h), 0) : l.ba(0)
                    })
                })),
                f = d.g(O(function(g) {
                    g = g.ee;
                    return !!g && g.fa().value
                }), Re(1), Bd(function(g) {
                    var h = g.xa;
                    var k;
                    return Ca(function(l) {
                        return h ?
                            l.u((k = b) == null ? void 0 : wp(k, h), 0) : l.ba(0)
                    })
                }));
            d = d.g(N(function(g) {
                return g.Li
            }), P(), kf(d.g(N(function(g) {
                return {
                    Va: g.Va,
                    xa: g.xa
                }
            }))), O(function(g) {
                g = x(g);
                g.next();
                return !!g.next().value.Va
            }), N(function(g) {
                g = x(g);
                g.next();
                var h = g.next().value;
                g = h.Va;
                h = h.xa;
                return {
                    xc: zp(g),
                    xa: h
                }
            }), hf(function(g) {
                return g.xc < 61500
            }, !0), P(function(g, h) {
                return g.xc === h.xc
            }), R({
                xc: 0,
                xa: null
            }), bf(), Bd(function(g) {
                g = x(g);
                var h = g.next().value.xc;
                g = g.next().value;
                var k = g.xc;
                var l = g.xa;
                var m;
                return Ca(function(u) {
                    return l &&
                        k ? u.u((m = b) == null ? void 0 : xp(m, l, k - h), 0) : u.ba(0)
                })
            }));
            return Pd(c, e, f, d).g(Pe())
        }
    };

    function Ep(a) {
        var b = new Map;
        if (typeof a !== "object" || a === null) return b;
        Object.values(a).forEach(function(c) {
            c && typeof c.fa === "function" && (b.has(c.clock.timeline) || b.set(c.clock.timeline, c.clock.now()))
        });
        return b
    };

    function Fp(a, b, c) {
        var d = Gp,
            e = Hp;
        c = c === void 0 ? .01 : c;
        return function(f) {
            c > 0 && Math.random() <= c && (a.global.HTMLFencedFrameElement && a.global.fence && typeof a.global.fence.reportEvent === "function" && a.global.fence.reportEvent({
                eventType: "active-view-error",
                eventData: "",
                destination: ["buyer"]
            }), f = Object.assign({}, f, {
                errorMessage: f.error instanceof Error && f.error.message ? f.error.message : String(f.error),
                dg: f.error instanceof Error && f.error.stack ? String(f.error.stack) : null,
                Th: f.error instanceof Error && f.error.name ?
                    String(f.error.name) : null,
                Rh: String(a.L.xf),
                Sh: f.escapedQueryId
            }), d(Object.assign({}, f, {
                ca: function() {
                    return function(g) {
                        try {
                            return e(Object.assign({}, g))
                        } catch (h) {
                            return {}
                        }
                    }
                }(),
                va: [b]
            }), Ep(f)).forEach(function(g) {
                a.I.K(g).sendNow()
            }))
        }
    };
    var Ip = K(N(function(a) {
        var b = a.I;
        var c = a.Zh;
        if (b === void 0 || c === void 0) return !1;
        if (a.Be !== void 0) return !0;
        if (c === null) return !1;
        for (a = 0; a < c; a++) b.K("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=extra&rnd=" + Math.floor(Math.random() * 1E7)).sendNow();
        return !0
    }), hf(function(a) {
        return !a
    }), Pe());
    var Jp = K(O(function(a) {
        return !!a.Kc
    }), O(function(a) {
        var b = a.shouldSendExplicitDisplayMeasurablePing;
        a = a.Ab;
        var c, d;
        return (d = b && ((c = a == null ? void 0 : a.length) != null ? c : 0) > 0) != null ? d : !1
    }), O(function(a) {
        return a.ca !== void 0 && a.Ab !== void 0 && a.Rb !== void 0 && a.cc !== void 0 && a.I !== void 0
    }), N(function(a) {
        return Object.assign({}, a, {
            Xd: Ep(a)
        })
    }), N(function(a) {
        a.Rb(Object.assign({}, a, {
            va: a.Ab,
            ca: a.ca,
            ad: a.cc,
            md: 3,
            cd: "m"
        }), a.Xd).forEach(function(b) {
            a.I.K(b).sendNow()
        });
        return !0
    }), hf(function(a) {
        return !a
    }), Pe());
    var Hp = function(a) {
        return {
            id: a.ad,
            mcvt: a.Uc,
            p: a.yd,
            asp: a.mk,
            tm: a.Yd,
            tu: a.Zd,
            mtos: a.Vc,
            tos: a.Va,
            v: a.Fh,
            bin: a.me,
            avms: a.Lg,
            bs: a.Tf,
            mc: a.Jg,
            "if": a.Nh,
            vu: a.Ph,
            app: a.Bb,
            mse: a.bf,
            mtop: a.cf,
            itpl: a.Qe,
            adk: a.xa,
            exk: a.pk,
            rs: a.fb,
            la: a.Fg,
            cr: a.Ue,
            uach: a.kd,
            vs: a.md,
            r: a.cd,
            pay: a.hi,
            co: a.Hh,
            rst: a.zh,
            rpt: a.yh,
            isd: a.li,
            lsd: a.Ei,
            context: a.Rh,
            msg: a.errorMessage,
            stack: a.dg,
            name: a.Th,
            ec: a.ii,
            sfr: a.vf,
            met: a.Gc,
            wmsd: a.Df,
            pv: a.Ok,
            epv: a.sk,
            pbe: a.zg,
            fle: a.ji,
            vae: a.ki,
            spb: a.eh,
            sfl: a.dh,
            ffslot: a.wi,
            reach: a.tj,
            io2: a.ce,
            rxdbg: a.Tk,
            omida: a.Ck,
            omidp: a.Jk,
            omidpv: a.Kk,
            omidor: a.Ik,
            omidv: a.Mk,
            omids: a.Lk,
            omidam: a.Bk,
            omidct: a.Dk,
            omidia: a.Gk,
            omiddc: a.Ek,
            omidlat: a.Hk,
            omiddit: a.Fk,
            qid: a.Sh
        }
    };

    function Kp() {
        var a = E.apply(0, arguments);
        return function(b) {
            var c = b.g(cf(1), id());
            b = a.map(function(d) {
                return c.g(d, Xe(!0))
            });
            return vd(b).g(Re(1), Pe())
        }
    };

    function Lp() {
        var a = E.apply(0, arguments);
        return function(b) {
            var c = b.g(cf(1), id());
            b = a.map(function(d) {
                return c.g(d, Xe(!0))
            });
            return Pd.apply(null, y(b)).g(Re(1), Pe())
        }
    };

    function Mp() {
        var a = Kp(Jp, Np),
            b = Op;
        return function(c) {
            var d = c.g(cf(1), id());
            c = d.g(a, Xe(!0));
            d = d.g(K(b, cf(), id()), Xe(!0));
            c = vd([c, d]);
            return Ud(c, d).g(Re(1), Pe())
        }
    };
    var Op = function(a) {
        var b = [];
        return a.g(N(function(c) {
            var d = c.I,
                e = c.ai,
                f = c.Va,
                g = c.zj,
                h = c.ca,
                k = c.yj,
                l = c.fh,
                m = c.Rb,
                u = c.ee,
                t = c.Kc,
                r = c.zg,
                w = c.eh,
                v = c.dh,
                z = c.Af;
            if (!c.lg || !t || c.Vc === void 0 || f === void 0 || g === void 0 || h === void 0 || k === void 0 || m === void 0 || d === void 0) return !1;
            if (c.Db) {
                if (l === void 0) return !1;
                g = c.sc;
                if (!g) return !1;
                g({
                    eventType: "active-view-time-on-screen",
                    eventData: z != null ? z : "",
                    destination: ["buyer"]
                });
                return !0
            }
            if (!(r || v || l)) return !1;
            z = Ep(c);
            var C;
            u = (C = u == null ? void 0 : u.Ba(z).value) != null ? C : !1;
            C = m(Object.assign({},
                c, {
                    ad: k,
                    md: u ? 4 : 3,
                    cd: l != null ? l : "u",
                    ca: h,
                    va: g
                }), z);
            if (r) {
                for (; b.length > g.length;) c = void 0, (c = b.shift()) == null || c.deactivate();
                C.forEach(function(T, oa) {
                    oa >= b.length ? b.push(d.K(T)) : b[oa].url = T
                });
                return w && e && l !== void 0 ? (C.forEach(function(T) {
                    e.K(T).sendNow()
                }), !0) : l !== void 0
            }
            if (w && e && l !== void 0) return C.forEach(function(T) {
                e.K(T).sendNow()
            }), !0;
            if (v && e) {
                for (; b.length > g.length;) w = void 0, (w = b.shift()) == null || w.deactivate();
                var Q = m(Object.assign({}, c, {
                        ad: k,
                        md: u ? 4 : 3,
                        cd: l != null ? l : "u",
                        ca: h,
                        va: ["https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fetch&later&lidartos"]
                    }),
                    z)[0];
                C.forEach(function(T, oa) {
                    oa >= b.length ? b.push(d.K(Q, {
                        cg: !0
                    })) : b[oa].url = Q
                });
                return l !== void 0 ? (C.forEach(function(T) {
                    e.K(T).sendNow()
                }), !0) : l !== void 0
            }
            return l !== void 0 ? (C.forEach(function(T) {
                d.K(T).sendNow()
            }), !0) : !1
        }), hf(function(c) {
            return !c
        }), Pe())
    };

    function Pp(a) {
        return function(b) {
            return b.g(N(function(c) {
                a.Sg || xb("Assertion on queued Observable output failed");
                return c
            }))
        }
    };

    function Qp(a) {
        return function(b) {
            return new L(function(c) {
                var d = !1,
                    e = b.g(Pp(a)).subscribe(function(f) {
                        d = !0;
                        c.next(f)
                    }, c.error.bind(c), c.complete.bind(c));
                Ta(a, function() {
                    d || c.next(null)
                }, 3);
                return e
            })
        }
    };

    function Rp(a, b) {
        return function(c) {
            return c.g(S(function(d) {
                return new L(function(e) {
                    function f() {
                        h.disconnect();
                        k.unsubscribe()
                    }
                    var g = a.MutationObserver;
                    if (g && d.j !== void 0) {
                        var h = new g(function(l) {
                            e.next(l)
                        });
                        h.observe(d.j, b);
                        var k = d.released.subscribe(f);
                        return f
                    }
                })
            }))
        }
    };
    var Sp = {
        kk: 0,
        Oj: 1,
        Qj: 2,
        Pj: 3,
        0: "UNKNOWN",
        1: "DEFER_MEASUREMENT",
        2: "DO_NOT_DEFER_MEASUREMENT",
        3: "DEFER_MEASUREMENT_AND_PING"
    };

    function Tp(a, b) {
        var c = b.g(Rp(a, {
            attributes: !0
        }), V(a.i, 1));
        return vd([b, c.g(V(a.i, 1), Qp(a.i))]).g(N(function(d) {
            return x(d).next().value
        }), bp("data-google-av-dm"), N(Up))
    }

    function Up(a) {
        return a && a in Sp ? Number(a) : 2
    };

    function Vp(a) {
        if (a.Ii === 3) return null;
        if (a.fh !== void 0) {
            var b = a.Mh === !1 ? "n" : null;
            if (b !== null) return b
        }
        return a.Dd instanceof ce ? "msf" : a.te instanceof de ? "c" : a.Kh === !1 ? "pv" : a.Dd || a.te ? "x" : null
    }
    var Wp = K(O(function(a) {
        return a.Ab !== void 0 && a.ca !== void 0 && a.Rb !== void 0 && a.cc !== void 0 && a.I !== void 0
    }), O(function(a) {
        return Vp(a) !== null
    }), pp(function(a) {
        return a.qd
    }, function(a) {
        return a.ab
    }), N(function(a) {
        if (a.Db) {
            var b = a.sc;
            if (b) {
                var c;
                b({
                    eventType: "active-view-unmeasurable",
                    eventData: (c = a.Af) != null ? c : "",
                    destination: ["buyer"]
                })
            }
        } else {
            c = void 0;
            var d = Vp(a);
            if (d === "x") {
                var e, f = (e = a.Dd) != null ? e : a.te;
                f && (b = f.stack, c = f.message)
            }
            a.Rb(Object.assign({}, a, {
                va: a.Ab,
                ca: a.ca,
                ad: a.cc,
                md: 2,
                cd: d,
                errorMessage: c,
                dg: b
            }), Ep(a)).forEach(function(g) {
                a.I.K(g).sendNow()
            })
        }
    }), Re(1), Pe());
    var Xp = function() {
            this.startTime = Math.floor(Date.now() / 1E3 - 1704067200);
            this.sequenceNumber = 0
        },
        Yp = function(a) {
            var b = a.sequenceNumber.toString(10).padStart(2, "0");
            b = "" + a.startTime + b;
            a.sequenceNumber < 99 && a.sequenceNumber++;
            return b
        };

    function Zp(a, b) {
        return typeof a === "string" ? encodeURIComponent(a) : typeof a === "number" ? String(a) : Array.isArray(a) ? a.map(function(c) {
            return Zp(c, b)
        }).join(",") : a instanceof qe ? a.toString() : a && typeof a.fa === "function" ? Zp(a.Ba(b).value, b) : a === !0 ? "1" : a === !1 ? "0" : a === void 0 || a === null ? null : a instanceof Xp ? Yp(a) : [a.top, a.left, a.top + a.height, a.left + a.width].join()
    }

    function $p(a, b) {
        a = Object.entries(a).map(function(c) {
            var d = x(c);
            c = d.next().value;
            d = d.next().value;
            d = Zp(d, b);
            return d === null ? "" : c + "=" + d
        }).filter(function(c) {
            return c !== ""
        });
        return a.length ? a.join("&") : ""
    };
    var aq = /(?:\[|%5B)([a-zA-Z0-9_]+)(?:\]|%5D)/g,
        cc = ac(bc(), "google3.javascript.ads.common.url_macros_substitutor", Rb).Fi;

    function bq(a, b) {
        return a.replace(aq, function(c, d) {
            try {
                var e = b !== null && d in b ? b[d] : void 0;
                if (e == null) return dc("No value supplied for unsupported macro: " + d), c;
                if (e.toString() == null) return dc("The toString method of value returns null for macro: " + d), c;
                e = e.toString();
                if (e == "" || !/^[\s\xa0]*$/.test(e == null ? "" : String(e))) return encodeURIComponent(e).replace(/%2C/g, ",");
                dc("Null value supplied for macro: " + d)
            } catch (f) {
                dc("Failed to set macro: " + d)
            }
            return c
        })
    };

    function cq(a, b) {
        var c = Object.assign({}, a),
            d = a.kd;
        c = (delete c.kd, c);
        c = a.ca(c);
        var e = $p(c, b);
        return Gb(a.va, function(f) {
            var g = "";
            typeof d === "string" && (g = "&" + $p({
                uach: d
            }, b));
            var h = {};
            return bq(f, (h.VIEWABILITY = e, h)) + g
        })
    };

    function Gp(a, b) {
        var c = a.ca(a),
            d = $p(c, b);
        return d ? Gb(a.va, function(e) {
            e = e.indexOf("?") >= 0 ? e : e + "?";
            e = "?&".indexOf(e.slice(-1)) >= 0 ? e : e + "&";
            return e + d
        }) : a.va
    };

    function dq(a, b) {
        return Gb(a, function(c) {
            if (typeof b.kd === "string") {
                var d = "&" + $p({
                    uach: b.kd
                }, new Map);
                return c.substring(c.length - 7) == "&adurl=" ? c.substring(0, c.length - 7) + d + "&adurl=" : c + d
            }
            return c
        })
    };
    var Np = K(O(function(a) {
        return a.ca !== void 0 && a.Ab !== void 0 && a.Rb !== void 0 && a.cc !== void 0 && a.I !== void 0
    }), N(function(a) {
        return Object.assign({}, a, {
            Xd: Ep(a)
        })
    }), O(function(a) {
        var b = a.ee;
        var c = a.Kc;
        a = a.Xd;
        var d;
        return !!c && ((d = b == null ? void 0 : b.Ba(a).value) != null ? d : !1)
    }), pp(function(a) {
        return a.rd
    }, function(a) {
        return a.ab
    }), N(function(a) {
        var b = a.I,
            c = a.Af;
        if (a.Db) {
            var d = a.sc;
            if (!d) return !1;
            d({
                eventType: "active-view-viewable",
                eventData: c != null ? c : "",
                destination: ["buyer"]
            });
            return !0
        }
        c = a.Rb(Object.assign({},
            a, {
                va: a.Ab,
                ca: a.ca,
                ad: a.cc,
                md: 4,
                cd: "v"
            }), a.Xd);
        (d = a.ve) && d.length > 0 && a.zc && a.zc(d, a).forEach(function(e) {
            b.K(e).sendNow()
        });
        (d = a.Cf) && d.length > 0 && a.zc && a.zc(d, a).forEach(function(e) {
            b.K(e).sendNow()
        });
        c.forEach(function(e) {
            b.K(e, {
                Bc: a.Xe
            }).sendNow()
        });
        return !0
    }), hf(function(a) {
        return !a
    }), Pe());

    function eq(a, b, c, d) {
        var e = Object.keys(c).map(function(h) {
                return h
            }),
            f = e.filter(function(h) {
                var k = c[h];
                h = d[h];
                return k instanceof W && h instanceof W && k.value === h.value
            }),
            g = f.reduce(function(h, k) {
                var l = {};
                return Object.assign({}, h, (l[k] = c[k], l))
            }, {});
        return e.reduce(function(h, k) {
            if (f.indexOf(k) >= 0) return h;
            var l = {};
            return Object.assign({}, h, (l[k] = b.g(S(function(m) {
                return (m = m ? c[k] : d[k]) && (m instanceof L || J(m.Gb) && J(m.subscribe)) ? m : m.X(a)
            })), l))
        }, g)
    };

    function fq(a) {
        return K(N(function() {
            return !0
        }), R(!1), V(a, 1))
    };

    function gq(a) {
        return a.length <= 0 ? Ac : vd(a.map(function(b) {
            var c = 0;
            return b.g(N(function(d) {
                return {
                    index: c++,
                    value: d
                }
            }))
        })).g(O(function(b) {
            return b.every(function(c) {
                return c.index === b[0].index
            })
        }), N(function(b) {
            return b.map(function(c) {
                return c.value
            })
        }))
    };

    function hq(a, b) {
        a.Ma && (a.Jb = a.Ma);
        a.Ma = b;
        a.Jb && a.Jb.value ? (b = Math.max(0, se(b.timestamp, a.Jb.timestamp)), a.totalTime += b, a.za += b) : a.za = 0;
        return a
    }

    function iq() {
        return K(ef(hq, {
            totalTime: 0,
            za: 0
        }), N(function(a) {
            return a.totalTime
        }))
    }

    function jq() {
        return K(ef(hq, {
            totalTime: 0,
            za: 0
        }), N(function(a) {
            return a.za
        }))
    };

    function kq(a, b) {
        return K(bp("data-google-av-metadata"), N(function(c) {
            if (c === null) return b(void 0);
            c = c.split("&").map(function(d) {
                return d.split("=")
            }).filter(function(d) {
                return d[0] === a
            });
            if (c.length === 0) return b(void 0);
            c = c[0].slice(1).join("=");
            return b(c)
        }))
    };
    var lq = {
        Kj: "asmreq",
        Lj: "asmres"
    };
    var mq = function(a) {
        uo.call(this, a)
    };
    q(mq, uo);
    mq.prototype.Vg = function(a) {
        gn(this, 1, a)
    };
    mq.W = "tagging.common.osd.AdSpeedMetricsRequest";
    mq.prototype.R = wo([0, lo]);
    var nq = function(a) {
        uo.call(this, a)
    };
    q(nq, uo);
    nq.W = "tagging.common.osd.AdSpeedMetricsResponse.Box";
    var oq = [0, eo, -3];
    nq.prototype.R = wo(oq);
    var pq = function(a) {
        uo.call(this, a)
    };
    q(pq, uo);
    pq.prototype.Vg = function(a) {
        gn(this, 1, a)
    };
    var qq = xo(pq);
    pq.W = "tagging.common.osd.AdSpeedMetricsResponse";
    pq.prototype.R = wo([0, lo, ho, oq, eo, -1]);

    function rq(a, b) {
        var c = c === void 0 ? So(a) : c;
        var d = new MessageChannel;
        b = b.g(N(function(f) {
            return Number(f)
        }), O(function(f) {
            return !isNaN(f) && f !== 0
        }), jf(function(f) {
            var g = new mq;
            g.Vg(f);
            f = {
                type: "asmreq",
                payload: g.hb()
            };
            c.postMessage(f, "*", [d.port2])
        }), Re(1));
        var e = To(a, d.port1).g(O(function(f) {
            return typeof f.data === "object"
        }), N(function(f) {
            var g = f.data;
            if (!Object.values(lq).includes(g.type) || !qh(g.payload) || f.data.type !== "asmres") return null;
            try {
                return qq(f.data.payload)
            } catch (h) {
                return null
            }
        }), O(function(f) {
            return f !==
                null
        }), N(function(f) {
            return f
        }));
        return b.g(S(function(f) {
            return Zc(f).g(Ne(e))
        }), O(function(f) {
            var g = x(f);
            f = g.next().value;
            g = g.next().value;
            if (pl(Im(g, 1)) != null) {
                var h = h === void 0 ? 0 : h;
                var k;
                g = ((k = pl(Im(g, 1))) != null ? k : h) === f
            } else g = !1;
            return g
        }), N(function(f) {
            f = x(f);
            f.next();
            return f.next().value
        }), Mh(a.i))
    };

    function sq(a, b, c) {
        var d = b.Rc.g(Re(1), S(function() {
            return rq(a, c)
        }), O(function(f) {
            return cn(f, 2) && Mm(f, nq, 3) && nl(Im(f, 4)) != null && nl(Im(f, 5)) != null
        }), Re(1), Mh(a.i));
        b = d.g(N(function(f) {
            var g = Zm(f, nq, 3);
            g = dn(g, 2);
            f = Zm(f, nq, 3);
            f = dn(f, 1);
            return {
                x: g,
                y: f
            }
        }), P(function(f, g) {
            return f.x === g.x && f.y === g.y
        }), V(a.i, 1));
        var e = d.g(N(function(f) {
            return dn(f, 4)
        }), V(a.i, 1));
        d = d.g(N(function(f) {
            return dn(f, 5)
        }), V(a.i, 1));
        return {
            li: e,
            Bh: b,
            Ei: d
        }
    };

    function tq(a, b) {
        return b.Rc.g(Re(1), N(function() {
            return a.l.now().round()
        }))
    };
    var uq = N(function(a) {
        return [a.value.da.width, a.value.da.height]
    });

    function vq(a, b) {
        return function(c) {
            return gq(b.map(function(d) {
                return c.g(a(d))
            }))
        }
    };

    function wq() {
        var a;
        return K(jf(function(b) {
            return void(a = b.timestamp)
        }), jq(), N(function(b) {
            return {
                timestamp: a,
                value: Math.round(b)
            }
        }))
    };
    var xq = function(a, b) {
            this.Vf = a;
            this.options = b;
            this.Se = this.Re = null
        },
        yq = function(a, b) {
            b ? a.Se || (b = Object.assign({}, a.options, {
                delay: 100,
                trackVisibility: !0
            }), a.Se = new IntersectionObserver(a.Vf, b)) : a.Re || (a.Re = new IntersectionObserver(a.Vf, a.options))
        },
        zq = function(a, b) {
            a = b ? a.Se : a.Re;
            if (!a) throw new fe;
            return a
        };
    xq.prototype.observe = function(a, b) {
        zq(this, a).observe(b)
    };
    xq.prototype.unobserve = function(a, b) {
        zq(this, a).unobserve(b)
    };
    xq.prototype.disconnect = function(a) {
        zq(this, a).disconnect()
    };
    xq.prototype.takeRecords = function(a) {
        return zq(this, a).takeRecords()
    };
    var Aq = {
        oa: "ns",
        qa: wi,
        da: wi,
        ma: new xc,
        Z: "ns",
        O: wi,
        aa: wi,
        wa: {
            x: 0,
            y: 0
        }
    };

    function Bq(a, b) {
        return xi(a.da, b.da) && xi(a.O, b.O) && xi(a.qa, b.qa) && xi(a.aa, b.aa) && a.Z === b.Z && a.ma === b.ma && a.oa === b.oa && a.wa.x === b.wa.x && a.wa.y === b.wa.y
    };

    function Cq(a, b) {
        return function(c) {
            return function(d) {
                var e = d.g(af(new xc), id());
                d = c.element.g(P());
                e = e.g(N(function(f) {
                    return f.value
                }));
                return vd([d, e, b]).g(N(function(f) {
                    var g = x(f);
                    f = g.next().value;
                    var h = g.next().value;
                    g = g.next().value;
                    if (f.j === void 0) var k = {
                        top: 0,
                        left: 0,
                        width: 0,
                        height: 0
                    };
                    else {
                        k = f.j.getBoundingClientRect();
                        var l = f.j,
                            m = a.global,
                            u = new vh(0, 0);
                        var t = (t = yh(l)) ? t.defaultView : window;
                        if (Kg(t, "parent")) {
                            do {
                                if (t == m) {
                                    var r = l,
                                        w = yh(r);
                                    Cb(r, "Parameter is required");
                                    var v = new vh(0, 0);
                                    var z =
                                        (w ? yh(w) : document).documentElement;
                                    r != z && (r = Eh(r), w = zh(w), w = Ah(w.Jc), v.x = r.left + w.x, v.y = r.top + w.y)
                                } else v = F(l), v = Eh(v), v = new vh(v.left, v.top);
                                u.x += v.x;
                                u.y += v.y
                            } while (t && t != m && t != t.parent && (l = t.frameElement) && (t = t.parent))
                        }
                        k = {
                            top: u.y,
                            left: u.x,
                            width: k.width,
                            height: k.height
                        }
                    }
                    k = zi(k, h.wa);
                    m = yi(k, h.qa);
                    u = a.l.now();
                    t = Object;
                    l = t.assign;
                    if (g !== 2 || a.Cb || m.width <= 0 || m.height <= 0) var C = !1;
                    else try {
                        var Q = a.document.elementFromPoint(m.left + m.width / 2, m.top + m.height / 2);
                        C = Q ? !Dq(Q, f) : !1
                    } catch (T) {
                        C = !1
                    }
                    return {
                        timestamp: u,
                        value: l.call(t, {}, h, {
                            Z: "geo",
                            aa: C ? Aq.aa : m,
                            O: k
                        })
                    }
                }), Mh(a.i))
            }
        }
    }

    function Dq(a, b, c) {
        c = c === void 0 ? 0 : c;
        return a.j === void 0 || b.j === void 0 ? !1 : a.j === b.j || Ch(b.j, function(d) {
            return d === a.j
        }) ? !0 : b.j.ownerDocument && b.j.ownerDocument.defaultView && b.j.ownerDocument.defaultView === b.j.ownerDocument.defaultView.top ? !1 : c < 10 && b.j.ownerDocument && b.j.ownerDocument.defaultView && b.j.ownerDocument.defaultView.frameElement ? Dq(a, new $h(b.j.ownerDocument.defaultView.frameElement), c + 1) : !0
    };

    function Eq(a) {
        return function(b) {
            return b.g(a.ResizeObserver ? Fq(a) : Gq(a), cf(1), id())
        }
    }

    function Fq(a) {
        return function(b) {
            return b.g(S(function(c) {
                var d = a.ResizeObserver;
                if (!d || c.j === void 0) return Zc(Aq.O);
                var e = (new L(function(f) {
                    function g() {
                        c.j !== void 0 && h.unobserve(c.j);
                        h.disconnect();
                        k.unsubscribe()
                    }
                    if (c.j === void 0) return f.complete(),
                        function() {};
                    var h = new d(function(l) {
                        l.forEach(function(m) {
                            f.next(m)
                        })
                    });
                    h.observe(c.j);
                    var k = c.released.subscribe(g);
                    return g
                })).g(sg(a.L, 736), N(function(f) {
                    return f.contentRect
                }));
                return Pd(Zc(c.j.getBoundingClientRect()), e)
            }), P(xi))
        }
    }

    function Gq(a) {
        return function(b) {
            var c = b.g(Rp(a, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                })),
                d = a.Vi;
            c = Pd(b.g(N(function() {
                return Zh("resize")
            })), c, d);
            return vd(b, c).g(sg(a.L, 737), N(function(e) {
                e = x(e).next().value;
                return e.j === void 0 ? void 0 : e.j.getBoundingClientRect()
            }), jp(), P(xi))
        }
    };

    function Hq(a, b) {
        var c = Iq(a, b).g(cf(1), id());
        return function(d) {
            return function(e) {
                e = e.g(S(function(f) {
                    return f.element
                }), P());
                return vd([c, e]).g(S(function(f) {
                    var g = x(f);
                    f = g.next().value;
                    g = g.next().value;
                    return Jq(a, f.ti, Eq(a), f.Ti, d, f.bi, g)
                }), Mh(a.i))
            }
        }
    }

    function Kq(a, b, c) {
        var d = Hq(a, c)(b);
        return function(e) {
            var f = d(Zc(e));
            return function(g) {
                return vd([g, f]).g(N(function(h) {
                    var k = x(h);
                    h = k.next().value;
                    k = k.next().value;
                    var l = zi(k.value.O, h.value.wa),
                        m = yi(zi(k.value.aa, h.value.wa), h.value.qa);
                    return {
                        timestamp: h.timestamp.maximum(k.timestamp),
                        value: Object.assign({}, h.value, {
                            Z: "nio",
                            aa: m,
                            O: l
                        })
                    }
                }))
            }
        }
    }

    function Lq(a) {
        return N(function(b) {
            return b.value.oa !== "nio" ? b : Object.assign({}, b, {
                value: Object.assign({}, b.value, {
                    qa: Uo(a, !0),
                    da: Uo(a, !0)
                })
            })
        })
    }

    function Mq(a, b) {
        return Zc(b).g(a, N(function() {
            return b
        }))
    }

    function Iq(a, b) {
        return a.l.timeline !== oe ? $c(new ce(2)) : a.MutationObserver ? typeof IntersectionObserver === "undefined" ? $c(new ce(0)) : (new L(function(c) {
            var d = new xc,
                e = new xq(d.next.bind(d), {
                    threshold: [].concat(y(b))
                });
            c.next({
                Ti: d.g(sg(a.L, 735)),
                ti: e,
                bi: function(f) {
                    f = e.takeRecords(f);
                    f.length > 0 && d.next(f)
                }
            })
        })).g(Re(1), cf(1), id()) : $c(new ce(1))
    }

    function Nq(a) {
        return Kc(a.sort(function(b, c) {
            return b.time - c.time
        }), md)
    }

    function Jq(a, b, c, d, e, f, g) {
        return new L(function(h) {
            function k() {
                w || (w = !0, g.j !== void 0 && b.unobserve(e, g.j), m.unsubscribe(), r.unsubscribe(), t.unsubscribe(), v.unsubscribe())
            }
            if (g.j !== void 0) {
                yq(b, e);
                b.observe(e, g.j);
                var l = new zc({
                        timestamp: a.l.now(),
                        value: Object.assign({}, Aq, {
                            oa: "nio",
                            Z: "nio"
                        })
                    }),
                    m = d.g(Bd(function(z) {
                        return Nq(z)
                    }), O(function(z) {
                        return z.target === g.j
                    }), N(function(z) {
                        return {
                            timestamp: new qe(z.time, oe),
                            value: {
                                oa: "nio",
                                qa: z.rootBounds || wi,
                                da: z.rootBounds || Uo(a, !0),
                                ma: u,
                                Z: "nio",
                                aa: z.intersectionRect,
                                O: z.boundingClientRect,
                                wa: {
                                    x: 0,
                                    y: 0
                                },
                                isIntersecting: z.isIntersecting,
                                Ig: z.isVisible
                            }
                        }
                    }), af(l), id()).subscribe(h),
                    u = new xc,
                    t = u.subscribe(function() {
                        f(e);
                        h.next({
                            timestamp: a.l.now(),
                            value: l.value.value
                        });
                        g.j !== void 0 && (b.unobserve(e, g.j), b.observe(e, g.j))
                    }),
                    r = Mq(c, g).subscribe(function() {
                        u.next()
                    }),
                    w = !1,
                    v = g.released.subscribe(function() {
                        return k()
                    });
                return k
            }
        })
    };

    function Oq(a, b) {
        var c = a.Ie().g(N(function() {
            return "b"
        }));
        return Ud(b, c).g(Re(1), V(a.i, 1))
    };

    function Pq(a) {
        return function(b) {
            var c;
            return b.g(jf(function(d) {
                return void(c = d.timestamp)
            }), N(function(d) {
                return d.value
            }), a, N(function(d) {
                return {
                    timestamp: c,
                    value: d
                }
            }))
        }
    };

    function Qq(a) {
        return a.aa.width * a.aa.height / (a.O.width * a.O.height)
    }
    var Rq = Pq(K(N(function(a) {
            var b;
            return (b = a.Cd) != null ? b : Qq(a)
        }), N(function(a) {
            return isFinite(a) ? a : 0
        }))),
        Sq = Pq(K(N(function(a) {
            var b;
            return (b = a.Cd) != null ? b : Qq(a)
        }), N(function(a) {
            return isFinite(a) ? a : -1
        })));
    var Tq = function(a, b) {
        this.a = a;
        this.b = b;
        if (a.clock.timeline !== b.clock.timeline) throw Error();
    };
    Tq.prototype.ea = function(a) {
        return a instanceof Tq ? this.a.ea(a.a) && this.b.ea(a.b) : !1
    };
    Tq.prototype.Aa = function(a) {
        var b = this.a.Aa(a).value,
            c = this.b.Aa(a).value;
        return {
            timestamp: a,
            value: [b, c]
        }
    };
    da.Object.defineProperties(Tq.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.a.active || this.b.active
            }
        },
        clock: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.a.clock
            }
        },
        H: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a = this.a.H.timestamp.maximum(this.b.H.timestamp),
                    b = this.a.H.timestamp.equals(a) ? this.a.H.value : this.a.Aa(a).value,
                    c = this.b.H.timestamp.equals(a) ? this.b.H.value : this.b.Aa(a).value;
                return {
                    timestamp: a,
                    value: [b, c]
                }
            }
        }
    });
    var Uq = function(a, b) {
        this.input = a;
        this.Od = b;
        this.H = {
            timestamp: this.input.H.timestamp,
            value: this.Od(this.input.H.value)
        }
    };
    Uq.prototype.ea = function(a) {
        return a instanceof Uq ? this.input.ea(a.input) && this.Od === a.Od : !1
    };
    Uq.prototype.Aa = function(a) {
        a = this.input.Aa(a);
        return {
            timestamp: a.timestamp,
            value: this.Od(a.value)
        }
    };
    da.Object.defineProperties(Uq.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.input.active
            }
        },
        clock: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.input.clock
            }
        }
    });

    function Vq(a, b, c) {
        c = c === void 0 ? function(d, e) {
            return d === e
        } : c;
        return a.timestamp.equals(b.timestamp) && c(a.value, b.value)
    };
    var Wq = function(a, b, c) {
        this.clock = a;
        this.H = b;
        this.active = c
    };
    Wq.prototype.ea = function(a) {
        return a instanceof Wq ? this.active === a.active && this.clock.timeline === a.clock.timeline && Vq(this.H, a.H) : !1
    };
    Wq.prototype.Aa = function(a) {
        return {
            timestamp: a,
            value: this.H.value + (this.active ? Math.max(0, se(a, this.H.timestamp)) : 0)
        }
    };
    var Xq = function() {};
    Xq.prototype.fa = function() {
        return this.Aa(this.clock.now())
    };
    Xq.prototype.Ba = function(a) {
        var b = this.clock.timeline,
            c, d = (c = a.get(b)) != null ? c : this.clock.now();
        a.set(b, d);
        return this.Aa(d)
    };
    Xq.prototype.map = function(a) {
        return new Yq(this, a)
    };
    Xq.prototype.Ca = function(a) {
        return new Zq(this, a)
    };
    var Zq = function() {
        Tq.apply(this, arguments);
        this.map = Xq.prototype.map;
        this.Ca = Xq.prototype.Ca;
        this.fa = Xq.prototype.fa;
        this.Ba = Xq.prototype.Ba
    };
    q(Zq, Tq);
    var $q = function() {
        Wq.apply(this, arguments);
        this.map = Xq.prototype.map;
        this.Ca = Xq.prototype.Ca;
        this.fa = Xq.prototype.fa;
        this.Ba = Xq.prototype.Ba
    };
    q($q, Wq);
    var Yq = function() {
        Uq.apply(this, arguments);
        this.map = Xq.prototype.map;
        this.Ca = Xq.prototype.Ca;
        this.fa = Xq.prototype.fa;
        this.Ba = Xq.prototype.Ba
    };
    q(Yq, Uq);

    function ar(a, b) {
        a.Ma && (a.Jb = a.Ma);
        a.Ma = b;
        a.Jb && a.Jb.value ? (b = Math.max(0, se(b.timestamp, a.Jb.timestamp)), a.totalTime += b, a.za += b) : a.za = 0;
        return a
    }

    function br(a) {
        return K(ef(ar, {
            totalTime: 0,
            za: 0
        }), N(function(b) {
            return new $q(a, {
                timestamp: b.Ma.timestamp,
                value: b.totalTime
            }, b.Ma.value)
        }))
    }

    function cr(a) {
        return K(ef(ar, {
            totalTime: 0,
            za: 0
        }), N(function(b) {
            return new $q(a, {
                timestamp: b.Ma.timestamp,
                value: b.za
            }, b.Ma.value)
        }))
    };

    function dr(a) {
        return K(cr(a), N(function(b) {
            return b.map(function(c) {
                return Math.round(c)
            })
        }))
    };
    var er = function(a, b) {
        this.H = b;
        this.fa = Xq.prototype.fa;
        this.Ba = Xq.prototype.Ba;
        this.map = Xq.prototype.map;
        this.Ca = Xq.prototype.Ca;
        this.clock = a
    };
    er.prototype.ea = function(a) {
        return a.active
    };
    er.prototype.Aa = function() {
        return this.H
    };
    da.Object.defineProperties(er.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return !1
            }
        }
    });

    function fr(a, b) {
        return b.g(N(function(c) {
            return new er(a.l, {
                timestamp: a.l.now(),
                value: c
            })
        }))
    };

    function gr(a, b) {
        return a >= 1 ? !0 : a <= 0 ? !1 : a >= b
    };

    function hr(a) {
        return function(b) {
            return b.g(kf(a), N(function(c) {
                var d = x(c);
                c = d.next().value;
                d = d.next().value;
                return {
                    timestamp: c.timestamp,
                    value: gr(c.value, d)
                }
            }))
        }
    };
    var ir = N(function(a) {
        if (a.value.oa === "omid") {
            if (a.value.Z === "nio") return "omio";
            if (a.value.Z === "geo") return "omgeo"
        }
        return a.value.Z === "geo" || a.value.Z === "nio" ? a.value.oa : a.value.Z
    });

    function jr() {
        return K(O(function(a, b) {
            return b > 0
        }), kr, R(-1), P())
    }
    var kr = K(O(function(a) {
        return !isNaN(a)
    }), ef(function(a, b) {
        return isNaN(a) ? b : Math.min(a, b)
    }, NaN), P());
    var lr = Pq(K(N(function(a) {
        return a.aa.width * a.aa.height / (a.qa.width * a.qa.height)
    }), N(function(a) {
        return isFinite(a) ? Math.min(1, a) : 0
    })));

    function mr(a, b, c) {
        return a ? vd([b, c]).g(O(function(d) {
            var e = x(d);
            d = e.next().value;
            e = e.next().value;
            return d.timestamp.equals(e.timestamp)
        }), N(function(d) {
            var e = x(d);
            d = e.next().value;
            e = e.next().value;
            return d.value > e.value ? d : e
        })) : b
    }

    function nr(a) {
        return function(b) {
            var c = b.g(Rq),
                d = b.g(lr);
            return a instanceof L ? a.g(S(function(e) {
                return mr(e, c, d)
            })) : mr(a.value, c, d)
        }
    };
    var or = K(Pq(N(function(a) {
        a = a.Cd ? a.O.width * a.O.height * a.Cd / (a.da.width * a.da.height) : a.aa.width * a.aa.height / (a.da.width * a.da.height);
        return isFinite(a) ? a : 0
    })));

    function pr(a, b, c, d) {
        var e = d.Ed,
            f = d.Ce,
            g = d.nh,
            h = d.Qf,
            k = d.Ye,
            l = d.Kg,
            m = d.Hd;
        d = d.jh;
        b = qr(a, c, b);
        c = rr(a, c);
        d = sr(b, d);
        var u = tr(a, e, l, b),
            t = u.g(N(function(D) {
                return D.value
            }), P(), V(a, 1), ef(function(D, fa) {
                return Math.max(D, fa)
            }, 0)),
            r = u.g(N(function(D) {
                return D.value
            }), jr(), V(a, 1)),
            w = b.g(Sq, N(function(D) {
                return D.value
            }), Re(2), P(), V(a, 1));
        g = ur(a, b, g, h);
        var v = g.g(R(!1), P(), N(function(D) {
            return D ? k : f
        }));
        h = u.g(hr(v), P(), V(a, 1));
        var z = vd([h, b]).g(O(function(D) {
            var fa = x(D);
            D = fa.next().value;
            fa = fa.next().value;
            return D.timestamp.equals(fa.timestamp)
        }), N(function(D) {
            var fa = x(D);
            D = fa.next().value;
            fa = fa.next().value;
            return {
                visible: D.value,
                geometry: fa.value.O
            }
        }), ef(function(D, fa) {
            return !fa.visible && D.visible ? D : fa
        }, {
            visible: !1,
            geometry: wi
        }), N(function(D) {
            return D.geometry
        }), R(wi), V(a, 1), P(xi));
        l = l instanceof L ? l.g(P(), Qe()) : Qd;
        v = vd([l, v]).g(Qe());
        var C = b.g(O(function(D) {
                return D.value.oa !== "ns" && D.value.Z !== "ns"
            }), ef(function(D) {
                return D + 1
            }, 0), R(0), V(a, 1)),
            Q = c.g(Qe(!0), R(!1), V(a, 1));
        Q = vd([m, Q]).g(N(function(D) {
            var fa =
                x(D);
            D = fa.next().value;
            fa = fa.next().value;
            return D && !fa
        }), V(a, 1));
        var T = b.g(or, P()),
            oa = T.g(N(function(D) {
                return D.value
            }), ef(function(D, fa) {
                return Math.max(D, fa)
            }, 0), P(), V(a, 1)),
            H = T.g(N(function(D) {
                return D.value
            }), jr(), V(a, 1));
        return {
            tf: l,
            hd: v,
            Fa: {
                cj: b,
                Lg: b.g(ir),
                yd: z.g(P(xi)),
                visible: h.g(P(Vq)),
                yf: u.g(P(Vq)),
                Jg: t,
                Ni: r,
                Tf: b.g(uq, P(Kb)),
                Bj: T,
                Gi: oa,
                Mi: H,
                Dd: c,
                ma: (new W(new xc)).X(a),
                Fg: g,
                Ed: e,
                Hd: m,
                lg: Q,
                Cj: C,
                Di: w,
                ce: d
            }
        }
    }

    function rr(a, b) {
        return b.g(O(function() {
            return !1
        }), N(function(c) {
            return c
        }), Ie(function(c) {
            return (new W(c)).X(a)
        }))
    }

    function sr(a, b) {
        a = vd([a, b]).g(N(function(e) {
            var f = x(e);
            e = f.next().value;
            if (f.next().value && e.value.isIntersecting) return e.value.Ig
        }), P());
        var c = a.g(N(function(e) {
                return e === void 0 ? !0 : e
            }), ef(function(e, f) {
                return e || !f
            }, !1)),
            d = a.g(ef(function(e, f) {
                return f === void 0 ? e : f ? !1 : e != null ? e : !0
            }, void 0), N(function(e) {
                return !!e
            }));
        return vd([b, Wd(a, c, d)]).g(N(function(e) {
            var f = x(e);
            e = f.next().value;
            var g = x(f.next().value);
            f = g.next().value;
            var h = g.next().value;
            g = g.next().value;
            var k = 0;
            if (!e) return 0;
            if (f === void 0) return 16;
            f && (k |= 1);
            f || (k |= 2);
            h && (k |= 4);
            g && (k |= 8);
            return k
        }))
    }

    function qr(a, b, c) {
        return b.g(Td(Qd), V(a, 1)).g(P(function(d, e) {
            return Vq(d, e, Bq)
        }), R({
            timestamp: c.now(),
            value: Aq
        }), V(a, 1))
    }

    function tr(a, b, c, d) {
        c = d.g(nr(c), Pq(N(function(e) {
            return Math.round(e * 100) / 100
        })), V(a, 1));
        return b instanceof W ? c : vd([c, b]).g(N(function(e) {
            var f = x(e);
            e = f.next().value;
            f = f.next().value;
            return {
                timestamp: f.timestamp.maximum(e.timestamp),
                value: f.value ? 0 : e.value
            }
        }), P(Vq), V(a, 10))
    }

    function ur(a, b, c, d) {
        b = [b.g(N(function(e) {
            return e.value.O.width * e.value.O.height >= 242500
        }))];
        c instanceof L && b.push(c.g(N(function(e) {
            return !!e
        })));
        c = vd(b);
        return d ? c.g(N(function(e) {
            return e.some(function(f) {
                return f
            })
        }), R(!1), P(), V(a, 1)) : (new W(!1)).X(a)
    };
    var vr = function(a) {
            this.l = a;
            this.Wd = null;
            this.timeout = new xc
        },
        xr = function(a, b) {
            wr(a);
            a.Wd = a.l.setTimeout(function() {
                return void a.timeout.next()
            }, b)
        },
        wr = function(a) {
            a.Wd !== null && (a.l.clearTimeout(a.Wd), a.Wd = null)
        };

    function yr(a, b, c, d) {
        var e = zr.gh,
            f = new vr(b);
        c = c.g(R(void 0), S(function() {
            wr(f);
            return d
        })).g(N(function(g) {
            wr(f);
            var h = g.H,
                k = g.active;
            h.value >= e || !k || (k = b.now(), k = Math.max(0, se(k, h.timestamp)), xr(f, Math.max(0, e - h.value - k)));
            return g.map(function(l) {
                return l >= e
            })
        }));
        return vd([c, Pd(f.timeout, Zc(void 0))]).g(N(function(g) {
            return x(g).next().value
        }), hf(function(g) {
            return !g.fa().value
        }, !0), V(a, 1))
    };

    function Ar(a) {
        var b = new $q(a, {
            timestamp: a.now(),
            value: 0
        }, !1);
        return K(cr(a), ef(function(c, d) {
            return c.H.value > d.H.value ? new $q(a, c.H, !1) : d
        }, b), N(function(c) {
            return c.map(function(d) {
                return Math.round(d)
            })
        }))
    };

    function Br(a) {
        return function(b) {
            return K(hr(Zc(b)), Ar(a))
        }
    };

    function Cr(a) {
        return function(b) {
            return K(Pq(N(function(c) {
                return gr(c, b)
            })), br(a), N(function(c) {
                return c.map(function(d) {
                    return Math.round(d)
                })
            }))
        }
    };

    function Dr(a) {
        return a.map(function(b) {
            return b.map(function(c) {
                return [c]
            })
        }).reduce(function(b, c) {
            return b.Ca(c).map(function(d) {
                return d.flat()
            })
        })
    }

    function Er(a, b) {
        return a.Ca(b).map(function(c) {
            var d = x(c);
            c = d.next().value;
            d = d.next().value;
            return c - d
        })
    }

    function Fr(a, b, c, d, e, f) {
        var g = Gr;
        if (g.length > 1)
            for (var h = 0; h < g.length - 1; h++)
                if (g[h] < g[h + 1]) throw Error();
        h = f.g(R(void 0), S(function() {
            return d.g(dr(a))
        }), P(function(k, l) {
            return k.ea(l)
        }), V(b, 1));
        f = f.g(R(void 0), S(function() {
            return d.g(Ar(a))
        }), P(function(k, l) {
            return k.ea(l)
        }), V(b, 1));
        return {
            Yd: e.g(R(void 0), S(function() {
                return c.g(N(function(k) {
                    return {
                        timestamp: k.timestamp,
                        value: !0
                    }
                }), br(a))
            }), P(function(k, l) {
                return k.ea(l)
            }), V(b, 1)),
            Zd: e.g(R(void 0), S(function() {
                return c.g(N(function(k) {
                    return {
                        timestamp: k.timestamp,
                        value: k.value === 0
                    }
                }), br(a))
            }), P(function(k, l) {
                return k.ea(l)
            }), V(b, 1)),
            Vc: e.g(R(void 0), S(function() {
                return c.g(vq(Br(a), g))
            }), N(Dr), P(function(k, l) {
                return k.ea(l)
            }), V(b, 1)),
            Va: e.g(R(void 0), S(function() {
                return c.g(vq(Cr(a), g), N(function(k) {
                    return k.map(function(l, m) {
                        return m > 0 ? Er(l, k[m - 1]) : l
                    })
                }))
            }), N(Dr), P(function(k, l) {
                return k.ea(l)
            }), V(b, 1)),
            Uc: f,
            pb: h.g(P(function(k, l) {
                return k.ea(l)
            }), V(b, 1))
        }
    };

    function Hr(a) {
        var b;
        if (b = Ir(a)) b = !Jr(a, "abgcp") && !Jr(a, "abgc") && !(typeof a.id === "string" && a.id === "abgb") && !(typeof a.id === "string" && a.id === "mys-abgc") && !Jr(a, "cbb");
        return b
    }

    function Jr(a, b) {
        return a.classList ? a.classList.contains(b) : (" " + a.className + " ").indexOf(" " + b + " ") > -1
    }

    function Ir(a) {
        try {
            var b = a.getBoundingClientRect();
            return b && b.height >= 30 && b.width >= 30
        } catch (c) {
            return !1
        }
    }

    function Kr(a, b) {
        if (a.j === void 0 || !a.j.children) return a;
        for (var c = Jb(a.j.children); c.length;) {
            var d = b ? c.filter(Hr) : c.filter(Ir);
            if (d.length === 1) return new $h(d[0]);
            if (d.length > 1) break;
            c = Mb(c, function(e) {
                return Jb(e.children)
            })
        }
        return a
    }

    function Lr(a, b, c, d, e) {
        if (c) return {
            xd: b,
            Kb: Zc(null)
        };
        c = b.element.g(N(function(f) {
            a: if (f.j === void 0 || Ir(f.j)) f = {
                    Pd: f,
                    Kb: "mue"
                };
                else {
                    var g = Kr(f, e);
                    if (g.j !== void 0 && Ir(g.j)) f = {
                        Pd: g,
                        Kb: "ie"
                    };
                    else {
                        if (d || a.Oe)
                            if (g = a.document.querySelector(".GoogleActiveViewInnerContainer")) {
                                f = {
                                    Pd: new $h(g),
                                    Kb: "ce"
                                };
                                break a
                            }
                        f = {
                            Pd: f,
                            Kb: "mue"
                        }
                    }
                }return f
        }), ff());
        return {
            xd: {
                Pb: b.Pb,
                element: c.g(N(function(f) {
                    return f.Pd
                }))
            },
            Kb: c.g(N(function(f) {
                return f.Kb
            }))
        }
    };

    function Mr(a, b, c, d) {
        var e = d.Ed,
            f = d.Ce,
            g = d.nh,
            h = d.Qf,
            k = d.Ye,
            l = d.Kg,
            m = d.Hd;
        d = d.jh;
        b = Nr(a, c, b);
        c = Or(a, c);
        d = Pr(b, d);
        var u = Qr(a, e, l, b),
            t = u.g(N(function(H) {
                return H.value
            }), P(), V(a, 1), ef(function(H, D) {
                return Math.max(H, D)
            }, 0)),
            r = u.g(N(function(H) {
                return H.value
            }), jr(), V(a, 1)),
            w = b.g(Sq, N(function(H) {
                return H.value
            }), Re(2), P(), V(a, 1));
        g = Rr(a, b, g, h);
        var v = g.g(R(!1), P(), N(function(H) {
            return H ? k : f
        }));
        h = u.g(hr(v), P(), V(a, 1));
        var z = vd([h, b]).g(O(function(H) {
                var D = x(H);
                H = D.next().value;
                D = D.next().value;
                return H.timestamp.equals(D.timestamp)
            }),
            N(function(H) {
                var D = x(H);
                H = D.next().value;
                D = D.next().value;
                return {
                    visible: H.value,
                    geometry: D.value.O
                }
            }), ef(function(H, D) {
                return !D.visible && H.visible ? H : D
            }, {
                visible: !1,
                geometry: wi
            }), N(function(H) {
                return H.geometry
            }), R(wi), V(a, 1), P(xi));
        l = l instanceof L ? l.g(P(), Qe()) : Qd;
        v = vd([l, v]).g(Qe());
        var C = b.g(O(function(H) {
                return H.value.oa !== "ns" && H.value.Z !== "ns"
            }), ef(function(H) {
                return H + 1
            }, 0), R(0), V(a, 1)),
            Q = c.g(Qe(!0), R(!1), V(a, 1));
        Q = vd([m, Q]).g(N(function(H) {
            var D = x(H);
            H = D.next().value;
            D = D.next().value;
            return H &&
                !D
        }), V(a, 1));
        var T = b.g(or, P()),
            oa = T.g(N(function(H) {
                return H.value
            }), ef(function(H, D) {
                return Math.max(H, D)
            }, 0), P(), V(a, 1));
        a = T.g(N(function(H) {
            return H.value
        }), jr(), V(a, 1));
        return {
            tf: l,
            hd: v,
            Fa: {
                cj: b,
                Lg: b.g(ir),
                yd: z.g(P(xi)),
                visible: h.g(P(Vq)),
                yf: u.g(P(Vq)),
                Jg: t,
                Ni: r,
                Tf: b.g(uq, P(Kb)),
                Bj: T,
                Gi: oa,
                Mi: a,
                Dd: c,
                ma: b.g(N(function(H) {
                    return H.value.ma
                })),
                Fg: g,
                Ed: e,
                Hd: m,
                lg: Q,
                Cj: C,
                Di: w,
                ce: d
            }
        }
    }

    function Or(a, b) {
        return b.g(O(function() {
            return !1
        }), N(function(c) {
            return c
        }), Ie(function(c) {
            return (new W(c)).X(a)
        }))
    }

    function Nr(a, b, c) {
        return b.g(Td(Qd), V(a, 1)).g(P(function(d, e) {
            return Vq(d, e, Bq)
        }), R({
            timestamp: c.now(),
            value: Aq
        }), V(a, 1))
    }

    function Qr(a, b, c, d) {
        c = d.g(nr(c), Pq(N(function(e) {
            return Math.round(e * 100) / 100
        })), V(a, 1));
        return b instanceof W ? c : vd([c, b]).g(N(function(e) {
            var f = x(e);
            e = f.next().value;
            f = f.next().value;
            return {
                timestamp: f.timestamp.maximum(e.timestamp),
                value: f.value ? 0 : e.value
            }
        }), P(Vq), V(a, 1))
    }

    function Rr(a, b, c, d) {
        b = [b.g(N(function(e) {
            return e.value.O.width * e.value.O.height >= 242500
        }))];
        c instanceof L && b.push(c.g(N(function(e) {
            return !!e
        })));
        c = vd(b);
        return d ? c.g(N(function(e) {
            return e.some(function(f) {
                return f
            })
        }), R(!1), P(), V(a, 1)) : (new W(!1)).X(a)
    }

    function Pr(a, b) {
        a = vd([a, b]).g(N(function(e) {
            var f = x(e);
            e = f.next().value;
            if (f.next().value && e.value.isIntersecting) return e.value.Ig
        }), P());
        var c = a.g(N(function(e) {
                return e === void 0 ? !0 : e
            }), ef(function(e, f) {
                return e || !f
            }, !1)),
            d = a.g(ef(function(e, f) {
                return f === void 0 ? e : f ? !1 : e != null ? e : !0
            }, void 0), N(function(e) {
                return !!e
            }));
        return vd([b, Wd(a, c, d)]).g(N(function(e) {
            var f = x(e);
            e = f.next().value;
            var g = x(f.next().value);
            f = g.next().value;
            var h = g.next().value;
            g = g.next().value;
            var k = 0;
            if (!e) return 0;
            if (f === void 0) return 16;
            f && (k |= 1);
            f || (k |= 2);
            h && (k |= 4);
            g && (k |= 8);
            return k
        }))
    };
    var Sr = K(bp("data-google-av-itpl"), N(function(a) {
        return Number(a)
    }), N(function(a) {
        return isNaN(a) ? 1 : a
    }));
    var Tr = {
            Jj: "addEventListener",
            Tj: "getMaxSize",
            Uj: "getScreenSize",
            Vj: "getState",
            Wj: "getVersion",
            hk: "removeEventListener",
            ck: "isViewable"
        },
        Ur = function(a, b) {
            this.Da = null;
            this.ri = new xc;
            b = b || this.Dj;
            var c = a.Oe,
                d = !a.Cb;
            if (c && d) {
                var e = a.global.top.mraid;
                if (e) {
                    this.wd = b(e);
                    this.Da = e;
                    this.Ob = 3;
                    return
                }
            }(a = a.global.mraid) ? (this.wd = b(a), this.Da = a, this.Ob = c ? d ? 2 : 1 : 0) : (this.Ob = -1, this.wd = 2)
        };
    Ur.prototype.addEventListener = function(a, b) {
        return this.tc("addEventListener", a, b)
    };
    Ur.prototype.removeEventListener = function(a, b) {
        return this.tc("removeEventListener", a, b)
    };
    Ur.prototype.rg = function() {
        var a = this.tc("getVersion");
        return typeof a === "string" ? a : ""
    };
    Ur.prototype.getState = function() {
        var a = this.tc("getState");
        return typeof a === "string" ? a : ""
    };
    var Vr = function(a) {
            a = a.tc("isViewable");
            return typeof a === "boolean" ? a : !1
        },
        Wr = function(a) {
            if (a.Da) return a = a.Da.AFMA_LIDAR, typeof a === "string" ? a : void 0
        };
    Ur.prototype.Dj = function(a) {
        return a ? a.IS_GMA_SDK ? Object.values(Tr).every(function(b) {
            return typeof a[b] === "function"
        }) ? 0 : 1 : 2 : 1
    };
    Ur.prototype.tc = function(a) {
        var b = E.apply(1, arguments);
        if (this.Da) try {
            return this.Da[a].apply(this.Da, y(b))
        } catch (c) {
            this.ri.next(a)
        }
    };
    da.Object.defineProperties(Ur.prototype, {
        bg: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                if (this.Da) {
                    var a = this.Da.AFMA_LIDAR_EXP_1;
                    return a === void 0 ? void 0 : !!a
                }
            },
            set: function(a) {
                this.Da && (this.Da.AFMA_LIDAR_EXP_1 = a)
            }
        }
    });

    function Xr(a, b) {
        return (new Ur(a)).Ob !== -1 ? (new W(!0)).X(a.i) : b.g(bp("data-google-av-inapp"), N(function(c) {
            return c !== null
        }), V(a.i, 1))
    };
    var Zr = function(a, b) {
            var c = this;
            this.l = a;
            this.af = this.Md = null;
            this.gj = b.g(P()).subscribe(function(d) {
                Yr(c);
                c.af = d
            })
        },
        $r = function(a, b) {
            Yr(a);
            a.Md = a.l.setTimeout(function() {
                var c;
                return void((c = a.af) == null ? void 0 : c.next())
            }, b)
        },
        Yr = function(a) {
            a.Md !== null && a.l.clearTimeout(a.Md);
            a.Md = null
        };
    Zr.prototype.dispose = function() {
        Yr(this);
        this.gj.unsubscribe();
        this.af = null
    };

    function as(a, b, c, d, e) {
        var f = zr.gh;
        var g = g === void 0 ? new Zr(b, d) : g;
        return (new L(function(h) {
            var k = c.g(R(void 0), S(function() {
                return bs(e)
            })).g(N(function(l) {
                var m = l.value;
                l = l.timestamp;
                var u = m.visible;
                m = m.pb;
                var t = m >= f;
                t || !u ? Yr(g) : (l = Math.max(0, se(b.now(), l)), $r(g, Math.max(0, f - m - l)));
                return t
            }), ef(function(l, m) {
                return m || l
            }, !1), P()).subscribe(h);
            return function() {
                g.dispose();
                k.unsubscribe()
            }
        })).g(hf(function(h) {
            return !h
        }, !0), V(a, 1))
    }

    function bs(a) {
        return gq([a, a.g(wq())]).g(N(function(b) {
            var c = x(b);
            b = c.next().value;
            c = c.next().value;
            return {
                timestamp: b.timestamp,
                value: {
                    visible: b.value,
                    pb: c.value
                }
            }
        }), P(function(b, c) {
            return Vq(b, c, function(d, e) {
                return d.pb === e.pb && d.visible === e.visible
            })
        }))
    };

    function cs(a, b) {
        return {
            xa: b.g(bp("data-google-av-adk")),
            Ec: b.g(bp("data-google-av-btr"), P(), N(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            ve: b.g(bp("data-google-av-cpmav"), P(), N(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            Cf: b.g(bp("data-google-av-vrus"), P(), N(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            Oh: Tp(a, b),
            flags: b.g(bp("data-google-av-flags"), P()),
            Bb: Xr(a, b),
            Ue: b.g(kq("cr", function(c) {
                return c ===
                    "1"
            }), P()),
            xi: b.g(kq("omid", function(c) {
                return c === "1"
            }), P()),
            Qe: b.g(Sr),
            metadata: b.g(bp("data-google-av-metadata")),
            fb: b.g(ip),
            va: b.g(cp),
            Hj: b.g(kq("la", function(c) {
                return c === "1"
            }), P()),
            Db: b.g(bp("data-google-av-turtlex"), N(function(c) {
                return c !== null
            }), P()),
            Xe: b.g(bp("data-google-av-vattr"), N(function(c) {
                return c !== null
            }), P())
        }
    };

    function ds() {
        return K(jq(), ef(function(a, b) {
            return Math.max(a, b)
        }, 0), N(function(a) {
            return Math.round(a)
        }))
    };

    function es(a) {
        return K(hr(Zc(a)), ds())
    };

    function fs(a, b, c, d, e) {
        c = c.g(N(function() {
            return !1
        }));
        d = vd([e, d]).g(S(function(f) {
            f = x(f).next().value;
            return gs(b, f)
        }));
        return Pd(Zc(!1), c, d).g(P(), V(a.i, 1))
    }

    function gs(a, b) {
        return a.g(N(function(c) {
            return b || c === 0 || c === 2
        }))
    };
    var hs = [33, 32],
        is = K(Sr, N(function(a) {
            return hs.indexOf(a) >= 0
        }), P());

    function js(a, b, c, d, e, f) {
        var g = c.g(N(function(k) {
                return k === 9
            })),
            h = b.element.g(is);
        c = e.g(O(function(k) {
            return k
        }), S(function() {
            return vd([g, h])
        }), N(function(k) {
            var l = x(k);
            k = l.next().value;
            return !l.next().value || k
        }), P());
        f = vd([c, d.g(P()), f]).g(N(function(k) {
            var l = x(k);
            k = l.next().value;
            var m = l.next().value;
            l = l.next().value;
            return Lr(a, b, !k, m, l)
        }), cf(1), id());
        d = f.g(N(function(k) {
            return k.xd
        }));
        f = f.g(S(function(k) {
            return k.Kb
        }), R(null), P(), V(a.i, 1));
        return {
            cb: d,
            Gc: f
        }
    };

    function ks(a) {
        var b = b === void 0 ? !1 : b;
        return K(S(function(c) {
            return ti(a.document, c, b)
        }), V(a.i, 1))
    };
    var ls = function(a, b, c, d, e, f) {
        this.Rc = b.element.g(ks(a), V(a.i, 1));
        this.ah = fs(a, c, b.element, this.Rc, d);
        c = js(a, b, e, d, this.ah, f);
        d = c.Gc;
        this.cb = c.cb;
        this.Gc = d;
        this.Df = Pd((new W(1)).X(a.i), b.element.g(Re(1), N(function() {
            return 2
        }), V(a.i, 1)), this.Rc.g(Re(1), N(function() {
            return 3
        }), V(a.i, 1)), this.ah.g(O(Boolean), Re(1), N(function() {
            return 0
        }), V(a.i, 1))).g(hf(function(g) {
            return g !== 0
        }, !0), V(a.i, 0))
    };

    function ms(a, b) {
        return a && b === 0 ? 15 : a || b !== 1 ? null : 14
    }

    function ns(a, b, c) {
        return b instanceof L ? b.g(S(function(d) {
            return (d = ms(d, c)) ? $c(new ce(d)) : a
        })) : (b = ms(b.value, c)) ? $c(new ce(b)) : a
    };

    function os(a) {
        var b = new ce(13);
        if (a.length < 1) return {
            chain: Ac,
            re: Ac
        };
        var c = new xc,
            d = a[0];
        return {
            chain: a.slice(1).reduce(function(e, f) {
                return e.g(Ie(function(g) {
                    c.next(g);
                    return f
                }))
            }, d).g(Ie(function(e) {
                c.next(e);
                return $c(b)
            }), af(new xc), id()),
            re: c
        }
    };
    var ps = function() {};
    var qs = function(a, b) {
        this.context = a;
        this.wj = b
    };
    q(qs, ps);
    qs.prototype.mb = function(a, b) {
        var c = this.wj.map(function(f) {
                return f.mb(a, b)
            }),
            d = os(c.map(function(f) {
                return f.wb
            })),
            e = d.re.g(rs());
        return {
            wb: d.chain.g(V(this.context.i, 1)),
            lb: Object.assign.apply(Object, [{
                vf: e,
                Vk: d.re
            }].concat(y(c.map(function(f) {
                return f.lb
            }))))
        }
    };
    var rs = function() {
        return ef(function(a, b) {
            b instanceof ce ? a.push(b.Ji) : a.push(-1);
            return a
        }, [])
    };

    function ss(a, b) {
        var c = a.g(af(new xc), id());
        return S(function(d) {
            return c.g(b(d))
        })
    };

    function ts(a, b) {
        if (a.Cb) return $c(new ce(6));
        var c = new xc;
        return Pd(Zc({}), b, c).g(N(function() {
            return {
                timestamp: a.l.now(),
                value: {
                    oa: "geo",
                    qa: us(a),
                    da: Uo(a, !0),
                    ma: c,
                    wa: {
                        x: 0,
                        y: 0
                    }
                }
            }
        }), Mh(a.i))
    }

    function us(a) {
        var b = Uo(a, !1);
        if (!a.Oe || !Lg(a.global.parent) || a.global.parent === a.global) return b;
        var c = new Po(a.global.parent, a.Na);
        c.I = a.I;
        c = us(c);
        a = a.global.frameElement.getBoundingClientRect();
        return yi(zi(yi(c, a), {
            x: b.left - a.left,
            y: b.top - a.top
        }), b)
    };
    var vs = function(a, b) {
        this.context = a;
        this.Ib = b
    };
    q(vs, ps);
    vs.prototype.mb = function(a, b) {
        var c = ss(ts(this.context, this.Ib), Cq(this.context, b.fb));
        return {
            wb: ns(a.cb.g(c), b.Bb, 0),
            lb: {}
        }
    };
    var ws = function(a, b, c) {
        c = c === void 0 ? Hq(a, b) : c;
        this.context = a;
        this.ui = c
    };
    q(ws, ps);
    ws.prototype.mb = function(a, b) {
        var c = this.ui(b.kh);
        return {
            wb: ns(a.cb.g(c, Lq(this.context)), b.Bb, 0),
            lb: {}
        }
    };

    function xs(a, b, c, d, e) {
        var f = f === void 0 ? new Ur(a) : f;
        var g = g === void 0 ? of (a.l, 500) : g;
        var h = h === void 0 ? of (a.l, 100) : h;
        e = Zc(f).g(ys(c), jf(function(k) {
            d.next(k.Ob)
        }), zs(a, h), As(a), Bs(a, e), cf(1), id());
        f = new xc;
        b = Pd(Zc({}), b, f);
        return e.g(Cs(a, f, b, g, c), V(a.i, 1))
    }

    function Bs(a, b) {
        return K(function(c) {
            return vd([c, b])
        }, Se(function(c) {
            var d = x(c);
            c = d.next().value;
            return d.next().value !== 9 || Vr(c) ? Zc(!0) : Ds(a, c, "viewableChange").g(O(function(e) {
                return x(e).next().value
            }), Re(1))
        }), N(function(c) {
            return x(c).next().value
        }))
    }

    function ys(a) {
        return S(function(b) {
            if (b.Ob === -1) return a.next("if"), $c(new ce(7));
            if (b.wd !== 0) switch (b.wd) {
                case 1:
                    return a.next("mm"), $c(new ce(18));
                case 2:
                    return a.next("ng"), $c(new ce(17));
                default:
                    return a.next("i"), $c(new ce(8))
            }
            return Zc(b)
        })
    }

    function zs(a, b) {
        return Se(function() {
            var c = a.Ng;
            return ri(a.document) === "complete" ? Zc(!0) : c.g(Se(function() {
                return b
            }))
        })
    }

    function As(a) {
        return S(function(b) {
            return b.getState() !== "loading" ? Zc(b) : Ds(a, b, "ready").g(N(function() {
                return b
            }))
        })
    }

    function Cs(a, b, c, d, e) {
        return S(function(f) {
            var g = Wr(f);
            if (typeof g !== "string") return e.next("nc"), $c(new ce(9));
            f.bg !== void 0 && (f.bg = !0);
            g = Ds(a, f, g, Es);
            var h = {
                version: f.rg(),
                Ob: f.Ob
            };
            g = g.g(N(function(l) {
                return Fs.apply(null, [a, b, f, h].concat(y(l)))
            }));
            var k = d.g(jf(function() {
                e.next("mt")
            }), S(function() {
                return $c(new ce(10))
            }));
            g = Ud(g, k);
            return vd([g, c]).g(N(function(l) {
                l = x(l).next().value;
                return Object.assign({}, l, {
                    timestamp: a.l.now()
                })
            }))
        })
    }

    function Es(a, b) {
        return (b === null || typeof b === "number") && (a === null || !!a && typeof a.height === "number" && typeof a.width === "number" && typeof a.x === "number" && typeof a.y === "number")
    }

    function Fs(a, b, c, d, e, f) {
        e = e ? {
            left: e.x,
            top: e.y,
            width: e.width,
            height: e.height
        } : wi;
        c = c.tc("getMaxSize");
        var g = c != null && typeof c.width === "number" && typeof c.height === "number" ? c : {
            width: 0,
            height: 0
        };
        c = {
            left: 0,
            top: 0,
            width: -1,
            height: -1
        };
        if (g) {
            var h = Number(String(g.width));
            g = Number(String(g.height));
            c = isNaN(h) || isNaN(g) ? c : {
                left: 0,
                top: 0,
                width: h,
                height: g
            }
        }
        a = {
            value: {
                qa: e,
                da: c,
                oa: "mraid",
                ma: b,
                wa: {
                    x: 0,
                    y: 0
                }
            },
            timestamp: a.l.now()
        };
        return Object.assign({}, a, d, {
            nk: f
        })
    }

    function Ds(a, b, c, d) {
        d = d === void 0 ? function() {
            return !0
        } : d;
        return (new L(function(e) {
            var f = a.L.yc(745, function() {
                e.next(E.apply(0, arguments))
            });
            b.addEventListener(c, f);
            return function() {
                b.removeEventListener(c, f)
            }
        })).g(O(function(e) {
            return d.apply(null, y(e))
        }))
    };
    var Gs = function(a, b) {
        this.context = a;
        this.Ib = b
    };
    q(Gs, ps);
    Gs.prototype.mb = function(a, b) {
        var c = new bd(1),
            d = new bd(1),
            e = ss(xs(this.context, this.Ib, c, d, b.fb), Cq(this.context, b.fb));
        return {
            wb: ns(a.cb.g(e), b.Bb, 1),
            lb: {
                bf: c.g(V(this.context.i, 1)),
                cf: d.g(V(this.context.i, 1))
            }
        }
    };

    function Hs(a) {
        return ["backgrounded", "notFound", "hidden", "noOutputDevice"].includes(a)
    };

    function Is(a, b) {
        var c = c === void 0 ? null : c;
        var d = new xc,
            e = void 0,
            f = a.kg,
            g = d.g(N(function() {
                return e ? Object.assign({}, e, {
                    timestamp: a.l.now()
                }) : null
            }), O(function(k) {
                return k !== null
            }), N(function(k) {
                return k
            }));
        b = vd([Pd(f, g), b]);
        var h = c;
        return b.g(O(function(k) {
            k = x(k).next().value;
            h === null && (h = k.value.Ah);
            return k.value.Ah === h
        }), jf(function(k) {
            return void(e = x(k).next().value)
        }), N(function(k) {
            var l = x(k);
            k = l.next().value;
            l = l.next().value;
            try {
                var m = k.value.data,
                    u = k.timestamp,
                    t = m.viewport,
                    r, w, v = Object.assign({},
                        t, {
                            width: (r = t == null ? void 0 : t.width) != null ? r : 0,
                            height: (w = t == null ? void 0 : t.height) != null ? w : 0,
                            x: 0,
                            y: 0,
                            Pk: t ? t.width * t.height : 0
                        }),
                    z = Js(v),
                    C = m.adView,
                    Q = C.measuringElement && C.containerGeometry ? Js(C.containerGeometry) : Js(C.geometry),
                    T = Js(C.geometry),
                    oa = C.reasons.some(Hs),
                    H = oa ? wi : Js(C.onScreenGeometry),
                    D;
                l && (D = C.percentageInView / 100);
                l && oa && (D = 0);
                return {
                    timestamp: u,
                    value: {
                        oa: "omid",
                        qa: Q,
                        da: z,
                        ma: d,
                        Z: "omid",
                        O: T,
                        wa: {
                            x: Q.left,
                            y: Q.top
                        },
                        aa: H,
                        Cd: D
                    }
                }
            } catch (pc) {
                ih(pc, th());
                var fa, Lc;
                m = (Lc = (fa = pc) == null ? void 0 : fa.message) !=
                    null ? Lc : "An unknown error occurred";
                fa = "Error while processing geometryChange event: " + JSON.stringify(k.value) + "; " + m;
                throw Error(fa);
            }
        }), cf(1), id())
    }

    function Js(a) {
        var b, c, d, e;
        return {
            left: Math.floor((b = a == null ? void 0 : a.x) != null ? b : 0),
            top: Math.floor((c = a == null ? void 0 : a.y) != null ? c : 0),
            width: Math.floor((d = a == null ? void 0 : a.width) != null ? d : 0),
            height: Math.floor((e = a == null ? void 0 : a.height) != null ? e : 0)
        }
    };

    function Ks(a, b, c, d) {
        c = c === void 0 ? Qd : c;
        var e = a.i;
        if (b === null) return $c(new ce(20));
        if (!b.validate()) return $c(new ce(21));
        var f;
        d = Ls(e, b, d).g(N(function(g) {
            var h = g.value;
            g = g.timestamp;
            var k = b.l,
                l = a.l;
            if (k.timeline !== g.timeline) throw new he;
            g = new qe(g.value - k.now().value + l.now().value, l.timeline);
            return f = {
                value: h,
                timestamp: g
            }
        }));
        return Pd(d, c.g(N(function() {
            return f
        }))).g(O(function(g) {
            return g !== void 0
        }), N(function(g) {
            return g
        }), V(a.i, 1))
    }

    function Ls(a, b, c) {
        return Is(b, c).g(V(a, 1), N(function(d) {
            return {
                timestamp: d.timestamp,
                value: {
                    wa: {
                        x: d.value.O.left,
                        y: d.value.O.top
                    },
                    qa: d.value.aa,
                    da: d.value.da,
                    oa: d.value.Z,
                    ma: d.value.ma
                }
            }
        }))
    };
    var Ms = function(a, b, c) {
        this.ta = a;
        this.D = b;
        this.Ib = c
    };
    q(Ms, ps);
    Ms.prototype.mb = function(a, b) {
        var c = b.fb;
        b = Ks(this.D, this.ta, this.Ib, b.Mg);
        c = ss(b, Cq(this.D, c));
        return {
            wb: a.cb.g(c),
            lb: {}
        }
    };
    var Ns = function(a, b, c) {
        this.ta = a;
        this.D = b;
        this.Yh = c
    };
    q(Ns, ps);
    Ns.prototype.mb = function(a, b) {
        var c = Ks(this.D, this.ta, void 0, b.Mg);
        b = Kq(this.D, b.kh, this.Yh);
        c = ss(c, b);
        return {
            wb: a.cb.g(c),
            lb: {}
        }
    };

    function Os(a) {
        if (a.prerendering) return 3;
        var b;
        return (b = {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5,
            "": 0
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""]) != null ? b : 0
    }

    function Ps(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    };

    function Qs(a) {
        return a.document.Xi.g(N(function(b) {
            return b === "visible"
        }), P(), V(a.i, 1))
    };
    var Dp = ["2026051301"].slice(-1)[0].substring(0, 8);

    function Rs(a, b, c) {
        var d;
        return b.g(P(), S(function(e) {
            return c.g(N(function() {
                if (!d) {
                    d = !0;
                    try {
                        e.next()
                    } finally {
                        d = !1
                    }
                }
                return !0
            }))
        }), R(!1), V(a.i, 1))
    };

    function Ss(a) {
        return K(Pq(N(function(b) {
            return gr(b, a)
        })), iq(), N(function(b) {
            return Math.round(b)
        }))
    };

    function Ts(a, b, c, d, e) {
        var f = Gr;
        if (f.length > 1)
            for (var g = 0; g < f.length - 1; g++)
                if (f[g] < f[g + 1]) throw Error();
        g = e.g(R(void 0), S(function() {
            return c.g(wq())
        }), P(), V(a, 1));
        e = e.g(R(void 0), S(function() {
            return c.g(ds())
        }), P(), V(a, 1));
        return {
            Yd: d.g(R(void 0), S(function() {
                return b.g(N(function(h) {
                    return {
                        timestamp: h.timestamp,
                        value: !0
                    }
                }), iq())
            }), P(), V(a, 1)),
            Zd: d.g(R(void 0), S(function() {
                return b.g(N(function(h) {
                    return {
                        timestamp: h.timestamp,
                        value: h.value === 0
                    }
                }), iq())
            }), P(), V(a, 1)),
            Vc: d.g(R(void 0), S(function() {
                return b.g(vq(es,
                    f))
            }), P(Kb), V(a, 1)),
            Va: d.g(R(void 0), S(function() {
                return b.g(vq(Ss, f), N(function(h) {
                    return h.map(function(k, l) {
                        return l > 0 ? k - h[l - 1] : k
                    })
                }))
            }), P(Kb), V(a, 1)),
            Uc: e,
            pb: g.g(P(Vq), V(a, 1))
        }
    };

    function Us(a, b, c) {
        var d = c.g(N(function(e) {
            return {
                value: e,
                timestamp: a.l.now()
            }
        }), P(Vq));
        return b instanceof L ? b.g(P(), S(function(e) {
            return e ? (new W({
                value: !1,
                timestamp: a.l.now()
            })).X(a.i) : d
        })) : b.value === !1 ? d : new W(!1)
    }

    function Vs(a, b, c, d, e, f, g) {
        var h = zr;
        b = b instanceof L ? b.g(R(!1), P()) : b;
        var k = !($g() || Zg());
        c = Us(a, c, d);
        a = g.cb.g(fq(a.i));
        return Object.assign({}, h, {
            Ed: c,
            nh: e,
            Qf: k,
            Kg: b,
            Hd: a,
            jh: f
        })
    };

    function Ws(a) {
        a = a.global;
        if (typeof a.__google_lidar_ === "undefined") return a.__google_lidar_ = 1, !1;
        a.__google_lidar_ = Number(a.__google_lidar_) + 1;
        var b = a.__google_lidar_adblocks_count_;
        if (typeof b === "number" && b > 0 && (a = a.__google_lidar_radf_, typeof a === "function")) try {
            a()
        } catch (c) {}
        return !0
    }

    function Xs(a) {
        var b = a.global;
        b.osdlfm = function() {
            return b.__google_lidar_radf_
        };
        if (b.__google_lidar_radf_ !== void 0) return Ac;
        b.__google_lidar_adblocks_count_ = 1;
        var c = new xc;
        b.__google_lidar_radf_ = function() {
            return void c.next(a)
        };
        return c.g(sg(a.L, 743))
    };
    var Ys = function(a) {
            var b = this;
            this.We = !1;
            this.ff = [];
            this.ef = [];
            a(function(c) {
                b.We = !0;
                b.resolution = c;
                b.evaluate()
            }, function(c) {
                b.dj = c;
                b.evaluate()
            })
        },
        Zs = function(a) {
            return new Ys(function(b, c) {
                var d = [],
                    e = 0;
                a.forEach(function(f, g) {
                    f.then(function(h) {
                        d[g] = h;
                        ++e === a.length && b(d)
                    }).catch(function(h) {
                        c(h)
                    })
                })
            })
        };
    Ys.prototype.evaluate = function() {
        var a = this.resolution,
            b = this.dj;
        if (b !== void 0 || this.We) this.We && this.ff.forEach(function(c) {
            return void c(a)
        }), b !== void 0 && this.ef.forEach(function(c) {
            return void c(b)
        }), this.ff = [], this.ef = []
    };
    Ys.prototype.then = function(a) {
        this.ff.push(a);
        this.evaluate();
        return this
    };
    Ys.prototype.catch = function(a) {
        this.ef.push(a);
        this.evaluate();
        return this
    };
    var $s = function(a) {
        this.children = a;
        this.Te = !1;
        this.se = []
    };
    $s.prototype.complete = function() {
        var a = this;
        this.Te = !0;
        this.se.forEach(function(b) {
            return void b(a)
        });
        this.se.splice(0)
    };
    $s.prototype.onComplete = function(a) {
        this.Te ? a(this) : this.se.push(a)
    };
    $s.prototype.nb = function(a) {
        var b = this.children.map(function(c) {
            return c.nb(a)
        });
        return b.find(function(c) {
            return c !== 2
        }) === void 0 ? 2 : this.completed ? 0 : b.some(function(c) {
            return c === 1
        }) ? 1 : 0
    };
    da.Object.defineProperties($s.prototype, {
        completed: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Te
            }
        }
    });
    var at = function() {
        var a = E.apply(0, arguments);
        $s.call(this, a);
        var b = this;
        this.events = a;
        var c = this.events.length;
        this.events.forEach(function(d) {
            d.onComplete(function() {
                --c === 0 && b.complete()
            })
        })
    };
    q(at, $s);
    at.prototype.clone = function() {
        return new(Function.prototype.bind.apply(at, [null].concat(y(this.events.map(function(a) {
            return a.clone()
        })))))
    };
    at.prototype.zf = function(a, b) {
        var c = this;
        if (!this.completed) {
            var d = this.events.find(function(e) {
                return e.nb(a) === 1
            });
            d !== void 0 && d.zf(a, function() {
                c.completed || b()
            })
        }
    };
    var bt = function(a, b) {
        $s.call(this, []);
        this.Ae = a;
        this.Id = Symbol(b);
        this.Yi = a
    };
    q(bt, $s);
    bt.prototype.clone = function() {
        var a = new bt(this.Yi, this.Id.description);
        a.Id = this.Id;
        return a
    };
    bt.prototype.nb = function(a) {
        return a !== this.event ? 2 : this.completed || this.Ae === 0 ? 0 : 1
    };
    bt.prototype.zf = function(a, b) {
        this.nb(a) === 1 && (this.Ae--, b(), this.Ae === 0 && this.complete())
    };
    da.Object.defineProperties(bt.prototype, {
        event: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Id
            }
        }
    });
    var ct = function(a) {
        bt.call(this, 1, a)
    };
    q(ct, bt);
    var dt = function(a, b, c) {
        var d = E.apply(3, arguments);
        this.Za = a;
        this.Vh = b;
        this.xe = c;
        this.Tc = new Set;
        this.jc = d;
        if (this.Za.D) this.context = this.Za.D;
        else if (this.Za.ta) this.context = this.Za.ta;
        else throw Error("La");
        var e = d.reduce(function(h, k) {
            k.subscribedEvents.forEach(function(l) {
                return void h.add(l)
            });
            return h
        }, new Set);
        e = x(e.values());
        for (var f = e.next(), g = {}; !f.done; g = {
                eg: void 0
            }, f = e.next()) {
            g.eg = f.value;
            f = d.filter(function(h) {
                return function(k) {
                    return k.controlledEvents.indexOf(h.eg) >= 0
                }
            }(g));
            if (f.length ===
                0) throw Error("Ma");
            if (f.length > 1) throw Error("Na");
        }
    };
    dt.prototype.start = function() {
        var a = this;
        this.jc.forEach(function(b) {
            return void b.start(a.Za)
        });
        this.xe.start(this.Za, this.di.bind(this), this.Yb.bind(this), function() {})
    };
    dt.prototype.dispose = function() {
        var a = this;
        this.xe.dispose();
        this.Tc.forEach(function(b) {
            return void a.Yb(b)
        });
        this.jc.forEach(function(b) {
            return void b.dispose()
        })
    };
    var et = function(a, b) {
            b = {
                measuringCreativeIds: [].concat(y(a.Tc.values())).map(function(c) {
                    return a.context.Ic.getName(c)
                }),
                hasCreativeSourceCompleted: !!a.xe.Vd,
                colleagues: a.jc.map(function(c) {
                    return {
                        name: c.name,
                        controlledEvents: c.controlledEvents.map(function(d) {
                            var e;
                            return (e = d.description) != null ? e : "n/a"
                        }),
                        subscribedEvents: c.subscribedEvents.map(function(d) {
                            var e;
                            return (e = d.description) != null ? e : "n/a"
                        })
                    }
                }),
                ephemeralCreativeStateChanges: b
            };
            b = {
                specMajor: 2,
                specMinor: 0,
                specPatch: 0,
                instanceId: a.context.Ic.getName(a.context.Pb),
                timestamp: se(a.context.l.now(), new qe(0, a.context.l.timeline)),
                mediatorState: b
            };
            $d(a.context, b)
        },
        ft = function(a, b, c, d, e) {
            var f = {};
            et(a, (f[b] = {
                events: [{
                    timestamp: c,
                    description: d,
                    status: e
                }]
            }, f))
        };
    dt.prototype.di = function(a, b, c) {
        var d = this;
        if (!this.Tc.has(a)) {
            var e = this.Vh.clone();
            this.Tc.add(a);
            et(this, {});
            var f = !1,
                g = [];
            this.jc.forEach(function(h) {
                var k = function(l, m, u) {
                    var t = d.context.Ic.getName(a),
                        r = se(d.context.l.now(), new qe(0, d.context.l.timeline)),
                        w, v = (w = l.description) != null ? w : "n/a";
                    if (h.controlledEvents.indexOf(l) < 0 || e.nb(l) !== 1) return u(!1), ft(d, t, r, v, 1), new Ys(function(C) {
                        return void C()
                    });
                    var z = new Ys(function(C) {
                        e.zf(l, function() {
                            d.jc.filter(function(Q) {
                                return Q.subscribedEvents.indexOf(l) >=
                                    0
                            }).forEach(function(Q) {
                                return void Q.handleEvent(a, l, m)
                            });
                            C()
                        })
                    });
                    return new Ys(function(C) {
                        z.then(function() {
                            u(!0);
                            ft(d, t, r, v, 2);
                            C()
                        })
                    })
                };
                h.Le(a, b, c, function(l, m, u) {
                    return f ? k(l, m, u) : new Ys(function(t) {
                        g.push(function() {
                            k(l, m, u).then(function() {
                                t()
                            })
                        })
                    })
                }, function(l) {
                    try {
                        d.context.I.K("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=colleague-executed&name=" + l, {
                            ia: "GET"
                        }).sendNow()
                    } catch (m) {}
                })
            });
            f = !0;
            g.forEach(function(h) {
                return void h()
            })
        }
    };
    dt.prototype.Yb = function(a) {
        this.Tc.delete(a);
        this.jc.forEach(function(b) {
            b.Yb(a)
        });
        et(this, {})
    };
    var gt = function(a, b) {
            this.key = a;
            this.defaultValue = b === void 0 ? !1 : b;
            this.valueType = "boolean"
        },
        ht = function(a, b) {
            this.key = a;
            this.defaultValue = b === void 0 ? 0 : b;
            this.valueType = "number"
        };
    var jt = {
        considerOmidZOrderOcclusions: [new gt("100006"), !1],
        extraPings: [new ht("45362137"), 0],
        extrapolators: [new gt("45377435"), !1],
        rxlidarStatefulBeacons: [new gt("45372163"), !1],
        shouldIgnoreAdChoicesIcon: [new gt("45382077"), !1],
        dedicatedViewableAttributionPing: [new ht("45389692"), 0],
        useReachIntegrationPolyfill: [new gt("45407239"), !1],
        useReachIntegrationSharedStorage: [new gt("45407240", !0), !0],
        sendBrowserIdInsteadOfVPID: [new gt("45407241"), !1],
        waitForImpressionColleague: [new gt("45430682"), !1],
        fetchLaterBeacons: [new gt("45618478"), !1],
        rxInNonrx: [new gt("45642405"), !1],
        addQueryIdToErrorPing: [new gt("45653435"), !1],
        shouldSendExplicitDisplayMeasurablePing: [new gt("45658589"), !1],
        reachUseCreateWorklet: [new gt("45661569"), !1],
        tosCustomTimeoutMillis: [new ht("45706257", 36E5), 36E5],
        shouldCacheTimeMetricsInLocalStorage: [new gt("45722991", !0), !0],
        omakaseAdStatsResetVersion: [new ht("45738539", 2), 2]
    };

    function kt(a) {
        return Object.entries(jt).reduce(function(b, c) {
            var d = x(c);
            c = d.next().value;
            var e = x(d.next().value);
            d = e.next().value;
            e = e.next().value;
            var f;
            if (a == null) var g = void 0;
            else a: {
                var h = a.hg[d.key];
                if (d.valueType === "proto") {
                    try {
                        var k = JSON.parse(h);
                        if (Array.isArray(k)) {
                            g = k;
                            break a
                        }
                    } catch (l) {}
                    g = d.defaultValue
                } else g = typeof h === typeof d.defaultValue ? h : d.defaultValue
            }
            b[c] = (f = g) != null ? f : e;
            return b
        }, {})
    };
    var Xm = function(a) {
        uo.call(this, a)
    };
    q(Xm, uo);
    var lt = function(a) {
        return sl(Im(a, 3))
    };
    Xm.prototype.Ge = function() {
        return cn(this, 4, !0)
    };
    var mt = function(a) {
        return gl(Im(a, 5))
    };
    Xm.prototype.Fd = function() {
        return dn(this, 6)
    };
    var nt = function(a) {
        return cn(a, 7)
    };
    Xm.W = "ads.branding.measurement.client.serving.integrations.active_view.ActiveViewMetadata";
    var ot = [0, io, -2, ho, -1, eo, ho];
    Xm.prototype.R = wo(ot);
    var pt = function(a) {
        uo.call(this, a)
    };
    q(pt, uo);
    pt.prototype.Yg = function(a) {
        return gn(this, 5, a)
    };
    pt.prototype.getType = function() {
        var a = a === void 0 ? 0 : a;
        var b = kl(Im(this, 6));
        return b != null ? b : a
    };
    var qt = xo(pt);
    pt.W = "ads.geo.GeoTargetMessage";
    var rt = function(a) {
        uo.call(this, a)
    };
    q(rt, uo);
    n = rt.prototype;
    n.mg = function() {
        return en(this, 2)
    };
    n.ng = function() {
        return sl(Im(this, 2))
    };
    n.Ge = function() {
        return cn(this, 3, !0)
    };
    n.og = function() {
        return Zm(this, pt, 4)
    };
    n.Wg = function(a) {
        return bn(this, pt, 4, a)
    };
    n.qg = function() {
        return Pm(this, 7, kl, void 0 === Qk ? 2 : 4)
    };
    n.Of = function(a) {
        return kn(this, 7, a)
    };
    n.Xg = function(a) {
        return fn(this, 9, a)
    };
    n.Fd = function() {
        return dn(this, 10)
    };
    rt.W = "ads.branding.measurement.client.serving.integrations.reach.ReachMetadata";
    var st = [0, eo, -3];
    var tt = [0, lo, -4, no, ho, eo, $n, lo, $n, lo, eo, lo, -1, st, mo, co, lo, bo, -1, eo, -1, bo, $n, [0, bo, eo, -1, no, $n, bo], Zn, lo, [0, eo, -6], ho, $n, [0, no, -3], st];
    pt.prototype.R = wo(tt);
    var ut = [0, io, -1, ho, tt, fo, -1, oo, eo, ho, eo];
    rt.prototype.R = wo(ut);
    var vt = function(a) {
        uo.call(this, a)
    };
    q(vt, uo);
    vt.prototype.mg = function() {
        return en(this, 1)
    };
    vt.prototype.ng = function() {
        return sl(Im(this, 1))
    };
    vt.prototype.Fd = function() {
        return dn(this, 2)
    };
    vt.W = "ads.branding.measurement.client.serving.integrations.shared.SharedMetadata";
    var wt = [0, io, eo];
    vt.prototype.R = wo(wt);
    var xt = function(a) {
        uo.call(this, a)
    };
    q(xt, uo);
    var yt = function(a) {
        return Zm(a, rt, 1)
    };
    xt.W = "ads.branding.measurement.client.serving.IntegratorMetadata";
    var zt = [0, ut, ot, wt];
    xt.prototype.R = wo(zt);
    var At = vo(xt, zt);
    var Bt = function() {
        this.hg = {}
    };
    var Ct = function() {
        this.ag = !1;
        this.Xf = new Map
    };
    Ct.prototype.start = function(a, b, c, d) {
        var e = this;
        if (this.Vd === void 0 && a.D) {
            var f = a.D;
            this.Wf = d;
            c = !this.ag && Ws(f);
            d = this.ag ? Ac : Xs(f);
            d = lp(f, d);
            this.Vd = (c ? Ac : d.g(N(function(g) {
                var h = h === void 0 ? Symbol() : h;
                return Object.freeze({
                    Pb: h,
                    element: (new W(g)).X(f.i)
                })
            }), dp())).subscribe(function(g) {
                var h = g.Pb;
                e.Xf.set(h, g);
                g.element.g(Re(1)).subscribe(function(k) {
                    var l = ap(k, "data-google-av-flags"),
                        m = new Bt;
                    if (l !== null) try {
                        var u = JSON.parse(l)[0];
                        l = "";
                        for (var t = 0; t < u.length; t++) l += String.fromCharCode(u.charCodeAt(t) ^
                            "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(t % 10));
                        m.hg = JSON.parse(l)
                    } catch (w) {}
                    m = kt(m);
                    k = ap(k, "data-google-av-ufs-integrator-metadata");
                    a: {
                        if (k !== null) try {
                            var r = At(k);
                            break a
                        } catch (w) {}
                        r = new xt
                    }
                    b(h, r, m)
                })
            });
            c && this.dispose();
            a.ta && Kf(a.ta)
        }
    };
    Ct.prototype.dispose = function() {
        var a, b;
        (a = this.Vd) == null || (b = a.unsubscribe) == null || b.call(a);
        this.Vd = void 0;
        var c;
        (c = this.Wf) == null || c.call(this);
        this.Wf = void 0
    };
    var Dt = function(a) {
        uo.call(this, a)
    };
    q(Dt, uo);
    Dt.prototype.Yg = function(a) {
        return jn(this, 2, a)
    };
    Dt.prototype.Nb = function(a) {
        return hn(this, 3, a)
    };
    Dt.prototype.Mb = function(a) {
        return hn(this, 4, a)
    };
    Dt.W = "ads.branding.measurement.client.frontend.integrations.active_view.OmakaseStatusMessage";
    var Et = [0, no, -1, io, -3];
    Dt.prototype.R = wo(Et);
    var Ft = function(a) {
        return function(b) {
            return Un(b, a)
        }
    }(Et);
    var Gt = function(a) {
            if (a.xb && typeof a.xb == "function") return a.xb();
            if (typeof Map !== "undefined" && a instanceof Map || typeof Set !== "undefined" && a instanceof Set) return Array.from(a.values());
            if (typeof a === "string") return a.split("");
            if (Ka(a)) {
                for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
                return b
            }
            b = [];
            c = 0;
            for (d in a) b[c++] = a[d];
            return b
        },
        Ht = function(a) {
            if (a.He && typeof a.He == "function") return a.He();
            if (!a.xb || typeof a.xb != "function") {
                if (typeof Map !== "undefined" && a instanceof Map) return Array.from(a.keys());
                if (!(typeof Set !== "undefined" && a instanceof Set)) {
                    if (Ka(a) || typeof a === "string") {
                        var b = [];
                        a = a.length;
                        for (var c = 0; c < a; c++) b.push(c);
                        return b
                    }
                    b = [];
                    c = 0;
                    for (var d in a) b[c++] = d;
                    return b
                }
            }
        },
        It = function(a, b, c) {
            if (a.forEach && typeof a.forEach == "function") a.forEach(b, c);
            else if (Ka(a) || typeof a === "string") Array.prototype.forEach.call(a, b, c);
            else
                for (var d = Ht(a), e = Gt(a), f = e.length, g = 0; g < f; g++) b.call(c, e[g], d && d[g], a)
        };

    function Bp(a) {
        this.Oa = this.Tb = this.gb = "";
        this.rc = null;
        this.ub = this.Ia = "";
        this.ra = this.yi = !1;
        if (a instanceof Bp) {
            this.ra = a.ra;
            Jt(this, a.gb);
            var b = a.Tb;
            Kt(this);
            this.Tb = b;
            b = a.Oa;
            Kt(this);
            this.Oa = b;
            Lt(this, a.rc);
            b = a.Ia;
            Kt(this);
            this.Ia = b;
            Mt(this, a.ua.clone());
            a = a.ub;
            Kt(this);
            this.ub = a
        } else a && (b = String(a).match(Ai)) ? (this.ra = !1, Jt(this, b[1] || "", !0), a = b[2] || "", Kt(this), this.Tb = Nt(a), a = b[3] || "", Kt(this), this.Oa = Nt(a, !0), Lt(this, b[4]), a = b[5] || "", Kt(this), this.Ia = Nt(a, !0), Mt(this, b[6] || "", !0), a = b[7] || "",
            Kt(this), this.ub = Nt(a)) : (this.ra = !1, this.ua = new Ot(null, this.ra))
    }
    Bp.prototype.toString = function() {
        var a = [],
            b = this.gb;
        b && a.push(Pt(b, Qt, !0), ":");
        var c = this.Oa;
        if (c || b == "file") a.push("//"), (b = this.Tb) && a.push(Pt(b, Qt, !0), "@"), a.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.rc, c != null && a.push(":", String(c));
        if (c = this.Ia) this.Oa && c.charAt(0) != "/" && a.push("/"), a.push(Pt(c, c.charAt(0) == "/" ? Rt : St, !0));
        (c = this.ua.toString()) && a.push("?", c);
        (c = this.ub) && a.push("#", Pt(c, Tt));
        return a.join("")
    };
    Bp.prototype.resolve = function(a) {
        var b = this.clone(),
            c = !!a.gb;
        c ? Jt(b, a.gb) : c = !!a.Tb;
        if (c) {
            var d = a.Tb;
            Kt(b);
            b.Tb = d
        } else c = !!a.Oa;
        c ? (d = a.Oa, Kt(b), b.Oa = d) : c = a.rc != null;
        d = a.Ia;
        if (c) Lt(b, a.rc);
        else if (c = !!a.Ia) {
            if (d.charAt(0) != "/")
                if (this.Oa && !this.Ia) d = "/" + d;
                else {
                    var e = b.Ia.lastIndexOf("/");
                    e != -1 && (d = b.Ia.slice(0, e + 1) + d)
                }
            e = d;
            if (e == ".." || e == ".") d = "";
            else if (e.indexOf("./") != -1 || e.indexOf("/.") != -1) {
                d = e.lastIndexOf("/", 0) == 0;
                e = e.split("/");
                for (var f = [], g = 0; g < e.length;) {
                    var h = e[g++];
                    h == "." ? d && g == e.length &&
                        f.push("") : h == ".." ? ((f.length > 1 || f.length == 1 && f[0] != "") && f.pop(), d && g == e.length && f.push("")) : (f.push(h), d = !0)
                }
                d = f.join("/")
            } else d = e
        }
        c ? (Kt(b), b.Ia = d) : c = a.ua.toString() !== "";
        c ? Mt(b, a.ua.clone()) : c = !!a.ub;
        c && (a = a.ub, Kt(b), b.ub = a);
        return b
    };
    Bp.prototype.clone = function() {
        return new Bp(this)
    };
    var Jt = function(a, b, c) {
            Kt(a);
            a.gb = c ? Nt(b, !0) : b;
            a.gb && (a.gb = a.gb.replace(/:$/, ""))
        },
        Lt = function(a, b) {
            Kt(a);
            if (b) {
                b = Number(b);
                if (isNaN(b) || b < 0) throw Error("Oa`" + b);
                a.rc = b
            } else a.rc = null
        },
        Mt = function(a, b, c) {
            Kt(a);
            b instanceof Ot ? (a.ua = b, a.ua.rf(a.ra)) : (c || (b = Pt(b, Ut)), a.ua = new Ot(b, a.ra))
        };
    Bp.prototype.getQuery = function() {
        return this.ua.toString()
    };
    var Cp = function(a, b, c) {
        Kt(a);
        a.ua.set(b, c)
    };
    Bp.prototype.removeParameter = function(a) {
        Kt(this);
        this.ua.remove(a);
        return this
    };
    var Kt = function(a) {
        if (a.yi) throw Error("Pa");
    };
    Bp.prototype.rf = function(a) {
        this.ra = a;
        this.ua && this.ua.rf(a)
    };
    var Nt = function(a, b) {
            return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : ""
        },
        Pt = function(a, b, c) {
            return typeof a === "string" ? (a = encodeURI(a).replace(b, Vt), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null
        },
        Vt = function(a) {
            a = a.charCodeAt(0);
            return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
        },
        Qt = /[#\/\?@]/g,
        St = /[#\?:]/g,
        Rt = /[#\?]/g,
        Ut = /[#\?@]/g,
        Tt = /#/g,
        Ot = function(a, b) {
            this.Y = this.N = null;
            this.ja = a || null;
            this.ra = !!b
        },
        Wt = function(a) {
            a.N || (a.N = new Map, a.Y = 0, a.ja && Bi(a.ja, function(b,
                c) {
                a.add(decodeURIComponent(b.replace(/\+/g, " ")), c)
            }))
        };
    Ot.prototype.add = function(a, b) {
        Wt(this);
        this.ja = null;
        a = Xt(this, a);
        var c = this.N.get(a);
        c || this.N.set(a, c = []);
        c.push(b);
        this.Y = yb(this.Y) + 1;
        return this
    };
    Ot.prototype.remove = function(a) {
        Wt(this);
        a = Xt(this, a);
        return this.N.has(a) ? (this.ja = null, this.Y = yb(this.Y) - this.N.get(a).length, this.N.delete(a)) : !1
    };
    Ot.prototype.clear = function() {
        this.N = this.ja = null;
        this.Y = 0
    };
    Ot.prototype.isEmpty = function() {
        Wt(this);
        return this.Y == 0
    };
    var Yt = function(a, b) {
        Wt(a);
        b = Xt(a, b);
        return a.N.has(b)
    };
    n = Ot.prototype;
    n.forEach = function(a, b) {
        Wt(this);
        this.N.forEach(function(c, d) {
            c.forEach(function(e) {
                a.call(b, e, d, this)
            }, this)
        }, this)
    };
    n.He = function() {
        Wt(this);
        for (var a = Array.from(this.N.values()), b = Array.from(this.N.keys()), c = [], d = 0; d < b.length; d++)
            for (var e = a[d], f = 0; f < e.length; f++) c.push(b[d]);
        return c
    };
    n.xb = function(a) {
        Wt(this);
        var b = [];
        if (typeof a === "string") Yt(this, a) && (b = b.concat(this.N.get(Xt(this, a))));
        else {
            a = Array.from(this.N.values());
            for (var c = 0; c < a.length; c++) b = b.concat(a[c])
        }
        return b
    };
    n.set = function(a, b) {
        Wt(this);
        this.ja = null;
        a = Xt(this, a);
        Yt(this, a) && (this.Y = yb(this.Y) - this.N.get(a).length);
        this.N.set(a, [b]);
        this.Y = yb(this.Y) + 1;
        return this
    };
    n.get = function(a, b) {
        if (!a) return b;
        a = this.xb(a);
        return a.length > 0 ? String(a[0]) : b
    };
    n.toString = function() {
        if (this.ja) return this.ja;
        if (!this.N) return "";
        for (var a = [], b = Array.from(this.N.keys()), c = 0; c < b.length; c++) {
            var d = b[c],
                e = encodeURIComponent(String(d));
            d = this.xb(d);
            for (var f = 0; f < d.length; f++) {
                var g = e;
                d[f] !== "" && (g += "=" + encodeURIComponent(String(d[f])));
                a.push(g)
            }
        }
        return this.ja = a.join("&")
    };
    n.clone = function() {
        var a = new Ot;
        a.ja = this.ja;
        this.N && (a.N = new Map(this.N), a.Y = this.Y);
        return a
    };
    var Xt = function(a, b) {
        b = String(b);
        a.ra && (b = b.toLowerCase());
        return b
    };
    Ot.prototype.rf = function(a) {
        a && !this.ra && (Wt(this), this.ja = null, this.N.forEach(function(b, c) {
            var d = c.toLowerCase();
            c != d && (this.remove(c), this.remove(d), b.length > 0 && (this.ja = null, this.N.set(Xt(this, d), Jb(b)), this.Y = yb(this.Y) + b.length))
        }, this));
        this.ra = a
    };
    Ot.prototype.extend = function(a) {
        for (var b = 0; b < arguments.length; b++) It(arguments[b], function(c, d) {
            this.add(d, c)
        }, this)
    };

    function Zt(a, b) {
        var c = (new Dt).Nb(b.name).Yg(1).Mb(b.message);
        c = hn(c, 5, b.stack);
        c = hn(c, 6, String(a.L.xf));
        switch (b.name) {
            case "SecurityError":
                jn(c, 1, 2);
                break;
            case "QuotaExceededError":
                jn(c, 1, 1);
                break;
            case "SyntaxError":
                jn(c, 1, 3);
                break;
            case "TypeError":
                jn(c, 1, 4);
                break;
            case "InvalidStateError":
                jn(c, 1, 7);
                break;
            case "AbortError":
                jn(c, 1, 6);
                break;
            case "NotSupportedError":
                jn(c, 1, 8);
                break;
            case "IframeError":
                jn(c, 1, 5);
                break;
            case "LocksApiUnavailableError":
                jn(c, 1, 9);
                break;
            default:
                jn(c, 1, 0)
        }
        b = new Bp("https://pagead2.googlesyndication.com/pagead/gen_204");
        Cp(b, "id", "av-js");
        Cp(b, "type", "omakase");
        Cp(b, "proto", Th(Ft(c)));
        Cp(b, "v", Dp);
        a.I.K(b.toString(), {
            ia: "GET"
        }).sendNow()
    };
    var $t = function(a) {
        this.D = a
    };
    n = $t.prototype;
    n.reportError = function(a) {
        Zt(this.D, a)
    };
    n.setItem = function(a, b) {
        try {
            this.hasLocalStorageAccess() && this.D.localStorage.setItem(a, b)
        } catch (c) {
            this.reportError(c)
        }
    };
    n.getItem = function(a) {
        try {
            if (this.hasLocalStorageAccess()) return this.D.localStorage.getItem(a)
        } catch (b) {
            this.reportError(b)
        }
        return null
    };
    n.hasLocalStorageAccess = function() {
        return Ro(this.D)
    };
    n.Lc = function() {
        return this.D.Lc()
    };
    n.mf = function(a, b) {
        var c = this;
        return Ca(function(d) {
            return d.u(c.D.mf(a, b), 0)
        })
    };
    n.performExclusiveLockedOperation = function(a, b) {
        var c = this,
            d;
        return Ca(function(e) {
            if (e.A == 1) {
                if (!c.Lc()) return b(), e.ba(0);
                e.Lb(3);
                return e.u(c.D.mf(a, b), 5)
            }
            if (e.A != 3) return e.Pc(0);
            d = e.sb();
            c.reportError(d);
            e.Eb()
        })
    };
    var au = function(a) {
        uo.call(this, a)
    };
    q(au, uo);
    var bu = function(a, b) {
        return hn(a, 1, b)
    };
    au.W = "contentads.bow.rendering.client.TurtleDoveReportingData";
    au.prototype.R = wo([0, io, eo, io, -5, no, io, -4]);

    function cu() {
        var a = Pg();
        return a ? Hb("AmazonWebAppPlatform;Android TV;Apple TV;AppleTV;BRAVIA;BeyondTV;Freebox;GoogleTV;HbbTV;LongTV;MiBOX;MiTV;NetCast.TV;Netcast;Opera TV;PANASONIC;POV_TV;SMART-TV;SMART_TV;SWTV;Smart TV;SmartTV;TV Store;UnionTV;Version/8.0 Safari/601.1 WPE;WebOS".split(";"), function(b) {
            return Va(a, b)
        }) || Va(a, "OMI/") && !Va(a, "XiaoMi/") ? !0 : Va(a, "Presto") && Va(a, "Linux") && !Va(a, "X11") && !Va(a, "Android") && !Va(a, "Mobi") : !1
    };
    var zr = Object.freeze({
            gh: 1E3,
            Ce: .5,
            Ye: .3
        }),
        Gr = Object.freeze([1, .75, zr.Ce, zr.Ye, 0]),
        du = function(a, b, c, d, e, f, g) {
            this.bj = a;
            this.hc = b;
            this.ac = c;
            this.Dc = d;
            this.qd = e;
            this.rd = f;
            this.me = g;
            this.name = "rxlidar";
            this.Hi = new bd;
            this.controlledEvents = [];
            this.subscribedEvents = [];
            this.ye = new bd;
            this.Ra = new bd;
            this.controlledEvents.push(this.Dc, this.qd, this.rd);
            this.subscribedEvents.push(this.ac)
        };
    n = du.prototype;
    n.start = function(a) {
        if (this.Je === void 0 && a.D) {
            var b;
            if ((b = this.hc) != null) var c = b;
            else {
                b = a.D;
                var d = (c = a.ta) != null ? c : null;
                c = {
                    Uh: .01,
                    Ki: of (b.l, 36E5),
                    Ib: b.l.Ga(100).g(V(b.i, 1)),
                    ta: d
                }
            }
            this.hc = c;
            a = a.D;
            this.Je = eu(a, this.ye.g(V(a.i, 1)), this.hc.Uh, this.hc.Ki, this.hc.Ib, this.hc.ta, this.Ra.g(R(!1), V(a.i, 1)), this.Dc, this.qd, this.rd, this.me).subscribe(this.Hi)
        }
    };
    n.dispose = function() {
        this.ye.complete();
        this.Ra.complete();
        var a;
        (a = this.Je) == null || a.unsubscribe();
        this.Je = void 0
    };
    n.Le = function(a, b, c, d, e) {
        if (!Mm(b, Xm, 2) || Zm(b, Xm, 2).Ge()) {
            this.ye.next(Object.assign({}, this.bj.Xf.get(a), {
                metadata: b,
                experimentState: c,
                Wk: a,
                ab: d
            }));
            var f, g;
            e((g = (f = Zm(b, Xm, 2)) == null ? void 0 : f.Fd()) != null ? g : -1)
        }
    };
    n.Yb = function() {};
    n.handleEvent = function(a, b) {
        b === this.ac && (this.Ra.next(!0), this.Ra.complete())
    };

    function eu(a, b, c, d, e, f, g, h, k, l, m) {
        var u = Qs(a).g(N(function(r) {
                return !r
            })),
            t = new qs(a, [new ws(a, Gr), new vs(a, e), new Ns(f, a, Gr), new Ms(f, a, e), new Gs(a, e)]);
        return op(a, b, function(r, w) {
            var v = cs(r, w.element),
                z = v.xa,
                C = v.Ec,
                Q = v.ve,
                T = v.Cf,
                oa = v.Oh,
                H = v.Bb,
                D = v.xi,
                fa = v.Qe,
                Lc = v.Ue,
                pc = v.fb,
                yd = v.va,
                Qa = v.Hj,
                Eg = v.Db;
            v = v.Xe;
            var Fg, Ya = (Fg = lt(Ym(w.metadata))) != null ? Fg : "",
                Ou = nt(Ym(w.metadata));
            Fg = bu(new au, atob(Ya)).hb();
            Ya = (new W(w.experimentState)).X(r.i);
            var Jn = new W(new qf(r, new Ig(r))),
                Kn = Ya.g(N(function(B) {
                        return B.fetchLaterBeacons
                    }),
                    R(!1), P(), V(r.i, 1)),
                Pu = Kn.g(N(function(B) {
                    return B && (new Bg(r)).P({
                        cg: !0
                    })
                }), jf(function(B) {
                    B && Jn.value.K("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fetch&later&start&control&fle=1&sfl=1").sendNow()
                })),
                Le = Ya.g(N(function(B) {
                    return B.shouldIgnoreAdChoicesIcon
                })),
                Ra = H.g(Ne(D), N(function(B) {
                    var Za = x(B);
                    B = Za.next().value;
                    Za = Za.next().value;
                    (B = B || Za) || ((B = Va(Pg(), "CrKey") && !(Va(Pg(), "CrKey") && Va(Pg(), "SmartSpeaker")) || Va(Pg(), "PlayStation") || Va(Pg(), "Roku") || cu() || Va(Pg(), "Xbox")) ||
                        (B = Pg(), B = Va(B, "AppleTV") || Va(B, "Apple TV") || Va(B, "CFNetwork") || Va(B, "tvOS")), B || (B = Pg(), B = Va(B, "sdk_google_atv_x86") || Va(B, "Android TV")));
                    return B
                }));
            D = new ls(r, w, oa, H, pc, Le);
            Le = Ya.g(N(function(B) {
                return B.considerOmidZOrderOcclusions
            }));
            var Oc, Bb = (Oc = mt(Ym(w.metadata))) != null ? Oc : !1;
            Oc = t.mb(D, {
                Bb: H,
                kh: Bb,
                fb: pc,
                Mg: Le
            });
            var gb = Oc.wb,
                Me = Oc.lb;
            Oc = Me.bf;
            Le = Me.cf;
            Me = Me.vf;
            Bb = (new W(Bb)).X(r.i);
            var Pc = Vs(r, Lc, Ra, u, Qa, Bb, D);
            Qa = Mr(r.i, r.l, gb, Pc);
            Ra = Ts(r.i, Qa.Fa.yf, Qa.Fa.visible, Qa.tf, Qa.hd);
            Bb = as(r.i, r.l,
                Qa.hd, Qa.Fa.ma, Qa.Fa.visible);
            gb = pr(r.i, r.l, gb, Pc);
            Pc = Fr(r.l, r.i, gb.Fa.yf, gb.Fa.visible, gb.tf, gb.hd);
            var Gg = {
                    ee: yr(r.i, r.l, gb.hd, Pc.Uc)
                },
                Yi = Ya.g(N(function(B) {
                    return B.extrapolators
                }), R(!1));
            gb = eq(r.i, Yi, Object.assign({}, gb.Fa, Pc, Gg), Object.assign({}, Qa.Fa, {
                ee: fr(r, Bb),
                Vc: fr(r, Ra.Vc),
                Va: fr(r, Ra.Va),
                Uc: fr(r, Ra.Uc),
                pb: Ra.pb.g(N(function(B) {
                    return new er(r.l, B)
                })),
                Yd: fr(r, Ra.Yd),
                Zd: fr(r, Ra.Zd)
            }));
            Ra = Oq(r, d.g(Qe("t")));
            Bb = (f !== null && f.validate() ? f.qj : Qd).g(V(r.i, 1), Qe("u"));
            Ra = Ud(Ra, Bb);
            var Ln = Ra.g(O(function(B) {
                return B !==
                    null
            }));
            Bb = Ya.g(N(function(B) {
                return B.shouldCacheTimeMetricsInLocalStorage && Ou
            }), P(), V(r.i, 1)).g(N(function(B) {
                B && fu(r);
                return B && Ro(r, function(Za) {
                    Zt(r, Za)
                }) && !r.Cb
            }), P(), V(r.i, 1));
            Pc = Ya.g(N(function(B) {
                return B.omakaseAdStatsResetVersion
            }), P(), V(r.i, 1));
            var Ru = r.l.Ga(4E3).g(Ne(u), O(function(B) {
                B = x(B);
                B.next();
                return !B.next().value
            }), N(function(B) {
                return x(B).next().value
            }), V(r.i, 1));
            Gg = Bb.g(S(function(B) {
                return B ? Pd(Ln, Ru) : Ln
            }), P(), V(r.i, 1));
            Yi = Rs(r, gb.ma, Gg);
            var Mn = gu(r, D, z),
                Uu = hu(r, Ra, w.element),
                Vu = Mn.Bh.g(R({
                    x: 0,
                    y: 0
                })),
                Wu = Ya.g(N(function(B) {
                    return B.rxlidarStatefulBeacons
                }), R(!1), P(), jf(function(B) {
                    Jh = B
                }), V(r.i, 1)),
                Nn = fa.g(N(function(B) {
                    return B === 40 || B === 41 || B === 42
                })),
                Xu = Ya.g(N(function(B) {
                    return B.waitForImpressionColleague
                }), R(!1), P(), V(r.i, 1)),
                Yu = b.g(N(function(B) {
                    var Za;
                    return B.experimentState.addQueryIdToErrorPing ? (Za = Zm(B.metadata, vt, 3)) == null ? void 0 : Za.ng() : void 0
                }));
            return Object.assign({}, {
                I: new W(r.I),
                cc: new W("lidar2"),
                yj: new W("lidartos"),
                Fh: new W(Dp),
                me: new W(m),
                te: new W(r.validate() ?
                    null : new de),
                Kh: new W(si(r.document)),
                ca: new W(Hp),
                Be: Ra,
                fh: Ra,
                Rk: Yi,
                Kc: g,
                Gj: Xu,
                Li: Gg,
                sf: Bb,
                hj: Pc,
                ab: new W(w.ab),
                Dc: new W(h),
                qd: new W(k),
                rd: new W(l),
                Nh: new W(r.Cb ? 1 : void 0),
                Ph: new W(r.Gh ? 1 : void 0),
                Bb: H,
                Db: Eg,
                Af: new W(Fg),
                sc: Eg.g(O(function(B) {
                    return B
                }), N(function() {
                    return r.sc.bind(r)
                })),
                bf: Oc.g(V(r.i, 1)),
                cf: Le.g(V(r.i, 1)),
                Zh: Ya.g(N(function(B) {
                    return B.extraPings
                })),
                zg: Wu,
                ji: Kn,
                dh: Pu,
                Xe: v,
                wi: Nn,
                ki: Ya.g(N(function(B) {
                    return B.dedicatedViewableAttributionPing
                })),
                ai: Jn,
                eh: new W(Jh && (new Ih(r)).P({
                    ia: "GET"
                })),
                tj: new W(Number(w.experimentState.useReachIntegrationSharedStorage) << 0 + Number(w.experimentState.useReachIntegrationPolyfill) << 1 + Number(w.experimentState.sendBrowserIdInsteadOfVPID) << 2),
                Mh: w.element.g(N(function(B) {
                    return B !== null
                })),
                Ab: yd,
                zj: yd,
                ve: Q.g(R([])),
                Cf: T.g(R([])),
                hi: Q.g(N(function(B) {
                    return B.length > 0 ? !0 : null
                }), R(null), P()),
                Ec: C.g(R([]), V(r.i, 1)),
                vk: Ya,
                shouldSendExplicitDisplayMeasurablePing: Ya.g(N(function(B) {
                    return B.shouldSendExplicitDisplayMeasurablePing
                })),
                xa: z,
                Gc: D.Gc,
                Qe: fa.g(R(0),
                    V(r.i, 1)),
                Ii: oa,
                fb: pc.g(R(0), V(r.i, 1)),
                Rb: Nn.g(N(function(B) {
                    return B ? cq : Gp
                })),
                zc: new W(dq),
                Ue: Lc,
                Bg: D.Rc.g(fq(r.i)),
                Df: D.Df
            }, gb, {
                yd: vd([gb.yd, Vu]).g(N(function(B) {
                    var Za = x(B);
                    B = Za.next().value;
                    Za = Za.next().value;
                    return zi(B, Za)
                }), P(xi))
            }, Mn, {
                kd: Xh(r),
                ii: Uu,
                vf: Me,
                ce: Qa.Fa.ce,
                Hh: new W(new Xp),
                escapedQueryId: Yu
            })
        }, Fp(a, "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&bin=" + m + "&v=" + Dp, c), Kp(Lp(Mp(), Wp), qp, Ip, Ap(new $t(a))))
    }

    function gu(a, b, c) {
        var d = d === void 0 ? Ha : d;
        var e, f;
        d = ((e = d.performance) == null ? void 0 : (f = e.timing) == null ? void 0 : f.navigationStart) || 0;
        return Object.assign({}, {
            zh: new W(d),
            yh: tq(a, b)
        }, sq(a, b, c))
    }

    function hu(a, b, c) {
        return b.g(O(function(d) {
            return d !== null
        }), S(function() {
            return c
        }), N(function(d) {
            var e = fp(a);
            return e.length > 0 && e.indexOf(d) >= 0
        }), N(function(d) {
            return !d
        }))
    }

    function fu(a) {
        if (a.Cb) {
            var b = Error();
            b.name = "IframeError";
            b.message = "Failure: Omakase is running in cross origin context.";
            Zt(a, b)
        }
        a.Lc() || (b = Error(), b.name = "LocksApiUnavailableError", b.message = "Failure: Web Locks API is not present", Zt(a, b))
    };
    var iu = function(a) {
        var b = b === void 0 ? [] : b;
        var c = c === void 0 ? [a] : c;
        this.ac = a;
        this.subscribedEvents = b;
        this.controlledEvents = c;
        this.name = "impression";
        this.Ne = new Map
    };
    n = iu.prototype;
    n.start = function(a) {
        this.Za = a
    };
    n.dispose = function() {
        this.Ne.clear()
    };
    n.Le = function(a, b, c, d) {
        if (b = this.Za) c = new ju(b, c, this.ac, d), this.Ne.set(a, c)
    };
    n.Yb = function(a) {
        this.Ne.delete(a)
    };
    n.handleEvent = function() {};
    var ju = function(a, b, c, d) {
        var e = this;
        this.context = a;
        this.ac = c;
        this.ih = function() {};
        this.yg = [];
        this.wg = "&avradf=1";
        this.xg = Zs([]);
        this.Ra = new bd;
        c = a.ta;
        var f = c !== null && (c == null ? void 0 : c.validate()),
            g, h = (g = a.D) == null ? void 0 : g.i;
        this.Ra.g(R(!b.waitForImpressionColleague), V(h, 1));
        this.vj = f ? c == null ? void 0 : c.vg.g(Re(1), Qe(!0), R(!1)) : (new W(!0)).X(h);
        this.ih = function(k, l) {
            e.Ra.next(!0);
            e.Ra.complete();
            vd([e.Ra, e.vj]).subscribe(function(m) {
                var u = x(m);
                m = u.next().value;
                u = u.next().value;
                if (!u) return Qd;
                m && u &&
                    d(e.ac, k, l);
                return !0
            })
        };
        this.init(a.D)
    };
    ju.prototype.init = function(a) {
        var b = this;
        this.Zc = a.global.document;
        this.yg.push(ku(this));
        var c = {};
        this.xg = Zs(this.yg);
        this.xg.then(function() {
            b.wg = "&vis=" + Os(b.Zc) + "&uach=0&ms=0";
            c.paramString = b.wg;
            c.view_type = "DELAYED_IMPRESSION";
            b.ih(c, function() {})
        })
    };
    var ku = function(a) {
        return new Ys(function(b) {
            var c = Ps(a.Zc);
            if (c)
                if (Os(a.Zc) === 3) {
                    var d = function() {
                        var e = a.Zc;
                        typeof e.removeEventListener === "function" && e.removeEventListener(c, d, !1);
                        b(!0)
                    };
                    Fh(a.Zc, c, d)
                } else b(!0)
        })
    };

    function lu(a) {
        var b = Yh(a);
        return b ? b.g(N(function(c) {
            var d;
            c = (d = an(c).find(function(f) {
                return sl(Im(f, 1)) === "Google Chrome"
            })) == null ? void 0 : sl(Im(d, 2));
            if (!c) return !1;
            var e;
            return ((e = x(c.split(".").map(function(f) {
                return Number(f)
            })).next().value) != null ? e : 0) >= 121
        })) : Oh.X(a.i)
    };

    function mu(a, b) {
        b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=reach&proto=" + encodeURIComponent(Th(b.R()));
        a.I.K(b, {
            ia: "GET"
        }).sendNow()
    };

    function nu(a) {
        return [{
            Wb: 2,
            fd: !1,
            Hc: !0,
            filterIds: ou(a == null ? void 0 : a.productionFilterIds)
        }, {
            Wb: 2,
            fd: !0,
            Hc: !0,
            filterIds: ou(a == null ? void 0 : a.testFilterIds)
        }, {
            Wb: 2,
            fd: !1,
            Hc: !1,
            filterIds: ou(a == null ? void 0 : a.testFilterIds)
        }]
    }

    function ou(a) {
        if (a !== void 0 && typeof BigInt === "function") return a.map(function(b) {
            return BigInt(b)
        })
    };
    var pu = function(a) {
        uo.call(this, a)
    };
    q(pu, uo);
    var qu = function(a, b) {
        return jn(a, 1, b)
    };
    n = pu.prototype;
    n.Nb = function(a) {
        return hn(this, 2, a)
    };
    n.Mb = function(a) {
        return hn(this, 3, a)
    };
    n.gd = function(a) {
        return hn(this, 10, a)
    };
    n.og = function() {
        return Zm(this, pt, 11)
    };
    n.Wg = function(a) {
        return bn(this, pt, 11, a)
    };
    pu.W = "ads.branding.measurement.client.frontend.integrations.reach.ReachStatusMessage";
    pu.prototype.R = wo([0, no, io, -1, no, -2, io, -1, eo, io, tt, oo, eo]);
    var ru = function(a) {
            this.context = a;
            this.points = []
        },
        su = function(a, b) {
            Ca(function(c) {
                if (c.A == 1) return c.qf(2), c.u(b(), 4);
                if (c.A != 2) return c.return(c.V);
                c.Bd();
                a.flush();
                return c.Nd(0)
            })
        };
    ru.prototype.flush = function() {
        if (!(this.points.length <= 0)) {
            var a = new pu;
            qu(a, 9);
            var b = nu().length;
            Km(a, 13, b == null ? b : ml(b));
            kn(a, 12, this.points);
            this.points.splice(0);
            mu(this.context, a)
        }
    };

    function tu() {
        this.blockSize = -1
    };

    function uu(a, b) {
        this.blockSize = -1;
        this.blockSize = 64;
        this.vd = Ha.Uint8Array ? new Uint8Array(this.blockSize) : Array(this.blockSize);
        this.ae = this.bc = 0;
        this.F = [];
        this.Ri = a;
        this.Ag = b;
        this.Fj = Ha.Int32Array ? new Int32Array(64) : Array(64);
        vu === void 0 && (vu = Ha.Int32Array ? new Int32Array(wu) : wu);
        this.reset()
    }
    Na(uu, tu);
    for (var xu = [], yu = 0; yu < 63; yu++) xu[yu] = 0;
    var zu = [].concat(128, xu);
    uu.prototype.reset = function() {
        this.ae = this.bc = 0;
        this.F = Ha.Int32Array ? new Int32Array(this.Ag) : Jb(this.Ag)
    };
    var Au = function(a) {
        var b = a.vd;
        F(b.length == a.blockSize);
        for (var c = a.Fj, d = 0, e = 0; e < b.length;) c[d++] = b[e] << 24 | b[e + 1] << 16 | b[e + 2] << 8 | b[e + 3], e = d * 4;
        for (b = 16; b < 64; b++) d = c[b - 15] | 0, e = c[b - 2] | 0, c[b] = ((c[b - 16] | 0) + ((d >>> 7 | d << 25) ^ (d >>> 18 | d << 14) ^ d >>> 3) | 0) + ((c[b - 7] | 0) + ((e >>> 17 | e << 15) ^ (e >>> 19 | e << 13) ^ e >>> 10) | 0) | 0;
        b = a.F[0] | 0;
        d = a.F[1] | 0;
        e = a.F[2] | 0;
        for (var f = a.F[3] | 0, g = a.F[4] | 0, h = a.F[5] | 0, k = a.F[6] | 0, l = a.F[7] | 0, m = 0; m < 64; m++) {
            var u = ((b >>> 2 | b << 30) ^ (b >>> 13 | b << 19) ^ (b >>> 22 | b << 10)) + (b & d ^ b & e ^ d & e) | 0,
                t = (l + ((g >>> 6 | g << 26) ^ (g >>> 11 |
                    g << 21) ^ (g >>> 25 | g << 7)) | 0) + (((g & h ^ ~g & k) + (vu[m] | 0) | 0) + (c[m] | 0) | 0) | 0;
            l = k;
            k = h;
            h = g;
            g = f + t | 0;
            f = e;
            e = d;
            d = b;
            b = t + u | 0
        }
        a.F[0] = a.F[0] + b | 0;
        a.F[1] = a.F[1] + d | 0;
        a.F[2] = a.F[2] + e | 0;
        a.F[3] = a.F[3] + f | 0;
        a.F[4] = a.F[4] + g | 0;
        a.F[5] = a.F[5] + h | 0;
        a.F[6] = a.F[6] + k | 0;
        a.F[7] = a.F[7] + l | 0
    };
    uu.prototype.update = function(a, b) {
        b === void 0 && (b = a.length);
        var c = 0,
            d = this.bc;
        if (typeof a === "string")
            for (; c < b;) this.vd[d++] = a.charCodeAt(c++), d == this.blockSize && (Au(this), d = 0);
        else if (Ka(a))
            for (; c < b;) {
                var e = a[c++];
                if (!("number" == typeof e && 0 <= e && 255 >= e && e == (e | 0))) throw Error("Qa");
                this.vd[d++] = e;
                d == this.blockSize && (Au(this), d = 0)
            } else throw Error("Ra");
        this.bc = d;
        this.ae += b
    };
    uu.prototype.digest = function() {
        var a = [],
            b = this.ae * 8;
        this.bc < 56 ? this.update(zu, 56 - this.bc) : this.update(zu, this.blockSize - (this.bc - 56));
        for (var c = 63; c >= 56; c--) this.vd[c] = b & 255, b /= 256;
        Au(this);
        for (c = b = 0; c < this.Ri; c++)
            for (var d = 24; d >= 0; d -= 8) a[b++] = this.F[c] >> d & 255;
        return a
    };
    var wu = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804,
            4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298
        ],
        vu;

    function Bu() {
        uu.call(this, 8, Cu)
    }
    Na(Bu, uu);
    var Cu = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
    var ro = function(a) {
        uo.call(this, a)
    };
    q(ro, uo);
    ro.W = "EventIdMessage";
    var Du = function(a) {
        uo.call(this, a)
    };
    q(Du, uo);
    Du.prototype.vc = function(a) {
        return gn(this, 4, a)
    };
    Du.prototype.qg = function() {
        return Pm(this, 8, kl, void 0 === Qk ? 2 : 4)
    };
    Du.prototype.Of = function(a) {
        return kn(this, 8, a)
    };
    Du.prototype.Xg = function(a) {
        return fn(this, 9, a)
    };
    Du.W = "ads.branding.measurement.client.frontend.integrations.reach.ContextIdMessage";
    var Eu = [0, ao, go, -1];
    ro.prototype.R = wo(Eu);
    Du.prototype.R = wo([0, Eu, ho, -1, lo, -3, po, ho]);
    var qo = function(a) {
        uo.call(this, a, 1)
    };
    q(qo, uo);
    qo.W = "proto2.bridge.MessageSet";
    var Fu = {};
    qo[Rk] = Fu;
    var Gu = vo(ro, Eu);
    Fu[4156379] = {
        yk: new so
    };
    var Hu = function() {
        var a;
        this.message = a = a === void 0 ? new Du : a
    };
    Hu.prototype.gd = function(a) {
        var b = this.message;
        a = Gu(Vh(a));
        this.message = bn(b, ro, 1, a);
        return this
    };
    var Iu = function(a, b) {
        var c = fn(a.message, 2, b.Wb === 2);
        b = fn(c, 3, !b.fd);
        a.message = b;
        return a
    };
    Hu.prototype.vc = function(a) {
        this.message = this.message.vc(Math.max(1, a));
        return this
    };
    var Ju = function(a, b) {
            a.message = a.message.Of(b);
            return a
        },
        Ku = function(a) {
            var b = Dp,
                c = b.match(/m\d{12}/g),
                d = b.match(/\d{8}/g);
            if (c && c.length > 0) return b = c[0].slice(1), c = a.message, d = Number(b.slice(0, 8)), c = gn(c, 5, d), d = Number(b.slice(8, 10)), c = gn(c, 6, d), b = Number(b.slice(10, 12)), b = gn(c, 7, b), a.message = b, a;
            if (d && d.length > 0) return b = gn(a.message, 5, Number(d[0])), b = Km(b, 6), b = Km(b, 7), a.message = b, a;
            b === "unreleased" && (b = Km(a.message, 5), b = gn(b, 6, 0), b = Km(b, 7), a.message = b);
            return a
        };
    Hu.prototype.encode = function() {
        var a = this.message,
            b = Th(a.R());
        b.length > 64 && (a = a.vc(1), b = Th(a.R()));
        b.length > 64 && (a = Km(a, 6), b = Th(a.R()));
        b.length > 64 && (a = Km(a, 7), b = Th(a.R()));
        b.length > 64 && (a = Km(a, 5), b = Th(a.R()));
        return b
    };

    function Lu(a, b) {
        if (b === void 0 || b.length === 0) return mu(a, qu(new pu, 7)), [ae(0)].filter(function(d) {
            return d !== void 0
        });
        var c = ae(-2147483648);
        return c === void 0 ? [] : b.map(function(d) {
            var e = d % c;
            d !== e && mu(a, qu(new pu, 6));
            return e
        })
    };

    function Mu(a, b) {
        var c = c === void 0 ? BigInt(0) : c;
        return {
            bucket: a,
            value: b ? 1 : 16384,
            filteringId: c
        }
    };

    function Nu(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            e < 128 ? b[c++] = e : (e < 2048 ? b[c++] = e >> 6 | 192 : ((e & 64512) == 55296 && d + 1 < a.length && (a.charCodeAt(d + 1) & 64512) == 56320 ? (e = 65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023), b[c++] = e >> 18 | 240, b[c++] = e >> 12 & 63 | 128) : b[c++] = e >> 12 | 224, b[c++] = e >> 6 & 63 | 128), b[c++] = e & 63 | 128)
        }
        if (b.length >= 24) throw Error("Sa");
        return [96 | b.length].concat(y(b))
    }

    function Qu(a) {
        if (a.length >= 24) throw Error("Ta");
        return [160 | a.length].concat(y(a.sort(Su).map(function(b) {
            return [].concat(y(b[0]), y(b[1]))
        }).flat()))
    }

    function Tu(a) {
        if (a.length >= 24) throw Error("Ua");
        return [128 | a.length].concat(y(a.flat()))
    }

    function Zu(a, b) {
        for (var c = []; a > 0;) c.push(Number(a % BigInt(255))), a /= BigInt(255);
        for (; c.length < b;) c.push(0);
        return c.reverse()
    }

    function Su(a, b) {
        a = a[0];
        b = b[0];
        if (a.length !== b.length) return a.length - b.length;
        for (var c = 0; c < a.length; c++)
            if (a[c] !== b[c]) return a[c] - b[c];
        return 0
    };

    function $u(a, b, c, d) {
        var e = Mu(BigInt(c), d);
        b = {
            shared_info: JSON.stringify({
                api: "shared-storage",
                report_id: "PRE_WORKLET_ERROR",
                reporting_origin: "https://www.googleadservices.com",
                scheduled_report_time: String((new Date).getUTCSeconds()),
                version: "polyfill"
            }),
            aggregation_service_payloads: [],
            context_id: b,
            aggregation_coordinator_origin: "https://publickeyservice.msmt.gcp.privacysandboxservices.com"
        };
        d ? (b.debug_key = "0", b.aggregation_service_payloads.push({
                payload: String(c),
                key_id: "0",
                debug_cleartext_payload: av([e])
            })) :
            b.aggregation_service_payloads.push({
                payload: String(c),
                key_id: "0"
            });
        try {
            var f, g;
            (f = a.global) == null || (g = f.fetch) == null || g.call(f, "https://www.googleadservices.com/.well-known/private-aggregation/report-shared-storage", {
                method: "POST",
                cache: "no-cache",
                keepalive: !0,
                mode: "no-cors",
                headers: {
                    "content-type": "application/json"
                },
                body: JSON.stringify(b)
            }).catch(function() {})
        } catch (h) {}
    }

    function av(a) {
        a = Qu([
            [Nu("data"), Tu(a.map(function(b) {
                return Qu([
                    [Nu("value"), [68].concat(y(Zu(BigInt(b.value), 4)))],
                    [Nu("bucket"), [80].concat(y(Zu(b.bucket, 16)))],
                    [Nu("filteringId"), [68].concat(y(Zu(b.filteringId, 4)))]
                ])
            }))],
            [Nu("operation"), Nu("histogram")]
        ]);
        return btoa(String.fromCharCode.apply(String, y(new Uint8Array(a))))
    };
    var bv = {},
        cv = (bv[2] = "prod", bv[1] = "canary", bv);

    function dv(a, b, c, d) {
        var e, f, g, h, k, l, m, u;
        return Ca(function(t) {
            switch (t.A) {
                case 1:
                    e = nu(c);
                    f = function(r) {
                        e.forEach(function(w) {
                            var v, z = Ku(Iu(Ju((new Hu).gd(c.escapedQueryId), (v = c.trafficTypes) != null ? v : [0]), w)).vc(-1).encode();
                            $u(a, z, r, w.Hc)
                        })
                    };
                    g = Qo(a);
                    if (g instanceof Error) return f(-16), h = qu(new pu, 8).Nb(g.name).Mb(g.message), mu(a, h), t.return();
                    d.points.push(7);
                    k = ev(a, c, e);
                    return t.u(c.experimentState.reachUseCreateWorklet ? fv(a, b, f) : gv(a, b, f), 2);
                case 2:
                    return l = t.V, t.u(k, 3);
                case 3:
                    return m = t.V, d.points.push(8),
                        u = e.map(function(r) {
                            var w, v, z;
                            return hv(a, l, r, m, (w = c.deviceType) != null ? w : 1, c.escapedQueryId, (v = c.trafficTypes) != null ? v : [0], (z = c.isProductSplitVpidLogsExperiment) != null ? z : !1, function(C) {
                                var Q, T = Ku(Iu(Ju((new Hu).gd(c.escapedQueryId), (Q = c.trafficTypes) != null ? Q : [0]).vc(-1), r)).encode();
                                $u(a, T, C, r.Hc)
                            })
                        }), t.u(Promise.all(u), 4);
                case 4:
                    d.points.push(9), t.Eb()
            }
        })
    }

    function gv(a, b, c) {
        var d, e, f;
        return Ca(function(g) {
            switch (g.A) {
                case 1:
                    d = a.sharedStorage;
                    if (!d) return g.return(Promise.reject(Error("Va")));
                    g.Lb(2);
                    return g.u(d.worklet.addModule(b), 4);
                case 4:
                    g.Pc(3);
                    break;
                case 2:
                    e = g.sb(), c(-17), f = qu(new pu, 1).Nb(e.name).Mb(e.message), mu(a, f);
                case 3:
                    return g.return(d)
            }
        })
    }

    function fv(a, b, c) {
        var d, e, f;
        return Ca(function(g) {
            if (g.A == 1) {
                d = a.sharedStorage;
                if (!d) return g.return(Promise.reject(Error("Va")));
                g.Lb(2);
                return g.u(d.createWorklet(b, {
                    dataOrigin: "script-origin"
                }), 4)
            }
            if (g.A != 2) return g.return(g.V);
            e = g.sb();
            c(-17);
            f = qu(new pu, 1).Nb(e.name).Mb(e.message);
            mu(a, f);
            return g.return(Promise.reject(e))
        })
    }

    function ev(a, b, c) {
        var d, e, f;
        return Ca(function(g) {
            if (g.A == 1) return d = [].concat(y(new Set(c.map(function(h) {
                return h.Wb
            })))), e = d.map(function(h) {
                return iv(a, b, h)
            }), g.u(Promise.all(e), 2);
            f = g.V;
            return g.return(new Map(f.map(function(h, k) {
                return [d[k], h]
            })))
        })
    }

    function iv(a, b, c) {
        var d, e, f, g, h, k, l, m, u;
        return Ca(function(t) {
            switch (t.A) {
                case 1:
                    return e = (d = b.clientsideModelFilename) != null ? d : "model_person_country_code_XX_person_region_code_5858.json", f = void 0, g = 1, h = {
                        method: "GET"
                    }, k = 200, l = b.geoTargetMessage ? qt(b.geoTargetMessage) : void 0, m = (new pu).gd(b.escapedQueryId).Wg(l), t.Lb(2), t.u(a.global.fetch(jv(c, e), h), 4);
                case 4:
                    f = t.V;
                    k = f.status;
                    if (f.ok) {
                        t.ba(5);
                        break
                    }
                    return t.u(a.global.fetch(jv(c, "model_person_country_code_XX_person_region_code_5858.json"), h), 6);
                case 6:
                    f =
                        t.V, g = 2;
                case 5:
                    t.Pc(3);
                    break;
                case 2:
                    u = t.sb(), k = -1, u instanceof Error && m.Nb(u.name).Mb(u.message);
                case 3:
                    var r = qu(m, 2);
                    Km(r, 9, k == null ? k : ml(k));
                    if (!f || !f.ok) return r = jn(m, 4, 4), r = hn(r, 8, e), hn(r, 7, ""), mu(a, m), t.return();
                    r = jn(m, 4, g);
                    hn(r, 7, g === 1 ? e : "");
                    mu(a, m);
                    return t.u(f.text(), 7);
                case 7:
                    return t.return(t.V)
            }
        })
    }

    function jv(a, b) {
        return "https://www.googletagservices.com/agrp/" + cv[a] + "/" + b
    }

    function hv(a, b, c, d, e, f, g, h, k) {
        var l, m, u, t, r, w, v;
        return Ca(function(z) {
            switch (z.A) {
                case 1:
                    l = d.get(c.Wb);
                    if (l === void 0) return z.return();
                    var C = ae(-2147483648);
                    if (C === void 0) C = -1;
                    else {
                        var Q = Number,
                            T = new Bu;
                        T.update(l);
                        var oa = T.digest();
                        T = BigInt(0);
                        oa = x(oa);
                        for (var H = oa.next(); !H.done; H = oa.next()) T = (T * BigInt(256) + BigInt(H.value)) % C;
                        C = Q(T)
                    }
                    m = C;
                    C = Ku(Iu(Ju((new Hu).gd(f), g), c).vc(m));
                    C.message = C.message.Xg(h);
                    u = C.encode();
                    t = {
                        contextId: u,
                        aggregationCoordinatorOrigin: "https://publickeyservice.msmt.gcp.privacysandboxservices.com",
                        filteringIdMaxBytes: 4
                    };
                    r = {
                        modelJson: l,
                        modelHash: m,
                        deviceType: e,
                        enableDebugMode: c.Hc,
                        reportBrowserIdInsteadOfVPID: c.fd,
                        filterIds: Lu(a, c.filterIds)
                    };
                    w = b.run("google_reach", {
                        privateAggregationConfig: t,
                        data: r,
                        keepAlive: !0
                    });
                    if (w === void 0) {
                        z.ba(2);
                        break
                    }
                    z.Lb(3);
                    return z.u(w, 5);
                case 5:
                    z.Pc(2);
                    break;
                case 3:
                    v = z.sb(), k(-18), C = v, oa = qu(new pu, 3).Nb((Q = C == null ? void 0 : C.name) != null ? Q : "unknown").Mb((T = C == null ? void 0 : C.message) != null ? T : ""), mu(a, oa);
                case 2:
                    C = qu(new pu, 5), C = jn(C, 5, c.Wb === 1 ? 1 : 2), C = jn(C, 6, c.fd ? 1 : 2),
                        mu(a, C), z.Eb()
            }
        })
    };
    var kv = function(a) {
        var b = b === void 0 ? [] : b;
        var c = c === void 0 ? [a] : c;
        this.gf = a;
        this.subscribedEvents = b;
        this.controlledEvents = c;
        this.name = "reach";
        this.bd = new Map
    };
    n = kv.prototype;
    n.start = function(a) {
        a.D && (this.context = a.D)
    };
    n.dispose = function() {
        this.bd.forEach(function(a) {
            return void a.dispose()
        });
        this.bd.clear()
    };
    n.Le = function(a, b, c, d, e) {
        var f = this,
            g = this.context;
        if (g) {
            var h = new ru(g);
            su(h, function() {
                var k, l, m, u;
                return Ca(function(t) {
                    if (t.A == 1) {
                        h.points.push(1);
                        if (Mm(b, rt, 1) && !yt(b).Ge()) return t.return();
                        h.points.push(2);
                        return Qo(g) ? t.u(gd(lu(g)), 2) : t.return()
                    }
                    if (t.A != 3) {
                        k = t.V;
                        if (!k) return t.return();
                        h.points.push(3);
                        l = new lv(g, b, f.gf, c, d, h);
                        f.bd.set(a, l);
                        return t.u(l.run(), 3)
                    }
                    e((u = (m = yt(b)) == null ? void 0 : m.Fd()) != null ? u : -1);
                    t.Eb()
                })
            })
        }
    };
    n.Yb = function(a) {
        var b;
        (b = this.bd.get(a)) == null || b.dispose();
        this.bd.delete(a)
    };
    n.handleEvent = function() {};
    var lv = function(a, b, c, d, e, f) {
        this.context = a;
        this.metadata = b;
        this.gf = c;
        this.experimentState = d;
        this.ab = e;
        this.ue = f
    };
    lv.prototype.run = function() {
        var a = this,
            b, c;
        return Ca(function(d) {
            if (d.A == 1) return b = {}, d.u(new Promise(function(e) {
                a.ab(a.gf, b, e)
            }), 2);
            c = d.V;
            if (!c) return d.return();
            a.ue.points.push(4);
            return d.u(mv(a), 0)
        })
    };
    var mv = function(a) {
            var b, c, d, e, f, g, h, k, l, m, u, t, r, w, v, z, C, Q;
            return Ca(function(T) {
                var oa = a.experimentState,
                    H = (l = (b = yt(a.metadata)) == null ? void 0 : b.mg()) != null ? l : "",
                    D = (m = (c = yt(a.metadata)) == null ? void 0 : c.qg()) != null ? m : void 0,
                    fa = (d = yt(a.metadata)) == null ? void 0 : sl(Im(d, 1)),
                    Lc = (u = (e = yt(a.metadata)) == null ? void 0 : (f = e.og()) == null ? void 0 : f.hb()) != null ? u : void 0,
                    pc = (t = (g = yt(a.metadata)) == null ? void 0 : dn(g, 8)) != null ? t : void 0,
                    yd = nv;
                var Qa = (h = yt(a.metadata)) == null ? void 0 : Pm(h, 5, nl, Qk === Qk ? 2 : 4);
                yd = yd(a, (r = Qa) != null ?
                    r : void 0);
                Qa = nv;
                var Eg = (k = yt(a.metadata)) == null ? void 0 : Pm(k, 6, nl, Qk === Qk ? 2 : 4);
                v = {
                    experimentState: oa,
                    escapedQueryId: H,
                    trafficTypes: D,
                    isProductSplitVpidLogsExperiment: !0,
                    clientsideModelFilename: fa,
                    geoTargetMessage: Lc,
                    deviceType: pc,
                    productionFilterIds: yd,
                    testFilterIds: Qa(a, (w = Eg) != null ? w : void 0)
                };
                if (a.experimentState.reachUseCreateWorklet) return Q = a.context.uf[2], a.ue.points.push(10), T.u(dv(a.context, Q, v, a.ue), 0);
                z = a.context.uf[0];
                C = btoa(JSON.stringify(v));
                return T.u(vi(a.context.document, z, C), 0)
            })
        },
        nv = function(a, b) {
            if (b !== void 0) return b.map(function(c) {
                var d;
                return String((d = ae(c)) != null ? d : 0)
            })
        };
    lv.prototype.dispose = function() {};
    var ov = Hf("m202605130101".match(/^m\d{10}$/g) !== null ? "m202605130101" : "current"),
        pv;
    a: {
        try {
            var qv = new mg;
            pv = new Jf(qv, "doubleclickbygoogle.com-omid", void 0, ov);
            break a
        } catch (a) {}
        pv = void 0
    }
    var rv = pv,
        sv = {
            D: new Po(void 0, void 0, void 0, ov),
            ta: rv
        };
    (function(a) {
        if (a && zg(a)) {
            var b = yg(a);
            if (b) {
                a.global.fetch("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-start2", {
                    method: "GET",
                    cache: "no-cache",
                    keepalive: !0,
                    mode: "no-cors"
                });
                try {
                    b("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-later2", {
                        method: "GET",
                        cache: "no-cache",
                        mode: "no-cors",
                        activateAfter: 96E4
                    })
                } catch (c) {
                    a.global.fetch("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-fallback2", {
                        method: "GET",
                        cache: "no-cache",
                        keepalive: !0,
                        mode: "no-cors"
                    })
                }
                a.Og.subscribe(function() {
                    a.global.fetch("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-pagehide2", {
                        method: "GET",
                        cache: "no-cache",
                        keepalive: !0,
                        mode: "no-cors"
                    })
                })
            }
        }
    })(sv.D);
    (function(a, b, c) {
        var d = new ct("impression"),
            e = new ct("begin to render"),
            f = new ct("unmeasurable"),
            g = new ct("viewable"),
            h = new ct("reach vpid"),
            k = new at(d, h, e, g, f),
            l = new Ct,
            m = new iu(d.event);
        b = new du(l, c, d.event, e.event, f.event, g.event, b);
        h = new kv(h.event);
        var u = new dt(a, k, l, m, b, h);
        u.start();
        return {
            dispose: function() {
                return void u.dispose()
            },
            colleagues: {
                tk: m,
                Uk: b,
                Qk: h
            }
        }
    })(sv, 7);
}).call(this);
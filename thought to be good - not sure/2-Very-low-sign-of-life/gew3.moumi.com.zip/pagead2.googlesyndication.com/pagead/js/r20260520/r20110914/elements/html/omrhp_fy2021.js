(function() {
    'use strict';
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var g = this || self;

    function h(a) {
        h[" "](a);
        return a
    }
    h[" "] = function() {};

    function l(a) {
        for (var b = g, c = 0; b && c++ < 40;) {
            var d = !1;
            try {
                var e;
                if (e = !!b && b.location.href != null) b: {
                    try {
                        h(b.foo);
                        e = !0;
                        break b
                    } catch (f) {}
                    e = !1
                }
                d = e
            } catch {
                d = !1
            }
            if (d && a(b)) break;
            a: {
                try {
                    let f = b.parent;
                    if (f && f !== b) {
                        b = f;
                        break a
                    }
                } catch {}
                b = null
            }
        }
    };

    function n() {
        return new p(a => a(void 0))
    }

    function q(a, b) {
        if (!a.i)
            if (b instanceof p) b.then(c => {
                q(a, c)
            });
            else {
                a.i = !0;
                a.j = b;
                for (b = 0; b < a.g.length; ++b) r(a, a.g[b]);
                a.g = []
            }
    }

    function r(a, b) {
        a.i ? b(a.j) : a.g.push(b)
    }
    class p {
        constructor(a) {
            this.i = !1;
            this.g = [];
            a(b => {
                q(this, b)
            })
        }
        then(a) {
            return new p(b => {
                r(this, c => {
                    b(a(c))
                })
            })
        }
    };

    function t(a, b) {
        if (a)
            for (let c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function u(a = document) {
        return a.createElement("img")
    };

    function v(a) {
        var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=rhmss";
        t(a, (c, d) => {
            if (c || c === 0) b += `&${d}=${encodeURIComponent(String(c))}`
        });
        w(b)
    }

    function w(a) {
        var b = window;
        if (b.fetch) b.fetch(a, {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors"
        });
        else {
            b.google_image_requests || (b.google_image_requests = []);
            let c = u(b.document);
            c.src = a;
            b.google_image_requests.push(c)
        }
    };
    var x = {
        v: "app",
        A: "web"
    };

    function y(a) {
        if (!a) throw Error("functionToExecute must not be truthy.");
    };

    function z() {
        return /\d+\.\d+\.\d+(-.*)?/.test("1.6.5-google_20260406")
    }

    function A() {
        var a = ["1", "6", "5"],
            b = ["1", "0", "3"];
        for (let c = 0; c < 3; c++) {
            let d = parseInt(a[c], 10),
                e = parseInt(b[c], 10);
            if (d > e) break;
            else if (d < e) return !1
        }
        return !0
    };

    function B(a) {
        return !!a && a.omid_message_guid !== void 0 && a.omid_message_method !== void 0 && a.omid_message_version !== void 0 && typeof a.omid_message_guid === "string" && typeof a.omid_message_method === "string" && typeof a.omid_message_version === "string" && (a.omid_message_args === void 0 || a.omid_message_args !== void 0)
    }

    function C(a) {
        return new D(a.omid_message_guid, a.omid_message_method, a.omid_message_version, a.omid_message_args)
    }

    function E(a) {
        var b = {
            omid_message_guid: a.i,
            omid_message_method: a.method,
            omid_message_version: a.version
        };
        a.g !== void 0 && (b.omid_message_args = a.g);
        return b
    }
    class D {
        constructor(a, b, c, d) {
            this.i = a;
            this.method = b;
            this.version = c;
            this.g = d
        }
    };
    class F {
        constructor(a) {
            this.i = a
        }
    };

    function G(a, b) {
        try {
            return a.frames && !!a.frames[b]
        } catch (c) {
            return !1
        }
    }

    function H(a) {
        return ["omid_v1_present", "omid_v1_present_web", "omid_v1_present_app"].some(b => G(a, b))
    }

    function I(a) {
        for (let b of Object.values(x))
            if (G(a, {
                    app: "omid_v1_present_app",
                    web: "omid_v1_present_web"
                }[b])) return b;
        return null
    };

    function J(a, b) {
        return a && (a[b] || (a[b] = {}))
    };

    function K() {
        return typeof crypto !== "undefined" && typeof crypto.getRandomValues === "function"
    }

    function L() {
        var a = new Uint8Array(16);
        crypto.getRandomValues(a);
        a[6] = a[6] & 15 | 64;
        a[8] = a[8] & 63 | 128;
        var b = [];
        for (let c = 0; c < 16; c++) b.push(a[c].toString(16).padStart(2, "0"));
        return b[0] + b[1] + b[2] + b[3] + "-" + b[4] + b[5] + "-" + b[6] + b[7] + "-" + b[8] + b[9] + "-" + b[10] + b[11] + b[12] + b[13] + b[14] + b[15]
    }

    function M() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, a => {
            var b = Math.random() * 16 | 0;
            return a === "y" ? (b & 3 | 8).toString(16) : b.toString(16)
        })
    };

    function N(...a) {
        O(() => {
            throw Error("Could not complete the test successfully - ", ...a);
        }, () => console.error(...a))
    }

    function O(a, b) {
        typeof jasmine !== "undefined" && jasmine ? a() : typeof console !== "undefined" && console && console.error && b()
    };
    var P = function() {
        if (typeof omidGlobal !== "undefined" && omidGlobal) return omidGlobal;
        if (typeof global !== "undefined" && global) return global;
        if (typeof window !== "undefined" && window) return window;
        if (typeof globalThis !== "undefined" && globalThis) return globalThis;
        var a = Function("return this")();
        if (a) return a;
        throw Error("Could not determine global object context.");
    }();
    class Q extends F {
        constructor(a) {
            super(a);
            this.handleExportedMessage = Q.prototype.j.bind(this)
        }
        sendMessage(a, b = this.i) {
            if (!b) throw Error("Message destination must be defined at construction time or when sending the message.");
            b.handleExportedMessage(E(a), this)
        }
        j(a, b) {
            B(a) && this.g && this.g(C(a), b)
        }
    };

    function R(a) {
        return a != null && typeof a.top !== "undefined" && a.top != null
    }

    function S(a) {
        if (a === P) return !1;
        try {
            if (typeof a.location.hostname === "undefined") return !0
        } catch (b) {
            return !0
        }
        return !1
    }

    function T() {
        var a;
        typeof a === "undefined" && typeof window !== "undefined" && window && (a = window);
        return R(a) ? a : P
    };
    class U extends F {
        constructor(a, b = P) {
            super(b);
            a.addEventListener("message", c => {
                if (typeof c.data === "object") {
                    var d = c.data;
                    B(d) && c.source && this.g && this.g(C(d), c.source)
                }
            })
        }
        sendMessage(a, b = this.i) {
            if (!b) throw Error("Message destination must be defined at construction time or when sending the message.");
            b.postMessage(E(a), "*")
        }
    };
    var aa = ["omid", "v1_VerificationServiceCommunication"],
        ba = ["omidVerificationProperties", "serviceWindow"];

    function V(a, b) {
        return b.reduce((c, d) => c && c[d], a)
    };

    function W(a, b, c, ...d) {
        if (a.i) {
            var e = K() ? L() : M();
            c && (a.j[e] = c);
            b = "VerificationService." + b;
            d = z() && A() ? d : JSON.stringify(d);
            a.i.sendMessage(new D(e, b, "1.6.5-google_20260406", d))
        }
    }
    class X {
        constructor(a) {
            if (!a) {
                a = T();
                var b = [],
                    c = V(a, ba);
                c && b.push(c);
                b.push(R(a) ? a.top : P);
                a: {
                    for (let e of b) {
                        b: {
                            b = a;c = H;
                            if (!S(e)) try {
                                let f = V(e, aa);
                                if (f) {
                                    var d = new Q(f);
                                    break b
                                }
                            } catch (f) {}
                            d = c(e) ? new U(b, e) : null
                        }
                        if (b = d) {
                            a = b;
                            break a
                        }
                    }
                    a = null
                }
            }
            if (this.i = a) this.i.g = this.l.bind(this);
            else if (d = (d = P.omid3p) && typeof d.registerSessionObserver === "function" && typeof d.addEventListener === "function" ? d : null) this.omid3p = d;
            this.j = {};
            (this.g = (d = P.omidVerificationProperties) ? d.injectionId : void 0) || (K() ? L() : M())
        }
        registerSessionObserver(a,
            b) {
            y(a);
            this.omid3p ? this.omid3p.registerSessionObserver(a, b, this.g) : W(this, "addSessionListener", a, b, this.g)
        }
        addEventListener(a, b) {
            if (!a) throw Error("Value for eventType is undefined, null or blank.");
            if (typeof a !== "string" && !(a instanceof String)) throw Error("Value for eventType is not a string.");
            if (a.trim() === "") throw Error("Value for eventType is empty string.");
            y(b);
            this.omid3p ? this.omid3p.addEventListener(a, b, this.g) : W(this, "addEventListener", b, a, this.g)
        }
        l(a) {
            var b = a.method,
                c = a.i;
            a = a.g;
            if (b ===
                "response" && this.j[c]) {
                var d = z() && A() ? a ? a : [] : a && typeof a === "string" ? JSON.parse(a) : [];
                this.j[c].apply(this, d)
            }
            b === "error" && window.console && N(a)
        }
    }(function(a, b, c = typeof omidExports === "undefined" ? null : omidExports) {
        c && (a = a.split("."), a.slice(0, a.length - 1).reduce(J, c)[a[a.length - 1]] = b)
    })("OmidVerificationClient", X);

    function ca() {
        var a = null;
        l(b => (b = b.mraid) && b.IS_GMA_SDK ? (a = b, !0) : !1);
        return a
    }

    function da() {
        return new p(a => {
            g.document.readyState && g.document.readyState === "complete" ? a() : g.addEventListener("load", a)
        })
    }

    function ea() {
        return new p(a => {
            var b = ca();
            b && (b.getState() === "loading" ? b.addEventListener("ready", () => {
                a(b)
            }) : a(b))
        })
    }

    function fa(a, b = null) {
        b = new ha({
            timeout: b
        });
        b.i || ia(b);
        b.i.then(a)
    }

    function ja() {
        return new p(a => {
            da().then(() => {
                ea().then(b => {
                    var c = (d, e) => {
                        e.width > 0 && e.height > 0 && (a(), b.removeEventListener("exposureChange", c))
                    };
                    b.addEventListener("exposureChange", c)
                })
            })
        })
    }

    function ia(a) {
        a.m ? (a.i = new p(b => {
            var c = new p(e => {
                    var f = !1,
                        m, ka = (new Date).getTime();
                    a.l.registerSessionObserver(k => {
                        k.type === "sessionStart" && (m && g.clearTimeout(m), f ? (f = !1, k = (new Date).getTime() - ka, a.o || (a.o = !0, v({
                            te: k,
                            to: a.j
                        }))) : (k = k.data, e(k.context.environment == "app"), k.context.omidNativeInfo && (a.g.sdk = k.context.omidNativeInfo.partnerName)))
                    });
                    a.j != null && (m = g.setTimeout(() => {
                        f = !0;
                        e(!1)
                    }, a.j))
                }),
                d = new p(e => {
                    a.l.addEventListener("geometryChange", f => {
                        f = f.data;
                        var m = f.adView.reasons;
                        m && m.indexOf("hidden") !=
                            -1 || (f = f.adView, (f = f.onScreenContainerGeometry || f.onScreenGeometry) && f.width && f.height && e())
                    })
                });
            c.then(e => {
                e ? (d.then(() => {
                    a.g.src = 1;
                    b(a.g)
                }), ja().then(() => {
                    a.g.src = 2;
                    b(a.g)
                })) : b()
            })
        }), a.i.then(() => {
            a.m = !1
        })) : a.i = n()
    }
    var ha = class {
        constructor(a = {}) {
            var b = this.l = a.client ? ? new X,
                c = T();
            var d = (d = P.omidVerificationProperties) && d.injectionSource ? d.injectionSource : void 0;
            this.u = (d || I(c) || I(R(c) ? c.top : P)) !== "web" || b.g ? !(!b.i && !b.omid3p) : !1;
            this.i = null;
            this.m = this.u;
            this.g = {};
            this.j = a.timeout ? ? null;
            this.o = !1
        }
    };
    var Y = function(a, b = null) {
            return b && b.getAttribute("data-jc") === String(a) ? b : document.querySelector(`[data-jc="${a}"]`)
        }(86, document.currentScript),
        Z;
    if (Y) {
        let a = {},
            b = Y.attributes;
        for (let c = b.length - 1; c >= 0; c--) {
            let d = b[c].name;
            d.indexOf("data-jcp-") === 0 && (a[d.substring(9)] = b[c].value)
        }
        Z = a
    } else Z = {};
    window.omrhp = function(a) {
        var b = +a ? .owwt;
        Number.isNaN(b) && (b = null);
        return c => {
            fa(c, b)
        }
    }(Z);
}).call(this);
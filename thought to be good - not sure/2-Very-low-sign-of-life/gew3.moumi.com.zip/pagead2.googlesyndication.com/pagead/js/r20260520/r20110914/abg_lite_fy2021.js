(function() {
    'use strict';
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var k = this || self;

    function ba(a) {
        k.setTimeout(() => {
            throw a;
        }, 0)
    };
    var ca, q;
    a: {
        for (var da = ["CLOSURE_FLAGS"], r = k, ea = 0; ea < da.length; ea++)
            if (r = r[da[ea]], r == null) {
                q = null;
                break a
            }
        q = r
    }
    var fa = q && q[748402147];
    ca = fa != null ? fa : !0;

    function ha(a) {
        ha[" "](a);
        return a
    }
    ha[" "] = function() {};
    var ia = void 0;

    function ja(a, b = !1) {
        return b && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol()
    }
    var ka = ja(),
        t = ja("m_m", !0);
    var w = ja("jas", !0);
    var x = {};

    function A(a, b) {
        return b === void 0 ? a.i !== B && !!(2 & (a.g[w] | 0)) : !!(2 & b) && a.i !== B
    }
    var B = {};

    function la(a) {
        a.W = !0;
        return a
    };
    var ma = la(a => typeof a === "number"),
        na = la(a => typeof a === "string");
    var qa = la(a => a >= oa && a <= pa),
        oa = BigInt(Number.MIN_SAFE_INTEGER),
        pa = BigInt(Number.MAX_SAFE_INTEGER);
    var ra = Number.isFinite;

    function E(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return ra(a) ? a | 0 : void 0
    };

    function sa(a) {
        return a
    };

    function ta(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        var f = [],
            g = a.length,
            h = 4294967295,
            l = !1,
            n = !!(b & 64),
            m = n ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1)) {
            var v = g && a[g - 1];
            v != null && typeof v === "object" && v.constructor === Object ? (g--, h = g) : v = void 0;
            !n || b & 128 || e || (l = !0, h = (ua ? ? sa)(h - m, m, a, v, void 0) + m)
        }
        b = void 0;
        for (e = 0; e < g; e++) {
            let p = a[e];
            if (p != null && (p = c(p, d)) != null)
                if (n && e >= h) {
                    let u = e - m;
                    (b ? ? (b = {}))[u] = p
                } else f[e] = p
        }
        if (v)
            for (let p in v) {
                a = v[p];
                if (a == null || (a = c(a, d)) == null) continue;
                g = +p;
                let u;
                n && !Number.isNaN(g) && (u = g + m) < h ? f[u] = a : (b ? ?
                    (b = {}))[p] = a
            }
        b && (l ? f.push(b) : f[h] = b);
        return f
    }

    function va(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return qa(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    let b = a[w] | 0;
                    return a.length === 0 && b & 1 ? void 0 : ta(a, b, va)
                }
                if (a != null && a[t] === x) return ya(a);
                return
        }
        return a
    }
    var ua;

    function ya(a) {
        a = a.g;
        return ta(a, a[w] | 0, va)
    };

    function za(a, b, c, d = 0) {
        if (a == null) {
            var e = 32;
            c ? (a = [c], e |= 128) : a = [];
            b && (e = e & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[w] | 0;
            if (ca && 1 & e) throw Error("rfarr");
            2048 & e && !(2 & e) && Aa();
            if (e & 256) throw Error("farr");
            if (e & 64) return (e | d) !== e && (a[w] = e | d), a;
            if (c && (e |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;e |= 64;
                var f = c.length;
                if (f) {
                    var g = f - 1;
                    let l = c[g];
                    if (l != null && typeof l === "object" && l.constructor === Object) {
                        b = e & 128 ? 0 : -1;
                        g -= b;
                        if (g >= 1024) throw Error("pvtlmt");
                        for (var h in l)
                            if (f = +h,
                                f < g) c[f + b] = l[h], delete l[h];
                            else break;
                        e = e & -16760833 | (g & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    h = Math.max(b, f - (e & 128 ? 0 : -1));
                    if (h > 1024) throw Error("spvt");
                    e = e & -16760833 | (h & 1023) << 14
                }
            }
        }
        a[w] = e | 64 | d;
        return a
    }

    function Aa() {
        if (ca) throw Error("carr");
        if (ka != null) {
            var a = ia ? ? (ia = {});
            var b = a[ka] || 0;
            b >= 5 || (a[ka] = b + 1, a = Error(), a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {}), a.__closure__error__context__984382.severity = "incident", ba(a))
        }
    };

    function Ba(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[w] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = G(a, c, !1, b && !(c & 16)) : (a[w] |= 34, c & 4 && Object.freeze(a)));
            return a
        }
        if (a != null && a[t] === x) return b = a.g, c = b[w] | 0, A(a, c) ? a : Ca(a, b, c) ? Da(a, b) : G(b, c)
    }

    function Da(a, b, c) {
        a = new a.constructor(b);
        c && (a.i = B);
        a.j = B;
        return a
    }

    function G(a, b, c, d) {
        d ? ? (d = !!(34 & b));
        a = ta(a, b, Ba, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        a[w] = b;
        return a
    }

    function Ea(a, b) {
        b === void 0 && (b = a[w] | 0);
        b & 32 && !(b & 4096) && (a[w] = b | 4096)
    }

    function Ca(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (b[w] = c | 2, a.i = B, !0) : !1
    };

    function H(a, b) {
        a = Fa(a.g, b);
        if (a !== null) return a
    }

    function Fa(a, b, c) {
        if (b === -1) return null;
        var d = b + -1,
            e = a.length - 1;
        if (!(e < 0)) {
            if (d >= e) {
                var f = a[e];
                if (f != null && typeof f === "object" && f.constructor === Object) {
                    e = f[b];
                    var g = !0
                } else if (d === e) e = f;
                else return
            } else e = a[d];
            if (c && e != null) {
                c = c(e);
                if (c == null) return c;
                if (!Object.is(c, e)) return g ? f[b] = c : a[d] = c, c
            }
            return e
        }
    }

    function Ga(a) {
        a = a.g;
        return Ha(a, a[w] | 0) !== void 0
    }

    function Ha(a, b) {
        var c = Ia,
            d = !1,
            e = Fa(a, 1, f => {
                if (f != null && f[t] === x) var g = f;
                else if (Array.isArray(f)) {
                    g = f[w] | 0;
                    let h;
                    h = g | b & 32;
                    h |= b & 2;
                    h !== g && (f[w] = h);
                    g = new c(f)
                } else g = void 0;
                d = g !== f && g != null;
                return g
            });
        if (e != null) return d && !A(e) && Ea(a, b), e
    }

    function Ja(a) {
        var b = a.g,
            c = b[w] | 0,
            d = Ha(b, c);
        if (d == null) return d;
        c = b[w] | 0;
        if (!A(a, c)) {
            var e = d;
            var f = e.g,
                g = f[w] | 0;
            e = A(e, g) ? Ca(e, f, g) ? Da(e, f, !0) : new e.constructor(G(f, g, !1)) : e;
            if (e !== d) {
                a.i === B ? (d = a.g, d = G(d, d[w] | 0), d[w] |= 2048, a.g = d, a.i = void 0, a.j = void 0, d = !0) : d = !1;
                d && (b = a.g, c = b[w] | 0);
                d = e;
                a: {
                    a = b;e = d;f = a.length - 1;
                    if (f >= 0 && 0 >= f && (g = a[f], g != null && typeof g === "object" && g.constructor === Object)) {
                        g[1] = e;
                        break a
                    }
                    0 <= f ? a[0] = e : e !== void 0 && (f = (c ? ? (c = a[w] | 0)) >> 14 & 1023 || 536870912, 1 >= f ? e != null && (a[f + -1] = {
                            [1]: e
                        }) : a[0] =
                        e)
                }
                Ea(b, c)
            }
        }
        return d
    }

    function I(a, b) {
        a = H(a, b);
        return a == null || typeof a === "string" ? a : void 0
    }

    function J(a, b) {
        a = H(a, b);
        return (a == null || typeof a === "boolean" ? a : typeof a === "number" ? !!a : void 0) ? ? !1
    };
    var Ka = class {
        constructor(a) {
            this.g = za(a, void 0, void 0, 2048)
        }
        toJSON() {
            return ya(this)
        }
    };
    Ka.prototype[t] = x;
    var Ia = class extends Ka {};
    var La = function(a) {
        return b => {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b[w] |= 32;
                b = new a(b)
            }
            return b
        }
    }(class extends Ka {});

    function Ma(a, b) {
        if (a)
            for (let c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function Na(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    var Oa = globalThis.trustedTypes,
        Pa;

    function Qa() {
        var a = null;
        if (!Oa) return a;
        try {
            let b = c => c;
            a = Oa.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (b) {}
        return a
    };
    var Ra = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function Sa(a = document) {
        a = a.querySelector ? .("script[nonce]");
        return a == null ? "" : a.nonce || a.getAttribute("nonce") || ""
    };

    function Ta(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    };

    function K(a) {
        var b = document;
        return typeof a === "string" ? b.getElementById(a) : a
    }

    function Ua(a) {
        var b = document;
        if (b.getElementsByClassName) a = b.getElementsByClassName(a)[0];
        else {
            b = document;
            var c;
            a ? c = b.querySelector(a ? "." + a : "") : c = (a ? b.querySelectorAll(a ? "." + a : "") : b.getElementsByTagName("*"))[0] || null;
            a = c
        }
        return a || null
    }

    function Va(a) {
        a && a.parentNode && a.parentNode.removeChild(a)
    };
    var Wa = {
            passive: !0
        },
        Xa = Na(() => {
            var a = !1;
            try {
                let b = Object.defineProperty({}, "passive", {
                    get() {
                        a = !0
                    }
                });
                k.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function Ya(a) {
        return a ? a.passive && Xa() ? a : a.capture || !1 : !1
    }

    function L(a, b, c, d) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, Ya(d))
    }

    function M(a) {
        a.preventDefault ? a.preventDefault() : a.returnValue = !1
    };

    function Za(a, b, c = null, d = !1) {
        $a(a, b, c, d)
    }

    function $a(a, b, c, d) {
        a.google_image_requests || (a.google_image_requests = []);
        var e = Ta("IMG", a.document);
        if (c || d) {
            let f = g => {
                c && c(g);
                if (d) {
                    g = a.google_image_requests;
                    let h = Array.prototype.indexOf.call(g, e, void 0);
                    h >= 0 && Array.prototype.splice.call(g, h, 1)
                }
                typeof e.removeEventListener === "function" && e.removeEventListener("load", f, Ya());
                typeof e.removeEventListener === "function" && e.removeEventListener("error", f, Ya())
            };
            L(e, "load", f);
            L(e, "error", f)
        }
        e.src = b;
        a.google_image_requests.push(e)
    };
    var ab = 0;

    function bb(a) {
        return (a = cb(a, document.currentScript)) && a.getAttribute("data-jc-version") || "unknown"
    }

    function cb(a, b = null) {
        return b && b.getAttribute("data-jc") === String(a) ? b : document.querySelector(`[data-jc="${a}"]`)
    }

    function hb() {
        if (!(Math.random() > .01)) {
            var a = cb(60, document.currentScript);
            a = `https://${a&&a.getAttribute("data-jc-rcd")==="true"?"pagead2.googlesyndication-cn.com":"pagead2.googlesyndication.com"}/pagead/gen_204?id=jca&jc=60&version=${bb(60)}&sample=0.01`;
            var b = window,
                c;
            if (c = b.navigator) c = b.navigator.userAgent, c = /Chrome/.test(c) && !/Edge/.test(c) ? !0 : !1;
            c && typeof b.navigator.sendBeacon === "function" ? b.navigator.sendBeacon(a) : Za(b, a, void 0, !1)
        }
    };
    var ib = document,
        N = window;

    function jb(a) {
        return typeof a.className == "string" ? a.className : a.getAttribute && a.getAttribute("class") || ""
    }

    function kb(a, b) {
        a.classList ? b = a.classList.contains(b) : (a = a.classList ? a.classList : jb(a).match(/\S+/g) || [], b = Array.prototype.indexOf.call(a, b, void 0) >= 0);
        return b
    }

    function O(a, b) {
        if (a.classList) a.classList.add(b);
        else if (!kb(a, b)) {
            let c = jb(a);
            b = c + (c.length > 0 ? " " + b : b);
            typeof a.className == "string" ? a.className = b : a.setAttribute && a.setAttribute("class", b)
        }
    };
    var lb = class {
        constructor(a) {
            this.serializedAttributionData = ya(a);
            var b = a.g,
                c = b[w] | 0;
            this.g = Ca(a, b, c) ? Da(a, b, !0) : new a.constructor(G(b, c, !1));
            if (a = Ga(this.g)) a = Ja(this.g), a = !!J(a, 33);
            this.isMutableImpression = a;
            I(this.g, 30);
            this.T = !!J(this.g, 11);
            this.hasUserFeedbackData = !!this.g && Ga(this.g);
            this.L = !!J(this.g, 4);
            this.O = !!J(this.g, 6);
            this.K = !!J(this.g, 13);
            E(H(this.g, 8));
            this.creativeIndexSuffix = (E(H(this.g, 8)) ? ? 0) > 1 ? (E(H(this.g, 7)) ? ? 0).toString() : "";
            I(this.g, 34) != null && (this.creativeIndexSuffix = (I(this.g,
                34) ? ? "") + "_" + this.creativeIndexSuffix);
            this.U = !!J(this.g, 17);
            this.R = !!J(this.g, 18);
            this.J = !!J(this.g, 14);
            this.F = !!J(this.g, 15);
            this.V = !!J(this.g, 31);
            this.P = J(this.g, 9) == 1;
            this.openAttributionInline = J(this.g, 10) == 1;
            this.isMobileDevice = !!J(this.g, 12);
            this.B = null;
            this.N = (a = ib.querySelector("[data-slide]")) ? a.getAttribute("data-slide") === "true" : !1;
            (this.H = (E(H(this.g, 8)) ? ? 0) > 1) && N.goog_multislot_cache === void 0 && (N.goog_multislot_cache = {});
            this.H && !this.N ? (a = N.goog_multislot_cache.hd, a === void 0 && (a = !1,
                (b = ib.querySelector("[data-dim]")) ? (b = b.getBoundingClientRect(), b.right - b.left >= 150 && b.bottom - b.top >= 150 ? a = !1 : (c = document.body.getBoundingClientRect(), (Math.abs(c.left - b.left) <= 1 && Math.abs(c.right - b.right) <= 1 ? b.bottom - b.top : b.right - b.left) < 150 && (a = !0))) : a = !1, window.goog_multislot_cache.hd = a)) : a = !1;
            this.G = a;
            this.v = K("abgcp" + this.creativeIndexSuffix);
            this.C = K("abgc" + this.creativeIndexSuffix);
            this.i = K("abgs" + this.creativeIndexSuffix);
            K("abgl" + this.creativeIndexSuffix);
            this.u = K("abgb" + this.creativeIndexSuffix);
            this.D = K("abgac" + this.creativeIndexSuffix);
            K("mute_panel" + this.creativeIndexSuffix);
            this.A = Ua("goog_delegate_attribution" + this.creativeIndexSuffix);
            this.isDelegateAttributionActive = !!this.A && !!this.J && !Ua("goog_delegate_disabled") && !this.F;
            if (this.i) a: for (a = this.i, b = a.childNodes, c = 0; c < b.length; c++) {
                let d = b.item(c);
                if (typeof d.tagName != "undefined" && d.tagName.toUpperCase() == "A") {
                    a = d;
                    break a
                }
            } else a = null;
            this.m = a;
            this.l = this.isDelegateAttributionActive ? this.A : K("cbb" + this.creativeIndexSuffix);
            this.M =
                this.G ? this.creativeIndexSuffix === "0" : !0;
            this.enableDelegateDismissableMenu = !!this.l && kb(this.l, "goog_dismissable_menu");
            this.o = null;
            this.I = 0;
            this.j = this.isDelegateAttributionActive ? this.A : this.O && this.v ? this.v : this.C;
            this.autoExpandOnLoad = !!J(this.g, 19);
            this.adbadgeEnabled = !!J(this.g, 24);
            this.enableNativeJakeUi = !!J(this.g, 27);
            I(this.g, 33)
        }
    };
    var mb = class {
        constructor(a, b, c) {
            if (!a) throw Error("bad conv util ctor args");
            this.i = a;
            this.g = c
        }
    };
    var nb = class {
        constructor(a, b) {
            this.error = a;
            this.meta = {};
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror"
        }
    };

    function ob(a) {
        var b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        if (a.stack) a: {
            a = a.stack;
            var c = b;
            try {
                a.indexOf(c) == -1 && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n");
                break a
            } catch (d) {
                b = c;
                break a
            }
            b = void 0
        }
        return b
    };
    var pb = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)"),
        qb = class {
            constructor(a, b) {
                this.g = a;
                this.i = b
            }
        },
        rb = class {
            constructor(a, b) {
                this.url = a;
                this.g = !!b;
                this.depth = null
            }
        };
    var P = null;

    function sb() {
        var a = k.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function tb() {
        var a = k.performance;
        return a && a.now ? a.now() : null
    };
    var ub = class {
        constructor(a, b) {
            var c = tb() || sb();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    var R = k.performance,
        vb = !!(R && R.mark && R.measure && R.clearMarks),
        S = Na(() => {
            var a;
            if (a = vb) {
                var b;
                a = window;
                if (P === null) {
                    P = "";
                    try {
                        let c = "";
                        try {
                            c = a.top.location.hash
                        } catch (d) {
                            c = a.location.hash
                        }
                        c && (P = (b = c.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (c) {}
                }
                b = P;
                a = !!b.indexOf && b.indexOf("1337") >= 0
            }
            return a
        });

    function wb(a) {
        a && R && S() && (R.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), R.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    };

    function T(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    }

    function xb(a, b, c, d, e) {
        var f = [];
        Ma(a, (g, h) => {
            (g = yb(g, b, c, d, e)) && f.push(`${h}=${g}`)
        });
        return f.join(b)
    }

    function yb(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        na(c) && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                let f = [];
                for (let g = 0; g < a.length; g++) f.push(yb(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(xb(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function zb(a) {
        var b = 1;
        for (let c in a.i) c.length > b && (b = c.length);
        return 3997 - b - a.j.length - 1
    }

    function Ab(a, b, c) {
        b = "https://" + b + c;
        var d = zb(a) - c.length;
        if (d < 0) return "";
        a.g.sort((f, g) => f - g);
        c = null;
        var e = "";
        for (let f = 0; f < a.g.length; f++) {
            let g = a.g[f],
                h = a.i[g];
            for (let l = 0; l < h.length; l++) {
                if (!d) {
                    c = c == null ? g : c;
                    break
                }
                let n = xb(h[l], a.j, ",$");
                if (n) {
                    n = e + n;
                    if (d >= n.length) {
                        d -= n.length;
                        b += n;
                        e = a.j;
                        break
                    }
                    c = c == null ? g : c
                }
            }
        }
        a = "";
        c != null && (a = `${e}trn=${c}`);
        return b + a
    }
    var Bb = class {
        constructor() {
            this.j = "&";
            this.i = {};
            this.l = 0;
            this.g = []
        }
    };
    var Cb = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function Db(a, b, c) {
        try {
            if (a.g && a.g.g) {
                var d = a.g.start(b.toString(), 3);
                var e = c();
                a.g.end(d)
            } else e = c()
        } catch (f) {
            c = !0;
            try {
                wb(d), c = a.m(b, new nb(f, {
                    message: ob(f)
                }), void 0, void 0)
            } catch (g) {
                a.l(217, g)
            }
            if (c) window.console ? .error ? .(f);
            else throw f;
        }
        return e
    }

    function Eb(a, b) {
        var c = U;
        return (...d) => Db(c, a, () => b.apply(void 0, d))
    }
    var Hb = class {
        constructor(a = null) {
            this.pinger = Fb;
            this.g = a;
            this.i = null;
            this.j = !1;
            this.m = this.l
        }
        l(a, b, c, d, e) {
            e = e || "jserror";
            var f = void 0;
            try {
                let C = new Bb;
                var g = C;
                g.g.push(1);
                g.i[1] = T("context", a);
                b.error && b.meta && b.id || (b = new nb(b, {
                    message: ob(b)
                }));
                g = b;
                if (g.msg) {
                    b = C;
                    var h = g.msg.substring(0, 512);
                    b.g.push(2);
                    b.i[2] = T("msg", h)
                }
                var l = g.meta || {};
                h = l;
                if (this.i) try {
                    this.i(h)
                } catch (z) {}
                if (d) try {
                    d(h)
                } catch (z) {}
                d = C;
                l = [l];
                d.g.push(3);
                d.i[3] = l;
                var n;
                if (!(n = u)) {
                    d = k;
                    l = [];
                    let z;
                    h = null;
                    do {
                        var m = d;
                        try {
                            var v;
                            if (v = !!m &&
                                m.location.href != null) b: {
                                try {
                                    ha(m.foo);
                                    v = !0;
                                    break b
                                } catch (y) {}
                                v = !1
                            }
                            var p = v
                        } catch {
                            p = !1
                        }
                        p ? (z = m.location.href, h = m.document && m.document.referrer || null) : (z = h, h = null);
                        l.push(new rb(z || ""));
                        try {
                            d = m.parent
                        } catch (y) {
                            d = null
                        }
                    } while (d && m !== d);
                    for (let y = 0, db = l.length - 1; y <= db; ++y) l[y].depth = db - y;
                    m = k;
                    if (m.location && m.location.ancestorOrigins && m.location.ancestorOrigins.length === l.length - 1)
                        for (p = 1; p < l.length; ++p) {
                            let y = l[p];
                            y.url || (y.url = m.location.ancestorOrigins[p - 1] || "", y.g = !0)
                        }
                    n = l
                }
                var u = n;
                let aa = new rb(k.location.href, !1);
                n = null;
                let wa = u.length - 1;
                for (m = wa; m >= 0; --m) {
                    var D = u[m];
                    !n && pb.test(D.url) && (n = D);
                    if (D.url && !D.g) {
                        aa = D;
                        break
                    }
                }
                D = null;
                let Rb = u.length && u[wa].url;
                aa.depth !== 0 && Rb && (D = u[wa]);
                f = new qb(aa, D);
                if (f.i) {
                    u = C;
                    var F = f.i.url || "";
                    u.g.push(4);
                    u.i[4] = T("top", F)
                }
                var xa = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    let z = f.g.url.match(Cb);
                    var Q = z[1],
                        eb = z[3],
                        fb = z[4];
                    F = "";
                    Q && (F += Q + ":");
                    eb && (F += "//", F += eb, fb && (F += ":" + fb));
                    var gb = F
                } else gb = "";
                Q = C;
                xa = [xa, {
                    url: gb
                }];
                Q.g.push(5);
                Q.i[5] = xa;
                Gb(this.pinger, e, C, this.j, c)
            } catch (C) {
                try {
                    Gb(this.pinger,
                        e, {
                            context: "ecmserr",
                            rctx: a,
                            msg: ob(C),
                            url: f ? .g.url ? ? ""
                        }, this.j, c)
                } catch (aa) {}
            }
            return !0
        }
    };

    function Gb(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof Bb ? f = c : (f = new Bb, Ma(c, (h, l) => {
                var n = f,
                    m = n.l++;
                h = T(l, h);
                n.g.push(m);
                n.i[m] = h
            }));
            let g = Ab(f, a.domain, a.path + b + "&");
            g && Za(k, g)
        } catch (f) {}
    }

    function Ib() {
        var a = Fb,
            b = window.google_srt;
        b >= 0 && b <= 1 && (a.g = b)
    }
    var Jb = class {
        constructor() {
            this.domain = "pagead2.googlesyndication.com";
            this.path = "/pagead/gen_204?id=";
            this.g = Math.random()
        }
    };
    var Fb, U, V = new class {
        constructor(a, b) {
            this.i = [];
            this.j = b || k;
            var c = null;
            b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.i = b.google_js_reporting_queue, c = b.google_measure_js_timing);
            this.g = S() || (c != null ? c : Math.random() < a)
        }
        start(a, b) {
            if (!this.g) return null;
            a = new ub(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            R && S() && R.mark(b);
            return a
        }
        end(a) {
            if (this.g && ma(a.value)) {
                a.duration = (tb() || sb()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                R && S() && R.mark(b);
                !this.g || this.i.length >
                    2048 || this.i.push(a)
            }
        }
    }(1, window);

    function Kb() {
        window.google_measure_js_timing || (V.g = !1, V.i !== V.j.google_js_reporting_queue && (S() && Array.prototype.forEach.call(V.i, wb, void 0), V.i.length = 0))
    }(function(a) {
        Fb = a ? ? new Jb;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        Ib();
        U = new Hb(V);
        U.i = b => {
            var c = ab;
            c !== 0 && (b.jc = String(c), b.shv = bb(c))
        };
        U.j = !0;
        window.document.readyState === "complete" ? Kb() : V.g && L(window, "load", () => {
            Kb()
        })
    })();

    function W(a, b) {
        return Eb(a, b)
    };
    var X = (a, b) => {
        a && Ma(b, (c, d) => {
            a.style[d] = c
        })
    };

    function Lb(a) {
        if (a.g.m && a.g.R) {
            let b = Ja(a.g.g);
            b && I(b, 5) != null && I(b, 6) != null && (a.j = new mb(I(b, 5) ? ? "", I(b, 6) ? ? "", I(b, 19) ? ? ""));
            L(a.g.m, "click", W(452, () => {
                if (!a.l && (a.l = !0, a.j)) {
                    var c = a.j;
                    let d = c.i + "&label=closebutton_whythisad_click";
                    d += "&label_instance=1";
                    c.g && (d += "&cid=" + c.g);
                    Za(window, d)
                }
            }))
        }
    }

    function Mb(a) {
        if (a.g.T) L(a.g.j, "click", W(365, b => {
            var c = N.goog_interstitial_display;
            c && (c(b), b && (b.stopPropagation(), b.preventDefault()))
        }));
        else if (a.g.isMutableImpression && a.g.isMobileDevice) L(a.g.j, "click", () => a.i());
        else if (a.g.isMutableImpression && !a.g.isMobileDevice && (a.g.l && (L(a.g.l, "click", () => a.i()), L(a.g.l, "keydown", b => {
                b.code !== "Enter" && b.code !== "Space" || a.i()
            })), a.g.V && a.g.i && L(a.g.i, "click", () => a.i())), a.g.L) Nb(a);
        else {
            L(a.g.j, "mouseover", W(367, () => Nb(a)));
            L(a.g.j, "mouseout", W(369, () =>
                Ob(a, 500)));
            L(a.g.j, "touchstart", W(368, () => Nb(a)), Wa);
            let b = W(370, () => Ob(a, 4E3));
            L(a.g.j, "mouseup", b);
            L(a.g.j, "touchend", b);
            L(a.g.j, "touchcancel", b);
            a.g.m && L(a.g.m, "click", W(371, c => a.preventDefault(c)))
        }
    }

    function Nb(a) {
        window.clearTimeout(a.g.o);
        a.g.o = null;
        a.g.i && a.g.i.style.display == "block" || (a.g.I = Date.now(), a.g.u && a.g.i && (a.g.u.style.display = "none", a.g.i.style.display = "block"))
    }

    function Ob(a, b) {
        window.clearTimeout(a.g.o);
        a.g.o = window.setTimeout(() => Pb(a), b)
    }

    function Qb(a) {
        var b = a.g.D;
        b !== void 0 && (b.style.display = "block", a.g.enableNativeJakeUi && window.requestAnimationFrame(() => {
            O(b, "abgacfo")
        }))
    }

    function Pb(a) {
        window.clearTimeout(a.g.o);
        a.g.o = null;
        a.g.u && a.g.i && (a.g.u.style.display = "block", a.g.i.style.display = "none")
    }
    class Sb {
        constructor(a, b) {
            this.g = a;
            this.i = b;
            this.g.U || (this.l = !1, this.j = null, !this.g.G || this.g.adbadgeEnabled || this.g.M ? Lb(this) : (a = {
                display: "none"
            }, b = {
                width: "15px",
                height: "15px"
            }, this.g.isMobileDevice ? (X(this.g.u, a), X(this.g.i, a), X(this.g.v, b), X(this.g.C, b)) : X(this.g.C, a)), Mb(this), this.g.enableNativeJakeUi && O(this.g.D, "abgnac"), this.g.isDelegateAttributionActive ? (O(document.body, "goog_delegate_active"), O(document.body, "jaa")) : (!this.g.isMutableImpression && this.g.l && Va(this.g.l), setTimeout(() => {
                O(document.body,
                    "jar")
            }, this.g.K ? 750 : 100)), this.g.F && O(document.body, "goog_delegate_disabled"), this.g.autoExpandOnLoad && N.addEventListener("load", () => this.i()))
        }
        preventDefault(a) {
            if (this.g.i && this.g.i.style.display == "block" && Date.now() - this.g.I < 500) M(a);
            else if (this.g.openAttributionInline) {
                var b = this.g.m.getAttribute("href");
                window.adSlot ? window.adSlot.openAttribution(b) && M(a) : window.openAttribution && (window.openAttribution(b), M(a))
            } else this.g.P && (b = this.g.m.getAttribute("href"), window.adSlot ? window.adSlot.openSystemBrowser(b) &&
                M(a) : window.openSystemBrowser && (window.openSystemBrowser(b), M(a)))
        }
    };

    function Tb(a) {
        if (!a.g && (a.g = !0, N.goog_delegate_deferred_token = void 0, a.i)) {
            var b = a.j;
            a = La(JSON.stringify(a.i));
            if (!a) throw Error("bad attrdata");
            a = new lb(a);
            new b(a)
        }
    }
    class Ub {
        constructor(a) {
            var b = Vb;
            if (!b) throw Error("bad ctor");
            this.j = b;
            this.i = a;
            this.g = !1;
            Ua("goog_delegate_deferred") ? N.goog_delegate_deferred_token !== void 0 ? Tb(this) : (a = () => {
                Tb(this)
            }, N.goog_delegate_deferred_token = a, setTimeout(a, 5E3)) : Tb(this)
        }
    };
    var Wb = (a = []) => {
        k.google_logging_queue || (k.google_logging_queue = []);
        k.google_logging_queue.push([11, a])
    };
    class Xb {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.reject = b
            })
        }
    };

    function Yb() {
        var {
            promise: a,
            resolve: b
        } = new Xb;
        return {
            promise: a,
            resolve: b
        }
    };

    function Zb(a, b = () => {}) {
        a.google_llp || (a.google_llp = {});
        a = a.google_llp;
        var c = a[5];
        if (c) return c;
        c = Yb();
        a[5] = c;
        b();
        return c
    }

    function $b(a, b) {
        return Zb(a, () => {
            var c = a.document,
                d = Ta("SCRIPT", c);
            if (b instanceof Ra) var e = b.g;
            else throw Error("");
            d.src = e;
            (e = Sa(d.ownerDocument)) && d.setAttribute("nonce", e);
            (c = c.getElementsByTagName("script")[0]) && c.parentNode && c.parentNode.insertBefore(d, c)
        }).promise
    };

    function ac(a) {
        a = a === null ? "null" : a === void 0 ? "undefined" : a;
        var b;
        Pa === void 0 && (Pa = Qa());
        a = (b = Pa) ? b.createScriptURL(a) : a;
        return new Ra(a)
    };

    function bc(a) {
        Wb([a]);
        new Ub(a)
    }

    function cc(a) {
        a.g.B ? a.g.B.expandAttributionCard() : (Db(U, 373, () => {
            Pb(a.i);
            Qb(a.i)
        }), $b(window, ac(`https://pagead2.googlesyndication.com${"/pagead/js/"+(I(a.g.g,33)??"")+"/abg_survey.js"}`)).then(b => {
            b.createAttributionCard(a.g);
            a.g.B = b;
            b.expandAttributionCard()
        }), hb())
    }
    var Vb = class {
        constructor(a) {
            this.g = a;
            this.i = new Sb(this.g, W(359, () => cc(this)))
        }
    };
    ab = 60;
    var dc = cb(60, document.currentScript);
    if (dc == null) throw Error("JSC not found 60");
    var ec = {},
        fc = dc.attributes;
    for (let a = fc.length - 1; a >= 0; a--) {
        let b = fc[a].name;
        b.indexOf("data-jcp-") === 0 && (ec[b.substring(9)] = fc[a].value)
    }
    if (ec["attribution-data"]) bc(JSON.parse(ec["attribution-data"]));
    else
        for (var hc = ["buildAttribution"], Y = k, Z; hc.length && (Z = hc.shift());) hc.length || bc === void 0 ? Y[Z] && Y[Z] !== Object.prototype[Z] ? Y = Y[Z] : Y = Y[Z] = {} : Y[Z] = bc;
}).call(this);
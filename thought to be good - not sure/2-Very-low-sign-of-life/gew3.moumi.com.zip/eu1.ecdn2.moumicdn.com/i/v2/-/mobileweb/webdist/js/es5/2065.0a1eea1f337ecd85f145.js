"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [2065], {
        92065: function(_, O, T) {
            T.r(O), T.d(O, {
                TOKEN_A11Y_FOCUS_RING_FIELD_COLOR: function() {
                    return E
                },
                TOKEN_A11Y_FOCUS_RING_FIELD_OFFSET: function() {
                    return n
                },
                TOKEN_A11Y_FOCUS_RING_FIELD_WIDTH: function() {
                    return N
                },
                TOKEN_A11Y_FOCUS_RING_INNER_COLOR: function() {
                    return S
                },
                TOKEN_A11Y_FOCUS_RING_INNER_OFFSET: function() {
                    return C
                },
                TOKEN_A11Y_FOCUS_RING_INNER_WIDTH: function() {
                    return A
                },
                TOKEN_A11Y_FOCUS_RING_OUTER_COLOR: function() {
                    return I
                },
                TOKEN_A11Y_FOCUS_RING_OUTER_OFFSET: function() {
                    return R
                },
                TOKEN_A11Y_FOCUS_RING_OUTER_WIDTH: function() {
                    return t
                },
                TOKEN_A11Y_MIN_TARGET_SIZE: function() {
                    return u
                },
                TOKEN_ACTIONSHEET_FOOTER_PADDING_BOTTOM: function() {
                    return r
                },
                TOKEN_ACTIONSHEET_FOOTER_PADDING_HORIZONTAL: function() {
                    return M
                },
                TOKEN_ACTIONSHEET_GRAVITY: function() {
                    return L
                },
                TOKEN_ACTIONSHEET_HEADER_BACKGROUND_BASE: function() {
                    return K
                },
                TOKEN_ACTIONSHEET_HEADER_BACKGROUND_PRIMARY: function() {
                    return D
                },
                TOKEN_ACTIONSHEET_HEADER_EXTRA_MARGIN_TOP: function() {
                    return e
                },
                TOKEN_ACTIONSHEET_HEADER_MEDIA_BADGE_SIZE: function() {
                    return i
                },
                TOKEN_ACTIONSHEET_HEADER_MEDIA_MARGIN_BOTTOM: function() {
                    return o
                },
                TOKEN_ACTIONSHEET_HEADER_PADDING_HORIZONTAL: function() {
                    return c
                },
                TOKEN_ACTIONSHEET_HEADER_PADDING_TOP: function() {
                    return F
                },
                TOKEN_ACTIONSHEET_HEADER_PADDING_VERTICAL: function() {
                    return f
                },
                TOKEN_ACTIONSHEET_HEADER_TEXT_MARGIN_TOP: function() {
                    return G
                },
                TOKEN_ACTIONSHEET_ITEM_BORDER_COLOR: function() {
                    return P
                },
                TOKEN_ACTIONSHEET_ITEM_BORDER_WIDTH: function() {
                    return B
                },
                TOKEN_ACTIONSHEET_ITEM_COLOR_DESTRUCTIVE: function() {
                    return U
                },
                TOKEN_ACTIONSHEET_ITEM_COLOR_GENERIC: function() {
                    return H
                },
                TOKEN_ACTIONSHEET_ITEM_HEIGHT: function() {
                    return p
                },
                TOKEN_ACTIONSHEET_ITEM_PADDING_HORIZONTAL: function() {
                    return x
                },
                TOKEN_ACTIONSHEET_ITEM_PADDING_VERTICAL: function() {
                    return Y
                },
                TOKEN_ACTIONSHEET_LIST_MARGIN_BOTTOM: function() {
                    return V
                },
                TOKEN_ACTIONSHEET_LIST_MARGIN_TOP: function() {
                    return W
                },
                TOKEN_ACTIONSHEET_SPACING_HEADER_FOOTER: function() {
                    return Z
                },
                TOKEN_ACTIONSHEET_SPACING_LIST_FOOTER: function() {
                    return X
                },
                TOKEN_ACTION_CELL_BASE_BACKGROUND_COLOR: function() {
                    return s
                },
                TOKEN_ACTION_CELL_BASE_TEXT_COLOR: function() {
                    return l
                },
                TOKEN_ACTION_CELL_BORDER_RADIUS: function() {
                    return m
                },
                TOKEN_ACTION_CELL_EXTRA_HEIGHT: function() {
                    return a
                },
                TOKEN_ACTION_CELL_EXTRA_MARGIN_LEFT: function() {
                    return b
                },
                TOKEN_ACTION_CELL_EXTRA_MIN_WIDTH: function() {
                    return d
                },
                TOKEN_ACTION_CELL_MAX_WIDTH: function() {
                    return y
                },
                TOKEN_ACTION_CELL_MEDIA_MARGIN_RIGHT: function() {
                    return Q
                },
                TOKEN_ACTION_CELL_MEDIA_SIZE: function() {
                    return k
                },
                TOKEN_ACTION_CELL_PADDING_HORIZONTAL: function() {
                    return J
                },
                TOKEN_ACTION_CELL_PADDING_VERTICAL: function() {
                    return h
                },
                TOKEN_ACTION_CELL_SELECTED_BACKGROUND_COLOR: function() {
                    return z
                },
                TOKEN_ACTION_CELL_SELECTED_TEXT_COLOR: function() {
                    return w
                },
                TOKEN_ACTION_ROW_EXTRA_COLOR: function() {
                    return g
                },
                TOKEN_ACTION_ROW_EXTRA_MARGIN_LEFT: function() {
                    return v
                },
                TOKEN_ACTION_ROW_EXTRA_MEDIUM_HEIGHT: function() {
                    return j
                },
                TOKEN_ACTION_ROW_EXTRA_MEDIUM_MIN_WIDTH: function() {
                    return q
                },
                TOKEN_ACTION_ROW_EXTRA_SMALL_HEIGHT: function() {
                    return $
                },
                TOKEN_ACTION_ROW_EXTRA_SMALL_MIN_WIDTH: function() {
                    return __
                },
                TOKEN_ACTION_ROW_HINT_COLOR: function() {
                    return O_
                },
                TOKEN_ACTION_ROW_HINT_MARGIN_TOP: function() {
                    return T_
                },
                TOKEN_ACTION_ROW_MEDIA_COLOR: function() {
                    return E_
                },
                TOKEN_ACTION_ROW_MEDIA_MARGIN_RIGHT: function() {
                    return n_
                },
                TOKEN_ACTION_ROW_MEDIA_SIZE: function() {
                    return N_
                },
                TOKEN_ACTION_ROW_PADDING_HORIZONTAL: function() {
                    return S_
                },
                TOKEN_ACTION_ROW_PADDING_VERTICAL: function() {
                    return C_
                },
                TOKEN_ACTION_ROW_STATUS_PRESSED_BACKGROUND_COLOR: function() {
                    return A_
                },
                TOKEN_ACTION_ROW_STATUS_PRESSED_BACKGROUND_OPACITY: function() {
                    return I_
                },
                TOKEN_ACTION_ROW_TITLE_COLOR: function() {
                    return R_
                },
                TOKEN_ACTION_ROW_TITLE_COLOR_BASE: function() {
                    return t_
                },
                TOKEN_ACTION_ROW_TITLE_COLOR_DANGER: function() {
                    return u_
                },
                TOKEN_ACTION_ROW_VALUE_ICON_COLOR: function() {
                    return r_
                },
                TOKEN_ACTION_ROW_VALUE_ICON_MARGIN_RIGHT: function() {
                    return M_
                },
                TOKEN_ACTION_ROW_VALUE_ICON_SIZE: function() {
                    return L_
                },
                TOKEN_ACTION_ROW_VALUE_MARGIN_LEFT: function() {
                    return K_
                },
                TOKEN_ACTION_ROW_VALUE_TEXT_COLOR: function() {
                    return D_
                },
                TOKEN_ADAPTOR_ACTION_COLOR: function() {
                    return e_
                },
                TOKEN_ADAPTOR_CHEVRON_COLOR: function() {
                    return i_
                },
                TOKEN_ADAPTOR_CHEVRON_SIZE: function() {
                    return o_
                },
                TOKEN_ADAPTOR_MESSAGE_COLOR: function() {
                    return c_
                },
                TOKEN_ADAPTOR_MESSAGE_MARGIN_TOP: function() {
                    return F_
                },
                TOKEN_ADAPTOR_TITLE_COLOR: function() {
                    return f_
                },
                TOKEN_AVATAR_BACKGROUND_COLOR: function() {
                    return G_
                },
                TOKEN_AVATAR_PLACEHOLDER_COLOR_DEFAULT: function() {
                    return P_
                },
                TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_1: function() {
                    return B_
                },
                TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_2: function() {
                    return U_
                },
                TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_3: function() {
                    return H_
                },
                TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_4: function() {
                    return p_
                },
                TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_5: function() {
                    return x_
                },
                TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_6: function() {
                    return Y_
                },
                TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_7: function() {
                    return V_
                },
                TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_8: function() {
                    return W_
                },
                TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_9: function() {
                    return Z_
                },
                TOKEN_BADGE_LARGE_BORDER_RADIUS: function() {
                    return X_
                },
                TOKEN_BADGE_LARGE_END_ICON_SIZE: function() {
                    return s_
                },
                TOKEN_BADGE_LARGE_HEIGHT: function() {
                    return l_
                },
                TOKEN_BADGE_LARGE_MEDIA_SIZE: function() {
                    return m_
                },
                TOKEN_BADGE_LARGE_PADDING_HORIZONTAL: function() {
                    return a_
                },
                TOKEN_BADGE_LARGE_SPACING_MEDIA_TEXT: function() {
                    return b_
                },
                TOKEN_BADGE_LARGE_SPACING_TEXT_ICON: function() {
                    return d_
                },
                TOKEN_BADGE_MEDIUM_BORDER_RADIUS: function() {
                    return y_
                },
                TOKEN_BADGE_MEDIUM_END_ICON_SIZE: function() {
                    return Q_
                },
                TOKEN_BADGE_MEDIUM_HEIGHT: function() {
                    return k_
                },
                TOKEN_BADGE_MEDIUM_MEDIA_SIZE: function() {
                    return J_
                },
                TOKEN_BADGE_MEDIUM_PADDING_HORIZONTAL: function() {
                    return h_
                },
                TOKEN_BADGE_MEDIUM_SPACING_MEDIA_TEXT: function() {
                    return z_
                },
                TOKEN_BADGE_MEDIUM_SPACING_TEXT_ICON: function() {
                    return w_
                },
                TOKEN_BADGE_SMALL_BORDER_RADIUS: function() {
                    return g_
                },
                TOKEN_BADGE_SMALL_END_ICON_SIZE: function() {
                    return v_
                },
                TOKEN_BADGE_SMALL_HEIGHT: function() {
                    return j_
                },
                TOKEN_BADGE_SMALL_MEDIA_SIZE: function() {
                    return q_
                },
                TOKEN_BADGE_SMALL_PADDING_HORIZONTAL: function() {
                    return $_
                },
                TOKEN_BADGE_SMALL_SPACING_MEDIA_TEXT: function() {
                    return _O
                },
                TOKEN_BADGE_SMALL_SPACING_TEXT_ICON: function() {
                    return OO
                },
                TOKEN_BORDER_RADIUS_LG: function() {
                    return TO
                },
                TOKEN_BORDER_RADIUS_MD: function() {
                    return EO
                },
                TOKEN_BORDER_RADIUS_SM: function() {
                    return nO
                },
                TOKEN_BORDER_RADIUS_XLG: function() {
                    return NO
                },
                TOKEN_BORDER_RADIUS_XXLG: function() {
                    return SO
                },
                TOKEN_BRICKGROUP_CASCADE_MD_OVERLAP: function() {
                    return CO
                },
                TOKEN_BRICKGROUP_CASCADE_SM_OVERLAP: function() {
                    return AO
                },
                TOKEN_BRICKGROUP_CASCADE_XXSM_OVERLAP: function() {
                    return IO
                },
                TOKEN_BRICKGROUP_DOUBLE_MM_OVERLAP: function() {
                    return RO
                },
                TOKEN_BRICKGROUP_TRIPLE_MMM_OVERLAP: function() {
                    return tO
                },
                TOKEN_BRICKGROUP_TRIPLE_MXLM_OVERLAP: function() {
                    return uO
                },
                TOKEN_BRICKGROUP_TRIPLE_SMS_OVERLAP: function() {
                    return rO
                },
                TOKEN_BRICK_BADGE_SIZE_LG: function() {
                    return MO
                },
                TOKEN_BRICK_BADGE_SIZE_MD: function() {
                    return LO
                },
                TOKEN_BRICK_BADGE_SIZE_RATIO: function() {
                    return KO
                },
                TOKEN_BRICK_BADGE_SIZE_SM: function() {
                    return DO
                },
                TOKEN_BRICK_BORDER_RADIUS_CIRCLE: function() {
                    return eO
                },
                TOKEN_BRICK_BORDER_RADIUS_SQUARED: function() {
                    return iO
                },
                TOKEN_BRICK_BORDER_RADIUS_SQUARED_FIXED: function() {
                    return oO
                },
                TOKEN_BRICK_HALO_COLOR_LIKED_YOU: function() {
                    return cO
                },
                TOKEN_BRICK_HALO_COLOR_PRIMARY: function() {
                    return FO
                },
                TOKEN_BRICK_HALO_GAP: function() {
                    return fO
                },
                TOKEN_BRICK_HALO_WIDTH: function() {
                    return GO
                },
                TOKEN_BRICK_MD_BADGE_SIZE: function() {
                    return PO
                },
                TOKEN_BRICK_OVERLAY_DARK_BACKGROUND_COLOR: function() {
                    return BO
                },
                TOKEN_BRICK_OVERLAY_DARK_BACKGROUND_OPACITY: function() {
                    return UO
                },
                TOKEN_BRICK_OVERLAY_PRIMARY_BACKGROUND_COLOR: function() {
                    return HO
                },
                TOKEN_BRICK_OVERLAY_PRIMARY_BACKGROUND_OPACITY: function() {
                    return pO
                },
                TOKEN_BRICK_SIZE_LG: function() {
                    return xO
                },
                TOKEN_BRICK_SIZE_MD: function() {
                    return YO
                },
                TOKEN_BRICK_SIZE_SM: function() {
                    return VO
                },
                TOKEN_BRICK_SIZE_XLG: function() {
                    return WO
                },
                TOKEN_BRICK_SIZE_XXSM: function() {
                    return ZO
                },
                TOKEN_BRICK_SM_BADGE_SIZE: function() {
                    return XO
                },
                TOKEN_BRICK_XXSM_BADGE_SIZE: function() {
                    return sO
                },
                TOKEN_BUTTON_MAX_WIDTH: function() {
                    return lO
                },
                TOKEN_BUTTON_MEDIUM_BORDER_RADIUS: function() {
                    return mO
                },
                TOKEN_BUTTON_MEDIUM_HEIGHT: function() {
                    return aO
                },
                TOKEN_BUTTON_MEDIUM_ICON_SIZE: function() {
                    return bO
                },
                TOKEN_BUTTON_MEDIUM_LOADER_SIZE: function() {
                    return dO
                },
                TOKEN_BUTTON_MEDIUM_PADDING_HORIZONTAL: function() {
                    return yO
                },
                TOKEN_BUTTON_MEDIUM_PADDING_VERTICAL: function() {
                    return QO
                },
                TOKEN_BUTTON_MEDIUM_SPACING_ICON_TEXT: function() {
                    return kO
                },
                TOKEN_BUTTON_SMALL_BORDER_RADIUS: function() {
                    return JO
                },
                TOKEN_BUTTON_SMALL_HEIGHT: function() {
                    return hO
                },
                TOKEN_BUTTON_SMALL_ICON_SIZE: function() {
                    return zO
                },
                TOKEN_BUTTON_SMALL_LOADER_SIZE: function() {
                    return wO
                },
                TOKEN_BUTTON_SMALL_PADDING_HORIZONTAL: function() {
                    return gO
                },
                TOKEN_BUTTON_SMALL_PADDING_VERTICAL: function() {
                    return vO
                },
                TOKEN_BUTTON_SMALL_SPACING_ICON_TEXT: function() {
                    return jO
                },
                TOKEN_BUTTON_STATUS_DISABLED_OPACITY: function() {
                    return qO
                },
                TOKEN_BUTTON_STATUS_FOCUSED_OVERLAY_DARK_BACKGROUND_COLOR: function() {
                    return $O
                },
                TOKEN_BUTTON_STATUS_FOCUSED_OVERLAY_DARK_OPACITY: function() {
                    return _T
                },
                TOKEN_BUTTON_STATUS_PRESSED_OVERLAY_DARK_BACKGROUND_COLOR: function() {
                    return OT
                },
                TOKEN_BUTTON_STATUS_PRESSED_OVERLAY_DARK_OPACITY: function() {
                    return TT
                },
                TOKEN_BUTTON_VARIANT_STROKE_BORDER_WIDTH: function() {
                    return ET
                },
                TOKEN_CHAT_BUBBLE_BASE_BACKGROUND_COLOR: function() {
                    return nT
                },
                TOKEN_CHAT_BUBBLE_FIX_WIDTH: function() {
                    return NT
                },
                TOKEN_CHAT_BUBBLE_INSET_HORIZONTAL: function() {
                    return ST
                },
                TOKEN_CHAT_BUBBLE_INSET_VERTICAL: function() {
                    return CT
                },
                TOKEN_CHAT_BUBBLE_IN_BACKGROUND_COLOR: function() {
                    return AT
                },
                TOKEN_CHAT_BUBBLE_IN_TEXT_COLOR: function() {
                    return IT
                },
                TOKEN_CHAT_BUBBLE_OUT_BACKGROUND_COLOR: function() {
                    return RT
                },
                TOKEN_CHAT_BUBBLE_OUT_TEXT_COLOR: function() {
                    return tT
                },
                TOKEN_CHAT_BUBBLE_RADIUS: function() {
                    return uT
                },
                TOKEN_CHAT_BUBBLE_RADIUS_SMALL: function() {
                    return rT
                },
                TOKEN_CHAT_BUBBLE_REL_WIDTH: function() {
                    return MT
                },
                TOKEN_CHAT_COMPOSER_ACTION_ACTIVE_COLOR: function() {
                    return LT
                },
                TOKEN_CHAT_COMPOSER_ACTION_BASE_COLOR: function() {
                    return KT
                },
                TOKEN_CHAT_COMPOSER_ACTION_DISABLED_COLOR: function() {
                    return DT
                },
                TOKEN_CHAT_COMPOSER_FRAME_HEIGHT: function() {
                    return eT
                },
                TOKEN_CHAT_COMPOSER_FRAME_ITEM_GAP: function() {
                    return iT
                },
                TOKEN_CHAT_COMPOSER_FRAME_ITEM_SIZE: function() {
                    return oT
                },
                TOKEN_CHAT_COMPOSER_MINI_ACTION_ICON_SIZE: function() {
                    return cT
                },
                TOKEN_CHAT_COMPOSER_MINI_ACTION_MARGIN_LEFT: function() {
                    return FT
                },
                TOKEN_CHAT_COMPOSER_MINI_INPUT_FIELD_HEIGHT: function() {
                    return fT
                },
                TOKEN_CHAT_COMPOSER_MINI_PADDING_START: function() {
                    return GT
                },
                TOKEN_CHAT_DATE_MARGIN_VERTICAL: function() {
                    return PT
                },
                TOKEN_CHAT_DATE_PILL_ELEVATED_BACKGROUND_COLOR: function() {
                    return BT
                },
                TOKEN_CHAT_DATE_PILL_ELEVATED_OUTER_BORDER_OPACITY: function() {
                    return UT
                },
                TOKEN_CHAT_DATE_PILL_ELEVATED_OUTER_BORDER_SIZE: function() {
                    return HT
                },
                TOKEN_CHAT_DATE_PILL_ELEVATED_RADIUS: function() {
                    return pT
                },
                TOKEN_CHAT_DATE_PILL_ELEVATED_SHADOW_BLUR_RADIUS: function() {
                    return xT
                },
                TOKEN_CHAT_DATE_PILL_ELEVATED_SHADOW_COLOR: function() {
                    return YT
                },
                TOKEN_CHAT_DATE_PILL_ELEVATED_SHADOW_OPACITY: function() {
                    return VT
                },
                TOKEN_CHAT_DATE_PILL_ELEVATED_SHADOW_VERTICAL_OFFSET: function() {
                    return WT
                },
                TOKEN_CHAT_DATE_PILL_HEIGHT: function() {
                    return ZT
                },
                TOKEN_CHAT_DATE_PILL_PADDING_HORIZONTAL: function() {
                    return XT
                },
                TOKEN_CHAT_DATE_PILL_TEXT_COLOR: function() {
                    return sT
                },
                TOKEN_CHAT_INPUT_FIELD_FONT_SIZE: function() {
                    return lT
                },
                TOKEN_CHAT_INPUT_FIELD_HEIGHT: function() {
                    return mT
                },
                TOKEN_CHAT_INPUT_FIELD_ICON_SIZE: function() {
                    return aT
                },
                TOKEN_CHAT_INPUT_FIELD_INSET_HORIZONTAL: function() {
                    return bT
                },
                TOKEN_CHAT_INPUT_FIELD_LINE_HEIGHT: function() {
                    return dT
                },
                TOKEN_CHAT_INPUT_MESSAGE_BACKGROUND_COLOR: function() {
                    return yT
                },
                TOKEN_CHAT_INPUT_MESSAGE_BORDER_COLOR: function() {
                    return QT
                },
                TOKEN_CHAT_INPUT_MESSAGE_CONTENT_COLOR: function() {
                    return kT
                },
                TOKEN_CHAT_INPUT_MESSAGE_PLACEHOLDER_COLOR: function() {
                    return JT
                },
                TOKEN_CHAT_INPUT_SEARCH_BACKGROUND_COLOR: function() {
                    return hT
                },
                TOKEN_CHAT_INPUT_SEARCH_BORDER_COLOR: function() {
                    return zT
                },
                TOKEN_CHAT_INPUT_SEARCH_CONTENT_COLOR: function() {
                    return wT
                },
                TOKEN_CHAT_INPUT_SEARCH_ICON_COLOR: function() {
                    return gT
                },
                TOKEN_CHAT_INPUT_SEARCH_ICON_MARGIN_LEFT: function() {
                    return vT
                },
                TOKEN_CHAT_INPUT_SEARCH_ICON_MARGIN_RIGHT: function() {
                    return jT
                },
                TOKEN_CHAT_INPUT_SEARCH_ICON_SIZE: function() {
                    return qT
                },
                TOKEN_CHAT_INPUT_SEARCH_PLACEHOLDER_COLOR: function() {
                    return $T
                },
                TOKEN_CHAT_ITEM_CONTENT_WIDTH_FIXED: function() {
                    return _E
                },
                TOKEN_CHAT_ITEM_CONTENT_WIDTH_RELATIVE: function() {
                    return OE
                },
                TOKEN_CHAT_ITEM_GROUP_AVATAR_BORDER_RADIUS: function() {
                    return TE
                },
                TOKEN_CHAT_ITEM_GROUP_AVATAR_MARGIN_BOTTOM: function() {
                    return EE
                },
                TOKEN_CHAT_ITEM_GROUP_AVATAR_OVERALL_SPACE: function() {
                    return nE
                },
                TOKEN_CHAT_ITEM_GROUP_AVATAR_SIZE: function() {
                    return NE
                },
                TOKEN_CHAT_ITEM_GROUP_SUPPORT: function() {
                    return SE
                },
                TOKEN_CHAT_ITEM_GROUP_TITLE_MARGIN_BOTTOM: function() {
                    return CE
                },
                TOKEN_CHAT_ITEM_MARGIN_TOP: function() {
                    return AE
                },
                TOKEN_CHAT_ITEM_MARGIN_TOP_CONTINUATION: function() {
                    return IE
                },
                TOKEN_CHAT_ITEM_REACTION_BACKGROUND_COLOR: function() {
                    return RE
                },
                TOKEN_CHAT_ITEM_REACTION_BORDER_COLOR: function() {
                    return tE
                },
                TOKEN_CHAT_ITEM_REACTION_BORDER_RADIUS: function() {
                    return uE
                },
                TOKEN_CHAT_ITEM_REACTION_BORDER_WIDTH: function() {
                    return rE
                },
                TOKEN_CHAT_ITEM_REACTION_EXTRA_MARGIN_BOTTOM: function() {
                    return ME
                },
                TOKEN_CHAT_ITEM_REACTION_SIZE: function() {
                    return LE
                },
                TOKEN_CHAT_ITEM_SELECT_OVERALL_SPACE: function() {
                    return KE
                },
                TOKEN_CHAT_ITEM_STATUS_COLOR_BASE: function() {
                    return DE
                },
                TOKEN_CHAT_ITEM_STATUS_COLOR_ERROR: function() {
                    return eE
                },
                TOKEN_CHAT_ITEM_STATUS_COLOR_INFO: function() {
                    return iE
                },
                TOKEN_CHAT_ITEM_STATUS_COLOR_READ_RECEIPT: function() {
                    return oE
                },
                TOKEN_CHAT_ITEM_STATUS_ICON_MARGIN_RIGHT: function() {
                    return cE
                },
                TOKEN_CHAT_ITEM_STATUS_ICON_SIZE: function() {
                    return FE
                },
                TOKEN_CHAT_ITEM_STATUS_MARGIN_TOP: function() {
                    return fE
                },
                TOKEN_CHAT_LIST_INSET_HORIZONTAL: function() {
                    return GE
                },
                TOKEN_CHAT_MESSAGE_AUDIO_BAR_GAP: function() {
                    return PE
                },
                TOKEN_CHAT_MESSAGE_AUDIO_BAR_MAX_HEIGHT: function() {
                    return BE
                },
                TOKEN_CHAT_MESSAGE_AUDIO_BAR_OPACITY: function() {
                    return UE
                },
                TOKEN_CHAT_MESSAGE_AUDIO_BAR_RADIUS: function() {
                    return HE
                },
                TOKEN_CHAT_MESSAGE_AUDIO_BAR_WIDTH: function() {
                    return pE
                },
                TOKEN_CHAT_MESSAGE_AUDIO_ICON_BAR_SPACING_SIZE: function() {
                    return xE
                },
                TOKEN_CHAT_MESSAGE_AUDIO_ICON_SIZE: function() {
                    return YE
                },
                TOKEN_CHAT_MESSAGE_EMOJI_FONT_SIZE: function() {
                    return VE
                },
                TOKEN_CHAT_MESSAGE_EMOJI_SIZE: function() {
                    return WE
                },
                TOKEN_CHAT_MESSAGE_FORWARD_HEADER_TEXT_OPACITY: function() {
                    return ZE
                },
                TOKEN_CHAT_MESSAGE_GIFT_WIDTH: function() {
                    return XE
                },
                TOKEN_CHAT_MESSAGE_INSET_HORIZONTAL: function() {
                    return sE
                },
                TOKEN_CHAT_MESSAGE_INSET_VERTICAL: function() {
                    return lE
                },
                TOKEN_CHAT_MESSAGE_LOCATION_ICON_MARGIN_LEFT: function() {
                    return mE
                },
                TOKEN_CHAT_MESSAGE_LOCATION_ICON_SIZE: function() {
                    return aE
                },
                TOKEN_CHAT_MESSAGE_LOCATION_NOTE_COLOR: function() {
                    return bE
                },
                TOKEN_CHAT_MESSAGE_LOCATION_NOTE_MARGIN_TOP: function() {
                    return dE
                },
                TOKEN_CHAT_MESSAGE_LOCATION_TITLE_COLOR: function() {
                    return yE
                },
                TOKEN_CHAT_MESSAGE_PRIVATE_PHOTO_COLOR: function() {
                    return QE
                },
                TOKEN_CHAT_MESSAGE_SONG_INSET_HORIZONTAL: function() {
                    return kE
                },
                TOKEN_CHAT_MESSAGE_SONG_INSET_VERTICAL: function() {
                    return JE
                },
                TOKEN_CHAT_MESSAGE_SONG_MIN_WIDTH: function() {
                    return hE
                },
                TOKEN_CHAT_MESSAGE_STICKER_WIDTH: function() {
                    return zE
                },
                TOKEN_CHAT_MESSAGE_TEXT_WITH_LINK_DESCRIPTION_COLOR: function() {
                    return wE
                },
                TOKEN_CHAT_MESSAGE_TEXT_WITH_LINK_DESCRIPTION_MARGIN_BOTTOM: function() {
                    return gE
                },
                TOKEN_CHAT_MESSAGE_TEXT_WITH_LINK_DOMAIN_COLOR: function() {
                    return vE
                },
                TOKEN_CHAT_MESSAGE_TEXT_WITH_LINK_PREVIEW_IMAGE_RATIO: function() {
                    return jE
                },
                TOKEN_CHAT_MESSAGE_TEXT_WITH_LINK_TITLE_COLOR: function() {
                    return qE
                },
                TOKEN_CHAT_MESSAGE_TEXT_WITH_LINK_TITLE_MARGIN_BOTTOM: function() {
                    return $E
                },
                TOKEN_CHAT_MESSAGE_VIDEO_TELESCOPE_BACKGROUND_COLOR: function() {
                    return _n
                },
                TOKEN_CHAT_MESSAGE_VIDEO_TELESCOPE_INDICATOR_SIZE: function() {
                    return On
                },
                TOKEN_CHAT_MESSAGE_VIDEO_TELESCOPE_SIZE: function() {
                    return Tn
                },
                TOKEN_CHAT_PANEL_PILLS_ITEM_BACKGROUND_COLOR: function() {
                    return En
                },
                TOKEN_CHAT_PANEL_PILLS_ITEM_BACKGROUND_COLOR_ACTIVE: function() {
                    return nn
                },
                TOKEN_CHAT_PANEL_PILLS_ITEM_BORDER_RADIUS: function() {
                    return Nn
                },
                TOKEN_CHAT_PANEL_PILLS_ITEM_CONTENT_COLOR: function() {
                    return Sn
                },
                TOKEN_CHAT_PANEL_PILLS_ITEM_CONTENT_COLOR_ACTIVE: function() {
                    return Cn
                },
                TOKEN_CHAT_PANEL_PILLS_ITEM_HEIGHT: function() {
                    return An
                },
                TOKEN_CHAT_PANEL_PILLS_ITEM_MEDIA_SIZE: function() {
                    return In
                },
                TOKEN_CHAT_PANEL_PILLS_ITEM_PADDING_HORIZONTAL: function() {
                    return Rn
                },
                TOKEN_CHAT_PANEL_PILLS_ITEM_SPACING_HORIZONTAL: function() {
                    return tn
                },
                TOKEN_CHAT_PREVIEW_MESSAGE_MEDIA_SHAPE_CIRCLE_BORDER_RADIUS: function() {
                    return un
                },
                TOKEN_CHAT_PREVIEW_MESSAGE_MEDIA_SHAPE_SQUARED_BORDER_RADIUS: function() {
                    return rn
                },
                TOKEN_CHAT_PREVIEW_MESSAGE_MEDIA_SIZE: function() {
                    return Mn
                },
                TOKEN_CHAT_PREVIEW_MESSAGE_QUOTE_DECORATION_IN_BACKGROUND_COLOR: function() {
                    return Ln
                },
                TOKEN_CHAT_PREVIEW_MESSAGE_QUOTE_DECORATION_OUT_BACKGROUND_COLOR: function() {
                    return Kn
                },
                TOKEN_CHAT_PREVIEW_MESSAGE_QUOTE_DECORATION_RADIUS: function() {
                    return Dn
                },
                TOKEN_CHAT_PREVIEW_MESSAGE_QUOTE_DECORATION_WIDTH: function() {
                    return en
                },
                TOKEN_CHAT_SCROLL_TO_BOTTOM_ICON_COLOR: function() {
                    return on
                },
                TOKEN_CHAT_SCROLL_TO_BOTTOM_ICON_SIZE: function() {
                    return cn
                },
                TOKEN_CHAT_SCROLL_TO_BOTTOM_NOTIFICATION_SIZE: function() {
                    return Fn
                },
                TOKEN_CHAT_SCROLL_TO_BOTTOM_OUTER_BORDER_OPACITY: function() {
                    return fn
                },
                TOKEN_CHAT_SCROLL_TO_BOTTOM_OUTER_BORDER_SIZE: function() {
                    return Gn
                },
                TOKEN_CHAT_SCROLL_TO_BOTTOM_SHADOW_BLUR_RADIUS: function() {
                    return Pn
                },
                TOKEN_CHAT_SCROLL_TO_BOTTOM_SHADOW_COLOR: function() {
                    return Bn
                },
                TOKEN_CHAT_SCROLL_TO_BOTTOM_SHADOW_OPACITY: function() {
                    return Un
                },
                TOKEN_CHAT_SCROLL_TO_BOTTOM_SHADOW_VERTICAL_OFFSET: function() {
                    return Hn
                },
                TOKEN_CHAT_SCROLL_TO_BOTTOM_SIZE: function() {
                    return pn
                },
                TOKEN_CHERRYPICKER_ADD_CONTENT_OPACITY: function() {
                    return xn
                },
                TOKEN_CHERRYPICKER_ICON_SHIFT: function() {
                    return Yn
                },
                TOKEN_CHERRYPICKER_ICON_SIZE: function() {
                    return Vn
                },
                TOKEN_COLOR_BLACK: function() {
                    return Wn
                },
                TOKEN_COLOR_ERROR: function() {
                    return Zn
                },
                TOKEN_COLOR_FEATURE_ATTENTION_BOOST: function() {
                    return Xn
                },
                TOKEN_COLOR_FEATURE_BILLING: function() {
                    return sn
                },
                TOKEN_COLOR_FEATURE_BOOST: function() {
                    return ln
                },
                TOKEN_COLOR_FEATURE_BUMP: function() {
                    return mn
                },
                TOKEN_COLOR_FEATURE_BUNDLE_SALE: function() {
                    return an
                },
                TOKEN_COLOR_FEATURE_CHAT_QUOTA: function() {
                    return bn
                },
                TOKEN_COLOR_FEATURE_CHAT_WITH_NEWBIES: function() {
                    return dn
                },
                TOKEN_COLOR_FEATURE_CHAT_WITH_TIRED: function() {
                    return yn
                },
                TOKEN_COLOR_FEATURE_CRITERIA: function() {
                    return Qn
                },
                TOKEN_COLOR_FEATURE_CRUSH: function() {
                    return kn
                },
                TOKEN_COLOR_FEATURE_DEFAULT: function() {
                    return Jn
                },
                TOKEN_COLOR_FEATURE_DEFAULT_LIGHT: function() {
                    return hn
                },
                TOKEN_COLOR_FEATURE_EXTRA_SHOWS: function() {
                    return zn
                },
                TOKEN_COLOR_FEATURE_FAVOURITES: function() {
                    return wn
                },
                TOKEN_COLOR_FEATURE_ICEBREAKER: function() {
                    return gn
                },
                TOKEN_COLOR_FEATURE_INVISIBLE_MODE: function() {
                    return vn
                },
                TOKEN_COLOR_FEATURE_LIKED_YOU: function() {
                    return jn
                },
                TOKEN_COLOR_FEATURE_LIKED_YOU_DARK: function() {
                    return qn
                },
                TOKEN_COLOR_FEATURE_LIVE: function() {
                    return $n
                },
                TOKEN_COLOR_FEATURE_NEVER_LOOSE_ACCOUNT: function() {
                    return _N
                },
                TOKEN_COLOR_FEATURE_PREMIUM: function() {
                    return ON
                },
                TOKEN_COLOR_FEATURE_PREMIUM_ALT_GRADIENT_START: function() {
                    return TN
                },
                TOKEN_COLOR_FEATURE_PREMIUM_ALT_GRADIENT_STOP: function() {
                    return EN
                },
                TOKEN_COLOR_FEATURE_PREMIUM_GRADIENT_START: function() {
                    return nN
                },
                TOKEN_COLOR_FEATURE_PREMIUM_GRADIENT_STOP: function() {
                    return NN
                },
                TOKEN_COLOR_FEATURE_PREMIUM_LIGHT: function() {
                    return SN
                },
                TOKEN_COLOR_FEATURE_PREMIUM_PLUS: function() {
                    return CN
                },
                TOKEN_COLOR_FEATURE_PREMIUM_PLUS_ALT: function() {
                    return AN
                },
                TOKEN_COLOR_FEATURE_PREMIUM_PLUS_ALT_GRADIENT_START: function() {
                    return IN
                },
                TOKEN_COLOR_FEATURE_PREMIUM_PLUS_ALT_GRADIENT_STOP: function() {
                    return RN
                },
                TOKEN_COLOR_FEATURE_PREMIUM_PLUS_GRADIENT_START: function() {
                    return tN
                },
                TOKEN_COLOR_FEATURE_PREMIUM_PLUS_GRADIENT_STOP: function() {
                    return uN
                },
                TOKEN_COLOR_FEATURE_QUESTIONS_GAME: function() {
                    return rN
                },
                TOKEN_COLOR_FEATURE_QUESTIONS_GAME_DARK: function() {
                    return MN
                },
                TOKEN_COLOR_FEATURE_READ_RECEIPT: function() {
                    return LN
                },
                TOKEN_COLOR_FEATURE_REVENUE: function() {
                    return KN
                },
                TOKEN_COLOR_FEATURE_REVENUE_ALT: function() {
                    return DN
                },
                TOKEN_COLOR_FEATURE_REVENUE_LIGHT: function() {
                    return eN
                },
                TOKEN_COLOR_FEATURE_RISEUP: function() {
                    return iN
                },
                TOKEN_COLOR_FEATURE_SPECIAL_DELIVERY: function() {
                    return oN
                },
                TOKEN_COLOR_FEATURE_SPOTLIGHT: function() {
                    return cN
                },
                TOKEN_COLOR_FEATURE_UNDO: function() {
                    return FN
                },
                TOKEN_COLOR_FEATURE_VERIFICATION: function() {
                    return fN
                },
                TOKEN_COLOR_GENERIC_BLUE: function() {
                    return GN
                },
                TOKEN_COLOR_GENERIC_CORAL: function() {
                    return PN
                },
                TOKEN_COLOR_GENERIC_GREEN: function() {
                    return BN
                },
                TOKEN_COLOR_GENERIC_GREEN_DARK: function() {
                    return UN
                },
                TOKEN_COLOR_GENERIC_ORANGE: function() {
                    return HN
                },
                TOKEN_COLOR_GENERIC_PINK: function() {
                    return pN
                },
                TOKEN_COLOR_GENERIC_PINK_LIGHT: function() {
                    return xN
                },
                TOKEN_COLOR_GENERIC_PURPLE: function() {
                    return YN
                },
                TOKEN_COLOR_GENERIC_RED: function() {
                    return VN
                },
                TOKEN_COLOR_GENERIC_YELLOW: function() {
                    return WN
                },
                TOKEN_COLOR_GENERIC_YELLOW_DARK: function() {
                    return ZN
                },
                TOKEN_COLOR_GRAY: function() {
                    return XN
                },
                TOKEN_COLOR_GRAY_10: function() {
                    return sN
                },
                TOKEN_COLOR_GRAY_20: function() {
                    return lN
                },
                TOKEN_COLOR_GRAY_30: function() {
                    return mN
                },
                TOKEN_COLOR_GRAY_50: function() {
                    return aN
                },
                TOKEN_COLOR_GRAY_80: function() {
                    return bN
                },
                TOKEN_COLOR_GRAY_DARK: function() {
                    return dN
                },
                TOKEN_COLOR_GRAY_LIGHT: function() {
                    return yN
                },
                TOKEN_COLOR_NOTIFICATION: function() {
                    return QN
                },
                TOKEN_COLOR_POPULARITY_AVERAGE: function() {
                    return kN
                },
                TOKEN_COLOR_POPULARITY_HIGH: function() {
                    return JN
                },
                TOKEN_COLOR_POPULARITY_LOW: function() {
                    return hN
                },
                TOKEN_COLOR_POPULARITY_VERYHIGH: function() {
                    return zN
                },
                TOKEN_COLOR_POPULARITY_VERYLOW: function() {
                    return wN
                },
                TOKEN_COLOR_PRIMARY: function() {
                    return gN
                },
                TOKEN_COLOR_PRIMARY_DARK: function() {
                    return vN
                },
                TOKEN_COLOR_PRIMARY_LIGHT: function() {
                    return jN
                },
                TOKEN_COLOR_PRIMARY_LIGHTER: function() {
                    return qN
                },
                TOKEN_COLOR_PROVIDER_APPLE: function() {
                    return $N
                },
                TOKEN_COLOR_PROVIDER_FACEBOOK: function() {
                    return _S
                },
                TOKEN_COLOR_PROVIDER_GOOGLE: function() {
                    return OS
                },
                TOKEN_COLOR_PROVIDER_INSTAGRAM: function() {
                    return TS
                },
                TOKEN_COLOR_PROVIDER_LINKEDIN: function() {
                    return ES
                },
                TOKEN_COLOR_PROVIDER_ODNOKLASSNIKI: function() {
                    return nS
                },
                TOKEN_COLOR_PROVIDER_SPOTIFY: function() {
                    return NS
                },
                TOKEN_COLOR_PROVIDER_TWITTER: function() {
                    return SS
                },
                TOKEN_COLOR_PROVIDER_VKONTAKTE: function() {
                    return CS
                },
                TOKEN_COLOR_SECONDARY: function() {
                    return AS
                },
                TOKEN_COLOR_STATUS_ERROR: function() {
                    return IS
                },
                TOKEN_COLOR_STATUS_NOTIFICATION: function() {
                    return RS
                },
                TOKEN_COLOR_STATUS_POSITIVE: function() {
                    return tS
                },
                TOKEN_COLOR_STATUS_POSITIVE_DARK: function() {
                    return uS
                },
                TOKEN_COLOR_STATUS_WARNING: function() {
                    return rS
                },
                TOKEN_COLOR_STATUS_WARNING_DARK: function() {
                    return MS
                },
                TOKEN_COLOR_WHITE: function() {
                    return LS
                },
                TOKEN_COSMOS_ACTIONBADGE_BORDER_RADIUS: function() {
                    return KS
                },
                TOKEN_COSMOS_ACTIONBADGE_BORDER_WIDTH_DEFAULT: function() {
                    return DS
                },
                TOKEN_COSMOS_ACTIONBADGE_BORDER_WIDTH_SELECTED: function() {
                    return eS
                },
                TOKEN_COSMOS_ACTIONBADGE_COLOR_BACKGROUND_DEFAULT: function() {
                    return iS
                },
                TOKEN_COSMOS_ACTIONBADGE_COLOR_BACKGROUND_OVERLAY_HOVER: function() {
                    return oS
                },
                TOKEN_COSMOS_ACTIONBADGE_COLOR_BACKGROUND_OVERLAY_PRESSED: function() {
                    return cS
                },
                TOKEN_COSMOS_ACTIONBADGE_COLOR_BACKGROUND_SELECTED: function() {
                    return FS
                },
                TOKEN_COSMOS_ACTIONBADGE_COLOR_BORDER_DEFAULT: function() {
                    return fS
                },
                TOKEN_COSMOS_ACTIONBADGE_COLOR_BORDER_SELECTED: function() {
                    return GS
                },
                TOKEN_COSMOS_ACTIONBADGE_COLOR_CONTENT_DEFAULT: function() {
                    return PS
                },
                TOKEN_COSMOS_ACTIONBADGE_COLOR_CONTENT_SELECTED: function() {
                    return BS
                },
                TOKEN_COSMOS_ACTIONBADGE_COLOR_ICON_DEFAULT: function() {
                    return US
                },
                TOKEN_COSMOS_ACTIONBADGE_COLOR_ICON_SELECTED: function() {
                    return HS
                },
                TOKEN_COSMOS_ACTIONBADGE_SIZING_ASSET: function() {
                    return pS
                },
                TOKEN_COSMOS_ACTIONBADGE_SIZING_EMOJI: function() {
                    return xS
                },
                TOKEN_COSMOS_ACTIONBADGE_SIZING_ICON: function() {
                    return YS
                },
                TOKEN_COSMOS_ACTIONBADGE_SIZING_MIN_HEIGHT: function() {
                    return VS
                },
                TOKEN_COSMOS_ACTIONBADGE_SIZING_NAVIGATION: function() {
                    return WS
                },
                TOKEN_COSMOS_ACTIONBADGE_SPACING_GAP_MEDIUM: function() {
                    return ZS
                },
                TOKEN_COSMOS_ACTIONBADGE_SPACING_GAP_SMALL: function() {
                    return XS
                },
                TOKEN_COSMOS_ACTIONBADGE_SPACING_HORIZONTAL: function() {
                    return sS
                },
                TOKEN_COSMOS_ACTIONBADGE_SPACING_VERTICAL: function() {
                    return lS
                },
                TOKEN_COSMOS_ACTIONBADGE_TYPOGRAPHY_CONTENT: function() {
                    return mS
                },
                TOKEN_COSMOS_ACTIONCARD_BORDER_RADIUS: function() {
                    return aS
                },
                TOKEN_COSMOS_ACTIONCARD_BORDER_WIDTH_ACCENT: function() {
                    return bS
                },
                TOKEN_COSMOS_ACTIONCARD_BORDER_WIDTH_PRIMARY: function() {
                    return dS
                },
                TOKEN_COSMOS_ACTIONCARD_BORDER_WIDTH_SECONDARY: function() {
                    return yS
                },
                TOKEN_COSMOS_ACTIONCARD_BORDER_WIDTH_TERTIARY: function() {
                    return QS
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_BACKGROUND_ACCENT: function() {
                    return kS
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_BACKGROUND_OVERLAY_HOVER: function() {
                    return JS
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_BACKGROUND_OVERLAY_PRESSED: function() {
                    return hS
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_BACKGROUND_PRIMARY: function() {
                    return zS
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_BACKGROUND_SECONDARY: function() {
                    return wS
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_BACKGROUND_TERTIARY: function() {
                    return gS
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_BORDER_ACCENT: function() {
                    return vS
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_BORDER_PRIMARY: function() {
                    return jS
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_BORDER_SECONDARY: function() {
                    return qS
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_BORDER_TERTIARY: function() {
                    return $S
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_DESCRIPTION_ACCENT: function() {
                    return _C
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_DESCRIPTION_PRIMARY: function() {
                    return OC
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_DESCRIPTION_SECONDARY: function() {
                    return TC
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_DESCRIPTION_TERTIARY: function() {
                    return EC
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_ICON_ACCENT: function() {
                    return nC
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_ICON_NAVIGATION: function() {
                    return NC
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_ICON_PRIMARY: function() {
                    return SC
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_ICON_SECONDARY: function() {
                    return CC
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_ICON_TERTIARY: function() {
                    return AC
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_TITLE_ACCENT: function() {
                    return IC
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_TITLE_PRIMARY: function() {
                    return RC
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_TITLE_SECONDARY: function() {
                    return tC
                },
                TOKEN_COSMOS_ACTIONCARD_COLOR_TITLE_TERTIARY: function() {
                    return uC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_HIGH_BLUR: function() {
                    return rC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_HIGH_COLOR: function() {
                    return MC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_HIGH_SPREAD: function() {
                    return LC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_HIGH_X: function() {
                    return KC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_HIGH_Y: function() {
                    return DC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_LOW_BLUR: function() {
                    return eC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_LOW_COLOR: function() {
                    return iC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_LOW_SPREAD: function() {
                    return oC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_LOW_X: function() {
                    return cC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_LOW_Y: function() {
                    return FC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_MEDIUM_BLUR: function() {
                    return fC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_MEDIUM_COLOR: function() {
                    return GC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_MEDIUM_SPREAD: function() {
                    return PC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_MEDIUM_X: function() {
                    return BC
                },
                TOKEN_COSMOS_ACTIONCARD_SHADOW_MEDIUM_Y: function() {
                    return UC
                },
                TOKEN_COSMOS_ACTIONCARD_SIZING_ICON_END: function() {
                    return HC
                },
                TOKEN_COSMOS_ACTIONCARD_SIZING_ICON_START_MEDIUM: function() {
                    return pC
                },
                TOKEN_COSMOS_ACTIONCARD_SIZING_ICON_START_SMALL: function() {
                    return xC
                },
                TOKEN_COSMOS_ACTIONCARD_SPACING_GAP_HORIZONTAL: function() {
                    return YC
                },
                TOKEN_COSMOS_ACTIONCARD_SPACING_GAP_VERTICAL: function() {
                    return VC
                },
                TOKEN_COSMOS_ACTIONCARD_SPACING_HORIZONTAL: function() {
                    return WC
                },
                TOKEN_COSMOS_ACTIONCARD_SPACING_VERTICAL: function() {
                    return ZC
                },
                TOKEN_COSMOS_ACTIONCARD_TYPOGRAPHY_DESCRIPTION: function() {
                    return XC
                },
                TOKEN_COSMOS_ACTIONCARD_TYPOGRAPHY_TITLE: function() {
                    return sC
                },
                TOKEN_COSMOS_ACTIONCELL_BORDER_RADIUS: function() {
                    return lC
                },
                TOKEN_COSMOS_ACTIONCELL_BORDER_WIDTH_DEFAULT: function() {
                    return mC
                },
                TOKEN_COSMOS_ACTIONCELL_BORDER_WIDTH_ERROR: function() {
                    return aC
                },
                TOKEN_COSMOS_ACTIONCELL_BORDER_WIDTH_SELECTED: function() {
                    return bC
                },
                TOKEN_COSMOS_ACTIONCELL_COLOR_BACKGROUND_DEFAULT: function() {
                    return dC
                },
                TOKEN_COSMOS_ACTIONCELL_COLOR_BACKGROUND_ERROR: function() {
                    return yC
                },
                TOKEN_COSMOS_ACTIONCELL_COLOR_BACKGROUND_OVERLAY_HOVER: function() {
                    return QC
                },
                TOKEN_COSMOS_ACTIONCELL_COLOR_BACKGROUND_OVERLAY_PRESSED: function() {
                    return kC
                },
                TOKEN_COSMOS_ACTIONCELL_COLOR_BACKGROUND_SELECTED: function() {
                    return JC
                },
                TOKEN_COSMOS_ACTIONCELL_COLOR_BORDER_DEFAULT: function() {
                    return hC
                },
                TOKEN_COSMOS_ACTIONCELL_COLOR_BORDER_ERROR: function() {
                    return zC
                },
                TOKEN_COSMOS_ACTIONCELL_COLOR_BORDER_SELECTED: function() {
                    return wC
                },
                TOKEN_COSMOS_ACTIONCELL_COLOR_CONTENT_DEFAULT: function() {
                    return gC
                },
                TOKEN_COSMOS_ACTIONCELL_COLOR_CONTENT_ERROR: function() {
                    return vC
                },
                TOKEN_COSMOS_ACTIONCELL_COLOR_CONTENT_SELECTED: function() {
                    return jC
                },
                TOKEN_COSMOS_ACTIONCELL_COLOR_ICON: function() {
                    return qC
                },
                TOKEN_COSMOS_ACTIONCELL_SIZING_EMOJI: function() {
                    return $C
                },
                TOKEN_COSMOS_ACTIONCELL_SIZING_ICON: function() {
                    return _A
                },
                TOKEN_COSMOS_ACTIONCELL_SPACING_GAP: function() {
                    return OA
                },
                TOKEN_COSMOS_ACTIONCELL_SPACING_HORIZONTAL: function() {
                    return TA
                },
                TOKEN_COSMOS_ACTIONCELL_SPACING_VERTICAL: function() {
                    return EA
                },
                TOKEN_COSMOS_ACTIONCELL_TYPOGRAPHY_CONTENT: function() {
                    return nA
                },
                TOKEN_COSMOS_ACTIONROW_COLOR_BACKGROUND_DEFAULT: function() {
                    return NA
                },
                TOKEN_COSMOS_ACTIONROW_COLOR_BACKGROUND_OVERLAY_HOVER: function() {
                    return SA
                },
                TOKEN_COSMOS_ACTIONROW_COLOR_BACKGROUND_OVERLAY_PRESSED: function() {
                    return CA
                },
                TOKEN_COSMOS_ACTIONROW_COLOR_CHEVRON: function() {
                    return AA
                },
                TOKEN_COSMOS_ACTIONROW_COLOR_DESCRIPTION: function() {
                    return IA
                },
                TOKEN_COSMOS_ACTIONROW_COLOR_ICON_END: function() {
                    return RA
                },
                TOKEN_COSMOS_ACTIONROW_COLOR_ICON_START: function() {
                    return tA
                },
                TOKEN_COSMOS_ACTIONROW_COLOR_LABEL: function() {
                    return uA
                },
                TOKEN_COSMOS_ACTIONROW_COLOR_TITLE: function() {
                    return rA
                },
                TOKEN_COSMOS_ACTIONROW_SIZING_CHEVRON: function() {
                    return MA
                },
                TOKEN_COSMOS_ACTIONROW_SIZING_ICON_END: function() {
                    return LA
                },
                TOKEN_COSMOS_ACTIONROW_SIZING_ICON_START_MEDIUM: function() {
                    return KA
                },
                TOKEN_COSMOS_ACTIONROW_SIZING_ICON_START_SMALL: function() {
                    return DA
                },
                TOKEN_COSMOS_ACTIONROW_SIZING_MIN_HEIGHT_SMALL: function() {
                    return eA
                },
                TOKEN_COSMOS_ACTIONROW_SPACING_GAP_HORIZONTAL_MEDIUM: function() {
                    return iA
                },
                TOKEN_COSMOS_ACTIONROW_SPACING_GAP_HORIZONTAL_SMALL: function() {
                    return oA
                },
                TOKEN_COSMOS_ACTIONROW_SPACING_GAP_HORIZONTAL_XSMALL: function() {
                    return cA
                },
                TOKEN_COSMOS_ACTIONROW_SPACING_GAP_VERTICAL: function() {
                    return FA
                },
                TOKEN_COSMOS_ACTIONROW_SPACING_HORIZONTAL_COMPACT: function() {
                    return fA
                },
                TOKEN_COSMOS_ACTIONROW_SPACING_HORIZONTAL_DEFAULT: function() {
                    return GA
                },
                TOKEN_COSMOS_ACTIONROW_SPACING_VERTICAL_COMPACT_MEDIUM: function() {
                    return PA
                },
                TOKEN_COSMOS_ACTIONROW_SPACING_VERTICAL_COMPACT_SMALL: function() {
                    return BA
                },
                TOKEN_COSMOS_ACTIONROW_SPACING_VERTICAL_DEFAULT: function() {
                    return UA
                },
                TOKEN_COSMOS_ACTIONROW_TYPOGRAPHY_DESCRIPTION: function() {
                    return HA
                },
                TOKEN_COSMOS_ACTIONROW_TYPOGRAPHY_LABEL: function() {
                    return pA
                },
                TOKEN_COSMOS_ACTIONROW_TYPOGRAPHY_TITLE_SMALL: function() {
                    return xA
                },
                TOKEN_COSMOS_ACTIONSHEET_BORDER_RADIUS_ROUNDED: function() {
                    return YA
                },
                TOKEN_COSMOS_ACTIONSHEET_BORDER_RADIUS_SQUARED: function() {
                    return VA
                },
                TOKEN_COSMOS_ACTIONSHEET_COLOR_BACKGROUND_BACKDROP: function() {
                    return WA
                },
                TOKEN_COSMOS_ACTIONSHEET_COLOR_BACKGROUND_CONTAINER: function() {
                    return ZA
                },
                TOKEN_COSMOS_ACTIONSHEET_COLOR_BACKGROUND_MEDIA: function() {
                    return XA
                },
                TOKEN_COSMOS_ACTIONSHEET_SHADOW_CONTAINER_BLUR: function() {
                    return sA
                },
                TOKEN_COSMOS_ACTIONSHEET_SHADOW_CONTAINER_COLOR: function() {
                    return lA
                },
                TOKEN_COSMOS_ACTIONSHEET_SHADOW_CONTAINER_SPREAD: function() {
                    return mA
                },
                TOKEN_COSMOS_ACTIONSHEET_SHADOW_CONTAINER_X: function() {
                    return aA
                },
                TOKEN_COSMOS_ACTIONSHEET_SHADOW_CONTAINER_Y: function() {
                    return bA
                },
                TOKEN_COSMOS_ACTIONSHEET_SPACING_GAP_MEDIUM: function() {
                    return dA
                },
                TOKEN_COSMOS_ACTIONSHEET_SPACING_GAP_SMALL: function() {
                    return yA
                },
                TOKEN_COSMOS_ACTIONSHEET_SPACING_HORIZONTAL_MEDIUM: function() {
                    return QA
                },
                TOKEN_COSMOS_ACTIONSHEET_SPACING_HORIZONTAL_SMALL: function() {
                    return kA
                },
                TOKEN_COSMOS_ACTIONSHEET_SPACING_VERTICAL_BOTTOM: function() {
                    return JA
                },
                TOKEN_COSMOS_ACTIONSHEET_SPACING_VERTICAL_TOP_MEDIUM: function() {
                    return hA
                },
                TOKEN_COSMOS_ACTIONSHEET_SPACING_VERTICAL_TOP_SMALL: function() {
                    return zA
                },
                TOKEN_COSMOS_ACTIONSHEET_SPACING_VERTICAL_TOP_XSMALL: function() {
                    return wA
                },
                TOKEN_COSMOS_AVATAR_ASPECT_RATIO_HEIGHT: function() {
                    return gA
                },
                TOKEN_COSMOS_AVATAR_ASPECT_RATIO_WIDTH: function() {
                    return vA
                },
                TOKEN_COSMOS_AVATAR_COLOR_BACKGROUND: function() {
                    return jA
                },
                TOKEN_COSMOS_AVATAR_COLOR_ICON: function() {
                    return qA
                },
                TOKEN_COSMOS_BADGE_BORDER_RADIUS: function() {
                    return $A
                },
                TOKEN_COSMOS_BADGE_BORDER_WIDTH_ALT: function() {
                    return _I
                },
                TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_SOLID_ALT: function() {
                    return OI
                },
                TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_SOLID_BRAND: function() {
                    return TI
                },
                TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_SOLID_DEFAULT: function() {
                    return EI
                },
                TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_SOLID_HIGHLIGHT: function() {
                    return nI
                },
                TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_SOLID_INVERSE: function() {
                    return NI
                },
                TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_SOLID_VERIFICATION: function() {
                    return SI
                },
                TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_TRANSPARENT_ALT: function() {
                    return CI
                },
                TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_TRANSPARENT_BRAND: function() {
                    return AI
                },
                TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_TRANSPARENT_DEFAULT: function() {
                    return II
                },
                TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_TRANSPARENT_HIGHLIGHT: function() {
                    return RI
                },
                TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_TRANSPARENT_INVERSE: function() {
                    return tI
                },
                TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_TRANSPARENT_VERIFICATION: function() {
                    return uI
                },
                TOKEN_COSMOS_BADGE_COLOR_BORDER_ALT: function() {
                    return rI
                },
                TOKEN_COSMOS_BADGE_COLOR_CONTENT_SOLID_ALT: function() {
                    return MI
                },
                TOKEN_COSMOS_BADGE_COLOR_CONTENT_SOLID_BRAND: function() {
                    return LI
                },
                TOKEN_COSMOS_BADGE_COLOR_CONTENT_SOLID_DEFAULT: function() {
                    return KI
                },
                TOKEN_COSMOS_BADGE_COLOR_CONTENT_SOLID_HIGHLIGHT: function() {
                    return DI
                },
                TOKEN_COSMOS_BADGE_COLOR_CONTENT_SOLID_INVERSE: function() {
                    return eI
                },
                TOKEN_COSMOS_BADGE_COLOR_CONTENT_SOLID_VERIFICATION: function() {
                    return iI
                },
                TOKEN_COSMOS_BADGE_COLOR_CONTENT_TRANSPARENT_ALT: function() {
                    return oI
                },
                TOKEN_COSMOS_BADGE_COLOR_CONTENT_TRANSPARENT_BRAND: function() {
                    return cI
                },
                TOKEN_COSMOS_BADGE_COLOR_CONTENT_TRANSPARENT_DEFAULT: function() {
                    return FI
                },
                TOKEN_COSMOS_BADGE_COLOR_CONTENT_TRANSPARENT_HIGHLIGHT: function() {
                    return fI
                },
                TOKEN_COSMOS_BADGE_COLOR_CONTENT_TRANSPARENT_INVERSE: function() {
                    return GI
                },
                TOKEN_COSMOS_BADGE_COLOR_CONTENT_TRANSPARENT_VERIFICATION: function() {
                    return PI
                },
                TOKEN_COSMOS_BADGE_COLOR_ICON_SOLID_ALT: function() {
                    return BI
                },
                TOKEN_COSMOS_BADGE_COLOR_ICON_SOLID_BRAND: function() {
                    return UI
                },
                TOKEN_COSMOS_BADGE_COLOR_ICON_SOLID_DEFAULT: function() {
                    return HI
                },
                TOKEN_COSMOS_BADGE_COLOR_ICON_SOLID_HIGHLIGHT: function() {
                    return pI
                },
                TOKEN_COSMOS_BADGE_COLOR_ICON_SOLID_INVERSE: function() {
                    return xI
                },
                TOKEN_COSMOS_BADGE_COLOR_ICON_SOLID_VERIFICATION: function() {
                    return YI
                },
                TOKEN_COSMOS_BADGE_COLOR_ICON_TRANSPARENT_ALT: function() {
                    return VI
                },
                TOKEN_COSMOS_BADGE_COLOR_ICON_TRANSPARENT_BRAND: function() {
                    return WI
                },
                TOKEN_COSMOS_BADGE_COLOR_ICON_TRANSPARENT_DEFAULT: function() {
                    return ZI
                },
                TOKEN_COSMOS_BADGE_COLOR_ICON_TRANSPARENT_HIGHLIGHT: function() {
                    return XI
                },
                TOKEN_COSMOS_BADGE_COLOR_ICON_TRANSPARENT_INVERSE: function() {
                    return sI
                },
                TOKEN_COSMOS_BADGE_COLOR_ICON_TRANSPARENT_VERIFICATION: function() {
                    return lI
                },
                TOKEN_COSMOS_BADGE_SIZING_BACKGROUND_BLUR_ALT: function() {
                    return mI
                },
                TOKEN_COSMOS_BADGE_SIZING_BACKGROUND_BLUR_BRAND: function() {
                    return aI
                },
                TOKEN_COSMOS_BADGE_SIZING_BACKGROUND_BLUR_DEFAULT: function() {
                    return bI
                },
                TOKEN_COSMOS_BADGE_SIZING_BACKGROUND_BLUR_HIGHLIGHT: function() {
                    return dI
                },
                TOKEN_COSMOS_BADGE_SIZING_BACKGROUND_BLUR_INVERSE: function() {
                    return yI
                },
                TOKEN_COSMOS_BADGE_SIZING_BACKGROUND_BLUR_VERIFICATION: function() {
                    return QI
                },
                TOKEN_COSMOS_BADGE_SIZING_EMOJI_MICRO: function() {
                    return kI
                },
                TOKEN_COSMOS_BADGE_SIZING_EMOJI_MINI: function() {
                    return JI
                },
                TOKEN_COSMOS_BADGE_SIZING_EMOJI_SMALL: function() {
                    return hI
                },
                TOKEN_COSMOS_BADGE_SIZING_ICON_MICRO: function() {
                    return zI
                },
                TOKEN_COSMOS_BADGE_SIZING_ICON_MINI: function() {
                    return wI
                },
                TOKEN_COSMOS_BADGE_SIZING_ICON_SMALL: function() {
                    return gI
                },
                TOKEN_COSMOS_BADGE_SIZING_MEDIA_MICRO: function() {
                    return vI
                },
                TOKEN_COSMOS_BADGE_SIZING_MEDIA_MINI: function() {
                    return jI
                },
                TOKEN_COSMOS_BADGE_SIZING_MEDIA_SMALL: function() {
                    return qI
                },
                TOKEN_COSMOS_BADGE_SIZING_MIN_HEIGHT_MICRO: function() {
                    return $I
                },
                TOKEN_COSMOS_BADGE_SIZING_MIN_HEIGHT_MINI: function() {
                    return _R
                },
                TOKEN_COSMOS_BADGE_SIZING_MIN_HEIGHT_SMALL: function() {
                    return OR
                },
                TOKEN_COSMOS_BADGE_SPACING_GAP_MICRO: function() {
                    return TR
                },
                TOKEN_COSMOS_BADGE_SPACING_GAP_MINI: function() {
                    return ER
                },
                TOKEN_COSMOS_BADGE_SPACING_GAP_SMALL: function() {
                    return nR
                },
                TOKEN_COSMOS_BADGE_SPACING_HORIZONTAL_MICRO_END_DEFAULT: function() {
                    return NR
                },
                TOKEN_COSMOS_BADGE_SPACING_HORIZONTAL_MICRO_END_MEDIA: function() {
                    return SR
                },
                TOKEN_COSMOS_BADGE_SPACING_HORIZONTAL_MICRO_START_DEFAULT: function() {
                    return CR
                },
                TOKEN_COSMOS_BADGE_SPACING_HORIZONTAL_MICRO_START_MEDIA: function() {
                    return AR
                },
                TOKEN_COSMOS_BADGE_SPACING_HORIZONTAL_MINI_END_DEFAULT: function() {
                    return IR
                },
                TOKEN_COSMOS_BADGE_SPACING_HORIZONTAL_MINI_END_MEDIA: function() {
                    return RR
                },
                TOKEN_COSMOS_BADGE_SPACING_HORIZONTAL_MINI_START_DEFAULT: function() {
                    return tR
                },
                TOKEN_COSMOS_BADGE_SPACING_HORIZONTAL_MINI_START_MEDIA: function() {
                    return uR
                },
                TOKEN_COSMOS_BADGE_SPACING_HORIZONTAL_SMALL_END_DEFAULT: function() {
                    return rR
                },
                TOKEN_COSMOS_BADGE_SPACING_HORIZONTAL_SMALL_END_MEDIA: function() {
                    return MR
                },
                TOKEN_COSMOS_BADGE_SPACING_HORIZONTAL_SMALL_START_DEFAULT: function() {
                    return LR
                },
                TOKEN_COSMOS_BADGE_SPACING_HORIZONTAL_SMALL_START_MEDIA: function() {
                    return KR
                },
                TOKEN_COSMOS_BADGE_SPACING_VERTICAL_MEDIA: function() {
                    return DR
                },
                TOKEN_COSMOS_BADGE_SPACING_VERTICAL_MICRO: function() {
                    return eR
                },
                TOKEN_COSMOS_BADGE_SPACING_VERTICAL_MINI: function() {
                    return iR
                },
                TOKEN_COSMOS_BADGE_SPACING_VERTICAL_SMALL: function() {
                    return oR
                },
                TOKEN_COSMOS_BADGE_TYPOGRAPHY_MICRO: function() {
                    return cR
                },
                TOKEN_COSMOS_BADGE_TYPOGRAPHY_MINI: function() {
                    return FR
                },
                TOKEN_COSMOS_BADGE_TYPOGRAPHY_SMALL: function() {
                    return fR
                },
                TOKEN_COSMOS_BRICK_BORDER_RADIUS_LARGE: function() {
                    return GR
                },
                TOKEN_COSMOS_BRICK_BORDER_RADIUS_MEDIUM: function() {
                    return PR
                },
                TOKEN_COSMOS_BRICK_BORDER_RADIUS_ROUNDED: function() {
                    return BR
                },
                TOKEN_COSMOS_BRICK_BORDER_RADIUS_SMALL: function() {
                    return UR
                },
                TOKEN_COSMOS_BRICK_BORDER_RADIUS_XLARGE: function() {
                    return HR
                },
                TOKEN_COSMOS_BRICK_BORDER_RADIUS_XSMALL: function() {
                    return pR
                },
                TOKEN_COSMOS_BRICK_COLOR_ICON: function() {
                    return xR
                },
                TOKEN_COSMOS_BRICK_COLOR_OVERLAY: function() {
                    return YR
                },
                TOKEN_COSMOS_BRICK_SIZING_BACKGROUND_BLUR_OVERLAY: function() {
                    return VR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_HEIGHT_LARGE: function() {
                    return WR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_HEIGHT_MEDIUM: function() {
                    return ZR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_HEIGHT_SMALL: function() {
                    return XR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_HEIGHT_XLARGE: function() {
                    return sR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_HEIGHT_XSMALL: function() {
                    return lR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_WIDTH_COMPACT_LARGE: function() {
                    return mR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_WIDTH_COMPACT_MEDIUM: function() {
                    return aR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_WIDTH_COMPACT_SMALL: function() {
                    return bR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_WIDTH_COMPACT_XLARGE: function() {
                    return dR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_WIDTH_COMPACT_XSMALL: function() {
                    return yR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_WIDTH_DEFAULT_LARGE: function() {
                    return QR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_WIDTH_DEFAULT_MEDIUM: function() {
                    return kR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_WIDTH_DEFAULT_SMALL: function() {
                    return JR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_WIDTH_DEFAULT_XLARGE: function() {
                    return hR
                },
                TOKEN_COSMOS_BRICK_SIZING_CONTAINER_WIDTH_DEFAULT_XSMALL: function() {
                    return zR
                },
                TOKEN_COSMOS_BRICK_SIZING_HALO_LARGE: function() {
                    return wR
                },
                TOKEN_COSMOS_BRICK_SIZING_HALO_MEDIUM: function() {
                    return gR
                },
                TOKEN_COSMOS_BRICK_SIZING_HALO_SMALL: function() {
                    return vR
                },
                TOKEN_COSMOS_BRICK_SIZING_HALO_XLARGE: function() {
                    return jR
                },
                TOKEN_COSMOS_BRICK_SIZING_HALO_XSMALL: function() {
                    return qR
                },
                TOKEN_COSMOS_BRICK_SIZING_ICON_DEFAULT_LARGE: function() {
                    return $R
                },
                TOKEN_COSMOS_BRICK_SIZING_ICON_DEFAULT_MEDIUM: function() {
                    return _t
                },
                TOKEN_COSMOS_BRICK_SIZING_ICON_DEFAULT_XLARGE: function() {
                    return Ot
                },
                TOKEN_COSMOS_BRICK_SIZING_ICON_OVERLAY_LARGE: function() {
                    return Tt
                },
                TOKEN_COSMOS_BRICK_SIZING_ICON_OVERLAY_MEDIUM: function() {
                    return Et
                },
                TOKEN_COSMOS_BRICK_SIZING_ICON_OVERLAY_SMALL: function() {
                    return nt
                },
                TOKEN_COSMOS_BRICK_SIZING_ICON_OVERLAY_XLARGE: function() {
                    return Nt
                },
                TOKEN_COSMOS_BRICK_SIZING_ICON_OVERLAY_XSMALL: function() {
                    return St
                },
                TOKEN_COSMOS_BRICK_SPACING_OFFSET_CIRCLE_HORIZONTAL_LARGE: function() {
                    return Ct
                },
                TOKEN_COSMOS_BRICK_SPACING_OFFSET_CIRCLE_HORIZONTAL_MEDIUM: function() {
                    return At
                },
                TOKEN_COSMOS_BRICK_SPACING_OFFSET_CIRCLE_HORIZONTAL_SMALL: function() {
                    return It
                },
                TOKEN_COSMOS_BRICK_SPACING_OFFSET_CIRCLE_HORIZONTAL_XLARGE: function() {
                    return Rt
                },
                TOKEN_COSMOS_BRICK_SPACING_OFFSET_CIRCLE_HORIZONTAL_XSMALL: function() {
                    return tt
                },
                TOKEN_COSMOS_BRICK_SPACING_OFFSET_CIRCLE_VERTICAL_LARGE: function() {
                    return ut
                },
                TOKEN_COSMOS_BRICK_SPACING_OFFSET_CIRCLE_VERTICAL_MEDIUM: function() {
                    return rt
                },
                TOKEN_COSMOS_BRICK_SPACING_OFFSET_CIRCLE_VERTICAL_SMALL: function() {
                    return Mt
                },
                TOKEN_COSMOS_BRICK_SPACING_OFFSET_CIRCLE_VERTICAL_XLARGE: function() {
                    return Lt
                },
                TOKEN_COSMOS_BRICK_SPACING_OFFSET_CIRCLE_VERTICAL_XSMALL: function() {
                    return Kt
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_IN_IS_CONTINUATION_BOTTOM_LEFT: function() {
                    return Dt
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_IN_IS_CONTINUATION_BOTTOM_RIGHT: function() {
                    return et
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_IN_IS_CONTINUATION_TOP_LEFT: function() {
                    return it
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_IN_IS_CONTINUATION_TOP_RIGHT: function() {
                    return ot
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_IN_NOT_CONTINUATION_BOTTOM_LEFT: function() {
                    return ct
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_IN_NOT_CONTINUATION_BOTTOM_RIGHT: function() {
                    return Ft
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_IN_NOT_CONTINUATION_TOP_LEFT: function() {
                    return ft
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_IN_NOT_CONTINUATION_TOP_RIGHT: function() {
                    return Gt
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_OUT_IS_CONTINUATION_BOTTOM_LEFT: function() {
                    return Pt
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_OUT_IS_CONTINUATION_BOTTOM_RIGHT: function() {
                    return Bt
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_OUT_IS_CONTINUATION_TOP_LEFT: function() {
                    return Ut
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_OUT_IS_CONTINUATION_TOP_RIGHT: function() {
                    return Ht
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_OUT_NOT_CONTINUATION_BOTTOM_LEFT: function() {
                    return pt
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_OUT_NOT_CONTINUATION_BOTTOM_RIGHT: function() {
                    return xt
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_OUT_NOT_CONTINUATION_TOP_LEFT: function() {
                    return Yt
                },
                TOKEN_COSMOS_BUBBLE_BORDER_RADIUS_OUT_NOT_CONTINUATION_TOP_RIGHT: function() {
                    return Vt
                },
                TOKEN_COSMOS_BUBBLE_COLOR_BACKGROUND_GRAY: function() {
                    return Wt
                },
                TOKEN_COSMOS_BUBBLE_COLOR_BACKGROUND_PRIMARY: function() {
                    return Zt
                },
                TOKEN_COSMOS_BUBBLE_COLOR_BACKGROUND_QUESTION: function() {
                    return Xt
                },
                TOKEN_COSMOS_BUBBLE_COLOR_BACKGROUND_WHITE: function() {
                    return st
                },
                TOKEN_COSMOS_BUBBLE_COLOR_CONTENT: function() {
                    return lt
                },
                TOKEN_COSMOS_BUBBLE_SPACING_HORIZONTAL: function() {
                    return mt
                },
                TOKEN_COSMOS_BUBBLE_SPACING_VERTICAL: function() {
                    return at
                },
                TOKEN_COSMOS_BUBBLE_TYPOGRAPHY_CONTENT: function() {
                    return bt
                },
                TOKEN_COSMOS_BUTTON_BORDER_RADIUS_MEDIUM: function() {
                    return dt
                },
                TOKEN_COSMOS_BUTTON_BORDER_RADIUS_MICRO: function() {
                    return yt
                },
                TOKEN_COSMOS_BUTTON_BORDER_RADIUS_MINI: function() {
                    return Qt
                },
                TOKEN_COSMOS_BUTTON_BORDER_RADIUS_SMALL: function() {
                    return kt
                },
                TOKEN_COSMOS_BUTTON_BORDER_WIDTH_PRIMARY_DEFAULT: function() {
                    return Jt
                },
                TOKEN_COSMOS_BUTTON_BORDER_WIDTH_PRIMARY_DESTRUCTIVE: function() {
                    return ht
                },
                TOKEN_COSMOS_BUTTON_BORDER_WIDTH_PRIMARY_INVERSE: function() {
                    return zt
                },
                TOKEN_COSMOS_BUTTON_BORDER_WIDTH_SECONDARY_DEFAULT: function() {
                    return wt
                },
                TOKEN_COSMOS_BUTTON_BORDER_WIDTH_SECONDARY_DESTRUCTIVE: function() {
                    return gt
                },
                TOKEN_COSMOS_BUTTON_BORDER_WIDTH_SECONDARY_INVERSE: function() {
                    return vt
                },
                TOKEN_COSMOS_BUTTON_BORDER_WIDTH_TERTIARY_DEFAULT: function() {
                    return jt
                },
                TOKEN_COSMOS_BUTTON_BORDER_WIDTH_TERTIARY_DESTRUCTIVE: function() {
                    return qt
                },
                TOKEN_COSMOS_BUTTON_BORDER_WIDTH_TERTIARY_INVERSE: function() {
                    return $t
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_OVERLAY_BASE_HOVER: function() {
                    return _u
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_OVERLAY_BASE_PRESSED: function() {
                    return Ou
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_OVERLAY_INVERSE_HOVER: function() {
                    return Tu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_OVERLAY_INVERSE_PRESSED: function() {
                    return Eu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_APPLE: function() {
                    return nu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_DEFAULT: function() {
                    return Nu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_DESTRUCTIVE: function() {
                    return Su
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_FACEBOOK: function() {
                    return Cu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_GOOGLE: function() {
                    return Au
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_INSTAGRAM: function() {
                    return Iu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_INVERSE: function() {
                    return Ru
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_LINKEDIN: function() {
                    return tu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_ODNOKLASSNIKI: function() {
                    return uu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_SPOTIFY: function() {
                    return ru
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_TWITTER: function() {
                    return Mu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_VKONTAKTE: function() {
                    return Lu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_SECONDARY_DEFAULT: function() {
                    return Ku
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_SECONDARY_DESTRUCTIVE: function() {
                    return Du
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_SECONDARY_INVERSE: function() {
                    return eu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_TERTIARY_DEFAULT: function() {
                    return iu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_TERTIARY_DESTRUCTIVE: function() {
                    return ou
                },
                TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_TERTIARY_INVERSE: function() {
                    return cu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_APPLE: function() {
                    return Fu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_DEFAULT: function() {
                    return fu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_DESTRUCTIVE: function() {
                    return Gu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_FACEBOOK: function() {
                    return Pu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_GOOGLE: function() {
                    return Bu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_INSTAGRAM: function() {
                    return Uu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_INVERSE: function() {
                    return Hu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_LINKEDIN: function() {
                    return pu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_ODNOKLASSNIKI: function() {
                    return xu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_SPOTIFY: function() {
                    return Yu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_TWITTER: function() {
                    return Vu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_VKONTAKTE: function() {
                    return Wu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_SECONDARY_DEFAULT: function() {
                    return Zu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_SECONDARY_DESTRUCTIVE: function() {
                    return Xu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_SECONDARY_INVERSE: function() {
                    return su
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_TERTIARY_DEFAULT: function() {
                    return lu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_TERTIARY_DESTRUCTIVE: function() {
                    return mu
                },
                TOKEN_COSMOS_BUTTON_COLOR_BORDER_TERTIARY_INVERSE: function() {
                    return au
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_APPLE: function() {
                    return bu
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_DEFAULT: function() {
                    return du
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_DESTRUCTIVE: function() {
                    return yu
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_FACEBOOK: function() {
                    return Qu
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_GOOGLE: function() {
                    return ku
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_INSTAGRAM: function() {
                    return Ju
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_INVERSE: function() {
                    return hu
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_LINKEDIN: function() {
                    return zu
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_ODNOKLASSNIKI: function() {
                    return wu
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_SPOTIFY: function() {
                    return gu
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_TWITTER: function() {
                    return vu
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_VKONTAKTE: function() {
                    return ju
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_SECONDARY_DEFAULT: function() {
                    return qu
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_SECONDARY_DESTRUCTIVE: function() {
                    return $u
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_SECONDARY_INVERSE: function() {
                    return _r
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_TERTIARY_DEFAULT: function() {
                    return Or
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_TERTIARY_DESTRUCTIVE: function() {
                    return Tr
                },
                TOKEN_COSMOS_BUTTON_COLOR_CONTENT_TERTIARY_INVERSE: function() {
                    return Er
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_APPLE: function() {
                    return nr
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_DEFAULT: function() {
                    return Nr
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_DESTRUCTIVE: function() {
                    return Sr
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_FACEBOOK: function() {
                    return Cr
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_GOOGLE: function() {
                    return Ar
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_INSTAGRAM: function() {
                    return Ir
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_INVERSE: function() {
                    return Rr
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_LINKEDIN: function() {
                    return tr
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_ODNOKLASSNIKI: function() {
                    return ur
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_SPOTIFY: function() {
                    return rr
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_TWITTER: function() {
                    return Mr
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_VKONTAKTE: function() {
                    return Lr
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_SECONDARY_DEFAULT: function() {
                    return Kr
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_SECONDARY_DESTRUCTIVE: function() {
                    return Dr
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_SECONDARY_INVERSE: function() {
                    return er
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_TERTIARY_DEFAULT: function() {
                    return ir
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_TERTIARY_DESTRUCTIVE: function() {
                    return or
                },
                TOKEN_COSMOS_BUTTON_COLOR_ICON_TERTIARY_INVERSE: function() {
                    return cr
                },
                TOKEN_COSMOS_BUTTON_SIZING_ICON_MEDIUM: function() {
                    return Fr
                },
                TOKEN_COSMOS_BUTTON_SIZING_ICON_MICRO: function() {
                    return fr
                },
                TOKEN_COSMOS_BUTTON_SIZING_ICON_MINI: function() {
                    return Gr
                },
                TOKEN_COSMOS_BUTTON_SIZING_ICON_SMALL: function() {
                    return Pr
                },
                TOKEN_COSMOS_BUTTON_SIZING_MAX_WIDTH: function() {
                    return Br
                },
                TOKEN_COSMOS_BUTTON_SIZING_MIN_HEIGHT_MEDIUM: function() {
                    return Ur
                },
                TOKEN_COSMOS_BUTTON_SIZING_MIN_HEIGHT_MICRO: function() {
                    return Hr
                },
                TOKEN_COSMOS_BUTTON_SIZING_MIN_HEIGHT_MINI: function() {
                    return pr
                },
                TOKEN_COSMOS_BUTTON_SIZING_MIN_HEIGHT_SMALL: function() {
                    return xr
                },
                TOKEN_COSMOS_BUTTON_SPACING_GAP_MEDIUM: function() {
                    return Yr
                },
                TOKEN_COSMOS_BUTTON_SPACING_GAP_MICRO: function() {
                    return Vr
                },
                TOKEN_COSMOS_BUTTON_SPACING_GAP_MINI: function() {
                    return Wr
                },
                TOKEN_COSMOS_BUTTON_SPACING_GAP_SMALL: function() {
                    return Zr
                },
                TOKEN_COSMOS_BUTTON_SPACING_HORIZONTAL_MEDIUM: function() {
                    return Xr
                },
                TOKEN_COSMOS_BUTTON_SPACING_HORIZONTAL_MICRO: function() {
                    return sr
                },
                TOKEN_COSMOS_BUTTON_SPACING_HORIZONTAL_MINI: function() {
                    return lr
                },
                TOKEN_COSMOS_BUTTON_SPACING_HORIZONTAL_SMALL: function() {
                    return mr
                },
                TOKEN_COSMOS_BUTTON_SPACING_VERTICAL_MEDIUM: function() {
                    return ar
                },
                TOKEN_COSMOS_BUTTON_SPACING_VERTICAL_MICRO: function() {
                    return br
                },
                TOKEN_COSMOS_BUTTON_SPACING_VERTICAL_MINI: function() {
                    return dr
                },
                TOKEN_COSMOS_BUTTON_SPACING_VERTICAL_SMALL: function() {
                    return yr
                },
                TOKEN_COSMOS_BUTTON_TYPOGRAPHY_MEDIUM: function() {
                    return Qr
                },
                TOKEN_COSMOS_BUTTON_TYPOGRAPHY_MICRO: function() {
                    return kr
                },
                TOKEN_COSMOS_BUTTON_TYPOGRAPHY_MINI: function() {
                    return Jr
                },
                TOKEN_COSMOS_BUTTON_TYPOGRAPHY_SMALL: function() {
                    return hr
                },
                TOKEN_COSMOS_CARD_BORDER_RADIUS: function() {
                    return zr
                },
                TOKEN_COSMOS_CARD_BORDER_WIDTH_ACCENT: function() {
                    return wr
                },
                TOKEN_COSMOS_CARD_BORDER_WIDTH_PRIMARY: function() {
                    return gr
                },
                TOKEN_COSMOS_CARD_BORDER_WIDTH_SECONDARY: function() {
                    return vr
                },
                TOKEN_COSMOS_CARD_BORDER_WIDTH_TERTIARY: function() {
                    return jr
                },
                TOKEN_COSMOS_CARD_COLOR_BACKGROUND_ACCENT_DEFAULT: function() {
                    return qr
                },
                TOKEN_COSMOS_CARD_COLOR_BACKGROUND_ACCENT_TRANSPARENT: function() {
                    return $r
                },
                TOKEN_COSMOS_CARD_COLOR_BACKGROUND_PRIMARY_DEFAULT: function() {
                    return _M
                },
                TOKEN_COSMOS_CARD_COLOR_BACKGROUND_PRIMARY_TRANSPARENT: function() {
                    return OM
                },
                TOKEN_COSMOS_CARD_COLOR_BACKGROUND_SECONDARY_DEFAULT: function() {
                    return TM
                },
                TOKEN_COSMOS_CARD_COLOR_BACKGROUND_SECONDARY_TRANSPARENT: function() {
                    return EM
                },
                TOKEN_COSMOS_CARD_COLOR_BACKGROUND_TERTIARY_DEFAULT: function() {
                    return nM
                },
                TOKEN_COSMOS_CARD_COLOR_BACKGROUND_TERTIARY_TRANSPARENT: function() {
                    return NM
                },
                TOKEN_COSMOS_CARD_COLOR_BORDER_ACCENT: function() {
                    return SM
                },
                TOKEN_COSMOS_CARD_COLOR_BORDER_PRIMARY: function() {
                    return CM
                },
                TOKEN_COSMOS_CARD_COLOR_BORDER_SECONDARY: function() {
                    return AM
                },
                TOKEN_COSMOS_CARD_COLOR_BORDER_TERTIARY: function() {
                    return IM
                },
                TOKEN_COSMOS_CARD_SHADOW_PRIMARY_BLUR: function() {
                    return RM
                },
                TOKEN_COSMOS_CARD_SHADOW_PRIMARY_COLOR: function() {
                    return tM
                },
                TOKEN_COSMOS_CARD_SHADOW_PRIMARY_SPREAD: function() {
                    return uM
                },
                TOKEN_COSMOS_CARD_SHADOW_PRIMARY_X: function() {
                    return rM
                },
                TOKEN_COSMOS_CARD_SHADOW_PRIMARY_Y: function() {
                    return MM
                },
                TOKEN_COSMOS_CARD_SIZING_BACKGROUND_BLUR_ACCENT: function() {
                    return LM
                },
                TOKEN_COSMOS_CARD_SIZING_BACKGROUND_BLUR_PRIMARY: function() {
                    return KM
                },
                TOKEN_COSMOS_CARD_SIZING_BACKGROUND_BLUR_SECONDARY: function() {
                    return DM
                },
                TOKEN_COSMOS_CARD_SIZING_BACKGROUND_BLUR_TERTIARY: function() {
                    return eM
                },
                TOKEN_COSMOS_CARD_SPACING_HORIZONTAL_MEDIUM: function() {
                    return iM
                },
                TOKEN_COSMOS_CARD_SPACING_HORIZONTAL_SMALL: function() {
                    return oM
                },
                TOKEN_COSMOS_CARD_SPACING_VERTICAL_MEDIUM: function() {
                    return cM
                },
                TOKEN_COSMOS_CARD_SPACING_VERTICAL_SMALL: function() {
                    return FM
                },
                TOKEN_COSMOS_CAROUSEL_COLOR_BACKGROUND: function() {
                    return fM
                },
                TOKEN_COSMOS_CAROUSEL_COLOR_ICON_FOREGROUND: function() {
                    return GM
                },
                TOKEN_COSMOS_CAROUSEL_SPACING_GAP: function() {
                    return PM
                },
                TOKEN_COSMOS_CAROUSEL_SPACING_HORIZONTAL_LEFT: function() {
                    return BM
                },
                TOKEN_COSMOS_CAROUSEL_SPACING_HORIZONTAL_RIGHT: function() {
                    return UM
                },
                TOKEN_COSMOS_CAROUSEL_SPACING_VERTICAL: function() {
                    return HM
                },
                TOKEN_COSMOS_CHECKBOX_BORDER_RADIUS: function() {
                    return pM
                },
                TOKEN_COSMOS_CHECKBOX_BORDER_WIDTH_DEFAULT_ERROR: function() {
                    return xM
                },
                TOKEN_COSMOS_CHECKBOX_BORDER_WIDTH_DEFAULT_SELECTED: function() {
                    return YM
                },
                TOKEN_COSMOS_CHECKBOX_BORDER_WIDTH_DEFAULT_UNSELECTED: function() {
                    return VM
                },
                TOKEN_COSMOS_CHECKBOX_BORDER_WIDTH_INVERSE_ERROR: function() {
                    return WM
                },
                TOKEN_COSMOS_CHECKBOX_BORDER_WIDTH_INVERSE_SELECTED: function() {
                    return ZM
                },
                TOKEN_COSMOS_CHECKBOX_BORDER_WIDTH_INVERSE_UNSELECTED: function() {
                    return XM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_BACKGROUND_DEFAULT_ERROR: function() {
                    return sM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_BACKGROUND_DEFAULT_SELECTED: function() {
                    return lM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_BACKGROUND_DEFAULT_UNSELECTED: function() {
                    return mM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_BACKGROUND_INVERSE_ERROR: function() {
                    return aM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_BACKGROUND_INVERSE_SELECTED: function() {
                    return bM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_BACKGROUND_INVERSE_UNSELECTED: function() {
                    return dM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_BORDER_DEFAULT_ERROR: function() {
                    return yM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_BORDER_DEFAULT_SELECTED: function() {
                    return QM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_BORDER_DEFAULT_UNSELECTED: function() {
                    return kM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_BORDER_INVERSE_ERROR: function() {
                    return JM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_BORDER_INVERSE_SELECTED: function() {
                    return hM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_BORDER_INVERSE_UNSELECTED: function() {
                    return zM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_ICON_DEFAULT_ERROR: function() {
                    return wM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_ICON_DEFAULT_SELECTED: function() {
                    return gM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_ICON_DEFAULT_UNSELECTED: function() {
                    return vM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_ICON_INVERSE_ERROR: function() {
                    return jM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_ICON_INVERSE_SELECTED: function() {
                    return qM
                },
                TOKEN_COSMOS_CHECKBOX_COLOR_ICON_INVERSE_UNSELECTED: function() {
                    return $M
                },
                TOKEN_COSMOS_CHECKBOX_SIZING_CONTAINER: function() {
                    return _L
                },
                TOKEN_COSMOS_CHECKBOX_SIZING_ICON: function() {
                    return OL
                },
                TOKEN_COSMOS_CTABOX_COLOR_CONTENT_DESCRIPTION: function() {
                    return TL
                },
                TOKEN_COSMOS_CTABOX_COLOR_CONTENT_HINT: function() {
                    return EL
                },
                TOKEN_COSMOS_CTABOX_COLOR_CONTENT_TITLE: function() {
                    return nL
                },
                TOKEN_COSMOS_CTABOX_SIZING_BADGE: function() {
                    return NL
                },
                TOKEN_COSMOS_CTABOX_SPACING_GAP_LARGE: function() {
                    return SL
                },
                TOKEN_COSMOS_CTABOX_SPACING_GAP_MEDIUM: function() {
                    return CL
                },
                TOKEN_COSMOS_CTABOX_SPACING_GAP_SMALL: function() {
                    return AL
                },
                TOKEN_COSMOS_CTABOX_SPACING_GAP_XSMALL: function() {
                    return IL
                },
                TOKEN_COSMOS_CTABOX_TYPOGRAPHY_DESCRIPTION: function() {
                    return RL
                },
                TOKEN_COSMOS_CTABOX_TYPOGRAPHY_HINT: function() {
                    return tL
                },
                TOKEN_COSMOS_CTABOX_TYPOGRAPHY_TITLE: function() {
                    return uL
                },
                TOKEN_COSMOS_DIVIDER_BORDER_WIDTH_INTERACTIVE: function() {
                    return rL
                },
                TOKEN_COSMOS_DIVIDER_BORDER_WIDTH_SUPPORTIVE: function() {
                    return ML
                },
                TOKEN_COSMOS_DIVIDER_COLOR_BORDER_INTERACTIVE: function() {
                    return LL
                },
                TOKEN_COSMOS_DIVIDER_COLOR_BORDER_SUPPORTIVE: function() {
                    return KL
                },
                TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_BORDER_RADIUS: function() {
                    return DL
                },
                TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_BORDER_WIDTH_DEFAULT: function() {
                    return eL
                },
                TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_BORDER_WIDTH_NONE: function() {
                    return iL
                },
                TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_COLOR_BACKGROUND: function() {
                    return oL
                },
                TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_COLOR_BORDER_DEFAULT: function() {
                    return cL
                },
                TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_COLOR_BORDER_NONE: function() {
                    return FL
                },
                TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_COLOR_CONTENT: function() {
                    return fL
                },
                TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_SIZING_CIRCLE: function() {
                    return GL
                },
                TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_SIZING_MIN_WIDTH: function() {
                    return PL
                },
                TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_SPACING_HORIZONTAL: function() {
                    return BL
                },
                TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_SPACING_VERTICAL: function() {
                    return UL
                },
                TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_TYPOGRAPHY_CONTENT: function() {
                    return HL
                },
                TOKEN_COSMOS_EMPTYSTATE_COLOR_DESCRIPTION: function() {
                    return pL
                },
                TOKEN_COSMOS_EMPTYSTATE_COLOR_TITLE: function() {
                    return xL
                },
                TOKEN_COSMOS_EMPTYSTATE_SPACING_VERTICAL_LARGE: function() {
                    return YL
                },
                TOKEN_COSMOS_EMPTYSTATE_SPACING_VERTICAL_MEDIUM: function() {
                    return VL
                },
                TOKEN_COSMOS_EMPTYSTATE_SPACING_VERTICAL_SMALL: function() {
                    return WL
                },
                TOKEN_COSMOS_EMPTYSTATE_TYPOGRAPHY_DESCRIPTION: function() {
                    return ZL
                },
                TOKEN_COSMOS_EMPTYSTATE_TYPOGRAPHY_TITLE: function() {
                    return XL
                },
                TOKEN_COSMOS_FILTERS_BORDER_RADIUS: function() {
                    return sL
                },
                TOKEN_COSMOS_FILTERS_BORDER_WIDTH_DEFAULT: function() {
                    return lL
                },
                TOKEN_COSMOS_FILTERS_BORDER_WIDTH_SELECTED: function() {
                    return mL
                },
                TOKEN_COSMOS_FILTERS_COLOR_BACKGROUND_DEFAULT: function() {
                    return aL
                },
                TOKEN_COSMOS_FILTERS_COLOR_BACKGROUND_OVERLAY_HOVER: function() {
                    return bL
                },
                TOKEN_COSMOS_FILTERS_COLOR_BACKGROUND_OVERLAY_PRESSED: function() {
                    return dL
                },
                TOKEN_COSMOS_FILTERS_COLOR_BACKGROUND_SELECTED: function() {
                    return yL
                },
                TOKEN_COSMOS_FILTERS_COLOR_BORDER_DEFAULT: function() {
                    return QL
                },
                TOKEN_COSMOS_FILTERS_COLOR_BORDER_SELECTED: function() {
                    return kL
                },
                TOKEN_COSMOS_FILTERS_COLOR_CONTENT_DEFAULT: function() {
                    return JL
                },
                TOKEN_COSMOS_FILTERS_COLOR_CONTENT_SELECTED: function() {
                    return hL
                },
                TOKEN_COSMOS_FILTERS_COLOR_ICON_DEFAULT: function() {
                    return zL
                },
                TOKEN_COSMOS_FILTERS_COLOR_ICON_SELECTED: function() {
                    return wL
                },
                TOKEN_COSMOS_FILTERS_SIZING_ASSET: function() {
                    return gL
                },
                TOKEN_COSMOS_FILTERS_SIZING_EMOJI: function() {
                    return vL
                },
                TOKEN_COSMOS_FILTERS_SIZING_ICON: function() {
                    return jL
                },
                TOKEN_COSMOS_FILTERS_SIZING_MIN_HEIGHT: function() {
                    return qL
                },
                TOKEN_COSMOS_FILTERS_SIZING_NAVIGATION: function() {
                    return $L
                },
                TOKEN_COSMOS_FILTERS_SPACING_GAP_MEDIUM: function() {
                    return _K
                },
                TOKEN_COSMOS_FILTERS_SPACING_GAP_SMALL: function() {
                    return OK
                },
                TOKEN_COSMOS_FILTERS_SPACING_HORIZONTAL: function() {
                    return TK
                },
                TOKEN_COSMOS_FILTERS_SPACING_VERTICAL: function() {
                    return EK
                },
                TOKEN_COSMOS_FILTERS_TYPOGRAPHY_CONTENT: function() {
                    return nK
                },
                TOKEN_COSMOS_FORMS_BORDER_RADIUS_ROUNDED: function() {
                    return NK
                },
                TOKEN_COSMOS_FORMS_BORDER_RADIUS_SQUARED: function() {
                    return SK
                },
                TOKEN_COSMOS_FORMS_BORDER_WIDTH_ERROR: function() {
                    return CK
                },
                TOKEN_COSMOS_FORMS_BORDER_WIDTH_FOCUS: function() {
                    return AK
                },
                TOKEN_COSMOS_FORMS_BORDER_WIDTH_RESTING: function() {
                    return IK
                },
                TOKEN_COSMOS_FORMS_BORDER_WIDTH_SUCCESS: function() {
                    return RK
                },
                TOKEN_COSMOS_FORMS_COLOR_BACKGROUND_DEFAULT: function() {
                    return tK
                },
                TOKEN_COSMOS_FORMS_COLOR_BACKGROUND_FOCUS: function() {
                    return uK
                },
                TOKEN_COSMOS_FORMS_COLOR_BAR: function() {
                    return rK
                },
                TOKEN_COSMOS_FORMS_COLOR_BORDER_ERROR: function() {
                    return MK
                },
                TOKEN_COSMOS_FORMS_COLOR_BORDER_FOCUS: function() {
                    return LK
                },
                TOKEN_COSMOS_FORMS_COLOR_BORDER_RESTING: function() {
                    return KK
                },
                TOKEN_COSMOS_FORMS_COLOR_BORDER_SUCCESS: function() {
                    return DK
                },
                TOKEN_COSMOS_FORMS_COLOR_CONTENT_ACTION: function() {
                    return eK
                },
                TOKEN_COSMOS_FORMS_COLOR_CONTENT_COUNTER_DEFAULT: function() {
                    return iK
                },
                TOKEN_COSMOS_FORMS_COLOR_CONTENT_COUNTER_ERROR: function() {
                    return oK
                },
                TOKEN_COSMOS_FORMS_COLOR_CONTENT_COUNTER_SUCCESS: function() {
                    return cK
                },
                TOKEN_COSMOS_FORMS_COLOR_CONTENT_LABEL: function() {
                    return FK
                },
                TOKEN_COSMOS_FORMS_COLOR_CONTENT_OPTIONAL: function() {
                    return fK
                },
                TOKEN_COSMOS_FORMS_COLOR_CONTENT_PLACEHOLDER: function() {
                    return GK
                },
                TOKEN_COSMOS_FORMS_COLOR_CONTENT_PREFIX: function() {
                    return PK
                },
                TOKEN_COSMOS_FORMS_COLOR_CONTENT_SUFIX: function() {
                    return BK
                },
                TOKEN_COSMOS_FORMS_COLOR_ICON_DEFAULT: function() {
                    return UK
                },
                TOKEN_COSMOS_FORMS_COLOR_ITEM_BACKGROUND_DEFAULT: function() {
                    return HK
                },
                TOKEN_COSMOS_FORMS_COLOR_ITEM_BACKGROUND_SELECTED: function() {
                    return pK
                },
                TOKEN_COSMOS_FORMS_COLOR_ITEM_CONTENT: function() {
                    return xK
                },
                TOKEN_COSMOS_FORMS_COLOR_ITEM_ICON: function() {
                    return YK
                },
                TOKEN_COSMOS_FORMS_SIZING_ICON_MEDIUM: function() {
                    return VK
                },
                TOKEN_COSMOS_FORMS_SIZING_ICON_SMALL: function() {
                    return WK
                },
                TOKEN_COSMOS_FORMS_SPACING_GAP_HORIZONTAL_MEDIUM: function() {
                    return ZK
                },
                TOKEN_COSMOS_FORMS_SPACING_GAP_HORIZONTAL_SMALL: function() {
                    return XK
                },
                TOKEN_COSMOS_FORMS_SPACING_GAP_HORIZONTAL_XSMALL: function() {
                    return sK
                },
                TOKEN_COSMOS_FORMS_SPACING_GAP_HORIZONTAL_XXSMALL: function() {
                    return lK
                },
                TOKEN_COSMOS_FORMS_SPACING_GAP_VERTICAL_MEDIUM: function() {
                    return mK
                },
                TOKEN_COSMOS_FORMS_SPACING_GAP_VERTICAL_SMALL: function() {
                    return aK
                },
                TOKEN_COSMOS_FORMS_SPACING_HORIZONTAL_MEDIUM: function() {
                    return bK
                },
                TOKEN_COSMOS_FORMS_SPACING_HORIZONTAL_SMALL: function() {
                    return dK
                },
                TOKEN_COSMOS_FORMS_SPACING_ITEM_GAP: function() {
                    return yK
                },
                TOKEN_COSMOS_FORMS_SPACING_ITEM_HORIZONTAL: function() {
                    return QK
                },
                TOKEN_COSMOS_FORMS_SPACING_ITEM_VERTICAL: function() {
                    return kK
                },
                TOKEN_COSMOS_FORMS_SPACING_VERTICAL_MEDIUM: function() {
                    return JK
                },
                TOKEN_COSMOS_FORMS_SPACING_VERTICAL_SMALL: function() {
                    return hK
                },
                TOKEN_COSMOS_FORMS_SPACING_VERTICAL_XSMALL: function() {
                    return zK
                },
                TOKEN_COSMOS_FORMS_TYPOGRAPHY_ACTION: function() {
                    return wK
                },
                TOKEN_COSMOS_FORMS_TYPOGRAPHY_COUNTER: function() {
                    return gK
                },
                TOKEN_COSMOS_FORMS_TYPOGRAPHY_ITEM: function() {
                    return vK
                },
                TOKEN_COSMOS_FORMS_TYPOGRAPHY_LABEL: function() {
                    return jK
                },
                TOKEN_COSMOS_FORMS_TYPOGRAPHY_OPTIONAL: function() {
                    return qK
                },
                TOKEN_COSMOS_FORMS_TYPOGRAPHY_PLACEHOLDER: function() {
                    return $K
                },
                TOKEN_COSMOS_FORMS_TYPOGRAPHY_PREFIX: function() {
                    return _D
                },
                TOKEN_COSMOS_FORMS_TYPOGRAPHY_SUFIX: function() {
                    return OD
                },
                TOKEN_COSMOS_HELPERTEXT_COLOR_CONTENT_DEFAULT: function() {
                    return TD
                },
                TOKEN_COSMOS_HELPERTEXT_COLOR_CONTENT_ERROR: function() {
                    return ED
                },
                TOKEN_COSMOS_HELPERTEXT_COLOR_CONTENT_SUCCESS: function() {
                    return nD
                },
                TOKEN_COSMOS_HELPERTEXT_COLOR_ICON_DEFAULT: function() {
                    return ND
                },
                TOKEN_COSMOS_HELPERTEXT_COLOR_ICON_ERROR: function() {
                    return SD
                },
                TOKEN_COSMOS_HELPERTEXT_COLOR_ICON_SUCCESS: function() {
                    return CD
                },
                TOKEN_COSMOS_HELPERTEXT_SIZING_ICON: function() {
                    return AD
                },
                TOKEN_COSMOS_HELPERTEXT_SPACING_GAP: function() {
                    return ID
                },
                TOKEN_COSMOS_HELPERTEXT_SPACING_VERTICAL: function() {
                    return RD
                },
                TOKEN_COSMOS_HELPERTEXT_TYPOGRAPHY_CONTENT: function() {
                    return tD
                },
                TOKEN_COSMOS_ICONBUTTON_BORDER_RADIUS_LARGE: function() {
                    return uD
                },
                TOKEN_COSMOS_ICONBUTTON_BORDER_RADIUS_MEDIUM: function() {
                    return rD
                },
                TOKEN_COSMOS_ICONBUTTON_BORDER_RADIUS_SMALL: function() {
                    return MD
                },
                TOKEN_COSMOS_ICONBUTTON_BORDER_RADIUS_XLARGE: function() {
                    return LD
                },
                TOKEN_COSMOS_ICONBUTTON_BORDER_WIDTH_ACCENT: function() {
                    return KD
                },
                TOKEN_COSMOS_ICONBUTTON_BORDER_WIDTH_OUTLINE: function() {
                    return DD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_BACKGROUND_DEFAULT_ACCENT: function() {
                    return eD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_BACKGROUND_DEFAULT_INVERSE: function() {
                    return iD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_BACKGROUND_DEFAULT_LAYERED: function() {
                    return oD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_BACKGROUND_DEFAULT_OUTLINE: function() {
                    return cD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_BACKGROUND_DEFAULT_SOLID: function() {
                    return FD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_BACKGROUND_DEFAULT_TRANSPARENT: function() {
                    return fD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_BACKGROUND_DISABLED_ACCENT: function() {
                    return GD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_BACKGROUND_DISABLED_INVERSE: function() {
                    return PD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_BACKGROUND_DISABLED_LAYERED: function() {
                    return BD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_BACKGROUND_DISABLED_OUTLINE: function() {
                    return UD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_BACKGROUND_DISABLED_SOLID: function() {
                    return HD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_BACKGROUND_DISABLED_TRANSPARENT: function() {
                    return pD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_BORDER_ACCENT: function() {
                    return xD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_BORDER_OUTLINE: function() {
                    return YD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_ICON_DEFAULT_ACCENT: function() {
                    return VD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_ICON_DEFAULT_INVERSE: function() {
                    return WD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_ICON_DEFAULT_LAYERED: function() {
                    return ZD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_ICON_DEFAULT_OUTLINE: function() {
                    return XD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_ICON_DEFAULT_SOLID: function() {
                    return sD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_ICON_DEFAULT_TRANSPARENT: function() {
                    return lD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_ICON_DISABLED_ACCENT: function() {
                    return mD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_ICON_DISABLED_INVERSE: function() {
                    return aD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_ICON_DISABLED_LAYERED: function() {
                    return bD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_ICON_DISABLED_OUTLINE: function() {
                    return dD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_ICON_DISABLED_SOLID: function() {
                    return yD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_ICON_DISABLED_TRANSPARENT: function() {
                    return QD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_REACTIVE_DEFAULT_HOVER: function() {
                    return kD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_REACTIVE_DEFAULT_PRESSED: function() {
                    return JD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_REACTIVE_INVERSE_HOVER: function() {
                    return hD
                },
                TOKEN_COSMOS_ICONBUTTON_COLOR_REACTIVE_INVERSE_PRESSED: function() {
                    return zD
                },
                TOKEN_COSMOS_ICONBUTTON_SIZING_LARGE_CONTAINER: function() {
                    return wD
                },
                TOKEN_COSMOS_ICONBUTTON_SIZING_LARGE_ICON: function() {
                    return gD
                },
                TOKEN_COSMOS_ICONBUTTON_SIZING_LARGE_WRAPPER: function() {
                    return vD
                },
                TOKEN_COSMOS_ICONBUTTON_SIZING_MEDIUM_CONTAINER: function() {
                    return jD
                },
                TOKEN_COSMOS_ICONBUTTON_SIZING_MEDIUM_ICON: function() {
                    return qD
                },
                TOKEN_COSMOS_ICONBUTTON_SIZING_MEDIUM_WRAPPER: function() {
                    return $D
                },
                TOKEN_COSMOS_ICONBUTTON_SIZING_SMALL_CONTAINER: function() {
                    return _e
                },
                TOKEN_COSMOS_ICONBUTTON_SIZING_SMALL_ICON: function() {
                    return Oe
                },
                TOKEN_COSMOS_ICONBUTTON_SIZING_SMALL_WRAPPER: function() {
                    return Te
                },
                TOKEN_COSMOS_ICONBUTTON_SIZING_XLARGE_CONTAINER: function() {
                    return Ee
                },
                TOKEN_COSMOS_ICONBUTTON_SIZING_XLARGE_ICON: function() {
                    return ne
                },
                TOKEN_COSMOS_ICONBUTTON_SIZING_XLARGE_WRAPPER: function() {
                    return Ne
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_BORDER_RADIUS: function() {
                    return Se
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_BORDER_WIDTH: function() {
                    return Ce
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_BACKGROUND: function() {
                    return Ae
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_BORDER: function() {
                    return Ie
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_ICON_DEFAULT: function() {
                    return Re
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_ICON_NEGATIVE_BACKGROUND: function() {
                    return te
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_ICON_NEGATIVE_FOREGROUND: function() {
                    return ue
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_ICON_POSITIVE_BACKGROUND: function() {
                    return re
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_ICON_POSITIVE_FOREGROUND: function() {
                    return Me
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_TEXT: function() {
                    return Le
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_TITLE: function() {
                    return Ke
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_UNDERLAY_END: function() {
                    return De
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_UNDERLAY_START: function() {
                    return ee
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SHADOW_BLUR: function() {
                    return ie
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SHADOW_COLOR: function() {
                    return oe
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SHADOW_SPREAD: function() {
                    return ce
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SHADOW_X: function() {
                    return Fe
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SHADOW_Y: function() {
                    return fe
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SIZING_BACKGROUND_BLUR: function() {
                    return Ge
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SIZING_ICON: function() {
                    return Pe
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_HORIZONTAL: function() {
                    return Be
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_ITEM_GAP_HORIZONTAL_MEDIUM: function() {
                    return Ue
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_ITEM_GAP_HORIZONTAL_SMALL: function() {
                    return He
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_ITEM_GAP_VERTICAL_MEDIUM: function() {
                    return pe
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_ITEM_GAP_VERTICAL_SMALL: function() {
                    return xe
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_ITEM_HORIZONTAL: function() {
                    return Ye
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_ITEM_VERTICAL: function() {
                    return Ve
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_VERTICAL: function() {
                    return We
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_TYPOGRAPHY_TEXT: function() {
                    return Ze
                },
                TOKEN_COSMOS_INAPPNOTIFICATION_TYPOGRAPHY_TITLE: function() {
                    return Xe
                },
                TOKEN_COSMOS_MARK_BORDER_RADIUS: function() {
                    return se
                },
                TOKEN_COSMOS_MARK_BORDER_WIDTH_DEFAULT: function() {
                    return le
                },
                TOKEN_COSMOS_MARK_BORDER_WIDTH_INVERSE: function() {
                    return me
                },
                TOKEN_COSMOS_MARK_BOX_SHADOW_DEFAULT_BLUR: function() {
                    return ae
                },
                TOKEN_COSMOS_MARK_BOX_SHADOW_DEFAULT_COLOR: function() {
                    return be
                },
                TOKEN_COSMOS_MARK_BOX_SHADOW_DEFAULT_SPREAD: function() {
                    return de
                },
                TOKEN_COSMOS_MARK_BOX_SHADOW_DEFAULT_X: function() {
                    return ye
                },
                TOKEN_COSMOS_MARK_BOX_SHADOW_DEFAULT_Y: function() {
                    return Qe
                },
                TOKEN_COSMOS_MARK_BOX_SHADOW_FLOATING_BLUR: function() {
                    return ke
                },
                TOKEN_COSMOS_MARK_BOX_SHADOW_FLOATING_COLOR: function() {
                    return Je
                },
                TOKEN_COSMOS_MARK_BOX_SHADOW_FLOATING_SPREAD: function() {
                    return he
                },
                TOKEN_COSMOS_MARK_BOX_SHADOW_FLOATING_X: function() {
                    return ze
                },
                TOKEN_COSMOS_MARK_BOX_SHADOW_FLOATING_Y: function() {
                    return we
                },
                TOKEN_COSMOS_MARK_COLOR_BACKGROUND_DEFAULT: function() {
                    return ge
                },
                TOKEN_COSMOS_MARK_COLOR_BACKGROUND_INVERSE: function() {
                    return ve
                },
                TOKEN_COSMOS_MARK_COLOR_BORDER_DEFAULT: function() {
                    return je
                },
                TOKEN_COSMOS_MARK_COLOR_BORDER_INVERSE: function() {
                    return qe
                },
                TOKEN_COSMOS_MARK_COLOR_ICON_DEFAULT: function() {
                    return $e
                },
                TOKEN_COSMOS_MARK_COLOR_ICON_INVERSE: function() {
                    return _i
                },
                TOKEN_COSMOS_MARK_COLOR_TEXT_DEFAULT: function() {
                    return Oi
                },
                TOKEN_COSMOS_MARK_COLOR_TEXT_INVERSE: function() {
                    return Ti
                },
                TOKEN_COSMOS_MARK_SIZING_ICON: function() {
                    return Ei
                },
                TOKEN_COSMOS_MARK_SIZING_MIN_WIDTH: function() {
                    return ni
                },
                TOKEN_COSMOS_MARK_SPACING_GAP: function() {
                    return Ni
                },
                TOKEN_COSMOS_MARK_SPACING_HORIZONTAL: function() {
                    return Si
                },
                TOKEN_COSMOS_MARK_SPACING_VERTICAL: function() {
                    return Ci
                },
                TOKEN_COSMOS_MARK_TYPOGRAPHY_TEXT: function() {
                    return Ai
                },
                TOKEN_COSMOS_MENU_COLOR_BACKGROUND_DEFAULT: function() {
                    return Ii
                },
                TOKEN_COSMOS_MENU_COLOR_BACKGROUND_OVERLAY_HOVER: function() {
                    return Ri
                },
                TOKEN_COSMOS_MENU_COLOR_BACKGROUND_OVERLAY_PRESSED: function() {
                    return ti
                },
                TOKEN_COSMOS_MENU_COLOR_CONTENT: function() {
                    return ui
                },
                TOKEN_COSMOS_MENU_COLOR_ICON: function() {
                    return ri
                },
                TOKEN_COSMOS_MENU_SHADOW_BLUR: function() {
                    return Mi
                },
                TOKEN_COSMOS_MENU_SHADOW_COLOR: function() {
                    return Li
                },
                TOKEN_COSMOS_MENU_SHADOW_SPREAD: function() {
                    return Ki
                },
                TOKEN_COSMOS_MENU_SHADOW_X: function() {
                    return Di
                },
                TOKEN_COSMOS_MENU_SHADOW_Y: function() {
                    return ei
                },
                TOKEN_COSMOS_MENU_SIZING_ICON: function() {
                    return ii
                },
                TOKEN_COSMOS_MENU_SPACING_GAP_MEDIUM: function() {
                    return oi
                },
                TOKEN_COSMOS_MENU_SPACING_GAP_SMALL: function() {
                    return ci
                },
                TOKEN_COSMOS_MENU_SPACING_HORIZONTAL: function() {
                    return Fi
                },
                TOKEN_COSMOS_MENU_SPACING_VERTICAL: function() {
                    return fi
                },
                TOKEN_COSMOS_MENU_TYPOGRAPHY_CONTENT: function() {
                    return Gi
                },
                TOKEN_COSMOS_MODAL_BORDER_RADIUS: function() {
                    return Pi
                },
                TOKEN_COSMOS_MODAL_COLOR_BACKGROUND_BACKDROP: function() {
                    return Bi
                },
                TOKEN_COSMOS_MODAL_COLOR_BACKGROUND_CONTAINER: function() {
                    return Ui
                },
                TOKEN_COSMOS_MODAL_SIZING_BACKGROUND_BLUR: function() {
                    return Hi
                },
                TOKEN_COSMOS_MODAL_SIZING_MAX_HEIGHT: function() {
                    return pi
                },
                TOKEN_COSMOS_MODAL_SIZING_MAX_WIDTH: function() {
                    return xi
                },
                TOKEN_COSMOS_MODAL_SPACING_HORIZONTAL: function() {
                    return Yi
                },
                TOKEN_COSMOS_MODAL_SPACING_OUTSET: function() {
                    return Vi
                },
                TOKEN_COSMOS_MODAL_SPACING_VERTICAL: function() {
                    return Wi
                },
                TOKEN_COSMOS_NAVIGATIONBAR_COLOR_ACTION_DEFAULT: function() {
                    return Zi
                },
                TOKEN_COSMOS_NAVIGATIONBAR_COLOR_ACTION_DISABLED: function() {
                    return Xi
                },
                TOKEN_COSMOS_NAVIGATIONBAR_COLOR_BACKGROUND_DEFAULT: function() {
                    return si
                },
                TOKEN_COSMOS_NAVIGATIONBAR_COLOR_BACKGROUND_TRANSPARENT: function() {
                    return li
                },
                TOKEN_COSMOS_NAVIGATIONBAR_COLOR_DESCRIPTION_DEFAULT: function() {
                    return mi
                },
                TOKEN_COSMOS_NAVIGATIONBAR_COLOR_ICON_DEFAULT_BACKGROUND: function() {
                    return ai
                },
                TOKEN_COSMOS_NAVIGATIONBAR_COLOR_ICON_DEFAULT_FOREGROUND: function() {
                    return bi
                },
                TOKEN_COSMOS_NAVIGATIONBAR_COLOR_LOGO: function() {
                    return di
                },
                TOKEN_COSMOS_NAVIGATIONBAR_COLOR_TITLE_DEFAULT: function() {
                    return yi
                },
                TOKEN_COSMOS_NAVIGATIONBAR_SIZING_BACKGROUND_BLUR: function() {
                    return Qi
                },
                TOKEN_COSMOS_NAVIGATIONBAR_SIZING_HEIGHT: function() {
                    return ki
                },
                TOKEN_COSMOS_NAVIGATIONBAR_SPACING_GAP_HORIZONTAL_LARGE: function() {
                    return Ji
                },
                TOKEN_COSMOS_NAVIGATIONBAR_SPACING_GAP_HORIZONTAL_MEDIUM: function() {
                    return hi
                },
                TOKEN_COSMOS_NAVIGATIONBAR_SPACING_GAP_HORIZONTAL_SMALL: function() {
                    return zi
                },
                TOKEN_COSMOS_NAVIGATIONBAR_SPACING_GAP_HORIZONTAL_XLARGE: function() {
                    return wi
                },
                TOKEN_COSMOS_NAVIGATIONBAR_SPACING_GAP_VERTICAL: function() {
                    return gi
                },
                TOKEN_COSMOS_NAVIGATIONBAR_SPACING_HORIZONTAL_MEDIUM: function() {
                    return vi
                },
                TOKEN_COSMOS_NAVIGATIONBAR_SPACING_HORIZONTAL_SMALL: function() {
                    return ji
                },
                TOKEN_COSMOS_NAVIGATIONBAR_SPACING_VERTICAL_MEDIUM: function() {
                    return qi
                },
                TOKEN_COSMOS_NAVIGATIONBAR_SPACING_VERTICAL_SMALL: function() {
                    return $i
                },
                TOKEN_COSMOS_NAVIGATIONBAR_TYPOGRAPHY_ACTION: function() {
                    return _o
                },
                TOKEN_COSMOS_NAVIGATIONBAR_TYPOGRAPHY_DESCRIPTION: function() {
                    return Oo
                },
                TOKEN_COSMOS_NAVIGATIONBAR_TYPOGRAPHY_INFO: function() {
                    return To
                },
                TOKEN_COSMOS_NAVIGATIONBAR_TYPOGRAPHY_TITLE_MEDIUM: function() {
                    return Eo
                },
                TOKEN_COSMOS_NAVIGATIONBAR_TYPOGRAPHY_TITLE_SMALL: function() {
                    return no
                },
                TOKEN_COSMOS_NUDGE_BORDER_RADIUS: function() {
                    return No
                },
                TOKEN_COSMOS_NUDGE_COLOR_BACKGROUND_ALT: function() {
                    return So
                },
                TOKEN_COSMOS_NUDGE_COLOR_BACKGROUND_DEFAULT: function() {
                    return Co
                },
                TOKEN_COSMOS_NUDGE_COLOR_DESCRIPTION_ALT: function() {
                    return Ao
                },
                TOKEN_COSMOS_NUDGE_COLOR_DESCRIPTION_DEFAULT: function() {
                    return Io
                },
                TOKEN_COSMOS_NUDGE_COLOR_HINT: function() {
                    return Ro
                },
                TOKEN_COSMOS_NUDGE_COLOR_TITLE: function() {
                    return to
                },
                TOKEN_COSMOS_NUDGE_SIZING_ICON: function() {
                    return uo
                },
                TOKEN_COSMOS_NUDGE_SPACING_GAP_HORIZONTAL_MEDIUM: function() {
                    return ro
                },
                TOKEN_COSMOS_NUDGE_SPACING_GAP_VERTICAL_MEDIUM: function() {
                    return Mo
                },
                TOKEN_COSMOS_NUDGE_SPACING_GAP_VERTICAL_SMALL: function() {
                    return Lo
                },
                TOKEN_COSMOS_NUDGE_SPACING_HORIZONTAL: function() {
                    return Ko
                },
                TOKEN_COSMOS_NUDGE_SPACING_VERTICAL: function() {
                    return Do
                },
                TOKEN_COSMOS_NUDGE_TYPOGRAPHY_DESCRIPTION: function() {
                    return eo
                },
                TOKEN_COSMOS_NUDGE_TYPOGRAPHY_HINT: function() {
                    return io
                },
                TOKEN_COSMOS_NUDGE_TYPOGRAPHY_TITLE: function() {
                    return oo
                },
                TOKEN_COSMOS_PAGINATIONDOTS_BORDER_RADIUS_DEFAULT: function() {
                    return co
                },
                TOKEN_COSMOS_PAGINATIONDOTS_COLOR_BACKGROUND_DEFAULT_SELECTED: function() {
                    return Fo
                },
                TOKEN_COSMOS_PAGINATIONDOTS_COLOR_BACKGROUND_DEFAULT_UNSELECTED: function() {
                    return fo
                },
                TOKEN_COSMOS_PAGINATIONDOTS_COLOR_BACKGROUND_INVERSE_SELECTED: function() {
                    return Go
                },
                TOKEN_COSMOS_PAGINATIONDOTS_COLOR_BACKGROUND_INVERSE_UNSELECTED: function() {
                    return Po
                },
                TOKEN_COSMOS_PAGINATIONDOTS_OPACITY_DEFAULT_UNSELECTED: function() {
                    return Bo
                },
                TOKEN_COSMOS_PAGINATIONDOTS_OPACITY_INVERSE_UNSELECTED: function() {
                    return Uo
                },
                TOKEN_COSMOS_PAGINATIONDOTS_SIZING_CIRCLE_LARGE: function() {
                    return Ho
                },
                TOKEN_COSMOS_PAGINATIONDOTS_SIZING_CIRCLE_MEDIUM: function() {
                    return po
                },
                TOKEN_COSMOS_PAGINATIONDOTS_SIZING_CIRCLE_SMALL: function() {
                    return xo
                },
                TOKEN_COSMOS_PAGINATIONDOTS_SIZING_CIRCLE_XLARGE: function() {
                    return Yo
                },
                TOKEN_COSMOS_PAGINATIONDOTS_SPACING_GAP: function() {
                    return Vo
                },
                TOKEN_COSMOS_PROFILECARD_BORDER_RADIUS: function() {
                    return Wo
                },
                TOKEN_COSMOS_PROFILECARD_BORDER_WIDTH_DEFAULT: function() {
                    return Zo
                },
                TOKEN_COSMOS_PROFILECARD_COLOR_BACKGROUND_DEFAULT: function() {
                    return Xo
                },
                TOKEN_COSMOS_PROFILECARD_COLOR_BADGE: function() {
                    return so
                },
                TOKEN_COSMOS_PROFILECARD_COLOR_BORDER_DEFAULT: function() {
                    return lo
                },
                TOKEN_COSMOS_PROFILECARD_COLOR_GRADIENT_END: function() {
                    return mo
                },
                TOKEN_COSMOS_PROFILECARD_COLOR_GRADIENT_START: function() {
                    return ao
                },
                TOKEN_COSMOS_PROFILECARD_COLOR_ICON_DEFAULT: function() {
                    return bo
                },
                TOKEN_COSMOS_PROFILECARD_COLOR_ICON_INVERSE: function() {
                    return yo
                },
                TOKEN_COSMOS_PROFILECARD_COLOR_TITLE: function() {
                    return Qo
                },
                TOKEN_COSMOS_PROFILECARD_SHADOW_BLUR: function() {
                    return ko
                },
                TOKEN_COSMOS_PROFILECARD_SHADOW_COLOR: function() {
                    return Jo
                },
                TOKEN_COSMOS_PROFILECARD_SHADOW_SPREAD: function() {
                    return ho
                },
                TOKEN_COSMOS_PROFILECARD_SHADOW_X: function() {
                    return zo
                },
                TOKEN_COSMOS_PROFILECARD_SHADOW_Y: function() {
                    return wo
                },
                TOKEN_COSMOS_PROFILECARD_SIZING_BADGE: function() {
                    return go
                },
                TOKEN_COSMOS_PROFILECARD_SIZING_ICON: function() {
                    return vo
                },
                TOKEN_COSMOS_PROFILECARD_SPACING_GAP_HORIZONTAL_MEDIUM: function() {
                    return jo
                },
                TOKEN_COSMOS_PROFILECARD_SPACING_GAP_HORIZONTAL_SMALL: function() {
                    return qo
                },
                TOKEN_COSMOS_PROFILECARD_SPACING_GAP_VERTICAL_MEDIUM: function() {
                    return $o
                },
                TOKEN_COSMOS_PROFILECARD_SPACING_GAP_VERTICAL_SMALL: function() {
                    return _c
                },
                TOKEN_COSMOS_PROFILECARD_SPACING_GAP_VERTICAL_XSMALL: function() {
                    return Oc
                },
                TOKEN_COSMOS_PROFILECARD_SPACING_HORIZONTAL_LEFT: function() {
                    return Tc
                },
                TOKEN_COSMOS_PROFILECARD_SPACING_HORIZONTAL_RIGHT_MEDIUM: function() {
                    return Ec
                },
                TOKEN_COSMOS_PROFILECARD_SPACING_HORIZONTAL_RIGHT_SMALL: function() {
                    return nc
                },
                TOKEN_COSMOS_PROFILECARD_SPACING_VERTICAL_BOTTOM_MEDIUM: function() {
                    return Nc
                },
                TOKEN_COSMOS_PROFILECARD_SPACING_VERTICAL_BOTTOM_SMALL: function() {
                    return Sc
                },
                TOKEN_COSMOS_PROFILECARD_SPACING_VERTICAL_TOP_MEDIUM: function() {
                    return Cc
                },
                TOKEN_COSMOS_PROFILECARD_SPACING_VERTICAL_TOP_SMALL: function() {
                    return Ac
                },
                TOKEN_COSMOS_PROFILECARD_TYPOGRAPHY_ACTION: function() {
                    return Ic
                },
                TOKEN_COSMOS_PROFILECARD_TYPOGRAPHY_TITLE: function() {
                    return Rc
                },
                TOKEN_COSMOS_PROGRESSBAR_BORDER_RADIUS: function() {
                    return tc
                },
                TOKEN_COSMOS_PROGRESSBAR_COLOR_BACKGROUND_DEFAULT: function() {
                    return uc
                },
                TOKEN_COSMOS_PROGRESSBAR_COLOR_BACKGROUND_INVERSE: function() {
                    return rc
                },
                TOKEN_COSMOS_PROGRESSBAR_COLOR_INDICATOR_DEFAULT: function() {
                    return Mc
                },
                TOKEN_COSMOS_PROGRESSBAR_COLOR_INDICATOR_INVERSE: function() {
                    return Lc
                },
                TOKEN_COSMOS_PROGRESSBAR_OPACITY_BACKGROUND_DEFAULT: function() {
                    return Kc
                },
                TOKEN_COSMOS_PROGRESSBAR_OPACITY_BACKGROUND_INVERSE: function() {
                    return Dc
                },
                TOKEN_COSMOS_PROGRESSBAR_SIZING_HEIGHT: function() {
                    return ec
                },
                TOKEN_COSMOS_PROGRESSCIRCLE_BORDER_RADIUS: function() {
                    return ic
                },
                TOKEN_COSMOS_PROGRESSCIRCLE_COLOR_BACKGROUND_DEFAULT: function() {
                    return oc
                },
                TOKEN_COSMOS_PROGRESSCIRCLE_COLOR_BACKGROUND_INVERSE: function() {
                    return cc
                },
                TOKEN_COSMOS_PROGRESSCIRCLE_COLOR_INDICATOR_DEFAULT: function() {
                    return Fc
                },
                TOKEN_COSMOS_PROGRESSCIRCLE_COLOR_INDICATOR_INVERSE: function() {
                    return fc
                },
                TOKEN_COSMOS_PROGRESSCIRCLE_OPACITY_BACKGROUND_DEFAULT: function() {
                    return Gc
                },
                TOKEN_COSMOS_PROGRESSCIRCLE_OPACITY_BACKGROUND_INVERSE: function() {
                    return Pc
                },
                TOKEN_COSMOS_PROGRESSCIRCLE_SIZING_WIDTH: function() {
                    return Bc
                },
                TOKEN_COSMOS_RADIOBUTTON_BORDER_RADIUS: function() {
                    return Uc
                },
                TOKEN_COSMOS_RADIOBUTTON_BORDER_WIDTH_DEFAULT_ERROR: function() {
                    return Hc
                },
                TOKEN_COSMOS_RADIOBUTTON_BORDER_WIDTH_DEFAULT_SELECTED: function() {
                    return pc
                },
                TOKEN_COSMOS_RADIOBUTTON_BORDER_WIDTH_DEFAULT_UNSELECTED: function() {
                    return xc
                },
                TOKEN_COSMOS_RADIOBUTTON_BORDER_WIDTH_INVERSE_ERROR: function() {
                    return Yc
                },
                TOKEN_COSMOS_RADIOBUTTON_BORDER_WIDTH_INVERSE_SELECTED: function() {
                    return Vc
                },
                TOKEN_COSMOS_RADIOBUTTON_BORDER_WIDTH_INVERSE_UNSELECTED: function() {
                    return Wc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_BACKGROUND_DEFAULT_ERROR: function() {
                    return Zc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_BACKGROUND_DEFAULT_SELECTED: function() {
                    return Xc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_BACKGROUND_DEFAULT_UNSELECTED: function() {
                    return sc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_BACKGROUND_INVERSE_ERROR: function() {
                    return lc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_BACKGROUND_INVERSE_SELECTED: function() {
                    return mc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_BACKGROUND_INVERSE_UNSELECTED: function() {
                    return ac
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_BORDER_DEFAULT_ERROR: function() {
                    return bc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_BORDER_DEFAULT_SELECTED: function() {
                    return dc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_BORDER_DEFAULT_UNSELECTED: function() {
                    return yc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_BORDER_INVERSE_ERROR: function() {
                    return Qc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_BORDER_INVERSE_SELECTED: function() {
                    return kc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_BORDER_INVERSE_UNSELECTED: function() {
                    return Jc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_ICON_DEFAULT_ERROR: function() {
                    return hc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_ICON_DEFAULT_SELECTED: function() {
                    return zc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_ICON_DEFAULT_UNSELECTED: function() {
                    return wc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_ICON_INVERSE_ERROR: function() {
                    return gc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_ICON_INVERSE_SELECTED: function() {
                    return vc
                },
                TOKEN_COSMOS_RADIOBUTTON_COLOR_ICON_INVERSE_UNSELECTED: function() {
                    return jc
                },
                TOKEN_COSMOS_RADIOBUTTON_SIZING_MEDIUM: function() {
                    return qc
                },
                TOKEN_COSMOS_RADIOBUTTON_SIZING_SMALL: function() {
                    return $c
                },
                TOKEN_COSMOS_SEARCH_BORDER_RADIUS: function() {
                    return _F
                },
                TOKEN_COSMOS_SEARCH_BORDER_WIDTH_DEFAULT: function() {
                    return OF
                },
                TOKEN_COSMOS_SEARCH_BORDER_WIDTH_FILLED: function() {
                    return TF
                },
                TOKEN_COSMOS_SEARCH_COLOR_BACKGROUND_DEFAULT: function() {
                    return EF
                },
                TOKEN_COSMOS_SEARCH_COLOR_BORDER_DEFAULT: function() {
                    return nF
                },
                TOKEN_COSMOS_SEARCH_COLOR_BORDER_FILLED: function() {
                    return NF
                },
                TOKEN_COSMOS_SEARCH_COLOR_CONTENT_DEFAULT: function() {
                    return SF
                },
                TOKEN_COSMOS_SEARCH_COLOR_CONTENT_FILLED: function() {
                    return CF
                },
                TOKEN_COSMOS_SEARCH_COLOR_ICON_LEFT: function() {
                    return AF
                },
                TOKEN_COSMOS_SEARCH_COLOR_ICON_RIGHT: function() {
                    return IF
                },
                TOKEN_COSMOS_SEARCH_SIZING_HEIGHT: function() {
                    return RF
                },
                TOKEN_COSMOS_SEARCH_SIZING_ICON_LEFT: function() {
                    return tF
                },
                TOKEN_COSMOS_SEARCH_SPACING_GAP: function() {
                    return uF
                },
                TOKEN_COSMOS_SEARCH_SPACING_HORIZONTAL_LEFT: function() {
                    return rF
                },
                TOKEN_COSMOS_SEARCH_SPACING_HORIZONTAL_RIGHT: function() {
                    return MF
                },
                TOKEN_COSMOS_SEARCH_SPACING_VERTICAL: function() {
                    return LF
                },
                TOKEN_COSMOS_SEARCH_TYPOGRAPHY_ACTION: function() {
                    return KF
                },
                TOKEN_COSMOS_SEARCH_TYPOGRAPHY_CONTENT: function() {
                    return DF
                },
                TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_16_9_HEIGHT: function() {
                    return eF
                },
                TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_16_9_WIDTH: function() {
                    return iF
                },
                TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_1_1_HEIGHT: function() {
                    return oF
                },
                TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_1_1_WIDTH: function() {
                    return cF
                },
                TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_3_2_HEIGHT: function() {
                    return FF
                },
                TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_3_2_WIDTH: function() {
                    return fF
                },
                TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_3_4_HEIGHT: function() {
                    return GF
                },
                TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_3_4_WIDTH: function() {
                    return PF
                },
                TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_4_3_HEIGHT: function() {
                    return BF
                },
                TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_4_3_WIDTH: function() {
                    return UF
                },
                TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_4_5_HEIGHT: function() {
                    return HF
                },
                TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_4_5_WIDTH: function() {
                    return pF
                },
                TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_9_16_HEIGHT: function() {
                    return xF
                },
                TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_9_16_WIDTH: function() {
                    return YF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_0: function() {
                    return VF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_10: function() {
                    return WF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_12: function() {
                    return ZF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_16: function() {
                    return XF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_19: function() {
                    return sF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_24: function() {
                    return lF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_32: function() {
                    return mF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_4: function() {
                    return aF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_8: function() {
                    return bF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_FULL: function() {
                    return dF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_LEVEL_0: function() {
                    return yF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_LEVEL_1: function() {
                    return QF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_LEVEL_1_LARGE: function() {
                    return kF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_LEVEL_1_SMALL: function() {
                    return JF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_LEVEL_2: function() {
                    return hF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_LEVEL_3: function() {
                    return zF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_NONE: function() {
                    return wF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_WIDTH_FOCUS: function() {
                    return gF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_WIDTH_INTERACTIVE: function() {
                    return vF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_WIDTH_NONE: function() {
                    return jF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_WIDTH_RESTING: function() {
                    return qF
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_WIDTH_SUPPORTIVE: function() {
                    return $F
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_WIDTH_THICK: function() {
                    return _f
                },
                TOKEN_COSMOS_SEMANTIC_BORDER_WIDTH_THIN: function() {
                    return Of
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_BORDER_DEFAULT: function() {
                    return Tf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_BORDER_FOCUS: function() {
                    return Ef
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_BORDER_INTERACTIVE: function() {
                    return nf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_BORDER_INVERSE: function() {
                    return Nf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_BORDER_RESTING: function() {
                    return Sf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_BORDER_SELECTED: function() {
                    return Cf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_BORDER_STRONG: function() {
                    return Af
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_BORDER_SUBTLE: function() {
                    return If
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_BORDER_SUPPORTIVE: function() {
                    return Rf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_ACCENT_DEFAULT: function() {
                    return tf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_ACCENT_TRANSPARENT: function() {
                    return uf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_BRAND: function() {
                    return rf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_BRAND_2: function() {
                    return Mf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_BRAND_3: function() {
                    return Lf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_DEFAULT: function() {
                    return Kf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_DESTRUCTIVE: function() {
                    return Df
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_DISABLED: function() {
                    return ef
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_INVERSE: function() {
                    return of
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_LAYERED_TRANSPARENT: function() {
                    return cf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_OVERLAY_BOTTOM_GRADIENT_END: function() {
                    return Ff
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_OVERLAY_BOTTOM_GRADIENT_START: function() {
                    return ff
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_PRIMARY_DEFAULT: function() {
                    return Gf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_PRIMARY_TRANSPARENT: function() {
                    return Pf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_SECONDARY_DEFAULT: function() {
                    return Bf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_SECONDARY_TRANSPARENT: function() {
                    return Uf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_SELECTED: function() {
                    return Hf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_SUBTLE: function() {
                    return pf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_SUBTLE_2: function() {
                    return xf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_SUBTLE_3: function() {
                    return Yf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_TERTIARY_DEFAULT: function() {
                    return Vf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_TERTIARY_TRANSPARENT: function() {
                    return Wf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_TRANSPARENT: function() {
                    return Zf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_DEFAULT: function() {
                    return Xf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_DEFAULT_ICON: function() {
                    return sf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_LIKED_YOU: function() {
                    return lf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_LIKED_YOU_ICON: function() {
                    return mf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_PREMIUM: function() {
                    return af
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_PREMIUM_ALT: function() {
                    return bf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_PREMIUM_ICON: function() {
                    return df
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_PREMIUM_PLUS: function() {
                    return yf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_PREMIUM_PLUS_ALT: function() {
                    return Qf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_PREMIUM_PLUS_ICON: function() {
                    return kf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_REVENUE: function() {
                    return Jf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_REVENUE_ICON: function() {
                    return hf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_TIER_EXTRA: function() {
                    return zf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_TIER_EXTRA_ALT: function() {
                    return wf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_TIER_EXTRA_ICON: function() {
                    return gf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_TIER_PREMIUM: function() {
                    return vf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_TIER_PREMIUM_ALT: function() {
                    return jf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_TIER_PREMIUM_ICON: function() {
                    return qf
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_VERIFICATION: function() {
                    return $f
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_BLUE: function() {
                    return _G
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_BLUE_STRONG: function() {
                    return OG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_BLUE_SUBTLE: function() {
                    return TG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_GREEN: function() {
                    return EG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_GREEN_STRONG: function() {
                    return nG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_GREEN_SUBTLE: function() {
                    return NG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_ORANGE: function() {
                    return SG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_ORANGE_STRONG: function() {
                    return CG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_ORANGE_SUBTLE: function() {
                    return AG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_PURPLE: function() {
                    return IG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_PURPLE_STRONG: function() {
                    return RG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_PURPLE_SUBTLE: function() {
                    return tG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_RED: function() {
                    return uG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_RED_STRONG: function() {
                    return rG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_RED_SUBTLE: function() {
                    return MG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_YELLOW: function() {
                    return LG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_YELLOW_STRONG: function() {
                    return KG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_YELLOW_SUBTLE: function() {
                    return DG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_ICON_BRAND: function() {
                    return eG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_ICON_DEFAULT: function() {
                    return iG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_ICON_DISABLED: function() {
                    return oG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_ICON_INVERSE: function() {
                    return cG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_ICON_SELECTED: function() {
                    return FG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_ICON_SUBTLE: function() {
                    return fG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_BRAND: function() {
                    return GG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_BRAND_2: function() {
                    return PG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_BRAND_3: function() {
                    return BG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_DEFAULT: function() {
                    return UG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_OVERLAY: function() {
                    return HG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_OVERLAY_GRADIENT_END: function() {
                    return pG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_OVERLAY_GRADIENT_START: function() {
                    return xG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_STRONG: function() {
                    return YG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_SUBTLE: function() {
                    return VG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_REACTIVE_DEFAULT_HOVER: function() {
                    return WG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_REACTIVE_DEFAULT_PRESSED: function() {
                    return ZG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_REACTIVE_INVERSE_HOVER: function() {
                    return XG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_REACTIVE_INVERSE_PRESSED: function() {
                    return sG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_APPLE: function() {
                    return lG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_FACEBOOK: function() {
                    return mG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_GOOGLE: function() {
                    return aG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_INSTAGRAM: function() {
                    return bG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_LINKEDIN: function() {
                    return dG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_NETFLIX: function() {
                    return yG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_ODNOKLASSNIKI: function() {
                    return QG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_SPOTIFY: function() {
                    return kG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_TWITTER: function() {
                    return JG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_VKONTAKTE: function() {
                    return hG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SUPPORTIVE_FEEDBACK_ALERT: function() {
                    return zG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SUPPORTIVE_FEEDBACK_ALERT_SUBTLE: function() {
                    return wG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SUPPORTIVE_FEEDBACK_ERROR: function() {
                    return gG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SUPPORTIVE_FEEDBACK_ERROR_SUBTLE: function() {
                    return vG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SUPPORTIVE_FEEDBACK_NOTIFICATION: function() {
                    return jG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SUPPORTIVE_FEEDBACK_SUCCESS: function() {
                    return qG
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_SUPPORTIVE_FEEDBACK_SUCCESS_SUBTLE: function() {
                    return $G
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_DEFAULT: function() {
                    return _P
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_DESTRUCTIVE: function() {
                    return OP
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_DISABLED: function() {
                    return TP
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_ERROR: function() {
                    return EP
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_INVERSE: function() {
                    return nP
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_LINKS: function() {
                    return NP
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_POSITIVE: function() {
                    return SP
                },
                TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_SUBDUED: function() {
                    return CP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_EXTRALONG_1: function() {
                    return AP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_EXTRALONG_2: function() {
                    return IP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_EXTRALONG_3: function() {
                    return RP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_EXTRALONG_4: function() {
                    return tP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_LONG_1: function() {
                    return uP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_LONG_2: function() {
                    return rP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_LONG_3: function() {
                    return MP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_LONG_4: function() {
                    return LP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_MEDIUM_1: function() {
                    return KP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_MEDIUM_2: function() {
                    return DP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_MEDIUM_3: function() {
                    return eP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_MEDIUM_4: function() {
                    return iP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_SHORT_1: function() {
                    return oP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_SHORT_2: function() {
                    return cP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_SHORT_3: function() {
                    return FP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_DURATION_SHORT_4: function() {
                    return fP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_EASING_EMPHASIZED: function() {
                    return GP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_EASING_EMPHASIZED_ACCELERATE: function() {
                    return PP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_EASING_EMPHASIZED_DECELERATE: function() {
                    return BP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_EASING_STANDARD: function() {
                    return UP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_EASING_STANDARD_ACCELERATE: function() {
                    return HP
                },
                TOKEN_COSMOS_SEMANTIC_MOTION_EASING_STANDARD_DECELERATE: function() {
                    return pP
                },
                TOKEN_COSMOS_SEMANTIC_OPACITY_0: function() {
                    return xP
                },
                TOKEN_COSMOS_SEMANTIC_OPACITY_10: function() {
                    return YP
                },
                TOKEN_COSMOS_SEMANTIC_OPACITY_100: function() {
                    return VP
                },
                TOKEN_COSMOS_SEMANTIC_OPACITY_20: function() {
                    return WP
                },
                TOKEN_COSMOS_SEMANTIC_OPACITY_30: function() {
                    return ZP
                },
                TOKEN_COSMOS_SEMANTIC_OPACITY_40: function() {
                    return XP
                },
                TOKEN_COSMOS_SEMANTIC_OPACITY_5: function() {
                    return sP
                },
                TOKEN_COSMOS_SEMANTIC_OPACITY_50: function() {
                    return lP
                },
                TOKEN_COSMOS_SEMANTIC_OPACITY_60: function() {
                    return mP
                },
                TOKEN_COSMOS_SEMANTIC_OPACITY_70: function() {
                    return aP
                },
                TOKEN_COSMOS_SEMANTIC_OPACITY_80: function() {
                    return bP
                },
                TOKEN_COSMOS_SEMANTIC_OPACITY_90: function() {
                    return dP
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_BLUR: function() {
                    return yP
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_COLOR: function() {
                    return QP
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_1_BLUR: function() {
                    return kP
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_1_COLOR: function() {
                    return JP
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_1_SPREAD: function() {
                    return hP
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_1_X: function() {
                    return zP
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_1_Y: function() {
                    return wP
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_2_BLUR: function() {
                    return gP
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_2_COLOR: function() {
                    return vP
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_2_SPREAD: function() {
                    return jP
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_2_X: function() {
                    return qP
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_2_Y: function() {
                    return $P
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_SPREAD: function() {
                    return _B
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_X: function() {
                    return OB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_Y: function() {
                    return TB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_IN_LINE_BLUR: function() {
                    return EB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_IN_LINE_COLOR: function() {
                    return nB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_IN_LINE_SPREAD: function() {
                    return NB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_IN_LINE_X: function() {
                    return SB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_IN_LINE_Y: function() {
                    return CB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_NONE_BLUR: function() {
                    return AB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_NONE_COLOR: function() {
                    return IB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_NONE_SPREAD: function() {
                    return RB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_NONE_X: function() {
                    return tB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_NONE_Y: function() {
                    return uB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_OVERLAY_BLUR: function() {
                    return rB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_OVERLAY_COLOR: function() {
                    return MB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_OVERLAY_SPREAD: function() {
                    return LB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_OVERLAY_X: function() {
                    return KB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_OVERLAY_Y: function() {
                    return DB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_1_BLUR: function() {
                    return eB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_1_COLOR: function() {
                    return iB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_1_SPREAD: function() {
                    return oB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_1_X: function() {
                    return cB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_1_Y: function() {
                    return FB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_2_BLUR: function() {
                    return fB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_2_COLOR: function() {
                    return GB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_2_SPREAD: function() {
                    return PB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_2_X: function() {
                    return BB
                },
                TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_2_Y: function() {
                    return UB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_0: function() {
                    return HB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_12: function() {
                    return pB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_16: function() {
                    return xB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_2: function() {
                    return YB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_20: function() {
                    return VB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_24: function() {
                    return WB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_32: function() {
                    return ZB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_36: function() {
                    return XB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_4: function() {
                    return sB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_40: function() {
                    return lB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_48: function() {
                    return mB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_56: function() {
                    return aB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_6: function() {
                    return bB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_64: function() {
                    return dB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_72: function() {
                    return yB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_8: function() {
                    return QB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_80: function() {
                    return kB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_BLUR_ACCENT: function() {
                    return JB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_BLUR_LAYERED: function() {
                    return hB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_BLUR_PRIMARY: function() {
                    return zB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_BLUR_SECONDARY: function() {
                    return wB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_BLUR_TERTIARY: function() {
                    return gB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_ICON_LARGE: function() {
                    return vB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_ICON_MEDIUM: function() {
                    return jB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_ICON_SMALL: function() {
                    return qB
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_ICON_XSMALL: function() {
                    return $B
                },
                TOKEN_COSMOS_SEMANTIC_SIZING_ICON_XXSMALL: function() {
                    return _U
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_0: function() {
                    return OU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_1: function() {
                    return TU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_12: function() {
                    return EU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_16: function() {
                    return nU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_2: function() {
                    return NU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_20: function() {
                    return SU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_24: function() {
                    return CU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_3: function() {
                    return AU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_32: function() {
                    return IU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_4: function() {
                    return RU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_40: function() {
                    return tU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_48: function() {
                    return uU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_56: function() {
                    return rU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_8: function() {
                    return MU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_GAP_LARGE: function() {
                    return LU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_GAP_MEDIUM: function() {
                    return KU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_GAP_SMALL: function() {
                    return DU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_GAP_XLARGE: function() {
                    return eU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_GAP_XSMALL: function() {
                    return iU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_GAP_XXLARGE: function() {
                    return oU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_MARGINS_HORIZONTAL: function() {
                    return cU
                },
                TOKEN_COSMOS_SEMANTIC_SPACING_MARGINS_VERTICAL: function() {
                    return FU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_FONT_FAMILY: function() {
                    return fU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_FONT_SIZE: function() {
                    return GU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_FONT_WEIGHT: function() {
                    return PU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_LETTER_SPACING: function() {
                    return BU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_LINE_HEIGHT: function() {
                    return UU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_MINI_FONT_FAMILY: function() {
                    return HU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_MINI_FONT_SIZE: function() {
                    return pU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_MINI_FONT_WEIGHT: function() {
                    return xU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_MINI_LETTER_SPACING: function() {
                    return YU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_MINI_LINE_HEIGHT: function() {
                    return VU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_MINI_PARAGRAPH_SPACING: function() {
                    return WU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_MINI_TEXT_CASE: function() {
                    return ZU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_MINI_TEXT_DECORATION: function() {
                    return XU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_PARAGRAPH_SPACING: function() {
                    return sU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_SMALL_FONT_FAMILY: function() {
                    return lU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_SMALL_FONT_SIZE: function() {
                    return mU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_SMALL_FONT_WEIGHT: function() {
                    return aU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_SMALL_LETTER_SPACING: function() {
                    return bU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_SMALL_LINE_HEIGHT: function() {
                    return dU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_SMALL_PARAGRAPH_SPACING: function() {
                    return yU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_SMALL_TEXT_CASE: function() {
                    return QU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_SMALL_TEXT_DECORATION: function() {
                    return kU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_TEXT_CASE: function() {
                    return JU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_TEXT_DECORATION: function() {
                    return hU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_CAPTION_FONT_FAMILY: function() {
                    return zU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_CAPTION_FONT_SIZE: function() {
                    return wU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_CAPTION_FONT_WEIGHT: function() {
                    return gU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_CAPTION_LETTER_SPACING: function() {
                    return vU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_CAPTION_LINE_HEIGHT: function() {
                    return jU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_CAPTION_PARAGRAPH_SPACING: function() {
                    return qU
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_CAPTION_TEXT_CASE: function() {
                    return $U
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_CAPTION_TEXT_DECORATION: function() {
                    return _H
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D1_FONT_FAMILY: function() {
                    return OH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D1_FONT_SIZE: function() {
                    return TH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D1_FONT_WEIGHT: function() {
                    return EH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D1_LETTER_SPACING: function() {
                    return nH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D1_LINE_HEIGHT: function() {
                    return NH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D1_PARAGRAPH_SPACING: function() {
                    return SH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D1_TEXT_CASE: function() {
                    return CH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D1_TEXT_DECORATION: function() {
                    return AH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D2_FONT_FAMILY: function() {
                    return IH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D2_FONT_SIZE: function() {
                    return RH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D2_FONT_WEIGHT: function() {
                    return tH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D2_LETTER_SPACING: function() {
                    return uH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D2_LINE_HEIGHT: function() {
                    return rH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D2_PARAGRAPH_SPACING: function() {
                    return MH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D2_TEXT_CASE: function() {
                    return LH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D2_TEXT_DECORATION: function() {
                    return KH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D3_FONT_FAMILY: function() {
                    return DH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D3_FONT_SIZE: function() {
                    return eH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D3_FONT_WEIGHT: function() {
                    return iH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D3_LETTER_SPACING: function() {
                    return oH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D3_LINE_HEIGHT: function() {
                    return cH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D3_PARAGRAPH_SPACING: function() {
                    return FH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D3_TEXT_CASE: function() {
                    return fH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D3_TEXT_DECORATION: function() {
                    return GH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_FONT_FAMILY: function() {
                    return PH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_FONT_SIZE: function() {
                    return BH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_FONT_WEIGHT: function() {
                    return UH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_LETTER_SPACING: function() {
                    return HH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_LINE_HEIGHT: function() {
                    return pH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_PARAGRAPH_SPACING: function() {
                    return xH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_TEXT_CASE: function() {
                    return YH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_TEXT_DECORATION: function() {
                    return VH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_FONT_FAMILY: function() {
                    return WH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_FONT_SIZE: function() {
                    return ZH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_FONT_WEIGHT: function() {
                    return XH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_LETTER_SPACING: function() {
                    return sH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_LINE_HEIGHT: function() {
                    return lH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_PARAGRAPH_SPACING: function() {
                    return mH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_TEXT_CASE: function() {
                    return aH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_TEXT_DECORATION: function() {
                    return bH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_FONT_FAMILY: function() {
                    return dH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_FONT_SIZE: function() {
                    return yH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_FONT_WEIGHT: function() {
                    return QH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_LETTER_SPACING: function() {
                    return kH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_LINE_HEIGHT: function() {
                    return JH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_PARAGRAPH_SPACING: function() {
                    return hH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_TEXT_CASE: function() {
                    return zH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_TEXT_DECORATION: function() {
                    return wH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H4_FONT_FAMILY: function() {
                    return gH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H4_FONT_SIZE: function() {
                    return vH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H4_FONT_WEIGHT: function() {
                    return jH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H4_LETTER_SPACING: function() {
                    return qH
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H4_LINE_HEIGHT: function() {
                    return $H
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H4_PARAGRAPH_SPACING: function() {
                    return _p
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H4_TEXT_CASE: function() {
                    return Op
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H4_TEXT_DECORATION: function() {
                    return Tp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_1_FONT_FAMILY: function() {
                    return Ep
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_1_FONT_SIZE: function() {
                    return np
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_1_FONT_WEIGHT: function() {
                    return Np
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_1_LETTER_SPACING: function() {
                    return Sp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_1_LINE_HEIGHT: function() {
                    return Cp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_1_PARAGRAPH_SPACING: function() {
                    return Ap
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_1_TEXT_CASE: function() {
                    return Ip
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_1_TEXT_DECORATION: function() {
                    return Rp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_2_FONT_FAMILY: function() {
                    return tp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_2_FONT_SIZE: function() {
                    return up
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_2_FONT_WEIGHT: function() {
                    return rp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_2_LETTER_SPACING: function() {
                    return Mp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_2_LINE_HEIGHT: function() {
                    return Lp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_2_PARAGRAPH_SPACING: function() {
                    return Kp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_2_TEXT_CASE: function() {
                    return Dp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_2_TEXT_DECORATION: function() {
                    return ep
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_3_FONT_FAMILY: function() {
                    return ip
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_3_FONT_SIZE: function() {
                    return op
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_3_FONT_WEIGHT: function() {
                    return cp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_3_LETTER_SPACING: function() {
                    return Fp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_3_LINE_HEIGHT: function() {
                    return fp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_3_PARAGRAPH_SPACING: function() {
                    return Gp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_3_TEXT_CASE: function() {
                    return Pp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_3_TEXT_DECORATION: function() {
                    return Bp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_BOLDER_FONT_FAMILY: function() {
                    return Up
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_BOLDER_FONT_SIZE: function() {
                    return Hp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_BOLDER_FONT_WEIGHT: function() {
                    return pp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_BOLDER_LETTER_SPACING: function() {
                    return xp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_BOLDER_LINE_HEIGHT: function() {
                    return Yp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_BOLDER_PARAGRAPH_SPACING: function() {
                    return Vp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_BOLDER_TEXT_CASE: function() {
                    return Wp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_BOLDER_TEXT_DECORATION: function() {
                    return Zp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_FONT_FAMILY: function() {
                    return Xp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_FONT_SIZE: function() {
                    return sp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_FONT_WEIGHT: function() {
                    return lp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_LETTER_SPACING: function() {
                    return mp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_LINE_HEIGHT: function() {
                    return ap
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_PARAGRAPH_SPACING: function() {
                    return bp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_TEXT_CASE: function() {
                    return dp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_TEXT_DECORATION: function() {
                    return yp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_BOLDER_FONT_FAMILY: function() {
                    return Qp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_BOLDER_FONT_SIZE: function() {
                    return kp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_BOLDER_FONT_WEIGHT: function() {
                    return Jp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_BOLDER_LETTER_SPACING: function() {
                    return hp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_BOLDER_LINE_HEIGHT: function() {
                    return zp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_BOLDER_PARAGRAPH_SPACING: function() {
                    return wp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_BOLDER_TEXT_CASE: function() {
                    return gp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_BOLDER_TEXT_DECORATION: function() {
                    return vp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_FONT_FAMILY: function() {
                    return jp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_FONT_SIZE: function() {
                    return qp
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_FONT_WEIGHT: function() {
                    return $p
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_LETTER_SPACING: function() {
                    return _x
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_LINE_HEIGHT: function() {
                    return Ox
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_PARAGRAPH_SPACING: function() {
                    return Tx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_TEXT_CASE: function() {
                    return Ex
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_TEXT_DECORATION: function() {
                    return nx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_BOLDER_FONT_FAMILY: function() {
                    return Nx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_BOLDER_FONT_SIZE: function() {
                    return Sx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_BOLDER_FONT_WEIGHT: function() {
                    return Cx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_BOLDER_LETTER_SPACING: function() {
                    return Ax
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_BOLDER_LINE_HEIGHT: function() {
                    return Ix
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_BOLDER_PARAGRAPH_SPACING: function() {
                    return Rx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_BOLDER_TEXT_CASE: function() {
                    return tx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_BOLDER_TEXT_DECORATION: function() {
                    return ux
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_FONT_FAMILY: function() {
                    return rx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_FONT_SIZE: function() {
                    return Mx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_FONT_WEIGHT: function() {
                    return Lx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_LETTER_SPACING: function() {
                    return Kx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_LINE_HEIGHT: function() {
                    return Dx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_PARAGRAPH_SPACING: function() {
                    return ex
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_TEXT_CASE: function() {
                    return ix
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_TEXT_DECORATION: function() {
                    return ox
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_TITLE_FONT_FAMILY: function() {
                    return cx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_TITLE_FONT_SIZE: function() {
                    return Fx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_TITLE_FONT_WEIGHT: function() {
                    return fx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_TITLE_LETTER_SPACING: function() {
                    return Gx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_TITLE_LINE_HEIGHT: function() {
                    return Px
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_TITLE_PARAGRAPH_SPACING: function() {
                    return Bx
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_TITLE_TEXT_CASE: function() {
                    return Ux
                },
                TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_TITLE_TEXT_DECORATION: function() {
                    return Hx
                },
                TOKEN_COSMOS_SNACKPILL_BORDER_RADIUS: function() {
                    return px
                },
                TOKEN_COSMOS_SNACKPILL_BOX_SHADOW_BLUR: function() {
                    return xx
                },
                TOKEN_COSMOS_SNACKPILL_BOX_SHADOW_COLOR: function() {
                    return Yx
                },
                TOKEN_COSMOS_SNACKPILL_BOX_SHADOW_SPREAD: function() {
                    return Vx
                },
                TOKEN_COSMOS_SNACKPILL_BOX_SHADOW_X: function() {
                    return Wx
                },
                TOKEN_COSMOS_SNACKPILL_BOX_SHADOW_Y: function() {
                    return Zx
                },
                TOKEN_COSMOS_SNACKPILL_COLOR_BACKGROUND_DEFAULT: function() {
                    return Xx
                },
                TOKEN_COSMOS_SNACKPILL_COLOR_ICON_DEFAULT: function() {
                    return sx
                },
                TOKEN_COSMOS_SNACKPILL_COLOR_ICON_ERROR: function() {
                    return lx
                },
                TOKEN_COSMOS_SNACKPILL_COLOR_ICON_SUCCESS: function() {
                    return mx
                },
                TOKEN_COSMOS_SNACKPILL_COLOR_ICON_WARNING: function() {
                    return ax
                },
                TOKEN_COSMOS_SNACKPILL_COLOR_TEXT_DEFAULT: function() {
                    return bx
                },
                TOKEN_COSMOS_SNACKPILL_SIZING_ICON: function() {
                    return dx
                },
                TOKEN_COSMOS_SNACKPILL_SIZING_MIN_HEIGHT: function() {
                    return yx
                },
                TOKEN_COSMOS_SNACKPILL_SPACING_GAP_MEDIUM: function() {
                    return Qx
                },
                TOKEN_COSMOS_SNACKPILL_SPACING_GAP_SMALL: function() {
                    return kx
                },
                TOKEN_COSMOS_SNACKPILL_SPACING_HORIZONTAL: function() {
                    return Jx
                },
                TOKEN_COSMOS_SNACKPILL_SPACING_VERTICAL: function() {
                    return hx
                },
                TOKEN_COSMOS_SNACKPILL_TYPOGRAPHY_CONTENT: function() {
                    return zx
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_BORDER_WIDTH_GOOGLE: function() {
                    return wx
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_APPLE: function() {
                    return gx
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_FACEBOOK: function() {
                    return vx
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_GOOGLE: function() {
                    return jx
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_INSTAGRAM: function() {
                    return qx
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BORDER_GOOGLE: function() {
                    return $x
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_CONTENT_DEFAULT: function() {
                    return _Y
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_CONTENT_INVERSE: function() {
                    return OY
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_ICON_DEFAULT: function() {
                    return TY
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_ICON_INVERSE: function() {
                    return EY
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_OVERLAY_HOVER_APPLE: function() {
                    return nY
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_OVERLAY_HOVER_FACEBOOK: function() {
                    return NY
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_OVERLAY_HOVER_GOOGLE: function() {
                    return SY
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_OVERLAY_HOVER_INSTAGRAM: function() {
                    return CY
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_OVERLAY_PRESSED_APPLE: function() {
                    return AY
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_OVERLAY_PRESSED_FACEBOOK: function() {
                    return IY
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_OVERLAY_PRESSED_GOOGLE: function() {
                    return RY
                },
                TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_OVERLAY_PRESSED_INSTAGRAM: function() {
                    return tY
                },
                TOKEN_COSMOS_STACK_SPACING_GAP_COMPACT: function() {
                    return uY
                },
                TOKEN_COSMOS_STACK_SPACING_GAP_LOOSE: function() {
                    return rY
                },
                TOKEN_COSMOS_STACK_SPACING_GAP_TIGHT: function() {
                    return MY
                },
                TOKEN_COSMOS_TABBAR_COLOR_BACKGROUND: function() {
                    return LY
                },
                TOKEN_COSMOS_TABBAR_COLOR_ICON_DEFAULT: function() {
                    return KY
                },
                TOKEN_COSMOS_TABBAR_COLOR_ICON_SELECTED: function() {
                    return DY
                },
                TOKEN_COSMOS_TABBAR_COLOR_TEXT_DEFAULT: function() {
                    return eY
                },
                TOKEN_COSMOS_TABBAR_COLOR_TEXT_SELECTED: function() {
                    return iY
                },
                TOKEN_COSMOS_TABBAR_SIZING_BACKGROUND_BLUR: function() {
                    return oY
                },
                TOKEN_COSMOS_TABBAR_SIZING_ICON: function() {
                    return cY
                },
                TOKEN_COSMOS_TABBAR_SPACING_GAP: function() {
                    return FY
                },
                TOKEN_COSMOS_TABBAR_SPACING_HORIZONTAL: function() {
                    return fY
                },
                TOKEN_COSMOS_TABBAR_SPACING_OFFSET_DOTCOUNTERNOTIFICATION_HIDDEN_HORIZONTAL: function() {
                    return GY
                },
                TOKEN_COSMOS_TABBAR_SPACING_OFFSET_DOTCOUNTERNOTIFICATION_HIDDEN_VERTICAL: function() {
                    return PY
                },
                TOKEN_COSMOS_TABBAR_SPACING_OFFSET_DOTCOUNTERNOTIFICATION_VISIBLE_HORIZONTAL: function() {
                    return BY
                },
                TOKEN_COSMOS_TABBAR_SPACING_OFFSET_DOTCOUNTERNOTIFICATION_VISIBLE_VERTICAL: function() {
                    return UY
                },
                TOKEN_COSMOS_TABBAR_SPACING_VERTICAL_BOTTOM: function() {
                    return HY
                },
                TOKEN_COSMOS_TABBAR_SPACING_VERTICAL_TOP: function() {
                    return pY
                },
                TOKEN_COSMOS_TABBAR_TYPOGRAPHY_TEXT: function() {
                    return xY
                },
                TOKEN_COSMOS_TABS_BORDER_WIDTH_DEFAULT_SELECTED: function() {
                    return YY
                },
                TOKEN_COSMOS_TABS_BORDER_WIDTH_DEFAULT_UNSELECTED: function() {
                    return VY
                },
                TOKEN_COSMOS_TABS_BORDER_WIDTH_INVERSE_SELECTED: function() {
                    return WY
                },
                TOKEN_COSMOS_TABS_BORDER_WIDTH_INVERSE_UNSELECTED: function() {
                    return ZY
                },
                TOKEN_COSMOS_TABS_COLOR_BACKGROUND_DEFAULT: function() {
                    return XY
                },
                TOKEN_COSMOS_TABS_COLOR_BACKGROUND_INVERSE: function() {
                    return sY
                },
                TOKEN_COSMOS_TABS_COLOR_BORDER_DEFAULT_SELECTED: function() {
                    return lY
                },
                TOKEN_COSMOS_TABS_COLOR_BORDER_DEFAULT_UNSELECTED: function() {
                    return mY
                },
                TOKEN_COSMOS_TABS_COLOR_BORDER_INVERSE_SELECTED: function() {
                    return aY
                },
                TOKEN_COSMOS_TABS_COLOR_BORDER_INVERSE_UNSELECTED: function() {
                    return bY
                },
                TOKEN_COSMOS_TABS_COLOR_ICON_DEFAULT_DEFAULT: function() {
                    return dY
                },
                TOKEN_COSMOS_TABS_COLOR_ICON_DEFAULT_SELECTED: function() {
                    return yY
                },
                TOKEN_COSMOS_TABS_COLOR_ICON_INVERSE_DEFAULT: function() {
                    return QY
                },
                TOKEN_COSMOS_TABS_COLOR_ICON_INVERSE_SELECTED: function() {
                    return kY
                },
                TOKEN_COSMOS_TABS_COLOR_TEXT_DEFAULT_SELECTED: function() {
                    return JY
                },
                TOKEN_COSMOS_TABS_COLOR_TEXT_DEFAULT_UNSELECTED: function() {
                    return hY
                },
                TOKEN_COSMOS_TABS_COLOR_TEXT_INVERSE_SELECTED: function() {
                    return zY
                },
                TOKEN_COSMOS_TABS_COLOR_TEXT_INVERSE_UNSELECTED: function() {
                    return wY
                },
                TOKEN_COSMOS_TABS_SIZING_ICON: function() {
                    return gY
                },
                TOKEN_COSMOS_TABS_SPACING_GAP: function() {
                    return vY
                },
                TOKEN_COSMOS_TABS_SPACING_HORIZONTAL: function() {
                    return jY
                },
                TOKEN_COSMOS_TABS_SPACING_ITEM_GAP: function() {
                    return qY
                },
                TOKEN_COSMOS_TABS_SPACING_ITEM_HORIZONTAL: function() {
                    return $Y
                },
                TOKEN_COSMOS_TABS_SPACING_ITEM_VERTICAL: function() {
                    return _V
                },
                TOKEN_COSMOS_TABS_TYPOGRAPHY_TEXT: function() {
                    return OV
                },
                TOKEN_COSMOS_TEXTBUTTON_COLOR_CONTENT_DEFAULT: function() {
                    return TV
                },
                TOKEN_COSMOS_TEXTBUTTON_COLOR_CONTENT_INVERSE: function() {
                    return EV
                },
                TOKEN_COSMOS_TEXTBUTTON_COLOR_ICON_DEFAULT: function() {
                    return nV
                },
                TOKEN_COSMOS_TEXTBUTTON_COLOR_ICON_INVERSE: function() {
                    return NV
                },
                TOKEN_COSMOS_TEXTBUTTON_SIZING_ICON_LARGE: function() {
                    return SV
                },
                TOKEN_COSMOS_TEXTBUTTON_SIZING_ICON_MEDIUM: function() {
                    return CV
                },
                TOKEN_COSMOS_TEXTBUTTON_SIZING_ICON_MINI: function() {
                    return AV
                },
                TOKEN_COSMOS_TEXTBUTTON_SIZING_ICON_SMALL: function() {
                    return IV
                },
                TOKEN_COSMOS_TEXTBUTTON_SPACING_GAP_LARGE: function() {
                    return RV
                },
                TOKEN_COSMOS_TEXTBUTTON_SPACING_GAP_MEDIUM: function() {
                    return tV
                },
                TOKEN_COSMOS_TEXTBUTTON_SPACING_GAP_MINI: function() {
                    return uV
                },
                TOKEN_COSMOS_TEXTBUTTON_SPACING_GAP_SMALL: function() {
                    return rV
                },
                TOKEN_COSMOS_TEXTBUTTON_TYPOGRAPHY_CONTENT_LARGE: function() {
                    return MV
                },
                TOKEN_COSMOS_TEXTBUTTON_TYPOGRAPHY_CONTENT_MEDIUM: function() {
                    return LV
                },
                TOKEN_COSMOS_TEXTBUTTON_TYPOGRAPHY_CONTENT_MINI: function() {
                    return KV
                },
                TOKEN_COSMOS_TEXTBUTTON_TYPOGRAPHY_CONTENT_SMALL: function() {
                    return DV
                },
                TOKEN_COSMOS_TIP_BORDER_RADIUS_MEDIUM: function() {
                    return eV
                },
                TOKEN_COSMOS_TIP_BORDER_RADIUS_SMALL: function() {
                    return iV
                },
                TOKEN_COSMOS_TIP_BORDER_WIDTH_PRIMARY_FLOATING: function() {
                    return oV
                },
                TOKEN_COSMOS_TIP_BORDER_WIDTH_PRIMARY_INLINE: function() {
                    return cV
                },
                TOKEN_COSMOS_TIP_BORDER_WIDTH_SECONDARY_FLOATING: function() {
                    return FV
                },
                TOKEN_COSMOS_TIP_BORDER_WIDTH_SECONDARY_INLINE: function() {
                    return fV
                },
                TOKEN_COSMOS_TIP_COLOR_BACKGROUND_PRIMARY_FLOATING: function() {
                    return GV
                },
                TOKEN_COSMOS_TIP_COLOR_BACKGROUND_PRIMARY_INLINE: function() {
                    return PV
                },
                TOKEN_COSMOS_TIP_COLOR_BACKGROUND_PRIMARY_STICKY: function() {
                    return BV
                },
                TOKEN_COSMOS_TIP_COLOR_BACKGROUND_SECONDARY_FLOATING: function() {
                    return UV
                },
                TOKEN_COSMOS_TIP_COLOR_BACKGROUND_SECONDARY_INLINE: function() {
                    return HV
                },
                TOKEN_COSMOS_TIP_COLOR_BACKGROUND_SECONDARY_STICKY: function() {
                    return pV
                },
                TOKEN_COSMOS_TIP_COLOR_BORDER_PRIMARY_FLOATING: function() {
                    return xV
                },
                TOKEN_COSMOS_TIP_COLOR_BORDER_PRIMARY_INLINE: function() {
                    return YV
                },
                TOKEN_COSMOS_TIP_COLOR_BORDER_SECONDARY_FLOATING: function() {
                    return VV
                },
                TOKEN_COSMOS_TIP_COLOR_BORDER_SECONDARY_INLINE: function() {
                    return WV
                },
                TOKEN_COSMOS_TIP_COLOR_DESCRIPTION_PRIMARY_FLOATING: function() {
                    return ZV
                },
                TOKEN_COSMOS_TIP_COLOR_DESCRIPTION_PRIMARY_INLINE: function() {
                    return XV
                },
                TOKEN_COSMOS_TIP_COLOR_DESCRIPTION_PRIMARY_STICKY: function() {
                    return sV
                },
                TOKEN_COSMOS_TIP_COLOR_DESCRIPTION_SECONDARY_FLOATING: function() {
                    return lV
                },
                TOKEN_COSMOS_TIP_COLOR_DESCRIPTION_SECONDARY_INLINE: function() {
                    return mV
                },
                TOKEN_COSMOS_TIP_COLOR_DESCRIPTION_SECONDARY_STICKY: function() {
                    return aV
                },
                TOKEN_COSMOS_TIP_COLOR_ICON_PRIMARY_FLOATING: function() {
                    return bV
                },
                TOKEN_COSMOS_TIP_COLOR_ICON_PRIMARY_INLINE: function() {
                    return dV
                },
                TOKEN_COSMOS_TIP_COLOR_ICON_PRIMARY_STICKY: function() {
                    return yV
                },
                TOKEN_COSMOS_TIP_COLOR_ICON_SECONDARY_FLOATING: function() {
                    return QV
                },
                TOKEN_COSMOS_TIP_COLOR_ICON_SECONDARY_INLINE: function() {
                    return kV
                },
                TOKEN_COSMOS_TIP_COLOR_ICON_SECONDARY_STICKY: function() {
                    return JV
                },
                TOKEN_COSMOS_TIP_COLOR_REACTIVE_DEFAULT_HOVER: function() {
                    return hV
                },
                TOKEN_COSMOS_TIP_COLOR_REACTIVE_DEFAULT_PRESSED: function() {
                    return zV
                },
                TOKEN_COSMOS_TIP_COLOR_REACTIVE_INVERSE_HOVER: function() {
                    return wV
                },
                TOKEN_COSMOS_TIP_COLOR_REACTIVE_INVERSE_PRESSED: function() {
                    return gV
                },
                TOKEN_COSMOS_TIP_COLOR_TITLE_PRIMARY_FLOATING: function() {
                    return vV
                },
                TOKEN_COSMOS_TIP_COLOR_TITLE_PRIMARY_INLINE: function() {
                    return jV
                },
                TOKEN_COSMOS_TIP_COLOR_TITLE_PRIMARY_STICKY: function() {
                    return qV
                },
                TOKEN_COSMOS_TIP_COLOR_TITLE_SECONDARY_FLOATING: function() {
                    return $V
                },
                TOKEN_COSMOS_TIP_COLOR_TITLE_SECONDARY_INLINE: function() {
                    return _W
                },
                TOKEN_COSMOS_TIP_COLOR_TITLE_SECONDARY_STICKY: function() {
                    return OW
                },
                TOKEN_COSMOS_TIP_SHADOW_FLOATING_BLUR: function() {
                    return TW
                },
                TOKEN_COSMOS_TIP_SHADOW_FLOATING_COLOR: function() {
                    return EW
                },
                TOKEN_COSMOS_TIP_SHADOW_FLOATING_SPREAD: function() {
                    return nW
                },
                TOKEN_COSMOS_TIP_SHADOW_FLOATING_X: function() {
                    return NW
                },
                TOKEN_COSMOS_TIP_SHADOW_FLOATING_Y: function() {
                    return SW
                },
                TOKEN_COSMOS_TIP_SHADOW_INLINE_BLUR: function() {
                    return CW
                },
                TOKEN_COSMOS_TIP_SHADOW_INLINE_COLOR: function() {
                    return AW
                },
                TOKEN_COSMOS_TIP_SHADOW_INLINE_SPREAD: function() {
                    return IW
                },
                TOKEN_COSMOS_TIP_SHADOW_INLINE_X: function() {
                    return RW
                },
                TOKEN_COSMOS_TIP_SHADOW_INLINE_Y: function() {
                    return tW
                },
                TOKEN_COSMOS_TIP_SHADOW_NONE_BLUR: function() {
                    return uW
                },
                TOKEN_COSMOS_TIP_SHADOW_NONE_COLOR: function() {
                    return rW
                },
                TOKEN_COSMOS_TIP_SHADOW_NONE_SPREAD: function() {
                    return MW
                },
                TOKEN_COSMOS_TIP_SHADOW_NONE_X: function() {
                    return LW
                },
                TOKEN_COSMOS_TIP_SHADOW_NONE_Y: function() {
                    return KW
                },
                TOKEN_COSMOS_TIP_SIZING_BACKGROUND_BLUR_PRIMARY_FLOATING: function() {
                    return DW
                },
                TOKEN_COSMOS_TIP_SIZING_BACKGROUND_BLUR_PRIMARY_STICKY: function() {
                    return eW
                },
                TOKEN_COSMOS_TIP_SIZING_BACKGROUND_BLUR_SECONDARY_FLOATING: function() {
                    return iW
                },
                TOKEN_COSMOS_TIP_SIZING_BACKGROUND_BLUR_SECONDARY_STICKY: function() {
                    return oW
                },
                TOKEN_COSMOS_TIP_SIZING_ICON_START_MEDIUM: function() {
                    return cW
                },
                TOKEN_COSMOS_TIP_SIZING_ICON_START_SMALL: function() {
                    return FW
                },
                TOKEN_COSMOS_TIP_SIZING_MIN_HEIGHT_CONTAINER: function() {
                    return fW
                },
                TOKEN_COSMOS_TIP_SPACING_GAP_HORIZONTAL_LARGE: function() {
                    return GW
                },
                TOKEN_COSMOS_TIP_SPACING_GAP_HORIZONTAL_MEDIUM: function() {
                    return PW
                },
                TOKEN_COSMOS_TIP_SPACING_GAP_HORIZONTAL_SMALL: function() {
                    return BW
                },
                TOKEN_COSMOS_TIP_SPACING_GAP_VERTICAL_MEDIUM: function() {
                    return UW
                },
                TOKEN_COSMOS_TIP_SPACING_GAP_VERTICAL_SMALL: function() {
                    return HW
                },
                TOKEN_COSMOS_TIP_SPACING_HORIZONTAL_END_LARGE: function() {
                    return pW
                },
                TOKEN_COSMOS_TIP_SPACING_HORIZONTAL_END_MEDIUM: function() {
                    return xW
                },
                TOKEN_COSMOS_TIP_SPACING_HORIZONTAL_END_SMALL: function() {
                    return YW
                },
                TOKEN_COSMOS_TIP_SPACING_HORIZONTAL_START_LARGE: function() {
                    return VW
                },
                TOKEN_COSMOS_TIP_SPACING_HORIZONTAL_START_MEDIUM: function() {
                    return WW
                },
                TOKEN_COSMOS_TIP_SPACING_VERTICAL: function() {
                    return ZW
                },
                TOKEN_COSMOS_TIP_TYPOGRAPHY_DESCRIPTION: function() {
                    return XW
                },
                TOKEN_COSMOS_TIP_TYPOGRAPHY_TITLE: function() {
                    return sW
                },
                TOKEN_COSMOS_TOGGLE_BORDER_RADIUS: function() {
                    return lW
                },
                TOKEN_COSMOS_TOGGLE_BORDER_WIDTH_DEFAULT_SELECTED: function() {
                    return mW
                },
                TOKEN_COSMOS_TOGGLE_BORDER_WIDTH_DEFAULT_UNSELECTED: function() {
                    return aW
                },
                TOKEN_COSMOS_TOGGLE_BORDER_WIDTH_INVERSE_SELECTED: function() {
                    return bW
                },
                TOKEN_COSMOS_TOGGLE_BORDER_WIDTH_INVERSE_UNSELECTED: function() {
                    return dW
                },
                TOKEN_COSMOS_TOGGLE_COLOR_BACKGROUND_DEFAULT_SELECTED: function() {
                    return yW
                },
                TOKEN_COSMOS_TOGGLE_COLOR_BACKGROUND_DEFAULT_UNSELECTED: function() {
                    return QW
                },
                TOKEN_COSMOS_TOGGLE_COLOR_BACKGROUND_INVERSE_SELECTED: function() {
                    return kW
                },
                TOKEN_COSMOS_TOGGLE_COLOR_BACKGROUND_INVERSE_UNSELECTED: function() {
                    return JW
                },
                TOKEN_COSMOS_TOGGLE_COLOR_BORDER_DEFAULT_SELECTED: function() {
                    return hW
                },
                TOKEN_COSMOS_TOGGLE_COLOR_BORDER_DEFAULT_UNSELECTED: function() {
                    return zW
                },
                TOKEN_COSMOS_TOGGLE_COLOR_BORDER_INVERSE_SELECTED: function() {
                    return wW
                },
                TOKEN_COSMOS_TOGGLE_COLOR_BORDER_INVERSE_UNSELECTED: function() {
                    return gW
                },
                TOKEN_COSMOS_TOGGLE_COLOR_HANDLE_DEFAULT_SELECTED: function() {
                    return vW
                },
                TOKEN_COSMOS_TOGGLE_COLOR_HANDLE_DEFAULT_UNSELECTED: function() {
                    return jW
                },
                TOKEN_COSMOS_TOGGLE_COLOR_HANDLE_INVERSE_SELECTED: function() {
                    return qW
                },
                TOKEN_COSMOS_TOGGLE_COLOR_HANDLE_INVERSE_UNSELECTED: function() {
                    return $W
                },
                TOKEN_COSMOS_TOGGLE_SIZING_HANDLE: function() {
                    return _Z
                },
                TOKEN_COSMOS_TOGGLE_SPACING_HORIZONTAL_END_SELECTED: function() {
                    return OZ
                },
                TOKEN_COSMOS_TOGGLE_SPACING_HORIZONTAL_END_UNSELECTED: function() {
                    return TZ
                },
                TOKEN_COSMOS_TOGGLE_SPACING_HORIZONTAL_START_SELECTED: function() {
                    return EZ
                },
                TOKEN_COSMOS_TOGGLE_SPACING_HORIZONTAL_START_UNSELECTED: function() {
                    return nZ
                },
                TOKEN_COSMOS_TOGGLE_SPACING_VERTICAL: function() {
                    return NZ
                },
                TOKEN_COSMOS_TOOLTIP_BORDER_RADIUS: function() {
                    return SZ
                },
                TOKEN_COSMOS_TOOLTIP_COLOR_BACKGROUND: function() {
                    return CZ
                },
                TOKEN_COSMOS_TOOLTIP_COLOR_CONTENT: function() {
                    return AZ
                },
                TOKEN_COSMOS_TOOLTIP_SIZING_BEAK_HEIGHT: function() {
                    return IZ
                },
                TOKEN_COSMOS_TOOLTIP_SIZING_BEAK_WIDTH: function() {
                    return RZ
                },
                TOKEN_COSMOS_TOOLTIP_SPACING_GAP_END: function() {
                    return tZ
                },
                TOKEN_COSMOS_TOOLTIP_SPACING_GAP_LEFT: function() {
                    return uZ
                },
                TOKEN_COSMOS_TOOLTIP_SPACING_GAP_RIGHT: function() {
                    return rZ
                },
                TOKEN_COSMOS_TOOLTIP_SPACING_GAP_START: function() {
                    return MZ
                },
                TOKEN_COSMOS_TOOLTIP_SPACING_HORIZONTAL: function() {
                    return LZ
                },
                TOKEN_COSMOS_TOOLTIP_SPACING_VERTICAL: function() {
                    return KZ
                },
                TOKEN_COSMOS_TOOLTIP_TYPOGRAPHY_CONTENT: function() {
                    return DZ
                },
                TOKEN_CTABOX_COMPACT_ADDITIONAL_MARGIN_TOP: function() {
                    return eZ
                },
                TOKEN_CTABOX_COMPACT_BUTTONS_MARGIN_TOP: function() {
                    return iZ
                },
                TOKEN_CTABOX_COMPACT_CONTENT_MARGIN_TOP: function() {
                    return oZ
                },
                TOKEN_CTABOX_COMPACT_HEADER_MARGIN_BOTTOM: function() {
                    return cZ
                },
                TOKEN_CTABOX_COMPACT_MEDIA_ICON_SIZE: function() {
                    return FZ
                },
                TOKEN_CTABOX_COMPACT_MEDIA_MARGIN_BOTTOM: function() {
                    return fZ
                },
                TOKEN_CTABOX_COMPACT_TEXT_GAP: function() {
                    return GZ
                },
                TOKEN_CTABOX_MAX_WIDTH: function() {
                    return PZ
                },
                TOKEN_CTABOX_NORMAL_ADDITIONAL_MARGIN_TOP: function() {
                    return BZ
                },
                TOKEN_CTABOX_NORMAL_BUTTONS_MARGIN_TOP: function() {
                    return UZ
                },
                TOKEN_CTABOX_NORMAL_CONTENT_MARGIN_TOP: function() {
                    return HZ
                },
                TOKEN_CTABOX_NORMAL_HEADER_MARGIN_BOTTOM: function() {
                    return pZ
                },
                TOKEN_CTABOX_NORMAL_MEDIA_ICON_SIZE: function() {
                    return xZ
                },
                TOKEN_CTABOX_NORMAL_MEDIA_MARGIN_BOTTOM: function() {
                    return YZ
                },
                TOKEN_CTABOX_NORMAL_TEXT_GAP: function() {
                    return VZ
                },
                TOKEN_DATE_FIELD_ITEM_HORIZONTAL_GAP: function() {
                    return WZ
                },
                TOKEN_DATE_FIELD_ITEM_MIN_WIDTH_2: function() {
                    return ZZ
                },
                TOKEN_DATE_FIELD_ITEM_MIN_WIDTH_4: function() {
                    return XZ
                },
                TOKEN_DOTCOUNTERNOTIFICATION_ANIMATION_TIMING_BOUNCE: function() {
                    return sZ
                },
                TOKEN_DOTCOUNTERNOTIFICATION_ANIMATION_TIMING_POPOUT: function() {
                    return lZ
                },
                TOKEN_DOTCOUNTERNOTIFICATION_COUNTER_FONT_SIZE: function() {
                    return mZ
                },
                TOKEN_DOTCOUNTERNOTIFICATION_COUNTER_MIN_SIZE: function() {
                    return aZ
                },
                TOKEN_DOTCOUNTERNOTIFICATION_COUNTER_OUTER_BORDER_WIDTH: function() {
                    return bZ
                },
                TOKEN_DOTCOUNTERNOTIFICATION_DOT_OUTER_BORDER_WIDTH: function() {
                    return dZ
                },
                TOKEN_DOTCOUNTERNOTIFICATION_DOT_SIZE: function() {
                    return yZ
                },
                TOKEN_EDIT_PROFILE_BLOCK_BACKGROUND_COLOR: function() {
                    return QZ
                },
                TOKEN_EDIT_PROFILE_BLOCK_BORDER_RADIUS: function() {
                    return kZ
                },
                TOKEN_EDIT_PROFILE_BLOCK_CHEVRON_COLOR: function() {
                    return JZ
                },
                TOKEN_EDIT_PROFILE_BLOCK_CHEVRON_MARGIN_LEFT: function() {
                    return hZ
                },
                TOKEN_EDIT_PROFILE_BLOCK_CHEVRON_SIZE: function() {
                    return zZ
                },
                TOKEN_EDIT_PROFILE_BLOCK_GAP: function() {
                    return wZ
                },
                TOKEN_EDIT_PROFILE_BLOCK_HEADER_ICON_SIZE: function() {
                    return gZ
                },
                TOKEN_EDIT_PROFILE_BLOCK_HEADER_ITEM_GAP: function() {
                    return vZ
                },
                TOKEN_EDIT_PROFILE_BLOCK_HEADER_MARGIN_BOTTOM: function() {
                    return jZ
                },
                TOKEN_EDIT_PROFILE_BLOCK_PADDING_HORIZONTAL: function() {
                    return qZ
                },
                TOKEN_EDIT_PROFILE_BLOCK_PADDING_VERTICAL: function() {
                    return $Z
                },
                TOKEN_FONT_FAMILY_ACTION: function() {
                    return _X
                },
                TOKEN_FONT_FAMILY_ACTION_MINI: function() {
                    return OX
                },
                TOKEN_FONT_FAMILY_ACTION_SMALL: function() {
                    return TX
                },
                TOKEN_FONT_FAMILY_CUSTOM: function() {
                    return EX
                },
                TOKEN_FONT_FAMILY_DISPLAY_1: function() {
                    return nX
                },
                TOKEN_FONT_FAMILY_DISPLAY_2: function() {
                    return NX
                },
                TOKEN_FONT_FAMILY_DISPLAY_3: function() {
                    return SX
                },
                TOKEN_FONT_FAMILY_HEADER_1: function() {
                    return CX
                },
                TOKEN_FONT_FAMILY_HEADER_2: function() {
                    return AX
                },
                TOKEN_FONT_FAMILY_HEADER_3: function() {
                    return IX
                },
                TOKEN_FONT_FAMILY_HEADER_4: function() {
                    return RX
                },
                TOKEN_FONT_FAMILY_PARAGRAPH_1: function() {
                    return tX
                },
                TOKEN_FONT_FAMILY_PARAGRAPH_1_BOLDER: function() {
                    return uX
                },
                TOKEN_FONT_FAMILY_PARAGRAPH_2: function() {
                    return rX
                },
                TOKEN_FONT_FAMILY_PARAGRAPH_2_BOLDER: function() {
                    return MX
                },
                TOKEN_FONT_FAMILY_PARAGRAPH_3: function() {
                    return LX
                },
                TOKEN_FONT_FAMILY_PARAGRAPH_3_BOLDER: function() {
                    return KX
                },
                TOKEN_FONT_FAMILY_TITLE: function() {
                    return DX
                },
                TOKEN_FONT_SIZE_ACTION: function() {
                    return eX
                },
                TOKEN_FONT_SIZE_ACTION_MINI: function() {
                    return iX
                },
                TOKEN_FONT_SIZE_ACTION_SMALL: function() {
                    return oX
                },
                TOKEN_FONT_SIZE_DISPLAY_1: function() {
                    return cX
                },
                TOKEN_FONT_SIZE_DISPLAY_2: function() {
                    return FX
                },
                TOKEN_FONT_SIZE_DISPLAY_3: function() {
                    return fX
                },
                TOKEN_FONT_SIZE_HEADER_1: function() {
                    return GX
                },
                TOKEN_FONT_SIZE_HEADER_2: function() {
                    return PX
                },
                TOKEN_FONT_SIZE_HEADER_3: function() {
                    return BX
                },
                TOKEN_FONT_SIZE_HEADER_4: function() {
                    return UX
                },
                TOKEN_FONT_SIZE_PARAGRAPH_1: function() {
                    return HX
                },
                TOKEN_FONT_SIZE_PARAGRAPH_1_BOLDER: function() {
                    return pX
                },
                TOKEN_FONT_SIZE_PARAGRAPH_2: function() {
                    return xX
                },
                TOKEN_FONT_SIZE_PARAGRAPH_2_BOLDER: function() {
                    return YX
                },
                TOKEN_FONT_SIZE_PARAGRAPH_3: function() {
                    return VX
                },
                TOKEN_FONT_SIZE_PARAGRAPH_3_BOLDER: function() {
                    return WX
                },
                TOKEN_FONT_SIZE_TITLE: function() {
                    return ZX
                },
                TOKEN_FONT_WEIGHT_ACTION: function() {
                    return XX
                },
                TOKEN_FONT_WEIGHT_ACTION_MINI: function() {
                    return sX
                },
                TOKEN_FONT_WEIGHT_ACTION_SMALL: function() {
                    return lX
                },
                TOKEN_FONT_WEIGHT_DISPLAY_1: function() {
                    return mX
                },
                TOKEN_FONT_WEIGHT_DISPLAY_2: function() {
                    return aX
                },
                TOKEN_FONT_WEIGHT_DISPLAY_3: function() {
                    return bX
                },
                TOKEN_FONT_WEIGHT_HEADER_1: function() {
                    return dX
                },
                TOKEN_FONT_WEIGHT_HEADER_2: function() {
                    return yX
                },
                TOKEN_FONT_WEIGHT_HEADER_3: function() {
                    return QX
                },
                TOKEN_FONT_WEIGHT_HEADER_4: function() {
                    return kX
                },
                TOKEN_FONT_WEIGHT_PARAGRAPH_1: function() {
                    return JX
                },
                TOKEN_FONT_WEIGHT_PARAGRAPH_1_BOLDER: function() {
                    return hX
                },
                TOKEN_FONT_WEIGHT_PARAGRAPH_2: function() {
                    return zX
                },
                TOKEN_FONT_WEIGHT_PARAGRAPH_2_BOLDER: function() {
                    return wX
                },
                TOKEN_FONT_WEIGHT_PARAGRAPH_3: function() {
                    return gX
                },
                TOKEN_FONT_WEIGHT_PARAGRAPH_3_BOLDER: function() {
                    return vX
                },
                TOKEN_FONT_WEIGHT_TITLE: function() {
                    return jX
                },
                TOKEN_FORM_ACTIONS_MARGIN_TOP: function() {
                    return qX
                },
                TOKEN_FORM_CONTROL_GAP_VERTICAL: function() {
                    return $X
                },
                TOKEN_FORM_HINT_MARGIN_TOP: function() {
                    return _s
                },
                TOKEN_FORM_LABEL_COLOR: function() {
                    return Os
                },
                TOKEN_FORM_LABEL_MARGIN_BOTTOM: function() {
                    return Ts
                },
                TOKEN_FORM_MAX_WIDTH: function() {
                    return Es
                },
                TOKEN_FORM_NOTE_COLOR_ERROR: function() {
                    return ns
                },
                TOKEN_FORM_NOTE_COLOR_HINT: function() {
                    return Ns
                },
                TOKEN_FORM_NOTE_COLOR_SUCCESS: function() {
                    return Ss
                },
                TOKEN_FORM_NOTE_EXTRA_MARGIN_LEFT: function() {
                    return Cs
                },
                TOKEN_FORM_NOTE_ICON_MARGIN_RIGHT: function() {
                    return As
                },
                TOKEN_FORM_NOTE_ICON_SIZE: function() {
                    return Is
                },
                TOKEN_FORM_NOTE_MARGIN_TOP: function() {
                    return Rs
                },
                TOKEN_FORM_TEXT_GAP: function() {
                    return ts
                },
                TOKEN_FORM_TEXT_MARGIN_BOTTOM: function() {
                    return us
                },
                TOKEN_GIFT_WRAP_COLOR_DEFAULT: function() {
                    return rs
                },
                TOKEN_GIFT_WRAP_COLOR_VARIANT_1: function() {
                    return Ms
                },
                TOKEN_GIFT_WRAP_COLOR_VARIANT_2: function() {
                    return Ls
                },
                TOKEN_GIFT_WRAP_COLOR_VARIANT_3: function() {
                    return Ks
                },
                TOKEN_GIFT_WRAP_COLOR_VARIANT_4: function() {
                    return Ds
                },
                TOKEN_GIFT_WRAP_COLOR_VARIANT_5: function() {
                    return es
                },
                TOKEN_GIFT_WRAP_COLOR_VARIANT_6: function() {
                    return is
                },
                TOKEN_GIFT_WRAP_COLOR_VARIANT_7: function() {
                    return os
                },
                TOKEN_GIFT_WRAP_COLOR_VARIANT_8: function() {
                    return cs
                },
                TOKEN_GIFT_WRAP_COLOR_VARIANT_9: function() {
                    return Fs
                },
                TOKEN_GRID_LIST_SPACING_LG: function() {
                    return fs
                },
                TOKEN_GRID_LIST_SPACING_MD: function() {
                    return Gs
                },
                TOKEN_GRID_LIST_SPACING_SM: function() {
                    return Ps
                },
                TOKEN_GRID_LIST_SPACING_XLG: function() {
                    return Bs
                },
                TOKEN_HINT_FONT_FAMILY: function() {
                    return Us
                },
                TOKEN_HINT_FONT_SIZE: function() {
                    return Hs
                },
                TOKEN_HINT_FONT_WEIGHT: function() {
                    return ps
                },
                TOKEN_HINT_GAP_VERTICAL: function() {
                    return xs
                },
                TOKEN_HINT_LINE_HEIGHT: function() {
                    return Ys
                },
                TOKEN_ICON_JUMBO_SIZE_LG: function() {
                    return Vs
                },
                TOKEN_ICON_JUMBO_SIZE_MD: function() {
                    return Ws
                },
                TOKEN_ICON_JUMBO_SIZE_SM: function() {
                    return Zs
                },
                TOKEN_ICON_SIZE_LG: function() {
                    return Xs
                },
                TOKEN_ICON_SIZE_MD: function() {
                    return ss
                },
                TOKEN_ICON_SIZE_SM: function() {
                    return ls
                },
                TOKEN_ICON_SIZE_XLG: function() {
                    return ms
                },
                TOKEN_ICON_SIZE_XSM: function() {
                    return as
                },
                TOKEN_ICON_SIZE_XXLG: function() {
                    return bs
                },
                TOKEN_INAPPNOTIFICATION_BACKGROUND_COLOR: function() {
                    return ds
                },
                TOKEN_INAPPNOTIFICATION_BADGE_SIZE: function() {
                    return ys
                },
                TOKEN_INAPPNOTIFICATION_BORDER_RADIUS: function() {
                    return Qs
                },
                TOKEN_INAPPNOTIFICATION_CONTENT_COLOR: function() {
                    return ks
                },
                TOKEN_INAPPNOTIFICATION_ICON_COLOR: function() {
                    return Js
                },
                TOKEN_INAPPNOTIFICATION_ICON_SIZE: function() {
                    return hs
                },
                TOKEN_INAPPNOTIFICATION_IMAGE_MARGIN_RIGHT: function() {
                    return zs
                },
                TOKEN_INAPPNOTIFICATION_IMAGE_SIZE: function() {
                    return ws
                },
                TOKEN_INAPPNOTIFICATION_INSET_HORIZONTAL: function() {
                    return gs
                },
                TOKEN_INAPPNOTIFICATION_INSET_VERTICAL: function() {
                    return vs
                },
                TOKEN_INPUT_CHOICE_BORDER_RADIUS_CHECKBOX: function() {
                    return js
                },
                TOKEN_INPUT_CHOICE_BORDER_RADIUS_RADIO: function() {
                    return qs
                },
                TOKEN_INPUT_CHOICE_COLOR_BASE_SELECTED: function() {
                    return $s
                },
                TOKEN_INPUT_CHOICE_COLOR_BASE_SELECTED_BACKGROUND: function() {
                    return _l
                },
                TOKEN_INPUT_CHOICE_COLOR_BASE_SELECTED_FOREGROUND: function() {
                    return Ol
                },
                TOKEN_INPUT_CHOICE_COLOR_BASE_STATUS_ERROR_BACKGROUND: function() {
                    return Tl
                },
                TOKEN_INPUT_CHOICE_COLOR_BASE_STATUS_ERROR_FOREGROUND: function() {
                    return El
                },
                TOKEN_INPUT_CHOICE_COLOR_BASE_UNSELECTED: function() {
                    return nl
                },
                TOKEN_INPUT_CHOICE_COLOR_BASE_UNSELECTED_BACKGROUND: function() {
                    return Nl
                },
                TOKEN_INPUT_CHOICE_COLOR_BASE_UNSELECTED_FOREGROUND: function() {
                    return Sl
                },
                TOKEN_INPUT_CHOICE_COLOR_WHITE_SELECTED_BACKGROUND: function() {
                    return Cl
                },
                TOKEN_INPUT_CHOICE_COLOR_WHITE_SELECTED_FOREGROUND: function() {
                    return Al
                },
                TOKEN_INPUT_CHOICE_COLOR_WHITE_STATUS_ERROR_BACKGROUND: function() {
                    return Il
                },
                TOKEN_INPUT_CHOICE_COLOR_WHITE_STATUS_ERROR_FOREGROUND: function() {
                    return Rl
                },
                TOKEN_INPUT_CHOICE_COLOR_WHITE_UNSELECTED_BACKGROUND: function() {
                    return tl
                },
                TOKEN_INPUT_CHOICE_COLOR_WHITE_UNSELECTED_FOREGROUND: function() {
                    return ul
                },
                TOKEN_INPUT_CHOICE_SIZE: function() {
                    return rl
                },
                TOKEN_INPUT_CHOICE_STATUS_DISABLED_OPACITY: function() {
                    return Ml
                },
                TOKEN_INPUT_SEARCH_BORDER_RADIUS_ROUNDED: function() {
                    return Ll
                },
                TOKEN_INPUT_SEARCH_BORDER_RADIUS_SQUARED: function() {
                    return Kl
                },
                TOKEN_INPUT_SEARCH_CLEAR_COLOR: function() {
                    return Dl
                },
                TOKEN_INPUT_SEARCH_CLEAR_MARGIN_RIGHT: function() {
                    return el
                },
                TOKEN_INPUT_SEARCH_CLEAR_SIZE: function() {
                    return il
                },
                TOKEN_INPUT_SEARCH_HEIGHT: function() {
                    return ol
                },
                TOKEN_INPUT_SEARCH_ICON_COLOR: function() {
                    return cl
                },
                TOKEN_INPUT_SEARCH_ICON_MARGIN_LEFT: function() {
                    return Fl
                },
                TOKEN_INPUT_SEARCH_ICON_MARGIN_RIGHT: function() {
                    return fl
                },
                TOKEN_INPUT_SEARCH_ICON_SIZE: function() {
                    return Gl
                },
                TOKEN_INPUT_SEARCH_INPUT_MARGIN_RIGHT: function() {
                    return Pl
                },
                TOKEN_INPUT_SEARCH_INPUT_PLACEHOLDER_COLOR: function() {
                    return Bl
                },
                TOKEN_INPUT_SEARCH_INPUT_TEXT_COLOR: function() {
                    return Ul
                },
                TOKEN_INPUT_TOGGLE_ANIMATION_TRANSITION_DURATION: function() {
                    return Hl
                },
                TOKEN_INPUT_TOGGLE_BORDER_WIDTH: function() {
                    return pl
                },
                TOKEN_INPUT_TOGGLE_COLOR_BASE_SELECTED: function() {
                    return xl
                },
                TOKEN_INPUT_TOGGLE_COLOR_BASE_SELECTED_BACKGROUND: function() {
                    return Yl
                },
                TOKEN_INPUT_TOGGLE_COLOR_BASE_SELECTED_BORDER: function() {
                    return Vl
                },
                TOKEN_INPUT_TOGGLE_COLOR_BASE_SELECTED_THUMB: function() {
                    return Wl
                },
                TOKEN_INPUT_TOGGLE_COLOR_BASE_UNSELECTED: function() {
                    return Zl
                },
                TOKEN_INPUT_TOGGLE_COLOR_BASE_UNSELECTED_BACKGROUND: function() {
                    return Xl
                },
                TOKEN_INPUT_TOGGLE_COLOR_BASE_UNSELECTED_BORDER: function() {
                    return sl
                },
                TOKEN_INPUT_TOGGLE_COLOR_BASE_UNSELECTED_THUMB: function() {
                    return ll
                },
                TOKEN_INPUT_TOGGLE_HEIGHT: function() {
                    return ml
                },
                TOKEN_INPUT_TOGGLE_THUMB_SIZE: function() {
                    return al
                },
                TOKEN_INPUT_TOGGLE_WIDTH: function() {
                    return bl
                },
                TOKEN_LINE_HEIGHT_ACTION: function() {
                    return dl
                },
                TOKEN_LINE_HEIGHT_ACTION_MINI: function() {
                    return yl
                },
                TOKEN_LINE_HEIGHT_ACTION_SMALL: function() {
                    return Ql
                },
                TOKEN_LINE_HEIGHT_DISPLAY_1: function() {
                    return kl
                },
                TOKEN_LINE_HEIGHT_DISPLAY_2: function() {
                    return Jl
                },
                TOKEN_LINE_HEIGHT_DISPLAY_3: function() {
                    return hl
                },
                TOKEN_LINE_HEIGHT_HEADER_1: function() {
                    return zl
                },
                TOKEN_LINE_HEIGHT_HEADER_2: function() {
                    return wl
                },
                TOKEN_LINE_HEIGHT_HEADER_3: function() {
                    return gl
                },
                TOKEN_LINE_HEIGHT_HEADER_4: function() {
                    return vl
                },
                TOKEN_LINE_HEIGHT_PARAGRAPH_1: function() {
                    return jl
                },
                TOKEN_LINE_HEIGHT_PARAGRAPH_1_BOLDER: function() {
                    return ql
                },
                TOKEN_LINE_HEIGHT_PARAGRAPH_2: function() {
                    return $l
                },
                TOKEN_LINE_HEIGHT_PARAGRAPH_2_BOLDER: function() {
                    return _m
                },
                TOKEN_LINE_HEIGHT_PARAGRAPH_3: function() {
                    return Om
                },
                TOKEN_LINE_HEIGHT_PARAGRAPH_3_BOLDER: function() {
                    return Tm
                },
                TOKEN_LINE_HEIGHT_TITLE: function() {
                    return Em
                },
                TOKEN_LISTBOX_BORDER_COLOR: function() {
                    return nm
                },
                TOKEN_LISTBOX_BORDER_RADIUS: function() {
                    return Nm
                },
                TOKEN_LISTBOX_BORDER_WIDTH: function() {
                    return Sm
                },
                TOKEN_LISTBOX_HINT_PADDING_HORIZONTAL: function() {
                    return Cm
                },
                TOKEN_LISTBOX_HINT_PADDING_VERTICAL: function() {
                    return Am
                },
                TOKEN_LISTBOX_HINT_TEXT_COLOR: function() {
                    return Im
                },
                TOKEN_LISTBOX_ITEM_BASE_BACKGROUND_COLOR: function() {
                    return Rm
                },
                TOKEN_LISTBOX_ITEM_BASE_TEXT_COLOR: function() {
                    return tm
                },
                TOKEN_LISTBOX_ITEM_ICON_MARGIN_START: function() {
                    return um
                },
                TOKEN_LISTBOX_ITEM_ICON_SIZE: function() {
                    return rm
                },
                TOKEN_LISTBOX_ITEM_PADDING_HORIZONTAL: function() {
                    return Mm
                },
                TOKEN_LISTBOX_ITEM_PADDING_VERTICAL: function() {
                    return Lm
                },
                TOKEN_LISTBOX_ITEM_SELECTED_BACKGROUND_COLOR: function() {
                    return Km
                },
                TOKEN_LISTBOX_ITEM_SELECTED_TEXT_COLOR: function() {
                    return Dm
                },
                TOKEN_LISTBOX_PADDING_VERTICAL: function() {
                    return em
                },
                TOKEN_MARK_BORDER_RADIUS: function() {
                    return im
                },
                TOKEN_MARK_ICON_SIZE: function() {
                    return om
                },
                TOKEN_MARK_PADDING_HORIZONTAL: function() {
                    return cm
                },
                TOKEN_MARK_SHADOW_BLUR_RADIUS: function() {
                    return Fm
                },
                TOKEN_MARK_SHADOW_COLOR: function() {
                    return fm
                },
                TOKEN_MARK_SHADOW_OPACITY: function() {
                    return Gm
                },
                TOKEN_MARK_SHADOW_VERTICAL_OFFSET: function() {
                    return Pm
                },
                TOKEN_MARK_SIZE: function() {
                    return Bm
                },
                TOKEN_MARK_SPACING_ICON_TEXT: function() {
                    return Um
                },
                TOKEN_MATCH_PHOTOS_BORDER_COLOR: function() {
                    return Hm
                },
                TOKEN_MATCH_PHOTOS_BORDER_RADIUS: function() {
                    return pm
                },
                TOKEN_MATCH_PHOTOS_ICON_TO_IMAGE_SIZE_RATIO: function() {
                    return xm
                },
                TOKEN_MATCH_PHOTOS_IMAGE_LEFT_ROTATE: function() {
                    return Ym
                },
                TOKEN_MATCH_PHOTOS_IMAGE_LEFT_STACK_INDEX: function() {
                    return Vm
                },
                TOKEN_MATCH_PHOTOS_IMAGE_LEFT_TRANSLATE_X: function() {
                    return Wm
                },
                TOKEN_MATCH_PHOTOS_IMAGE_LEFT_TRANSLATE_Y: function() {
                    return Zm
                },
                TOKEN_MATCH_PHOTOS_IMAGE_RIGHT_ROTATE: function() {
                    return Xm
                },
                TOKEN_MATCH_PHOTOS_IMAGE_RIGHT_STACK_INDEX: function() {
                    return sm
                },
                TOKEN_MATCH_PHOTOS_IMAGE_RIGHT_TRANSLATE_X: function() {
                    return lm
                },
                TOKEN_MATCH_PHOTOS_IMAGE_RIGHT_TRANSLATE_Y: function() {
                    return mm
                },
                TOKEN_MATCH_PHOTOS_LG_BORDER_WIDTH: function() {
                    return am
                },
                TOKEN_MATCH_PHOTOS_LG_IMAGE_SIZE: function() {
                    return bm
                },
                TOKEN_MATCH_PHOTOS_MD_BORDER_WIDTH: function() {
                    return dm
                },
                TOKEN_MATCH_PHOTOS_MD_IMAGE_SIZE: function() {
                    return ym
                },
                TOKEN_MATCH_PHOTOS_XLG_BORDER_WIDTH: function() {
                    return Qm
                },
                TOKEN_MATCH_PHOTOS_XLG_IMAGE_SIZE: function() {
                    return km
                },
                TOKEN_MOCKCARD_BORDER_COLOR: function() {
                    return Jm
                },
                TOKEN_MOCKCARD_BORDER_RADIUS_ROUNDED: function() {
                    return hm
                },
                TOKEN_MOCKCARD_BORDER_RADIUS_SQUARED: function() {
                    return zm
                },
                TOKEN_MOCKCARD_BORDER_WIDTH: function() {
                    return wm
                },
                TOKEN_MOCKCARD_CLOSE_ICON_MARGIN_RIGHT: function() {
                    return gm
                },
                TOKEN_MOCKCARD_CLOSE_ICON_MARGIN_TOP: function() {
                    return vm
                },
                TOKEN_MOCKCARD_CLOSE_ICON_SIZE: function() {
                    return jm
                },
                TOKEN_MOCKCARD_CORNER_ICON_COLOR: function() {
                    return qm
                },
                TOKEN_MOCKCARD_CORNER_ICON_SIZE: function() {
                    return $m
                },
                TOKEN_MOCKCARD_MIN_HEIGHT: function() {
                    return _a
                },
                TOKEN_MOCKCARD_PADDING_HORIZONTAL: function() {
                    return Oa
                },
                TOKEN_MOCKCARD_PADDING_VERTICAL: function() {
                    return Ta
                },
                TOKEN_MOCKCARD_SPACING_ACTION_MARGIN_TOP: function() {
                    return Ea
                },
                TOKEN_MOCKCARD_SPACING_MEDIA_CONTENT: function() {
                    return na
                },
                TOKEN_MOCKCARD_SPACING_TITLE_TEXT: function() {
                    return Na
                },
                TOKEN_MOCKCARD_TEXT_MAX_LINES: function() {
                    return Sa
                },
                TOKEN_MOCKCARD_TITLE_MAX_LINES: function() {
                    return Ca
                },
                TOKEN_MODAL_BORDER_RADIUS: function() {
                    return Aa
                },
                TOKEN_MODAL_BOTTOM_DRAWER_PADDING_EXTRA_BOTTOM: function() {
                    return Ia
                },
                TOKEN_MODAL_BOTTOM_OUTSET_SPACE: function() {
                    return Ra
                },
                TOKEN_MODAL_MAX_HEIGHT: function() {
                    return ta
                },
                TOKEN_MODAL_MAX_WIDTH: function() {
                    return ua
                },
                TOKEN_MODAL_NAVIGATION_ICON_COLOR: function() {
                    return ra
                },
                TOKEN_MODAL_NAVIGATION_ICON_SIZE: function() {
                    return Ma
                },
                TOKEN_MODAL_NAVIGATION_PADDING_BOTTOM: function() {
                    return La
                },
                TOKEN_MODAL_PADDING_HORIZONTAL: function() {
                    return Ka
                },
                TOKEN_MODAL_PADDING_VERTICAL: function() {
                    return Da
                },
                TOKEN_MODAL_POPUP_OUTSET_SPACE: function() {
                    return ea
                },
                TOKEN_MODAL_SHADOW_OPACITY: function() {
                    return ia
                },
                TOKEN_NAVIGATION_BAR_BASE_SLOT_SIZE: function() {
                    return oa
                },
                TOKEN_NAVIGATION_BAR_BUTTON_TEXT_COLOR_BASE: function() {
                    return ca
                },
                TOKEN_NAVIGATION_BAR_COLOR_ACTIVE: function() {
                    return Fa
                },
                TOKEN_NAVIGATION_BAR_COLOR_BASE: function() {
                    return fa
                },
                TOKEN_NAVIGATION_BAR_COLOR_DISABLED_OPACITY: function() {
                    return Ga
                },
                TOKEN_NAVIGATION_BAR_COLOR_INVERTED: function() {
                    return Pa
                },
                TOKEN_NAVIGATION_BAR_HEIGHT: function() {
                    return Ba
                },
                TOKEN_NAVIGATION_BAR_ICON_SIZE: function() {
                    return Ua
                },
                TOKEN_NAVIGATION_BAR_LOGO_HEIGHT: function() {
                    return Ha
                },
                TOKEN_NAVIGATION_BAR_LOGO_WIDTH: function() {
                    return pa
                },
                TOKEN_NAVIGATION_BAR_OPTICAL_HALF_GAP: function() {
                    return xa
                },
                TOKEN_NAVIGATION_BAR_PROFILE_ADDITIONAL_COLOR: function() {
                    return Ya
                },
                TOKEN_NAVIGATION_BAR_PROFILE_AVATAR_SIZE: function() {
                    return Va
                },
                TOKEN_NAVIGATION_BAR_PROFILE_INFO_COLOR: function() {
                    return Wa
                },
                TOKEN_NAVIGATION_BAR_PROFILE_SPACING_AVATAR_TEXT: function() {
                    return Za
                },
                TOKEN_NUDGE_BASE_BACKGROUND_COLOR: function() {
                    return Xa
                },
                TOKEN_NUDGE_BASE_TEXT_COLOR: function() {
                    return sa
                },
                TOKEN_NUDGE_BORDER_RADIUS: function() {
                    return la
                },
                TOKEN_NUDGE_ICON_COLOR: function() {
                    return ma
                },
                TOKEN_NUDGE_ICON_SIZE: function() {
                    return aa
                },
                TOKEN_NUDGE_PADDING_HORIZONTAL: function() {
                    return ba
                },
                TOKEN_NUDGE_PADDING_VERTICAL: function() {
                    return da
                },
                TOKEN_NUDGE_SPACING_ACTION_MARGIN_TOP: function() {
                    return ya
                },
                TOKEN_NUDGE_SPACING_HINT_MARGIN_TOP: function() {
                    return Qa
                },
                TOKEN_NUDGE_SPACING_MEDIA_MARGIN_BOTTOM: function() {
                    return ka
                },
                TOKEN_NUDGE_SPACING_TITLE_TEXT: function() {
                    return Ja
                },
                TOKEN_ONLINE_STATUS_COLOR_IDLE: function() {
                    return ha
                },
                TOKEN_ONLINE_STATUS_COLOR_ONLINE: function() {
                    return za
                },
                TOKEN_ONLINE_STATUS_SIZE: function() {
                    return wa
                },
                TOKEN_PAGINATION_BAR_ACTION_PRESSED_SHIFT: function() {
                    return ga
                },
                TOKEN_PAGINATION_BAR_ACTION_SHADOW_BLUR_RADIUS: function() {
                    return va
                },
                TOKEN_PAGINATION_BAR_ACTION_SHADOW_COLOR: function() {
                    return ja
                },
                TOKEN_PAGINATION_BAR_ACTION_SHADOW_OPACITY: function() {
                    return qa
                },
                TOKEN_PAGINATION_BAR_ACTION_SHADOW_VERTICAL_OFFSET: function() {
                    return $a
                },
                TOKEN_PAGINATION_BAR_ACTION_SIZE: function() {
                    return _b
                },
                TOKEN_PAGINATION_BAR_SPACING_ACTION_CONTENT: function() {
                    return Ob
                },
                TOKEN_PAGINATION_DOTS_ANIMATION_TIMING_TRANSITION: function() {
                    return Tb
                },
                TOKEN_PAGINATION_DOTS_DOT_EXPLORATION_SCALING_FACTOR_P1: function() {
                    return Eb
                },
                TOKEN_PAGINATION_DOTS_DOT_EXPLORATION_SCALING_FACTOR_P2: function() {
                    return nb
                },
                TOKEN_PAGINATION_DOTS_DOT_EXPLORATION_SCALING_FACTOR_P3: function() {
                    return Nb
                },
                TOKEN_PAGINATION_DOTS_DOT_EXPLORATION_SCALING_FACTOR_P4: function() {
                    return Sb
                },
                TOKEN_PAGINATION_DOTS_DOT_GAP: function() {
                    return Cb
                },
                TOKEN_PAGINATION_DOTS_DOT_OPACITY_ACTIVE: function() {
                    return Ab
                },
                TOKEN_PAGINATION_DOTS_DOT_OPACITY_BASE: function() {
                    return Ib
                },
                TOKEN_PAGINATION_DOTS_DOT_SIZE: function() {
                    return Rb
                },
                TOKEN_PHONE_FIELD_COUNTRY_CODE_WIDTH: function() {
                    return tb
                },
                TOKEN_PHONE_FIELD_NUMBER_OVERLAP: function() {
                    return ub
                },
                TOKEN_PLACARD_BORDER_COLOR: function() {
                    return rb
                },
                TOKEN_PLACARD_BORDER_RADIUS: function() {
                    return Mb
                },
                TOKEN_PLACARD_BORDER_WIDTH: function() {
                    return Lb
                },
                TOKEN_PLACARD_EXTRA_SIZE: function() {
                    return Kb
                },
                TOKEN_PLACARD_MEDIA_SIZE: function() {
                    return Db
                },
                TOKEN_PLACARD_PADDING_HORIZONTAL: function() {
                    return eb
                },
                TOKEN_PLACARD_PADDING_VERTICAL: function() {
                    return ib
                },
                TOKEN_PLACARD_SPACING_CONTENT_EXTRA: function() {
                    return ob
                },
                TOKEN_PLACARD_SPACING_MEDIA_CONTENT: function() {
                    return cb
                },
                TOKEN_PREFIXED_FIELD_ITEM_COLOR: function() {
                    return Fb
                },
                TOKEN_PREFIXED_FIELD_ITEM_HORIZONTAL_GAP: function() {
                    return fb
                },
                TOKEN_PROGRESS_BAR_HEIGHT: function() {
                    return Gb
                },
                TOKEN_SCROLL_LIST_SPACING_LG: function() {
                    return Pb
                },
                TOKEN_SCROLL_LIST_SPACING_MD: function() {
                    return Bb
                },
                TOKEN_SCROLL_LIST_SPACING_SM: function() {
                    return Ub
                },
                TOKEN_SCROLL_LIST_SPACING_XLG: function() {
                    return Hb
                },
                TOKEN_SCROLL_LIST_SPACING_XXLG: function() {
                    return pb
                },
                TOKEN_SELECT_BASE_BACKGROUND_COLOR: function() {
                    return xb
                },
                TOKEN_SELECT_BASE_BORDER_COLOR: function() {
                    return Yb
                },
                TOKEN_SELECT_BASE_BORDER_WIDTH: function() {
                    return Vb
                },
                TOKEN_SELECT_BASE_TEXT_COLOR: function() {
                    return Wb
                },
                TOKEN_SELECT_BORDER_RADIUS: function() {
                    return Zb
                },
                TOKEN_SELECT_FOCUSED_BORDER_COLOR: function() {
                    return Xb
                },
                TOKEN_SELECT_FOCUSED_BORDER_WIDTH: function() {
                    return sb
                },
                TOKEN_SELECT_FONT_FAMILY: function() {
                    return lb
                },
                TOKEN_SELECT_FONT_SIZE: function() {
                    return mb
                },
                TOKEN_SELECT_FONT_WEIGHT: function() {
                    return ab
                },
                TOKEN_SELECT_HEIGHT: function() {
                    return bb
                },
                TOKEN_SELECT_ICON_COLOR: function() {
                    return db
                },
                TOKEN_SELECT_ICON_MARGIN_LEFT: function() {
                    return yb
                },
                TOKEN_SELECT_ICON_SIZE: function() {
                    return Qb
                },
                TOKEN_SELECT_LINE_HEIGHT: function() {
                    return kb
                },
                TOKEN_SELECT_PADDING_HORIZONTAL: function() {
                    return Jb
                },
                TOKEN_SELECT_STATUS_ERROR_BORDER_COLOR: function() {
                    return hb
                },
                TOKEN_SELECT_STATUS_ERROR_BORDER_WIDTH: function() {
                    return zb
                },
                TOKEN_SELECT_STATUS_SUCCESS_BORDER_COLOR: function() {
                    return wb
                },
                TOKEN_SELECT_STATUS_SUCCESS_BORDER_WIDTH: function() {
                    return gb
                },
                TOKEN_SHOWCASE_ITEM_TITLE_ICON_SIZE: function() {
                    return vb
                },
                TOKEN_SNACKPILL_BORDER_RADIUS: function() {
                    return jb
                },
                TOKEN_SNACKPILL_ICON_SIZE: function() {
                    return qb
                },
                TOKEN_SNACKPILL_PADDING_HORIZONTAL: function() {
                    return $b
                },
                TOKEN_SNACKPILL_PADDING_VERTICAL: function() {
                    return _d
                },
                TOKEN_SNACKPILL_SHADOW_BLUR_RADIUS: function() {
                    return Od
                },
                TOKEN_SNACKPILL_SHADOW_COLOR: function() {
                    return Td
                },
                TOKEN_SNACKPILL_SHADOW_OPACITY: function() {
                    return Ed
                },
                TOKEN_SNACKPILL_SHADOW_VERTICAL_OFFSET: function() {
                    return nd
                },
                TOKEN_SNACKPILL_SPACING_ICON_TEXT: function() {
                    return Nd
                },
                TOKEN_SONGBOX_ACTION_PADDING: function() {
                    return Sd
                },
                TOKEN_SONGBOX_BACKGROUND_COLOR: function() {
                    return Cd
                },
                TOKEN_SONGBOX_BORDER_RADIUS: function() {
                    return Ad
                },
                TOKEN_SONGBOX_PADDING: function() {
                    return Id
                },
                TOKEN_SONGBOX_SPACING_SONG_ACTION: function() {
                    return Rd
                },
                TOKEN_SONGBUTTON_BACKGROUND_COLOR: function() {
                    return td
                },
                TOKEN_SONGBUTTON_BORDER_COLOR: function() {
                    return ud
                },
                TOKEN_SONGBUTTON_BORDER_RADIUS: function() {
                    return rd
                },
                TOKEN_SONGBUTTON_BORDER_WIDTH: function() {
                    return Md
                },
                TOKEN_SONGBUTTON_SIZE: function() {
                    return Ld
                },
                TOKEN_SONG_ARTIST_TEXT_OPACITY: function() {
                    return Kd
                },
                TOKEN_SONG_MEDIA_BACKGROUND_COLOR: function() {
                    return Dd
                },
                TOKEN_SONG_MEDIA_BACKGROUND_OPACITY: function() {
                    return ed
                },
                TOKEN_SONG_MEDIA_BORDER_RADIUS: function() {
                    return id
                },
                TOKEN_SONG_MEDIA_ICON_SIZE: function() {
                    return od
                },
                TOKEN_SONG_MEDIA_OVERLAY_COLOR: function() {
                    return cd
                },
                TOKEN_SONG_MEDIA_OVERLAY_OPACITY: function() {
                    return Fd
                },
                TOKEN_SONG_MEDIA_SIZE: function() {
                    return fd
                },
                TOKEN_SONG_SPACING_MEDIA_CONTENT: function() {
                    return Gd
                },
                TOKEN_SONG_SPACING_TITLE_ARTIST: function() {
                    return Pd
                },
                TOKEN_SONG_TITLE_ICON_MARGIN_RIGHT: function() {
                    return Bd
                },
                TOKEN_SONG_TITLE_ICON_SIZE: function() {
                    return Ud
                },
                TOKEN_SPACING_GAP: function() {
                    return Hd
                },
                TOKEN_SPACING_LG: function() {
                    return pd
                },
                TOKEN_SPACING_MD: function() {
                    return xd
                },
                TOKEN_SPACING_SM: function() {
                    return Yd
                },
                TOKEN_SPACING_XLG: function() {
                    return Vd
                },
                TOKEN_SPACING_XSM: function() {
                    return Wd
                },
                TOKEN_SPACING_XXLG: function() {
                    return Zd
                },
                TOKEN_SPRINGBOX_SPACING_CONTENT_EXTRA: function() {
                    return Xd
                },
                TOKEN_SPRINGBOX_SPACING_MEDIA_CONTENT: function() {
                    return sd
                },
                TOKEN_SPRINGBOX_SPACING_MEDIA_CONTENT_COMPACT: function() {
                    return ld
                },
                TOKEN_STACK_SPACING_COMPACT: function() {
                    return md
                },
                TOKEN_STACK_SPACING_LOOSE: function() {
                    return ad
                },
                TOKEN_STICKER_LOADER_COLOR: function() {
                    return bd
                },
                TOKEN_STICKER_LOADER_MIN_SIZE: function() {
                    return dd
                },
                TOKEN_STICKER_LOADER_SIZE: function() {
                    return yd
                },
                TOKEN_TABBAR_COLOR_ACTIVE: function() {
                    return Qd
                },
                TOKEN_TABBAR_COLOR_BASE: function() {
                    return kd
                },
                TOKEN_TABBAR_HEIGHT: function() {
                    return Jd
                },
                TOKEN_TABBAR_LABEL_COLOR_ACTIVE: function() {
                    return hd
                },
                TOKEN_TABBAR_LABEL_COLOR_BASE: function() {
                    return zd
                },
                TOKEN_TABBAR_LABEL_FONT_FAMILY: function() {
                    return wd
                },
                TOKEN_TABBAR_LABEL_FONT_SIZE: function() {
                    return gd
                },
                TOKEN_TABBAR_LABEL_LINE_HEIGHT: function() {
                    return vd
                },
                TOKEN_TABBAR_MEDIA_COLOR_ACTIVE: function() {
                    return jd
                },
                TOKEN_TABBAR_MEDIA_COLOR_BASE: function() {
                    return qd
                },
                TOKEN_TABBAR_MEDIA_MARGIN_BOTTOM: function() {
                    return $d
                },
                TOKEN_TABBAR_MEDIA_SIZE: function() {
                    return _y
                },
                TOKEN_TABBAR_NOTIFICATION_CENTER_POSITION_LEFT: function() {
                    return Oy
                },
                TOKEN_TABBAR_NOTIFICATION_CENTER_POSITION_TOP: function() {
                    return Ty
                },
                TOKEN_TABBAR_PADDING_TOP: function() {
                    return Ey
                },
                TOKEN_TABS_ITEM_ACTIVE_DARK_COLOR: function() {
                    return ny
                },
                TOKEN_TABS_ITEM_ACTIVE_FEATURE_REVENUE_ALT_COLOR: function() {
                    return Ny
                },
                TOKEN_TABS_ITEM_ACTIVE_LIGHT_COLOR: function() {
                    return Sy
                },
                TOKEN_TABS_ITEM_ACTIVE_PRIMARY_COLOR: function() {
                    return Cy
                },
                TOKEN_TABS_ITEM_BASE_DARK_COLOR: function() {
                    return Ay
                },
                TOKEN_TABS_ITEM_BASE_LIGHT_COLOR: function() {
                    return Iy
                },
                TOKEN_TABS_ITEM_BASE_LIGHT_OPACITY: function() {
                    return Ry
                },
                TOKEN_TABS_ITEM_DISABLED_OPACITY: function() {
                    return ty
                },
                TOKEN_TABS_ITEM_MARK_MARGIN_LEFT: function() {
                    return uy
                },
                TOKEN_TABS_ITEM_MEDIA_DARK_ACTIVE_COLOR: function() {
                    return ry
                },
                TOKEN_TABS_ITEM_MEDIA_DARK_BASE_COLOR: function() {
                    return My
                },
                TOKEN_TABS_ITEM_MEDIA_LIGHT_ACTIVE_COLOR: function() {
                    return Ly
                },
                TOKEN_TABS_ITEM_MEDIA_LIGHT_BASE_COLOR: function() {
                    return Ky
                },
                TOKEN_TABS_ITEM_MEDIA_MARGIN_BOTTOM: function() {
                    return Dy
                },
                TOKEN_TABS_ITEM_MEDIA_SIZE: function() {
                    return ey
                },
                TOKEN_TABS_ITEM_MEDIUM_LABEL_FONT_FAMILY: function() {
                    return iy
                },
                TOKEN_TABS_ITEM_MEDIUM_LABEL_FONT_SIZE: function() {
                    return oy
                },
                TOKEN_TABS_ITEM_MEDIUM_LABEL_FONT_WEIGHT: function() {
                    return cy
                },
                TOKEN_TABS_ITEM_MEDIUM_LABEL_HEIGHT: function() {
                    return Fy
                },
                TOKEN_TABS_ITEM_MEDIUM_LABEL_LINE_HEIGHT: function() {
                    return fy
                },
                TOKEN_TABS_ITEM_MEDIUM_PADDING_BOTTOM: function() {
                    return Gy
                },
                TOKEN_TABS_ITEM_MEDIUM_PADDING_HORIZONTAL: function() {
                    return Py
                },
                TOKEN_TABS_ITEM_MEDIUM_PADDING_TOP: function() {
                    return By
                },
                TOKEN_TABS_ITEM_MIN_WIDTH: function() {
                    return Uy
                },
                TOKEN_TABS_ITEM_SMALL_LABEL_FONT_FAMILY: function() {
                    return Hy
                },
                TOKEN_TABS_ITEM_SMALL_LABEL_FONT_SIZE: function() {
                    return py
                },
                TOKEN_TABS_ITEM_SMALL_LABEL_FONT_WEIGHT: function() {
                    return xy
                },
                TOKEN_TABS_ITEM_SMALL_LABEL_HEIGHT: function() {
                    return Yy
                },
                TOKEN_TABS_ITEM_SMALL_LABEL_LINE_HEIGHT: function() {
                    return Vy
                },
                TOKEN_TABS_ITEM_SMALL_PADDING_BOTTOM: function() {
                    return Wy
                },
                TOKEN_TABS_ITEM_SMALL_PADDING_HORIZONTAL: function() {
                    return Zy
                },
                TOKEN_TABS_ITEM_SMALL_PADDING_TOP: function() {
                    return Xy
                },
                TOKEN_TABS_ITEM_UNDERLINE_HEIGHT: function() {
                    return sy
                },
                TOKEN_TABS_PADDING_HORIZONTAL: function() {
                    return ly
                },
                TOKEN_TABS_SHADOW_DARK_COLOR: function() {
                    return my
                },
                TOKEN_TABS_SHADOW_DARK_OPACITY: function() {
                    return ay
                },
                TOKEN_TABS_SHADOW_HEIGHT: function() {
                    return by
                },
                TOKEN_TABS_SHADOW_LIGHT_COLOR: function() {
                    return dy
                },
                TOKEN_TABS_SHADOW_LIGHT_OPACITY: function() {
                    return yy
                },
                TOKEN_TEXT_AREA_BASE_BACKGROUND_COLOR: function() {
                    return Qy
                },
                TOKEN_TEXT_AREA_BASE_BORDER_COLOR: function() {
                    return ky
                },
                TOKEN_TEXT_AREA_BASE_BORDER_WIDTH: function() {
                    return Jy
                },
                TOKEN_TEXT_AREA_BASE_TEXT_COLOR: function() {
                    return hy
                },
                TOKEN_TEXT_AREA_BORDER_RADIUS: function() {
                    return zy
                },
                TOKEN_TEXT_AREA_FOCUSED_BORDER_COLOR: function() {
                    return wy
                },
                TOKEN_TEXT_AREA_FOCUSED_BORDER_WIDTH: function() {
                    return gy
                },
                TOKEN_TEXT_AREA_FONT_FAMILY: function() {
                    return vy
                },
                TOKEN_TEXT_AREA_FONT_SIZE: function() {
                    return jy
                },
                TOKEN_TEXT_AREA_FONT_WEIGHT: function() {
                    return qy
                },
                TOKEN_TEXT_AREA_LINE_HEIGHT: function() {
                    return $y
                },
                TOKEN_TEXT_AREA_MIN_HEIGHT: function() {
                    return _Q
                },
                TOKEN_TEXT_AREA_PADDING_HORIZONTAL: function() {
                    return OQ
                },
                TOKEN_TEXT_AREA_PADDING_VERTICAL: function() {
                    return TQ
                },
                TOKEN_TEXT_AREA_STATUS_ERROR_BORDER_COLOR: function() {
                    return EQ
                },
                TOKEN_TEXT_AREA_STATUS_ERROR_BORDER_WIDTH: function() {
                    return nQ
                },
                TOKEN_TEXT_AREA_STATUS_SUCCESS_BORDER_COLOR: function() {
                    return NQ
                },
                TOKEN_TEXT_AREA_STATUS_SUCCESS_BORDER_WIDTH: function() {
                    return SQ
                },
                TOKEN_TEXT_FIELD_BASE_BACKGROUND_COLOR: function() {
                    return CQ
                },
                TOKEN_TEXT_FIELD_BASE_BORDER_COLOR: function() {
                    return AQ
                },
                TOKEN_TEXT_FIELD_BASE_BORDER_WIDTH: function() {
                    return IQ
                },
                TOKEN_TEXT_FIELD_BASE_TEXT_COLOR: function() {
                    return RQ
                },
                TOKEN_TEXT_FIELD_BORDER_RADIUS: function() {
                    return tQ
                },
                TOKEN_TEXT_FIELD_FOCUSED_BORDER_COLOR: function() {
                    return uQ
                },
                TOKEN_TEXT_FIELD_FOCUSED_BORDER_WIDTH: function() {
                    return rQ
                },
                TOKEN_TEXT_FIELD_FONT_FAMILY: function() {
                    return MQ
                },
                TOKEN_TEXT_FIELD_FONT_SIZE: function() {
                    return LQ
                },
                TOKEN_TEXT_FIELD_FONT_WEIGHT: function() {
                    return KQ
                },
                TOKEN_TEXT_FIELD_HEIGHT: function() {
                    return DQ
                },
                TOKEN_TEXT_FIELD_ICON_COLOR: function() {
                    return eQ
                },
                TOKEN_TEXT_FIELD_ICON_SIZE: function() {
                    return iQ
                },
                TOKEN_TEXT_FIELD_LINE_HEIGHT: function() {
                    return oQ
                },
                TOKEN_TEXT_FIELD_PADDING_HORIZONTAL: function() {
                    return cQ
                },
                TOKEN_TEXT_FIELD_SPACING_ICON_ACTION: function() {
                    return FQ
                },
                TOKEN_TEXT_FIELD_STATUS_ERROR_BORDER_COLOR: function() {
                    return fQ
                },
                TOKEN_TEXT_FIELD_STATUS_ERROR_BORDER_WIDTH: function() {
                    return GQ
                },
                TOKEN_TEXT_FIELD_STATUS_SUCCESS_BORDER_COLOR: function() {
                    return PQ
                },
                TOKEN_TEXT_FIELD_STATUS_SUCCESS_BORDER_WIDTH: function() {
                    return BQ
                },
                TOKEN_TOOLTIP_ARROW_OFFSET: function() {
                    return UQ
                },
                TOKEN_TOOLTIP_ARROW_SIZE: function() {
                    return HQ
                },
                TOKEN_TOOLTIP_BACKGROUND_COLOR: function() {
                    return pQ
                },
                TOKEN_TOOLTIP_BORDER_RADIUS: function() {
                    return xQ
                },
                TOKEN_TOOLTIP_OFFSET: function() {
                    return YQ
                },
                TOKEN_TOOLTIP_PADDING_HORIZONTAL: function() {
                    return VQ
                },
                TOKEN_TOOLTIP_PADDING_VERTICAL: function() {
                    return WQ
                },
                TOKEN_TOOLTIP_SHADOW_BLUR_RADIUS: function() {
                    return ZQ
                },
                TOKEN_TOOLTIP_SHADOW_COLOR: function() {
                    return XQ
                },
                TOKEN_TOOLTIP_SHADOW_OPACITY: function() {
                    return sQ
                },
                TOKEN_TOOLTIP_SHADOW_VERTICAL_OFFSET: function() {
                    return lQ
                },
                TOKEN_TOOLTIP_TEXT_COLOR: function() {
                    return mQ
                },
                TOKEN_USERCARD_ACTIONS_HEIGHT: function() {
                    return aQ
                },
                TOKEN_USERCARD_ACTION_ICON_SIZE: function() {
                    return bQ
                },
                TOKEN_USERCARD_BACKGROUND_COLOR: function() {
                    return dQ
                },
                TOKEN_USERCARD_BORDER_RADIUS: function() {
                    return yQ
                },
                TOKEN_USERCARD_CONTENT_INSET: function() {
                    return QQ
                },
                TOKEN_USERCARD_HALO_OPACITY: function() {
                    return kQ
                },
                TOKEN_USERCARD_HALO_WIDTH: function() {
                    return JQ
                },
                TOKEN_USERCARD_MEDIA_GRADIENT_BOTTOM_HEIGHT: function() {
                    return hQ
                },
                TOKEN_USERCARD_MEDIA_GRADIENT_BOTTOM_OPACITY: function() {
                    return zQ
                },
                TOKEN_USERCARD_MEDIA_GRADIENT_TOP_HEIGHT: function() {
                    return wQ
                },
                TOKEN_USERCARD_MEDIA_GRADIENT_TOP_OPACITY: function() {
                    return gQ
                },
                TOKEN_USERCARD_PORTRAIT_RATIO: function() {
                    return vQ
                },
                TOKEN_USERCARD_THIN_BORDER_OPACITY: function() {
                    return jQ
                },
                TOKEN_USERCARD_THIN_BORDER_WIDTH: function() {
                    return qQ
                },
                TOKEN_USERLIST_CELL_GAP_HORIZONTAL: function() {
                    return $Q
                },
                TOKEN_USERLIST_CELL_GAP_VERTICAL_CHESS: function() {
                    return _k
                },
                TOKEN_USERLIST_CELL_GAP_VERTICAL_GRID: function() {
                    return Ok
                },
                TOKEN_USERLIST_CELL_MAX_WIDTH: function() {
                    return Tk
                },
                TOKEN_USERLIST_CELL_MEDIA_PORTRAIT_RATIO: function() {
                    return Ek
                },
                TOKEN_USERLIST_CELL_MIN_WIDTH: function() {
                    return nk
                },
                TOKEN_USERLIST_CELL_SHIFT_VERTICAL_CHESS: function() {
                    return Nk
                },
                TOKEN_USERLIST_CELL_TEXT_ICON_MARGIN_END: function() {
                    return Sk
                },
                TOKEN_USERLIST_CELL_TEXT_ICON_SIZE: function() {
                    return Ck
                },
                TOKEN_USERLIST_CELL_TEXT_MARGIN_TOP: function() {
                    return Ak
                }
            });
            var E = "#121212",
                n = "-2px",
                N = "2px",
                S = "#0974B0",
                C = "-3px",
                A = "2px",
                I = "#0974B0",
                R = "2px",
                t = "1px",
                u = "44px",
                r = "24px",
                M = "24px",
                L = "center",
                K = "#FFFFFF",
                D = "#121212",
                e = "16px",
                i = "64px",
                o = "12px",
                c = "24px",
                F = "24px",
                f = "24px",
                G = "8px",
                P = "#F6F6F6",
                B = "1px",
                U = "#C8001A",
                H = "#121212",
                p = "48px",
                x = "24px",
                Y = "8px",
                V = "12px",
                W = "12px",
                Z = "24px",
                X = "16px",
                s = "#F6F6F6",
                l = "#121212",
                m = "24px",
                a = "24px",
                b = "8px",
                d = "24px",
                y = "480px",
                Q = "8px",
                k = "24px",
                J = "16px",
                h = "12px",
                z = "#E9D8FF",
                w = "#121212",
                g = "#121212",
                v = "8px",
                j = "24px",
                q = "24px",
                $ = "16px",
                __ = "16px",
                O_ = "#717171",
                T_ = "4px",
                E_ = "#121212",
                n_ = "12px",
                N_ = "24px",
                S_ = "24px",
                C_ = "16px",
                A_ = "#121212",
                I_ = "0.1",
                R_ = "#121212",
                t_ = "#121212",
                u_ = "#C8001A",
                r_ = "#121212",
                M_ = "4px",
                L_ = "16px",
                K_ = "12px",
                D_ = "#717171",
                e_ = "#121212",
                i_ = "#CCCCCC",
                o_ = "16px",
                c_ = "#717171",
                F_ = "4px",
                f_ = "#121212",
                G_ = "#EAEAEA",
                P_ = "#717171",
                B_ = "#FF4000",
                U_ = "#FF4278",
                H_ = "#FF8201",
                p_ = "#FFC831",
                x_ = "#00CAA8",
                Y_ = "#17D417",
                V_ = "#B500E3",
                W_ = "#1AB0FF",
                Z_ = "#2B8CFC",
                X_ = "22px",
                s_ = "18px",
                l_ = "44px",
                m_ = "18px",
                a_ = "16px",
                b_ = "4px",
                d_ = "4px",
                y_ = "18px",
                Q_ = "16px",
                k_ = "36px",
                J_ = "16px",
                h_ = "12px",
                z_ = "4px",
                w_ = "4px",
                g_ = "12px",
                v_ = "12px",
                j_ = "24px",
                q_ = "12px",
                $_ = "8px",
                _O = "4px",
                OO = "4px",
                TO = "16px",
                EO = "12px",
                nO = "8px",
                NO = "24px",
                SO = "32px",
                CO = "24px",
                AO = "16px",
                IO = "8px",
                RO = "28px",
                tO = "32px",
                uO = "24px",
                rO = "16px",
                MO = "36px",
                LO = "24px",
                KO = "37.5%",
                DO = "12px",
                eO = "50%",
                iO = "16%",
                oO = "16px",
                cO = "#C8001A",
                FO = "#121212",
                fO = "2.5px",
                GO = "1.5px",
                PO = "36px",
                BO = "#000000",
                UO = "0.4",
                HO = "#121212",
                pO = "0.4",
                xO = "120px",
                YO = "96px",
                VO = "64px",
                WO = "150px",
                ZO = "32px",
                XO = "24px",
                sO = "12px",
                lO = "480px",
                mO = "26px",
                aO = "52px",
                bO = "22px",
                dO = "24px",
                yO = "32px",
                QO = "8px",
                kO = "8px",
                JO = "22px",
                hO = "44px",
                zO = "22px",
                wO = "24px",
                gO = "32px",
                vO = "4px",
                jO = "8px",
                qO = "0.7",
                $O = "#000000",
                _T = "0.05",
                OT = "#000000",
                TT = "0.1",
                ET = "1px",
                nT = "#FFFFFF",
                NT = "250px",
                ST = "12px",
                CT = "8px",
                AT = "#F6F6F6",
                IT = "#121212",
                RT = "#F3EAFF",
                tT = "#121212",
                uT = "19px",
                rT = "4px",
                MT = "80%",
                LT = "#121212",
                KT = "#121212",
                DT = "#CCCCCC",
                eT = "48px",
                iT = "8px",
                oT = "36px",
                cT = "32px",
                FT = "8px",
                fT = "36px",
                GT = "16px",
                PT = "6px",
                BT = "#FFFFFF",
                UT = "0.04",
                HT = "1px",
                pT = "14px",
                xT = "8px",
                YT = "#000000",
                VT = "0.08",
                WT = "4px",
                ZT = "28px",
                XT = "12px",
                sT = "#717171",
                lT = "17px",
                mT = "36px",
                aT = "24px",
                bT = "12px",
                dT = "22px",
                yT = "#FFFFFF",
                QT = "#717171",
                kT = "#121212",
                JT = "#717171",
                hT = "#F6F6F6",
                zT = "#F6F6F6",
                wT = "#121212",
                gT = "#121212",
                vT = "12px",
                jT = "6px",
                qT = "16px",
                $T = "#717171",
                _E = "250px",
                OE = "80%",
                TE = "16px",
                EE = "2px",
                nE = "40px",
                NE = "32px",
                SE = "false",
                CE = "6px",
                AE = "8px",
                IE = "4px",
                RE = "#FFFFFF",
                tE = "#FFFFFF",
                uE = "11px",
                rE = "2px",
                ME = "11px",
                LE = "22px",
                KE = "36px",
                DE = "#717171",
                eE = "#C8001A",
                iE = "#717171",
                oE = "#121212",
                cE = "4px",
                FE = "16px",
                fE = "6px",
                GE = "10px",
                PE = "1px",
                BE = "16px",
                UE = "0.24",
                HE = "1.5px",
                pE = "3px",
                xE = "8px",
                YE = "18px",
                VE = "48px",
                WE = "46px",
                ZE = "0.48",
                XE = "90px",
                sE = "12px",
                lE = "8px",
                mE = "12px",
                aE = "22px",
                bE = "#717171",
                dE = "4px",
                yE = "#121212",
                QE = "#000000",
                kE = "12px",
                JE = "12px",
                hE = "200px",
                zE = "150px",
                wE = "#121212",
                gE = "4px",
                vE = "#717171",
                jE = "175%",
                qE = "#121212",
                $E = "4px",
                _n = "#F6F6F6",
                On = "22px",
                Tn = "160px",
                En = "#FFFFFF",
                nn = "#F6F6F6",
                Nn = "8px",
                Sn = "#CCCCCC",
                Cn = "#717171",
                An = "36px",
                In = "22px",
                Rn = "10px",
                tn = "4px",
                un = "50%",
                rn = "4px",
                Mn = "32px",
                Ln = "#121212",
                Kn = "#121212",
                Dn = "1px",
                en = "2px",
                on = "#121212",
                cn = "24px",
                Fn = "12px",
                fn = "0.04",
                Gn = "1px",
                Pn = "8px",
                Bn = "#000000",
                Un = "0.08",
                Hn = "4px",
                pn = "40px",
                xn = "0.16",
                Yn = "-4px",
                Vn = "22px",
                Wn = "#121212",
                Zn = "#C8001A",
                Xn = "#121212",
                sn = "#121212",
                ln = "#121212",
                mn = "#121212",
                an = "#121212",
                bn = "#121212",
                dn = "#121212",
                yn = "#121212",
                Qn = "#121212",
                kn = "#121212",
                Jn = "#121212",
                hn = "#E9D8FF",
                zn = "#121212",
                wn = "#FFA800",
                gn = "#121212",
                vn = "#121212",
                jn = "#C8001A",
                qn = "#FFFFFF",
                $n = "#121212",
                _N = "#121212",
                ON = "#121212",
                TN = "#121212",
                EN = "#121212",
                nN = "#E9D8FF",
                NN = "#E9D8FF",
                SN = "#E9D8FF",
                CN = "#29131D",
                AN = "#FFFFFF",
                IN = "#FFFFFF",
                RN = "#FFFFFF",
                tN = "#29131D",
                uN = "#29131D",
                rN = "#F3EAFF",
                MN = "#E9D8FF",
                LN = "#121212",
                KN = "#121212",
                DN = "#121212",
                eN = "#E9D8FF",
                iN = "#121212",
                oN = "#121212",
                cN = "#121212",
                FN = "#121212",
                fN = "#0974B0",
                GN = "#0974B0",
                PN = "#121212",
                BN = "#5CA500",
                UN = "#407300",
                HN = "#121212",
                pN = "#E9D8FF",
                xN = "#F3EAFF",
                YN = "#121212",
                VN = "#C8001A",
                WN = "#FFA800",
                ZN = "#B04F16",
                XN = "#CCCCCC",
                sN = "#F6F6F6",
                lN = "#EAEAEA",
                mN = "#CCCCCC",
                aN = "#979797",
                bN = "#717171",
                dN = "#717171",
                yN = "#F6F6F6",
                QN = "#C8001A",
                kN = "#FFA800",
                JN = "#5CA500",
                hN = "#C8001A",
                zN = "#5CA500",
                wN = "#C8001A",
                gN = "#121212",
                vN = "#121212",
                jN = "#E9D8FF",
                qN = "#E9D8FF",
                $N = "#000000",
                _S = "#1672E9",
                OS = "#DC4A3D",
                TS = "#D93175",
                ES = "#0076B7",
                nS = "#FF8201",
                NS = "#1DB954",
                SS = "#1AB0FF",
                CS = "#507299",
                AS = "#F3EAFF",
                IS = "#C8001A",
                RS = "#C8001A",
                tS = "#5CA500",
                uS = "#407300",
                rS = "#FFA800",
                MS = "#B04F16",
                LS = "#FFFFFF",
                KS = "1000px",
                DS = "0px",
                eS = "0px",
                iS = "#F6F6F6",
                oS = "#1212120D",
                cS = "#1212121A",
                FS = "#E9D8FF",
                fS = "#1212121F",
                GS = "#1212121F",
                PS = "#121212",
                BS = "#121212",
                US = "#121212",
                HS = "#121212",
                pS = "20px",
                xS = "20px",
                YS = "20px",
                VS = "45px",
                WS = "12px",
                ZS = "8px",
                XS = "4px",
                sS = "16px",
                lS = "12px",
                mS = "action-small",
                aS = "24px",
                bS = "0.5px",
                dS = "0.5px",
                yS = "0.5px",
                QS = "1px",
                kS = "#E9D8FF",
                JS = "#1212120D",
                hS = "#1212121A",
                zS = "#FFFFFF",
                wS = "#F6F6F6",
                gS = "#FFFFFF",
                vS = "#12121214",
                jS = "#12121214",
                qS = "#12121214",
                $S = "#1212121F",
                _C = "#717171",
                OC = "#717171",
                TC = "#717171",
                EC = "#717171",
                nC = "#121212",
                NC = "#717171",
                SC = "#121212",
                CC = "#121212",
                AC = "#121212",
                IC = "#121212",
                RC = "#121212",
                tC = "#121212",
                uC = "#121212",
                rC = "24px",
                MC = "#12121233",
                LC = "0px",
                KC = "0px",
                DC = "1px",
                eC = "8px",
                iC = "#1212121F",
                oC = "0px",
                cC = "0px",
                FC = "1px",
                fC = "12px",
                GC = "#12121233",
                PC = "0px",
                BC = "0px",
                UC = "1px",
                HC = "16px",
                pC = "40px",
                xC = "24px",
                YC = "12px",
                VC = "2px",
                WC = "16px",
                ZC = "16px",
                XC = "p2",
                sC = "title",
                lC = "24px",
                mC = "0px",
                aC = "0px",
                bC = "0px",
                dC = "#F6F6F6",
                yC = "#F6F6F6",
                QC = "#1212120D",
                kC = "#1212121A",
                JC = "#E9D8FF",
                hC = "#12121214",
                zC = "#12121214",
                wC = "#12121214",
                gC = "#121212",
                vC = "#121212",
                jC = "#121212",
                qC = "#121212",
                $C = "24px",
                _A = "24px",
                OA = "8px",
                TA = "16px",
                EA = "12px",
                nA = "action-small",
                NA = "#FFFFFF00",
                SA = "#1212120D",
                CA = "#1212121A",
                AA = "#717171",
                IA = "#717171",
                RA = "#121212",
                tA = "#121212",
                uA = "#121212",
                rA = "#121212",
                MA = "16px",
                LA = "16px",
                KA = "40px",
                DA = "24px",
                eA = "23px",
                iA = "12px",
                oA = "8px",
                cA = "4px",
                FA = "2px",
                fA = "0px",
                GA = "16px",
                PA = "16px",
                BA = "4px",
                UA = "16px",
                HA = "p2",
                pA = "p3",
                xA = "title",
                YA = "32px",
                VA = "0px",
                WA = "#12121299",
                ZA = "#FFFFFF",
                XA = "#FFFFFF",
                sA = "12px",
                lA = "#12121233",
                mA = "0px",
                aA = "0px",
                bA = "1px",
                dA = "12px",
                yA = "0px",
                QA = "20px",
                kA = "8px",
                JA = "20px",
                hA = "20px",
                zA = "8px",
                wA = "0px",
                gA = "100%",
                vA = "100%",
                jA = "#F6F6F6",
                qA = "#717171",
                $A = "1000px",
                _I = "0.5px",
                OI = "#FFFFFF",
                TI = "#F3EAFF",
                EI = "#F6F6F6",
                nI = "#C8001A",
                NI = "#121212",
                SI = "#3F61DB",
                CI = "#FFFFFFCC",
                AI = "#F3EAFF80",
                II = "#F6F6F6E6",
                RI = "#C8001A80",
                tI = "#121212B3",
                uI = "#3F61DBCC",
                rI = "#12121214",
                MI = "#121212",
                LI = "#121212",
                KI = "#121212",
                DI = "#FFFFFF",
                eI = "#FFFFFF",
                iI = "#FFFFFF",
                oI = "#121212",
                cI = "#121212",
                FI = "#121212",
                fI = "#FFFFFF",
                GI = "#FFFFFF",
                PI = "#FFFFFF",
                BI = "#121212",
                UI = "#121212",
                HI = "#121212",
                pI = "#FFFFFF",
                xI = "#FFFFFF",
                YI = "#FFFFFF",
                VI = "#121212",
                WI = "#121212",
                ZI = "#121212",
                XI = "#FFFFFF",
                sI = "#FFFFFF",
                lI = "#FFFFFF",
                mI = "40px",
                aI = "20px",
                bI = "20px",
                dI = "20px",
                yI = "20px",
                QI = "40px",
                kI = "12px",
                JI = "12px",
                hI = "16px",
                zI = "12px",
                wI = "12px",
                gI = "16px",
                vI = "19px",
                jI = "23px",
                qI = "34px",
                $I = "21px",
                _R = "25px",
                OR = "36px",
                TR = "4px",
                ER = "4px",
                nR = "4px",
                NR = "8px",
                SR = "8px",
                CR = "8px",
                AR = "1px",
                IR = "8px",
                RR = "8px",
                tR = "8px",
                uR = "1px",
                rR = "16px",
                MR = "16px",
                LR = "16px",
                KR = "1px",
                DR = "1px",
                eR = "2px",
                iR = "4px",
                oR = "8px",
                cR = "p3",
                FR = "p3",
                fR = "p2-bolder",
                GR = "12px",
                PR = "10px",
                BR = "1000px",
                UR = "8px",
                HR = "16px",
                pR = "8px",
                xR = "#FFFFFF",
                YR = "#12121280",
                VR = "20px",
                WR = "64px",
                ZR = "40px",
                XR = "32px",
                sR = "96px",
                lR = "24px",
                mR = "48px",
                aR = "32px",
                bR = "24px",
                dR = "72px",
                yR = "20px",
                QR = "64px",
                kR = "40px",
                JR = "32px",
                hR = "96px",
                zR = "24px",
                wR = "68px",
                gR = "44px",
                vR = "34px",
                jR = "104px",
                qR = "26px",
                $R = "24px",
                _t = "16px",
                Ot = "40px",
                Tt = "24px",
                Et = "16px",
                nt = "12px",
                Nt = "40px",
                St = "12px",
                Ct = "-5px",
                At = "-2px",
                It = "0px",
                Rt = "-10px",
                tt = "0px",
                ut = "5px",
                rt = "2px",
                Mt = "0px",
                Lt = "10px",
                Kt = "0px",
                Dt = "4px",
                et = "19px",
                it = "4px",
                ot = "19px",
                ct = "4px",
                Ft = "19px",
                ft = "19px",
                Gt = "19px",
                Pt = "19px",
                Bt = "4px",
                Ut = "19px",
                Ht = "4px",
                pt = "19px",
                xt = "4px",
                Yt = "19px",
                Vt = "19px",
                Wt = "#F6F6F6",
                Zt = "#E9D8FF",
                Xt = "#F3EAFF",
                st = "#FFFFFF",
                lt = "#121212",
                mt = "12px",
                at = "8px",
                bt = "p1",
                dt = "28px",
                yt = "16px",
                Qt = "19px",
                kt = "22px",
                Jt = "0px",
                ht = "0px",
                zt = "0px",
                wt = "1px",
                gt = "1px",
                vt = "1px",
                jt = "0px",
                qt = "0px",
                $t = "0px",
                _u = "#1212120D",
                Ou = "#1212121A",
                Tu = "#FFFFFF0D",
                Eu = "#FFFFFF1A",
                nu = "#000000",
                Nu = "#121212",
                Su = "#C8001A",
                Cu = "#1672E9",
                Au = "#FFFFFF",
                Iu = "#E4405F",
                Ru = "#FFFFFF",
                tu = "#0076B7",
                uu = "#FF8201",
                ru = "#1DB954",
                Mu = "#1AB0FF",
                Lu = "#507299",
                Ku = "#FFFFFF00",
                Du = "#FFFFFF00",
                eu = "#FFFFFF00",
                iu = "#FFFFFF00",
                ou = "#FFFFFF00",
                cu = "#FFFFFF00",
                Fu = "#FFFFFF00",
                fu = "#1212121F",
                Gu = "#C8001A",
                Pu = "#FFFFFF00",
                Bu = "#FFFFFF00",
                Uu = "#FFFFFF00",
                Hu = "#1212121F",
                pu = "#FFFFFF00",
                xu = "#FFFFFF00",
                Yu = "#FFFFFF00",
                Vu = "#FFFFFF00",
                Wu = "#FFFFFF00",
                Zu = "#121212",
                Xu = "#C8001A",
                su = "#FFFFFF",
                lu = "#1212121F",
                mu = "#C8001A",
                au = "#1212121F",
                bu = "#FFFFFF",
                du = "#FFFFFF",
                yu = "#FFFFFF",
                Qu = "#FFFFFF",
                ku = "#FFFFFF",
                Ju = "#FFFFFF",
                hu = "#121212",
                zu = "#FFFFFF",
                wu = "#FFFFFF",
                gu = "#FFFFFF",
                vu = "#FFFFFF",
                ju = "#FFFFFF",
                qu = "#121212",
                $u = "#C8001A",
                _r = "#FFFFFF",
                Or = "#121212",
                Tr = "#C8001A",
                Er = "#FFFFFF",
                nr = "#FFFFFF",
                Nr = "#FFFFFF",
                Sr = "#FFFFFF",
                Cr = "#FFFFFF",
                Ar = "#FFFFFF",
                Ir = "#FFFFFF",
                Rr = "#121212",
                tr = "#FFFFFF",
                ur = "#FFFFFF",
                rr = "#FFFFFF",
                Mr = "#FFFFFF",
                Lr = "#FFFFFF",
                Kr = "#121212",
                Dr = "#C8001A",
                er = "#FFFFFF",
                ir = "#121212",
                or = "#C8001A",
                cr = "#FFFFFF",
                Fr = "20px",
                fr = "14px",
                Gr = "16px",
                Pr = "18px",
                Br = "480px",
                Ur = "56px",
                Hr = "25px",
                pr = "36px",
                xr = "44px",
                Yr = "8px",
                Vr = "4px",
                Wr = "6px",
                Zr = "6px",
                Xr = "32px",
                sr = "10px",
                lr = "16px",
                mr = "32px",
                ar = "16px",
                br = "6px",
                dr = "10px",
                yr = "12px",
                Qr = "action",
                kr = "action-mini",
                Jr = "action-mini",
                hr = "action-small",
                zr = "16px",
                wr = "0px",
                gr = "0px",
                vr = "0px",
                jr = "1px",
                qr = "#E9D8FF",
                $r = "#E9D8FF80",
                _M = "#FFFFFF",
                OM = "#121212B3",
                TM = "#F6F6F6",
                EM = "#F6F6F6E6",
                nM = "#FFFFFF",
                NM = "#FFFFFFCC",
                SM = "#1212121F",
                CM = "#12121214",
                AM = "#12121214",
                IM = "#1212121F",
                RM = "8px",
                tM = "#1212121F",
                uM = "0px",
                rM = "0px",
                MM = "1px",
                LM = "20px",
                KM = "20px",
                DM = "20px",
                eM = "40px",
                iM = "16px",
                oM = "12px",
                cM = "16px",
                FM = "12px",
                fM = "#FFFFFF",
                GM = "#121212",
                PM = "8px",
                BM = "20px",
                UM = "0px",
                HM = "4px",
                pM = "8px",
                xM = "2px",
                YM = "0px",
                VM = "2px",
                WM = "2px",
                ZM = "0px",
                XM = "2px",
                sM = "#FFFFFF",
                lM = "#121212",
                mM = "#FFFFFF",
                aM = "#121212",
                bM = "#FFFFFF",
                dM = "#121212",
                yM = "#C8001A",
                QM = "#121212",
                kM = "#121212",
                JM = "#C8001A",
                hM = "#FFFFFF",
                zM = "#FFFFFF",
                wM = "#FFFFFF",
                gM = "#FFFFFF",
                vM = "#FFFFFF",
                jM = "#121212",
                qM = "#121212",
                $M = "#121212",
                _L = "24px",
                OL = "16px",
                TL = "#717171",
                EL = "#717171",
                nL = "#121212",
                NL = "48px",
                SL = "16px",
                CL = "12px",
                AL = "8px",
                IL = "0px",
                RL = "p1",
                tL = "p3",
                uL = "h1",
                rL = "1px",
                ML = "0.5px",
                LL = "#1212121F",
                KL = "#12121214",
                DL = "1000px",
                eL = "2px",
                iL = "0px",
                oL = "#C8001A",
                cL = "#FFFFFF",
                FL = "#FFFFFF",
                fL = "#FFFFFF",
                GL = "8px",
                PL = "16px",
                BL = "4px",
                UL = "0px",
                HL = "caption",
                pL = "#717171",
                xL = "#121212",
                YL = "16px",
                VL = "12px",
                WL = "8px",
                ZL = "p3",
                XL = "h4",
                sL = "1000px",
                lL = "0px",
                mL = "0px",
                aL = "#F6F6F6",
                bL = "#1212120D",
                dL = "#1212121A",
                yL = "#E9D8FF",
                QL = "#1212121F",
                kL = "#1212121F",
                JL = "#121212",
                hL = "#121212",
                zL = "#121212",
                wL = "#121212",
                gL = "20px",
                vL = "20px",
                jL = "20px",
                qL = "45px",
                $L = "16px",
                _K = "8px",
                OK = "4px",
                TK = "16px",
                EK = "12px",
                nK = "action-mini",
                NK = "16px",
                SK = "0px",
                CK = "1px",
                AK = "2px",
                IK = "1px",
                RK = "1px",
                tK = "#FFFFFF",
                uK = "#FFFFFF",
                rK = "#717171",
                MK = "#C8001A",
                LK = "#121212",
                KK = "#12121280",
                DK = "#5CA500",
                eK = "#121212",
                iK = "#121212",
                oK = "#C8001A",
                cK = "#5CA500",
                FK = "#121212",
                fK = "#717171",
                GK = "#121212",
                PK = "#121212",
                BK = "#121212",
                UK = "#121212",
                HK = "#FFFFFF00",
                pK = "#F6F6F6",
                xK = "#121212",
                YK = "#121212",
                VK = "24px",
                WK = "16px",
                ZK = "12px",
                XK = "8px",
                sK = "4px",
                lK = "0px",
                mK = "4px",
                aK = "0px",
                bK = "16px",
                dK = "0px",
                yK = "12px",
                QK = "16px",
                kK = "8px",
                JK = "16px",
                hK = "2px",
                zK = "2px",
                wK = "action",
                gK = "p3",
                vK = "p2",
                jK = "p2-bolder",
                qK = "p2-bolder",
                $K = "p1",
                _D = "p1-bolder",
                OD = "p1-bolder",
                TD = "#717171",
                ED = "#C8001A",
                nD = "#5CA500",
                ND = "#717171",
                SD = "#C8001A",
                CD = "#5CA500",
                AD = "16px",
                ID = "8px",
                RD = "1px",
                tD = "p3",
                uD = "1000px",
                rD = "1000px",
                MD = "1000px",
                LD = "16px",
                KD = "1px",
                DD = "1px",
                eD = "#E9D8FF",
                iD = "#FFFFFF00",
                oD = "#121212B3",
                cD = "#FFFFFF",
                FD = "#FFFFFF",
                fD = "#FFFFFF00",
                GD = "#CCCCCC",
                PD = "#FFFFFF00",
                BD = "#CCCCCC",
                UD = "#FFFFFF",
                HD = "#FFFFFF",
                pD = "#FFFFFF00",
                xD = "#1212121F",
                YD = "#1212121F",
                VD = "#121212",
                WD = "#FFFFFF",
                ZD = "#FFFFFF",
                XD = "#121212",
                sD = "#121212",
                lD = "#121212",
                mD = "#FFFFFF",
                aD = "#CCCCCC",
                bD = "#FFFFFF",
                dD = "#CCCCCC",
                yD = "#CCCCCC",
                QD = "#CCCCCC",
                kD = "#1212120D",
                JD = "#1212121A",
                hD = "#FFFFFF0D",
                zD = "#FFFFFF1A",
                wD = "48px",
                gD = "24px",
                vD = "40px",
                jD = "48px",
                qD = "20px",
                $D = "36px",
                _e = "48px",
                Oe = "16px",
                Te = "32px",
                Ee = "56px",
                ne = "24px",
                Ne = "56px",
                Se = "24px",
                Ce = "0.5px",
                Ae = "#FFFFFF",
                Ie = "#12121214",
                Re = "#121212",
                te = "#C8001A",
                ue = "#FFFFFF",
                re = "#5CA500",
                Me = "#FFFFFF",
                Le = "#121212",
                Ke = "#121212",
                De = "#FFFFFF00",
                ee = "#12121299",
                ie = "12px",
                oe = "#12121233",
                ce = "0px",
                Fe = "0px",
                fe = "1px",
                Ge = "20px",
                Pe = "16px",
                Be = "12px",
                Ue = "12px",
                He = "0px",
                pe = "12px",
                xe = "2px",
                Ye = "12px",
                Ve = "12px",
                We = "8px",
                Ze = "p2",
                Xe = "title",
                se = "1000px",
                le = "0px",
                me = "1px",
                ae = "0px",
                be = "#FFFFFF00",
                de = "0px",
                ye = "0px",
                Qe = "0px",
                ke = "8px",
                Je = "#1212121F",
                he = "0px",
                ze = "0px",
                we = "1px",
                ge = "#C8001A",
                ve = "#FFFFFF",
                je = "#1212121F",
                qe = "#12121214",
                $e = "#FFFFFF",
                _i = "#121212",
                Oi = "#FFFFFF",
                Ti = "#121212",
                Ei = "12px",
                ni = "24px",
                Ni = "4px",
                Si = "8px",
                Ci = "4px",
                Ai = "p3",
                Ii = "#FFFFFF00",
                Ri = "#1212120D",
                ti = "#1212121A",
                ui = "#121212",
                ri = "#121212",
                Mi = "12px",
                Li = "#12121233",
                Ki = "0px",
                Di = "0px",
                ei = "1px",
                ii = "20px",
                oi = "8px",
                ci = "0px",
                Fi = "16px",
                fi = "16px",
                Gi = "action-small",
                Pi = "24px",
                Bi = "#12121299",
                Ui = "#FFFFFF",
                Hi = "20px",
                pi = "90%",
                xi = "528px",
                Yi = "20px",
                Vi = "20px",
                Wi = "20px",
                Zi = "#121212",
                Xi = "#717171",
                si = "#FFFFFF",
                li = "#FFFFFF00",
                mi = "#717171",
                ai = "#FFFFFF",
                bi = "#121212",
                di = "#121212",
                yi = "#121212",
                Qi = "4px",
                ki = "56px",
                Ji = "12px",
                hi = "8px",
                zi = "0px",
                wi = "16px",
                gi = "0px",
                vi = "20px",
                ji = "12px",
                qi = "8px",
                $i = "4px",
                _o = "action",
                Oo = "p3",
                To = "h3",
                Eo = "h1",
                no = "title",
                No = "24px",
                So = "#F3EAFF",
                Co = "#F6F6F6",
                Ao = "#121212",
                Io = "#717171",
                Ro = "#717171",
                to = "#121212",
                uo = "40px",
                ro = "12px",
                Mo = "20px",
                Lo = "8px",
                Ko = "24px",
                Do = "24px",
                eo = "p2",
                io = "p3",
                oo = "h3",
                co = "1000px",
                Fo = "#121212",
                fo = "#121212",
                Go = "#FFFFFF",
                Po = "#FFFFFF",
                Bo = "20%",
                Uo = "50%",
                Ho = "8px",
                po = "4px",
                xo = "2px",
                Yo = "24px",
                Vo = "8px",
                Wo = "16px",
                Zo = "0.5px",
                Xo = "#FFFFFF",
                so = "#121212",
                lo = "#12121214",
                mo = "#1E1E1E80",
                ao = "#FFFFFF00",
                bo = "#121212",
                yo = "#FFFFFF",
                Qo = "#121212",
                ko = "8px",
                Jo = "#1212121F",
                ho = "0px",
                zo = "0px",
                wo = "1px",
                go = "16px",
                vo = "24px",
                jo = "8px",
                qo = "0px",
                $o = "8px",
                _c = "4px",
                Oc = "0px",
                Tc = "16px",
                Ec = "16px",
                nc = "4px",
                Nc = "16px",
                Sc = "4px",
                Cc = "16px",
                Ac = "4px",
                Ic = "action-small",
                Rc = "title",
                tc = "1000px",
                uc = "#121212",
                rc = "#FFFFFF",
                Mc = "#121212",
                Lc = "#FFFFFF",
                Kc = "20%",
                Dc = "50%",
                ec = "4px",
                ic = "1000px",
                oc = "#121212",
                cc = "#FFFFFF",
                Fc = "#121212",
                fc = "#FFFFFF",
                Gc = "20%",
                Pc = "50%",
                Bc = "4%",
                Uc = "1000px",
                Hc = "2px",
                pc = "0px",
                xc = "2px",
                Yc = "2px",
                Vc = "0px",
                Wc = "2px",
                Zc = "#FFFFFF",
                Xc = "#121212",
                sc = "#FFFFFF",
                lc = "#121212",
                mc = "#FFFFFF",
                ac = "#121212",
                bc = "#C8001A",
                dc = "#121212",
                yc = "#121212",
                Qc = "#C8001A",
                kc = "#FFFFFF",
                Jc = "#FFFFFF",
                hc = "#FFFFFF",
                zc = "#FFFFFF",
                wc = "#FFFFFF",
                gc = "#121212",
                vc = "#121212",
                jc = "#121212",
                qc = "24px",
                $c = "12px",
                _F = "1000px",
                OF = "0.5px",
                TF = "0.5px",
                EF = "#F6F6F6",
                nF = "#12121214",
                NF = "#12121214",
                SF = "#717171",
                CF = "#121212",
                AF = "#121212",
                IF = "#121212",
                RF = "48px",
                tF = "20px",
                uF = "8px",
                rF = "16px",
                MF = "2px",
                LF = "8px",
                KF = "action",
                DF = "p1",
                eF = "56.25%",
                iF = "100%",
                oF = "100%",
                cF = "100%",
                FF = "66.6%",
                fF = "100%",
                GF = "100%",
                PF = "75%",
                BF = "75%",
                UF = "100%",
                HF = "80%",
                pF = "100%",
                xF = "100%",
                YF = "56.25%",
                VF = "0px",
                WF = "10px",
                ZF = "12px",
                XF = "16px",
                sF = "19px",
                lF = "24px",
                mF = "32px",
                aF = "4px",
                bF = "8px",
                dF = "1000px",
                yF = "24px",
                QF = "16px",
                kF = "20px",
                JF = "12px",
                hF = "10px",
                zF = "8px",
                wF = "0px",
                gF = "2px",
                vF = "1px",
                jF = "0px",
                qF = "1px",
                $F = "0.5px",
                _f = "2px",
                Of = "1px",
                Tf = "#1212121F",
                Ef = "#121212",
                nf = "#1212121F",
                Nf = "#FFFFFF",
                Sf = "#12121280",
                Cf = "#121212",
                Af = "#121212",
                If = "#12121214",
                Rf = "#12121214",
                tf = "#E9D8FF",
                uf = "#E9D8FF80",
                rf = "#E9D8FF",
                Mf = "#B492DE",
                Lf = "#600436",
                Kf = "#FFFFFF",
                Df = "#C8001A",
                ef = "#CCCCCC",
                of = "#121212",
                cf = "#12121280",
                Ff = "#1E1E1E80",
                ff = "#FFFFFF00",
                Gf = "#FFFFFF",
                Pf = "#121212B3",
                Bf = "#F6F6F6",
                Uf = "#F6F6F6E6",
                Hf = "#E9D8FF",
                pf = "#F6F6F6",
                xf = "#F3EAFF",
                Yf = "#E9D8FF",
                Vf = "#FFFFFF",
                Wf = "#FFFFFFCC",
                Zf = "#FFFFFF00",
                Xf = "#E9D8FF",
                sf = "#121212",
                lf = "#C8001A",
                mf = "#FFFFFF",
                af = "#E9D8FF",
                bf = "#B492DE",
                df = "#121212",
                yf = "#29131D",
                Qf = "#FFFFFF",
                kf = "#FFFFFF",
                Jf = "#E9D8FF",
                hf = "#121212",
                zf = "#600436",
                wf = "#F3EAFF",
                gf = "#FFFFFF",
                vf = "#29131D",
                jf = "#E9D8FF",
                qf = "#FFFFFF",
                $f = "#0974B0",
                _G = "#45B2EF",
                OG = "#0974B0",
                TG = "#BFE8FF",
                EG = "#5CA500",
                nG = "#407300",
                NG = "#DFF2AF",
                SG = "#FF4B23",
                CG = "#CD2500",
                AG = "#FFBDB4",
                IG = "#E9D8FF",
                RG = "#B492DE",
                tG = "#F3EAFF",
                uG = "#C8001A",
                rG = "#600436",
                MG = "#FFB6C8",
                LG = "#FFA800",
                KG = "#B04F16",
                DG = "#FFF1A4",
                eG = "#C8001A",
                iG = "#121212",
                oG = "#CCCCCC",
                cG = "#FFFFFF",
                FG = "#121212",
                fG = "#717171",
                GG = "#E9D8FF",
                PG = "#B492DE",
                BG = "#600436",
                UG = "#FFFFFF",
                HG = "#12121299",
                pG = "#00000000",
                xG = "#12121280",
                YG = "#121212",
                VG = "#F6F6F6",
                WG = "#1212120D",
                ZG = "#1212121A",
                XG = "#FFFFFF0D",
                sG = "#FFFFFF1A",
                lG = "#000000",
                mG = "#1672E9",
                aG = "#FFFFFF",
                bG = "#E4405F",
                dG = "#0076B7",
                yG = "#1D252C",
                QG = "#FF8201",
                kG = "#1DB954",
                JG = "#1AB0FF",
                hG = "#507299",
                zG = "#FFA800",
                wG = "#FFF1A4",
                gG = "#C8001A",
                vG = "#FFB6C8",
                jG = "#C8001A",
                qG = "#5CA500",
                $G = "#DFF2AF",
                _P = "#121212",
                OP = "#C8001A",
                TP = "#717171",
                EP = "#C8001A",
                nP = "#FFFFFF",
                NP = "#121212",
                SP = "#5CA500",
                CP = "#717171",
                AP = "700ms",
                IP = "800ms",
                RP = "900ms",
                tP = "1000ms",
                uP = "450ms",
                rP = "500ms",
                MP = "550ms",
                LP = "600ms",
                KP = "250ms",
                DP = "300ms",
                eP = "350ms",
                iP = "400ms",
                oP = "50ms",
                cP = "100ms",
                FP = "150ms",
                fP = "200ms",
                GP = "cubic-bezier(0.2,0.0,0,1.0)",
                PP = "cubic-bezier(0.3,0.0,0.8,0.15)",
                BP = "cubic-bezier(0.05,0.7,0.1,1.0)",
                UP = "cubic-bezier(0.2,0.0,0,1.0)",
                HP = "cubic-bezier(0.3,0,1,1.0)",
                pP = "cubic-bezier(0,0,0,1.0)",
                xP = "0%",
                YP = "10%",
                VP = "100%",
                WP = "20%",
                ZP = "30%",
                XP = "40%",
                sP = "5%",
                lP = "50%",
                mP = "60%",
                aP = "70%",
                bP = "80%",
                dP = "90%",
                yP = "12px",
                QP = "#12121233",
                kP = "12px",
                JP = "#12121233",
                hP = "0px",
                zP = "0px",
                wP = "1px",
                gP = "12px",
                vP = "#12121233",
                jP = "0px",
                qP = "0px",
                $P = "1px",
                _B = "0px",
                OB = "0px",
                TB = "1px",
                EB = "8px",
                nB = "#1212121F",
                NB = "0px",
                SB = "0px",
                CB = "1px",
                AB = "0px",
                IB = "#FFFFFF00",
                RB = "0px",
                tB = "0px",
                uB = "0px",
                rB = "24px",
                MB = "#12121233",
                LB = "0px",
                KB = "0px",
                DB = "1px",
                eB = "8px",
                iB = "#1212121F",
                oB = "0px",
                cB = "0px",
                FB = "1px",
                fB = "8px",
                GB = "#1212121F",
                PB = "0px",
                BB = "0px",
                UB = "1px",
                HB = "0px",
                pB = "12px",
                xB = "16px",
                YB = "2px",
                VB = "20px",
                WB = "24px",
                ZB = "32px",
                XB = "36px",
                sB = "4px",
                lB = "40px",
                mB = "48px",
                aB = "56px",
                bB = "6px",
                dB = "64px",
                yB = "72px",
                QB = "8px",
                kB = "80px",
                JB = "20px",
                hB = "20px",
                zB = "20px",
                wB = "20px",
                gB = "40px",
                vB = "40px",
                jB = "24px",
                qB = "20px",
                $B = "16px",
                _U = "12px",
                OU = "0px",
                TU = "1px",
                EU = "12px",
                nU = "16px",
                NU = "2px",
                SU = "20px",
                CU = "24px",
                AU = "3px",
                IU = "32px",
                RU = "4px",
                tU = "40px",
                uU = "48px",
                rU = "56px",
                MU = "8px",
                LU = "12px",
                KU = "8px",
                DU = "4px",
                eU = "16px",
                iU = "0px",
                oU = "24px",
                cU = "20px",
                FU = "20px",
                fU = "Beausite Classic",
                GU = "17px",
                PU = "semibold",
                BU = "0px",
                UU = "24px",
                HU = "Beausite Classic",
                pU = "12px",
                xU = "semibold",
                YU = "-0.1px",
                VU = "17px",
                WU = "0px",
                ZU = "none",
                XU = "none",
                sU = "0px",
                lU = "Beausite Classic",
                mU = "15px",
                aU = "semibold",
                bU = "-0.1px",
                dU = "21px",
                yU = "0px",
                QU = "none",
                kU = "none",
                JU = "none",
                hU = "none",
                zU = "Beausite Classic",
                wU = "11px",
                gU = "Clear",
                vU = "0px",
                jU = "14px",
                qU = "0px",
                $U = "none",
                _H = "none",
                OH = "Beausite Classic",
                TH = "60px",
                EH = "bold",
                nH = "-0.7px",
                NH = "67px",
                SH = "0px",
                CH = "none",
                AH = "none",
                IH = "Beausite Classic",
                RH = "49px",
                tH = "bold",
                uH = "-0.5px",
                rH = "55px",
                MH = "0px",
                LH = "none",
                KH = "none",
                DH = "Beausite Classic",
                eH = "34px",
                iH = "bold",
                oH = "-0.4px",
                cH = "38px",
                FH = "0px",
                fH = "none",
                GH = "none",
                PH = "Beausite Classic",
                BH = "24px",
                UH = "semibold",
                HH = "-0.3px",
                pH = "29px",
                xH = "0px",
                YH = "none",
                VH = "none",
                WH = "Beausite Classic",
                ZH = "21px",
                XH = "semibold",
                sH = "-0.3px",
                lH = "25px",
                mH = "0px",
                aH = "none",
                bH = "none",
                dH = "Beausite Classic",
                yH = "18px",
                QH = "semibold",
                kH = "-0.2px",
                JH = "22px",
                hH = "0px",
                zH = "none",
                wH = "none",
                gH = "Beausite Classic",
                vH = "15px",
                jH = "semibold",
                qH = "-0.1px",
                $H = "18px",
                _p = "0px",
                Op = "none",
                Tp = "none",
                Ep = "Beausite Classic",
                np = "17px",
                Np = "medium",
                Sp = "-0.1px",
                Cp = "24px",
                Ap = "0px",
                Ip = "none",
                Rp = "underline",
                tp = "Beausite Classic",
                up = "15px",
                rp = "medium",
                Mp = "-0.1px",
                Lp = "21px",
                Kp = "0px",
                Dp = "none",
                ep = "underline",
                ip = "Beausite Classic",
                op = "12px",
                cp = "semibold",
                Fp = "0px",
                fp = "17px",
                Gp = "0px",
                Pp = "none",
                Bp = "underline",
                Up = "Beausite Classic",
                Hp = "17px",
                pp = "semibold",
                xp = "-0.1px",
                Yp = "24px",
                Vp = "0px",
                Wp = "none",
                Zp = "none",
                Xp = "Beausite Classic",
                sp = "17px",
                lp = "Clear",
                mp = "-0.1px",
                ap = "24px",
                bp = "0px",
                dp = "none",
                yp = "none",
                Qp = "Beausite Classic",
                kp = "15px",
                Jp = "semibold",
                hp = "-0.1px",
                zp = "21px",
                wp = "0px",
                gp = "none",
                vp = "none",
                jp = "Beausite Classic",
                qp = "15px",
                $p = "Clear",
                _x = "-0.1px",
                Ox = "21px",
                Tx = "0px",
                Ex = "none",
                nx = "none",
                Nx = "Beausite Classic",
                Sx = "12px",
                Cx = "semibold",
                Ax = "0px",
                Ix = "17px",
                Rx = "0px",
                tx = "none",
                ux = "none",
                rx = "Beausite Classic",
                Mx = "12px",
                Lx = "medium",
                Kx = "0px",
                Dx = "17px",
                ex = "0px",
                ix = "none",
                ox = "none",
                cx = "Beausite Classic",
                Fx = "17px",
                fx = "medium",
                Gx = "-0.1px",
                Px = "19px",
                Bx = "0px",
                Ux = "none",
                Hx = "none",
                px = "1000px",
                xx = "12px",
                Yx = "#12121233",
                Vx = "0px",
                Wx = "0px",
                Zx = "1px",
                Xx = "#121212",
                sx = "#FFFFFF",
                lx = "#C8001A",
                mx = "#5CA500",
                ax = "#FFA800",
                bx = "#FFFFFF",
                dx = "20px",
                yx = "48px",
                Qx = "16px",
                kx = "8px",
                Jx = "12px",
                hx = "8px",
                zx = "p2-bolder",
                wx = "1px",
                gx = "#000000",
                vx = "#1672E9",
                jx = "#FFFFFF",
                qx = "#E4405F",
                $x = "#DADCE0",
                _Y = "#FFFFFF",
                OY = "#121212",
                TY = "#FFFFFF",
                EY = "#121212",
                nY = "#1C1C1E",
                NY = "#166FE5",
                SY = "#F8F9FA",
                CY = "#E22B4A",
                AY = "#333333",
                IY = "#1546A6",
                RY = "#F1F3F4",
                tY = "#E11B3C",
                uY = "8px",
                rY = "12px",
                MY = "0px",
                LY = "#FFFFFF",
                KY = "#717171",
                DY = "#121212",
                eY = "#717171",
                iY = "#121212",
                oY = "40px",
                cY = "24px",
                FY = "4px",
                fY = "8px",
                GY = "2px",
                PY = "-2px",
                BY = "6px",
                UY = "-6px",
                HY = "8px",
                pY = "8px",
                xY = "caption",
                YY = "2px",
                VY = "1px",
                WY = "2px",
                ZY = "1px",
                XY = "#FFFFFF00",
                sY = "#FFFFFF00",
                lY = "#121212",
                mY = "#12121214",
                aY = "#FFFFFF",
                bY = "#FFFFFF",
                dY = "#717171",
                yY = "#121212",
                QY = "#FFFFFF",
                kY = "#FFFFFF",
                JY = "#121212",
                hY = "#717171",
                zY = "#FFFFFF",
                wY = "#FFFFFF",
                gY = "24px",
                vY = "8px",
                jY = "16px",
                qY = "8px",
                $Y = "16px",
                _V = "12px",
                OV = "action-small",
                TV = "#121212",
                EV = "#FFFFFF",
                nV = "#717171",
                NV = "#FFFFFF",
                SV = "12px",
                CV = "12px",
                AV = "12px",
                IV = "12px",
                RV = "4px",
                tV = "4px",
                uV = "4px",
                rV = "4px",
                MV = "h3",
                LV = "p1-bolder",
                KV = "p3-bolder",
                DV = "p2-bolder",
                eV = "24px",
                iV = "0px",
                oV = "0px",
                cV = "0px",
                FV = "0px",
                fV = "0px",
                GV = "#121212B3",
                PV = "#FFFFFF",
                BV = "#121212B3",
                UV = "#E9D8FF80",
                HV = "#E9D8FF",
                pV = "#E9D8FF80",
                xV = "#12121214",
                YV = "#12121214",
                VV = "#12121214",
                WV = "#12121214",
                ZV = "#FFFFFF",
                XV = "#121212",
                sV = "#FFFFFF",
                lV = "#121212",
                mV = "#121212",
                aV = "#121212",
                bV = "#FFFFFF",
                dV = "#121212",
                yV = "#FFFFFF",
                QV = "#121212",
                kV = "#121212",
                JV = "#121212",
                hV = "#1212120D",
                zV = "#1212121A",
                wV = "#FFFFFF0D",
                gV = "#FFFFFF1A",
                vV = "#FFFFFF",
                jV = "#121212",
                qV = "#FFFFFF",
                $V = "#121212",
                _W = "#121212",
                OW = "#121212",
                TW = "12px",
                EW = "#12121233",
                nW = "0px",
                NW = "0px",
                SW = "1px",
                CW = "8px",
                AW = "#1212121F",
                IW = "0px",
                RW = "0px",
                tW = "1px",
                uW = "0px",
                rW = "#FFFFFF00",
                MW = "0px",
                LW = "0px",
                KW = "0px",
                DW = "20px",
                eW = "20px",
                iW = "20px",
                oW = "20px",
                cW = "40px",
                FW = "24px",
                fW = "48px",
                GW = "12px",
                PW = "8px",
                BW = "0px",
                UW = "8px",
                HW = "2px",
                pW = "20px",
                xW = "16px",
                YW = "0px",
                VW = "20px",
                WW = "16px",
                ZW = "12px",
                XW = "p3",
                sW = "title",
                lW = "1000px",
                mW = "2px",
                aW = "2px",
                bW = "2px",
                dW = "2px",
                yW = "#121212",
                QW = "#FFFFFF",
                kW = "#FFFFFF",
                JW = "#121212",
                hW = "#121212",
                zW = "#121212",
                wW = "#FFFFFF",
                gW = "#FFFFFF",
                vW = "#FFFFFF",
                jW = "#121212",
                qW = "#121212",
                $W = "#FFFFFF",
                _Z = "16px",
                OZ = "4px",
                TZ = "20px",
                EZ = "20px",
                nZ = "4px",
                NZ = "4px",
                SZ = "24px",
                CZ = "#E9D8FF",
                AZ = "#121212",
                IZ = "8px",
                RZ = "12px",
                tZ = "16px",
                uZ = "20px",
                rZ = "20px",
                MZ = "16px",
                LZ = "16px",
                KZ = "12px",
                DZ = "p3-bolder",
                eZ = "12px",
                iZ = "24px",
                oZ = "16px",
                cZ = "8px",
                FZ = "64px",
                fZ = "12px",
                GZ = "8px",
                PZ = "480px",
                BZ = "16px",
                UZ = "24px",
                HZ = "16px",
                pZ = "12px",
                xZ = "64px",
                YZ = "16px",
                VZ = "12px",
                WZ = "8px",
                ZZ = "56px",
                XZ = "78px",
                sZ = "0.9s",
                lZ = "3.0s",
                mZ = "11px",
                aZ = "18px",
                bZ = "2px",
                dZ = "2px",
                yZ = "6px",
                QZ = "#FFFFFF",
                kZ = "12px",
                JZ = "#121212",
                hZ = "8px",
                zZ = "16px",
                wZ = "8px",
                gZ = "22px",
                vZ = "8px",
                jZ = "8px",
                qZ = "16px",
                $Z = "16px",
                _X = "system",
                OX = "system",
                TX = "system",
                EX = "Noi Grotesk",
                nX = "Noi Grotesk",
                NX = "Noi Grotesk",
                SX = "Noi Grotesk",
                CX = "Noi Grotesk",
                AX = "Noi Grotesk",
                IX = "Noi Grotesk",
                RX = "system",
                tX = "system",
                uX = "system",
                rX = "system",
                MX = "system",
                LX = "system",
                KX = "system",
                DX = "system",
                eX = "17px",
                iX = "13px",
                oX = "15px",
                cX = "60px",
                FX = "49px",
                fX = "34px",
                GX = "26px",
                PX = "22px",
                BX = "19px",
                UX = "15px",
                HX = "17px",
                pX = "17px",
                xX = "15px",
                YX = "15px",
                VX = "12px",
                WX = "12px",
                ZX = "18px",
                XX = "semibold",
                sX = "semibold",
                lX = "semibold",
                mX = "semibold",
                aX = "semibold",
                bX = "semibold",
                dX = "semibold",
                yX = "semibold",
                QX = "semibold",
                kX = "semibold",
                JX = "regular",
                hX = "medium",
                zX = "regular",
                wX = "semibold",
                gX = "medium",
                vX = "bold",
                jX = "semibold",
                qX = "24px",
                $X = "24px",
                _s = "16px",
                Os = "#121212",
                Ts = "8px",
                Es = "480px",
                ns = "#C8001A",
                Ns = "#717171",
                Ss = "#5CA500",
                Cs = "8px",
                As = "8px",
                Is = "16px",
                Rs = "8px",
                ts = "12px",
                us = "16px",
                rs = "#CCCCCC",
                Ms = "#FD7F7E",
                Ls = "#F99DF0",
                Ks = "#FF8201",
                Ds = "#FED759",
                es = "#15CC79",
                is = "#17D417",
                os = "#783BF9",
                cs = "#44A3EA",
                Fs = "#2B8CFC",
                fs = "8px",
                Gs = "4px",
                Ps = "1px",
                Bs = "12px",
                Us = "system",
                Hs = "12px",
                ps = "medium",
                xs = "8px",
                Ys = "16px",
                Vs = "120px",
                Ws = "96px",
                Zs = "64px",
                Xs = "30px",
                ss = "22px",
                ls = "16px",
                ms = "36px",
                as = "10px",
                bs = "46px",
                ds = "#FFFFFF",
                ys = "24px",
                Qs = "24px",
                ks = "#121212",
                Js = "#121212",
                hs = "16px",
                zs = "16px",
                ws = "48px",
                gs = "16px",
                vs = "16px",
                js = "8px",
                qs = "12px",
                $s = "#121212",
                _l = "#FFFFFF",
                Ol = "#121212",
                Tl = "#FFFFFF",
                El = "#C8001A",
                nl = "#CCCCCC",
                Nl = "#FFFFFF",
                Sl = "#121212",
                Cl = "#121212",
                Al = "#FFFFFF",
                Il = "#FFFFFF",
                Rl = "#C8001A",
                tl = "#00000000",
                ul = "#FFFFFF",
                rl = "24px",
                Ml = "0.5",
                Ll = "18px",
                Kl = "8px",
                Dl = "#121212",
                el = "8px",
                il = "20px",
                ol = "36px",
                cl = "#121212",
                Fl = "12px",
                fl = "8px",
                Gl = "18px",
                Pl = "12px",
                Bl = "#717171",
                Ul = "#121212",
                Hl = "0.2s",
                pl = "2px",
                xl = "#121212",
                Yl = "#121212",
                Vl = "#00000000",
                Wl = "#FFFFFF",
                Zl = "#121212",
                Xl = "#FFFFFF",
                sl = "#121212",
                ll = "#121212",
                ml = "24px",
                al = "16px",
                bl = "40px",
                dl = "22px",
                yl = "20px",
                Ql = "20px",
                kl = "64px",
                Jl = "55px",
                hl = "37px",
                zl = "30px",
                wl = "26px",
                gl = "21px",
                vl = "19px",
                jl = "22px",
                ql = "22px",
                $l = "20px",
                _m = "20px",
                Om = "16px",
                Tm = "16px",
                Em = "22px",
                nm = "#717171",
                Nm = "16px",
                Sm = "1px",
                Cm = "16px",
                Am = "8px",
                Im = "#717171",
                Rm = "#FFFFFF",
                tm = "#121212",
                um = "12px",
                rm = "16px",
                Mm = "16px",
                Lm = "8px",
                Km = "#F6F6F6",
                Dm = "#121212",
                em = "8px",
                im = "12px",
                om = "12px",
                cm = "6px",
                Fm = "4px",
                fm = "#000000",
                Gm = "0.1",
                Pm = "2px",
                Bm = "24px",
                Um = "4px",
                Hm = "#00000000",
                pm = "16%",
                xm = "50%",
                Ym = "-10",
                Vm = "2",
                Wm = "6%",
                Zm = "5%",
                Xm = "10",
                sm = "1",
                lm = "-6%",
                mm = "15%",
                am = "0px",
                bm = "128px",
                dm = "0px",
                ym = "96px",
                Qm = "0px",
                km = "168px",
                Jm = "#121212",
                hm = "12px",
                zm = "2px",
                wm = "5px",
                gm = "12px",
                vm = "12px",
                jm = "24px",
                qm = "#717171",
                $m = "24px",
                _a = "200px",
                Oa = "16px",
                Ta = "16px",
                Ea = "16px",
                na = "16px",
                Na = "6px",
                Sa = "2",
                Ca = "1",
                Aa = "32px",
                Ia = "24px",
                Ra = "16px",
                ta = "90%",
                ua = "528px",
                ra = "#121212",
                Ma = "24px",
                La = "12px",
                Ka = "24px",
                Da = "24px",
                ea = "16px",
                ia = "0.6",
                oa = "40px",
                ca = "#121212",
                Fa = "#121212",
                fa = "#121212",
                Ga = "0.4",
                Pa = "#FFFFFF",
                Ba = "50px",
                Ua = "24px",
                Ha = "36px",
                pa = "36px",
                xa = "8px",
                Ya = "#717171",
                Va = "36px",
                Wa = "#121212",
                Za = "8px",
                Xa = "#F6F6F6",
                sa = "#121212",
                la = "24px",
                ma = "#717171",
                aa = "24px",
                ba = "24px",
                da = "24px",
                ya = "16px",
                Qa = "16px",
                ka = "8px",
                Ja = "6px",
                ha = "#FFA800",
                za = "#5CA500",
                wa = "6px",
                ga = "2px",
                va = "10px",
                ja = "#000000",
                qa = "0.08",
                $a = "4px",
                _b = "48px",
                Ob = "40px",
                Tb = "0.3s",
                Eb = "1",
                nb = "0.666",
                Nb = "0.333",
                Sb = "0",
                Cb = "4px",
                Ab = "1",
                Ib = "0.4",
                Rb = "6px",
                tb = "110px",
                ub = "2px",
                rb = "#CCCCCC",
                Mb = "24px",
                Lb = "1px",
                Kb = "24px",
                Db = "36px",
                eb = "16px",
                ib = "16px",
                ob = "12px",
                cb = "12px",
                Fb = "#121212",
                fb = "12px",
                Gb = "4px",
                Pb = "8px",
                Bb = "4px",
                Ub = "1px",
                Hb = "16px",
                pb = "24px",
                xb = "#FFFFFF",
                Yb = "#717171",
                Vb = "1px",
                Wb = "#121212",
                Zb = "16px",
                Xb = "#121212",
                sb = "2px",
                lb = "system",
                mb = "17px",
                ab = "medium",
                bb = "56px",
                db = "#121212",
                yb = "4px",
                Qb = "16px",
                kb = "22px",
                Jb = "16px",
                hb = "#C8001A",
                zb = "2px",
                wb = "#5CA500",
                gb = "2px",
                vb = "10px",
                jb = "16px",
                qb = "16px",
                $b = "15px",
                _d = "7px",
                Od = "10px",
                Td = "#000000",
                Ed = "0.2",
                nd = "5px",
                Nd = "5px",
                Sd = "6px",
                Cd = "#F6F6F6",
                Ad = "10px",
                Id = "6px",
                Rd = "12px",
                td = "#FFFFFF",
                ud = "#CCCCCC",
                rd = "16px",
                Md = "1px",
                Ld = "32px",
                Kd = "0.6",
                Dd = "#000000",
                ed = "0.2",
                id = "0px",
                od = "12px",
                cd = "#000000",
                Fd = "0.2",
                fd = "48px",
                Gd = "12px",
                Pd = "4px",
                Bd = "4px",
                Ud = "16px",
                Hd = "16px",
                pd = "16px",
                xd = "12px",
                Yd = "8px",
                Vd = "24px",
                Wd = "4px",
                Zd = "32px",
                Xd = "12px",
                sd = "16px",
                ld = "12px",
                md = "8px",
                ad = "12px",
                bd = "#CCCCCC",
                dd = "15px",
                yd = "25%",
                Qd = "#121212",
                kd = "#717171",
                Jd = "48px",
                hd = "#121212",
                zd = "#717171",
                wd = "system",
                gd = "10px",
                vd = "12px",
                jd = "#121212",
                qd = "#979797",
                $d = "4px",
                _y = "24px",
                Oy = "23px",
                Ty = "5px",
                Ey = "6px",
                ny = "#121212",
                Ny = "#121212",
                Sy = "#FFFFFF",
                Cy = "#121212",
                Ay = "#121212",
                Iy = "#FFFFFF",
                Ry = "1",
                ty = "0.5",
                uy = "8px",
                ry = "#121212",
                My = "#121212",
                Ly = "#FFFFFF",
                Ky = "#FFFFFF",
                Dy = "4px",
                ey = "24px",
                iy = "system",
                oy = "15px",
                cy = "semibold",
                Fy = "24px",
                fy = "20px",
                Gy = "12px",
                Py = "16px",
                By = "12px",
                Uy = "44px",
                Hy = "system",
                py = "13px",
                xy = "semibold",
                Yy = "24px",
                Vy = "20px",
                Wy = "12px",
                Zy = "8px",
                Xy = "12px",
                sy = "3px",
                ly = "16px",
                my = "#EAEAEA",
                ay = "1",
                by = "1px",
                dy = "#EAEAEA",
                yy = "1",
                Qy = "#FFFFFF",
                ky = "#717171",
                Jy = "1px",
                hy = "#121212",
                zy = "16px",
                wy = "#121212",
                gy = "2px",
                vy = "system",
                jy = "17px",
                qy = "medium",
                $y = "22px",
                _Q = "84px",
                OQ = "16px",
                TQ = "16px",
                EQ = "#C8001A",
                nQ = "2px",
                NQ = "#5CA500",
                SQ = "2px",
                CQ = "#FFFFFF",
                AQ = "#717171",
                IQ = "1px",
                RQ = "#121212",
                tQ = "16px",
                uQ = "#121212",
                rQ = "2px",
                MQ = "system",
                LQ = "17px",
                KQ = "medium",
                DQ = "56px",
                eQ = "#121212",
                iQ = "24px",
                oQ = "22px",
                cQ = "16px",
                FQ = "8px",
                fQ = "#C8001A",
                GQ = "2px",
                PQ = "#5CA500",
                BQ = "2px",
                UQ = "20px",
                HQ = "14px",
                pQ = "#E9D8FF",
                xQ = "20px",
                YQ = "16px",
                VQ = "16px",
                WQ = "12px",
                ZQ = "10px",
                XQ = "#000000",
                sQ = "0.08",
                lQ = "4px",
                mQ = "#121212",
                aQ = "44px",
                bQ = "22px",
                dQ = "#F6F6F6",
                yQ = "12px",
                QQ = "8.6%",
                kQ = ".8",
                JQ = "2px",
                hQ = "50%",
                zQ = ".25",
                wQ = "50%",
                gQ = ".15",
                vQ = "133.333%",
                jQ = ".05",
                qQ = "1px",
                $Q = "12px",
                _k = "16px",
                Ok = "16px",
                Tk = "120px",
                Ek = "125%",
                nk = "80px",
                Nk = "50%",
                Sk = "4px",
                Ck = "16px",
                Ak = "8px"
        }
    }
]);
//# sourceMappingURL=2065.0a1eea1f337ecd85f145.js.map
"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [9904], {
        19247: function(e, t, n) {
            var i = n(96540),
                o = n(74022);
            t.A = function(e) {
                var t = (0, i.useState)({
                        scrollX: 0,
                        scrollY: 0
                    }),
                    n = t[0],
                    r = t[1];
                return (0, i.useEffect)((function() {
                    var t = null == e ? void 0 : e.current,
                        n = (0, o.A)((function() {
                            t && r({
                                scrollX: t.scrollLeft,
                                scrollY: t.scrollTop
                            })
                        }), 100);
                    return t && t.addEventListener("scroll", n, {
                            capture: !1,
                            passive: !0
                        }),
                        function() {
                            t && t.removeEventListener("scroll", n)
                        }
                }), [e]), n
            }
        },
        39904: function(e, t, n) {
            n.d(t, {
                $4: function() {
                    return a
                },
                Ez: function() {
                    return o
                },
                TN: function() {
                    return r
                },
                X2: function() {
                    return i
                }
            });
            n(52675), n(45700), n(2008), n(51629), n(48598), n(15086), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(3949), n(37550), n(23500);
            var i, o, r, a, l = n(96540),
                s = n(46942),
                c = n.n(s),
                u = n(88086),
                d = n(19247),
                p = n(73260),
                A = n(40075),
                f = n(82195),
                v = n(99795),
                h = n(83852),
                y = n(10730),
                b = n(94318),
                O = n(68072),
                g = n(28733),
                E = n(12554),
                C = n(89769),
                I = n(12501),
                T = n(8483),
                L = n(41296),
                R = n(15279),
                m = n(74848);

            function N(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function k(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? N(Object(n), !0).forEach((function(t) {
                        S(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : N(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function S(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function j(e, t) {
                var n = function(e, t) {
                    switch (e) {
                        case i.BACK:
                            return ["navigation-bar-back", A.Ay.get(269)];
                        case i.CLOSE:
                            return ["navigation-bar-close", A.Ay.get(270)];
                        case i.EDIT:
                            return ["navigation-bar-edit", ""];
                        case i.EDIT_PROFILE:
                            return ["navigation-bar-edit-profile", A.Ay.get(271)];
                        case i.FAVOURITE:
                            return [t ? "navigation-bar-favourite-active" : "navigation-bar-favourite", t ? A.Ay.get(276) : A.Ay.get(268)];
                        case i.FILTER:
                            return ["navigation-bar-filter", A.Ay.get(273)];
                        case i.LIKED_YOU:
                            return ["navigation-bar-liked-you", A.Ay.get(274)];
                        case i.MENU:
                            return ["navigation-bar-menu", A.Ay.get(275)];
                        case i.SETTINGS:
                            return ["navigation-bar-settings", A.Ay.get(277)];
                        case i.UNDO:
                            return ["navigation-bar-undo", A.Ay.get(279)];
                        case i.VIDEO_CALL:
                            return ["navigation-bar-video", A.Ay.get(281)];
                        case i.ELLIPSIS:
                            return ["navigation-bar-ellipsis", A.Ay.get(272)];
                        case i.NOTIFICATION:
                            return ["generic-notification", ""]
                    }
                }(e, t);
                return {
                    name: n[0],
                    a11y: {
                        iconLabel: n[1]
                    }
                }
            }! function(e) {
                e.BACK = "BACK", e.CLOSE = "CLOSE", e.EDIT = "EDIT", e.EDIT_PROFILE = "EDIT_PROFILE", e.FAVOURITE = "FAVOURITE", e.FILTER = "FILTER", e.LIKED_YOU = "LIKED_YOU", e.MENU = "MENU", e.SETTINGS = "SETTINGS", e.UNDO = "UNDO", e.VIDEO_CALL = "VIDEO_CALL", e.ELLIPSIS = "ELLIPSIS", e.NOTIFICATION = "NOTIFICATION"
            }(i || (i = {})),
            function(e) {
                e.PRIMARY = "PRIMARY", e.SECONDARY = "SECONDARY"
            }(o || (o = {})),
            function(e) {
                e.POPULARITY = "POPULARITY", e.CHAT_UNBLOCKERS = "CHAT_UNBLOCKERS", e.CUSTOM_COMPONENT = "CUSTOM_COMPONENT"
            }(r || (r = {})),
            function(e) {
                e.BUTTON = "BUTTON"
            }(a || (a = {}));
            t.Ay = function(e) {
                var t, n, s = e.children,
                    N = e.actions,
                    S = e.title,
                    D = e.subTitle,
                    P = e.titleTag,
                    _ = void 0 === P ? "h1" : P,
                    x = e.logo,
                    U = e.logoReplacement,
                    w = void 0 === U ? null : U,
                    Y = e.logoTag,
                    F = e.position,
                    H = e.hasShadow,
                    V = e.shadowThreshold,
                    G = void 0 === V ? 1 : V,
                    M = e.shadowRef,
                    W = e.transparent,
                    B = e.inverted,
                    Q = e.profile,
                    K = e.isProfileHidden,
                    X = e.isShowingBlockingTip,
                    J = e.isBalanced,
                    z = void 0 === J || J,
                    $ = e.a11y,
                    q = (0, p.pJ)(),
                    Z = [],
                    ee = [],
                    te = {
                        status: "visible"
                    };
                null == N || N.forEach((function(e, t) {
                    var n, s, c, u, d, v, y;
                    switch (e.type) {
                        case i.BACK:
                        case i.LIKED_YOU:
                        case i.MENU:
                            Z.push((0, l.createElement)(b.A, k(k({}, j(e.type, e.isActive)), {}, {
                                key: "navigation-action-" + e.type.toLowerCase(),
                                notification: e.hasNotification ? te : void 0,
                                isDisabled: e.isDisabled,
                                onClick: e.onClick,
                                dataQA: e.dataQA
                            })));
                            break;
                        case i.CLOSE:
                            (e.position === o.SECONDARY ? ee : Z).push((0, l.createElement)(b.A, k(k({}, j(e.type, e.isActive)), {}, {
                                key: "navigation-action-" + e.type.toLowerCase(),
                                notification: e.hasNotification ? te : void 0,
                                isDisabled: e.isDisabled,
                                onClick: e.onClick,
                                dataQA: e.dataQA
                            })));
                            break;
                        case r.POPULARITY:
                            ee.push((0, m.jsx)(l.Fragment, {
                                children: (0, m.jsx)(b.A, {
                                    name: p.yf[e.level],
                                    onClick: e.onClick,
                                    a11y: {
                                        iconLabel: q[e.level].labelFull
                                    },
                                    dataQA: e.dataQA
                                })
                            }, "navigation-action-" + e.type.toLowerCase()));
                            break;
                        case r.CHAT_UNBLOCKERS:
                            ee.push((0, m.jsx)(L.A, {
                                type: 45,
                                children: (0, m.jsx)("div", {
                                    ref: e.ref,
                                    style: {
                                        padding: "8px 4px"
                                    },
                                    children: (0, m.jsx)(f.A, {
                                        icon: "generic-chat",
                                        text: void 0 !== e.numChatUnblockers ? "" + e.numChatUnblockers : "-",
                                        styling: e.isPremiumPlus ? "premium-plus" : "notification",
                                        onClick: e.onClick,
                                        a11y: {
                                            ariaDescribedby: null == (n = e.a11y) ? void 0 : n.ariaDescribedby,
                                            label: void 0 !== e.numChatUnblockers ? A.Ay.get(280, {
                                                num: e.numChatUnblockers
                                            }) : void 0
                                        }
                                    })
                                })
                            }, "navigation-action-" + e.type.toLowerCase()));
                            break;
                        case i.SETTINGS:
                        case i.UNDO:
                        case i.EDIT:
                        case i.EDIT_PROFILE:
                        case i.FAVOURITE:
                        case i.VIDEO_CALL:
                        case i.ELLIPSIS:
                            ee.push((0, m.jsx)(L.A, {
                                type: (null == (s = e.tooltip) ? void 0 : s.type) || 59,
                                condition: (null == (c = e.tooltip) ? void 0 : c.condition) || X && e.type === i.ELLIPSIS,
                                onClick: (null == (u = e.tooltip) ? void 0 : u.onClick) || e.onClick,
                                children: (0, m.jsx)("div", {
                                    className: "encounters-header-tooltip-wrapper",
                                    children: (0, m.jsx)(b.A, k(k({}, j(e.type, e.isActive)), {}, {
                                        notification: e.hasNotification ? te : void 0,
                                        isDisabled: e.isDisabled,
                                        onClick: e.onClick,
                                        dataQA: e.dataQA
                                    }))
                                })
                            }, "navigation-action-" + e.type.toLowerCase()));
                            break;
                        case i.NOTIFICATION:
                            ee.push((0, m.jsx)(b.A, k(k({}, j(e.type, e.isActive)), {}, {
                                notification: e.hasNotification ? te : void 0,
                                isDisabled: e.isDisabled,
                                onClick: e.onClick,
                                dataQA: e.dataQA
                            })));
                            break;
                        case i.FILTER:
                            ee.push((0, m.jsx)(L.A, {
                                type: (null == (d = e.tooltip) ? void 0 : d.type) || 9,
                                condition: null == (v = e.tooltip) ? void 0 : v.condition,
                                onClick: (null == (y = e.tooltip) ? void 0 : y.onClick) || e.onClick,
                                children: (0, m.jsx)(b.A, k(k({}, j(e.type, e.isActive)), {}, {
                                    notification: e.hasNotification ? te : void 0,
                                    isDisabled: e.isDisabled,
                                    onClick: e.onClick,
                                    dataQA: e.dataQA,
                                    a11y: null == e ? void 0 : e.a11y
                                }))
                            }, "navigation-action-" + e.type.toLowerCase()));
                            break;
                        case a.BUTTON:
                            ee.push((0, m.jsx)(h.A, {
                                text: e.text,
                                isDisabled: e.isDisabled,
                                onClick: e.onClick,
                                dataQA: e.dataQA
                            }, "navigation-action-" + e.type.toLowerCase()));
                            break;
                        case r.CUSTOM_COMPONENT:
                            var O = (0, l.cloneElement)(e.component, {
                                key: "navigation-action-" + e.type.toLowerCase() + "-" + t
                            });
                            e.isPrimaryAction ? Z.push(O) : ee.push(O)
                    }
                }));
                var ne, ie = Z.length > 0 || z && ee.length > 0,
                    oe = ee.length > 0 || z && Z.length > 0,
                    re = !!N && N.some((function(e) {
                        return e.type === a.BUTTON
                    })),
                    ae = (Z.length > 1 || ee.length > 1 || re) && !Q;
                ne = "sticky" === F ? "fixed" : F;
                var le = (0, u.A)().scrollY,
                    se = (0, d.A)(M).scrollY,
                    ce = [null == Q || null == (t = Q.user) ? void 0 : t.name, null == Q || null == (n = Q.user) ? void 0 : n.age, null == Q ? void 0 : Q.additional, A.Ay.get(419)].filter(Boolean).join(", ");
                return (0, m.jsxs)(l.Fragment, {
                    children: [(0, m.jsxs)(v.A, {
                        position: ne,
                        shadow: H && (le > G || se > G),
                        transparent: W,
                        inverted: B,
                        extra: D ? (0, m.jsx)(R.A, {
                            text: D
                        }) : void 0,
                        children: [ie ? (0, m.jsx)(g.A, {
                            isWide: ae,
                            children: Z
                        }) : null, "string" == typeof S ? (0, m.jsx)(I.A, {
                            text: S,
                            tag: _,
                            a11y: {
                                label: null == $ ? void 0 : $.titleLabel
                            }
                        }) : null, "object" == typeof S && S.text ? (0, m.jsx)(I.A, k({}, S)) : null, x && !w ? (0, m.jsx)(O.A, {
                            a11y: {
                                label: (null == $ ? void 0 : $.logoLabel) || A.Ay.get(621)
                            },
                            tag: Y || null != $ && $.logoLabel ? "h1" : void 0,
                            children: (0, m.jsx)(T.A, {
                                name: "logo-boxed"
                            })
                        }) : w, Q ? (0, m.jsx)("div", {
                            className: c()("navigation-profile", {
                                "navigation-profile--shifted-top": K
                            }),
                            "aria-hidden": K,
                            children: (0, m.jsx)(E.A, k(k({}, Q), {}, {
                                a11y: {
                                    label: ce
                                },
                                onClick: K ? void 0 : Q.onClick
                            }))
                        }) : null, s ? (0, m.jsx)(y.A, {
                            children: s
                        }) : null, oe ? (0, m.jsx)(C.A, {
                            isWide: ae,
                            children: ee
                        }) : null]
                    }), "sticky" === F ? (0, m.jsx)(v.A, {
                        transparent: W
                    }) : null]
                })
            }
        },
        41296: function(e, t, n) {
            n(10287);
            var i = n(56368),
                o = n(96540),
                r = n(74848);

            function a(e, t) {
                return a = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, a(e, t)
            }
            var l = function(e) {
                function t(t) {
                    var n;
                    return (n = e.call(this, t) || this).childRef = void 0, n.onboardingTipsController = i.A.getInstance(), n.setRef = n.setRef.bind(n), n.handleAction = n.handleAction.bind(n), n.handleSecondaryAction = n.handleSecondaryAction.bind(n), n
                }
                var n, o;
                o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, a(n, o);
                var l = t.prototype;
                return l.componentDidMount = function() {
                    var e = this.props,
                        t = e.condition,
                        n = e.type,
                        o = e.timer;
                    !this.childRef || void 0 !== t && !0 !== t || (this.onboardingTipsController.registerElement({
                        type: n,
                        timer: o,
                        ref: this.childRef
                    }), this.onboardingTipsController.on(i.A.ACTIONS.PERFORM_ACTION, this.handleAction), this.onboardingTipsController.on(i.A.ACTIONS.PERFORM_SECONDARY_ACTION, this.handleSecondaryAction))
                }, l.componentWillUnmount = function() {
                    this.onboardingTipsController.unregisterElement(this.props.type), this.onboardingTipsController.off(i.A.ACTIONS.PERFORM_ACTION, this.handleAction), this.onboardingTipsController.off(i.A.ACTIONS.PERFORM_SECONDARY_ACTION, this.handleSecondaryAction)
                }, l.componentDidUpdate = function(e) {
                    var t = e.condition,
                        n = this.props,
                        i = n.condition,
                        o = n.type,
                        r = n.timer;
                    !t && i && this.onboardingTipsController.registerElement({
                        type: o,
                        timer: r,
                        ref: this.childRef
                    })
                }, l.handleAction = function(e, t) {
                    var n = this.props,
                        i = n.type,
                        o = n.onClick;
                    i === e && o && o(t)
                }, l.handleSecondaryAction = function(e, t) {
                    var n = this.props,
                        i = n.type,
                        o = n.onSecondaryClick;
                    i === e && o && o(t)
                }, l.setRef = function(e) {
                    this.childRef = e
                }, l.render = function() {
                    return this.props.renderWithRef ? this.props.renderWithRef(this.setRef) : (0, r.jsx)("div", {
                        ref: this.setRef,
                        children: this.props.children
                    })
                }, t
            }(o.Component);
            t.A = l
        },
        73260: function(e, t, n) {
            n.d(t, {
                pJ: function() {
                    return s
                },
                s7: function() {
                    return r
                },
                yf: function() {
                    return l
                }
            });
            var i, o, r, a = n(40075);
            ! function(e) {
                e.VERY_LOW = "VERY_LOW", e.LOW = "LOW", e.AVERAGE = "AVERAGE", e.HIGH = "HIGH", e.VERY_HIGH = "VERY_HIGH"
            }(r || (r = {}));
            var l = ((i = {})[r.VERY_LOW] = "speedometer-popularity-verylow", i[r.LOW] = "speedometer-popularity-low", i[r.AVERAGE] = "speedometer-popularity-average", i[r.HIGH] = "speedometer-popularity-high", i[r.VERY_HIGH] = "speedometer-popularity-veryhigh", i),
                s = ((o = {})[r.VERY_LOW] = "verylow", o[r.LOW] = "low", o[r.AVERAGE] = "average", o[r.HIGH] = "high", o[r.VERY_HIGH] = "veryhigh", function() {
                    var e;
                    return (e = {})[r.VERY_LOW] = {
                        labelFull: a.Ay.get(267)
                    }, e[r.LOW] = {
                        labelFull: a.Ay.get(265)
                    }, e[r.AVERAGE] = {
                        labelFull: a.Ay.get(263)
                    }, e[r.HIGH] = {
                        labelFull: a.Ay.get(264)
                    }, e[r.VERY_HIGH] = {
                        labelFull: a.Ay.get(266)
                    }, e
                })
        },
        88086: function(e, t, n) {
            var i = n(99417),
                o = n(96540),
                r = n(74022);
            t.A = function() {
                var e = (0, o.useState)({
                        scrollX: 0,
                        scrollY: 0
                    }),
                    t = e[0],
                    n = e[1];
                return (0, o.useEffect)((function() {
                    var e = (0, r.A)((function() {
                        n({
                            scrollX: i.A.scrollX,
                            scrollY: i.A.scrollY
                        })
                    }), 100);
                    return i.A.addEventListener("scroll", e),
                        function() {
                            i.A.removeEventListener("scroll", e)
                        }
                }), []), t
            }
        }
    }
]);
//# sourceMappingURL=9904.600c076736103d6dc4ac.js.map
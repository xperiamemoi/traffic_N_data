"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [2362], {
        2513: function(e, n, t) {
            t.d(n, {
                A: function() {
                    return c
                }
            });
            var r = t(65297),
                o = t(1270),
                a = t(58544),
                i = t(68507);

            function c(e) {
                var n = (0, i.A)(),
                    t = (0, o.A)(e.getScrollableElement()),
                    c = !1,
                    u = 0,
                    l = (0, a.lh)(),
                    s = (0, a.lh)();

                function f() {
                    c || (l.trigger(), u = n.scrollTop, t.addClass("is-fixed"), t.css("top", "-" + u + "px"), c = !0)
                }

                function d() {
                    var r;
                    c && (t.removeClass("is-fixed"), t.css("top", null), function() {
                        var t = "fixed" === (0, o.A)(e.getScrollableElement()).css("position");
                        if (!c || !t) return;
                        n.offsetHeight - u < n.clientHeight && (u = 0)
                    }(), r = u, n.scrollTop = r, c = !1, s.trigger())
                }

                function v() {
                    c && (u = 0, t.css("top", null))
                }

                function A() {
                    e.isActive() && f()
                }

                function g() {
                    e.isActive() && d()
                }
                return r.A.on(r.A.ORIENTATION_CHANGE, v), r.A.on(r.A.BEFORE_SHOW_MODAL, A).on(r.A.HIDE_MODAL, g), {
                    lockPosition: f,
                    unlockPosition: d,
                    isPositionLocked: function() {
                        return c
                    },
                    beforePositionLock: l.subscribe,
                    onPositionUnlock: s.subscribe,
                    detachEvents: function() {
                        r.A.off(r.A.ORIENTATION_CHANGE, v), r.A.off(r.A.BEFORE_SHOW_MODAL, A).off(r.A.HIDE_MODAL, g)
                    }
                }
            }
        },
        4172: function(e, n, t) {
            t.d(n, {
                w: function() {
                    return m
                }
            });
            var r = t(37905),
                o = t(65297),
                a = t(96540),
                i = t(73510),
                c = t(80004),
                u = t(18640),
                l = t(12579),
                s = t(24446),
                f = t(15193),
                d = t(61938),
                v = t(49952),
                A = t(66644),
                g = t(75349),
                p = t(2513),
                b = t(74848);

            function m(e, n) {
                void 0 === n && (n = {});
                var t = {
                    pageController: e,
                    params: n
                };
                o.A.trigger(o.A.LEGACY_OPEN_PAGE, t)
            }
            n.A = function(e) {
                var n = e.onControllerInstance,
                    t = e.pageLoadStartRef,
                    o = (0, A.Pi)(),
                    m = (0, A.cq)(),
                    h = (0, a.useRef)(),
                    y = (0, a.useState)(),
                    j = y[0],
                    O = y[1],
                    P = (0, f.A)(o),
                    N = (0, f.A)(j),
                    E = (0, d.A)(m),
                    x = E[0],
                    S = E[1];

                function T() {
                    r.A.regenerateId()
                }(0, a.useEffect)((function() {
                    o && (0, g.A)()
                }), [o]), (0, a.useEffect)((function() {
                    if (j) {
                        var e = (0, p.A)(j);
                        return function() {
                            return e.detachEvents()
                        }
                    }
                }), [j]);
                var k = (0, a.useCallback)((function() {
                    j && (n && n(j), v.R.trigger(j))
                }), [j, n]);
                (0, a.useEffect)((function() {
                    j && (v.nJ.trigger(j, (null == m ? void 0 : m.parameters) || {}), null != m && m.routeName && (null == h ? void 0 : h.current) !== (null == m ? void 0 : m.routeName) && (u.U.pageView(), h.current = null == m ? void 0 : m.routeName))
                }), [j, m]);
                var C = (0, a.useCallback)((function(e) {
                        r.A.setController(e), e.jinba && e.jinba.start(t.current), O(e)
                    }), [t]),
                    R = (0, l.A)(o, P, m),
                    w = R.timeout,
                    _ = R.className,
                    L = (0, a.useCallback)((function(e) {
                        return (0, a.cloneElement)(e, {
                            classNames: _,
                            timeout: w,
                            nodeRef: null
                        })
                    }), [_, w]),
                    D = (0, a.useRef)(null);
                return (0, b.jsx)(c.A, {
                    component: null,
                    childFactory: L,
                    children: o && m ? (0, b.jsx)(i.A, {
                        appear: !0,
                        nodeRef: D,
                        classNames: _,
                        timeout: w,
                        mountOnEnter: !0,
                        unmountOnExit: !0,
                        onEntered: k,
                        children: function(e) {
                            return (0, b.jsx)(s.A, {
                                transitionStatus: e,
                                activationPlace: N ? N.activationPlace : void 0,
                                controller: o,
                                navigation: m,
                                onAttached: C,
                                pageNodeRef: D,
                                onScreenNameChange: T,
                                scrollPosition: x,
                                saveScrollPosition: S
                            }, m.routeName)
                        }
                    }, m.routeName) : null
                })
            }
        },
        6084: function(e, n, t) {
            t.r(n);
            t(28706), t(10287);
            var r = t(85558),
                o = t(3508),
                a = t(58385),
                i = t(61804),
                c = t(74848);

            function u(e, n) {
                return u = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, n) {
                    return e.__proto__ = n, e
                }, u(e, n)
            }
            var l = function(e) {
                function n() {
                    for (var n, t = arguments.length, r = new Array(t), o = 0; o < t; o++) r[o] = arguments[o];
                    return (n = e.call.apply(e, [this].concat(r)) || this).transition = !1, n.notificationScreenAccess = 3, n.screenName = 270, n.hasTabBar = !0, n
                }
                var t, r;
                return r = e, (t = n).prototype = Object.create(r.prototype), t.prototype.constructor = t, u(t, r), n.prototype.render = function() {
                    var e = this.props.parameters,
                        n = e.errorDetails,
                        t = e.onRefresh,
                        r = e.backHistoryEntry;
                    return this.addPageWrapper((0, c.jsx)(i.A, {
                        goToThePreviousScreen: function() {
                            return function(e) {
                                a.A.goToHistoryEntry(e, (function(e) {
                                    e || a.A.navigate(o.A.get("default.page"), !0)
                                }))
                            }(r)
                        },
                        errorDetails: n,
                        onRefresh: t
                    }))
                }, n
            }(r.A);
            n.default = l
        },
        12579: function(e, n, t) {
            t.d(n, {
                A: function() {
                    return f
                }
            });
            var r = t(99417),
                o = t(36521),
                a = t(36721),
                i = t(13614),
                c = t(52453),
                u = {
                    timeout: 0,
                    className: ""
                },
                l = {
                    timeout: 300,
                    className: "forward"
                },
                s = {
                    timeout: 300,
                    className: "backward"
                };

            function f(e, n, t) {
                if (!e || !n) return u;
                var f = t || {},
                    d = f.back,
                    v = f.browserNavigation;
                if (r.A._badoo_noTransition || !o.A.supportsTransitions || a.A.isOldAndroidWebkit() || (0, i.Yg)() || o.A.ios && v) return u;
                var A = d ? n : e;
                return (0, c.n)(A) && !1 === A.type.transition || !1 === A.transition ? u : d ? s : l
            }
        },
        15193: function(e, n, t) {
            t.d(n, {
                A: function() {
                    return o
                }
            });
            var r = t(96540);

            function o(e) {
                var n = (0, r.useRef)(),
                    t = (0, r.useRef)(e);
                return t.current !== e && (n.current = t.current, t.current = e), n.current
            }
        },
        16688: function(e, n, t) {
            t(62062), t(26099);
            var r = t(96540),
                o = t(46942),
                a = t.n(o),
                i = t(69020),
                c = t(99795),
                u = t(83852),
                l = t(94318),
                s = t(68072),
                f = t(28733),
                d = t(89769),
                v = t(12501),
                A = t(8483),
                g = t(40075),
                p = t(74848);
            n.A = function(e) {
                var n, t, o, b, m, h, y, j, O = [];
                e.primary ? O.push(e.primary) : null != (n = e.actions) && n.back ? O.push((0, p.jsx)("div", {
                    className: "js-navigation js-navigation-back",
                    "data-action": i.A.BACK,
                    "data-qa": "navbar-back",
                    children: (0, p.jsx)(l.A, {
                        name: "navigation-bar-back",
                        a11y: {
                            iconLabel: g.Ay.get(269)
                        }
                    })
                }, "navbar-button-back")) : null != (t = e.actions) && t.close && O.push((0, p.jsx)("div", {
                    className: "js-navigation js-navigation-close",
                    "data-action": i.A.CLOSE,
                    "data-qa": "navbar-close",
                    children: (0, p.jsx)(l.A, {
                        name: "navigation-bar-close",
                        a11y: {
                            iconLabel: g.Ay.get(270)
                        }
                    })
                }, "navbar-button-close"));
                var P = [];
                e.secondary ? P.push(e.secondary) : null != (o = e.actions) && o.location ? P.push((0, p.jsx)("div", {
                    className: "js-navigation",
                    "data-action": i.A.LOCATION,
                    "data-qa": "navbar-location",
                    children: (0, p.jsx)(l.A, {
                        name: "navigation-bar-location",
                        a11y: {
                            iconLabel: g.Ay.get(209)
                        }
                    })
                }, "navbar-button-location")) : null != (b = e.actions) && b.link && P.push((0, p.jsx)("div", {
                    className: "js-navigation",
                    "data-action": e.actions.link.action,
                    "data-qa": "navbar-link",
                    children: (0, p.jsx)(u.A, {
                        text: e.actions.link.text,
                        isDisabled: e.actions.link.disabled
                    })
                }, "navbar-button-" + e.actions.link.action));
                var N = (O.length || P.length) > 0,
                    E = e.isWide || (O.length || P.length) > 1,
                    x = a()(e.extraClass, {
                        "js-scroll-toggle": e.scrollToggle
                    }),
                    S = {};
                return e.scrollToggleClass && (S["data-toggle-class"] = e.scrollToggleClass), e.scrollToggle && (S["data-scroll-top"] = e.scrollToggle), (0, p.jsxs)(r.Fragment, {
                    children: [(0, p.jsxs)(c.A, {
                        position: "fixed",
                        shadow: e.hasShadow,
                        extraClass: x,
                        extraAttrs: S,
                        children: [N ? (0, p.jsx)(f.A, {
                            isWide: E,
                            children: O.map((function(e, n) {
                                return (0, p.jsx)(r.Fragment, {
                                    children: e
                                }, "primary-navbar-button-" + n)
                            }))
                        }) : null, e.title ? (0, p.jsx)(v.A, {
                            text: (0, p.jsx)("span", {
                                dangerouslySetInnerHTML: {
                                    __html: e.title
                                }
                            })
                        }) : null, e.logo && !e.logoInverted ? (0, p.jsx)(s.A, {
                            a11y: {
                                label: (null == (m = e.a11y) ? void 0 : m.logoLabel) || g.Ay.get(621)
                            },
                            tag: null != (h = e.a11y) && h.logoLabel ? "h1" : void 0,
                            children: (0, p.jsx)(A.A, {
                                name: "logo-boxed"
                            })
                        }) : null, e.logo && e.logoInverted ? (0, p.jsx)(s.A, {
                            a11y: {
                                label: (null == (y = e.a11y) ? void 0 : y.logoLabel) || g.Ay.get(621)
                            },
                            tag: null != (j = e.a11y) && j.logoLabel ? "h1" : void 0,
                            children: (0, p.jsx)(A.A, {
                                name: "logo-boxed-inverted"
                            })
                        }) : null, e.profile, N ? (0, p.jsx)(d.A, {
                            isWide: E,
                            children: P.map((function(e, n) {
                                return (0, p.jsx)(r.Fragment, {
                                    children: e
                                }, "primary-navbar-button-" + n)
                            }))
                        }) : null]
                    }), e.noFake ? null : (0, p.jsx)(c.A, {})]
                })
            }
        },
        19898: function(e, n, t) {
            t.d(n, {
                HP: function() {
                    return a
                },
                Qr: function() {
                    return i
                },
                in: function() {
                    return c
                },
                r7: function() {
                    return u
                }
            });
            t(60739);
            var r = t(44851),
                o = t(23735);

            function a(e) {
                var n, t = null == (n = u(e)) ? void 0 : n.type;
                return t && r.A.getType(t) === r.A.TYPE.FATAL
            }

            function i(e) {
                var n, t = null == (n = u(e)) ? void 0 : n.type;
                return t && r.A.getType(t) === r.A.TYPE.NON_FATAL
            }

            function c(e) {
                return e instanceof o.Qc
            }

            function u(e) {
                if ("badoo.bma.ServerErrorMessage" === (null == e ? void 0 : e.$gpb)) return e.toJSON ? e.toJSON() : e
            }
        },
        24446: function(e, n, t) {
            var r = t(66345),
                o = t(56870),
                a = t(52453),
                i = t(74848);
            n.A = function(e) {
                var n = e.activationPlace,
                    t = e.controller,
                    c = e.navigation,
                    u = e.onAttached,
                    l = e.transitionStatus,
                    s = e.pageNodeRef,
                    f = e.onScreenNameChange,
                    d = e.scrollPosition,
                    v = e.saveScrollPosition;
                return t ? (0, a.n)(t) ? (0, i.jsx)(o.A, {
                    activationPlace: n,
                    controller: t,
                    parameters: c.parameters,
                    back: c.back,
                    onAttached: u,
                    transitionStatus: l,
                    pageNodeRef: s,
                    onScreenNameChange: f,
                    scrollPosition: d,
                    saveScrollPosition: v
                }) : (0, i.jsx)(r.A, {
                    activationPlace: n,
                    controller: t,
                    parameters: c.parameters,
                    back: c.back,
                    onAttached: u,
                    transitionStatus: l,
                    pageNodeRef: s,
                    scrollPosition: d,
                    saveScrollPosition: v
                }) : null
            }
        },
        28431: function(e, n, t) {
            var r, o, a = t(85208),
                i = t(58385),
                c = t(3508),
                u = t(6084),
                l = t(19898),
                s = t(58544),
                f = t(64949),
                d = t(37905),
                v = t(18084),
                A = t(74389),
                g = v.A.getLogger("errorHandler"),
                p = u.default,
                b = (0, a.A)({}, s.zb, {
                    handleError: function(e, n) {
                        return t = e.error, !!((0, l.HP)(t) || (0, l.Qr)(t) || (0, l.in)(t) || (0, f.M)(t)) && (function(e) {
                            var n = d.A.controller;
                            n && n !== p && (r = n);
                            r || g.error("No previous page found (screenName: " + e.screenName + ")", e.error);
                            i.A.navigate(A.x.ERROR, {
                                errorDetails: e,
                                onRefresh: h,
                                backHistoryEntry: r ? r.routeName : c.A.get("default.page")
                            })
                        }(e), n && (o = n), !0);
                        var t
                    },
                    hideErrorScreen: m
                });

            function m() {
                var e;
                null != (e = r) && e.routeName ? i.A.navigate(r.routeName, !0, r.getParameters()) : i.A.navigate(c.A.get("default.page"), !0)
            }

            function h() {
                m(), o && o()
            }
            n.A = b
        },
        45897: function(e, n, t) {
            t.d(n, {
                pg: function() {
                    return o
                }
            });
            var r = (0, t(96540).createContext)({
                    router: null
                }),
                o = (r.Consumer, r.Provider);
            n.Ay = r
        },
        46763: function(e, n, t) {
            t(52675), t(45700), t(2008), t(51629), t(89572), t(2892), t(67945), t(84185), t(83851), t(81278), t(79432), t(26099), t(98992), t(54520), t(3949), t(23500);
            var r = t(40075),
                o = t(16688),
                a = t(47901),
                i = t(87184),
                c = t(11734),
                u = t(15376),
                l = t(4571),
                s = t(46770),
                f = t(40578),
                d = t(27895),
                v = t(20017),
                A = t(8483),
                g = t(93827),
                p = t(74848);

            function b(e, n) {
                var t = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    n && (r = r.filter((function(n) {
                        return Object.getOwnPropertyDescriptor(e, n).enumerable
                    }))), t.push.apply(t, r)
                }
                return t
            }

            function m(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var t = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? b(Object(t), !0).forEach((function(n) {
                        h(e, n, t[n])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : b(Object(t)).forEach((function(n) {
                        Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n))
                    }))
                }
                return e
            }

            function h(e, n, t) {
                return (n = function(e) {
                    var n = function(e, n) {
                        if ("object" != typeof e || !e) return e;
                        var t = e[Symbol.toPrimitive];
                        if (void 0 !== t) {
                            var r = t.call(e, n || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === n ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof n ? n : n + ""
                }(n)) in e ? Object.defineProperty(e, n, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[n] = t, e
            }
            n.A = function(e) {
                var n = e.data,
                    t = e.onRefresh,
                    b = e.timerText,
                    h = e.navBarProps;
                return (0, p.jsxs)(a.A, {
                    children: [(0, p.jsx)(u.A, {
                        children: h ? (0, p.jsx)(o.A, m({}, h)) : null
                    }), (0, p.jsx)(i.A, {
                        hpadded: !0,
                        vpadded: !0,
                        align: "center",
                        children: (0, p.jsxs)(l.A, {
                            children: [(0, p.jsx)(d.A, {
                                size: "icon",
                                children: (0, p.jsx)(A.A, {
                                    name: "badge-alert-primary"
                                })
                            }), (0, p.jsx)(f.A, {
                                text: null != n && n.isOffline ? r.Ay.get(646) : r.Ay.get(509),
                                tag: "h1"
                            }), (0, p.jsx)(s.A, {
                                children: (0, p.jsx)(v.A, {
                                    text: r.Ay.get(1084),
                                    onClick: t
                                })
                            })]
                        })
                    }), (0, p.jsx)(c.A, {
                        hpadded: !0,
                        vpadded: !0,
                        children: (0, p.jsx)(g.Sz, {
                            align: "center",
                            color: "gray-80",
                            children: (0, p.jsx)("div", {
                                className: "js-error-refresh-timer",
                                children: b
                            })
                        })
                    })]
                })
            }
        },
        52453: function(e, n, t) {
            function r(e) {
                return a(null == e ? void 0 : e.constructor)
            }

            function o(e) {
                return a(null == e ? void 0 : e.type)
            }

            function a(e) {
                var n;
                return Boolean(e && (null == e || null == (n = e.prototype) ? void 0 : n.isReactComponent))
            }
            t.d(n, {
                CS: function() {
                    return a
                },
                n: function() {
                    return o
                },
                n9: function() {
                    return r
                }
            })
        },
        56870: function(e, n, t) {
            var r = t(96540),
                o = t(13927),
                a = t(48164),
                i = t(74848),
                c = (0, r.memo)((function(e) {
                    var n = e.activationPlace,
                        t = e.controller,
                        c = e.parameters,
                        u = e.back,
                        l = e.onAttached,
                        s = e.transitionStatus,
                        f = e.pageNodeRef,
                        d = e.onScreenNameChange,
                        v = e.scrollPosition,
                        A = e.saveScrollPosition,
                        g = (0, r.useRef)(null);
                    return (0, r.useLayoutEffect)((function() {
                        g.current && l && l(g.current)
                    }), [l]), (0, r.useEffect)((function() {
                        var e;
                        s === a.A.ENTERED && (null != (e = g.current) && e.shouldShowTabBar() ? o.A.show() : o.A.hide())
                    }), [s]), (0, i.jsx)("div", {
                        className: "page-container",
                        ref: f,
                        id: "page-container",
                        children: (0, r.cloneElement)(t, {
                            ref: g,
                            parameters: c || {},
                            activationPlace: n,
                            navigatedBack: u,
                            transitionStatus: s,
                            onScreenNameChange: d,
                            scrollPosition: v,
                            saveScrollPosition: A
                        })
                    })
                }));
            n.A = c
        },
        61804: function(e, n, t) {
            t.d(n, {
                X: function() {
                    return r
                }
            });
            var r, o = t(96540),
                a = t(23715),
                i = t(89730),
                c = t(64949),
                u = t(46763),
                l = t(19898),
                s = t(20175),
                f = t(79860),
                d = t(74848);
            ! function(e) {
                e.STOP = "STOP", e.BACK_ONLINE = "BACK_ONLINE"
            }(r || (r = {}));
            var v = function(e, n) {
                var t = Date.now() - e;
                return Math.max(0, n - Math.floor(t / 1e3))
            };
            n.A = function(e) {
                var n = e.goToThePreviousScreen,
                    t = e.errorDetails,
                    A = e.onRefresh,
                    g = (0, o.useState)(null),
                    p = g[0],
                    b = g[1],
                    m = (0, o.useState)(void 0),
                    h = m[0],
                    y = m[1],
                    j = (0, o.useRef)(null),
                    O = (0, o.useRef)(null),
                    P = (0, o.useRef)(null),
                    N = (0, o.useRef)(void 0),
                    E = function() {
                        P.current && (clearInterval(P.current), b(null), j.current = null, O.current = null, P.current = null)
                    },
                    x = function(e) {
                        var n = (0, l.r7)(e);
                        O.current = (null == n ? void 0 : n.error_eta) || 480, j.current = Date.now();
                        var t = v(j.current, O.current);
                        b(t), P.current = setInterval((function() {
                            return function() {
                                if (j.current && O.current) {
                                    var e = v(j.current, O.current);
                                    if (e <= 0) return E(), void A();
                                    b(e)
                                } else E()
                            }()
                        }), 500)
                    },
                    S = (0, o.useCallback)((function() {
                        var e = !1;
                        N.current && (e = N.current(r.BACK_ONLINE), N.current = void 0), e || n()
                    }), [n]);
                return (0, o.useEffect)((function() {
                    return a.A.on(a.A.EVENTS.ONLINE, S),
                        function() {
                            a.A.off(a.A.EVENTS.ONLINE, S)
                        }
                }), [S]), (0, o.useEffect)((function() {
                    var e = t.error;
                    return (0, i.A)(t), (0, l.HP)(e) ? x(e) : y(t.navigationBar),
                        function(e, n) {
                            (0, l.HP)(e) || (0, c.M)(e) ? (0, f.sx)(49, {
                                screen_name: 270
                            }) : n && (0, f.sx)(258, {
                                element: 72,
                                screen_name: n
                            })
                        }(e, t.screenName), N.current = null == t ? void 0 : t.onHide,
                        function() {
                            E(), N.current && N.current(r.STOP)
                        }
                }), []), (0, d.jsx)(u.A, {
                    data: {
                        isOffline: !a.A.isOnline()
                    },
                    onRefresh: function() {
                        (0, f.sx)(332, {
                            element: 64,
                            parent_element: 72
                        }), A()
                    },
                    timerText: p ? (0, s.At)(p, !0) : void 0,
                    navBarProps: h
                })
            }
        },
        61938: function(e, n, t) {
            t.d(n, {
                A: function() {
                    return u
                }
            });
            t(52675), t(45700), t(2008), t(51629), t(89572), t(2892), t(67945), t(84185), t(83851), t(81278), t(79432), t(26099), t(98992), t(54520), t(3949), t(23500);
            var r = t(96540),
                o = t(99417);

            function a(e, n) {
                var t = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    n && (r = r.filter((function(n) {
                        return Object.getOwnPropertyDescriptor(e, n).enumerable
                    }))), t.push.apply(t, r)
                }
                return t
            }

            function i(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var t = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? a(Object(t), !0).forEach((function(n) {
                        c(e, n, t[n])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : a(Object(t)).forEach((function(n) {
                        Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n))
                    }))
                }
                return e
            }

            function c(e, n, t) {
                return (n = function(e) {
                    var n = function(e, n) {
                        if ("object" != typeof e || !e) return e;
                        var t = e[Symbol.toPrimitive];
                        if (void 0 !== t) {
                            var r = t.call(e, n || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === n ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof n ? n : n + ""
                }(n)) in e ? Object.defineProperty(e, n, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[n] = t, e
            }

            function u(e) {
                var n = (0, r.useState)({}),
                    t = n[0],
                    a = n[1];
                return [(e ? t[e.routeName] : 0) || 0, function(n) {
                    e && a((function(t) {
                        var r;
                        return i(i({}, t), {}, ((r = {})[e.routeName] = n || o.A.scrollY, r))
                    }))
                }]
            }
        },
        66345: function(e, n, t) {
            t(69085);
            var r = t(96540),
                o = t(13927),
                a = t(48164),
                i = t(74848),
                c = (0, r.memo)((function(e) {
                    var n = e.activationPlace,
                        t = e.controller,
                        c = e.parameters,
                        u = e.back,
                        l = e.onAttached,
                        s = e.transitionStatus,
                        f = e.pageNodeRef,
                        d = e.scrollPosition,
                        v = e.saveScrollPosition,
                        A = (0, r.useMemo)((function() {
                            return Object.assign({
                                transitionStatus: s,
                                scrollPosition: d,
                                saveScrollPosition: v
                            }, c)
                        }), [s, d, v, c]);
                    return (0, r.useLayoutEffect)((function() {
                        var e;
                        null == f || null == (e = f.current) || null == e.appendChild || e.appendChild(t.element.get(0))
                    }), [t.element, f]), (0, r.useEffect)((function() {
                        l && s === a.A.ENTERING && l(t), s !== a.A.ENTERED && s !== a.A.ENTERING || (t.isStarted() ? (t.setWasBack(Boolean(u)), t.updateParameters(A)) : t.open({
                            parameters: A,
                            activationPlace: n,
                            navigatedBack: Boolean(u)
                        })), s === a.A.ENTERED && (t.ready(), t.shouldShowTabBar() ? o.A.show() : o.A.hide()), s === a.A.EXITED && t.close()
                    }), [n, u, t, A, l, c, s]), (0, i.jsx)("div", {
                        className: "page-container",
                        ref: f,
                        id: "page-container"
                    })
                }));
            n.A = c
        },
        66644: function(e, n, t) {
            t.d(n, {
                Pi: function() {
                    return i
                },
                cq: function() {
                    return a
                }
            });
            var r = t(96540),
                o = t(45897);

            function a() {
                return (0, r.useContext)(o.Ay).navigation
            }

            function i() {
                return (0, r.useContext)(o.Ay).pageController
            }
        },
        75349: function(e, n, t) {
            t.d(n, {
                A: function() {
                    return a
                }
            });
            var r = t(99417),
                o = t(65297);

            function a() {
                if (!r.A._badoo_keep_splash_screen) {
                    var e = r.A.document.querySelector("#splash-screen");
                    e && (e.remove(), o.A.trigger("splash-screen-removed"))
                }
            }
        }
    }
]);
//# sourceMappingURL=2362.1e187905d7763eead27f.js.map
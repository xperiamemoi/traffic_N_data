"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [2847], {
        5587: function(e, a, t) {
            var s = t(74848),
                i = t(96540);
            a.A = ({
                children: e,
                tag: a,
                dataQA: t
            }) => {
                const n = i.Children.toArray(e).filter(Boolean),
                    o = a || n.length >= 4 ? "ul" : "div",
                    c = "div" !== o ? "li" : "div",
                    l = {
                        "data-qa": "action-sheet-list",
                        ...t
                    };
                return (0, s.jsx)(o, {
                    className: "csms-actionsheet__list",
                    ...l,
                    role: "ul" === o ? "list" : void 0,
                    children: n.map(((e, a) => (0, s.jsx)(c, {
                        className: "csms-actionsheet__list-item",
                        "data-qa": "action-sheet-list-item",
                        children: e
                    }, a)))
                })
            }
        },
        8562: function(e, a, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i),
                o = t(93827);
            a.A = ({
                media: e,
                mediaSize: a,
                title: t,
                text: i
            }) => {
                const c = n()({
                    "csms-actionsheet__header-media": !0,
                    [`csms-actionsheet__header-media--size-${a}`]: a
                });
                return (0, s.jsxs)("div", {
                    className: "csms-actionsheet__header",
                    "data-qa": "action-sheet-header",
                    children: [e ? (0, s.jsx)("div", {
                        className: c,
                        children: e
                    }) : null, t ? (0, s.jsx)("div", {
                        className: "csms-actionsheet__header-title",
                        "data-qa": "action-sheet-header-title",
                        children: (0, s.jsx)(o.Sz, {
                            color: "black",
                            breakWords: !0,
                            tag: "h2",
                            children: t
                        })
                    }) : null, i ? (0, s.jsx)("div", {
                        className: "csms-actionsheet__header-text",
                        "data-qa": "action-sheet-header-text",
                        children: (0, s.jsx)(o.P1, {
                            color: "gray-80",
                            breakWords: !0,
                            dangerous: "string" == typeof i,
                            children: i
                        })
                    }) : null]
                })
            }
        },
        15700: function(e, a, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i),
                o = t(8483),
                c = t(93827);
            a.A = ({
                icon: e,
                text: a,
                extra: t,
                variant: i = "hint",
                id: l,
                dataQA: r
            }) => {
                const d = n()({
                    "csms-form-control-note": !0,
                    [`csms-form-control-note--variant-${i}`]: i
                });
                let m = e;
                return m || ("success" === i && (m = "generic-verification-hollow"), "error" === i && (m = "generic-error")), (0, s.jsxs)("div", {
                    className: d,
                    role: "error" === i ? "alert" : void 0,
                    children: [m && a ? (0, s.jsx)("div", {
                        className: "csms-form-control-note__icon",
                        children: (0, s.jsx)(o.A, {
                            name: m
                        })
                    }) : null, a ? (0, s.jsx)("div", {
                        className: "csms-form-control-note__text",
                        children: (0, s.jsx)(c.P3, {
                            id: l,
                            dataQA: r,
                            children: a
                        })
                    }) : null, t ? (0, s.jsx)("div", {
                        className: "csms-form-control-note__extra",
                        children: t
                    }) : null]
                })
            }
        },
        17380: function(e, a, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i),
                o = t(8483);
            a.A = ({
                type: e,
                color: a = "default",
                id: t,
                name: i,
                value: c,
                isChecked: l,
                isInvalid: r,
                isDisabled: d,
                onChange: m,
                onClick: u,
                dataQA: h,
                a11y: x
            }) => {
                let v = l ? "checked" : "unchecked";
                r && !l && (v = "error");
                const b = n()({
                        "csms-choice": !0,
                        "csms-choice--is-checked": l,
                        ["csms-choice--" + ("checkbox" === e ? "checkbox" : "radiobutton")]: !0,
                        "csms-choice--disabled": d,
                        [`csms-choice--${a}-${v}-${"checkbox"===e?"checkbox":"radiobutton"}`]: !0
                    }),
                    p = "checkbox" === e ? "checkbox" : "radio",
                    f = {
                        "data-qa": `csms-${p}`,
                        ...h
                    };
                return (0, s.jsxs)("span", {
                    className: b,
                    ...f,
                    children: [(0, s.jsx)("input", {
                        className: "csms-choice__input",
                        id: t,
                        name: i,
                        value: c,
                        type: p,
                        checked: l,
                        onChange: m,
                        disabled: d,
                        onClick: u,
                        "aria-label": x ? .label,
                        "aria-invalid": r && !l
                    }), (0, s.jsx)("span", {
                        className: "csms-choice__icon",
                        children: (0, s.jsx)(o.A, {
                            name: "checkbox" === e ? "elements-checkbox-selected-indicator" : "elements-radiobutton-selected-indicator"
                        })
                    }), (0, s.jsx)("span", {
                        className: "csms-choice__border"
                    })]
                })
            }
        },
        23914: function(e, a, t) {
            t.d(a, {
                A: function() {
                    return d
                }
            });
            var s = t(74848),
                i = t(46942),
                n = t.n(i),
                o = t(56301);
            var c = ({
                children: e,
                type: a = "bottom-drawer",
                isPadded: t,
                background: i = "white",
                animationStatus: c,
                style: l,
                hostRef: r,
                navigation: d,
                a11y: m
            }) => {
                const u = n()({
                        "csms-modal__content": !0,
                        [`csms-modal__content--${a}`]: !0,
                        [`csms-modal__content--background-${i}`]: !0,
                        [`csms-modal__content--${c}`]: c
                    }),
                    h = n()({
                        "csms-modal__scrollable": !0,
                        "csms-modal__scrollable--padded": t
                    });
                return (0, s.jsxs)("div", {
                    className: u,
                    style: l,
                    ref: r,
                    "aria-hidden": m ? .ariaHidden,
                    tabIndex: m ? .ariaHidden ? -1 : 0,
                    children: [d && "bottom-drawer" === a ? (0, s.jsx)(o.A, { ...d
                    }) : null, (0, s.jsx)("div", {
                        className: h,
                        children: e
                    })]
                })
            };
            var l = ({
                animationStatus: e,
                onClick: a,
                hostRef: t,
                backdropColor: i = "dark"
            }) => {
                const o = n()({
                        "csms-modal__shadow": !0,
                        [`csms-modal__shadow--${e}`]: e,
                        [`csms-modal__shadow--${i}`]: i
                    }),
                    c = a ? "button" : "div";
                return (0, s.jsx)(c, {
                    className: o,
                    onClick: a,
                    ref: t,
                    "aria-hidden": !0,
                    tabIndex: -1,
                    type: "button" === c ? "button" : void 0
                })
            };
            var r = ({
                children: e,
                style: a,
                hostRef: t,
                a11y: i
            }) => (0, s.jsx)("div", {
                className: "csms-modal",
                style: a,
                ref: t,
                tabIndex: i ? .ariaHidden ? -1 : 0,
                role: "dialog",
                "aria-modal": !0,
                "aria-label": i ? .label,
                "aria-hidden": i ? .ariaHidden,
                children: e
            });
            var d = ({
                children: e,
                type: a = "bottom-drawer",
                isPadded: t,
                background: i = "white",
                animationStatus: n,
                onDismiss: o,
                wrapperRef: d,
                shadowRef: m,
                backdropColor: u,
                contentRef: h,
                navigation: x,
                a11y: v
            }) => {
                const b = "visible" !== n;
                return (0, s.jsxs)(r, {
                    hostRef: d,
                    a11y: {
                        label: v ? .wrapperLabel,
                        ariaHidden: b
                    },
                    children: ["fullscreen" !== a ? (0, s.jsx)(l, {
                        onClick: o || x ? .onClickClose,
                        animationStatus: n,
                        hostRef: m,
                        backdropColor: u
                    }) : null, (0, s.jsx)(c, {
                        type: a,
                        isPadded: t,
                        background: i,
                        animationStatus: n,
                        hostRef: h,
                        a11y: {
                            ariaHidden: b
                        },
                        navigation: x,
                        children: e
                    })]
                })
            }
        },
        31189: function(e, a, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i);
            a.A = ({
                children: e,
                onSubmit: a,
                noValidate: t = !0,
                isFixed: i,
                extraClass: o
            }) => {
                const c = n()(o, {
                    "csms-form": !0,
                    "csms-form--fixed": i
                });
                return a ? (0, s.jsx)("form", {
                    method: "post",
                    className: c,
                    onSubmit: a,
                    noValidate: t,
                    children: e
                }) : (0, s.jsx)("div", {
                    className: c,
                    children: e
                })
            }
        },
        33702: function(e, a, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i),
                o = t(84362),
                c = t(8483),
                l = t(33815);
            a.A = ({
                id: e,
                type: a = "text",
                name: t,
                value: i,
                docked: r,
                pattern: d,
                maxLength: m,
                min: u,
                max: h,
                autoFocus: x,
                isFocused: v,
                status: b,
                onFocus: p,
                onChange: f,
                onBlur: _,
                onClick: j,
                onKeyUp: k,
                inputRef: g,
                actionIcon: A,
                onActionClick: y,
                isLoading: C,
                autoComplete: N,
                autoCapitalize: w,
                autoCorrect: q,
                inputMode: $,
                dir: Q = "auto",
                spellCheck: R,
                dataQA: S,
                dataQAInput: z,
                a11y: F = {}
            }) => {
                let I = "auto";
                "tel" === a && (I = "ltr");
                const B = n()({
                        "csms-text-field": !0,
                        [`csms-text-field--${a}`]: !0,
                        "csms-text-field--is-focused": v,
                        [`csms-text-field--status-${b}`]: b,
                        [`csms-text-field--docked-${r}`]: r,
                        [`csms-text-field--dir-${Q||I}`]: !0,
                        "csms-text-field--has-action": A || C
                    }),
                    L = n()({
                        "csms-text-field__input": !0,
                        [`csms-text-field__input--${a}`]: a
                    }),
                    D = {
                        "data-qa": "text-field",
                        ...S
                    },
                    H = y ? "button" : "div";
                return (0, s.jsxs)("div", {
                    className: B,
                    ...D,
                    children: [(0, s.jsx)("input", {
                        className: L,
                        type: a,
                        autoComplete: N,
                        id: e,
                        name: t,
                        value: f ? i : void 0,
                        defaultValue: f ? void 0 : i,
                        maxLength: void 0 !== m && m > 0 ? m : void 0,
                        onFocus: p,
                        onChange: f,
                        onKeyUp: k,
                        onBlur: _,
                        onClick: j,
                        ref: g,
                        pattern: d,
                        dir: Q || I,
                        "data-qa": z || "text-field-input",
                        autoCapitalize: w,
                        autoCorrect: q,
                        inputMode: $,
                        spellCheck: R,
                        autoFocus: x,
                        min: u,
                        max: h,
                        role: F.role,
                        "aria-label": F.inputLabel,
                        "aria-controls": F.ariaControls,
                        "aria-autocomplete": F.ariaAutocomplete,
                        "aria-expanded": F.ariaExpanded,
                        "aria-haspopup": F.ariaHaspopup,
                        "aria-describedby": F.ariaDescribedby,
                        "aria-required": F.ariaRequired,
                        "aria-invalid": "error" === b || void 0,
                        "aria-activedescendant": F.ariaActivedescendant
                    }), A || C ? (0, s.jsx)(H, {
                        className: "csms-text-field__action",
                        onClick: C ? void 0 : y,
                        "data-qa": "text-field-action",
                        type: y && !C ? "button" : void 0,
                        "aria-pressed": y && !C ? F.actionAriaPressed : void 0,
                        "aria-describedby": `${e}-action-description`,
                        "aria-controls": e,
                        children: C ? (0, s.jsx)(l.A, {}) : (0, s.jsx)(c.A, {
                            name: A,
                            a11y: y ? {
                                label: F.actionIconLabel
                            } : void 0
                        })
                    }) : null, (0, s.jsx)(o.A, {
                        id: `${e}-action-description`,
                        children: F.actionAriaDescription
                    }), (0, s.jsx)("div", {
                        className: "csms-text-field__focus-ring"
                    })]
                })
            }
        },
        33736: function(e, a, t) {
            var s = t(74848),
                i = t(95299);
            a.A = ({
                text: e,
                extra: a,
                icon: t,
                onClick: n,
                type: o = "generic",
                tag: c,
                innerRef: l,
                dataQA: r,
                a11y: d
            }) => {
                const m = {
                    "data-qa": "action-sheet-item",
                    "data-qa-type": o,
                    ...r
                };
                return (0, s.jsx)(i.A, {
                    onClick: n,
                    media: t ? {
                        content: t,
                        size: "small"
                    } : void 0,
                    title: {
                        text: e,
                        color: "destructive" === o ? "danger" : "base"
                    },
                    action: {
                        action: a ? "custom" : "chevron",
                        content: a || void 0
                    },
                    tag: c,
                    innerRef: l,
                    dataQA: m,
                    a11y: d
                })
            }
        },
        36167: function(e, a, t) {
            t.d(a, {
                A: function() {
                    return d
                }
            });
            var s = t(74848),
                i = t(23914),
                n = t(47908),
                o = t(8562),
                c = t(5587),
                l = t(56301);
            var r = e => e.onClickBack || e.onClickClose ? (0, s.jsx)("div", {
                className: "csms-actionsheet__navigation",
                "data-qa": "action-sheet-navigation",
                children: (0, s.jsx)(l.A, { ...e
                })
            }) : null;
            var d = e => {
                const {
                    children: a,
                    navigation: t,
                    header: l,
                    listTag: d,
                    footer: m,
                    isFooterDocked: u,
                    onSubmit: h,
                    dataQA: x,
                    ...v
                } = e, b = {
                    "data-qa": "action-sheet",
                    ...x
                }, p = h ? "form" : "div", f = a && "object" == typeof a && a.type && "ActionSheetContent" === a.type.name;
                return (0, s.jsx)(i.A, { ...v,
                    children: (0, s.jsxs)(p, {
                        className: "csms-actionsheet",
                        ...b,
                        children: [t ? (0, s.jsx)(r, {
                            onClickBack: t.onClickBack,
                            onClickClose: t.onClickClose,
                            a11y: t.a11y
                        }) : null, l ? (0, s.jsx)(o.A, {
                            media: l.media,
                            mediaSize: l.mediaSize,
                            title: l.title,
                            text: l.text
                        }) : null, f ? a : (0, s.jsx)(c.A, {
                            tag: d,
                            children: a
                        }), m ? (0, s.jsx)(n.A, {
                            isDocked: u,
                            children: m
                        }) : null]
                    })
                })
            }
        },
        47908: function(e, a, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i);
            a.A = ({
                children: e,
                isDocked: a
            }) => (0, s.jsx)("div", {
                className: n()("csms-actionsheet__footer", {
                    "csms-actionsheet__footer--docked": a
                }),
                "data-qa": "action-sheet-footer",
                children: e
            })
        },
        56301: function(e, a, t) {
            var s = t(74848),
                i = t(8483);
            a.A = ({
                onClickBack: e,
                onClickClose: a,
                a11y: t
            }) => e || a ? (0, s.jsxs)("div", {
                className: "csms-modal__navigation",
                "data-qa": "modal-navigation",
                children: [e ? (0, s.jsx)("button", {
                    className: "csms-modal__navigation-item csms-modal__navigation-item--start",
                    onClick: e,
                    "data-qa": "modal-back",
                    type: "button",
                    children: (0, s.jsx)(i.A, {
                        name: "generic-chevron-left",
                        a11y: {
                            label: t ? .backLabel
                        }
                    })
                }) : null, a ? (0, s.jsx)("button", {
                    className: "csms-modal__navigation-item csms-modal__navigation-item--end",
                    onClick: a,
                    "data-qa": "modal-close",
                    type: "button",
                    children: (0, s.jsx)(i.A, {
                        name: "generic-close",
                        a11y: {
                            label: t ? .closeLabel
                        }
                    })
                }) : null]
            }) : null
        },
        56535: function(e, a, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i);
            a.A = ({
                id: e,
                isChecked: a,
                isDisabled: t,
                onChange: i,
                isDecorative: o,
                tag: c = "input",
                onClick: l
            }) => {
                const r = n()({
                        "csms-toggle": !0,
                        "csms-toggle--disabled": t,
                        "csms-toggle--checked": a
                    }),
                    d = "button" === c ? "button" : "span";
                return (0, s.jsxs)(d, {
                    className: r,
                    "data-qa": "toggle",
                    "data-qa-state": a ? "on" : "off",
                    "aria-checked": "button" !== c || o ? void 0 : Boolean(a),
                    type: "button" !== c || o ? void 0 : "button",
                    role: "button" !== c || o ? void 0 : "switch",
                    onClick: l,
                    children: [o || "input" !== c ? null : (0, s.jsx)("input", {
                        className: "csms-toggle__input",
                        id: e,
                        type: "checkbox",
                        checked: a,
                        onChange: i,
                        disabled: t
                    }), (0, s.jsx)("span", {
                        className: "csms-toggle__surrogate"
                    })]
                })
            }
        },
        66130: function(e, a, t) {
            var s = t(74848);
            a.A = ({
                children: e
            }) => (0, s.jsx)("div", {
                className: "csms-form-actions",
                "data-qa": "form-actions",
                children: e
            })
        },
        71859: function(e, a, t) {
            var s = t(74848);
            a.A = ({
                children: e
            }) => (0, s.jsx)("div", {
                className: "csms-app-overlay",
                children: (0, s.jsx)("div", {
                    className: "csms-app-overlay__inner",
                    children: e
                })
            })
        },
        79752: function(e, a, t) {
            t.d(a, {
                A: function() {
                    return c
                }
            });
            var s = t(74848),
                i = t(93827);
            var n = ({
                    text: e,
                    fieldId: a,
                    tag: t
                }) => {
                    let n = t || "label";
                    "label" !== n || a || (n = "span");
                    const o = {
                        label: {
                            "data-qa": "form-control-label",
                            htmlFor: a,
                            children: e
                        },
                        legend: {
                            "data-qa": "form-control-legend",
                            children: e
                        },
                        span: {
                            "data-qa": "form-control-label",
                            children: e
                        }
                    };
                    return (0, s.jsx)("div", {
                        className: "csms-form-control-label",
                        "data-qa": "csms-form-control-label",
                        children: (0, s.jsx)(i.P2, {
                            weight: "bolder",
                            children: (0, s.jsx)(n, { ...o[n]
                            })
                        })
                    })
                },
                o = t(15700);
            var c = ({
                label: e,
                children: a,
                hint: t,
                status: i,
                tag: c = "div",
                dataQA: l,
                fieldId: r
            }) => {
                const d = {
                        "data-qa": "form-control",
                        ...l
                    },
                    m = c;
                return (0, s.jsxs)(m, {
                    className: "csms-form-control",
                    ...d,
                    children: [e ? (0, s.jsx)(n, {
                        text: e,
                        fieldId: r,
                        tag: "fieldset" === c ? "legend" : "label"
                    }) : null, a, i ? (0, s.jsx)(o.A, {
                        text: i.text,
                        extra: i.extra,
                        variant: i.variant || "error",
                        id: i.id,
                        dataQA: {
                            "data-qa": `form-control-${i.variant||"error"}`
                        }
                    }) : null, t ? .text ? (0, s.jsx)(o.A, {
                        icon: t.icon,
                        text: t.text,
                        extra: t.extra,
                        id: t.id,
                        dataQA: {
                            "data-qa": "form-control-hint"
                        }
                    }) : null]
                })
            }
        },
        84395: function(e, a, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i),
                o = t(8483);
            a.A = ({
                id: e,
                name: a,
                options: t,
                value: i,
                allowEmptyState: c = !0,
                selectedLabel: l,
                dir: r = "auto",
                isFocused: d,
                docked: m,
                status: u,
                onFocus: h,
                onChange: x,
                onBlur: v,
                onKeyUp: b,
                selectRef: p,
                dataQA: f,
                dataQASelect: _,
                a11y: j = {}
            }) => {
                const k = n()({
                        "csms-select": !0,
                        "csms-select--is-focused": d,
                        [`csms-select--status-${u}`]: u,
                        "csms-select--has-label": l,
                        [`csms-select--docked-${m}`]: m,
                        [`csms-select--dir-${r}`]: r
                    }),
                    g = {
                        "data-qa": "csms-select",
                        ...f
                    };
                return (0, s.jsxs)("div", {
                    className: k,
                    ...g,
                    children: [(0, s.jsx)("span", {
                        className: "csms-select__icon",
                        children: (0, s.jsx)(o.A, {
                            name: "generic-chevron-down"
                        })
                    }), (0, s.jsxs)("select", {
                        className: "csms-select__field",
                        id: e,
                        name: a,
                        value: x ? i : void 0,
                        defaultValue: x ? void 0 : i,
                        onFocus: h,
                        onChange: x,
                        onKeyUp: b,
                        onBlur: v,
                        ref: p,
                        dir: r,
                        "data-qa": _ || "csms-select-dropdown",
                        "aria-describedby": j.ariaDescribedby,
                        "aria-required": j.ariaRequired,
                        "aria-invalid": "error" === u || void 0,
                        "aria-label": j.label,
                        children: [c ? (0, s.jsx)("option", {}) : void 0, t.map(((e, a) => (0, s.jsx)("option", {
                            value: e.value,
                            children: e.label
                        }, a)))]
                    }), l ? (0, s.jsx)("div", {
                        className: "csms-select__label",
                        dir: r,
                        "aria-hidden": !0,
                        children: l
                    }) : null, (0, s.jsx)("div", {
                        className: "csms-select__focus-ring"
                    })]
                })
            }
        },
        88163: function(e, a, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i),
                o = t(84395),
                c = t(33702);
            a.A = ({
                countryCode: e,
                number: a,
                dataQA: t
            }) => {
                const i = e.isFocused && !a.isFocused || "error" === e.status && "error" !== a.status,
                    l = n()({
                        "csms-phone-field__country-code": !0,
                        "csms-phone-field__country-code--lifted": i
                    }),
                    r = {
                        "data-qa": "phone-field",
                        ...t
                    };
                return (0, s.jsxs)("div", {
                    className: "csms-phone-field",
                    ...r,
                    children: [(0, s.jsx)("div", {
                        className: l,
                        children: (0, s.jsx)(o.A, { ...e,
                            dir: "ltr",
                            docked: "end"
                        })
                    }), (0, s.jsx)("div", {
                        className: "csms-phone-field__number",
                        children: (0, s.jsx)(c.A, { ...a,
                            type: "tel",
                            docked: "start",
                            autoCapitalize: "none",
                            autoCorrect: "off",
                            inputMode: "tel"
                        })
                    })]
                })
            }
        },
        89162: function(e, a, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i),
                o = t(93827);
            a.A = ({
                text: e,
                color: a = "gray-80",
                tag: t
            }) => {
                const i = "string" == typeof e,
                    c = n()({
                        "csms-form-text": !0,
                        [`csms-form-text--${a}`]: a
                    });
                return (0, s.jsx)("div", {
                    className: c,
                    "data-qa": "form-text",
                    children: (0, s.jsx)(o.P1, {
                        breakWords: !0,
                        dangerous: i,
                        tag: t,
                        children: e
                    })
                })
            }
        },
        95299: function(e, a, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i),
                o = t(84362),
                c = t(20017),
                l = t(17380),
                r = t(56535),
                d = t(8483),
                m = t(93827);
            a.A = ({
                media: e,
                title: a,
                description: t,
                label: i,
                action: u = {
                    action: "none"
                },
                variant: h = "default",
                onClick: x,
                isPressed: v,
                tag: b,
                innerRef: p,
                a11y: f,
                dataQA: _
            }) => {
                const j = n()({
                        "csms-action-row": !0,
                        "csms-action-row--compact": "compact" === h,
                        "csms-action-row--no-action": "none" === u ? .action,
                        "is-pressed": v
                    }),
                    k = n()({
                        "csms-action-row__content": !0,
                        "csms-action-row__content--no-label": !i
                    }),
                    g = n()({
                        "csms-action-row__title": !0,
                        [`csms-action-row__title--color-${a.color}`]: a.color,
                        [`csms-action-row__title--size-${a.size||"small"}`]: !0
                    }),
                    A = n()({
                        "csms-action-row__media": !0,
                        "csms-action-row__media--size-medium": "medium" === e ? .size
                    }),
                    y = Boolean(f ? .contentLabel),
                    C = x ? "button" : b || "span",
                    N = {
                        "data-qa": "action-row",
                        ..._
                    };
                return (0, s.jsxs)(C, {
                    className: j,
                    onClick: x,
                    type: "button" === C ? "button" : void 0,
                    ref: p,
                    "aria-describedby": x ? f ? .descriptionHintId : void 0,
                    "aria-selected": f ? .ariaSelected,
                    "aria-checked": f ? .ariaChecked,
                    "aria-pressed": f ? .ariaPressed,
                    role: f ? .role,
                    ...N,
                    children: [e ? (0, s.jsx)("span", {
                        className: A,
                        children: e.content
                    }) : null, (0, s.jsx)(o.A, {
                        children: f ? .contentLabel
                    }), (0, s.jsxs)("span", {
                        className: k,
                        "aria-hidden": y,
                        children: [(0, s.jsx)("span", {
                            className: g,
                            "data-qa": "action-row-title",
                            children: "medium" === a.size ? (0, s.jsx)(m.Qi, {
                                ellipsis: !0,
                                children: a.text
                            }) : (0, s.jsx)(m.Qi, {
                                ellipsis: a.ellipsis,
                                breakWords: !a.ellipsis,
                                children: a.text
                            })
                        }), t ? .text ? (0, s.jsx)("span", {
                            className: "csms-action-row__hint",
                            "data-qa": "action-row-hint",
                            "aria-hidden": Boolean(f ? .descriptionHintId),
                            id: f ? .descriptionHintId,
                            children: (0, s.jsx)(m.Qi, {
                                ellipsis: t.ellipsis,
                                children: t.text
                            })
                        }) : null]
                    }), i ? (0, s.jsx)("span", {
                        className: "csms-action-row__label",
                        "aria-hidden": y,
                        children: (0, s.jsx)("span", {
                            className: "csms-action-row__label-text",
                            "data-qa": "action-row-value-text",
                            children: (0, s.jsx)(m.Qi, {
                                ellipsis: !0,
                                children: i
                            })
                        })
                    }) : null, "none" !== u ? .action && "label" !== u ? .action ? (0, s.jsx)("span", {
                        className: "csms-action-row__extra-placeholder",
                        "data-qa": "action-row-extra",
                        children: (0, s.jsxs)("span", {
                            className: "csms-action-row__extra",
                            "data-qa": "action-row-extra",
                            children: ["custom" === u.action && u.content ? u.content : null, "chevron" === u.action && (0, s.jsx)(d.A, {
                                name: "generic-chevron-right",
                                supportsRtl: !0
                            }), "checkbox" === u.action && u.checkbox ? (0, s.jsx)(l.A, { ...u.checkbox
                            }) : null, "toggle" === u.action && u.toggle ? (0, s.jsx)(r.A, { ...u.toggle
                            }) : null, "button" === u.action && u.button ? (0, s.jsx)(c.A, { ...u.button,
                                size: "micro"
                            }) : null]
                        })
                    }) : null]
                })
            }
        }
    }
]);
//# sourceMappingURL=2847.6e98d1472beb72a58fa9.js.map
/*! For license information please see 8819.37f07638da84cd911fb3.js.LICENSE.txt */
"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [8819], {
        107: function(e, t, r) {
            r.d(t, {
                M: function() {
                    return i
                }
            });
            var n = r(72537),
                i = function() {
                    return n.A.isAllowed(n.A.getSync(415)) && n.A.isAllowed(n.A.getSync(418))
                }
        },
        254: function(e, t, r) {
            r.d(t, {
                XQ: function() {
                    return E
                },
                py: function() {
                    return b
                },
                Ay: function() {
                    return I
                },
                qD: function() {
                    return U
                }
            });
            r(74423), r(62062), r(72712), r(60739), r(79432), r(26099), r(58940), r(27495), r(38781), r(71761), r(11392), r(98992), r(81454), r(8872);
            var n = r(73090),
                i = r(40075),
                a = (r(2008), r(25276), r(54520), r(79601)),
                o = (r(90906), r(28706), r(48598), r(84864), r(57465), r(87745), [].concat("[\\u2700-\\u27bf]", "(?:\\ud83c[\\udde6-\\uddff]){2}", "[\\ud800-\\udbff][\\udc00-\\udfff]", "[\\u0023-\\u0039]\\ufe0f?\\u20e3", ["\\u3299", "\\u3297"], ["\\u303d", "\\u3030"], ["\\u24c2"], ["\\ud83c[\\udd70-\\udd71]", "\\ud83c[\\udd7e-\\udd7f]", "\\ud83c\\udd8e", "\\ud83c[\\udd91-\\udd9a]", "\\ud83c[\\udde6-\\uddff]"], ["[\\ud83c[\\ude01-\\ude02]", "\\ud83c\\ude1a", "\\ud83c\\ude2f", "[\\ud83c[\\ude32-\\ude3a]", "[\\ud83c[\\ude50-\\ude51]"], ["\\u203c", "\\u2049"], ["[\\u25aa-\\u25ab]", "\\u25b6", "\\u25c0", "[\\u25fb-\\u25fe]"], ["\\u00a9", "\\u00ae"], ["\\u2122", "\\u2139"], ["\\ud83c\\udc04"], "[\\u2600-\\u26FF]", ["\\u2b05", "\\u2b06", "\\u2b07", "\\u2b1b", "\\u2b1c", "\\u2b50", "\\u2b55"], ["\\u231a", "\\u231b", "\\u2328", "\\u23cf", "[\\u23e9-\\u23f3]", "[\\u23f8-\\u23fa]"], ["\\ud83c\\udccf"], ["\\u2934", "\\u2935"], ["[\\u2190-\\u21ff]"]).join("|")),
                s = new RegExp("(?:" + o + ")");
            var c = {
                EMOJI_SIZE: {
                    EXTRA_EXTRA_LARGE: "xxlg",
                    EXTRA_LARGE: "xlg",
                    LARGE: "lg",
                    MEDIUM: "md"
                },
                isEmoji: function(e) {
                    if (!e || e.indexOf("\n") > -1) return !1;
                    var t = u(e = e.replace(/\s/g, "")).length,
                        r = c.emojiCount(e);
                    return t === r && r <= 3
                },
                emojiCount: function(e) {
                    return e ? u(e).map((function(e) {
                        return t = e, s.test(t);
                        var t
                    })).filter(Boolean).length : 0
                },
                emojiSize: function(e) {
                    switch (c.emojiCount(e)) {
                        case 1:
                            return c.EMOJI_SIZE.EXTRA_EXTRA_LARGE;
                        case 2:
                            return c.EMOJI_SIZE.EXTRA_LARGE;
                        case 3:
                            return c.EMOJI_SIZE.LARGE;
                        default:
                            return c.EMOJI_SIZE.MEDIUM
                    }
                }
            };

            function u(e) {
                return (0, a.A)(e.replace(/\s/g, ""))
            }
            var l = c,
                d = r(47632),
                p = r(20175),
                f = r(7929),
                h = r(28030),
                g = r(35837),
                v = r(15566),
                m = [2, 4],
                y = /.{3}/g,
                P = 86400,
                A = 604800,
                E = {
                    DELIVERED: "DELIVERED",
                    FAILED: "FAILED",
                    INAPPROPRIATE: "INAPPROPRIATE",
                    READ: "READ",
                    SENDING: "SENDING",
                    UPLOADING: "UPLOADING"
                },
                _ = {
                    IN: "in",
                    OUT: "out"
                },
                b = "TEMP_ID:",
                T = 0;

            function S(e, t, r) {
                this.actions = void 0, this.chatDate = void 0, this.context = 10;
                var n = parseInt(Date.now() / 1e3 + 3600, 10);
                this.dateCreated = n, this.dateModified = n, this.direction = _.OUT, this.displayMessage = void 0, this.fromPersonId = void 0, this.gif = void 0, this.gift = void 0, this.id = void 0, this.image = void 0, this.audio = void 0, this.isContinuation = void 0, this.isLiked = void 0, this.isMasked = void 0, this.isNew = void 0, this.isOffensive = void 0, this.isInappropriate = void 0, this.isResentAfterInappropriateMark = void 0, this.isRead = void 0, this.isSelectable = !1, this.isSelected = !1, this.hasLewdPhoto = !1, this.message = void 0, this.messageType = void 0, this.originalMessageType = void 0, this.notice = void 0, this.promoType = void 0, this.replyToUid = void 0, this.request = void 0, this.size = void 0, this.status = {
                    text: ""
                }, this.statusType = void 0, this.toPersonId = void 0, this.isReplyFeatureAllowed = Boolean(null == r ? void 0 : r.isReplyFeatureAllowed), this.repliedMessage = void 0, this.allowLike = !1, this.allowReply = !1, this.readMessagesTimestamp = null == r ? void 0 : r.readMessagesTimestamp, this._isFemale = void 0, this.position = void 0, this.question = void 0, this.isLikelyOffensive = !1, this.reaction = void 0, this.update(e, t)
            }
            S.prototype = {
                DIRECTIONS: _,
                STATUS: E,
                isYours: function() {
                    return this.direction === _.OUT
                },
                isTemporary: function() {
                    return (this.id || "").startsWith("TEMP")
                },
                _updateFromJSON: function(e, t) {
                    for (var r in e) this.hasOwnProperty(r) && (this[r] = e[r]);
                    this.messageType = L(this), this.originalMessageType = e.message_type, this.size || (this.size = j(this.message)), !this.gift || this.gift instanceof v.sz8 || (this.gift = new v.sz8(this.gift)), this.image && Object.keys(this.image).length || (this.image = O(this, t)), this.video && Object.keys(this.video).length || (this.video = C(this)), this.audio && Object.keys(this.audio).length || (this.audio = R(this)), this.repliedMessage && (this.isReplyFeatureAllowed ? this.repliedMessage = new S(this.repliedMessage, t) : this.repliedMessage = void 0)
                },
                _updateFromGPB: function(e, t) {
                    var r, n, i, a, o = function(e) {
                            return e.getMssg("")
                        }(e),
                        s = function(e, t) {
                            var r = 10 === e.getMessageType() && e.hasGift() && e.getGift();
                            if (!r) return;
                            return r.setFromUserName(t ? t.getName() : ""), r.setFromUserId(e.getFromPersonId()), r.setToUserId(e.getToPersonId()), r
                        }(e, t),
                        c = function(e) {
                            var t;
                            return e.hasReaction() ? {
                                emoji: e.getReaction().getEmoji(),
                                reactedPhotoSrc: null == (t = e.getReaction().getReactionElement()) || null == (t = t.getPhoto()) ? void 0 : t.getLargeUrl()
                            } : void 0
                        }(e);
                    this.actions = void 0, this.chatDate = e.getSectionTitle(), this.dateCreated = e.getDateCreated(), this.dateModified = e.getDateModified(), this.direction = w(e) ? _.OUT : _.IN, this.displayMessage = e.getDisplayMessage(o), this.fromPersonId = e.getFromPersonId(), this.gif = e.hasGifMessageInfo() ? new f.A(e, e.getGifMessageInfo().getType()) : void 0, this.gift = s, this.id = e.getUid(), this.image = null != (r = this.image) && r.src ? this.image : O(e, t), this.video = null != (n = this.video) && n.src ? this.video : C(e), this.audio = null != (i = this.audio) && i.src ? this.audio : R(e), this.isLiked = e.getIsLiked(!1), this.isMasked = e.getIsMasked(!1), this.isNew = void 0, this.isOffensive = e.getOffensive(!1), this.isRead = e.getRead(!1), this.hasLewdPhoto = e.getHasLewdPhoto(!1), this.message = o, this.messageType = L(e), this.originalMessageType = e.getMessageType(), this.notice = void 0, this.replyToUid = e.getReplyToUid(this.replyToUid), this.request = function(e) {
                        if (! function(e) {
                                return [28, 25, 3].includes(D(e))
                            }(e)) return;
                        var t = e.getVerificationMethod(),
                            r = e.getAccessResponseType(0),
                            n = !w(e) && 0 === r;
                        return {
                            canAnswer: n,
                            providerType: t && t.getProviderType(),
                            type: t && t.getType()
                        }
                    }(e), this.size = j(o), this.toPersonId = e.getToPersonId(), this.location = function(e) {
                        var t = e.getLiveLocation();
                        if (t) {
                            var r = t.getGeoLocation();
                            if (r) return {
                                longitude: r.getLongitudePrecise(),
                                latitude: r.getLatitudePrecise()
                            }
                        }
                        var n = e.getTheirLocation();
                        if (n) return {
                            longitude: n.getLongitude(),
                            latitude: n.getLatitude()
                        }
                    }(e), this.locationExpiresAt = function(e) {
                        var t = e.getLiveLocation(),
                            r = Math.floor(Date.now() / 1e3);
                        if (t) return t.getExpiresAt(r);
                        return r
                    }(e), this.allowLike = e.getAllowLike(!1), this.allowReply = e.getAllowReply(!1), this.question = null == (a = e.getQuestion()) ? void 0 : a.toJSON(), this.isLikelyOffensive = e.getIsLikelyOffensive(!1), this.reaction = c, e.hasBanner() && (this.banner = e.getBanner().toJSON()), this.isReplyFeatureAllowed && e.hasRepliedChatMessage() && (this.repliedMessage = new S(e.getRepliedChatMessage(), t))
                },
                _updateFromPromo: function(e) {
                    var t = e.getButtons();
                    this.actions = {
                        primary: t[0] && t[0].getText(),
                        secondary: t[1] && t[1].getText()
                    }, this.direction = _.IN, this.id = e.getUniqueId(), this.message = e.getMssg(), this.messageType = function(e) {
                        return "PROMO_ID:" + e.getPromoBlockType()
                    }(e), this.notice = e.getHeader(), this.promoType = e.getPromoBlockType(), this.request = {
                        canAnswer: !0
                    }
                },
                setReadMessagesTimestamp: function(e) {
                    this.readMessagesTimestamp = e
                },
                setStatus: function(e, t) {
                    var r, n, a = "info";
                    switch (this.isRead = e === E.READ, this.statusType = e, e) {
                        case E.READ:
                            if (this.image || this.gif) {
                                t = i.Ay.get(422);
                                break
                            }
                            if (r = "generic-read-receipt", n = "read-receipt", this.readMessagesTimestamp > 1) {
                                var o = this.readMessagesTimestamp - this.dateCreated;
                                t = o <= P ? i.Ay.get(149, {
                                    str: (0, p.Cp)(this.readMessagesTimestamp)
                                }) : o <= A ? i.Ay.get(150, {
                                    num: Math.floor(o / P)
                                }) : o <= 2678400 ? i.Ay.get(151, {
                                    num: Math.floor(o / A)
                                }) : i.Ay.get(152)
                            }
                            break;
                        case E.SENDING:
                            t = i.Ay.get(432);
                            break;
                        case E.FAILED:
                            t = t || i.Ay.get(432), a = "error", r = "generic-error", n = "error";
                            break;
                        case E.INAPPROPRIATE:
                            t = i.Ay.get(27), a = "info", r = "generic-tap", this.isInappropriate = !0;
                            break;
                        case E.UPLOADING:
                            t = i.Ay.get(751);
                            break;
                        case E.DELIVERED:
                            r = "generic-read-receipt", t = i.Ay.get(148)
                    }
                    this.status = {
                        text: t,
                        textColor: undefined,
                        level: a,
                        icon: r,
                        iconColor: n
                    }
                },
                update: function(e, t) {
                    if (e instanceof v.cMz ? this._updateFromGPB(e, t) : e instanceof v.d4N ? this._updateFromPromo(e) : this._updateFromJSON(e, t), w(this) && !this.isTemporary()) {
                        var r = this.statusType;
                        e instanceof v.cMz && (r = this.dateCreated <= this.readMessagesTimestamp ? E.READ : E.DELIVERED), this.setStatus(r, void 0)
                    }
                    var i;
                    this._isFemale = 2 === ((i = t) instanceof v.KJW ? i.getGender() : null == i ? void 0 : i.gender), this.fromPersonId || (this.fromPersonId = n.A.getUserId()), this.toPersonId || (this.toPersonId = t && (t.id || t.getUserId())), this.id || (this.id = "" + b + ++T)
                },
                toGPB: function() {
                    var e = "string" == typeof this.messageType ? 1 : this.messageType || 1,
                        t = (new v.cMz).setFromPersonId(this.fromPersonId).setMessageType(e).setMssg(this.message || "").setRead(Boolean(this.isRead)).setToPersonId(this.toPersonId).setUid(String(this.id));
                    switch (this.context && t.setContext(this.context), this.replyToUid && t.setReplyToUid(String(this.replyToUid)), this.isResentAfterInappropriateMark && t.setResentAfterInappropriateMark(!0), e) {
                        case 23:
                            t.setSticker((new v.CSG).setImageId(String(this.image.src)).setId(String(this.image.id)));
                            break;
                        case 36:
                            t.setMssg(this.gif.url).setGifMessageInfo((new v.c3O).setType(this.gif.provider));
                            break;
                        case 10:
                            t.setGift(this.gift);
                            break;
                        case 50:
                            t.setQuestion((new v.vNH).setId(this.question.id))
                    }
                    var r = function(e) {
                        try {
                            var t = e.image,
                                r = e.audio,
                                n = new v.U0R;
                            if (r) {
                                var i = (new v.SzZ).setType(r.format.type).setSampleRateHz(r.format.sample_rate_hz).setBitRateKbps(r.format.bit_rate_kbps).setAudioStereo(r.format.audio_stereo).setVbrEnable(r.format.vbr_enable),
                                    a = (new v.fP5).setId(r.id.toString()).setWaveform(r.waveformSrv).setFormat(i).setDurationMs(1e3 * r.duration),
                                    o = (new v.anE).setVisibilityType(4);
                                n.setFormat(3).setAudio(a).setVisibility(o)
                            } else {
                                var s = (new v.$_D).setId(t.id),
                                    c = (new v.anE).setVisibilityType(t.visibility);
                                n.setFormat(t.format || 1).setPhoto(s).setVisibility(c)
                            }
                            return n
                        } catch (e) {
                            return
                        }
                    }(this);
                    return r && t.setMultimedia(r), t
                }
            };
            var I = S;

            function O(e, t) {
                if (e.gif || e.hasGifMessageInfo && e.hasGifMessageInfo()) return {};
                var r = function(e, t) {
                    var r;
                    return function(e, t) {
                        var r = (0, g.A)(n.A.getUser(), v.KJW);
                        !w(e) && t || (t = r);
                        var i = t && t.getProfilePhoto() || r && r.getProfilePhoto();
                        return 4 === D(e) && i && i.getLargeUrl()
                    }(e, t) || function(e) {
                        var t = e.gift || (null == e.getGift ? void 0 : e.getGift()),
                            r = null == t || null == t.getGift ? void 0 : t.getGift();
                        if (!r) return;
                        return r.getThumbUrl()
                    }(e) || (null == (r = e.gif) ? void 0 : r.src) || function(e) {
                        return e.hasSticker && e.hasSticker() && e.getSticker().getImageId()
                    }(e) || function(e) {
                        var t = e.getMultimedia && e.getMultimedia(),
                            r = t && t.getPhoto();
                        return r && r.getLargeUrl()
                    }(e)
                }(e, t);
                if (r) {
                    var i = e.getMultimedia && e.getMultimedia(),
                        a = i && i.getFormat();
                    if (!m.includes(a)) {
                        var o = i && i.getPhoto(),
                            s = o && o.getLargePhotoSize(),
                            c = s && s.getHeight() || 0,
                            u = s && s.getWidth() || 0,
                            l = o && o.getId() || e.hasSticker && e.hasSticker() && e.getSticker().getId(),
                            d = c / u,
                            p = i && i.getViewDate(),
                            f = i && i.getVisibility().getVisibilityType(),
                            h = function(e) {
                                var t = e.gift || e.getGift && e.getGift();
                                return t && t.getIsBoxed() ? t.getBoxThumbUrl() : void 0
                            }(e);
                        return {
                            format: a,
                            height: c,
                            id: l,
                            ratio: d,
                            src: r,
                            srcBox: h,
                            viewDate: p,
                            visibility: f,
                            width: u
                        }
                    }
                }
            }

            function C(e) {
                var t = e.getMultimedia && e.getMultimedia();
                if (t) {
                    var r = t.getFormat();
                    if (m.includes(r)) {
                        var n = t.getPhoto();
                        if (n) {
                            var i = n.getId(),
                                a = n.getVideo(),
                                o = n.getVideoExpirationTs(),
                                s = n.getLargeUrl();
                            return s && (s = d.A.getImageUrlForSize(s, 160)), {
                                format: r,
                                id: i,
                                previewUrl: s,
                                src: a && a.getUrl(),
                                expirationTs: o,
                                visibility: t.getVisibility().getVisibilityType()
                            }
                        }
                    }
                }
            }

            function R(e) {
                var t = e.getMultimedia && e.getMultimedia();
                if (t) {
                    var r = t.getFormat();
                    if (3 === r) {
                        var n = t.getAudio();
                        if (n) {
                            var i = n.getId(),
                                a = n.getExpirationTs(),
                                o = n.getUrl(),
                                s = t.getVisibility().getVisibilityType();
                            return {
                                expirationTs: a,
                                waveform: U(n.getWaveform([])),
                                duration: n.getDurationMs(0) / 1e3,
                                format: r,
                                id: i,
                                src: o,
                                visibility: s
                            }
                        }
                    }
                }
            }

            function w(e) {
                return n.A.getUserId() === (e.fromPersonId || e.getFromPersonId && e.getFromPersonId())
            }

            function D(e) {
                return e instanceof v.cMz ? e.getMessageType() : e.messageType
            }

            function L(e) {
                if (e.getOffensive && e.getOffensive()) return "REPORTED_XP";
                var t = D(e);
                if (1 === t) {
                    var r = e.message || e.getMssg && e.getMssg() || "";
                    if (l.isEmoji(r)) return ["♥︎", "♥", "❤️", "❤"].includes(r.replace(/\s/g, "")) ? "ANIMATED_EMOJI" : "EMOJI"
                }
                return t
            }

            function j(e) {
                return l.isEmoji(e) ? l.emojiSize(e) : void 0
            }

            function U(e) {
                var t, r = h.A.getSettings(),
                    n = (null == r || null == (t = r.chat_settings) || null == (t = t.audio_recording_settings) ? void 0 : t.waveform_length) || 3;
                return e.map((function(e) {
                    for (var t = e.toString(2), r = 10 * n - t.length; r > 0;) t = "0" + t, r--;
                    return t.match(y)
                })).reduce((function(e, t) {
                    for (var r = t.length - 1; r >= 0; --r) e.push(parseInt(t[r], 2));
                    return e
                }), [])
            }
        },
        484: function(e, t, r) {
            r.d(t, {
                X: function() {
                    return n
                }
            });
            r(50113), r(26099), r(98992), r(72577);

            function n(e, t) {
                if (!e || !t) return "";
                var r = (e.providers || []).find((function(e) {
                    return e.provider_id === t
                }));
                return (null == r ? void 0 : r.price_token) || ""
            }
        },
        1064: function(e, t, r) {
            var n;
            r.d(t, {
                $1: function() {
                    return o
                },
                UH: function() {
                    return i
                },
                rw: function() {
                    return a
                }
            });
            var i = ((n = {})[4] = "badge-feature-match", n[30] = "badge-feature-liked-you", n[23] = "badge-feature-favourites", n[2] = "badge-nearby", n[22] = "badge-visited-you", n);

            function a(e) {
                return i[e]
            }

            function o(e) {
                if (void 0 !== e.initialScreen && null !== e.initialScreen && e.initialScreen.user) {
                    var t = e.initialScreen.user;
                    if (!t.hasCameFrom() && !t.getCameFromText()) return;
                    if (!a(t.getCameFrom())) return;
                    return {
                        id: e.initialScreen.user.getCameFrom(),
                        text: e.initialScreen.user.getCameFromText(),
                        counter: 1
                    }
                }
                if (void 0 !== e.sourceOfMessage && e.sourceOfMessage.counter > 0) return e.sourceOfMessage.counter--, e.sourceOfMessage
            }
        },
        1977: function(e, t, r) {
            r.d(t, {
                m: function() {
                    return i
                }
            });
            r(27495), r(90906);
            var n = /^[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i;

            function i(e) {
                return n.test(e)
            }
        },
        3208: function(e, t, r) {
            var n, i = r(67311);

            function a() {
                n = (0, i.A)()
            }
            t.A = {
                generate: a,
                get: function() {
                    return n || a(), n
                }
            }
        },
        4803: function(e, t, r) {
            function n(e) {
                return 193 === (null == e ? void 0 : e.provider)
            }
            r.d(t, {
                W: function() {
                    return n
                }
            })
        },
        7802: function(e, t, r) {
            r.d(t, {
                q: function() {
                    return n
                }
            });
            var n = (0, r(99306).A)(!1)
        },
        7815: function(e, t, r) {
            r.d(t, {
                VB: function() {
                    return a
                },
                jq: function() {
                    return n.jq
                }
            });
            var n = r(64975),
                i = r(18084).A.getLogger("PaymentResultChannel"),
                a = new n.j0(i)
        },
        7929: function(e, t, r) {
            r(2892), r(9868), r(79432);
            var n = r(85208),
                i = r(26666),
                a = r(97286),
                o = r(36721),
                s = r(15566);

            function c(e, t) {
                this.id = null, this.image = null, this.provider = t, this.url = null, this.setup(e)
            }
            c.fromJSON = function(e) {
                var t = new c;
                return (0, n.A)(t, (0, a.A)(e, Object.keys(t)))
            }, c.prototype.setup = function(e) {
                if (e) {
                    if (e instanceof s.cMz) return 2 === this.provider ? this.id = e.getGifMessageInfo().getId() : (this.url = e.getMssg(""), this.id = (0, i.A)(this.url.split("/"))), void(this.image = {
                        ratio: e.getGifMessageInfo().getAspectRatio(),
                        extraText: "GIPHY"
                    });
                    if (1 === this.provider) {
                        var t = o.A.canUseWebP(),
                            r = e.images.fixed_width_downsampled || {},
                            n = r.height,
                            a = e.images.original || {},
                            c = t && r.webp && Number(r.size) > Number(r.webp_size),
                            u = t && a.webp && Number(a.size) > Number(a.webp_size),
                            l = r.width;
                        return this.id = e.id, this.url = e.embed_url, void(this.image = {
                            height: n,
                            preview: c ? r.webp : r.url,
                            ratio: (n / l * 100).toFixed(3),
                            url: u ? a.webp : a.url,
                            width: l,
                            extraText: "GIPHY"
                        })
                    }
                    if (2 === this.provider) {
                        this.id = e.id, this.url = e.url;
                        var d = e.media[0].gif;
                        this.image = {
                            height: d.dims[1],
                            preview: d.url,
                            ratio: (d.dims[1] / d.dims[0] * 100).toFixed(3),
                            url: d.url,
                            width: d.dims[0],
                            isExtraIconHidden: !0,
                            extraText: "Via Tenor"
                        }
                    }
                }
            }, t.A = c
        },
        10031: function(e, t, r) {
            function n(e) {
                if (!e) return !1;
                var t = e.form_error,
                    r = null == t ? void 0 : t.failure;
                return 63 === (null == r ? void 0 : r.type)
            }
            r.d(t, {
                Q: function() {
                    return n
                }
            })
        },
        11927: function(e, t, r) {
            r.d(t, {
                F: function() {
                    return o
                }
            });
            r(48598), r(26099), r(38781);
            var n = r(99417),
                i = "badoo://badoo/googleplaypayment?",
                a = {
                    TRANSACTION_ID: "transaction_id_param",
                    CONSUME_TRANSACTION: "consume_transaction",
                    CONSUME_ALL: "consume_all",
                    PURCHASE_TOKEN: "purchase_token",
                    SKU: "sku_param",
                    IS_SUBSCRIPTION: "is_subscription",
                    RESULT_URL: "result_url_param"
                };

            function o(e) {
                var t = e.consumeAll,
                    r = e.consumeTransaction,
                    o = e.isSubscription,
                    s = e.purchaseToken,
                    c = e.resultUrl,
                    u = e.sku,
                    l = e.transactionId,
                    d = new n.A.URL(i),
                    p = d.searchParams;
                if (r && p.set(a.CONSUME_TRANSACTION, "1"), l && ("string" == typeof l ? p.set(a.TRANSACTION_ID, l) : p.set(a.TRANSACTION_ID, l.join(","))), s && p.set(a.PURCHASE_TOKEN, s), t && p.set(a.CONSUME_ALL, "1"), void 0 !== o) {
                    var f = o ? "1" : "0";
                    p.set(a.IS_SUBSCRIPTION, f)
                }
                return c && p.set(a.RESULT_URL, c), u && p.set(a.SKU, u), d.toString()
            }
        },
        12632: function(e, t, r) {
            function n(e) {
                var t = e.metaKey || e.altKey || e.ctrlKey || e.shiftKey;
                return 0 === e.button && !t && (e.preventDefault(), !0)
            }
            r.d(t, {
                s: function() {
                    return n
                }
            })
        },
        12702: function(e, t, r) {
            r.d(t, {
                Kl: function() {
                    return c
                },
                BX: function() {
                    return s
                },
                FW: function() {
                    return m
                },
                jh: function() {
                    return y
                }
            });
            r(52675), r(2008), r(51629), r(74423), r(67945), r(84185), r(83851), r(81278), r(79432), r(26099), r(21699), r(98992), r(54520), r(3949), r(23500), r(45700), r(89572), r(2892);
            var n = r(96540),
                i = r(86812),
                a = r(484),
                o = r(70271);
            r(50113), r(72577);
            var s, c, u = r(74848),
                l = ["children"];

            function d(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function p(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? d(Object(r), !0).forEach((function(t) {
                        f(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : d(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function f(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function h(e) {
                var t = e.paymentOptions,
                    r = e.selectedProduct,
                    n = e.selectedProvider,
                    i = e.storedProvider,
                    a = e.nonStoredProviders,
                    o = e.defaultUcbRecap;
                return {
                    isLoading: !1,
                    billingEmail: "",
                    isStoredProviderPressed: !1,
                    emailErrorLabel: "",
                    currentTransaction: void 0,
                    autoTopUpValue: Boolean((null == o ? void 0 : o.is_auto_topup_available) && (null == o ? void 0 : o.auto_top_up_default_state)),
                    ignoreStoredDetails: !1,
                    ccFormUrl: "",
                    isCcPayment: !1,
                    isCcFormFullscreen: !1,
                    paymentOptions: t,
                    selectedProduct: r,
                    selectedProvider: n,
                    storedProvider: i,
                    nonStoredProviders: a,
                    currentUcbRecap: void 0,
                    ccFormState: void 0,
                    deviceProfilingId: void 0,
                    userPickedPaymentMethod: !1,
                    toBeClosed: !1
                }
            }

            function g(e, t) {
                var r, n, c, u, l = p({}, e);
                switch (t.type) {
                    case s.UPDATE_IS_LOADING:
                        l.isLoading = t.value;
                        break;
                    case s.UPDATE_BILLING_EMAIL:
                        l.billingEmail = t.value;
                        break;
                    case s.UPDATE_STORE_PROVIDER_PRESSED:
                        l.isStoredProviderPressed = t.value;
                        break;
                    case s.UPDATE_EMAIL_ERROR_LABEL:
                        l.emailErrorLabel = t.value;
                        break;
                    case s.UPDATE_CURRENT_TRANSACTION:
                        var d;
                        l.currentTransaction = t.value, l.ccFormUrl = null == (d = l.currentTransaction) ? void 0 : d.redirect_url;
                        break;
                    case s.UPDATE_AUTO_TOP_UP_VALUE:
                        l.autoTopUpValue = t.value, l.paymentOptions = p(p({}, l.paymentOptions), {}, {
                            autoTopup: t.value
                        });
                        break;
                    case s.UPDATE_IGNORE_STORED_DETAILS:
                        l.ignoreStoredDetails = t.value;
                        break;
                    case s.UPDATE_IS_CC_PAYMENT:
                        l.isCcPayment = t.value;
                        break;
                    case s.UPDATE_IS_CC_FORM_FULLSCREEN:
                        l.isCcFormFullscreen = t.value;
                        break;
                    case s.UPDATE_PAYMENT_OPTIONS:
                        l.paymentOptions = t.value;
                        break;
                    case s.UPDATE_SELECTED_PROVIDER:
                        var f = t.value;
                        l.selectedProvider = f;
                        var h = p(p({}, l.paymentOptions), {}, {
                            extraDataModalFlow: (0, i.A)(f),
                            priceToken: (0, a.X)(l.selectedProduct, null == f ? void 0 : f.provider_id),
                            provider: null == f ? void 0 : f.provider,
                            providerId: null == f ? void 0 : f.provider_id,
                            providerName: null == f ? void 0 : f.provider_name
                        });
                        l.paymentOptions = h;
                        var g = Boolean((null == f ? void 0 : f.provider) && (0, o.n8)(null == f ? void 0 : f.provider_id) && !(100001 === (null == f ? void 0 : f.provider)));
                        l.isCcPayment = g;
                        var v = (r = l.selectedProduct, n = null == f ? void 0 : f.provider_id, null == (u = null == r || null == (c = r.providers) ? void 0 : c.find((function(e) {
                            return e.provider_id === n
                        }))) ? void 0 : u.ucb_recap);
                        l.currentUcbRecap = v;
                        break;
                    case s.UPDATE_STORED_PROVIDER:
                        l.storedProvider = t.value;
                        break;
                    case s.UPDATE_SELECTED_PRODUCT:
                        l.selectedProduct = t.value;
                        break;
                    case s.UPDATE_CURRENT_UCB_RECAP:
                        l.currentUcbRecap = t.value;
                        break;
                    case s.UPDATE_CC_FORM_STATE:
                        l.ccFormState = t.value;
                        break;
                    case s.UPDATE_DEVICE_PROFILING_ID:
                        l.deviceProfilingId = t.value;
                        break;
                    case s.UPDATE_USER_PICKED_PAYMENT_METHOD:
                        l.userPickedPaymentMethod = t.value;
                        break;
                    case s.FIRE_SIGNAL_CLOSE:
                        l.toBeClosed = t.value;
                        break;
                    default:
                        throw new Error("ucbReducer - Unhandled action type")
                }
                return l
            }! function(e) {
                e.UPDATE_IS_LOADING = "UPDATE_IS_LOADING", e.UPDATE_BILLING_EMAIL = "UPDATE_BILLING_EMAIL", e.UPDATE_STORE_PROVIDER_PRESSED = "UPDATE_STORE_PROVIDER_PRESSED", e.UPDATE_EMAIL_ERROR_LABEL = "UPDATE_EMAIL_ERROR_LABEL", e.UPDATE_CURRENT_TRANSACTION = "UPDATE_CURRENT_TRANSACTION", e.UPDATE_AUTO_TOP_UP_VALUE = "UPDATE_AUTO_TOP_UP_VALUE", e.UPDATE_IGNORE_STORED_DETAILS = "UPDATE_IGNORE_STORED_DETAILS", e.UPDATE_CC_FORM_URL = "UPDATE_CC_FORM_URL", e.UPDATE_IS_CC_PAYMENT = "UPDATE_IS_CC_PAYMENT", e.UPDATE_IS_CC_FORM_FULLSCREEN = "UPDATE_IS_CC_FORM_FULLSCREEN", e.UPDATE_PAYMENT_OPTIONS = "UPDATE_PAYMENT_OPTIONS", e.UPDATE_SELECTED_PRODUCT = "UPDATE_SELECTED_PRODUCT", e.UPDATE_SELECTED_PROVIDER = "UPDATE_SELECTED_PROVIDER", e.UPDATE_STORED_PROVIDER = "UPDATE_STORED_PROVIDER", e.UPDATE_CURRENT_UCB_RECAP = "UPDATE_CURRENT_UCB_RECAP", e.UPDATE_CC_FORM_STATE = "UPDATE_CC_FORM_STATE", e.UPDATE_DEVICE_PROFILING_ID = "UPDATE_DEVICE_PROFILING_ID", e.UPDATE_USER_PICKED_PAYMENT_METHOD = "UPDATE_USER_PICKED_PAYMENT_METHOD", e.FIRE_SIGNAL_CLOSE = "FIRE_SIGNAL_CLOSE"
            }(s || (s = {})),
            function(e) {
                e.NORMAL = "NORMAL", e.SECURITY_STEP = "SECURITY_STEP"
            }(c || (c = {}));
            var v = (0, n.createContext)({
                    state: h({}),
                    dispatch: function() {}
                }),
                m = function(e) {
                    var t = e.children,
                        r = function(e, t) {
                            if (null == e) return {};
                            var r = {};
                            for (var n in e)
                                if ({}.hasOwnProperty.call(e, n)) {
                                    if (t.includes(n)) continue;
                                    r[n] = e[n]
                                }
                            return r
                        }(e, l),
                        i = (0, n.useReducer)(g, h(p({}, r))),
                        a = {
                            state: i[0],
                            dispatch: i[1]
                        };
                    return (0, u.jsx)(v.Provider, {
                        value: a,
                        children: t
                    })
                };

            function y() {
                var e = (0, n.useContext)(v);
                if (void 0 === e) throw new Error("useUcbContext must be used within a UcbContextProvider");
                return e
            }
        },
        13315: function(e, t, r) {
            r(28706), r(2008), r(23792), r(72712), r(10287), r(26099), r(47764), r(98992), r(54520), r(8872), r(62953), r(27208), r(48408);
            var n = r(78029),
                i = r(71672),
                a = r(23735);

            function o(e, t) {
                return o = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, o(e, t)
            }
            var s;
            ! function(e) {
                e.SUCCESS = "SUCCESS", e.PENDING = "PENDING", e.FAILURE = "FAILURE", e.CANCEL = "CANCEL"
            }(s || (s = {}));
            var c = "payment-state",
                u = function(e) {
                    function t() {
                        var r;
                        return r = e.call(this) || this, a.Kj.on(455, (function() {
                            r.setResult(t.RESULTS.SUCCESS)
                        })), r
                    }
                    var r, n;
                    n = e, (r = t).prototype = Object.create(n.prototype), r.prototype.constructor = r, o(r, n), t.getInstance = function() {
                        return null === t.instance && (t.instance = new t), t.instance
                    };
                    var s = t.prototype;
                    return s.getBackRoute = function() {
                        return this.getValue("back")
                    }, s.getBackAction = function() {
                        return this.getValue("action")
                    }, s.getResult = function() {
                        return this.getValue("result")
                    }, s.getTrustedOrigins = function() {
                        return this.getValue("trustedOrigins") || []
                    }, s.setBackRoute = function(e) {
                        this.setValue("back", e), this.persistState()
                    }, s.setBackAction = function(e) {
                        this.setValue("action", e), this.persistState()
                    }, s.setResult = function(e) {
                        this.setValue("result", e)
                    }, s.setTrustedOrigins = function(e, t) {
                        var r = e.filter(Boolean).reduce((function(e, t) {
                            var r = "";
                            try {
                                r = new URL(t).origin
                            } catch (e) {}
                            return r ? [].concat(e, [r]) : e
                        }), t ? this.getTrustedOrigins() : []);
                        this.setValue("trustedOrigins", r)
                    }, s.clear = function() {
                        this.setBackRoute(null), this.setBackAction(null), this.setResult(null), i.A.remove(c)
                    }, s.retrieveState = function() {
                        var e = i.A.getObject(c);
                        e && (this.setBackAction(e.action), this.setBackRoute(e.back))
                    }, s.persistState = function() {
                        i.A.saveObject(c, {
                            back: this.getBackRoute(),
                            action: this.getBackAction()
                        })
                    }, t
                }((0, n.tG)((function() {})));
            u.RESULTS = s, u.instance = null, t.A = u
        },
        18826: function(e, t, r) {
            r(52675), r(45700), r(2008), r(48980), r(51629), r(25276), r(62062), r(26910), r(60739), r(89572), r(2892), r(69085), r(67945), r(84185), r(83851), r(81278), r(79432), r(26099), r(98992), r(54520), r(3949), r(81454), r(23500), r(99417);
            var n = r(13614),
                i = r(254),
                a = r(15566),
                o = r(1064);

            function s(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function c(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? s(Object(r), !0).forEach((function(t) {
                        u(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : s(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function u(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var l = {},
                d = void 0;

            function p(e) {
                return h({
                    chatMessage: e.chatMessage,
                    clientChatMessages: e.clientChatMessages,
                    clientOpenChat: e.clientOpenChat,
                    userId: e.userId
                })
            }

            function f(e) {
                var t = e.blockingFeature,
                    r = e.chatMessage,
                    i = e.clientChatMessages,
                    a = e.clientOpenChat,
                    s = e.chatSettings,
                    c = e.initialScreen,
                    u = e.userId,
                    l = p({
                        clientOpenChat: a,
                        userId: u,
                        clientChatMessages: i,
                        chatMessage: r
                    });
                return a && function(e) {
                    var t = e.clientOpenChat,
                        r = e.userId,
                        i = h({
                            clientOpenChat: t,
                            userId: r
                        });
                    if (!t) return i;
                    var a = t.getChatInstance(),
                        s = t.getChatSettings(),
                        c = t.getChatUser(i.chatUser),
                        u = function(e) {
                            if (!e.hasInitialChatScreen()) return;
                            var t = e.getInitialChatScreen(),
                                r = t.hasGifts() && t.getGifts().getSections()[0].getGiftProducts();
                            return {
                                blockingFeature: t.getBlockingFeature(),
                                gifts: r && r.map((function(e) {
                                    return e.toJSON()
                                })),
                                message: t.getMessage(""),
                                promo: t.getPromo(),
                                subtitle: t.getSubtitle(""),
                                title: t.getTitle(""),
                                type: t.getType(),
                                user: t.getUser()
                            }
                        }(t),
                        l = function(e) {
                            var t = e.getChatUser();
                            if (!(0, o.rw)(t.getCameFrom())) return;
                            return {
                                id: t.getCameFrom(),
                                text: t.getCameFromText(),
                                counter: 1
                            }
                        }(t),
                        d = s && s.getInputSettings(),
                        p = s && s.getAllowReply(!1),
                        f = s && s.getAllowUrlParsing(!1),
                        v = d && d.getInputFeatures(),
                        y = d && d.toJSON().input_items || [],
                        P = t.getMaxUnansweredMessages(i.maxUnansweredMessages);
                    Object.assign(i, {
                        isReplyFeatureAllowed: p,
                        isAllowUrlParsing: f,
                        chatInstanceId: a ? a.getUid() : r,
                        chatUser: c,
                        counter: a ? a.getCounter(0) : i.counter,
                        deletedMember: a ? a.getOtherAccountDeleted() : i.deletedMember,
                        allowDisablingPrivateDetector: s && s.getAllowDisablingPrivateDetector(),
                        dummy: !1,
                        gender: c.getGender(),
                        initialScreen: u,
                        sourceOfMessage: l,
                        initialScreenType: null == u ? void 0 : u.type,
                        inputFeatures: v ? v.map((function(e) {
                            return e.toJSON()
                        })) : i.inputFeatures,
                        inputSettingsItems: y,
                        isMatch: c.getIsMatch(),
                        largePhoto: (0, n.Yz)(c),
                        maxUnansweredMessages: P,
                        messages: m({
                            clientOpenChat: t,
                            userId: r
                        }),
                        multimediaVisibility: g(s),
                        promoBanners: t.getPromoBanners([]),
                        readMessagesTimestamp: t.getReadMessagesTimestamp(i.readMessagesTimestamp),
                        userId: r,
                        isShowingCrushAnimation: s && s.getShowCrushAnimation(),
                        isNotInterested: t.getIsNotInterested(),
                        isShowingOffensiveMessagesPrompt: s && s.getShowOffensiveMessagesPrompt()
                    })
                }({
                    clientOpenChat: a,
                    userId: u
                }), void 0 !== t && function(e) {
                    var t = e.userId,
                        r = e.chatMessage,
                        n = e.blockingFeature,
                        i = p({
                            userId: t,
                            chatMessage: r
                        });
                    i.initialScreen && (i.initialScreen.blockingFeature = n)
                }({
                    userId: u,
                    chatMessage: r,
                    blockingFeature: t
                }), void 0 !== s && function(e) {
                    var t = e.userId,
                        r = e.chatSettings,
                        n = p({
                            userId: t
                        }),
                        i = r && r.getInputSettings(),
                        a = i && i.getInputFeatures(),
                        o = i && i.toJSON().input_items;
                    n.inputSettingsItems = o, n.inputFeatures = a ? a.map((function(e) {
                        return e.toJSON()
                    })) : n.inputFeatures, n.allowDisablingPrivateDetector = r && r.getAllowDisablingPrivateDetector()
                }({
                    userId: u,
                    chatSettings: s
                }), void 0 !== c && v({
                    userId: u,
                    chatMessage: r,
                    initialScreen: c
                }), void 0 === i && void 0 === r || function(e) {
                    var t = e.clientOpenChat,
                        r = e.userId,
                        n = e.clientChatMessages,
                        i = e.chatMessage,
                        a = p({
                            clientOpenChat: t,
                            userId: r,
                            clientChatMessages: n,
                            chatMessage: i
                        }),
                        o = a.messages.length;
                    if (m({
                            clientOpenChat: t,
                            userId: r,
                            clientChatMessages: n,
                            chatMessage: i
                        }), n) {
                        var s = n.getChatInstance();
                        a.counter = s.getCounter(a.counter)
                    } else i && o < a.messages.length && (v({
                        userId: r,
                        chatMessage: i,
                        initialScreen: void 0
                    }), a.counter++, i.isYours() ? 10 !== i.messageType && a.maxUnansweredMessages-- : a.maxUnansweredMessages = 1 / 0)
                }({
                    clientOpenChat: a,
                    userId: u,
                    clientChatMessages: i,
                    chatMessage: r
                }), l
            }

            function h(e) {
                var t = e.chatMessage,
                    r = e.clientChatMessages,
                    n = e.clientOpenChat,
                    o = e.userId,
                    s = function(e) {
                        var t = e.clientOpenChat,
                            r = e.userId,
                            n = e.clientChatMessages,
                            a = e.chatMessage,
                            o = t && t.getChatInstance(),
                            s = n ? n.getMessages([]) : [],
                            c = s.length ? new i.Ay(s[0]) : a;
                        if (o) {
                            var u = t.getChatUser();
                            return o.getUid() || (u ? u.getUserId() : r)
                        }
                        if (c) return (c.isYours() ? c.toPersonId : c.fromPersonId) || r;
                        return r
                    }({
                        chatMessage: t,
                        clientChatMessages: r,
                        clientOpenChat: n,
                        userId: o
                    });
                o = o || s;
                var c = l[s] = l[o] = l[s] || function(e) {
                    return {
                        chatInstanceId: e,
                        chatUser: new a.KJW({
                            user_id: e,
                            name: ""
                        }),
                        counter: 0,
                        deletedMember: !1,
                        dummy: !0,
                        gender: void 0,
                        inputFeatures: [{
                            feature: 18,
                            enabled: !0
                        }, {
                            feature: 70,
                            enabled: !1
                        }, {
                            feature: 111,
                            enabled: !1
                        }, {
                            feature: 113,
                            enabled: !1
                        }, {
                            feature: 155,
                            enabled: !1
                        }],
                        initialScreen: void 0,
                        initialScreenType: void 0,
                        sourceOfMessage: void 0,
                        isMatch: void 0,
                        largePhoto: void 0,
                        maxUnansweredMessages: 1 / 0,
                        messages: [],
                        multimediaVisibility: g(),
                        promoBanners: [],
                        dismissedPromoBanners: [],
                        readMessagesTimestamp: void 0,
                        userId: e
                    }
                }(o);
                return c
            }

            function g(e) {
                if (!d) {
                    var t = e && e.getMultimediaSettings().getMultimediaConfig().getVisibility();
                    t && (d = t.map((function(e) {
                        return {
                            seconds: e.getSeconds(),
                            title: e.getDisplayValue(),
                            visibilityType: e.getVisibilityType()
                        }
                    })))
                }
                return d || []
            }

            function v(e) {
                var t = e.userId,
                    r = e.chatMessage,
                    n = e.initialScreen,
                    i = p({
                        userId: t,
                        chatMessage: r
                    });
                return i.initialScreen = n, i.initialScreenType = null == n ? void 0 : n.type, i
            }

            function m(e) {
                var t = e.clientOpenChat,
                    r = e.userId,
                    n = e.clientChatMessages,
                    a = e.chatMessage,
                    o = t && t.getInitialChatScreen(),
                    s = function(e) {
                        var t = e.clientOpenChat,
                            r = e.userId,
                            n = e.clientChatMessages,
                            a = e.chatMessage;
                        if (t) {
                            var o = t.getChatUser(),
                                s = t.getChatSettings(),
                                c = s && s.getAllowReply(!1);
                            return t.getChatMessages([]).map((function(e) {
                                return new i.Ay(e, o, {
                                    isReplyFeatureAllowed: c,
                                    readMessagesTimestamp: t.getReadMessagesTimestamp()
                                })
                            }))
                        }
                        if (n) {
                            var u = p({
                                userId: r
                            }).chatUser;
                            return n.getMessages([]).map((function(e) {
                                return new i.Ay(e, u)
                            }))
                        }
                        return a ? [a] : []
                    }({
                        clientOpenChat: t,
                        userId: r,
                        clientChatMessages: n,
                        chatMessage: a
                    }),
                    c = p({
                        clientOpenChat: t,
                        userId: r,
                        clientChatMessages: n,
                        chatMessage: a
                    }),
                    u = c.messages;
                return o && 7 === o.getType() && (u.length = 0), s.forEach((function(e) {
                        var t = e.id,
                            r = u.findIndex((function(e) {
                                return e.id === t
                            })),
                            n = 20 === e.messageType; - 1 !== r ? (n && (e.messageType = u[r].messageType), u[r].update(e, c.chatUser)) : n || u.push(e)
                    })),
                    function(e) {
                        return (e || []).sort((function(e, t) {
                            return e.dateCreated - t.dateCreated || e.id - t.id
                        }))
                    }(u)
            }

            function y(e) {
                var t = l[e],
                    r = t.initialScreen || {},
                    n = r.blockingFeature,
                    i = r.promo;
                return c(c({}, t), {}, {
                    chatUser: t.chatUser.toJSON(),
                    messages: t.messages.slice(-5),
                    promoBanners: t.promoBanners.map((function(e) {
                        return e.toJSON()
                    })),
                    initialScreen: t.initialScreen ? c(c({}, t.initialScreen), {}, {
                        blockingFeature: n && n.toJSON(),
                        promo: i && i.toJSON()
                    }) : void 0
                })
            }
            t.A = {
                create: function(e) {
                    var t = e.chatMessage,
                        r = e.clientChatMessages,
                        n = e.clientOpenChat,
                        i = e.userId;
                    return f({
                        chatMessage: t,
                        clientChatMessages: r,
                        clientOpenChat: n,
                        userId: i
                    })
                },
                read: p,
                update: f,
                delete: function e(t) {
                    if (t) l.hasOwnProperty(t) && delete l[t];
                    else
                        for (var r in l) e(r)
                },
                increaseMaxAnswers: function(e) {
                    var t = e.clientOpenChat,
                        r = e.userId,
                        n = e.clientChatMessages,
                        i = e.chatMessage;
                    p({
                        clientOpenChat: t,
                        userId: r,
                        clientChatMessages: n,
                        chatMessage: i
                    }).maxUnansweredMessages++
                },
                markChatPromoHandled: function(e, t, r) {
                    var n = e.clientOpenChat,
                        i = e.userId,
                        a = e.clientChatMessages,
                        o = e.chatMessage,
                        s = p({
                            clientOpenChat: n,
                            userId: i,
                            clientChatMessages: a,
                            chatMessage: o
                        });
                    if (r) {
                        var c = s.dismissedPromoBanners.indexOf(t);
                        c > -1 && s.dismissedPromoBanners.splice(c, 1)
                    } else s.dismissedPromoBanners.push(t)
                },
                load: function() {},
                save: function(e) {
                    if (e) return y(e);
                    var t = {};
                    for (var r in l) t[r] = y(r);
                    return t
                }
            }
        },
        20140: function(e, t, r) {
            r.d(t, {
                U: function() {
                    return n
                }
            });
            r(50113), r(26099), r(98992), r(72577);

            function n(e, t) {
                return e.find((function(e) {
                    return e.provider_id === t
                }))
            }
        },
        26935: function(e, t, r) {
            r(52675), r(45700), r(2008), r(51629), r(89572), r(2892), r(69085), r(67945), r(84185), r(83851), r(81278), r(79432), r(26099), r(98992), r(54520), r(3949), r(23500);
            var n = r(42302),
                i = r(74389),
                a = r(58385),
                o = r(18084),
                s = r(13315),
                c = r(41025),
                u = r(59179),
                l = r(62608),
                d = r(20387),
                p = r(76854),
                f = r(49683),
                h = r(10031),
                g = r(30922),
                v = r(51438),
                m = r(62386);

            function y(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function P(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? y(Object(r), !0).forEach((function(t) {
                        A(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : y(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function A(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function E(e) {
                var t = e.purchaseParameters,
                    r = e.transactionResult,
                    n = t.chatMessage,
                    o = t.cost,
                    s = t.onComplete,
                    u = t.onError,
                    l = t.onSuccess,
                    p = t.productType,
                    f = r.error,
                    y = r.clientPurchaseReceipt,
                    A = r.featureProductList,
                    E = r.purchaseTransaction,
                    _ = r.purchaseTransactionFailed,
                    b = t.hotPanelData,
                    T = void 0 === b ? {
                        activationPlace: 1
                    } : b,
                    S = 1 !== T.eventVersion,
                    I = void 0;
                if (!p) return u("Trying to make a one-click payment without productType"), void s(!1);
                if (S && (I = (0, v.Im)(t.hotPanelPaymentFlowId || null, p, T.activationPlace, {
                        activation_place_option: T.activationPlaceOption,
                        banner_id: T.bannerId,
                        credits_cost: Number(o),
                        is_one_click_payment: Boolean(y),
                        object_id: T.objectId
                    })), f)
                    if (_) {
                        if (S && (0, v.Np)(I, v.QO.FAILURE), (0, h.Q)(_)) return a.A.navigate(i.x.ADD_PHOTOS, {
                            backHistoryEntry: a.A.getHistoryEntryId(),
                            destination: a.A.getUrl()
                        }), void s(!1);
                        var O = _.notification,
                            C = null == O ? void 0 : O.message;
                        u(C), s(!1)
                    } else {
                        if (E) {
                            var R = new m.A;
                            return R.on(m.A.EVENTS.SUCCESS, (function() {
                                l(), s(!0), R.stop()
                            })).on(m.A.EVENTS.FAILED, (function() {
                                u(), s(!1), R.stop()
                            })).on(m.A.ACTIONS.BACK, (function() {
                                u(), s(!1, !0), R.stop()
                            })), R.start(), void R.updateParameters(function(e, t) {
                                var r = t.uid,
                                    n = P(P({
                                        purchaseTransaction: t,
                                        handleOnStartTransaction: !0
                                    }, e), {}, {
                                        provider: t.provider,
                                        providerName: "Credit Card",
                                        forceIframeFlow: !0
                                    });
                                r && (n.uid = r);
                                return n
                            }(t, E))
                        }
                        var w, D = null == n || null == (w = n.gift) ? void 0 : w.getGift();
                        c.A.navigateToPayment({
                            back: t.back,
                            chatMessage: n,
                            cost: o,
                            giftProductId: null == D ? void 0 : D.getProductId(),
                            hotPanelData: T,
                            newNavigation: t.newNavigation,
                            productType: p,
                            promoBlockType: t.promoBlockType,
                            stickerPackId: t.stickerPackId,
                            transactionResult: A,
                            userId: t.userId,
                            callback: function(e) {
                                var t = e.cancelled,
                                    r = e.purchaseReceipt;
                                e.success && r ? g.A.subscribeToNotificationShow(r, (function(e) {
                                    var t = e.receipt;
                                    l(t), d.A.getInstance().invalidateCreditFolders(), s(!0)
                                })) : (!0 !== t && u(), s(!1, t))
                            }
                        }, {
                            replace: t.popState,
                            existingPaymentFlowId: I,
                            paymentTransitionInFlow: t.paymentTransitionInFlow
                        })
                    }
                else y ? (g.A.processClientPurchaseReceipt(y), g.A.subscribeToNotificationShow(y, (function() {
                    S && (0, v.Np)(I, v.QO.SUCCESS, T.eventVersion), l(y), d.A.getInstance().invalidateCreditFolders(), s(!0, !1, {
                        isOneClickPayment: !0
                    })
                }))) : (S && (0, v.Np)(I, v.QO.FAILURE), u(), s(!1))
            }
            var _ = function() {
                function e() {}
                return e.purchase = function(t) {
                    null != t && t.productType ? l.A.getInstance().getCredits().then((function(e) {
                        var r, n = t.ignoreCost || p.A.getInstance().hasConsumableForProductType(t.productType),
                            i = t.cost,
                            a = !n && "number" == typeof i,
                            o = "number" == typeof i && e >= i,
                            s = u.A.getInstance().canUseInstantPaywall(t.productType),
                            c = Boolean(null == (r = t.purchaseTransactionSetup) ? void 0 : r.crossSellOrderId);
                        if (!s || !a || o || c) {
                            var l = function(e) {
                                var t, r = Object.assign({
                                    chatMessage: e.chatMessage,
                                    featureType: e.featureType,
                                    productType: e.productType,
                                    userId: e.userId
                                }, e.purchaseTransactionSetup);
                                null != (t = e.hotPanelData) && t.activationPlace && (r.hpActivationPlaceId = e.hotPanelData.activationPlace);
                                return r
                            }(t);
                            f.A.getInstance().tryCreditsPurchase(l, (function(e) {
                                E({
                                    purchaseParameters: b(t),
                                    transactionResult: e
                                })
                            }))
                        } else E({
                            purchaseParameters: b(t),
                            transactionResult: {
                                error: new Error("Not able to purchase credits in OneClickPurchase")
                            }
                        })
                    })) : e.log.error("Trying to pay without productType")
                }, e
            }();

            function b(e) {
                var t = e.hotPanelData;
                return Object.assign({
                    back: s.A.getInstance().getBackRoute() || e.back,
                    chatMessage: e.chatMessage,
                    cost: e.cost || t.cost,
                    hotPanelData: e.hotPanelData,
                    hotPanelPaymentFlowId: t.existingPaymentFlowId,
                    newNavigation: e.newNavigation,
                    paymentTransitionInFlow: Boolean(e.paymentTransitionInFlow),
                    popState: e.popState,
                    productType: e.productType,
                    promoBlockType: e.promoBlockType,
                    userId: e.userId,
                    onComplete: e.complete || n.A,
                    onError: e.error || n.A,
                    onSuccess: e.success || n.A
                }, e.purchaseTransactionSetup)
            }
            _.log = o.A.getLogger("oneClickPaymentFeature"), t.A = _
        },
        28244: function(e, t, r) {
            r(52675), r(45700), r(2008), r(51629), r(74423), r(89572), r(2892), r(67945), r(84185), r(83851), r(81278), r(79432), r(26099), r(21699), r(98992), r(54520), r(3949), r(23500);
            var n = r(58385),
                i = r(12632),
                a = r(18084),
                o = r(99417),
                s = r(33926),
                c = r(74848),
                u = ["routeName", "routeParams", "href", "onClick", "dataQA", "children", "target", "preventNavigation"];

            function l(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function d(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? l(Object(r), !0).forEach((function(t) {
                        p(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : l(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function p(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var f = a.A.getLogger("RoutingAnchor");
            t.A = function(e) {
                var t, r = e.routeName,
                    a = e.routeParams,
                    l = e.href,
                    p = e.onClick,
                    h = e.dataQA,
                    g = e.children,
                    v = e.target,
                    m = e.preventNavigation,
                    y = function(e, t) {
                        if (null == e) return {};
                        var r = {};
                        for (var n in e)
                            if ({}.hasOwnProperty.call(e, n)) {
                                if (t.includes(n)) continue;
                                r[n] = e[n]
                            }
                        return r
                    }(e, u);
                r && (t = n.A.getAccessibleUrl({
                    routeName: r,
                    parameters: a
                })), t || l || p || f.error("RoutingAnchor is meaningless because neither accessible URL nor onClick exist", {
                    children: g,
                    routeName: r
                });
                var P = t || l ? "a" : "button",
                    A = d({
                        "data-qa": "routing-anchor"
                    }, h);
                return (0, c.jsxs)(P, d(d(d({
                    href: t || l,
                    onClick: function(e) {
                        var t = (0, i.s)(e);
                        null == p || p(), !m && t && (r ? n.A.navigate(r, a) : l && o.A.open(l, v || "_self"))
                    },
                    type: "button" === P ? "button" : void 0,
                    target: "a" === P ? v : void 0
                }, A), y), {}, {
                    children: [g, "a" === P && "_blank" === v ? (0, c.jsx)(s.A, {}) : null]
                }))
            }
        },
        30245: function(e, t, r) {
            r.d(t, {
                J: function() {
                    return n
                }
            });
            r(50113), r(26099), r(98992), r(72577);

            function n(e, t) {
                return e.find((function(e) {
                    return e.uid === t
                }))
            }
        },
        30711: function(e, t, r) {
            var n;
            r.d(t, {
                    f: function() {
                        return n
                    }
                }),
                function(e) {
                    e.EXTRA = "EXTRA", e.SPP = "SPP", e.PREMIUM_PLUS = "PREMIUM_PLUS"
                }(n || (n = {}))
        },
        30922: function(e, t, r) {
            r(51629), r(26099), r(98992), r(3949), r(23500);
            var n = r(99417),
                i = r(58385),
                a = r(74389),
                o = r(93529),
                s = {},
                c = function() {
                    function e() {
                        this.clientNotification = void 0, this.clientPurchaseReceipt = void 0, this.notificationShown = void 0, this.notificationShownCallbacks = void 0, this.waitTime = void 0, this.waitTimeIsOver = void 0, this.notificationShownCallbacks = [], this.notificationShown = !1, this.waitTimeIsOver = !1
                    }
                    var t = e.prototype;
                    return t.addNotificationShownCallback = function(e) {
                        this.notificationShown ? e({
                            receipt: this.clientPurchaseReceipt
                        }) : this.notificationShownCallbacks.push(e)
                    }, t.setClientPurchaseReceipt = function(e) {
                        var t = this;
                        this.clientPurchaseReceipt = e, this.waitTime = this.clientPurchaseReceipt.payment_timeout, this.checkState(), this.waitTime && n.A.setTimeout((function() {
                            t.waitTimeIsOver = !0, t.checkState()
                        }), 1e3 * this.waitTime)
                    }, t.setClientNotification = function(e) {
                        this.clientNotification = e, this.checkState()
                    }, t.checkState = function() {
                        var e = this;
                        if (!this.notificationShown && this.clientPurchaseReceipt) return this.clientPurchaseReceipt.cross_sell ? (this.setNotificationShown(), void n.A.setTimeout((function() {
                            return e.navigateToCrossSell()
                        }), 400)) : void(!this.clientNotification && this.clientPurchaseReceipt.purchase_success && this.waitTime && !this.waitTimeIsOver || (this.showNotification(), this.setNotificationShown()))
                    }, t.setNotificationShown = function() {
                        var e = this;
                        this.notificationShown = !0, this.notificationShownCallbacks.forEach((function(t) {
                            return t({
                                receipt: e.clientPurchaseReceipt
                            })
                        }))
                    }, t.navigateToCrossSell = function() {
                        i.A.navigate(a.x.CROSS_SELL, {
                            clientPurchaseReceipt: this.clientPurchaseReceipt
                        })
                    }, t.showNotification = function() {
                        var e, t, r = this.clientNotification || (null == (e = this.clientPurchaseReceipt) ? void 0 : e.notification);
                        if (r) {
                            var n = r.message,
                                i = r.title;
                            i && i !== n && (n = i + " " + n);
                            var a = {
                                    type: o.A.TYPES.INFO,
                                    text: n
                                },
                                s = r.promo_block;
                            18 === (null == s ? void 0 : s.promo_block_position) && (a.promoBlock = s), null != (t = this.clientPurchaseReceipt) && t.productType && (a.type = o.A.TYPES.PAYMENT, a.productType = this.clientPurchaseReceipt.productType), o.A.showNotification(a)
                        }
                    }, e
                }();

            function u(e) {
                return s[e] || (s[e] = new c), s[e]
            }
            t.A = {
                processClientNotification: function(e) {
                    e.transaction_identifier && u(e.transaction_identifier).setClientNotification(e)
                },
                processClientPurchaseReceipt: function(e) {
                    e && u(e.transaction_identifier).setClientPurchaseReceipt(e)
                },
                subscribeToNotificationShow: function(e, t) {
                    var r = u(e.transaction_identifier);
                    t && r.addNotificationShownCallback(t)
                },
                reset: function() {
                    for (var e in s) delete s[e]
                }
            }
        },
        32411: function(e, t, r) {
            r(10287), r(26099), r(3362);
            var n = r(6696),
                i = r(32308),
                a = r(41298);

            function o(e, t) {
                return o = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, o(e, t)
            }
            var s = function(e) {
                function t() {
                    return e.call(this, {
                        get: {
                            message: 493,
                            response: 494
                        }
                    }, {
                        name: "ProductExplanationModel",
                        useCache: !1
                    }) || this
                }
                var r, n;
                return n = e, (r = t).prototype = Object.create(n.prototype), r.prototype.constructor = r, o(r, n), t.getInstance = function() {
                    return t.instance || (t.instance = new t), t.instance
                }, t.prototype.getProductExplanation = function(t) {
                    var r = t.productType,
                        n = t.userId,
                        o = t.explanationType,
                        s = t.clientSource,
                        c = t.promoBlockType;
                    if (!(0, i.Rg)(r)) return (0, a.A)(Promise.reject(new Error("Invalid badoo.bma.PaymentProductType provided: " + r)));
                    var u = {
                        product_type: r
                    };
                    return o && (u.type = o), n && (u.user_id = n), s && (u.context = s), c && (u.promo_block_type = c), e.prototype.get.call(this, u)
                }, t
            }(n.A);
            s.instance = null, t.A = s
        },
        33926: function(e, t, r) {
            r.d(t, {
                P: function() {
                    return o
                }
            });
            var n = r(84362),
                i = r(40075),
                a = r(74848);

            function o(e) {
                return e + '<span class="csms-a11y-visually-hidden"> ' + i.Ay.get(618) + "</span>"
            }
            t.A = function(e) {
                var t = e.children,
                    r = i.Ay.get(618);
                return (0, a.jsxs)(a.Fragment, {
                    children: [t, (0, a.jsx)(n.A, {
                        children: r
                    })]
                })
            }
        },
        34256: function(e, t, r) {
            r.d(t, {
                d: function() {
                    return a
                }
            });
            var n = r(96540),
                i = r(7802),
                a = function() {
                    var e = (0, n.useState)(!1),
                        t = e[0],
                        r = e[1];
                    return (0, n.useEffect)((function() {
                        function e(e) {
                            r(e)
                        }
                        return i.q.changeEvent.subscribe(e),
                            function() {
                                i.q.changeEvent.unsubscribe(e)
                            }
                    }), []), t
                }
        },
        39403: function(e, t, r) {
            r.d(t, {
                F: function() {
                    return c
                },
                l: function() {
                    return s
                }
            });
            r(2892), r(42762);
            var n = r(63334),
                i = r(3208),
                a = r(57998),
                o = r(32308);

            function s(e, t) {
                var r = c(t),
                    o = function(e, t) {
                        var r, o = {
                            auto_top_up: Boolean(t.autoTopup),
                            result_url: (0, n.B)(),
                            browser_info: a.T.getInfo()
                        };
                        t.plaidInstitutionId && (o.plaid_institution_id = t.plaidInstitutionId);
                        t.uid && (o.uid = t.uid, o.initiated_from_instant_paywall = Boolean(t.isInstantPayWall));
                        e && (o.product_type = Number(e));
                        t.promoBlockVariantId && (o.promo_block_variant_id = String(t.promoBlockVariantId));
                        t.provider && (o.provider = t.provider);
                        t.promoBlockType && (o.promo_block_type = t.promoBlockType);
                        t.providerId && (o.provider_id = t.providerId);
                        t.sharingProviderType && (o.sharing_provider_type = t.sharingProviderType);
                        12 === t.productType && (o.chat_initial_screen_type = 19);
                        t.context ? o.context = t.context : null != (r = t.chatMessage) && r.context && (o.context = t.chatMessage.context);
                        t.priceToken && (o.price_token = t.priceToken);
                        t.threatmetrixSessionId && (o.threatmetrix_session_id = t.threatmetrixSessionId);
                        t.threatmetrixProfilingStatus && (o.threatmetrix_profiling_status = t.threatmetrixProfilingStatus);
                        t.billingEmail && (o.billing_email = t.billingEmail);
                        t.ignoreStoredDetails && (o.ignore_stored_details = t.ignoreStoredDetails);
                        t.hpActivationPlaceId && (o.hp_activation_place_id = t.hpActivationPlaceId);
                        t.googlePayToken && (o.google_pay_token = t.googlePayToken);
                        o.unique_flow_id = i.A.get(), t.deviceProfilingId && (o.device_profiling_id = t.deviceProfilingId);
                        return o
                    }(e, t);
                return o.purchase_params = r, o
            }

            function c(e) {
                var t = {
                    msisdn: e.msisdn
                };
                if (e.userId && (t.user_id = String(e.userId)), e.chatMessage) {
                    var r = function(e, t) {
                            var r = {},
                                n = e.messageType;
                            if ((0, o.Rg)(n) || (n = 1), r.type = n, t && (r.to_user_id = String(t)), e.gift) {
                                var i = e.gift;
                                r.gift_is_private = Boolean(i.getIsPrivate()), r.gift_product_id = Number(i.getGift().getProductId()), r.message_text = String(i.getText())
                            }
                            if (e.message && (r.message_text = String(e.message)), e.id && (r.client_message_id = String(e.id)), 23 === e.messageType && (r.sticker_id = String(e.image.id)), e.gif) {
                                var a = {
                                    type: e.gif.provider
                                };
                                e.gif.image && (a.aspect_ratio = e.gif.image.ratio), r.gif_info = a
                            }
                            return r
                        }(e.chatMessage, e.userId),
                        n = function(e) {
                            var t = e.gift_product_id;
                            if (t) return {
                                gift_product_id: t,
                                text: e.message_text || "",
                                is_private: e.gift_is_private || !1
                            }
                        }(r);
                    n && (t.gift_params = n), t.chat_message_params = r
                }
                if (e.stickerPackId && (t.sticker_pack_id = String(e.stickerPackId)), e.crossSellOrderId && (t.cross_sell_order_id = String(e.crossSellOrderId)), e.photoId && (t.photo_id = e.photoId), e.productToActivate && (t.product_to_activate = e.productToActivate), e.billingInfo) {
                    var i = 195 === e.provider,
                        a = e.billingInfo,
                        s = {},
                        c = {},
                        u = {
                            id: Number(a.city.id),
                            name: a.city.name
                        };
                    i && (u.name = a.city.name.split(",")[0].trim(), c = {
                        value: String(a.document),
                        type: 1
                    }), a.region && (s = {
                        id: Number(a.region.id),
                        name: a.region.name,
                        abbreviation: a.region.abbreviation
                    }), t.billing_info = {
                        full_name: a.fullName,
                        tax_id: String(a.taxId),
                        postcode: a.postcode,
                        street_address: a.streetAddress,
                        phone: a.phone,
                        email: a.email,
                        address_number: a.addressNumber,
                        document: c,
                        city: u,
                        region: s
                    }
                }
                return t
            }
        },
        41025: function(e, t, r) {
            r.d(t, {
                A: function() {
                    return y
                }
            });
            r(52675), r(45700), r(2008), r(51629), r(89572), r(2892), r(67945), r(84185), r(83851), r(81278), r(79432), r(26099), r(27495), r(98992), r(54520), r(3949), r(23500), r(99417);
            var n, i, a = r(74389),
                o = r(58385),
                s = r(18084),
                c = r(3208),
                u = r(30711),
                l = r(93529),
                d = r(79860);

            function p(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function f(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? p(Object(r), !0).forEach((function(t) {
                        h(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : p(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function h(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var g = s.A.getLogger("RouteHelper"),
                v = ((n = {})[u.f.EXTRA] = 818, n[u.f.SPP] = 8, n[u.f.PREMIUM_PLUS] = 557, n),
                m = ((i = {})[u.f.EXTRA] = 66, i[u.f.SPP] = 1, i[u.f.PREMIUM_PLUS] = 47, i),
                y = function() {
                    function e() {}
                    return e.navigateToPayment = function(e, t) {
                        if (e.productType) {
                            var r = t || {},
                                n = r.existingPaymentFlowId,
                                i = r.paymentTransitionInFlow,
                                s = void 0 !== i && i,
                                u = r.replace,
                                l = void 0 !== u && u,
                                d = f(f({}, e), {}, {
                                    paymentFlowId: n || c.A.get()
                                }),
                                p = s ? a.x.PAY : a.x.PAY_OVERLAY;
                            0, o.A.navigate(p, l, d)
                        } else g.error("Trying to navigate to payment without productType")
                    }, e.navigateToTierPaywall = function(t, r) {
                        if (r) l.A.showNotification({
                            type: l.A.TYPES.ERROR,
                            text: r.error_message
                        });
                        else {
                            var n = v[t],
                                i = m[t];
                            (0, d.sx)(139, {
                                banner_id: n,
                                position_id: 29,
                                context: 8,
                                call_to_action_type: 1
                            }), e.navigateToPayment({
                                hotPanelData: {
                                    activationPlace: 364
                                },
                                productType: i,
                                back: o.A.getUrl()
                            })
                        }
                    }, e
                }()
        },
        47632: function(e, t, r) {
            r(74423), r(26099), r(3362);
            var n, i, a = r(99417),
                o = r(18084),
                s = r(79880),
                c = {
                    SYMBOL: "symbol",
                    URL: "url"
                },
                u = o.A.getLogger("ImageHelper"),
                l = ((n = {})[56] = "badge-feature-attention-boost", n[96] = "badge-feature-crush", n[59] = "badge-feature-chat-quota", n[58] = "badge-feature-chat-quota", n[5] = "badge-feature-chat-with-tired", n[4] = "badge-feature-chat-with-newbies", n[8] = "badge-feature-premium", n[10] = "badge-feature-extra-shows", n[11] = "badge-feature-extra-shows", n[48] = "badge-feature-extra-shows", n[6] = "badge-feature-favourites", n[7] = "badge-feature-liked-you", n[38] = "badge-feature-liked-you", n[1] = "badge-feature-riseup", n[24] = "badge-gift", n[3] = "badge-feature-special-delivery", n[16] = "badge-feature-special-delivery", n[40] = "badge-feature-special-delivery", n[12] = "badge-add-photos", n[37] = "badge-feature-invisible-mode", n[43] = "badge-feature-undo", n[35] = "badge-feature-undo", n[57] = "badge-feature-bundle-sale", n[165] = "badge-chat", n[160] = "badge-chat", n[41] = null, n[388] = "badge-feature-read-receipt", n[119] = "badge-no-advert", n),
                d = ((i = {})[3] = f(6), i[4] = f(7), i[5] = f(1), i[7] = f(10), i[8] = f(8), i[9] = "badge-coin", i[18] = f(4), i[22] = f(43), i[25] = "badge-provider-instagram", i[26] = f(56), i[27] = f(57), i[28] = f(48), i[29] = f(59), i[54] = f(160), i[30] = f(58), i[32] = "badge-provider-facebook", i[33] = "badge-provider-vkontakte", i[34] = "badge-plus", i[37] = f(7), i[40] = f(96), i[19] = "badge-feature-special-delivery", i[1] = null, i),
                p = {
                    getImageUrlForSize: s.A,
                    getPlaceholderForGender: function(e) {
                        var t;
                        switch (e) {
                            case "male":
                            case 1:
                                t = "avatar-placeholder-male";
                                break;
                            case "female":
                            case 2:
                                t = "avatar-placeholder-female";
                                break;
                            default:
                                t = "avatar-placeholder-unknown"
                        }
                        return {
                            type: c.SYMBOL,
                            value: t
                        }
                    },
                    getBadgeName: function(e) {
                        var t = d[e] || null;
                        return void 0 === t && u.error("Badge name not supported for NotificationBadgeType " + e), t
                    },
                    getBadgeTypeFromFeature: function(e) {
                        switch (e) {
                            case 127:
                                return f(56);
                            case 18:
                                return "badge-feature-chat-quota";
                            case 32:
                                return f(10);
                            case 15:
                                return "badge-feature-extra-votes";
                            case 50:
                            case 8:
                                return f(6);
                            case 42:
                                return f(7);
                            case 28:
                                return f(1)
                        }
                        u.warn("FeatureType to an icon not mapped: " + e + ".")
                    },
                    getOrientation: function(e) {
                        var t = a.A.FileReader,
                            r = a.A.DataView;
                        return null != t && t.prototype.readAsArrayBuffer && r ? new Promise((function(n) {
                            var i = a.A.document.createElement("img");
                            i.onload = function() {
                                if (1 === i.width && 2 === i.height) return n(0);
                                var a = new t;
                                a.onload = function(e) {
                                    var t, i = new r(null == (t = e.target) ? void 0 : t.result);
                                    if (65496 !== i.getUint16(0, !1)) return n(-2);
                                    for (var a = i.byteLength, o = 2; o < a;) {
                                        var s = i.getUint16(o, !1);
                                        if (o += 2, 65505 === s) {
                                            if (1165519206 !== i.getUint32(o += 2, !1)) return n(-1);
                                            var c = 18761 === i.getUint16(o += 6, !1);
                                            o += i.getUint32(o + 4, c);
                                            var u = i.getUint16(o, c);
                                            o += 2;
                                            for (var l = 0; l < u; l++)
                                                if (274 === i.getUint16(o + 12 * l, c)) return n(i.getUint16(o + 12 * l + 8, c))
                                        } else {
                                            if (65280 & ~s) break;
                                            o += i.getUint16(o, !1)
                                        }
                                    }
                                    return n(-1)
                                }, a.readAsArrayBuffer(function(e) {
                                    var t = 65536;
                                    return e.slice ? e.slice(0, t) : e.webkitSlice ? e.webkitSlice(0, t) : e
                                }(e))
                            }, i.src = "data:image/jpeg;base64,/9j/4QAiRXhpZgAATU0AKgAAAAgAAQESAAMAAAABAAYAAAAAAAD/2wCEAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/AABEIAAEAAgMBEQACEQEDEQH/xABKAAEAAAAAAAAAAAAAAAAAAAALEAEAAAAAAAAAAAAAAAAAAAAAAQEAAAAAAAAAAAAAAAAAAAAAEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwA/8H//2Q=="
                        })) : Promise.resolve(-1)
                    },
                    getOrientationFromExifValue: function(e) {
                        switch (e) {
                            case 3:
                            case 4:
                                return 180;
                            case 5:
                            case 6:
                                return 90;
                            case 7:
                            case 8:
                                return -90;
                            default:
                                return 0
                        }
                    },
                    rotateBase64: function(e, t, r) {
                        return new Promise((function(n, i) {
                            var o = a.A.document.createElement("canvas"),
                                s = o.getContext("2d"),
                                c = new a.A.Image,
                                u = [5, 6, 7, 8, 90].includes(Math.abs(t));
                            c.src = e, c.onerror = i, c.onload = function() {
                                var e = u ? c.width : c.height,
                                    i = u ? c.height : c.width,
                                    l = u ? a.A.innerHeight : a.A.innerWidth,
                                    d = r ? l / i : 1,
                                    p = c.height * d,
                                    f = c.width * d;
                                if (o.height = e * d, o.width = i * d, s) {
                                    switch (t) {
                                        case 5:
                                        case 6:
                                        case 90:
                                            s.translate(p, 0), s.rotate(Math.PI / 2);
                                            break;
                                        case 3:
                                        case 4:
                                        case 180:
                                            s.translate(f, p), s.rotate(Math.PI);
                                            break;
                                        case 7:
                                        case 8:
                                        case -90:
                                            s.translate(0, f), s.rotate(-Math.PI / 2)
                                    }
                                    s.drawImage(c, 0, 0, f, p), n(o.toDataURL("image/jpeg"))
                                }
                            }
                        }))
                    },
                    getBadgeTypeFromPromoBlock: f,
                    IMAGE_TYPE: c
                };

            function f(e) {
                var t = l[e] || null;
                return t || u.warn("Badge type not supported for PromoBlockType " + e), t
            }
            t.A = p
        },
        49683: function(e, t, r) {
            r.d(t, {
                i: function() {
                    return O
                }
            });
            r(10287), r(25276), r(26099), r(58940), r(3362), r(27495), r(38781), r(71761);
            var n, i = r(99562),
                a = r(6696),
                o = r(32308),
                s = r(31709),
                c = r(23149),
                u = r(47344),
                l = r(93529),
                d = r(59179),
                p = r(32411),
                f = r(39403),
                h = r(63334),
                g = r(10031),
                v = r(30922),
                m = r(13315),
                y = r(67556),
                P = r(75248),
                A = r(25093),
                E = r(41298);

            function _(e, t) {
                return _ = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, _(e, t)
            }
            var b = {},
                T = function(e) {
                    function t() {
                        var t;
                        return (t = e.call(this, {}, {
                            name: "PaymentsModel",
                            useCache: !1
                        }) || this).fetchProductExplanation = function(e, t, r, n) {
                            return p.A.getInstance().getProductExplanation({
                                productType: e,
                                userId: t,
                                explanationType: r,
                                clientSource: n
                            })
                        }, t
                    }
                    var r, n;
                    n = e, (r = t).prototype = Object.create(n.prototype), r.prototype.constructor = r, _(r, n);
                    var a = t.prototype;
                    return a.init = function() {
                        P.A.getInstance().on(P.A.Type.NOTIFICATION, S, this)
                    }, a.getPaymentReceipt = function(e) {
                        if ("string" != typeof e._id || "string" != typeof e._pid) return (0, E.A)(Promise.reject(new Error("Missing _id or _pid when trying to get receipt")));
                        var t = e._id,
                            r = function(e) {
                                return !e.success || "true" === e.success.toString()
                            }(e),
                            n = {
                                transaction_identifier: t,
                                payment_success: r
                            },
                            i = parseInt(e._p, 10);
                        (0, o.Rg)(i) && (n.provider = i);
                        var a = parseInt(e._pid, 10);
                        isNaN(a) || (n.provider_id = a), "string" == typeof e.uid && (n.product_uid = e.uid), e.cancellation_reason && (0, o.Rg)(e.cancellation_reason) && (n.cancellation_reason = e.cancellation_reason), "cancellation_reason" in n || (n.cancellation_reason = "error_type" in e ? 2 : 0);
                        var s = y.K.remove(t);
                        if (null != s && s.billingEmail && (n.billing_email = s.billingEmail), 113 === i || 117 === i || 180 === i) r && (e._receipt_data && (n.receipt_data = e._receipt_data), e._receipt_signature && (n.receipt_signature = e._receipt_signature));
                        else {
                            var u = function(e) {
                                (0, c.A)(e) || (e = {});
                                return function(e) {
                                    var t = e.url.match(/\?/) ? e.url : e.url + "/?";
                                    for (var r in e.params) {
                                        t += r + "=" + (e.nonEncodedKeys && e.nonEncodedKeys.indexOf(r) > -1 ? e.params[r] : encodeURIComponent(e.params[r])) + "&"
                                    }
                                    return t.substring(0, t.length - 1)
                                }({
                                    url: (0, h.B)(),
                                    params: e
                                })
                            }(e);
                            u && (n.receipt_data = u)
                        }
                        return this.sendReceipt(n)
                    }, a.sendReceipt = function(e) {
                        return (0, i.Y)({
                            requestType: 154,
                            responseType: 173,
                            message: e
                        })
                    }, a.startTransaction = function(e, t) {
                        e.isInstantPayWall = d.A.getInstance().canUseInstantPaywall(e.productType);
                        var r = (0, f.l)(e.productType, e);
                        this.sendPurchaseTransaction(r, e, t)
                    }, a.startTransactionAsPromise = function(e) {
                        var t = this;
                        return (0, E.A)(new Promise((function(r, n) {
                            t.startTransaction(e, (function(e) {
                                var t = e.error;
                                t ? n(t) : r(e)
                            }))
                        })))
                    }, a.sendPurchaseTransaction = function(e, r, n) {
                        var i = this,
                            a = (0, u.A)(n),
                            o = {};
                        new s.Ay(166, e).onResponse(167, (function(e) {
                            i.trigger(t.EVENTS.SUCCESS, null, e, r), o.purchaseTransaction = e, o.data = r
                        })).onResponse(168, (function(n) {
                            i.trigger(t.EVENTS.FAILURE, null, n, r), n ? I(n.transaction_id, m.A.RESULTS.FAILURE) : i.log.error("Missing purchaseTransactionFailed info from failed transaction.", {
                                data: r,
                                purchaseTransactionFailed: n,
                                purchaseTransactionSetup: e
                            }), o.purchaseTransactionFailed = n
                        })).onResponse(173, (function(e) {
                            i.trigger(t.EVENTS.RECEIPT, null, e, r), e && I(e.transaction_identifier, m.A.RESULTS.PENDING), o.clientPurchaseReceipt = e
                        })).onResponse(153, (function(e) {
                            o.featureProductList = e
                        })).onResponse(1, (function(e) {
                            o.error = e
                        })).onError((function(t) {
                            t && t.type !== s.a5.HANDLER_UNSATISFIED && ((0, A.A)(t) && i.log.error("Error sending a PurchaseTransaction.", {
                                data: r,
                                error: t,
                                purchaseTransactionSetup: e
                            }), o.error || (o.error = t))
                        })).onSpecialEvent(s.SE.REQ_FINISHED, (function() {
                            a(o)
                        })).setIsSynchronous(Boolean(r.useSync)).request()
                    }, a.tryCreditsPurchase = function(e, t) {
                        this.startTransaction(e, (function(e) {
                            var r = e.error,
                                n = e.clientPurchaseReceipt,
                                i = e.purchaseTransactionFailed;
                            if (r || !n) {
                                var a, o;
                                if (i && O(e)) a = null == (o = i.form_error) || null == (o = o.failure) ? void 0 : o.error_message;
                                else null != i && i.notification && (a = i.notification.message);
                                a && l.A.showNotification({
                                    type: l.A.TYPES.ERROR,
                                    text: a
                                }), e.error = e.error || new Error("Not able to purchase credits in tryCreditsPurchase")
                            }
                            t(e)
                        }))
                    }, a.validateMerchant = function(e) {
                        var t = {
                            validation_url: e.validationURL,
                            transaction_id: e.transactionId
                        };
                        return (0, i.Y)({
                            requestType: 738,
                            responseType: 739,
                            message: t
                        })
                    }, t
                }(a.A);

            function S(e) {
                e && (46 === e.type ? (v.A.processClientNotification(e), I(e.transaction_identifier, m.A.RESULTS.SUCCESS)) : 49 === e.type && (v.A.processClientNotification(e), I(e.transaction_identifier, m.A.RESULTS.FAILURE)))
            }

            function I(e, t) {
                e || m.A.getInstance().setResult(t);
                var r = b[e];
                (!r || r.state !== t && t !== m.A.RESULTS.PENDING) && (r = {
                    state: t,
                    paymentStateUpdated: !1
                }, b[e] = r), r.paymentStateUpdated && t !== m.A.RESULTS.PENDING || (m.A.getInstance().setResult(r.state), r.paymentStateUpdated = !0)
            }

            function O(e) {
                return (0, g.Q)(null == e ? void 0 : e.purchaseTransactionFailed)
            }
            n = T, T.EVENTS = {
                SUCCESS: "payment-success",
                FAILURE: "payment-failure",
                RECEIPT: "payment-receipt"
            }, T.instance = null, T.getInstance = function() {
                return n.instance || (n.instance = new n), n.instance
            }, t.A = T
        },
        49711: function(e, t, r) {
            var n;
            r.d(t, {
                    P: function() {
                        return n
                    }
                }),
                function(e) {
                    e.DEFAULT = "DEFAULT", e.EXTRA = "EXTRA", e.SPP = "SPP", e.PREMIUM_PLUS = "PREMIUM_PLUS"
                }(n || (n = {}))
        },
        51438: function(e, t, r) {
            r.d(t, {
                D$: function() {
                    return S
                },
                D4: function() {
                    return I
                },
                Im: function() {
                    return E
                },
                Np: function() {
                    return C
                },
                QO: function() {
                    return y
                },
                UM: function() {
                    return b
                },
                a_: function() {
                    return _
                },
                eV: function() {
                    return T
                },
                s$: function() {
                    return O
                }
            });
            r(52675), r(45700), r(2008), r(50113), r(51629), r(25276), r(89572), r(2892), r(67945), r(84185), r(83851), r(81278), r(79432), r(26099), r(98992), r(54520), r(72577), r(3949), r(23500);
            var n = r(32308),
                i = r(79860),
                a = r(18084),
                o = r(71672),
                s = r(69978),
                c = r(3208);

            function u(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function l(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(r), !0).forEach((function(t) {
                        d(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : u(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function d(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var p, f, h, g = "trackedPaymentFlowIds",
                v = [],
                m = a.A.getLogger("PaymentTracker"),
                y = {
                    CANCELLED: 1,
                    SUCCESS: 3,
                    FAILURE: 2
                };

            function P(e) {
                var t = 1;
                return void 0 === e ? t = 3 : e && (t = 2), t
            }

            function A() {
                return o.A.getArray(g) || []
            }

            function E(e, t, r, a) {
                if (void 0 === a && (a = {}), function(e) {
                        return Boolean(A().find((function(t) {
                            return t.id === e
                        })))
                    }(e = e || c.A.get())) return e;
                var u;
                (0, n.Rg)(r) || (r = 1);
                var d = function(e) {
                    var t = (0, s.z)(e);
                    return t || m.error("No product enum for specified productType", {
                        productType: e
                    }), t
                }(t);
                return d && (u = d), u ? ((0, i.sx)(54, l({
                    uid: e,
                    activation_place: r,
                    product: u
                }, a)), function(e) {
                    var t = A();
                    t.push({
                        id: e,
                        date: (new Date).getTime()
                    }), o.A.saveArray(g, t)
                }(e), e) : (m.error("Missing required product type. ", {
                    inputFeature: t
                }), "")
            }

            function _(e, t, r) {
                "string" == typeof e && (0, i.sx)(46, {
                    uid: e,
                    provider_id: t,
                    product_id: r
                })
            }

            function b(e, t, r) {
                var n;
                "string" == typeof e && ("boolean" == typeof t && (n = P(t)), (0, i.sx)(109, l({
                    uid: e,
                    auto_topup: n
                }, r)))
            }

            function T(e, t, r) {
                if ("string" == typeof e) {
                    var n = P(t);
                    (0, i.sx)(112, l({
                        uid: e,
                        auto_topup: n
                    }, r))
                }
            }

            function S(e, t, r) {
                var n;
                "string" == typeof e && ("boolean" == typeof t && (n = P(t)), (0, i.sx)(111, l({
                    uid: e,
                    auto_topup: n
                }, r)))
            }

            function I(e, t) {
                if ("string" == typeof e) {
                    var r = P(t);
                    (0, i.sx)(113, {
                        uid: e,
                        auto_topup: r
                    })
                }
            }

            function O(e, t, r) {
                if ("string" == typeof e) {
                    var n = P(t);
                    (0, i.sx)(114, l({
                        uid: e,
                        auto_topup: n
                    }, r))
                }
            }

            function C(e, t, r) {
                if ("string" == typeof e) {
                    var n = t + ":" + e; - 1 === v.indexOf(n) ? (v.push(n), (0, i.sx)(115, {
                        uid: e,
                        result: t,
                        event_version: r
                    })) : m.warn("Payment tracker tried to track multiple times the payment with result state as " + t + ".", e)
                }
            }
            p = 1728e5, f = (new Date).getTime(), h = A().filter((function(e) {
                return f - e.date < p
            })), o.A.saveArray(g, h)
        },
        54129: function(e, t, r) {
            function n(e) {
                return 192 === (null == e ? void 0 : e.provider)
            }
            r.d(t, {
                R: function() {
                    return n
                }
            })
        },
        55272: function(e, t, r) {
            function n(e) {
                return 180 === (null == e ? void 0 : e.provider)
            }
            r.d(t, {
                K: function() {
                    return n
                }
            })
        },
        56217: function(e, t, r) {
            r.d(t, {
                H: function() {
                    return n
                }
            });
            r(50113), r(26099), r(98992), r(72577);

            function n(e, t) {
                var r = e.find((function(e) {
                    return e.provider_id === t
                }));
                return null == r ? void 0 : r.default_product_uid
            }
        },
        58478: function(e, t, r) {
            r.d(t, {
                D: function() {
                    return a
                },
                V: function() {
                    return o
                }
            });
            var n = r(58385),
                i = r(74389),
                a = function(e) {
                    var t = null == e ? void 0 : e.start_transaction_to_display_wizard,
                        r = null == e ? void 0 : e.prefilled_billing_info;
                    return !1 === t && r
                },
                o = function(e, t, r, a) {
                    n.A.navigate(i.x.ADD_BILLING_INFO, !0, {
                        purchase: t,
                        selectedProvider: e,
                        deviceProfilingId: r,
                        tnc: a
                    })
                }
        },
        59028: function(e, t, r) {
            r(10287), r(26099), r(3362);
            var n = r(6696),
                i = r(99562),
                a = r(32308),
                o = r(31709),
                s = r(41298);

            function c(e, t) {
                return c = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, c(e, t)
            }
            var u = function(e) {
                function t() {
                    var t;
                    return (t = e.call(this, {
                        get: {
                            message: 182,
                            response: 183
                        },
                        set: {
                            message: 195,
                            response: 196
                        }
                    }, {
                        name: "PaymentSettings",
                        useCache: !1
                    }) || this).removeStoredPayment = function(e) {
                        if (!e) return (0, s.A)(Promise.reject(new Error("Missing payment id when trying to remove stored payment")));
                        var t = {
                            value: e
                        };
                        return (0, i.e)({
                            requestType: 197,
                            responseType: 198,
                            message: t
                        })
                    }, t.unsubscribe = function(e, t) {
                        if (!(0, a.Rg)(e)) return (0, s.A)(Promise.reject(new Error("Invalid SubscriptionType provided: " + e)));
                        var r = {
                            type: e,
                            client_unsubscribe_alternative_supported: Boolean(t)
                        };
                        return (0, s.A)(new Promise((function(e, t) {
                            var n = {},
                                i = !1,
                                a = function(e) {
                                    e && e.type !== o.a5.HANDLER_UNSATISFIED && (i = !0, t(e))
                                };
                            new o.Ay(464, r).onResponse(483, (function(e) {
                                n.unsubscribeAlternative = e
                            })).onResponse(1, a).onError(a).onSpecialEvent(o.SE.REQ_FINISHED, (function() {
                                i || e(n)
                            })).request()
                        })))
                    }, t
                }
                var r, n;
                return n = e, (r = t).prototype = Object.create(n.prototype), r.prototype.constructor = r, c(r, n), t.getInstance = function() {
                    return t.instance || (t.instance = new t), t.instance
                }, t.prototype.removeAutoTopup = function() {
                    return this.set()
                }, t
            }(n.A);
            u.instance = void 0, t.A = u
        },
        59179: function(e, t, r) {
            r.d(t, {
                A: function() {
                    return H
                }
            });
            r(52675), r(45700), r(89572), r(2892), r(67945), r(84185), r(83851), r(81278), r(79432), r(10287), r(2008), r(51629), r(74423), r(23792), r(72712), r(26099), r(3362), r(21699), r(98992), r(54520), r(3949), r(8872), r(23500), r(62953);
            var n = r(31709),
                i = r(72537),
                a = r(6696),
                o = r(73090),
                s = r(41298),
                c = r(8054),
                u = r(14153),
                l = r(83183),
                d = r(75248),
                p = (r(50113), r(23418), r(31415), r(47764), r(72577), r(99417)),
                f = r(41051),
                h = r(25093);

            function g(e, t) {
                return g = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, g(e, t)
            }
            var v = function(e) {
                function t() {
                    var r;
                    return (r = e.call(this, {
                        get: {
                            message: 749,
                            response: 750
                        }
                    }, {
                        name: "ServerSyncInstantPaywallsModel",
                        useCache: !1
                    }) || this).origin = 0, r.retryLaterTimeout = -1, r.cacheActionTypeReplaceWithResponse = function(e, n) {
                        var i = P(n, e.product_type);
                        r.sendStats(i, e), r.trigger(t.EVENTS.CACHE, e)
                    }, r.cacheActionTypeUseExisting = function(e, t) {
                        var n = P(t, e.product_type);
                        r.setAvailableProducts(n)
                    }, r.cacheActionTypeDropAndRetryLater = function(e, t) {
                        var n = e.product_type,
                            i = e.retry_in_sec,
                            a = P(t, n);
                        r.sendStats(a, e), r.dropFeatureProductListCache(n), p.A.clearTimeout(r.retryLaterTimeout), r.retryLaterTimeout = p.A.setTimeout(r.handleEmptyCacheCase, 1e3 * i)
                    }, r.cacheActionTypeDropAndFallback = function(e) {
                        var n = e.product_type;
                        r.dropFeatureProductListCache(n), 13 !== n && 1 !== n || r.trigger(t.EVENTS.PRELOAD_PAYWALLS, n)
                    }, r.cacheActionTypeUndefined = function(e) {
                        r.dropFeatureProductListCache(void 0), r.handleEmptyCacheCase()
                    }, r.handleSyncedPaywallsResponse = function(e, t) {
                        var n = (null == e ? void 0 : e.paywalls) || [];
                        0 === n.length && r.handleEmptyCacheCase(), n.forEach((function(e) {
                            r.setAvailableProducts(e);
                            var n = e.cache_action;
                            r.getPaywallHandler(n)(e, t), 0 === t.length && [2, 3].includes(n)
                        }))
                    }, r.handleEmptyCacheCase = function() {
                        r.trigger(t.EVENTS.PRELOAD_PAYWALLS)
                    }, r
                }
                var r, n;
                n = e, (r = t).prototype = Object.create(n.prototype), r.prototype.constructor = r, g(r, n), t.getInstance = function() {
                    return t.instance || (t.instance = new t), t.instance
                };
                var i = t.prototype;
                return i.getSyncedPaywalls = function(e) {
                    var t = {
                        cached_paywalls: this.getCachedPaywallProductRequest(e)
                    };
                    return this.get(t)
                }, i.setOrigin = function(e) {
                    this.origin = e
                }, i.syncInstantPaywalls = function(e, t) {
                    var r = this;
                    t && this.setOrigin(t), this.getSyncedPaywalls(e).then((function(t) {
                        r.handleSyncedPaywallsResponse(t, e)
                    })).catch((function(e) {
                        (0, h.A)(e) && r.log.error("Failed to sync Instant Paywalls", {
                            error: e
                        })
                    }))
                }, i.getPaywallHandler = function(e) {
                    switch (e) {
                        case 1:
                            return this.cacheActionTypeReplaceWithResponse;
                        case 2:
                            return this.cacheActionTypeUseExisting;
                        case 3:
                            return this.cacheActionTypeDropAndRetryLater;
                        case 4:
                            return this.cacheActionTypeDropAndFallback;
                        default:
                            return this.cacheActionTypeUndefined
                    }
                }, i.dropFeatureProductListCache = function(e) {
                    e ? this.trigger(t.EVENTS.INVALIDATE, e) : this.trigger(t.EVENTS.INVALIDATE_ALL, !0)
                }, i.setAvailableProducts = function(e) {
                    var r = e.paywall_data;
                    Boolean(null == r ? void 0 : r.available_products) && this.trigger(t.EVENTS.UPDATE_PRODUCTS, r)
                }, i.sendStats = function(e, t) {
                    var r = {
                        cachedPaywallId: m(e),
                        freshPaywallId: m(t),
                        cachedPaywallPriceTokens: y(e),
                        freshPaywallPriceTokens: y(t),
                        refreshOrigin: this.origin
                    };
                    f.A.sendCachedPaywallsUpdatedStats(r)
                }, i.getCachedPaywallProductRequest = function(e) {
                    var t = this;
                    return void 0 === e && (e = []), e.reduce((function(e, r) {
                        var n = r.paywall_data,
                            i = null == n ? void 0 : n.product_type;
                        if (i) {
                            var a = {
                                product_type: i
                            };
                            r.request_mode && (a.request_mode = r.request_mode);
                            var o = null == n ? void 0 : n.identifier;
                            o && (a.cached_instant_paywall_identifier = o), e.push(a)
                        } else t.log.error("ProductRequest: cached paywall has not productType", {
                            paywall: r
                        });
                        return e
                    }), [])
                }, t
            }(a.A);

            function m(e) {
                var t = null == e ? void 0 : e.paywall_data;
                return (null == t ? void 0 : t.identifier) || ""
            }

            function y(e) {
                var t = [],
                    r = null == e ? void 0 : e.paywall_data;
                return ((null == r ? void 0 : r.products) || []).forEach((function(e) {
                    (e.providers || []).forEach((function(e) {
                        var r = (null == e ? void 0 : e.price_token) || "";
                        t.push(r)
                    }))
                })), Array.from(new Set(t))
            }

            function P(e, t) {
                return t && e.find((function(e) {
                    return e.product_type === t
                })) || {}
            }
            v.EVENTS = {
                CACHE: "cache",
                INVALIDATE: "invalidate",
                INVALIDATE_ALL: "invalidate_all",
                INVALIDATED: "invalidated",
                PRELOAD_PAYWALLS: "preload_paywalls",
                UPDATE_PRODUCTS: "update_products"
            }, v.instance = null;
            var A = v,
                E = r(3508),
                _ = r(65869),
                b = r(36721),
                T = r(32308),
                S = r(3208);

            function I(e, t) {
                var r = {
                    experimental_is_for_instant_wizard: Boolean(null == t ? void 0 : t.isInstantPayWall),
                    product_type: e,
                    providers: (0, _.A)({
                        paymentProviderConfig: E.A.get("payment.providers"),
                        supportsApplePay: b.A.supportsApplePay(),
                        isTWA: b.A.isTWA()
                    }),
                    request_mode: 1
                };
                return t && (Array.isArray(t.providers) && (r.providers = t.providers), t.userId && (r.user_id = String(t.userId)), (0, T.Rg)(t.requestMode) && (r.request_mode = t.requestMode), (0, T.Rg)(t.promoBlockType) && (r.promo_block_type = t.promoBlockType), (0, T.Rg)(t.context) && (r.context = t.context), t.creditsForProduct && (r.credits_for_product = Number(t.creditsForProduct)), 12 === e && (r.chat_initial_screen_type = 19), t.promoCampaignId && (r.promo_campaign_id = t.promoCampaignId), t.ignoreStoredDetails && (r.ignore_stored_details = t.ignoreStoredDetails), r.unique_flow_id = S.A.get()), r
            }
            var O = function() {};
            O.getPaywallData = function(e, t) {
                var r = I(e, t);
                return (0, s.A)(new Promise((function(e, t) {
                    new n.Ay(630, r).onResponse(153, (function(t) {
                        e(t)
                    })).onResponse(1, (function(e) {
                        t(e)
                    })).onError((function(e) {
                        e && e.type !== n.a5.HANDLER_UNSATISFIED && t(e)
                    })).request()
                })))
            };
            var C = O,
                R = r(39403);
            var w = function() {
                function e() {}
                return e.getPaywallData = function(e, t) {
                    var r = function(e, t) {
                        return (0, R.l)(e, t)
                    }(e, t);
                    return (0, s.A)(new Promise((function(e, t) {
                        new n.Ay(644, r).onResponse(153, (function(t) {
                            e(t)
                        })).onResponse(1, (function(e) {
                            t(e)
                        })).onError((function(e) {
                            e && e.type !== n.a5.HANDLER_UNSATISFIED && t(e)
                        })).request()
                    })))
                }, e
            }();
            var D = r(63826);
            var L, j, U = r(107);

            function N(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function x(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function M(e, t) {
                return M = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, M(e, t)
            }! function(e) {
                e.EXTRA = "EXTRA", e.SPP = "SPP", e.PREMIUM_PLUS = "PREMIUM_PLUS", e.CREDITS = "CREDITS"
            }(j || (j = {}));
            var k = ((L = {})[j.EXTRA] = j.EXTRA, L[j.SPP] = j.SPP, L[j.PREMIUM_PLUS] = j.PREMIUM_PLUS, L[j.CREDITS] = j.CREDITS, L),
                F = 0,
                B = function(e) {
                    function t() {
                        var t;
                        return (t = e.call(this, {
                            get: {
                                message: 627,
                                response: 666
                            }
                        }, {
                            name: "FeatureProductListModel" + (b.A.isTWA() ? "_TWA" : b.A.isHuaweiQuickApp() ? "_HUAWEI" : "_MW"),
                            preventMultiple: !0
                        }) || this).instantProductTypes = [66, 1, 47, 13], t.serverSyncInstantPaywallsModel = void 0, t.serverSyncInstantPaywallsModel = A.getInstance(), t
                    }
                    var r, a;
                    a = e, (r = t).prototype = Object.create(a.prototype), r.prototype.constructor = r, M(r, a), t.getInstance = function() {
                        return t.instance || (t.instance = new t), t.instance
                    };
                    var c = t.prototype;
                    return c.init = function() {
                        var e = this;
                        this.serverSyncInstantPaywallsModel = A.getInstance(), d.A.getInstance().on(d.A.Type.SYSTEM_NOTIFICATION, (function(t) {
                            23 === t.id && (e.invalidateAll(!0), e.preloadInstantPaywalls(2))
                        }));
                        var t = i.A.getObservable(204);
                        i.A.observe(t, this.preloadInstantPaywall.bind(this), {
                            leading: !1
                        }), this.serverSyncInstantPaywallsModel.on(A.EVENTS.CACHE, this.cachePaywallData, this).on(A.EVENTS.INVALIDATE, this.invalidateByProductType, this).on(A.EVENTS.INVALIDATE_ALL, this.invalidateAll, this).on(A.EVENTS.PRELOAD_PAYWALLS, this.preloadPaywalls, this).on(A.EVENTS.UPDATE_PRODUCTS, this.setAvailableProducts, this), this.updateInstantProductTypesFromCache()
                    }, c.canUseInstantPaywall = function(e) {
                        var t, r = i.A.getSync(204).enabled,
                            n = Boolean(e && (null == (t = this.cache) ? void 0 : t.get(G(e)))),
                            a = !e || this.instantProductTypes.includes(e);
                        return r && a && !n
                    }, c.setInstantProductTypes = function(e) {
                        Array.isArray(e) && (this.instantProductTypes = e)
                    }, c.updateInstantProductTypesFromCache = function() {
                        var e = this;
                        this.getCachedInstantPayWalls().forEach((function(t) {
                            var r = t.paywall_data;
                            (null == r ? void 0 : r.available_products) && e.setAvailableProducts(r)
                        }))
                    }, c.getInstantPaywall = function(e) {
                        var t, r = this.getCacheKey(627, e),
                            i = null == (t = this.cache) ? void 0 : t.get(r);
                        if (!e.ignore_stored_details && null != i && i.length) {
                            i.fromCache = !0;
                            var a = i[0];
                            return Promise.resolve({
                                productList: null == a ? void 0 : a.paywall_data
                            })
                        }
                        return new Promise((function(t, r) {
                            var i = {};
                            new n.Ay(627, e).onResponse(666, (function(e) {
                                i.productList = e.paywall_data
                            })).onResponse(629, (function(e) {
                                i.productListFailure = e
                            })).onResponse(1, (function(e) {
                                i.serverErrorMessage = e
                            })).onError((function(e) {
                                e && e.type !== n.a5.HANDLER_UNSATISFIED && r(e)
                            })).onSpecialEvent(n.SE.REQ_END, (function() {
                                t(i)
                            })).request()
                        }))
                    }, c.getByProduct = function(e, t) {
                        var r = this,
                            i = this.canUseInstantPaywall(e),
                            a = Boolean(this.getCachedInstantPayWalls(e).length),
                            o = W(e),
                            c = I(e, t),
                            u = i && (a || !o) ? this.getInstantPaywall(c) : function(e) {
                                return new Promise((function(t, r) {
                                    var i = {};
                                    new n.Ay(165, e).onResponse(153, (function(e) {
                                        i.productList = e
                                    })).onResponse(1, (function(e) {
                                        i.serverErrorMessage = e
                                    })).onError((function(e) {
                                        e && e.type !== n.a5.HANDLER_UNSATISFIED && r(e)
                                    })).onSpecialEvent(n.SE.REQ_END, (function() {
                                        t(i)
                                    })).request()
                                }))
                            }(c);
                        return (0, s.A)(u.then((function(n) {
                            var i = n.productList,
                                a = n.productListFailure,
                                o = n.serverErrorMessage;
                            if (o) throw o;
                            if (a) {
                                if (r.handleProductListFailure(e, a), null != t && t.background) return {};
                                r.getByProduct(e, t)
                            }
                            if (i) return c.ignore_stored_details || r.cachePaywallData(i), r.setAvailableProducts(i),
                                function(e, t) {
                                    if (e && t) {
                                        var r, n = function(e) {
                                                for (var t = 1; t < arguments.length; t++) {
                                                    var r = null != arguments[t] ? arguments[t] : {};
                                                    t % 2 ? N(Object(r), !0).forEach((function(t) {
                                                        x(e, t, r[t])
                                                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : N(Object(r)).forEach((function(t) {
                                                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                                                    }))
                                                }
                                                return e
                                            }({}, e),
                                            i = null == (r = n.products) ? void 0 : r.filter((function(e) {
                                                return !e.value || e.value >= t
                                            }));
                                        return n.products = i, n
                                    }
                                    return e
                                }(i, null == t ? void 0 : t.cost);
                            throw new Error("Retrieving featureProductList when the session has expired on SRV")
                        })).catch((function(t) {
                            throw r.disablePayWall(e), t
                        })))
                    }, c.getMultiplePaywalls = function() {
                        var e = this,
                            t = [13, 1];
                        (0, D.X)() && t.push(47), (0, U.M)() && t.push(66);
                        var r = [];
                        t.forEach((function(e) {
                            r.push({
                                message_type: 627,
                                body: I(e, {
                                    productType: e,
                                    background: !0
                                })
                            })
                        }));
                        var i = t.length,
                            a = [];
                        return new Promise((function(t, o) {
                            var s = function(r) {
                                    if (e.cachePaywallData(r), a.push(r), a.length === i) return t(a)
                                },
                                c = function(e) {
                                    if (e) {
                                        if ((0, u.i)(e) && e.type === n.a5.HANDLER_UNSATISFIED) return;
                                        var t = "";
                                        (0, l.P)(e) && (t = e.error_message), o(new Error(t))
                                    }
                                };
                            new n.Ay(628, r).onResponse(153, s).onResponse(666, s).onResponse(1, c).onError(c).request()
                        }))
                    }, c.getCacheTime = function() {
                        return 31536e6
                    }, c.cachePaywallData = function(e) {
                        F = Date.now();
                        var t = this.getCacheKey(627, e),
                            r = this.getCacheTime(),
                            n = function(e) {
                                return "paywall_data" in e
                            }(e) ? e : function(e) {
                                var t = e.product_type;
                                if (!t) return {};
                                return {
                                    product_type: t,
                                    request_mode: 1,
                                    paywall_data: e
                                }
                            }(e);
                        this.cacheResponse(t, r, n)
                    }, c.invalidateByProductType = function(e) {
                        var t = V(e);
                        this.invalidate(t, !1, !0)
                    }, c.handleProductListFailure = function(e, t) {
                        var r = t.retry_in_sec,
                            n = r ? 1e3 * r : r;
                        this.disablePayWall(e, n)
                    }, c.disablePayWall = function(e, t) {
                        var r;
                        t || (t = 9e5), null == (r = this.cache) || r.invalidate(G(e), !1, !0)
                    }, c.getContextPayWall = function(e, t) {
                        var r = this,
                            n = e || t.productType;
                        t.isInstantPayWall = this.canUseInstantPaywall(n);
                        var i = W(n) ? C.getPaywallData(n, t) : w.getPaywallData(n, t);
                        return i.catch((function(e) {
                            if (r.disablePayWall(n), !t.background) throw e;
                            r.log.warn(e)
                        })), i
                    }, c.getCacheKey = function(e, t) {
                        return V(t.product_type)
                    }, c.shouldCache = function(e) {
                        return 627 === e
                    }, c.handleCacheInvalidated = function(t) {
                        var r = this,
                            n = t.all,
                            i = t.keys,
                            a = t.fromWatchdog;
                        e.prototype.handleCacheInvalidated.call(this, t), this.canUseInstantPaywall() && !a && (n ? this.preloadInstantPaywall() : null == i || i.forEach((function(e) {
                            e === k.CREDITS ? r.preloadCreditsPaywall() : e === k.EXTRA ? r.preloadExtraPaywall() : e === k.SPP ? r.preloadSppPaywall() : e === k.PREMIUM_PLUS && r.preloadPremiumPlusPaywall()
                        })))
                    }, c.cacheResponse = function(t, r, n) {
                        var i = null == n ? void 0 : n.paywall_data;
                        if (i) {
                            var a, o = i.product_type;
                            if (o) null == (a = this.cache) || a.invalidate(G(o), !0);
                            return e.prototype.cacheResponse.call(this, t, r, n)
                        }
                        return n
                    }, c.getCachedInstantPayWalls = function(e) {
                        var t, r = this;
                        return ((null == (t = this.cache) ? void 0 : t.getKeys()) || []).reduce((function(t, n) {
                            if (k[n]) {
                                var i, a = null == (i = r.cache) ? void 0 : i.get(n);
                                if (a) {
                                    var o = Array.isArray(a) ? a[0] : a,
                                        s = o.product_type;
                                    (!e || e === s) && t.push(o)
                                }
                            }
                            return t
                        }), [])
                    }, c.preloadPaywalls = function(e) {
                        13 === e ? this.preloadCreditsPaywall() : 1 === e ? this.preloadSppPaywall() : 66 === e ? this.preloadExtraPaywall() : 47 === e ? this.preloadPremiumPlusPaywall() : this.getMultiplePaywalls().catch(Y)
                    }, c.preloadInstantPaywall = function() {
                        S.A.generate(), this.preloadCreditsPaywall(), this.preloadExtraPaywall(), this.preloadSppPaywall(), this.preloadPremiumPlusPaywall()
                    }, c.preloadInstantPaywalls = function(e) {
                        S.A.generate();
                        var t = this.getCachedInstantPayWalls();
                        this.serverSyncInstantPaywallsModel.syncInstantPaywalls(t, e)
                    }, c.preloadCreditsPaywall = function() {
                        var e = this;
                        if (i.A.getSync(204).enabled && o.A.isLoggedIn()) return this.getByProduct(13, {
                            background: !0,
                            productType: 13
                        }).then((function(t) {
                            t && e.setAvailableProducts(t)
                        })).catch(Y)
                    }, c.preloadExtraPaywall = function() {
                        if (i.A.getSync(204).enabled && o.A.isLoggedIn() && !i.A.getSync(19).enabled) return this.getByProduct(66, {
                            background: !0,
                            productType: 66
                        }).catch(Y)
                    }, c.preloadSppPaywall = function() {
                        if (i.A.getSync(204).enabled && o.A.isLoggedIn() && !i.A.getSync(19).enabled) return this.getByProduct(1, {
                            background: !0,
                            productType: 1
                        }).catch(Y)
                    }, c.preloadPremiumPlusPaywall = function() {
                        if (i.A.getSync(204).enabled && o.A.isLoggedIn() && (0, D.X)() && !i.A.getSync(19).enabled) return this.getByProduct(47, {
                            background: !0,
                            productType: 47
                        }).catch(Y)
                    }, c.setAvailableProducts = function(e) {
                        var t = e.available_products;
                        Boolean(t) && this.setInstantProductTypes(t)
                    }, t
                }(a.A);
            B.instance = null;
            var H = B;

            function G(e) {
                return "DID_PAYWALL_FAIL:" + e
            }

            function V(e) {
                switch (e) {
                    case 66:
                        return k.EXTRA;
                    case 1:
                        return k.SPP;
                    case 47:
                        return k.PREMIUM_PLUS;
                    default:
                        return k.CREDITS
                }
            }

            function W(e) {
                return 66 === e || 1 === e || 47 === e || 13 === e
            }

            function Y() {
                return !0
            }(0, c.A)({
                getLastInstantPaywallUpdate: function() {
                    return F
                }
            })
        },
        59244: function(e, t, r) {
            var n, i;
            r.d(t, {
                y: function() {
                    return s
                }
            });
            var a = ((n = {})[26] = "badge-feature-boost", n[75] = "badge-feature-premium-plus", n[27] = "badge-feature-bundle-sale", n[30] = "badge-chat", n[40] = "badge-feature-crush", n[7] = "badge-feature-extra-shows", n[3] = "badge-feature-favourites", n[17] = "badge-feature-chat-with-tired", n[31] = "badge-feature-invisible-mode", n[37] = "badge-feature-liked-you", n[4] = "badge-feature-match", n[18] = "badge-feature-chat-with-newbies", n[19] = "badge-feature-special-delivery", n[74] = "badge-feature-read-receipt", n[44] = "badge-no-advert", n[5] = "badge-feature-riseup", n[8] = "badge-feature-premium", n[22] = "badge-feature-undo", n[28] = "badge-feature-encounters", n[70] = "badge-feature-filter", n[91] = "badge-feature-credit", n),
                o = ((i = {})[26] = "badge-feature-boost-premium-plus", i[30] = "badge-chat-premium-plus", i[40] = "badge-feature-crush-premium-plus", i[7] = "badge-feature-boost-premium-plus", i[74] = "badge-feature-read-receipt-premium-plus", i);

            function s(e, t) {
                if (e) {
                    var r = 47 === t ? o[e] : void 0;
                    return r || (r = a[e]), r
                }
            }
        },
        62386: function(e, t, r) {
            r.d(t, {
                A: function() {
                    return fr
                }
            });
            r(52675), r(89463), r(45700), r(28706), r(2008), r(51629), r(74423), r(25276), r(48598), r(72712), r(94490), r(60739), r(89572), r(33110), r(2892), r(67945), r(84185), r(83851), r(81278), r(40875), r(79432), r(10287), r(26099), r(3362), r(27495), r(90906), r(98992), r(54520), r(3949), r(8872), r(23500);
            var n, i = r(64741),
                a = r(42302),
                o = r(89610),
                s = r(99417),
                c = r(40075),
                u = r(36521),
                l = r(73090),
                d = r(13264),
                p = r(36721),
                f = r(58385),
                h = r(74389),
                g = r(18025),
                v = r(49683),
                m = r(31087),
                y = r(20387),
                P = r(83771),
                A = r(41298),
                E = r(76201),
                _ = r(25093),
                b = r(30397),
                T = r(23715),
                S = r(19276),
                I = r(78195),
                O = r(14566),
                C = r(68906),
                R = r(30922),
                w = r(93529),
                D = r(7815);
            ! function(e) {
                e.TRANSACTION = "transaction", e.GOOGLE_RECEIPT = "googleReceipt", e.SERVER_RECEIPT = "serverReceipt"
            }(n || (n = {}));
            var L = "bd-google-play-transactions";

            function j(e) {
                s.A.localStorage.setItem(L, JSON.stringify(e))
            }

            function U() {
                var e = s.A.localStorage.getItem(L);
                return e ? JSON.parse(e) : {}
            }

            function N(e, t) {
                var r = t || U();
                return Object.prototype.hasOwnProperty.call(r, e) ? r[e][n.TRANSACTION] : null
            }
            var x = {
                    createTransaction: function(e) {
                        var t, r = U();
                        N(e.transaction_id, r) || (r[e.transaction_id] = ((t = {})[n.TRANSACTION] = e, t[n.GOOGLE_RECEIPT] = null, t[n.SERVER_RECEIPT] = null, t), j(r))
                    },
                    removeTransaction: function(e) {
                        var t = U();
                        return !!Object.prototype.hasOwnProperty.call(t, e) && (delete t[e], j(t), !0)
                    },
                    _load: U,
                    getTransaction: N,
                    addGoogleReceipt: function(e, t) {
                        var r = U();
                        Object.prototype.hasOwnProperty.call(r, t) && (r[t][n.GOOGLE_RECEIPT] = e), j(r)
                    },
                    getGoogleReceipt: function(e) {
                        var t = U();
                        return Object.prototype.hasOwnProperty.call(t, e) ? t[e][n.GOOGLE_RECEIPT] : null
                    },
                    addServerReceipt: function(e, t) {
                        var r = U();
                        Object.prototype.hasOwnProperty.call(r, t) && (r[t][n.SERVER_RECEIPT] = e), j(r)
                    },
                    getServerReceipt: function(e) {
                        var t = U();
                        return Object.prototype.hasOwnProperty.call(t, e) ? t[e][n.SERVER_RECEIPT] : null
                    }
                },
                M = r(70271),
                k = [113, 117];

            function F(e, t) {
                var r, n = (null == (r = e.data) ? void 0 : r.type) === D.jq;
                return t ? n && e.source === t : n
            }
            var B = r(67556),
                H = r(11927),
                G = r(18084),
                V = G.A.getLogger("getGooglePurchaseToken");
            var W = r(10031),
                Y = r(17412),
                q = (r(21699), r(96540)),
                Q = r(65297),
                K = r(1977),
                X = r(59028),
                z = r(46942),
                Z = r.n(z),
                J = r(47901),
                $ = r(87184),
                ee = r(15376),
                te = r(11734),
                re = r(99795),
                ne = r(94318),
                ie = r(28733),
                ae = r(89769),
                oe = r(12501),
                se = r(20017),
                ce = r(47632),
                ue = r(55105),
                le = r(74848),
                de = function(e) {
                    var t = e.children,
                        r = e.isLoading,
                        n = e.isFullScreen,
                        i = e.hasPadding,
                        a = Z()({
                            "order-recap__payment-details": !0,
                            "is-loading": r,
                            "is-fullscreen": n,
                            "has-padding": i
                        });
                    return (0, le.jsxs)("div", {
                        className: a,
                        children: [r && n ? (0, le.jsx)(ue.A, {}) : null, t]
                    })
                },
                pe = r(93827),
                fe = r(13315),
                he = function(e) {
                    (0, q.useEffect)((function() {
                        return fe.A.getInstance().setTrustedOrigins([e], !0),
                            function() {
                                fe.A.getInstance().setTrustedOrigins([])
                            }
                    }), [e])
                },
                ge = he,
                ve = function(e) {
                    he(e.url);
                    var t = e.iframeRef,
                        r = e.isScrollable,
                        n = void 0 !== r && r,
                        i = e.url,
                        a = n ? "yes" : "no";
                    return (0, le.jsx)("iframe", {
                        ref: t,
                        src: i,
                        className: "embedded-iframe",
                        scrolling: a,
                        title: c.Ay.get(320)
                    })
                },
                me = function(e) {
                    var t = e.providerInfo,
                        r = e.textCta,
                        n = e.iframeParams,
                        i = e.onClickCta;
                    return (0, le.jsxs)("div", {
                        className: "payment-details__content",
                        children: [(0, le.jsxs)("div", {
                            className: "payment-details__content-top",
                            children: [(0, le.jsxs)("div", {
                                className: "payment-details__content-start",
                                children: [(0, le.jsxs)("div", {
                                    className: "payment-details__provider-info",
                                    children: [(0, le.jsx)("img", {
                                        src: t.imageSrc,
                                        className: "payment-details__provider-image",
                                        alt: ""
                                    }), (0, le.jsx)(pe.P1, {
                                        children: t.name
                                    })]
                                }), t.payerInfo ? (0, le.jsx)("div", {
                                    className: "payment-details__payer-info",
                                    children: (0, le.jsx)(pe.P3, {
                                        color: "gray-80",
                                        dangerous: !0,
                                        children: t.payerInfo
                                    })
                                }) : null]
                            }), r && i ? (0, le.jsx)("div", {
                                className: "payment-details__content-end",
                                children: (0, le.jsx)("button", {
                                    className: "payment-details__cta",
                                    onClick: i,
                                    children: (0, le.jsx)(pe.P3, {
                                        color: "primary",
                                        children: r
                                    })
                                })
                            }) : null]
                        }), null != n && n.url ? (0, le.jsx)(ve, {
                            iframeRef: n.iframeRef,
                            url: n.url,
                            isScrollable: n.isScrollable
                        }) : null]
                    })
                },
                ye = r(33815),
                Pe = (r(23792), r(15086), r(47764), r(37550), r(62953), r(27208), r(48408), function(e) {
                    var t = new URL(e).hostname.split(".").reverse(),
                        r = t[0];
                    return t[1] + "." + r
                }),
                Ae = function(e) {
                    return fe.A.getInstance().getTrustedOrigins().some((function(t) {
                        return Pe(e) === Pe(t)
                    }))
                },
                Ee = Ae,
                _e = r(46996);

            function be() {
                be = function() {
                    return t
                };
                var e, t = {},
                    r = Object.prototype,
                    n = r.hasOwnProperty,
                    i = Object.defineProperty || function(e, t, r) {
                        e[t] = r.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    o = a.iterator || "@@iterator",
                    s = a.asyncIterator || "@@asyncIterator",
                    c = a.toStringTag || "@@toStringTag";

                function u(e, t, r) {
                    return Object.defineProperty(e, t, {
                        value: r,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    u({}, "")
                } catch (e) {
                    u = function(e, t, r) {
                        return e[t] = r
                    }
                }

                function l(e, t, r, n) {
                    var a = t && t.prototype instanceof m ? t : m,
                        o = Object.create(a.prototype),
                        s = new w(n || []);
                    return i(o, "_invoke", {
                        value: I(e, r, s)
                    }), o
                }

                function d(e, t, r) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, r)
                        }
                    } catch (e) {
                        return {
                            type: "throw",
                            arg: e
                        }
                    }
                }
                t.wrap = l;
                var p = "suspendedStart",
                    f = "suspendedYield",
                    h = "executing",
                    g = "completed",
                    v = {};

                function m() {}

                function y() {}

                function P() {}
                var A = {};
                u(A, o, (function() {
                    return this
                }));
                var E = Object.getPrototypeOf,
                    _ = E && E(E(D([])));
                _ && _ !== r && n.call(_, o) && (A = _);
                var b = P.prototype = m.prototype = Object.create(A);

                function T(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        u(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function S(e, t) {
                    function r(i, a, o, s) {
                        var c = d(e[i], e, a);
                        if ("throw" !== c.type) {
                            var u = c.arg,
                                l = u.value;
                            return l && "object" == typeof l && n.call(l, "__await") ? t.resolve(l.__await).then((function(e) {
                                r("next", e, o, s)
                            }), (function(e) {
                                r("throw", e, o, s)
                            })) : t.resolve(l).then((function(e) {
                                u.value = e, o(u)
                            }), (function(e) {
                                return r("throw", e, o, s)
                            }))
                        }
                        s(c.arg)
                    }
                    var a;
                    i(this, "_invoke", {
                        value: function(e, n) {
                            function i() {
                                return new t((function(t, i) {
                                    r(e, n, t, i)
                                }))
                            }
                            return a = a ? a.then(i, i) : i()
                        }
                    })
                }

                function I(t, r, n) {
                    var i = p;
                    return function(a, o) {
                        if (i === h) throw Error("Generator is already running");
                        if (i === g) {
                            if ("throw" === a) throw o;
                            return {
                                value: e,
                                done: !0
                            }
                        }
                        for (n.method = a, n.arg = o;;) {
                            var s = n.delegate;
                            if (s) {
                                var c = O(s, n);
                                if (c) {
                                    if (c === v) continue;
                                    return c
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if (i === p) throw i = g, n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            i = h;
                            var u = d(t, r, n);
                            if ("normal" === u.type) {
                                if (i = n.done ? g : f, u.arg === v) continue;
                                return {
                                    value: u.arg,
                                    done: n.done
                                }
                            }
                            "throw" === u.type && (i = g, n.method = "throw", n.arg = u.arg)
                        }
                    }
                }

                function O(t, r) {
                    var n = r.method,
                        i = t.iterator[n];
                    if (i === e) return r.delegate = null, "throw" === n && t.iterator.return && (r.method = "return", r.arg = e, O(t, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), v;
                    var a = d(i, t.iterator, r.arg);
                    if ("throw" === a.type) return r.method = "throw", r.arg = a.arg, r.delegate = null, v;
                    var o = a.arg;
                    return o ? o.done ? (r[t.resultName] = o.value, r.next = t.nextLoc, "return" !== r.method && (r.method = "next", r.arg = e), r.delegate = null, v) : o : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, v)
                }

                function C(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function R(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function w(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(C, this), this.reset(!0)
                }

                function D(t) {
                    if (t || "" === t) {
                        var r = t[o];
                        if (r) return r.call(t);
                        if ("function" == typeof t.next) return t;
                        if (!isNaN(t.length)) {
                            var i = -1,
                                a = function r() {
                                    for (; ++i < t.length;)
                                        if (n.call(t, i)) return r.value = t[i], r.done = !1, r;
                                    return r.value = e, r.done = !0, r
                                };
                            return a.next = a
                        }
                    }
                    throw new TypeError(typeof t + " is not iterable")
                }
                return y.prototype = P, i(b, "constructor", {
                    value: P,
                    configurable: !0
                }), i(P, "constructor", {
                    value: y,
                    configurable: !0
                }), y.displayName = u(P, c, "GeneratorFunction"), t.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === y || "GeneratorFunction" === (t.displayName || t.name))
                }, t.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, P) : (e.__proto__ = P, u(e, c, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, t.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, T(S.prototype), u(S.prototype, s, (function() {
                    return this
                })), t.AsyncIterator = S, t.async = function(e, r, n, i, a) {
                    void 0 === a && (a = Promise);
                    var o = new S(l(e, r, n, i), a);
                    return t.isGeneratorFunction(r) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, T(b), u(b, c, "Generator"), u(b, o, (function() {
                    return this
                })), u(b, "toString", (function() {
                    return "[object Generator]"
                })), t.keys = function(e) {
                    var t = Object(e),
                        r = [];
                    for (var n in t) r.push(n);
                    return r.reverse(),
                        function e() {
                            for (; r.length;) {
                                var n = r.pop();
                                if (n in t) return e.value = n, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, t.values = D, w.prototype = {
                    constructor: w,
                    reset: function(t) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = e, this.done = !1, this.delegate = null, this.method = "next", this.arg = e, this.tryEntries.forEach(R), !t)
                            for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = e)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(t) {
                        if (this.done) throw t;
                        var r = this;

                        function i(n, i) {
                            return s.type = "throw", s.arg = t, r.next = n, i && (r.method = "next", r.arg = e), !!i
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var o = this.tryEntries[a],
                                s = o.completion;
                            if ("root" === o.tryLoc) return i("end");
                            if (o.tryLoc <= this.prev) {
                                var c = n.call(o, "catchLoc"),
                                    u = n.call(o, "finallyLoc");
                                if (c && u) {
                                    if (this.prev < o.catchLoc) return i(o.catchLoc, !0);
                                    if (this.prev < o.finallyLoc) return i(o.finallyLoc)
                                } else if (c) {
                                    if (this.prev < o.catchLoc) return i(o.catchLoc, !0)
                                } else {
                                    if (!u) throw Error("try statement without catch or finally");
                                    if (this.prev < o.finallyLoc) return i(o.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var i = this.tryEntries[r];
                            if (i.tryLoc <= this.prev && n.call(i, "finallyLoc") && this.prev < i.finallyLoc) {
                                var a = i;
                                break
                            }
                        }
                        a && ("break" === e || "continue" === e) && a.tryLoc <= t && t <= a.finallyLoc && (a = null);
                        var o = a ? a.completion : {};
                        return o.type = e, o.arg = t, a ? (this.method = "next", this.next = a.finallyLoc, v) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), v
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var r = this.tryEntries[t];
                            if (r.finallyLoc === e) return this.complete(r.completion, r.afterLoc), R(r), v
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var r = this.tryEntries[t];
                            if (r.tryLoc === e) {
                                var n = r.completion;
                                if ("throw" === n.type) {
                                    var i = n.arg;
                                    R(r)
                                }
                                return i
                            }
                        }
                        throw Error("illegal catch attempt")
                    },
                    delegateYield: function(t, r, n) {
                        return this.delegate = {
                            iterator: D(t),
                            resultName: r,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = e), v
                    }
                }, t
            }

            function Te(e, t, r, n, i, a, o) {
                try {
                    var s = e[a](o),
                        c = s.value
                } catch (e) {
                    return void r(e)
                }
                s.done ? t(c) : Promise.resolve(c).then(n, i)
            }
            var Se = G.A.getLogger("handleThreatMetrixStep"),
                Ie = function() {
                    var e, t = (e = be().mark((function e(t, r) {
                        var n, i;
                        return be().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 1, r.startProfiling();
                                case 1:
                                    return 2 !== (n = e.sent).status && (i = n.error || "ThreatMetrix profiling error", Se.error(i, {
                                        profilingStatus: n.status,
                                        profilingType: t.threatmetrix_profiling_type
                                    })), e.abrupt("return", {
                                        threatmetrixSessionId: t.threatmetrix_session_id,
                                        threatmetrixProfilingStatus: n.status
                                    });
                                case 2:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })), function() {
                        var t = this,
                            r = arguments;
                        return new Promise((function(n, i) {
                            var a = e.apply(t, r);

                            function o(e) {
                                Te(a, n, i, o, s, "next", e)
                            }

                            function s(e) {
                                Te(a, n, i, o, s, "throw", e)
                            }
                            o(void 0)
                        }))
                    });
                    return function(e, r) {
                        return t.apply(this, arguments)
                    }
                }(),
                Oe = function(e) {
                    return "is_hidden_view" in e
                };

            function Ce(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function Re(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Ce(Object(r), !0).forEach((function(t) {
                        we(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Ce(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function we(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var De = G.A.getLogger("useMakeServerPurchaseTransaction");

            function Le(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function je(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Le(Object(r), !0).forEach((function(t) {
                        Ue(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Le(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function Ue(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var Ne = function(e) {
                    var t = e.paymentOptions,
                        r = e.onPurchaseTransaction,
                        n = e.onClientPurchaseReceipt,
                        i = e.onErrorLoadingPaymentDetails,
                        a = (0, q.useState)(!0),
                        o = a[0],
                        s = a[1],
                        c = (0, q.useState)(""),
                        u = c[0],
                        l = c[1],
                        d = (0, q.useState)(),
                        p = d[0],
                        g = d[1],
                        m = (0, q.useState)(t),
                        y = m[0],
                        P = m[1];
                    (0, q.useEffect)((function() {
                        var e = je(je({}, y), t);
                        (0, _e.A)(e, y) || P(je(je({}, e), {}, {
                            threatmetrixProfilingStatus: void 0,
                            threatmetrixSessionId: void 0
                        }))
                    }), [t, y]);
                    var A = function(e) {
                            var t = e.onClientPurchaseReceipt,
                                r = e.onPurchaseTransaction,
                                n = e.paymentOptions,
                                i = e.onErrorLoadingPaymentDetails,
                                a = e.setIsLoading,
                                o = e.setCcFormUrl,
                                s = e.setPaymentOptions,
                                c = (0, q.useRef)(null),
                                u = (0, q.useRef)(),
                                l = (0, q.useCallback)((function(e) {
                                    var l, d = (e || {}).ignoreStoredDetails,
                                        p = void 0 === d || d;
                                    a(!0), null == r || r(), null == (l = c.current) || l.cancel(), c.current = v.A.getInstance().startTransactionAsPromise(Re(Re({}, n), {}, {
                                        ignoreStoredDetails: p
                                    })), c.current.then((function(e) {
                                        var n, c = e.error,
                                            l = e.purchaseTransaction,
                                            d = e.clientPurchaseReceipt;
                                        if (l)
                                            if ((0, O.k)(l)) null == (n = u.current) || n.destroy(), u.current = new O._(l), Ie(l, u.current).then((function(e) {
                                                s((function(t) {
                                                    return Re(Re({}, t), e)
                                                }))
                                            }));
                                            else if (Oe(l)) De.error("A 3DS step was triggered from the Compliance flow. We do not expect it to be triggered here.", {
                                            purchaseTransaction: l
                                        });
                                        else if (l.redirect_url) {
                                            var p = l.redirect_url || "";
                                            null == r || r(l), o(p), a(!1)
                                        } else De.error('Failed to get a "redirect_url"', {
                                            purchaseTransaction: l
                                        }), f.A.navigate(h.x.OWN_PROFILE);
                                        else d ? t(d) : i(c || new Error("Error loading the payment details"), e)
                                    })).catch(i)
                                }), [t, i, r, n, o, a, s]);
                            return (0, q.useEffect)((function() {
                                return function() {
                                    var e, t;
                                    null == (e = c.current) || e.cancel(), null == (t = u.current) || t.destroy()
                                }
                            }), []), {
                                makeServerPurchaseTransaction: l
                            }
                        }({
                            onClientPurchaseReceipt: n,
                            onErrorLoadingPaymentDetails: i,
                            onPurchaseTransaction: r,
                            paymentOptions: y,
                            setCcFormUrl: l,
                            setIsLoading: s,
                            setPaymentOptions: P
                        }),
                        E = A.makeServerPurchaseTransaction;
                    return (0, q.useEffect)((function() {
                        var e = y.providerId,
                            t = y.recurringPromo,
                            r = y.provider;
                        t ? (g(t), s(!1), (0, M.JW)(r) && (0, M.dX)(e) && E({
                            ignoreStoredDetails: !1
                        })) : (0, M.n8)(e) ? E() : s(!1)
                    }), [y, E]), {
                        ccFormUrl: u,
                        promoDetails: p,
                        isLoading: o,
                        setIsLoading: s
                    }
                },
                xe = 22;
            var Me = function(e) {
                    var t = e.paymentOptions,
                        r = e.mop,
                        n = e.textCta,
                        i = e.onClickCta,
                        a = e.onClientPurchaseReceipt,
                        o = e.onErrorLoadingPaymentDetails,
                        c = e.onIframeRef,
                        u = e.onPurchaseTransaction,
                        l = (0, q.useState)(!1),
                        d = l[0],
                        p = l[1],
                        f = (0, q.useState)(!1),
                        h = f[0],
                        g = f[1],
                        v = (0, q.useState)(null),
                        m = v[0],
                        y = v[1],
                        P = (0, q.useRef)(!1),
                        A = Ne({
                            paymentOptions: t,
                            onPurchaseTransaction: u,
                            onClientPurchaseReceipt: a,
                            onErrorLoadingPaymentDetails: o
                        }),
                        E = A.ccFormUrl,
                        _ = A.promoDetails,
                        b = A.isLoading,
                        T = A.setIsLoading,
                        S = (0, q.useMemo)((function() {
                            return function(e, t) {
                                var r = {
                                    imageSrc: "",
                                    name: ""
                                };
                                if (t) {
                                    var n, i = null == (n = (t.pictures || [])[0]) ? void 0 : n.display_images;
                                    r.imageSrc = ce.A.getImageUrlForSize(i, xe, xe), r.name = t.header, r.payerInfo = t.mssg
                                } else r.imageSrc = ce.A.getImageUrlForSize(e.image, xe, xe), r.name = e.providerName;
                                return r
                            }(r, _)
                        }), [r, _]),
                        I = (0, q.useCallback)((function(e) {
                            if (m) {
                                var t = void 0 !== e ? e + "px" : "";
                                m.style.height = t, m.height = t
                            }
                        }), [m]);
                    (0, q.useEffect)((function() {
                        if (null == c || c(m), m) return s.A.addEventListener("message", e),
                            function() {
                                s.A.removeEventListener("message", e)
                            };

                        function e(e) {
                            if (Ae(e.origin) && e.data) {
                                Object.prototype.hasOwnProperty.call(e.data, "isKeyboardVisible") && (P.current = Boolean(e.data.isKeyboardVisible)), F(e) && T(!0);
                                var t = e.data,
                                    r = t.event,
                                    n = t.type,
                                    i = t.data,
                                    a = void 0 === i ? {} : i;
                                r === Y.An.SECURITY_CHECK && (p(!0), I(), n === Y.vD.REDIRECT && g(!0)), r === Y.An.UPDATE_HEIGHT && m && !d && I(a.height)
                            }
                        }
                    }), [m, d, c, I, T]);
                    var O = (0, q.useCallback)((function(e) {
                            y(e), 504 === t.provider && e && (d ? (e.style.height = "", e.height = "") : (e.style.height = "300px", e.height = "300px"))
                        }), [d, t.provider]),
                        C = (0, q.useMemo)((function() {
                            return {
                                iframeRef: O,
                                url: E,
                                isScrollable: h
                            }
                        }), [E, O, h]),
                        R = (0, q.useMemo)((function() {
                            return (0, M.JW)(t.provider) && (0, M.dX)(t.providerId)
                        }), [t.provider, t.providerId]);
                    return (0, le.jsx)(de, {
                        isLoading: b,
                        isFullScreen: d,
                        hasPadding: 504 === t.provider,
                        children: b ? d ? null : (0, le.jsx)(ye.A, {}) : E && !R ? (0, le.jsx)(ve, {
                            iframeRef: C.iframeRef,
                            url: C.url,
                            isScrollable: C.isScrollable
                        }) : (0, le.jsx)(me, {
                            providerInfo: S,
                            textCta: n,
                            onClickCta: i,
                            iframeParams: C
                        })
                    })
                },
                ke = r(73616),
                Fe = r(84932),
                Be = function(e) {
                    var t = e.email,
                        r = e.emailLabel,
                        n = e.emailErrorLabel,
                        i = e.onSubmit,
                        a = e.onChange;
                    return (0, le.jsx)("div", {
                        className: "order-recap__email",
                        children: (0, le.jsx)(ke.A, {
                            onSubmit: i,
                            children: (0, le.jsx)(Fe.A, {
                                errorMessage: n,
                                fieldId: "order-recap-email",
                                type: "email",
                                value: t,
                                onChange: a,
                                label: r
                            })
                        })
                    })
                },
                He = function(e) {
                    var t = e.title,
                        r = e.price,
                        n = e.displayPrice,
                        i = e.textCta,
                        a = e.onClickCta,
                        o = r ? "gray-80" : "black";
                    return (0, le.jsx)("div", {
                        className: "service-summary",
                        children: (0, le.jsxs)("div", {
                            className: "service-summary__content",
                            children: [(0, le.jsxs)("div", {
                                className: "service-summary__content-start",
                                children: [t ? (0, le.jsx)(pe.P1, {
                                    children: t
                                }) : null, n ? (0, le.jsx)("div", {
                                    className: "service-summary__display-price",
                                    children: (0, le.jsx)(pe.P3, {
                                        color: o,
                                        children: n
                                    })
                                }) : null]
                            }), (0, le.jsxs)("div", {
                                className: "service-summary__content-end",
                                children: [r ? (0, le.jsx)(pe.P1, {
                                    children: r
                                }) : null, i ? (0, le.jsx)("button", {
                                    className: "service-summary__cta",
                                    onClick: a,
                                    children: (0, le.jsx)(pe.P3, {
                                        color: "primary",
                                        children: i
                                    })
                                }) : null]
                            })]
                        })
                    })
                },
                Ge = function(e) {
                    var t = e.tnc;
                    return (0, le.jsx)("div", {
                        className: "recurring-billing",
                        children: (0, le.jsx)(pe.P2, {
                            dangerous: !0,
                            children: t
                        })
                    })
                },
                Ve = r(17380),
                We = function(e) {
                    var t = e.label,
                        r = e.value,
                        n = e.onChange;
                    return (0, le.jsxs)("div", {
                        className: "order-recap-autotopup",
                        "data-qa": "product-top-up",
                        children: [(0, le.jsx)("div", {
                            className: "order-recap-autotopup__checkbox",
                            children: (0, le.jsx)(Ve.A, {
                                id: "order-recap-autotopup",
                                isChecked: r,
                                onChange: n,
                                type: "checkbox"
                            })
                        }), (0, le.jsx)("label", {
                            className: "order-recap-autotopup__label",
                            htmlFor: "order-recap-autotopup",
                            children: (0, le.jsx)(pe.P3, {
                                color: "gray-80",
                                inline: !0,
                                children: t
                            })
                        })]
                    })
                },
                Ye = function(e) {
                    var t, r = e.autoTopUpText,
                        n = e.autoTopUpValue,
                        i = e.closeIconLabel,
                        a = e.email,
                        o = e.emailErrorLabel,
                        s = e.emailLabel,
                        c = e.isAutoTopUpAvailable,
                        u = void 0 !== c && c,
                        l = e.isBillingEmailRequired,
                        d = void 0 !== l && l,
                        p = e.isLoading,
                        f = e.isScreenFixed,
                        h = e.paymentDetails,
                        g = e.submitCta,
                        v = e.summary,
                        m = e.title,
                        y = e.tnc,
                        P = e.onClickClose,
                        A = e.onSubmitEmail,
                        E = e.onChangeEmail,
                        _ = e.onChangeAutoTopUp,
                        b = e.onClickSubmitPayment;
                    f && (t = "fixed");
                    var T = Z()({
                        "order-recap": !0,
                        "is-fixed": f
                    });
                    return (0, le.jsxs)("div", {
                        className: T,
                        children: [(0, le.jsxs)(J.A, {
                            children: [(0, le.jsx)(ee.A, {
                                children: (0, le.jsxs)(re.A, {
                                    position: t,
                                    children: [(0, le.jsx)(ie.A, {
                                        children: (0, le.jsx)(ne.A, {
                                            name: "navigation-bar-close",
                                            onClick: P,
                                            a11y: {
                                                iconLabel: i
                                            }
                                        })
                                    }), (0, le.jsx)(oe.A, {
                                        text: m
                                    }), (0, le.jsx)(ae.A, {})]
                                })
                            }), (0, le.jsx)($.A, {
                                hpadded: !0,
                                vpadded: !0,
                                children: (0, le.jsx)(He, {
                                    title: v.title,
                                    price: v.price,
                                    displayPrice: v.displayPrice,
                                    textCta: v.textCta,
                                    onClickCta: v.onClickCta
                                })
                            }), (0, le.jsx)($.A, {
                                hpadded: !0,
                                vpadded: !0,
                                children: (0, le.jsx)(Me, {
                                    paymentOptions: h.paymentOptions,
                                    mop: h.mop,
                                    textCta: h.textCta,
                                    onClickCta: h.onClickCta,
                                    onClientPurchaseReceipt: h.onClientPurchaseReceipt,
                                    onErrorLoadingPaymentDetails: h.onErrorLoadingPaymentDetails,
                                    onIframeRef: h.onIframeRef,
                                    onPurchaseTransaction: h.onPurchaseTransaction
                                })
                            }), d ? (0, le.jsx)($.A, {
                                hpadded: !0,
                                vpadded: !0,
                                children: (0, le.jsx)(Be, {
                                    email: a,
                                    emailLabel: s,
                                    emailErrorLabel: o,
                                    onSubmit: A,
                                    onChange: E
                                })
                            }) : null, u && r ? (0, le.jsx)($.A, {
                                hpadded: !0,
                                vpadded: !0,
                                children: (0, le.jsx)(We, {
                                    label: r,
                                    value: n,
                                    onChange: _
                                })
                            }) : null, y ? (0, le.jsx)($.A, {
                                hpadded: !0,
                                vpadded: !0,
                                children: (0, le.jsx)(Ge, {
                                    tnc: y
                                })
                            }) : null, (0, le.jsx)(te.A, {
                                hpadded: !0,
                                vpadded: !0,
                                children: (0, le.jsx)("div", {
                                    className: "order-recap__footer",
                                    children: (0, le.jsx)(se.A, {
                                        icon: "generic-lock",
                                        text: g,
                                        isLoading: p,
                                        onClick: b
                                    })
                                })
                            })]
                        }), p ? (0, le.jsx)(ue.A, {}) : null]
                    })
                },
                qe = [Y.An.INPUT_ERRORS, Y.An.SECURITY_CHECK];

            function Qe(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function Ke(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Qe(Object(r), !0).forEach((function(t) {
                        Xe(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Qe(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function Xe(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function ze(e, t) {
                return ze = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, ze(e, t)
            }
            var Ze = function(e) {
                    function t(t) {
                        var r;
                        (r = e.call(this, t) || this).iframeElement = void 0, r.ccFormUrl = void 0, r.transaction = void 0, r.log = G.A.getLogger("OrderRecapContainer"), r.settingsPromise = void 0, r.handlePaymentSettings = function(e) {
                            e && (e.auto_topup || r.showChangeCtas())
                        }, r.handleErrorPaymentSettings = function(e) {
                            (0, _.A)(e) && r.log.error("Error loading the payment settings", {
                                error: e
                            })
                        }, r.handlePurchaseTransaction = function(e) {
                            r.isCcPayment() && r.setState({
                                isLoading: !e
                            }), r.transaction = e, r.ccFormUrl = null == e ? void 0 : e.redirect_url
                        }, r.handleIframeRef = function(e) {
                            r.iframeElement = e
                        }, r.handleMessageFromIframe = function(e) {
                            if (Ae(e.origin) && e.data) {
                                var t = e.data,
                                    n = t.event,
                                    i = t.data;
                                if (n && qe.includes(n) && r.setState({
                                        isLoading: !1
                                    }), n === Y.An.SECURITY_CHECK && (r.setState({
                                        hasSecurityCheckRequested: !0
                                    }), r.iframeElement && (r.iframeElement.height = "", r.iframeElement.style.height = "")), n === Y.An.UPDATE_HEIGHT) {
                                    var a = (i || {}).height,
                                        o = Number(a);
                                    r.iframeElement && (isNaN(o) ? (r.iframeElement.height = "", r.iframeElement.style.height = "") : (r.iframeElement.height = o + "px", r.iframeElement.style.height = o + "px"))
                                }
                                n === Y.An.SUBMIT_FORM_REQUESTED && r.handleClickSubmitPayment()
                            }
                        }, r.handleErrorLoadingPaymentDetails = function(e, t) {
                            var n = t || {},
                                i = n.error,
                                a = n.purchaseTransactionFailed;
                            if (!a && (0, _.A)(i || e) && r.log.error("Error loading the payment details", {
                                    error: e,
                                    transactionResult: t
                                }), !(e instanceof A.k)) {
                                var o, s = null == a || null == (o = a.notification) ? void 0 : o.message;
                                w.A.showNotification({
                                    type: w.A.TYPES.ERROR,
                                    text: s
                                }), r.props.onClose()
                            }
                        }, r.handleSubmitEmail = function(e) {
                            e.preventDefault(), r.handleClickSubmitPayment()
                        }, r.handleChangeEmail = function(e) {
                            r.setState({
                                email: e.currentTarget.value,
                                emailErrorLabel: ""
                            })
                        }, r.handleClickClose = function() {
                            var e = r.state.hasSecurityCheckRequested;
                            r.props.onClose(r.transaction, e)
                        }, r.handleChangePackage = function() {
                            null == r.props.onChangePackage || r.props.onChangePackage(), r.handleClickClose()
                        }, r.handleChangePaymentMethod = function() {
                            null == r.props.onChangePaymentMethod || r.props.onChangePaymentMethod()
                        }, r.handleChangeAutoTopUp = function() {
                            r.isCcPayment() && r.postMessageCcForm(Y.An.STORE_DETAILS), s.A.setTimeout((function() {
                                r.setState((function(e) {
                                    return {
                                        autoTopUpValue: !e.autoTopUpValue,
                                        paymentDetails: Ke(Ke({}, e.paymentDetails), {}, {
                                            paymentOptions: Ke(Ke({}, e.paymentDetails.paymentOptions), {}, {
                                                autoTopup: !e.autoTopUpValue
                                            })
                                        })
                                    }
                                }))
                            }))
                        }, r.handleClickSubmitPayment = function() {
                            var e = r.props.paymentOptions,
                                t = r.isCcPayment(),
                                n = r.isStoredDetailsAdyenPayment();
                            (!t || r.iframeElement && r.ccFormUrl) && (r.setState({
                                isLoading: !0
                            }), !r.props.orderRecap.is_billing_email_required || (0, K.m)(r.state.email) ? t || n ? (r.setTransactionExtraData(), r.postMessageCcForm(Y.An.SUBMIT_FORM, {
                                emailField: r.state.email || ""
                            })) : (r.state.email && (e.billingEmail = r.state.email), e.autoTopup = r.state.autoTopUpValue, e.ignoreStoredDetails = r.props.ignoreStoredDetails, r.props.onSubmitPayment(e)) : r.setState({
                                emailErrorLabel: c.Ay.get(683),
                                isLoading: !1
                            }))
                        };
                        var n = r.props,
                            i = n.mop,
                            a = n.orderRecap,
                            o = n.paymentOptions,
                            u = Boolean(a.is_auto_topup_available && a.auto_top_up_default_state);
                        return r.state = {
                            email: "",
                            emailErrorLabel: "",
                            autoTopUpValue: u,
                            isLoading: r.isCcPayment(),
                            hasSecurityCheckRequested: !1,
                            summary: {
                                title: a.title || "",
                                price: a.price || "",
                                displayPrice: a.display_price || ""
                            },
                            paymentDetails: {
                                mop: i,
                                paymentOptions: Ke(Ke({}, o), {}, {
                                    autoTopup: u
                                }),
                                onClientPurchaseReceipt: t.onClientPurchaseReceipt,
                                onIframeRef: r.handleIframeRef,
                                onErrorLoadingPaymentDetails: r.handleErrorLoadingPaymentDetails,
                                onPurchaseTransaction: r.handlePurchaseTransaction
                            }
                        }, r.iframeElement = null, r
                    }
                    var r, n;
                    n = e, (r = t).prototype = Object.create(n.prototype), r.prototype.constructor = r, ze(r, n);
                    var i = t.prototype;
                    return i.componentDidMount = function() {
                        this.isCreditsProduct() ? (this.settingsPromise = X.A.getInstance().get(), this.settingsPromise.then(this.handlePaymentSettings).catch(this.handleErrorPaymentSettings)) : this.showChangeCtas(), s.A.addEventListener("message", this.handleMessageFromIframe), Q.A.trigger(Q.A.BEFORE_SHOW_MODAL)
                    }, i.componentWillUnmount = function() {
                        var e;
                        null == (e = this.settingsPromise) || e.cancel(), s.A.removeEventListener("message", this.handleMessageFromIframe), Q.A.trigger(Q.A.HIDE_MODAL)
                    }, i.isCreditsProduct = function() {
                        return 13 === this.props.paymentOptions.productType
                    }, i.showChangeCtas = function() {
                        var e = this,
                            t = this.props,
                            r = t.allowChangePackage,
                            n = t.onChangePaymentMethod;
                        r && this.setState((function(t) {
                            return {
                                summary: Ke(Ke({}, t.summary), {}, {
                                    textCta: c.Ay.get(682),
                                    onClickCta: e.handleChangePackage
                                })
                            }
                        })), n && this.setState((function(t) {
                            return {
                                paymentDetails: Ke(Ke({}, t.paymentDetails), {}, {
                                    textCta: c.Ay.get(682),
                                    onClickCta: e.handleChangePaymentMethod
                                })
                            }
                        }))
                    }, i.isCcPayment = function() {
                        var e = this.props.paymentOptions;
                        return !this.isStoredPayment() && (0, M.n8)(e.providerId)
                    }, i.isStoredDetailsAdyenPayment = function() {
                        var e = this.props.paymentOptions;
                        return this.isStoredPayment() && (0, M.dX)(e.providerId)
                    }, i.isStoredPayment = function() {
                        var e = this.props,
                            t = e.storedDetails,
                            r = e.paymentOptions.provider;
                        return t || (0, M.JW)(r)
                    }, i.setTransactionExtraData = function() {
                        var e, t = null == (e = this.transaction) ? void 0 : e.transaction_id;
                        t && B.K.set(t, {
                            billingEmail: this.state.email
                        })
                    }, i.postMessageCcForm = function(e, t) {
                        var r;
                        null == (r = this.iframeElement.contentWindow) || r.postMessage({
                            event: e,
                            payload: t
                        }, "*")
                    }, i.render = function() {
                        var e = this.props,
                            t = e.title,
                            r = e.orderRecap,
                            n = this.state,
                            i = n.autoTopUpValue,
                            a = n.email,
                            o = n.emailErrorLabel,
                            s = n.isLoading,
                            u = n.hasSecurityCheckRequested,
                            l = n.paymentDetails,
                            d = n.summary;
                        return (0, le.jsx)(Ye, {
                            closeIconLabel: c.Ay.get(270),
                            title: t,
                            summary: d,
                            paymentDetails: l,
                            isBillingEmailRequired: Boolean(r.is_billing_email_required),
                            email: a,
                            emailLabel: c.Ay.get(684),
                            emailErrorLabel: o,
                            tnc: r.tnc,
                            isAutoTopUpAvailable: r.is_auto_topup_available,
                            autoTopUpValue: i,
                            autoTopUpText: r.auto_top_up_text,
                            onClickClose: this.handleClickClose,
                            submitCta: r.service_action,
                            isLoading: s,
                            isScreenFixed: u,
                            onSubmitEmail: this.handleSubmitEmail,
                            onChangeEmail: this.handleChangeEmail,
                            onChangeAutoTopUp: this.handleChangeAutoTopUp,
                            onClickSubmitPayment: this.handleClickSubmitPayment
                        })
                    }, t
                }(q.PureComponent),
                Je = r(12702),
                $e = r(8483),
                et = function(e) {
                    var t = e.title,
                        r = e.subTitle,
                        n = e.price;
                    return (0, le.jsxs)("div", {
                        className: "ucb-selected-product",
                        children: [(0, le.jsx)("div", {
                            className: "ucb-selected-product__logo",
                            children: (0, le.jsx)($e.A, {
                                name: "logo-square"
                            })
                        }), (0, le.jsxs)("div", {
                            className: "ucb-selected-product__titles",
                            children: [(0, le.jsx)(pe.P1, {
                                children: t
                            }), (0, le.jsx)(pe.P3, {
                                color: "gray-50",
                                children: r
                            })]
                        }), (0, le.jsx)("div", {
                            className: "ucb-selected-product__price",
                            children: (0, le.jsx)(pe.ZS, {
                                children: n
                            })
                        })]
                    })
                },
                tt = function(e) {
                    var t = e.children,
                        r = e.onClickBack,
                        n = e.title,
                        i = e.description,
                        a = e.isLoading,
                        o = e.isClosable ? "navigation-bar-close" : "navigation-bar-back";
                    return (0, le.jsx)("div", {
                        className: "ucb-screen-wrapper",
                        children: (0, le.jsxs)(J.A, {
                            dataQA: {
                                "data-qa": "paywall-screen"
                            },
                            children: [(0, le.jsx)(ee.A, {
                                children: (0, le.jsxs)(re.A, {
                                    transparent: !0,
                                    children: [(0, le.jsx)(ie.A, {
                                        isWide: !0,
                                        children: (0, le.jsx)(ne.A, {
                                            name: o,
                                            onClick: r
                                        })
                                    }), (0, le.jsx)("div", {
                                        "data-qa": "paywall-title",
                                        children: (0, le.jsx)(oe.A, {
                                            text: n,
                                            tag: "h1"
                                        })
                                    }), (0, le.jsx)(ie.A, {
                                        isWide: !0,
                                        children: " "
                                    })]
                                })
                            }), (0, le.jsx)($.A, {
                                align: "top",
                                children: (0, le.jsxs)("div", {
                                    className: "ucb-screen-wrapper__content",
                                    children: [i ? (0, le.jsx)("div", {
                                        className: "ucb-screen-wrapper__description",
                                        "data-qa": "paywall-description",
                                        children: (0, le.jsx)(pe.P1, {
                                            children: i
                                        })
                                    }) : null, t]
                                })
                            }), a ? (0, le.jsx)(ue.A, {}) : null]
                        })
                    })
                },
                rt = (r(62062), r(81454), function(e) {
                    var t = e.children,
                        r = e.onSelect,
                        n = e.isSelected,
                        i = e.isStored,
                        a = e.iconName,
                        o = e.iconImage,
                        s = e.label,
                        c = e.value,
                        u = function() {
                            null == r || r(c || "")
                        },
                        l = function() {
                            null == r || r(c || "")
                        },
                        d = function() {
                            return a ? (0, le.jsx)($e.A, {
                                name: a
                            }) : (0, le.jsx)("img", {
                                src: o,
                                alt: "",
                                style: {
                                    width: "100%",
                                    height: "100%"
                                }
                            })
                        },
                        p = "ucb-payment-provider-" + c,
                        f = Z()({
                            "ucb-provider-item": !0,
                            "is-selected": n
                        });
                    return (0, le.jsxs)("div", {
                        className: f,
                        children: [i ? (0, le.jsxs)("button", {
                            className: "ucb-provider-item__heading",
                            onClick: l,
                            children: [(0, le.jsx)("span", {
                                className: "ucb-provider-item__image",
                                children: d()
                            }), (0, le.jsx)(pe.P2, {
                                inline: !0,
                                children: s
                            }), (0, le.jsx)("span", {
                                className: "ucb-provider-item__button-icon",
                                children: (0, le.jsx)($e.A, {
                                    name: "generic-chevron-right",
                                    size: "xsm"
                                })
                            })]
                        }) : (0, le.jsxs)("label", {
                            className: "ucb-provider-item__heading",
                            htmlFor: p,
                            "data-qa": "payment-provider-" + c,
                            children: [(0, le.jsx)("span", {
                                className: "ucb-provider-item__checkbox",
                                children: (0, le.jsx)(Ve.A, {
                                    type: "radio",
                                    onChange: u,
                                    name: "provider",
                                    isChecked: n,
                                    value: c,
                                    id: p
                                })
                            }), (0, le.jsx)("span", {
                                className: "ucb-provider-item__image",
                                children: d()
                            }), (0, le.jsx)(pe.P2, {
                                inline: !0,
                                children: s
                            })]
                        }), (0, le.jsx)("div", {
                            className: "ucb-provider-item__content",
                            children: t
                        })]
                    })
                }),
                nt = r(78979),
                it = function(e) {
                    var t = e.billingEmail,
                        r = e.autoTopUp,
                        n = e.tnc,
                        i = e.onSubmit,
                        a = e.ctaText,
                        o = e.isLoading,
                        s = t || {},
                        c = s.isRequired,
                        u = s.email,
                        l = void 0 === u ? "" : u,
                        d = s.emailLabel,
                        p = s.emailErrorLabel,
                        f = s.onSubmitEmail,
                        h = s.onChangeEmail,
                        g = r || {},
                        v = g.isRequired,
                        m = g.autoTopUpText,
                        y = g.autoTopUpValue,
                        P = g.onChangeAutoTopUp;
                    return (0, le.jsxs)("div", {
                        className: "ucb-generic-data-for-provider",
                        children: [c ? (0, le.jsx)("div", {
                            className: "ucb-billing-email",
                            children: (0, le.jsx)(Be, {
                                email: l,
                                emailLabel: d,
                                emailErrorLabel: p,
                                onSubmit: f,
                                onChange: h
                            })
                        }) : null, (0, le.jsxs)(nt.A, {
                            spacing: "loose",
                            children: [v && m ? (0, le.jsx)("div", {
                                "data-qa": "product-top-up",
                                children: (0, le.jsx)(We, {
                                    label: m,
                                    value: y,
                                    onChange: P
                                })
                            }) : null, (0, le.jsx)("div", {
                                className: "ucb-recap__footer",
                                children: (0, le.jsx)(se.A, {
                                    icon: "generic-lock",
                                    text: a,
                                    isLoading: o,
                                    onClick: i,
                                    dataQA: {
                                        "data-qa-action": "continue-payment"
                                    }
                                })
                            }), n ? (0, le.jsx)(Ge, {
                                tnc: n
                            }) : null]
                        })]
                    })
                },
                at = function(e) {
                    var t = e.url,
                        r = e.isFullscreen,
                        n = e.hasDescription,
                        i = e.onRef;
                    ge(t);
                    var a = Z()({
                        "ucb-iframe": !0,
                        "is-fullscreen": r,
                        "has-description": n
                    });
                    return (0, le.jsx)("iframe", {
                        ref: i,
                        src: t,
                        title: c.Ay.get(320),
                        className: a
                    })
                };

            function ot(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function st(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? ot(Object(r), !0).forEach((function(t) {
                        ct(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : ot(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function ct(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var ut = G.A.getLogger("UcbRecap"),
                lt = function(e) {
                    var t = (0, Je.jh)().state.ccFormState;
                    return {
                        title: (0, q.useMemo)((function() {
                            return t === Je.Kl.SECURITY_STEP ? c.Ay.get(901) : e
                        }), [e, t]),
                        description: (0, q.useMemo)((function() {
                            return t === Je.Kl.SECURITY_STEP ? c.Ay.get(900) : ""
                        }), [t])
                    }
                },
                dt = (r(48980), r(79860)),
                pt = function(e) {
                    return e ? 2186 : 2185
                },
                ft = function(e) {
                    var t = e.isActive,
                        r = e.iframeRef,
                        n = e.onClientPurchaseReceipt,
                        i = e.onSubmit,
                        a = (0, Je.jh)(),
                        o = a.state,
                        s = a.dispatch,
                        u = o.ccFormUrl,
                        l = o.isCcPayment,
                        d = o.isCcFormFullscreen,
                        p = o.isLoading,
                        f = o.billingEmail,
                        h = o.emailErrorLabel,
                        g = o.autoTopUpValue,
                        m = o.currentUcbRecap,
                        y = o.storedProvider,
                        P = lt("").description,
                        E = Boolean(P);
                    ! function(e) {
                        var t = e.isActive,
                            r = e.onClientPurchaseReceipt,
                            n = (0, q.useRef)(null),
                            i = (0, Je.jh)(),
                            a = i.state,
                            o = i.dispatch,
                            s = a.isCcPayment,
                            c = a.paymentOptions,
                            u = (0, q.useCallback)((function(e) {
                                s && o({
                                    type: Je.BX.UPDATE_IS_LOADING,
                                    value: !e
                                }), o({
                                    type: Je.BX.UPDATE_CURRENT_TRANSACTION,
                                    value: e
                                })
                            }), [o, s]),
                            l = (0, q.useCallback)((function(e, t) {
                                var r = t || {},
                                    n = r.error,
                                    i = r.purchaseTransactionFailed;
                                if (!i && (0, _.A)(n || e) && ut.error("Error loading the payment details", {
                                        error: e,
                                        transactionResult: t
                                    }), o({
                                        type: Je.BX.UPDATE_IS_LOADING,
                                        value: !1
                                    }), o({
                                        type: Je.BX.FIRE_SIGNAL_CLOSE,
                                        value: !0
                                    }), !(e instanceof A.k)) {
                                    var a, s = null == i || null == (a = i.notification) ? void 0 : a.message;
                                    w.A.showNotification({
                                        type: w.A.TYPES.ERROR,
                                        text: s
                                    })
                                }
                            }), [o]);
                        (0, q.useEffect)((function() {
                            var e;
                            s && t ? (null == u || u(), null == (e = n.current) || e.cancel(), n.current = v.A.getInstance().startTransactionAsPromise(st(st({}, c), {}, {
                                ignoreStoredDetails: !0
                            })), n.current.then((function(e) {
                                var t = e.error,
                                    n = e.purchaseTransaction,
                                    i = e.clientPurchaseReceipt;
                                n ? null == u || u(n) : i ? null == r || r(i) : null == l || l(t || new Error("Error loading the payment details"), e)
                            }))) : o({
                                type: Je.BX.UPDATE_CURRENT_TRANSACTION,
                                value: void 0
                            })
                        }), [t, s, r, l, u, c, n, o])
                    }({
                        isActive: t,
                        onClientPurchaseReceipt: n
                    });
                    var b = function(e) {
                            s({
                                type: Je.BX.UPDATE_BILLING_EMAIL,
                                value: e.currentTarget.value
                            }), s({
                                type: Je.BX.UPDATE_EMAIL_ERROR_LABEL,
                                value: ""
                            })
                        },
                        T = function(e) {
                            e.preventDefault(), i()
                        },
                        S = function() {
                            var e, t, r = !g;
                            s({
                                type: Je.BX.UPDATE_AUTO_TOP_UP_VALUE,
                                value: r
                            }), e = r, t = void 0 !== y, (0, dt.sx)(332, {
                                element: 709,
                                parent_element: pt(t),
                                position: e ? 1 : 0
                            })
                        };
                    return t ? (0, le.jsxs)("div", {
                        className: "ucb-provider-item-content",
                        children: [l && (0, le.jsx)(at, {
                            url: u || "",
                            onRef: r,
                            isFullscreen: d,
                            hasDescription: E
                        }), (0, le.jsx)(it, {
                            billingEmail: {
                                isRequired: Boolean(null == m ? void 0 : m.is_billing_email_required),
                                email: f,
                                emailLabel: c.Ay.get(684),
                                emailErrorLabel: h,
                                onChangeEmail: b,
                                onSubmitEmail: T
                            },
                            autoTopUp: {
                                isRequired: null == m ? void 0 : m.is_auto_topup_available,
                                autoTopUpText: null == m ? void 0 : m.auto_top_up_text,
                                autoTopUpValue: g,
                                onChangeAutoTopUp: S
                            },
                            tnc: null == m ? void 0 : m.tnc,
                            onSubmit: i,
                            ctaText: null == m ? void 0 : m.service_action,
                            isLoading: p
                        })]
                    }) : null
                },
                ht = function(e) {
                    var t = e.iframeRef,
                        r = e.providers,
                        n = e.isStoredProviderPressed,
                        i = e.onSubmit,
                        a = e.onProviderSelected,
                        o = e.onClientPurchaseReceipt,
                        s = (0, Je.jh)().state,
                        u = s.selectedProvider,
                        l = s.userPickedPaymentMethod;
                    return (0, le.jsxs)("div", {
                        children: [(0, le.jsx)("div", {
                            className: "ucb-screen-title",
                            children: (0, le.jsx)(pe.ZS, {
                                children: n ? c.Ay.get(1046) : c.Ay.get(1045)
                            })
                        }), (0, le.jsx)("div", {
                            "data-qa": "payment-providers-wrapper",
                            className: "ucb-provider-items-list",
                            children: null == r ? void 0 : r.map((function(e) {
                                var r = (null == u ? void 0 : u.provider) === e.provider && (null == u ? void 0 : u.provider_id) === e.provider_id && l;
                                return (0, le.jsx)(rt, {
                                    label: e.provider_name,
                                    value: String(e.provider_id),
                                    iconImage: e.image,
                                    isSelected: r,
                                    onSelect: function() {
                                        return a(e)
                                    },
                                    children: (0, le.jsx)(ft, {
                                        iframeRef: t,
                                        isActive: r,
                                        onSubmit: i,
                                        onClientPurchaseReceipt: o
                                    })
                                }, e.provider + "_" + e.provider_id)
                            }))
                        })]
                    })
                },
                gt = function(e) {
                    var t = e.onSubmit,
                        r = e.onClick,
                        n = (0, Je.jh)().state.storedProvider;
                    return (0, le.jsxs)("div", {
                        children: [(0, le.jsx)("div", {
                            className: "ucb-screen-title",
                            children: (0, le.jsx)(pe.ZS, {
                                children: c.Ay.get(1047)
                            })
                        }), (0, le.jsxs)("div", {
                            "data-qa": "payment-providers-wrapper",
                            className: "ucb-provider-items-list",
                            children: [(0, le.jsx)(rt, {
                                label: null == n ? void 0 : n.provider_name,
                                value: String(null == n ? void 0 : n.provider),
                                iconImage: null == n ? void 0 : n.image,
                                isStored: !0,
                                onSelect: function() {
                                    return r(n)
                                }
                            }, null == n ? void 0 : n.provider), (0, le.jsx)(ft, {
                                isActive: !0,
                                onSubmit: t
                            })]
                        })]
                    })
                },
                vt = function(e) {
                    var t = e.onSubmit,
                        r = e.onProviderSelected,
                        n = (0, Je.jh)().state,
                        i = n.selectedProvider,
                        a = n.storedProvider,
                        o = n.userPickedPaymentMethod,
                        s = (null == i ? void 0 : i.provider) === (null == a ? void 0 : a.provider) && (null == i ? void 0 : i.provider_id) === (null == a ? void 0 : a.provider_id) && o;
                    return (0, le.jsxs)("div", {
                        children: [(0, le.jsx)("div", {
                            className: "ucb-screen-title",
                            children: (0, le.jsx)(pe.ZS, {
                                children: c.Ay.get(1047)
                            })
                        }), (0, le.jsx)("div", {
                            "data-qa": "payment-providers-wrapper",
                            className: "ucb-provider-items-list",
                            children: (0, le.jsx)(rt, {
                                label: null == a ? void 0 : a.provider_name,
                                value: String(null == a ? void 0 : a.provider),
                                isSelected: s,
                                iconImage: null == a ? void 0 : a.image,
                                onSelect: function() {
                                    return r(a)
                                },
                                children: (0, le.jsx)(ft, {
                                    isActive: s,
                                    onSubmit: t
                                })
                            }, null == a ? void 0 : a.provider)
                        })]
                    })
                },
                mt = r(64872),
                yt = r(55272),
                Pt = r(54129),
                At = r(7802),
                Et = r(34256),
                _t = r(58478);

            function bt(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function Tt(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? bt(Object(r), !0).forEach((function(t) {
                        St(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : bt(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function St(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var It = function(e) {
                    var t = e.title,
                        r = e.defaultUcbRecap,
                        n = e.transactionController,
                        i = e.onClose,
                        a = e.onSubmitPayment,
                        o = e.onClientPurchaseReceipt,
                        u = (0, Je.jh)(),
                        l = u.state,
                        d = u.dispatch,
                        p = l.isLoading,
                        f = l.billingEmail,
                        h = l.isStoredProviderPressed,
                        g = l.currentTransaction,
                        m = l.autoTopUpValue,
                        y = l.ignoreStoredDetails,
                        P = l.ccFormUrl,
                        A = l.ccFormState,
                        E = l.isCcPayment,
                        _ = l.selectedProvider,
                        b = l.storedProvider,
                        T = l.nonStoredProviders,
                        S = l.toBeClosed,
                        I = l.selectedProduct,
                        O = l.deviceProfilingId,
                        C = l.paymentOptions,
                        R = (0, Et.d)(),
                        w = lt(t),
                        D = w.title,
                        L = w.description,
                        j = (0, q.useRef)(null),
                        U = (0, q.useMemo)((function() {
                            return !b || h
                        }), [b, h]),
                        N = (0, q.useMemo)((function() {
                            return b && h
                        }), [h, b]),
                        x = (0, q.useMemo)((function() {
                            return b && !h
                        }), [h, b]),
                        M = x || N,
                        k = function(e) {
                            var t, r;
                            null != (t = j.current) && t.src && (null == (r = j.current) || null == (r = r.contentWindow) || r.postMessage({
                                event: e
                            }, "*"))
                        },
                        F = (0, q.useCallback)((function(e) {
                            d({
                                type: Je.BX.UPDATE_SELECTED_PROVIDER,
                                value: e
                            }), h && d({
                                type: Je.BX.UPDATE_IGNORE_STORED_DETAILS,
                                value: !0
                            })
                        }), [d, h]),
                        H = (0, q.useCallback)((function(e) {
                            F(e), d({
                                    type: Je.BX.UPDATE_USER_PICKED_PAYMENT_METHOD,
                                    value: !0
                                }),
                                function(e, t, r) {
                                    var n = (null == t ? void 0 : t.findIndex((function(t) {
                                        return t.provider === (null == e ? void 0 : e.provider)
                                    }))) || 0;
                                    (0, dt.sx)(332, {
                                        element: 2188,
                                        parent_element: pt(r),
                                        position: Math.max(n, 0)
                                    })
                                }(e, T, M)
                        }), [d, F, M, T]),
                        G = function(e) {
                            F(e), (0, dt.sx)(332, {
                                element: 2187,
                                parent_element: pt(!0),
                                position: 0
                            }), d({
                                type: Je.BX.UPDATE_STORED_PROVIDER,
                                value: e
                            }), d({
                                type: Je.BX.UPDATE_STORE_PROVIDER_PRESSED,
                                value: !0
                            })
                        },
                        V = function() {
                            if (function(e) {
                                    (0, dt.sx)(332, {
                                        element: 235,
                                        parent_element: pt(e)
                                    })
                                }(M), (0, _t.D)(_))(0, _t.V)(_, C, O);
                            else if (!E || j.current && P) {
                                if (d({
                                        type: Je.BX.UPDATE_IS_LOADING,
                                        value: !0
                                    }), At.q.setValue(!0), null != r && r.is_billing_email_required && !(0, K.m)(f || "")) return d({
                                    type: Je.BX.UPDATE_EMAIL_ERROR_LABEL,
                                    value: c.Ay.get(683)
                                }), void d({
                                    type: Je.BX.UPDATE_IS_LOADING,
                                    value: !1
                                });
                                if (E)(t = null == g ? void 0 : g.transaction_id) && B.K.set(t, {
                                    billingEmail: f
                                }), k(Y.An.SUBMIT_FORM);
                                else {
                                    if ((0, yt.K)(_) || (0, Pt.R)(_)) {
                                        var e = Tt(Tt({}, C), {}, {
                                            useSync: !0
                                        });
                                        v.A.getInstance().startTransaction(e, (function(e) {
                                            C.purchaseTransaction = e.purchaseTransaction, C.handleOnStartTransaction = !0
                                        }))
                                    } else C.purchaseTransaction = void 0, C.handleOnStartTransaction = void 0;
                                    f && (C.billingEmail = f), C.autoTopup = m, C.ignoreStoredDetails = y, a(C)
                                }
                                var t
                            }
                        };
                    (0, q.useEffect)((function() {
                        (x || N) && F(b)
                    }), [F, x, N, b]), (0, q.useEffect)((function() {
                        S && i()
                    }), [i, S]), (0, q.useEffect)((function() {
                        var e;
                        U && 1 === (null == T ? void 0 : T.length) && d({
                            type: Je.BX.UPDATE_CURRENT_UCB_RECAP,
                            value: null == I || null == (e = I.providers) ? void 0 : e[0].ucb_recap
                        })
                    }), [d, U, T, I]), (0, mt.L)({
                        selectedProvider: _,
                        transactionController: n,
                        isUcbFlow: !0
                    }),
                    function(e) {
                        var t = e.iframeRef,
                            r = e.isCcPayment,
                            n = (0, Je.jh)().dispatch;
                        (0, q.useEffect)((function() {
                            if (r) return s.A.addEventListener("message", i),
                                function() {
                                    return s.A.removeEventListener("message", i)
                                };

                            function e(e) {
                                var r = Number(e);
                                null != t && t.current && (isNaN(r) ? (t.current.height = "", t.current.style.height = "") : (t.current.height = r + "px", t.current.style.height = r + "px"))
                            }

                            function i(t) {
                                if (Ee(t.origin) && t.data) {
                                    var r = t.data,
                                        i = r.event,
                                        a = r.data;
                                    i && qe.includes(i) && n({
                                        type: Je.BX.UPDATE_IS_LOADING,
                                        value: !1
                                    }), i === Y.An.SECURITY_CHECK && (n({
                                        type: Je.BX.UPDATE_IS_CC_FORM_FULLSCREEN,
                                        value: !0
                                    }), n({
                                        type: Je.BX.UPDATE_CC_FORM_STATE,
                                        value: Je.Kl.SECURITY_STEP
                                    }), e("NaN")), i === Y.An.UPDATE_HEIGHT && e((a || {}).height)
                                }
                            }
                        }), [n, t, r])
                    }({
                        iframeRef: j,
                        isCcPayment: E
                    }), (0, q.useEffect)((function() {
                        k(Y.An.STORE_DETAILS)
                    }), [m]), (0, q.useEffect)((function() {
                        d({
                            type: Je.BX.UPDATE_IS_LOADING,
                            value: R
                        })
                    }), [d, R]), (0, q.useEffect)((function() {
                        var e = (null == T ? void 0 : T.length) || 1;
                        (0, dt.sx)(258, {
                            element: pt(void 0 !== b),
                            count: M ? 1 : e
                        })
                    }), [T, M, b]);
                    return (0, le.jsxs)(tt, {
                        title: D,
                        description: L,
                        onClickBack: function() {
                            h ? d({
                                type: Je.BX.UPDATE_STORE_PROVIDER_PRESSED,
                                value: !1
                            }) : i(g, A === Je.Kl.SECURITY_STEP)
                        },
                        isClosable: !h,
                        isLoading: p,
                        children: [(0, le.jsx)(et, {
                            title: null == r ? void 0 : r.title,
                            subTitle: null == r ? void 0 : r.display_price,
                            price: null == r ? void 0 : r.price
                        }), (0, le.jsxs)("div", {
                            className: "ucb-screen-wrapper__content_scrollable",
                            children: [x ? (0, le.jsx)(gt, {
                                onSubmit: V,
                                onClick: G
                            }) : null, N ? (0, le.jsx)(vt, {
                                onSubmit: V,
                                onProviderSelected: H
                            }) : null, U ? (0, le.jsx)(ht, {
                                iframeRef: j,
                                providers: T,
                                isStoredProviderPressed: h,
                                onSubmit: V,
                                onProviderSelected: H,
                                onClientPurchaseReceipt: o
                            }) : null]
                        })]
                    })
                },
                Ot = ["children"];

            function Ct(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function Rt(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Ct(Object(r), !0).forEach((function(t) {
                        wt(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Ct(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function wt(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var Dt = function(e) {
                    e.children;
                    var t = function(e, t) {
                        if (null == e) return {};
                        var r = {};
                        for (var n in e)
                            if ({}.hasOwnProperty.call(e, n)) {
                                if (t.includes(n)) continue;
                                r[n] = e[n]
                            }
                        return r
                    }(e, Ot);
                    return (0, le.jsx)(Je.FW, Rt(Rt({}, t), {}, {
                        children: (0, le.jsx)(It, {
                            title: t.title,
                            defaultUcbRecap: t.defaultUcbRecap,
                            onClose: t.onClose,
                            onSubmitPayment: t.onSubmitPayment,
                            onClientPurchaseReceipt: t.onClientPurchaseReceipt,
                            transactionController: t.transactionController
                        })
                    }))
                },
                Lt = r(91258),
                jt = function(e) {
                    var t = e.closeIconLabel,
                        r = e.psd2HeaderRef,
                        n = e.psd2Heading,
                        i = e.psd2Body,
                        a = e.onClose;
                    return Boolean(n || i) ? (0, le.jsxs)("div", {
                        ref: r,
                        children: [(0, le.jsxs)(re.A, {
                            position: "fixed",
                            shadow: !1,
                            children: [(0, le.jsx)(ie.A, {
                                children: (0, le.jsx)(ne.A, {
                                    name: "navigation-bar-close",
                                    onClick: a,
                                    a11y: {
                                        iconLabel: t
                                    }
                                })
                            }), (0, le.jsx)(oe.A, {
                                text: n
                            }), (0, le.jsx)(ae.A, {})]
                        }), (0, le.jsx)(re.A, {}), (0, le.jsx)("div", {
                            className: "payment-process-window__sub-header",
                            children: (0, le.jsx)("div", {
                                className: "payment-process-window__sub-header_content",
                                children: (0, le.jsx)(pe.P2, {
                                    children: i
                                })
                            })
                        })]
                    }) : (0, le.jsx)(re.A, {
                        position: "fixed",
                        transparent: !0,
                        children: (0, le.jsx)(ie.A, {
                            children: (0, le.jsx)(ne.A, {
                                name: "generic-close-circle-semitransparent",
                                a11y: {
                                    iconLabel: t
                                },
                                dataQA: {
                                    "data-qa": "navbar-close"
                                },
                                onClick: a
                            })
                        })
                    })
                },
                Ut = function(e) {
                    var t, r, n = e.children,
                        i = e.childrenContainerRef,
                        a = e.closeIconLabel,
                        o = e.isLoading,
                        s = void 0 !== o && o,
                        c = e.psd2Body,
                        u = e.psd2HeaderRef,
                        l = e.psd2Heading,
                        d = e.processWindowHeight,
                        p = e.onClose,
                        f = Boolean(l || c),
                        h = Z()({
                            "payment-process-window__content": !0,
                            "payment-process-window__content--fit": Boolean(f)
                        });
                    return f ? d && (r = {
                        height: d + "px"
                    }) : t = "stretch", (0, le.jsx)("div", {
                        className: "payment-process-window",
                        children: (0, le.jsxs)(J.A, {
                            children: [(0, le.jsx)(ee.A, {
                                children: (0, le.jsx)(jt, {
                                    closeIconLabel: a,
                                    psd2Body: c,
                                    psd2HeaderRef: u,
                                    psd2Heading: l,
                                    onClose: p
                                })
                            }), (0, le.jsx)($.A, {
                                align: t,
                                children: (0, le.jsx)("div", {
                                    className: h,
                                    style: r,
                                    children: (0, le.jsxs)("div", {
                                        className: "payment-process-window__fake",
                                        ref: i,
                                        children: [n, s ? (0, le.jsx)(ue.A, {}) : null]
                                    })
                                })
                            })]
                        })
                    })
                },
                Nt = function(e) {
                    var t = e.threeDSecureRedirect,
                        r = e.onClose,
                        n = e.onError,
                        i = e.onSuccess,
                        a = (0, q.useState)(!0),
                        o = a[0],
                        u = a[1],
                        l = (0, q.useState)(0),
                        d = l[0],
                        p = l[1],
                        f = (0, q.useRef)(null),
                        h = (0, q.useRef)(null);
                    (0, q.useEffect)((function() {
                        return Q.A.trigger(Q.A.BEFORE_SHOW_MODAL),
                            function() {
                                var e;
                                Q.A.trigger(Q.A.HIDE_MODAL), null == (e = h.current) || e.destroy()
                            }
                    }), []);
                    var g = (0, q.useCallback)((function() {
                        if (f.current) {
                            var e = s.A.document.body.clientHeight - f.current.clientHeight;
                            p(e)
                        }
                    }), []);
                    return (0, q.useEffect)((function() {
                        return s.A.addEventListener("resize", g),
                            function() {
                                s.A.removeEventListener("resize", g)
                            }
                    }), [g]), (0, le.jsx)(Ut, {
                        childrenContainerRef: function(e) {
                            if (e) {
                                var r = t.params || [];
                                h.current = new C.RQ({
                                    rootElement: e,
                                    data: {
                                        form_action_url: t.url,
                                        fields: r.reduce((function(e, t) {
                                            return e[t.key] = t.value, e
                                        }), {})
                                    },
                                    onSuccess: i,
                                    onError: n
                                }), s.A.setTimeout((function() {
                                    u(!1)
                                }), 1e3)
                            }
                        },
                        closeIconLabel: c.Ay.get(270),
                        isLoading: o,
                        processWindowHeight: d,
                        psd2Body: c.Ay.get(900),
                        psd2HeaderRef: function(e) {
                            f.current = e, g()
                        },
                        psd2Heading: c.Ay.get(901),
                        onClose: r
                    })
                },
                xt = r(27384),
                Mt = function(e) {
                    var t = e.closeIconLabel,
                        r = e.iframeRef,
                        n = e.iframeTitle,
                        i = e.iframeUrl,
                        a = e.isIframeHidden,
                        o = e.isLoading,
                        s = void 0 !== o && o,
                        c = e.isScrollableIframe,
                        u = void 0 !== c && c,
                        l = e.processWindowHeight,
                        d = e.psd2HeaderRef,
                        p = e.psd2Heading,
                        f = e.psd2Body,
                        h = e.onClose;
                    he(i);
                    var g = Z()({
                            "payment-process-window__iframe": !0,
                            "is-hidden": a
                        }),
                        v = u ? "yes" : "no";
                    return (0, le.jsx)(Ut, {
                        closeIconLabel: t,
                        isLoading: s,
                        processWindowHeight: l,
                        psd2Body: f,
                        psd2HeaderRef: d,
                        psd2Heading: p,
                        onClose: h,
                        children: (0, le.jsx)("iframe", {
                            title: n,
                            ref: r,
                            src: i,
                            className: g,
                            style: {
                                width: "100%",
                                height: "100%",
                                border: "none"
                            },
                            scrolling: v,
                            "data-qa": "payment-process-window"
                        })
                    })
                };
            var kt, Ft, Bt, Ht, Gt = {
                    CC_FORM: "cc_form",
                    EMBEDDED_SECURITY_CHECK: Y.vD.EMBEDDED,
                    REDIRECT_SECURITY_CHECK: Y.vD.REDIRECT
                },
                Vt = function(e) {
                    var t = e.isFinishingPayment,
                        r = void 0 !== t && t,
                        n = e.isIframeHidden,
                        i = e.isOneOffSecurityStep,
                        a = e.url,
                        o = e.onClose,
                        l = e.onIframeMounted,
                        d = (0, q.useState)(0),
                        p = d[0],
                        f = d[1],
                        h = (0, q.useState)(i ? Gt.EMBEDDED_SECURITY_CHECK : Gt.CC_FORM),
                        g = h[0],
                        v = h[1],
                        m = (0, q.useRef)(null),
                        y = (0, q.useRef)(!1),
                        P = (i || g !== Gt.CC_FORM) && !n,
                        A = (0, q.useCallback)((function() {
                            null == o || o(g === Gt.EMBEDDED_SECURITY_CHECK)
                        }), [o, g]);
                    (0, q.useEffect)((function() {
                        function e(e) {
                            Ee(e.origin) && e.data && (Object.prototype.hasOwnProperty.call(e.data, "isKeyboardVisible") && (y.current = Boolean(e.data.isKeyboardVisible)), function(e) {
                                var t;
                                return (null == (t = e.data) ? void 0 : t.event) === Y.An.SECURITY_CHECK
                            }(e) && v(e.data.type))
                        }
                        return Q.A.trigger(Q.A.BEFORE_SHOW_MODAL), s.A.addEventListener("message", e),
                            function() {
                                var t;
                                Q.A.trigger(Q.A.HIDE_MODAL), s.A.removeEventListener("message", e), u.A.ios && y.current && (y.current = !1, (t = s.A.document.createElement("input")).type = "text", s.A.document.body.appendChild(t), t.addEventListener("focus", (function() {
                                    s.A.setTimeout((function() {
                                        t.blur(), t.remove()
                                    }), 300)
                                })), t.focus())
                            }
                    }), []);
                    var E = (0, q.useCallback)((function() {
                        if (P && m.current) {
                            var e = s.A.document.body.clientHeight - m.current.clientHeight;
                            f(e)
                        }
                    }), [P]);
                    return (0, q.useEffect)((function() {
                        return s.A.addEventListener("resize", E),
                            function() {
                                s.A.removeEventListener("resize", E)
                            }
                    }), [E]), (0, le.jsx)(Mt, {
                        closeIconLabel: c.Ay.get(270),
                        iframeRef: function(e) {
                            e && (null == l || l(e))
                        },
                        iframeTitle: P ? c.Ay.get(321) : c.Ay.get(320),
                        iframeUrl: a,
                        isIframeHidden: n,
                        isLoading: r,
                        isScrollableIframe: g !== Gt.EMBEDDED_SECURITY_CHECK,
                        processWindowHeight: p,
                        psd2HeaderRef: function(e) {
                            m.current = e, E()
                        },
                        psd2Heading: P ? c.Ay.get(901) : void 0,
                        psd2Body: P ? c.Ay.get(900) : void 0,
                        onClose: A
                    })
                },
                Wt = r(86812),
                Yt = (r(50113), r(26910), r(72577), r(69079));

            function qt() {
                qt = function() {
                    return t
                };
                var e, t = {},
                    r = Object.prototype,
                    n = r.hasOwnProperty,
                    i = Object.defineProperty || function(e, t, r) {
                        e[t] = r.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    o = a.iterator || "@@iterator",
                    s = a.asyncIterator || "@@asyncIterator",
                    c = a.toStringTag || "@@toStringTag";

                function u(e, t, r) {
                    return Object.defineProperty(e, t, {
                        value: r,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    u({}, "")
                } catch (e) {
                    u = function(e, t, r) {
                        return e[t] = r
                    }
                }

                function l(e, t, r, n) {
                    var a = t && t.prototype instanceof m ? t : m,
                        o = Object.create(a.prototype),
                        s = new w(n || []);
                    return i(o, "_invoke", {
                        value: I(e, r, s)
                    }), o
                }

                function d(e, t, r) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, r)
                        }
                    } catch (e) {
                        return {
                            type: "throw",
                            arg: e
                        }
                    }
                }
                t.wrap = l;
                var p = "suspendedStart",
                    f = "suspendedYield",
                    h = "executing",
                    g = "completed",
                    v = {};

                function m() {}

                function y() {}

                function P() {}
                var A = {};
                u(A, o, (function() {
                    return this
                }));
                var E = Object.getPrototypeOf,
                    _ = E && E(E(D([])));
                _ && _ !== r && n.call(_, o) && (A = _);
                var b = P.prototype = m.prototype = Object.create(A);

                function T(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        u(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function S(e, t) {
                    function r(i, a, o, s) {
                        var c = d(e[i], e, a);
                        if ("throw" !== c.type) {
                            var u = c.arg,
                                l = u.value;
                            return l && "object" == typeof l && n.call(l, "__await") ? t.resolve(l.__await).then((function(e) {
                                r("next", e, o, s)
                            }), (function(e) {
                                r("throw", e, o, s)
                            })) : t.resolve(l).then((function(e) {
                                u.value = e, o(u)
                            }), (function(e) {
                                return r("throw", e, o, s)
                            }))
                        }
                        s(c.arg)
                    }
                    var a;
                    i(this, "_invoke", {
                        value: function(e, n) {
                            function i() {
                                return new t((function(t, i) {
                                    r(e, n, t, i)
                                }))
                            }
                            return a = a ? a.then(i, i) : i()
                        }
                    })
                }

                function I(t, r, n) {
                    var i = p;
                    return function(a, o) {
                        if (i === h) throw Error("Generator is already running");
                        if (i === g) {
                            if ("throw" === a) throw o;
                            return {
                                value: e,
                                done: !0
                            }
                        }
                        for (n.method = a, n.arg = o;;) {
                            var s = n.delegate;
                            if (s) {
                                var c = O(s, n);
                                if (c) {
                                    if (c === v) continue;
                                    return c
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if (i === p) throw i = g, n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            i = h;
                            var u = d(t, r, n);
                            if ("normal" === u.type) {
                                if (i = n.done ? g : f, u.arg === v) continue;
                                return {
                                    value: u.arg,
                                    done: n.done
                                }
                            }
                            "throw" === u.type && (i = g, n.method = "throw", n.arg = u.arg)
                        }
                    }
                }

                function O(t, r) {
                    var n = r.method,
                        i = t.iterator[n];
                    if (i === e) return r.delegate = null, "throw" === n && t.iterator.return && (r.method = "return", r.arg = e, O(t, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), v;
                    var a = d(i, t.iterator, r.arg);
                    if ("throw" === a.type) return r.method = "throw", r.arg = a.arg, r.delegate = null, v;
                    var o = a.arg;
                    return o ? o.done ? (r[t.resultName] = o.value, r.next = t.nextLoc, "return" !== r.method && (r.method = "next", r.arg = e), r.delegate = null, v) : o : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, v)
                }

                function C(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function R(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function w(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(C, this), this.reset(!0)
                }

                function D(t) {
                    if (t || "" === t) {
                        var r = t[o];
                        if (r) return r.call(t);
                        if ("function" == typeof t.next) return t;
                        if (!isNaN(t.length)) {
                            var i = -1,
                                a = function r() {
                                    for (; ++i < t.length;)
                                        if (n.call(t, i)) return r.value = t[i], r.done = !1, r;
                                    return r.value = e, r.done = !0, r
                                };
                            return a.next = a
                        }
                    }
                    throw new TypeError(typeof t + " is not iterable")
                }
                return y.prototype = P, i(b, "constructor", {
                    value: P,
                    configurable: !0
                }), i(P, "constructor", {
                    value: y,
                    configurable: !0
                }), y.displayName = u(P, c, "GeneratorFunction"), t.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === y || "GeneratorFunction" === (t.displayName || t.name))
                }, t.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, P) : (e.__proto__ = P, u(e, c, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, t.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, T(S.prototype), u(S.prototype, s, (function() {
                    return this
                })), t.AsyncIterator = S, t.async = function(e, r, n, i, a) {
                    void 0 === a && (a = Promise);
                    var o = new S(l(e, r, n, i), a);
                    return t.isGeneratorFunction(r) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, T(b), u(b, c, "Generator"), u(b, o, (function() {
                    return this
                })), u(b, "toString", (function() {
                    return "[object Generator]"
                })), t.keys = function(e) {
                    var t = Object(e),
                        r = [];
                    for (var n in t) r.push(n);
                    return r.reverse(),
                        function e() {
                            for (; r.length;) {
                                var n = r.pop();
                                if (n in t) return e.value = n, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, t.values = D, w.prototype = {
                    constructor: w,
                    reset: function(t) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = e, this.done = !1, this.delegate = null, this.method = "next", this.arg = e, this.tryEntries.forEach(R), !t)
                            for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = e)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(t) {
                        if (this.done) throw t;
                        var r = this;

                        function i(n, i) {
                            return s.type = "throw", s.arg = t, r.next = n, i && (r.method = "next", r.arg = e), !!i
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var o = this.tryEntries[a],
                                s = o.completion;
                            if ("root" === o.tryLoc) return i("end");
                            if (o.tryLoc <= this.prev) {
                                var c = n.call(o, "catchLoc"),
                                    u = n.call(o, "finallyLoc");
                                if (c && u) {
                                    if (this.prev < o.catchLoc) return i(o.catchLoc, !0);
                                    if (this.prev < o.finallyLoc) return i(o.finallyLoc)
                                } else if (c) {
                                    if (this.prev < o.catchLoc) return i(o.catchLoc, !0)
                                } else {
                                    if (!u) throw Error("try statement without catch or finally");
                                    if (this.prev < o.finallyLoc) return i(o.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var i = this.tryEntries[r];
                            if (i.tryLoc <= this.prev && n.call(i, "finallyLoc") && this.prev < i.finallyLoc) {
                                var a = i;
                                break
                            }
                        }
                        a && ("break" === e || "continue" === e) && a.tryLoc <= t && t <= a.finallyLoc && (a = null);
                        var o = a ? a.completion : {};
                        return o.type = e, o.arg = t, a ? (this.method = "next", this.next = a.finallyLoc, v) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), v
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var r = this.tryEntries[t];
                            if (r.finallyLoc === e) return this.complete(r.completion, r.afterLoc), R(r), v
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var r = this.tryEntries[t];
                            if (r.tryLoc === e) {
                                var n = r.completion;
                                if ("throw" === n.type) {
                                    var i = n.arg;
                                    R(r)
                                }
                                return i
                            }
                        }
                        throw Error("illegal catch attempt")
                    },
                    delegateYield: function(t, r, n) {
                        return this.delegate = {
                            iterator: D(t),
                            resultName: r,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = e), v
                    }
                }, t
            }

            function Qt(e, t, r, n, i, a, o) {
                try {
                    var s = e[a](o),
                        c = s.value
                } catch (e) {
                    return void r(e)
                }
                s.done ? t(c) : Promise.resolve(c).then(n, i)
            }

            function Kt(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function Xt(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Kt(Object(r), !0).forEach((function(t) {
                        zt(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Kt(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function zt(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function Zt(e, t) {
                return Zt = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, Zt(e, t)
            }! function(e) {
                e.CANCEL = "CANCEL", e.COMPLETE = "COMPLETE", e.FAILED = "FAILED", e.PROCESSING = "PROCESSING", e.SUCCESS = "SUCCESS"
            }(kt || (kt = {})),
            function(e) {
                e.BACK = "BACK"
            }(Ft || (Ft = {})),
            function(e) {
                e.SUCCESS = "SUCCESS", e.FAILED = "FAILED", e.CANCELLED = "CANCELLED"
            }(Bt || (Bt = {})),
            function(e) {
                e.DETECT_SLEEP = "DETECT_SLEEP", e.MANUAL = "MANUAL", e.MANUAL_INTERRUPTED = "MANUAL_INTERRUPTED", e.STORED = "STORED", e.LOCAL_STORAGE = "LOCAL_STORAGE", e.BILLING = "BILLING"
            }(Ht || (Ht = {}));
            var Jt = g.A.getInstance(),
                $t = "bd-payment-redirect",
                er = "/payment-container.html",
                tr = u.A.ios7 || u.A.samsungBrowser,
                rr = [],
                nr = [113, 117, 180, 192, 504],
                ir = function(e) {
                    function t() {
                        for (var t, r = arguments.length, n = new Array(r), a = 0; a < r; a++) n[a] = arguments[a];
                        return (t = e.call.apply(e, [this].concat(n)) || this).applePay = null, t.ccOverlayData = {
                            containerId: "",
                            hideIframe: !1,
                            iframe: null,
                            isFinishingPayment: !1,
                            isOneOffSecurityStep: !1,
                            url: ""
                        }, t.googlePay = null, t.orderRecapContainerId = "", t.ucbRecapContainerId = "", t.extraDataModalContainerId = "", t.paymentPopupWindow = null, t.paymentResultReceived = !1, t.paymentResultWait = null, t.threatmetrixHandler = null, t.threeDSData = {
                            containerId: "",
                            iframe: null
                        }, t.threeDS2Handler = null, t.transactionStarted = !1, t.transactionFinished = !1, t.currentTransaction = null, t.merchantValidationHandler = function(e) {
                            return new Promise((function(r, n) {
                                var i, a = (null == (i = t.applePay) ? void 0 : i.getTransactionId()) || "";
                                v.A.getInstance().validateMerchant({
                                    validationURL: e,
                                    transactionId: a
                                }).then((function(e) {
                                    if (!e.success) return n(new Error("Failed to validate the merchant"));
                                    try {
                                        var t = e.validation_data;
                                        if ("string" == typeof t) {
                                            var i = JSON.parse(t);
                                            r(i)
                                        } else n(new Error("Merchant session is not present"))
                                    } catch (e) {
                                        n(new Error("Merchant session is invalid"))
                                    }
                                })).catch(n)
                            }))
                        }, t.handleStartTransaction = function(e, r) {
                            if (!t.checkIfTransactionHasRequirements(e)) {
                                var n = e.error,
                                    i = e.purchaseTransaction;
                                if (!n && i) {
                                    var a = i.provider,
                                        o = function(e) {
                                            return e && k.includes(e)
                                        }(a),
                                        s = 192 === a,
                                        c = 180 === a;
                                    return o ? void t.startGoogleWalletPayment(i) : s ? void t.startGooglePayPayment(i) : c ? void t.startApplePayPayment(i) : void t.handlePurchaseTransaction(i, r)
                                }
                                var u = e.clientPurchaseReceipt;
                                t.removePaymentWindow().then((function() {
                                    if (!n && u) {
                                        var r = u.purchase_success ? Bt.SUCCESS : Bt.FAILED;
                                        t.handleTransactionFinished(r, Ht.STORED, e)
                                    } else t.handleTransactionFinished(Bt.FAILED, Ht.BILLING, e)
                                }))
                            }
                        }, t.handleErrorThreeDSecureRedirect = function() {
                            t.handleTransactionFinished(Bt.FAILED, Ht.BILLING)
                        }, t.handleError3DS2 = function() {
                            t.handleTransactionFinished(Bt.FAILED, Ht.BILLING)
                        }, t.handleIframeMounted = function(e) {
                            t.ccOverlayData.iframe = e, t.paymentPopupWindow = null == e ? void 0 : e.contentWindow
                        }, t.handleDeviceWakeUp = (0, i.A)((function() {
                            b.A.off(b.A.ACTIONS.WAKE_UP, t.handleDeviceWakeUp);
                            var e = D.VB.getPaymentResult();
                            e ? t.handleTransactionResultReceived({
                                result: e
                            }) : (t.log.error("Empty payment result after a device has woken up"), t.handleTransactionFinished(Bt.CANCELLED, Ht.DETECT_SLEEP))
                        }), 1e3), t.handleMessageReceived = function(e) {
                            var r;
                            Ee(e.origin) && (F(e, t.paymentPopupWindow) && (null != (r = e.data) && r.data ? (t.mustHandleDeviceWakeUp() && b.A.off(b.A.ACTIONS.WAKE_UP, t.handleDeviceWakeUp), t.handleTransactionResultReceived({
                                result: e.data.data
                            })) : (t.log.error("Payment failed, invalid message", {
                                data: e.data
                            }), t.handleTransactionFinished(Bt.CANCELLED, Ht.LOCAL_STORAGE))))
                        }, t.handlePaymentReceipt = function(e, r) {
                            var n = !e && null != r && r.purchase_success ? Bt.SUCCESS : Bt.FAILED;
                            if (r && "purchase_success" in r) {
                                var i = rr.indexOf((null == r ? void 0 : r.transaction_identifier) || "");
                                i > -1 && rr.splice(i, 1)
                            }
                            t.handleTransactionFinished(n, Ht.LOCAL_STORAGE, {
                                clientPurchaseReceipt: r
                            })
                        }, t.handleIframeClosed = function(e) {
                            t.removeCcOverlay(), t.handleTransactionFinished(Bt.CANCELLED, e ? Ht.MANUAL_INTERRUPTED : Ht.MANUAL)
                        }, t.handleClickCloseThreeDSecureRedirectIframe = function() {
                            ur(t.getParameters(), t.threeDSData.purchaseTransaction, {
                                cancellation_reason: 1
                            }), t.removeThreeDSecureRedirectOverlay(), t.handleTransactionFinished(Bt.CANCELLED, Ht.MANUAL), t.trigger(kt.CANCEL)
                        }, t.handleReceiptAnyRecapPayment = function(e) {
                            t.handleStartTransaction({
                                clientPurchaseReceipt: e
                            })
                        }, t.handleSubmitAnyRecapPayment = function(e) {
                            t.updateParameters(e)
                        }, t.handleChangePaymentMethod = function() {
                            var e = t.getParameter("orderRecapFlow");
                            null == e || null == e.onChangePaymentMethod || e.onChangePaymentMethod(), t.removeOrderRecap()
                        }, t.handleCloseOrderRecap = function(e, r) {
                            if (e) {
                                var n = {
                                    cancellation_reason: r ? 3 : 1
                                };
                                ur(t.getParameters(), e, n)
                            }
                            var i = t.getParameter("orderRecapFlow");
                            null == i || null == i.onClose || i.onClose(), t.removeOrderRecap()
                        }, t.handleCloseUcbRecap = function(e, r) {
                            if (e) {
                                var n = {
                                    cancellation_reason: r ? 3 : 1
                                };
                                ur(t.getParameters(), e, n)
                            }
                            t.removeUcbRecap()
                        }, t.removeExtraDataModal = function() {
                            t.extraDataModalContainerId && (t.removeReactView((0, xt.j)()), t.extraDataModalContainerId = "")
                        }, t
                    }
                    var r, n;
                    n = e, (r = t).prototype = Object.create(n.prototype), r.prototype.constructor = r, Zt(r, n);
                    var u = t.prototype;
                    return u.getParameters = function() {
                        return e.prototype.getParameters.call(this)
                    }, u.onParametersUpdate = function() {
                        var e = this.getParameters();
                        return t.hasRequiredParamsMissed(e) ? (this.log.error("Haven't got all the parameters we need"), f.A.back(), void this.trigger(Ft.BACK)) : (this.transactionFinished = !1, this.transactionStarted = !0, this.paymentResultReceived = !1, this.isOrderRecapFlow() ? this.renderOrderRecap() : this.isUcbRecapFlow() ? this.renderUcbRecap() : this.isExtraModalFlow() ? this.renderExtraDataModal(e) : void this.startTransaction(e))
                    }, t.getExtraDataModalFlow = function(e) {
                        return e.extraDataModalFlow
                    }, t.hasRequiredParamsMissed = function(e) {
                        return !("number" == typeof e.provider && "string" == typeof e.providerName && "string" == typeof e.uid) && !Boolean(e.ucbRecapFlow)
                    }, u.getTransactionFromParams = function(e) {
                        var t = e || Xt({}, this.getParameters());
                        return Xt(Xt({}, t), {}, {
                            useSync: tr
                        })
                    }, u.startTransaction = function(e) {
                        var t = this;
                        if (!e.purchaseTransaction || e.orderRecapFlow) {
                            or(e.provider) && ar() && !tr && this.openPaymentWindow(er);
                            var r = this.getTransactionFromParams(e);
                            v.A.getInstance().startTransaction(r, this.handleStartTransaction)
                        } else e.handleOnStartTransaction ? (or(e.provider) && this.openPaymentWindow(er), this.handleStartTransaction({
                            purchaseTransaction: e.purchaseTransaction
                        })) : cr(e).then((function(e) {
                            t.handleStartTransaction({
                                clientPurchaseReceipt: e
                            })
                        })).catch((function(e) {
                            t.handleStartTransaction({
                                error: e
                            })
                        }))
                    }, u.checkPendingPayment = function() {
                        var e = D.VB.getPaymentResult();
                        return !!e && (this.handleTransactionResultReceived({
                            result: e,
                            sameWindow: !0
                        }), !0)
                    }, u.onStart = function() {
                        f.A.navigationEvent.subscribe(this.handleNavigation, this), this.resetCcOverlayData()
                    }, u.onStop = function() {
                        return this.paymentResultWait && (this.paymentResultWait.stop(), this.paymentResultWait = null), this.resetCcOverlayData(), f.A.navigationEvent.unsubscribe(this.handleNavigation, this), s.A.removeEventListener("message", this.handleMessageReceived), this.mustHandleDeviceWakeUp() && b.A.off(b.A.ACTIONS.WAKE_UP, this.handleDeviceWakeUp), this.removePaymentWindow().then((function() {
                            D.VB.removePaymentResult()
                        }))
                    }, u.initApplePay = function(e) {
                        var t = this,
                            r = Xt(Xt({}, e), {}, {
                                onReady: function(r, n) {
                                    t.handleApplePayReady(r), "function" == typeof e.onReady && e.onReady(r, n)
                                },
                                merchantValidationHandler: this.merchantValidationHandler
                            });
                        return this.applePay = new S.A(r), this.applePay
                    }, u.handleApplePayReady = function(e) {
                        e && !(0, Wt.y)(e) && (w.A.showNotification({
                            type: w.A.TYPES.ERROR
                        }), this.log.error("Apple Pay initialized with an error", {
                            error: e
                        }))
                    }, u.initGooglePay = function(e) {
                        var t = this,
                            r = Xt(Xt({}, e), {}, {
                                onReady: function(r, n) {
                                    r ? t.handleGooglePayError(r) : "function" == typeof e.onReady && e.onReady(null, n)
                                }
                            });
                        return this.googlePay = new I.A(r), this.googlePay
                    }, u.handleGooglePayError = function(e) {
                        w.A.showNotification({
                            type: w.A.TYPES.ERROR
                        }), this.log.error("Google pay initialized with an error", {
                            error: e
                        })
                    }, u.checkIfTransactionHasRequirements = function(e) {
                        return !!(0, W.Q)(e.purchaseTransactionFailed) && (this.removePaymentWindow().then((function() {
                            lr(e.purchaseTransactionFailed), f.A.navigate(h.x.ADD_PHOTOS, {
                                backHistoryEntry: f.A.getHistoryEntryId(),
                                destination: f.A.getUrl()
                            })
                        })), !0)
                    }, u.handlePurchaseTransaction = function(e, t) {
                        if (!e) return this.log.error("Missing transactionResult handling the startTransaction", {
                            transactionParams: t || this.getTransactionFromParams()
                        }), void this.handleTransactionFinished(Bt.FAILED, Ht.BILLING);
                        (this.currentTransaction = e, Oe(e)) ? this.startOneOff3DS2Handler({
                            redirect_url: e.redirect_url,
                            is_hidden_view: e.is_hidden_view,
                            hidden_view_timeout_sec: e.hidden_view_timeout_sec
                        }, e): (0, O.k)(e) ? this.startThreatmetrixProfiling(e, t) : ar() && this.startWindowPayment(e) || function(e) {
                            var t = e.redirect_url;
                            t && (r = r || f.A.getUrl(), f.A.saveHistory(), E.A.set($t, "/" + r), s.A.location = t);
                            var r
                        }(e)
                    }, u.startThreatmetrixProfiling = function(e, t) {
                        var r = this;
                        this.removeThreatmetrixHandler(), this.threatmetrixHandler = new O._(e), this.threatmetrixHandler.startProfiling().then((function(n) {
                            var i = t ? Xt({}, t) : r.getTransactionFromParams();
                            i.threatmetrixSessionId = e.threatmetrix_session_id, i.threatmetrixProfilingStatus = n.status, 2 !== n.status && r.log.error(n.error, {
                                profilingStatus: n.status,
                                profilingType: e.threatmetrix_profiling_type
                            }), v.A.getInstance().startTransaction(i, r.handleStartTransaction)
                        }))
                    }, u.startThreeDSecureRedirectHandler = function(e) {
                        Jt.pauseHistory(), this.threeDSData.redirect = e.three_d_secure_redirect, this.threeDSData.purchaseTransaction = e, this.renderThreeDSecureRedirectOverlay()
                    }, u.handleSuccessThreeDSecureRedirect = function(e) {
                        var t = this,
                            r = this.threeDSData,
                            n = r.purchaseTransaction;
                        if (r.containerId)
                            if (e.receipt_data) {
                                var i = this.getParameters(),
                                    a = i.priceToken,
                                    o = i.productType,
                                    s = i.providerName;
                                cr({
                                    priceToken: a,
                                    productType: o,
                                    provider: (null == n ? void 0 : n.provider) || this.getParameter("provider"),
                                    providerId: (null == n ? void 0 : n.provider_id) || this.getParameter("providerId"),
                                    providerName: s,
                                    purchaseTransaction: n,
                                    receiptData: e.receipt_data,
                                    uid: (null == n ? void 0 : n.uid) || this.getParameter("uid")
                                }).then((function(e) {
                                    t.handleStartTransaction({
                                        clientPurchaseReceipt: e
                                    })
                                })).catch((function(e) {
                                    t.handleStartTransaction({
                                        error: e
                                    })
                                }))
                            } else this.handleErrorThreeDSecureRedirect()
                    }, u.startOneOff3DS2Handler = function(e, t) {
                        var r, n, i = this;
                        Jt.pauseHistory(), this.ccOverlayData.containerId && (r = (0, xt.j)(), n = this.ccOverlayData.iframe || void 0, this.ccOverlayData.hideIframe = Boolean(null == e ? void 0 : e.is_hidden_view), this.ccOverlayData.isOneOffSecurityStep = !0, this.renderCcOverlay()), this.threeDS2Handler ? this.threeDS2Handler.updateOptions({
                            data: e,
                            onSuccess: function(e) {
                                return i.handleSuccess3DS2(t, e)
                            }
                        }) : this.threeDS2Handler = new C.Us({
                            rootElement: r,
                            iframe: n,
                            data: e,
                            onSuccess: function(e) {
                                return i.handleSuccess3DS2(t, e)
                            },
                            onError: this.handleError3DS2
                        }), this.threeDS2Handler.start()
                    }, u.handleSuccess3DS2 = function(e, t) {
                        var r = this;
                        this.threeDS2Handler && (t.redirect_url ? this.startOneOff3DS2Handler(t, e) : t.receipt_data ? cr({
                            purchaseTransaction: e,
                            productType: this.getParameter("productType"),
                            providerName: this.getParameter("providerName"),
                            priceToken: "",
                            providerId: e.provider_id,
                            provider: e.provider,
                            uid: e.uid,
                            receiptData: t.receipt_data
                        }).then((function(e) {
                            r.handleStartTransaction({
                                clientPurchaseReceipt: e
                            })
                        })).catch((function(e) {
                            r.handleStartTransaction({
                                error: e
                            })
                        })) : this.handleError3DS2())
                    }, u.startGoogleWalletPayment = function(e) {
                        var t = e.transaction_id,
                            r = e.unique_flow_id,
                            n = e.provider_product_uid,
                            i = 117 === e.provider,
                            a = this.getParameter("productType"),
                            o = s.A.location.pathname;
                        if (5 === a) {
                            for (var c = s.A.location.pathname.split("/"), u = 0; u < c.length; u += 1)
                                if (c[u] === r) {
                                    c[u + 2] = String(13);
                                    break
                                }
                            o = c.join("/")
                        }
                        var l = "" + s.A.location.origin + o + "?__twa=1";
                        if (s.A.localStorage) {
                            x.createTransaction(e), f.A.saveHistory();
                            var d = (0, H.F)({
                                transactionId: t,
                                sku: n,
                                isSubscription: Boolean(i),
                                resultUrl: l
                            });
                            s.A.location = d
                        }
                    }, u.startGooglePayPayment = function(e) {
                        var t, r = this;
                        null != (t = this.googlePay) && t.isReadyToPay() ? this.googlePay.submitPaymentDataRequest(e, (function(e) {
                            var t = function(e) {
                                    e && (e instanceof A.k || w.A.showNotification({
                                        type: w.A.TYPES.ERROR
                                    }), (0, _.A)(e) && r.log.error("Start transaction as promise failed", {
                                        error: e
                                    })), r.trigger(kt.CANCEL)
                                },
                                n = r.getParameters();
                            v.A.getInstance().startTransactionAsPromise(Xt(Xt({}, n), {}, {
                                googlePayToken: e
                            })).then((function(e) {
                                var n, i, a, o = e.clientPurchaseReceipt,
                                    s = e.error,
                                    c = e.purchaseTransaction,
                                    u = e.purchaseTransactionFailed;
                                o ? (n = null, a = null == (i = o) ? void 0 : i.purchase_success, !n && a || (r.trigger(kt.CANCEL), r.log.error("Google Pay failed on the provider side", {
                                    error: n
                                })), r.handlePaymentReceipt(n, i)) : u ? (lr(u), r.trigger(kt.CANCEL)) : null != c && c.three_d_secure_redirect ? r.startThreeDSecureRedirectHandler(c) : s ? t(s) : (r.log.error("Unexpected server purchase transaction response after google pay payment", {
                                    response: e
                                }), r.trigger(kt.CANCEL))
                            })).catch(t)
                        }), (function(t) {
                            if (t.statusCode && "CANCELED" === t.statusCode) {
                                ur(r.getParameters(), e, {
                                    cancellation_reason: 2
                                })
                            } else w.A.showNotification({
                                type: w.A.TYPES.ERROR
                            }), r.log.error("Google Pay failed", {
                                error: t,
                                transactionResult: e
                            });
                            r.trigger(kt.CANCEL)
                        })) : (this.log.error("User has seen Google Pay section, but device does not support Google Pay"), w.A.showNotification({
                            type: w.A.TYPES.ERROR
                        }), this.trigger(kt.CANCEL), this.removeOrderRecap(), this.removeUcbRecap())
                    }, u.startApplePayPayment = function(e) {
                        var t, r, n = this,
                            i = null == (t = this.applePay) ? void 0 : t.getIsPaymentsPossible(),
                            a = null == (r = this.applePay) ? void 0 : r.getIsPaymentsAvailable();
                        if (i)
                            if (a) {
                                var o, s, u = c.Ay.get(1039);
                                null == (o = this.applePay) || o.updateCurrentSession(e, u);
                                var l = this.getApplePaySessionHandlers();
                                null == (s = this.applePay) || s.startSession(l)
                            } else {
                                var d, p;
                                null == (d = this.applePay) || d.updatePurchaseTransactionData(e), null == (p = this.applePay) || p.setupApplePay().catch((function(t) {
                                    w.A.showNotification({
                                        type: w.A.TYPES.ERROR
                                    }), n.log.error("ApplePay is not available on this device", {
                                        error: t,
                                        purchaseTransaction: e
                                    }), n.trigger(kt.CANCEL), n.removeOrderRecap(), n.removeUcbRecap()
                                }))
                            }
                        else this.log.error("User have seen the Apple Pay section, but his devices does not support Apple Pay"), w.A.showNotification({
                            type: w.A.TYPES.ERROR
                        }), this.removeOrderRecap(), this.removeUcbRecap()
                    }, u.reCheckApplePaymentAvailability = function(e, t) {
                        if (e = "function" == typeof e ? e : a.A, t = "function" == typeof t ? t : a.A, this.transactionStarted) {
                            if (this.applePay) return e(), this.applePay.checkForApplePayAvailability(t);
                            this.log.error("ApplePay has not been initialized in the TransactionsController")
                        }
                    }, u.getApplePaySessionHandlers = function() {
                        var e = this;
                        return {
                            onValidateMerchant: function(t, r) {
                                t && (w.A.showNotification({
                                    type: w.A.TYPES.ERROR
                                }), e.log.error("Merchant validation failed", {
                                    error: t,
                                    merchantSession: r
                                }), e.trigger(kt.CANCEL))
                            },
                            onPaymentAuthorized: function(t, r) {
                                return e.handleApplePayPaymentResult(t, r)
                            },
                            onCancel: function(t, r) {
                                e.trigger(kt.CANCEL)
                            }
                        }
                    }, u.handleApplePayPaymentResult = function(e, t) {
                        var r = this;
                        return new Promise((function(n, i) {
                            var a;
                            if (e) return w.A.showNotification({
                                type: w.A.TYPES.ERROR
                            }), r.trigger(kt.CANCEL), i(new Error("Apple Pay failed for unknown reason"));
                            var o = t || {},
                                s = o.transactionId,
                                c = void 0 === s ? "" : s,
                                u = o.providerId,
                                l = void 0 === u ? "" : u,
                                d = o.uid,
                                p = void 0 === d ? "" : d,
                                f = o.event,
                                h = (null == f || null == (a = f.payment) || null == (a = a.token) ? void 0 : a.paymentData) || {},
                                g = JSON.stringify(h),
                                m = {
                                    uid: p,
                                    success: !0,
                                    _id: String(c),
                                    _pid: String(l),
                                    _p: String(180),
                                    _receipt_data: g
                                };
                            v.A.getInstance().getPaymentReceipt(m).then((function(e) {
                                e.purchase_success ? n(e) : (r.trigger(kt.CANCEL), i(new Error("Apple Pay failed on the provider side"))), r.handlePaymentReceipt(null, e)
                            })).catch((function(e) {
                                r.trigger(kt.CANCEL), i(e), r.handlePaymentReceipt(e)
                            }))
                        }))
                    }, u.startWindowPayment = function(e) {
                        var t = e.redirect_url || "";
                        return this.listenForPaymentResult(), this.mustHandleDeviceWakeUp() && b.A.on(b.A.ACTIONS.WAKE_UP, this.handleDeviceWakeUp), this.setPaymentWindowUrl(t)
                    }, u.listenForPaymentResult = function() {
                        var e = this;
                        s.A.addEventListener("message", this.handleMessageReceived), this.paymentResultWait || (this.paymentResultWait = D.VB.waitForPaymentResult((function(t) {
                            e.handleTransactionResultReceived({
                                result: t
                            })
                        })))
                    }, u.setPaymentWindowUrl = function(e) {
                        if (this.paymentPopupWindow || this.ccOverlayData.containerId) {
                            var t;
                            if (this.isIframeFlow()) this.ccOverlayData.url = pr(e), this.renderCcOverlay();
                            else null == (t = this.paymentPopupWindow) || t.location.replace(e);
                            return !0
                        }
                        return this.openPaymentWindow(e)
                    }, u.openPaymentWindow = function(e) {
                        if (this.isIframeFlow()) return this.trigger(kt.PROCESSING), f.A.saveHistory(), Jt.pauseHistory(), this.ccOverlayData.url = pr(e), this.renderCcOverlay(), !0;
                        var t = s.A.open(e);
                        return !(!t || s.A.closed) && (this.paymentPopupWindow = t, !0)
                    }, u.renderCcOverlay = function() {
                        this.ccOverlayData.containerId = this.renderReactView((0, le.jsx)(Vt, {
                            url: this.ccOverlayData.url,
                            isOneOffSecurityStep: this.ccOverlayData.isOneOffSecurityStep,
                            isIframeHidden: this.ccOverlayData.hideIframe,
                            isFinishingPayment: this.ccOverlayData.isFinishingPayment,
                            onIframeMounted: this.handleIframeMounted,
                            onClose: this.handleIframeClosed
                        }), (0, xt.j)())
                    }, u.renderThreeDSecureRedirectOverlay = function() {
                        var e;
                        this.threeDSData.containerId = this.renderReactView((0, le.jsx)(Nt, {
                            threeDSecureRedirect: null == (e = this.threeDSData.purchaseTransaction) ? void 0 : e.three_d_secure_redirect,
                            onSuccess: this.handleSuccessThreeDSecureRedirect,
                            onError: this.handleErrorThreeDSecureRedirect,
                            onClose: this.handleClickCloseThreeDSecureRedirectIframe
                        }), (0, xt.j)())
                    }, u.handleTransactionResultReceived = function(e) {
                        var t = this,
                            r = e.result,
                            n = e.sameWindow,
                            i = void 0 !== n && n,
                            a = r._id;
                        this.paymentResultReceived || rr.includes(a) || (this.paymentResultReceived = !0, rr.push(a), sr(i ? "same_window" : "new_window"), this.ccOverlayData.isFinishingPayment = !0, this.hideIframe(), v.A.getInstance().getPaymentReceipt(r).then((function(e) {
                            t.handlePaymentReceipt(null, e)
                        })).catch((function(e) {
                            t.handlePaymentReceipt(e)
                        })))
                    }, u.onGooglePlayPaymentsToConsume = function(e, t) {
                        var r = this,
                            n = e.reduce((function(e, n) {
                                var i = n.transaction_id;
                                if (rr.includes(i)) return e;
                                x.getTransaction(i) || r.log.warn("Unable to find transaction in localStorage, continuing to send transaction anyway", {
                                    transactionId: i
                                });
                                var a = JSON.parse(n.google_response_json).productId,
                                    o = null;
                                if (t.forEach((function(e) {
                                        var t = e.uid,
                                            r = e.providers;
                                        null == r || r.forEach((function(e) {
                                            e.external_id === a && (o = s.A.btoa(t))
                                        }))
                                    })), !o) return r.log.warn("Unable to find any product with external_id " + a + "."), e;
                                var c = {
                                    _id: i,
                                    _p: "113",
                                    _pid: "30",
                                    uid: o,
                                    _receipt_data: n.google_response_json,
                                    _receipt_signature: n.google_signature
                                };
                                return x.addGoogleReceipt(n, i), e.push(c), e
                            }), []);
                        if (0 !== n.length) {
                            var i = [],
                                a = [],
                                o = [],
                                c = this;
                            this.trigger(kt.PROCESSING), n.forEach((function(e) {
                                v.A.getInstance().getPaymentReceipt(e).then((function(t) {
                                    u(e._id, 0, t)
                                })).catch((function(t) {
                                    u(e._id)
                                }))
                            }))
                        }

                        function u(e, t, r) {
                            if (null != r && r.purchase_success ? (x.addServerReceipt(r, e), rr.push(e), a.push(r), o.push(e)) : x.removeTransaction(e), i.push(e), i.length === n.length)
                                if (o.length) {
                                    var u = (0, H.F)({
                                        transactionId: o,
                                        consumeTransaction: !0
                                    });
                                    s.A.setTimeout((function() {
                                        c.trigger(kt.CANCEL), f.A.navigate(h.x.GOOGLE_PLAY_PURCHASE_SUCCESS, !0, {
                                            clientPurchaseReceipts: a,
                                            purchaseConsumeUrl: u,
                                            onPurchaseConsumed: function() {
                                                T.A.isOnline() && o.forEach((function(e) {
                                                    return x.removeTransaction(e)
                                                })), c.navigateAway(Bt.SUCCESS, {
                                                    clientPurchaseReceipt: a[a.length - 1]
                                                })
                                            }
                                        })
                                    }), 1e3)
                                } else c.navigateAway(Bt.FAILED, {
                                    clientPurchaseReceipt: r
                                })
                        }
                    }, u.onGooglePlayPaymentResult = function(e) {
                        var t = this,
                            r = e.result,
                            n = e.isCancelled,
                            i = e.isFailed;
                        if (!rr.includes(r.transaction_id)) {
                            var a = x.getTransaction(r.transaction_id);
                            if (a) {
                                this.trigger(kt.PROCESSING);
                                var o = {
                                    _id: a.transaction_id,
                                    _p: "113",
                                    _pid: "" + a.provider_id,
                                    uid: s.A.btoa(a.uid)
                                };
                                n || i ? n ? (o.success = "nope", o.cancellation_reason = 1, x.removeTransaction(r.transaction_id)) : i && (o.success = "nope", o.cancellation_reason = 2, x.removeTransaction(r.transaction_id)) : (o._receipt_data = s.A.atob(r.google_response_json), o._receipt_signature = r.google_signature, x.addGoogleReceipt(r, r.transaction_id), sr("new_window")), v.A.getInstance().getPaymentReceipt(o).then((function(e) {
                                    t.handleGooglePlayPaymentReceipt(a, null, e)
                                })).catch((function(e) {
                                    t.handleGooglePlayPaymentReceipt(a, e)
                                }))
                            } else this.log.error("Unable to find google play transaction in localStorage", {
                                result: r,
                                isCancelled: n,
                                isFailed: i
                            })
                        }
                    }, u.handleGooglePlayPaymentReceipt = function(e, t, r) {
                        var n = this,
                            i = e.transaction_id;
                        if (null != r && r.purchase_success) {
                            x.addServerReceipt(r, i);
                            var a = function(e) {
                                    var t, r = x.getGoogleReceipt(e);
                                    if (r) try {
                                        t = JSON.parse(s.A.atob(r.google_response_json)).purchaseToken
                                    } catch (e) {
                                        V.error("Error parsing Google receipt to get the purchaseToken", {
                                            error: e,
                                            googleReceiptData: r
                                        })
                                    }
                                    return t
                                }(i),
                                o = (0, H.F)({
                                    consumeTransaction: !0,
                                    purchaseToken: a,
                                    transactionId: i
                                });
                            117 === e.provider ? (x.removeTransaction(i), this.handlePaymentReceipt(t, r)) : (this.transactionFinished = !0, this.transactionStarted = !1, this.currentTransaction = null, rr.push(i), s.A.setTimeout((function() {
                                f.A.navigate(h.x.GOOGLE_PLAY_PURCHASE_SUCCESS, !0, {
                                    clientPurchaseReceipts: [r],
                                    purchaseConsumeUrl: o,
                                    onPurchaseConsumed: function() {
                                        T.A.isOnline() && x.removeTransaction(i), n.navigateAway(Bt.SUCCESS, {
                                            clientPurchaseReceipt: r
                                        })
                                    },
                                    backHistoryEntry: f.A.getHistoryEntryId(),
                                    destination: f.A.getUrl()
                                })
                            }), 1e3))
                        } else x.removeTransaction(i), this.handlePaymentReceipt(t, r)
                    }, u.handleTransactionFinished = function() {
                        var e, t = (e = qt().mark((function e(t, r, n) {
                            var i;
                            return qt().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (!this.transactionFinished) {
                                            e.next = 1;
                                            break
                                        }
                                        return this.log.warn("Transaction has finished already", t, r), e.abrupt("return");
                                    case 1:
                                        return e.next = 2, Jt.restartHistory();
                                    case 2:
                                        this.transactionFinished = !0, this.transactionStarted = !1, i = this.currentTransaction, this.currentTransaction = null, D.VB.removePaymentResult(), this.displayResultMessage({
                                            result: t,
                                            type: r,
                                            transactionResult: n,
                                            purchaseTransaction: i
                                        });
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this)
                        })), function() {
                            var t = this,
                                r = arguments;
                            return new Promise((function(n, i) {
                                var a = e.apply(t, r);

                                function o(e) {
                                    Qt(a, n, i, o, s, "next", e)
                                }

                                function s(e) {
                                    Qt(a, n, i, o, s, "throw", e)
                                }
                                o(void 0)
                            }))
                        });
                        return function(e, r, n) {
                            return t.apply(this, arguments)
                        }
                    }(), u.displayResultMessage = function(e) {
                        var t = e.result,
                            r = e.type,
                            n = e.transactionResult,
                            i = e.purchaseTransaction,
                            a = n || {},
                            o = a.clientPurchaseReceipt,
                            s = a.purchaseTransactionFailed;
                        if (t === Bt.SUCCESS) R.A.processClientPurchaseReceipt(o);
                        else if (t === Bt.CANCELLED && i)
                            if (11 === i.provider_id && i.processing_message) w.A.showNotification({
                                type: w.A.TYPES.INFO,
                                text: i.processing_message
                            });
                            else {
                                var c = {
                                    cancellation_reason: function() {
                                        switch (r) {
                                            case Ht.MANUAL:
                                                return 1;
                                            case Ht.MANUAL_INTERRUPTED:
                                                return 3;
                                            default:
                                                return 0
                                        }
                                    }()
                                };
                                ur(this.getParameters(), i, c)
                            }
                        else if (t !== Bt.CANCELLED || ![Ht.MANUAL, Ht.MANUAL_INTERRUPTED].includes(r)) {
                            var u, l = (null == s ? void 0 : s.notification) || (null == o ? void 0 : o.notification);
                            l && (u = l.message), w.A.showNotification({
                                type: w.A.TYPES.ERROR,
                                text: u
                            })
                        }
                        this.navigateAway(t, n)
                    }, u.navigateAway = function(e, t) {
                        var r = this;
                        this.removePaymentWindow().then((function() {
                            if (e === Bt.CANCELLED) return r.trigger(Ft.BACK), void r.trigger(kt.CANCEL);
                            var n = t || {},
                                i = n.clientPurchaseReceipt,
                                a = n.purchaseTransactionFailed;
                            e === Bt.SUCCESS ? (m.A.getInstance().invalidate(l.A.getUserId()), y.A.getInstance().invalidatePaymentFolders(), P.A.getInstance().invalidate(), r.trigger(kt.SUCCESS, i)) : r.trigger(kt.FAILED, a || i), r.trigger(kt.COMPLETE)
                        }))
                    }, u.removePaymentWindow = function() {
                        var e = this;
                        if (!(this.paymentPopupWindow || this.ccOverlayData.containerId || this.threeDSData.containerId || this.orderRecapContainerId || this.ucbRecapContainerId || this.extraDataModalContainerId)) return Promise.resolve();
                        if (this.isOrderRecapFlow() || this.isUcbRecapFlow()) Jt.restartHistory().then((function() {
                            e.removePaymentFlows()
                        }));
                        else {
                            if (this.isIframeFlow()) return this.paymentPopupWindow = null, Jt.restartHistory().then((function() {
                                e.removePaymentFlows()
                            }));
                            if (this.threeDSData.containerId) return Jt.restartHistory().then((function() {
                                e.removePaymentFlows()
                            }))
                        }
                        return function(e) {
                            var t = e.log,
                                r = e.remoteWindow,
                                n = function() {
                                    try {
                                        if (!r) return;
                                        if (r.closed) return;
                                        if (!(0, o.A)(r.close)) return;
                                        if (!(0, o.A)(r.setTimeout)) return;
                                        r.setTimeout(n, 0), r.close()
                                    } catch (e) {
                                        t.error("Error closing window!", {
                                            error: e
                                        })
                                    }
                                };
                            n()
                        }({
                            remoteWindow: this.paymentPopupWindow,
                            log: this.log
                        }), this.paymentPopupWindow = null, Promise.resolve()
                    }, u.mustHandleDeviceWakeUp = function() {
                        return !(this.isIframeFlow() || this.isOrderRecapFlow() && (0, M.n8)(this.getParameter("providerId")))
                    }, u.isExtraModalFlow = function(e) {
                        var r = e || this.getParameters();
                        return void 0 !== t.getExtraDataModalFlow(r)
                    }, u.isOrderRecapFlow = function() {
                        return Boolean(this.getParameter("orderRecapFlow"))
                    }, u.isUcbRecapFlow = function() {
                        return Boolean(this.getParameter("ucbRecapFlow"))
                    }, u.isIframeFlow = function() {
                        var e = this.getParameters(),
                            t = e.forceIframeFlow,
                            r = e.providerId,
                            n = (0, M.n8)(r);
                        if (this.isOrderRecapFlow()) {
                            var i = this.getParameter("orderRecapFlow");
                            return !!n && Boolean(i.storedDetails)
                        }
                        return t || n
                    }, u.removeCcOverlay = function() {
                        this.ccOverlayData.containerId && (this.removeReactView((0, xt.j)()), this.resetCcOverlayData())
                    }, u.resetCcOverlayData = function() {
                        this.ccOverlayData = {
                            containerId: "",
                            hideIframe: !1,
                            iframe: null,
                            isFinishingPayment: !1,
                            isOneOffSecurityStep: !1,
                            url: ""
                        }
                    }, u.removeThreeDSecureRedirectOverlay = function() {
                        this.threeDSData.containerId && (this.removeReactView((0, xt.j)()), this.threeDSData = {
                            containerId: "",
                            iframe: null
                        })
                    }, u.handleNavigation = function() {
                        this.removePaymentFlows()
                    }, u.removePaymentFlows = function() {
                        this.removeCcOverlay(), this.removeThreeDSecureRedirectOverlay(), this.remove3DS2Handler(), this.removeThreatmetrixHandler(), this.removeOrderRecap(), this.removeUcbRecap()
                    }, u.remove3DS2Handler = function() {
                        this.threeDS2Handler && (this.threeDS2Handler.stop(), this.threeDS2Handler = null)
                    }, u.removeThreatmetrixHandler = function() {
                        this.threatmetrixHandler && (this.threatmetrixHandler.destroy(), this.threatmetrixHandler = null)
                    }, u.hideIframe = function() {
                        (this.ccOverlayData.containerId || this.isUcbRecapFlow() || this.isOrderRecapFlow()) && (this.ccOverlayData.hideIframe = !0, this.renderCcOverlay()), this.threeDS2Handler && this.threeDS2Handler.hideIframe()
                    }, u.renderOrderRecap = function() {
                        Jt.pauseHistory(), this.listenForPaymentResult();
                        var e = this.getParameter("orderRecapFlow");
                        e ? this.orderRecapContainerId = this.renderReactView((0, le.jsx)(Ze, {
                            paymentOptions: e.paymentOptions,
                            orderRecap: e.orderRecap,
                            mop: e.mop,
                            storedDetails: e.storedDetails,
                            ignoreStoredDetails: e.ignoreStoredDetails,
                            title: e.title,
                            allowChangePackage: e.allowChangePackage,
                            onClientPurchaseReceipt: this.handleReceiptAnyRecapPayment,
                            onClose: this.handleCloseOrderRecap,
                            onChangePackage: e.onChangePackage,
                            onChangePaymentMethod: this.handleChangePaymentMethod,
                            onSubmitPayment: this.handleSubmitAnyRecapPayment
                        }), (0, xt.j)()) : this.log.error('Failed to render the OrderRecap screen. The "orderRecapFlow" parameter was undefined.')
                    }, u.renderUcbRecap = function() {
                        Jt.pauseHistory(), this.listenForPaymentResult();
                        var e = function(e) {
                            var t, r, n = e.productsList,
                                i = e.providersList,
                                a = e.paymentOptions,
                                o = e.title,
                                s = null == n ? void 0 : n.find((function(e) {
                                    return e.uid === a.uid
                                })),
                                c = null == s || null == (t = s.providers) ? void 0 : t.map((function(e) {
                                    return e.provider_id
                                })),
                                u = null == i ? void 0 : i.filter((function(e) {
                                    return null == c ? void 0 : c.includes(e.provider_id)
                                })),
                                l = null == i ? void 0 : i.find((function(e) {
                                    return e.provider === a.provider
                                })),
                                d = null == u ? void 0 : u.find((function(e) {
                                    return 100001 === e.provider
                                })),
                                p = null == u ? void 0 : u.filter((function(e) {
                                    return 100001 !== e.provider
                                })).sort(Yt.e);
                            return {
                                title: o,
                                defaultUcbRecap: null == s || null == (r = s.providers) || null == (r = r[0]) ? void 0 : r.ucb_recap,
                                paymentOptions: a,
                                selectedProduct: s,
                                selectedProvider: l,
                                storedProvider: d,
                                nonStoredProviders: p
                            }
                        }(this.getParameter("ucbRecapFlow"));
                        s.A.document.body.classList.add("fullscreen"), this.ucbRecapContainerId = this.renderReactView((0, le.jsx)(Dt, {
                            title: e.title,
                            defaultUcbRecap: e.defaultUcbRecap,
                            paymentOptions: e.paymentOptions,
                            selectedProduct: e.selectedProduct,
                            selectedProvider: e.selectedProvider,
                            storedProvider: e.storedProvider,
                            nonStoredProviders: e.nonStoredProviders,
                            onClose: this.handleCloseUcbRecap,
                            onClientPurchaseReceipt: this.handleReceiptAnyRecapPayment,
                            onSubmitPayment: this.handleSubmitAnyRecapPayment,
                            transactionController: this
                        }), (0, xt.j)())
                    }, u.renderExtraDataModal = function(e) {
                        if (t.getExtraDataModalFlow(e) === Y.qR.PROVIDER_PLAID) this.renderExtraDataModalProviderPlaid(e)
                    }, u.renderExtraDataModalProviderPlaid = function(e) {
                        this.extraDataModalContainerId = this.renderReactView((0, le.jsx)(Lt.A, {
                            paymentOptions: e,
                            onReturn: this.removeExtraDataModal
                        }), (0, xt.j)())
                    }, u.removeOrderRecap = function() {
                        this.orderRecapContainerId && (this.removeReactView((0, xt.j)()), this.orderRecapContainerId = "")
                    }, u.removeUcbRecap = function() {
                        if (this.ucbRecapContainerId) {
                            this.removeReactView((0, xt.j)()), this.ucbRecapContainerId = "";
                            var e = this.getParameter("ucbRecapFlow");
                            null == e || null == e.onClose || e.onClose(), s.A.document.body.classList.remove("fullscreen")
                        }
                    }, t
                }(d.A);

            function ar() {
                return !p.A.isWindowsDevice && !p.A.isHuaweiQuickApp()
            }

            function or(e) {
                return e && !nr.includes(e)
            }

            function sr(e) {
                (0, dt.sx)(51, {
                    event_name: "redirect_payment",
                    p1: e
                })
            }

            function cr(e) {
                var t, r = (null == (t = e.purchaseTransaction) ? void 0 : t.transaction_id) || "",
                    n = B.K.remove(r),
                    i = {
                        payment_success: !0,
                        transaction_identifier: r,
                        provider_id: Number(e.providerId),
                        provider: e.provider,
                        product_uid: e.uid
                    };
                return null != n && n.billingEmail && (i.billing_email = n.billingEmail), e.receiptData && (i.receipt_data = e.receiptData), v.A.getInstance().sendReceipt(i)
            }

            function ur(e, t, r) {
                var n = Xt({
                    payment_success: !1,
                    transaction_identifier: t.transaction_id,
                    provider_id: e.providerId,
                    provider: e.provider,
                    product_uid: e.uid
                }, r);
                v.A.getInstance().sendReceipt(n).then((function(e) {
                    var t = null == e ? void 0 : e.notification,
                        r = null == t ? void 0 : t.message;
                    r && w.A.showNotification({
                        text: r,
                        type: w.A.TYPES.INFO
                    })
                })).catch(a.A)
            }

            function lr(e) {
                var t = e.form_error,
                    r = null == t ? void 0 : t.failure,
                    n = null == r ? void 0 : r.error_message,
                    i = e.notification,
                    a = null == i ? void 0 : i.message;
                w.A.showNotification({
                    text: n || a,
                    type: w.A.TYPES.ERROR
                })
            }
            ir.EVENTS = kt, ir.ACTIONS = Ft;
            var dr = /^https?:/;

            function pr(e) {
                return e ? dr.test(e) ? e : ("/" !== e.charAt(0) && (e = "/" + e), s.A.location.protocol + "//" + s.A.location.hostname + e) : e
            }
            var fr = ir
        },
        62608: function(e, t, r) {
            r(50113), r(10287), r(26099), r(3362), r(98992), r(72577);
            var n, i = r(65297),
                a = r(6696),
                o = r(73090),
                s = r(31709);

            function c(e, t) {
                return c = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, c(e, t)
            }! function(e) {
                e.CHANGE = "CHANGE"
            }(n || (n = {}));
            var u = function(e) {
                function t() {
                    var t;
                    return (t = e.call(this, {
                        get: {
                            message: 573,
                            response: 574
                        }
                    }, {
                        commitCache: !1,
                        name: "CreditsModel",
                        useCache: !1
                    }) || this).creditsBalance = void 0, t
                }
                var r, a;
                a = e, (r = t).prototype = Object.create(a.prototype), r.prototype.constructor = r, c(r, a), t.getInstance = function() {
                    return t.instance || (t.instance = new t), t.instance
                };
                var u = t.prototype;
                return u.init = function() {
                    var e = this;
                    return s.aV.onResponse(574, (function(t) {
                        e.saveAndTriggerBalanceChange(t)
                    })), i.A.on(i.A.Session.SESSION_CHANGED, (function(t) {
                        t.isLoggedIn || e.setCreditsBalance(void 0)
                    })), this
                }, u.saveAndTriggerBalanceChange = function(e) {
                    var t = function(e) {
                        if (!e) return;
                        return (e.balances || []).find((function(e) {
                            return 1 === e.type
                        }))
                    }(e);
                    if (t)
                        if (this.creditsBalance) {
                            var r = this.creditsBalance.balance_ts || 0,
                                n = t.balance_ts || 0;
                            if (n > r) this.setCreditsBalance(t);
                            else if (n === r) {
                                var i = this.creditsBalance.value < t.value ? this.creditsBalance : t;
                                this.setCreditsBalance(i)
                            }
                        } else this.setCreditsBalance(t)
                }, u.setCreditsBalance = function(e) {
                    var t = this.getCurrentCredits();
                    this.creditsBalance = e;
                    var r = this.getCurrentCredits();
                    r !== t && this.trigger(n.CHANGE, r)
                }, u.getCredits = function() {
                    var t = this;
                    if (!o.A.isLoggedIn()) return Promise.resolve(0);
                    if (this.creditsBalance) return Promise.resolve(this.getCurrentCredits());
                    return e.prototype.get.call(this, {
                        types: [1]
                    }).then((function(e) {
                        if (t.saveAndTriggerBalanceChange(e), !t.creditsBalance) throw new Error("Credits balance not found");
                        return t.getCurrentCredits()
                    }))
                }, u.getCurrentCredits = function() {
                    var e;
                    return (null == (e = this.creditsBalance) ? void 0 : e.value) || 0
                }, t
            }(a.A);
            u.EVENTS = n, u.instance = null, u.getInstance(), t.A = u
        },
        63334: function(e, t, r) {
            r.d(t, {
                B: function() {
                    return i
                }
            });
            var n = r(99417);

            function i() {
                return n.A.location.protocol + "//" + n.A.location.hostname + "/payment-result.html"
            }
        },
        64872: function(e, t, r) {
            r.d(t, {
                L: function() {
                    return _
                }
            });
            r(26099), r(3362), r(9391);
            var n = r(96540),
                i = r(55272),
                a = r(54129);
            var o, s = r(65153),
                c = r(99417),
                u = r(89104),
                l = r(8054),
                d = (0, r(40504).A)(c.A.location.hostname).env === u.A.DEV_REMOTE;
            ! function(e) {
                e.INITIALIZED = "INITIALIZED", e.INITIALIZING = "INITIALIZING", e.NONE = "NONE"
            }(o || (o = {})), (0, l.A)({
                enableGooglePayTestEnv: function(e) {
                    return void 0 === e && (e = !0), d = e, e
                }
            });
            var p, f, h = r(26359);
            ! function(e) {
                e.INITIALIZED = "INITIALIZED", e.INITIALIZING = "INITIALIZING", e.NONE = "NONE"
            }(p || (p = {})),
            function(e) {
                e.SANDBOX = "https://static-sandbox.dlocal.com/js/collector/direct.js", e.PRODUCTION = "https://static.dlocal.com/js/collector/direct.js"
            }(f || (f = {}));
            var g = r(86812),
                v = r(18084),
                m = r(93529),
                y = r(12702),
                P = r(7802),
                A = r(87574),
                E = v.A.getLogger("useExternalProviderInitialiser"),
                _ = function(e) {
                    var t, r, u, l = e.selectedProvider,
                        v = e.transactionController,
                        _ = e.isUcbFlow,
                        b = (0, s.Q)(),
                        T = b.initApplePay,
                        S = b.isInitialized,
                        I = b.needsInitialization,
                        O = (t = (0, n.useState)(o.NONE), r = t[0], u = t[1], {
                            initGooglePay: function(e, t) {
                                return new Promise((function(r, n) {
                                    var i = null == t ? void 0 : t.integration,
                                        a = null == i ? void 0 : i.app_key;
                                    if (a) {
                                        u(o.INITIALIZING);
                                        var s = e.initGooglePay({
                                            gatewayMerchantId: a,
                                            isTestEnvironment: d,
                                            nonce: c.A._nonce,
                                            onReady: function(e) {
                                                e ? n(e) : r(s), s.isReadyToPay() ? u(o.INITIALIZED) : u(o.NONE)
                                            }
                                        })
                                    } else n(new Error("Cannot get gatewayMerchantId for GooglePay"))
                                }))
                            },
                            needsInitialization: r === o.NONE
                        }),
                        C = O.initGooglePay,
                        R = O.needsInitialization,
                        w = function() {
                            var e = (0, n.useState)(p.NONE),
                                t = e[0],
                                r = e[1];
                            return {
                                initUpi: function(e) {
                                    return new Promise((function(t, n) {
                                        var i = null == e ? void 0 : e.integration,
                                            a = null == i ? void 0 : i.app_key;
                                        if (a) {
                                            var o = null == i ? void 0 : i.is_sandbox,
                                                s = o ? f.SANDBOX : f.PRODUCTION;
                                            r(p.INITIALIZING), (0, h.k)(s, {
                                                nonce: c.A._nonce
                                            }).then((function() {
                                                c.A.window.dlocalCollector.create({
                                                    ENV: o ? "sandbox" : "production",
                                                    apiKey: a
                                                }).then((function(e) {
                                                    r(p.INITIALIZED), t(e)
                                                }))
                                            }))
                                        } else n(new Error("Cannot get merchantIdentifier for Upi"))
                                    }))
                                },
                                needsInitialization: t === p.NONE
                            }
                        }(),
                        D = w.initUpi,
                        L = w.needsInitialization,
                        j = (0, y.jh)().dispatch,
                        U = (0, A.LZ)().dispatch;
                    (0, n.useEffect)((function() {
                        var e, t = (0, i.K)(l),
                            r = (0, a.R)(l),
                            n = 195 === (null == (e = l) ? void 0 : e.provider),
                            o = function(e) {
                                _ ? j({
                                    type: y.BX.UPDATE_IS_LOADING,
                                    value: e
                                }) : P.q.setValue(e)
                            };
                        t && I ? (o(!0), T(v, l).catch((function(e) {
                            (0, g.y)(e) || E.error("Cannot get merchantIdentifier for ApplePay", {
                                error: e,
                                mop: l
                            }), m.A.showNotification({
                                type: m.A.TYPES.ERROR
                            })
                        })).finally((function() {
                            o(!1)
                        }))) : r && R ? (o(!0), C(v, l).catch((function() {
                            E.error("Cannot get gatewayMerchantId for GooglePay", {
                                mop: l
                            }), m.A.showNotification({
                                type: m.A.TYPES.ERROR
                            })
                        })).finally((function() {
                            o(!1)
                        }))) : n && L && (o(!0), D(l).then((function(e) {
                            _ ? j({
                                type: y.BX.UPDATE_DEVICE_PROFILING_ID,
                                value: e
                            }) : U({
                                type: A.YM.UPDATE_DEVICE_PROFILING_ID,
                                value: e
                            })
                        })).finally((function() {
                            o(!1)
                        })))
                    }), [l, v, _, T, C, D, S, R, I, L, j, U])
                }
        },
        65153: function(e, t, r) {
            r.d(t, {
                Q: function() {
                    return a
                }
            });
            r(26099), r(3362);
            var n, i = r(96540);

            function a() {
                var e = (0, i.useState)(n.NONE),
                    t = e[0],
                    r = e[1];
                return {
                    initApplePay: function(e, t) {
                        return new Promise((function(i, a) {
                            var o = null == t ? void 0 : t.integration,
                                s = null == o ? void 0 : o.app_key;
                            if (s) {
                                r(n.INITIALIZING);
                                var c = null == t ? void 0 : t.provider_id,
                                    u = e.initApplePay({
                                        providerId: String(c),
                                        merchantIdentifier: s,
                                        onReady: function(e) {
                                            e ? a(e) : i(u), null != u && null != u.getIsPaymentsAvailable && u.getIsPaymentsAvailable() ? r(n.INITIALIZED) : r(n.NONE)
                                        }
                                    })
                            } else a(new Error("Cannot get merchantIdentifier for ApplePay"))
                        }))
                    },
                    isInitialized: t === n.INITIALIZED,
                    needsInitialization: t === n.NONE
                }
            }! function(e) {
                e.INITIALIZED = "INITIALIZED", e.INITIALIZING = "INITIALIZING", e.NONE = "NONE"
            }(n || (n = {}))
        },
        67556: function(e, t, r) {
            r.d(t, {
                K: function() {
                    return n
                }
            });
            var n = function() {
                function e() {}
                return e.get = function(t) {
                    return e.transactionsExtraData[t]
                }, e.set = function(t, r) {
                    e.transactionsExtraData[t] = r
                }, e.remove = function(t) {
                    var r = e.transactionsExtraData[t];
                    return delete e.transactionsExtraData[t], r
                }, e
            }();
            n.transactionsExtraData = {}
        },
        68251: function(e, t, r) {
            var n;
            r.d(t, {
                    G: function() {
                        return n
                    }
                }),
                function(e) {
                    e.SPP = "SPP", e.SPP_CONTEXTUAL = "SPP_CONTEXTUAL", e.PREMIUM_PLUS = "PREMIUM_PLUS", e.PREMIUM_PLUS_CONTEXTUAL = "PREMIUM_PLUS_CONTEXTUAL", e.CREDITS = "CREDITS", e.CREDITS_CONTEXTUAL = "CREDITS_CONTEXTUAL"
                }(n || (n = {}))
        },
        69079: function(e, t, r) {
            function n(e, t) {
                return t.priority || 0 - e.priority || 0
            }
            r.d(t, {
                e: function() {
                    return n
                }
            })
        },
        69978: function(e, t, r) {
            var n;
            r.d(t, {
                z: function() {
                    return a
                }
            });
            var i = ((n = {})[1] = 6, n[23] = 22, n[3] = 1, n[4] = 7, n[5] = 9, n[6] = 3, n[7] = 8, n[12] = 13, n[13] = 2, n[14] = 11, n[21] = 15, n[22] = 21, n[25] = 23, n[45] = 47, n[47] = 48, n[66] = 57, n);

            function a(e) {
                if (e) return i[e]
            }
        },
        70182: function(e, t, r) {
            r.d(t, {
                A: function() {
                    return a
                }
            });
            r(74423);
            var n = r(74389),
                i = [n.x.PAYMENT_TERMS, n.x.PLAN_COMPARISON],
                a = function() {
                    function e() {}
                    return e.set = function(t) {
                        e.initialProductType = t.initialProductType, e.methodOfPayment = t.methodOfPayment, e.product = t.product
                    }, e.get = function() {
                        return {
                            initialProductType: e.initialProductType,
                            methodOfPayment: e.methodOfPayment,
                            product: e.product
                        }
                    }, e.clear = function() {
                        e.initialProductType = void 0, e.methodOfPayment = void 0, e.product = void 0
                    }, e.hasToStoreSelection = function(e) {
                        return i.includes(e)
                    }, e
                }();
            a.initialProductType = void 0, a.methodOfPayment = void 0, a.product = void 0
        },
        70271: function(e, t, r) {
            r.d(t, {
                JW: function() {
                    return a
                },
                dX: function() {
                    return n
                },
                n8: function() {
                    return i
                }
            });
            var n = function(e) {
                    return 83 === e
                },
                i = function(e) {
                    return function(e) {
                        return 2 === e
                    }(e) || n(e)
                },
                a = function(e) {
                    return 100001 === e
                }
        },
        73160: function(e, t, r) {
            r.d(t, {
                A: function() {
                    return v
                }
            });
            r(52675), r(45700), r(2008), r(51629), r(62062), r(89572), r(2892), r(67945), r(84185), r(83851), r(81278), r(79432), r(26099), r(84864), r(57465), r(27495), r(87745), r(38781), r(98992), r(54520), r(3949), r(81454), r(23500);
            var n = r(96540),
                i = r(18084),
                a = r(28244),
                o = r(74848);

            function s(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function c(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? s(Object(r), !0).forEach((function(t) {
                        u(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : s(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function u(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var l = /\[link(?:=["']?([^'"\]]+)["']?)?\]([^\[]+)\[\/link\]/,
                d = /<a(?:[^>]+href="([^"]*)"([^>]*))?>([^<]+)<\/a>/,
                p = /(<a(?:[^>]+href[^>]+)?>[^<]+<\/a>)/,
                f = ["rel", "target"],
                h = i.A.getLogger("RoutingText");

            function g(e) {
                var t, r = e.text,
                    i = e.routingMapping,
                    s = e.ignoreMissingRoutingInfo,
                    u = void 0 !== s && s,
                    g = new RegExp(l, "gi"),
                    v = new RegExp(d, "gi"),
                    m = new RegExp(p, "gi"),
                    y = r.replace(g, '<a href="$1">$2</a>').split(m).map((function(e) {
                        var t, n = v.exec(e);
                        if (n) {
                            var s, l = n[1];
                            if (!l && null != i && i.default && (l = "default"), i && (s = i[l]), s) {
                                if ("href" in (t = s) || "routeName" in t) {
                                    var d = function(e) {
                                        var t = {},
                                            r = document.createElement("div");
                                        r.innerHTML = e;
                                        var n = r.getElementsByTagName("a")[0];
                                        n && f.forEach((function(e) {
                                            t[e] = n.getAttribute(e) || void 0
                                        }));
                                        return t
                                    }(e);
                                    return (0, o.jsx)(a.A, c(c(c({}, d), s), {}, {
                                        children: n[3]
                                    }))
                                }
                                return (0, o.jsx)("button", c(c({
                                    onClick: s.onClick
                                }, s.dataQA), {}, {
                                    type: "button",
                                    children: n[3]
                                }))
                            }
                            u || h.error("RoutingText string contains anchor markup, but no routing information is passed", {
                                textPiece: e,
                                text: r,
                                routingMapping: i
                            })
                        }
                        return e
                    }));
                return t = y, (0, o.jsx)(n.Fragment, {
                    children: t.map((function(e, t) {
                        return "string" == typeof e ? (0, o.jsx)("span", {
                            dangerouslySetInnerHTML: {
                                __html: e
                            }
                        }, "fragment-" + t) : (0, o.jsx)(n.Fragment, {
                            children: e
                        }, "fragment-" + t)
                    }))
                })
            }
            var v = function(e) {
                var t = e.text,
                    r = e.routingMapping,
                    n = e.className,
                    i = g({
                        text: t,
                        routingMapping: r,
                        ignoreMissingRoutingInfo: e.ignoreMissingRoutingInfo
                    });
                return (0, o.jsx)("span", {
                    className: n,
                    children: i
                })
            }
        },
        73616: function(e, t, r) {
            var n = r(31189);
            t.A = n.A
        },
        76854: function(e, t, r) {
            r(10287), r(2008), r(51629), r(74423), r(72712), r(26099), r(3362), r(98992), r(54520), r(3949), r(23500);
            var n, i, a = r(65297),
                o = r(6696),
                s = r(73090),
                c = r(31709),
                u = r(41298),
                l = r(25093);

            function d(e, t) {
                return d = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, d(e, t)
            }! function(e) {
                e.CHANGE_CHAT_UNBLOCKERS = "CHANGE_CHAT_UNBLOCKERS", e.CHANGE_CRUSHES = "CHANGE_CRUSHES", e.CHANGE_EXTRA_SHOWS = "CHANGE_EXTRA_SHOWS"
            }(i || (i = {}));
            var p = [12, 2, 13],
                f = ((n = {})[12] = i.CHANGE_CHAT_UNBLOCKERS, n[2] = i.CHANGE_CRUSHES, n[13] = i.CHANGE_EXTRA_SHOWS, n),
                h = function(e) {
                    function t() {
                        var t;
                        return (t = e.call(this, {
                            get: {
                                message: 573,
                                response: 574
                            }
                        }, {
                            commitCache: !1,
                            name: "ConsumablesModel",
                            useCache: !1
                        }) || this).consumablesBalance = g(), t.loadBalancePromise = (0, u.A)(Promise.resolve({})), t
                    }
                    var r, n;
                    n = e, (r = t).prototype = Object.create(n.prototype), r.prototype.constructor = r, d(r, n), t.getInstance = function() {
                        return t.instance || (t.instance = new t), t.instance
                    };
                    var i = t.prototype;
                    return i.init = function() {
                        var t = this;
                        return e.prototype.init.call(this), c.aV.onResponse(574, (function(e) {
                            t.updateBalances(e)
                        })), a.A.on(a.A.Session.SESSION_CHANGED, (function(e) {
                            e.isLoggedIn ? t.preloadConsumables() : t.resetBalances()
                        })), this.preloadConsumables(), this
                    }, i.resetBalances = function() {
                        this.consumablesBalance = g()
                    }, i.preloadConsumables = function() {
                        var t = this;
                        if (s.A.isLoggedIn()) {
                            var r = {
                                types: p
                            };
                            this.loadBalancePromise = e.prototype.get.call(this, r), this.loadBalancePromise.then((function(e) {
                                t.updateBalances(e)
                            })).catch((function(e) {
                                (0, l.A)(e) && t.log.error("Error preloading the consumables balances", {
                                    error: e
                                })
                            }))
                        }
                    }, i.updateBalances = function(e) {
                        var t = this,
                            r = function(e) {
                                if (!e) return [];
                                return (e.balances || []).filter((function(e) {
                                    return Boolean(e.type && p.includes(e.type))
                                }))
                            }(e);
                        0 !== r.length && r.forEach((function(e) {
                            t.updateBalanceByType(e, e.type)
                        }))
                    }, i.updateBalanceByType = function(e, t) {
                        var r, n, i, a, o = this.consumablesBalance[t],
                            s = null != (r = null == o ? void 0 : o.balance_ts) ? r : 0,
                            c = null != (n = null == e ? void 0 : e.balance_ts) ? n : 0,
                            u = null != (i = null == o ? void 0 : o.value) ? i : 0,
                            l = null != (a = null == e ? void 0 : e.value) ? a : 0;
                        c > s && (this.consumablesBalance[t] = e, u !== l && this.trigger(f[t], e))
                    }, i.getBalanceValue = function(e) {
                        return this.consumablesBalance[e].value || 0
                    }, i.getCurrentChatBlockers = function() {
                        return this.getBalanceValue(12)
                    }, i.getCurrentCrushes = function() {
                        return this.getBalanceValue(2)
                    }, i.getCurrentExtraShows = function() {
                        return this.getBalanceValue(13)
                    }, i.hasConsumableForProductType = function(e) {
                        switch (e) {
                            case 44:
                            case 46:
                                return this.getCurrentChatBlockers() > 0;
                            case 50:
                            case 6:
                                return this.getCurrentExtraShows() > 0;
                            case 49:
                            case 25:
                                return this.getCurrentCrushes() > 0;
                            default:
                                return !1
                        }
                    }, t
                }(o.A);

            function g() {
                return p.reduce((function(e, t) {
                    return e[t] = {
                        balance_ts: 0,
                        type: t,
                        value: 0
                    }, e
                }), {})
            }
            h.EVENTS = i, h.instance = null, h.getInstance(), t.A = h
        },
        83771: function(e, t, r) {
            r(10287);
            var n, i, a = r(6696);

            function o(e, t) {
                return o = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, o(e, t)
            }! function(e) {
                e.INVALIDATED = "invalidated"
            }(i || (i = {}));
            var s = function(e) {
                function t() {
                    return e.call(this, {
                        get: {
                            message: 418,
                            response: 419
                        }
                    }, {
                        name: "PopularityModel",
                        useCache: !1
                    }) || this
                }
                var r, n;
                return n = e, (r = t).prototype = Object.create(n.prototype), r.prototype.constructor = r, o(r, n), t.prototype.invalidate = function() {
                    this.trigger(i.INVALIDATED)
                }, t
            }(a.A);
            n = s, s.EVENTS = i, s.instance = null, s.getInstance = function() {
                return n.instance || (n.instance = new n), n.instance
            }, t.A = s
        },
        84932: function(e, t, r) {
            r(52675), r(45700), r(2008), r(51629), r(89572), r(2892), r(67945), r(84185), r(83851), r(81278), r(79432), r(26099), r(98992), r(54520), r(3949), r(23500);
            var n = r(51709),
                i = r(33702),
                a = r(14680),
                o = r(74848);

            function s(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function c(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? s(Object(r), !0).forEach((function(t) {
                        u(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : s(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function u(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            t.A = function(e) {
                var t = (0, n.iD)(e),
                    r = t.a11y,
                    s = t.ids,
                    u = t.labelProps;
                return (0, o.jsxs)(a.A, c(c(c({}, e), s), {}, {
                    label: u.label,
                    children: [(0, o.jsx)(i.A, c(c(c(c({}, e), s), (0, n.$E)(e.preset, e)), {}, {
                        status: Boolean(e.errorMessage) || e.isInvalid ? "error" : void 0,
                        a11y: c(c({}, r), {}, {
                            ariaRequired: u.ariaRequired
                        })
                    })), e.extraContent]
                }))
            }
        },
        86812: function(e, t, r) {
            r.d(t, {
                A: function() {
                    return s
                },
                y: function() {
                    return o
                }
            });
            var n = r(19276),
                i = r(17412),
                a = r(4803),
                o = function(e) {
                    return (null == e ? void 0 : e.errorCode) === n.A.ERROR_CODES.PAYMENTS_WITH_CURRENT_CARD_CHECK_FAILED
                },
                s = function(e) {
                    return (0, a.W)(e) ? i.qR.PROVIDER_PLAID : void 0
                }
        },
        87574: function(e, t, r) {
            r.d(t, {
                YM: function() {
                    return T
                },
                vh: function() {
                    return M
                },
                LZ: function() {
                    return k
                }
            });
            r(52675), r(45700), r(2008), r(51629), r(62062), r(89572), r(2892), r(67945), r(84185), r(83851), r(81278), r(79432), r(26099), r(98992), r(54520), r(3949), r(81454), r(23500);
            var n = r(96540),
                i = r(56217),
                a = (r(50113), r(72577), r(72537)),
                o = function(e) {
                    var t = a.A.getSync(415);
                    return Boolean(e.isDoubleCredits) || t.enabled ? e.previous_display_name : void 0
                };

            function s(e) {
                var t, r, n, i;
                return {
                    badge: e.badge,
                    displayName: e.display_name || "",
                    displayPrice: e.display_price || "",
                    isDoubleCredits: Boolean(e.isDoubleCredits),
                    isTopUpAvailable: e.is_top_up_possible || !1,
                    isTopUpEnabled: e.top_up_default_state || !1,
                    previousDisplayName: o(e),
                    previousDisplayPrice: e.previous_display_price,
                    pricePerUnit: e.price_per_unit,
                    savedPaymentText: e.saved_payment_text,
                    shortTnc: e.short_tnc,
                    paywallUiFooterText: (null == (r = e, i = (r.ui || []).find((function(e) {
                        return "paywall_ui_footer" === e.ref
                    })), t = null == i || null == (n = i.children) ? void 0 : n.find((function(e) {
                        return "paywall_ui_footer_content" === e.ref
                    }))) ? void 0 : t.text) || "",
                    uid: e.uid,
                    unitName: e.unit_name || ""
                }
            }
            var c = r(68251);

            function u(e, t) {
                var r = t && 8 !== t;
                return 1 === e ? r ? c.G.SPP_CONTEXTUAL : c.G.SPP : 47 === e ? r || t && 557 !== t ? c.G.PREMIUM_PLUS_CONTEXTUAL : c.G.PREMIUM_PLUS : e && 13 !== e || 12 === e ? c.G.CREDITS_CONTEXTUAL : 13 === e ? c.G.CREDITS : c.G.CREDITS_CONTEXTUAL
            }
            var l = r(49711);

            function d(e) {
                switch (e) {
                    case 66:
                        return l.P.EXTRA;
                    case 1:
                    case 23:
                        return l.P.SPP;
                    case 47:
                        return l.P.PREMIUM_PLUS;
                    default:
                        return l.P.DEFAULT
                }
            }
            var p = r(30245),
                f = (r(26910), r(69079));

            function h(e, t) {
                var r = [];
                return e ? (e.forEach((function(e) {
                    var n, i = (e.providers || []).find((function(e) {
                        return e.provider_id === t
                    }));
                    i && (i.uid = e.uid, i.isDoubleCredits = !!(n = e.options) && Boolean(n.find((function(e) {
                        return 3 === e
                    }))), r.push(i))
                })), r.sort(f.e)) : r
            }
            var g = r(20140),
                v = r(3208);
            var m = r(79880),
                y = (r(72712), r(8872), r(59244));

            function P(e, t) {
                var r;
                return 562 === t.promo_block_type ? ["badge-feature-special-delivery-premium-plus"] : (null == (r = t.pictures) ? void 0 : r.reduce((function(t, r) {
                    var n = (0, y.y)(r.badge_type, e);
                    return void 0 !== n && t.push(n), t
                }), [])) || []
            }

            function A(e) {
                var t, r = null == (t = e.pictures) ? void 0 : t.find((function(e) {
                    return 2 === e.badge_type
                }));
                return null == r ? void 0 : r.badge_text
            }

            function E(e, t) {
                if (47 === e) return (t.buttons || []).find((function(e) {
                    return 3 === e.type
                }))
            }
            r(27495);
            var _ = r(92065);

            function b(e) {
                var t = d(e) === l.P.DEFAULT ? _.TOKEN_ICON_JUMBO_SIZE_SM : _.TOKEN_ICON_JUMBO_SIZE_MD;
                return Number(t.replace("px", ""))
            }
            var T, S = r(78944),
                I = r(70182),
                O = r(31709),
                C = r(74848);

            function R(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function w(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function D(e, t) {
                var r = t || (null == e ? void 0 : e.default_provider_id),
                    n = h(null == e ? void 0 : e.products, r).map(s);
                return n.length > 0 ? n : void 0
            }

            function L(e, t) {
                var r;
                return null == (r = function(e) {
                    if (e) return e.filter((function(e) {
                        return 10 === e.promo_block_position
                    }))
                }(null == t ? void 0 : t.product_promos)) ? void 0 : r.map((function(t) {
                    return function(e, t) {
                        var r, n = e.promo_block_type;
                        return {
                            badges: P(t, e),
                            badgeText: A(e),
                            image: (0, m.A)(null == (r = e.pictures) ? void 0 : r[0].display_images, b(t)),
                            isDoubleCredits: 41 === n,
                            linkCta: E(t, e),
                            message: e.mssg || "",
                            pictures: e.pictures,
                            timer: e.timer,
                            title: e.header || "",
                            type: n
                        }
                    }(t, e)
                }))
            }

            function j(e) {
                var t;
                e.selectedProduct || (e.selectedProduct = null == (t = e.paywallData) || null == (t = t.products) ? void 0 : t[0])
            }

            function U(e) {
                var t = e || {},
                    r = t.paywallData,
                    n = t.promoBlocksData,
                    a = t.productType,
                    o = t.promoBlockType,
                    s = I.A.get(),
                    c = s.initialProductType,
                    l = s.methodOfPayment,
                    f = s.product,
                    h = void 0,
                    m = void 0;
                if (l && f) h = f, m = l;
                else if (r) {
                    var y = r.default_provider_id;
                    m = (0, g.U)(r.provider_name, y);
                    var P = (0, i.H)(r.provider_name, y);
                    h = (0, p.J)(r.products, P)
                }
                var A = {
                    initialProductType: c || a || 13,
                    isTopUpEnabled: !1,
                    paywallData: r,
                    paywallInteraction: new S.V({
                        Rpc: O.Ay
                    }),
                    paywallType: d(a),
                    products: D(r),
                    productType: a || 13,
                    promoBlocks: L(a || 13, n),
                    promoBlocksData: n,
                    selectedProduct: h,
                    selectedProvider: m,
                    screenMode: u(a, o),
                    uniqueFlowId: v.A.get(),
                    deviceProfilingId: void 0
                };
                return j(A), A
            }! function(e) {
                e.UPDATE_AUTO_TOP_UP = "UPDATE_AUTO_TOP_UP", e.UPDATE_PAYWALL_DATA = "UPDATE_PAYWALL_DATA", e.UPDATE_PRODUCT_TYPE = "UPDATE_PRODUCT_TYPE", e.UPDATE_PROMO_BLOCKS_DATA = "UPDATE_PROMO_BLOCKS_DATA", e.UPDATE_SELECTED_PRODUCT = "UPDATE_SELECTED_PRODUCT", e.UPDATE_SELECTED_PROVIDER = "UPDATE_SELECTED_PROVIDER", e.UPDATE_UNIQUE_FLOW_ID = "UPDATE_UNIQUE_FLOW_ID", e.UPDATE_DEVICE_PROFILING_ID = "UPDATE_DEVICE_PROFILING_ID"
            }(T || (T = {}));
            var N = (0, n.createContext)({
                state: U(),
                dispatch: function() {}
            });

            function x(e, t) {
                var r = function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? R(Object(r), !0).forEach((function(t) {
                            w(e, t, r[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : R(Object(r)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                        }))
                    }
                    return e
                }({}, e);
                switch (t.type) {
                    case T.UPDATE_AUTO_TOP_UP:
                        r.isTopUpEnabled = t.value;
                        break;
                    case T.UPDATE_PAYWALL_DATA:
                        var n = t.value;
                        if (r.paywallInteraction.setIdentifier(null == n ? void 0 : n.identifier).setProductType(null == n ? void 0 : n.product_type).setViewMode(null == n ? void 0 : n.view_mode), r.paywallData = n, n) {
                            var a = (0, g.U)(n.provider_name, n.default_provider_id);
                            r = x(r, {
                                type: T.UPDATE_SELECTED_PROVIDER,
                                value: a
                            })
                        }
                        break;
                    case T.UPDATE_PRODUCT_TYPE:
                        r.paywallType = d(t.value), r.productType = t.value;
                        break;
                    case T.UPDATE_PROMO_BLOCKS_DATA:
                        r.promoBlocksData = t.value, r.promoBlocks = L(r.productType, t.value);
                        break;
                    case T.UPDATE_SELECTED_PRODUCT:
                        r.selectedProduct = t.value, j(r);
                        break;
                    case T.UPDATE_SELECTED_PROVIDER:
                        var o, s, c;
                        r.selectedProvider = t.value;
                        var u = null == (o = t.value) ? void 0 : o.provider_id;
                        r.products = D(r.paywallData, u);
                        var l = (0, i.H)(null == (s = r.paywallData) ? void 0 : s.provider_name, u);
                        r = x(r, {
                            type: T.UPDATE_SELECTED_PRODUCT,
                            value: (0, p.J)(null == (c = r.paywallData) ? void 0 : c.products, l)
                        });
                        break;
                    case T.UPDATE_UNIQUE_FLOW_ID:
                        r.uniqueFlowId = t.value;
                        break;
                    case T.UPDATE_DEVICE_PROFILING_ID:
                        r.deviceProfilingId = t.value;
                        break;
                    default:
                        throw new Error("PaywallContext: Unhandled action type")
                }
                return r
            }
            var M = function(e) {
                var t = (0, n.useReducer)(x, U(e)),
                    r = {
                        state: t[0],
                        dispatch: t[1]
                    };
                return (0, C.jsx)(N.Provider, {
                    value: r,
                    children: e.children
                })
            };

            function k() {
                var e = (0, n.useContext)(N);
                if (void 0 === e) throw new Error("usePaywallContext must be used within a PaywallContextProvider");
                return e
            }
        },
        91258: function(e, t, r) {
            r.d(t, {
                A: function() {
                    return J
                }
            });
            var n = r(40075),
                i = r(47901),
                a = r(15376),
                o = r(99795),
                s = r(28733),
                c = r(89769),
                u = r(94318),
                l = r(12501),
                d = r(74848),
                p = function(e) {
                    var t = e.title,
                        r = e.onNavigateBack,
                        p = e.children;
                    return (0, d.jsx)("div", {
                        className: "open-banking__screen",
                        children: (0, d.jsxs)(i.A, {
                            children: [(0, d.jsx)(a.A, {
                                children: (0, d.jsxs)(o.A, {
                                    children: [(0, d.jsx)(s.A, {
                                        isWide: !0,
                                        children: (0, d.jsx)(u.A, {
                                            name: "navigation-bar-back",
                                            onClick: r,
                                            a11y: {
                                                iconLabel: n.Ay.get(270)
                                            }
                                        })
                                    }), (0, d.jsx)(l.A, {
                                        text: t
                                    }), (0, d.jsx)(c.A, {
                                        isWide: !0
                                    })]
                                })
                            }), p]
                        })
                    })
                },
                f = function(e) {
                    var t = e.height,
                        r = e.width;
                    return (0, d.jsxs)("svg", {
                        width: r || 43,
                        height: t || 16,
                        viewBox: "0 0 43 16",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, d.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M22.4332 5.48287C22.0753 5.18324 21.4644 5.0336 20.6002 5.0336H18.6511V11.0288H20.1086V9.1498H20.7614C21.5538 9.1498 22.1349 8.97622 22.5047 8.62874C22.9212 8.23947 23.1308 7.72111 23.1308 7.074C23.1308 6.40297 22.8981 5.87248 22.4332 5.48287ZM20.7252 7.79323H20.1086V6.39016H20.6626C21.3364 6.39016 21.6733 6.62541 21.6733 7.09591C21.6733 7.56034 21.3571 7.7929 20.7252 7.7929V7.79323ZM25.6248 5.03326H24.105V11.0284H27.3863V9.67152H25.6248V5.03326ZM30.3638 5.03326L27.9765 11.0284H29.6127L29.9256 10.1569H32L32.2862 11.0284H33.9407L31.5703 5.03326H30.3638ZM30.3459 8.94319L30.972 6.89403L31.5883 8.94319H30.3455H30.3459Z",
                            fill: "#767676"
                        }), (0, d.jsx)("mask", {
                            id: "mask0_3379_504",
                            style: {
                                maskType: "alpha"
                            },
                            maskUnits: "userSpaceOnUse",
                            x: "0",
                            y: "0",
                            width: r || 43,
                            height: t || 16,
                            children: (0, d.jsx)("path", {
                                d: "M0 16H42.6667V0H0V16Z",
                                fill: "white"
                            })
                        }), (0, d.jsx)("g", {
                            mask: "url(#mask0_3379_504)",
                            children: (0, d.jsx)("path", {
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M34.6999 11.0284H36.2199V5.03326H34.6999V11.0284ZM42.1215 6.15693C41.9295 5.87984 41.6829 5.64444 41.3968 5.465C40.938 5.17717 40.3119 5.0336 39.5192 5.0336H37.5165V11.0284H39.8591C40.7057 11.0284 41.385 10.7531 41.8976 10.2017C42.4103 9.65062 42.6663 8.91926 42.6663 8.00826C42.6663 7.28364 42.4845 6.66653 42.1211 6.15693H42.1215ZM39.6891 9.67118H39.0366V6.3905H39.6983C40.1632 6.3905 40.5205 6.53542 40.771 6.82426C41.0216 7.1131 41.1469 7.52293 41.1469 8.05342C41.1469 9.13193 40.661 9.67118 39.6891 9.67118ZM6.31094 0L1.38497 1.2841L0.0274286 6.21456L1.72529 7.94961L0 9.65602L1.27763 14.6081L6.18226 15.972L7.90789 14.2653L9.60576 16L14.5317 14.7159L15.8889 9.7851L14.1914 8.05072L15.9167 6.34432L14.6391 1.39195L9.73376 0.0279738L8.0088 1.73438L6.31094 0ZM3.28804 2.23251L5.88292 1.55575L7.01765 2.71514L5.36279 4.35178L3.28804 2.23251ZM8.98438 2.73065L10.1374 1.59046L12.7211 2.30902L10.6125 4.39425L8.98438 2.73065ZM1.58205 5.80979L2.29689 3.21294L4.37096 5.33221L2.71644 6.96885L1.58205 5.80945V5.80979ZM11.5874 5.39085L13.696 3.30495L14.3685 5.91359L13.2158 7.05412L11.5874 5.39085ZM6.33803 5.34805L7.99289 3.71142L9.62066 5.37501L7.96614 7.01165L6.33803 5.34805ZM3.69202 7.96512L5.34654 6.32848L6.97532 7.99208L5.32013 9.62872L3.69202 7.96512ZM8.94171 8.00792L10.5962 6.37128L12.2243 8.03488L10.5695 9.67152L8.94171 8.00792ZM1.54751 10.0864L2.70087 8.94555L4.32863 10.6095L2.2207 12.6944L1.54751 10.0864ZM6.29536 10.625L7.95022 8.98835L9.57833 10.6519L7.92381 12.2886L6.29536 10.625ZM11.5447 10.6681L13.1996 9.03149L14.3343 10.1906L13.6198 12.7874L11.5447 10.6681ZM3.1956 13.6913L5.30387 11.6054L6.93266 13.269L5.7793 14.4099L3.1956 13.691V13.6913ZM8.89905 13.2849L10.5536 11.6482L12.628 13.7678L10.0334 14.4443L8.89905 13.2849Z",
                                fill: "#767676"
                            })
                        })]
                    })
                },
                h = (r(62062), r(26099), r(98992), r(81454), r(96540)),
                g = r(20017),
                v = r(87908),
                m = r(87184),
                y = r(11611),
                P = r(47667),
                A = r(93827),
                E = r(30559),
                _ = r(26914),
                b = r(55105),
                T = r(51709),
                S = function(e) {
                    var t = (0, h.useMemo)((function() {
                            return n.Ay.get(464)
                        }), []),
                        r = (0, h.useMemo)((function() {
                            return n.Ay.get(472)
                        }), []),
                        i = (0, h.useState)(""),
                        a = i[0],
                        o = i[1],
                        s = (0, h.useState)(!0),
                        c = s[0],
                        u = s[1],
                        l = e.institutions,
                        p = e.onSelectInstitution,
                        f = e.onSearchInstitution;
                    (0, h.useEffect)((function() {
                        f(a), u("" === a)
                    }), [f, a]);
                    var S = l;
                    return l && c && (S = null == l ? void 0 : l.slice(0, 8)), (0, d.jsxs)(m.A, {
                        children: [(0, d.jsx)(v.A, {
                            hpadded: !0,
                            isSticky: !0,
                            children: (0, d.jsx)("div", {
                                className: "open-banking-institutions__search",
                                children: (0, d.jsx)(y.A, {
                                    a11y: {
                                        clearLabel: r,
                                        inputId: "open-banking-search-input",
                                        inputLabel: t
                                    },
                                    onChange: function(e) {
                                        o(e.target.value)
                                    },
                                    value: a,
                                    showClear: a.length > 0,
                                    onClear: function() {
                                        return o("")
                                    },
                                    onSubmit: function(e) {
                                        return (0, T.Y4)(e, (function() {
                                            return o(a)
                                        }))
                                    }
                                })
                            })
                        }), S ? (0, d.jsxs)(d.Fragment, {
                            children: [S.map((function(e) {
                                return (0, d.jsx)(P.A, {
                                    onClick: function() {
                                        return p(e)
                                    },
                                    color: "white",
                                    content: (0, d.jsxs)(d.Fragment, {
                                        children: [(0, d.jsx)(A.P1, {
                                            weight: "bolder",
                                            children: e.name
                                        }), (0, d.jsx)(A.P3, {
                                            color: "gray-80",
                                            children: e.url
                                        })]
                                    }),
                                    media: (0, d.jsx)(E.A, {
                                        children: (0, d.jsx)("div", {
                                            className: "open-banking-logo",
                                            children: (0, d.jsx)(_.A, {
                                                size: "xxsm",
                                                image: {
                                                    src: "data:image/png;base64, " + e.logo
                                                }
                                            })
                                        })
                                    }),
                                    mediaAlign: "center"
                                }, e.id)
                            })), c ? (0, d.jsx)(v.A, {
                                hpadded: !0,
                                isSticky: !0,
                                align: "bottom",
                                children: (0, d.jsx)("div", {
                                    className: "open-banking-institutions__show-all",
                                    children: (0, d.jsx)(g.A, {
                                        text: n.Ay.get(681),
                                        size: "small",
                                        narrow: !0,
                                        onClick: function() {
                                            u(!1)
                                        }
                                    })
                                })
                            }) : null]
                        }) : (0, d.jsx)(b.A, {})]
                    })
                },
                I = r(11734),
                O = r(3508),
                C = r(4571),
                R = r(51634),
                w = r(27895),
                D = r(40578),
                L = function(e) {
                    var t = e.label,
                        r = e.value;
                    return r ? (0, d.jsxs)("div", {
                        className: "open-banking-order-label",
                        children: [(0, d.jsx)("div", {
                            className: "open-banking-order-label__key",
                            children: (0, d.jsx)(A.P2, {
                                inline: !0,
                                align: "left",
                                color: "gray-80",
                                children: t
                            })
                        }), (0, d.jsx)(A.P1, {
                            align: "right",
                            children: r
                        })]
                    }) : null
                },
                j = r(32483),
                U = r(73160),
                N = r(74389),
                x = "https://" + O.A.get("partner_url"),
                M = x + "/" + N.x.PRIVACY,
                k = x + "/" + N.x.TERMS,
                F = function(e) {
                    var t = e.orderParams,
                        r = t.accountProviderName,
                        i = t.amount,
                        a = t.bacsAccount,
                        o = t.bacsSortCode,
                        s = t.payeeName,
                        c = e.confirmationStatus,
                        u = e.providerLogo;
                    return (0, d.jsxs)(C.A, {
                        align: "center",
                        isCompact: !0,
                        children: [c ? (0, d.jsxs)(d.Fragment, {
                            children: [(0, d.jsx)(w.A, {
                                children: (0, d.jsx)(_.A, {
                                    size: "sm",
                                    icon: {
                                        name: "success" === c ? "badge-check" : "badge-cross"
                                    }
                                })
                            }), (0, d.jsx)(D.A, {
                                isCompact: !0,
                                text: "success" === c ? n.Ay.get(678) : n.Ay.get(677)
                            })]
                        }) : null, (0, d.jsxs)(R.A, {
                            width: "stretch",
                            children: [c ? (0, d.jsx)("hr", {
                                className: "open-banking-order-details__seperator"
                            }) : null, (0, d.jsx)(L, {
                                label: n.Ay.get(671),
                                value: i
                            }), (0, d.jsx)(L, {
                                label: n.Ay.get(674),
                                value: s
                            }), (0, d.jsx)(L, {
                                label: n.Ay.get(675),
                                value: a
                            }), (0, d.jsx)(L, {
                                label: n.Ay.get(676),
                                value: o
                            }), (0, d.jsx)(L, {
                                label: n.Ay.get(670),
                                value: r
                            }), c ? null : (0, d.jsxs)(h.Fragment, {
                                children: [(0, d.jsx)("hr", {
                                    className: "open-banking-order-details__seperator"
                                }), (0, d.jsx)("div", {
                                    className: "open-banking-order-details__legal-text",
                                    children: (0, d.jsx)(j.A, {
                                        children: (0, d.jsx)(U.A, {
                                            routingMapping: {
                                                "#privacy": {
                                                    href: M,
                                                    target: "_blank"
                                                },
                                                "#terms": {
                                                    href: k,
                                                    target: "_blank"
                                                },
                                                "#plaid_terms": {
                                                    href: "https://plaid.com/legal/#end-user-privacy-policy",
                                                    target: "_blank"
                                                }
                                            },
                                            text: n.Ay.get(673)
                                        })
                                    })
                                }), (0, d.jsxs)("div", {
                                    className: "open-banking-order-details__provider",
                                    children: [(0, d.jsx)(j.A, {
                                        children: n.Ay.get(679)
                                    }), u]
                                })]
                            })]
                        })]
                    })
                },
                B = function(e) {
                    var t = e.orderParams,
                        r = e.onClick,
                        i = e.confirmationStatus,
                        a = e.isReadyForConnection,
                        o = e.returnToDestination,
                        s = e.providerLogo;
                    return (0, d.jsxs)(h.Fragment, {
                        children: [(0, d.jsx)(m.A, {
                            hpadded: !0,
                            vpadded: !0,
                            align: "stretch",
                            children: (0, d.jsx)(F, {
                                orderParams: t,
                                confirmationStatus: i,
                                providerLogo: s
                            })
                        }), (0, d.jsx)(I.A, {
                            hpadded: !0,
                            vpadded: !0,
                            children: i ? "success" === i ? (0, d.jsx)(g.A, {
                                onClick: o,
                                text: n.Ay.get(672)
                            }) : null : (0, d.jsx)(g.A, {
                                onClick: r,
                                text: n.Ay.get(457),
                                isLoading: !a
                            })
                        })]
                    })
                },
                H = (r(52675), r(45700), r(2008), r(51629), r(74423), r(89572), r(2892), r(67945), r(84185), r(83851), r(81278), r(79432), r(21699), r(54520), r(3949), r(23500), r(24947)),
                G = r(58385),
                V = r(93529),
                W = r(99562),
                Y = r(49683),
                q = r(18084);

            function Q(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function K(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Q(Object(r), !0).forEach((function(t) {
                        X(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Q(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function X(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function z(e) {
                var t, r = e.paymentOptions,
                    n = e.onReturn,
                    i = (0, h.useState)(!1),
                    a = i[0],
                    o = i[1],
                    s = (0, h.useState)(),
                    c = s[0],
                    u = s[1],
                    l = (0, h.useState)(),
                    d = l[0],
                    p = l[1],
                    f = (0, h.useState)(),
                    g = f[0],
                    v = f[1],
                    m = (0, h.useState)(""),
                    y = m[0],
                    P = m[1],
                    A = (0, h.useRef)(q.A.getLogger("usePlaidInstitutions")),
                    E = (0, H.usePlaidLink)({
                        token: null == g || null == (t = g.plaid_params) ? void 0 : t.link_token,
                        onSuccess: function() {
                            Y.A.getInstance().sendReceipt({
                                payment_success: !0,
                                transaction_identifier: null == g ? void 0 : g.transaction_id
                            }), u("success")
                        },
                        onExit: function() {
                            Y.A.getInstance().sendReceipt({
                                payment_success: !1,
                                transaction_identifier: null == g ? void 0 : g.transaction_id
                            }), u("fail")
                        }
                    }),
                    _ = E.open,
                    b = E.ready,
                    T = (0, h.useMemo)((function() {
                        var e;
                        return y ? null == d || null == (e = d.plaid_institutions) ? void 0 : e.filter((function(e) {
                            var t;
                            return null == (t = e.name) ? void 0 : t.toLocaleLowerCase().includes(y.toLocaleLowerCase())
                        })) : null == d ? void 0 : d.plaid_institutions
                    }), [d, y]);
                (0, h.useEffect)((function() {
                    (0, W.Y)({
                        requestType: 889,
                        responseType: 890
                    }).then((function(e) {
                        p(e)
                    })).catch((function(e) {
                        A.current.error(e)
                    }))
                }), []);
                return {
                    isLoading: a,
                    isReadyForConnection: b,
                    confirmationStatus: c,
                    institutions: T,
                    purchaseTransaction: g,
                    searchTerm: y,
                    handleBankSelected: function(e) {
                        o(!0), Y.A.getInstance().startTransaction(K(K({}, r), {}, {
                            plaidInstitutionId: e.id
                        }), (function(e) {
                            var t = e.error,
                                r = e.purchaseTransactionFailed;
                            if (t || !e.purchaseTransaction) {
                                var i, a, s;
                                if (r && (0, Y.i)(e)) i = null == (s = r.form_error) || null == (s = s.failure) ? void 0 : s.error_message, a = function() {
                                    return G.A.navigate(N.x.ADD_PHOTOS, {
                                        backHistoryEntry: G.A.getHistoryEntryId(),
                                        destination: G.A.getUrl()
                                    })
                                };
                                else null != r && r.notification && (i = r.notification.message);
                                i && V.A.showNotification({
                                        type: V.A.TYPES.ERROR,
                                        text: i
                                    }), e.error = e.error || new Error("Not able to purchase using Plaid"),
                                    function(e) {
                                        n(), e && e()
                                    }(a)
                            }
                            v(e.purchaseTransaction), o(!1)
                        }))
                    },
                    handleSearchTermChanged: P,
                    handleStartFlow: function() {
                        b && _()
                    }
                }
            }
            var Z = function(e) {
                    return {
                        accountProviderName: e.plaid_params.account_provider_name,
                        amount: e.plaid_params.amount,
                        bacsAccount: e.plaid_params.bacs_account,
                        bacsSortCode: e.plaid_params.bacs_sort_code,
                        linkToken: e.plaid_params.link_token,
                        payeeName: e.plaid_params.payee_name,
                        reference: e.plaid_params.reference
                    }
                },
                J = function(e) {
                    var t = e.paymentOptions,
                        r = e.onReturn,
                        i = z({
                            paymentOptions: t,
                            onReturn: r
                        }),
                        a = i.isLoading,
                        o = i.isReadyForConnection,
                        s = i.confirmationStatus,
                        c = i.institutions,
                        u = i.purchaseTransaction,
                        l = i.handleBankSelected,
                        h = i.handleSearchTermChanged,
                        g = i.handleStartFlow,
                        v = function() {
                            r()
                        };
                    return (0, d.jsx)(p, {
                        title: u ? n.Ay.get(83) : n.Ay.get(680),
                        onNavigateBack: v,
                        children: a ? (0, d.jsx)(b.A, {}) : u ? (0, d.jsx)(B, {
                            onClick: g,
                            returnToDestination: v,
                            orderParams: Z(u),
                            confirmationStatus: s,
                            isReadyForConnection: o,
                            providerLogo: (0, d.jsx)(f, {})
                        }) : (0, d.jsx)(S, {
                            onSelectInstitution: l,
                            institutions: c,
                            onSearchInstitution: h
                        })
                    })
                }
        },
        98819: function(e, t, r) {
            r(50113), r(48980), r(51629), r(25276), r(23792), r(2892), r(79432), r(26099), r(3362), r(27495), r(47764), r(11392), r(42762), r(98992), r(72577), r(3949), r(23500), r(62953);
            var n = r(23735),
                i = r(35837),
                a = r(1978),
                o = r(38795),
                s = r(47344),
                c = r(74022),
                u = r(57917),
                l = r(73090),
                d = r(23715),
                p = r(58336),
                f = r(26935),
                h = r(75248),
                g = r(41298),
                v = r(25093),
                m = r(65297),
                y = r(254),
                P = r(18826),
                A = r(15566),
                E = (0, p.A)("FLUSH", "HISTORY_UPDATED", "IS_WRITING", "MESSAGE_DELETED", "MESSAGE_FROM_ME", "MESSAGE_FROM_USER", "MESSAGES_READ", "NEW_MESSAGE_READ", "NEW_OFFLINE_MESSAGE", "CHAT_PROMO_HANDLED", "INPUT_FOCUSED", "SETTINGS_UPDATED"),
                _ = {},
                b = u.A.extend({
                    name: "Chat",
                    EVENTS: E,
                    commitCache: !1,
                    pendingPaidMessages_: [],
                    offlinePendingMessages: [],
                    getRequestMessageType: 102,
                    getResponseMessageType: [103],
                    setRequestMessageType: 104,
                    setResponseMessageType: (0, n.jU)(151, 1),
                    preventMultiple: !0,
                    watch_: {},
                    messagesToDelete: {},
                    init_: function() {
                        var e = this;
                        this.throttledSendReadTimestamp = (0, c.A)(this.sendReadTimestamp.bind(this), 500), d.A.on(d.A.EVENTS.ONLINE, this.sync_, this), m.A.on("push-sync", this.sync_, this), m.A.on(m.A.Session.LOGOUT, this.invalidateAll, this), h.A.getInstance().on(h.A.Type.CHAT_MESSAGE_RECEIVED, (function(t) {
                            e.checkPendingPaidMessages_((0, i.A)(t, A.bF6))
                        })).on(h.A.Type.CHAT_MESSAGE, (function(t) {
                            e.onChatMessageReceived_((0, i.A)(t, A.cMz))
                        })).on(h.A.Type.CHAT_MESSAGE_READ, this.onChatMessageRead_, this).on(h.A.Type.CHAT_IS_WRITING, this.onChatIsWriting_, this).on(h.A.Type.SYSTEM_NOTIFICATION, this.onSystemNotification_, this).on(h.A.Type.CHAT_SETTINGS, (function(t) {
                            return e.trigger(E.SETTINGS_UPDATED, t)
                        }), this)
                    },
                    sync_: function() {
                        for (var e = this, t = []; this.offlinePendingMessages.length;) {
                            var r = this.offlinePendingMessages.shift();
                            t.push(this.send(r.toPersonId, r))
                        }
                        Promise.all(t).then((function() {
                            Object.keys(e.watch_).forEach((function(t) {
                                P.A.read({
                                    userId: t
                                }).dummy ? e.trigger(E.FLUSH) : e.loadNewChatMessages_(t)
                            }))
                        }))
                    },
                    ignoreUser: function(e) {
                        delete this.watch_[e]
                    },
                    loadNewChatMessages_: function(e) {
                        var t = this,
                            r = P.A.read({
                                userId: e
                            });
                        if (r) {
                            var n = r.messages.length,
                                i = (0, o.A)(r.messages, (function(e) {
                                    return !e.isTemporary()
                                })),
                                a = i && Number(i.id),
                                s = {
                                    messageId: a
                                };
                            a && this.getMessages(e, s).then((function(e) {
                                n < e.length && t.trigger(E.MESSAGE_FROM_USER, e[0])
                            })).catch((function(r) {
                                (0, v.A)(r) && t.log.error("loadNewChatMessages_::SERVER_GET_CHAT_MESSAGES", r, {
                                    userId: e
                                }, s)
                            }))
                        }
                    },
                    watchUser: function(e) {
                        this.watch_[e] = !0
                    },
                    updatePrivateDetectorStatus: function(e, t) {
                        var r = (new A.eZb).setChatInstanceId(e).setEnable(t);
                        return this.fetch_(737, 360, r).then((function(t) {
                            var r = t[0];
                            P.A.update({
                                userId: e,
                                chatSettings: r
                            })
                        }))
                    },
                    markChatPromoHandled: function(e, t, r) {
                        P.A.markChatPromoHandled({
                            userId: e
                        }, t, r), this.trigger(E.CHAT_PROMO_HANDLED, t, r)
                    },
                    accessRequest: function(e, t, r) {
                        var n = this,
                            i = (new A.tUm).setAccessObject(t).setUserId(String(e));
                        return r && i.setVerificationAccessObject(r), this.fetch_(509, 105, i).then((function(e) {
                            var t = e[0];
                            if (t instanceof A.cMz) return n.onChatMessageReceived_(t)
                        }))
                    },
                    accessResponse: function(e) {
                        var t = this,
                            r = e.userId,
                            n = e.accessObject,
                            i = e.grant,
                            a = e.uid,
                            o = e.verificationAccessObject,
                            s = (new A.hBT).setAccessObject(n).setChatMessageUid(String(a)).setResponse(i ? 1 : 2).setUserId(String(r));
                        return o && s.setVerificationAccessObject(o), this.fetch_(510, 105, s).then((function(e) {
                            var r = e[0];
                            if (r instanceof A.cMz) return t.onChatMessageReceived_(r)
                        }))
                    },
                    add: function(e) {
                        if (P.A.update({
                                chatMessage: e
                            }), O(e) ? this.trigger(E.MESSAGE_FROM_ME, e) : this.trigger(E.MESSAGE_FROM_USER, e), !d.A.isOnline()) {
                            var t = C(e),
                                r = e instanceof y.Ay ? e.message : e.getMessage();
                            this.trigger(E.NEW_OFFLINE_MESSAGE, r, t.chatUser)
                        }
                        return this.triggerStreamDirectMessage_(e), e
                    },
                    checkPendingPaidMessages_: function(e) {
                        if (e instanceof A.bF6 && e.hasUid()) {
                            var t = this.pendingPaidMessages_.find((function(t) {
                                    return t.id === e.getUid()
                                })),
                                r = this.pendingPaidMessages_.indexOf(t);
                            if (t) return this.pendingPaidMessages_.splice(r, 1), e.getSuccess() ? t.resolve([e, null]) : t.reject(new Error("Failed to send paid chat message")), !0
                        }
                    },
                    revertAddMessage_: function(e, t) {
                        var r = P.A.read({
                                chatMessage: e
                            }),
                            n = null == r ? void 0 : r.messages;
                        if (this.pendingPaidMessages_.length) {
                            var i = this.pendingPaidMessages_.findIndex((function(t) {
                                return t.id === e.id
                            })); - 1 !== i && this.pendingPaidMessages_.splice(i, 1)
                        }
                        if (n) {
                            var a = n.findIndex((function(t) {
                                return t.id === e.id
                            }));
                            if (-1 === a) return;
                            null != t && t.increaseMaxAnswers && P.A.increaseMaxAnswers({
                                chatMessage: e
                            }), n.splice(a, 1)
                        }
                        this.trigger(E.MESSAGE_DELETED, e)
                    },
                    deleteChatMessage: function(e, t, r) {
                        var n = Promise.resolve();
                        t.startsWith(y.py) ? this.messagesToDelete[t] = {
                            reason: r
                        } : n = this.deleteChatMessageInServer(t, r);
                        var i = this.removeChatMessageFromStore(e, t),
                            a = i.messages,
                            o = i.index,
                            s = i.deletedMessage;
                        return n.catch((function(e) {
                            return a.splice(o, 0, s), e
                        }))
                    },
                    deleteChatMessageInServer: function(e, t) {
                        var r = (new A.Tcu).setUid(e).setDeleteReason(t);
                        return this.fetch_(373, 374, r).then((function(e) {
                            var t = e[0];
                            if (!t.getSuccess()) throw new Error("Not possible to delete chat message");
                            return t
                        }))
                    },
                    removeChatMessageFromStore: function(e, t) {
                        var r = P.A.read({
                                userId: e
                            }).messages,
                            n = r.find((function(e) {
                                return e.id === t
                            })),
                            i = r.indexOf(n);
                        return n && (r.splice(i, 1), this.trigger(E.MESSAGE_DELETED, n)), {
                            index: i,
                            messages: r,
                            deletedMessage: n
                        }
                    },
                    deleteInitialChatScreen: function(e) {
                        P.A.update({
                            userId: e,
                            initialScreen: null
                        })
                    },
                    reportUser: function(e) {
                        _[e] = !0
                    },
                    isUserReported: function(e) {
                        return _[e]
                    },
                    hasInitialChatScreen: function(e) {
                        return Boolean(this.getInitialChatScreen(e))
                    },
                    getInitialChatScreen: function(e) {
                        return P.A.read({
                            userId: e
                        }).initialScreen
                    },
                    cacheResponse_: function(e, t, r) {
                        var n = null == r ? void 0 : r[0];
                        return n instanceof A.eI_ ? P.A.update({
                            userId: e,
                            clientOpenChat: n
                        }) : r
                    },
                    getFromCache_: function() {
                        return null
                    },
                    getCachedClientOpenChat: C,
                    getSenderName: function(e) {
                        var t = e.fromPersonId;
                        if (l.A.getUserId() === t) return l.A.getUser().name;
                        return C(t).chatUser.getName()
                    },
                    isReplyFeatureAllowed: R,
                    getBlockingFeature: function(e) {
                        var t = this.getInitialChatScreen(e);
                        return null == t ? void 0 : t.blockingFeature
                    },
                    getPromoBlock: function(e, t) {
                        return P.A.read({
                            userId: e
                        }).promoBanners.find((function(e) {
                            return e.getPromoBlockType() === t
                        }))
                    },
                    getClientOpenChat: function(e, t) {
                        return !Number(e) && e.length < 20 && this.log.error("WRONG CHAT USER ID: " + e), d.A.isOnline() ? this.fetch(function(e, t) {
                            var r = (new A.Ad3).setChatInstanceId(e).setUserFieldFilter(T());
                            t && (t.allowConsumeChatUnblocker && r.setAllowConsumeChatUnblocker(t.allowConsumeChatUnblocker), "number" == typeof t.context && r.setContext(t.context), t.folderId && r.setFolderId(t.folderId), t.userType && r.setUserType(t.userType));
                            return r.setInitialScreenUserFieldFilter(S()), r
                        }(e, t)) : Promise.resolve(P.A.read({
                            userId: e
                        }))
                    },
                    getCacheKey_: function(e, t) {
                        return t instanceof A.Ad3 ? t.getChatInstanceId() : null
                    },
                    getMaxUnansweredMessages: function(e) {
                        return P.A.read({
                            userId: e
                        }).maxUnansweredMessages
                    },
                    getMessages: function(e, t) {
                        var r = this,
                            n = P.A.read({
                                userId: e
                            }).chatInstanceId;
                        return this.fetch_(279, 280, function(e, t) {
                            return t = t || {}, new A.wTs({
                                chat_instance_id: e,
                                count: t.count,
                                direction: t.direction,
                                inclusive: t.inclusive || !1,
                                message_id: t.messageId
                            })
                        }(n, t)).then((function(e) {
                            var t = e[0];
                            return r.updateChatMessages(t)
                        }))
                    },
                    getLastReadableMessage_: function(e, t) {
                        var r = P.A.read({
                            userId: e
                        }).messages;
                        return (0, o.A)(r, (function(e) {
                            return e.fromPersonId === t && 19 !== e.messageType
                        }))
                    },
                    send: function(e, t, r, n) {
                        if (this.messagesToDelete[t.id]) {
                            var i = (0, g.A)(Promise.resolve());
                            return i.cancel(), i
                        }
                        if (t.setStatus(t.STATUS.SENDING), !d.A.isOnline()) return -1 !== this.offlinePendingMessages.indexOf(t) || (this.offlinePendingMessages.push(t), this.add(t)), Promise.resolve(t);
                        var a = this.needToPayToSendMessage_(e, t) ? this.payToSend({
                            userId: e,
                            chatMessage: t,
                            backUrl: r,
                            redirectUrl: n
                        }) : this.set(t.toGPB());
                        return this.add(t), a.then(this.onSend_(e, t), this.onError_(t))
                    },
                    shouldCache_: function(e) {
                        return 555 !== e && this.useCache_
                    },
                    markMessageRead: function(e) {
                        this.updateTheirReadMessages_(e), e.setStatus(e.STATUS.READ)
                    },
                    likeMessage: function(e) {
                        var t = this,
                            r = e.isLiked,
                            n = e.messageType;
                        "EMOJI" === n && (n = 1);
                        var i = e.toGPB().setContext(e.context).setIsLiked(!r).setUid(e.id).setMessageType(n).setFromPersonId(e.fromPersonId).setToPersonId(e.toPersonId);
                        return this.fetch_(705, 151, i).then((function(r) {
                            var n = r[0];
                            if (!n || !n.getSuccess) throw new Error(new Error("No response received on message sent!"));
                            n.getSuccess() || t.onUpdateChatMessageError_(e), t.updateChatMessage_(e, n.getChatMessage().setRead(!0))
                        }))
                    },
                    sendQuestionsGameAnswer: function(e, t, r) {
                        var n = this,
                            i = (new A.vNH).setId(e.question.id).setText(e.question.text).setOwnAnswer(r ? t : e.question.own_answer).setOtherAnswer(r ? e.question.other_answer : t),
                            a = e.toGPB().setContext(e.context).setUid(e.id).setMessageType(50).setFromPersonId(e.fromPersonId).setToPersonId(e.toPersonId).setQuestion(i);
                        return this.fetch_(705, 151, a).then((function(t) {
                            var r = t[0];
                            if (!r) throw new Error(new Error("No response received on message sent!"));
                            r.getSuccess() || n.onUpdateChatMessageError_(e), n.updateChatMessage_(e, r.getChatMessage().setQuestion(i))
                        }), (function() {
                            n.onUpdateChatMessageError_(e)
                        }))
                    },
                    sendReadTimestamp: function(e) {
                        var t = P.A.read({
                            userId: e
                        });
                        this.fetch_(555, 387, (new A.eN$).setUserId(e).setReadTimestamp(t.readMessagesTimestamp))
                    },
                    markMultimediaView: function(e) {
                        var t = e.image,
                            r = null == t ? void 0 : t.viewDate,
                            n = 19 === e.messageType;
                        if (!e.isYours() && t && !r && n) {
                            var i = e.toGPB().setContext(e.context).setFromPersonId(e.toPersonId).setMessageType(20).setToPersonId(e.fromPersonId);
                            this.trigger(E.MESSAGES_READ, e.fromPersonId, e.dateCreated), this.set(i)
                        }
                    },
                    needToPayToSendMessage_: function(e, t) {
                        return I(this.getBlockingFeature(e)) || this.getPromoBlock(e, 472) || 10 === t.messageType
                    },
                    onChatMessageRead_: function(e) {
                        if (e) {
                            var t = e.user_id,
                                r = e.read_timestamp;
                            this.updateMyReadMessages_(t, r)
                        }
                    },
                    updateMyReadMessages_: function(e, t) {
                        var r = P.A.read({
                                userId: e
                            }),
                            n = null;
                        r.messages.forEach((function(e) {
                            !e.isRead && e.isYours() && e.dateCreated <= t && (n = e, e.setReadMessagesTimestamp(t), e.setStatus(e.STATUS.READ, void 0))
                        })), n && this.trigger(E.MESSAGES_READ, e, t)
                    },
                    updateTheirReadMessages_: function(e) {
                        var t = null,
                            r = e.fromPersonId,
                            n = P.A.read({
                                userId: r
                            }),
                            i = Math.max(e.dateCreated, n.readMessagesTimestamp);
                        n.messages.forEach((function(e) {
                            !e.isYours() && e.dateCreated <= i && !e.isRead && (t = e, e.isRead = !0)
                        })), t && !n.dummy && (n.readMessagesTimestamp = i, this.throttledSendReadTimestamp(r, i), this.trigger(E.NEW_MESSAGE_READ, r, t))
                    },
                    onChatIsWriting_: function(e) {
                        var t = e.who_is_writing;
                        this.trigger(E.IS_WRITING, t)
                    },
                    onChatMessageReceived_: function(e) {
                        if (!(e instanceof A.cMz)) {
                            if (e instanceof Error) this.log.error(e);
                            else {
                                var t = e && (e.$gpb || e.constructor.name) || "UNKNOWN";
                                this.log.error("Expected instance of ChatMessage and got " + t, e)
                            }
                            return e
                        }
                        if (10 !== e.getMessageType() || !this.pendingPaidMessages_.length) {
                            var r = C(e),
                                n = r.chatUser && r.chatUser.getUserId();
                            return this.add(new y.Ay(e, r.chatUser, {
                                isReplyFeatureAllowed: R(n)
                            }))
                        }
                        this.checkPendingPaidMessages_((new A.bF6).setChatMessage(e).setSuccess(!0).setUid(this.pendingPaidMessages_[0].id))
                    },
                    onSend_: function(e, t) {
                        var r = this;
                        return function(e) {
                            var n = e[0],
                                i = e[1];
                            if (!n && !i) throw new Error(new Error("No response received on message sent!"));
                            if (i || !n.getSuccess()) {
                                var a = "Unknown error when sending message",
                                    o = i ? function(e, t) {
                                        var r = e.getFeature(),
                                            n = new Error(r && r.getDisplayMessage() || e.getErrorMessage(t));
                                        return n.serverErrorMessage = e, n
                                    }(i, a) : new Error(a);
                                return r.onError_(t)(o)
                            }
                            return r.updateChatMessage_(t, n.getChatMessage()), t
                        }
                    },
                    onError_: function(e) {
                        return function(t) {
                            throw t.serverErrorMessage && 91 === t.serverErrorMessage.getType() && 3 === t.serverErrorMessage.getBehaviour() ? e.setStatus(e.STATUS.INAPPROPRIATE, "") : e.setStatus(e.STATUS.FAILED, t.message && t.message.replace(/\(.*\)/g, "").trim()), t
                        }
                    },
                    onUpdateChatMessageError_: function(e) {
                        var t = new Error("Unknown error when sending message");
                        return this.onError_(e)(t)
                    },
                    onSystemNotification_: function(e) {
                        switch (e.id) {
                            case 5:
                            case 2:
                            case 6:
                                this.invalidateAll(), this.trigger(E.FLUSH)
                        }
                    },
                    onStreamMessage: function(e, t) {
                        e && this.on(w(e), t)
                    },
                    offStreamMessage: function(e, t) {
                        var r = w(e);
                        this.hasListeners(r) && this.off(r, t)
                    },
                    triggerStreamDirectMessage_: function(e) {
                        var t = w(e.streamId);
                        this.hasListeners(t) && this.trigger(t, e)
                    },
                    invalidate: function(e) {
                        this.trigger(E.FLUSH), P.A.delete(e)
                    },
                    invalidateAll: function() {
                        P.A.delete()
                    },
                    payToSend: function(e) {
                        var t = this,
                            r = e.userId,
                            n = e.chatMessage,
                            i = e.backUrl,
                            a = e.redirectUrl,
                            o = e.blockingFeature;
                        return new Promise((function(e, s) {
                            var c = t.getPromoBlock(r, 472),
                                u = function(e, t, r) {
                                    if (e.gift) {
                                        var n = e.gift.getGift();
                                        return {
                                            activationPlace: 122,
                                            cost: n.getCost(),
                                            objectId: String(n.getProductId()),
                                            product: 5
                                        }
                                    }
                                    if (t) return {
                                        activationPlace: I(t) ? 80 : null,
                                        cost: t.getPaymentAmount(),
                                        product: t.getProductType()
                                    };
                                    if (r) return {
                                        activationPlace: 472 === r.getPromoBlockType() ? 80 : null,
                                        cost: r.getPaymentAmount(),
                                        product: r.getOkPaymentProductType()
                                    }
                                }(n, o || t.getBlockingFeature(r), c);
                            c && t.markChatPromoHandled(r, c.getPromoBlockType()), t.pendingPaidMessages_.push({
                                id: n.id,
                                resolve: e,
                                reject: s
                            }), f.A.purchase({
                                back: i,
                                cost: null == u ? void 0 : u.cost,
                                newNavigation: a,
                                chatMessage: n,
                                hotPanelData: u,
                                productType: u.product,
                                userId: r,
                                complete: function(e) {
                                    e || (t.revertAddMessage_(n), c && t.markChatPromoHandled(r, c.getPromoBlockType(), !0))
                                },
                                error: function(e) {
                                    n.setStatus(n.STATUS.FAILED, null == e ? void 0 : e.message), s(e || new Error("Unknown error when try to send a payed message"))
                                },
                                success: function() {
                                    P.A.update({
                                        userId: r,
                                        blockingFeature: null
                                    })
                                }
                            })
                        }))
                    },
                    updateChatMessages: function(e) {
                        var t = e.getChatInstance().getUid(),
                            r = P.A.update({
                                userId: t,
                                clientChatMessages: e
                            });
                        return this.trigger(E.HISTORY_UPDATED, t, r.counter, r.messages.length), r.messages
                    },
                    updateChatMessage_: function(e, t) {
                        var r = t.getUid(),
                            n = this.messagesToDelete[e.id];
                        if (n) return this.revertAddMessage_(e, {
                            increaseMaxAnswers: !0
                        }), void this.deleteChatMessageInServer(r, n.reason);
                        var i = P.A.read({
                                chatMessage: e
                            }),
                            a = i.messages.find((function(e) {
                                return e.id === r
                            }));
                        a && e.id !== r ? (this.revertAddMessage_(e, {
                            increaseMaxAnswers: !0
                        }), a.update(t, i.chatUser), this.add(a)) : (e.update(t, i.chatUser), this.add(e))
                    },
                    getMaskedMessage: function(e, t) {
                        var r = this;
                        return this.fetch_(606, (0, n.jU)(280, 360), (new A.tm1).setUserId(e).setAction(1).setMessageIds(t).setContext(10)).then((function(t) {
                            var n = t[0],
                                i = t[1],
                                o = r.updateChatMessages(n);
                            return i && (0, a.A)((function() {
                                P.A.update({
                                    userId: e,
                                    chatSettings: i
                                })
                            })), o
                        }))
                    },
                    focusInput: function() {
                        this.trigger(E.INPUT_FOCUSED)
                    },
                    setShowLikelyOffensivePrompt: function(e, t) {
                        C(e).isShowingOffensiveMessagesPrompt = t
                    },
                    createMultimedia: function(e) {
                        var t = (new A.$_D).setId(e.multimediaId),
                            r = (new A.anE).setVisibilityType(e.visibility);
                        return (new A.U0R).setFormat(e.format || 1).setPhoto(t).setVisibility(r)
                    },
                    isContactsForCreditsFeature: I,
                    isYours: O
                }, "ChatModel");
            var T = (0, s.A)((function() {
                    var e = new A.KkJ,
                        t = [210, 230, 610, 580, 290, 583, 250, 100, 570, 200, 331, 330, 340, 560, 650, 930, 1436, 760, 761];
                    return e.setRequestAlbums([(new A.Nij).setAlbumType(2).setCount(20)]).setProfileOptionTypes([10, 1, 12]), t.push.apply(t, [370, 431, 700, 410, 310, 490, 311]), e.setProjection(t)
                })),
                S = function() {
                    return (new A.KkJ).setProjection([760, 761])
                };

            function I(e) {
                var t = e;
                if (!t) return !1;
                var r = t.getCreditsForProduct(t.getProductType());
                return 18 === r || 12 === r
            }

            function O(e) {
                return e instanceof A.cMz ? e.getFromPersonId() === l.A.getUserId() : e.fromPersonId === l.A.getUserId()
            }

            function C(e) {
                return e instanceof A.cMz ? e = O(e) ? e.getToPersonId() : e.getFromPersonId() : e instanceof y.Ay && (e = O(e) ? e.toPersonId : e.fromPersonId), P.A.read({
                    userId: e
                })
            }

            function R(e) {
                var t = C(e);
                return Boolean(t.isReplyFeatureAllowed)
            }

            function w(e) {
                return "STREAM::" + e
            }
            var D = new b;
            D.getInstance = function() {
                return D
            }, t.A = D
        }
    }
]);
//# sourceMappingURL=8819.37f07638da84cd911fb3.js.map
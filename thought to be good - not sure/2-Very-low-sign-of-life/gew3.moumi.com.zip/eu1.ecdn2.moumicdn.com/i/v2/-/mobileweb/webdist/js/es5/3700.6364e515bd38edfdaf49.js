"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [3700], {
        1765: function(e, t, r) {
            r(50113), r(51629), r(25276), r(15086), r(52675), r(45700), r(2008), r(60739), r(89572), r(2892), r(67945), r(84185), r(83851), r(81278), r(79432), r(54520), r(26099), r(3362), r(98992), r(72577), r(3949), r(37550), r(23500);
            var n, i, o = r(85208),
                a = r(1978),
                c = r(97286),
                s = r(3508),
                u = r(58544),
                f = r(58385),
                d = r(5586),
                p = r(73090),
                l = r(58336),
                g = r(19232),
                v = r(37905),
                h = r(79860),
                y = r(18084),
                m = r(41025),
                A = r(47294),
                T = r(31087),
                P = r(32308),
                b = r(74389),
                O = r(63620);

            function I(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function E(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? I(Object(r), !0).forEach((function(t) {
                        _(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : I(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function _(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var R = r(13242).A.hasRecentlyPassedVerification,
                w = ((n = {})[1] = {
                    id: "facebook",
                    hotpanel: 6,
                    element: 120
                }, n[2] = {
                    id: "vk",
                    hotpanel: 9,
                    element: 178
                }, n[3] = {
                    id: "ok",
                    hotpanel: 10,
                    element: 179
                }, n[4] = {
                    id: "google",
                    hotpanel: 11,
                    element: 301
                }, n[12] = {
                    id: "instagram",
                    hotpanel: 13,
                    element: 44
                }, n[14] = {
                    id: "linkedin",
                    hotpanel: 8,
                    element: 302
                }, n[15] = {
                    id: "twitter",
                    hotpanel: 7,
                    element: 201
                }, n),
                V = "phone",
                x = "spp",
                S = ((i = {})[1] = "facebook", i[2] = "vkontakte", i[3] = "odnoklassniki", i[4] = "google", i[15] = "twitter", i[12] = "instagram", i[14] = "linkedin", i),
                D = y.A.getLogger("VerificationUtil"),
                F = (0, l.A)("FAIL", "SUCCESS"),
                C = (0, o.A)({
                    verify: function(e) {
                        var t, r = v.A.controller,
                            n = {
                                context: r.activationPlace,
                                destination: e.destination || f.A.getUrl(),
                                isForced: !1,
                                isNotification: !1,
                                requireVerification: e.isForced || !1,
                                verifyForUser: e.verifyForUser
                            };
                        switch (e.activationPlace && (n.activationPlace = e.activationPlace), (0, o.A)(n, (0, c.A)(e, Object.keys(n))), e.methodType) {
                            case 5:
                                var i;
                                t = 5;
                                var a = n.isForced ? b.x.FORCED_PHOTO_VERIFICATION : b.x.PHOTO_VERIFICATION;
                                f.A.navigate(a, {
                                    callback: n.callback,
                                    clientSource: n.clientSource,
                                    destination: n.destination,
                                    isNotification: n.isNotification,
                                    promo: null == (i = n.promo) ? void 0 : i.toJSON()
                                });
                                break;
                            case 1:
                                t = 2, f.A.navigate(b.x.PHONE_VERIFICATION, E(E({}, n), {}, {
                                    verificationMethod: e.verificationMethod
                                }));
                                break;
                            case 2:
                                t = 12;
                                var s = {
                                    back: n.destination,
                                    hotPanelData: {
                                        activationPlace: n.activationPlace
                                    },
                                    productType: 1
                                };
                                return Promise.resolve(m.A.navigateToPayment(s));
                            case 3:
                                if (!e.providerType) return D.error("no provider type", e), Promise.reject(new Error("No provider type given for VERIFY_SOURCE_EXTERNAL_PROVIDER"));
                                w[e.providerType] && (t = w[e.providerType].hotpanel), this.login_(e)
                        }
                        return (0, P.Rg)(r.getScreenName()) && t && (0, h.sx)(164, {
                            verification_method: t,
                            activation_place: n.activationPlace || r.activationPlace
                        }), Promise.resolve()
                    },
                    verifyByPhoto: function(e) {
                        var t = this;
                        return e = e || {}, T.A.getInstance().get({
                            id: p.A.getUserId(),
                            requestedFields: [100]
                        }).then((function(r) {
                            var n = r.getVerifiedInformation().getMethods([]),
                                i = n.find((function(e) {
                                    return 5 === e.getType()
                                })),
                                a = i.getIsConfirmed(!1),
                                c = i.getIsConnected(!1),
                                s = !a && !!i.getSecondsToWait(),
                                u = c && s;
                            return c && a || u ? !!u && f.A.navigate(b.x.OWN_PROFILE_EDIT, {
                                anchor: O.l.VERIFICATION
                            }) : t.verify((0, o.A)(e, {
                                methodType: 5
                            }))
                        }), D.error)
                    },
                    login_: function(e) {
                        g.A.off(g.A.EVENTS.AUTH_ERROR, this.onFail_), g.A.on(g.A.EVENTS.AUTH_ERROR, this.onFail_.bind(this));
                        var t = e.destination || d.A.encodeRoute(b.x.VERIFY, {
                                returnRoute: f.A.getUrl(),
                                methodType: e.methodType,
                                providerType: e.providerType
                            }),
                            r = {
                                callback: this.setVerified.bind(this, e),
                                methodType: e.methodType,
                                providerContext: e.providerContext || 3,
                                context: e.context || null,
                                providerType: e.providerType,
                                returnRoute: t,
                                startVerification: !0
                            };
                        g.A.login(r)
                    },
                    setVerified: function(e, t) {
                        var r = this,
                            n = t.providerId,
                            i = t.providerType,
                            o = g.A.getStoredAuthData();
                        t.provider && (n = t.provider.id, i = t.provider.type), o && (n = o.providerId, g.A.removeStoredAuthData());
                        var a = {
                            methodType: t.methodType,
                            providerId: n,
                            providerType: i,
                            verifyForUser: e.verifyForUser,
                            context: t.context
                        };
                        return A.A.getInstance().setVerified(a).then((function(t) {
                            N(e.destination), t && t.getSuccess() ? r.trigger(F.SUCCESS, t) : r.onFail_(t)
                        })).catch((function(t) {
                            N(e.destination), r.onFail_(t)
                        }))
                    },
                    registerProviders: function(e, t) {
                        var r = [];
                        e.forEach((function(e) {
                            var t = e.getExternalProviderData();
                            t && r.push(t.toJSON())
                        })), g.A.setProviderData(t || 3, r)
                    },
                    disconnect: function(e) {
                        A.A.getInstance().remove({
                            methodType: e.methodType,
                            providerType: e.providerType
                        }).then(e.callback)
                    },
                    onFail_: function(e) {
                        D.error("Verification Failed", e), this.trigger(F.FAIL, e)
                    },
                    createContextForMethod: function(e, t, r) {
                        var n, i = e.getType(),
                            o = s.A.get("verification.providers"),
                            a = null,
                            c = e.getVerificationData() || e.getDisplayMessage();
                        p.A.isLoggedIn() || (c = e.getDisplayMessage() || e.getVerificationData());
                        var u = {
                            hideMessage: r,
                            isConfigurable: t && e.getIsConfirmed() && e.hasAccessRestrictions(),
                            isInactive: !e.getIsConfirmed() || e.hasAccessRequestPromo(),
                            message: c,
                            methodType: e.getType(),
                            name: e.getName(),
                            verified: e.getIsConfirmed(!1)
                        };
                        switch (i) {
                            case 1:
                                a = V;
                                break;
                            case 2:
                                a = x;
                                break;
                            case 5:
                                var f = e.getPhotoVerification(),
                                    d = e.getIsConfirmed(),
                                    l = e.getIsConnected(),
                                    g = f && f.hasError();
                                u.isProcessing = !1, d || (!f || l && !g) && (u.isProcessing = !0), u.verificationError = g, u.secondsToWait = e.getSecondsToWait(0);
                                break;
                            case 3:
                                if (!(n = e.getExternalProviderData())) return void this.log.error("broken provider", e);
                                var v = u.providerType = n.getType();
                                if (-1 === o.indexOf(v)) return null;
                                a = S[v]
                        }
                        return u.className = a, u[a] = {
                            verified: e.getIsConfirmed()
                        }, u
                    },
                    createKeyForMethod: function(e) {
                        var t = e.getType();
                        return 1 === t ? "phone" : 2 === t ? "spp" : 3 === t ? w[e.getExternalProviderData().getType()].id : void 0
                    },
                    createHotPanelVerificationMethod: function(e) {
                        var t = e.getType();
                        if (1 === t) {
                            var r = e.getPhoneNumberVerificationType();
                            if (2 === r) return 2;
                            if (3 === r) return 1
                        } else {
                            if (5 === t) return 5;
                            if (3 === t) return w[e.getExternalProviderData().getType()].hotpanel
                        }
                    },
                    getVerificationHotPanelElement: function(e) {
                        var t = e.getType();
                        return 1 === t ? 300 : 2 === t ? 130 : 3 === t ? w[e.getExternalProviderData().getType()].element : void 0
                    },
                    handleNotification: function(e) {
                        var t = e.getVerifiedInformation().getMethods(),
                            r = t.find((function(e) {
                                return 1 === e.getType()
                            }));
                        if (r) f.A.navigate(b.x.PHONE_VERIFICATION, {
                            requireVerification: e.getBlocking() ? "true" : "false",
                            isNotification: "true",
                            verificationMethod: r
                        });
                        else if (t.some((function(e) {
                                return 5 === e.getType()
                            }))) {
                            var n;
                            if (R()) return;
                            var i = e.getBlocking() ? b.x.FORCED_PHOTO_VERIFICATION : b.x.PHOTO_VERIFICATION;
                            f.A.navigate(i, {
                                promo: null == (n = e.getPromoBlock()) ? void 0 : n.toJSON(),
                                isNotification: !0
                            })
                        } else;
                    }
                }, u.zb);

            function N(e) {
                e && (0, a.A)((function() {
                    f.A.navigate(e, !0, {
                        date: +new Date
                    })
                }))
            }
            C.ACTIONS = F, t.A = C
        },
        13242: function(e, t) {
            var r;
            t.A = {
                notifyVerificationPassed: function() {
                    r = Date.now()
                },
                hasRecentlyPassedVerification: function() {
                    return r && Date.now() < r + 3e4
                }
            }
        },
        31247: function(e, t, r) {
            r.d(t, {
                b: function() {
                    return n
                }
            });
            r(2008), r(48598), r(26099), r(98992), r(54520);

            function n(e, t) {
                return e.filter((function(e) {
                    return void 0 !== e && "" !== e
                })).join(t || ", ")
            }
        },
        37445: function(e, t, r) {
            var n = r(32675),
                i = r(74848);
            t.A = function(e) {
                var t = e.text,
                    r = e.size,
                    o = e.onClick,
                    a = e.icon;
                return (0, i.jsx)(n.A, {
                    onClick: o,
                    text: t,
                    size: r,
                    icon: a
                })
            }
        },
        42616: function(e, t, r) {
            r.d(t, {
                h: function() {
                    return o
                }
            });
            var n = r(40075),
                i = r(31247);

            function o(e) {
                var t, r = e.userName,
                    o = e.isProfilePhoto,
                    a = e.type,
                    c = void 0 === a ? "photo" : a,
                    s = e.provider,
                    u = e.position,
                    f = e.total,
                    d = e.extraAction,
                    p = e.hasOpenFullScreenAction ? n.Ay.get(548) : void 0,
                    l = u && f ? n.Ay.get(547, {
                        position: u,
                        total: f
                    }) : void 0;
                return r ? (t = n.Ay.get(692, {
                    name: r
                }), o && (t = n.Ay.get(686, {
                    name: r
                })), "video" === c && (t = n.Ay.get(693, {
                    name: r
                })), 12 === s && (t = n.Ay.get(690, {
                    name: r
                }), "video" === c && (t = n.Ay.get(691, {
                    name: r
                }))), u && f && (t = n.Ay.get(687, {
                    name: r,
                    num: u,
                    total: f
                }), "video" === c && (t = n.Ay.get(688, {
                    name: r,
                    num: u,
                    total: f
                })), 12 === s && (t = n.Ay.get(689, {
                    name: r,
                    n: u,
                    total: f
                }), "video" === c && (t = n.Ay.get(691, {
                    name: r
                }), t = (0, i.b)([t, l])))), (0, i.b)([t, d || p])) : (t = "video" === c ? n.Ay.get(564) : n.Ay.get(549), (0, i.b)([t, l, d || p]))
            }
        },
        44523: function(e, t, r) {
            r(52675), r(89463), r(45700), r(2008), r(51629), r(89572), r(2892), r(67945), r(84185), r(83851), r(81278), r(79432), r(26099), r(98992), r(54520), r(3949), r(23500);
            var n = r(96540),
                i = r(93827),
                o = r(47667),
                a = r(17380),
                c = r(36693),
                s = r(8483),
                u = r(74848);

            function f(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function d(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? f(Object(r), !0).forEach((function(t) {
                        p(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : f(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function p(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            t.A = function(e) {
                var t = e.header,
                    r = e.description,
                    f = e.icon,
                    p = e.type,
                    l = e.isStandalone,
                    g = e.isSelected,
                    v = e.onOptionClick,
                    h = {
                        align: "left",
                        color: "black",
                        dataQA: {
                            "data-qa-tiw-option-header": p || ""
                        }
                    },
                    y = l ? (0, u.jsx)(i.Zb, d(d({}, h), {}, {
                        children: t
                    })) : (0, u.jsxs)(n.Fragment, {
                        children: [(0, u.jsx)(i.ZS, d(d({}, h), {}, {
                            children: t
                        })), r ? (0, u.jsx)(c.A, {
                            top: "xsm",
                            children: (0, u.jsx)(i.P2, {
                                align: "left",
                                color: "gray-80",
                                children: r
                            })
                        }) : null]
                    });
                return (0, u.jsx)(o.A, {
                    media: null != f && f.name ? (0, u.jsx)(s.A, {
                        name: f.name,
                        size: "xlg",
                        color: f.color
                    }) : null,
                    mediaAlign: "center",
                    content: y,
                    extra: l ? null : (0, u.jsx)(a.A, {
                        isChecked: g,
                        type: "radio"
                    }),
                    color: g ? "selected" : "gray-10",
                    onClick: v,
                    dataQA: p ? {
                        "data-qa-tiw-option-type": p
                    } : void 0
                })
            }
        },
        47294: function(e, t, r) {
            r(50113), r(26099), r(3362), r(98992), r(72577);
            var n, i = r(32308),
                o = r(23735),
                a = r(57917),
                c = r(73090),
                s = r(88651),
                u = r(31087),
                f = r(64266),
                d = r(15566),
                p = a.A.extend({
                    name: "Verification",
                    commitCache: !1,
                    getRequestMessageType: 260,
                    getResponseMessageType: 261,
                    setRequestMessageType: 262,
                    setResponseMessageType: [263, 261],
                    removeRequestMessageType: 264,
                    removeResponseMessageType: 265,
                    waitingApproval_: !1,
                    photoVerificationUploadedData_: null,
                    get: function(e) {
                        var t = this;
                        return c.A.isLoggedIn() ? this.waitingApproval_ ? this.fetch(e) : u.A.getInstance().get(this.getRequest_(e)).then((function(e) {
                            return t.onResult_(e)
                        })).catch((function(e) {
                            return t.onError_(e)
                        })) : Promise.reject(new Error("Cannot verify without being logged in"))
                    },
                    fetch: function(e) {
                        var t = this;
                        return u.A.getInstance().fetch(this.getRequest_(e)).then((function(e) {
                            return t.onResult_(e)
                        })).catch((function(e) {
                            return t.onError_(e)
                        }))
                    },
                    getRequest_: function(e) {
                        return {
                            context: e.context,
                            id: c.A.getUserId(),
                            requestedFields: [100]
                        }
                    },
                    onResult_: function(e) {
                        var t = e.getVerifiedInformation();
                        return this.waitingApproval_ = 0 !== function(e) {
                            var t = e.getMethods([]),
                                r = t.find((function(e) {
                                    return 5 === e.getType()
                                }));
                            return r && r.getSecondsToWait(0)
                        }(t), [t, this.uploadedPhotoVerificationData]
                    },
                    onError_: function(e) {
                        if (e instanceof d.beZ && 51 === e.getType()) throw e;
                        if (!(0, f.A)(e)) throw new Error("Error while fetching USER_FIELD_VERIFIED_INFORMATION.")
                    },
                    setRestriction: function(e, t) {
                        var r = (new d.ve9).setType(e.getType());
                        e.hasExternalProviderData() && r.setProviderType(e.getExternalProviderData().getType()), new o.Ay(507, (new d.Mrk).setMethod(r).setAccessType(t)).request()
                    },
                    setRequest_: function(e, t) {
                        return new o.Ay(this.setRequestMessageType, e).setRetryCount(this.maxRetries_).on(o.jU.apply(null, this.setResponseMessageType), t, this).request()
                    },
                    setVerified: function(e) {
                        var t = this,
                            r = (new d.aYs).setType(e.methodType);
                        return 1 === e.methodType && e.phoneVerificationType && r.setSwitchPhoneNumberVerificationType(e.phoneVerificationType), "string" == typeof e.pin ? r.setPinCode(e.pin) : 1 === e.methodType ? (e.token && (r.setPhoneNumber(e.token), r.setPhonePinRequest(!0)), e.phonePrefix && r.setPhonePrefix(e.phonePrefix), e.reset && r.setReset(!0)) : 5 === e.methodType ? "string" == typeof e.photoId && r.setPhotoId(e.photoId) : r.setExternalProviderDetails((new d.TlF).setProviderId(e.providerId)), e.verifyForUser && r.setVerifyForUser(e.verifyForUser), e.context && r.setContext(e.context), p._super.set.call(this, r).then((function(t) {
                            var r = t[0],
                                n = t[1];
                            return l(e, r, n), r
                        })).catch((function(e) {
                            return t.onError_(e)
                        }))
                    },
                    getPhotoVerificationUploadedData: function() {
                        return this.photoVerificationUploadedData_
                    },
                    setPhotoVerificationUploadedData: function(e) {
                        this.photoVerificationUploadedData_ = e
                    },
                    clearPhotoVerificationUploadedData: function() {
                        this.setPhotoVerificationUploadedData(null)
                    },
                    remove: function(e) {
                        var t = this,
                            r = new d.Wgd;
                        return r.setVerificationType(e.methodType), (0, i.Rg)(e.providerType) && r.setExternalProviderType(e.providerType), new Promise((function(n, i) {
                            new o.Ay(t.removeRequestMessageType, r).on(t.removeResponseMessageType, (function(t, r) {
                                t ? i(t) : (l(e, r.getVerifiedSource()), n(r))
                            })).request()
                        }))
                    }
                }, "Verification");

            function l(e, t, r) {
                u.A.getInstance().invalidateAll(), s.A.getInstance().invalidateAll(), t && (t = t instanceof d.JnN ? t : t.getVerifiedSource(), g(c.A.getUserId(), t)), null != e && e.verifyForUser && r instanceof d.JnN && g(e.verifyForUser, r)
            }

            function g(e, t) {
                if (t) {
                    var r = {
                        verifiedInformation: t
                    };
                    t.hasVerificationStatus() && (r.verificationStatus = t.getVerificationStatus()), u.A.getInstance().updateCache(e, r)
                }
            }
            p.getInstance = function() {
                return n || (n = new p)
            }, t.A = p
        },
        63620: function(e, t, r) {
            var n;
            r.d(t, {
                    l: function() {
                        return n
                    }
                }),
                function(e) {
                    e.ADD_INTERESTS = "add-interests", e.OWN_INTERESTS = "own-interests", e.ADD_PHOTOS = "add-photos", e.PREVIEW_PROFILE = "preview-profile", e.VERIFICATION = "verification", e.ANCHOR_MOOD_STATUS = "mood-status", e.PLANS_TAB = "plans", e.SAFETY_TAB = "safety"
                }(n || (n = {}))
        },
        93019: function(e, t, r) {
            r.d(t, {
                I: function() {
                    return o
                },
                p: function() {
                    return a
                }
            });
            r(62062), r(26099), r(98992), r(81454);
            var n, i = ((n = {})[0] = "unknown", n[1] = "friends", n[2] = "chat", n[3] = "date", n[4] = "casual", n[5] = "serious", n[6] = "dont_mind", n[7] = "business", n[8] = "long_commitment", n),
                o = function(e) {
                    switch (e) {
                        case 2:
                            return {
                                name: "generic-bubble",
                                color: "default"
                            };
                        case 3:
                            return {
                                name: "generic-cup",
                                color: "default"
                            };
                        case 5:
                            return {
                                name: "generic-heart",
                                color: "default"
                            };
                        default:
                            return
                    }
                },
                a = function(e, t, r) {
                    return e.map((function(e) {
                        var n = o(e.type);
                        return {
                            id: e.tiw_phrase_id,
                            header: e.tiw_phrase,
                            description: e.tiw_description,
                            isSelected: e.tiw_phrase_id === t,
                            onOptionClick: function() {
                                return r(e.tiw_phrase_id)
                            },
                            type: i[e.type || 0],
                            icon: n
                        }
                    }))
                }
        }
    }
]);
//# sourceMappingURL=3700.6364e515bd38edfdaf49.js.map
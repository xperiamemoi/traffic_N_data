"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [4375], {
        20816: function(t, e, n) {
            n(51629), n(25276), n(23792), n(79432), n(10287), n(26099), n(3362), n(98992), n(3949), n(23500), n(62953);
            var i = n(58544),
                o = n(73090),
                r = n(27378),
                a = n(75248),
                s = n(31709),
                c = n(84230);

            function u(t, e) {
                return u = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                    return t.__proto__ = e, t
                }, u(t, e)
            }
            var l = [8, 0, 6, 4, 53, 54],
                f = function(t) {
                    function e() {
                        var e;
                        return (e = t.call(this) || this).EVENTS = {
                            CHANGE: 1,
                            UPDATE: 2,
                            INVALIDATED: "invalidated"
                        }, e.cache = void 0, e.trackNextRequest = !1, e.cache = c.A.getInstance("BadgeCounters"), e.cache.on(c.A.EVENTS.INVALIDATED, (function(t) {
                            e.trigger(e.EVENTS.INVALIDATED, t)
                        })), a.A.getInstance().on(a.A.Type.PERSON_NOTICE, (function(t) {
                            e.cacheResponse(t)
                        })).on(a.A.Type.CHAT_MESSAGE, (function() {
                            e.invalidateAll()
                        })), e
                    }
                    var n, i;
                    i = t, (n = e).prototype = Object.create(i.prototype), n.prototype.constructor = n, u(n, i);
                    var f = e.prototype;
                    return f.getCached = function() {
                        var t = this,
                            e = this.cache.getKeys() || [],
                            n = {},
                            i = [];
                        return e.length > 0 && e.forEach((function(e) {
                            var o = t.cache.get(e);
                            o && "badoo.bma.PersonNotice" === o.$gpb && void 0 !== o.folder && (n[o.folder] = o.int_value, i.push(o))
                        })), {
                            values: n,
                            notices: i
                        }
                    }, f.get = function() {
                        var t = this.getCached();
                        return 0 === Object.keys(t.values).length ? this.fetch() : Promise.resolve(t)
                    }, f.fetch = function() {
                        var t = this;
                        return o.A.isLoggedIn() ? new Promise((function(e) {
                            var n = new s.Ay(157, {
                                folder_id: l,
                                person_notice_type: [1]
                            }).onResponse(138, t.cacheResponse, t).onSpecialEvent(s.SE.REQ_FINISHED, (function() {
                                e(t.getCached())
                            }));
                            t.trackNextRequest && (r.A.trackRPC(n), t.trackNextRequest = !1), n.request()
                        })) : Promise.resolve(void 0)
                    }, f.trackNext = function() {
                        return this.trackNextRequest = !0, this
                    }, f.invalidateAll = function() {
                        this.cache.invalidateAll()
                    }, f.cacheResponse = function(t) {
                        if (void 0 !== t.folder && -1 !== l.indexOf(t.folder) && (1 === t.type || 3 === t.type || 5 === t.type)) {
                            var e = function(t) {
                                    var e = void 0 !== t.folder ? t.folder : "-";
                                    return "" + (t.type || "-") + e
                                }(t),
                                n = this.cache.get(e);
                            this.trigger(this.EVENTS.UPDATE, t, n), this.cache.put(e, t, {
                                ttl: 36e5
                            });
                            var i = t.int_value || 0,
                                o = (null == n ? void 0 : n.int_value) || 0;
                            if (!n || i !== o) {
                                var r = n ? i - o : i;
                                this.trigger(this.EVENTS.CHANGE, t, r)
                            }
                        }
                    }, e
                }(i.sV);
            e.A = new f
        },
        23318: function(t, e, n) {
            n.d(e, {
                A: function() {
                    return i
                }
            });
            n(50113), n(26099), n(27495), n(98992), n(72577);

            function i(t, e) {
                var n, i = ((null == t ? void 0 : t.external_endpoints) || []).find((function(t) {
                    return t.type === e
                }));
                return null == i || null == (n = i.url) ? void 0 : n.replace("http://", "https://")
            }
        },
        23336: function(t, e, n) {
            n.d(e, {
                F: function() {
                    return o
                }
            });
            var i, o, r = n(46942),
                a = n.n(r),
                s = n(74848);
            ! function(t) {
                t.DEFAULT = "DEFAULT", t.SQUARE = "SQUARE"
            }(o || (o = {}));
            var c = ((i = {})[o.DEFAULT] = "", i[o.SQUARE] = "external-ads-banner--square", i);
            e.A = function(t) {
                var e, n = t.adSlot,
                    i = t.dataQa,
                    r = t.type,
                    u = void 0 === r ? o.DEFAULT : r,
                    l = t.innerRef,
                    f = t.disabled,
                    p = a()(((e = {
                        "external-ads-banner": !0
                    })[c[u]] = !0, e["external-ads-banner--no-events"] = f, e));
                return (0, s.jsx)("div", {
                    className: p,
                    children: (0, s.jsx)("div", {
                        id: n,
                        "data-qa-ads": i,
                        ref: l
                    })
                })
            }
        },
        41795: function(t, e, n) {
            n(61806)
        },
        42982: function(t, e, n) {
            n.r(e), n.d(e, {
                default: function() {
                    return _e
                }
            });
            var i = n(40961),
                o = n(99417),
                r = (n(2892), n(26099), n(3362), n(27495), n(18084)),
                a = r.A.getLogger("hasStylesheetLoaded"),
                s = function(t, e) {
                    var n = !1;
                    return new Promise((function(i, r) {
                        if (n) i();
                        else {
                            var s = 0,
                                c = o.A.document,
                                u = c.createElement("div");
                            u.id = t;
                            var l = c.body;
                            l.appendChild(u);
                            var f = setInterval((function() {
                                s++;
                                try {
                                    Math.ceil(Number(o.A.getComputedStyle(u, null).height.replace("px", ""))) === e && (l.removeChild(u), clearInterval(f), n = !0, i())
                                } catch (e) {
                                    s > 500 && (t = "CSS not loaded after 500 attempts. Exception: " + e.message, a.error(t), l.removeChild(u), clearInterval(f), r(new Error(t)))
                                }
                                var t
                            }), 60)
                        }
                    }))
                };
            n(52675), n(45700), n(28706), n(2008), n(51629), n(89572), n(67945), n(84185), n(83851), n(81278), n(79432), n(98992), n(54520), n(3949), n(23500);
            var c = n(64174),
                u = (n(50113), n(23792), n(47764), n(72577), n(62953), n(96540)),
                l = n(49603),
                f = n(22302),
                p = n(36521),
                d = n(36721),
                h = n(85854);
            var v = n(88309),
                m = n(46163),
                b = n(27384),
                g = "js-touchable",
                A = "is-pressed";

            function y(t) {
                return (0, u.useEffect)((function() {
                    var e, n = t.current;
                    if (n) {
                        n.appendChild((0, v.A)()), n.appendChild((0, b.j)()), n.appendChild((0, m.A)());
                        var i = o.A.document.createElement("div");
                        i.className = "js-onboarding-tips", n.appendChild(i), e = o.A.document.body, p.A.ios && (e.classList.add("ios"), 9 === p.A.version && e.classList.add("ios9"), p.A.version >= 9 ? e.classList.add("ios-font-sanfrancisco") : e.classList.add("ios-font-helvetica"), p.A.iphoneNotch && e.classList.add("ios-notch")), p.A.android && (e.classList.add("android"), p.A.version >= 5 ? e.classList.add("android-font-roboto-new") : e.classList.add("android-font-system")), p.A.windowsPhone && (e.classList.add("windows"), p.A.windowsPhone10 ? e.classList.add("windows10") : e.classList.add("old-windows-ie")), p.A.bb10 && e.classList.add("bb10"), d.A.isOldAndroidWebkit() && e.classList.add("old-android-webkit"), d.A.isDesktop && (e.classList.add("desktop"), h.A.hit(), h.A.isActive() && e.classList.add("top-tabbar")), (0, l.Ts)(), (0, f.Ts)()
                    }
                    return function() {
                        n && (n.removeChild((0, v.A)()), n.removeChild((0, b.j)()), n.removeChild((0, m.A)()))
                    }
                }), [t]), {
                    onTouchStart: (0, u.useCallback)((function(t) {
                        var e = null == t.target.closest ? void 0 : t.target.closest("." + g);
                        e && e.classList.add(A)
                    }), []),
                    onTouchEnd: (0, u.useCallback)((function(t) {
                        var e = null == t.target.closest ? void 0 : t.target.closest("." + g);
                        e && e.classList.remove(A)
                    }), [])
                }
            }
            n(62062), n(72712), n(10287), n(81454), n(8872), n(41795);
            var O = n(73090),
                E = n(65297),
                j = n(53010),
                x = n(69110),
                S = n(13927),
                P = n(49952),
                _ = n(74848);

            function N(t, e) {
                return N = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                    return t.__proto__ = e, t
                }, N(t, e)
            }

            function T() {
                o.A.document.getElementById("splash-screen") ? E.A.once("splash-screen-removed", (function() {
                    setTimeout((function() {
                        j.A.render()
                    }), 0)
                })) : j.A.render()
            }

            function C() {
                if (j.A.isEnabled()) return j.A.create(j.A.placements.TABBAR)
            }
            var w = function(t) {
                    function e(e) {
                        var n;
                        return (n = t.call(this, e) || this).state = {}, n.updateAdSlot = n.updateAdSlot.bind(n), n.onPageView = n.onPageView.bind(n), n
                    }
                    var n, i;
                    i = t, (n = e).prototype = Object.create(i.prototype), n.prototype.constructor = n, N(n, i);
                    var o = e.prototype;
                    return o.componentDidMount = function() {
                        this.updateAdSlot(), j.A.enabledChangeEvent.subscribe(this.updateAdSlot), P.nJ.subscribe(this.onPageView)
                    }, o.componentWillUnmount = function() {
                        j.A.enabledChangeEvent.unsubscribe(this.updateAdSlot), P.nJ.unsubscribe(this.onPageView)
                    }, o.render = function() {
                        return this.state.adSlot && S.A.isVisible() ? (0, _.jsx)("div", {
                            className: "tabbar-container__banner",
                            children: (0, _.jsx)(x.A, {
                                adSlot: this.state.adSlot,
                                dataQa: "tabbar",
                                innerRef: T
                            })
                        }) : null
                    }, o.updateAdSlot = function() {
                        this.setState({
                            adSlot: C()
                        }), this.lastRefreshTimestamp = Date.now()
                    }, o.onPageView = function() {
                        var t = Date.now();
                        !S.A.isVisible() || !this.state.adSlot || this.lastRefreshTimestamp + 2e4 > t || (j.A.refresh(j.A.placements.TABBAR), this.lastRefreshTimestamp = t)
                    }, e
                }(u.Component),
                k = n(72537),
                L = n(78029),
                I = n(58385),
                D = n(79860),
                R = n(97547),
                M = n(46942),
                V = n.n(M),
                B = n(45869);
            var U = ({
                    children: t,
                    isActive: e,
                    notification: n,
                    onClick: i,
                    label: o,
                    a11y: r,
                    dataQA: a
                }) => {
                    const s = V()({
                            "csms-tabbar__media": !0,
                            "csms-tabbar__media--is-active": e
                        }),
                        c = V()({
                            "csms-tabbar__label": !0,
                            "csms-tabbar__label--is-active": e,
                            "csms-text-ellipsis": e
                        });
                    return (0, _.jsxs)("button", {
                        className: "csms-tabbar__item",
                        onClick: i,
                        "aria-current": e,
                        "aria-hidden": r ? .ariaHidden,
                        tabIndex: r ? .ariaHidden ? -1 : void 0,
                        type: "button",
                        ...a,
                        children: [(0, _.jsxs)("span", {
                            className: s,
                            children: [t, n ? (0, _.jsx)("span", {
                                className: "csms-tabbar__notification",
                                children: (0, _.jsx)(B.A, { ...n,
                                    a11y: {
                                        label: r ? .notificationLabel
                                    }
                                })
                            }) : null]
                        }), (0, _.jsx)("span", {
                            className: c,
                            children: o
                        })]
                    })
                },
                H = n(8483),
                G = n(74389);

            function F(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function q(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? F(Object(n), !0).forEach((function(e) {
                        W(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : F(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function W(t, e, n) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != typeof t || !t) return t;
                        var n = t[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(t, e || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == typeof e ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }

            function K(t, e) {
                return K = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                    return t.__proto__ = e, t
                }, K(t, e)
            }
            var Y = function(t) {
                    function e(e) {
                        var n;
                        return (n = t.call(this, e) || this).state = {
                            animation: {
                                timestamp: 0,
                                notification: "hidden",
                                counter: "hidden"
                            },
                            enabled: !e.featureType || (k.A.getSync(e.featureType).enabled || !1),
                            active: e.target === I.A.getLocation().routeName
                        }, n.onClick = n.onClick.bind(n), n.onNavigation = n.onNavigation.bind(n), n
                    }
                    var n, i;
                    i = t, (n = e).prototype = Object.create(i.prototype), n.prototype.constructor = n, K(n, i);
                    var r = e.prototype;
                    return r.componentDidMount = function() {
                        var t = this,
                            e = this.props.featureType;
                        e && (this.featureObserver = L.Ay.observe(k.A.getObservable(e), (function() {
                            t.setState({
                                enabled: k.A.getSync(e).enabled || !1
                            })
                        }), {
                            leading: !1
                        })), I.A.navigationEvent.subscribe(this.onNavigation)
                    }, r.componentWillUnmount = function() {
                        this.featureObserver && this.featureObserver.stop(), clearTimeout(this.simpleAnimationTimeout), I.A.navigationEvent.unsubscribe(this.onNavigation)
                    }, r.componentDidUpdate = function(t) {
                        t.counter !== this.props.counter ? this.runAnimation(this.props.counter > t.counter) : t.notification !== this.props.notification && this.notify()
                    }, r.render = function() {
                        return this.state.enabled ? (0, _.jsx)(U, {
                            dataQA: {
                                "data-qa": this.props.id
                            },
                            onClick: this.onClick,
                            isActive: this.state.active,
                            notification: this.getNotification(),
                            label: this.props.label,
                            children: (0, _.jsx)(H.A, {
                                name: "tabbar-" + this.props.id
                            })
                        }) : null
                    }, r.notify = function() {
                        var t = this,
                            e = this.props.notification;
                        if (!(this.state.animation.timestamp > Date.now())) {
                            var n = Date.now() + 900;
                            this.setState({
                                animation: {
                                    timestamp: n,
                                    notification: e ? "visible" : "hidden",
                                    counter: this.state.animation.counter
                                }
                            }), e > 0 && !this.state.active && o.A.requestAnimationFrame((function() {
                                o.A.requestAnimationFrame((function() {
                                    t.setState({
                                        animation: {
                                            timestamp: n,
                                            notification: "bouncing",
                                            counter: t.state.animation.counter
                                        }
                                    })
                                }))
                            }))
                        }
                    }, r.runAnimation = function(t) {
                        var e = this,
                            n = this.props,
                            i = n.notification,
                            r = n.counter;
                        if (!(this.state.animation.timestamp > Date.now())) {
                            var a = {
                                timestamp: Date.now() + 3e3
                            };
                            a.notification = i || r ? "visible" : "hidden", a.counter = "hidden", t && !this.state.active && (d.A.isOldSamsungBrowser() ? a.counter = "visible" : a.counter = "popout", this.setState({
                                animation: {
                                    timestamp: a.timestamp,
                                    counter: "hidden",
                                    notification: a.notification
                                }
                            })), o.A.requestAnimationFrame((function() {
                                o.A.requestAnimationFrame((function() {
                                    e.setState({
                                        animation: a
                                    }), "visible" === a.counter && e.scheduleSimpleAnimation()
                                }))
                            }))
                        }
                    }, r.scheduleSimpleAnimation = function() {
                        var t = this;
                        clearTimeout(this.simpleAnimationTimeout), this.simpleAnimationTimeout = setTimeout((function() {
                            t.setState((function(t) {
                                return {
                                    animation: q(q({}, t.animation), {}, {
                                        counter: "hidden"
                                    })
                                }
                            }))
                        }), 2500)
                    }, r.getNotification = function() {
                        var t = this.props,
                            e = t.counter,
                            n = t.notification,
                            i = t.isCounterVisible;
                        if (void 0 !== n || void 0 !== e) {
                            var o = this.state.animation,
                                r = e ? o.counter : "hidden";
                            return i && this.state.active && (r = "visible"), {
                                color: "status-notification",
                                status: n || e ? o.notification : "hidden",
                                counterStatus: r,
                                counterText: e > 99 ? "99+" : String(e)
                            }
                        }
                    }, r.onClick = function() {
                        var t = I.A.getLocation().routeName;
                        this.props.hotPanelElement && ((0, D.sx)(332, {
                            element: this.props.hotPanelElement,
                            parent_element: 60
                        }), (0, D.sx)(333, {
                            element: this.props.hotPanelElement,
                            attention: Boolean(this.props.notification > 0 || this.props.counter > 0),
                            active: this.state.active
                        })), this.props.target !== G.x.PEOPLE_NEARBY || t !== G.x.PEOPLE_NEARBY ? I.A.navigate(this.props.target) : (0, R.V)(o.A, 0, !0)
                    }, r.onNavigation = function() {
                        this.setState({
                            active: this.props.target === I.A.getLocation().routeName
                        })
                    }, e
                }(u.Component),
                Q = (n(16034), n(30397)),
                z = n(20816),
                J = n(75248),
                $ = n(73155),
                X = n(40075);

            function Z(t, e) {
                return Z = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                    return t.__proto__ = e, t
                }, Z(t, e)
            }
            var tt = function(t) {
                    function e(e) {
                        var n;
                        return (n = t.call(this, e) || this).state = {
                            totalNotifications: 0,
                            unreadMessages: 0
                        }, n.fetchCounters = n.fetchCounters.bind(n), n.onChatMessage = n.onChatMessage.bind(n), n
                    }
                    var n, i;
                    i = t, (n = e).prototype = Object.create(i.prototype), n.prototype.constructor = n, Z(n, i);
                    var o = e.prototype;
                    return o.componentDidMount = function() {
                        z.A.on(z.A.EVENTS.CHANGE, this.fetchCounters), Q.A.on(Q.A.ACTIONS.WAKE_UP, this.fetchCounters), I.A.navigationEvent.subscribe(this.fetchCounters), J.A.getInstance().on(J.A.Type.CHAT_MESSAGE, this.onChatMessage)
                    }, o.componentWillUnmount = function() {
                        clearTimeout(this.fetchDebounceTimeout), z.A.off(z.A.EVENTS.CHANGE, this.fetchCounters), Q.A.off(Q.A.ACTIONS.WAKE_UP, this.fetchCounters), I.A.navigationEvent.unsubscribe(this.fetchCounters), J.A.getInstance().off(J.A.Type.CHAT_MESSAGE, this.onChatMessage)
                    }, o.render = function() {
                        return (0, _.jsx)(Y, {
                            id: this.props.id,
                            name: this.props.Localization.get(484),
                            featureType: 163,
                            target: "connections",
                            hotPanelElement: 59,
                            notification: this.state.totalNotifications,
                            counter: this.state.unreadMessages,
                            label: X.Ay.get(1029)
                        })
                    }, o.fetchCounters = function() {
                        var t = this;
                        clearTimeout(this.fetchDebounceTimeout), this.fetchDebounceTimeout = setTimeout((function() {
                            z.A.get().then((function(e) {
                                if (e) {
                                    var n = e.values;
                                    t.setState({
                                        totalNotifications: Object.values(n).reduce((function(t, e) {
                                            return t += e
                                        }), 0),
                                        unreadMessages: n[0]
                                    })
                                }
                            }))
                        }), 100)
                    }, o.onChatMessage = function(t) {
                        this.setState({
                            unreadMessages: t.total_unread || 0
                        })
                    }, e
                }(u.Component),
                et = (0, $.gj)(tt),
                nt = function() {
                    var t = (0, u.useState)(0),
                        e = t[0],
                        n = t[1];
                    return (0, u.useEffect)((function() {
                        function t(t) {
                            6 === t.folder && n(t.int_value || 0)
                        }
                        return z.A.get().then((function(t) {
                                var e = null == t ? void 0 : t.values;
                                e && n(e[6] || 0)
                            })), z.A.on(z.A.EVENTS.CHANGE, t),
                            function() {
                                z.A.off(z.A.EVENTS.CHANGE, t)
                            }
                    }), []), (0, _.jsx)(Y, {
                        id: "liked-you",
                        target: G.x.LIKED_YOU,
                        hotPanelElement: 5,
                        counter: e,
                        isCounterVisible: !0,
                        label: X.Ay.get(1031)
                    }, "liked-you")
                };
            var it = ({
                    children: t,
                    a11y: e
                }) => (0, _.jsx)("nav", {
                    className: "csms-tabbar",
                    "aria-label": e ? .label,
                    children: t
                }),
                ot = n(62721),
                rt = n(87351);

            function at(t, e) {
                return at = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                    return t.__proto__ = e, t
                }, at(t, e)
            }
            var st = ["people-nearby", "encounters", "liked-you", "connections", "my-profile"],
                ct = ["connections", "people-nearby", "liked-you", "encounters", "my-profile"];

            function ut(t) {
                var e = t.isMale,
                    n = t.children,
                    i = u.Children.toArray(n).reduce((function(t, e) {
                        return t[e.props.id] = e, t
                    }), {});
                return (0, _.jsx)(it, {
                    children: (e ? st : ct).map((function(t) {
                        return i[t]
                    }))
                })
            }
            var lt = function(t) {
                    function e(e) {
                        var n;
                        return (n = t.call(this, e) || this).state = {
                            ready: !1
                        }, n
                    }
                    var n, i;
                    i = t, (n = e).prototype = Object.create(i.prototype), n.prototype.constructor = n, at(n, i);
                    var o = e.prototype;
                    return o.componentDidMount = function() {
                        var t = this;
                        this.loginObserver_ = O.A.getLoginObserver((function(e) {
                            var n = e.isAuthenticated,
                                i = O.A.getUser();
                            t.setState({
                                ready: t.state.ready || n,
                                sexType: null == i ? void 0 : i.gender
                            }), rt.A.hit()
                        }))
                    }, o.componentWillUnmount = function() {
                        this.loginObserver_.stop()
                    }, o.render = function() {
                        if (!this.state.ready) return null;
                        var t = 1 === this.state.sexType;
                        return (0, _.jsxs)("div", {
                            className: "tabbar-container",
                            id: "tabbar",
                            children: [d.A.isDesktop && h.A.isActive() ? (0, _.jsx)("div", {
                                className: "tabbar-container__logo",
                                children: (0, _.jsx)(ot.A, {
                                    name: "logo-boxed"
                                })
                            }) : null, (0, _.jsxs)(ut, {
                                isMale: t,
                                children: [(0, _.jsx)(Y, {
                                    id: "people-nearby",
                                    featureType: 10,
                                    target: G.x.PEOPLE_NEARBY,
                                    hotPanelElement: 56,
                                    label: X.Ay.get(1033)
                                }, "people-nearby"), (0, _.jsx)(Y, {
                                    id: "encounters",
                                    featureType: 11,
                                    target: G.x.ENCOUNTERS,
                                    hotPanelElement: 57,
                                    label: X.Ay.get(1030)
                                }, "encounters"), rt.A.isActive() ? (0, _.jsx)(nt, {
                                    id: "liked-you"
                                }, "liked-you") : null, (0, _.jsx)(et, {
                                    id: "connections"
                                }, "connections"), (0, _.jsx)(Y, {
                                    id: "my-profile",
                                    target: G.x.OWN_PROFILE,
                                    hotPanelElement: 58,
                                    label: X.Ay.get(1032)
                                }, "my-profile")]
                            }), h.A.isActive() ? null : (0, _.jsx)(w, {})]
                        })
                    }, e
                }(u.Component),
                ft = "js-fullscreen",
                pt = function(t) {
                    var e = t.children,
                        n = t.appRef,
                        i = t.inAppNotificationsContainerRef,
                        o = y(n),
                        r = o.onTouchStart,
                        a = o.onTouchEnd;
                    return (0, _.jsxs)("div", {
                        className: "app-view",
                        ref: n,
                        onTouchStart: r,
                        onTouchEnd: a,
                        children: [e, (0, _.jsx)("div", {
                            className: "inapp-notification-container",
                            ref: i,
                            id: "inapp-notification-container",
                            role: "alert",
                            "aria-live": "polite"
                        }), (0, _.jsx)("div", {
                            id: ft,
                            className: ft + " is-hidden"
                        }), (0, _.jsx)(lt, {}), h.A.isActive() ? (0, _.jsx)(w, {}) : null]
                    })
                },
                dt = n(71363),
                ht = (n(69085), n(42302)),
                vt = n(85208),
                mt = n(52453),
                bt = n(48164),
                gt = n(79886);
            var At = n(1168),
                yt = n(28431),
                Ot = n(45897);

            function Et(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function jt(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? Et(Object(n), !0).forEach((function(e) {
                        xt(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : Et(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function xt(t, e, n) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != typeof t || !t) return t;
                        var n = t[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(t, e || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == typeof e ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }
            var St = r.A.getLogger("BrowserRouter");

            function Pt(t) {
                var e = t.config,
                    n = t.navigation,
                    i = t.navigationIdRef,
                    r = t.navigator,
                    a = t.pageLoadStartRef,
                    s = t.setRouterState,
                    c = t.router,
                    u = t.Session;
                if (!At.A.handleNavigation(n)) {
                    var l = c.getRoute(n.routeName);
                    if (l || St.error("No route found for " + n.routeName), !l || function(t, e, n, i) {
                            if (t.requiresAuthentication && !e) {
                                var o = i.getLocation().routeName !== G.x.LANDING ? i.getUrl() : void 0;
                                return void i.navigate(G.x.LANDING, !0, {
                                    forward: o
                                })
                            }
                            if (t.requiresAnonymous && e) return void i.navigate(n.get(dt.O.DEFAULT_AUTHENTICATED_PAGE), !0);
                            return !0
                        }(l, u.isLoggedIn(), e, r)) {
                        i.current++, a.current = Date.now();
                        var f = i.current;
                        c.resolveController(n.routeName, n.parameters).then((function(t) {
                            var e = function(t) {
                                var e = t.Controller,
                                    n = {
                                        routeName: t.name
                                    },
                                    i = (0, gt.A)(t.name);
                                if (i && Object.assign(n, {
                                        clientSource: i
                                    }), t.config && Object.assign(n, t.config), (0, mt.CS)(e)) return (0, _.jsx)(e, {
                                    config: n,
                                    parameters: {},
                                    navigatedBack: !1,
                                    transitionStatus: bt.A.EXITED,
                                    saveScrollPosition: ht.A
                                });
                                t.controllerInstance || (t.controllerInstance = new e({}));
                                var o = t.controllerInstance;
                                return (0, vt.A)(o, n), o
                            }(t);
                            i.current === f && s((function(t) {
                                return jt(jt({}, t), {}, {
                                    pageController: e,
                                    navigation: n
                                })
                            }))
                        }), (function(e) {
                            throw i.current === f && yt.A.handleError({
                                error: e
                            }, (function() {
                                return Pt(t)
                            })), e
                        })).catch(o.A.trackDynamicImportError)
                    }
                }
            }
            var _t = function(t) {
                    var e = t.children,
                        n = t.config,
                        i = t.navigator,
                        o = t.pageLoadStartRef,
                        r = t.router,
                        a = t.Session,
                        s = (0, u.useState)({}),
                        c = s[0],
                        l = c.pageController,
                        f = c.navigation,
                        p = s[1],
                        d = (0, u.useRef)(0);
                    return (0, u.useEffect)((function() {
                        var t = function(t) {
                            return Pt({
                                config: n,
                                navigation: t,
                                navigationIdRef: d,
                                navigator: i,
                                pageLoadStartRef: o,
                                router: r,
                                setRouterState: p,
                                Session: a
                            })
                        };
                        return i.navigationEvent.subscribe(t),
                            function() {
                                i.navigationEvent.unsubscribe(t)
                            }
                    }), [a, n, i, o, r]), (0, u.useEffect)((function() {
                        i.start(), At.A.start()
                    }), [i]), (0, u.useEffect)((function() {
                        var t = function(t) {
                            var e = t.pageController,
                                n = t.params,
                                o = {
                                    routeName: i.getUrl() + "-LEGACY_OPEN_PAGE",
                                    back: !1,
                                    browserNavigation: !1,
                                    parameters: n
                                };
                            if (!At.A.handleNavigation(o)) {
                                var r;
                                if ((0, mt.n9)(e)) {
                                    var a = e.constructor;
                                    r = (0, _.jsx)(a, jt({}, e.props))
                                } else r = e;
                                p((function(t) {
                                    return jt(jt({}, t), {}, {
                                        pageController: r,
                                        navigation: o
                                    })
                                }))
                            }
                        };
                        return E.A.on(E.A.LEGACY_OPEN_PAGE, t),
                            function() {
                                E.A.off(E.A.LEGACY_OPEN_PAGE, t)
                            }
                    }), [i]), (0, _.jsx)(Ot.pg, {
                        value: {
                            router: r,
                            pageController: l,
                            navigation: f
                        },
                        children: e
                    })
                },
                Nt = n(5586),
                Tt = n(20679),
                Ct = n(4172),
                wt = (n(25276), n(66644)),
                kt = [G.x.COOKIE_POLICY, G.x.HELP, G.x.SETTINGS_HELP_QUESTION, G.x.TERMS, G.x.PRIVACY, G.x.SAFETY],
                Lt = function(t) {
                    var e = (0, u.useState)(),
                        n = e[0],
                        i = e[1],
                        r = (0, wt.cq)(),
                        a = r && -1 === kt.indexOf(r.routeName);
                    return (0, u.useEffect)((function() {
                        null == o.A.__tcfapi || o.A.__tcfapi("addEventListener", 2, (function(t) {
                            i(t.gdprApplies)
                        }))
                    }), []), a && !1 === n ? (0, _.jsx)(u.Fragment, {
                        children: t.children
                    }) : null
                },
                It = (n(60739), n(33110), n(20017)),
                Dt = n(93827),
                Rt = function(t) {
                    var e = t.title,
                        n = t.text,
                        i = t.cookiePolicyLink,
                        o = t.acceptText,
                        r = t.settingsText,
                        a = t.onSettingsClick,
                        s = t.onAcceptClick;
                    return (0, _.jsxs)("div", {
                        className: "cookie-notification",
                        children: [(0, _.jsxs)("div", {
                            className: "cookie-notification__content",
                            children: [(0, _.jsx)("div", {
                                className: "cookie-notification__title",
                                children: (0, _.jsx)(Dt.hE, {
                                    children: e
                                })
                            }), (0, _.jsx)("div", {
                                className: "cookie-notification__text",
                                children: (0, _.jsx)(Dt.P2, {
                                    color: "gray-80",
                                    dangerous: !0,
                                    children: n
                                })
                            })]
                        }), (0, _.jsxs)("div", {
                            className: "cookie-notification__actions cookie-notification__actions--medium",
                            children: [(0, _.jsx)("div", {
                                className: "cookie-notification__action",
                                children: (0, _.jsx)(It.A, {
                                    text: r,
                                    onClick: a,
                                    semantic: "tertiary",
                                    tag: "a",
                                    linkAttrs: {
                                        href: i
                                    }
                                })
                            }), (0, _.jsx)("div", {
                                className: "cookie-notification__action",
                                children: (0, _.jsx)(It.A, {
                                    text: o,
                                    onClick: s
                                })
                            })]
                        }), (0, _.jsxs)("div", {
                            className: "cookie-notification__actions cookie-notification__actions--small",
                            children: [(0, _.jsx)("div", {
                                className: "cookie-notification__action",
                                children: (0, _.jsx)(It.A, {
                                    size: "small",
                                    text: r,
                                    onClick: a,
                                    semantic: "tertiary",
                                    tag: "a",
                                    linkAttrs: {
                                        href: i
                                    }
                                })
                            }), (0, _.jsx)("div", {
                                className: "cookie-notification__action",
                                children: (0, _.jsx)(It.A, {
                                    size: "small",
                                    text: o,
                                    onClick: s
                                })
                            })]
                        })]
                    })
                },
                Mt = n(17369),
                Vt = n(80725);
            var Bt = function(t) {
                    var e = (0, $.B2)(),
                        n = (0, u.useRef)(!1),
                        i = (0, u.useState)(t.cookieSettings),
                        o = i[0],
                        r = i[1];
                    if ((0, u.useEffect)((function() {
                            r(Mt.Ay.cookieSettings())
                        }), []), (0, u.useEffect)((function() {
                            var t = function() {
                                r(Mt.Ay.cookieSettings())
                            };
                            return Q.A.on(Q.A.ACTIONS.WAKE_UP, t),
                                function() {
                                    Q.A.off(Q.A.ACTIONS.WAKE_UP, t)
                                }
                        }), [r]), (0, u.useLayoutEffect)((function() {
                            n.current || o || (n.current = !0, (0, D.sx)(258, {
                                element: 694
                            }))
                        }), [n, o]), o) return null;
                    var a = e.get(45);
                    return a = a.replace(/<a p\d>/, '<a href="' + t.cookiePolicyLink + '" target="_blank">'), (0, _.jsx)("div", {
                        className: "cookie-notification-container",
                        children: (0, _.jsx)(Rt, {
                            title: e.get(47),
                            text: a,
                            cookiePolicyLink: t.cookiePolicyLink,
                            acceptText: e.get(44),
                            settingsText: e.get(46),
                            onSettingsClick: function() {
                                (0, D.sx)(332, {
                                    element: 128,
                                    parent_element: 694
                                })
                            },
                            onAcceptClick: function() {
                                var t, e = new Date;
                                e.setTime(Number(new Date) + 31536e7), Mt.Ay.set(Vt.Z.COOKIE_SETTINGS, JSON.stringify(((t = {})[Mt.AF] = !0, t[Mt.rO] = !0, t)), {
                                    expires: e
                                }), r(Mt.Ay.cookieSettings()), (0, D.sx)(332, {
                                    element: 855,
                                    parent_element: 694
                                })
                            }
                        })
                    })
                },
                Ut = n(56368);

            function Ht(t, e) {
                return Ht = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                    return t.__proto__ = e, t
                }, Ht(t, e)
            }
            var Gt, Ft, qt = function(t) {
                    function e() {
                        for (var e, n = arguments.length, i = new Array(n), o = 0; o < n; o++) i[o] = arguments[o];
                        return (e = t.call.apply(t, [this].concat(i)) || this).inited = !1, e.onboardingTipsController_ = Ut.A.getInstance(), e
                    }
                    var n, i;
                    i = t, (n = e).prototype = Object.create(i.prototype), n.prototype.constructor = n, Ht(n, i);
                    var o = e.prototype;
                    return o.componentDidUpdate = function() {
                        this.inited ? this.onboardingTipsController_.triggerUpdateView(1) : (this.onboardingTipsController_.start(), this.inited = !0)
                    }, o.render = function() {
                        return this.props.children
                    }, e
                }(u.Component),
                Wt = qt,
                Kt = (n(74423), n(23715)),
                Yt = n(73939);
            ! function(t) {
                t.TOP = "TOP", t.BOTTOM = "BOTTOM"
            }(Gt || (Gt = {})),
            function(t) {
                t.IDLE = "IDLE", t.VISIBLE = "VISIBLE"
            }(Ft || (Ft = {}));
            var Qt = {
                    TOP: "network-status--placement-top",
                    BOTTOM: "network-status--placement-bottom"
                },
                zt = {
                    IDLE: "is-idle",
                    VISIBLE: "is-visible"
                },
                Jt = function(t) {
                    var e, n = t.text,
                        i = t.placement,
                        o = t.animationStatus,
                        r = void 0 === o ? Ft.VISIBLE : o,
                        a = V()("network-status", ((e = {})[Qt[i]] = i, e[zt[r]] = r, e));
                    return (0, _.jsx)("div", {
                        className: a,
                        children: (0, _.jsx)(Yt.A, {
                            text: n
                        })
                    })
                };

            function $t(t, e) {
                return $t = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                    return t.__proto__ = e, t
                }, $t(t, e)
            }
            var Xt = [243, 20],
                Zt = function(t) {
                    function e(e) {
                        var n;
                        return (n = t.call(this, e) || this).state = {
                            isOnline: !0
                        }, n
                    }
                    var n, i;
                    i = t, (n = e).prototype = Object.create(i.prototype), n.prototype.constructor = n, $t(n, i);
                    var o = e.prototype;
                    return o.componentDidMount = function() {
                        Kt.A.on(Kt.A.EVENTS.ONLINE, this.toggleContainer, this), Kt.A.on(Kt.A.EVENTS.OFFLINE, this.toggleContainer, this)
                    }, o.componentWillUnmount = function() {
                        Kt.A.off(Kt.A.EVENTS.ONLINE, this.toggleContainer, this), Kt.A.off(Kt.A.EVENTS.OFFLINE, this.toggleContainer, this)
                    }, o.render = function() {
                        return this.hasBanner() ? (0, _.jsx)(Jt, {
                            text: X.Ay.get(646),
                            placement: S.A.isVisible() ? Gt.BOTTOM : Gt.TOP
                        }) : null
                    }, o.toggleContainer = function() {
                        this.setState({
                            isOnline: Kt.A.isOnline()
                        })
                    }, o.hasBanner = function() {
                        var t = this.props.controllerInstance,
                            e = null == t ? void 0 : t.screenName;
                        return e && Xt.includes(e) && !this.state.isOnline
                    }, e
                }(u.Component),
                te = n(77409),
                ee = n(59977),
                ne = n(23318);

            function ie(t, e) {
                var n, i, o = null == e || null == (n = e.body) ? void 0 : n.find((function(t) {
                    return 379 === t.message_type
                }));
                return null == o || null == (i = o.client_common_settings) || null == (i = i.dev_features) ? void 0 : i.find((function(e) {
                    return e.id === t
                }))
            }
            var oe = n(76598);

            function re(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function ae(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? re(Object(n), !0).forEach((function(e) {
                        se(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : re(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function se(t, e, n) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != typeof t || !t) return t;
                        var n = t[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(t, e || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == typeof e ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }
            var ce = (0, u.lazy)((function() {
                return Promise.all([n.e(5235), n.e(2065), n.e(7967), n.e(8925), n.e(1052), n.e(8556), n.e(1087), n.e(387), n.e(9904), n.e(7397), n.e(8819), n.e(8651), n.e(9232), n.e(3700), n.e(1218), n.e(1588), n.e(1379), n.e(7799)]).then(n.bind(n, 49469))
            }));

            function ue(t) {
                var e, n, i = null == t || null == (e = t.body) ? void 0 : e.find((function(t) {
                    return 379 === t.message_type
                }));
                return n = null == i ? void 0 : i.client_common_settings, (0, ne.A)(n, 41) || "/" + G.x.COOKIE_POLICY
            }

            function le(t, e) {
                return ae(ae({}, t), e)
            }
            var fe = function(t) {
                    var e = t.startupResult,
                        n = t.appRef,
                        i = (0, u.useContext)(te.Ay),
                        o = i.Session,
                        r = i.config,
                        a = (0, u.useReducer)(le, {
                            pageControllerLoaded: !1
                        }),
                        s = a[0],
                        c = s.controllerInstance,
                        l = s.pageControllerLoaded,
                        f = a[1],
                        p = (0, u.useRef)(null),
                        d = (0, u.useRef)(0),
                        h = (0, oe.a)();
                    h && I.A.navigate(G.x.APP_BLOCKED), (0, u.useEffect)((function() {
                        !c || l || h || (f({
                            pageControllerLoaded: !0
                        }), Tt.A.getInstance().trackMeaningfulPaint())
                    }), [c, l, h]);
                    var v = (0, u.useCallback)((function(t) {
                            f({
                                controllerInstance: t
                            })
                        }), []),
                        m = (0, u.useMemo)((function() {
                            return [ie(ee.v.NEW_COOKIES_CONSENT, e), ue(e)]
                        }), [e]),
                        b = m[0],
                        g = m[1];
                    return (0, _.jsx)(_t, {
                        config: r,
                        navigator: I.A,
                        router: Nt.A,
                        pageLoadStartRef: d,
                        Session: o,
                        children: (0, _.jsx)(Wt, {
                            children: (0, _.jsxs)(pt, {
                                appRef: n,
                                inAppNotificationsContainerRef: p,
                                children: [l ? (0, _.jsx)(u.Suspense, {
                                    fallback: null,
                                    children: (0, _.jsx)(ce, {
                                        startupResult: e,
                                        inAppNotificationsContainerRef: p,
                                        controllerInstance: c,
                                        navigator: I.A
                                    })
                                }) : null, (0, _.jsx)(Ct.A, {
                                    onControllerInstance: v,
                                    pageLoadStartRef: d
                                }), null != b && b.enabled ? (0, _.jsx)(Lt, {
                                    children: (0, _.jsx)(Bt, {
                                        cookiePolicyLink: g
                                    })
                                }) : null, (0, _.jsx)(Zt, {
                                    controllerInstance: c
                                })]
                            })
                        })
                    })
                },
                pe = n(3508),
                de = n(4553),
                he = n(45016),
                ve = n(18483),
                me = n(40223),
                be = n(46763),
                ge = function(t) {
                    var e = t.Localization,
                        n = t.cosmosContextValue,
                        i = (0, u.useCallback)((function() {
                            (0, D.sx)(332, {
                                element: 64,
                                parent_element: 72
                            }), o.A.location.reload()
                        }), []);
                    return (0, u.useEffect)((function() {
                        (0, D.sx)(49, {
                            screen_name: 270
                        })
                    }), []), (0, _.jsx)(me.Kq, {
                        value: n,
                        children: (0, _.jsx)($.G4, {
                            instance: e,
                            children: (0, _.jsx)(be.A, {
                                data: {
                                    isOffline: !Kt.A.isOnline()
                                },
                                onRefresh: i
                            })
                        })
                    })
                };

            function Ae(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function ye(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? Ae(Object(n), !0).forEach((function(e) {
                        Oe(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : Ae(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function Oe(t, e, n) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != typeof t || !t) return t;
                        var n = t[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(t, e || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == typeof e ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }
            var Ee = r.A.getLogger("ReactComponentWrapper"),
                je = function(t) {
                    var e = t.startupResult,
                        n = he.Ay.getValue(),
                        i = (0, u.useRef)(null),
                        o = {
                            Session: O.A,
                            config: pe.A,
                            cookies: {},
                            device: (0, de.N)(),
                            interfaceLanguage: ve.A,
                            queryParams: {},
                            appRef: i
                        };
                    return (0, _.jsx)(c.A, ye(ye({}, ye({
                        logError: function(t) {
                            for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), i = 1; i < e; i++) n[i - 1] = arguments[i];
                            Ee.error.apply(Ee, [t].concat(n))
                        },
                        Localization: X.Ay,
                        cosmosContextValue: n,
                        errorFallback: (0, _.jsx)(ge, {
                            cosmosContextValue: n,
                            Localization: X.Ay
                        })
                    }, o)), {}, {
                        children: (0, _.jsx)(fe, {
                            startupResult: e,
                            appRef: i
                        })
                    }))
                },
                xe = n(31709),
                Se = function() {
                    function t(t) {
                        this.system = void 0, this.system = t, this.handleMessage = this.handleMessage.bind(this)
                    }
                    var e = t.prototype;
                    return e.init = function() {
                        this.subscribeToPostMessages(), this.sendMessage({
                            mw: !0,
                            action: "ready"
                        })
                    }, e.subscribeToPostMessages = function() {
                        this.system.onmessage = this.handleMessage.bind(this)
                    }, e.unsubscribeToPostMessages = function() {
                        this.sendMessage({
                            mw: !0,
                            action: "disconnect"
                        }), this.system.onmessage = void 0
                    }, e.handleMessage = function(t) {
                        try {
                            var e = JSON.parse(t);
                            null != e && e.hwqa && e.pushToken && (n = e.pushToken, new xe.Ay(199, {
                                device_regid: n
                            }).onResponse(387, (function() {})).request())
                        } catch (e) {
                            r.A.getLogger("HostingAppCommunicator").error("Error parsing the message", {
                                message: t
                            })
                        }
                        var n
                    }, e.sendMessage = function(t) {
                        this.system.postMessage(JSON.stringify(t))
                    }, t
                }();
            var Pe = function() {
                (0, oe.a)() && o.A.system && new Se(o.A.system).init()
            };

            function _e(t, e) {
                return X.Ay.setCommonWords(e.common), e.lexemes && X.Ay.setEntries(e.lexemes), s("css-load-test-element", 43).then((function() {
                    (0, i.render)((0, _.jsx)(je, {
                        startupResult: t.startupResult || {}
                    }), o.A.document.getElementById("app-root")), Pe()
                }))
            }
        },
        46163: function(t, e, n) {
            var i, o = n(99417);
            e.A = function() {
                return i || ((i = o.A.document.createElement("div")).className = "filters-container"), i
            }
        },
        61806: function(t, e, n) {
            var i = n(46518),
                o = n(28551),
                r = n(72652),
                a = n(1767),
                s = [].push;
            i({
                target: "Iterator",
                proto: !0,
                real: !0
            }, {
                toArray: function() {
                    var t = [];
                    return r(a(o(this)), s, {
                        that: t,
                        IS_RECORD: !0
                    }), t
                }
            })
        },
        69110: function(t, e, n) {
            n(52675), n(45700), n(2008), n(51629), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(3949), n(23500);
            var i = n(96540),
                o = n(65297),
                r = n(23336),
                a = n(74848);

            function s(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function c(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? s(Object(n), !0).forEach((function(e) {
                        u(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function u(t, e, n) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != typeof t || !t) return t;
                        var n = t[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(t, e || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == typeof e ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }
            e.A = function(t) {
                var e = (0, i.useState)(!1),
                    n = e[0],
                    s = e[1];

                function u() {
                    s(!0)
                }

                function l() {
                    s(!1)
                }
                return (0, i.useEffect)((function() {
                    return o.A.on(o.A.SHOW_MODAL, u), o.A.on(o.A.HIDE_MODAL, l),
                        function() {
                            o.A.off(o.A.SHOW_MODAL, u), o.A.off(o.A.HIDE_MODAL, l)
                        }
                }), []), (0, a.jsx)(r.A, c(c({}, t), {}, {
                    disabled: n
                }))
            }
        },
        73939: function(t, e, n) {
            var i = n(74848),
                o = n(46942),
                r = n.n(o),
                a = n(8483),
                s = n(93827);
            e.A = ({
                icon: t,
                text: e,
                color: n = "dark",
                onClick: o
            }) => {
                const c = r()({
                        "csms-snackpill": !0,
                        [`csms-snackpill--${n}`]: n
                    }),
                    u = o ? "button" : "div";
                return (0, i.jsxs)(u, {
                    className: c,
                    onClick: o,
                    type: "button" === u ? "button" : void 0,
                    children: [t ? (0, i.jsx)("span", {
                        className: "csms-snackpill__icon",
                        children: (0, i.jsx)(a.A, {
                            name: t
                        })
                    }) : null, (0, i.jsx)(s.P2, {
                        children: e
                    })]
                })
            }
        },
        97547: function(t, e, n) {
            n.d(e, {
                V: function() {
                    return r
                }
            });
            var i = n(99417);

            function o(t) {
                this.wrapper = t, this.reset()
            }

            function r(t, e, n) {
                try {
                    t.scrollTo({
                        behavior: n ? "smooth" : "instant",
                        top: e
                    })
                } catch (n) {
                    if (!(n instanceof TypeError)) throw n;
                    t && "function" == typeof t.scrollTo && t.scrollTo(0, e)
                }
            }

            function a(t) {
                return t.wrapper.scrollHeight - t.scrollBottom - i.A.innerHeight
            }
            o.prototype = {
                restore: function(t) {
                    this.scrollTop = t ? this.scrollTop : a(this), r(this.wrapper, this.scrollTop, !1)
                },
                prepare: function() {
                    this.scrollBottom = this.wrapper.scrollHeight - this.wrapper.scrollTop - i.A.innerHeight, this.scrollTop = a(this)
                },
                reset: function() {
                    this.scrollBottom = 0, this.scrollTop = a(this)
                },
                scrollIntoView: function(t, e, n) {
                    t && r(this.wrapper, t.offsetTop - (e || 0), n)
                },
                scrollToBottom: function(t) {
                    r(this.wrapper, this.wrapper.scrollHeight + this.wrapper.clientHeight, t)
                },
                scrollBy: function(t, e) {
                    r(this.wrapper, this.wrapper.scrollTop + t, e)
                },
                scrollTo: function(t, e) {
                    r(this.wrapper, t, e)
                }
            }, e.A = o
        }
    }
]);
//# sourceMappingURL=render.cdd3968cd1d34077a9e1.js.map
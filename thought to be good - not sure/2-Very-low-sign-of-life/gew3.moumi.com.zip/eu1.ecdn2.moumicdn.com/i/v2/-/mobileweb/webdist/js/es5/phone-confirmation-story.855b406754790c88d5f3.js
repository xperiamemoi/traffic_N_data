"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [1588, 9201], {
        1116: function(t, e, n) {
            n(50113), n(60739), n(33110), n(26099), n(16034), n(98992), n(72577);
            var i, o, r = n(23735),
                a = n(99417),
                s = n(58385),
                c = n(18084),
                u = n(74389),
                l = c.A.getLogger("SecurityCheck"),
                f = ((i = {})[1] = u.x.SECURITY_SOCIAL_NETWORK, i[2] = u.x.SECURITY_EMAIL, i[4] = u.x.SECURITY_PHONE_CALL, i[5] = u.x.SECURITY_SMS, i[6] = u.x.SECURITY_COMPLETE_PHONE, i[7] = u.x.SECURITY_COMPLETE_EMAIL, i),
                d = !1;

            function h(t, e) {
                t || (e instanceof Error ? l.error(e.message) : e && 51 === e.getType() && function() {
                    if (d) return;
                    d = !0, new r.Ay(523, null).on(r.Dl.ON_REQ_END, (function() {
                        d = !1
                    })).request()
                }())
            }

            function p(t, e) {
                if (t) l.error("Security check response error", JSON.stringify(t));
                else {
                    var n = e.toJSON ? e.toJSON() : e;
                    0 !== n.type ? o && Date.now() < o + 3e4 ? a.A.location.reload() : function(t) {
                        var e = f[t.type],
                            n = (i = s.A.getLocation(), Boolean(Object.values(f).find((function(t) {
                                return t === i.routeName
                            }))));
                        var i;
                        s.A.navigate(e, n, {
                            clientSecurityPage: t
                        })
                    }(n) : a.A.location.reload()
                }
            }
            e.A = {
                init: function() {
                    r.Kj.on(1, h), r.Kj.on(524, p)
                },
                notifySecurityCheckPassed: function() {
                    o = Date.now()
                },
                getRouteNameFromSecurityPage: function(t) {
                    return !!t && f[t.type]
                }
            }
        },
        7164: function(t, e, n) {
            var i = n(74848),
                o = n(32483);
            e.A = ({
                children: t,
                ...e
            }) => (0, i.jsx)("div", {
                className: "csms-form-hint",
                children: (0, i.jsx)(o.A, { ...e,
                    children: t
                })
            })
        },
        11734: function(t, e, n) {
            var i = n(74848),
                o = n(87908);
            e.A = ({
                children: t,
                hpadded: e,
                vpadded: n,
                tag: r,
                isSticky: a
            }) => (0, i.jsx)(o.A, {
                align: "bottom",
                hpadded: e,
                vpadded: n,
                tag: r,
                isSticky: a,
                dataQA: {
                    "data-qa": "screen-footer"
                },
                children: t
            })
        },
        13228: function(t, e, n) {
            n(52675), n(45700), n(2008), n(51629), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(3949), n(23500);
            var i = n(51709),
                o = n(91344),
                r = n(33702),
                a = n(14680),
                s = n(74848);

            function c(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function u(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? c(Object(n), !0).forEach((function(e) {
                        l(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function l(t, e, n) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != typeof t || !t) return t;
                        var n = t[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(t, e || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == typeof e ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }
            e.A = function(t) {
                var e, n = (0, i.iD)(t),
                    c = n.a11y,
                    l = n.ids,
                    f = n.labelProps;
                return "numeric" !== t.preset && "sms" !== t.preset || (e = t.maxLength ? "d{" + t.maxLength + "}" : "[0-9]+"), (0, s.jsx)(a.A, u(u(u({}, t), l), {}, {
                    label: f.label,
                    children: (0, s.jsx)(o.A, {
                        prefix: t.prefix,
                        suffix: t.suffix,
                        children: (0, s.jsx)(r.A, u(u(u(u({}, t), l), (0, i.$E)(t.preset || "text-code", t)), {}, {
                            pattern: t.pattern || e,
                            status: Boolean(t.errorMessage) || t.isInvalid ? "error" : void 0,
                            dir: "ltr",
                            a11y: u(u({}, c), {}, {
                                ariaRequired: f.ariaRequired
                            })
                        }))
                    })
                }))
            }
        },
        14680: function(t, e, n) {
            var i = n(51709),
                o = n(79752),
                r = n(74848);
            e.A = function(t) {
                var e = t.label,
                    n = t.children,
                    a = t.errorMessage,
                    s = t.errorId,
                    c = t.hintMessage,
                    u = t.hintId,
                    l = t.hintIcon,
                    f = t.noteExtra,
                    d = t.dataQa,
                    h = t.fieldId,
                    p = t.tag,
                    g = a || f && !c ? {
                        text: a,
                        variant: "error",
                        extra: f,
                        id: s
                    } : void 0,
                    v = c || f && !a ? {
                        text: c,
                        extra: g ? void 0 : f,
                        id: u,
                        icon: l
                    } : void 0;
                return (0, r.jsx)(o.A, {
                    label: (0, i.Fi)(e),
                    status: g,
                    hint: v,
                    fieldId: h,
                    tag: p,
                    dataQA: d,
                    children: n
                })
            }
        },
        15680: function(t, e, n) {
            var i = n(75248),
                o = (0, n(58544).lh)(),
                r = {
                    onChange: o.subscribe,
                    start: function() {
                        i.A.getInstance().on(i.A.Type.COMET_CONFIG, (function(t) {
                            r.cometConfiguration = t, o.trigger()
                        }))
                    }
                };
            e.A = r
        },
        16427: function(t, e, n) {
            var i = n(85208),
                o = n(42302),
                r = n(99417),
                a = n(80294),
                s = n(23735),
                c = n(73090),
                u = n(58544),
                l = n(65297),
                f = n(23318),
                d = n(18084),
                h = n(30397),
                p = n(23715),
                g = n(15680),
                v = n(28030),
                A = n(92105),
                m = n(15566),
                _ = {
                    WRITING: 2
                };

            function y() {
                (0, A.A)(this), this.log = d.A.getLogger("Comet"), this.comet_ = new a.A
            }

            function x(t) {
                return (0, f.A)(t, 19)
            }(0, i.A)(y.prototype, u.zb, {
                comet_: null,
                pingTimeoutId_: null,
                lastPingTime_: 0,
                lastActiveTime_: 0,
                isActive_: !1,
                userId_: null,
                connectionLost_: !1,
                init: function() {
                    var t = this;
                    return l.A.on(l.A.Session.LOGOUT, this.disconnect_).on(l.A.Session.SESSION_CHANGED, this.onSessionChange_), p.A.on(p.A.EVENTS.ONLINE, this.softReconnect, this), g.A.onChange((function() {
                        return t.configure_()
                    })), v.A.onChange((function(e) {
                        var n = x(e);
                        n && (t.userId_ = n, t.comet_.session_change(n), t.softReconnect())
                    })), this.comet_.on("im:new_msg", this.onNewMsg_, this).on("im:writing", this.onMessageWriting_, this).on("gpb:push", this.onPush_, this).on("unauth", this.onUnauth_, this).on("start", this.onStart_, this).on("stop", this.onStop_, this).on("open", this.onOpen_, this).on("close", this.onClose_, this), h.A.on(h.A.ACTIONS.WAKE_UP, this.onShown_, this).on(h.A.ACTIONS.SLEEP, this.onHidden_, this), this
                },
                configureComet_: function(t) {
                    if (!t) return !1;
                    var e = this.comet_;
                    if (e.url === t.path && e.seq === t.sequence) return !1;
                    e.mode = "master";
                    var n = x(v.A.getSettings());
                    return !!n && (this.userId_ = n, e.configure(t.path, t.sequence, n), e.channel("im", {
                        mid: 0
                    }), !0)
                },
                softReconnect: function() {
                    c.A.isLoggedIn() ? this.userId_ ? this.comet_.user_id && (this.userId_ === this.comet_.user_id ? (this.isActive_ = !0, this.comet_.soft_reconnect()) : this.log.error("softReconnect UserId is unequal " + this.userId_ + "!=" + this.comet_.user_id)) : this.log.error("softReconnect without UserId") : this.disconnect_()
                },
                hasUserId: function() {
                    return Boolean(this.userId_)
                },
                onHidden_: function() {
                    this.comet_.stop(), this.isActive_ = !1
                },
                onShown_: function() {
                    c.A.isLoggedIn() && this.softReconnect()
                },
                updatePing_: function() {
                    if (this.pingTimeoutId_ && (r.A.clearTimeout(this.pingTimeoutId_), this.pingTimeoutId_ = null), this.comet_.run) {
                        var t = this.lastPingTime_ + 6e5,
                            e = +new Date;
                        if (t < e) this.onPing_();
                        else {
                            var n = t - e + 1;
                            this.pingTimeoutId_ = setTimeout(this.onPing_, n)
                        }
                    }
                },
                onPing_: function() {
                    this.lastPingTime_ = +new Date, new s.Ay(0, null).on(0, o.A).request(), this.updatePing_()
                },
                disconnect_: function() {
                    this.comet_.unauth(), this.isActive_ = !1
                },
                configure_: function() {
                    this.configureComet_(g.A.cometConfiguration) && this.softReconnect()
                },
                onNewMsg_: function(t, e) {
                    s.Kj.send(e)
                },
                onMessageWriting_: function(t) {
                    this.trigger(_.WRITING, t)
                },
                onPush_: function(t) {
                    s.Kj.send(t)
                },
                onSessionChange_: function() {
                    if (this.isActive_ && c.A.isLoggedIn()) {
                        var t = x(v.A.getSettings());
                        t && (this.userId_ = t), this.comet_.session_change(t), this.softReconnect()
                    }
                },
                onStart_: function() {
                    var t;
                    this.lastPingTime_ = +new Date, this.updatePing_(), this.connectionLost_ && (this.connectionLost_ = !1, (t = new m.z5o).setBackgroundSession(!1), new s.Ay(199, t).on(387, o.A).request())
                },
                onOpen_: function() {
                    p.A.isOnline() && this.lastActiveTime_ && this.lastActiveTime_ + 3e4 <= +new Date && l.A.trigger("push-sync")
                },
                onStop_: function() {
                    this.updatePing_(), this.connectionLost_ = !0
                },
                onClose_: function(t, e) {
                    this.lastActiveTime_ = e
                },
                onUnauth_: function() {
                    this.disconnect_()
                },
                notifyWriting: function(t) {}
            });
            var b = null;
            y.getInstance = function() {
                return b || (b = new y), b
            }, y.EVENTS = _, e.A = 8792 == n.j ? y : null
        },
        17315: function(t, e, n) {
            n(48598), n(27495), n(71761);
            var i = n(23735),
                o = n(99417),
                r = /'errno' => '([^']+)'/,
                a = /'errmsg' => '(.*?)($|##uncutable##)/m;

            function s(t) {
                if (o.A.console) {
                    var e = t.match(r),
                        n = t.match(a);
                    console.groupCollapsed ? e && n ? (console.groupCollapsed("%c%s", "color: red; font-weight: bold", "[SRV-ERROR " + e[1] + "] " + n[1]), console.error(t), console.groupEnd()) : (console.groupCollapsed("%c%s", "color: red; font-weight: bold", t.split("\n").slice(0, 3).join("\n")), console.error(t.split("\n").slice(3).join("\n")), console.groupEnd()) : console.error && console.error(t)
                }
            }
            var c = {
                init: function() {
                    i.Kj.on(6001, this.onTestError_)
                },
                onTestError_: function(t, e) {
                    if (!t)
                        for (var n = e.getErrors(), i = 0; i < n.length; i++) s(n[i])
                }
            };
            e.A = 8792 == n.j ? c : null
        },
        17412: function(t, e, n) {
            var i, o, r;
            n.d(e, {
                    An: function() {
                        return o
                    },
                    qR: function() {
                        return i
                    },
                    vD: function() {
                        return r
                    }
                }),
                function(t) {
                    t[t.PROVIDER_PLAID = 0] = "PROVIDER_PLAID"
                }(i || (i = {})),
                function(t) {
                    t.INITIATE_FULLSCREEN_FLOW = "InitiateFullscreenFlow", t.INPUT_ERRORS = "InputErrors", t.SECURITY_CHECK = "SecurityCheck", t.STORE_DETAILS = "StoreDetails", t.SUBMIT_FORM = "SubmitForm", t.UPDATE_HEIGHT = "UpdateHeight", t.SUBMIT_FORM_REQUESTED = "SubmitFormRequested"
                }(o || (o = {})),
                function(t) {
                    t.EMBEDDED = "embedded", t.REDIRECT = "redirect"
                }(r || (r = {}))
        },
        20175: function(t, e, n) {
            function i(t) {
                return t < 10 ? "0" + t : "" + t
            }

            function o(t, e) {
                void 0 === e && (e = !1);
                var n = Math.floor(t / 3600 % 24),
                    o = Math.floor(t / 60 % 60),
                    r = Math.floor(t % 60);
                return n || e ? n + ":" + i(o) + ":" + i(r) : i(o) + ":" + i(r)
            }

            function r(t) {
                var e = new Date(1e3 * t),
                    n = e.getHours(),
                    o = e.getMinutes();
                return i(n) + ":" + i(o)
            }
            n.d(e, {
                At: function() {
                    return o
                },
                Cp: function() {
                    return r
                }
            })
        },
        23318: function(t, e, n) {
            n.d(e, {
                A: function() {
                    return i
                }
            });
            n(50113), n(26099), n(27495), n(98992), n(72577);

            function i(t, e) {
                var n, i = ((null == t ? void 0 : t.external_endpoints) || []).find((function(t) {
                    return t.type === e
                }));
                return null == i || null == (n = i.url) ? void 0 : n.replace("http://", "https://")
            }
        },
        24500: function(t, e, n) {
            n(52675), n(89463), n(50113), n(48980), n(26099), n(98992), n(72577);
            var i = n(96540),
                o = n(80021),
                r = n(93019),
                a = n(79860),
                s = n(4571),
                c = n(46770),
                u = n(51634),
                l = n(40578),
                f = n(30784),
                d = n(20017),
                h = n(74848);
            e.A = function(t) {
                var e, n = t.header,
                    p = t.description,
                    g = t.buttonText,
                    v = t.intentions,
                    A = t.onConfirm,
                    m = t.preselectedIntentionId,
                    _ = (0, i.useState)(m || (null == (e = v.find((function(t) {
                        return t.default_for_new_users
                    }))) ? void 0 : e.tiw_phrase_id)),
                    y = _[0],
                    x = _[1],
                    b = (0, r.p)(v, y, (function(t) {
                        x(t), (0, a.sx)(332, {
                            element: 1767,
                            position: v.findIndex((function(e) {
                                return e.tiw_phrase_id === t
                            }))
                        })
                    }));
                return (0, h.jsxs)(s.A, {
                    isCompact: !0,
                    children: [(0, h.jsx)(l.A, {
                        text: n,
                        tag: "h2"
                    }), (0, h.jsx)(f.A, {
                        text: p
                    }), (0, h.jsx)(u.A, {
                        children: (0, h.jsx)(o.A, {
                            intentions: b
                        })
                    }), (0, h.jsx)(c.A, {
                        children: (0, h.jsx)(d.A, {
                            text: g,
                            onClick: function() {
                                y && A(y), (0, a.sx)(332, {
                                    element: 395
                                })
                            },
                            dataQA: {
                                "data-qa": "tiw-save-button"
                            }
                        })
                    })]
                })
            }
        },
        27384: function(t, e, n) {
            n.d(e, {
                j: function() {
                    return a
                }
            });
            var i, o = n(99417),
                r = "js-payments-overlay";

            function a() {
                return i || ((i = o.A.document.createElement("div")).className = r), i
            }
        },
        31190: function(t, e, n) {
            n(10287), n(28706), n(50113), n(48980), n(74423), n(25276), n(60739), n(26099), n(27495), n(11392);
            var i, o = n(1978),
                r = n(3508),
                a = n(31709),
                s = n(61155),
                c = n(13264),
                u = n(65297),
                l = n(58385),
                f = n(40075),
                d = n(36521),
                h = n(73090),
                p = n(93529),
                g = n(37414),
                v = n(30685),
                A = n(61405),
                m = n(75248),
                _ = n(13614),
                y = n(65422),
                x = n(41025),
                b = n(30922),
                I = n(7541),
                C = n(1168),
                O = n(39778),
                N = n(88309),
                E = n(28030),
                T = n(20387),
                S = n(31087),
                w = n(49952),
                P = n(37905),
                R = n(1765),
                j = n(59977),
                k = n(48788),
                M = n(15566),
                D = n(35837),
                L = n(74389),
                U = n(60808),
                B = n(83186),
                F = n(95773),
                q = n(74848);

            function H(t, e) {
                return H = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                    return t.__proto__ = e, t
                }, H(t, e)
            }
            var V, G = [81, 60, 66, 50, 3, 56, 78, 73, 44, 89, 120, 2, 112, 163, 170, 171, 140],
                Q = [7, 1],
                W = [L.x.SPP_TRIAL, L.x.PAY];

            function Y(t) {
                return -1 !== G.indexOf(t.getType())
            }
            var K = function(t) {
                function e() {
                    for (var e, n = arguments.length, i = new Array(n), o = 0; o < n; o++) i[o] = arguments[o];
                    return (e = t.call.apply(t, [this].concat(i)) || this).queue = [], e.ignorePhoneVerificationNotification = !1, e.currentNotification = null, e
                }
                var n, i;
                i = t, (n = e).prototype = Object.create(i.prototype), n.prototype.constructor = n, H(n, i);
                var c = e.prototype;
                return c.init = function() {
                    return C.A.onUnblock(this.onAppUnblocked_, this), this.ignorePhoneVerificationNotification = !1, this.queue = [], this
                }, c.onAppUnblocked_ = function() {
                    this.advanceQueue()
                }, c.onStart = function() {
                    m.A.getInstance().on(m.A.Type.NOTIFICATION, this.onClientNotification, this), m.A.getInstance().on(m.A.Type.SYSTEM_NOTIFICATION, this.onSystemNotification, this)
                }, c.onStop = function() {
                    return m.A.getInstance().off(m.A.Type.NOTIFICATION, this.onClientNotification, this), m.A.getInstance().off(m.A.Type.SYSTEM_NOTIFICATION, this.onSystemNotification, this), t.prototype.onStop.call(this)
                }, c.onSystemNotification = function(t) {
                    switch (t.id) {
                        case 5:
                        case 2:
                        case 6:
                            S.A.getInstance().invalidate(h.A.getUserId())
                    }
                }, c.onClientNotification = function(t) {
                    this.addToQueue((0, D.A)(t, M.z5N)), this.advanceQueue()
                }, c.addToQueue = function(t) {
                    if (t instanceof M.z5N && "string" == typeof t.getId() && !this.isDuplicated(t) && !(t.getMessage("").startsWith("Connected to QA") || d.A.selenium && t.getMessage("").startsWith("Connected to "))) {
                        var e = P.A.controller;
                        null != e && e.discardGenericPromos && 81 === t.getType() || this.ignorePhoneVerificationNotification && z(t) || this.queue.push(t)
                    }
                }, c.isDuplicated = function(t) {
                    var e, n = t.getId();
                    if (n === (null == (e = this.currentNotification) ? void 0 : e.getId())) return !0;
                    for (var i = 0; i < this.queue.length; i += 1)
                        if (this.queue[i].getId() === n) return !0;
                    return !1
                }, c.advanceQueue = function() {
                    var t;
                    this.queue.length && null === this.currentNotification && (this.currentNotification = this.queue.shift(), Y(t = this.currentNotification) || -1 === Q.indexOf(t.getAction()) || function(t) {
                        return 96 === t.getType()
                    }(t) ? Y(this.currentNotification) ? this.overlayNotification() : ! function(t) {
                        return !Y(t) && 9 === t.getAction()
                    }(this.currentNotification) ? this.notificationHandled() : this.spendCredits() : this.notifyMessage())
                }, c.performNotificationAction = function() {
                    var t, e;
                    12 === (null == (t = this.currentNotification) ? void 0 : t.getType()) ? (e = {
                        back: r.A.get("default.page"),
                        hotPanelData: {
                            activationPlace: 48
                        },
                        productType: 1
                    }, x.A.navigateToPayment(e), this.notificationHandled()) : p.A.showNotification({
                        type: p.A.TYPES.ERROR
                    })
                }, c.overlayNotification = function() {
                    var t = this.currentNotification;
                    if (t) {
                        var e = t.getType(),
                            n = t.getPromoBlock(),
                            i = n ? n.getPromoBlockType() : null,
                            o = t.toJSON();
                        this.handleOverlayNotification({
                            type: e,
                            promo: n,
                            promoBlockType: i,
                            notificationJSON: o,
                            notification: t
                        }) && (0, w.cj)(this.notificationHandled.bind(this))
                    }
                }, c.handleOverlayNotification = function(t) {
                    var e, n = t.type,
                        i = t.promo,
                        o = t.promoBlockType,
                        r = t.notificationJSON,
                        a = t.notification,
                        c = !0;
                    switch (n) {
                        case 78:
                            ! function(t, e) {
                                var n, i;
                                t && null != e && null != (n = e.pictures) && null != (n = n[0]) && n.video && (0, _.NN)(null == (i = e.pictures) || null == (i = i[0].video) ? void 0 : i.url).then((function(e) {
                                    var n = e[0];
                                    l.A.navigate(L.x.UPLOAD_VIDEO, {
                                        clientNotification: t,
                                        src: n
                                    })
                                })).catch((function(t) {
                                    return (0, F.gf)(t, "Upload video")
                                }))
                            }(r, i.toJSON());
                            break;
                        case 120:
                            this.showPassiveMatches(r), c = !1;
                            break;
                        case 2:
                            this.showTiwMappingPopup(r), c = !1;
                            break;
                        case 3:
                            setTimeout((function() {
                                return l.A.navigate(L.x.MODERATED_PHOTOS, {
                                    notification: r
                                })
                            }), 700);
                            break;
                        case 81:
                            if (61 === o) return;
                            if (153 === o && !E.A.isDevFeatureEnabled(j.v.STILL_YOUR_NUMBER)) return;
                            c = this.handleOverlayNotificationGenericPromo({
                                promo: i,
                                promoBlockType: o,
                                notificationJSON: r
                            });
                            break;
                        case 50:
                            l.A.navigate(L.x.NICE_NAME, !1, {
                                notification: r
                            });
                            break;
                        case 44:
                            l.A.navigate(L.x.ABUSE_WARNING, !1, {
                                notification: r
                            });
                            break;
                        case 73:
                            92 === o ? l.A.navigate(L.x.NEVER_LOOSE_ACCOUNT, !1, {
                                notification: r,
                                isNotification: "true"
                            }) : R.A.handleNotification(a);
                            break;
                        case 60:
                            I.A.show(a);
                            break;
                        case 56:
                            var u = l.A.getUrl();
                            W.find((function(t) {
                                return u.startsWith(t)
                            })) || l.A.navigate(L.x.SPP_TRIAL, !1, {
                                returnTo: u,
                                context: 45
                            });
                            break;
                        case 89:
                            if (148 === (null == (e = r.promo_block) ? void 0 : e.promo_block_type)) {
                                s.A.setAsReached(), l.A.navigate(L.x.ENCOUNTERS_ONBOARDING_PROMO, !1, {
                                    notification: r
                                });
                                break
                            }
                            l.A.navigate(L.x.NEW_USER_SUBSTITUTE, !1, {
                                notification: r
                            });
                            break;
                        case 112:
                            this.showCreditsFeatureFinished(r);
                            break;
                        case 163:
                            this.showAppInstallNudgeNotification(r);
                            break;
                        case 170:
                            this.showGroupPhotoUpload(r), this.notificationHandled(), c = !1;
                            break;
                        case 171:
                            l.A.navigate(L.x.PHOTOS_AUTO_BLUR, !1, {
                                notification: r
                            }), this.notificationHandled(), c = !1;
                            break;
                        case 140:
                            this.showUnavailableSubscriptionFeaturesNotification(r), this.notificationHandled();
                            break;
                        default:
                            c = !1
                    }
                    return c
                }, c.handleOverlayNotificationGenericPromo = function(t) {
                    var e = t.promo,
                        n = t.promoBlockType,
                        i = t.notificationJSON;
                    if (165 === n) return l.A.navigate(L.x.MESSENGER_MINI_GAME_PROMO, {
                        notification: i,
                        promoBlock: e
                    }), !1;
                    if (69 === n) return l.A.navigate(L.x.CONFIRM_EMAIL, {
                        notification: i
                    }), !1;
                    if (222 === n) return l.A.navigate(L.x.MODERATED_PHOTOS, {
                        notification: i
                    }), !1;
                    if (346 === n) return l.A.navigate(L.x.PROFILE_QUESTIONS_CHAT_BLOCKER, {
                        notification: i
                    }), !1;
                    var r = i.id.replace(/_/g, "-"),
                        a = [L.x.MARKETING_SUBSCRIPTION];
                    return [].concat(a, [L.x.ATTENTION_BOOST_REMINDER, L.x.EXTRA_SHOWS_REMINDER, L.x.RISE_UP_REMINDER, L.x.IS_THIS_STILL_YOUR_NUMBER]).includes(r) ? (0, o.A)((function() {
                        l.A.navigate(r, {
                            notification: i
                        })
                    })) : this.log.error("The notification with id " + i.id + " has no matching route."), a.includes(r)
                }, c.spendCredits = function() {
                    var t, e, n, i = this;
                    if (l.A.getLocation().routeName !== L.x.PAY) {
                        k.A.set(!0);
                        var o = (0, N.A)();
                        this.renderReactView((0, q.jsx)(O.A, {
                            header: null == (t = this.currentNotification) ? void 0 : t.getTitle(),
                            message: null == (e = this.currentNotification) ? void 0 : e.getMessage(),
                            confirmLabel: null == (n = this.currentNotification) ? void 0 : n.getActionText(),
                            cancelLabel: f.Ay.get(451),
                            isOpen: !0,
                            onConfirm: function() {
                                i.performNotificationAction(), k.A.set(!1), i.removeReactView(o)
                            },
                            onCancel: function() {
                                i.handleDecline(), k.A.set(!1), i.removeReactView(o)
                            }
                        }), o)
                    } else this.notificationHandled()
                }, c.showPassiveMatches = function(t) {
                    var e = this;
                    k.A.set(!0);
                    var n = this.renderReactView((0, q.jsx)(v.A, {
                        promoBlocks: t.promo_blocks,
                        onClose: function() {
                            k.A.set(!1), e.removeReactView(n)
                        }
                    }), this.createElement()[0])
                }, c.showTiwMappingPopup = function(t) {
                    var e = this;
                    k.A.set(!0);
                    var n = this.renderReactView((0, q.jsx)(U.A, {
                        promoBlocks: t.promo_blocks,
                        onClose: function() {
                            k.A.set(!1), e.removeReactView(n)
                        }
                    }), this.createElement()[0])
                }, c.showCreditsFeatureFinished = function(t) {
                    var e = this;
                    k.A.set(!0);
                    var n = this.renderReactView((0, q.jsx)(y.A, {
                        promoBlock: t.promo_block,
                        onClose: function() {
                            k.A.set(!1), e.removeReactView(n)
                        }
                    }), this.createElement()[0])
                }, c.showAppInstallNudgeNotification = function(t) {
                    var e = this;
                    k.A.set(!0);
                    var n = this.renderReactView((0, q.jsx)(B.A, {
                        promoBlock: t.promo_block,
                        onClose: function() {
                            k.A.set(!1), e.removeReactView(n)
                        }
                    }), this.createElement()[0])
                }, c.showGroupPhotoUpload = function(t) {
                    var e = this;
                    k.A.set(!0);
                    var n = this.renderReactView((0, q.jsx)(g.A, {
                        notification: t,
                        onClose: function() {
                            k.A.set(!1), e.removeReactView(n)
                        }
                    }), this.createElement()[0])
                }, c.showUnavailableSubscriptionFeaturesNotification = function(t) {
                    var e = this;
                    k.A.set(!0);
                    var n = this.renderReactView((0, q.jsx)(A.A, {
                        notification: t,
                        onClose: function() {
                            k.A.set(!1), e.removeReactView(n)
                        }
                    }), this.createElement()[0])
                }, c.notifyMessage = function() {
                    var t = this.currentNotification;
                    this.clearCurrentNotification(), t && (t.getTransactionIdentifier() ? b.A.processClientNotification(t.toJSON()) : u.A.trigger(u.A.SHOW_NOTIFICATION, t))
                }, c.handleDecline = function() {
                    var t;
                    12 === (null == (t = this.currentNotification) ? void 0 : t.getType()) && (S.A.getInstance().invalidate(h.A.getUserId()), T.A.getInstance().invalidateSppFolders()), this.notificationHandled()
                }, c.notificationHandled = function(t) {
                    this.currentNotification && (t = "string" == typeof t ? t : this.currentNotification.getId()) === this.currentNotification.getId() && (new a.Ay(159, {
                        value: t
                    }).request(), this.clearCurrentNotification(), this.advanceQueue())
                }, c.clearCurrentNotification = function() {
                    this.currentNotification = null
                }, c.clearPhoneVerificationNotification = function() {
                    var t = this.queue.findIndex(z);
                    this.ignorePhoneVerificationNotification = !0, t > -1 && this.queue.splice(t, 1)
                }, e
            }(c.A);

            function z(t) {
                var e = t.getPromoBlock();
                return !!Boolean(e) && 94 === e.getPromoBlockType()
            }
            i = K, K.getInstance = function() {
                return V || (V = new i)
            }, e.A = 8792 == n.j ? K : null
        },
        51709: function(t, e, n) {
            n.d(e, {
                $E: function() {
                    return u
                },
                Fi: function() {
                    return s
                },
                JU: function() {
                    return d
                },
                Y4: function() {
                    return f
                },
                iD: function() {
                    return l
                }
            });
            n(52675), n(45700), n(2008), n(51629), n(25276), n(48598), n(62062), n(72712), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(27495), n(38781), n(98992), n(54520), n(3949), n(81454), n(8872), n(23500);
            var i = n(40075);

            function o(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function r(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? o(Object(n), !0).forEach((function(e) {
                        a(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function a(t, e, n) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != typeof t || !t) return t;
                        var n = t[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(t, e || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == typeof e ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }

            function s(t) {
                return t && t.toUpperCase().indexOf("FIXME_LABEL") < 0 ? t : void 0
            }
            var c = {
                email: {
                    type: "email",
                    inputMode: "email",
                    spellCheck: !1,
                    autoCapitalize: "none",
                    autoCorrect: "off",
                    autoComplete: "username"
                },
                tel: {
                    type: "tel",
                    inputMode: "tel",
                    spellCheck: !1,
                    autoCapitalize: "none",
                    autoCorrect: "off",
                    autoComplete: "tel-national"
                },
                numeric: {
                    type: "text",
                    inputMode: "numeric",
                    spellCheck: !1,
                    autoCapitalize: "none",
                    autoCorrect: "off"
                },
                sms: {
                    type: "text",
                    inputMode: "numeric",
                    spellCheck: !1,
                    autoCapitalize: "none",
                    autoCorrect: "off",
                    autoComplete: "one-time-code"
                },
                "text-code": {
                    type: "text",
                    spellCheck: !1,
                    autoCapitalize: "none",
                    autoCorrect: "off",
                    autoComplete: "off"
                },
                password: {
                    type: "password",
                    spellCheck: !1,
                    autoCapitalize: "none",
                    autoCorrect: "off"
                },
                date: {
                    type: "date",
                    autoComplete: "bday",
                    autoCorrect: "off"
                },
                location: {
                    type: "text",
                    spellCheck: !0,
                    autoCapitalize: "none",
                    autoCorrect: "off",
                    autoComplete: "location"
                },
                "given-name": {
                    type: "text",
                    spellCheck: !1,
                    autoCapitalize: "words",
                    autoCorrect: "off",
                    autoComplete: "given-name"
                }
            };

            function u(t, e) {
                var n = e.type,
                    i = e.inputMode,
                    o = e.spellCheck,
                    a = e.autoCapitalize,
                    s = e.autoCorrect,
                    u = e.autoComplete;
                return r(r(r(r(r(r(r({}, t && c[t]), n && {
                    type: n
                }), i && {
                    inputMode: i
                }), o && {
                    spellCheck: o
                }), a && {
                    autoCapitalize: a
                }), s && {
                    autoCorrect: s
                }), u && {
                    autoComplete: u
                })
            }

            function l(t) {
                var e, n, o, a, s, c, u, l, f = t.a11y || {},
                    d = (e = t.fieldId, n = t.errorId, o = t.hintId, {
                        fieldId: e,
                        id: e,
                        errorId: n || e + "_error",
                        hintId: o || e + "_hint",
                        counterId: e + "_counter"
                    }),
                    h = (a = t.label, s = t.labelStatus, c = f.ariaRequired, l = c, (u = a) && "required" === s && (u = a + " " + i.Ay.get(211), l = !1), u && "optional" === s && (u = a + " " + i.Ay.get(210), l = !1), {
                        label: u,
                        ariaRequired: l
                    }),
                    p = [];
                return t.errorMessage && p.push(d.errorId), t.hintMessage && p.push(d.hintId), t.maxLengthCounter && p.push(d.counterId), {
                    a11y: r({
                        ariaDescribedby: p.join(" ") || void 0
                    }, f),
                    ids: d,
                    labelProps: h
                }
            }

            function f(t, e) {
                t.preventDefault(), e()
            }

            function d(t) {
                return void 0 === t && (t = ""), t.split("").map((function(t) {
                    return t.charCodeAt(0)
                })).reduce((function(t, e) {
                    return t + ((t << 7) + (t << 3)) ^ e
                })).toString(16)
            }
        },
        62536: function(t, e, n) {
            n.d(e, {
                M: function() {
                    return a
                }
            });
            n(2892);
            var i = n(31087),
                o = n(73090),
                r = n(15566),
                a = function(t) {
                    var e = (new r.KJW).setUserId(o.A.getUserId()).setTiwIdea((new r._oR).setTiwPhraseId(Number(t)));
                    return i.A.getInstance().set(e, [494])
                }
        },
        64266: function(t, e, n) {
            n.d(e, {
                A: function() {
                    return h
                }
            });
            var i, o = n(15566),
                r = n(73090),
                a = n(93529),
                s = n(40075),
                c = n(18084),
                u = n(25093),
                l = 124,
                f = 25,
                d = c.A.getLogger("session");

            function h(t, e) {
                return !! function(t, e) {
                    if (e === l) return !0;
                    return t instanceof o.beZ && ("1" === t.getErrorCode() || t.getType() === f)
                }(t, e) && (function(t) {
                    var e, n = (0, u.A)(t);
                    n && d.error("Attempt to use failed session", {
                        error: t,
                        url: null == (e = window) ? void 0 : e.location.href
                    });
                    if (t instanceof o.beZ && "1002" === t.getErrorCode()) return;
                    if (i && Date.now() < i + 3e4) return void(u.A && d.error("Additional attempt to use failed session, could lead to infinite loader", {
                        error: t
                    }));
                    i = Date.now(), r.A.logout(!0), a.A.showNotification({
                        type: a.A.TYPES.INFO,
                        text: s.Ay.get(521)
                    })
                }(t), !0)
            }
        },
        64928: function(t, e, n) {
            n(10287);
            var i = n(72537),
                o = n(78029),
                r = n(31709);

            function a(t, e) {
                return a = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                    return t.__proto__ = e, t
                }, a(t, e)
            }
            var s = function(t) {
                function e() {
                    return t.call(this, {
                        get: {
                            message: 34,
                            response: 35
                        },
                        set: {
                            message: 36,
                            response: 35
                        }
                    }, {
                        commitCache: !1,
                        name: "AppSettings"
                    }) || this
                }
                var n, s;
                s = t, (n = e).prototype = Object.create(s.prototype), n.prototype.constructor = n, a(n, s), e.getInstance = function() {
                    return e.instance || (e.instance = new e), e.instance
                };
                var c = e.prototype;
                return c.init = function() {
                    var t = this;
                    o.Ay.observe(i.A.getObservable(19), (function() {
                        return t.invalidate()
                    }), {
                        leading: !1
                    }), r.aV.onResponse(35, (function(e) {
                        t.inform(e)
                    }))
                }, c.updateLanguage = function(t) {
                    var e = {
                        interface_language: t
                    };
                    return this.set(e)
                }, c.set = function(e) {
                    var n = this,
                        i = t.prototype.set.call(this, e);
                    return i.then((function(t) {
                        return n.inform(t), t
                    })), i
                }, c.getRequestTypeByObject = function() {
                    var t;
                    return (null == (t = this.messages.get) ? void 0 : t.message) || null
                }, c.getCacheByObject = function(t) {
                    return t
                }, e
            }(n(6696).A);
            s.instance = void 0, e.A = 8792 == n.j ? s : null
        },
        65107: function(t, e, n) {
            n.r(e), n.d(e, {
                default: function() {
                    return P
                }
            });
            n(26099), n(27495), n(38781), n(42762);
            var i, o = n(96540),
                r = n(99417),
                a = n(79860),
                s = n(17414),
                c = n(91133),
                u = n(5322),
                l = n(40068),
                f = n(73616),
                d = n(13228),
                h = n(87184),
                p = n(20017),
                g = n(66130),
                v = n(7164),
                A = n(89162),
                m = n(74848),
                _ = function(t) {
                    var e = t.formMessage,
                        n = t.ctaText,
                        i = t.hintText,
                        o = t.hintAction,
                        r = t.inputPrefix,
                        a = t.digits,
                        s = void 0 === a ? "" : a,
                        c = t.digitsMaxLength,
                        u = void 0 === c ? 0 : c,
                        l = t.onChangeDigits,
                        _ = t.onHintActionClick,
                        y = t.onSubmit,
                        x = t.errorMessage,
                        b = t.isCheckingForm,
                        I = u > 0 && s.length < u;
                    return (0, m.jsx)(h.A, {
                        hpadded: !0,
                        vpadded: !0,
                        children: (0, m.jsxs)(f.A, {
                            onSubmit: y,
                            children: [(0, m.jsx)(A.A, {
                                text: e
                            }), (0, m.jsx)(d.A, {
                                autoFocus: !0,
                                prefix: r,
                                value: s,
                                onChange: l,
                                errorMessage: x,
                                maxLength: u,
                                fieldId: "confirmation-code-input",
                                dataQAInput: "code-input",
                                preset: "numeric",
                                a11y: {
                                    ariaRequired: !0
                                }
                            }), (0, m.jsx)(g.A, {
                                children: (0, m.jsx)(p.A, {
                                    text: n,
                                    isLoading: b,
                                    isDisabled: I,
                                    dataQA: {
                                        "data-qa": "continue-button"
                                    },
                                    buttonAttrs: {
                                        type: "submit"
                                    }
                                })
                            }), i || o ? (0, m.jsxs)(v.A, {
                                children: [i, i && o ? " " : null, o ? (0, m.jsx)("button", {
                                    type: "button",
                                    onClick: _,
                                    children: o
                                }) : null]
                            }) : null]
                        })
                    })
                },
                y = (n(60739), n(73090)),
                x = n(31709),
                b = n(57864),
                I = n(15566),
                C = n(30866),
                O = ((i = {})[1] = "/encounters", i[2] = "/people-nearby", i);

            function N(t) {
                window.location.href = function(t) {
                    if (t) return 71 === t.redirect_page ? t.url : O[t.redirect_page];
                    return
                }(t.redirect_page) || "/encounters"
            }
            var E = "";
            var T = {
                    get: function() {
                        return E
                    },
                    set: function(t) {
                        E = t
                    }
                },
                S = n(64715),
                w = n(80051);
            var P = function(t) {
                var e, n, i, f, d, h, p = t.setScreenName,
                    g = (i = (0, o.useContext)(u.P).getFlowData, f = !1, d = null, h = null, function(t, e) {
                        var n = i(),
                            o = n.screen_id,
                            r = n.flow_id;
                        new x.Ay(968, {
                            screen_context: {
                                screen_id: o,
                                flow_id: r || "badoo_mobile_web_registration"
                            },
                            pin: t
                        }).onResponse(17, (function(t) {
                            d = t
                        })).onResponse(687, (function(t) {
                            h = t
                        })).onResponse(1, (function(n) {
                            if (f = !0, e({
                                    errorMessage: n.error_message
                                }), 15 === n.type) {
                                T.set(t);
                                var i = new I.beZ;
                                i.fromJSON(n), (0, C.V)(i, 185)
                            }
                        })).onSpecialEvent(b.SE.REQ_FINISHED, (function() {
                            var t;
                            f || d && (y.A.processClientLoginSuccess(d, {}), h && (null == (t = h) || null == (t = t.screen_story) ? void 0 : t.id) !== S.Y ? h && x.aV.send(new b.XX(687, h).toJSON()) : N(d))
                        })).request()
                    }),
                    v = (0, o.useContext)(u.P).handleBackClick,
                    A = (0, l.A)(w.l, 129)[0],
                    O = A.subheader,
                    E = A.timer,
                    P = A.pin,
                    R = A.changeNumber,
                    j = A.timerFallback,
                    k = A.inputPrefix,
                    M = A[s.Pf],
                    D = (0, o.useState)(""),
                    L = D[0],
                    U = D[1],
                    B = (0, o.useState)(void 0),
                    F = B[0],
                    q = B[1],
                    H = (0, o.useState)(!1),
                    V = H[0],
                    G = H[1],
                    Q = (0, o.useState)(Boolean(null == E ? void 0 : E.timer_sec)),
                    W = Q[0],
                    Y = Q[1],
                    K = (0, o.useState)((null == E ? void 0 : E.timer_sec) || 0),
                    z = K[0],
                    J = K[1],
                    X = (0, o.useState)(void 0),
                    $ = X[0],
                    Z = X[1],
                    tt = (0, c.G)(129);
                (0, o.useEffect)((function() {
                    var t = r.A.setInterval((function() {
                        J((function(t) {
                            return t - 1
                        }))
                    }), 1e3);
                    return "" !== T.get() && (U(T.get()), T.set("")),
                        function() {
                            return r.A.clearInterval(t)
                        }
                }), []), (0, o.useEffect)((function() {
                    E.text && z > 0 ? Z(function(t, e) {
                        return t.replace("[timer]", e.toString())
                    }(E.text, z)) : (Y(!1), Z(void 0))
                }), [E.text, z]), (0, o.useEffect)((function() {
                    tt(2)
                }), [tt]), (0, o.useEffect)((function() {
                    p(185), (0, a.sx)(49, {
                        screen_name: 185
                    })
                }), [p]);
                var et = function(t) {
                    G(!1), (0, a.sx)(125, {
                        event_type: 36,
                        error_type: 28
                    }), q(t.errorMessage)
                };
                return (0, m.jsx)(_, {
                    formMessage: O.text,
                    ctaText: M.text,
                    inputPrefix: k.text,
                    hintText: $,
                    hintAction: W ? null == (e = R.call_to_action) ? void 0 : e.text : null == (n = j.call_to_action) ? void 0 : n.text,
                    digits: L,
                    digitsMaxLength: P.length,
                    onChangeDigits: function(t) {
                        var e = t.target.value.trim();
                        q(void 0), U(e)
                    },
                    onHintActionClick: v,
                    onSubmit: function(t) {
                        G(!0), tt(1), (0, a.sx)(332, {
                            element: 288
                        }), g(L, et), null == t || t.preventDefault()
                    },
                    errorMessage: F,
                    isCheckingForm: V
                })
            }
        },
        66130: function(t, e, n) {
            var i = n(74848);
            e.A = ({
                children: t
            }) => (0, i.jsx)("div", {
                className: "csms-form-actions",
                "data-qa": "form-actions",
                children: t
            })
        },
        88309: function(t, e, n) {
            var i, o = n(99417);
            e.A = function() {
                return i || ((i = o.A.document.createElement("div")).className = "modal-container"), i
            }
        },
        88626: function(t, e, n) {
            n(74423);
            var i = n(58385),
                o = n(74389);
            e.A = {
                shouldRedirectToBlocked: function(t) {
                    var e = t.type,
                        n = 25 === e,
                        i = 72 === e,
                        o = 5 === t.behaviour;
                    return n || i && !o
                },
                redirectToBlocked: function(t) {
                    var e = i.A.getLocation().routeName;
                    [o.x.ACCOUNT_BLOCKED, o.x.TERMS, o.x.FEEDBACK, o.x.DEBUG, o.x.HELP].includes(e) || (25 === t.type ? i.A.navigate(o.x.ACCOUNT_BLOCKED, {
                        title: t.explanation.header,
                        message: t.explanation.mssg,
                        type: t.type,
                        secondaryMessage: t.explanation.extra_texts[0].text,
                        explanation: t.explanation
                    }) : i.A.navigate(o.x.ACCOUNT_BLOCKED, {
                        title: t.error_title,
                        message: t.error_message,
                        type: t.type
                    }))
                }
            }
        },
        89162: function(t, e, n) {
            var i = n(74848),
                o = n(46942),
                r = n.n(o),
                a = n(93827);
            e.A = ({
                text: t,
                color: e = "gray-80",
                tag: n
            }) => {
                const o = "string" == typeof t,
                    s = r()({
                        "csms-form-text": !0,
                        [`csms-form-text--${e}`]: e
                    });
                return (0, i.jsx)("div", {
                    className: s,
                    "data-qa": "form-text",
                    children: (0, i.jsx)(a.P1, {
                        breakWords: !0,
                        dangerous: o,
                        tag: n,
                        children: t
                    })
                })
            }
        },
        91344: function(t, e, n) {
            var i = n(74848),
                o = n(93827);
            e.A = ({
                prefix: t,
                suffix: e,
                children: n
            }) => (0, i.jsxs)("div", {
                className: "csms-prefixed-field",
                dir: "ltr",
                children: [t ? (0, i.jsx)("div", {
                    className: "csms-prefixed-field__prefix",
                    children: (0, i.jsx)(o.P1, {
                        weight: "bolder",
                        children: t
                    })
                }) : null, (0, i.jsx)("div", {
                    className: "csms-prefixed-field__content",
                    children: n
                }), e ? (0, i.jsx)("div", {
                    className: "csms-prefixed-field__suffix",
                    children: (0, i.jsx)(o.P1, {
                        weight: "bolder",
                        children: e
                    })
                }) : null]
            })
        }
    }
]);
//# sourceMappingURL=phone-confirmation-story.855b406754790c88d5f3.js.map
"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [8497], {
        26172: function(e, t, o) {
            o(28706), o(2008), o(25276), o(62062), o(72712), o(26910), o(26099), o(98992), o(54520), o(81454), o(8872);
            var n = o(85608),
                r = o(47632),
                a = o(18084),
                i = a.A.getLogger("PromotionPageHelper"),
                c = [50],
                s = function() {
                    function e() {}
                    return e.getTitle = function(e) {
                        return e
                    }, e.getDataFromNotification = function(e) {
                        var t, o = null == e ? void 0 : e.image_urls,
                            n = null == o ? void 0 : o[0],
                            r = null == e ? void 0 : e.import_providers,
                            a = null == r || null == (t = r.providers) ? void 0 : t[0];
                        return {
                            avatars: [{
                                significance: 1,
                                src: n
                            }],
                            imageUrl: n,
                            providerType: null == a ? void 0 : a.type,
                            buttons: [{
                                actionText: (null == e ? void 0 : e.action_text) || "",
                                actionType: null == e ? void 0 : e.action,
                                type: 1
                            }],
                            notificationId: null == e ? void 0 : e.id,
                            titleText: (null == e ? void 0 : e.title) || "",
                            messageText: (null == e ? void 0 : e.message) || "",
                            actionType: null == e ? void 0 : e.action,
                            cancelActionText: null == e ? void 0 : e.cancel_action_text,
                            actionText: null == e ? void 0 : e.action_text,
                            empathizedText: null == e ? void 0 : e.display_comment
                        }
                    }, e.getDataFromPrePurchaseInfo = function(e) {
                        if (e) {
                            var t = e.application_feature || {},
                                o = null == t ? void 0 : t.feature,
                                a = e.album,
                                i = (null == a ? void 0 : a.photos) || [],
                                c = Boolean(a) ? i.map((function(e) {
                                    var t = u(e);
                                    return {
                                        src: e.large_url,
                                        badgeType: t,
                                        badgeName: r.A.getBadgeName(t),
                                        significance: 2
                                    }
                                })) : [],
                                s = (t.display_images || []).map((function(e) {
                                    var t = u(e);
                                    return {
                                        src: e.display_images,
                                        badgeType: t,
                                        badgeName: r.A.getBadgeName(t),
                                        significance: 2
                                    }
                                })),
                                l = t.product_type,
                                d = c.concat(s),
                                p = n.A.getPromoBlockForProduct(l),
                                m = d.slice(0, 3),
                                f = null;
                            return 3 === m.length && ((f = m[1]).badgeName = r.A.getBadgeTypeFromPromoBlock(p), f.significance = 1), {
                                avatars: m,
                                buttons: [{
                                    actionText: t.display_action || "",
                                    actionType: t.required_action,
                                    type: 1
                                }],
                                featureName: n.A.getFeatureName(p),
                                costOfService: e.cost,
                                cost: t.payment_amount,
                                featureType: o,
                                messageText: t.display_message || "",
                                pageTitle: e.header,
                                productType: l,
                                sharingPicture: f ? f.src : void 0,
                                titleText: t.display_title || ""
                            }
                        }
                    }, e.getDataFromPromoBlock = function(e, t) {
                        var o;
                        void 0 === t && (t = !1);
                        var a = function(e) {
                                var t = (e.pictures || []).sort(l).map((function(e) {
                                    var t = e.badge_type || 1;
                                    return {
                                        badgeName: r.A.getBadgeName(t),
                                        badgeType: t,
                                        significance: e.significance || -1,
                                        src: e.display_images
                                    }
                                }));
                                3 === t.length && (t = [t[2], t[0], t[1]]);
                                return t
                            }(e),
                            i = e.promo_block_type,
                            c = e.ok_payment_product_type,
                            s = function(e) {
                                var t = e.buttons || [];
                                if (t.length) return t.filter((function(e) {
                                    return 4 !== e.type
                                })).map((function(t) {
                                    var o = t.product_type || e.ok_payment_product_type,
                                        n = t.redirect_page;
                                    return {
                                        actionText: t.text || "",
                                        actionType: t.action,
                                        type: t.type,
                                        productType: o,
                                        redirectPage: null == n ? void 0 : n.redirect_page,
                                        isPremiumPlus: 47 === o
                                    }
                                }));
                                var o = [];
                                o.push({
                                    actionText: e.action || "",
                                    actionType: e.ok_action
                                }), e.other_text && e.other_action && o.push({
                                    actionText: e.other_text,
                                    actionType: e.other_action
                                });
                                return o
                            }(e),
                            u = (e.extra_texts || []).reduce((function(e, t) {
                                switch (t.type) {
                                    case 11:
                                        e.inBetweenText = t.text;
                                        break;
                                    case 28:
                                        e.offerText = t.text;
                                        break;
                                    case 31:
                                        e.disclaimerText = t.text
                                }
                                return e
                            }), {});
                        return {
                            avatars: a,
                            buttonName: n.A.getButtonName(i),
                            buttons: s,
                            cost: e.payment_amount,
                            costOfService: e.credits_cost,
                            extraTexts: u,
                            featureName: n.A.getFeatureName(i, t),
                            featureType: c && n.A.getFeatureFromPaymentProductType(c),
                            messageText: e.mssg || "",
                            pageTitle: e.screen_header || e.header,
                            productType: c,
                            sharingPicture: a.length ? (a[1] || a[0]).src : void 0,
                            titleText: e.header || "",
                            promoBlockType: i,
                            redirectPage: null == (o = e.redirect_page) ? void 0 : o.redirect_page
                        }
                    }, e.getDataFromCorrectSource = function(t) {
                        var o = t.clientNotification,
                            n = t.prePurchaseInfo,
                            r = t.promoBlock,
                            a = t.twoTiersIsAvailable;
                        if (o || n || r) {
                            if (o) {
                                var s = o.type;
                                return 81 === s || 89 === s ? e.getDataFromPromoBlock(o.promo_block) : s && -1 === c.indexOf(s) ? e.getDataFromPrePurchaseInfo(o.purchase_info) : e.getDataFromNotification(o)
                            }
                            return n ? e.getDataFromPrePurchaseInfo(n) : r ? e.getDataFromPromoBlock(r, a) : void 0
                        }
                        i.error("Invalid arguments, expected Notification, PrePurchaseInfo or PromoBlock object")
                    }, e
                }();

            function l(e, t) {
                return (e.significance || -1) < (t.significance || -1) ? -1 : (e.significance || -1) > (t.significance || -1) ? 1 : 0
            }

            function u(e) {
                return (null == e ? void 0 : e.badge_type) || 1
            }
            t.A = s
        },
        51265: function(e, t, o) {
            o(28706), o(10287);
            var n = o(35837),
                r = o(85558),
                a = o(31190),
                i = o(15566);

            function c(e, t) {
                return c = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, c(e, t)
            }
            var s = function(e) {
                function t() {
                    for (var t, o = arguments.length, n = new Array(o), r = 0; r < o; r++) n[r] = arguments[r];
                    return (t = e.call.apply(e, [this].concat(n)) || this).notification = void 0, t
                }
                var o, r;
                r = e, (o = t).prototype = Object.create(r.prototype), o.prototype.constructor = o, c(o, r);
                var s = t.prototype;
                return s.componentDidMount = function() {
                    if (e.prototype.componentDidMount.call(this), "string" != typeof this.getParameter("notification")) {
                        var t = this.getParameter("notification");
                        t && (this.notification = (0, n.A)(t))
                    }
                }, s.notifyHandler = function() {
                    var e;
                    this.notification instanceof i.z5N && "string" == typeof(null == (e = this.notification) ? void 0 : e.getId()) && a.A.getInstance().notificationHandled(this.notification.getId())
                }, t
            }(r.A);
            t.A = s
        },
        73648: function(e, t, o) {
            o(52675), o(45700), o(2008), o(51629), o(89572), o(2892), o(67945), o(84185), o(83851), o(81278), o(79432), o(26099), o(98992), o(54520), o(3949), o(23500);
            var n = o(46942),
                r = o.n(n),
                a = o(28244),
                i = o(74848);

            function c(e, t) {
                var o = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), o.push.apply(o, n)
                }
                return o
            }

            function s(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? c(Object(o), !0).forEach((function(t) {
                        l(e, t, o[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : c(Object(o)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t))
                    }))
                }
                return e
            }

            function l(e, t, o) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var o = e[Symbol.toPrimitive];
                        if (void 0 !== o) {
                            var n = o.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = o, e
            }
            t.A = function(e) {
                var t = e.linkAppstore,
                    o = e.imageSrc,
                    n = e.jsClass,
                    c = e.a11y,
                    l = r()({
                        "badge-appstore": !0
                    }, n);
                return (0, i.jsx)(a.A, s(s({}, t), {}, {
                    className: l,
                    children: (0, i.jsx)("img", {
                        className: "badge-appstore__image",
                        src: o,
                        alt: c.label
                    })
                }))
            }
        },
        80878: function(e, t, o) {
            o.r(t), o.d(t, {
                default: function() {
                    return Ae
                }
            });
            o(28706), o(10287);
            var n, r = o(58385),
                a = o(56368),
                i = o(51265),
                c = o(96540),
                s = o(31709),
                l = o(74389),
                u = o(93529),
                d = o(79860),
                p = (o(62062), o(26099), o(98992), o(81454), o(40075)),
                m = (o(52675), o(45700), o(2008), o(51629), o(89572), o(2892), o(67945), o(84185), o(83851), o(81278), o(79432), o(54520), o(3949), o(23500), o(69020)),
                f = o(47901),
                x = o(87184),
                v = o(11734),
                g = o(4571),
                T = o(46770),
                _ = o(40578),
                b = o(27895),
                A = o(30784),
                y = o(20017),
                h = o(32483),
                O = o(26914),
                k = o(31023),
                E = o(8483),
                P = o(85608),
                j = o(93827),
                N = o(36693),
                I = o(74026),
                S = o(74848);

            function C(e, t) {
                var o = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), o.push.apply(o, n)
                }
                return o
            }

            function w(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? C(Object(o), !0).forEach((function(t) {
                        B(e, t, o[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : C(Object(o)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t))
                    }))
                }
                return e
            }

            function B(e, t, o) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var o = e[Symbol.toPrimitive];
                        if (void 0 !== o) {
                            var n = o.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = o, e
            }
            var R = ((n = {})[P.T.ATTENTION_BOOST] = "default", n[P.T.BUNDLE_SALE] = "default", n[P.T.CHAT_WITH_NEWBIES] = "default", n[P.T.CHAT_WITH_TIRED] = "default", n[P.T.CRUSH] = "revenue", n[P.T.EXTRA_SHOWS] = "default", n[P.T.GET_VERIFIED] = "default", n[P.T.LIKED_YOU] = "default", n[P.T.QUESTIONS_IN_PROFILE] = "default", n[P.T.RISEUP] = "default", n[P.T.SPECIAL_DELIVERY] = "revenue", n[P.T.SPP] = "revenue", n[P.T.UNDO_VOTE] = "revenue", n[P.T.LIKED_YOU_PREMIUM_PLUS] = "default", n),
                U = function(e) {
                    var t, o, n = e.avatars,
                        r = e.hasSameSignificance,
                        a = e.zeroEncounters,
                        i = e.gender;
                    return t = 1 === n.length ? "single" : "triple", o = r ? "m-m-m" : "s-m-s", n.length ? (0, S.jsx)(b.A, {
                        children: (0, S.jsx)("div", {
                            style: {
                                position: "relative"
                            },
                            children: (0, S.jsx)(k.A, {
                                layout: t,
                                variant: o,
                                children: n.map((function(e, o) {
                                    var n = "single" === t ? "md" : void 0,
                                        r = {};
                                    e.src && (r.photo = {
                                        src: e.src
                                    }), i && (r.gender = i);
                                    var a = e.badgeName ? {
                                        position: "bc",
                                        icon: {
                                            name: e.badgeName,
                                            size: "lg"
                                        }
                                    } : void 0;
                                    return (0, S.jsx)(O.A, {
                                        size: n,
                                        user: r,
                                        badge: a
                                    }, o)
                                }))
                            })
                        })
                    }) : a ? (0, S.jsx)(b.A, {
                        size: "icon",
                        children: (0, S.jsx)(E.A, {
                            name: "badge-encounters"
                        })
                    }) : null
                },
                D = function(e, t) {
                    return {
                        "data-action-type": (t = w(w({}, e), t)).actionType,
                        "data-activation-place": t.activationPlace,
                        "data-button-name": t.buttonName,
                        "data-cost": t.cost,
                        "data-feature-type": t.featureType,
                        "data-from": t.from,
                        "data-notification-id": t.notificationId,
                        "data-product-type": t.productType,
                        "data-promo-block-type": t.promoBlockType,
                        "data-provider-type": t.providerType,
                        "data-has-extra-shows": t.hasExtraShows,
                        "data-redirect-page": t.redirectPage,
                        "data-sharing-picture": t.sharingPicture,
                        "data-user-id": t.userId
                    }
                },
                L = function(e, t, o) {
                    void 0 === o && (o = !1);
                    var n, r = w(w({}, e), t);
                    return n = r.isPremiumPlus ? "continue-premium-button" : o ? "close-button" : "continue-button", {
                        "data-qa-button": o && !r.isPremiumPlus ? "secondary" : r.featureName,
                        "data-qa": n
                    }
                },
                M = function(e) {
                    var t, o = e.featureName,
                        n = e.buttons,
                        r = e.hideCloseButton,
                        a = e.extrasText,
                        i = e.hasExtraShows,
                        s = e.isTwoTiersAvailable,
                        l = e.onBackClick,
                        u = e.onClick,
                        d = null == (t = n[1]) ? void 0 : t.isPremiumPlus,
                        f = {
                            0: s && null != a && a.inBetweenText || d ? "secondary" : "primary",
                            1: s && null != a && a.inBetweenText || d ? "primary" : "secondary",
                            2: "tertiary"
                        };
                    return n.length <= 2 && r && (f[1] = "tertiary"), (0, S.jsxs)(T.A, {
                        children: [n.map((function(t, n) {
                            if (0 === n) {
                                var l = void 0 !== o ? function(e, t) {
                                    if (t || P.T.LIKED_YOU_PREMIUM_PLUS !== e) return R[e]
                                }(o, i) : void 0;
                                return (0, S.jsxs)(c.Fragment, {
                                    children: [(0, S.jsx)(y.A, {
                                        semantic: f[n],
                                        styling: l,
                                        text: t.actionText,
                                        extraAttrs: D(e, t),
                                        dataQA: L(e, t),
                                        extraClass: "js-action",
                                        onClick: function() {
                                            return u(t)
                                        }
                                    }, "button-" + n), s && null != a && a.inBetweenText ? (0, S.jsx)(N.A, {
                                        top: "sm",
                                        children: (0, S.jsx)(I.A, {
                                            text: null == a ? void 0 : a.inBetweenText
                                        })
                                    }) : null]
                                }, n)
                            }
                            return (0, S.jsxs)(c.Fragment, {
                                children: [null != a && a.offerText ? (0, S.jsx)(N.A, {
                                    top: "sm",
                                    bottom: "sm",
                                    children: (0, S.jsx)(j.P2, {
                                        children: null == a ? void 0 : a.offerText
                                    })
                                }) : null, r ? (0, S.jsx)(y.A, {
                                    semantic: f[n],
                                    text: t.actionText,
                                    extraAttrs: D(e, t),
                                    dataQA: L(e, t, !0),
                                    extraClass: "js-navigation js-action",
                                    onClick: function() {
                                        return u(t)
                                    }
                                }, "button-" + n) : (0, S.jsx)(y.A, {
                                    semantic: f[n],
                                    text: t.actionText,
                                    extraAttrs: D(e, t),
                                    dataQA: L(e, t, !0),
                                    extraClass: "js-action",
                                    onClick: function() {
                                        return u(t)
                                    }
                                }, "button-" + n)]
                            }, n)
                        })), r ? null : (0, S.jsx)(y.A, {
                            semantic: "tertiary",
                            text: p.Ay.get(650),
                            extraAttrs: {
                                "data-action": m.A.CLOSE
                            },
                            dataQA: L(e, {}, !0),
                            extraClass: "js-navigation",
                            onClick: function() {
                                return l()
                            }
                        })]
                    })
                },
                F = function(e) {
                    var t = e.titleText,
                        o = e.messageText,
                        n = e.costOfService;
                    return (0, S.jsxs)(f.A, {
                        children: [(0, S.jsx)(x.A, {
                            hpadded: !0,
                            vpadded: !0,
                            align: "center",
                            children: (0, S.jsxs)(g.A, {
                                children: [(0, S.jsx)(U, {
                                    avatars: e.hasOneAvatar ? e.avatars.slice(0, 1) : e.avatars,
                                    hasSameSignificance: e.hasSameSignificance,
                                    zeroEncounters: e.zeroEncounters,
                                    gender: e.gender
                                }), (0, S.jsx)(_.A, {
                                    text: t,
                                    tag: "h1"
                                }), (0, S.jsx)(A.A, {
                                    text: o
                                }), (0, S.jsx)(M, w(w({}, e), {}, {
                                    featureName: e.featureName,
                                    buttons: e.buttons,
                                    hideCloseButton: e.hideCloseButton
                                }))]
                            })
                        }), n ? (0, S.jsx)(v.A, {
                            hpadded: !0,
                            vpadded: !0,
                            children: (0, S.jsx)(h.A, {
                                children: n
                            })
                        }) : null]
                    })
                },
                K = function(e) {
                    var t, o = e.titleText,
                        n = e.messageText,
                        r = e.costOfService,
                        a = e.buttons;
                    return (0, S.jsxs)(f.A, {
                        children: [(0, S.jsx)(x.A, {
                            hpadded: !0,
                            vpadded: !0,
                            align: "center",
                            children: (0, S.jsxs)(g.A, {
                                children: [(0, S.jsx)(b.A, {
                                    size: "icon",
                                    children: (0, S.jsx)(E.A, {
                                        name: "badge-feature-invisible-mode"
                                    })
                                }), (0, S.jsx)(_.A, {
                                    text: (0, S.jsx)("span", {
                                        className: "qa-title",
                                        children: o
                                    }),
                                    tag: "h1"
                                }), (0, S.jsx)(A.A, {
                                    text: (0, S.jsx)("span", {
                                        className: "qa-message",
                                        children: n
                                    })
                                }), (0, S.jsxs)(T.A, {
                                    children: [a.map((function(t, o) {
                                        return (0, S.jsx)(y.A, {
                                            styling: "revenue",
                                            text: t.actionText,
                                            extraAttrs: D(e, t),
                                            dataQA: L(e, t, !1),
                                            extraClass: "js-action"
                                        }, "button-" + o)
                                    })), (0, S.jsx)(y.A, {
                                        semantic: "tertiary",
                                        text: p.Ay.get(650),
                                        extraAttrs: {
                                            "data-action": null == (t = e.NAVIGATION_BUTTONS) ? void 0 : t.CLOSE
                                        },
                                        extraClass: "js-navigation"
                                    })]
                                })]
                            })
                        }), r ? (0, S.jsx)(v.A, {
                            hpadded: !0,
                            vpadded: !0,
                            children: (0, S.jsx)(h.A, {
                                children: r
                            })
                        }) : null]
                    })
                },
                G = o(47632),
                H = o(51634),
                z = function(e) {
                    var t, o, n = e.imageUrl,
                        r = e.providerType,
                        a = e.titleText,
                        i = e.messageText,
                        c = e.empathizedText,
                        s = e.cancelActionText,
                        l = e.buttons,
                        u = e.PROVIDER_TYPES,
                        d = e.onBackClick,
                        p = e.onClick;
                    switch (n && (t = {
                        photo: {
                            src: G.A.getImageUrlForSize(n, 100)
                        }
                    }), r) {
                        case u.FACEBOOK:
                            o = {
                                icon: "badge-provider-facebook"
                            };
                            break;
                        case u.VKONTAKTE:
                            o = {
                                icon: "badge-provider-vkontakte"
                            };
                            break;
                        case u.ODNOKLASSNIKI:
                            o = {
                                icon: "badge-provider-odnoklassniki"
                            };
                            break;
                        case u.GOOGLE:
                            o = {
                                icon: "badge-provider-google"
                            };
                            break;
                        case u.TWITTER:
                            o = {
                                icon: "badge-provider-twitter"
                            };
                            break;
                        case u.INSTAGRAM:
                            o = {
                                icon: "badge-provider-instagram"
                            };
                            break;
                        case u.LINKEDIN:
                            o = {
                                icon: "badge-provider-linkedin"
                            };
                            break;
                        default:
                            o = {}
                    }
                    return (0, S.jsx)(f.A, {
                        children: (0, S.jsx)(x.A, {
                            hpadded: !0,
                            vpadded: !0,
                            align: "center",
                            children: (0, S.jsxs)(g.A, {
                                children: [(0, S.jsx)(b.A, {
                                    children: (0, S.jsx)(O.A, {
                                        size: "md",
                                        user: t,
                                        badge: o.icon ? {
                                            icon: {
                                                name: o.icon
                                            }
                                        } : void 0
                                    })
                                }), (0, S.jsx)(_.A, {
                                    text: a,
                                    tag: "h1"
                                }), (0, S.jsx)(A.A, {
                                    text: i
                                }), (0, S.jsx)(H.A, {
                                    children: (0, S.jsx)(j.P1, {
                                        weight: "bolder",
                                        color: "gray-80",
                                        breakWords: !0,
                                        children: c
                                    })
                                }), (0, S.jsxs)(T.A, {
                                    children: [l.map((function(t, o) {
                                        return (0, S.jsx)(y.A, {
                                            styling: "revenue",
                                            text: t.actionText,
                                            extraAttrs: D(e, t),
                                            dataQA: L(e, t, !1),
                                            extraClass: "js-action",
                                            onClick: function() {
                                                return p(t)
                                            }
                                        }, "button-" + o)
                                    })), (0, S.jsx)(y.A, {
                                        semantic: "tertiary",
                                        text: s,
                                        extraClass: "js-navigation",
                                        onClick: d,
                                        extraAttrs: {
                                            "data-action": "CLOSE"
                                        }
                                    })]
                                })]
                            })
                        })
                    })
                },
                V = o(73648),
                X = function(e) {
                    var t = e.src,
                        o = e.titleText,
                        n = e.messageText,
                        r = e.linkAppstore,
                        a = e.appstoreImage,
                        i = e.onBackClick;
                    return (0, S.jsx)(f.A, {
                        children: (0, S.jsx)(x.A, {
                            hpadded: !0,
                            vpadded: !0,
                            align: "center",
                            children: (0, S.jsxs)(g.A, {
                                children: [(0, S.jsx)(b.A, {
                                    children: (0, S.jsx)(O.A, {
                                        size: "md",
                                        image: {
                                            src: G.A.getImageUrlForSize(t, 100)
                                        },
                                        badge: {
                                            icon: {
                                                name: "badge-video"
                                            }
                                        }
                                    })
                                }), (0, S.jsx)(_.A, {
                                    text: o,
                                    tag: "h1"
                                }), (0, S.jsx)(A.A, {
                                    text: n
                                }), (0, S.jsxs)(T.A, {
                                    children: [(0, S.jsx)(V.A, {
                                        jsClass: "js-app-store",
                                        imageSrc: a.src,
                                        linkAppstore: r,
                                        a11y: {
                                            label: a.label
                                        }
                                    }), (0, S.jsx)(y.A, {
                                        semantic: "tertiary",
                                        text: p.Ay.get(451),
                                        extraAttrs: {
                                            "data-action": m.A.CLOSE
                                        },
                                        dataQA: {
                                            "data-qa": "dismiss"
                                        },
                                        extraClass: "js-navigation",
                                        onClick: i
                                    })]
                                })]
                            })
                        })
                    })
                },
                W = function(e) {
                    var t = e.title,
                        o = e.buttons,
                        n = e.onBackClick,
                        r = e.onClick;
                    return (0, S.jsx)("div", {
                        className: "promo-card promo-card--survey",
                        children: (0, S.jsxs)("div", {
                            className: "promo-card__inner",
                            children: [(0, S.jsx)("button", {
                                className: "promo-card__close js-action",
                                "data-promo-block-type": e.promoBlockType,
                                "data-dismiss": !0,
                                onClick: n,
                                children: (0, S.jsx)(E.A, {
                                    name: "generic-close",
                                    size: "md",
                                    a11y: {
                                        label: p.Ay.get(270)
                                    }
                                })
                            }), (0, S.jsxs)("div", {
                                className: "promo-card__content",
                                children: [(0, S.jsx)("div", {
                                    className: "promo-card__title",
                                    children: (0, S.jsx)(j.Zb, {
                                        align: "center",
                                        tag: "h1",
                                        children: t
                                    })
                                }), o.map((function(t) {
                                    return (0, S.jsx)("div", {
                                        className: "promo-card__action",
                                        children: (0, S.jsx)("button", {
                                            className: "promo-card__button js-action",
                                            "data-answer-id": t.id,
                                            "data-promo-block-type": e.promoBlockType,
                                            onClick: function() {
                                                return r(t)
                                            },
                                            children: (0, S.jsx)(j.P1, {
                                                children: t.text
                                            })
                                        }, t.id)
                                    })
                                }))]
                            })]
                        })
                    })
                },
                q = o(19049),
                Y = o(13614),
                J = {
                    FACEBOOK: 1,
                    VKONTAKTE: 2,
                    ODNOKLASSNIKI: 3,
                    GOOGLE: 4,
                    TWITTER: 15,
                    INSTAGRAM: 12,
                    LINKEDIN: 14
                },
                Q = function(e) {
                    var t = e.data,
                        o = e.externalUrl,
                        n = e.hasExtraShows,
                        r = e.productMode,
                        a = e.src,
                        i = e.isTwoTiersAvailable,
                        c = e.onBackClick,
                        s = e.onClick,
                        l = t.avatars,
                        u = t.buttons,
                        d = t.cancelActionText,
                        p = t.costOfService,
                        m = t.empathizedText,
                        f = t.hideCloseButton,
                        x = t.imageUrl,
                        v = t.messageText,
                        g = t.mode,
                        T = t.promoBlockType,
                        _ = t.providerType,
                        b = t.titleText,
                        A = (0, Y.Je)();
                    switch (r || g) {
                        case q.J.INVISIBLE_MODE:
                            return (0, S.jsx)(K, {
                                buttons: u,
                                messageText: v,
                                titleText: b
                            });
                        case q.J.NICE_NAME:
                            return (0, S.jsx)(z, {
                                buttons: u,
                                cancelActionText: d,
                                empathizedText: m,
                                imageUrl: x,
                                messageText: v,
                                providerType: _,
                                titleText: b,
                                onBackClick: c,
                                onClick: s,
                                PROVIDER_TYPES: J
                            });
                        case q.J.VIDEO_CHAT_EXPLANATION:
                            return (0, S.jsx)(X, {
                                appstoreImage: A,
                                linkAppstore: {
                                    href: o,
                                    target: "_blank",
                                    onClick: c
                                },
                                messageText: v,
                                titleText: b,
                                src: a,
                                onBackClick: c
                            });
                        case q.J.USER_SURVEY:
                            return (0, S.jsx)(W, {
                                buttons: u,
                                title: b,
                                onClick: s,
                                onBackClick: c
                            });
                        default:
                            return (0, S.jsx)(F, {
                                avatars: l,
                                buttons: u,
                                costOfService: p,
                                hideCloseButton: f,
                                messageText: v,
                                promoBlockType: T,
                                titleText: b,
                                hasExtraShows: n,
                                isTwoTiersAvailable: i,
                                onBackClick: c,
                                onClick: s
                            })
                    }
                },
                Z = o(18084),
                $ = o(51438),
                ee = o(15566);

            function te(e, t, o, n) {
                (0, d.sx)(138, {
                    banner_id: e,
                    position_id: t,
                    context: o,
                    variation_id: n
                })
            }

            function oe(e, t, o, n) {
                (0, d.sx)(139, {
                    banner_id: e,
                    position_id: t,
                    context: o,
                    variation_id: n,
                    call_to_action_type: 1
                })
            }

            function ne(e, t) {
                var o = e.promo_block;
                new s.Ay(278, {
                    promo_banner_stats: {
                        event: t,
                        promo_block_type: null == o ? void 0 : o.promo_block_type,
                        promo_block_position: null == o ? void 0 : o.promo_block_position,
                        variant_id: null == o ? void 0 : o.variant_id
                    }
                }).request()
            }
            o(88431), o(15086), o(23215), o(37550);
            var re = o(72537),
                ae = o(73090),
                ie = o(26172);

            function ce(e) {
                var t, o, n, a = re.A.getSync(19),
                    i = e.clientNotification,
                    c = e.prePurchaseInfo,
                    s = e.promoBlock,
                    l = e.isTwoTiersAvailable,
                    u = e.productMode,
                    d = ie.A.getDataFromCorrectSource({
                        clientNotification: i,
                        prePurchaseInfo: c,
                        promoBlock: s,
                        isTwoTiersAvailable: l
                    }),
                    p = d.avatars;
                if (d.hasBadges = p.some((function(e) {
                        return !!e.badgeName
                    })), d.hasSameSignificance = p.every((function(e) {
                        return e.significance === p[0].significance
                    })), d.hasOneAvatar = 1 === p.length, d.gender = (0, Y.v4)(null == (t = ae.A.getUser()) ? void 0 : t.gender), d.from = r.A.getUrl(), d.sppEnabled = a.enabled, s && d.featureType && (d.hotPanelPaymentFlowId = (n = (o = s).ok_payment_product_type, (0, $.Im)(null, n, 77, {
                        credits_cost: o.payment_amount || 0,
                        promo_option: !0
                    }))), 326 === d.promoBlockType && (d.avatars[1].badgeName = "badge-feature-liked-you", d.hideCloseButton = !0), 48 === d.promoBlockType && (d.zeroEncounters = !0), 107 === d.promoBlockType) {
                    var m, f, x = null == i || null == (m = i.promo_block) || null == (m = m.survey) || null == (m = m.questions) ? void 0 : m[0];
                    d.mode = q.J.USER_SURVEY, d.titleText = (null == x ? void 0 : x.question_text) || "", d.buttons = (null == x || null == (f = x.answers) ? void 0 : f.map((function(e) {
                        return {
                            id: e.answer_id,
                            text: e.answer_text
                        }
                    }))) || []
                }
                return u === q.J.MMG_PROMO && (d.buttons = d.buttons.filter((function(e) {
                    return 1 === e.type
                }))), d
            }
            var se, le, ue = o(25093),
                de = o(41298),
                pe = o(26935),
                me = o(3208),
                fe = o(64058),
                xe = Z.A.getLogger("PromotionPage"),
                ve = function(e) {
                    var t = e.activationPlace,
                        o = e.externalUrl,
                        n = e.notification,
                        i = e.productMode,
                        p = e.prePurchaseInfo,
                        m = e.promoBlock,
                        f = e.src,
                        x = e.userId,
                        v = e.hasExtraShows,
                        g = e.isTwoTiersAvailable,
                        T = (0, c.useMemo)((function() {
                            return ce({
                                clientNotification: n,
                                prePurchaseInfo: p,
                                promoBlock: m,
                                isTwoTiersAvailable: g,
                                productMode: i
                            })
                        }), [n, m, p, g, i]);
                    (0, c.useEffect)((function() {
                        i === q.J.MMG_PROMO && ((0, d.sx)(258, {
                            element: 14
                        }), (0, d.sx)(150, {
                            promo_screen: 84
                        }), ne(n, 2))
                    }), [n, i]), (0, c.useEffect)((function() {
                        switch (T.promoBlockType) {
                            case 326:
                                te(null == m ? void 0 : m.promo_block_type, null == m ? void 0 : m.promo_block_position, 3);
                                break;
                            case 48:
                                te(null == m ? void 0 : m.promo_block_type, null == m ? void 0 : m.promo_block_position, null == m ? void 0 : m.context, 1);
                                break;
                            case 107:
                            case 195:
                                te(null == m ? void 0 : m.promo_block_type, null == m ? void 0 : m.promo_block_position, null == m ? void 0 : m.context, null == m ? void 0 : m.stats_variation_id);
                                break;
                            case 165:
                                (0, d.sx)(332, {
                                    element: 288,
                                    parent_element: 14
                                }), (0, d.sx)(244, {
                                    promo_screen: 84
                                })
                        }
                    }), [T, m]);
                    var _ = function() {
                            i === q.J.MMG_PROMO && ((0, d.sx)(332, {
                                element: 65,
                                parent_element: 14
                            }), ne(n, 4)), r.A.back(), a.A.getInstance().enableTooltips(a.A.BLOCKER_TYPES.PROMO)
                        },
                        b = function() {
                            var e = T.featureType,
                                o = T.cost,
                                n = T.from,
                                r = T.productType;
                            if (e) {
                                var a = {
                                    activationPlace: t,
                                    cost: o,
                                    existingPaymentFlowId: T.hotPanelPaymentFlowId,
                                    feature: e,
                                    promoBlockType: null == m ? void 0 : m.promo_block_type
                                };
                                pe.A.purchase({
                                    back: n,
                                    cost: o,
                                    featureType: e,
                                    hotPanelData: a,
                                    popState: !0,
                                    productType: r,
                                    userId: x,
                                    paymentTransitionInFlow: !0,
                                    complete: function(e, t, o) {
                                        e && null != o && o.isOneClickPayment ? _() : t || function(e) {
                                            e && (0, ue.A)(e) && xe.error(e);
                                            e instanceof de.k || (u.A.showNotification({
                                                type: u.A.TYPES.ERROR
                                            }), _())
                                        }()
                                    }
                                })
                            } else xe.error("Invalid feature type")
                        },
                        A = function(e) {
                            var o = e.actionType,
                                n = e.redirectPage,
                                r = e.productType,
                                a = T.cost,
                                i = T.from,
                                c = {
                                    action: o,
                                    activationPlace: t,
                                    banner: null == m ? void 0 : m.promo_block_type,
                                    cost: a,
                                    popState: !0,
                                    productType: r,
                                    paymentTransitionInFlow: !0
                                };
                            n && (c.redirectPage = function(e) {
                                return (new ee.gGJ).setRedirectPage(e)
                            }(n)), P.A.handlePromoSelected(c, {
                                from: i
                            })
                        };
                    return T ? (0, S.jsx)("div", {
                        className: i,
                        children: (0, S.jsx)(Q, {
                            data: T,
                            externalUrl: o,
                            hasExtraShows: v,
                            productMode: i,
                            src: f,
                            isTwoTiersAvailable: g,
                            onBackClick: function() {
                                107 === T.promoBlockType && ne(n, 4), T.hotPanelPaymentFlowId && (0, $.Np)(T.hotPanelPaymentFlowId, $.QO.CANCELLED), _()
                            },
                            onClick: function(e) {
                                var t, o, a, i, c, p, f, x = e.actionType;
                                if (me.A.generate(), T.buttonName && (0, d.sx)(38, {
                                        button_name: T.buttonName
                                    }), 326 === T.promoBlockType && oe(null == m ? void 0 : m.promo_block_type, null == m ? void 0 : m.promo_block_position, 3), 195 === T.promoBlockType) {
                                    var v = n.promo_block;
                                    return oe(null == v ? void 0 : v.promo_block_type, null == v ? void 0 : v.promo_block_position, null == v ? void 0 : v.context), void r.A.navigate(l.x.SECURITY_WALKTHROUGH_REDIRECT, {
                                        securityWalkthroughSource: l.x.ENCOUNTERS
                                    })
                                }
                                if (107 === T.promoBlockType) return c = e.id, new s.Ay(450, {
                                    context: 45,
                                    answers: [{
                                        question_id: 0,
                                        answer_id: c || 0
                                    }]
                                }).request(), oe(null == n || null == (t = n.promo_block) ? void 0 : t.promo_block_type, null == n || null == (o = n.promo_block) ? void 0 : o.promo_block_position, null == n || null == (a = n.promo_block) ? void 0 : a.context, null == n || null == (i = n.promo_block) ? void 0 : i.stats_variation_id), _();
                                switch (x) {
                                    case 60:
                                        p = T.notificationId, f = T.providerType, new s.Ay(402, {
                                            value: p
                                        }).onResponse(387, (function(e) {
                                            e && u.A.showNotification({
                                                type: u.A.TYPES.ERROR
                                            })
                                        })).request(), f && (0, d.sx)(153, {
                                            social_media: fe.A[f]
                                        }), _();
                                        break;
                                    case 9:
                                        b();
                                        break;
                                    case 77:
                                    case 20:
                                        _();
                                        break;
                                    default:
                                        A(e)
                                }
                            }
                        })
                    }) : null
                },
                ge = o(63826),
                Te = ((se = {})[l.x.ATTENTION_BOOST_REMINDER] = 209, se[l.x.EXTRA_SHOWS_REMINDER] = 69, se[l.x.RISE_UP_REMINDER] = 70, se[l.x.NICE_NAME] = 118, se[l.x.EXTRA_SHOWS_EXPLANATION] = 208, se[l.x.CRUSH_EXPLANATION] = 181, se[l.x.RISEUP_EXPLANATION] = 70, se[l.x.INVISIBLE_EXPLANATION] = 117, se[l.x.MESSENGER_MINI_GAME_PROMO] = 496, se[l.x.ENCOUNTERS_EXTRA_SHOWS] = 143, se[l.x.EXTRA_SHOWS_EXPLANATION_VISITING_SOURCE] = 205, se[l.x.RISE_UP_EXPLANATION_VISITING_SOURCE] = 205, se[l.x.ATTENTION_BOOST_EXPLANATION_VISITING_SOURCE] = 205, se[l.x.ATTENTION_BOOST_EXPLANATION] = 204, se[l.x.VIDEO_CHAT_EXPLANATION] = 541, se[l.x.BUNDLE_SALE_EXPLANATION] = 204, se[l.x.NEW_USER_SUBSTITUTE] = 11, se[l.x.GET_MORE_LIKES] = 143, se[l.x.VOTE_QUOTA_REACHED] = 125, se);
            (le = {})[69] = 76, le[70] = 133, le[209] = 723;

            function _e(e, t) {
                return _e = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, _e(e, t)
            }
            var be = function(e) {
                    function t() {
                        for (var t, o = arguments.length, n = new Array(o), a = 0; a < o; a++) n[a] = arguments[a];
                        return (t = e.call.apply(e, [this].concat(n)) || this).getScreenName = function() {
                            var e = r.A.getLocation().routeName;
                            return Te[e] || 204
                        }, t.notificationScreenAccess = 3, t
                    }
                    var o, n;
                    n = e, (o = t).prototype = Object.create(n.prototype), o.prototype.constructor = o, _e(o, n);
                    var i = t.prototype;
                    return i.componentDidMount = function() {
                        a.A.getInstance().disableTooltips(a.A.BLOCKER_TYPES.PROMO)
                    }, i.componentWillUnmount = function() {
                        a.A.getInstance().enableTooltips(a.A.BLOCKER_TYPES.PROMO)
                    }, i.render = function() {
                        var e = this.getParameters(),
                            t = e.activationPlace,
                            o = e.externalUrl,
                            n = e.hasExtraShows,
                            r = e.notification,
                            a = e.promoBlock,
                            i = e.prePurchaseInfo,
                            c = e.src,
                            s = e.userId,
                            l = this.props.config,
                            u = l.productMode,
                            d = l.qaAttribute,
                            p = (0, ge.X)();
                        return this.addPageWrapper((0, S.jsx)(ve, {
                            activationPlace: t,
                            externalUrl: o,
                            notification: r,
                            productMode: u,
                            prePurchaseInfo: i,
                            promoBlock: a,
                            src: c,
                            userId: s,
                            hasExtraShows: n,
                            isTwoTiersAvailable: p
                        }), "overlay-page", {
                            "data-qa-page": d
                        })
                    }, t
                }(i.A),
                Ae = be
        }
    }
]);
//# sourceMappingURL=8497.fcfefaa92881a491065b.js.map
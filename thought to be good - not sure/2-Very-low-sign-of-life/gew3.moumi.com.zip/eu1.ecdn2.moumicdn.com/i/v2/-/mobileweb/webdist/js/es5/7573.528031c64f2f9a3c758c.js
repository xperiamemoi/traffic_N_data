"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [7573], {
        13380: function(e, t, n) {
            var o;
            n.d(t, {
                    p: function() {
                        return o
                    }
                }),
                function(e) {
                    e.TABBAR = "TABBAR", e.CONNECTIONS = "CONNECTIONS", e.PNB = "PNB", e.INTERSTITIAL = "INTERSTITIAL", e.CHAT = "CHAT", e.PROFILE = "PROFILE"
                }(o || (o = {}))
        },
        13927: function(e, t, n) {
            n.d(t, {
                J: function() {
                    return a
                }
            });
            n(51629), n(23418), n(26099), n(47764), n(98992), n(3949), n(23500);
            var o = n(99417),
                r = n(53010),
                i = n(79860),
                a = {
                    HAS_TABBAR: "has-tabbar",
                    HAS_TABBAR_BANNER: "has-tabbar-banner"
                },
                u = !1;

            function c(e) {
                var t;
                e && !u && (0, i.sx)(258, {
                    element: 60
                });
                var n = (null == (t = document.getElementById("tabbar")) ? void 0 : t.getElementsByTagName("button")) || [];
                if (o.A.document) {
                    var c = o.A.document.body.classList;
                    e ? (Array.from(n).forEach((function(e) {
                        e.removeAttribute("aria-hidden"), e.removeAttribute("tabIndex")
                    })), c.add(a.HAS_TABBAR)) : (c.remove(a.HAS_TABBAR), Array.from(n).forEach((function(e) {
                        e.setAttribute("tabindex", "-1"), e.setAttribute("aria-hidden", "true")
                    }))), e && r.A.isEnabled() ? c.add(a.HAS_TABBAR_BANNER) : c.remove(a.HAS_TABBAR_BANNER)
                }
                u = e
            }
            t.A = {
                show: function() {
                    c(!0)
                },
                hide: function() {
                    c(!1)
                },
                isVisible: function() {
                    return u
                },
                getHeight: function() {
                    if (u) {
                        var e = 48;
                        return r.A.isEnabled() && (e += 50), e
                    }
                }
            }, r.A.enabledChangeEvent.subscribe((function() {
                c(u)
            }))
        },
        20175: function(e, t, n) {
            function o(e) {
                return e < 10 ? "0" + e : "" + e
            }

            function r(e, t) {
                void 0 === t && (t = !1);
                var n = Math.floor(e / 3600 % 24),
                    r = Math.floor(e / 60 % 60),
                    i = Math.floor(e % 60);
                return n || t ? n + ":" + o(r) + ":" + o(i) : o(r) + ":" + o(i)
            }

            function i(e) {
                var t = new Date(1e3 * e),
                    n = t.getHours(),
                    r = t.getMinutes();
                return o(n) + ":" + o(r)
            }
            n.d(t, {
                At: function() {
                    return r
                },
                Cp: function() {
                    return i
                }
            })
        },
        27384: function(e, t, n) {
            n.d(t, {
                j: function() {
                    return a
                }
            });
            var o, r = n(99417),
                i = "js-payments-overlay";

            function a() {
                return o || ((o = r.A.document.createElement("div")).className = i), o
            }
        },
        39329: function(e, t, n) {
            n.d(t, {
                U: function() {
                    return a
                }
            });
            var o = n(59777),
                r = n(74619),
                i = n(79860);

            function a(e, t) {
                var n = (0, o.HS)(e);
                t.addEventListener("mouseover", (function() {
                    var e = {
                        ad_placement: n.placement,
                        activation_place: (0, r.I)(),
                        ad_aggregator: 11,
                        element: n.element
                    };
                    (0, i.sx)(478, e)
                }))
            }
        },
        44851: function(e, t) {
            var n = {
                FATAL: 9,
                NON_FATAL: 10,
                OTHER: 12
            };
            t.A = {
                getType: function(e) {
                    return 10002 === e || e >= 9100 && e <= 9199 ? n.FATAL : 46 === e ? n.NON_FATAL : n.OTHER
                },
                TYPE: n
            }
        },
        53010: function(e, t, n) {
            n(2008), n(26099), n(38781), n(98992), n(54520);
            var o, r = n(99417),
                i = n(99306),
                a = n(28030),
                u = n(73090),
                c = n(54725),
                l = n(92778),
                s = n(39329),
                d = n(54009),
                f = n(59977),
                A = n(13380),
                b = (0, i.A)(),
                g = Math.random().toString(36).substring(2, 15),
                p = 0,
                m = [],
                v = {
                    placements: A.p,
                    init: function() {
                        c.A.init({
                            onSlotVisibilityChanged: d.g,
                            bidders: [l.A]
                        })
                    },
                    isEnabled: function() {
                        var e;
                        return Boolean(null == (e = a.A.getSettings()) ? void 0 : e.experimental_show_external_ads)
                    },
                    create: function(e) {
                        var t = g + "-" + p++ + "-" + e;
                        return m.push({
                            created: L(),
                            slotId: t,
                            placement: e,
                            bidders: {}
                        }), t
                    },
                    render: function() {
                        r.A.clearTimeout(o), u.A.isLoggedIn() && (o = r.A.setTimeout(B, 20))
                    },
                    refresh: function(e) {
                        u.A.isLoggedIn() && c.A.refresh(e)
                    },
                    destroy: function(e) {
                        c.A.destroy(e)
                    },
                    enabledChangeEvent: b.changeEvent
                };

            function B() {
                if (u.A.isLoggedIn()) {
                    var e = [],
                        t = L();
                    m = m.filter((function(n) {
                        var o = r.A.document.getElementById(n.slotId);
                        return o ? (e.push(n), (0, s.U)(n.placement, o), !1) : n.created + 1e4 > t
                    })), e.length && c.A.render(e)
                }
            }

            function E() {
                var e = v.isEnabled();
                b.setValue(e), e || c.A.destroyAll(), l.A.setEnabled(a.A.isDevFeatureEnabled(f.v.AMAZON_INTEGRATION))
            }

            function L() {
                var e;
                return null != (e = r.A.performance) && e.now ? r.A.performance.now() : Date.now()
            }
            E(), a.A.onChange(E), t.A = v
        },
        54009: function(e, t, n) {
            n.d(t, {
                g: function() {
                    return u
                }
            });
            var o = n(99417),
                r = n(59777),
                i = n(74619),
                a = n(79860);

            function u(e) {
                var t = e.slotId,
                    n = e.placement,
                    u = o.A.document.getElementById(t);
                if (u && null === u.getAttribute("data-viewed")) {
                    u.setAttribute("data-viewed", "");
                    var c = (0, r.HS)(n);
                    (0, a.sx)(475, {
                        activation_place: (0, i.I)(),
                        ad_placement: c.placement,
                        ad_aggregator: 11,
                        element: c.element
                    }), (0, a.sx)(258, {
                        element: c.element
                    })
                }
            }
        },
        54725: function(e, t, n) {
            n(52675), n(45700), n(2008), n(51629), n(62062), n(15086), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(16034), n(98992), n(54520), n(3949), n(81454), n(37550), n(23500);
            var o, r = n(99417),
                i = n(26359),
                a = n(59777),
                u = n(28030),
                c = n(17369),
                l = n(72526),
                s = n(73090),
                d = n(18084),
                f = n(59977);

            function A(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, o)
                }
                return n
            }

            function b(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? A(Object(n), !0).forEach((function(t) {
                        g(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : A(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function g(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var o = n.call(e, t || "default");
                            if ("object" != typeof o) return o;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var p = d.A.getLogger("ExternalAds#dfp");
            r.A.googletag = {
                cmd: []
            };
            var m, v = [],
                B = [],
                E = [],
                L = {
                    init: function(e) {
                        var t = e.bidders,
                            n = e.onSlotVisibilityChanged;
                        r.A.googletag.cmd.push(function(e) {
                            return function() {
                                var t = r.A.googletag.pubads();
                                if (t.enableLazyLoad({
                                        fetchMarginPercent: 100
                                    }), t.enableSingleRequest(), t.setForceSafeFrame(!0), u.A.isDevFeatureEnabled(f.v.NEW_COOKIES_CONSENT)) {
                                    var n = c.Ay.cookieSettings();
                                    null != n && n.analytics || t.setRequestNonPersonalizedAds(1)
                                }
                                r.A.googletag.enableServices(), t.addEventListener("slotVisibilityChanged", (function(t) {
                                    if (t.inViewPercentage > 0) {
                                        var n = t.slot.getAdUnitPath();
                                        e({
                                            slotId: t.slot.getSlotElementId(),
                                            placement: (0, a.z1)(n)
                                        })
                                    }
                                }))
                            }
                        }(n)), t && t.forEach((function(e) {
                            E.push(e.request)
                        }))
                    },
                    render: function(e) {
                        e.length && (0, i.k)("https://securepubads.g.doubleclick.net/tag/js/gpt.js", {
                            nonce: r.A._nonce
                        }).then((function() {
                            e.forEach((function(e) {
                                v.push(b(b({}, e), {}, {
                                    bidders: {}
                                }))
                            })), r.A.googletag.cmd.push((function() {
                                h()
                            }))
                        })).catch((function(e) {
                            console.log("Failed to load securepubs gpt script.", e)
                        }))
                    },
                    refresh: function(e) {
                        r.A.googletag.cmd.push((function() {
                            var t = B.filter((function(t) {
                                return t.placement === e
                            })).map((function(e) {
                                return e.slot
                            }));
                            t.length && r.A.googletag.pubads().refresh(t)
                        }))
                    },
                    destroy: function(e) {
                        r.A.googletag.cmd.push((function() {
                            var t = [];
                            B = B.filter((function(n) {
                                return n.placement !== e || (t.push(n.slot), !1)
                            })), t.length && r.A.googletag.destroySlots(t)
                        }))
                    },
                    destroyAll: function() {
                        var e;
                        null != (e = r.A.googletag) && e.destroySlots && (B = [], r.A.googletag.destroySlots())
                    }
                };

            function h() {
                function e(e) {
                    return !e
                }
                r.A.clearTimeout(m), r.A.googletag.pubadsReady ? v = v.filter((function(t) {
                    var n = (0, a.HS)(t.placement);
                    if (t.slot || (t.slot = r.A.googletag.defineSlot(n.unit, n.sizes, t.slotId).addService(r.A.googletag.pubads()), r.A.clearTimeout(o), o = r.A.setTimeout(_, 5e3), E.forEach((function(e) {
                            e(t, h)
                        }))), t.slot && !Object.values(t.bidders).some(e)) {
                        var i = (0, l.l)(),
                            u = s.A.isLoggedIn();
                        return i && u ? (r.A.googletag.display(t.slotId), B.push(t), !1) : (u || p.error("Attempt to load an ad in an incorrect state", {
                            isRouteWithAds: i,
                            isUserLoggedIn: u
                        }), !1)
                    }
                    return !0
                })) : m = r.A.setTimeout(h, 150)
            }

            function _() {
                v.forEach((function(e) {
                    e.bidders = {}
                })), h()
            }
            t.A = L
        },
        59777: function(e, t, n) {
            n.d(t, {
                HS: function() {
                    return b
                },
                z1: function() {
                    return A
                }
            });
            n(50113), n(51629), n(69085), n(79432), n(26099), n(98992), n(72577), n(3949), n(23500);
            var o, r, i, a, u = n(36721),
                c = n(13380),
                l = ((o = {})[c.p.TABBAR] = {
                    unit: "/21617135166/Badoo_ALL_MobileWeb/Badoo_MW_Banner_Below_Tab",
                    placement: 2,
                    element: 442,
                    sizes: [
                        [320, 50]
                    ]
                }, o[c.p.CONNECTIONS] = {
                    unit: "/21617135166/Badoo_ALL_MobileWeb/Badoo_MW_Connections",
                    placement: 1,
                    element: 439,
                    sizes: [
                        [320, 50]
                    ]
                }, o[c.p.PNB] = {
                    unit: "/21617135166/Badoo_ALL_MobileWeb/Badoo_MW_Banner_MREC_300x250",
                    placement: 1,
                    element: 439,
                    sizes: ["fluid", [300, 250]]
                }, o[c.p.INTERSTITIAL] = {
                    unit: "/21617135166/Badoo_ALL_MobileWeb/Badoo_MW_Int_320x480",
                    placement: 4,
                    element: 438,
                    sizes: ["fluid", [320, 480]],
                    noAmazon: !0
                }, o[c.p.CHAT] = {
                    unit: "/21617135166/Badoo_ALL_MobileWeb/Badoo_MW_Banner_Chat",
                    placement: 2,
                    element: 448,
                    sizes: [
                        [320, 50]
                    ]
                }, o[c.p.PROFILE] = {
                    unit: "/21617135166/Badoo_ALL_MobileWeb/Badoo_MW_Profile_Chat",
                    placement: 2,
                    element: 791,
                    sizes: [
                        [320, 50]
                    ]
                }, o),
                s = ((r = {})[c.p.TABBAR] = {
                    unit: "/21617135166/BadooLiteMobileWeb/BadooLite320x50Banner"
                }, r[c.p.CONNECTIONS] = {
                    unit: "/21617135166/BadooLiteMobileWeb/BadooLite320x50Banner"
                }, r[c.p.PNB] = {
                    unit: "/21617135166/BadooLiteMobileWeb/BadooLite300x250MRec"
                }, r[c.p.INTERSTITIAL] = {
                    unit: "/21617135166/BadooLiteMobileWeb/BadooLite320x480Interstitial"
                }, r[c.p.CHAT] = {
                    unit: "/21617135166/BadooLiteMobileWeb/BadooLite320x50Banner"
                }, r[c.p.PROFILE] = {
                    unit: "/21617135166/BadooLiteMobileWeb/BadooLite320x50Banner"
                }, r),
                d = ((i = {})[c.p.TABBAR] = {
                    unit: "/21617135166/1221/BadooLiteALLMobileWebHawei320x50"
                }, i[c.p.CONNECTIONS] = {
                    unit: "/21617135166/1221/BadooLiteALLMobileWebHawei320x50"
                }, i[c.p.PNB] = {
                    unit: "/21617135166/1221/BadooLiteALLMobileWebHawei300x250"
                }, i[c.p.INTERSTITIAL] = {
                    unit: "/21617135166/1221/BadooLiteALLMobileWebHawei320x480"
                }, i[c.p.CHAT] = {
                    unit: "/21617135166/1221/BadooLiteALLMobileWebHawei320x50"
                }, i[c.p.PROFILE] = {
                    unit: "/21617135166/1221/BadooLiteALLMobileWebHawei320x50"
                }, i);

            function f(e) {
                var t = l;
                return Object.keys(e).forEach((function(n) {
                    Object.assign(t[n], e[n])
                })), t
            }

            function A(e) {
                var t = g();
                return Object.keys(t).find((function(n) {
                    return t[n].unit === e
                }))
            }

            function b(e) {
                return g()[e]
            }

            function g() {
                return a || (a = u.A.isTWA() ? f(s) : u.A.isHuaweiQuickApp() ? f(d) : l)
            }
        },
        72526: function(e, t, n) {
            n.d(t, {
                l: function() {
                    return a
                }
            });
            n(50113), n(26099), n(11392);
            var o = n(58385),
                r = n(74389),
                i = [r.x.BLOCKED, r.x.CHAT, r.x.CHAT_PROFILE, r.x.CONNECTIONS, r.x.ENCOUNTERS, r.x.FANS, r.x.MESSAGES, r.x.OWN_PROFILE, r.x.PEOPLE_NEARBY, r.x.PROFILE, r.x.SHARE_PROFILE];

            function a() {
                return Boolean(i.find((function(e) {
                    return o.A.getUrl().startsWith(e)
                })))
            }
        },
        74619: function(e, t, n) {
            n.d(t, {
                I: function() {
                    return r
                }
            });
            var o = n(37905);

            function r() {
                var e = o.A.controller;
                return null != e && e.activationPlace ? e.activationPlace : 1
            }
        },
        88309: function(e, t, n) {
            var o, r = n(99417);
            t.A = function() {
                return o || ((o = r.A.document.createElement("div")).className = "modal-container"), o
            }
        },
        89730: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return a
                }
            });
            n(60739);
            var o = n(79860),
                r = n(44851),
                i = "mw_unknown_error";

            function a(e) {
                var t, n, a = e.error;
                "badoo.bma.ServerErrorMessage" === (null == a ? void 0 : a.$gpb) && (n = a.toJSON ? a.toJSON() : a);
                var u, c = (null == (t = n) ? void 0 : t.error_id) || i;
                e.isExpected ? u = 11 : e.isOther ? u = 12 : n && (u = r.A.getType(a.type)), (0, o.sx)(216, {
                    error_id: c,
                    error_type: "number" == typeof u ? u : void 0
                }), (0, o.bX)()
            }
        },
        92778: function(e, t, n) {
            n(23792), n(26099), n(3362), n(47764), n(62953);
            var o, r = n(99417),
                i = n(59777),
                a = "2b7a2c6a-d956-4404-a81d-a951ffbf26d6",
                u = !0,
                c = {
                    setEnabled: function(e) {
                        u = e
                    },
                    request: function(e, t) {
                        if (u) {
                            var c = (0, i.HS)(e.placement);
                            c.noAmazon || function() {
                                o || (o = new Promise((function(e) {
                                    n.e(8399).then(n.bind(n, 38399)).then((function() {
                                        r.A.apstag.init({
                                            pubID: a,
                                            adServer: "googletag"
                                        }), e()
                                    }))
                                })));
                                return o
                            }().then((function() {
                                e.bidders.amazon = !1;
                                var n = c.sizes,
                                    o = r.A.apstag;
                                o.fetchBids({
                                    slots: [{
                                        slotID: e.slotId,
                                        slotName: c.unit,
                                        sizes: [n[n.length - 1]]
                                    }]
                                }, (function() {
                                    r.A.googletag.cmd.push((function() {
                                        e.bidders.amazon = !0, o.setDisplayBids(), t()
                                    }))
                                }))
                            }))
                        }
                    }
                };
            t.A = c
        }
    }
]);
//# sourceMappingURL=7573.528031c64f2f9a3c758c.js.map
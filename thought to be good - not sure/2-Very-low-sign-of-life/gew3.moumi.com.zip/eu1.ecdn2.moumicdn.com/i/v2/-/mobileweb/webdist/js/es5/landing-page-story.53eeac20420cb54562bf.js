"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [852], {
        6642: function(e, t, n) {
            n.d(t, {
                x: function() {
                    return c
                }
            });
            n(52675), n(45700), n(2008), n(51629), n(60739), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(3949), n(23500);
            var r = n(28030),
                o = n(57564),
                i = n(31709);

            function a(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function u(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? a(Object(n), !0).forEach((function(t) {
                        l(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function l(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(e, t || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function c(e) {
                var t = e.data,
                    n = e.providerType,
                    a = e.flowData,
                    l = e.onArkoseDisabled,
                    c = e.onArkoseEnabled,
                    s = e.handleError,
                    f = e.setIsLoading;
                r.A.get().then((function(e) {
                    if ((0, o.x)(e, n)) {
                        var r = new i.Ay(1029, u(u({}, t), {}, {
                            auth_method: n,
                            screen_context: {
                                flow_id: a.flow_id,
                                screen_id: a.screen_id
                            }
                        }));
                        r.onResponse(1030, (function(e) {
                            ! function(e, t, n) {
                                e.skip_arkose ? t() : n(e.blob ? e.blob : "{}")
                            }(e, l, c)
                        })), r.onResponse(1, (function(e) {
                            ! function(e, t, n) {
                                n(!1), 10002 === e.type ? t(e.error_message) : 15 === e.type && i.aV.send(new i.XX(1, e).toJSON())
                            }(e, s, f)
                        })), r.request()
                    } else l()
                }))
            }
        },
        12632: function(e, t, n) {
            function r(e) {
                var t = e.metaKey || e.altKey || e.ctrlKey || e.shiftKey;
                return 0 === e.button && !t && (e.preventDefault(), !0)
            }
            n.d(t, {
                s: function() {
                    return r
                }
            })
        },
        14680: function(e, t, n) {
            var r = n(51709),
                o = n(79752),
                i = n(74848);
            t.A = function(e) {
                var t = e.label,
                    n = e.children,
                    a = e.errorMessage,
                    u = e.errorId,
                    l = e.hintMessage,
                    c = e.hintId,
                    s = e.hintIcon,
                    f = e.noteExtra,
                    d = e.dataQa,
                    p = e.fieldId,
                    v = e.tag,
                    g = a || f && !l ? {
                        text: a,
                        variant: "error",
                        extra: f,
                        id: u
                    } : void 0,
                    m = l || f && !a ? {
                        text: l,
                        extra: g ? void 0 : f,
                        id: c,
                        icon: s
                    } : void 0;
                return (0, i.jsx)(o.A, {
                    label: (0, r.Fi)(t),
                    status: g,
                    hint: m,
                    fieldId: p,
                    tag: v,
                    dataQA: d,
                    children: n
                })
            }
        },
        16230: function(e, t) {
            var n, r, o = ((n = {})[0] = 12, n[1] = 26, n[2] = 27, n[3] = 28, n[4] = 23, n[5] = 25, n),
                i = ((r = {})[0] = 12, r[1] = 28, r[5] = 25, r),
                a = {
                    getErrorFromFieldErrorType: function(e) {
                        return i[e] || 16
                    },
                    getErrorFieldValidationErrorType: function(e) {
                        return o[e] || 16
                    }
                };
            t.A = a
        },
        18194: function(e, t, n) {
            n(52675), n(45700), n(2008), n(51629), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(3949), n(23500);
            var r = n(96540),
                o = n(51709),
                i = n(40075),
                a = n(88163),
                u = n(14680),
                l = n(49755),
                c = n(74848);

            function s(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function f(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? s(Object(n), !0).forEach((function(t) {
                        d(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function d(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(e, t || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            t.A = function(e) {
                var t = (0, o.iD)(e),
                    n = t.a11y,
                    s = t.ids,
                    d = t.labelProps,
                    p = (0, r.useState)(e.countryCode.value),
                    v = p[0],
                    g = p[1],
                    m = (0, r.useState)(),
                    y = m[0],
                    b = m[1];
                (0, r.useEffect)((function() {
                    g(e.countryCode.value)
                }), [e.countryCode.value]), (0, r.useEffect)((function() {
                    var t = (0, l.Z)(v, e.countryCode.options);
                    b(null == t ? void 0 : t.selectedLabel)
                }), [v, e.countryCode.options]);
                var h = i.Ay.get(214),
                    x = i.Ay.get(215),
                    j = e.label ? e.label + ", " + h : h;
                return (0, c.jsx)(u.A, f(f(f({}, e), s), {}, {
                    children: (0, c.jsx)(a.A, {
                        countryCode: f(f({}, e.countryCode), {}, {
                            onChange: function(t) {
                                g(t.target.value), null == e.countryCode.onChange || e.countryCode.onChange(t)
                            },
                            value: v,
                            selectedLabel: y,
                            id: s.fieldId + "_code",
                            status: Boolean(e.errorMessage) || e.isInvalid ? "error" : void 0,
                            a11y: f(f({}, n), {}, {
                                label: j,
                                ariaRequired: d.ariaRequired || e.isRequired
                            })
                        }),
                        number: f(f(f({}, e.number), s), {}, {
                            status: Boolean(e.errorMessage) || e.isInvalid ? "error" : void 0,
                            autoComplete: "tel-national",
                            a11y: f(f({
                                inputLabel: x
                            }, n), {}, {
                                ariaRequired: d.ariaRequired || e.isRequired
                            })
                        })
                    })
                }))
            }
        },
        21204: function(e, t, n) {
            function r(e, t) {
                return "https://mlink." + e + "/aa/landto?install_ref=" + t
            }
            n.d(t, {
                A: function() {
                    return r
                }
            })
        },
        24412: function(e, t, n) {
            n(10287);

            function r(e, t) {
                return r = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, r(e, t)
            }
            var o = function(e) {
                function t() {
                    return e.call(this, {
                        set: {
                            message: 640,
                            response: 489
                        }
                    }, {
                        name: "ValidatePhoneNumber",
                        useCache: !1
                    }) || this
                }
                var n, o;
                return o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, r(n, o), t.getInstance = function() {
                    return t.instance || (t.instance = new t), t.instance
                }, t.prototype.validatePhoneNumber = function(e) {
                    var t = e.phonePrefix,
                        n = e.phone,
                        r = e.context,
                        o = e.countryId,
                        i = {};
                    return t && (i.phone_prefix = t), o && (i.country_id = o), n && (i.phone = n), r && (i.context = r), this.set(i)
                }, t
            }(n(6696).A);
            o.instance = void 0, t.A = o
        },
        28244: function(e, t, n) {
            n(52675), n(45700), n(2008), n(51629), n(74423), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(21699), n(98992), n(54520), n(3949), n(23500);
            var r = n(58385),
                o = n(12632),
                i = n(18084),
                a = n(99417),
                u = n(33926),
                l = n(74848),
                c = ["routeName", "routeParams", "href", "onClick", "dataQA", "children", "target", "preventNavigation"];

            function s(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function f(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? s(Object(n), !0).forEach((function(t) {
                        d(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function d(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(e, t || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var p = i.A.getLogger("RoutingAnchor");
            t.A = function(e) {
                var t, n = e.routeName,
                    i = e.routeParams,
                    s = e.href,
                    d = e.onClick,
                    v = e.dataQA,
                    g = e.children,
                    m = e.target,
                    y = e.preventNavigation,
                    b = function(e, t) {
                        if (null == e) return {};
                        var n = {};
                        for (var r in e)
                            if ({}.hasOwnProperty.call(e, r)) {
                                if (t.includes(r)) continue;
                                n[r] = e[r]
                            }
                        return n
                    }(e, c);
                n && (t = r.A.getAccessibleUrl({
                    routeName: n,
                    parameters: i
                })), t || s || d || p.error("RoutingAnchor is meaningless because neither accessible URL nor onClick exist", {
                    children: g,
                    routeName: n
                });
                var h = t || s ? "a" : "button",
                    x = f({
                        "data-qa": "routing-anchor"
                    }, v);
                return (0, l.jsxs)(h, f(f(f({
                    href: t || s,
                    onClick: function(e) {
                        var t = (0, o.s)(e);
                        null == d || d(), !y && t && (n ? r.A.navigate(n, i) : s && a.A.open(s, m || "_self"))
                    },
                    type: "button" === h ? "button" : void 0,
                    target: "a" === h ? m : void 0
                }, x), b), {}, {
                    children: [g, "a" === h && "_blank" === m ? (0, l.jsx)(u.A, {}) : null]
                }))
            }
        },
        33926: function(e, t, n) {
            n.d(t, {
                P: function() {
                    return a
                }
            });
            var r = n(84362),
                o = n(40075),
                i = n(74848);

            function a(e) {
                return e + '<span class="csms-a11y-visually-hidden"> ' + o.Ay.get(618) + "</span>"
            }
            t.A = function(e) {
                var t = e.children,
                    n = o.Ay.get(618);
                return (0, i.jsxs)(i.Fragment, {
                    children: [t, (0, i.jsx)(r.A, {
                        children: n
                    })]
                })
            }
        },
        47587: function(e, t, n) {
            n.r(t), n.d(t, {
                default: function() {
                    return T
                }
            });
            var r = n(96540),
                o = (n(60739), n(31709)),
                i = n(57864),
                a = n(17414),
                u = n(97748),
                l = n(79860),
                c = n(16230),
                s = n(18084),
                f = n(52864),
                d = n(93529),
                p = n(40068),
                v = n(91133),
                g = n(5322),
                m = n(86451),
                y = n(57981),
                b = n(51709),
                h = n(93827),
                x = n(36693),
                j = n(87184),
                O = n(20017),
                A = n(89162),
                _ = n(66130),
                C = n(8483),
                k = n(73616),
                P = n(84932),
                w = n(74848),
                S = function(e) {
                    var t = e.title,
                        n = e.text,
                        r = e.inputLabel,
                        o = e.primaryButtonText,
                        i = e.secondaryButtonText,
                        a = e.privacyInfoText,
                        u = e.emailValue,
                        l = e.isButtonDisabled,
                        c = e.isLoading,
                        s = e.errorMessage,
                        f = e.onEmailChange,
                        d = e.onSubmit,
                        p = e.onSignupWithPhone;
                    return (0, w.jsx)(j.A, {
                        hpadded: !0,
                        vpadded: !0,
                        children: (0, w.jsxs)(k.A, {
                            onSubmit: function(e) {
                                return (0, b.Y4)(e, (function() {
                                    return d(u)
                                }))
                            },
                            isFixed: !0,
                            children: [(0, w.jsx)(h.Zb, {
                                tag: "h1",
                                children: t
                            }), (0, w.jsx)(x.A, {
                                top: "md",
                                children: (0, w.jsx)(A.A, {
                                    text: n
                                })
                            }), (0, w.jsxs)(x.A, {
                                top: "md",
                                children: [(0, w.jsx)(P.A, {
                                    preset: "email",
                                    fieldId: "signin-name",
                                    value: u,
                                    label: r,
                                    errorMessage: s,
                                    spellCheck: !1,
                                    onChange: function(e) {
                                        f(e.target.value)
                                    }
                                }), (0, w.jsx)(O.A, {
                                    semantic: "tertiary",
                                    text: i,
                                    onClick: p
                                })]
                            }), (0, w.jsxs)(_.A, {
                                children: [(0, w.jsx)(x.A, {
                                    top: "lg",
                                    bottom: "md",
                                    children: (0, w.jsxs)(h.P2, {
                                        color: "gray-80",
                                        align: "center",
                                        children: [(0, w.jsx)("span", {
                                            style: {
                                                display: "inline-block",
                                                marginRight: "8px"
                                            },
                                            children: (0, w.jsx)(C.A, {
                                                name: "generic-lock",
                                                size: "sm"
                                            })
                                        }), (0, w.jsx)("span", {
                                            children: a
                                        })]
                                    })
                                }), (0, w.jsx)(O.A, {
                                    isDisabled: l || "" === u,
                                    text: o,
                                    isLoading: c,
                                    buttonAttrs: {
                                        type: "submit"
                                    }
                                })]
                            })]
                        })
                    })
                },
                E = n(57564),
                D = "";
            var N = {
                    get: function() {
                        return D
                    },
                    set: function(e) {
                        D = e
                    }
                },
                I = n(6642),
                L = s.A.getLogger("PasswordlessOnboardingEmail");
            var R = function() {
                    var e, t, n = (0, r.useState)(N.get()),
                        s = n[0],
                        b = n[1],
                        h = (0, r.useState)(""),
                        x = h[0],
                        j = h[1],
                        O = (0, r.useState)(!1),
                        A = O[0],
                        _ = O[1],
                        C = (0, r.useState)(!1),
                        k = C[0],
                        P = C[1],
                        D = (0, r.useState)(null),
                        R = D[0],
                        T = D[1],
                        M = (0, r.useRef)(null),
                        B = (0, r.useRef)(!1),
                        F = (0, p.A)(y.dm, 127),
                        q = F[0],
                        V = q.header,
                        z = q.subHeader,
                        Q = q.secondaryCta,
                        H = q.cta,
                        U = q.privacyInfo,
                        G = q.inputLabel,
                        X = (0, F[1])(H.children, y.c6),
                        W = (0, v.G)(127),
                        Y = (0, r.useContext)(g.P),
                        J = Y.handleCallToActionClick,
                        K = Y.getFlowData;
                    (0, r.useEffect)((function() {
                        (0, l.sx)(49, {
                            screen_name: 88
                        })
                    }), []), (0, r.useEffect)((function() {
                        W(2)
                    }), [W]);
                    var $ = (0, r.useCallback)((function(e) {
                        _(!1), j(e)
                    }), []);
                    var Z = (0, r.useCallback)((function(e) {
                            _(!0), new o.Ay(694, {
                                screen_context: {
                                    screen_id: String(127),
                                    flow_id: a.wq.FLOW_BADOO_REGISTRATION
                                },
                                email_address: s,
                                subscribe_to_marketing: e
                            }).onResponse(687, (function(e) {
                                _(!1), o.aV.send(new i.XX(687, e).toJSON()), H.call_to_action && J(H.call_to_action)
                            })).onResponse(1, (function(e) {
                                _(!1), 10002 === e.type ? j(e.error_message) : 15 === e.type ? o.aV.send(new i.XX(1, e).toJSON()) : e.error_message && (j(e.error_message), d.A.showNotification({
                                    type: d.A.TYPES.ERROR
                                }))
                            })).onError((function(e) {
                                _(!1), j("Error"), d.A.showNotification({
                                    type: d.A.TYPES.ERROR
                                })
                            })).request()
                        }), [H.call_to_action, s, J]),
                        ee = (0, r.useCallback)((function(e) {
                            M.current = e, M.current.run()
                        }), []),
                        te = (0, r.useCallback)((function(e) {
                            _(!1), M.current = e || null, e ? e.run() : Z(B.current)
                        }), [_, Z]),
                        ne = (0, r.useCallback)((function() {
                            _(!1), T(null)
                        }), [_]),
                        re = (0, r.useCallback)((function() {
                            Z(B.current)
                        }), [Z]);

                    function oe() {
                        (0, I.x)({
                            data: {
                                email: s
                            },
                            providerType: 18,
                            flowData: K(),
                            onArkoseDisabled: function() {
                                Z(B.current)
                            },
                            onArkoseEnabled: function(e) {
                                T(e)
                            },
                            handleError: $,
                            setIsLoading: _
                        })
                    }
                    return (0, w.jsxs)(w.Fragment, {
                        children: [(0, w.jsx)(S, {
                            title: null == V ? void 0 : V.text,
                            text: null == z ? void 0 : z.text,
                            inputLabel: null == G ? void 0 : G.text,
                            primaryButtonText: null == H || null == (e = H.call_to_action) ? void 0 : e.text,
                            secondaryButtonText: null == Q || null == (t = Q.call_to_action) ? void 0 : t.text,
                            privacyInfoText: null == U ? void 0 : U.text,
                            emailValue: s,
                            isButtonDisabled: !1,
                            isLoading: A,
                            errorMessage: x,
                            onEmailChange: function(e) {
                                b(e)
                            },
                            onSubmit: function(e) {
                                var t;
                                W(1), b(e), t = e, N.set(t), _(!0), f.A.getInstance().getValidateUserField({
                                    field_type: 10,
                                    value: t,
                                    context: 108
                                }).then((function(e) {
                                    _(!0), e && function(e) {
                                        var t = !e.valid;
                                        if (t) {
                                            var n = e.error_message || "",
                                                r = c.A.getErrorFieldValidationErrorType(e.error_type);
                                            ! function(e, t) {
                                                (0, l.sx)(125, {
                                                    event_type: 5,
                                                    field_name: 7,
                                                    error_type: t,
                                                    error_message: 12 === t ? e : void 0
                                                })
                                            }(n, r), (0, u.n)() && 28 === r && L.error("Error in registration while validating the email", {
                                                email: s,
                                                isLoggedIn: !1
                                            }), j(n)
                                        } else P(!0), (0, l.sx)(20, {
                                            alert_type: 55,
                                            activation_place: 66,
                                            action_type: 12
                                        })
                                    }(e)
                                }))
                            },
                            onSignupWithPhone: function() {
                                J(Q.call_to_action)
                            }
                        }), k ? (0, w.jsx)(m.A, {
                            header: null == X ? void 0 : X.title.text,
                            message: null == X ? void 0 : X.subtitle.text,
                            primaryLabel: null == X ? void 0 : X.accept.text,
                            cancelLabel: null == X ? void 0 : X.decline.text,
                            isVisible: !0,
                            onConfirm: function() {
                                P(!1), _(!0), B.current = !0, oe()
                            },
                            onCancel: function() {
                                P(!1), _(!0), B.current = !1, oe()
                            },
                            onAnimationOutComplete: function() {
                                P(!1)
                            }
                        }) : null, R ? (0, w.jsx)(E.A, {
                            authMethod: 18,
                            blob: R,
                            flowData: K(),
                            onArkoseReady: ee,
                            onArkoseUnavailable: te,
                            onArkoseComplete: re,
                            onErrorClosed: ne
                        }) : null]
                    })
                },
                T = function(e) {
                    var t = e.setScreenName;
                    return (0, r.useEffect)((function() {
                        t(88)
                    }), [t]), (0, w.jsx)(R, {})
                }
        },
        49476: function(e, t, n) {
            n.r(t), n.d(t, {
                default: function() {
                    return we
                }
            });
            var r = n(96540),
                o = n(99417),
                i = n(77409),
                a = n(47832),
                u = (n(10287), n(65297)),
                l = n(69705),
                c = n(79860),
                s = n(40075),
                f = n(39778),
                d = n(74848);
            l.A.PLACE_LANDING, l.A.PLACE_ENCOUNTERS, l.A.PLACE_CHAT;

            function p(e, t) {
                (0, c.sx)(47, {
                    permission_type: 2,
                    permission_granted: e,
                    activation_place: t
                })
            }
            var v = function(e) {
                return (0, r.useEffect)((function() {
                    var t;
                    e.isShown && (t = e.activationPlace, (0, c.sx)(20, {
                        alert_type: 7,
                        activation_place: t
                    }))
                }), [e.isShown, e.activationPlace]), e.isShown ? (0, d.jsx)(f.A, {
                    message: s.Ay.get(984),
                    isOpen: !0,
                    onConfirm: function() {
                        l.A.userWantsPushes(e.place).then((function(t) {
                            p(t, e.activationPlace), e.onClose()
                        }))
                    },
                    onCancel: function() {
                        l.A.userDeniesPushes(e.place), p(!1, e.activationPlace), e.onClose()
                    }
                }) : null
            };

            function g(e, t) {
                return g = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, g(e, t)
            }
            var m = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).handleCloseNotificationPermissions = function() {
                            n.setState({
                                showNotificationPermission: !1
                            })
                        }, n.onPushNotificationsInit = function() {
                            l.A.inited && void 0 === l.A.getCurrentChoice(l.A.PLACE_LANDING) && n.setState({
                                showNotificationPermission: !0
                            })
                        }, n.state = {
                            showNotificationPermission: !1
                        }, n
                    }
                    var n, r;
                    r = e, (n = t).prototype = Object.create(r.prototype), n.prototype.constructor = n, g(n, r);
                    var o = t.prototype;
                    return o.componentDidMount = function() {
                        l.A.inited ? this.onPushNotificationsInit() : u.A.once(u.A.SW_INITED, this.onPushNotificationsInit, this)
                    }, o.render = function() {
                        return (0, d.jsx)(v, {
                            isShown: this.state.showNotificationPermission,
                            place: l.A.PLACE_LANDING,
                            activationPlace: 367,
                            onClose: this.handleCloseNotificationPermissions
                        })
                    }, t
                }(r.Component),
                y = n(26035),
                b = (n(50113), n(26099), n(98992), n(72577), n(59599)),
                h = n(3508),
                x = n(71363),
                j = n(73090),
                O = n(55105),
                A = n(57660),
                _ = n(54643),
                C = n(73160),
                k = n(73155),
                P = n(93827),
                w = function(e) {
                    var t = (0, k.B2)(),
                        n = e.termsLink,
                        r = e.privacyLink;
                    return (0, d.jsx)("div", {
                        className: "landing-tnc",
                        children: (0, d.jsx)(P.P3, {
                            tag: "span",
                            align: "center",
                            color: "black",
                            children: (0, d.jsx)(C.A, {
                                text: t.get(61, {
                                    terms_url: "terms_link",
                                    privacy_url: "privacy_link"
                                }),
                                routingMapping: {
                                    terms_link: n,
                                    privacy_link: r
                                },
                                className: "landing-tnc__text"
                            })
                        })
                    })
                },
                S = n(54109),
                E = function() {
                    var e = S.FS.linkTerms,
                        t = S.FS.linkPrivacy;
                    return (0, d.jsx)(w, {
                        termsLink: e,
                        privacyLink: t
                    })
                },
                D = (n(52675), n(45700), n(2008), n(51629), n(62062), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(54520), n(3949), n(81454), n(23500), n(28244));

            function N(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function I(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? N(Object(n), !0).forEach((function(t) {
                        L(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : N(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function L(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(e, t || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var R, T = function(e) {
                    var t = e.links,
                        n = e.showExtraLinks,
                        o = e.seoLinks,
                        i = e.onClickLanguage,
                        a = e.onClickSEOLink,
                        u = (0, k.B2)(),
                        l = "badoo" === h.A.get("partner_id") ? u.get(89) : u.get(49);
                    return (0, d.jsxs)("ul", {
                        className: "landing-links",
                        children: [t.linkCookiePolicy ? (0, d.jsx)("li", {
                            className: "landing-links__list-item",
                            children: "href" in t.linkCookiePolicy ? (0, d.jsx)(D.A, I(I({}, t.linkCookiePolicy), {}, {
                                className: "landing-links__item",
                                id: "gdpr_link",
                                children: (0, d.jsx)(P.P3, {
                                    tag: "span",
                                    children: l
                                })
                            })) : (0, d.jsx)("button", {
                                onClick: t.linkCookiePolicy.onClick,
                                className: "landing-links__item",
                                id: "gdpr_link",
                                type: "button",
                                children: (0, d.jsx)(P.P3, {
                                    tag: "span",
                                    children: l
                                })
                            })
                        }) : null, t.linkImpressum ? (0, d.jsx)("li", {
                            className: "landing-links__list-item",
                            children: (0, d.jsx)(D.A, I(I({}, t.linkImpressum), {}, {
                                className: "landing-links__item",
                                id: "impressum_link",
                                children: (0, d.jsx)(P.P3, {
                                    tag: "span",
                                    children: "Impressum"
                                })
                            }))
                        }) : null, n ? (0, d.jsxs)(r.Fragment, {
                            children: [t.linkHelp ? (0, d.jsx)("li", {
                                className: "landing-links__list-item",
                                children: (0, d.jsx)(D.A, I(I({}, t.linkHelp), {}, {
                                    className: "landing-links__item",
                                    children: (0, d.jsx)(P.P3, {
                                        tag: "span",
                                        children: u.get(465)
                                    })
                                }))
                            }) : null, t.linkSafetyCentre ? (0, d.jsx)("li", {
                                className: "landing-links__list-item",
                                children: (0, d.jsx)(D.A, I(I({}, t.linkSafetyCentre), {}, {
                                    className: "landing-links__item",
                                    children: (0, d.jsx)(P.P3, {
                                        tag: "span",
                                        children: u.get(137)
                                    })
                                }))
                            }) : null, i ? (0, d.jsx)("li", {
                                className: "landing-links__list-item",
                                children: (0, d.jsx)("button", {
                                    className: "landing-links__item",
                                    onClick: i,
                                    children: (0, d.jsx)(P.P3, {
                                        tag: "span",
                                        children: u.get(598)
                                    })
                                })
                            }) : null, null == o ? void 0 : o.map((function(e, t) {
                                return (0, d.jsx)("li", {
                                    className: "landing-links__list-item",
                                    children: (0, d.jsx)(D.A, {
                                        href: e.link,
                                        onClick: function() {
                                            return null == a ? void 0 : a(e.type)
                                        },
                                        className: "landing-links__item",
                                        children: (0, d.jsx)(P.P3, {
                                            tag: "span",
                                            children: e.text
                                        })
                                    })
                                }, "seo-link-" + t)
                            }))]
                        }) : null, t.linkCcpa ? (0, d.jsx)("li", {
                            className: "landing-links__list-item",
                            children: (0, d.jsx)("button", {
                                onClick: t.linkCcpa.onClick,
                                className: "landing-links__item",
                                id: "ccpa_link",
                                type: "button",
                                children: (0, d.jsx)(P.P3, {
                                    tag: "span",
                                    children: u.get(88)
                                })
                            })
                        }) : null]
                    })
                },
                M = function(e) {
                    var t = e.seoLinks,
                        n = e.onClickLanguage,
                        r = e.showExtraLinks;
                    return (0, d.jsx)(T, {
                        seoLinks: t,
                        links: S.FS,
                        showExtraLinks: r,
                        onClickLanguage: function() {
                            o.A.scrollTo(0, 0), (0, S.uT)(), null == n || n()
                        },
                        onClickSEOLink: S.Op
                    })
                },
                B = n(92669),
                F = (n(15086), n(27495), n(5746), n(37550), n(4279)),
                q = n(11141),
                V = n(11733),
                z = n(21204),
                Q = n(67471),
                H = n(28030),
                U = ((R = {})[8] = F.O.IOS, R[9] = F.O.ANDROID, R[11] = F.O.WINDOWS_PHONE, R);

            function G(e, t) {
                var n = function(e) {
                    var t = H.A.getSettings(),
                        n = null == t ? void 0 : t.external_endpoints;
                    return null == n ? void 0 : n.some((function(t) {
                        var n = t.type,
                            r = t.url,
                            o = function(e) {
                                return e ? U[e] : void 0
                            }(n) === e,
                            i = Boolean(r);
                        return o && i
                    }))
                }(t);
                return n ? function(e, t, n, r) {
                    var o = n.utm_source,
                        i = n.utm_campaign,
                        a = n.gclid;
                    return "googleadwords" === o && 100 === e ? "http://badoo.onelink.me/1368615218?pid=googleadwords_int&c=" + i + "&af_c_id=" + i + "&gclid=" + a : (0, z.A)(t, r)
                }(h.A.get(x.O.APP_PRODUCT_TYPE), h.A.get(x.O.PARTNER_URL), (0, Q.L)(o.A.location.search.substring(1)), e) : ""
            }

            function X(e) {
                var t = G(B.i6, e);
                if (t) return {
                    href: t,
                    onClick: function() {
                        e === F.O.ANDROID ? (0, c.sx)(332, {
                            element: 692
                        }) : e === F.O.IOS ? (0, c.sx)(332, {
                            element: 691
                        }) : e === F.O.WINDOWS_PHONE && (0, c.sx)(332, {
                            element: 693
                        }), (0, q.A)(V.T.APP_BANNER_GET_APP)
                    },
                    target: "_blank"
                }
            }
            var W, Y, J, K, $ = n(91133),
                Z = function(e, t) {
                    var n;
                    void 0 === e && (e = void 0);
                    var r = null == (n = e) ? void 0 : n.children;
                    if (r) return r.filter((function(e) {
                        var t, n;
                        return 73 !== (null == (t = e.call_to_action) ? void 0 : t.action) || 1 !== (null == (n = e.call_to_action) || null == (n = n.external_provider) ? void 0 : n.type)
                    })).map((function(e) {
                        var n, r, o, i, a = (null == (n = e.call_to_action) || null == (n = n.external_provider) ? void 0 : n.type) || (null == (r = e.call_to_action) ? void 0 : r.external_provider_type);
                        return {
                            text: e.call_to_action.text,
                            type: a,
                            onClick: (o = t, i = a, function() {
                                return o(i)
                            }),
                            dataQa: B.TM[a],
                            size: B.bt[a]
                        }
                    }))
                },
                ee = (n(23418), n(94490), n(47764), n(95917)),
                te = n(47901),
                ne = n(36631),
                re = n(87184),
                oe = n(36693),
                ie = n(73648),
                ae = n(20017),
                ue = n(66130),
                le = n(8323),
                ce = n(73616);

            function se(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function fe(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? se(Object(n), !0).forEach((function(t) {
                        de(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : se(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function de(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(e, t || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var pe = ((W = {})[39] = "generic-provider-apple", W[1] = "generic-provider-facebook", W[4] = "generic-provider-google-color", W[40] = "generic-phone", W[18] = "generic-message", W[42] = "generic-passkey", W),
                ve = ((Y = {})[39] = "apple", Y[1] = "facebook", Y[9] = "google", Y[40] = "inverse", Y[18] = "inverse", Y),
                ge = ((J = {})[39] = "apple", J[1] = "facebook", J[9] = "google", J[40] = "default", J[18] = "default", J),
                me = ((K = {})[39] = "primary", K[1] = "primary", K[9] = "primary", K[40] = "secondary", K[18] = "secondary", K),
                ye = function(e) {
                    var t = e.product,
                        n = e.appStoreBadgeImage,
                        o = e.linkAppstore,
                        i = e.showExtraLinks,
                        a = e.landingLinks,
                        u = e.tagline,
                        l = e.socialButtons,
                        c = e.loginButtons,
                        f = e.passkeyButton,
                        p = e.dividerText,
                        v = e.footer,
                        g = e.otherMethodsButton,
                        m = e.showOtherMethods,
                        y = e.isAnimatedButtonsInitial,
                        b = e.isControlGroup,
                        h = void 0 !== b && b,
                        x = (0, r.useState)(y),
                        j = x[0],
                        O = x[1],
                        A = (0, r.useRef)(null),
                        _ = (0, r.useRef)(null),
                        C = r.useState(0),
                        k = C[0],
                        w = C[1];
                    return (0, r.useEffect)((function() {
                        _.current && w(_.current.getBoundingClientRect().height)
                    }), []), (0, r.useEffect)((function() {
                        if (m && A.current) {
                            var e = 0,
                                t = Array.from(A.current.children);
                            A.current.style.height = k + "px", t.reverse().forEach((function(t) {
                                j && t.classList.add("animate"), t.style.bottom = e + "px", e += t.getBoundingClientRect().height + 12
                            })), j && A.current.classList.add("animate"), A.current.style.height = e - 12 + "px", O(!1)
                        }
                    }), [m, k, j, O]), (0, d.jsxs)(r.Fragment, {
                        children: [(0, d.jsx)(ee.A, {
                            product: t
                        }), (0, d.jsxs)(te.A, {
                            children: [(0, d.jsx)(ne.z, {
                                taglineText: u,
                                product: t,
                                isCompact: !1,
                                a11y: {
                                    hiddenHeader: s.Ay.get(717)
                                }
                            }), (0, d.jsx)(re.A, {
                                align: !h || p ? "bottom" : "center",
                                hpadded: !0,
                                children: (0, d.jsxs)(ce.A, {
                                    isFixed: !0,
                                    children: [(0, d.jsx)(oe.A, {
                                        top: "md"
                                    }), m && p ? (0, d.jsx)(P.P2, {
                                        align: "center",
                                        color: "black",
                                        children: p
                                    }) : null, (0, d.jsx)(ue.A, {
                                        children: (0, d.jsx)("div", {
                                            ref: _,
                                            children: (0, d.jsxs)(le.A, {
                                                children: [f && !m ? (0, d.jsx)(ae.A, {
                                                    icon: pe[42],
                                                    text: f.text,
                                                    onClick: f.onClick,
                                                    dataQA: {
                                                        "data-qa": f.dataQa
                                                    },
                                                    size: "medium"
                                                }) : null, m ? (0, d.jsxs)("div", {
                                                    className: "landing-passwordless__other-methods",
                                                    ref: A,
                                                    children: [c ? c.map((function(e) {
                                                        return (0, d.jsx)(ae.A, {
                                                            icon: pe[e.type],
                                                            styling: h ? ve[e.type] : ge[e.type],
                                                            semantic: h ? "primary" : me[e.type],
                                                            text: e.text,
                                                            onClick: e.onClick,
                                                            dataQA: {
                                                                "data-qa": e.dataQa
                                                            },
                                                            size: "medium"
                                                        }, "provider-button-" + e.type)
                                                    })) : null, l ? l.map((function(e) {
                                                        return (0, d.jsx)(ae.A, {
                                                            icon: pe[e.type],
                                                            styling: h ? ve[e.type] : ge[e.type],
                                                            semantic: h ? "primary" : me[e.type],
                                                            text: e.text,
                                                            onClick: e.onClick,
                                                            dataQA: {
                                                                "data-qa": e.dataQa
                                                            },
                                                            size: e.size
                                                        }, "provider-button-" + e.type)
                                                    })) : null]
                                                }) : null, g && !m ? (0, d.jsx)(ae.A, fe(fe({}, g), {}, {
                                                    semantic: "secondary"
                                                })) : null, (0, d.jsx)(oe.A, {
                                                    bottom: "md",
                                                    children: (0, d.jsx)(P.P3, {
                                                        color: "black",
                                                        children: v
                                                    })
                                                })]
                                            })
                                        })
                                    })]
                                })
                            }), i && n && o ? (0, d.jsx)(re.A, {
                                children: (0, d.jsx)(oe.A, {
                                    bottom: "md",
                                    top: "md",
                                    children: (0, d.jsx)(ie.A, {
                                        imageSrc: n.src,
                                        linkAppstore: o,
                                        a11y: {
                                            label: n.label
                                        }
                                    })
                                })
                            }) : null, a ? (0, d.jsx)(re.A, {
                                hpadded: !0,
                                children: (0, d.jsx)(oe.A, {
                                    top: "md",
                                    children: a
                                })
                            }) : null]
                        }), (0, d.jsx)("div", {
                            className: "overscrolling overscrolling--top"
                        }), (0, d.jsx)("div", {
                            className: "overscrolling overscrolling--bottom"
                        })]
                    })
                },
                be = n(57564),
                he = n(5322),
                xe = n(18483),
                je = n(13614),
                Oe = n(19232),
                Ae = n(40068),
                _e = n(57981),
                Ce = n(6642),
                ke = "passkey_buttons_shown",
                Pe = function(e) {
                    var t, n, i, a, u, l, s = e.setScreenName,
                        f = e.platform,
                        p = (e.isHostedApp, e.notificationPermission),
                        v = e.seoLinks,
                        g = (0, r.useContext)(he.P),
                        m = g.handleCallToActionClick,
                        y = g.getFlowData,
                        C = h.A.get(x.O.APP_PRODUCT_TYPE),
                        k = (0, r.useState)(!0),
                        P = k[0],
                        w = k[1],
                        S = (0, r.useState)(null),
                        D = S[0],
                        N = S[1],
                        I = (0, r.useState)(!1),
                        L = I[0],
                        R = I[1],
                        T = (0, r.useState)(null),
                        F = T[0],
                        q = T[1],
                        V = (0, r.useState)(!1),
                        z = V[0],
                        Q = V[1],
                        H = (0, r.useState)(!1),
                        U = H[0],
                        G = H[1],
                        W = (0, r.useState)(!1),
                        Y = W[0],
                        J = W[1],
                        K = (0, r.useState)(!1),
                        ee = K[0],
                        te = K[1],
                        ne = (0, r.useState)(!1),
                        re = ne[0],
                        oe = ne[1],
                        ie = (0, r.useRef)(null),
                        ae = (0, Ae.A)(_e.ji, 124),
                        ue = ae[0],
                        le = ae[1],
                        ce = (0, $.G)(124);
                    (0, r.useEffect)((function() {
                        ce(2)
                    }), [ce]), (0, r.useEffect)((function() {
                        ue && P && w(!1)
                    }), [ue, P]), (0, r.useEffect)((function() {
                        s(999)
                    }), [s]);
                    var se = (0, d.jsx)(M, {
                            seoLinks: v,
                            onClickLanguage: function() {
                                return R(!0)
                            },
                            showExtraLinks: !0
                        }),
                        fe = function() {
                            w(!1), N(null)
                        },
                        de = (0, r.useCallback)((function(e) {
                            ie.current = e, ie.current.run()
                        }), []),
                        pe = (0, r.useCallback)((function() {
                            w(!1), N(null), q(null)
                        }), []),
                        ve = (0, r.useCallback)((function(e) {
                            Oe.A.loginAsPromise({
                                providerType: e,
                                providerContext: 3,
                                needsAppLogin: !0
                            }).then((function() {
                                w(!1), N(null)
                            })).catch(fe)
                        }), []),
                        ge = (0, r.useCallback)((function(e) {
                            w(!1), ie.current = e || null, e ? e.run() : ve(D)
                        }), [w, ve, D]),
                        me = (0, r.useMemo)((function() {
                            var e;
                            return null != ue && null != (e = ue.passkey) && e.children ? le(ue.passkey.children, _e.V$) : void 0
                        }), [ue, le]),
                        Pe = (0, r.useMemo)((function() {
                            return me ? le(me.passkeyErrorDialog.children, _e.zx) : void 0
                        }), [me, le]),
                        we = function() {
                            (0, c.sx)(332, {
                                element: 2543
                            });
                            var e = y();
                            j.A.loginPasskey(107, {
                                flow_id: e.flow_id,
                                screen_id: e.screen_id
                            }).then((function() {
                                w(!1)
                            })).catch((function(e) {
                                if ("NotAllowedError" === e.name) return z || (0, c.sx)(49, {
                                    screen_option: 269
                                }), Q(!0), void J(!1);
                                (0, c.sx)(125, {
                                    error_type: 63,
                                    event_type: 11
                                }), oe(!0)
                            }))
                        },
                        Se = {
                            text: null == me || null == (t = me.signIn) || null == (t = t.call_to_action) ? void 0 : t.text,
                            type: 42,
                            dataQa: "passkeys-login",
                            size: "medium",
                            onClick: we
                        },
                        Ee = {
                            text: null == me || null == (n = me.otherMethods) ? void 0 : n.text,
                            type: 0,
                            dataQa: "show-other-methods",
                            size: "medium",
                            onClick: function() {
                                (0, c.sx)(332, {
                                    element: 382
                                }), (0, c.sx)(49, {
                                    screen_option: 268
                                }), Q(!0), J(!1), o.A.sessionStorage.setItem(ke, "true")
                            }
                        };
                    (0, r.useEffect)((function() {
                        b.Ay.hit()
                    }), []), (0, r.useEffect)((function() {
                        var e = null == me ? void 0 : me.signIn,
                            t = null == me ? void 0 : me.otherMethods;
                        if (e || t ? (o.A.sessionStorage.getItem(ke) ? Q(!0) : te(!0), e && G(!0), t && J(!0)) : Q(!0), null != me && me.passkeyErrorDialog) {
                            if (null != me && me.otherMethods) return void(0, c.sx)(49, {
                                screen_option: 267
                            });
                            if (null != me && me.signIn) return void(0, c.sx)(49, {
                                screen_option: 263
                            });
                            (0, c.sx)(49, {
                                screen_option: 266
                            })
                        }
                    }), [me]);
                    var De = function(e) {
                            if (w(!0), (0, c.sx)(332, {
                                    element: B.cC[e] || 174
                                }), 42 === e) return we(), void w(!1);
                            if (37 === e || 40 === e || 18 === e) {
                                var t, n, r, o;
                                if (void 0 === (r = null == (t = ue.lastSigned) || null == (t = t.children) ? void 0 : t.find((function(t) {
                                        var n;
                                        return (null == (n = t.call_to_action) ? void 0 : n.external_provider_type) === e
                                    })))) r = null == (o = ue.providers.children) ? void 0 : o.find((function(t) {
                                    var n;
                                    return (null == (n = t.call_to_action) ? void 0 : n.external_provider_type) === e
                                }));
                                return m(null == (n = r) ? void 0 : n.call_to_action), void w(!1)
                            }(0, Ce.x)({
                                providerType: e,
                                flowData: y(),
                                onArkoseDisabled: function() {
                                    ve(e)
                                },
                                onArkoseEnabled: function(t) {
                                    q(t), N(e)
                                },
                                handleError: fe,
                                setIsLoading: w
                            })
                        },
                        Ne = null != ue && null != (i = ue.tnc) && i.text ? (0, d.jsx)(E, {}) : null;
                    return (0, d.jsxs)(r.Fragment, {
                        children: [P ? (0, d.jsx)(O.A, {}) : (0, d.jsx)(ye, {
                            product: B.U4[C],
                            tagline: null == ue || null == (a = ue.tagline) ? void 0 : a.text,
                            appStoreBadgeImage: (0, je.Je)(),
                            linkAppstore: X(f),
                            passkeyButton: U ? Se : void 0,
                            socialButtons: Z(null == ue ? void 0 : ue.providers, De),
                            loginButtons: Z(null == ue ? void 0 : ue.lastSigned, De),
                            dividerText: null == ue || null == (u = ue.lastSigned) ? void 0 : u.text,
                            footer: null == ue || null == (l = ue.footer) ? void 0 : l.text,
                            landingLinks: (0, d.jsxs)(r.Fragment, {
                                children: [se, Ne]
                            }),
                            otherMethodsButton: Y ? Ee : void 0,
                            showOtherMethods: z,
                            isAnimatedButtonsInitial: ee,
                            isControlGroup: !b.Ay.isActive()
                        }), L ? (0, d.jsx)(A.A, {
                            languages: xe.A.getSupportedLanguages(),
                            selectedLanguageId: xe.A.getCurrentLanguageId(),
                            onClose: function() {
                                return R(!1)
                            },
                            onLanguageSelected: function(e) {
                                xe.A.redirect(e)
                            }
                        }) : null, p, D && F && (0, d.jsx)(be.A, {
                            authMethod: D,
                            blob: F,
                            flowData: y(),
                            onArkoseReady: de,
                            onArkoseUnavailable: ge,
                            onArkoseComplete: function() {
                                return ve(D)
                            },
                            onErrorClosed: pe
                        }), re && Pe && (0, d.jsx)(_.A, {
                            title: Pe.title.text,
                            text: Pe.subtitle.text,
                            isOpen: re,
                            primaryCta: {
                                text: Pe.primaryButton.text,
                                onClick: function() {
                                    (0, c.sx)(332, {
                                        element: 395,
                                        parent_element: 72
                                    }), oe(!1), we()
                                }
                            },
                            secondaryCta: {
                                text: Pe.secondaryButton.text,
                                onClick: function() {
                                    (0, c.sx)(332, {
                                        element: 725,
                                        parent_element: 72
                                    }), oe(!1), Q(!0)
                                }
                            },
                            onDismiss: function() {
                                (0, c.sx)(332, {
                                    element: 113,
                                    parent_element: 72
                                }), oe(!1)
                            }
                        })]
                    })
                },
                we = function(e) {
                    var t = e.setScreenName;
                    (0, r.useEffect)((function() {
                        a.A.hasSavedInfos() || (0, y.A)("Landing interactive", 14)
                    }), []);
                    var n = (0, r.useContext)(i.Ay),
                        u = n.device,
                        l = u.isTWA,
                        c = u.isHuaweiQuickApp,
                        s = u.platform,
                        f = n.interfaceLanguage,
                        p = l || c || Boolean(o.A.navigator.standalone),
                        v = l ? (0, d.jsx)(m, {}) : void 0;
                    return (0, d.jsx)(Pe, {
                        isHostedApp: p,
                        notificationPermission: v,
                        platform: s,
                        seoLinks: f.getCurrentLanguageSEOLinks(),
                        setScreenName: t
                    })
                }
        },
        49755: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return f
                }
            });
            n(52675), n(45700), n(2008), n(50113), n(51629), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(72577), n(3949), n(23500);
            var r = n(96540),
                o = n(51709),
                i = n(84395),
                a = n(14680),
                u = n(74848);

            function l(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function c(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? l(Object(n), !0).forEach((function(t) {
                        s(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : l(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function s(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(e, t || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function f(e, t) {
                return null == t ? void 0 : t.find((function(t) {
                    return String(e) === String(t.value)
                }))
            }
            t.A = 8792 == n.j ? function(e) {
                var t = (0, o.iD)(e),
                    n = t.a11y,
                    l = t.ids,
                    s = t.labelProps,
                    d = (0, r.useState)(e.value),
                    p = d[0],
                    v = d[1],
                    g = (0, r.useState)(),
                    m = g[0],
                    y = g[1];
                return (0, r.useEffect)((function() {
                    var t = f(p, e.options);
                    y(null == t ? void 0 : t.selectedLabel)
                }), [p, e.options]), (0, u.jsx)(a.A, c(c(c({}, e), l), {}, {
                    label: s.label,
                    children: (0, u.jsx)(i.A, c(c(c({}, e), l), {}, {
                        onChange: function(t) {
                            v(t.target.value), null == e.onChange || e.onChange(t)
                        },
                        selectedLabel: m,
                        value: p,
                        status: Boolean(e.errorMessage) || e.isInvalid ? "error" : void 0,
                        a11y: c(c({}, n), {}, {
                            ariaRequired: s.ariaRequired
                        })
                    }))
                }))
            } : null
        },
        51709: function(e, t, n) {
            n.d(t, {
                $E: function() {
                    return c
                },
                Fi: function() {
                    return u
                },
                JU: function() {
                    return d
                },
                Y4: function() {
                    return f
                },
                iD: function() {
                    return s
                }
            });
            n(52675), n(45700), n(2008), n(51629), n(25276), n(48598), n(62062), n(72712), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(27495), n(38781), n(98992), n(54520), n(3949), n(81454), n(8872), n(23500);
            var r = n(40075);

            function o(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function i(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? o(Object(n), !0).forEach((function(t) {
                        a(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function a(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(e, t || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function u(e) {
                return e && e.toUpperCase().indexOf("FIXME_LABEL") < 0 ? e : void 0
            }
            var l = {
                email: {
                    type: "email",
                    inputMode: "email",
                    spellCheck: !1,
                    autoCapitalize: "none",
                    autoCorrect: "off",
                    autoComplete: "username"
                },
                tel: {
                    type: "tel",
                    inputMode: "tel",
                    spellCheck: !1,
                    autoCapitalize: "none",
                    autoCorrect: "off",
                    autoComplete: "tel-national"
                },
                numeric: {
                    type: "text",
                    inputMode: "numeric",
                    spellCheck: !1,
                    autoCapitalize: "none",
                    autoCorrect: "off"
                },
                sms: {
                    type: "text",
                    inputMode: "numeric",
                    spellCheck: !1,
                    autoCapitalize: "none",
                    autoCorrect: "off",
                    autoComplete: "one-time-code"
                },
                "text-code": {
                    type: "text",
                    spellCheck: !1,
                    autoCapitalize: "none",
                    autoCorrect: "off",
                    autoComplete: "off"
                },
                password: {
                    type: "password",
                    spellCheck: !1,
                    autoCapitalize: "none",
                    autoCorrect: "off"
                },
                date: {
                    type: "date",
                    autoComplete: "bday",
                    autoCorrect: "off"
                },
                location: {
                    type: "text",
                    spellCheck: !0,
                    autoCapitalize: "none",
                    autoCorrect: "off",
                    autoComplete: "location"
                },
                "given-name": {
                    type: "text",
                    spellCheck: !1,
                    autoCapitalize: "words",
                    autoCorrect: "off",
                    autoComplete: "given-name"
                }
            };

            function c(e, t) {
                var n = t.type,
                    r = t.inputMode,
                    o = t.spellCheck,
                    a = t.autoCapitalize,
                    u = t.autoCorrect,
                    c = t.autoComplete;
                return i(i(i(i(i(i(i({}, e && l[e]), n && {
                    type: n
                }), r && {
                    inputMode: r
                }), o && {
                    spellCheck: o
                }), a && {
                    autoCapitalize: a
                }), u && {
                    autoCorrect: u
                }), c && {
                    autoComplete: c
                })
            }

            function s(e) {
                var t, n, o, a, u, l, c, s, f = e.a11y || {},
                    d = (t = e.fieldId, n = e.errorId, o = e.hintId, {
                        fieldId: t,
                        id: t,
                        errorId: n || t + "_error",
                        hintId: o || t + "_hint",
                        counterId: t + "_counter"
                    }),
                    p = (a = e.label, u = e.labelStatus, l = f.ariaRequired, s = l, (c = a) && "required" === u && (c = a + " " + r.Ay.get(211), s = !1), c && "optional" === u && (c = a + " " + r.Ay.get(210), s = !1), {
                        label: c,
                        ariaRequired: s
                    }),
                    v = [];
                return e.errorMessage && v.push(d.errorId), e.hintMessage && v.push(d.hintId), e.maxLengthCounter && v.push(d.counterId), {
                    a11y: i({
                        ariaDescribedby: v.join(" ") || void 0
                    }, f),
                    ids: d,
                    labelProps: p
                }
            }

            function f(e, t) {
                e.preventDefault(), t()
            }

            function d(e) {
                return void 0 === e && (e = ""), e.split("").map((function(e) {
                    return e.charCodeAt(0)
                })).reduce((function(e, t) {
                    return e + ((e << 7) + (e << 3)) ^ t
                })).toString(16)
            }
        },
        52864: function(e, t, n) {
            n(25276), n(10287), n(26099), n(3362);
            var r = n(6696);

            function o(e, t) {
                return o = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, o(e, t)
            }
            var i = [10, 200, 220, 20],
                a = function(e) {
                    function t() {
                        return e.call(this, {
                            get: {
                                message: 488,
                                response: 489
                            }
                        }, {
                            name: "ValidateUserField",
                            useCache: !1
                        }) || this
                    }
                    var n, r;
                    return r = e, (n = t).prototype = Object.create(r.prototype), n.prototype.constructor = n, o(n, r), t.getInstance = function() {
                        return t.instance || (t.instance = new t), t.instance
                    }, t.prototype.getValidateUserField = function(t) {
                        return void 0 === t.field_type || -1 === i.indexOf(t.field_type) ? Promise.resolve(null) : void 0 === t.value || null === t.value ? (this.log.error("Value for fieldType " + t.field_type + " can't be null or undefined"), Promise.resolve(null)) : e.prototype.get.call(this, t)
                    }, t
                }(r.A);
            a.instance = void 0, t.A = a
        },
        54109: function(e, t, n) {
            n.d(t, {
                Jg: function() {
                    return m
                },
                Fo: function() {
                    return p
                },
                Op: function() {
                    return b
                },
                FS: function() {
                    return y
                },
                uT: function() {
                    return g
                }
            });
            n(74423);
            var r, o = n(99417),
                i = n(74389),
                a = n(79860),
                u = n(28030),
                l = n(92669),
                c = (n(50113), n(26099), n(98992), n(72577), n(59977));
            ! function(e) {
                e.CCPA = "CCPA", e.GDPR = "GDPR"
            }(r || (r = {}));
            var s = function() {
                    var e, t = u.A.getDevFeature(c.v.NEW_COOKIES_CONSENT);
                    if (null != t && t.enabled) {
                        var n;
                        e = "/" + i.x.COOKIE_POLICY;
                        var r = null == (n = u.A.getSettings()) || null == (n = n.external_endpoints) ? void 0 : n.find((function(e) {
                            return 41 === e.type
                        }));
                        r && (e = r.url)
                    }
                    return e
                }(),
                f = function() {
                    (0, a.sx)(332, {
                        element: 202
                    })
                },
                d = function() {
                    (0, a.sx)(332, {
                        element: 161
                    })
                },
                p = function(e) {
                    (0, a.sx)(332, {
                        element: 473
                    });
                    try {
                        e === r.CCPA ? o.A._sp_.ccpa.loadPrivacyManagerModal("589604") : o.A._sp_.gdpr.loadPrivacyManagerModal()
                    } catch (e) {
                        console.log("Cookies consent falling back to legacy behaviour : ", e), o.A.location.href = "/" + i.x.COOKIE_POLICY
                    }
                },
                v = function() {
                    (0, a.sx)(332, {
                        element: 110
                    })
                },
                g = function() {
                    (0, a.sx)(332, {
                        element: 150
                    })
                },
                m = function() {
                    var e = u.A.getSettings(),
                        t = null == e ? void 0 : e.user_country;
                    return 55 === ((null == t ? void 0 : t.id) || null) ? r.CCPA : r.GDPR
                },
                y = function() {
                    var e, t, n, o, a = {
                        linkPrivacy: {
                            routeName: i.x.PRIVACY,
                            onClick: f
                        },
                        linkTerms: {
                            href: i.x.TERMS,
                            onClick: d
                        },
                        linkHelp: {
                            href: i.x.HELP,
                            onClick: v
                        }
                    };
                    if (m() === r.CCPA) a.linkCcpa = {
                        onClick: function() {
                            return p(r.CCPA)
                        }
                    };
                    else {
                        var l = function() {
                            return p(r.GDPR)
                        };
                        a.linkCookiePolicy = s ? {
                            href: s,
                            onClick: l,
                            preventNavigation: !0
                        } : {
                            onClick: l
                        }
                    }
                    return e = u.A.getSettings(), t = null == e ? void 0 : e.user_country, n = (null == t ? void 0 : t.id) || null, o = null == e ? void 0 : e.language_id, (18 === n || 5 === o) && (a.linkImpressum = {
                            href: i.x.IMPRESSUM
                        }),
                        function() {
                            var e = u.A.getSettings(),
                                t = null == e ? void 0 : e.language_iso_code;
                            return t && ["en", "fr", "pt", "ru", "es"].includes(t)
                        }() && (a.linkSafetyCentre = {
                            href: i.x.SAFETY_CENTRE
                        }), a
                }(),
                b = function(e) {
                    var t = l.cB[e];
                    t && ((0, a.sx)(332, {
                        element: t
                    }), (0, a.bX)())
                }
        },
        54643: function(e, t, n) {
            var r = n(96540),
                o = n(20017),
                i = n(4571),
                a = n(40578),
                u = n(30784),
                l = n(46770),
                c = n(36693),
                s = n(65736),
                f = n(26914),
                d = n(27895),
                p = n(74848);
            t.A = function(e) {
                var t = e.title,
                    n = e.text,
                    v = e.isOpen,
                    g = e.isLoading,
                    m = void 0 !== g && g,
                    y = e.primaryCta,
                    b = e.secondaryCta,
                    h = e.onDismiss,
                    x = (0, r.useState)(v),
                    j = x[0],
                    O = x[1];
                (0, r.useEffect)((function() {
                    O(v)
                }), [v]);
                return v ? (0, p.jsx)(s.A, {
                    wrapperType: s.T.ACTION_SHEET,
                    isVisible: j,
                    hasDefaultDismissButton: !0,
                    dataQA: {
                        "data-qa": "passkey-error-modal"
                    },
                    onDismiss: function() {
                        O(!1)
                    },
                    onAnimationOutComplete: h,
                    children: (0, p.jsx)(c.A, {
                        left: "lg",
                        right: "lg",
                        children: (0, p.jsxs)(i.A, {
                            align: "start",
                            children: [(0, p.jsx)(d.A, {
                                children: (0, p.jsx)(f.A, {
                                    size: "sm",
                                    icon: {
                                        name: "badge-alert-primary"
                                    }
                                })
                            }), (0, p.jsx)(a.A, {
                                text: t
                            }), (0, p.jsx)(u.A, {
                                text: n
                            }), (0, p.jsxs)(l.A, {
                                children: [(0, p.jsx)(o.A, {
                                    isLoading: m,
                                    isDisabled: m,
                                    text: y.text,
                                    "data-qa": "passkey-error-modal-primary",
                                    onClick: function() {
                                        y.onClick()
                                    }
                                }), (0, p.jsx)(o.A, {
                                    isLoading: m,
                                    isDisabled: m,
                                    text: b.text,
                                    "data-qa": "passkey-error-modal-secondary",
                                    semantic: "secondary",
                                    onClick: function() {
                                        b.onClick()
                                    }
                                })]
                            })]
                        })
                    })
                }) : null
            }
        },
        57564: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return C
                },
                x: function() {
                    return A
                }
            });
            n(52675), n(45700), n(2008), n(50113), n(51629), n(60739), n(89572), n(33110), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(72577), n(3949), n(23500);
            var r, o = n(96540),
                i = n(99417),
                a = n(28030),
                u = n(4571),
                l = n(46770),
                c = n(40578),
                s = n(27895),
                f = n(20017),
                d = n(8483),
                p = n(65736),
                v = n(74848),
                g = function(e) {
                    var t = e.text,
                        n = e.cta,
                        r = e.onClose,
                        i = (0, o.useState)(!0),
                        a = i[0],
                        g = i[1];
                    return (0, v.jsx)(p.A, {
                        type: "popup",
                        wrapperType: p.T.MODAL,
                        isPadded: !0,
                        isDismissible: !1,
                        hasDefaultDismissButton: !1,
                        isVisible: a,
                        onAnimationOutComplete: r,
                        children: (0, v.jsxs)(u.A, {
                            isCompact: !0,
                            align: "center",
                            children: [(0, v.jsx)(s.A, {
                                children: (0, v.jsx)("div", {
                                    className: "arkose-error-modal__icon",
                                    children: (0, v.jsx)(d.A, {
                                        name: "generic-error",
                                        color: "status-error",
                                        size: "stretch"
                                    })
                                })
                            }), (0, v.jsx)(c.A, {
                                text: t,
                                dangerous: !0,
                                tag: "h2"
                            }), (0, v.jsx)(l.A, {
                                children: (0, v.jsx)(f.A, {
                                    semantic: "primary",
                                    text: n,
                                    onClick: function() {
                                        g(!1)
                                    },
                                    dataQA: {
                                        "data-qa": "partnership-result-continue-cta"
                                    }
                                })
                            })]
                        })
                    })
                },
                m = n(31709),
                y = n(79860),
                b = n(57864);

            function h(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function x(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? h(Object(n), !0).forEach((function(t) {
                        j(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : h(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function j(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(e, t || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var O = ((r = {})[1] = 505, r[39] = 506, r[4] = 504, r[40] = 271, r[18] = 290, r);

            function A(e, t) {
                var n, r, o = null == e || null == (n = e.sdk_integrations) ? void 0 : n.find((function(e) {
                        return 28 === e.type
                    })),
                    i = null == o || null == (r = o.arkose_auth_methods) ? void 0 : r.find((function(e) {
                        return e.auth_method === t
                    }));
                if (i && null != o && o.url) return x(x({}, i), {}, {
                    url: o.url
                })
            }

            function _(e) {
                if ("" !== e) {
                    var t = document.getElementById(e);
                    t && t.remove()
                }
            }
            var C = function(e) {
                var t = e.authMethod,
                    n = e.blob,
                    r = e.flowData,
                    u = e.onArkoseReady,
                    l = e.onArkoseUnavailable,
                    c = e.onArkoseComplete,
                    s = e.onErrorClosed,
                    f = (0, o.useRef)(""),
                    d = (0, o.useRef)(null),
                    p = (0, o.useRef)(t),
                    h = (0, o.useRef)(0),
                    x = (0, o.useRef)(),
                    j = (0, o.useRef)(0),
                    C = (0, o.useRef)(),
                    k = (0, o.useRef)(),
                    P = (0, o.useState)(),
                    w = P[0],
                    S = P[1],
                    E = (0, o.useCallback)((function(e, n, o) {
                        new m.Ay(1014, {
                            token: e,
                            auth_method: t,
                            screen_context: {
                                flow_id: r.flow_id,
                                screen_id: r.screen_id
                            },
                            error_type: n,
                            error_info: o ? JSON.stringify(o) : void 0
                        }).onResponse(1015, (function(e) {
                            e.success ? c() : S(e.error_message)
                        })).onResponse(1, (function(e) {
                            15 === e.type ? m.aV.send(new b.XX(1, e).toJSON()) : S(e.error_message)
                        })).request()
                    }), [t, r.flow_id, r.screen_id, c]),
                    D = (0, o.useCallback)((function(e) {
                        return setTimeout((function() {
                            var e;
                            d.current || (x.current = Date.now(), h.current && (0, y.sx)(998, {
                                activation_place: O[t],
                                is_challenged: !1,
                                is_timeout: !0,
                                response_time: (x.current - h.current) / 1e3
                            }), null == (e = k.current) || e.remove(), l({
                                run: function() {
                                    return E("", 2)
                                }
                            }), _(f.current))
                        }), 1e3 * e)
                    }), [E, l, t]),
                    N = (0, o.useCallback)((function() {
                        return a.A.onChange((function(e) {
                            A(e, t) || l()
                        }))
                    }), [t, l]);
                return (0, o.useEffect)((function() {
                    function e(e) {
                        e.setConfig({
                            selector: "#arkose-enforcement",
                            mode: "lightbox",
                            data: n ? JSON.parse(n) : {},
                            onReady: function() {
                                x.current = Date.now(), d.current && u(d.current)
                            },
                            onShown: function(e) {
                                j.current = Date.now(), (0, y.sx)(49, {
                                    activation_place: O[t],
                                    screen_name: 1455
                                }), (0, y.sx)(998, {
                                    activation_place: O[t],
                                    is_challenged: !0,
                                    is_timeout: !1,
                                    response_time: (x.current - h.current) / 1e3
                                })
                            },
                            onShow: function() {},
                            onSuppress: function(e) {
                                (0, y.sx)(998, {
                                    activation_place: O[t],
                                    is_challenged: !1,
                                    is_timeout: !1,
                                    response_time: (x.current - h.current) / 1e3
                                })
                            },
                            onCompleted: function(e) {
                                var t;
                                null == (t = k.current) || t.remove(), C.current = Date.now(), (0, y.sx)(999, {
                                    session_time: (C.current - j.current) / 1e3,
                                    solved: e.completed
                                }), E(e.token, void 0, e)
                            },
                            onReset: function() {},
                            onHide: function(e) {
                                var t;
                                e.completed || (null == (t = k.current) || t.remove(), C.current = Date.now(), e.token && ((0, y.sx)(999, {
                                    session_time: (C.current - j.current) / 1e3,
                                    solved: !1
                                }), E(e.token, void 0, e)))
                            },
                            onError: function(e) {
                                var t;
                                null == (t = k.current) || t.remove(), l({
                                    run: function() {
                                        return E("", 3, e)
                                    }
                                })
                            },
                            onFailed: function(e) {
                                var t;
                                null == (t = k.current) || t.remove(), C.current = Date.now(), (0, y.sx)(999, {
                                    session_time: (C.current - j.current) / 1e3,
                                    solved: !1
                                }), E(e.token, 3, e)
                            }
                        }), p.current = t
                    }
                    i.A.setupEnforcement = function(t) {
                        "" !== f.current && (d.current = t, e(d.current))
                    }, d.current && p.current === t ? e(d.current) : "" !== f.current && p.current === t || (h.current = Date.now(), a.A.get().then((function(e) {
                        var n = A(e, t);
                        if (null != n && n.api_key) {
                            var r = n.api_key,
                                o = n.timeout;
                            k.current = N(), o && D(o), f.current = "arkose-script-" + r, (function(e, t, n) {
                                _(t);
                                var r = document.createElement("script");
                                r.id = t, r.type = "text/javascript", r.src = "" + n + e + "/api.js", r.setAttribute("data-callback", "setupEnforcement"), r.async = !0, r.defer = !0, i.A._nonce && r.setAttribute("data-nonce", i.A._nonce);
                                return document.body.appendChild(r), r
                            }(r, f.current, n.url)).onerror = function() {
                                console.log("Could not load the Arkose API Script!"), l({
                                    run: function() {
                                        return E("", 1)
                                    }
                                })
                            }
                        } else l()
                    })))
                }), [u, l, E, D, N, t, n]), (0, o.useEffect)((function() {
                    return function() {
                        i.A.setupEnforcement && delete i.A.setupEnforcement, _(f.current)
                    }
                }), []), (0, v.jsx)("div", {
                    id: "arkose-enforcement",
                    children: w ? (0, v.jsx)(g, {
                        text: w,
                        cta: "Close",
                        onClose: function() {
                            S(void 0), null == s || s()
                        }
                    }) : null
                })
            }
        },
        65941: function(e, t, n) {
            n.r(t), n.d(t, {
                default: function() {
                    return V
                }
            });
            var r = n(96540),
                o = (n(52675), n(45700), n(2008), n(50113), n(51629), n(62062), n(60739), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(27495), n(90906), n(42762), n(98992), n(54520), n(72577), n(3949), n(81454), n(23500), n(31709)),
                i = n(57864),
                a = n(40075),
                u = n(17414),
                l = n(79860),
                c = n(66701),
                s = n(28030),
                f = n(24412),
                d = n(93529),
                p = n(40068),
                v = n(5322),
                g = n(91133),
                m = n(94604),
                y = n(86451),
                b = n(57981),
                h = n(51709),
                x = n(93827),
                j = n(36693),
                O = n(87184),
                A = n(20017),
                _ = n(89162),
                C = n(66130),
                k = n(8483),
                P = n(73616),
                w = n(18194),
                S = n(74848),
                E = function(e) {
                    var t = e.title,
                        n = e.text,
                        r = e.inputLabel,
                        o = e.listCountryCodes,
                        i = e.countryCodeValue,
                        a = e.phoneNumber,
                        u = e.primaryButtonText,
                        l = e.secondaryButtonText,
                        c = e.privacyInfoText,
                        s = e.isButtonDisabled,
                        f = e.isLoading,
                        d = e.errorMessage,
                        p = e.onChangeCountryCode,
                        v = e.onClickCountryCode,
                        g = e.onChangePhoneNumber,
                        m = e.onFocusInput,
                        y = e.onBlurInput,
                        b = e.onSubmit,
                        E = e.onSignupWithEmail,
                        D = e.inputRef;
                    return (0, S.jsx)(O.A, {
                        hpadded: !0,
                        vpadded: !0,
                        children: (0, S.jsxs)(P.A, {
                            onSubmit: function(e) {
                                return (0, h.Y4)(e, b)
                            },
                            isFixed: !0,
                            children: [(0, S.jsx)(x.Zb, {
                                tag: "h1",
                                children: t
                            }), (0, S.jsx)(j.A, {
                                top: "md",
                                children: (0, S.jsx)(_.A, {
                                    text: n
                                })
                            }), (0, S.jsxs)(j.A, {
                                top: "md",
                                bottom: "md",
                                children: [(0, S.jsx)(w.A, {
                                    label: r,
                                    countryCode: {
                                        options: o,
                                        onChange: p,
                                        dataQASelect: "phone-select",
                                        onFocus: function(e) {
                                            return v
                                        },
                                        value: i
                                    },
                                    number: {
                                        value: a,
                                        onChange: g,
                                        onFocus: m,
                                        onBlur: y,
                                        inputRef: D,
                                        dataQAInput: "phone-input",
                                        name: "phone",
                                        autoComplete: "phone"
                                    },
                                    hintMessage: "",
                                    errorMessage: d,
                                    isInvalid: "" !== d,
                                    fieldId: "phone-input",
                                    isRequired: !0
                                }), (0, S.jsx)(A.A, {
                                    semantic: "tertiary",
                                    text: l,
                                    onClick: E
                                })]
                            }), (0, S.jsxs)(C.A, {
                                children: [(0, S.jsx)(j.A, {
                                    top: "lg",
                                    bottom: "md",
                                    children: (0, S.jsxs)(x.P2, {
                                        color: "gray-80",
                                        align: "center",
                                        children: [(0, S.jsx)("span", {
                                            style: {
                                                display: "inline-block",
                                                marginRight: "8px"
                                            },
                                            children: (0, S.jsx)(k.A, {
                                                name: "generic-lock",
                                                size: "sm"
                                            })
                                        }), (0, S.jsx)("span", {
                                            children: c
                                        })]
                                    })
                                }), (0, S.jsx)(A.A, {
                                    isDisabled: s || "" === a,
                                    text: u,
                                    isLoading: f,
                                    buttonAttrs: {
                                        type: "submit"
                                    }
                                })]
                            })]
                        })
                    })
                },
                D = n(57564),
                N = "";
            var I = {
                    get: function() {
                        return N
                    },
                    set: function(e) {
                        N = e
                    }
                },
                L = n(6642);

            function R(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function T(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? R(Object(n), !0).forEach((function(t) {
                        M(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : R(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function M(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(e, t || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function B(e, t) {
                var n;
                return null == (n = e.find((function(e) {
                    return e.id === t
                }))) ? void 0 : n.phonePrefix
            }

            function F() {
                (0, l.sx)(332, {
                    element: 386
                })
            }
            var q = function() {
                    var e, t = (0, r.useState)(I.get()),
                        n = t[0],
                        h = t[1],
                        x = (0, r.useState)([]),
                        j = x[0],
                        O = x[1],
                        A = (0, r.useState)(),
                        _ = A[0],
                        C = A[1],
                        k = (0, r.useState)(""),
                        P = k[0],
                        w = k[1],
                        N = (0, r.useState)(!1),
                        R = N[0],
                        M = N[1],
                        q = (0, r.useState)(""),
                        V = q[0],
                        z = q[1],
                        Q = (0, r.useState)(""),
                        H = Q[0],
                        U = Q[1],
                        G = (0, r.useState)(!1),
                        X = G[0],
                        W = G[1],
                        Y = (0, r.useState)(null),
                        J = Y[0],
                        K = Y[1],
                        $ = (0, r.useRef)(null),
                        Z = (0, p.A)(b.Xd, 128)[0],
                        ee = Z.header,
                        te = Z.subHeader,
                        ne = Z.secondaryCta,
                        re = Z.cta,
                        oe = Z.privacyInfo,
                        ie = Z.inputLabel,
                        ae = (0, r.useContext)(v.P),
                        ue = ae.handleCallToActionClick,
                        le = ae.getFlowData,
                        ce = (0, g.G)(128);
                    (0, r.useEffect)((function() {
                        s.A.get().then((function(e) {
                            var t;
                            C(null == (t = e.user_country) ? void 0 : t.id)
                        }))
                    }), [j.length]), (0, r.useEffect)((function() {
                        c.A.getInstance().get().then((function(e) {
                            if (e.countries) {
                                var t, n = null != (t = e.countries) ? t : [];
                                O(n.map((function(e) {
                                    return m.Ay.countryToSelectOption(e)
                                })).map((function(e) {
                                    return T(T({}, e), {}, {
                                        selected: !1
                                    })
                                })))
                            }
                        }))
                    }), []), (0, r.useEffect)((function() {
                        j.length > 1 && !_ && C(j[0].id), j.length > 1 && _ && O(j.map((function(e) {
                            return T(T({}, e), {}, {
                                selected: e.id === _
                            })
                        })))
                    }), [j.length, _]), (0, r.useEffect)((function() {
                        ce(2)
                    }), [ce]);
                    var se = (0, r.useCallback)((function(e) {
                        M(!1), "string" == typeof e ? w(e) : 15 === (null == e ? void 0 : e.type) ? w(e.error_message) : w(String(e) || a.Ay.get(1083))
                    }), []);
                    var fe = (0, r.useCallback)((function() {
                            M(!0);
                            var e = B(j, _);
                            new o.Ay(678, {
                                screen_context: {
                                    screen_id: String(128),
                                    flow_id: u.wq.FLOW_BADOO_REGISTRATION
                                },
                                phone_prefix: e,
                                phone: n
                            }).onResponse(687, (function(e) {
                                M(!1), o.aV.send(new i.XX(687, e).toJSON()), re.call_to_action && ue(re.call_to_action)
                            })).onResponse(1, (function(e) {
                                M(!1), 10002 === e.type ? se(e.error_message) : 15 === e.type && o.aV.send(new i.XX(1, e).toJSON())
                            })).onError((function(e) {
                                se(e), d.A.showNotification({
                                    type: d.A.TYPES.ERROR
                                })
                            })).request()
                        }), [re.call_to_action, ue, se, j, n, _]),
                        de = (0, r.useCallback)((function(e) {
                            $.current = e, $.current.run()
                        }), []),
                        pe = (0, r.useCallback)((function(e) {
                            M(!1), $.current = e || null, e ? e.run() : fe()
                        }), [M, fe]),
                        ve = (0, r.useCallback)((function() {
                            M(!1), K(null)
                        }), [M]);
                    return (0, S.jsxs)(S.Fragment, {
                        children: [(0, S.jsx)(E, {
                            title: null == ee ? void 0 : ee.text,
                            text: null == te ? void 0 : te.text,
                            inputLabel: null == ie ? void 0 : ie.text,
                            listCountryCodes: j.map((function(e) {
                                return {
                                    value: e.value,
                                    label: e.label,
                                    selectedLabel: e.selectedLabel.replace(/[^+0-9]/gi, "")
                                }
                            })),
                            phoneNumber: n,
                            countryCodeValue: _,
                            primaryButtonText: null == re ? void 0 : re.text,
                            secondaryButtonText: null == ne || null == (e = ne.call_to_action) ? void 0 : e.text,
                            privacyInfoText: null == oe ? void 0 : oe.text,
                            isButtonDisabled: R,
                            isLoading: R,
                            errorMessage: P,
                            onChangeCountryCode: function(e) {
                                var t = e.target.value;
                                O(j.map((function(e) {
                                    return T(T({}, e), {}, {
                                        selected: e.value === t
                                    })
                                })));
                                var n = j.find((function(e) {
                                    return e.value === t
                                }));
                                n && C(n.id)
                            },
                            onClickCountryCode: F,
                            onChangePhoneNumber: function(e) {
                                var t = String(e.target.value).trim();
                                h(t)
                            },
                            onSubmit: function() {
                                var e;
                                ce(1), e = 474, (0, l.sx)(332, {
                                    element: e
                                }), /[+0-9]+/.test(n) ? R || (M(!0), function() {
                                    I.set(n);
                                    var e = B(j, _);
                                    f.A.getInstance().validatePhoneNumber({
                                        phonePrefix: e,
                                        phone: n,
                                        context: 108
                                    }).then((function(e) {
                                        null != e && e.valid ? (z(e.confirmation_header || ""), U(e.confirmation_message || ""), W(!0), (0, l.sx)(20, {
                                            alert_type: 48,
                                            activation_place: 66,
                                            action_type: 12
                                        })) : (se(e.error_message), M(!1))
                                    })).catch(se)
                                }()) : w(a.Ay.get(96))
                            },
                            onSignupWithEmail: function() {
                                ue(ne.call_to_action)
                            }
                        }), X ? (0, S.jsx)(y.A, {
                            header: V,
                            message: H,
                            onConfirm: function() {
                                W(!1), M(!0), (0, l.sx)(20, {
                                    alert_type: 48,
                                    activation_place: 66,
                                    action_type: 2
                                }), (0, L.x)({
                                    data: {
                                        country_id: "" + _,
                                        phone: n
                                    },
                                    providerType: 40,
                                    flowData: le(),
                                    onArkoseDisabled: fe,
                                    onArkoseEnabled: function(e) {
                                        K(e)
                                    },
                                    handleError: se,
                                    setIsLoading: M
                                })
                            },
                            onCancel: function() {
                                W(!1), M(!1), (0, l.sx)(20, {
                                    alert_type: 48,
                                    activation_place: 66,
                                    action_type: 5
                                })
                            },
                            onAnimationOutComplete: function() {
                                W(!1)
                            }
                        }) : null, J ? (0, S.jsx)(D.A, {
                            authMethod: 40,
                            blob: J,
                            flowData: le(),
                            onArkoseReady: de,
                            onArkoseUnavailable: pe,
                            onArkoseComplete: fe,
                            onErrorClosed: ve
                        }) : null]
                    })
                },
                V = function(e) {
                    var t = e.setScreenName;
                    return (0, r.useEffect)((function() {
                        t(145)
                    }), [t]), (0, S.jsx)(q, {})
                }
        },
        66701: function(e, t, n) {
            n(10287);

            function r(e, t) {
                return r = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, r(e, t)
            }
            var o = function(e) {
                function t() {
                    return e.call(this, {
                        get: {
                            message: 410,
                            response: 411
                        }
                    }, {
                        name: "Countries"
                    }) || this
                }
                var n, o;
                return o = e, (n = t).prototype = Object.create(o.prototype), n.prototype.constructor = n, r(n, o), t.getInstance = function() {
                    return t.instance || (t.instance = new t), t.instance
                }, t.prototype.getCacheKey = function(e) {
                    return String(e)
                }, t
            }(n(6696).A);
            o.instance = void 0, t.A = o
        },
        73160: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return m
                }
            });
            n(52675), n(45700), n(2008), n(51629), n(62062), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(84864), n(57465), n(27495), n(87745), n(38781), n(98992), n(54520), n(3949), n(81454), n(23500);
            var r = n(96540),
                o = n(18084),
                i = n(28244),
                a = n(74848);

            function u(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function l(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(n), !0).forEach((function(t) {
                        c(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function c(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(e, t || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var s = /\[link(?:=["']?([^'"\]]+)["']?)?\]([^\[]+)\[\/link\]/,
                f = /<a(?:[^>]+href="([^"]*)"([^>]*))?>([^<]+)<\/a>/,
                d = /(<a(?:[^>]+href[^>]+)?>[^<]+<\/a>)/,
                p = ["rel", "target"],
                v = o.A.getLogger("RoutingText");

            function g(e) {
                var t, n = e.text,
                    o = e.routingMapping,
                    u = e.ignoreMissingRoutingInfo,
                    c = void 0 !== u && u,
                    g = new RegExp(s, "gi"),
                    m = new RegExp(f, "gi"),
                    y = new RegExp(d, "gi"),
                    b = n.replace(g, '<a href="$1">$2</a>').split(y).map((function(e) {
                        var t, r = m.exec(e);
                        if (r) {
                            var u, s = r[1];
                            if (!s && null != o && o.default && (s = "default"), o && (u = o[s]), u) {
                                if ("href" in (t = u) || "routeName" in t) {
                                    var f = function(e) {
                                        var t = {},
                                            n = document.createElement("div");
                                        n.innerHTML = e;
                                        var r = n.getElementsByTagName("a")[0];
                                        r && p.forEach((function(e) {
                                            t[e] = r.getAttribute(e) || void 0
                                        }));
                                        return t
                                    }(e);
                                    return (0, a.jsx)(i.A, l(l(l({}, f), u), {}, {
                                        children: r[3]
                                    }))
                                }
                                return (0, a.jsx)("button", l(l({
                                    onClick: u.onClick
                                }, u.dataQA), {}, {
                                    type: "button",
                                    children: r[3]
                                }))
                            }
                            c || v.error("RoutingText string contains anchor markup, but no routing information is passed", {
                                textPiece: e,
                                text: n,
                                routingMapping: o
                            })
                        }
                        return e
                    }));
                return t = b, (0, a.jsx)(r.Fragment, {
                    children: t.map((function(e, t) {
                        return "string" == typeof e ? (0, a.jsx)("span", {
                            dangerouslySetInnerHTML: {
                                __html: e
                            }
                        }, "fragment-" + t) : (0, a.jsx)(r.Fragment, {
                            children: e
                        }, "fragment-" + t)
                    }))
                })
            }
            var m = function(e) {
                var t = e.text,
                    n = e.routingMapping,
                    r = e.className,
                    o = g({
                        text: t,
                        routingMapping: n,
                        ignoreMissingRoutingInfo: e.ignoreMissingRoutingInfo
                    });
                return (0, a.jsx)("span", {
                    className: r,
                    children: o
                })
            }
        },
        73616: function(e, t, n) {
            var r = n(31189);
            t.A = r.A
        },
        73648: function(e, t, n) {
            n(52675), n(45700), n(2008), n(51629), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(3949), n(23500);
            var r = n(46942),
                o = n.n(r),
                i = n(28244),
                a = n(74848);

            function u(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function l(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(n), !0).forEach((function(t) {
                        c(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function c(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(e, t || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            t.A = function(e) {
                var t = e.linkAppstore,
                    n = e.imageSrc,
                    r = e.jsClass,
                    u = e.a11y,
                    c = o()({
                        "badge-appstore": !0
                    }, r);
                return (0, a.jsx)(i.A, l(l({}, t), {}, {
                    className: c,
                    children: (0, a.jsx)("img", {
                        className: "badge-appstore__image",
                        src: n,
                        alt: u.label
                    })
                }))
            }
        },
        84256: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return a
                }
            });
            n(27495);
            var r = n(99417),
                o = n(4104),
                i = n(67471);

            function a(e, t, n) {
                var a = e.redirect_page;
                if (a) {
                    var u = n.getRouteFromRedirectPage(a);
                    if (u) return t.navigate(u, !0), a.redirect_page;
                    if (a.url) return r.A.location.replace(a.url), a.redirect_page
                }
                var l = (0, i.L)()[o.k.REDIRECT];
                if (l) return r.A.location.replace(l), null == a ? void 0 : a.redirect_page
            }
        },
        84932: function(e, t, n) {
            n(52675), n(45700), n(2008), n(51629), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(3949), n(23500);
            var r = n(51709),
                o = n(33702),
                i = n(14680),
                a = n(74848);

            function u(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function l(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(n), !0).forEach((function(t) {
                        c(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function c(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(e, t || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            t.A = function(e) {
                var t = (0, r.iD)(e),
                    n = t.a11y,
                    u = t.ids,
                    c = t.labelProps;
                return (0, a.jsxs)(i.A, l(l(l({}, e), u), {}, {
                    label: c.label,
                    children: [(0, a.jsx)(o.A, l(l(l(l({}, e), u), (0, r.$E)(e.preset, e)), {}, {
                        status: Boolean(e.errorMessage) || e.isInvalid ? "error" : void 0,
                        a11y: l(l({}, n), {}, {
                            ariaRequired: c.ariaRequired
                        })
                    })), e.extraContent]
                }))
            }
        },
        86451: function(e, t, n) {
            var r = n(96540),
                o = n(40075),
                i = n(65736),
                a = n(33736),
                u = n(74848);
            t.A = function(e) {
                var t = e.header,
                    n = e.message,
                    l = e.primaryLabel,
                    c = e.secondaryLabel,
                    s = e.destructiveLabel,
                    f = e.cancelLabel,
                    d = e.isVisible,
                    p = void 0 === d || d,
                    v = e.onConfirm,
                    g = e.onSecondary,
                    m = e.onDestructive,
                    y = e.onCancel,
                    b = e.onAnimationOutComplete,
                    h = (0, r.useState)(p),
                    x = h[0],
                    j = h[1],
                    O = (0, r.useRef)(null),
                    A = function(e) {
                        O.current = e, j(!1)
                    };
                return (0, u.jsxs)(i.A, {
                    isVisible: x,
                    isDismissible: !1,
                    wrapperType: i.T.ACTION_SHEET,
                    onAnimationOutComplete: function() {
                        null == O.current || O.current(), null == b || b()
                    },
                    header: t || n ? {
                        title: t,
                        text: n
                    } : void 0,
                    children: [v ? (0, u.jsx)(a.A, {
                        text: l || o.Ay.get(373),
                        onClick: function() {
                            return A(v)
                        },
                        dataQA: {
                            "data-qa": "modal-action-ok"
                        }
                    }) : null, c && g ? (0, u.jsx)(a.A, {
                        text: c,
                        onClick: function() {
                            return A(g)
                        },
                        dataQA: {
                            "data-qa": "modal-action-secondary"
                        }
                    }) : null, s && m ? (0, u.jsx)(a.A, {
                        text: s,
                        type: "destructive",
                        onClick: function() {
                            return A(m)
                        },
                        dataQA: {
                            "data-qa": "modal-action-delete"
                        }
                    }) : null, (0, u.jsx)(a.A, {
                        text: f || o.Ay.get(451),
                        onClick: function() {
                            return A(y)
                        },
                        dataQA: {
                            "data-qa": "modal-action-cancel"
                        }
                    })]
                })
            }
        }
    }
]);
//# sourceMappingURL=landing-page-story.53eeac20420cb54562bf.js.map
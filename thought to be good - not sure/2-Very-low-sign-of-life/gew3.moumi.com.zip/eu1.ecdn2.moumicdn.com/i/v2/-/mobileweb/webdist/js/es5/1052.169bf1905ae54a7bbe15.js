"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [1052], {
        5587: function(a, e, t) {
            var s = t(74848),
                i = t(96540);
            e.A = ({
                children: a,
                tag: e,
                dataQA: t
            }) => {
                const n = i.Children.toArray(a).filter(Boolean),
                    o = e || n.length >= 4 ? "ul" : "div",
                    c = "div" !== o ? "li" : "div",
                    l = {
                        "data-qa": "action-sheet-list",
                        ...t
                    };
                return (0, s.jsx)(o, {
                    className: "csms-actionsheet__list",
                    ...l,
                    role: "ul" === o ? "list" : void 0,
                    children: n.map(((a, e) => (0, s.jsx)(c, {
                        className: "csms-actionsheet__list-item",
                        "data-qa": "action-sheet-list-item",
                        children: a
                    }, e)))
                })
            }
        },
        8562: function(a, e, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i),
                o = t(93827);
            e.A = ({
                media: a,
                mediaSize: e,
                title: t,
                text: i
            }) => {
                const c = n()({
                    "csms-actionsheet__header-media": !0,
                    [`csms-actionsheet__header-media--size-${e}`]: e
                });
                return (0, s.jsxs)("div", {
                    className: "csms-actionsheet__header",
                    "data-qa": "action-sheet-header",
                    children: [a ? (0, s.jsx)("div", {
                        className: c,
                        children: a
                    }) : null, t ? (0, s.jsx)("div", {
                        className: "csms-actionsheet__header-title",
                        "data-qa": "action-sheet-header-title",
                        children: (0, s.jsx)(o.Sz, {
                            color: "black",
                            breakWords: !0,
                            tag: "h2",
                            children: t
                        })
                    }) : null, i ? (0, s.jsx)("div", {
                        className: "csms-actionsheet__header-text",
                        "data-qa": "action-sheet-header-text",
                        children: (0, s.jsx)(o.P1, {
                            color: "gray-80",
                            breakWords: !0,
                            dangerous: "string" == typeof i,
                            children: i
                        })
                    }) : null]
                })
            }
        },
        23914: function(a, e, t) {
            t.d(e, {
                A: function() {
                    return r
                }
            });
            var s = t(74848),
                i = t(46942),
                n = t.n(i),
                o = t(56301);
            var c = ({
                children: a,
                type: e = "bottom-drawer",
                isPadded: t,
                background: i = "white",
                animationStatus: c,
                style: l,
                hostRef: d,
                navigation: r,
                a11y: m
            }) => {
                const h = n()({
                        "csms-modal__content": !0,
                        [`csms-modal__content--${e}`]: !0,
                        [`csms-modal__content--background-${i}`]: !0,
                        [`csms-modal__content--${c}`]: c
                    }),
                    u = n()({
                        "csms-modal__scrollable": !0,
                        "csms-modal__scrollable--padded": t
                    });
                return (0, s.jsxs)("div", {
                    className: h,
                    style: l,
                    ref: d,
                    "aria-hidden": m ? .ariaHidden,
                    tabIndex: m ? .ariaHidden ? -1 : 0,
                    children: [r && "bottom-drawer" === e ? (0, s.jsx)(o.A, { ...r
                    }) : null, (0, s.jsx)("div", {
                        className: u,
                        children: a
                    })]
                })
            };
            var l = ({
                animationStatus: a,
                onClick: e,
                hostRef: t,
                backdropColor: i = "dark"
            }) => {
                const o = n()({
                        "csms-modal__shadow": !0,
                        [`csms-modal__shadow--${a}`]: a,
                        [`csms-modal__shadow--${i}`]: i
                    }),
                    c = e ? "button" : "div";
                return (0, s.jsx)(c, {
                    className: o,
                    onClick: e,
                    ref: t,
                    "aria-hidden": !0,
                    tabIndex: -1,
                    type: "button" === c ? "button" : void 0
                })
            };
            var d = ({
                children: a,
                style: e,
                hostRef: t,
                a11y: i
            }) => (0, s.jsx)("div", {
                className: "csms-modal",
                style: e,
                ref: t,
                tabIndex: i ? .ariaHidden ? -1 : 0,
                role: "dialog",
                "aria-modal": !0,
                "aria-label": i ? .label,
                "aria-hidden": i ? .ariaHidden,
                children: a
            });
            var r = ({
                children: a,
                type: e = "bottom-drawer",
                isPadded: t,
                background: i = "white",
                animationStatus: n,
                onDismiss: o,
                wrapperRef: r,
                shadowRef: m,
                backdropColor: h,
                contentRef: u,
                navigation: b,
                a11y: _
            }) => {
                const x = "visible" !== n;
                return (0, s.jsxs)(d, {
                    hostRef: r,
                    a11y: {
                        label: _ ? .wrapperLabel,
                        ariaHidden: x
                    },
                    children: ["fullscreen" !== e ? (0, s.jsx)(l, {
                        onClick: o || b ? .onClickClose,
                        animationStatus: n,
                        hostRef: m,
                        backdropColor: h
                    }) : null, (0, s.jsx)(c, {
                        type: e,
                        isPadded: t,
                        background: i,
                        animationStatus: n,
                        hostRef: u,
                        a11y: {
                            ariaHidden: x
                        },
                        navigation: b,
                        children: a
                    })]
                })
            }
        },
        31751: function(a, e, t) {
            var s = t(74848),
                i = t(96540);
            const n = {
                    breakpoint: 19,
                    fontSizeRatio: .8,
                    lineHeightRatio: 1
                },
                o = {
                    breakpoint: 24,
                    fontSizeRatio: .9,
                    lineHeightRatio: 1.15
                };
            e.A = ({
                size: a,
                text: e,
                imageSrc: t,
                visuallyCorrected: c,
                a11y: l
            }) => {
                const d = {
                        display: "block",
                        width: a,
                        height: a
                    },
                    r = parseInt(a, 10),
                    m = (0, i.useMemo)((() => ((a, e) => {
                        let t = a,
                            s = a;
                        return e && a <= o.breakpoint && (t = a * o.fontSizeRatio, s = a * o.lineHeightRatio), e && a <= n.breakpoint && (t = a * n.fontSizeRatio, s = a * n.lineHeightRatio), {
                            fontSize: t,
                            lineHeight: `${s}px`
                        }
                    })(r, c)), [r, c]);
                let h;
                return t && (h = (0, s.jsx)("img", {
                    src: t,
                    style: d,
                    alt: l ? .label || "",
                    "data-qa": "emoji-image"
                })), e && (h = (0, s.jsx)("span", {
                    role: "img",
                    "aria-label": l ? .ariaHidden ? void 0 : l ? .label || e,
                    "aria-hidden": l ? .ariaHidden,
                    style: { ...d,
                        ...m
                    },
                    "data-qa": "emoji-text",
                    children: e
                })), (0, s.jsx)(i.Fragment, {
                    children: h
                })
            }
        },
        32675: function(a, e, t) {
            var s = t(74848),
                i = t(96540),
                n = t(46942),
                o = t.n(n),
                c = t(84362),
                l = t(40223),
                d = t(31751),
                r = t(8483),
                m = t(93827);
            e.A = ({
                emoji: a,
                icon: e,
                imageSrc: t,
                text: n,
                styling: h = "default",
                size: u = "small",
                hasTransparency: b = !1,
                onClick: _,
                innerRef: x,
                extraIcon: g,
                a11y: p,
                dataQA: v
            }) => {
                let j = h;
                "selected" === h && (j = "brand");
                const k = (0, l.dw)(),
                    f = (0, i.useMemo)((() => ({
                        micro: k.TOKEN_COSMOS_BADGE_SIZING_EMOJI_MICRO,
                        mini: k.TOKEN_COSMOS_BADGE_SIZING_EMOJI_MINI,
                        small: k.TOKEN_COSMOS_BADGE_SIZING_EMOJI_SMALL
                    })), [k]),
                    y = o()({
                        "csms-badge": !0,
                        [`csms-badge--size-${u}`]: !0,
                        [`csms-badge--styling-${j}`]: j
                    }),
                    C = {
                        "--csms-badge-background-color": `var(--token-cosmos-badge-color-background-${b?"transparent":"solid"}-${j})`,
                        "--csms-badge-text-color": `var(--token-cosmos-badge-color-content-${b?"transparent":"solid"}-${j})`,
                        "--csms-badge-icon-color": `var(--token-cosmos-badge-color-icon-${j})`
                    },
                    N = _ ? "button" : "div",
                    A = Boolean(p ? .label),
                    w = {
                        "data-qa": "badge",
                        ...v
                    };
                return (0, s.jsxs)(N, {
                    className: y,
                    style: C,
                    onClick: _,
                    "aria-hidden": p ? .ariaHidden,
                    tabIndex: p ? .ariaHidden ? -1 : void 0,
                    "aria-pressed": p ? .ariaPressed,
                    type: _ ? "button" : void 0,
                    ref: x,
                    ...w,
                    children: [a ? (0, s.jsx)("span", {
                        className: "csms-badge__media",
                        children: (0, s.jsx)(d.A, {
                            size: f[u],
                            text: a,
                            visuallyCorrected: !0,
                            a11y: {
                                ariaHidden: !0
                            }
                        })
                    }) : null, e ? (0, s.jsx)("span", {
                        className: "csms-badge__media",
                        children: (0, s.jsx)(r.A, {
                            name: e
                        })
                    }) : null, t ? (0, s.jsx)("img", {
                        className: "csms-badge__media",
                        src: t,
                        alt: "",
                        "data-qa": "badge-image"
                    }) : null, (0, s.jsx)(m.Qi, {
                        ellipsis: !0,
                        className: "csms-badge__text",
                        a11y: {
                            ariaHidden: A || void 0
                        },
                        children: n
                    }), p ? .ariaHidden ? null : (0, s.jsx)(c.A, {
                        children: p ? .label
                    }), g ? (0, s.jsx)("span", {
                        className: "csms-badge__end-icon",
                        children: (0, s.jsx)(r.A, {
                            name: g
                        })
                    }) : null]
                })
            }
        },
        33736: function(a, e, t) {
            var s = t(74848),
                i = t(95299);
            e.A = ({
                text: a,
                extra: e,
                icon: t,
                onClick: n,
                type: o = "generic",
                tag: c,
                innerRef: l,
                dataQA: d,
                a11y: r
            }) => {
                const m = {
                    "data-qa": "action-sheet-item",
                    "data-qa-type": o,
                    ...d
                };
                return (0, s.jsx)(i.A, {
                    onClick: n,
                    media: t ? {
                        content: t,
                        size: "small"
                    } : void 0,
                    title: {
                        text: a,
                        color: "destructive" === o ? "danger" : "base"
                    },
                    action: {
                        action: e ? "custom" : "chevron",
                        content: e || void 0
                    },
                    tag: c,
                    innerRef: l,
                    dataQA: m,
                    a11y: r
                })
            }
        },
        36167: function(a, e, t) {
            t.d(e, {
                A: function() {
                    return r
                }
            });
            var s = t(74848),
                i = t(23914),
                n = t(47908),
                o = t(8562),
                c = t(5587),
                l = t(56301);
            var d = a => a.onClickBack || a.onClickClose ? (0, s.jsx)("div", {
                className: "csms-actionsheet__navigation",
                "data-qa": "action-sheet-navigation",
                children: (0, s.jsx)(l.A, { ...a
                })
            }) : null;
            var r = a => {
                const {
                    children: e,
                    navigation: t,
                    header: l,
                    listTag: r,
                    footer: m,
                    isFooterDocked: h,
                    onSubmit: u,
                    dataQA: b,
                    ..._
                } = a, x = {
                    "data-qa": "action-sheet",
                    ...b
                }, g = u ? "form" : "div", p = e && "object" == typeof e && e.type && "ActionSheetContent" === e.type.name;
                return (0, s.jsx)(i.A, { ..._,
                    children: (0, s.jsxs)(g, {
                        className: "csms-actionsheet",
                        ...x,
                        children: [t ? (0, s.jsx)(d, {
                            onClickBack: t.onClickBack,
                            onClickClose: t.onClickClose,
                            a11y: t.a11y
                        }) : null, l ? (0, s.jsx)(o.A, {
                            media: l.media,
                            mediaSize: l.mediaSize,
                            title: l.title,
                            text: l.text
                        }) : null, p ? e : (0, s.jsx)(c.A, {
                            tag: r,
                            children: e
                        }), m ? (0, s.jsx)(n.A, {
                            isDocked: h,
                            children: m
                        }) : null]
                    })
                })
            }
        },
        47908: function(a, e, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i);
            e.A = ({
                children: a,
                isDocked: e
            }) => (0, s.jsx)("div", {
                className: n()("csms-actionsheet__footer", {
                    "csms-actionsheet__footer--docked": e
                }),
                "data-qa": "action-sheet-footer",
                children: a
            })
        },
        56301: function(a, e, t) {
            var s = t(74848),
                i = t(8483);
            e.A = ({
                onClickBack: a,
                onClickClose: e,
                a11y: t
            }) => a || e ? (0, s.jsxs)("div", {
                className: "csms-modal__navigation",
                "data-qa": "modal-navigation",
                children: [a ? (0, s.jsx)("button", {
                    className: "csms-modal__navigation-item csms-modal__navigation-item--start",
                    onClick: a,
                    "data-qa": "modal-back",
                    type: "button",
                    children: (0, s.jsx)(i.A, {
                        name: "generic-chevron-left",
                        a11y: {
                            label: t ? .backLabel
                        }
                    })
                }) : null, e ? (0, s.jsx)("button", {
                    className: "csms-modal__navigation-item csms-modal__navigation-item--end",
                    onClick: e,
                    "data-qa": "modal-close",
                    type: "button",
                    children: (0, s.jsx)(i.A, {
                        name: "generic-close",
                        a11y: {
                            label: t ? .closeLabel
                        }
                    })
                }) : null]
            }) : null
        },
        56535: function(a, e, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i);
            e.A = ({
                id: a,
                isChecked: e,
                isDisabled: t,
                onChange: i,
                isDecorative: o,
                tag: c = "input",
                onClick: l
            }) => {
                const d = n()({
                        "csms-toggle": !0,
                        "csms-toggle--disabled": t,
                        "csms-toggle--checked": e
                    }),
                    r = "button" === c ? "button" : "span";
                return (0, s.jsxs)(r, {
                    className: d,
                    "data-qa": "toggle",
                    "data-qa-state": e ? "on" : "off",
                    "aria-checked": "button" !== c || o ? void 0 : Boolean(e),
                    type: "button" !== c || o ? void 0 : "button",
                    role: "button" !== c || o ? void 0 : "switch",
                    onClick: l,
                    children: [o || "input" !== c ? null : (0, s.jsx)("input", {
                        className: "csms-toggle__input",
                        id: a,
                        type: "checkbox",
                        checked: e,
                        onChange: i,
                        disabled: t
                    }), (0, s.jsx)("span", {
                        className: "csms-toggle__surrogate"
                    })]
                })
            }
        },
        71859: function(a, e, t) {
            var s = t(74848);
            e.A = ({
                children: a
            }) => (0, s.jsx)("div", {
                className: "csms-app-overlay",
                children: (0, s.jsx)("div", {
                    className: "csms-app-overlay__inner",
                    children: a
                })
            })
        },
        95299: function(a, e, t) {
            var s = t(74848),
                i = t(46942),
                n = t.n(i),
                o = t(84362),
                c = t(20017),
                l = t(17380),
                d = t(56535),
                r = t(8483),
                m = t(93827);
            e.A = ({
                media: a,
                title: e,
                description: t,
                label: i,
                action: h = {
                    action: "none"
                },
                variant: u = "default",
                onClick: b,
                isPressed: _,
                tag: x,
                innerRef: g,
                a11y: p,
                dataQA: v
            }) => {
                const j = n()({
                        "csms-action-row": !0,
                        "csms-action-row--compact": "compact" === u,
                        "csms-action-row--no-action": "none" === h ? .action,
                        "is-pressed": _
                    }),
                    k = n()({
                        "csms-action-row__content": !0,
                        "csms-action-row__content--no-label": !i
                    }),
                    f = n()({
                        "csms-action-row__title": !0,
                        [`csms-action-row__title--color-${e.color}`]: e.color,
                        [`csms-action-row__title--size-${e.size||"small"}`]: !0
                    }),
                    y = n()({
                        "csms-action-row__media": !0,
                        "csms-action-row__media--size-medium": "medium" === a ? .size
                    }),
                    C = Boolean(p ? .contentLabel),
                    N = b ? "button" : x || "span",
                    A = {
                        "data-qa": "action-row",
                        ...v
                    };
                return (0, s.jsxs)(N, {
                    className: j,
                    onClick: b,
                    type: "button" === N ? "button" : void 0,
                    ref: g,
                    "aria-describedby": b ? p ? .descriptionHintId : void 0,
                    "aria-selected": p ? .ariaSelected,
                    "aria-checked": p ? .ariaChecked,
                    "aria-pressed": p ? .ariaPressed,
                    role: p ? .role,
                    ...A,
                    children: [a ? (0, s.jsx)("span", {
                        className: y,
                        children: a.content
                    }) : null, (0, s.jsx)(o.A, {
                        children: p ? .contentLabel
                    }), (0, s.jsxs)("span", {
                        className: k,
                        "aria-hidden": C,
                        children: [(0, s.jsx)("span", {
                            className: f,
                            "data-qa": "action-row-title",
                            children: "medium" === e.size ? (0, s.jsx)(m.Qi, {
                                ellipsis: !0,
                                children: e.text
                            }) : (0, s.jsx)(m.Qi, {
                                ellipsis: e.ellipsis,
                                breakWords: !e.ellipsis,
                                children: e.text
                            })
                        }), t ? .text ? (0, s.jsx)("span", {
                            className: "csms-action-row__hint",
                            "data-qa": "action-row-hint",
                            "aria-hidden": Boolean(p ? .descriptionHintId),
                            id: p ? .descriptionHintId,
                            children: (0, s.jsx)(m.Qi, {
                                ellipsis: t.ellipsis,
                                children: t.text
                            })
                        }) : null]
                    }), i ? (0, s.jsx)("span", {
                        className: "csms-action-row__label",
                        "aria-hidden": C,
                        children: (0, s.jsx)("span", {
                            className: "csms-action-row__label-text",
                            "data-qa": "action-row-value-text",
                            children: (0, s.jsx)(m.Qi, {
                                ellipsis: !0,
                                children: i
                            })
                        })
                    }) : null, "none" !== h ? .action && "label" !== h ? .action ? (0, s.jsx)("span", {
                        className: "csms-action-row__extra-placeholder",
                        "data-qa": "action-row-extra",
                        children: (0, s.jsxs)("span", {
                            className: "csms-action-row__extra",
                            "data-qa": "action-row-extra",
                            children: ["custom" === h.action && h.content ? h.content : null, "chevron" === h.action && (0, s.jsx)(r.A, {
                                name: "generic-chevron-right",
                                supportsRtl: !0
                            }), "checkbox" === h.action && h.checkbox ? (0, s.jsx)(l.A, { ...h.checkbox
                            }) : null, "toggle" === h.action && h.toggle ? (0, s.jsx)(d.A, { ...h.toggle
                            }) : null, "button" === h.action && h.button ? (0, s.jsx)(c.A, { ...h.button,
                                size: "micro"
                            }) : null]
                        })
                    }) : null]
                })
            }
        }
    }
]);
//# sourceMappingURL=1052.169bf1905ae54a7bbe15.js.map
"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [9232], {
        19232: function(t, e, r) {
            r.d(e, {
                A: function() {
                    return D
                }
            });
            r(52675), r(45700), r(2008), r(51629), r(74423), r(25276), r(62062), r(60739), r(89572), r(2892), r(67945), r(84185), r(83851), r(81278), r(79432), r(26099), r(3362), r(27495), r(21699), r(71761), r(5746), r(98992), r(54520), r(3949), r(81454), r(23500);
            var o = r(36521),
                n = r(99417),
                i = r(85208),
                s = r(89610),
                a = r(1978),
                u = r(18084),
                p = r(58544),
                c = r(76598),
                l = r(58385),
                d = r(3508),
                h = r(27378),
                v = r(71672),
                f = r(32308),
                _ = r(31709),
                m = r(92105),
                g = r(5586),
                A = r(73090),
                w = r(84256);
            var R = r(65297);

            function P(t, e) {
                var r = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    e && (o = o.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), r.push.apply(r, o)
                }
                return r
            }

            function b(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var r = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? P(Object(r), !0).forEach((function(e) {
                        y(t, e, r[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r)) : P(Object(r)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(r, e))
                    }))
                }
                return t
            }

            function y(t, e, r) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != typeof t || !t) return t;
                        var r = t[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var o = r.call(t, e || "default");
                            if ("object" != typeof o) return o;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == typeof e ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = r, t
            }
            var I = u.A.getLogger("ExternalProvider"),
                O = function(t) {
                    if (t || "undefined" == typeof window) {
                        if (!t) return ""
                    } else t = n.A.location.hostname;
                    var e = t.match(/\w+\.\w+$/);
                    return e ? e[0] : ""
                }(),
                S = "cb.html",
                C = ["https://localhost." + O + "/" + S],
                k = {
                    FOUND_CONNECTION_BLOCK: 1,
                    NOT_FOUND_CONNECTION_BLOCK: 3,
                    AUTH_ERROR: 2
                },
                E = d.A.get("persistence.auth.key");

            function j() {}

            function T(t) {
                return (t = b({}, t)).startImport && !t.returnRoute && (t.returnRoute = l.A.getUrl()), t
            }(0, i.A)(j.prototype, p.zb, {
                init: function() {
                    (0, m.A)(this), R.A.on(R.A.Session.LOGOUT, this.onSessionLogout_, this).on(R.A.Session.SESSION_CHANGED, this.deleteProvidersCache, this), this.providers_ = {}
                },
                EVENTS: k,
                providers_: {},
                authenticationState_: null,
                popupWindow_: null,
                popupCheckTimer_: null,
                handleAuthenticationFailure_: function() {
                    this.startImportReject_ && this.startImportReject_(), this.trigger(k.AUTH_ERROR)
                },
                onExternalProviderMessage_: function(t) {
                    var e, r, o = t.origin.search(O) >= 0,
                        i = null == t || null == (e = t.data) ? void 0 : e.href,
                        s = (null == i ? void 0 : i.includes(S)) && (null == i ? void 0 : i.includes(O));
                    if (o && s) {
                        var a = t.data.success,
                            u = this.authenticationState_;
                        if (!a) return this.removeStoredAuthData(), this.handleAuthenticationFailure_(), null;
                        this.authenticationState_.success = a, this.stopPopupCheckTimer_(), n.A.removeEventListener("message", this.onExternalProviderMessage_);
                        var p = null == t || null == (r = t.data) ? void 0 : r.href.match(W());
                        return p && (this.authenticationState_ = null, u.startImport ? this.startImportProgress(u) : this.processOauthState(u)), this.removeStoredAuthData(), this.popupWindow_.close(), this.popupWindow_ = null, p
                    }
                },
                login: function(t) {
                    void 0 === t && (t = {});
                    var e = t,
                        r = e.personId,
                        o = e.provider,
                        n = e.providerContext,
                        i = e.providerType;
                    if (!(0, f.Rg)(i) || !(0, f.Rg)(n)) {
                        var s = "The providerType or providerContext is not valid: type: " + i + " context: " + n;
                        return I.error(s), Promise.reject(new Error(s))
                    }
                    if (r) {
                        if (o) return this.onLogin_(t, o)
                    } else {
                        var a = this.getCachedProvider_(n, i) || o;
                        if (a) return this.onLogin_(t, a)
                    }
                    return this.getProvider({
                        providerType: i,
                        providerContext: n,
                        personId: r,
                        referrer: t.referrer,
                        useSync: t.useSync
                    }).then(this.onLogin_.bind(this, t))
                },
                loginAsPromise: function(t) {
                    var e = this;
                    return new Promise((function(r, o) {
                        function n(t) {
                            this.off(k.AUTH_ERROR, n, this), t ? o(t) : r(!1)
                        }
                        e.on(k.AUTH_ERROR, n, e), e.login(b(b({}, t), {}, {
                            callback: function(t) {
                                e.off(k.AUTH_ERROR, n, e), r(t)
                            }
                        }))
                    }))
                },
                onLogin_: function(t, e) {
                    var r;
                    t.provider = e, t.providerId = e.id;
                    var i = this.authenticationState_ = t;
                    if (this.popupWindow_ && !this.popupWindow_.closed) try {
                        this.popupWindow_.close(), this.popupWindow_ = null
                    } catch (t) {
                        return
                    }
                    n.A.removeEventListener("message", this.onExternalProviderMessage_), n.A.addEventListener("message", this.onExternalProviderMessage_);
                    var s, a = null == (r = e.auth_data) ? void 0 : r.oauth_url;
                    o.A.cantCloseWindows && !t.dontRedirect || (0, c.a)() ? this.popupBlockedFlow_(i, a, t) : (n.A._badoo_noLoginPopup || (s = this.popupWindow_ = n.A.open(a, "_externalProvider")), !this.isWindowBlocked_(s) || t.dontRedirect ? (this.setStoredAuthData(T(i)), this.startPopupCheckTimer_()) : this.popupBlockedFlow_(i, a, t))
                },
                isWindowBlocked_: function(t) {
                    return !t || t.closed
                },
                popupBlockedFlow_: function(t, e, r) {
                    n.A.removeEventListener("message", this.onExternalProviderMessage_), this.popupWindow_ = null, this.setStoredAuthData(T(t)), r.skipRememberStates || l.A.saveHistory(2), r.callback && r.callback(), n.A.location = e
                },
                startPopupCheckTimer_: function() {
                    var t = this;
                    this.popupCheckTimer_ || (this.popupCheckTimer_ = setInterval((function() {
                        t.popupWindow_ && !t.popupWindow_.closed && t.popupWindow_.top || (t.stopPopupCheckTimer_(), t.popupWindow_ = null, t.authenticationState_.success || t.handleAuthenticationFailure_())
                    }), 500))
                },
                stopPopupCheckTimer_: function() {
                    clearInterval(this.popupCheckTimer_), this.popupCheckTimer_ = null
                },
                deleteProvidersCache: function() {
                    this.providers_ = {}
                },
                getProvider: function(t) {
                    return this.getSupportedProviders(t).then((function(e) {
                        var r = e[t.providerType];
                        if (!r) throw new Error("No matching external provider.");
                        return r
                    }))
                },
                getCachedProvider_: function(t, e) {
                    var r = this.providers_[t] || null;
                    return e ? r && (r[e] || null) : r
                },
                setProviderData: function(t, e) {
                    var r = this;
                    t && e && (this.providers_[t] || (this.providers_[t] = {}), e.forEach((function(e) {
                        r.providers_[t][e.type] = e
                    })))
                },
                getSupportedProviders: function(t) {
                    var e = this,
                        r = t.personId;
                    if (!r) {
                        var o = this.getCachedProvider_(t.providerContext);
                        if (o) return Promise.resolve(o)
                    }
                    return "boolean" == typeof t.referrer && (t.trackJinba = t.referrer, t.referrer = null), new Promise((function(o, n) {
                        var i = {
                            context: t.providerContext
                        };
                        r && (i.person_id = r), t.referrer && (i.referrer = t.referrer);
                        var s = new _.Ay(362, i).onResponse(363, (function(n) {
                            if (r) {
                                var i = function(t) {
                                    var e = {};
                                    return t.forEach((function(t) {
                                        e[t.type] = t
                                    })), e
                                }(n.providers);
                                o(i)
                            } else void 0 !== n.providers && e.setProviderData(t.providerContext, n.providers), o(e.providers_[t.providerContext] || {})
                        })).onResponse(1, (function(t) {
                            L(t), n(t)
                        })).onError(n);
                        t.trackJinba && h.A.trackRPC(s), s.setIsSynchronous(t.useSync), s.request()
                    }))
                },
                onSessionLogout_: function() {
                    this.stopPopupCheckTimer_(), this.popupWindow_ = null, this.authenticationState_ = null, this.removeStoredAuthData(), this.deleteProvidersCache()
                },
                startImport: function(t) {
                    var e = this;
                    t.startImport = !0;
                    var r = new Promise((function(t, r) {
                        e.startImportResolve_ = t, e.startImportReject_ = r
                    }));
                    return t.returnRoute && l.A.navigate(t.returnRoute, t.replaceCurrentUrl, b(b({}, t), {}, {
                        importPromise: r
                    })), this.login(t), r
                },
                startImportProgress: function(t) {
                    var e = this,
                        r = t.providerId,
                        o = t.providerContext,
                        n = t.referrer,
                        i = t.personId,
                        s = t.importFlow,
                        a = t.inviteFlow,
                        u = t.albumType,
                        p = t.allAlbums,
                        c = t.limit;
                    if (!r) return Promise.reject(new Error("No provider ID given or found"));
                    if ("1" === r) return I.error("Wrong provider ID: 1"), Promise.reject(new Error("Wrong provider ID: 1"));
                    var l = {
                        auth_credentials: {
                            provider_id: r,
                            context: o,
                            natively_authenticated: !1
                        }
                    };
                    if (n && (l.context = n), 1 === o) {
                        var d = {};
                        i && (d.person_id = i), s && (d.flow = s), a && (d.invite_flow = a), Object.keys(d).length > 0 && (l.start_contact_import_data = d)
                    } else if (2 === o || 14 === o) {
                        var h = {
                            all_albums: Boolean(p)
                        };
                        u && (h.album_type = u), l.start_photo_import_data = h, c && (l.limit = c), l.force_new_import = !0
                    }
                    return new Promise((function(t, r) {
                        var o = function(t) {
                            I.error("Start import failed: " + t), e.startImportReject_ && (e.startImportReject_(t), e.startImportReject_ = null), r(t)
                        };
                        new _.Ay(364, l).onResponse(365, (function(o) {
                            e.checkImport_(t, r, o)
                        })).onResponse(1, (function(t) {
                            L(t), o(t)
                        })).onError(o).request()
                    }))
                },
                checkImport_: function(t, e, r, o) {
                    var n = this;
                    if (r.complete) r.success ? this.startImportResolve_ ? (this.startImportResolve_(r), this.startImportResolve_ = null) : t(r) : this.startImportReject_ ? (this.startImportReject_(r), this.startImportReject_ = null) : e(r);
                    else {
                        var i = function(t) {
                                I.error("Check import failed: " + t), n.startImportReject_ && (n.startImportReject_(t), n.startImportReject_ = null), e(t)
                            },
                            s = new _.Ay(366, {
                                import_id: r.import_id
                            }).onResponse(365, (function(r) {
                                n.checkImport_(t, e, r, o)
                            })).onResponse(1, (function(t) {
                                L(t), i(t)
                            })).onError(i);
                        (o = ("number" == typeof o ? o : 0) + 500) > 7500 ? (this.startImportReject_ && (this.startImportReject_(r), this.startImportResolve_ = null), e(r)) : setTimeout(s.request.bind(s), o)
                    }
                },
                finishImport: function(t, e, r) {
                    return e || (e = {}), t && (e.import_id = t), r && (e.status = r), new Promise((function(t, r) {
                        new _.Ay(367, e).onResponse(369, (function(e) {
                            e.getSuccess() ? t(e) : r(new Error("Finish import returned unsuccessful result"))
                        })).onResponse(1, (function(t) {
                            L(t), r(t)
                        })).onError(r).request()
                    }))
                },
                finishFriendsImport: function(t, e, r, o) {
                    var n = {
                        contacts: (e = e || []).map((function(t) {
                            return {
                                contacts: [{
                                    contact: t,
                                    type: r
                                }],
                                name: ""
                            }
                        })),
                        sms_already_sent: !1
                    };
                    return "string" == typeof o && (n.facebook_request_id = o), this.finishImport(t, {
                        finish_contact_import_data: n
                    })
                },
                processOauthState: function(t, e) {
                    (0, s.A)(t.callback) && t.callback(t), 3 === t.providerContext && t.needsAppLogin ? function(t) {
                        var e = t.authState,
                            r = t.redirectUrl,
                            o = e.providerId,
                            n = e.providerType,
                            i = e.returnRoute,
                            s = e.activationPlace;
                        A.A.loginExternalProvider({
                            providerId: o,
                            redirectUrl: r,
                            providerType: n,
                            callback: function(t) {
                                t && (i ? l.A.navigate(i, e, !0) : (0, w.A)(t, l.A, g.A) || l.A.navigate(d.A.get("default.page"), !0))
                            },
                            activationPlace: s
                        })
                    }({
                        authState: t,
                        redirectUrl: this.getRedirectUrl(t.providerType)
                    }) : (0, a.A)((function() {
                        var r = "string" == typeof t.returnRoute ? t.returnRoute.replace("__ID__", t.providerId) : d.A.get("default.page");
                        l.A.navigate(r, !!e || t.replaceCurrentUrl, t)
                    }))
                },
                getStoredAuthData: function() {
                    return v.A.getObject(E)
                },
                setStoredAuthData: function(t) {
                    return v.A.saveObject(E, t)
                },
                removeStoredAuthData: function() {
                    return v.A.remove(E)
                },
                getRedirectUrl: function(t) {
                    var e = W();
                    return 4 === t && -1 === C.indexOf(e) && (e = C[0]), e
                }
            });
            var x = new j;
            x.init();
            var D = x;

            function W() {
                return "https://" + n.A.location.hostname + "/" + S
            }

            function L(t) {
                _.aV.send(new _.XX(1, t).toJSON())
            }
        }
    }
]);
//# sourceMappingURL=9232.b5ea94009c0750580bc2.js.map
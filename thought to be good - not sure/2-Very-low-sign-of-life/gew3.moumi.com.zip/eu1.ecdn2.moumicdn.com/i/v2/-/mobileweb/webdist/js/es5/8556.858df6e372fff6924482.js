"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [8556], {
        54864: function(e, t, s) {
            s.d(t, {
                A: function() {
                    return r
                }
            });
            s(28706);
            var n = s(15566),
                i = [210, 370, 660, 732, 670, 431, 93, 541, 220, 230, 420, 410, 250, 610, 580, 290, 304, 550, 200, 330, 331, 310, 50, 490, 470, 750, 460, 560, 291, 100, 360, 492, 1110, 494, 1424, 662, 730, 1457],
                r = [].concat(i, [650, 770, 670, 600, 320, 340, 480, 311, 1200, 663, 1434]),
                a = [210, 370, 230, 420, 290, 200, 330, 310, 490, 492, 1110, 340, 480, 291, 100, 494, 360],
                u = [40, 210, 370, 60, 70, 80, 93, 91, 492, 220, 10, 230, 420, 270, 290, 200, 330, 320, 20, 310, 690, 50, 490, 340, 470, 750, 1110, 460, 480, 291, 100, 311, 494, 360, 71, 231, 1436],
                c = [700, 210, 230, 432, 545, 250, 790, 270, 580, 280, 290, 600, 200, 330, 340, 291, 494, 360],
                h = [230, 432, 200, 330, 340, 291, 494],
                o = [].concat(c, [583]),
                l = [210, 650, 700, 541, 230, 630, 250, 610, 580, 280, 200, 330, 331, 340, 640, 291, 705],
                _ = [200, 210, 340, 871, 560, 370, 730, 662, 330, 290],
                g = {
                    getEncountersFilter: function() {
                        var e = new n.KkJ;
                        return e.setProjection(i), e.setRequestInterests((new n.ZzE).setLimit(500)), e.setRequestAlbums([(new n.Nij).setAlbumType(7), (new n.Nij).setAlbumType(2), (new n.Nij).setAlbumType(12).setExternalProvider(12).setOffset(0).setCount(24)]), e.setQuickChatRequest((new n.dRV).setMessageCount(0)), e
                    },
                    getProfileFilter: function(e, t) {
                        var s = new n.KkJ,
                            i = [].concat(r);
                        return 2 === t && i.push(1436), s.setProjection(i), s.setRequestAlbums([(new n.Nij).setAlbumType(2), (new n.Nij).setAlbumType(7), (new n.Nij).setAlbumType(12).setExternalProvider(12).setOffset(0).setCount(24)]), "string" == typeof e && (s.setRequestInterests((new n.ZzE).setUserId(e).setLimit(500)), s.setQuickChatRequest((new n.dRV).setMessageCount(0))), s
                    },
                    getUnauthenticatedProfileFilter: function(e) {
                        var t = new n.KkJ;
                        return t.setProjection(a), t.setRequestAlbums([(new n.Nij).setAlbumType(2), (new n.Nij).setAlbumType(7)]), "string" == typeof e && t.setRequestInterests((new n.ZzE).setUserId(e).setLimit(500)), t
                    },
                    getOwnProfileFilter: function() {
                        var e = this.getProfileFilter();
                        return e.setProjection(u), e.setRequestInterests((new n.ZzE).setLimit(500)), e.delQuickChatRequest(), e
                    },
                    getLikedYouProfileFilter: function(e) {
                        return (new n.KkJ).setProfilePhotoRequest(e).setProjection(_).setSystemBadges([6]).setRequestAlbums([(new n.Nij).setAlbumType(2)])
                    },
                    getFolderFilter: function(e) {
                        var t, s = (new n.qUb).setReturnLargeUrl(!0);
                        switch (e) {
                            case 2:
                                t = h;
                                break;
                            case 23:
                            case 22:
                            default:
                                t = c;
                                break;
                            case 6:
                                t = o;
                                break;
                            case 26:
                                t = l;
                                break;
                            case 3:
                                return this.getLikedYouProfileFilter(s)
                        }
                        return (new n.KkJ).setProfilePhotoRequest(s).setProjection(t)
                    }
                };
            g.ENCOUNTERS_PROJECTION = i, t.h = g
        },
        57917: function(e, t, s) {
            s(48598), s(62062), s(60739), s(5506), s(26099), s(58940), s(3362), s(27495), s(98992), s(81454);
            var n = s(85208),
                i = s(1978),
                r = s(42302),
                a = s(5664),
                u = s(99417),
                c = s(3508),
                h = s(58544),
                o = s(84230),
                l = s(15129),
                _ = s(18084),
                g = s(20679),
                f = s(35837),
                d = s(23735),
                m = {
                    INVALIDATED: "invalidated"
                };

            function p(e) {
                if (null != e && e.name && (this.name = e.name), this.log = _.A.getLogger(this.name.replace(/Model$/, "") + "Model"), this.useCache_) {
                    this.cache_ = o.A.getInstance("GPB" + this.name);
                    var t = parseInt(this.cache_.get("version"), 10);
                    (isNaN(t) || t !== this.getVersion_()) && this.invalidateAll(), this.cache_.on(o.A.EVENTS.INVALIDATED, this.onCacheInvalidated_, this)
                }
                this.init_(e)
            }(0, n.A)(p.prototype, h.zb, {
                name: "",
                cache_: null,
                useCache_: !0,
                commitCache: !0,
                init_: r.A,
                getRequestMessageType: null,
                getResponseMessageType: null,
                preventMultiple: !1,
                pendingRequests_: {},
                trackNext_: !1,
                maxRetries_: c.A.get("api.retries"),
                getRequest_: function(e, t, s, n) {
                    var i = new d.Ay(e, s).setRetryCount(this.maxRetries_).on(t, n, this);
                    return i.request(), i
                },
                setRequestMessageType: null,
                setResponseMessageType: null,
                setRequest_: function(e, t) {
                    return new d.Ay(this.setRequestMessageType, e).setRetryCount(this.maxRetries_).on(this.setResponseMessageType, t, this).request()
                },
                get: function(e) {
                    return this.get_(this.getRequestMessageType, this.getResponseMessageType, e)
                },
                validateCache_: function(e, t) {
                    return !!e
                },
                startJinbaEvent_: function(e, t) {
                    g.A.getInstance().eventStart(e + "-api-call", 7, {
                        group: "api-call",
                        message_type: t
                    })
                },
                endJinbaEvent_: function(e, t) {
                    this.trackNext_ = !1, g.A.getInstance().eventEnd(e + "-api-call", {
                        is_cached: t
                    })
                },
                trackNext: function() {
                    return this.trackNext_ = !0, this
                },
                get_: function(e, t, s, n) {
                    var i, r = null,
                        u = !1;
                    if (this.trackNext_ && (i = (0, a.A)(), this.startJinbaEvent_(i, e)), this.shouldCache_(e, s)) {
                        var c = this.getFromCache_(e, s, n);
                        null != c && c.length && (c.fromCache = !0, r = Promise.resolve(c))
                    }
                    return null === r ? this.fetch_(e, t, s, i) : (this.trackNext_ && (u = !0), this.resolvePromise_(r, i, u))
                },
                getFromCache_: function(e, t, s) {
                    var n = this.getCacheKey_(e, t),
                        i = this.cache_.get(n);
                    return this.validateCache_(i, s) ? i.map((function(e) {
                        if (!e) return e;
                        var t = (0, f.A)(e);
                        return t.fromCache = !0, t
                    })) : null
                },
                fetch: function(e) {
                    return this.fetch_(this.getRequestMessageType, this.getResponseMessageType, e)
                },
                fetch_: function(e, t, s, n) {
                    var i = this;
                    !n && this.trackNext_ && (n = (0, a.A)(), this.startJinbaEvent_(n, e));
                    var r, u = this.shouldCache_(e, s);
                    u && (r = this.getCacheKey_(e, s));
                    var c = this.preventMultiple && u,
                        h = c && this.getMatchingPendingRequest(e, s);
                    if (h) return this.resolvePromise_(h, n, !1);
                    var o = new Promise((function(n, r) {
                        i.getRequest_(e, t, s, (function(t) {
                            if (c && i.removePendingRequest(e, s, o), !t || t instanceof d.Qc && t._type === d.a5.HANDLER_UNSATISFIED) {
                                for (var a = arguments.length, u = new Array(a > 1 ? a - 1 : 0), h = 1; h < a; h++) u[h - 1] = arguments[h];
                                n(u)
                            } else r(t)
                        }))
                    }));
                    return u && (o = o.then(this.cacheResponse_.bind(this, r, this.getCacheTime_(e, s)))), c && this.addPendingRequest(e, s, o), this.resolvePromise_(o, n, !1)
                },
                getMatchingPendingRequest: function(e, t) {
                    var s = this.getCacheKey_(e, t);
                    return this.pendingRequests_[s]
                },
                addPendingRequest: function(e, t, s) {
                    var n = this.getCacheKey_(e, t);
                    this.pendingRequests_[n] = s
                },
                removePendingRequest: function(e, t) {
                    var s = this.getCacheKey_(e, t);
                    delete this.pendingRequests_[s]
                },
                set: function(e) {
                    var t, s = this;
                    this.trackNext_ && (t = (0, a.A)(), this.startJinbaEvent_(t, this.setRequestMessageType));
                    var n = new Promise((function(t, n) {
                        s.setRequest_(e, (function(e) {
                            if (e) n(e);
                            else {
                                for (var s = arguments.length, i = new Array(s > 1 ? s - 1 : 0), r = 1; r < s; r++) i[r - 1] = arguments[r];
                                t(i)
                            }
                        }))
                    }));
                    return this.resolvePromise_(n, t, !1)
                },
                shouldCache_: function(e, t) {
                    return this.useCache_
                },
                shouldCommitCache_: function(e) {
                    return this.commitCache
                },
                cacheResponse_: function(e, t, s) {
                    var n = (s || []).map((function(e) {
                        return e ? e.toJSON() : null
                    }));
                    return this.cache_.put(e, n, {
                        ttl: t,
                        noCommit: !this.shouldCommitCache_(s)
                    }), s
                },
                resolvePromise_: function(e, t, s) {
                    if ("string" == typeof t && this.trackNext_) {
                        var n = this.endJinbaEvent_.bind(this, t, s);
                        (0, i.A)((function() {
                            e.then(n, n)
                        }))
                    }
                    return e
                },
                getCacheTime_: function(e, t) {
                    return 6e4 * (u.A._badoo_cacheTime || 15)
                },
                getCacheKey_: function(e, t) {
                    return e + ":" + ("string" == typeof t ? t : Object.entries((null == t ? void 0 : t._data) || t || {}).map((function(e) {
                        return e[0] + "=" + e[1]
                    })).join("&"))
                },
                invalidate: function(e, t, s) {
                    this.useCache_ && (e ? this.cache_.invalidate(e, t, s) : this.invalidateAll())
                },
                invalidateAll: function(e) {
                    this.useCache_ && (this.cache_.invalidateAll(!0 === e), this.cache_.put("version", this.getVersion_(), {
                        ttl: 2592e6
                    }))
                },
                onCacheInvalidated_: function(e) {
                    this.trigger(m.INVALIDATED, e)
                },
                getRequestTypeByObject_: function() {},
                getRequestByObject_: function() {},
                getCacheByObject_: function() {},
                inform: function(e) {
                    var t = this.getRequestTypeByObject_(e),
                        s = this.getRequestByObject_(e),
                        n = this.getCacheByObject_(e);
                    return !(!t || void 0 === s || !n) && (!!this.shouldCache_(t, s) && (this.cacheResponse_(this.getCacheKey_(t, s), this.getCacheTime_(t, s), n), !0))
                },
                getVersion_: function() {
                    return 1
                }
            }), p.extend = l.A, p.EVENTS = m, t.A = p
        }
    }
]);
//# sourceMappingURL=8556.858df6e372fff6924482.js.map
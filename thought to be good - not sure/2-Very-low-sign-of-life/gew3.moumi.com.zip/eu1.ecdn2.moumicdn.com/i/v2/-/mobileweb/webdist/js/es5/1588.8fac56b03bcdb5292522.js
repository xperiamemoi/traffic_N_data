"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [1588], {
        24500: function(t, i, e) {
            e(52675), e(89463), e(50113), e(48980), e(26099), e(98992), e(72577);
            var n = e(96540),
                o = e(80021),
                a = e(93019),
                r = e(79860),
                c = e(4571),
                s = e(46770),
                u = e(51634),
                f = e(40578),
                l = e(30784),
                h = e(20017),
                d = e(74848);
            i.A = function(t) {
                var i, e = t.header,
                    A = t.description,
                    p = t.buttonText,
                    v = t.intentions,
                    N = t.onConfirm,
                    g = t.preselectedIntentionId,
                    T = (0, n.useState)(g || (null == (i = v.find((function(t) {
                        return t.default_for_new_users
                    }))) ? void 0 : i.tiw_phrase_id)),
                    I = T[0],
                    O = T[1],
                    m = (0, a.p)(v, I, (function(t) {
                        O(t), (0, r.sx)(332, {
                            element: 1767,
                            position: v.findIndex((function(i) {
                                return i.tiw_phrase_id === t
                            }))
                        })
                    }));
                return (0, d.jsxs)(c.A, {
                    isCompact: !0,
                    children: [(0, d.jsx)(f.A, {
                        text: e,
                        tag: "h2"
                    }), (0, d.jsx)(l.A, {
                        text: A
                    }), (0, d.jsx)(u.A, {
                        children: (0, d.jsx)(o.A, {
                            intentions: m
                        })
                    }), (0, d.jsx)(s.A, {
                        children: (0, d.jsx)(h.A, {
                            text: p,
                            onClick: function() {
                                I && N(I), (0, r.sx)(332, {
                                    element: 395
                                })
                            },
                            dataQA: {
                                "data-qa": "tiw-save-button"
                            }
                        })
                    })]
                })
            }
        },
        31190: function(t, i, e) {
            e(10287), e(28706), e(50113), e(48980), e(74423), e(25276), e(60739), e(26099), e(27495), e(11392);
            var n, o = e(1978),
                a = e(3508),
                r = e(31709),
                c = e(61155),
                s = e(13264),
                u = e(65297),
                f = e(58385),
                l = e(40075),
                h = e(36521),
                d = e(73090),
                A = e(93529),
                p = e(37414),
                v = e(30685),
                N = e(61405),
                g = e(75248),
                T = e(13614),
                I = e(65422),
                O = e(41025),
                m = e(30922),
                _ = e(7541),
                R = e(1168),
                w = e(39778),
                b = e(88309),
                S = e(28030),
                x = e(20387),
                E = e(31087),
                y = e(49952),
                k = e(37905),
                P = e(1765),
                C = e(59977),
                U = e(48788),
                M = e(15566),
                B = e(35837),
                V = e(74389),
                j = e(60808),
                D = e(83186),
                H = e(95773),
                F = e(74848);

            function L(t, i) {
                return L = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, i) {
                    return t.__proto__ = i, t
                }, L(t, i)
            }
            var q, G = [81, 60, 66, 50, 3, 56, 78, 73, 44, 89, 120, 2, 112, 163, 170, 171, 140],
                Q = [7, 1],
                J = [V.x.SPP_TRIAL, V.x.PAY];

            function W(t) {
                return -1 !== G.indexOf(t.getType())
            }
            var Y = function(t) {
                function i() {
                    for (var i, e = arguments.length, n = new Array(e), o = 0; o < e; o++) n[o] = arguments[o];
                    return (i = t.call.apply(t, [this].concat(n)) || this).queue = [], i.ignorePhoneVerificationNotification = !1, i.currentNotification = null, i
                }
                var e, n;
                n = t, (e = i).prototype = Object.create(n.prototype), e.prototype.constructor = e, L(e, n);
                var s = i.prototype;
                return s.init = function() {
                    return R.A.onUnblock(this.onAppUnblocked_, this), this.ignorePhoneVerificationNotification = !1, this.queue = [], this
                }, s.onAppUnblocked_ = function() {
                    this.advanceQueue()
                }, s.onStart = function() {
                    g.A.getInstance().on(g.A.Type.NOTIFICATION, this.onClientNotification, this), g.A.getInstance().on(g.A.Type.SYSTEM_NOTIFICATION, this.onSystemNotification, this)
                }, s.onStop = function() {
                    return g.A.getInstance().off(g.A.Type.NOTIFICATION, this.onClientNotification, this), g.A.getInstance().off(g.A.Type.SYSTEM_NOTIFICATION, this.onSystemNotification, this), t.prototype.onStop.call(this)
                }, s.onSystemNotification = function(t) {
                    switch (t.id) {
                        case 5:
                        case 2:
                        case 6:
                            E.A.getInstance().invalidate(d.A.getUserId())
                    }
                }, s.onClientNotification = function(t) {
                    this.addToQueue((0, B.A)(t, M.z5N)), this.advanceQueue()
                }, s.addToQueue = function(t) {
                    if (t instanceof M.z5N && "string" == typeof t.getId() && !this.isDuplicated(t) && !(t.getMessage("").startsWith("Connected to QA") || h.A.selenium && t.getMessage("").startsWith("Connected to "))) {
                        var i = k.A.controller;
                        null != i && i.discardGenericPromos && 81 === t.getType() || this.ignorePhoneVerificationNotification && K(t) || this.queue.push(t)
                    }
                }, s.isDuplicated = function(t) {
                    var i, e = t.getId();
                    if (e === (null == (i = this.currentNotification) ? void 0 : i.getId())) return !0;
                    for (var n = 0; n < this.queue.length; n += 1)
                        if (this.queue[n].getId() === e) return !0;
                    return !1
                }, s.advanceQueue = function() {
                    var t;
                    this.queue.length && null === this.currentNotification && (this.currentNotification = this.queue.shift(), W(t = this.currentNotification) || -1 === Q.indexOf(t.getAction()) || function(t) {
                        return 96 === t.getType()
                    }(t) ? W(this.currentNotification) ? this.overlayNotification() : ! function(t) {
                        return !W(t) && 9 === t.getAction()
                    }(this.currentNotification) ? this.notificationHandled() : this.spendCredits() : this.notifyMessage())
                }, s.performNotificationAction = function() {
                    var t, i;
                    12 === (null == (t = this.currentNotification) ? void 0 : t.getType()) ? (i = {
                        back: a.A.get("default.page"),
                        hotPanelData: {
                            activationPlace: 48
                        },
                        productType: 1
                    }, O.A.navigateToPayment(i), this.notificationHandled()) : A.A.showNotification({
                        type: A.A.TYPES.ERROR
                    })
                }, s.overlayNotification = function() {
                    var t = this.currentNotification;
                    if (t) {
                        var i = t.getType(),
                            e = t.getPromoBlock(),
                            n = e ? e.getPromoBlockType() : null,
                            o = t.toJSON();
                        this.handleOverlayNotification({
                            type: i,
                            promo: e,
                            promoBlockType: n,
                            notificationJSON: o,
                            notification: t
                        }) && (0, y.cj)(this.notificationHandled.bind(this))
                    }
                }, s.handleOverlayNotification = function(t) {
                    var i, e = t.type,
                        n = t.promo,
                        o = t.promoBlockType,
                        a = t.notificationJSON,
                        r = t.notification,
                        s = !0;
                    switch (e) {
                        case 78:
                            ! function(t, i) {
                                var e, n;
                                t && null != i && null != (e = i.pictures) && null != (e = e[0]) && e.video && (0, T.NN)(null == (n = i.pictures) || null == (n = n[0].video) ? void 0 : n.url).then((function(i) {
                                    var e = i[0];
                                    f.A.navigate(V.x.UPLOAD_VIDEO, {
                                        clientNotification: t,
                                        src: e
                                    })
                                })).catch((function(t) {
                                    return (0, H.gf)(t, "Upload video")
                                }))
                            }(a, n.toJSON());
                            break;
                        case 120:
                            this.showPassiveMatches(a), s = !1;
                            break;
                        case 2:
                            this.showTiwMappingPopup(a), s = !1;
                            break;
                        case 3:
                            setTimeout((function() {
                                return f.A.navigate(V.x.MODERATED_PHOTOS, {
                                    notification: a
                                })
                            }), 700);
                            break;
                        case 81:
                            if (61 === o) return;
                            if (153 === o && !S.A.isDevFeatureEnabled(C.v.STILL_YOUR_NUMBER)) return;
                            s = this.handleOverlayNotificationGenericPromo({
                                promo: n,
                                promoBlockType: o,
                                notificationJSON: a
                            });
                            break;
                        case 50:
                            f.A.navigate(V.x.NICE_NAME, !1, {
                                notification: a
                            });
                            break;
                        case 44:
                            f.A.navigate(V.x.ABUSE_WARNING, !1, {
                                notification: a
                            });
                            break;
                        case 73:
                            92 === o ? f.A.navigate(V.x.NEVER_LOOSE_ACCOUNT, !1, {
                                notification: a,
                                isNotification: "true"
                            }) : P.A.handleNotification(r);
                            break;
                        case 60:
                            _.A.show(r);
                            break;
                        case 56:
                            var u = f.A.getUrl();
                            J.find((function(t) {
                                return u.startsWith(t)
                            })) || f.A.navigate(V.x.SPP_TRIAL, !1, {
                                returnTo: u,
                                context: 45
                            });
                            break;
                        case 89:
                            if (148 === (null == (i = a.promo_block) ? void 0 : i.promo_block_type)) {
                                c.A.setAsReached(), f.A.navigate(V.x.ENCOUNTERS_ONBOARDING_PROMO, !1, {
                                    notification: a
                                });
                                break
                            }
                            f.A.navigate(V.x.NEW_USER_SUBSTITUTE, !1, {
                                notification: a
                            });
                            break;
                        case 112:
                            this.showCreditsFeatureFinished(a);
                            break;
                        case 163:
                            this.showAppInstallNudgeNotification(a);
                            break;
                        case 170:
                            this.showGroupPhotoUpload(a), this.notificationHandled(), s = !1;
                            break;
                        case 171:
                            f.A.navigate(V.x.PHOTOS_AUTO_BLUR, !1, {
                                notification: a
                            }), this.notificationHandled(), s = !1;
                            break;
                        case 140:
                            this.showUnavailableSubscriptionFeaturesNotification(a), this.notificationHandled();
                            break;
                        default:
                            s = !1
                    }
                    return s
                }, s.handleOverlayNotificationGenericPromo = function(t) {
                    var i = t.promo,
                        e = t.promoBlockType,
                        n = t.notificationJSON;
                    if (165 === e) return f.A.navigate(V.x.MESSENGER_MINI_GAME_PROMO, {
                        notification: n,
                        promoBlock: i
                    }), !1;
                    if (69 === e) return f.A.navigate(V.x.CONFIRM_EMAIL, {
                        notification: n
                    }), !1;
                    if (222 === e) return f.A.navigate(V.x.MODERATED_PHOTOS, {
                        notification: n
                    }), !1;
                    if (346 === e) return f.A.navigate(V.x.PROFILE_QUESTIONS_CHAT_BLOCKER, {
                        notification: n
                    }), !1;
                    var a = n.id.replace(/_/g, "-"),
                        r = [V.x.MARKETING_SUBSCRIPTION];
                    return [].concat(r, [V.x.ATTENTION_BOOST_REMINDER, V.x.EXTRA_SHOWS_REMINDER, V.x.RISE_UP_REMINDER, V.x.IS_THIS_STILL_YOUR_NUMBER]).includes(a) ? (0, o.A)((function() {
                        f.A.navigate(a, {
                            notification: n
                        })
                    })) : this.log.error("The notification with id " + n.id + " has no matching route."), r.includes(a)
                }, s.spendCredits = function() {
                    var t, i, e, n = this;
                    if (f.A.getLocation().routeName !== V.x.PAY) {
                        U.A.set(!0);
                        var o = (0, b.A)();
                        this.renderReactView((0, F.jsx)(w.A, {
                            header: null == (t = this.currentNotification) ? void 0 : t.getTitle(),
                            message: null == (i = this.currentNotification) ? void 0 : i.getMessage(),
                            confirmLabel: null == (e = this.currentNotification) ? void 0 : e.getActionText(),
                            cancelLabel: l.Ay.get(451),
                            isOpen: !0,
                            onConfirm: function() {
                                n.performNotificationAction(), U.A.set(!1), n.removeReactView(o)
                            },
                            onCancel: function() {
                                n.handleDecline(), U.A.set(!1), n.removeReactView(o)
                            }
                        }), o)
                    } else this.notificationHandled()
                }, s.showPassiveMatches = function(t) {
                    var i = this;
                    U.A.set(!0);
                    var e = this.renderReactView((0, F.jsx)(v.A, {
                        promoBlocks: t.promo_blocks,
                        onClose: function() {
                            U.A.set(!1), i.removeReactView(e)
                        }
                    }), this.createElement()[0])
                }, s.showTiwMappingPopup = function(t) {
                    var i = this;
                    U.A.set(!0);
                    var e = this.renderReactView((0, F.jsx)(j.A, {
                        promoBlocks: t.promo_blocks,
                        onClose: function() {
                            U.A.set(!1), i.removeReactView(e)
                        }
                    }), this.createElement()[0])
                }, s.showCreditsFeatureFinished = function(t) {
                    var i = this;
                    U.A.set(!0);
                    var e = this.renderReactView((0, F.jsx)(I.A, {
                        promoBlock: t.promo_block,
                        onClose: function() {
                            U.A.set(!1), i.removeReactView(e)
                        }
                    }), this.createElement()[0])
                }, s.showAppInstallNudgeNotification = function(t) {
                    var i = this;
                    U.A.set(!0);
                    var e = this.renderReactView((0, F.jsx)(D.A, {
                        promoBlock: t.promo_block,
                        onClose: function() {
                            U.A.set(!1), i.removeReactView(e)
                        }
                    }), this.createElement()[0])
                }, s.showGroupPhotoUpload = function(t) {
                    var i = this;
                    U.A.set(!0);
                    var e = this.renderReactView((0, F.jsx)(p.A, {
                        notification: t,
                        onClose: function() {
                            U.A.set(!1), i.removeReactView(e)
                        }
                    }), this.createElement()[0])
                }, s.showUnavailableSubscriptionFeaturesNotification = function(t) {
                    var i = this;
                    U.A.set(!0);
                    var e = this.renderReactView((0, F.jsx)(N.A, {
                        notification: t,
                        onClose: function() {
                            U.A.set(!1), i.removeReactView(e)
                        }
                    }), this.createElement()[0])
                }, s.notifyMessage = function() {
                    var t = this.currentNotification;
                    this.clearCurrentNotification(), t && (t.getTransactionIdentifier() ? m.A.processClientNotification(t.toJSON()) : u.A.trigger(u.A.SHOW_NOTIFICATION, t))
                }, s.handleDecline = function() {
                    var t;
                    12 === (null == (t = this.currentNotification) ? void 0 : t.getType()) && (E.A.getInstance().invalidate(d.A.getUserId()), x.A.getInstance().invalidateSppFolders()), this.notificationHandled()
                }, s.notificationHandled = function(t) {
                    this.currentNotification && (t = "string" == typeof t ? t : this.currentNotification.getId()) === this.currentNotification.getId() && (new r.Ay(159, {
                        value: t
                    }).request(), this.clearCurrentNotification(), this.advanceQueue())
                }, s.clearCurrentNotification = function() {
                    this.currentNotification = null
                }, s.clearPhoneVerificationNotification = function() {
                    var t = this.queue.findIndex(K);
                    this.ignorePhoneVerificationNotification = !0, t > -1 && this.queue.splice(t, 1)
                }, i
            }(s.A);

            function K(t) {
                var i = t.getPromoBlock();
                return !!Boolean(i) && 94 === i.getPromoBlockType()
            }
            n = Y, Y.getInstance = function() {
                return q || (q = new n)
            }, i.A = Y
        },
        62536: function(t, i, e) {
            e.d(i, {
                M: function() {
                    return r
                }
            });
            e(2892);
            var n = e(31087),
                o = e(73090),
                a = e(15566),
                r = function(t) {
                    var i = (new a.KJW).setUserId(o.A.getUserId()).setTiwIdea((new a._oR).setTiwPhraseId(Number(t)));
                    return n.A.getInstance().set(i, [494])
                }
        }
    }
]);
//# sourceMappingURL=1588.8fac56b03bcdb5292522.js.map
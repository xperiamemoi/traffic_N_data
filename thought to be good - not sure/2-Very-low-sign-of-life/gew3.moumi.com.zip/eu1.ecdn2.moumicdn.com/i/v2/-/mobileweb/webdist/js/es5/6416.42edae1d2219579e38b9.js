/*! For license information please see 6416.42edae1d2219579e38b9.js.LICENSE.txt */
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [6416], {
        4571: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(96540),
                s = n(46942),
                i = n.n(s);
            t.A = ({
                children: e,
                isCompact: t,
                tag: n = "div",
                align: s = "center",
                color: o = "default",
                dataQA: c
            }) => {
                const l = i()({
                        "csms-cta-box": !0,
                        "csms-cta-box--is-compact": t,
                        [`csms-cta-box--align-${s}`]: s,
                        [`csms-cta-box--${o}`]: o
                    }),
                    d = r.Children.toArray(e).filter(Boolean).map((e => (0, r.cloneElement)(e, {
                        isCompact: t
                    }))),
                    u = n,
                    f = {
                        "data-qa": "cta-box",
                        ...c
                    };
                return (0, a.jsx)(u, {
                    className: l,
                    ...f,
                    children: d
                })
            }
        },
        8323: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(78979);
            t.A = ({
                children: e,
                spacing: t = "loose"
            }) => (0, a.jsx)(r.A, {
                spacing: t,
                children: e
            })
        },
        8483: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(46942),
                s = n.n(r),
                i = n(84362),
                o = n(62721);
            t.A = ({
                name: e,
                size: t = "stretch",
                preserveAspectRatio: n,
                color: r,
                background: c,
                shadow: l,
                a11y: d,
                supportsRtl: u,
                customAsset: f
            }) => {
                const p = s()({
                        "csms-icon": !0,
                        [`csms-icon--size-${t}`]: !0,
                        [`csms-icon--color-${r}`]: r,
                        [`csms-icon--background-${c}`]: c,
                        "csms-icon--shadow": l,
                        "csms-icon--is-flipped": u
                    }),
                    h = d ? .label && d.label.toUpperCase().indexOf("FIXME_") < 0 ? d.label : void 0,
                    m = Boolean(h);
                let b = "image" === d ? .role ? "img" : void 0;
                m || (b = void 0);
                const v = r ? {
                    "--csms-icon-color": `var(--token-cosmos-semantic-color-icon-${r})`
                } : void 0;
                return (0, a.jsxs)("span", {
                    className: p,
                    "data-qa": "icon",
                    "data-qa-icon-name": e,
                    role: b,
                    "aria-label": b ? h : void 0,
                    "aria-hidden": !m || void 0,
                    style: v,
                    children: [!b && h ? (0, a.jsx)(i.A, {
                        children: h
                    }) : void 0, c ? (0, a.jsx)("span", {
                        className: "csms-icon__background"
                    }) : null, f || (0, a.jsx)(o.A, {
                        name: e,
                        preserveAspectRatio: n
                    })]
                })
            }
        },
        12501: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(96540),
                s = n(46942),
                i = n.n(s),
                o = n(84362),
                c = n(40223);
            t.A = ({
                text: e,
                tag: t = "h1",
                variant: n = "secondary",
                fontSize: s,
                a11y: l
            }) => {
                const {
                    tokens: d
                } = (0, r.useContext)(c.Ay), u = (0, r.useMemo)((() => function(e, t, n) {
                    if (t && "primary" === n) {
                        const n = parseInt(e.TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_FONT_SIZE.replace(/px$/, ""), 10),
                            a = parseInt(e.TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_FONT_SIZE.replace(/px$/, ""), 10),
                            r = parseInt(e.TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_FONT_SIZE.replace(/px$/, ""), 10),
                            s = parseInt(e.TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_LINE_HEIGHT.replace(/px$/, ""), 10),
                            i = parseInt(e.TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_LINE_HEIGHT.replace(/px$/, ""), 10),
                            o = parseInt(e.TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_LINE_HEIGHT.replace(/px$/, ""), 10),
                            c = Math.round(s / n * 100) / 100,
                            l = Math.round(i / a * 100) / 100,
                            d = Math.round(o / r * 100) / 100;
                        let u = t || n;
                        u >= n ? u = n : u <= r && (u = r);
                        let f = c;
                        return u <= a && (f = l), u <= r && (f = d), {
                            "--csms-navigation-bar-title-font-size": `${u}px`,
                            "--csms-navigation-bar-title-line-height": f
                        }
                    }
                }(d, s, n)), [d, s, n]), f = i()({
                    "csms-navigation-bar__title": !0,
                    [`csms-navigation-bar__title--${n}`]: n
                }), p = t, h = Boolean(l ? .label) || void 0;
                return (0, a.jsxs)(p, {
                    className: f,
                    "data-qa": "navbar-title",
                    "aria-hidden": Boolean(l ? .ariaHidden) || void 0,
                    children: [(0, a.jsx)(o.A, {
                        children: l ? .label
                    }), (0, a.jsx)("span", {
                        className: "csms-navigation-bar__title-text",
                        "aria-hidden": h,
                        style: u,
                        "data-qa": "csms-navbar-title-text",
                        children: e
                    })]
                })
            }
        },
        15287: function(e, t, n) {
            "use strict";
            var a = n(45228),
                r = 60103,
                s = 60106;
            t.Fragment = 60107, t.StrictMode = 60108, t.Profiler = 60114;
            var i = 60109,
                o = 60110,
                c = 60112;
            t.Suspense = 60113;
            var l = 60115,
                d = 60116;
            if ("function" == typeof Symbol && Symbol.for) {
                var u = Symbol.for;
                r = u("react.element"), s = u("react.portal"), t.Fragment = u("react.fragment"), t.StrictMode = u("react.strict_mode"), t.Profiler = u("react.profiler"), i = u("react.provider"), o = u("react.context"), c = u("react.forward_ref"), t.Suspense = u("react.suspense"), l = u("react.memo"), d = u("react.lazy")
            }
            var f = "function" == typeof Symbol && Symbol.iterator;

            function p(e) {
                for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
                return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
            }
            var h = {
                    isMounted: function() {
                        return !1
                    },
                    enqueueForceUpdate: function() {},
                    enqueueReplaceState: function() {},
                    enqueueSetState: function() {}
                },
                m = {};

            function b(e, t, n) {
                this.props = e, this.context = t, this.refs = m, this.updater = n || h
            }

            function v() {}

            function g(e, t, n) {
                this.props = e, this.context = t, this.refs = m, this.updater = n || h
            }
            b.prototype.isReactComponent = {}, b.prototype.setState = function(e, t) {
                if ("object" != typeof e && "function" != typeof e && null != e) throw Error(p(85));
                this.updater.enqueueSetState(this, e, t, "setState")
            }, b.prototype.forceUpdate = function(e) {
                this.updater.enqueueForceUpdate(this, e, "forceUpdate")
            }, v.prototype = b.prototype;
            var x = g.prototype = new v;
            x.constructor = g, a(x, b.prototype), x.isPureReactComponent = !0;
            var y = {
                    current: null
                },
                j = Object.prototype.hasOwnProperty,
                _ = {
                    key: !0,
                    ref: !0,
                    __self: !0,
                    __source: !0
                };

            function A(e, t, n) {
                var a, s = {},
                    i = null,
                    o = null;
                if (null != t)
                    for (a in void 0 !== t.ref && (o = t.ref), void 0 !== t.key && (i = "" + t.key), t) j.call(t, a) && !_.hasOwnProperty(a) && (s[a] = t[a]);
                var c = arguments.length - 2;
                if (1 === c) s.children = n;
                else if (1 < c) {
                    for (var l = Array(c), d = 0; d < c; d++) l[d] = arguments[d + 2];
                    s.children = l
                }
                if (e && e.defaultProps)
                    for (a in c = e.defaultProps) void 0 === s[a] && (s[a] = c[a]);
                return {
                    $$typeof: r,
                    type: e,
                    key: i,
                    ref: o,
                    props: s,
                    _owner: y.current
                }
            }

            function k(e) {
                return "object" == typeof e && null !== e && e.$$typeof === r
            }
            var F = /\/+/g;

            function C(e, t) {
                return "object" == typeof e && null !== e && null != e.key ? function(e) {
                    var t = {
                        "=": "=0",
                        ":": "=2"
                    };
                    return "$" + e.replace(/[=:]/g, (function(e) {
                        return t[e]
                    }))
                }("" + e.key) : t.toString(36)
            }

            function M(e, t, n, a, i) {
                var o = typeof e;
                "undefined" !== o && "boolean" !== o || (e = null);
                var c = !1;
                if (null === e) c = !0;
                else switch (o) {
                    case "string":
                    case "number":
                        c = !0;
                        break;
                    case "object":
                        switch (e.$$typeof) {
                            case r:
                            case s:
                                c = !0
                        }
                }
                if (c) return i = i(c = e), e = "" === a ? "." + C(c, 0) : a, Array.isArray(i) ? (n = "", null != e && (n = e.replace(F, "$&/") + "/"), M(i, t, n, "", (function(e) {
                    return e
                }))) : null != i && (k(i) && (i = function(e, t) {
                    return {
                        $$typeof: r,
                        type: e.type,
                        key: t,
                        ref: e.ref,
                        props: e.props,
                        _owner: e._owner
                    }
                }(i, n + (!i.key || c && c.key === i.key ? "" : ("" + i.key).replace(F, "$&/") + "/") + e)), t.push(i)), 1;
                if (c = 0, a = "" === a ? "." : a + ":", Array.isArray(e))
                    for (var l = 0; l < e.length; l++) {
                        var d = a + C(o = e[l], l);
                        c += M(o, t, n, d, i)
                    } else if (d = function(e) {
                            return null === e || "object" != typeof e ? null : "function" == typeof(e = f && e[f] || e["@@iterator"]) ? e : null
                        }(e), "function" == typeof d)
                        for (e = d.call(e), l = 0; !(o = e.next()).done;) c += M(o = o.value, t, n, d = a + C(o, l++), i);
                    else if ("object" === o) throw t = "" + e, Error(p(31, "[object Object]" === t ? "object with keys {" + Object.keys(e).join(", ") + "}" : t));
                return c
            }

            function $(e, t, n) {
                if (null == e) return e;
                var a = [],
                    r = 0;
                return M(e, a, "", "", (function(e) {
                    return t.call(n, e, r++)
                })), a
            }

            function z(e) {
                if (-1 === e._status) {
                    var t = e._result;
                    t = t(), e._status = 0, e._result = t, t.then((function(t) {
                        0 === e._status && (t = t.default, e._status = 1, e._result = t)
                    }), (function(t) {
                        0 === e._status && (e._status = 2, e._result = t)
                    }))
                }
                if (1 === e._status) return e._result;
                throw e._result
            }
            var E = {
                current: null
            };

            function S() {
                var e = E.current;
                if (null === e) throw Error(p(321));
                return e
            }
            var w = {
                ReactCurrentDispatcher: E,
                ReactCurrentBatchConfig: {
                    transition: 0
                },
                ReactCurrentOwner: y,
                IsSomeRendererActing: {
                    current: !1
                },
                assign: a
            };
            t.Children = {
                map: $,
                forEach: function(e, t, n) {
                    $(e, (function() {
                        t.apply(this, arguments)
                    }), n)
                },
                count: function(e) {
                    var t = 0;
                    return $(e, (function() {
                        t++
                    })), t
                },
                toArray: function(e) {
                    return $(e, (function(e) {
                        return e
                    })) || []
                },
                only: function(e) {
                    if (!k(e)) throw Error(p(143));
                    return e
                }
            }, t.Component = b, t.PureComponent = g, t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = w, t.cloneElement = function(e, t, n) {
                if (null == e) throw Error(p(267, e));
                var s = a({}, e.props),
                    i = e.key,
                    o = e.ref,
                    c = e._owner;
                if (null != t) {
                    if (void 0 !== t.ref && (o = t.ref, c = y.current), void 0 !== t.key && (i = "" + t.key), e.type && e.type.defaultProps) var l = e.type.defaultProps;
                    for (d in t) j.call(t, d) && !_.hasOwnProperty(d) && (s[d] = void 0 === t[d] && void 0 !== l ? l[d] : t[d])
                }
                var d = arguments.length - 2;
                if (1 === d) s.children = n;
                else if (1 < d) {
                    l = Array(d);
                    for (var u = 0; u < d; u++) l[u] = arguments[u + 2];
                    s.children = l
                }
                return {
                    $$typeof: r,
                    type: e.type,
                    key: i,
                    ref: o,
                    props: s,
                    _owner: c
                }
            }, t.createContext = function(e, t) {
                return void 0 === t && (t = null), (e = {
                    $$typeof: o,
                    _calculateChangedBits: t,
                    _currentValue: e,
                    _currentValue2: e,
                    _threadCount: 0,
                    Provider: null,
                    Consumer: null
                }).Provider = {
                    $$typeof: i,
                    _context: e
                }, e.Consumer = e
            }, t.createElement = A, t.createFactory = function(e) {
                var t = A.bind(null, e);
                return t.type = e, t
            }, t.createRef = function() {
                return {
                    current: null
                }
            }, t.forwardRef = function(e) {
                return {
                    $$typeof: c,
                    render: e
                }
            }, t.isValidElement = k, t.lazy = function(e) {
                return {
                    $$typeof: d,
                    _payload: {
                        _status: -1,
                        _result: e
                    },
                    _init: z
                }
            }, t.memo = function(e, t) {
                return {
                    $$typeof: l,
                    type: e,
                    compare: void 0 === t ? null : t
                }
            }, t.useCallback = function(e, t) {
                return S().useCallback(e, t)
            }, t.useContext = function(e, t) {
                return S().useContext(e, t)
            }, t.useDebugValue = function() {}, t.useEffect = function(e, t) {
                return S().useEffect(e, t)
            }, t.useImperativeHandle = function(e, t, n) {
                return S().useImperativeHandle(e, t, n)
            }, t.useLayoutEffect = function(e, t) {
                return S().useLayoutEffect(e, t)
            }, t.useMemo = function(e, t) {
                return S().useMemo(e, t)
            }, t.useReducer = function(e, t, n) {
                return S().useReducer(e, t, n)
            }, t.useRef = function(e) {
                return S().useRef(e)
            }, t.useState = function(e) {
                return S().useState(e)
            }, t.version = "17.0.2"
        },
        15376: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(87908);
            t.A = ({
                children: e,
                hpadded: t,
                vpadded: n,
                tag: s,
                isSticky: i
            }) => (0, a.jsx)(r.A, {
                align: "top",
                hpadded: t,
                vpadded: n,
                tag: s,
                isSticky: i,
                dataQA: {
                    "data-qa": "screen-header"
                },
                children: e
            })
        },
        20017: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(96540),
                s = n(46942),
                i = n.n(s),
                o = n(84362),
                c = n(8483),
                l = n(33815),
                d = n(93827);
            const u = ["facebook", "google", "apple"];
            t.A = ({
                semantic: e = "primary",
                styling: t = "default",
                size: n = "medium",
                narrow: s,
                icon: f,
                iconPosition: p = "start",
                text: h,
                tag: m = "button",
                isDisabled: b,
                isPressed: v,
                isLoading: g,
                onClick: x,
                linkAttrs: y,
                buttonAttrs: j,
                innerRef: _,
                dataQA: A,
                a11y: k,
                extraClass: F,
                extraAttrs: C
            }) => {
                const M = m,
                    $ = i()({
                        "csms-button": !0,
                        [`csms-button--semantic-${e}`]: e,
                        [`csms-button--styling-${t}`]: t,
                        [`csms-button--${n}`]: !0,
                        "csms-button--narrow": s,
                        "is-pressed": (v || g) && !b,
                        "is-loading": g,
                        "js-touchable": !0,
                        "qa-button": !0,
                        [F]: F
                    });
                let z = u.indexOf(t) >= 0;
                const E = ["brand", "vkontakte", "odnoklassniki"].indexOf(t) >= 0 ? "default" : t;
                "default" === E && (z = !1);
                const S = {
                        className: $,
                        style: z ? {
                            "--csms-button-background-color": `var(--token-cosmos-socialmediabutton-color-background-${E}, var(--token-cosmos-button-color-background-primary-${E}))`,
                            "--csms-button-content-color": `var(--${"google"===E?"token-cosmos-socialmediabutton-color-content-inverse":"token-cosmos-socialmediabutton-color-content-default"}, var(--token-cosmos-button-color-content-primary-${E}))`,
                            "--csms-button-icon-color": `var(--token-cosmos-socialmediabutton-color-icon, var(--token-cosmos-button-color-icon-primary-${E}))`,
                            "--csms-button-border-color": `var(--${"google"===E?"token-cosmos-socialmediabutton-color-border-google":"token-cosmos-socialmediabutton-color-background"}, var(--token-cosmos-button-color-border-primary-${E}))`,
                            "--csms-button-border-width": `var(--${"google"===E?"token-cosmos-socialmediabutton-border-width-google":"token-cosmos-button-border-width-primary-default"}, var(--token-cosmos-button-border-width-primary-${E}))`
                        } : {
                            "--csms-button-background-color": `var(--token-cosmos-button-color-background-${e}-${E})`,
                            "--csms-button-content-color": `var(--token-cosmos-button-color-content-${e}-${E})`,
                            "--csms-button-icon-color": `var(--token-cosmos-button-color-icon-${e}-${E})`,
                            "--csms-button-border-color": `var(--token-cosmos-button-color-border-${e}-${E})`,
                            "--csms-button-border-width": `var(--token-cosmos-button-border-width-${e}-${E})`,
                            "--csms-button-border-style": `var(--token-cosmos-button-border-style-${e}-${E})`
                        },
                        onClick: b ? void 0 : x,
                        disabled: b,
                        "aria-live": "polite",
                        "aria-busy": g,
                        ref: _,
                        "data-qa": "button",
                        ...A,
                        ...C
                    },
                    w = Boolean(k ? .label),
                    N = e => (0, a.jsx)("span", {
                        className: `csms-button__icon csms-button__icon--${e}`,
                        "aria-hidden": !0,
                        children: f && (0, a.jsx)(c.A, {
                            name: f
                        })
                    }),
                    O = (0, a.jsxs)(r.Fragment, {
                        children: [(0, a.jsxs)("span", {
                            className: "csms-button__content",
                            children: [f && "start" === p && N("start"), h ? (0, a.jsx)(d.Qi, {
                                breakWords: !0,
                                className: "csms-button__text",
                                a11y: {
                                    ariaHidden: g || w
                                },
                                children: h
                            }) : null, (0, a.jsx)(o.A, {
                                children: k ? .label
                            }), f && "end" === p && N("end")]
                        }), g ? (0, a.jsx)("span", {
                            className: "csms-button__loader",
                            children: (0, a.jsx)(l.A, {
                                a11y: {
                                    label: k ? .loaderLabel
                                }
                            })
                        }) : null]
                    });
                if ("a" === m) return (0, a.jsx)(M, { ...S,
                    "aria-disabled": b || !y ? .href && !x || void 0,
                    role: b || !y ? .href ? "link" : void 0,
                    tabIndex: y ? .href || !x || b ? void 0 : 0,
                    ...y,
                    href: b ? void 0 : y ? .href,
                    children: O
                }); {
                    const e = {
                        type: "button",
                        ...j
                    };
                    return (0, a.jsx)(M, { ...S,
                        ...e,
                        children: O
                    })
                }
            }
        },
        27895: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(46942),
                s = n.n(r);
            t.A = ({
                children: e,
                size: t,
                align: n = "start",
                isCompact: r
            }) => {
                const i = s()({
                        "csms-cta-box__media": !0,
                        "csms-cta-box__media--is-compact": r
                    }),
                    o = s()({
                        "csms-cta-box__media-content": !0,
                        [`csms-cta-box__media-content--align-${n}`]: n,
                        [`csms-cta-box__media-content--size-${t}`]: t
                    });
                return (0, a.jsx)("div", {
                    className: i,
                    "data-qa": "cta-box-media",
                    children: (0, a.jsx)("div", {
                        className: o,
                        children: e
                    })
                })
            }
        },
        28733: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(33943);
            t.A = ({
                children: e,
                isWide: t
            }) => (0, a.jsx)(r.A, {
                slot: "primary",
                isWide: t,
                children: e
            })
        },
        33815: function(e, t, n) {
            "use strict";
            var a = n(74848);
            t.A = ({
                a11y: e
            }) => (0, a.jsx)("span", {
                className: "csms-loader",
                "data-qa": "loader",
                role: e ? .label ? "status" : void 0,
                "aria-label": e ? .label,
                children: (0, a.jsxs)("svg", {
                    viewBox: "0 0 64 64",
                    width: "0",
                    height: "0",
                    "aria-hidden": !0,
                    children: [(0, a.jsx)("circle", {
                        cx: "12",
                        cy: "32",
                        r: "8",
                        className: "csms-loader__dot"
                    }), (0, a.jsx)("circle", {
                        cx: "32",
                        cy: "32",
                        r: "8",
                        className: "csms-loader__dot"
                    }), (0, a.jsx)("circle", {
                        cx: "52",
                        cy: "32",
                        r: "8",
                        className: "csms-loader__dot"
                    })]
                })
            })
        },
        33943: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(46942),
                s = n.n(r);
            t.A = ({
                children: e,
                slot: t,
                isWide: n
            }) => {
                const r = s()({
                    "csms-navigation-bar__slot": !0,
                    [`csms-navigation-bar__slot--${t}`]: t,
                    "csms-navigation-bar__slot--is-wide": n
                });
                return (0, a.jsx)("div", {
                    className: r,
                    "data-qa": `navbar-slot-${t}`,
                    children: e
                })
            }
        },
        40223: function(e, t, n) {
            "use strict";
            n.d(t, {
                Kq: function() {
                    return i
                },
                ZC: function() {
                    return s
                },
                dw: function() {
                    return o
                }
            });
            var a = n(96540);
            const r = (0, a.createContext)({
                brand: "badoo",
                assetStore: {},
                tokens: {}
            });
            t.Ay = r;
            const s = r.Consumer,
                i = r.Provider,
                o = () => {
                    const {
                        tokens: e
                    } = (0, a.useContext)(r);
                    return e
                }
        },
        40578: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(46942),
                s = n.n(r),
                i = n(93827);
            t.A = ({
                text: e,
                color: t = "default",
                tag: n = "div",
                dangerous: r,
                isCompact: o
            }) => {
                const c = s()({
                    "csms-cta-box__header": !0,
                    [`csms-cta-box__header--${t}`]: t,
                    "csms-cta-box__header--is-compact": o
                });
                return (0, a.jsx)(i.Qi, {
                    className: c,
                    breakWords: !0,
                    tag: n,
                    dangerous: r,
                    dataQA: {
                        "data-qa": "cta-box-header"
                    },
                    children: e
                })
            }
        },
        45228: function(e) {
            "use strict";
            var t = Object.getOwnPropertySymbols,
                n = Object.prototype.hasOwnProperty,
                a = Object.prototype.propertyIsEnumerable;
            e.exports = function() {
                try {
                    if (!Object.assign) return !1;
                    var e = new String("abc");
                    if (e[5] = "de", "5" === Object.getOwnPropertyNames(e)[0]) return !1;
                    for (var t = {}, n = 0; n < 10; n++) t["_" + String.fromCharCode(n)] = n;
                    if ("0123456789" !== Object.getOwnPropertyNames(t).map((function(e) {
                            return t[e]
                        })).join("")) return !1;
                    var a = {};
                    return "abcdefghijklmnopqrst".split("").forEach((function(e) {
                        a[e] = e
                    })), "abcdefghijklmnopqrst" === Object.keys(Object.assign({}, a)).join("")
                } catch (e) {
                    return !1
                }
            }() ? Object.assign : function(e, r) {
                for (var s, i, o = function(e) {
                        if (null == e) throw new TypeError("Object.assign cannot be called with null or undefined");
                        return Object(e)
                    }(e), c = 1; c < arguments.length; c++) {
                    for (var l in s = Object(arguments[c])) n.call(s, l) && (o[l] = s[l]);
                    if (t) {
                        i = t(s);
                        for (var d = 0; d < i.length; d++) a.call(s, i[d]) && (o[i[d]] = s[i[d]])
                    }
                }
                return o
            }
        },
        45869: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(46942),
                s = n.n(r),
                i = n(84362);
            t.A = ({
                status: e,
                borderColor: t = "white",
                counterText: n,
                counterStatus: r,
                a11y: o
            }) => {
                const c = s()({
                        "csms-dot-counter-notification": !0,
                        [`csms-dot-counter-notification--is-${e}`]: e
                    }),
                    l = s()({
                        "csms-dot-counter-notification__dot": !0,
                        [`csms-dot-counter-notification__dot--border-color-${t}`]: t
                    }),
                    d = s()({
                        "csms-dot-counter-notification__counter": !0,
                        [`csms-dot-counter-notification__counter--is-${r}`]: r,
                        [`csms-dot-counter-notification__counter--border-color-${t}`]: t
                    }),
                    u = Boolean(o ? .label);
                return (0, a.jsxs)("div", {
                    className: c,
                    "aria-live": "polite",
                    "aria-hidden": "hidden" === e,
                    "data-qa": "dot-counter-notification",
                    children: [(0, a.jsx)("div", {
                        className: l
                    }), n ? (0, a.jsx)("div", {
                        className: d,
                        "aria-hidden": u,
                        "data-qa": "dot-counter-notification-text",
                        children: n
                    }) : null, (0, a.jsx)(i.A, {
                        children: o ? .label
                    })]
                })
            }
        },
        46770: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(46942),
                s = n.n(r),
                i = n(8323);
            t.A = ({
                children: e,
                isCompact: t
            }) => {
                const n = s()({
                    "csms-cta-box__buttons": !0,
                    "csms-cta-box__buttons--is-compact": t
                });
                return (0, a.jsx)("div", {
                    className: n,
                    "data-qa": "cta-box-buttons",
                    children: (0, a.jsx)(i.A, {
                        children: e
                    })
                })
            }
        },
        46942: function(e, t) {
            var n;
            ! function() {
                "use strict";
                var a = {}.hasOwnProperty;

                function r() {
                    for (var e = "", t = 0; t < arguments.length; t++) {
                        var n = arguments[t];
                        n && (e = i(e, s(n)))
                    }
                    return e
                }

                function s(e) {
                    if ("string" == typeof e || "number" == typeof e) return e;
                    if ("object" != typeof e) return "";
                    if (Array.isArray(e)) return r.apply(null, e);
                    if (e.toString !== Object.prototype.toString && !e.toString.toString().includes("[native code]")) return e.toString();
                    var t = "";
                    for (var n in e) a.call(e, n) && e[n] && (t = i(t, n));
                    return t
                }

                function i(e, t) {
                    return t ? e ? e + " " + t : e + t : e
                }
                e.exports ? (r.default = r, e.exports = r) : void 0 === (n = function() {
                    return r
                }.apply(t, [])) || (e.exports = n)
            }()
        },
        47901: function(e, t, n) {
            "use strict";
            var a = n(74848);
            t.A = ({
                children: e,
                dataQA: t,
                innerRef: n
            }) => {
                const r = {
                    "data-qa": "screen",
                    ...t
                };
                return (0, a.jsx)("div", {
                    className: "csms-screen",
                    ref: n,
                    ...r,
                    children: e
                })
            }
        },
        62721: function(e, t, n) {
            "use strict";
            n.d(t, {
                A: function() {
                    return c
                }
            });
            var a = n(74848),
                r = n(40223);
            var s = {
                "badge-counter-1": function({
                    preserveAspectRatio: e
                }) {
                    return (0, a.jsx)("svg", {
                        "aria-hidden": !0,
                        "data-origin": "pipeline",
                        preserveAspectRatio: e,
                        viewBox: "0 0 44 44",
                        children: (0, a.jsxs)("g", {
                            fill: "none",
                            fillRule: "evenodd",
                            children: [(0, a.jsx)("rect", {
                                fill: "var(--token-cosmos-semantic-color-supportive-feedback-notification)",
                                width: 44,
                                height: 44,
                                rx: 22
                            }), (0, a.jsx)("path", {
                                fill: "#FFF",
                                d: "M22 31V15.45l-5 4.073V17l4.9-4H24l-.006 18.058z"
                            })]
                        })
                    })
                },
                "loading-dots": function({
                    preserveAspectRatio: e
                }) {
                    return (0, a.jsxs)("svg", {
                        "aria-hidden": !0,
                        viewBox: "0 0 64 64",
                        "data-origin": "cosmos-local",
                        preserveAspectRatio: e,
                        children: [(0, a.jsx)("circle", {
                            cx: "12",
                            cy: "32",
                            r: "8",
                            children: (0, a.jsx)("animate", {
                                attributeName: "r",
                                from: "8",
                                to: "8",
                                dur: "1.3s",
                                values: "8; 4; 4; 8",
                                keyTimes: "0; 0.25; 0.75; 1",
                                begin: "0s",
                                repeatCount: "indefinite"
                            })
                        }), (0, a.jsx)("circle", {
                            cx: "32",
                            cy: "32",
                            r: "8",
                            children: (0, a.jsx)("animate", {
                                attributeName: "r",
                                from: "8",
                                to: "8",
                                dur: "1.3s",
                                values: "8; 4; 4; 8",
                                keyTimes: "0; 0.25; 0.75; 1",
                                begin: "0.26s",
                                repeatCount: "indefinite"
                            })
                        }), (0, a.jsx)("circle", {
                            cx: "52",
                            cy: "32",
                            r: "8",
                            children: (0, a.jsx)("animate", {
                                attributeName: "r",
                                from: "8",
                                to: "8",
                                dur: "1.3s",
                                values: "8; 4; 4; 8",
                                keyTimes: "0; 0.25; 0.75; 1",
                                begin: "0.53s",
                                repeatCount: "indefinite"
                            })
                        })]
                    })
                },
                "premium-potion": function({
                    preserveAspectRatio: e
                }) {
                    return (0, a.jsxs)("svg", {
                        "aria-hidden": !0,
                        viewBox: "0 0 64 64",
                        "data-origin": "cosmos-local",
                        preserveAspectRatio: e,
                        children: [(0, a.jsx)("path", {
                            d: "M13.93 54.74a22.99 22.99 0 0013.85 6.57 23.02 23.02 0 0024.1-15.1 22.7 22.7 0 00-5.42-23.8 23.1 23.1 0 00-32.53.01 22.75 22.75 0 000 32.32",
                            fill: "#00A2DB"
                        }), (0, a.jsx)("path", {
                            d: "M27.78 61.3c6.66.7 13.47-1.58 18.68-6.56a21.57 21.57 0 006.6-18.56 23.02 23.02 0 00-24.1 15.1 22.7 22.7 0 00-1.18 10.03",
                            fill: "#27D3FC"
                        }), (0, a.jsx)("path", {
                            d: "M17.43 51.26A18.04 18.04 0 0028.3 56.4a18.07 18.07 0 0018.9-11.84 17.82 17.82 0 00-4.25-18.67c-7.04-7-18.47-7-25.52 0a17.85 17.85 0 000 25.36",
                            fill: "#007EC2"
                        }), (0, a.jsx)("path", {
                            d: "M13.36 38.4c1.1 2.32 3.9 3.43 6.53 3.4 3.34-.03 7.05-.76 10.25-1.68a3.13 3.13 0 002.38-3.03h15.72a18 18 0 01-5.29 14.17c-4 3.98-9.42 5.7-14.65 5.15a18.03 18.03 0 01-14.77-10.94 17.81 17.81 0 01-1.38-6.83v-1.55h.12c.23.52.6.98 1.09 1.32",
                            fill: "#7000E3"
                        }), (0, a.jsx)("path", {
                            d: "M12.15 37.09c.27 1.58 1.5 3.08 4.02 4.24 3.3 1.53 8.35 2.5 14.02 2.5s10.72-.97 14.03-2.5c2.51-1.16 4.02-2.64 4.02-4.24 0-3.73-7.72-6.17-24.04.87-9.13 3.95-12.25-2.1-12.05-.87",
                            fill: "#AF61FF"
                        }), (0, a.jsx)("path", {
                            d: "M21.66 55.52A3.61 3.61 0 0027.8 53a3.56 3.56 0 00-3.6-3.58A3.61 3.61 0 0020.61 53a3.56 3.56 0 001.05 2.52zM34.4 28.01A2.12 2.12 0 0038 26.52a2.1 2.1 0 00-2.11-2.1 2.12 2.12 0 00-2.12 2.1 2.1 2.1 0 00.62 1.49",
                            fill: "#fff"
                        }), (0, a.jsx)("path", {
                            d: "M1.88 28.03L21.07 8.97l6.74 6.7c2.97 2.96 1.08 9.62-4.21 14.88-5.3 5.26-12 7.14-14.97 4.19l-6.75-6.7z",
                            fill: "#27D3FC"
                        }), (0, a.jsx)("path", {
                            d: "M6.12 23.83l11.2 11.13c2.1-.95 4.3-2.44 6.28-4.41a21.5 21.5 0 004.43-6.24l-11.2-11.13-10.7 10.65z",
                            fill: "#3DDFF9"
                        }), (0, a.jsx)("path", {
                            d: "M12.37 17.61l12.1 12.02a19.07 19.07 0 004.28-7.33c.07-.26.13-.5.18-.76l-10.26-10.2-6.3 6.27z",
                            fill: "#fff"
                        }), (0, a.jsx)("path", {
                            d: "M1.88 28.03c2.97 2.95 9.68 1.08 14.97-4.18 5.3-5.27 7.19-11.93 4.21-14.88C18.1 6.02 11.4 7.9 6.1 13.16.8 18.42-1.1 25.08 1.88 28.03z",
                            fill: "#D2FFFF"
                        }), (0, a.jsx)("path", {
                            d: "M5.46 23.74c.8.78 2.04.98 3.46.67a11.26 11.26 0 005.24-3.1 11.2 11.2 0 003.11-5.2c.32-1.41.12-2.65-.67-3.44-1.73-1.71-5.61-.62-8.69 2.43-3.08 3.06-4.17 6.92-2.45 8.64",
                            fill: "#3DDFF9"
                        }), (0, a.jsx)("path", {
                            d: "M8.92 24.4a11.28 11.28 0 005.24-3.1 11.2 11.2 0 003.11-5.2 11.27 11.27 0 00-5.23 3.1 11.17 11.17 0 00-3.12 5.2",
                            fill: "#00A2DB"
                        }), (0, a.jsx)("path", {
                            d: "M5.4 18.13a1.87 1.87 0 003.2 1.32 1.87 1.87 0 10-3.05-2.03c-.1.22-.15.46-.15.7",
                            fill: "#7000E3"
                        }), (0, a.jsx)("path", {
                            d: "M11.06 13.9a1.87 1.87 0 003.2 1.32 1.87 1.87 0 00.54-1.32 1.87 1.87 0 00-3.2-1.32c-.34.35-.54.82-.54 1.32",
                            fill: "#AF61FF"
                        }), (0, a.jsx)("path", {
                            d: "M6.22 9.91a1.87 1.87 0 003.2 1.32 1.87 1.87 0 00.55-1.32 1.87 1.87 0 00-3.2-1.32c-.35.35-.55.82-.55 1.32zm7.76 11.52a9.7 9.7 0 01-4.08 2.51 4.28 4.28 0 015.97-5.02c-.5.93-1.14 1.77-1.9 2.5zm-2.8-18.66c0 .44.36.8.81.8a.8.8 0 00.57-1.37.8.8 0 00-.57-.24.8.8 0 00-.8.8zM20.11 41c.2 1.17 5.8 1.23 12.53.13 6.73-1.1 12.02-2.94 11.83-4.1-.2-1.17-5.8-1.23-12.53-.13C25.2 38 19.9 39.84 20.1 41z",
                            fill: "#7000E3"
                        }), (0, a.jsx)("path", {
                            d: "M25.31 40.05c.08.5 3.11.42 6.76-.18s6.54-1.48 6.46-1.98c-.08-.5-3.1-.42-6.76.17-3.65.6-6.54 1.49-6.46 1.99z",
                            fill: "#AF61FF"
                        })]
                    })
                },
                "credits-handful": function({
                    preserveAspectRatio: e
                }) {
                    return (0, a.jsxs)("svg", {
                        "aria-hidden": !0,
                        viewBox: "0 0 64 64",
                        "data-origin": "cosmos-local",
                        preserveAspectRatio: e,
                        fill: "none",
                        children: [(0, a.jsx)("path", {
                            opacity: ".05",
                            d: "M32 51.09c17.1 0 30.98-1.03 30.98-2.3 0-1.28-13.87-2.32-30.98-2.32-17.1 0-30.98 1.04-30.98 2.31 0 1.28 13.87 2.31 30.98 2.31z",
                            fill: "#000"
                        }), (0, a.jsx)("path", {
                            d: "M17.01 51.09c7.54 0 13.66-1.83 13.66-4.09 0-2.25-6.12-4.08-13.66-4.08S3.36 44.75 3.36 47.01c0 2.25 6.11 4.08 13.65 4.08z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M3.36 42.92h27.3v3.9H3.37v-3.9z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M17.01 47.18c7.54 0 13.66-1.83 13.66-4.08C30.67 40.84 24.55 39 17 39S3.36 40.84 3.36 43.1c0 2.25 6.11 4.08 13.65 4.08z",
                            fill: "#FFCE00"
                        }), (0, a.jsx)("path", {
                            d: "M17.34 45.05c4.05 0 7.33-.95 7.33-2.13s-3.28-2.13-7.33-2.13c-4.04 0-7.32.95-7.32 2.13s3.28 2.13 7.32 2.13zM45.99 50.38c7.54 0 13.66-1.83 13.66-4.09 0-2.25-6.12-4.08-13.66-4.08s-13.66 1.83-13.66 4.09c0 2.25 6.12 4.08 13.66 4.08z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M32.33 42.21h27.32v3.9H32.33v-3.9z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M45.99 46.83c7.54 0 13.66-1.83 13.66-4.09 0-2.25-6.12-4.08-13.66-4.08s-13.66 1.83-13.66 4.08c0 2.26 6.12 4.09 13.66 4.09z",
                            fill: "#FFCE00"
                        }), (0, a.jsx)("path", {
                            d: "M45.66 44.34c4.04 0 7.32-.95 7.32-2.13s-3.28-2.13-7.32-2.13c-4.05 0-7.33.95-7.33 2.13s3.28 2.13 7.33 2.13z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M44.99 45.05c7.54 0 13.66-1.83 13.66-4.08 0-2.26-6.12-4.09-13.66-4.09s-13.66 1.83-13.66 4.09c0 2.25 6.12 4.08 13.66 4.08z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M31.33 37.6h27.32v3.9H31.33v-3.9z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M44.99 41.5c7.54 0 13.66-1.83 13.66-4.09 0-2.25-6.12-4.08-13.66-4.08s-13.66 1.83-13.66 4.08c0 2.26 6.12 4.09 13.66 4.09z",
                            fill: "#FFCE00"
                        }), (0, a.jsx)("path", {
                            d: "M45.32 39.01c4.05 0 7.33-.95 7.33-2.13s-3.28-2.13-7.33-2.13c-4.04 0-7.33.95-7.33 2.13s3.29 2.13 7.33 2.13z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M47.66 40.79c7.54 0 13.65-1.83 13.65-4.09 0-2.25-6.11-4.08-13.66-4.08-7.54 0-13.65 1.83-13.65 4.08 0 2.26 6.11 4.09 13.66 4.09z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M34 32.62H61.3v3.9H34v-3.9z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M47.66 37.24c7.54 0 13.65-1.83 13.65-4.09s-6.11-4.08-13.66-4.08c-7.54 0-13.65 1.82-13.65 4.08s6.11 4.09 13.66 4.09z",
                            fill: "#FFCE00"
                        }), (0, a.jsx)("path", {
                            d: "M18.01 46.12c7.54 0 13.66-1.83 13.66-4.09 0-2.25-6.12-4.08-13.66-4.08S4.35 39.78 4.35 42.03c0 2.26 6.12 4.09 13.66 4.09z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M4.36 38.66h27.3v3.9H4.37v-3.9z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M18.01 42.56c7.54 0 13.66-1.82 13.66-4.08S25.55 34.4 18 34.4 4.35 36.22 4.35 38.48s6.12 4.09 13.66 4.09z",
                            fill: "#FFCE00"
                        }), (0, a.jsx)("path", {
                            d: "M18.34 40.08c4.05 0 7.33-.96 7.33-2.13 0-1.18-3.28-2.13-7.33-2.13-4.04 0-7.32.95-7.32 2.13 0 1.17 3.28 2.13 7.32 2.13z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M17.01 41.5c7.54 0 13.66-1.83 13.66-4.09 0-2.25-6.12-4.08-13.66-4.08S3.36 35.16 3.36 37.4c0 2.26 6.11 4.09 13.65 4.09z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M3.36 33.33h27.3v3.9H3.37v-3.9z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M17.01 37.6c7.54 0 13.66-1.84 13.66-4.1 0-2.25-6.12-4.08-13.66-4.08S3.36 31.25 3.36 33.51c0 2.25 6.11 4.08 13.65 4.08z",
                            fill: "#FFCE00"
                        }), (0, a.jsx)("path", {
                            d: "M17.34 35.46c4.05 0 7.33-.95 7.33-2.13s-3.28-2.13-7.33-2.13c-4.04 0-7.32.95-7.32 2.13s3.28 2.13 7.32 2.13z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M17.01 35.46c7.54 0 13.66-1.83 13.66-4.09 0-2.25-6.12-4.08-13.66-4.08S3.36 29.12 3.36 31.38c0 2.25 6.11 4.08 13.65 4.08z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M3.36 28h27.3v3.9H3.37V28z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M17.01 31.9c7.54 0 13.66-1.82 13.66-4.08 0-2.25-6.12-4.08-13.66-4.08S3.36 25.57 3.36 27.82c0 2.26 6.11 4.09 13.65 4.09z",
                            fill: "#FFCE00"
                        }), (0, a.jsx)("path", {
                            d: "M17.34 29.42c4.05 0 7.33-.95 7.33-2.13s-3.28-2.13-7.33-2.13c-4.04 0-7.32.95-7.32 2.13s3.28 2.13 7.32 2.13z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M18.01 30.13c7.54 0 13.66-1.83 13.66-4.08 0-2.26-6.12-4.09-13.66-4.09S4.35 23.8 4.35 26.05c0 2.25 6.12 4.08 13.66 4.08z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M4.36 21.96h27.3v3.9H4.37v-3.9z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M18.01 26.58c7.54 0 13.66-1.83 13.66-4.08 0-2.26-6.12-4.09-13.66-4.09S4.35 20.24 4.35 22.5c0 2.25 6.12 4.08 13.66 4.08z",
                            fill: "#FFCE00"
                        }), (0, a.jsx)("path", {
                            d: "M18.34 24.1c4.05 0 7.33-.96 7.33-2.14 0-1.17-3.28-2.13-7.33-2.13-4.04 0-7.32.96-7.32 2.13 0 1.18 3.28 2.13 7.32 2.13z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M16.68 25.51c7.54 0 13.66-1.82 13.66-4.08s-6.12-4.09-13.66-4.09-13.66 1.83-13.66 4.09 6.12 4.08 13.66 4.08z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M3.02 17.7h27.32v3.9H3.02v-3.9z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M16.68 21.6c7.54 0 13.66-1.82 13.66-4.08 0-2.25-6.12-4.08-13.66-4.08S3.02 15.27 3.02 17.52c0 2.26 6.12 4.09 13.66 4.09z",
                            fill: "#FFCE00"
                        }), (0, a.jsx)("path", {
                            d: "M16.34 19.48c4.05 0 7.33-.96 7.33-2.14 0-1.17-3.28-2.13-7.33-2.13-4.04 0-7.32.96-7.32 2.13 0 1.18 3.28 2.14 7.32 2.14z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M21.68 20.54c7.54 0 13.65-1.83 13.65-4.08 0-2.26-6.11-4.09-13.65-4.09-7.55 0-13.66 1.83-13.66 4.09 0 2.25 6.11 4.08 13.66 4.08z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M8.02 12.37h27.31v3.9H8.02v-3.9z",
                            fill: "#FFBC00"
                        }), (0, a.jsx)("path", {
                            d: "M21.68 16.28c7.54 0 13.65-1.83 13.65-4.09 0-2.25-6.11-4.08-13.65-4.08-7.55 0-13.66 1.83-13.66 4.08 0 2.26 6.11 4.09 13.66 4.09z",
                            fill: "#FFCE00"
                        }), (0, a.jsx)("path", {
                            opacity: ".05",
                            d: "M29.18 57.86c5.94 0 10.76-.58 10.76-1.28 0-.71-4.82-1.28-10.76-1.28-5.93 0-10.75.57-10.75 1.28 0 .7 4.82 1.28 10.75 1.28z",
                            fill: "#000"
                        }), (0, a.jsx)("path", {
                            d: "M29.18 57.86a13.31 13.31 0 100-26.63 13.31 13.31 0 000 26.63z",
                            fill: "#FFDA00"
                        }), (0, a.jsx)("path", {
                            d: "M29.18 57.6a13.06 13.06 0 100-26.12 13.06 13.06 0 000 26.13z",
                            stroke: "#FB0"
                        }), (0, a.jsx)("path", {
                            opacity: ".9",
                            d: "M32.38 39.42c-1.26 0-2.45.58-3.2 1.57a4.05 4.05 0 00-4.43-1.35c-1.63.52-2.73 2-2.73 3.66 0 3.5 4.8 7.9 7.16 7.9 2.37 0 7.17-4.4 7.17-7.9a3.94 3.94 0 00-3.97-3.88z",
                            fill: "#FFB200"
                        }), (0, a.jsx)("path", {
                            d: "M24.88 10.24a7.86 7.86 0 00-3.04.52c-.97-.37-2-.55-3.04-.52-2.09 0-3.79.58-3.79 1.29 0 1.16 4.58 2.62 6.83 2.62s6.83-1.46 6.83-2.63c0-.71-1.7-1.28-3.79-1.28zM50.86 30.5a7.86 7.86 0 00-3.04.52c-.97-.37-2-.55-3.04-.52-2.09 0-3.79.58-3.79 1.28 0 1.17 4.58 2.63 6.83 2.63s6.83-1.46 6.83-2.63c0-.7-1.7-1.28-3.79-1.28z",
                            fill: "#FFBC00"
                        })]
                    })
                }
            };
            var i = function({
                name: e,
                onError: t
            }) {
                return t ? t() : console.log(`Missing asset ${e}`), (0, a.jsx)("svg", {
                    viewBox: "0 0 64 64",
                    "aria-hidden": !0,
                    children: (0, a.jsx)("title", {
                        children: `Warning: invalid asset name "${e}" supplied to Icon → Asset components (that asset doesn't exist!)`
                    })
                })
            };

            function o({
                name: e,
                preserveAspectRatio: t,
                assetStore: n
            }) {
                const r = s[e];
                if (r) return (0, a.jsx)(r, {
                    preserveAspectRatio: t
                });
                const o = n[e];
                return o ? (0, a.jsx)(o, {
                    preserveAspectRatio: t
                }) : (0, a.jsx)(i, {
                    name: e
                })
            }
            var c = ({
                name: e,
                preserveAspectRatio: t
            }) => (0, a.jsx)(r.ZC, {
                children: ({
                    assetStore: n
                }) => (0, a.jsx)(o, {
                    name: e,
                    preserveAspectRatio: t,
                    assetStore: n
                })
            })
        },
        74848: function(e, t, n) {
            "use strict";
            e.exports = n(21020)
        },
        77001: function(e, t, n) {
            "use strict";
            n.d(t, {
                E: function() {
                    return i
                }
            });
            var a = n(74848),
                r = n(46942),
                s = n.n(r);
            const i = ({
                children: e,
                size: t,
                tag: n = "span",
                align: r,
                color: i,
                inline: o,
                ellipsis: c,
                breakWords: l,
                dangerous: d,
                id: u,
                a11y: f,
                className: p,
                dataQA: h
            }) => {
                const m = s()(p, {
                        [`csms-${t}`]: t,
                        [`csms-text-align-${r}`]: r,
                        "csms-text-ellipsis": c,
                        "csms-text-break-words": l,
                        [`csms-text-color-${i}`]: i
                    }),
                    b = n;
                let v = {};
                return o && "span" !== n && (v = {
                    display: "inline"
                }), o || "span" !== n || (v = {
                    display: "block"
                }), d ? (0, a.jsx)(b, {
                    id: u,
                    className: m,
                    dangerouslySetInnerHTML: {
                        __html: e
                    },
                    style: v,
                    "aria-hidden": Boolean(f ? .ariaHidden) || void 0,
                    ...h
                }) : (0, a.jsx)(b, {
                    id: u,
                    className: m,
                    style: v,
                    "aria-hidden": Boolean(f ? .ariaHidden) || void 0,
                    ...h,
                    children: e
                })
            };
            t.A = 8792 == n.j ? i : null
        },
        78979: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(96540),
                s = n(46942),
                i = n.n(s);
            t.A = ({
                fullWidth: e = !0,
                direction: t = "column",
                align: n = "stretch",
                spacing: s = "loose",
                children: o,
                dataQA: c
            }) => {
                const l = i()({
                    "csms-stack": !0,
                    "csms-stack--fullwidth": e,
                    [`csms-stack--${t}`]: t,
                    [`csms-stack--align-${n}`]: n,
                    [`csms-stack--spacing-${s}`]: s
                });
                return (0, a.jsx)("div", {
                    className: l,
                    "data-qa": "csms-stack",
                    ...c,
                    children: r.Children.toArray(o).filter(Boolean).map(((e, t) => (0, a.jsx)("div", {
                        className: "csms-stack__item",
                        "data-qa": "csms-stack-item",
                        children: e
                    }, t)))
                })
            }
        },
        84362: function(e, t, n) {
            "use strict";
            var a = n(74848);
            t.A = ({
                children: e,
                id: t,
                tag: n = "span",
                dangerous: r,
                a11y: s
            }) => {
                const i = n;
                return e ? r ? (0, a.jsx)(i, {
                    className: "csms-a11y-visually-hidden",
                    id: t,
                    dangerouslySetInnerHTML: {
                        __html: e
                    },
                    "aria-hidden": Boolean(s ? .ariaHidden) || void 0,
                    "aria-live": s ? .ariaLive
                }) : (0, a.jsx)(i, {
                    className: "csms-a11y-visually-hidden",
                    id: t,
                    "aria-hidden": Boolean(s ? .ariaHidden) || void 0,
                    "aria-live": s ? .ariaLive,
                    children: e
                }) : null
            }
        },
        87184: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(87908);
            t.A = ({
                children: e,
                hpadded: t,
                vpadded: n,
                align: s,
                tag: i
            }) => (0, a.jsx)(r.A, {
                align: s,
                hpadded: t,
                vpadded: n,
                tag: i,
                children: e
            })
        },
        87908: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(46942),
                s = n.n(r);
            t.A = ({
                children: e,
                hpadded: t,
                vpadded: n,
                align: r = "top",
                tag: i = "div",
                isSticky: o,
                dataQA: c
            }) => {
                const l = i,
                    d = s()({
                        "csms-screen__block": !0,
                        "csms-screen__block--hpadded": t,
                        "csms-screen__block--vpadded": n,
                        [`csms-screen__block--align-${r}`]: r,
                        [`csms-screen__block--sticky-${r}`]: o
                    });
                return e ? (0, a.jsx)(l, {
                    className: d,
                    ...c,
                    children: e
                }) : null
            }
        },
        89769: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(33943);
            t.A = ({
                children: e,
                isWide: t
            }) => (0, a.jsx)(r.A, {
                slot: "secondary",
                isWide: t,
                children: e
            })
        },
        93827: function(e, t, n) {
            "use strict";
            n.d(t, {
                Dl: function() {
                    return s
                },
                HL: function() {
                    return h
                },
                P1: function() {
                    return m
                },
                P2: function() {
                    return b
                },
                P3: function() {
                    return v
                },
                Qi: function() {
                    return g
                },
                Sz: function() {
                    return c
                },
                ZS: function() {
                    return l
                },
                Zb: function() {
                    return o
                },
                er: function() {
                    return f
                },
                gT: function() {
                    return d
                },
                hE: function() {
                    return p
                },
                rc: function() {
                    return u
                },
                w4: function() {
                    return i
                }
            });
            var a = n(74848),
                r = n(77001);
            const s = ({
                    children: e,
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u
                }) => (0, a.jsx)(r.E, {
                    size: "display-2",
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u,
                    children: e
                }),
                i = ({
                    children: e,
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u
                }) => (0, a.jsx)(r.E, {
                    size: "display-3",
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u,
                    children: e
                }),
                o = ({
                    children: e,
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u
                }) => (0, a.jsx)(r.E, {
                    size: "header-1",
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u,
                    children: e
                }),
                c = ({
                    children: e,
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u
                }) => (0, a.jsx)(r.E, {
                    size: "header-2",
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u,
                    children: e
                }),
                l = ({
                    children: e,
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u
                }) => (0, a.jsx)(r.E, {
                    size: "header-3",
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u,
                    children: e
                }),
                d = ({
                    children: e,
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u
                }) => (0, a.jsx)(r.E, {
                    size: "header-4",
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u,
                    children: e
                }),
                u = ({
                    children: e,
                    tag: t,
                    color: n,
                    inline: s,
                    breakWords: i,
                    dangerous: o,
                    a11y: c,
                    dataQA: l
                }) => (0, a.jsx)(r.E, {
                    size: "action",
                    tag: t,
                    color: n,
                    inline: s,
                    breakWords: i,
                    dangerous: o,
                    a11y: c,
                    dataQA: l,
                    children: e
                }),
                f = ({
                    children: e,
                    tag: t,
                    color: n,
                    inline: s,
                    breakWords: i,
                    dangerous: o,
                    a11y: c,
                    dataQA: l
                }) => (0, a.jsx)(r.E, {
                    size: "action-small",
                    tag: t,
                    color: n,
                    inline: s,
                    breakWords: i,
                    dangerous: o,
                    a11y: c,
                    dataQA: l,
                    children: e
                }),
                p = ({
                    children: e,
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u
                }) => (0, a.jsx)(r.E, {
                    size: "p-title",
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u,
                    children: e
                }),
                h = ({
                    children: e,
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u
                }) => (0, a.jsx)(r.E, {
                    size: "caption",
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    a11y: d,
                    dataQA: u,
                    children: e
                }),
                m = ({
                    children: e,
                    tag: t,
                    weight: n,
                    align: s,
                    color: i,
                    inline: o,
                    ellipsis: c,
                    breakWords: l,
                    dangerous: d,
                    a11y: u,
                    dataQA: f
                }) => (0, a.jsx)(r.E, {
                    size: "bolder" === n ? "p-1-bolder" : "p-1",
                    tag: t,
                    align: s,
                    color: i,
                    inline: o,
                    ellipsis: c,
                    breakWords: l,
                    dangerous: d,
                    a11y: u,
                    dataQA: f,
                    children: e
                }),
                b = ({
                    children: e,
                    tag: t,
                    weight: n,
                    align: s,
                    color: i,
                    inline: o,
                    ellipsis: c,
                    breakWords: l,
                    dangerous: d,
                    a11y: u,
                    dataQA: f
                }) => (0, a.jsx)(r.E, {
                    size: "bolder" === n ? "p-2-bolder" : "p-2",
                    tag: t,
                    align: s,
                    color: i,
                    inline: o,
                    ellipsis: c,
                    breakWords: l,
                    dangerous: d,
                    a11y: u,
                    dataQA: f,
                    children: e
                }),
                v = ({
                    children: e,
                    tag: t,
                    weight: n,
                    align: s,
                    color: i,
                    inline: o,
                    ellipsis: c,
                    breakWords: l,
                    dangerous: d,
                    id: u,
                    a11y: f,
                    dataQA: p
                }) => (0, a.jsx)(r.E, {
                    size: "bolder" === n ? "p-3-bolder" : "p-3",
                    tag: t,
                    align: s,
                    color: i,
                    inline: o,
                    ellipsis: c,
                    breakWords: l,
                    dangerous: d,
                    id: u,
                    a11y: f,
                    dataQA: p,
                    children: e
                }),
                g = ({
                    children: e,
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    id: d,
                    a11y: u,
                    dataQA: f,
                    className: p
                }) => (0, a.jsx)(r.E, {
                    tag: t,
                    align: n,
                    color: s,
                    inline: i,
                    ellipsis: o,
                    breakWords: c,
                    dangerous: l,
                    id: d,
                    a11y: u,
                    dataQA: f,
                    className: p,
                    children: e
                })
        },
        94318: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(46942),
                s = n.n(r),
                i = n(45869),
                o = n(8483);
            t.A = ({
                name: e,
                notification: t,
                isDisabled: n,
                onClick: r,
                innerRef: c,
                a11y: l,
                dataQA: d
            }) => {
                const u = s()({
                    "csms-navigation-bar__icon": !0,
                    "csms-navigation-bar__icon--is-disabled": n
                });
                return (0, a.jsxs)("button", {
                    className: u,
                    onClick: n ? void 0 : r,
                    ref: c,
                    "data-qa": "navbar-icon",
                    "data-qa-icon": e,
                    "aria-disabled": n,
                    "aria-describedby": l ? .ariaDescribedby,
                    type: "button",
                    ...d,
                    children: [(0, a.jsx)(o.A, {
                        name: e,
                        supportsRtl: !0,
                        a11y: {
                            label: l ? .iconLabel
                        }
                    }), t ? (0, a.jsx)("div", {
                        className: "csms-navigation-bar__icon-notification",
                        children: (0, a.jsx)(i.A, { ...t,
                            a11y: {
                                label: l ? .notificationLabel
                            }
                        })
                    }) : null]
                })
            }
        },
        96540: function(e, t, n) {
            "use strict";
            e.exports = n(15287)
        },
        99795: function(e, t, n) {
            "use strict";
            var a = n(74848),
                r = n(46942),
                s = n.n(r);
            t.A = ({
                children: e,
                position: t,
                transparent: n,
                shadow: r,
                inverted: i,
                a11y: o = {
                    tag: "nav"
                },
                extra: c,
                extraClass: l,
                extraAttrs: d
            }) => {
                const u = s()(l, {
                        "csms-navigation-bar": !0,
                        [`csms-navigation-bar--${t}`]: t,
                        "csms-navigation-bar--transparent": n,
                        "csms-navigation-bar--shadow": r,
                        "csms-navigation-bar--inverted": i,
                        [l]: l
                    }),
                    f = e ? o ? .tag || "nav" : "div";
                return (0, a.jsxs)(f, {
                    className: u,
                    "data-qa": "navbar",
                    ...d,
                    "aria-label": o ? .label,
                    children: [(0, a.jsx)("div", {
                        className: "csms-navigation-bar__main",
                        children: e
                    }), c]
                })
            }
        }
    }
]);
//# sourceMappingURL=6416.42edae1d2219579e38b9.js.map
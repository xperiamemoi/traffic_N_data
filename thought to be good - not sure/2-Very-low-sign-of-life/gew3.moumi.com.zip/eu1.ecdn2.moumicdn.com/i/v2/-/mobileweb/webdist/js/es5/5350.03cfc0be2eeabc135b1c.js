"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [5350], {
        2904: function(n, e, i) {
            i.d(e, {
                t: function() {
                    return t
                }
            });
            var t, o = i(96540),
                a = i(64665),
                r = i(8483),
                s = i(74848);
            ! function(n) {
                n.LOGO = "LOGO", n.STORE = "STORE"
            }(t || (t = {}));
            var l = function(n, e) {
                var i, o, l;
                return ((l = {})[a.Y.BADOO] = ((i = {})[t.LOGO] = (0, s.jsx)(r.A, {
                    name: "logo-boxed"
                }), i[t.STORE] = (0, s.jsx)(r.A, {
                    name: "logo-square"
                }), i), l[a.Y.HOTORNOT] = ((o = {})[t.LOGO] = (0, s.jsx)(r.A, {
                    name: "logo-boxed"
                }), o[t.STORE] = (0, s.jsx)(r.A, {
                    name: "logo-square"
                }), o), l)[n][e]
            };
            e.A = function(n) {
                var e = n.product,
                    i = void 0 === e ? a.Y.BADOO : e,
                    r = n.variant,
                    c = void 0 === r ? t.LOGO : r;
                return (0, s.jsx)(o.Fragment, {
                    children: l(i, c)
                })
            }
        },
        26035: function(n, e, i) {
            i.d(e, {
                A: function() {
                    return d
                }
            });
            var t = i(99417),
                o = i(20679),
                a = i(1237),
                r = 2e3,
                s = "/offline-page-worker.js",
                l = a.D.OFFLINE_PAGE,
                c = !0;

            function d(n, e) {
                var i;
                if (c && null != (i = t.A.performance) && i.timing) {
                    c = !1;
                    var a = o.A.getRequest(n, e);
                    a.setStart(t.A.performance.timing.navigationStart), setTimeout((function() {
                        a.end()
                    }), 0), setTimeout((function() {
                        "serviceWorker" in t.A.navigator && t.A.navigator.serviceWorker.register(s, {
                            scope: l
                        })
                    }), r)
                }
            }
        },
        36631: function(n, e, i) {
            i.d(e, {
                z: function() {
                    return x
                }
            });
            var t = i(46942),
                o = i.n(t),
                a = i(64665),
                r = i(2904);
            i(27495), i(71761);
            var s, l = i(40075),
                c = i(74848),
                d = ((s = {})[a.Y.HOTORNOT] = "landing-logo--hotornot", s[a.Y.BADOO] = "landing-logo--badoo", s),
                u = function(n) {
                    var e, i = n.product,
                        t = void 0 === i ? a.Y.BADOO : i,
                        s = (e = l.Ay.get(605)).slice(-1).match(/^[.,:!?]/) ? e : e + ".",
                        u = o()({
                            "landing-logo": !0
                        }, d[t]);
                    return (0, c.jsxs)("div", {
                        className: u,
                        children: [(0, c.jsx)("div", {
                            className: "landing-logo__icon",
                            children: (0, c.jsx)(r.A, {
                                product: t
                            })
                        }), (0, c.jsx)("img", {
                            src: "data:image/svg+xml,%3Csvg viewBox='0 0 25 9' xmlns='http://www.w3.org/2000/svg'/%3E",
                            alt: s,
                            className: "landing-logo__stretcher"
                        })]
                    })
                },
                O = i(36693),
                T = i(84362),
                g = i(93827),
                v = function(n) {
                    var e = n.text;
                    return (0, c.jsx)("div", {
                        className: "landing-tagline",
                        children: (0, c.jsx)(g.Sz, {
                            align: "center",
                            children: e
                        })
                    })
                },
                f = i(87184),
                x = function(n) {
                    var e = n.taglineText,
                        i = n.product,
                        t = n.isCompact,
                        o = n.a11y,
                        a = void 0 === t ? window.matchMedia("(min-height: 790px)").matches : t;
                    return (0, c.jsxs)(f.A, {
                        hpadded: !0,
                        tag: "header",
                        align: "center",
                        children: [(0, c.jsx)(u, {
                            product: i
                        }), null != o && o.hiddenHeader ? (0, c.jsx)(T.A, {
                            children: (0, c.jsx)("h1", {
                                children: null == o ? void 0 : o.hiddenHeader
                            })
                        }) : null, !a && e ? (0, c.jsx)(v, {
                            text: e
                        }) : null, a ? null : (0, c.jsx)(O.A, {
                            bottom: "md"
                        })]
                    })
                }
        },
        57660: function(n, e, i) {
            i.d(e, {
                A: function() {
                    return m
                }
            });
            var t = i(96540),
                o = (i(62062), i(26099), i(98992), i(81454), i(47901)),
                a = i(87184),
                r = i(15376),
                s = i(99795),
                l = i(94318),
                c = i(28733),
                d = i(12501),
                u = i(95299),
                O = i(8483),
                T = i(73155),
                g = i(74848),
                v = function() {},
                f = function(n) {
                    var e = n.languages,
                        i = n.selectedLanguageId,
                        t = n.onClose,
                        f = n.onLanguageSelected,
                        x = void 0 === f ? v : f,
                        m = (0, T.B2)();
                    return (0, g.jsxs)(o.A, {
                        children: [(0, g.jsxs)(r.A, {
                            children: [(0, g.jsxs)(s.A, {
                                position: "fixed",
                                shadow: !0,
                                children: [t ? (0, g.jsx)(c.A, {
                                    children: (0, g.jsx)(l.A, {
                                        name: "navigation-bar-close",
                                        onClick: t,
                                        a11y: {
                                            iconLabel: m.get(270)
                                        }
                                    })
                                }) : null, (0, g.jsx)(d.A, {
                                    text: m.get(598)
                                })]
                            }), (0, g.jsx)(s.A, {})]
                        }), (0, g.jsx)(a.A, {
                            vpadded: !0,
                            children: (0, g.jsx)("ul", {
                                children: e.map((function(n) {
                                    return (0, g.jsx)("li", {
                                        children: (0, g.jsx)(u.A, {
                                            title: {
                                                text: n.name
                                            },
                                            onClick: function() {
                                                return x(n.id)
                                            },
                                            action: n.id === i ? {
                                                action: "custom",
                                                content: (0, g.jsx)(O.A, {
                                                    name: "generic-check"
                                                })
                                            } : void 0
                                        })
                                    }, "interface-language-" + n.id)
                                }))
                            })
                        })]
                    })
                },
                x = i(65736),
                m = function(n) {
                    var e = n.languages,
                        i = n.selectedLanguageId,
                        o = n.onClose,
                        a = n.onLanguageSelected,
                        r = (0, t.useState)(!0),
                        s = r[0],
                        l = r[1];
                    return (0, g.jsx)(x.A, {
                        isVisible: s,
                        type: "fullscreen",
                        onAnimationOutComplete: o,
                        hasDefaultDismissButton: !1,
                        children: (0, g.jsx)("div", {
                            style: {
                                position: "absolute",
                                top: 0,
                                right: 0,
                                bottom: 0,
                                left: 0,
                                overflow: "auto"
                            },
                            children: (0, g.jsx)(f, {
                                languages: e,
                                selectedLanguageId: i,
                                onClose: function() {
                                    l(!1)
                                },
                                onLanguageSelected: a
                            })
                        })
                    })
                }
        },
        64665: function(n, e, i) {
            var t;
            i.d(e, {
                    Y: function() {
                        return t
                    }
                }),
                function(n) {
                    n.BADOO = "BADOO", n.HOTORNOT = "HOTORNOT"
                }(t || (t = {}))
        },
        88309: function(n, e, i) {
            var t, o = i(99417);
            e.A = function() {
                return t || ((t = o.A.document.createElement("div")).className = "modal-container"), t
            }
        },
        91133: function(n, e, i) {
            i.d(e, {
                G: function() {
                    return r
                }
            });
            var t = i(31709),
                o = i(96540),
                a = i(5322),
                r = function(n) {
                    var e = (0, o.useContext)(a.P).getScreenStoryByType;
                    return (0, o.useCallback)((function(i, o) {
                        var a = e(n);
                        if (a) {
                            var r = {
                                id: a.id,
                                type: a.type,
                                version: a.version,
                                variation: a.variation
                            };
                            return new t.Ay(278, {
                                screen_stats: {
                                    event: i,
                                    screen: r
                                }
                            }).onResponse(387, (function() {
                                null == o || o()
                            })).request()
                        }
                    }), [e, n])
                }
        },
        92669: function(n, e, i) {
            i.d(e, {
                U4: function() {
                    return v
                },
                i6: function() {
                    return u
                },
                cB: function() {
                    return f
                },
                cC: function() {
                    return O
                },
                bt: function() {
                    return g
                },
                TM: function() {
                    return T
                }
            });
            var t, o, a, r, s, l, c, d = i(64665);
            ! function(n) {
                n[n.RU = 2] = "RU"
            }(t || (t = {})),
            function(n) {
                n.CHAT = "chat", n.DATING = "dating"
            }(o || (o = {}));
            var u = "mw-bottom-link",
                O = ((a = {})[1] = 61, a[3] = 179, a[2] = 178, a[39] = 1264, a[37] = 175, a[40] = 1334, a[18] = 1335, a[9] = 2199, a[42] = 2543, a),
                T = ((r = {})[39] = "apple-login", r[1] = "facebook-login", r[3] = "odnoklassniki-login", r[4] = "google-login", r[40] = "phone-login", r[18] = "email-login", r[37] = "manual-login", r),
                g = ((s = {})[39] = "small", s[1] = "small", s[3] = "small", s),
                v = ((l = {})[100] = d.Y.BADOO, l[101] = d.Y.BADOO, l[102] = d.Y.BADOO, l[200] = d.Y.HOTORNOT, l),
                f = ((c = {})[o.DATING] = 384, c[o.CHAT] = 43, c)
        },
        95917: function(n, e, i) {
            i.d(e, {
                A: function() {
                    return O
                }
            });
            var t, o = i(46942),
                a = i.n(o),
                r = i(64665),
                s = i(40223);
            ! function(n) {
                n.TOP_LEFT = "TOP_LEFT", n.TOP_RIGHT = "TOP_RIGHT", n.BOTTOM_LEFT = "BOTTOM_LEFT"
            }(t || (t = {}));
            var l = i(74848),
                c = function(n) {
                    var e = n.tokens;
                    switch (n.position) {
                        case t.TOP_LEFT:
                            return (0, l.jsx)("svg", {
                                "aria-hidden": !0,
                                viewBox: "0 0 64 64",
                                children: (0, l.jsx)("path", {
                                    fill: e.TOKEN_COLOR_PRIMARY,
                                    fillRule: "evenodd",
                                    d: "M49.11 21.689l-.18-.488-6.088 2.196.18.489c2.226 6.063-.967 12.802-7.119 15.022-6.151 2.22-12.967-.909-15.194-6.973l-.18-.488-6.087 2.197.179.488c1.667 4.54 5.028 8.162 9.464 10.198a18.432 18.432 0 0 0 14.022.579c4.606-1.662 8.287-4.992 10.365-9.378 2.079-4.386 2.305-9.301.638-13.842zM40.208 5.992c8.662-3.124 18.766 1.36 22.018 10.216 6.345 17.28-5.332 37.356-19.115 42.33C29.328 63.51 7.364 55.57 1.02 38.29c-3.252-8.855 1.58-18.729 10.242-21.854 10.507-3.79 17.223 3.06 17.7 3.567.038-.692.74-10.22 11.247-14.01z"
                                })
                            });
                        case t.TOP_RIGHT:
                        case t.BOTTOM_LEFT:
                            return (0, l.jsx)("svg", {
                                "aria-hidden": !0,
                                viewBox: "0 0 64 64",
                                children: (0, l.jsx)("path", {
                                    fill: e.TOKEN_COLOR_GENERIC_PINK,
                                    fillRule: "evenodd",
                                    d: "M49.617 31.404l.135-.502-6.21-1.664-.136.502c-1.672 6.24-8.138 9.947-14.413 8.266-6.276-1.68-10.021-8.124-8.349-14.362l.135-.503-6.211-1.663-.135.502c-1.252 4.671-.6 9.553 1.838 13.746s6.368 7.196 11.067 8.454c4.699 1.259 9.604.623 13.812-1.79 4.208-2.413 7.215-6.315 8.467-10.986zm1.778-17.934c8.836 2.367 14.475 11.793 12.033 20.903-4.765 17.778-25.787 27.594-39.849 23.828C9.518 54.435-3.778 35.426.987 17.649 3.429 8.539 13.027 3.193 21.864 5.56 32.583 8.431 34.11 17.87 34.206 18.557c.428-.547 6.47-7.958 17.19-5.087z"
                                })
                            })
                    }
                },
                d = function(n) {
                    switch (n.position) {
                        case t.TOP_LEFT:
                            return (0, l.jsx)("svg", {
                                "aria-hidden": !0,
                                viewBox: "0 0 64 64",
                                children: (0, l.jsx)("path", {
                                    fill: "#1f63dc",
                                    fillRule: "evenodd",
                                    d: "M39.2727273,4.30178326 C48.7883044,0.50180796 59.243341,5.41166004 62.5454545,15.2318244 C68.3086978,30.4284976 54.7572978,57.4657814 44.3636364,61.1379973 C34.4168418,64.9017907 6.73243799,52.9393814 1.45454545,37.0919067 C-2.33291886,27.9225438 2.53398552,17.4113377 11.6363636,13.7744856 C17.4019785,11.9759368 23.4100801,12.7321527 28.3636364,15.9604938 C29.8023853,10.3952709 33.9203114,5.93720891 39.2727273,4.30178326 Z"
                                })
                            });
                        case t.TOP_RIGHT:
                        case t.BOTTOM_LEFT:
                            return (0, l.jsx)("svg", {
                                "aria-hidden": !0,
                                viewBox: "0 0 64 64",
                                children: (0, l.jsx)("path", {
                                    fill: "#e71032",
                                    fillRule: "evenodd",
                                    d: "M51.0144928,11.1020408 C60.5586305,14.1273805 66.0615289,24.2427175 63.0724638,34.3219955 C58.7103179,49.8443319 32.0728726,63.8132221 21.3333333,61.2571429 C11.4465421,57.9068159 -3.73136409,31.9639853 0.927536232,15.7460317 C3.61984692,6.36237099 13.6542314,0.696177464 23.1884058,3.67165533 C28.7311862,5.01350474 33.0995197,9.15196907 35.2463768,14.8172336 C39.5816654,11.0081492 45.4816757,9.81005326 51.0144928,11.1020408 Z"
                                })
                            })
                    }
                },
                u = function(n, e, i) {
                    var o, a, s;
                    return ((s = {})[r.Y.BADOO] = ((o = {})[t.TOP_LEFT] = (0, l.jsx)(c, {
                        tokens: e,
                        position: t.TOP_LEFT
                    }), o[t.TOP_RIGHT] = (0, l.jsx)(c, {
                        tokens: e,
                        position: t.TOP_RIGHT
                    }), o[t.BOTTOM_LEFT] = (0, l.jsx)(c, {
                        tokens: e,
                        position: t.BOTTOM_LEFT
                    }), o), s[r.Y.HOTORNOT] = ((a = {})[t.TOP_LEFT] = (0, l.jsx)(d, {
                        position: t.TOP_LEFT
                    }), a[t.TOP_RIGHT] = (0, l.jsx)(d, {
                        position: t.TOP_RIGHT
                    }), a[t.BOTTOM_LEFT] = (0, l.jsx)(d, {
                        position: t.BOTTOM_LEFT
                    }), a), s)[n][i]
                },
                O = function(n) {
                    var e = n.product,
                        i = void 0 === e ? r.Y.BADOO : e;
                    return i === r.Y.BADOO ? null : (0, l.jsx)(s.ZC, {
                        children: function(n) {
                            return (0, l.jsxs)("div", {
                                className: "landing-decoration",
                                children: [(0, l.jsx)("div", {
                                    className: a()({
                                        "landing-decoration__item": !0,
                                        "landing-decoration__item--tl": !0
                                    }),
                                    children: (0, l.jsx)("div", {
                                        className: "icon-inline",
                                        children: u(i, n.tokens, t.TOP_LEFT)
                                    })
                                }), (0, l.jsx)("div", {
                                    className: a()({
                                        "landing-decoration__item": !0,
                                        "landing-decoration__item--tr": !0
                                    }),
                                    children: (0, l.jsx)("div", {
                                        className: "icon-inline",
                                        children: u(i, n.tokens, t.TOP_RIGHT)
                                    })
                                }), (0, l.jsx)("div", {
                                    className: "landing-decoration__item landing-decoration__item--bl",
                                    children: (0, l.jsx)("div", {
                                        className: "icon-inline",
                                        children: u(i, n.tokens, t.BOTTOM_LEFT)
                                    })
                                })]
                            })
                        }
                    })
                }
        }
    }
]);
//# sourceMappingURL=5350.03cfc0be2eeabc135b1c.js.map
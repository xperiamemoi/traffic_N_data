(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [3669], {
        426: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(46942),
                i = a.n(t),
                c = a(25275);
            s.A = ({
                type: e = "base",
                id: s = "chat-composer-mini-input",
                name: a,
                value: t,
                iconName: r,
                iconColor: o,
                iconColorCustomValue: l,
                isActionDisabled: d,
                onFocus: u,
                onChange: m,
                onBlur: p,
                onSubmit: h,
                inputRef: x,
                a11y: f
            }) => {
                const b = i()({
                        "csms-chat-composer-mini": !0,
                        [`csms-chat-composer-mini--${e}`]: e
                    }),
                    v = i()({
                        "csms-chat-composer-mini__action": !0,
                        "csms-chat-composer-mini__action--is-disabled": d
                    });
                return (0, n.jsxs)("form", {
                    className: b,
                    onSubmit: h,
                    "aria-label": f.formLabel,
                    noValidate: !0,
                    children: [(0, n.jsxs)("div", {
                        className: "csms-chat-composer-mini__input",
                        children: [t ? null : (0, n.jsx)("label", {
                            className: "csms-chat-composer-mini__input-label",
                            "aria-hidden": !0,
                            htmlFor: s,
                            children: f.inputLabel
                        }), (0, n.jsx)("input", {
                            className: "csms-chat-composer-mini__input-field",
                            type: "text",
                            id: s,
                            name: a,
                            value: t,
                            onFocus: u,
                            onChange: m,
                            onBlur: p,
                            autoComplete: "off",
                            ref: x,
                            "data-qa": "quick-chat-text-input",
                            "aria-label": f.inputLabel
                        })]
                    }), (0, n.jsx)("div", {
                        className: "csms-chat-composer-mini__focus-ring"
                    }), (0, n.jsx)("div", {
                        className: v,
                        children: (0, n.jsx)(c.A, {
                            icon: r,
                            color: o,
                            colorCustomValue: l,
                            isDisabled: d,
                            a11y: {
                                label: f.actionLabel
                            },
                            buttonAttrs: {
                                type: "submit"
                            },
                            dataQA: {
                                "data-qa": "quick-chat-send"
                            }
                        })
                    })]
                })
            }
        },
        842: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(96540);
            s.A = ({
                children: e,
                onClick: s,
                innerRef: a,
                dataQA: i,
                a11y: c
            }) => {
                const r = {
                    "data-qa": "overlay-action",
                    ...i
                };
                return s ? (0, n.jsx)("button", {
                    className: "csms-a11y-stretched-touch",
                    onClick: s,
                    ref: a,
                    tabIndex: c ? .tabIndex,
                    "aria-hidden": c ? .ariaHidden || !e,
                    "aria-describedby": c ? .ariaDescribedby,
                    type: "button",
                    ...r,
                    children: e
                }) : (0, n.jsx)(t.Fragment, {
                    children: e
                })
            }
        },
        2694: function(e, s, a) {
            "use strict";
            var n = a(6925);

            function t() {}

            function i() {}
            i.resetWarningCache = t, e.exports = function() {
                function e(e, s, a, t, i, c) {
                    if (c !== n) {
                        var r = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
                        throw r.name = "Invariant Violation", r
                    }
                }

                function s() {
                    return e
                }
                e.isRequired = e;
                var a = {
                    array: e,
                    bigint: e,
                    bool: e,
                    func: e,
                    number: e,
                    object: e,
                    string: e,
                    symbol: e,
                    any: e,
                    arrayOf: s,
                    element: e,
                    elementType: e,
                    instanceOf: s,
                    node: e,
                    objectOf: s,
                    oneOf: s,
                    oneOfType: s,
                    shape: s,
                    exact: s,
                    checkPropTypes: i,
                    resetWarningCache: t
                };
                return a.PropTypes = a, a
            }
        },
        3368: function(e, s) {
            "use strict";
            s.A = function(e) {
                return function(s) {
                    return null == e ? void 0 : e[s]
                }
            }
        },
        3809: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(46942),
                i = a.n(t);
            s.A = ({
                id: e,
                name: s,
                value: a,
                maxLength: t,
                autoFocus: c,
                maxHeight: r,
                minHeight: o,
                autoResize: l,
                rows: d = 1,
                isFocused: u,
                status: m,
                onFocus: p,
                onChange: h,
                onBlur: x,
                onKeyUp: f,
                textareaRef: b,
                dataQA: v,
                dataQATextarea: _,
                a11y: g = {}
            }) => {
                const j = i()({
                        "csms-text-area": !0,
                        "csms-text-area--is-focused": u,
                        [`csms-text-area--status-${m}`]: m
                    }),
                    y = {
                        "data-qa": "text-area",
                        ...v
                    },
                    N = {
                        maxHeight: r ? `${r}px` : void 0,
                        minHeight: o ? `${o}px` : void 0
                    };
                return (0, n.jsxs)("div", {
                    className: j,
                    ...y,
                    children: [l ? (0, n.jsx)("div", {
                        className: "csms-text-area__mirror",
                        "aria-hidden": !0,
                        style: N,
                        children: a
                    }) : null, (0, n.jsx)("textarea", {
                        className: "csms-text-area__input",
                        id: e,
                        name: s,
                        value: a,
                        maxLength: t,
                        autoFocus: c,
                        style: N,
                        rows: d,
                        onFocus: p,
                        onChange: h,
                        onKeyUp: f,
                        onBlur: x,
                        ref: b,
                        dir: "auto",
                        "data-qa": _ || "text-area-input",
                        "aria-label": g ? .textareaLabel,
                        "aria-describedby": g.ariaDescribedby,
                        "aria-required": g.ariaRequired,
                        "aria-invalid": "error" === m || void 0
                    }), (0, n.jsx)("div", {
                        className: "csms-text-area__focus-ring"
                    })]
                })
            }
        },
        4037: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(46942),
                i = a.n(t);
            s.A = ({
                type: e = "primary",
                padding: s = "none",
                hasTransparency: a = !1,
                children: t
            }) => (0, n.jsx)("div", {
                className: i()("csms-card", `csms-card--${e}`, `csms-card--padding-${s}`, {
                    "csms-card--has-transparency": a
                }),
                children: t
            })
        },
        5556: function(e, s, a) {
            e.exports = a(2694)()
        },
        6925: function(e) {
            "use strict";
            e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
        },
        10730: function(e, s, a) {
            "use strict";
            var n = a(74848);
            s.A = ({
                children: e
            }) => (0, n.jsx)("div", {
                className: "csms-navigation-bar__content",
                children: e
            })
        },
        10901: function(e, s, a) {
            "use strict";
            a.d(s, {
                A: function() {
                    return r
                }
            });
            var n = a(3456),
                t = (0, a(3368).A)({
                    "&amp;": "&",
                    "&lt;": "<",
                    "&gt;": ">",
                    "&quot;": '"',
                    "&#39;": "'"
                }),
                i = /&(?:amp|lt|gt|quot|#39);/g,
                c = RegExp(i.source);
            var r = function(e) {
                return (e = (0, n.A)(e)) && c.test(e) ? e.replace(i, t) : e
            }
        },
        12554: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(84362),
                i = a(26914),
                c = a(53787),
                r = a(93827);
            s.A = ({
                user: e,
                additional: s,
                onClick: a,
                innerRef: o,
                a11y: l
            }) => {
                const d = a ? "button" : "div";
                return (0, n.jsxs)(d, {
                    className: "csms-navigation-bar__profile",
                    onClick: a,
                    ref: o,
                    type: "button" === d ? "button" : void 0,
                    children: [(0, n.jsx)(t.A, {
                        children: l ? .label
                    }), (0, n.jsx)("span", {
                        className: "csms-navigation-bar__profile-avatar",
                        "aria-hidden": Boolean(l ? .label) || void 0,
                        children: (0, n.jsx)(i.A, {
                            user: e
                        })
                    }), e ? .name ? (0, n.jsxs)("span", {
                        className: "csms-navigation-bar__profile-info",
                        children: [(0, n.jsx)(t.A, {
                            tag: "h1",
                            children: e.name
                        }), (0, n.jsx)(r.ZS, {
                            a11y: {
                                ariaHidden: Boolean(l ? .label) || void 0
                            },
                            children: (0, n.jsx)(c.A, {
                                name: e.name,
                                age: e.age,
                                status: e.status,
                                a11y: {
                                    label: l ? .profileInfoLabel
                                }
                            })
                        })]
                    }) : null, s ? (0, n.jsx)("span", {
                        className: "csms-navigation-bar__profile-additional",
                        "aria-hidden": Boolean(l ? .label) || void 0,
                        children: (0, n.jsx)(r.P3, {
                            ellipsis: !0,
                            children: s
                        })
                    }) : null]
                })
            }
        },
        13570: function(e, s, a) {
            "use strict";
            var n = a(74848);
            s.A = ({
                children: e
            }) => (0, n.jsx)("div", {
                className: "csms-actionsheet__content",
                children: e
            })
        },
        15279: function(e, s, a) {
            "use strict";
            var n = a(74848);
            s.A = ({
                text: e
            }) => (0, n.jsx)("div", {
                className: "csms-navigation-bar__sub-title",
                children: e
            })
        },
        25275: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(46942),
                i = a.n(t),
                c = a(8483);
            s.A = ({
                icon: e,
                color: s = "base",
                colorCustomValue: a,
                onClick: t,
                isDisabled: r,
                buttonAttrs: o,
                dataQA: l,
                a11y: d
            }) => {
                const u = i()({
                    "csms-chat-composer-action": !0,
                    [`csms-chat-composer-action--${s}`]: s
                });
                let m;
                "custom" === s && (m = {
                    color: a
                });
                const p = !!t || !!o ? .type,
                    h = p ? "button" : "span",
                    x = {
                        className: u,
                        style: m,
                        onClick: r ? void 0 : t,
                        type: p ? o ? .type || "button" : void 0,
                        "aria-disabled": p && r ? r : void 0,
                        "aria-pressed": "toggle" === d.role ? Boolean(d.ariaPressed) : void 0,
                        ...l
                    };
                return (0, n.jsx)(h, { ...x,
                    children: (0, n.jsx)(c.A, {
                        name: e,
                        a11y: {
                            label: d.label
                        }
                    })
                })
            }
        },
        26443: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(46942),
                i = a.n(t),
                c = a(84362);
            s.A = ({
                status: e = "hidden",
                a11y: s
            }) => {
                const a = i()({
                    "csms-online-status": !0,
                    [`csms-online-status--${e}`]: !0
                });
                return (0, n.jsx)("span", {
                    className: a,
                    "data-qa-online-status": e,
                    children: (0, n.jsx)(c.A, {
                        children: s ? .label
                    })
                })
            }
        },
        37819: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(46942),
                i = a.n(t);
            s.A = ({
                variant: e = "supportive"
            }) => {
                const s = i()("csms-divider", {
                    "csms-divider--border-interactive": "interactive" === e
                });
                return (0, n.jsx)("div", {
                    className: s
                })
            }
        },
        41562: function(e, s, a) {
            "use strict";

            function n(e) {
                if (!e) return !1;
                if (!0 === e.isTrusted) return !0;
                var s = e;
                return 0 !== s.pageX || 0 !== s.pageY
            }
            a.d(s, {
                Z: function() {
                    return n
                }
            })
        },
        45141: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(46942),
                i = a.n(t),
                c = a(93827);
            s.A = ({
                media: e,
                title: s,
                extra: a,
                isSelected: t,
                state: r,
                onClick: o,
                tag: l,
                innerRef: d,
                dataQA: u
            }) => {
                const m = i()({
                        "csms-action-cell": !0,
                        "csms-action-cell--is-selected": t,
                        [`csms-action-cell--${r}`]: r
                    }),
                    p = o ? "button" : l || "span",
                    h = {
                        "data-qa": "action-cell",
                        ...u
                    };
                return (0, n.jsxs)(p, {
                    className: m,
                    onClick: o,
                    type: "button" === p ? "button" : void 0,
                    ref: d,
                    ...h,
                    children: [e ? (0, n.jsx)("span", {
                        className: "csms-action-cell__media",
                        children: e
                    }) : null, (0, n.jsx)("span", {
                        className: "csms-action-cell__title",
                        children: (0, n.jsx)(c.Qi, {
                            breakWords: !0,
                            children: s
                        })
                    }), a ? (0, n.jsx)("span", {
                        className: "csms-action-cell__extra",
                        children: a
                    }) : null]
                })
            }
        },
        45998: function(e, s, a) {
            "use strict";
            var n = a(74848);
            s.A = ({
                children: e,
                tag: s = "div"
            }) => {
                const a = s;
                return (0, n.jsx)(a, {
                    className: "csms-spring-box__content",
                    children: e
                })
            }
        },
        53787: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(84362),
                i = a(26443);
            s.A = ({
                name: e,
                age: s,
                status: a,
                a11y: c
            }) => {
                const r = Boolean(c ? .label);
                return (0, n.jsxs)("span", {
                    className: "csms-profile-info",
                    children: [(0, n.jsx)("span", {
                        className: "csms-profile-info__name",
                        "data-qa": "profile-info__name",
                        "aria-hidden": r,
                        children: (0, n.jsx)("span", {
                            className: "csms-profile-info__name-inner",
                            children: e
                        })
                    }), s ? (0, n.jsx)("span", {
                        className: "csms-profile-info__age",
                        "aria-hidden": r,
                        children: (0, n.jsxs)("span", {
                            children: [", ", (0, n.jsx)("span", {
                                "data-qa": "profile-info__age",
                                children: s
                            })]
                        })
                    }) : null, a ? .online && "hidden" !== a ? .online ? (0, n.jsx)("span", {
                        className: "csms-profile-info__status",
                        "aria-hidden": r,
                        children: (0, n.jsx)(i.A, {
                            status: a.online
                        })
                    }) : null, (0, n.jsx)(t.A, {
                        children: c ? .label
                    })]
                })
            }
        },
        55015: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(46942),
                i = a.n(t),
                c = a(842),
                r = a(93827);
            s.A = ({
                header: e,
                children: s,
                hpadded: a
            }) => {
                const t = i()({
                    "csms-view-profile-block": !0,
                    "csms-view-profile-block--hpadded": a
                });
                return (0, n.jsxs)("section", {
                    className: t,
                    children: [e ? (0, n.jsxs)("div", {
                        className: "csms-view-profile-block__header",
                        children: [e.title ? (0, n.jsx)("div", {
                            className: "csms-view-profile-block__header-title",
                            children: (0, n.jsx)(r.gT, {
                                color: "gray-80",
                                ellipsis: !0,
                                tag: e.titleTag || "h3",
                                children: (0, n.jsx)(c.A, {
                                    onClick: e.onClickTitle,
                                    children: e.title
                                })
                            })
                        }) : null, e.text ? (0, n.jsx)("div", {
                            className: "csms-view-profile-block__header-text",
                            children: (0, n.jsx)(r.Sz, {
                                color: "black",
                                children: e.text
                            })
                        }) : null, e.action ? (0, n.jsx)("button", {
                            className: "csms-view-profile-block__header-action",
                            onClick: e.onClickAction,
                            type: "button",
                            children: (0, n.jsx)(r.rc, {
                                children: e.action
                            })
                        }) : null]
                    }) : null, s ? (0, n.jsx)("div", {
                        className: "csms-view-profile-block__content",
                        children: s
                    }) : null]
                })
            }
        },
        56123: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(46942),
                i = a.n(t);
            s.A = ({
                percentage: e = 0,
                color: s = "default",
                indicatorColorCustomValue: a,
                backgroundColorCustomValue: t,
                direction: c = "clockwise",
                rounded: r = !0,
                strokeRelativeWidth: o = .04,
                strokeIsOutside: l = !1,
                a11y: d
            }) => {
                const u = i()({
                        "csms-progress-circle": !0,
                        [`csms-progress-circle--${s}`]: !0
                    }),
                    m = 100,
                    p = m * o,
                    h = (m + (l ? 1 : -1) * p) / 2,
                    x = 2 * h * 3.1415,
                    f = ("anticlockwise" === c ? -1 : 1) * x * (1 - Number(e) / 100),
                    b = r ? "round" : "square";
                return (0, n.jsx)("span", {
                    className: u,
                    role: "progressbar",
                    "aria-valuenow": e,
                    "aria-valuemin": 0,
                    "aria-valuemax": 100,
                    "aria-valuetext": d ? .label,
                    children: (0, n.jsxs)("svg", {
                        className: "csms-progress-circle__svg",
                        width: m,
                        height: m,
                        viewBox: "0 0 100 100",
                        "aria-hidden": !0,
                        children: [(0, n.jsx)("circle", {
                            className: "csms-progress-circle__svg-path-background",
                            cx: "50%",
                            cy: "50%",
                            r: h,
                            fill: "transparent",
                            stroke: "custom" === s ? t : "",
                            strokeWidth: p
                        }), (0, n.jsx)("circle", {
                            className: "csms-progress-circle__svg-path-indicator",
                            cx: "50%",
                            cy: "50%",
                            r: h,
                            fill: "transparent",
                            stroke: "custom" === s ? a : "",
                            strokeWidth: p,
                            strokeDasharray: x,
                            strokeDashoffset: f,
                            strokeLinecap: b
                        })]
                    })
                })
            }
        },
        66130: function(e, s, a) {
            "use strict";
            var n = a(74848);
            s.A = ({
                children: e
            }) => (0, n.jsx)("div", {
                className: "csms-form-actions",
                "data-qa": "form-actions",
                children: e
            })
        },
        87019: function(e, s, a) {
            "use strict";
            var n = a(74848);
            s.A = ({
                children: e,
                tag: s = "div"
            }) => {
                const a = s;
                return (0, n.jsx)(a, {
                    className: "csms-spring-box__media",
                    children: e
                })
            }
        },
        89162: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(46942),
                i = a.n(t),
                c = a(93827);
            s.A = ({
                text: e,
                color: s = "gray-80",
                tag: a
            }) => {
                const t = "string" == typeof e,
                    r = i()({
                        "csms-form-text": !0,
                        [`csms-form-text--${s}`]: s
                    });
                return (0, n.jsx)("div", {
                    className: r,
                    "data-qa": "form-text",
                    children: (0, n.jsx)(c.P1, {
                        breakWords: !0,
                        dangerous: t,
                        tag: a,
                        children: e
                    })
                })
            }
        },
        94767: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(46942),
                i = a.n(t);
            s.A = ({
                children: e,
                isCompact: s,
                tag: a = "div",
                a11y: t
            }) => {
                const c = i()({
                        "csms-spring-box": !0,
                        "csms-spring-box--is-compact": s
                    }),
                    r = a;
                return (0, n.jsx)(r, {
                    className: c,
                    "aria-hidden": t ? .ariaHidden,
                    children: e
                })
            }
        },
        96506: function(e, s, a) {
            "use strict";
            var n = a(74848),
                t = a(46942),
                i = a.n(t);
            s.A = ({
                children: e,
                isCompact: s
            }) => {
                const a = i()({
                    "csms-cta-box__additional": !0,
                    "csms-cta-box__additional--is-compact": s
                });
                return (0, n.jsx)("div", {
                    className: a,
                    "data-qa": "cta-box-additional",
                    children: e
                })
            }
        }
    }
]);
//# sourceMappingURL=3669.afed2e6860d19c45dd6b.js.map
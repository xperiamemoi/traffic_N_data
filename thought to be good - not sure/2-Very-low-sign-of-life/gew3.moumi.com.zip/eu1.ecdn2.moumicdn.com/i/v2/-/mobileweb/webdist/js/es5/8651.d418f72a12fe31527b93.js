"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [8651], {
        61155: function(e, t, n) {
            var s = n(58544),
                r = n(84230),
                i = n(15566),
                o = (0, s.lh)(),
                u = r.A.getInstance("EncountersProgressBar"),
                a = "GoalProgress",
                c = {
                    get: function() {
                        return u.get(a)
                    },
                    update: function(e) {
                        var t = function(e) {
                            if (e instanceof i.rxp) return {
                                goal: e.getGoal(),
                                progress: e.getProgress()
                            };
                            return null
                        }(e);
                        t && t.goal === t.progress ? this.setAsReached() : (o.trigger(t), u.put(a, t, {
                            ttl: 6048e5
                        }))
                    },
                    setAsReached: function() {
                        o.trigger(null), u.invalidate(a)
                    },
                    subscribeOnChange: o.subscribe,
                    unsubscribeFromChange: o.unsubscribe
                };
            t.A = c
        },
        88651: function(e, t, n) {
            n(2008), n(50113), n(51629), n(74423), n(25276), n(48598), n(62062), n(72712), n(60739), n(26099), n(3362), n(21699), n(98992), n(54520), n(72577), n(3949), n(81454), n(8872), n(23500);
            var s, r = n(23735),
                i = n(64741),
                o = n(1978),
                u = n(23149),
                a = n(57917),
                c = (n(72537), n(7714), n(31087)),
                h = n(54864),
                g = n(92105),
                l = n(61155),
                d = n(32308),
                f = n(15566),
                _ = n(8054),
                p = null,
                v = null,
                y = "84::fab",
                I = "",
                C = a.A.extend({
                    name: "Encounters",
                    votedOn_: null,
                    getRequestMessageType: 81,
                    getResponseMessageType: [84, 83],
                    setRequestMessageType: 80,
                    setResponseMessageType: 132,
                    preventMultiple: !0,
                    hasInitialEncounters: !1,
                    previousSessionCached_: [],
                    init_: function() {
                        (0, g.A)(this), this.votedOn_ = this.cache_.get("votedOn") || {}, I = this.cache_.get("lastSeenId") || ""
                    },
                    getMessageBody_: function(e, t, n, s) {
                        var r = new f.KMf;
                        r.setLastPersonId(I);
                        var i = (this.hasInitialEncounters, 20);
                        return n = "number" == typeof n ? n : i, "number" == typeof t && r.setContext(t), e && Array.isArray(e) && e.length && (r.setRequestedPersonIds(e), this.cache_.invalidateAll(!0), I = "", p = null, v = null), r.setNumber(i), s && Array.isArray(s) && r.setEncountersQueueState(s), r
                    },
                    get: function(e) {
                        var t = this.getMessageBody_(e.ids, e.context, e.initialFetchCount, e.queueState).setUserFieldFilter(h.h.getEncountersFilter());
                        return this.hasInitialEncounters || (this.hasInitialEncounters = !0), this.get_(this.getRequestMessageType, this.getResponseMessageType, t).then(this.handleGetResponse_.bind(this, t, e.ids))
                    },
                    getFromCache_: function() {
                        return p || C._super.getFromCache_.apply(this, arguments)
                    },
                    handleGetResponse_: function(e, t, n) {
                        var s, r = this,
                            i = n.fromCache,
                            o = n[0] instanceof f.nsU,
                            u = this.getFromCache_(this.getRequestMessageType, e);
                        if (o && (!u || 0 === u.length)) return n[0];
                        if (o && (null == u ? void 0 : u.length) > 0 && (s = u), i && !o && (s = n), !i && !o) {
                            var a = n[0];
                            v = a;
                            var c = function(e) {
                                var t = e.getUserSubstitutes([]),
                                    n = e.getQuota();
                                if (n && 0 === n.getYesVotesQuota()) return t.find((function(e) {
                                    return 2 === e.getType() && 2 === e.getDisplayStrategy()
                                }));
                                return !1
                            }(a);
                            if (c) return c;
                            l.A.update(a.getGoalProgress()), s = this.processNewEncountersResponse(a, u)
                        }
                        var h = this.filterValidEncounters_(s, t);
                        return i && h.length < 12 ? r.fetch_(r.getRequestMessageType, r.getResponseMessageType, e).then(r.handleGetResponse_.bind(r, e, t)) : 0 === h.length && o ? n[0] : (this.cacheLastSeenId(h), i && h.length > 0 && function(e) {
                            r.previousSessionCached_ = e.map((function(e) {
                                return r.getUserId_(e)
                            }))
                        }(h), i || function(t) {
                            r.cacheResponse_(r.getCacheKey_(81, e), r.getCacheTime_(), t, !0)
                        }(h), {
                            encounters: h,
                            isCached: i,
                            hasLikedYouEntry: this.cache_.get(y)
                        })
                    },
                    processNewEncountersResponse: function(e, t) {
                        var n = this.substituteUsers_(e.getResults(), e.getUserSubstitutes([]));
                        return (null == t ? void 0 : t.length) > 0 ? this.getUnion_(t, n) : n
                    },
                    cacheLastSeenId: function(e) {
                        I !== (I = (e.length, this.getUserId_(e[e.length - 1]))) && this.cache_.put("lastSeenId", I, {
                            ttl: this.getCacheTime_()
                        })
                    },
                    forceUserVoteYes: function(e) {
                        for (var t = 0, n = e.length; t < n; t += 1) e[t].setHasUserVoted(!0);
                        return e
                    },
                    getUnion_: function(e, t) {
                        for (var n = this, s = e.map((function(e) {
                                return n.getUserId_(e)
                            })), r = 0; r < t.length; r += 1) - 1 === s.indexOf(this.getUserId_(t[r])) && e.push(t[r]);
                        return e
                    },
                    _constructVoteEntity: function(e) {
                        var t = (new f.s5f).setPersonId(e.id).setVote(e.voteType).setVoteSource(e.source).setIsForCachedEncounters(e.cached || !1).setClientSideMatch(e.canClientMatch || !1);
                        if (t.setFirstPhotoId(e.firstPhotoId || "").setHiddenPhotoIds(e.hiddenPhotoIds || []).setIsEngagedVote(e.isEngagedVote || !1), this.previousSessionCached_.includes(e.id)) {
                            var n = this.previousSessionCached_.indexOf(e.id);
                            n > -1 && (t.setIsForCachedEncounters(!0), this.previousSessionCached_.splice(n, 1))
                        }
                        return "string" == typeof e.photoId && t.setPhotoId(e.photoId), t
                    },
                    _isSetRequestValid: function(e) {
                        return (0, u.A)(e) && e.id && (0, d.Rg)(e.voteType) && (0, d.Rg)(e.source)
                    },
                    set: function(e) {
                        if (!this._isSetRequestValid(e)) return this.log.error("Invalid set request"), Promise.reject(new Error("Invalid set request"));
                        this.votedOn_[e.id] = !0, this.saveVotedOn_();
                        var t = this._constructVoteEntity(e);
                        return C._super.set.call(this, t).then(this.handleSetResponse_.bind(this, t))
                    },
                    undoVote: function(e) {
                        this.votedOn_[e] = !1, this.saveVotedOn_()
                    },
                    handleSetResponse_: function(e, t) {
                        switch ((t = t && Array.isArray(t) && t.length ? t[0] : null).getVoteResponseType()) {
                            case 5:
                            case 6:
                                return Promise.reject(t)
                        }
                        return c.A.getInstance().informVote(e, t), Promise.resolve(t)
                    },
                    saveVotedOn_: (0, i.A)((function() {
                        this.cache_.put("votedOn", this.votedOn_, {
                            ttl: this.getCacheTime_()
                        })
                    }), 500),
                    filterValidEncounters_: function(e, t) {
                        var n = this;
                        return (e || []).filter((function(e) {
                            if (e instanceof f.mBm) return !n.votedOn_[e.getId()];
                            var s = n.getUserId_(e);
                            return t && -1 !== t.indexOf(s) ? (e.setMyVote(1), !0) : (!s || !0 !== n.votedOn_[s]) && (void 0 === e.getMyVote() || 1 === e.getMyVote())
                        }))
                    },
                    getUserId_: function(e) {
                        return e instanceof f.q05 ? e.getUser().getUserId() : null
                    },
                    substituteUsers_: function(e, t) {
                        var n = this;
                        if (!t || 0 === t.length) return e;
                        var s = t.reduce((function(e, t) {
                                var n = t.getType(),
                                    s = t.getDisplayStrategy(),
                                    r = t.getId();
                                return (4 === n || 5 === n) && 4 === s && (e[r] = t), e
                            }), {}),
                            r = [];
                        return e.forEach((function(e) {
                            if (e instanceof f.q05)
                                if (3 !== e.getUser().getType()) r.push(e);
                                else {
                                    var t = s[n.getUserId_(e)];
                                    t && r.push(t)
                                }
                        })), r
                    },
                    markUserAsVoted: function(e) {
                        this.votedOn_[e] = !0, this.saveVotedOn_()
                    },
                    cacheResponse_: function(e, t, n, s) {
                        var r = this;
                        if (!s) return n;
                        p = n;
                        var i = n.map((function(e) {
                            return (e = e.toJSON()).has_user_voted = !1, e
                        }));
                        return (0, o.A)((function() {
                            r.cache_.put(e, i, {
                                ttl: t,
                                noCommit: !r.commitCache
                            })
                        })), i
                    },
                    onCacheInvalidated_: function(e) {
                        I = "", this.votedOn_ = {}, p = null, v = null, this.trigger(C.EVENTS.INVALIDATED, e)
                    },
                    getRequest_: function(e, t, n, s) {
                        var i = this,
                            o = new r.Ay(e, n);
                        return o.on(486, this.handleFloatingButtonConfig_, this), t.forEach((function(e) {
                            o.on(e, s, i)
                        })), o.request(), o
                    },
                    handleFloatingButtonConfig_: function(e, t) {
                        var n = !e && 3 === t.getType();
                        this.cache_.put(y, n, {
                            ttl: this.getCacheTime_()
                        })
                    },
                    getCacheKey_: function(e, t) {
                        return "" + (e + (t.getRequestedPersonIds() || []).join(","))
                    },
                    getVersion_: function() {
                        return 7
                    },
                    reset: function() {
                        p = null, I = ""
                    },
                    decreaseYesVoteQuota: function() {
                        var e = v && v.getQuota();
                        if (e) {
                            var t = e.getYesVotesQuota();
                            t > 0 && (e.setYesVotesQuota(Math.max(t - 1, 0)), 0 === e.getYesVotesQuota() && this.invalidateAll())
                        }
                    }
                }, "Encounters");
            C.getInstance = function() {
                return s || (s = new C)
            }, t.A = C, (0, _.A)({
                clearEncountersCache: function() {
                    C.getInstance().invalidateAll()
                }
            })
        }
    }
]);
//# sourceMappingURL=8651.d418f72a12fe31527b93.js.map
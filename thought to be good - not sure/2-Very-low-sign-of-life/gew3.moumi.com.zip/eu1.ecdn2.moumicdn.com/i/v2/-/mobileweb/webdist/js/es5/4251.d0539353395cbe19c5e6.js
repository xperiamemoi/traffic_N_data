"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [4251], {
        15419: function(t, e, n) {
            n.d(e, {
                gW: function() {
                    return p
                },
                un: function() {
                    return d
                },
                cI: function() {
                    return h
                }
            });
            n(52675), n(45700), n(28706), n(2008), n(50113), n(48980), n(51629), n(74423), n(62062), n(26910), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(21699), n(98992), n(54520), n(72577), n(3949), n(81454), n(23500);
            var r, o, i = n(78064),
                a = [4, 33],
                s = ((r = {})[4] = {
                    type: i.n7.ALL_MESSAGES,
                    context: 244,
                    isDefault: !0
                }, r[33] = {
                    type: i.n7.ACTIVITY,
                    route: "notifications",
                    context: 237,
                    isDefault: !1
                }, r),
                c = ((o = {})[i.n7.ALL_MESSAGES] = [{
                    id: 1,
                    type: 2,
                    variant: i.ku.RECENT
                }, {
                    id: 2,
                    type: 4,
                    variant: i.ku.UNREAD
                }, {
                    id: 7,
                    type: 1,
                    variant: i.ku.CHAT_REQUEST
                }, {
                    id: 3,
                    type: 6,
                    variant: i.ku.ONLINE
                }, {
                    id: 4,
                    type: 3,
                    variant: i.ku.MY_FAVOURITES
                }], o[i.n7.ACTIVITY] = [{
                    id: 1,
                    type: 2,
                    variant: i.ku.RECENT
                }, {
                    id: 8,
                    type: 4,
                    variant: i.ku.UNREAD
                }, {
                    id: 2,
                    type: 1,
                    variant: i.ku.MATCH
                }, {
                    id: 3,
                    type: 1,
                    variant: i.ku.VISIT
                }, {
                    id: 4,
                    type: 1,
                    variant: i.ku.FAVOURITED_YOU
                }, {
                    id: 6,
                    type: 3,
                    variant: i.ku.MY_FAVOURITES
                }], o);

            function u(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function l(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? u(Object(n), !0).forEach((function(e) {
                        f(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function f(t, e, n) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != typeof t || !t) return t;
                        var n = t[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(t, e || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == typeof e ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }

            function p(t, e) {
                var n, r = ((null == t || null == (n = t.combined_connections_settings) ? void 0 : n.sections) || []).filter((function(t) {
                        return a.includes(t.section_type)
                    })).map((function(t) {
                        var e = t.section_type,
                            n = s[e],
                            r = n.type,
                            o = t.sort_options.map((function(t) {
                                var e, n = t.id,
                                    o = t.type,
                                    i = null == (e = c[r].find((function(t) {
                                        return t.id === n && t.type === o
                                    }))) ? void 0 : e.variant,
                                    a = t.is_default;
                                return {
                                    id: n,
                                    name: t.name,
                                    type: o,
                                    variant: i,
                                    isDefault: a,
                                    isCurrent: a
                                }
                            })),
                            i = n.isDefault;
                        return {
                            type: r,
                            route: n.route,
                            connectionTypes: t.connection_types,
                            sortOptions: o,
                            context: n.context,
                            isDefault: i,
                            isCurrent: i
                        }
                    })),
                    o = r.findIndex((function(t) {
                        return t.route === e
                    }));
                return -1 !== o && (r = r.map((function(t, e) {
                    return l(l({}, t), {}, {
                        isCurrent: e === o
                    })
                }))), r
            }

            function d(t) {
                var e = [],
                    n = [];
                t.forEach((function(t) {
                    var r;
                    129 === (r = t.object).promo_block_type && 1 === r.promo_block_position && 2 === r.stats_variation_id ? e.push(t) : n.push(t)
                }));
                var r = function(t) {
                    var e = [];
                    if (t.forEach((function(t) {
                            t.object.sort_timestamp && e.push(t.object.sort_timestamp)
                        })), e.length) {
                        var n = Math.max.apply(null, e);
                        return t.find((function(t) {
                            return t.object.sort_timestamp === n
                        }))
                    }
                    return
                }(e);
                return r && n.unshift(r), n
            }

            function h(t, e) {
                var n = [],
                    r = [];
                switch (e) {
                    case i.ku.UNREAD:
                        t.forEach((function(t) {
                            t.object.is_unread ? n.push(t) : r.push(t)
                        }));
                        break;
                    case i.ku.CHAT_REQUEST:
                        t.forEach((function(t) {
                            4 === t.object.connection_status_indicator ? n.push(t) : r.push(t)
                        }));
                        break;
                    case i.ku.ONLINE:
                        t.forEach((function(t) {
                            1 === t.object.online_status ? n.push(t) : r.push(t)
                        }));
                        break;
                    case i.ku.MY_FAVOURITES:
                        t.forEach((function(t) {
                            t.object.is_favourite ? n.push(t) : r.push(t)
                        }));
                        break;
                    case i.ku.FAVOURITED_YOU:
                        t.forEach((function(t) {
                            t.object.favourited_you ? n.push(t) : r.push(t)
                        }));
                        break;
                    case i.ku.MATCH:
                        t.forEach((function(t) {
                            t.object.is_match ? n.push(t) : r.push(t)
                        }));
                        break;
                    case i.ku.VISIT:
                        t.forEach((function(t) {
                            t.object.is_visitor ? n.push(t) : r.push(t)
                        }));
                        break;
                    case i.ku.RECENT:
                    default:
                        return t.sort((function(t, e) {
                            return e.object.sort_timestamp - t.object.sort_timestamp
                        }))
                }
                return [].concat(n, r)
            }
        },
        20816: function(t, e, n) {
            n(51629), n(25276), n(23792), n(79432), n(10287), n(26099), n(3362), n(98992), n(3949), n(23500), n(62953);
            var r = n(58544),
                o = n(73090),
                i = n(27378),
                a = n(75248),
                s = n(31709),
                c = n(84230);

            function u(t, e) {
                return u = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                    return t.__proto__ = e, t
                }, u(t, e)
            }
            var l = [8, 0, 6, 4, 53, 54],
                f = function(t) {
                    function e() {
                        var e;
                        return (e = t.call(this) || this).EVENTS = {
                            CHANGE: 1,
                            UPDATE: 2,
                            INVALIDATED: "invalidated"
                        }, e.cache = void 0, e.trackNextRequest = !1, e.cache = c.A.getInstance("BadgeCounters"), e.cache.on(c.A.EVENTS.INVALIDATED, (function(t) {
                            e.trigger(e.EVENTS.INVALIDATED, t)
                        })), a.A.getInstance().on(a.A.Type.PERSON_NOTICE, (function(t) {
                            e.cacheResponse(t)
                        })).on(a.A.Type.CHAT_MESSAGE, (function() {
                            e.invalidateAll()
                        })), e
                    }
                    var n, r;
                    r = t, (n = e).prototype = Object.create(r.prototype), n.prototype.constructor = n, u(n, r);
                    var f = e.prototype;
                    return f.getCached = function() {
                        var t = this,
                            e = this.cache.getKeys() || [],
                            n = {},
                            r = [];
                        return e.length > 0 && e.forEach((function(e) {
                            var o = t.cache.get(e);
                            o && "badoo.bma.PersonNotice" === o.$gpb && void 0 !== o.folder && (n[o.folder] = o.int_value, r.push(o))
                        })), {
                            values: n,
                            notices: r
                        }
                    }, f.get = function() {
                        var t = this.getCached();
                        return 0 === Object.keys(t.values).length ? this.fetch() : Promise.resolve(t)
                    }, f.fetch = function() {
                        var t = this;
                        return o.A.isLoggedIn() ? new Promise((function(e) {
                            var n = new s.Ay(157, {
                                folder_id: l,
                                person_notice_type: [1]
                            }).onResponse(138, t.cacheResponse, t).onSpecialEvent(s.SE.REQ_FINISHED, (function() {
                                e(t.getCached())
                            }));
                            t.trackNextRequest && (i.A.trackRPC(n), t.trackNextRequest = !1), n.request()
                        })) : Promise.resolve(void 0)
                    }, f.trackNext = function() {
                        return this.trackNextRequest = !0, this
                    }, f.invalidateAll = function() {
                        this.cache.invalidateAll()
                    }, f.cacheResponse = function(t) {
                        if (void 0 !== t.folder && -1 !== l.indexOf(t.folder) && (1 === t.type || 3 === t.type || 5 === t.type)) {
                            var e = function(t) {
                                    var e = void 0 !== t.folder ? t.folder : "-";
                                    return "" + (t.type || "-") + e
                                }(t),
                                n = this.cache.get(e);
                            this.trigger(this.EVENTS.UPDATE, t, n), this.cache.put(e, t, {
                                ttl: 36e5
                            });
                            var r = t.int_value || 0,
                                o = (null == n ? void 0 : n.int_value) || 0;
                            if (!n || r !== o) {
                                var i = n ? r - o : r;
                                this.trigger(this.EVENTS.CHANGE, t, i)
                            }
                        }
                    }, e
                }(r.sV);
            e.A = new f
        },
        26035: function(t, e, n) {
            n.d(e, {
                A: function() {
                    return l
                }
            });
            var r = n(99417),
                o = n(20679),
                i = n(1237),
                a = 2e3,
                s = "/offline-page-worker.js",
                c = i.D.OFFLINE_PAGE,
                u = !0;

            function l(t, e) {
                var n;
                if (u && null != (n = r.A.performance) && n.timing) {
                    u = !1;
                    var i = o.A.getRequest(t, e);
                    i.setStart(r.A.performance.timing.navigationStart), setTimeout((function() {
                        i.end()
                    }), 0), setTimeout((function() {
                        "serviceWorker" in r.A.navigator && r.A.navigator.serviceWorker.register(s, {
                            scope: c
                        })
                    }), a)
                }
            }
        },
        33014: function(t, e, n) {
            var r = n(74848);
            e.A = function(t) {
                var e = t.children,
                    n = t.tag,
                    o = void 0 === n ? "div" : n;
                return (0, r.jsx)(o, {
                    className: "column-box__content",
                    children: e
                })
            }
        },
        37225: function(t, e, n) {
            n(25276), n(60739), n(26099), n(3362);
            var r, o, i = n(85208),
                a = n(58544),
                s = n(58385),
                c = n(5586),
                u = n(78029),
                l = n(72537),
                f = n(26935),
                p = n(41025),
                d = n(18084),
                h = n(49683),
                m = n(74389),
                g = n(63620),
                v = d.A.getLogger("ServerActionHelper"),
                y = [4, 9, 6],
                _ = ((r = {})[10] = m.x.ENCOUNTERS, r[11] = m.x.PEOPLE_NEARBY, r),
                b = {
                    handleAction: function(t) {
                        var e = t.getAction() || 0,
                            n = t.getProductType();
                        if (e in _) return s.A.navigate(_[e]), Promise.resolve();
                        switch (4 !== e || x(n) || (e = 9, 1 === n && (e = 6)), e) {
                            case 0:
                                return Promise.resolve();
                            case 2:
                            case 69:
                                return this.handlePhotoUpload(t);
                            case 4:
                                return this.handlePaymentRequired(t);
                            case 6:
                                return this.handleSuperPowers(t);
                            case 9:
                                return this.handleSpendCredits(t);
                            case 16:
                                return this.handleOpenPrivacySettings_(t);
                            case 63:
                                return this.handleRedirectPage(t);
                            case 50:
                                return this.handleShowPromoVideo(t);
                            default:
                                return v.error("Action Type not handled by ServerActionHelper: " + e), Promise.reject(new Error("Action Type not handled by ServerActionHelper: " + e))
                        }
                    },
                    handlePhotoUpload: function(t) {
                        var e = t.getAlbumType(),
                            n = t.getCallback(),
                            r = t.getBack(),
                            o = t.getFeature();
                        return s.A.navigate(m.x.OWN_PROFILE_EDIT, {
                            feature: o,
                            albumType: e,
                            destination: r,
                            callback: n,
                            anchor: g.l.ADD_PHOTOS
                        }), Promise.resolve()
                    },
                    handlePaymentRequired: function(t) {
                        var e = this,
                            n = t.getPopState(),
                            r = t.getProductType(),
                            o = t.getUserId();
                        return r ? new Promise((function(i, a) {
                            h.A.getInstance().fetchProductExplanation(r).then((function(t) {
                                return t.promo
                            })).then((function(c) {
                                if (!c) {
                                    var u = "No PromoBlock in response of ClientProductExplanation";
                                    return v.error(u), void a(new Error(u))
                                }
                                if (2 === (null == c ? void 0 : c.ok_action)) return e.handlePhotoUpload(t);
                                var l = x(r),
                                    f = {
                                        promoBlock: c,
                                        reject: a,
                                        resolve: i,
                                        userId: o
                                    };
                                s.A.navigate(l, n, f)
                            })).catch(a)
                        })) : (v.error("No product type but want to handle PAYMENT_REQUIRED"), Promise.reject(new Error("No product type but want to handle PAYMENT_REQUIRED")))
                    },
                    handleSuperPowers: function(t) {
                        return new Promise((function(e, n) {
                            var r = t.getBack(),
                                o = t.getHotPanelData(),
                                i = t.getPaymentFlowId(),
                                a = t.getPaymentTransitionInFlow(),
                                s = t.getPopState(),
                                c = {
                                    back: r,
                                    productType: 1,
                                    promoBlockType: t.getPromoBlockType(),
                                    hotPanelData: o,
                                    callback: function(t) {
                                        var r = t.success,
                                            o = t.cancelled,
                                            i = t.purchaseFailed;
                                        if (o) e(!1);
                                        else if (!r) {
                                            var a, s = (null == i || null == (a = i.notification) ? void 0 : a.message) || "Unknown error purchasing SuperPowers";
                                            n(new Error("SPP Error: " + s))
                                        }
                                    }
                                },
                                f = {
                                    existingPaymentFlowId: i,
                                    paymentTransitionInFlow: a,
                                    replace: s
                                };
                            p.A.navigateToPayment(c, f), u.Ay.observe(l.A.getObservable(19), (function(t) {
                                t.enabled && e(!0)
                            }), {
                                leading: !1,
                                once: !0
                            })
                        }))
                    },
                    handleSpendCredits: function(t) {
                        var e = t.getBack(),
                            n = t.getCost(),
                            r = t.getHotPanelData(),
                            o = t.getPopState(),
                            i = t.getProductType(),
                            a = t.getPromoBlockType(),
                            s = t.getPurchaseTransactionSetup();
                        return new Promise((function(t, c) {
                            var u = {
                                productType: i,
                                back: e,
                                cost: n,
                                hotPanelData: r,
                                popState: o,
                                promoBlockType: a,
                                purchaseTransactionSetup: s,
                                complete: t,
                                success: t,
                                error: c
                            };
                            f.A.purchase(u)
                        }))
                    },
                    handleOpenPrivacySettings_: function() {
                        return Promise.resolve(s.A.navigate(m.x.SETTINGS_PRIVACY))
                    },
                    handleRedirectPage: function(t) {
                        var e = t.getPopState(),
                            n = t.getRedirectPage(),
                            r = c.A.getRouteFromRedirectPage(n.toJSON());
                        return s.A.navigate(r, !!e, function(t) {
                            var e = {};
                            t.hasActivationPlace() && (e.activationPlace = t.getActivationPlace());
                            return e
                        }(t)), Promise.resolve()
                    },
                    handleShowPromoVideo: function(t) {
                        var e = t.getPromoBlock() || {},
                            n = (null == e.getId ? void 0 : e.getId()) || e.id || "",
                            r = {
                                timer: (null == e.getTimer ? void 0 : e.getTimer()) || e.timer || 0,
                                videoId: n
                            };
                        return s.A.navigate(m.x.EXTERNAL_PROMO_VIDEO, !1, r), Promise.resolve()
                    },
                    isPaymentAction: function(t) {
                        return -1 !== y.indexOf(t)
                    }
                };
            (0, i.A)(b, a.zb), e.A = b;
            var A = ((o = {})[21] = m.x.ATTENTION_BOOST_EXPLANATION, o[22] = m.x.BUNDLE_SALE_EXPLANATION, o[25] = m.x.CRUSH_EXPLANATION, o[6] = m.x.EXTRA_SHOWS_EXPLANATION, o[7] = m.x.RISEUP_EXPLANATION, o);

            function x(t) {
                return A[t]
            }
        },
        41476: function(t, e, n) {
            n.d(e, {
                QY: function() {
                    return l
                },
                vf: function() {
                    return f
                }
            });
            n(28706), n(2008), n(50113), n(48980), n(51629), n(74423), n(62062), n(15086), n(26099), n(21699), n(98992), n(54520), n(72577), n(3949), n(81454), n(37550), n(23500);
            var r = n(13264),
                o = n(18084),
                i = n(15419),
                a = o.A.getLogger("Connections"),
                s = [],
                c = !1,
                u = {
                    getItems: function(t, e, n) {
                        var o = [],
                            a = [];
                        if (t && e && n) {
                            var c = [],
                                u = [],
                                p = [];
                            s.forEach((function(n) {
                                f(n.object) && n.object.context === e ? u.push(n) : l(n.object) && t.includes(n.object.origin_folder) ? c.push(n) : n.object instanceof r.A && p.push(n)
                            })), o = (0, i.un)(u), a = (0, i.cI)(c, n), p.forEach((function(t, e) {
                                var n;
                                e < 1 ? (n = 12, a.splice(n, 0, t)) : a.slice(-10).some((function(t) {
                                    return !l(t.object)
                                })) || (n = 12 + 11 * e, a.splice(n, 0, t))
                            })), a = [].concat(o, a)
                        }
                        return a.length > 0 ? a : s
                    },
                    getUsers: function(t) {
                        return t ? s.filter((function(e) {
                            return l(e.object) && t.includes(e.object.origin_folder)
                        })) : s.filter((function(t) {
                            return l(t.object)
                        }))
                    },
                    getControllers: function() {
                        return s.filter((function(t) {
                            return t.object instanceof r.A
                        }))
                    },
                    initialise: function() {
                        c = !0, s = []
                    },
                    removeItem: function(t) {
                        var e; - 1 !== (e = "number" == typeof t ? t : this.findIndex(t)) && s.splice(e, 1)
                    },
                    findIndex: function(t) {
                        return "string" == typeof t ? s.findIndex((function(e) {
                            return l(e.object) && e.object.user_id === t
                        })) : l(t) ? s.findIndex((function(e) {
                            return l(e.object) && e.object.user_id === t.user_id
                        })) : f(t) || t instanceof r.A ? s.findIndex((function(e) {
                            return e.object === t
                        })) : -1
                    },
                    get: function(t) {
                        return s[t]
                    },
                    replaceItem: function(t, e) {
                        t.key || (t.key = h(t.object)), s[e] = t
                    },
                    removeUpdatedFlags: function() {
                        for (var t = 0; t < s.length; t++) delete s[t].isUpdate
                    },
                    addUpdates: function(t) {
                        var e = this;
                        t.forEach((function(t) {
                            l(t) && e.removeItem(t.user_id)
                        }));
                        var n = t.map((function(t) {
                            return {
                                object: t,
                                key: h(t),
                                isUpdate: !0
                            }
                        }));
                        Array.prototype.unshift.apply(s, n)
                    },
                    addPage: function(t, e) {
                        var n = t.map((function(t) {
                            return {
                                object: t,
                                key: h(t)
                            }
                        }));
                        e && (s = []), Array.prototype.push.apply(s, n)
                    },
                    moveItemToTop: function(t, e) {
                        e && this.removeItem(e), s.unshift(t), this.moveTopMostPromo()
                    },
                    moveTopMostPromo: function() {
                        var t = p();
                        if (t > -1) {
                            var e = s.splice(t, 1)[0];
                            s.unshift(e)
                        }
                    },
                    replaceTopMostPromo: function(t) {
                        var e = p();
                        if (e > -1) {
                            var n = s[e];
                            n.object = t, this.replaceItem(n, e)
                        }
                    },
                    updateUsers: function(t) {
                        var e = this;
                        t.forEach((function(t) {
                            var n = e.findIndex(t),
                                r = e.get(n);
                            r ? (r.object = t, e.replaceItem(r, n)) : a.error("ConnectionsItems - Entry at index " + n + " is undefined.", s.length, t, c)
                        }))
                    },
                    hasTopMostPromo: function() {
                        return -1 !== p()
                    },
                    getTopMostPromo: function() {
                        if (this.hasTopMostPromo()) {
                            var t = p();
                            return this.get(t)
                        }
                        return null
                    },
                    removeTopMostPromo: function() {
                        var t = this.getTopMostPromo();
                        if (t) {
                            var e = t.object || t;
                            this.removeItem(e)
                        }
                    },
                    updateYourMoveBadge: function(t, e) {
                        var n = s.find((function(e) {
                            return l(e.object) && e.object.user_id === t
                        }));
                        n && (n.object.connection_status_indicator = !0 === e ? 2 : 0)
                    }
                };

            function l(t) {
                return !!t && void 0 !== t.user_id
            }

            function f(t) {
                return !!t && void 0 !== t.promo_block_type
            }

            function p() {
                return s.findIndex((function(t) {
                    return f(t.object) && 4 === t.object.promo_block_position
                }))
            }
            e.Ay = u;
            var d = 0;

            function h(t) {
                return l(t) ? "user__" + t.user_id : t instanceof r.A ? "ctrl__" + t.name : "item__" + ++d
            }
        },
        55632: function(t, e, n) {
            var r = n(96540),
                o = n(73510),
                i = n(46942),
                a = n.n(i),
                s = n(20017),
                c = n(74848);
            e.A = function(t) {
                var e = t.styling,
                    n = t.text,
                    i = t.isActive,
                    u = t.isDisabled,
                    l = t.isLoading,
                    f = t.onClick,
                    p = t.dataQA,
                    d = (0, r.useRef)(null),
                    h = (0, r.useState)({}),
                    m = h[0],
                    g = h[1];
                return (0, r.useEffect)((function() {
                    i && d.current && g({
                        width: d.current.offsetWidth,
                        height: d.current.offsetHeight
                    })
                }), [i]), (0, c.jsx)(o.A, { in: i,
                    timeout: 300,
                    mountOnEnter: !0,
                    unmountOnExit: !0,
                    children: function(t) {
                        var o = a()({
                            "floating-action": !0,
                            "is-inactive": "entered" !== t
                        });
                        return (0, c.jsxs)(r.Fragment, {
                            children: [(0, c.jsx)("div", {
                                className: o,
                                ref: d,
                                children: (0, c.jsx)("div", {
                                    className: "floating-action__button",
                                    children: (0, c.jsx)(s.A, {
                                        styling: e,
                                        text: n,
                                        isDisabled: u,
                                        isLoading: l,
                                        onClick: f,
                                        dataQA: p
                                    })
                                })
                            }), (0, c.jsx)("div", {
                                className: "fake",
                                style: m
                            })]
                        })
                    }
                })
            }
        },
        59678: function(t, e, n) {
            n(2008), n(50113), n(51629), n(74423), n(25276), n(62062), n(60739), n(79432), n(26099), n(21699), n(98992), n(54520), n(72577), n(3949), n(81454), n(23500);
            var r = n(23735),
                o = n(99417),
                i = n(23149),
                a = n(42302),
                s = n(40075),
                c = n(5586),
                u = n(58385),
                l = n(35837),
                f = n(15566),
                p = n(74389),
                d = n(88651),
                h = n(3208),
                m = n(41025),
                g = 193,
                v = [113, 112],
                y = l.A.Message;

            function _(t) {
                var e = t.userSubstitute;
                this.id = e.getId(), this.encountersPromoCard = function(t) {
                    var e = x({
                        promos: t.getPromos([]),
                        position: 21,
                        type: b
                    })[0];
                    if (4 === t.getType() && 421 !== e.getPromoBlockType()) return e;
                    return A(e)
                }(e), this.connectionPromoCard = function(t) {
                    var e = x({
                        promos: t.getPromos([]),
                        position: 1,
                        type: g
                    })[0];
                    return A(e)
                }(e), this.contentModePromoCards = function(t) {
                    var e = x({
                        promos: t.getPromos([]),
                        position: 13,
                        type: g
                    });
                    return e.map((function(t) {
                        return A(t)
                    }))
                }(e), this.sponsoredAlert = function(t) {
                    var e = x({
                        promos: t.getPromos([]),
                        position: 22,
                        type: 194
                    })[0];
                    if (!e) return;
                    var n = x({
                        promos: t.getPromos([]),
                        position: 21,
                        type: g
                    })[0];
                    if (!n) return;
                    var r = P({
                        ctas: n.getButtons([]),
                        type: 3
                    });
                    if (r) return {
                        ctaText: r.getText(),
                        hotpanelData: k(e),
                        popup: {
                            header: e.getHeader(),
                            text: e.getMssg(),
                            buttons: e.getButtons([]).map((function(t) {
                                return {
                                    text: t.getText(),
                                    action: t.getAction()
                                }
                            }))
                        }
                    }
                }(e)
            }
            _.prototype = {
                getHeaderData: function() {
                    var t = this.encountersPromoCard;
                    t || (t = this.contentModePromoCards[0]);
                    var e = this.sponsoredAlert,
                        n = t.header,
                        r = {};
                    if (n && (r.header = n, null != e && e.ctaText)) {
                        r.header.subtitle = e.ctaText;
                        var o = e.popup,
                            i = o.buttons[0];
                        r.sponsoredAlert = {
                            hotpanelData: e.hotpanelData,
                            header: o.header,
                            text: o.text,
                            ctaText: i ? i.text : s.Ay.get(451)
                        }
                    }
                    return r
                },
                performPrimaryCta: function(t) {
                    var e = t.promoCard,
                        n = t.context,
                        r = t.replaceNavigation,
                        i = t.callback;
                    ! function(t, e) {
                        var n = (t || {}).action,
                            r = e || {},
                            i = r.callback,
                            s = void 0 === i ? a.A : i,
                            l = r.bannerId;
                        switch (n) {
                            case 63:
                                ! function(t, e) {
                                    if (!t) return;
                                    if (t.getUrl()) return void o.A.open(t.getUrl(), "_blank", "noopener");
                                    var n = c.A.getRouteFromRedirectPage(t.toJSON());
                                    u.A.navigate(n, e.replaceNavigation)
                                }(t.redirectPage, e);
                                break;
                            case 60:
                                s(t);
                                break;
                            case 4:
                                ! function(t) {
                                    h.A.generate(), m.A.navigateToPayment({
                                        back: p.x.LIKED_YOU,
                                        productType: 1,
                                        promoBlockType: 7,
                                        hotPanelData: {
                                            activationPlace: 105,
                                            isOneClickPayment: !1,
                                            bannerId: t
                                        },
                                        callback: function(t) {
                                            t.success && d.A.getInstance().invalidate()
                                        }
                                    })
                                }(l)
                        }
                    }(e.primaryCta, {
                        replaceNavigation: r,
                        callback: i,
                        bannerId: e.promoBlockType
                    }), j({
                        promoCard: e,
                        context: n
                    })
                },
                toJSON: function() {
                    return w(this, (function(t) {
                        return t instanceof y && t.toJSON()
                    }))
                }
            }, _.reportEventShow = function(t) {
                var e = t.promoCard,
                    n = t.context;
                O({
                    promoCard: e,
                    context: n,
                    event: 2
                })
            }, _.reportEventClick = j, _.reportEventSkip = function(t) {
                var e = t.promoCard,
                    n = t.context;
                O({
                    promoCard: e,
                    context: n,
                    event: 8,
                    avoidStatsRequired: !0
                })
            }, _.reportEventDismiss = function(t) {
                var e = t.promoCard,
                    n = t.context;
                O({
                    promoCard: e,
                    context: n,
                    event: 4,
                    avoidStatsRequired: !0
                })
            }, _.fromJSON = function(t) {
                return w(t, (function(t) {
                    return !(!(0, i.A)(t) || "string" != typeof t.$gpb) && (0, l.A)(t)
                }))
            };
            var b = [193, 10, 421];

            function A(t) {
                if (!t) return null;
                var e = t.getButtons([]),
                    n = P({
                        ctas: e,
                        type: 1
                    }),
                    r = n && n.getAction(),
                    o = n && n.getText() || "";
                n = [63, 60, 4].includes(r) ? {
                    action: r,
                    text: o,
                    redirectPage: n.getRedirectPage()
                } : null;
                var i = P({
                        ctas: e,
                        type: 2
                    }),
                    a = null;
                if (i) {
                    var s = i.getIcon();
                    a = {
                        title: i.getText(),
                        logo: s ? s.getDisplayImages() : null,
                        action: i.getAction(),
                        redirectPage: i.getRedirectPage()
                    }
                }
                var c = P({
                        ctas: e,
                        type: 9
                    }),
                    u = P({
                        ctas: e,
                        type: 8
                    }),
                    l = P({
                        ctas: e,
                        type: 14
                    }),
                    f = P({
                        ctas: e,
                        type: 15
                    }),
                    p = t.getId(),
                    d = t.getVariantId(),
                    h = function(t) {
                        var e = t.getPictures([]);
                        return e.length > 0 ? e.map((function(t) {
                            return {
                                url: t.getDisplayImages()
                            }
                        })) : void 0
                    }(t);
                return {
                    key: p + "-" + d,
                    id: p,
                    variantId: d,
                    hotpanelData: k(t),
                    promoBlockType: t.getPromoBlockType(),
                    promoBlockPosition: t.getPromoBlockPosition(),
                    statsRequired: t.getStatsRequired(),
                    header: a,
                    title: t.getHeader(),
                    text: t.getMssg(),
                    photo: t.getImageId([])[0],
                    avatars: h,
                    primaryCta: n,
                    showOnTap: f && v.includes(f.getAction()),
                    swipeLeft: c ? {
                        action: c.getAction()
                    } : null,
                    swipeRight: u ? {
                        action: u.getAction()
                    } : null,
                    swipeUp: l ? {
                        text: l.getText(),
                        action: l.getAction()
                    } : null
                }
            }

            function x(t) {
                var e = t.promos,
                    n = t.position,
                    r = t.type,
                    o = Array.isArray(r) ? r : [r];
                return e.filter((function(t) {
                    var e = t.getPromoBlockPosition(),
                        r = t.getPromoBlockType();
                    return e === n && o.includes(r)
                }))
            }

            function P(t) {
                var e = t.ctas,
                    n = t.type;
                return e.find((function(t) {
                    return t.getType() === n
                }))
            }

            function j(t) {
                O({
                    promoCard: t.promoCard,
                    context: t.context,
                    event: 1
                })
            }

            function O(t) {
                var e = t.promoCard,
                    n = t.context,
                    o = t.event,
                    i = t.avoidStatsRequired;
                if (e.statsRequired) {
                    if (!i) {
                        var a = e.statsRequired.indexOf(o);
                        if (-1 === a) return;
                        e.statsRequired.splice(a, 1)
                    }
                    var s = (new f.BEm).setEvent(o).setContext(n);
                    e.promoBlockType && s.setPromoBlockType(e.promoBlockType), e.promoBlockPosition && s.setPromoBlockPosition(e.promoBlockPosition), e.id && s.setPromoId(e.id), e.variantId && s.setVariantId(e.variantId),
                        function(t) {
                            new r.Ay(278, (new f.YDi).setPromoBannerStats(t)).request()
                        }(s)
                }
            }

            function k(t) {
                var e = {
                    banner_id: t.getPromoBlockType()
                };
                return t.hasPromoBlockPosition() && (e.position_id = t.getPromoBlockPosition()), t.hasStatsVariationId() && (e.variation_id = t.getStatsVariationId()), e
            }

            function w(t, e) {
                var n = e(t);
                return !1 !== n ? n : t && Array.isArray(t) ? function(t, e) {
                    var n = t.length,
                        r = [],
                        o = -1;
                    for (; ++o < n;) r[o] = w(t[o], e);
                    return r
                }(t, e) : (0, i.A)(t) ? function(t, e) {
                    var n = {};
                    return Object.keys(t).forEach((function(r) {
                        n[r] = w(t[r], e)
                    })), n
                }(t, e) : t
            }
            e.A = _
        },
        60090: function(t, e, n) {
            n.d(e, {
                A: function() {
                    return L
                }
            });
            n(52675), n(89463), n(45700), n(28706), n(2008), n(50113), n(48980), n(51629), n(74423), n(62062), n(15086), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(21699), n(98992), n(54520), n(72577), n(3949), n(81454), n(37550), n(23500);
            var r = n(96540),
                o = n(73090),
                i = n(58385),
                a = n(31709),
                s = n(65736),
                c = n(19543),
                u = n(74848),
                l = function(t) {
                    var e = t.slides,
                        n = t.pagination,
                        o = t.onSlideChange,
                        i = t.onDismissModal,
                        a = (0, r.useRef)(null);
                    return (0, c.A)(a, o, {
                        activeIndex: Math.max(0, Math.min(n.index, n.max - 1))
                    }), (0, u.jsx)(s.A, {
                        onDismiss: i,
                        hasDefaultDismissButton: !1,
                        children: (0, u.jsx)("div", {
                            className: "walkthrough-carousel",
                            "data-qa": "fsw-carousel",
                            children: (0, u.jsx)("div", {
                                className: "walkthrough-carousel__slides sticky-scroll_",
                                ref: a,
                                children: e.map((function(t, e) {
                                    return (0, u.jsx)("div", {
                                        className: "carousel-page",
                                        children: e === n.index ? t : null
                                    }, "carousel-page-" + e)
                                }))
                            })
                        })
                    })
                },
                f = n(20017),
                p = n(8323),
                d = n(93827),
                h = n(29639),
                m = n(31751),
                g = n(4571),
                v = n(30784),
                y = n(40578),
                _ = n(27895),
                b = n(46770),
                A = n(96506),
                x = n(51634),
                P = n(23350),
                j = n(40075),
                O = function(t) {
                    var e = t.heading,
                        n = t.subHeading,
                        r = t.imageUrl,
                        o = t.content,
                        i = t.buttons,
                        a = t.pagination,
                        s = t.footer;
                    return (0, u.jsx)("div", {
                        className: "sw-modal",
                        children: (0, u.jsxs)(g.A, {
                            isCompact: !0,
                            align: "start",
                            children: [(0, u.jsx)(_.A, {
                                children: r ? (0, u.jsx)("img", {
                                    className: "sw-modal__image-elem",
                                    src: r,
                                    alt: ""
                                }) : (0, u.jsx)("div", {
                                    className: "sw-modal__image-loading",
                                    "data-qa": "fsw-image-loading",
                                    children: (0, u.jsx)(P.Ay, {})
                                })
                            }), (0, u.jsx)(y.A, {
                                text: e,
                                tag: "h2"
                            }), n ? (0, u.jsx)(v.A, {
                                text: n
                            }) : null, o ? (0, u.jsx)(x.A, {
                                children: o
                            }) : null, i ? (0, u.jsx)(b.A, {
                                children: i
                            }) : null, s ? (0, u.jsx)(A.A, {
                                children: (0, u.jsxs)(d.P3, {
                                    color: "gray-80",
                                    children: [(0, u.jsx)("span", {
                                        className: "sw-modal__footer-emoji",
                                        children: (0, u.jsx)(m.A, {
                                            text: s.emoji,
                                            size: "16px"
                                        })
                                    }), " ", s.text]
                                })
                            }) : null, a ? (0, u.jsx)("div", {
                                className: "sw-modal__pagination",
                                children: (0, u.jsx)(h.A, {
                                    content: (0, u.jsxs)(d.P3, {
                                        align: "center",
                                        color: "gray-80",
                                        ellipsis: !0,
                                        children: [a.hasIntroPage ? a.index : a.index + 1, "/", a.max]
                                    }),
                                    prev: {
                                        onClick: a.onPrev,
                                        isHidden: a.hasIntroPage ? 1 === a.index : 0 === a.index,
                                        a11y: {
                                            label: j.Ay.get(1081)
                                        }
                                    },
                                    next: {
                                        onClick: a.onNext,
                                        a11y: {
                                            label: j.Ay.get(1080)
                                        }
                                    }
                                })
                            }) : null]
                        })
                    })
                },
                k = function(t) {
                    var e = t.heading,
                        n = t.subHeading,
                        r = t.ctaText,
                        o = t.dismissText,
                        i = t.onNext,
                        a = t.onDismiss,
                        s = t.imageUrl;
                    return (0, u.jsx)(O, {
                        heading: e,
                        subHeading: n,
                        imageUrl: s,
                        buttons: (0, u.jsxs)(p.A, {
                            children: [(0, u.jsx)(f.A, {
                                size: "medium",
                                tag: "button",
                                text: r,
                                onClick: i
                            }), (0, u.jsx)(f.A, {
                                size: "medium",
                                tag: "button",
                                text: o,
                                semantic: "tertiary",
                                onClick: a
                            })]
                        })
                    })
                },
                w = n(17380),
                E = n(45141),
                T = function(t) {
                    var e = t.heading,
                        n = t.imageUrl,
                        o = t.options,
                        i = t.footer,
                        a = t.pagination,
                        s = t.selectedOptions,
                        c = t.onOptionChange,
                        l = t.type,
                        f = t.onClose;
                    return (0, r.useEffect)((function() {
                        return function() {
                            f && f()
                        }
                    }), [f]), (0, u.jsx)(O, {
                        heading: e,
                        imageUrl: n,
                        footer: i,
                        pagination: a,
                        content: (0, u.jsx)(p.A, {
                            spacing: "compact",
                            children: o.map((function(t, e) {
                                return (0, u.jsx)(E.A, {
                                    extra: (0, u.jsx)(w.A, {
                                        type: l,
                                        isChecked: s.includes(t.key),
                                        onChange: function() {
                                            c(t.key)
                                        }
                                    }),
                                    tag: "label",
                                    title: t.text
                                }, e)
                            }))
                        })
                    })
                },
                S = n(74389),
                C = n(93529),
                N = n(64928),
                I = n(18084),
                D = n(79860);

            function R(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function U(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? R(Object(n), !0).forEach((function(e) {
                        M(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : R(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function M(t, e, n) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != typeof t || !t) return t;
                        var n = t[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(t, e || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == typeof e ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }
            var B = I.A.getLogger("SecurityWalkthroughContainer"),
                V = [1, 2, 3, 4, 5, 8],
                F = function(t) {
                    B.error("Error while calling server on Security walkthrough: ", t), C.A.showNotification({
                        type: C.A.TYPES.ERROR
                    })
                },
                q = function(t) {
                    new a.Ay(36, U({
                        context: 154
                    }, t)).onError(F).request()
                },
                H = function(t) {
                    new a.Ay(278, {
                        security_walkthrough_stats: {
                            event: 2,
                            security_walkthrough_page: t
                        }
                    }).request()
                },
                L = function(t) {
                    var e = t.onDismissModal,
                        n = t.context,
                        s = o.A.getUser().name,
                        c = (0, r.useState)(),
                        f = c[0],
                        p = c[1],
                        d = (0, r.useState)(),
                        h = d[0],
                        m = d[1],
                        g = (0, r.useState)(0),
                        v = g[0],
                        y = g[1],
                        _ = (0, r.useState)(),
                        b = _[0],
                        A = _[1],
                        x = (0, r.useState)(0),
                        O = x[0],
                        w = x[1],
                        E = (0, r.useState)(!1),
                        C = E[0],
                        I = E[1],
                        R = (0, r.useState)(),
                        M = R[0],
                        L = R[1],
                        Y = (0, r.useState)(!1),
                        Q = Y[0],
                        X = Y[1],
                        G = (0, r.useState)(!1),
                        W = G[0],
                        z = G[1],
                        J = (0, r.useState)([]),
                        Z = J[0],
                        K = J[1],
                        $ = (0, r.useState)(!0),
                        tt = $[0],
                        et = $[1],
                        nt = (0, r.useState)(!1),
                        rt = nt[0],
                        ot = nt[1],
                        it = function(t, n) {
                            var r, o = n.pagination,
                                c = n.images,
                                l = null == c || null == (r = c.find((function(e) {
                                    return e.page === t.type
                                }))) ? void 0 : r.url;
                            switch (t.type) {
                                case 1:
                                    return (0, u.jsx)(k, {
                                        heading: j.Ay.get(223, {
                                            str: s
                                        }),
                                        subHeading: j.Ay.get(224),
                                        ctaText: j.Ay.get(222),
                                        dismissText: j.Ay.get(221),
                                        onNext: function() {
                                            (0, D.sx)(332, {
                                                element: 104,
                                                parent_element: 1394
                                            }), o.onNext()
                                        },
                                        onDismiss: function() {
                                            (0, D.sx)(332, {
                                                element: 725,
                                                parent_element: 1394
                                            }), new a.Ay(278, {
                                                security_walkthrough_stats: {
                                                    event: 8,
                                                    security_walkthrough_page: 3
                                                }
                                            }).request(), e()
                                        },
                                        imageUrl: l
                                    });
                                case 2:
                                    var f = {
                                            key: 1,
                                            text: j.Ay.get(225)
                                        },
                                        p = {
                                            key: 2,
                                            text: j.Ay.get(226)
                                        };
                                    return (0, u.jsx)(T, {
                                        onOptionChange: function() {
                                            (0, D.sx)(332, {
                                                element: Q ? 404 : 5,
                                                parent_element: 1395
                                            }), X((function(t) {
                                                return !t
                                            }))
                                        },
                                        pagination: U(U({}, o), {}, {
                                            onNext: function() {
                                                (0, D.sx)(332, {
                                                    element: 282,
                                                    parent_element: 1395
                                                }), o.onNext()
                                            },
                                            onPrev: function() {
                                                (0, D.sx)(332, {
                                                    element: 1147,
                                                    parent_element: 1395
                                                }), o.onPrev()
                                            }
                                        }),
                                        type: "radio",
                                        heading: j.Ay.get(227),
                                        options: [f, p],
                                        selectedOptions: [Q ? p.key : f.key],
                                        imageUrl: l,
                                        footer: {
                                            emoji: "🤔",
                                            text: j.Ay.get(228)
                                        },
                                        onClose: function() {
                                            Q !== (null == M ? void 0 : M.messagesFromLiked) && q({
                                                privacy_show_only_to_people_i_like_or_visit: Q
                                            }), ot(!1 === Q)
                                        }
                                    });
                                case 3:
                                    var d = {
                                            key: 1,
                                            text: j.Ay.get(234)
                                        },
                                        h = {
                                            key: 2,
                                            text: j.Ay.get(235)
                                        };
                                    return (0, u.jsx)(T, {
                                        onOptionChange: function() {
                                            (0, D.sx)(332, {
                                                element: W ? 404 : 1101,
                                                parent_element: 1396
                                            }), z((function(t) {
                                                return !t
                                            }))
                                        },
                                        pagination: U(U({}, o), {}, {
                                            onNext: function() {
                                                (0, D.sx)(332, {
                                                    element: 282,
                                                    parent_element: 1396
                                                }), o.onNext()
                                            },
                                            onPrev: function() {
                                                (0, D.sx)(332, {
                                                    element: 1147,
                                                    parent_element: 1396
                                                }), o.onPrev()
                                            }
                                        }),
                                        type: "radio",
                                        heading: j.Ay.get(236),
                                        options: [d, h],
                                        selectedOptions: [W ? h.key : d.key],
                                        imageUrl: l,
                                        footer: {
                                            emoji: "🙂",
                                            text: j.Ay.get(237)
                                        },
                                        onClose: function() {
                                            W !== (null == M ? void 0 : M.messagesFromVerified) && q({
                                                verification_only_verified_messages: W
                                            })
                                        }
                                    });
                                case 4:
                                    var m = t.notification_settings ? t.notification_settings.map((function(t) {
                                            return t.description ? {
                                                key: t.stats_id,
                                                text: t.description
                                            } : void 0
                                        })).filter((function(t) {
                                            return !!t
                                        })) : [],
                                        g = C && t.notification_settings ? t.notification_settings.map((function(t) {
                                            return t.stats_id
                                        })).filter((function(t) {
                                            return !!t
                                        })) : [];
                                    return (0, u.jsx)(T, {
                                        onOptionChange: function(t) {
                                            C ? (K(g.filter((function(e) {
                                                return e !== t
                                            }))), I(!1)) : Z.includes(t) ? K(Z.filter((function(e) {
                                                return e !== t
                                            }))) : K([].concat(Z, [t])), (0, D.sx)(332, {
                                                element: t,
                                                parent_element: 1397
                                            })
                                        },
                                        pagination: U(U({}, o), {}, {
                                            onNext: function() {
                                                (0, D.sx)(332, {
                                                    element: 282,
                                                    parent_element: 1397
                                                }), o.onNext()
                                            },
                                            onPrev: function() {
                                                (0, D.sx)(332, {
                                                    element: 1147,
                                                    parent_element: 1397
                                                }), o.onPrev()
                                            }
                                        }),
                                        type: "checkbox",
                                        heading: j.Ay.get(229),
                                        options: m,
                                        selectedOptions: C ? g : Z,
                                        imageUrl: l,
                                        onClose: function() {
                                            t.notification_settings ? Z !== (null == M ? void 0 : M.notificationSelected) ? q({
                                                notification_settings: t.notification_settings.map((function(t) {
                                                    var e = t.stats_id;
                                                    return e ? Z.includes(e) ? t : U(U({}, t), {}, {
                                                        send_cloud_push: !1,
                                                        send_email: !1,
                                                        send_inapp: !1
                                                    }) : null
                                                })).filter((function(t) {
                                                    return !!t
                                                }))
                                            }) : C && q({
                                                notification_settings: t.notification_settings
                                            }) : B.error("No notifications supplied from server")
                                        }
                                    });
                                case 5:
                                    var v = {
                                            key: 1,
                                            text: j.Ay.get(230)
                                        },
                                        y = {
                                            key: 2,
                                            text: j.Ay.get(231)
                                        };
                                    return (0, u.jsx)(T, {
                                        onOptionChange: function() {
                                            (0, D.sx)(332, {
                                                element: tt ? 1040 : 1039,
                                                parent_element: 1398
                                            }), et((function(t) {
                                                return !t
                                            }))
                                        },
                                        pagination: U(U({}, o), {}, {
                                            onNext: function() {
                                                (0, D.sx)(332, {
                                                    element: 282,
                                                    parent_element: 1398
                                                }), o.onNext()
                                            },
                                            onPrev: function() {
                                                (0, D.sx)(332, {
                                                    element: 1147,
                                                    parent_element: 1398
                                                }), o.onPrev()
                                            }
                                        }),
                                        type: "radio",
                                        heading: j.Ay.get(232),
                                        options: [y, v],
                                        selectedOptions: [tt ? y.key : v.key],
                                        imageUrl: l,
                                        footer: {
                                            emoji: "😭",
                                            text: j.Ay.get(233)
                                        },
                                        onClose: function() {
                                            tt !== (null == M ? void 0 : M.onlineStatus) && q({
                                                privacy_show_online_status: tt
                                            })
                                        }
                                    });
                                case 8:
                                    return (0, u.jsx)(k, {
                                        heading: j.Ay.get(219),
                                        subHeading: j.Ay.get(220),
                                        ctaText: j.Ay.get(217),
                                        dismissText: j.Ay.get(218),
                                        onNext: function() {
                                            (0, D.sx)(332, {
                                                element: 104,
                                                parent_element: 1400
                                            }), i.A.navigate(S.x.ENCOUNTERS)
                                        },
                                        onDismiss: function() {
                                            (0, D.sx)(332, {
                                                element: 66,
                                                parent_element: 1400
                                            }), i.A.navigate(S.x.SETTINGS)
                                        },
                                        imageUrl: l
                                    });
                                default:
                                    return B.error("Unsupported page type in security walkthrough ", t.type), null
                            }
                        },
                        at = function(t) {
                            var e, r = (null == (e = t.pages) ? void 0 : e.findIndex((function(e) {
                                var n;
                                return e.type === (null == (n = t.default_page) ? void 0 : n.type)
                            }))) || 0;
                            1 === n && (r = r > 0 ? r : 1), p(t.pages || []), w(r > -1 ? r : 0)
                        };
                    (0, r.useEffect)((function() {
                        new a.Ay(623, {
                            context: n
                        }).onResponse(624, at).onError(F).request()
                    }), []);
                    var st = function(t) {
                        var e, n = null == (e = t.resources) ? void 0 : e.find((function(t) {
                            return 35 === t.resource_type
                        }));
                        null != n && n.payload && A(n.payload.security_walkthrough_images)
                    };
                    (0, r.useEffect)((function() {
                        new a.Ay(667, {
                            requests: [{
                                resource_type: 35,
                                reference: {
                                    context: 154
                                }
                            }]
                        }).onResponse(668, st).onError(F).request()
                    }), []), (0, r.useEffect)((function() {
                        N.A.getInstance().get().then((function(t) {
                            var e = Boolean(t.privacy_show_only_to_people_i_like_or_visit),
                                n = Boolean(t.verification_only_verified_messages),
                                r = Boolean(t.privacy_show_online_status);
                            X(e), z(n);
                            var o = t.notification_settings || [];
                            K(o.map((function(t) {
                                return t.send_email && t.send_cloud_push && t.send_inapp ? t.stats_id : null
                            })).filter((function(t) {
                                return !!t
                            }))), et(r), ot(!1 === t.privacy_show_only_to_people_i_like_or_visit), L({
                                messagesFromLiked: e,
                                messagesFromVerified: n,
                                notificationSelected: o,
                                onlineStatus: r
                            }), t.notification_settings || I(!0)
                        })).catch(F)
                    }), []), (0, r.useEffect)((function() {
                        if (f && M) {
                            var t = function(t, e) {
                                return e ? e.filter((function(e) {
                                    return !(null == e || !e.type) && (3 === e.type ? t : !!V.includes(e.type) || (B.error("Unsupported page type in security walkthrough ", e.type), !1))
                                })) : []
                            }(rt, f);
                            m(t);
                            var e = null == t ? void 0 : t.some((function(t) {
                                    return 1 === t.type
                                })),
                                n = 0;
                            t.length - 2 > 0 && (n = e ? t.length - 2 : t.length - 1), y(n)
                        }
                    }), [f, M, rt]), (0, r.useEffect)((function() {
                        var t = h ? h[O] : null;
                        if (t) switch (t.type) {
                            case 1:
                                return (0, D.sx)(258, {
                                    element: 1394
                                }), void H(1);
                            case 2:
                                return (0, D.sx)(258, {
                                    element: 1395
                                }), void H(2);
                            case 3:
                                return (0, D.sx)(258, {
                                    element: 1396
                                }), void H(3);
                            case 4:
                                return (0, D.sx)(258, {
                                    element: 1397
                                }), void H(4);
                            case 5:
                                return (0, D.sx)(258, {
                                    element: 1398
                                }), void H(5);
                            case 8:
                                return void(0, D.sx)(258, {
                                    element: 1400
                                });
                            default:
                                return
                        }
                    }), [O, h]);
                    var ct = null == h ? void 0 : h.some((function(t) {
                        return 1 === t.type
                    }));
                    return (0, u.jsx)(r.Fragment, {
                        children: h ? (0, u.jsx)(l, {
                            onDismissModal: e,
                            onSlideChange: function(t) {
                                w(t)
                            },
                            pagination: {
                                index: O,
                                max: v
                            },
                            slides: h.map((function(t, e) {
                                return it(t, {
                                    pagination: {
                                        index: e,
                                        max: v,
                                        hasIntroPage: ct,
                                        onNext: function() {
                                            w((function(t) {
                                                return t + 1
                                            }))
                                        },
                                        onPrev: function() {
                                            w((function(t) {
                                                return t - 1
                                            }))
                                        }
                                    },
                                    images: b
                                })
                            })).filter((function(t) {
                                return !!t
                            }))
                        }) : (0, u.jsx)("div", {
                            className: "sw-loading-wrapper",
                            "data-qa": "fsw-loading",
                            children: (0, u.jsx)(P.Ay, {})
                        })
                    })
                }
        },
        65609: function(t, e, n) {
            n.d(e, {
                A: function() {
                    return T
                }
            });
            n(52675), n(45700), n(2008), n(51629), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(3949), n(23500);
            var r = n(96540),
                o = n(58385),
                i = n(74389),
                a = n(40075),
                s = n(99644),
                c = n(20387),
                u = n(79860),
                l = n(93529),
                f = (n(62062), n(81454), n(65736)),
                p = n(33736),
                d = n(74848);

            function h(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function m(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? h(Object(n), !0).forEach((function(e) {
                        g(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : h(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function g(t, e, n) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != typeof t || !t) return t;
                        var n = t[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(t, e || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == typeof e ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }
            var v = function(t) {
                    var e = t.header,
                        n = t.text,
                        o = t.buttons,
                        i = t.onCancel;
                    return (0, d.jsx)(f.A, {
                        wrapperType: f.T.ACTION_SHEET,
                        header: {
                            title: e,
                            text: n
                        },
                        onDismiss: i,
                        children: o.map((function(t, e) {
                            return (0, r.createElement)(p.A, m(m({}, t), {}, {
                                key: "modal-confirmation-button-" + e
                            }))
                        }))
                    })
                },
                y = function(t) {
                    var e = t.isFavourite,
                        n = t.isSubstitute,
                        o = t.isMatch,
                        i = t.isDeleted,
                        s = t.isNewReportingFlow,
                        c = t.showUnmatchSkip,
                        u = t.showFavourite,
                        l = t.showViewProfile,
                        h = t.showStartChatting,
                        m = t.onDeleteChat,
                        g = t.onFavouriteToggle,
                        v = t.onStartChatting,
                        y = t.onUnmatchSkip,
                        _ = t.onViewProfile,
                        b = t.onReport,
                        A = t.onAnimationOutComplete;
                    return (0, d.jsx)(f.A, {
                        onAnimationOutComplete: A,
                        wrapperType: f.T.ACTION_SHEET,
                        children: i ? (0, d.jsxs)(r.Fragment, {
                            children: [(0, d.jsx)(p.A, {
                                text: a.Ay.get(238),
                                dataQA: {
                                    "data-qa": "delete-chat"
                                },
                                onClick: m
                            }), (0, d.jsx)(p.A, {
                                text: s ? a.Ay.get(1118) : a.Ay.get(416),
                                type: "destructive",
                                dataQA: {
                                    "data-qa": s ? "report-and-block" : "report"
                                },
                                onClick: b
                            })]
                        }) : (0, d.jsxs)(r.Fragment, {
                            children: [u ? (0, d.jsx)(p.A, {
                                text: e ? a.Ay.get(415) : a.Ay.get(414),
                                dataQA: {
                                    "data-qa": e ? "remove-from-favourites" : "add-to-favourites"
                                },
                                onClick: g
                            }) : null, n ? (0, d.jsx)(p.A, {
                                text: a.Ay.get(420),
                                onClick: _
                            }) : (0, d.jsxs)(r.Fragment, {
                                children: [h ? (0, d.jsx)(p.A, {
                                    text: a.Ay.get(254),
                                    dataQA: {
                                        "data-qa": "start-chatting"
                                    },
                                    onClick: v
                                }) : null, c ? (0, d.jsx)(p.A, {
                                    text: o ? a.Ay.get(418) : a.Ay.get(417),
                                    dataQA: {
                                        "data-qa": o ? "unmatch" : "skip"
                                    },
                                    onClick: y
                                }) : null, l ? (0, d.jsx)(p.A, {
                                    text: a.Ay.get(419),
                                    dataQA: {
                                        "data-qa": "view-profile"
                                    },
                                    onClick: _
                                }) : null, (0, d.jsx)(p.A, {
                                    text: s ? a.Ay.get(1118) : a.Ay.get(416),
                                    type: "destructive",
                                    dataQA: {
                                        "data-qa": s ? "report-and-block" : "report"
                                    },
                                    onClick: b
                                })]
                            })]
                        })
                    })
                },
                _ = n(60414),
                b = n(5974),
                A = n(72537),
                x = n(74787);

            function P(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function j(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? P(Object(n), !0).forEach((function(e) {
                        O(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : P(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function O(t, e, n) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != typeof t || !t) return t;
                        var n = t[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(t, e || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == typeof e ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }

            function k(t, e) {
                (0, u.sx)(332, {
                    element: t,
                    parent_element: e
                })
            }

            function w(t) {
                (0, u.sx)(20, {
                    alert_type: 17,
                    activation_place: 11,
                    action_type: t
                })
            }

            function E() {
                l.A.showNotification({
                    type: l.A.TYPES.ERROR
                })
            }
            var T = function(t) {
                var e = t.user,
                    n = t.showUnmatchSkip,
                    l = t.showFavourite,
                    f = void 0 === l || l,
                    p = t.showViewProfile,
                    h = void 0 === p || p,
                    m = t.showStartChatting,
                    g = void 0 !== m && m,
                    P = t.menuElement,
                    O = void 0 === P ? 1380 : P,
                    T = t.onDeleteChat,
                    S = t.onFavouriteToggle,
                    C = t.onViewProfile,
                    N = t.onStartChatting,
                    I = t.onUnmatchComplete,
                    D = t.onAnimationOutComplete,
                    R = (0, r.useState)(Boolean(e.isFavourite)),
                    U = R[0],
                    M = R[1],
                    B = (0, r.useState)(!1),
                    V = B[0],
                    F = B[1],
                    q = (0, r.useState)(!1),
                    H = q[0],
                    L = q[1],
                    Y = (0, r.useState)(null),
                    Q = Y[0],
                    X = Y[1],
                    G = b.A.isActive(),
                    W = A.A.getSync(1004).enabled,
                    z = function() {
                        D(), c.A.getInstance().unmatchUser({
                            personId: e.userId,
                            folderId: 31
                        }).then((function() {
                            I ? I() : o.A.navigate(i.x.CONNECTIONS)
                        })).catch(E)
                    },
                    J = function() {
                        G ? ((0, u.sx)(332, {
                            element: 87,
                            parent_element: 1493
                        }), X("report"), L(!0)) : (k(49, O), o.A.navigate(i.x.REPORT_USER, !1, {
                            userId: e.userId,
                            reportContext: 10
                        }), D())
                    },
                    Z = function() {
                        G ? e.isMatch ? (0, u.sx)(332, {
                            element: 215,
                            parent_element: 1493
                        }) : (0, u.sx)(332, {
                            element: 65,
                            parent_element: 1732
                        }) : w(2), z()
                    },
                    K = function() {
                        G ? k(113, O) : w(5), D()
                    },
                    $ = G ? {
                        header: a.Ay.get(386, {
                            me: s.ko.for("me", (0, x.nV)())
                        }),
                        text: e.isMatch ? a.Ay.get(385, {
                            other_user: s.ko.for("other_user", (0, a.Bt)(e.gender))
                        }) : a.Ay.get(384, {
                            me: s.ko.for("me", (0, x.nV)())
                        }),
                        buttons: [{
                            text: e.isMatch ? a.Ay.get(418) : a.Ay.get(95),
                            onClick: Z
                        }, {
                            text: a.Ay.get(1118),
                            type: "destructive",
                            onClick: J
                        }]
                    } : {
                        header: a.Ay.get(438),
                        text: a.Ay.get(437),
                        buttons: [{
                            text: a.Ay.get(418),
                            onClick: Z,
                            dataQA: {
                                "data-qa-type": "primary"
                            }
                        }, {
                            text: a.Ay.get(451),
                            onClick: K
                        }]
                    },
                    tt = function() {
                        L(!1), z()
                    };
                return (0, r.useEffect)((function() {
                    G && (0, u.sx)(258, {
                        element: 1380
                    }), b.A.hit()
                }), [G]), (0, r.useEffect)((function() {
                    G && V && (0, u.sx)(258, {
                        element: e.isMatch ? 1493 : 1732
                    })
                }), [G, V, e.isMatch]), H && Q ? (0, d.jsx)(_.A, {
                    clientSource: 10,
                    otherUserId: e.userId,
                    isDeleted: e.isDeleted,
                    action: Q,
                    onClose: function() {
                        L(!1)
                    },
                    onReport: tt,
                    onBlock: tt,
                    onUnmatch: z
                }) : (0, d.jsx)(r.Fragment, {
                    children: V ? (0, d.jsx)(v, j(j({}, $), {}, {
                        onCancel: K
                    })) : (0, d.jsx)(y, {
                        isFavourite: U,
                        isSubstitute: e.isSubstitute,
                        isMatch: e.isMatch,
                        isDeleted: e.isDeleted,
                        isNewReportingFlow: G,
                        showUnmatchSkip: n,
                        showFavourite: f,
                        showViewProfile: h,
                        showStartChatting: g,
                        onDeleteChat: function() {
                            (0, u.sx)(332, {
                                element: 106,
                                parent_element: 1493
                            }), T()
                        },
                        onFavouriteToggle: function() {
                            M(!U), S(), k(U ? 85 : 86, O)
                        },
                        onStartChatting: function() {
                            k(304, O), null == N || N(), D()
                        },
                        onUnmatchSkip: function() {
                            G && (W && e.isMatch ? (X("unmatch"), L(!0)) : F(!0)), e.isMatch ? (k(215, O), w(12), G || F(!0)) : (k(65, O), G || z())
                        },
                        onViewProfile: function() {
                            k(1169, O), C(), D()
                        },
                        onReport: J,
                        onAnimationOutComplete: D
                    })
                })
            }
        },
        67533: function(t, e, n) {
            n.d(e, {
                b: function() {
                    return r
                }
            });
            n(8921), n(27495), n(79978);

            function r(t) {
                return t.substring(t.lastIndexOf("/") + 1, t.lastIndexOf(".")).replaceAll("_", " ")
            }
        },
        69873: function(t, e, n) {
            var r = n(74848);
            e.A = function(t) {
                var e = t.children,
                    n = t.tag,
                    o = void 0 === n ? "div" : n;
                return (0, r.jsx)(o, {
                    className: "column-box__media",
                    children: e
                })
            }
        },
        74026: function(t, e, n) {
            var r = n(32675),
                o = n(74848);
            e.A = function(t) {
                var e = t.text,
                    n = t.size,
                    i = void 0 === n ? "small" : n,
                    a = t.styling,
                    s = void 0 === a ? "default" : a;
                return (0, o.jsxs)("div", {
                    className: "separator-chip",
                    children: [(0, o.jsx)("div", {
                        className: "separator-chip__line"
                    }), (0, o.jsx)("div", {
                        className: "separator-chip__chip",
                        children: (0, o.jsx)(r.A, {
                            text: e,
                            size: i,
                            styling: s
                        })
                    })]
                })
            }
        },
        79458: function(t, e, n) {
            var r = n(13264),
                o = n(69705),
                i = n(79860),
                a = n(39778),
                s = n(88309),
                c = n(74848),
                u = r.A.extend({
                    construct: function(t) {
                        u._super.construct.call(this), this.place_ = t.place, this.activationPlace_ = t.activationPlace
                    },
                    obtainPermission: function(t) {
                        o.A.inited && void 0 === o.A.getCurrentChoice(this.place_) && this.showConfirmationPopup_(t)
                    },
                    showConfirmationPopup_: function(t) {
                        var e = this,
                            n = (0, s.A)();
                        this.renderReactView((0, c.jsx)(a.A, {
                            message: t,
                            isOpen: !0,
                            isPortal: !1,
                            onConfirm: function() {
                                e.requestPermission_(), e.removeReactView(n)
                            },
                            onCancel: function() {
                                e.denyPermission_(), e.removeReactView(n)
                            }
                        }), n), this.trackConfirmationPopupView_()
                    },
                    trackConfirmationPopupView_: function() {
                        (0, i.sx)(20, {
                            alert_type: 7,
                            activation_place: this.activationPlace_
                        })
                    },
                    requestPermission_: function() {
                        var t = this;
                        o.A.userWantsPushes(this.place_).then((function(e) {
                            return t.trackPermissionRequest_(e)
                        }))
                    },
                    denyPermission_: function() {
                        o.A.userDeniesPushes(this.place_), this.trackPermissionRequest_(!1)
                    },
                    trackPermissionRequest_: function(t) {
                        (0, i.sx)(47, {
                            permission_type: 2,
                            permission_granted: t,
                            activation_place: this.activationPlace_
                        })
                    }
                }, "NotificationPermissionController");
            e.A = u
        },
        84914: function(t, e) {
            e.A = function(t) {
                var e = null;
                return {
                    callback: function(n) {
                        null !== e ? (t(e, n), e = n) : e = n
                    },
                    reset: function() {
                        e = null
                    }
                }
            }
        },
        88029: function(t, e, n) {
            n.d(e, {
                A: function() {
                    return c
                }
            });
            n(52675), n(45700), n(2008), n(50113), n(51629), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(72577), n(3949), n(23500);
            var r = n(31709),
                o = n(28030);

            function i(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function a(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? i(Object(n), !0).forEach((function(e) {
                        s(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function s(t, e, n) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != typeof t || !t) return t;
                        var n = t[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(t, e || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == typeof e ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }

            function c(t) {
                var e, n = a({}, null == (e = o.A.getSettings()) || null == (e = e.header_configs) ? void 0 : e.find((function(e) {
                    return e.context === t
                })));
                return n.subheader_text && function(t) {
                    new r.Ay(278, {
                        common_stats: {
                            event: 2,
                            source: 21,
                            context: t
                        }
                    }).request()
                }(t), a(a({}, {
                    context: 0,
                    header_text: "",
                    subheader_text: ""
                }), n)
            }
        },
        90982: function(t, e, n) {
            n(23418), n(62062), n(26099), n(47764), n(98992), n(81454);
            var r = n(85208),
                o = n(1270),
                i = n(99417),
                a = n(65297),
                s = n(36521),
                c = n(58336),
                u = n(84914),
                l = n(58544),
                f = s.A.supportsTouch,
                p = (0, c.A)("ZOOM"),
                d = function() {
                    if (f) {
                        var t, e = this.touchMove_.bind(this);
                        this.moveBuffer_ = (0, u.A)(e), this.touchMove_ = (t = this.moveBuffer_.callback, function(e) {
                            e.preventDefault(), t(e.touches && Array.from(e.touches).map((function(t) {
                                return {
                                    x: t.pageX,
                                    y: t.pageY
                                }
                            })))
                        }), this.touchEnd_ = this.touchEnd_.bind(this), this.onClick_ = this.onClick_.bind(this), this.reset = this.reset.bind(this)
                    }
                };

            function h(t, e) {
                i.A.requestAnimationFrame((function() {
                    t.css({
                        transform: "translateX(" + e.translateX + "px) translateY(" + e.translateY + "px) translateZ(0) scale(" + e.scale + ")",
                        "transform-origin": "0px 0px"
                    })
                }))
            }

            function m(t, e) {
                return Math.sqrt(Math.pow(e.x - t.x, 2) + Math.pow(e.y - t.y, 2))
            }

            function g(t) {
                var e = t.element,
                    n = t.transform,
                    r = t.deltaX,
                    o = t.deltaY,
                    i = t.deltaScale;
                i = i || 0;
                var a = e.offset(),
                    s = n.scale,
                    c = s + i,
                    u = Math.floor(a.height / s) - 1,
                    l = u * c,
                    f = v(n.translateY + o, u - l, 0),
                    p = Math.floor(a.width / s) - 1,
                    d = p * c;
                return {
                    scale: c,
                    translateY: f,
                    translateX: v(n.translateX + r, p - d, 0)
                }
            }

            function v(t, e, n) {
                return Math.min(n, Math.max(e, t))
            }
            d.EVENTS = p, d.prototype = (0, r.A)({}, l.zb, {
                maxScale: 3,
                minScale: 1,
                isEnabled_: !1,
                element_: null,
                transform_: null,
                isEnabled: function() {
                    return this.isEnabled_
                },
                enable: function(t) {
                    t && !this.isEnabled_ && f && (this.isEnabled_ = !0, this.element_ = (0, o.A)(t), this.element_.on("touchmove", this.touchMove_), this.element_.on("touchend", this.touchEnd_), this.element_.on("click", this.onClick_), a.A.on(a.A.ORIENTATION_CHANGE, this.reset), this.reset())
                },
                disable: function() {
                    this.isEnabled_ && f && (this.isEnabled_ = !1, this.element_.off("touchmove", this.touchMove_), this.element_.off("touchend", this.touchEnd_), this.element_.off("click", this.onClick_), a.A.off(a.A.ORIENTATION_CHANGE, this.reset), this.element_ = null)
                },
                reset: function() {
                    this.isEnabled_ && f && this.element_ && (this.transform_ = {
                        translateX: 0,
                        translateY: 0,
                        scale: 1
                    }, h(this.element_, this.transform_), this.trigger(p.ZOOM, this.transform_.scale))
                },
                onClick_: function(t) {
                    1 !== this.transform_.scale && (t.preventDefault(), t.stopPropagation(), this.reset())
                },
                touchEnd_: function(t) {
                    Math.abs(1 - this.transform_.scale) < .1 && this.reset(), this.moveBuffer_.reset()
                },
                touchMove_: function(t, e) {
                    var n, r, o, i, a, s, c, u = {
                        element: this.element_,
                        transform: this.transform_
                    };
                    2 === e.length && 2 === t.length ? (u.maxScale = this.maxScale, u.minScale = this.minScale, u.prevTouches = t, u.currTouches = e, this.transform_ = function(t) {
                        var e = t.element,
                            n = t.transform,
                            r = t.prevTouches,
                            o = t.currTouches,
                            i = t.maxScale,
                            a = t.minScale,
                            s = m(o[0], o[1]),
                            c = m(r[0], r[1]),
                            u = (s - c) / c,
                            l = v(n.scale + u, a, i) - n.scale,
                            f = (o[0].x + o[1].x) / 2,
                            p = (o[0].y + o[1].y) / 2;
                        return g({
                            element: e,
                            transform: n,
                            deltaX: -1 * l * f,
                            deltaY: -1 * l * p,
                            deltaScale: l
                        })
                    }(u), h(this.element_, this.transform_), this.trigger(p.ZOOM, this.transform_.scale)) : 1 !== this.transform_.scale && (u.prevTouch = t[0], u.currTouch = e[0], this.transform_ = (r = (n = u).element, o = n.transform, i = n.prevTouch, a = n.currTouch, s = a.x - i.x, c = a.y - i.y, g({
                        element: r,
                        transform: o,
                        deltaX: s,
                        deltaY: c
                    })), h(this.element_, this.transform_))
                }
            }), e.A = d
        },
        96956: function(t, e, n) {
            n(51629), n(74423), n(26099);
            var r = ["action", "cost", "paymentTransitionInFlow", "popState", "productType", "promoBlock", "promoBlockType", "purchaseTransactionSetup", "inviteFlow", "redirectPage", "source", "paymentFlowId", "hotPanelData", "albumType", "feature", "userId", "back", "clientSource", "activationPlace", "screenName", "callback"];

            function o() {}
            r.forEach((function(t) {
                var e = t.substring(0, 1).toUpperCase() + t.substring(1);
                o.prototype["get" + e] = function() {
                    return this[t]
                }, o.prototype["set" + e] = function(e) {
                    if (this[t] = e, "hotPanelData" === t)
                        for (var n in e) e.hasOwnProperty(n) && r.includes(n) && (this[n] = e[n]);
                    return this
                }, o.prototype["has" + e] = function() {
                    return t in this
                }
            })), e.A = o
        },
        97547: function(t, e, n) {
            n.d(e, {
                V: function() {
                    return i
                }
            });
            var r = n(99417);

            function o(t) {
                this.wrapper = t, this.reset()
            }

            function i(t, e, n) {
                try {
                    t.scrollTo({
                        behavior: n ? "smooth" : "instant",
                        top: e
                    })
                } catch (n) {
                    if (!(n instanceof TypeError)) throw n;
                    t && "function" == typeof t.scrollTo && t.scrollTo(0, e)
                }
            }

            function a(t) {
                return t.wrapper.scrollHeight - t.scrollBottom - r.A.innerHeight
            }
            o.prototype = {
                restore: function(t) {
                    this.scrollTop = t ? this.scrollTop : a(this), i(this.wrapper, this.scrollTop, !1)
                },
                prepare: function() {
                    this.scrollBottom = this.wrapper.scrollHeight - this.wrapper.scrollTop - r.A.innerHeight, this.scrollTop = a(this)
                },
                reset: function() {
                    this.scrollBottom = 0, this.scrollTop = a(this)
                },
                scrollIntoView: function(t, e, n) {
                    t && i(this.wrapper, t.offsetTop - (e || 0), n)
                },
                scrollToBottom: function(t) {
                    i(this.wrapper, this.wrapper.scrollHeight + this.wrapper.clientHeight, t)
                },
                scrollBy: function(t, e) {
                    i(this.wrapper, this.wrapper.scrollTop + t, e)
                },
                scrollTo: function(t, e) {
                    i(this.wrapper, t, e)
                }
            }, e.A = o
        },
        98234: function(t, e, n) {
            var r;
            n(10287);

            function o(t, e) {
                return o = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                    return t.__proto__ = e, t
                }, o(t, e)
            }
            var i = function(t) {
                function e() {
                    return t.call(this, {
                        get: {
                            message: 443,
                            response: 444
                        }
                    }, {
                        name: "GiftStoreModel"
                    }) || this
                }
                var n, r;
                r = t, (n = e).prototype = Object.create(r.prototype), n.prototype.constructor = n, o(n, r);
                var i = e.prototype;
                return i.getGifts = function(e, n) {
                    var r = {};
                    return e && (r.user_id = e), n && (r.context = n), t.prototype.get.call(this, r)
                }, i.getCacheKey = function(t, e) {
                    return e.user_id + ":" + (e.context || 0)
                }, e
            }(n(6696).A);
            r = i, i.instance = null, i.getInstance = function() {
                return r.instance || (r.instance = new r), r.instance
            }, e.A = i
        },
        99766: function(t, e, n) {
            n(52675), n(45700), n(2008), n(51629), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(3949), n(23500);
            var r = n(74848);

            function o(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function i(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? o(Object(n), !0).forEach((function(e) {
                        a(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function a(t, e, n) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != typeof t || !t) return t;
                        var n = t[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(t, e || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == typeof e ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }
            e.A = function(t) {
                var e = t.children,
                    n = t.tag,
                    o = void 0 === n ? "div" : n,
                    a = t.dataQA,
                    s = o;
                return (0, r.jsx)(s, i(i({
                    className: "column-box"
                }, a), {}, {
                    children: e
                }))
            }
        }
    }
]);
//# sourceMappingURL=4251.d0539353395cbe19c5e6.js.map
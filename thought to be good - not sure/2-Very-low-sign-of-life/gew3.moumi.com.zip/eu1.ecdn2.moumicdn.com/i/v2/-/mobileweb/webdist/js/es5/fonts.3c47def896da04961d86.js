"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [6699], {
        59906: function(e, t, A) {
            A.r(t);
            A(27495), A(90906);
            var n = A(20679),
                s = A(99417),
                a = n.A.getRequest("WebFont Loaded", 32),
                c = s.A._partner_id,
                o = s.A.localStorage,
                r = /^\s*</,
                i = function() {
                    if ("badoo" === c) return "/css/fonts/beausite-classic.5b846ac1ac3bbf8f1b0f.css";
                    return
                }();
            if (function() {
                    if (!("FontFace" in s.A)) return !1;
                    var e = new s.A.FontFace("t", 'url( "data:application/font-woff2;base64,d09GMgABAAAAAADcAAoAAAAAAggAAACWAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAABk4ALAoUNAE2AiQDCAsGAAQgBSAHIBtvAcieB3aD8wURQ+TZazbRE9HvF5vde4KCYGhiCgq/NKPF0i6UIsZynbP+Xi9Ng+XLbNlmNz/xIBBqq61FIQRJhC/+QA/08PJQJ3sK5TZFMlWzC/iK5GUN40psgqvxwBjBOg6JUSJ7ewyKE2AAaXZrfUB4v+hze37ugJ9d+DeYqiDwVgCawviwVFGnuttkLqIMGivmDg" ) format( "woff2" )', {});
                    return e.load(), "loading" === e.status || "loaded" === e.status
                }() && function() {
                    try {
                        return o.setItem("test", "test"), o.removeItem("test"), !0
                    } catch (e) {
                        return !1
                    }
                }()) {
                a.setStart(Date.now());
                var f = function() {
                    var e = o.font_css_cache_file;
                    if (!e) return;
                    if (e !== i) return void u();
                    var t = o.font_css_cache;
                    if (A = t, r.test(A)) return void u();
                    var A;
                    return t
                }();
                f ? d(f) : function(e) {
                    if (!i) return;
                    var t = new s.A.XMLHttpRequest;
                    t.open("GET", "" + s.A._badoo_cdnUrl + i, !0), t.onreadystatechange = function() {
                        if (4 === t.readyState)
                            if (200 === t.status) {
                                var A = t.responseText;
                                ! function(e) {
                                    o.font_css_cache = e, o.font_css_cache_file = i
                                }(A), e(A)
                            } else e()
                    }, t.send()
                }((function(e) {
                    e && d(e)
                }))
            }

            function u() {
                o.removeItem("font_css_cache"), o.removeItem("font_css_cache_file")
            }

            function d(e) {
                var t = s.A.document.createElement("style");
                t.setAttribute("type", "text/css"), t.styleSheet ? t.styleSheet.cssText = e : t.innerHTML = e, s.A.document.getElementsByTagName("head")[0].appendChild(t), a.end()
            }
        }
    }
]);
//# sourceMappingURL=fonts.3c47def896da04961d86.js.map
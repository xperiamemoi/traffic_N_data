/*! For license information please see screen-stories-controller.28717f9b7da697587863.js.LICENSE.txt */
"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [5976], {
        307: function(e, t, n) {
            n.d(t, {
                r: function() {
                    return o
                }
            });
            var r = n(17414),
                o = (0, r.Qr)({
                    progress: r.qG,
                    title: "title",
                    description: "description",
                    placeholder: "placeholder"
                })
        },
        2108: function(e, t, n) {
            n.d(t, {
                y: function() {
                    return r
                }
            });
            var r = (0, n(17414).Qr)({
                1: "progress",
                2: "title",
                3: "caption",
                4: "continueButton",
                5: "callToAction"
            })
        },
        3941: function(e, t, n) {
            n.d(t, {
                G6: function() {
                    return a
                },
                VT: function() {
                    return i
                },
                dc: function() {
                    return c
                },
                lY: function() {
                    return o
                }
            });
            var r = n(17414),
                o = (0, r.Qr)({
                    title: "title",
                    content: "text",
                    legal: "links",
                    acknowledged_checkbox: "confirmCheckbox",
                    content_timestamp: "contentTimestamp",
                    primary_button: "cta"
                }),
                i = (0, r.Qr)({
                    community_guidelines: "guidelines",
                    terms_and_conditions: "terms",
                    dispute: "dispute"
                }),
                a = (0, r.Qr)({
                    unchecked_error: "error"
                }),
                c = (0, r.Qr)({
                    title: "title",
                    content: "text",
                    primary_button: "cta"
                });
            (0, r.Qr)({
                title: "decisionTitle",
                content: "decisionText"
            }), (0, r.Qr)({
                title: "title",
                body: "body",
                primary_button: "primaryCta",
                secondary_button: "secondaryCta"
            }), (0, r.Qr)({
                title: "title",
                content: "text"
            })
        },
        6593: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return m
                },
                Z: function() {
                    return f
                }
            });
            n(52675), n(45700), n(2008), n(51629), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(3949), n(23500);
            var r = n(96540),
                o = n(18084),
                i = n(56591),
                a = n(74848);

            function c(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function s(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? c(Object(n), !0).forEach((function(t) {
                        u(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function u(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(e, t || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var l = o.A.getLogger("Registration Context"),
                d = function(e) {
                    return void 0 === e && (e = {}), {
                        user: {},
                        screen_context: {
                            screen_id: e.screenId,
                            flow_id: e.flowId
                        }
                    }
                },
                p = function(e, t) {
                    return t.type === i.$.UPDATE_USER ? s(s({}, e), {}, {
                        user: s(s({}, e.user), t.payload)
                    }) : e
                },
                f = (0, r.createContext)([d(), function() {
                    return l.error("Trying to dispatch event outside context")
                }]);
            f.displayName = "RegistrationContext";
            var m = function(e) {
                var t = (0, r.useReducer)(p, d(e)),
                    n = t[0],
                    o = t[1];
                return (0, a.jsx)(f.Provider, {
                    value: [n, o],
                    children: e.children
                })
            }
        },
        7163: function(e, t, n) {
            n.d(t, {
                b: function() {
                    return r
                }
            });
            var r = (0, n(17414).Qr)({
                tagline: "tagline",
                logo_subtitle: "logoSubtitle",
                blocker_ctabox_title: "title",
                blocker_ctabox_message: "description",
                blocker_ctabox_cta: "cta"
            })
        },
        10730: function(e, t, n) {
            var r = n(74848);
            t.A = ({
                children: e
            }) => (0, r.jsx)("div", {
                className: "csms-navigation-bar__content",
                children: e
            })
        },
        10801: function(e, t, n) {
            n.d(t, {
                GO: function() {
                    return a
                },
                Hu: function() {
                    return s
                },
                W7: function() {
                    return c
                },
                XA: function() {
                    return u
                },
                j: function() {
                    return i
                },
                tu: function() {
                    return o
                }
            });
            var r = n(17414),
                o = (0, r.Qr)({
                    title: "title",
                    content: "text",
                    legal: "links"
                }),
                i = (0, r.Qr)({
                    transparency_modal: "decision",
                    community_guidelines: "guidelines",
                    terms_and_conditions: "terms",
                    dispute: "dispute"
                }),
                a = (0, r.Qr)({
                    title: "decisionTitle",
                    content: "decisionText"
                }),
                c = (0, r.Qr)({
                    title: "title",
                    body: "body",
                    primary_button: "primaryCta",
                    secondary_button: "secondaryCta",
                    close: "close"
                }),
                s = (0, r.Qr)({
                    title: "title",
                    content: "text"
                }),
                u = (0, r.Qr)({
                    title: "title",
                    body: "text",
                    primary_button: "primaryCta"
                })
        },
        11680: function(e, t, n) {
            n.d(t, {
                s: function() {
                    return r
                }
            });
            var r = {
                    ERROR: "ERROR",
                    INFO: "INFO",
                    PAYMENT: "PAYMENT",
                    MESSAGE: "MESSAGE",
                    PHOTO_UPLOAD: "PHOTO_UPLOAD"
                },
                o = function() {};
            o.showNotification = void 0, o.updateNotification = void 0, o.TYPES = void 0
        },
        12554: function(e, t, n) {
            var r = n(74848),
                o = n(84362),
                i = n(26914),
                a = n(53787),
                c = n(93827);
            t.A = ({
                user: e,
                additional: t,
                onClick: n,
                innerRef: s,
                a11y: u
            }) => {
                const l = n ? "button" : "div";
                return (0, r.jsxs)(l, {
                    className: "csms-navigation-bar__profile",
                    onClick: n,
                    ref: s,
                    type: "button" === l ? "button" : void 0,
                    children: [(0, r.jsx)(o.A, {
                        children: u ? .label
                    }), (0, r.jsx)("span", {
                        className: "csms-navigation-bar__profile-avatar",
                        "aria-hidden": Boolean(u ? .label) || void 0,
                        children: (0, r.jsx)(i.A, {
                            user: e
                        })
                    }), e ? .name ? (0, r.jsxs)("span", {
                        className: "csms-navigation-bar__profile-info",
                        children: [(0, r.jsx)(o.A, {
                            tag: "h1",
                            children: e.name
                        }), (0, r.jsx)(c.ZS, {
                            a11y: {
                                ariaHidden: Boolean(u ? .label) || void 0
                            },
                            children: (0, r.jsx)(a.A, {
                                name: e.name,
                                age: e.age,
                                status: e.status,
                                a11y: {
                                    label: u ? .profileInfoLabel
                                }
                            })
                        })]
                    }) : null, t ? (0, r.jsx)("span", {
                        className: "csms-navigation-bar__profile-additional",
                        "aria-hidden": Boolean(u ? .label) || void 0,
                        children: (0, r.jsx)(c.P3, {
                            ellipsis: !0,
                            children: t
                        })
                    }) : null]
                })
            }
        },
        15279: function(e, t, n) {
            var r = n(74848);
            t.A = ({
                text: e
            }) => (0, r.jsx)("div", {
                className: "csms-navigation-bar__sub-title",
                children: e
            })
        },
        21020: function(e, t, n) {
            n(45228);
            var r = n(96540),
                o = 60103;
            if (t.Fragment = 60107, "function" == typeof Symbol && Symbol.for) {
                var i = Symbol.for;
                o = i("react.element"), t.Fragment = i("react.fragment")
            }
            var a = r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
                c = Object.prototype.hasOwnProperty,
                s = {
                    key: !0,
                    ref: !0,
                    __self: !0,
                    __source: !0
                };

            function u(e, t, n) {
                var r, i = {},
                    u = null,
                    l = null;
                for (r in void 0 !== n && (u = "" + n), void 0 !== t.key && (u = "" + t.key), void 0 !== t.ref && (l = t.ref), t) c.call(t, r) && !s.hasOwnProperty(r) && (i[r] = t[r]);
                if (e && e.defaultProps)
                    for (r in t = e.defaultProps) void 0 === i[r] && (i[r] = t[r]);
                return {
                    $$typeof: o,
                    type: e,
                    key: u,
                    ref: l,
                    props: i,
                    _owner: a.current
                }
            }
            t.jsx = u, t.jsxs = u
        },
        22523: function(e, t, n) {
            var r = n(74848);
            t.A = function(e) {
                var t = e.value,
                    n = void 0 === t ? 0 : t;
                return (0, r.jsx)("div", {
                    className: "registration-progress-bar",
                    "data-qa": "registration-progress-bar",
                    children: (0, r.jsx)("div", {
                        className: "registration-progress-bar__value",
                        style: {
                            width: n + "%"
                        }
                    })
                })
            }
        },
        25458: function(e, t, n) {
            n.d(t, {
                GO: function() {
                    return i
                },
                dN: function() {
                    return o
                },
                oY: function() {
                    return a
                },
                uY: function() {
                    return c
                }
            });
            var r = n(17414),
                o = (0, r.Qr)({
                    title: "title",
                    body: "text",
                    content: "content",
                    analytics: "analytics",
                    statement_ids: "statementIds",
                    transparency_modal: "decision",
                    primary_button: "cta",
                    footer: "footerText"
                }),
                i = (0, r.Qr)({
                    title: "decisionTitle",
                    content: "decisionText"
                }),
                a = ((0, r.Qr)({
                    title: "title",
                    body: "body",
                    primary_button: "primaryCta",
                    secondary_button: "secondaryCta"
                }), (0, r.Qr)({
                    title: "title",
                    content: "text"
                }), (0, r.Qr)({
                    title: "title",
                    body: "text",
                    email_address_label: "emailLabel",
                    primary_button: "primaryCta",
                    secondary_button: "secondaryCta"
                })),
                c = (0, r.Qr)({
                    title: "title",
                    body: "text",
                    primary_button: "cta"
                })
        },
        26443: function(e, t, n) {
            var r = n(74848),
                o = n(46942),
                i = n.n(o),
                a = n(84362);
            t.A = ({
                status: e = "hidden",
                a11y: t
            }) => {
                const n = i()({
                    "csms-online-status": !0,
                    [`csms-online-status--${e}`]: !0
                });
                return (0, r.jsx)("span", {
                    className: n,
                    "data-qa-online-status": e,
                    children: (0, r.jsx)(a.A, {
                        children: t ? .label
                    })
                })
            }
        },
        40068: function(e, t, n) {
            var r = n(96540),
                o = n(5322),
                i = n(18084);
            t.A = function(e, t) {
                var n = (0, r.useRef)(i.A.getLogger("useUICollection")),
                    a = (0, r.useContext)(o.P),
                    c = a.getUIForScreenByGivenId,
                    s = a.getUIForScreenChildren,
                    u = a.currentScreen,
                    l = a.getFlowData;
                t && !u && n.current.error("App is trying to get ui before stories loaded");
                var d = l();
                return [(0, r.useMemo)((function() {
                    return c(e, (null == u ? void 0 : u.id) || String(t))
                }), [c, e, u, d.flow_id]) || {}, s]
            }
        },
        44334: function(e, t, n) {
            n.d(t, {
                $: function() {
                    return i
                },
                h: function() {
                    return o
                }
            });
            var r = n(17414),
                o = (0, r.Qr)({
                    progress: "progress",
                    title: "title",
                    body: "body",
                    sign_out: "signOut",
                    registration: "registration",
                    redirect_action: "redirectAction",
                    passkey_error_dialog: "passkeyErrorDialog"
                }),
                i = (0, r.Qr)({
                    primary_button: "primaryButton",
                    secondary_button: "secondaryButton"
                })
        },
        44851: function(e, t) {
            var n = {
                FATAL: 9,
                NON_FATAL: 10,
                OTHER: 12
            };
            t.A = {
                getType: function(e) {
                    return 10002 === e || e >= 9100 && e <= 9199 ? n.FATAL : 46 === e ? n.NON_FATAL : n.OTHER
                },
                TYPE: n
            }
        },
        49185: function(e, t, n) {
            n.d(t, {
                V: function() {
                    return o
                },
                e: function() {
                    return i
                }
            });
            var r = n(17414),
                o = (0, r.Qr)({
                    title: "header",
                    subheader: "subheader",
                    tooltip: "tooltip",
                    cards: "cards"
                }),
                i = (0, r.Qr)({
                    camera: "takePhotoButton",
                    gallery: "galleryButton",
                    instagram: "instagramButton",
                    facebook: "facebookButton"
                })
        },
        50180: function(e, t, n) {
            n.d(t, {
                G: function() {
                    return o
                },
                e: function() {
                    return i
                }
            });
            var r = n(17414),
                o = (0, r.Qr)({
                    1: "header",
                    2: "subheader",
                    3: "cta",
                    4: "pin"
                }),
                i = (0, r.Qr)({
                    1: "header",
                    2: "subheader",
                    3: "pin"
                })
        },
        51014: function(e, t, n) {
            n.d(t, {
                h7: function() {
                    return p
                },
                qZ: function() {
                    return d
                },
                uU: function() {
                    return c
                }
            });
            var r = n(17414),
                o = n(40068),
                i = n(93100),
                a = n(93529),
                c = (0, r.Qr)({
                    progress: "progress",
                    header: "header",
                    subheader: "subheader",
                    photos: "photos",
                    btn_back: "backButton",
                    btn_add_photo: "addPhotoButton",
                    btn_continue: "continueButton"
                }),
                s = (0, r.Qr)({
                    choose_photos: "choosePhotos",
                    photos_2_3_4: "photos234",
                    photos_5: "photos5",
                    photos_max: "photosMax"
                }),
                u = (0, r.Qr)({
                    choose_photos: "choosePhotos",
                    photos_2: "photos2",
                    photos_3_4: "photos34",
                    photos_max: "photosMax",
                    reorder_text: "reorderText"
                }),
                l = (0, r.Qr)({
                    min_quantity: "minQuantity",
                    max_quantity: "maxQuantity",
                    add: "addMessage",
                    tooltip: "tooltipMessage",
                    error: "errorMessage",
                    delete: "deleteMessage"
                }),
                d = function(e) {
                    var t, n, r, a, d = (0, o.A)(c, 458),
                        p = d[0],
                        f = d[1],
                        m = f(p.header.children, s),
                        h = f(p.subheader.children, u),
                        g = f(p.photos.children, l);
                    return {
                        progress: p.progress.progress,
                        config: {
                            maxPhotos: g.maxQuantity.quantity || i.r,
                            minPhotos: g.minQuantity.quantity || 0
                        },
                        headerText: function() {
                            switch (!0) {
                                case 0 === e:
                                    return m.choosePhotos.text;
                                case 2 === e:
                                case 3 === e:
                                case 4 === e:
                                    return m.photos234.text;
                                case e === g.maxQuantity:
                                    return m.photos5.text;
                                default:
                                    return m.choosePhotos.text
                            }
                        }(),
                        subheaderText: function() {
                            switch (!0) {
                                case 0 === e:
                                    return h.choosePhotos.text;
                                case 2 === e:
                                    return h.photos2.text;
                                case 3 === e:
                                case 4 === e:
                                    return h.photos34.text;
                                case e === g.maxQuantity:
                                    return h.photosMax.text;
                                default:
                                    return h.choosePhotos.text
                            }
                        }(),
                        messages: {
                            reorderMessage: h.reorderText.text,
                            errorMessage: null == (t = g.errorMessage.call_to_action) ? void 0 : t.text,
                            addPhotoMessage: null == (n = g.addMessage.call_to_action) ? void 0 : n.text,
                            tooltipMessage: null == (r = g.tooltipMessage.call_to_action) ? void 0 : r.text,
                            deleteMessage: null == (a = g.deleteMessage.call_to_action) ? void 0 : a.text
                        },
                        buttons: {
                            backButton: p.backButton.call_to_action,
                            addPhotoButton: p.addPhotoButton.call_to_action,
                            continueButton: p.continueButton.call_to_action
                        }
                    }
                };

            function p(e) {
                a.A.showNotification({
                    type: a.A.TYPES.ERROR,
                    text: e
                })
            }
        },
        53787: function(e, t, n) {
            var r = n(74848),
                o = n(84362),
                i = n(26443);
            t.A = ({
                name: e,
                age: t,
                status: n,
                a11y: a
            }) => {
                const c = Boolean(a ? .label);
                return (0, r.jsxs)("span", {
                    className: "csms-profile-info",
                    children: [(0, r.jsx)("span", {
                        className: "csms-profile-info__name",
                        "data-qa": "profile-info__name",
                        "aria-hidden": c,
                        children: (0, r.jsx)("span", {
                            className: "csms-profile-info__name-inner",
                            children: e
                        })
                    }), t ? (0, r.jsx)("span", {
                        className: "csms-profile-info__age",
                        "aria-hidden": c,
                        children: (0, r.jsxs)("span", {
                            children: [", ", (0, r.jsx)("span", {
                                "data-qa": "profile-info__age",
                                children: t
                            })]
                        })
                    }) : null, n ? .online && "hidden" !== n ? .online ? (0, r.jsx)("span", {
                        className: "csms-profile-info__status",
                        "aria-hidden": c,
                        children: (0, r.jsx)(i.A, {
                            status: n.online
                        })
                    }) : null, (0, r.jsx)(o.A, {
                        children: a ? .label
                    })]
                })
            }
        },
        55105: function(e, t, n) {
            var r = n(40075),
                o = n(84362),
                i = n(23350),
                a = n(74848);
            t.A = function(e) {
                var t = e.size,
                    n = void 0 === t ? i.On.LARGE : t,
                    c = e.color,
                    s = void 0 === c ? i.Ac.DARK : c;
                return (0, a.jsxs)("div", {
                    className: "view-loading-mask",
                    "data-qa": "loader-screen",
                    children: [(0, a.jsx)("div", {
                        className: "view-loading-centre",
                        children: (0, a.jsx)("div", {
                            className: "view-loading-container",
                            children: (0, a.jsx)(i.Ay, {
                                color: s,
                                size: n
                            })
                        })
                    }), (0, a.jsx)(o.A, {
                        children: (0, a.jsx)("span", {
                            role: "status",
                            "aria-live": "polite",
                            children: r.Ay.get(992)
                        })
                    })]
                })
            }
        },
        56591: function(e, t, n) {
            var r;
            n.d(t, {
                    $: function() {
                        return r
                    }
                }),
                function(e) {
                    e[e.UPDATE_USER = 0] = "UPDATE_USER"
                }(r || (r = {}))
        },
        57981: function(e, t, n) {
            n.d(t, {
                V$: function() {
                    return s
                },
                Xd: function() {
                    return c
                },
                c6: function() {
                    return a
                },
                dm: function() {
                    return i
                },
                ji: function() {
                    return o
                },
                zx: function() {
                    return u
                }
            });
            var r = n(17414),
                o = (0, r.Qr)({
                    tagline: "tagline",
                    providers: "providers",
                    last_signed: "lastSigned",
                    footer: "footer",
                    tnc: "tnc",
                    passkey: "passkey"
                }),
                i = (0, r.Qr)({
                    1: "progress",
                    2: "header",
                    3: "subHeader",
                    4: "secondaryCta",
                    6: "cta",
                    8: "privacyInfo",
                    9: "inputLabel"
                }),
                a = (0, r.Qr)({
                    1: "title",
                    2: "subtitle",
                    3: "decline",
                    4: "accept"
                }),
                c = (0, r.Qr)({
                    1: "progress",
                    2: "header",
                    3: "subHeader",
                    4: "secondaryCta",
                    5: "cta",
                    9: "privacyInfo",
                    10: "inputLabel"
                }),
                s = (0, r.Qr)({
                    sign_in: "signIn",
                    other_methods: "otherMethods",
                    passkey_error_dialog: "passkeyErrorDialog"
                }),
                u = (0, r.Qr)({
                    title: "title",
                    subtitle: "subtitle",
                    primary_button: "primaryButton",
                    secondary_button: "secondaryButton"
                })
        },
        68072: function(e, t, n) {
            var r = n(74848),
                o = n(84362);
            t.A = ({
                children: e,
                onClick: t,
                tag: n = "div",
                a11y: i
            }) => {
                const a = n,
                    c = t ? "button" : "span";
                return (0, r.jsx)(a, {
                    className: "csms-navigation-bar__logo",
                    "aria-hidden": i ? .ariaHidden || void 0,
                    id: "navigation-logo",
                    children: (0, r.jsxs)(c, {
                        className: "csms-navigation-bar__logo-action",
                        onClick: t,
                        "aria-hidden": i ? .ariaHidden || void 0,
                        "data-qa": "navbar-logo",
                        type: "button" === c ? "button" : void 0,
                        children: [e, (0, r.jsx)(o.A, {
                            children: i ? .label
                        })]
                    })
                })
            }
        },
        71294: function(e, t, n) {
            n.r(t), n.d(t, {
                default: function() {
                    return ye
                }
            });
            n(52675), n(45700), n(2008), n(50113), n(51629), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(10287), n(26099), n(98992), n(54520), n(72577), n(3949), n(23500);
            var r = n(46942),
                o = n.n(r),
                i = n(85558),
                a = n(96540),
                c = n(79860),
                s = (n(23792), n(3362), n(47764), n(62953), n(80051)),
                u = n(98334),
                l = n(307),
                d = n(85246),
                p = n(2108),
                f = n(51014),
                m = n(10801),
                h = n(3941),
                g = n(25458),
                v = n(74703),
                y = n(76709),
                b = n(49185),
                _ = n(57981),
                N = n(50180),
                x = n(44334),
                S = n(7163),
                A = n(74389),
                P = (0, a.lazy)((function() {
                    return Promise.all([n.e(9232), n.e(7477)]).then(n.bind(n, 68894))
                })),
                O = (0, a.lazy)((function() {
                    return Promise.all([n.e(5235), n.e(2065), n.e(7967), n.e(8925), n.e(851), n.e(1052), n.e(8556), n.e(1087), n.e(387), n.e(7397), n.e(8819), n.e(8651), n.e(9232), n.e(3700), n.e(1218), n.e(1379), n.e(9201)]).then(n.bind(n, 65107))
                })),
                E = (0, a.lazy)((function() {
                    return Promise.all([n.e(5235), n.e(8556), n.e(1087), n.e(387), n.e(8651), n.e(4169), n.e(8571)]).then(n.bind(n, 42897))
                })),
                j = (0, a.lazy)((function() {
                    return n.e(1288).then(n.bind(n, 7560))
                })),
                T = (0, a.lazy)((function() {
                    return n.e(380).then(n.bind(n, 74219))
                })),
                R = (0, a.lazy)((function() {
                    return Promise.all([n.e(5235), n.e(8556), n.e(1087), n.e(1059)]).then(n.bind(n, 51172))
                })),
                C = (0, a.lazy)((function() {
                    return n.e(3838).then(n.bind(n, 62839))
                })),
                k = (0, a.lazy)((function() {
                    return Promise.all([n.e(5235), n.e(2065), n.e(1706), n.e(8436), n.e(8556), n.e(1087), n.e(7397), n.e(7065)]).then(n.bind(n, 32879))
                })),
                I = (0, a.lazy)((function() {
                    return n.e(4952).then(n.bind(n, 5612))
                })),
                L = (0, a.lazy)((function() {
                    return Promise.all([n.e(2847), n.e(7397), n.e(9232), n.e(5350), n.e(852)]).then(n.bind(n, 49476))
                })),
                Q = (0, a.lazy)((function() {
                    return Promise.all([n.e(5350), n.e(4179)]).then(n.bind(n, 6561))
                })),
                w = (0, a.lazy)((function() {
                    return n.e(1670).then(n.bind(n, 25015))
                })),
                D = (0, a.lazy)((function() {
                    return n.e(1670).then(n.bind(n, 77957))
                })),
                B = (0, a.lazy)((function() {
                    return Promise.all([n.e(602), n.e(9989)]).then(n.bind(n, 70995))
                })),
                M = (0, a.lazy)((function() {
                    return n.e(3076).then(n.bind(n, 50840))
                })),
                U = (0, a.lazy)((function() {
                    return Promise.all([n.e(7967), n.e(602), n.e(5209)]).then(n.bind(n, 40416))
                })),
                z = (0, a.lazy)((function() {
                    return Promise.all([n.e(7967), n.e(602), n.e(5209)]).then(n.bind(n, 68428))
                })),
                G = (0, a.lazy)((function() {
                    return Promise.all([n.e(7967), n.e(602), n.e(5209)]).then(n.bind(n, 88))
                })),
                q = (0, a.lazy)((function() {
                    return Promise.all([n.e(7967), n.e(602), n.e(5209)]).then(n.bind(n, 63657))
                })),
                H = (0, a.lazy)((function() {
                    return Promise.all([n.e(602), n.e(9856)]).then(n.bind(n, 82293))
                })),
                F = (0, a.lazy)((function() {
                    return Promise.all([n.e(602), n.e(9856)]).then(n.bind(n, 29853))
                })),
                Y = (0, a.lazy)((function() {
                    return Promise.all([n.e(602), n.e(9856)]).then(n.bind(n, 593))
                })),
                K = (0, a.lazy)((function() {
                    return Promise.all([n.e(7967), n.e(602), n.e(6577)]).then(n.bind(n, 30463))
                })),
                W = (0, a.lazy)((function() {
                    return Promise.all([n.e(7967), n.e(602), n.e(6577)]).then(n.bind(n, 6535))
                })),
                $ = (0, a.lazy)((function() {
                    return Promise.all([n.e(2847), n.e(7397), n.e(9232), n.e(5350), n.e(852)]).then(n.bind(n, 47587))
                })),
                V = (0, a.lazy)((function() {
                    return Promise.all([n.e(2847), n.e(7397), n.e(9232), n.e(5350), n.e(852)]).then(n.bind(n, 65941))
                })),
                X = (0, a.lazy)((function() {
                    return n.e(487).then(n.bind(n, 84321))
                })),
                Z = n(22523),
                J = n(39904),
                ee = n(55105),
                te = n(47901),
                ne = n(15376),
                re = n(74848),
                oe = function(e) {
                    var t = e.children,
                        n = e.title,
                        r = e.isLoading,
                        o = e.navigationActions,
                        i = e.progressValue;
                    return (0, re.jsxs)(te.A, {
                        dataQA: {
                            "data-qa-reg-page": "dataQaPage"
                        },
                        children: [(0, re.jsxs)(ne.A, {
                            children: [void 0 !== i ? (0, re.jsx)(Z.A, {
                                value: i
                            }) : null, (0, re.jsx)(J.Ay, {
                                title: n,
                                transparent: !0,
                                hasShadow: !0,
                                actions: o
                            })]
                        }), t, r ? (0, re.jsx)(ee.A, {}) : null]
                    })
                },
                ie = n(5322),
                ae = n(6593),
                ce = n(17414),
                se = n(18084),
                ue = n(23350),
                le = n(64715),
                de = se.A.getLogger("ScreenStoriesContainer"),
                pe = function(e) {
                    var t = e.setActivationPlace,
                        n = e.setScreenName,
                        r = e.setSrvScreenName,
                        o = e.toggleStretchLayout,
                        i = e.onScreenStoryChange,
                        Z = (0, a.useContext)(ie.P),
                        ee = Z.getUIForScreen,
                        te = Z.getCurrentScreenSettings,
                        ne = Z.getScreenStoryById,
                        se = Z.handleBackClick,
                        pe = Z.currentScreen,
                        fe = (0, a.useMemo)((function() {
                            var e = (null == pe ? void 0 : pe.id) === le.Y ? null : ne(null == pe ? void 0 : pe.id);
                            return pe && !e && de.warn("App is trying to access not existing screen story", {
                                screen: pe
                            }), e
                        }), [pe, ne]),
                        me = (0, a.useMemo)((function() {
                            return function(e) {
                                switch (e) {
                                    case 124:
                                        return {
                                            component: L,
                                            mapping: _.ji,
                                            hideNavigation: !0,
                                            routeName: A.x.LANDING
                                        };
                                    case 127:
                                        return {
                                            component: $,
                                            mapping: _.dm,
                                            hideNavigation: !1,
                                            routeName: A.x.ONBOARDING_EMAIL
                                        };
                                    case 128:
                                        return {
                                            component: V,
                                            mapping: _.Xd,
                                            hideNavigation: !1,
                                            routeName: A.x.ONBOARDING_PHONE
                                        };
                                    case 143:
                                        return {
                                            hideNavigation: !1,
                                            component: D,
                                            mapping: N.G,
                                            routeName: A.x.PHONE_CALL_EXPLANATION
                                        };
                                    case 133:
                                        return {
                                            hideNavigation: !0,
                                            component: w,
                                            mapping: N.e,
                                            routeName: A.x.PHONE_CALL
                                        };
                                    case 129:
                                        return {
                                            hideNavigation: !1,
                                            component: O,
                                            mapping: s.l,
                                            routeName: A.x.SCREEN_STORIES_FORGOT_PASSWORD_PIN
                                        };
                                    case 136:
                                        return {
                                            hideNavigation: !0,
                                            component: E,
                                            mapping: l.r,
                                            routeName: A.x.SCREEN_STORIES_MANUAL_LOCATION
                                        };
                                    case 140:
                                        return {
                                            hideNavigation: !0,
                                            component: j,
                                            mapping: d.g,
                                            routeName: A.x.PLEDGE
                                        };
                                    case 125:
                                        return {
                                            hideNavigation: !1,
                                            component: R,
                                            mapping: p.y,
                                            routeName: A.x.SCREEN_STORIES_NAME
                                        };
                                    case 212:
                                        return {
                                            hideNavigation: !0,
                                            component: C,
                                            mapping: v.j,
                                            routeName: A.x.SCREEN_STORIES_WALKTHROUGH
                                        };
                                    case 458:
                                        return {
                                            hideNavigation: !1,
                                            component: k,
                                            mapping: f.uU,
                                            routeName: A.x.SCREEN_STORIES_PHOTOS
                                        };
                                    case 460:
                                        return {
                                            hideNavigation: !1,
                                            component: P,
                                            mapping: b.V,
                                            routeName: A.x.SCREEN_STORIES_PHOTOS_SOURCE
                                        };
                                    case 278:
                                        return {
                                            hideNavigation: !1,
                                            component: T,
                                            mapping: u.k,
                                            routeName: A.x.INTENTIONS
                                        };
                                    case 147:
                                        return {
                                            hideNavigation: !0,
                                            component: I,
                                            mapping: y.j,
                                            routeName: A.x.AGE_BLOCKER
                                        };
                                    case 400:
                                        return {
                                            hideNavigation: !0,
                                            component: B,
                                            mapping: m.tu,
                                            routeName: A.x.USER_BLOCKED
                                        };
                                    case 504:
                                        return {
                                            hideNavigation: !1,
                                            mapping: m.tu,
                                            component: U,
                                            routeName: A.x.USER_BLOCKED_APPEAL_INITIAL
                                        };
                                    case 506:
                                        return {
                                            hideNavigation: !1,
                                            mapping: m.tu,
                                            component: q,
                                            routeName: A.x.USER_BLOCKED_APPEAL_GUIDELINES
                                        };
                                    case 508:
                                        return {
                                            hideNavigation: !1,
                                            mapping: m.tu,
                                            component: z,
                                            routeName: A.x.USER_BLOCKED_APPEAL_FINAL
                                        };
                                    case 560:
                                        return {
                                            hideNavigation: !1,
                                            mapping: m.tu,
                                            component: G,
                                            routeName: A.x.RES_APPEAL_SUCCESS
                                        };
                                    case 411:
                                        return {
                                            hideNavigation: !1,
                                            mapping: m.tu,
                                            component: M,
                                            routeName: A.x.USER_BLOCKED_APPEAL_PROGRESS
                                        };
                                    case 523:
                                        return {
                                            hideNavigation: !0,
                                            mapping: g.dN,
                                            component: H,
                                            routeName: A.x.CONTENT_MODERATED
                                        };
                                    case 535:
                                        return {
                                            hideNavigation: !0,
                                            mapping: g.oY,
                                            component: F,
                                            routeName: A.x.CONTENT_MODERATED_EMAIL
                                        };
                                    case 537:
                                        return {
                                            hideNavigation: !0,
                                            mapping: g.uY,
                                            component: Y,
                                            routeName: A.x.CONTENT_MODERATED_DISPUTED
                                        };
                                    case 396:
                                        return {
                                            hideNavigation: !0,
                                            mapping: h.lY,
                                            component: K,
                                            routeName: A.x.USER_WARNING
                                        };
                                    case 398:
                                        return {
                                            hideNavigation: !0,
                                            mapping: h.dc,
                                            component: W,
                                            routeName: A.x.USER_WARNING_SUCCESS
                                        };
                                    case 562:
                                        return {
                                            hideNavigation: !0,
                                            mapping: x.h,
                                            component: X,
                                            routeName: A.x.ADD_PASSKEY
                                        };
                                    case 583:
                                        return {
                                            hideNavigation: !0,
                                            mapping: S.b,
                                            component: Q,
                                            routeName: A.x.LANDING
                                        };
                                    default:
                                        return null
                                }
                            }(null == pe ? void 0 : pe.type)
                        }), [pe]),
                        he = (0, a.useCallback)((function() {
                            (0, c.sx)(332, {
                                element: 52
                            }), se()
                        }), [se]);
                    (0, a.useEffect)((function() {
                        i && i(null == pe ? void 0 : pe.type)
                    }), [pe]), (0, a.useEffect)((function() {
                        r(null == fe ? void 0 : fe.srv_screen_name)
                    }), [fe]);
                    return (0, re.jsx)(ae.A, {
                        children: (0, re.jsx)(a.Suspense, {
                            fallback: (0, re.jsx)(ue.Ay, {}),
                            children: function() {
                                var e = null == me ? void 0 : me.component,
                                    i = null == me ? void 0 : me.hideNavigation;
                                if (!fe || !pe || !e) return null;
                                if (i) return (0, re.jsx)(e, {
                                    setActivationPlace: t,
                                    setScreenName: n,
                                    setSrvScreenName: r,
                                    toggleStretchLayout: o
                                });
                                var a = ee(null == me ? void 0 : me.mapping, fe) || {},
                                    c = a[ce.qG],
                                    s = a[ce.A3],
                                    u = te(null == pe ? void 0 : pe.id).isBackPermitted,
                                    l = void 0;
                                null != c && c.progress && (l = c.progress.goal ? c.progress.progress / c.progress.goal * 100 : c.progress.progress);
                                var d = u ? [{
                                    type: J.X2.BACK,
                                    onClick: he
                                }] : [];
                                return (0, re.jsx)(oe, {
                                    title: null == s ? void 0 : s.text,
                                    progressValue: l,
                                    navigationActions: d,
                                    children: (0, re.jsx)(e, {
                                        setActivationPlace: t,
                                        setScreenName: n,
                                        setSrvScreenName: r,
                                        toggleStretchLayout: o
                                    })
                                })
                            }()
                        })
                    })
                },
                fe = n(40802);

            function me(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function he(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var r = n.call(e, t || "default");
                            if ("object" != typeof r) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function ge(e, t) {
                return ge = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, ge(e, t)
            }
            var ve = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this, t) || this).activationPlace = 56, n.notificationScreenAccess = 3, n.screenName = 149, n._lastTrackedScreenName = void 0, n.getScreenName = function() {
                            return n.screenName || 149
                        }, n.setScreenName = function(e) {
                            var t = n.screenName;
                            n.screenName = e, t && t !== e && n.onScreenNameChange()
                        }, n.setSrvScreenName = function(e) {
                            n.srvScreenName = e
                        }, n.setActivationPlace = function(e) {
                            n.activationPlace = e
                        }, n.toggleStretchLayout = function() {
                            n.setState((function(e) {
                                return {
                                    stretchLayout: !e.stretchLayout
                                }
                            }))
                        }, n.handleScreenStoryChange = function(e) {
                            var t, r = null == (t = fe.q.find((function(t) {
                                return t.screenStoryType === e
                            }))) ? void 0 : t.name;
                            n.setState((function() {
                                return {
                                    screenId: e,
                                    routeName: r
                                }
                            }))
                        }, n.state = {
                            stretchLayout: !1,
                            routeName: "",
                            screenId: void 0
                        }, n
                    }
                    var n, r;
                    r = e, (n = t).prototype = Object.create(r.prototype), n.prototype.constructor = n, ge(n, r);
                    var i = t.prototype;
                    return i.trackHotPanelScreen = function() {
                        this._lastTrackedScreenName !== this.screenName && (0, c.sx)(49, {
                            screen_option: this.screenOption ? this.screenOption : void 0
                        }), this._lastTrackedScreenName = this.screenName
                    }, i.shouldShowTabBar = function() {
                        return !1
                    }, i.render = function() {
                        var e, t = this.props,
                            n = this.state,
                            r = o()(((e = {})[n.routeName] = !0, e["not-stretched-layout"] = n.stretchLayout, e));
                        return this.addPageWrapper((0, re.jsx)(pe, function(e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var n = null != arguments[t] ? arguments[t] : {};
                                t % 2 ? me(Object(n), !0).forEach((function(t) {
                                    he(e, t, n[t])
                                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : me(Object(n)).forEach((function(t) {
                                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                                }))
                            }
                            return e
                        }({
                            setScreenName: this.setScreenName,
                            setSrvScreenName: this.setSrvScreenName,
                            setActivationPlace: this.setActivationPlace,
                            toggleStretchLayout: this.toggleStretchLayout,
                            onScreenStoryChange: this.handleScreenStoryChange
                        }, t)), r, {
                            "data-qa-screen-id": this.state.screenId
                        })
                    }, t
                }(i.A),
                ye = ve
        },
        74703: function(e, t, n) {
            n.d(t, {
                j: function() {
                    return r
                }
            });
            var r = (0, n(17414).Qr)({
                img: "img",
                header: "header",
                body: "body",
                btn_yes: "btnYes",
                btn_no: "btnNo"
            })
        },
        76709: function(e, t, n) {
            n.d(t, {
                j: function() {
                    return r
                }
            });
            var r = (0, n(17414).Qr)({
                img: "img",
                header: "header",
                body: "body",
                footer: "footer",
                btn: "btn"
            })
        },
        80051: function(e, t, n) {
            n.d(t, {
                l: function() {
                    return o
                }
            });
            var r = n(17414),
                o = (0, r.Qr)({
                    1: r.qG,
                    2: r.A3,
                    3: "subheader",
                    4: "timer",
                    5: r.Pf,
                    6: "pin",
                    7: "changeNumber",
                    8: "timerFallback",
                    9: "inputPrefix",
                    10: "confirmation"
                });
            (0, r.Qr)({
                1: "header",
                2: "message",
                3: "button"
            })
        },
        83852: function(e, t, n) {
            var r = n(74848),
                o = n(46942),
                i = n.n(o),
                a = n(93827);
            t.A = ({
                text: e,
                isDisabled: t,
                onClick: n,
                innerRef: o,
                dataQA: c
            }) => {
                const s = i()({
                    "csms-navigation-bar__button-text": !0,
                    "csms-navigation-bar__button-text--is-disabled": t
                });
                return (0, r.jsx)("button", {
                    className: s,
                    onClick: t ? void 0 : n,
                    ref: o,
                    "data-qa": "navbar-link",
                    "aria-disabled": t,
                    type: "button",
                    ...c,
                    children: (0, r.jsx)(a.Qi, {
                        children: e
                    })
                })
            }
        },
        85246: function(e, t, n) {
            n.d(t, {
                g: function() {
                    return o
                }
            });
            var r = n(17414),
                o = (0, r.Qr)({
                    progress: r.qG,
                    header: "header",
                    body: "body",
                    link: "link",
                    btn_accept: r.Pf
                })
        },
        89730: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return a
                }
            });
            n(60739);
            var r = n(79860),
                o = n(44851),
                i = "mw_unknown_error";

            function a(e) {
                var t, n, a = e.error;
                "badoo.bma.ServerErrorMessage" === (null == a ? void 0 : a.$gpb) && (n = a.toJSON ? a.toJSON() : a);
                var c, s = (null == (t = n) ? void 0 : t.error_id) || i;
                e.isExpected ? c = 11 : e.isOther ? c = 12 : n && (c = o.A.getType(a.type)), (0, r.sx)(216, {
                    error_id: s,
                    error_type: "number" == typeof c ? c : void 0
                }), (0, r.bX)()
            }
        },
        93100: function(e, t, n) {
            n.d(t, {
                r: function() {
                    return r
                }
            });
            var r = 6
        },
        93529: function(e, t, n) {
            n.d(t, {
                s: function() {
                    return s.s
                },
                A: function() {
                    return u
                }
            });
            var r = n(23149),
                o = n(40075),
                i = n(65297),
                a = n(18084),
                c = n(89730),
                s = n(11680);
            a.A.getLogger("ClientGeneratedNotification");
            var u = function() {
                function e(e) {
                    this.type = void 0, this.text = void 0, this.redirectPage = void 0, this.productType = void 0, this.picture = void 0, this.progress = void 0, this.promoBlock = void 0, e = (0, r.A)(e) ? e : {}, this.type = function(e) {
                        return e.type in s.s ? e.type : null
                    }(e), this.text = function(e) {
                        return "string" == typeof e.text ? e.text : e.type === s.s.ERROR ? o.Ay.get(1083) : ""
                    }(e), this.redirectPage = function(e) {
                        if ((0, r.A)(e.redirectPage)) {
                            var t = e.redirectPage,
                                n = {};
                            return t.redirectPage && (n.redirect_page = t.redirectPage), t.userId && (n.user_id = t.userId), t.token && (n.token = t.token), t.commonPlaceId && (n.common_place_id = t.commonPlaceId), t.sectionId && (n.section_id = t.sectionId), n
                        }
                    }(e), this.productType = e.productType, this.promoBlock = e.promoBlock, this.picture = e.picture, this.progress = e.progress
                }
                return e.showNotification = function(t) {
                    var n = new e(t);
                    t.type !== s.s.ERROR || t.text && t.text !== o.Ay.get(1083) || (0, c.A)({
                        isOther: !0
                    }), i.A.trigger(i.A.SHOW_NOTIFICATION, n)
                }, e.updateNotification = function(e) {
                    i.A.trigger(i.A.UPDATE_NOTIFICATION, e)
                }, e
            }();
            u.TYPES = s.s
        },
        98334: function(e, t, n) {
            n.d(t, {
                k: function() {
                    return o
                }
            });
            var r = n(17414),
                o = (0, r.Qr)({
                    progress: r.qG,
                    title: "title",
                    text: "text",
                    tiw: "tiw",
                    use_as_search_filter: "use_as_search_filter",
                    cta_continue: "cta_continue"
                })
        }
    }
]);
//# sourceMappingURL=screen-stories-controller.28717f9b7da697587863.js.map
"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [7397], {
        24867: function(e, t, n) {
            var i;
            n.d(t, {
                    T: function() {
                        return i
                    }
                }),
                function(e) {
                    e.MODAL = "modal", e.ACTION_SHEET = "action-sheet"
                }(i || (i = {}))
        },
        39778: function(e, t, n) {
            var i = n(96540),
                r = n(65736),
                o = n(33736),
                u = n(40075),
                l = n(74848);
            t.A = function(e) {
                var t = e.header,
                    n = e.message,
                    s = e.confirmLabel,
                    c = e.cancelLabel,
                    a = e.isOpen,
                    f = e.onConfirm,
                    d = e.onCancel,
                    v = e.dataQa,
                    m = (0, i.useState)(a),
                    h = m[0],
                    p = m[1],
                    b = (0, i.useRef)(void 0),
                    E = function(e) {
                        p(!1), b.current = e
                    };
                return (0, i.useEffect)((function() {
                    p(a)
                }), [a]), a ? (0, l.jsxs)(r.A, {
                    wrapperType: r.T.ACTION_SHEET,
                    header: t || n ? {
                        title: t,
                        text: n
                    } : void 0,
                    isVisible: h,
                    onAnimationOutComplete: function() {
                        "confirm" === b.current ? f() : "cancel" === b.current && d(), b.current = void 0
                    },
                    dataQA: v,
                    onDismiss: function() {
                        return E("cancel")
                    },
                    hasDefaultDismissButton: !1,
                    children: [(0, l.jsx)(o.A, {
                        type: "destructive",
                        text: s || u.Ay.get(372),
                        onClick: function() {
                            return E("confirm")
                        }
                    }), (0, l.jsx)(o.A, {
                        type: "generic",
                        text: c || u.Ay.get(371),
                        onClick: function() {
                            return E("cancel")
                        }
                    })]
                }) : null
            }
        },
        40289: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return r
                }
            });
            n(50113), n(51629), n(23418), n(74423), n(26099), n(21699), n(47764), n(98992), n(72577);

            function i(e) {
                [].forEach((function(t) {
                    null == t || t.toggleAttribute("inert", e), null == t || t.toggleAttribute("aria-hidden", e)
                }))
            }
            var r = function() {
                function e(e) {
                    this.contentWrapper = void 0, this.focusedElBeforeOpen = void 0, this.focusableElements = void 0, this.firstFocusableElement = void 0, this.lastFocusableElement = void 0, this.hasEventListener = void 0, this.onDismiss = void 0, this.noKeyHandlers = void 0, this.contentWrapper = null == e ? void 0 : e.contentWrapper, this.onDismiss = null == e ? void 0 : e.onDismiss, this.noKeyHandlers = null == e ? void 0 : e.noKeyHandlers, this.rememberFocusedElement(), this.handleKeyDown = this.handleKeyDown.bind(this)
                }
                var t = e.prototype;
                return t.updateFocusableElements = function(e) {
                    e && e !== this.contentWrapper && (this.contentWrapper = e);
                    var t = function(e) {
                        if (e) {
                            for (var t = Array.from(e.querySelectorAll('a[href], area[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), [tabindex]:not([tabindex="-1"])')), n = Array.from(e.querySelectorAll('[inert] a[href], [inert] area[href], [inert] input:not([disabled]), [inert] select:not([disabled]), [inert] textarea:not([disabled]), [inert] button:not([disabled]), [inert] [tabindex]:not([tabindex="-1"])')), i = {}, r = [], o = 0; o < t.length; o++) {
                                var u = t[o],
                                    l = u.name;
                                l || n.includes(u) ? i[l] || n.includes(u) || (r.push(u), i[l] = !0) : r.push(u)
                            }
                            return r
                        }
                        return []
                    }(this.contentWrapper);
                    this.focusableElements = t, this.firstFocusableElement = t[0], this.lastFocusableElement = t[t.length - 1]
                }, t.rememberFocusedElement = function() {
                    this.focusedElBeforeOpen = document.activeElement
                }, t.modalize = function() {
                    i(!0)
                }, t.focusFirstElement = function() {
                    var e, t;
                    null != (e = this.focusableElements) && e.find((function(e) {
                        return e === document.activeElement
                    })) || (null == (t = this.firstFocusableElement) || t.focus())
                }, t.focusWrapper = function() {
                    var e;
                    null == (e = this.contentWrapper) || e.focus()
                }, t.unmount = function() {
                    var e;
                    i(!1), this.toggleFocusTrap(!1), null == (e = this.focusedElBeforeOpen) || e.focus()
                }, t.update = function(e) {
                    this.contentWrapper = e.contentWrapper, this.onDismiss = e.onDismiss, this.noKeyHandlers = e.noKeyHandlers
                }, t.toggleFocusTrap = function(e) {
                    e ? this.hasEventListener || (document.addEventListener("keydown", this.handleKeyDown, !1), this.hasEventListener = !0) : (document.removeEventListener("keydown", this.handleKeyDown, !1), this.hasEventListener = !1)
                }, t.handleKeyDown = function(e) {
                    var t, n, i, r = "Tab" === e.key;
                    if (!this.noKeyHandlers)
                        if ("Escape" !== e.key) {
                            if (r) {
                                var o, u, l = null == (t = document.activeElement) ? void 0 : t.name,
                                    s = null == (n = this.firstFocusableElement) ? void 0 : n.name;
                                if (e.shiftKey) {
                                    if (document.activeElement === this.firstFocusableElement || l && l === s) null == (o = this.lastFocusableElement) || o.focus(), e.preventDefault()
                                } else if (document.activeElement === this.lastFocusableElement) null == (u = this.firstFocusableElement) || u.focus(), e.preventDefault()
                            }
                        } else null == (i = this.onDismiss) || i.call(this)
                }, e
            }()
        },
        65736: function(e, t, n) {
            n.d(t, {
                T: function() {
                    return d.T
                }
            });
            n(52675), n(45700), n(2008), n(51629), n(89572), n(2892), n(67945), n(84185), n(83851), n(81278), n(79432), n(26099), n(98992), n(54520), n(3949), n(23500);
            var i = n(96540),
                r = n(40961),
                o = n(99417),
                u = n(65297),
                l = n(40075),
                s = n(36521),
                c = n(71859),
                a = n(23914),
                f = n(36167),
                d = n(24867),
                v = n(88309),
                m = n(40289),
                h = n(74848);

            function p(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function b(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? p(Object(n), !0).forEach((function(t) {
                        E(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : p(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function E(e, t, n) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var i = n.call(e, t || "default");
                            if ("object" != typeof i) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            t.A = function(e) {
                var t = e.wrapperType,
                    n = void 0 === t ? d.T.MODAL : t,
                    p = e.outerContent,
                    E = e.isPortal,
                    y = void 0 === E || E,
                    A = e.isVisible,
                    g = void 0 === A || A,
                    O = e.isDismissible,
                    D = void 0 === O || O,
                    T = e.hasDefaultDismissButton,
                    k = void 0 === T || T,
                    C = e.onAnimationInComplete,
                    F = e.onAnimationOutComplete,
                    w = e.onDismiss,
                    L = e.focusTarget,
                    j = void 0 === L ? "first-focusable" : L,
                    x = e.navigation,
                    S = e.type,
                    W = (0, i.useRef)(),
                    P = (0, i.useRef)(),
                    H = (0, i.useRef)(new m.A),
                    K = null == x ? void 0 : x.onClickBack,
                    B = (0, i.useRef)(),
                    R = (0, i.useState)("idle"),
                    _ = R[0],
                    I = R[1],
                    M = (0, i.useCallback)((function() {
                        var e;
                        null == (e = H.current) || e.modalize(), u.A.trigger(u.A.BEFORE_SHOW_MODAL), W.current = o.A.requestAnimationFrame((function() {
                            I("visible"), P.current = o.A.setTimeout((function() {
                                var e, t, n;
                                null == C || C(), null == (e = H.current) || e.toggleFocusTrap(!0), "first-focusable" === j ? null == (t = H.current) || t.focusFirstElement() : null == (n = H.current) || n.focusWrapper(), u.A.trigger(u.A.SHOW_MODAL)
                            }), 300)
                        }))
                    }), [j]),
                    q = (0, i.useCallback)((function() {
                        clearTimeout(P.current), W.current && o.A.cancelAnimationFrame(W.current), W.current = o.A.requestAnimationFrame((function() {
                            I("idle"), P.current = o.A.setTimeout((function() {
                                null == F || F()
                            }), 300)
                        }))
                    }), []),
                    N = (0, i.useCallback)((function() {
                        null == w || w(), q()
                    }), [w, q]);
                (0, i.useEffect)((function() {
                    var e = null == H ? void 0 : H.current;
                    return g ? M() : q(),
                        function() {
                            e.unmount(), g && u.A.trigger(u.A.HIDE_MODAL), W.current && o.A.cancelAnimationFrame(W.current), P.current && clearTimeout(P.current)
                        }
                }), [g, q, M]);
                var Y, z, Q, V, G, J, U, X, Z = (0, i.useCallback)((function() {
                    var e;
                    D ? e = N : K && (e = K), null == e || e()
                }), [D, N, K]);

                function $() {
                    var t = (e.navigation || {}).onClickClose;
                    t ? t() : k && N()
                }
                return (0, i.useEffect)((function() {
                    var e;
                    null == (e = H.current) || e.update({
                        onDismiss: Z,
                        contentWrapper: null == B ? void 0 : B.current
                    })
                }), [Z]), (0, i.useEffect)((function() {
                    var e;
                    null == (e = H.current) || e.updateFocusableElements(null == B ? void 0 : B.current)
                })), (0, i.useEffect)((function() {
                    if (D && "fullscreen" !== S) {
                        var e = null == B ? void 0 : B.current,
                            t = 0,
                            n = 0;
                        return null == e || e.addEventListener("touchstart", i), null == e || e.addEventListener("touchmove", r), null == e || e.addEventListener("touchend", o),
                            function() {
                                null == e || e.removeEventListener("touchstart", i), null == e || e.removeEventListener("touchmove", r), null == e || e.removeEventListener("touchend", o)
                            }
                    }

                    function i(e) {
                        var n = s.A.supportsTouch ? e.touches[0] : e;
                        t = n.clientY
                    }

                    function r(e) {
                        var i = s.A.supportsTouch ? e.touches[0] : e;
                        s.A.supportsTouch && e.touches.length > 1 || (t > 0 && i.clientY - t > 0 && u(n = i.clientY - t), e.preventDefault())
                    }

                    function o() {
                        n > 100 ? (u(), q()) : n > 0 && u(0), t = 0, n = 0
                    }

                    function u(t) {
                        e && (e.style.transform = void 0 !== t ? "translateY(" + t + "px)" : "")
                    }
                }), [B, q]), G = {
                    onClickBack: null == (Y = e.navigation) ? void 0 : Y.onClickBack,
                    onClickClose: D && (null != (z = e.navigation) && z.onClickClose || k) ? $ : void 0,
                    a11y: {
                        backLabel: (null == (Q = e.navigation) || null == (Q = Q.a11y) ? void 0 : Q.backLabel) || l.Ay.get(269),
                        closeLabel: (null == (V = e.navigation) || null == (V = V.a11y) ? void 0 : V.closeLabel) || l.Ay.get(270)
                    }
                }, J = b(b({}, e), {}, {
                    animationStatus: _,
                    onDismiss: D ? N : void 0,
                    contentRef: B,
                    navigation: G
                }), U = n === d.T.ACTION_SHEET ? f.A : a.A, X = (0, h.jsxs)(c.A, {
                    children: [(0, h.jsx)(U, b(b({}, J), {}, {
                        children: J.children
                    })), p]
                }), y ? r.createPortal(X, (0, v.A)()) : X
            }
        }
    }
]);
//# sourceMappingURL=7397.6326907b017ce206c5e1.js.map
"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [349], {
        3388: function(e, t, o) {
            var n = o(58544);
            t.A = (0, n.lh)()
        },
        17001: function(e, t, o) {
            o(51629), o(62062), o(69085), o(26099), o(3362), o(98992), o(3949), o(81454), o(23500);
            var n, r = o(73090),
                a = o(15566),
                i = o(23735),
                c = o(79860),
                u = o(33263),
                p = o(58336),
                l = o(31087),
                s = o(58544),
                T = o(3388),
                P = o(64058),
                d = ((n = {})[1] = 1, n[12] = 4, n[9] = 7, n[3] = 6, n[2] = 5, n),
                f = (0, p.A)("PHOTO", "VIDEO"),
                m = (0, p.A)("PHOTO_UPLOADED"),
                A = Object.assign({}, s.zb, {
                    uploadMedia: function(e) {
                        e.mediaType === f.VIDEO ? function(e) {
                            e.photos.forEach((function(t) {
                                var o = {
                                        video_id: t,
                                        num_added: 1,
                                        num_videos: 1
                                    },
                                    n = P.A[e.providerType];
                                void 0 !== n && (o.source = n);
                                var r = d[e.providerType];
                                void 0 !== r && (o.import_source = r), void 0 !== e.activationPlace && (o.activation_place = e.activationPlace), (0, c.sx)(126, o)
                            }))
                        }(e) : function(e) {
                            e.photos.forEach((function(t) {
                                var o = {
                                        photo_id: t
                                    },
                                    n = d[e.providerType];
                                void 0 !== n && (o.photo_import_method = n), void 0 !== e.activationPlace && (o.activation_place = e.activationPlace), (0, c.sx)(19, o)
                            }))
                        }(e);
                        var t = {
                            photos: e.photos.map((function(t) {
                                return u.A.createProtoInstance(a.ryQ, {
                                    external_album_id: e.albumId,
                                    external_provider_id: e.providerId,
                                    photo_id: t,
                                    photo_source: 3
                                })
                            }))
                        };
                        t.album_type = e.albumType, e.requestedByUserId && (t.requested_by_user_id = e.requestedByUserId);
                        var o = u.A.createProtoInstance(a.UYE, t);
                        e.photoToReplace && o.setPhotosToReplace([e.photoToReplace]);
                        return new Promise((function(t, n) {
                            new i.Ay(495, o).on(496, (function(o, a) {
                                if (o) n(o);
                                else {
                                    e.mediaType === f.PHOTO && A.trigger(m.PHOTO_UPLOADED), e.mediaType === f.VIDEO && (r.A.getUser().video_count > 0 || l.A.getInstance().invalidateAll()), T.A.trigger();
                                    var i = a.getAlbum();
                                    t(i)
                                }
                            })).request()
                        }))
                    },
                    MediaType: f,
                    EVENTS: m
                });
            t.A = A
        },
        64266: function(e, t, o) {
            o.d(t, {
                A: function() {
                    return P
                }
            });
            var n, r = o(15566),
                a = o(73090),
                i = o(93529),
                c = o(40075),
                u = o(18084),
                p = o(25093),
                l = 124,
                s = 25,
                T = u.A.getLogger("session");

            function P(e, t) {
                return !! function(e, t) {
                    if (t === l) return !0;
                    return e instanceof r.beZ && ("1" === e.getErrorCode() || e.getType() === s)
                }(e, t) && (function(e) {
                    var t, o = (0, p.A)(e);
                    o && T.error("Attempt to use failed session", {
                        error: e,
                        url: null == (t = window) ? void 0 : t.location.href
                    });
                    if (e instanceof r.beZ && "1002" === e.getErrorCode()) return;
                    if (n && Date.now() < n + 3e4) return void(p.A && T.error("Additional attempt to use failed session, could lead to infinite loader", {
                        error: e
                    }));
                    n = Date.now(), a.A.logout(!0), i.A.showNotification({
                        type: i.A.TYPES.INFO,
                        text: c.Ay.get(521)
                    })
                }(e), !0)
            }
        },
        85608: function(e, t, o) {
            o.d(t, {
                T: function() {
                    return w
                }
            });
            o(52675), o(45700), o(2008), o(50113), o(74423), o(25276), o(23792), o(60739), o(69085), o(79432), o(51629), o(89572), o(2892), o(67945), o(84185), o(83851), o(81278), o(26099), o(3362), o(27495), o(38781), o(47764), o(98992), o(54520), o(72577), o(3949), o(23500), o(62953);
            var n, r, a, i, c, u, p = o(85208),
                l = o(42302),
                s = o(58544),
                T = o(35837),
                P = o(58385),
                d = o(5586),
                f = o(47632),
                m = o(18084),
                A = o(49683),
                g = o(26935),
                E = o(41025),
                y = o(17001),
                _ = o(49952),
                I = o(58336),
                v = o(3208),
                O = o(15566),
                S = o(74389),
                h = o(63620);

            function D(e, t) {
                var o = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), o.push.apply(o, n)
                }
                return o
            }

            function b(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? D(Object(o), !0).forEach((function(t) {
                        k(e, t, o[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : D(Object(o)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t))
                    }))
                }
                return e
            }

            function k(e, t, o) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != typeof e || !e) return e;
                        var o = e[Symbol.toPrimitive];
                        if (void 0 !== o) {
                            var n = o.call(e, t || "default");
                            if ("object" != typeof n) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = o, e
            }
            var N = m.A.getLogger("BannersHelper"),
                R = (0, I.A)("START_PAYMENT", "END_PAYMENT"),
                B = ((n = {})[127] = S.x.ATTENTION_BOOST_EXPLANATION, n[32] = S.x.EXTRA_SHOWS_EXPLANATION, n[28] = S.x.RISEUP_EXPLANATION, n[175] = S.x.BUNDLE_SALE_EXPLANATION, n[226] = S.x.CRUSH_EXPLANATION, n),
                w = {
                    ADD_PHOTO: "add-photo",
                    ATTENTION_BOOST: "attention-boost",
                    BUNDLE_SALE: "bundle-sale",
                    CHAT_WITH_NEWBIES: "chat-with-newbies",
                    CHAT_WITH_TIRED: "chat-with-tired",
                    CRUSH: "crush",
                    ENCOUNTERS: "encounters",
                    EXTRA_SHOWS: "extra-shows",
                    ENABLE_NOTIFICATIONS: "enable-notifications",
                    FAVOURITES: "favourites",
                    GET_VERIFIED: "get-verified",
                    INVISIBLE_MODE: "invisible-mode",
                    LIKED_YOU: "liked-you",
                    LIKED_YOU_PREMIUM_PLUS: "liked-you-premium-plus",
                    MESSENGER_MINI_GAME: "messenger-mini-game",
                    PREMIUM_PLUS: "premium-plus",
                    QUALITY_WALKTHROUGH: "quality-walkthrough",
                    QUESTIONS_IN_PROFILE: "questions-in-profile",
                    RISEUP: "riseup",
                    SPECIAL_DELIVERY: "special-delivery",
                    SPP: "premium",
                    STICKERS: "stickers",
                    UNDO_VOTE: "undo",
                    VIDEO_CHAT: "video-chat-explanation"
                },
                U = ((r = {})[326] = w.LIKED_YOU_PREMIUM_PLUS, r[558] = w.PREMIUM_PLUS, r),
                L = ((a = {})[12] = w.ADD_PHOTO, a[56] = w.ATTENTION_BOOST, a[57] = w.BUNDLE_SALE, a[4] = w.CHAT_WITH_NEWBIES, a[5] = w.CHAT_WITH_TIRED, a[96] = w.CRUSH, a[106] = w.ENABLE_NOTIFICATIONS, a[11] = w.EXTRA_SHOWS, a[10] = w.EXTRA_SHOWS, a[6] = w.FAVOURITES, a[35] = w.UNDO_VOTE, a[7] = w.LIKED_YOU, a[38] = w.LIKED_YOU, a[1] = w.RISEUP, a[16] = w.SPECIAL_DELIVERY, a[3] = w.SPECIAL_DELIVERY, a[65] = w.SPP, a[8] = w.SPP, a[22] = w.STICKERS, a[40] = w.SPECIAL_DELIVERY, a[43] = w.UNDO_VOTE, a[37] = w.INVISIBLE_MODE, a[10017] = w.VIDEO_CHAT, a[165] = w.MESSENGER_MINI_GAME, a[68] = w.GET_VERIFIED, a[199] = w.QUALITY_WALKTHROUGH, a[61] = w.ENCOUNTERS, a[326] = w.LIKED_YOU, a[346] = w.QUESTIONS_IN_PROFILE, a[48] = w.SPP, a[195] = null, a[107] = null, a[557] = w.PREMIUM_PLUS, a[558] = w.PREMIUM_PLUS, a),
                F = ((i = {})[1] = 8, i[3] = 59, i[4] = 48, i[5] = 24, i[6] = 10, i[7] = 1, i[12] = 58, i[14] = 64, i[16] = 27, i[18] = 58, i[20] = 7, i[21] = 56, i[22] = 57, i[23] = 65, i[25] = 96, i),
                x = ((c = {})[21] = 127, c[22] = 175, c[25] = 226, c[6] = 32, c[7] = 28, c[66] = 415, c[1] = 19, c[23] = 19, c[47] = 324, c[13] = 38, c),
                M = ((u = {})[96] = 76, u),
                C = (0, p.A)({}, s.zb, {
                    EVENTS: R,
                    getFeatureName: function(e, t) {
                        var o;
                        return void 0 === t && (t = !1), t && (o = U[e]), o || (o = L[e]), void 0 === o && N.error("Invalid PROMO_BLOCK_TO_FEATURE_NAME_MAPPING", {
                            promoBlockType: e
                        }), o
                    },
                    getButtonName: function(e) {
                        return M[e]
                    },
                    getFeatureFromPaymentProductType: function(e) {
                        var t = x[e];
                        return t || N.error("Invalid PRODUCT_TYPE_TO_FEATURE_MAPPING", {
                            paymentProductType: e
                        }), t
                    },
                    isFeatureConfigurable: function(e) {
                        return Boolean(e) && 19 !== e && 324 !== e
                    },
                    unifyPromoType: function(e) {
                        switch (e) {
                            case 3:
                            case 16:
                            case 40:
                                return 40;
                            case 43:
                            case 35:
                                return 43;
                            default:
                                return e
                        }
                    },
                    getBadgeTypeForPromoBlock: function(e) {
                        return f.A.getBadgeTypeFromPromoBlock(e)
                    },
                    getPromoBlockForProduct: function(e) {
                        var t = F[e];
                        return t || N.error("Invalid PRODUCT_TO_PROMO_BLOCK", {
                            productType: e
                        }), t
                    },
                    getPictureForPromoBlock: function(e, t) {
                        var o = function(e, t) {
                            t = t || 0;
                            var o = e.getPictures(),
                                n = o && e.getPictures()[t];
                            if (o && (t < 0 || t >= o.length)) return null;
                            return n ? n.getDisplayImages() : e.getImageId() && e.getImageId()[t]
                        }(e, t.index);
                        return o ? {
                            disableMasking: H(e.getPromoBlockType()),
                            type: f.A.IMAGE_TYPE.URL,
                            value: o
                        } : f.A.getPlaceholderForGender(t.gender)
                    },
                    getPictureForPromoBlockTS: function(e, t) {
                        var o = function(e, t) {
                            var o;
                            void 0 === t && (t = 0);
                            var n = e.pictures,
                                r = null == n ? void 0 : n[t];
                            if (n && (t < 0 || t >= n.length)) return null;
                            return r ? r.display_images : null == (o = e.image_id) ? void 0 : o[t]
                        }(e, t.index);
                        return o ? {
                            disableMasking: H(e.promo_block_type),
                            type: f.A.IMAGE_TYPE.URL,
                            value: o
                        } : f.A.getPlaceholderForGender(t.gender)
                    },
                    buyCrush: function(e, t, o) {
                        var n = {
                                from: P.A.getUrl()
                            },
                            r = {
                                userId: e,
                                productType: 25
                            };
                        return A.A.getInstance().fetchProductExplanation(25, e).then((function(e) {
                            var a = (0, T.A)(e);
                            if (o) {
                                var i = a.getPromo().getPictures([])[0];
                                if (i) {
                                    var c = i.getDisplayImages(),
                                        u = o.getLargeUrl(c);
                                    i.setDisplayImages(u)
                                }
                            }
                            return V({
                                hotPanelData: t,
                                context: n,
                                params: r,
                                clientProductExplanation: a,
                                onAction: l.A
                            })
                        }))
                    },
                    handlePromoSelected: function(e, t, o) {
                        var n, r = e.productType;
                        r && (n = C.getFeatureFromPaymentProductType(r));
                        var a = e.action,
                            i = e.activationPlace,
                            c = e.cost,
                            u = !!e.paymentTransitionInFlow,
                            s = e.popState,
                            f = C.unifyPromoType(e.banner),
                            m = C.isFeatureConfigurable(n),
                            y = e.crossSellTransaction;
                        (t = t || {}).from || N.warn('No "from" parameter given to BannersController. What should we do once payment is completed?');
                        var I = (o = o || {}).onAction || l.A;
                        41 === f && (r = 13, n = 38);
                        var O = {
                                activationPlace: i,
                                cost: c,
                                promoBlockType: f
                            },
                            D = (0, p.A)(O, e.hotPanelData || {});
                        switch (v.A.generate(), a) {
                            case 60:
                                ! function(e) {
                                    var t, o = e.context,
                                        n = e.cost,
                                        r = e.crossSellTransaction,
                                        a = e.hotPanelData,
                                        i = e.paymentTransitionInFlow,
                                        c = e.popState,
                                        u = e.productType,
                                        p = e.onAction,
                                        l = null == r || null == (t = r.purchase_params) ? void 0 : t.cross_sell_order_id;
                                    if (!l) return void N.error("Trying to perform cross/pack without required transaction id", {
                                        context: o,
                                        hotPanelData: a
                                    });
                                    var s = new Promise((function(e) {
                                            return (0, _.cj)(e)
                                        })),
                                        T = new Promise((function(e) {
                                            g.A.purchase({
                                                back: o.from,
                                                cost: n,
                                                hotPanelData: a,
                                                paymentTransitionInFlow: i,
                                                popState: c,
                                                productType: u,
                                                purchaseTransactionSetup: {
                                                    crossSellOrderId: l,
                                                    uid: r.uid,
                                                    providerId: r.provider_id
                                                },
                                                complete: function(t, n) {
                                                    C.trigger(R.END_PAYMENT, o, {
                                                        isSuccess: t,
                                                        cancelled: n
                                                    }), e(t)
                                                }
                                            })
                                        }));
                                    Promise.race([s, T]).then((function() {
                                        p(60)
                                    }))
                                }({
                                    context: t,
                                    cost: c,
                                    crossSellTransaction: y,
                                    hotPanelData: D,
                                    paymentTransitionInFlow: u,
                                    popState: s,
                                    productType: r,
                                    onAction: I
                                });
                                break;
                            case 9:
                                ! function(e) {
                                    var t = e.context,
                                        o = e.cost,
                                        n = e.hotPanelData,
                                        r = e.paymentTransitionInFlow,
                                        a = e.popState,
                                        i = e.productType,
                                        c = e.promoBlockType,
                                        u = e.onAction,
                                        p = null,
                                        l = new Promise((function(e) {
                                            return (0, _.cj)(e)
                                        }));
                                    C.trigger(R.START_PAYMENT, t), p = Y(i) ? new Promise((function(e) {
                                        g.A.purchase({
                                            back: t.from,
                                            cost: o,
                                            hotPanelData: n,
                                            paymentTransitionInFlow: r,
                                            popState: a,
                                            productType: i,
                                            promoBlockType: c,
                                            complete: function(o) {
                                                C.trigger(R.END_PAYMENT, t), e(o)
                                            }
                                        })
                                    })) : new Promise((function(e) {
                                        var p = {
                                                back: t.from,
                                                cost: o,
                                                productType: i,
                                                hotPanelData: n,
                                                promoBlockType: c,
                                                callback: function(t) {
                                                    W(t, {
                                                        productType: i,
                                                        onAction: u
                                                    }), e(t)
                                                }
                                            },
                                            l = {
                                                paymentTransitionInFlow: r,
                                                replace: a
                                            };
                                        E.A.navigateToPayment(p, l)
                                    }));
                                    Promise.race([l, p]).then((function() {
                                        u(60)
                                    }))
                                }({
                                    context: t,
                                    cost: c,
                                    hotPanelData: D,
                                    paymentTransitionInFlow: u,
                                    popState: s,
                                    productType: r,
                                    promoBlockType: f,
                                    onAction: I
                                });
                                break;
                            case 4:
                                ! function(e) {
                                    var t = e.context,
                                        o = e.cost,
                                        n = e.featureType,
                                        r = e.hotPanelData,
                                        a = e.isFeatureConfigurable,
                                        i = e.paymentTransitionInFlow,
                                        c = e.popState,
                                        u = e.productToActivate,
                                        p = e.productType,
                                        l = e.promoBlockType,
                                        s = e.promoData,
                                        P = e.onAction;
                                    if (C.trigger(R.START_PAYMENT, t), Y(p)) a ? A.A.getInstance().fetchProductExplanation(p).then((function(e) {
                                        var o = (0, T.A)(e);
                                        V({
                                            hotPanelData: r,
                                            context: t,
                                            params: s,
                                            clientProductExplanation: o,
                                            onAction: P
                                        })
                                    })).then((function() {
                                        P(60), 1 === p && P(6)
                                    })).catch((function(e) {
                                        if (P(60), e instanceof Error) throw e
                                    })) : j({
                                        feature: n,
                                        params: {
                                            cost: o,
                                            hotPanelData: r,
                                            popState: c,
                                            productType: p,
                                            promoBlockType: l
                                        },
                                        context: t,
                                        onAction: P
                                    }).then((function() {
                                        P(60), 1 === p && P(6)
                                    })).catch((function() {
                                        P(60)
                                    }));
                                    else {
                                        var d, f = new Promise((function(e) {
                                                (0, _.cj)(e)
                                            })),
                                            m = new Promise((function(e) {
                                                d = e
                                            })),
                                            g = {
                                                back: t.from,
                                                cost: o,
                                                hotPanelData: r,
                                                paymentTransitionInFlow: i,
                                                productToActivate: u,
                                                productType: p,
                                                promoBlockType: l,
                                                callback: function(e) {
                                                    W(e, {
                                                        productType: p,
                                                        onAction: P
                                                    }), d()
                                                }
                                            },
                                            y = {};
                                        c && (y.replace = c), E.A.navigateToPayment(g, y), Promise.race([f, m]).then((function() {
                                            P(60)
                                        }))
                                    }
                                }({
                                    context: t,
                                    cost: c,
                                    featureType: n,
                                    hotPanelData: D,
                                    isFeatureConfigurable: m,
                                    paymentTransitionInFlow: u,
                                    popState: s,
                                    productToActivate: e.productToActivate,
                                    productType: r,
                                    promoBlockType: f,
                                    promoData: e,
                                    onAction: I
                                });
                                break;
                            case 2:
                                (0, _.cj)((function() {
                                    return I(60)
                                })), G(e).then((function() {
                                    I(2)
                                }));
                                break;
                            case 63:
                                (0, _.cj)((function() {
                                    return I(60)
                                })),
                                function(e) {
                                    var t = e.redirectPage,
                                        o = e.redirectPageParams,
                                        n = b(b({}, e), o),
                                        r = d.A.getRouteFromRedirectPage(t.toJSON());
                                    P.A.navigate(r, !!e.popState, n)
                                }(e);
                                break;
                            case 13:
                                (0, _.cj)((function() {
                                    return I(60)
                                })), P.A.navigate(S.x.OWN_PROFILE_EDIT, {
                                    anchor: h.l.VERIFICATION
                                });
                                break;
                            case 52:
                                (0, _.cj)((function() {
                                    return I(60)
                                })), P.A.navigate(S.x.SHARE_PROFILE, e.navigateOpts);
                                break;
                            case 6:
                                ! function(e) {
                                    var t = e.context,
                                        o = e.productType,
                                        n = e.paymentTransitionInFlow,
                                        r = e.hotPanelData,
                                        a = e.promoBlockType,
                                        i = e.onAction,
                                        c = e.popState;
                                    C.trigger(R.START_PAYMENT, t);
                                    var u, p = new Promise((function(e) {
                                            (0, _.cj)(e)
                                        })),
                                        l = new Promise((function(e) {
                                            u = e
                                        })),
                                        s = {
                                            back: t.from,
                                            productType: o,
                                            paymentTransitionInFlow: n,
                                            hotPanelData: r,
                                            promoBlockType: a,
                                            callback: function(e) {
                                                W(e, {
                                                    productType: o,
                                                    onAction: i
                                                }), u()
                                            }
                                        },
                                        T = {};
                                    c && (T.replace = c);
                                    E.A.navigateToPayment(s, T), Promise.race([p, l]).then((function() {
                                        i(60)
                                    }))
                                }({
                                    context: t,
                                    hotPanelData: D,
                                    paymentTransitionInFlow: u,
                                    popState: s,
                                    productType: r,
                                    promoBlockType: f,
                                    onAction: I
                                });
                                break;
                            case 100:
                                C.trigger(R.START_PAYMENT, t), P.A.navigate(S.x.SPP_TRIAL, !1, {
                                    returnTo: t.from,
                                    context: t.context,
                                    activationPlace: i,
                                    fromBanner: !0
                                });
                                break;
                            default:
                                N.error("Unknown action type", {
                                    actionType: a,
                                    context: t,
                                    params: o,
                                    promoData: e
                                })
                        }
                    },
                    getActionTypeFromPromoBlock: function(e, t) {
                        t = t || {};
                        var o = e.getOkAction();
                        if (!o) {
                            var n, r = e.getButtons([]);
                            if (r.length > 0)(n = t.ctaType ? r.find((function(e) {
                                return e.getType() === t.ctaType
                            })) : r[0]) instanceof O.E0i && (o = n.getAction())
                        }
                        return o || t.defaultActionType
                    },
                    getRedirectPageFromPromoBlock: function(e, t) {
                        t = t || {};
                        var o = e.getRedirectPage();
                        if (!o) {
                            var n, r = e.getButtons([]);
                            if (r.length > 0)(n = t.ctaType ? r.find((function(e) {
                                return e.getType() === t.ctaType
                            })) : r.find((function(e) {
                                return e.hasRedirectPage()
                            }))) instanceof O.E0i && (o = n.getRedirectPage())
                        }
                        return o
                    },
                    getTrackingData: function(e, t) {
                        var o = {},
                            n = e.getPromoBlockType && e.getPromoBlockType() || e.promo_block_type,
                            r = e.getPromoBlockPosition && e.getPromoBlockPosition() || e.promo_block_position,
                            a = e.getVariantId && e.getVariantId(),
                            i = e.getContext && e.getContext() || e.context,
                            c = function(e) {
                                void 0 === e && (e = {});
                                var t = e.getCallToActionType && e.getCallToActionType() || e.call_to_action_type;
                                if (!t) {
                                    var o = (e.getButtons && e.getButtons() || e.buttons || [])[0] || {};
                                    t = o.getType && o.getType() || o.type || null || 1
                                }
                                return t
                            }(e),
                            u = {
                                banner_id: n,
                                position_id: r,
                                context: i,
                                variation_id: a
                            };
                        return 138 === t && (o = u), 139 === t && (o = b(b({}, u), {}, {
                            call_to_action_type: c
                        })), o
                    }
                });

            function H(e) {
                return [65, 41, 57].includes(e)
            }

            function j(e) {
                var t = e.feature,
                    o = e.params,
                    n = e.context,
                    r = e.onAction;
                return r = r || l.A, new Promise((function(e, a) {
                    if (o && o.promoBlock instanceof O.d4N && function(e) {
                            return e && 2 === e.getOkAction()
                        }(o.promoBlock)) return a(new Error("Photos are required to continue with this action")), G({
                        feature: t,
                        back: n.from
                    }).then((function() {
                        r && r(2)
                    }));
                    if (o.isSkipExplanationScreen || -1 === Object.keys(B).indexOf(t.toString())) {
                        var i = o.cost,
                            c = o.promoBlock,
                            u = o.productType,
                            p = o.promoBlockType;
                        u = u || c && c.getOkPaymentProductType(), p = p || c && c.getPromoBlockType(), g.A.purchase({
                            back: n.from,
                            cost: i,
                            hotPanelData: o.hotPanelData,
                            popState: o.popState,
                            productType: u,
                            promoBlockType: p,
                            userId: o.userId,
                            success: function(t) {
                                return e(t)
                            },
                            error: function(e) {
                                return a(e)
                            },
                            complete: function() {
                                return C.trigger(R.END_PAYMENT, n)
                            }
                        })
                    } else {
                        var l = B[t],
                            s = {
                                promoBlock: o.promoBlock.toJSON(),
                                reject: a,
                                resolve: e,
                                userId: o.userId
                            };
                        (0, _.cj)((function() {
                            return r(60)
                        })), P.A.navigate(l, o.popState, s)
                    }
                }))
            }

            function Y(e) {
                return 1 !== e && 13 !== e && 47 !== e && 66 !== e
            }

            function V(e) {
                var t = e.hotPanelData,
                    o = e.context,
                    n = e.params,
                    r = e.clientProductExplanation,
                    a = e.onAction,
                    i = r.getPromo(),
                    c = i.getOkPaymentProductType(),
                    u = C.getFeatureFromPaymentProductType(c),
                    p = i.getPaymentAmount();
                return !i.getScreenHeader() && r.getScreenHeader() && i.setScreenHeader(r.getScreenHeader()), Object.assign(n, {
                    cost: p,
                    hotPanelData: t,
                    promoBlock: i
                }), j({
                    feature: u,
                    params: n,
                    context: o,
                    onAction: a
                })
            }

            function G(e) {
                return new Promise((function(t) {
                    P.A.navigate(S.x.ADD_PHOTOS, !1, b(b({}, e), {}, {
                        callback: t
                    })), y.A.once(y.A.EVENTS.PHOTO_UPLOADED, t)
                }))
            }

            function W(e, t) {
                var o = t.productType,
                    n = t.onAction;
                null != e && e.success && 1 === o && n(6)
            }
            t.A = C
        }
    }
]);
//# sourceMappingURL=349.9843cbd4bae028a1358a.js.map
/*! For license information please see 3705.caf11d264229311d4ec7.js.LICENSE.txt */
"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [3705], {
        9417: function(e, n, t) {
            function r(e) {
                if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e
            }
            t.d(n, {
                A: function() {
                    return r
                }
            })
        },
        11734: function(e, n, t) {
            var r = t(74848),
                i = t(87908);
            n.A = ({
                children: e,
                hpadded: n,
                vpadded: t,
                tag: a,
                isSticky: s
            }) => (0, r.jsx)(i.A, {
                align: "bottom",
                hpadded: n,
                vpadded: t,
                tag: a,
                isSticky: s,
                dataQA: {
                    "data-qa": "screen-footer"
                },
                children: e
            })
        },
        21020: function(e, n, t) {
            t(45228);
            var r = t(96540),
                i = 60103;
            if (n.Fragment = 60107, "function" == typeof Symbol && Symbol.for) {
                var a = Symbol.for;
                i = a("react.element"), n.Fragment = a("react.fragment")
            }
            var s = r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
                o = Object.prototype.hasOwnProperty,
                l = {
                    key: !0,
                    ref: !0,
                    __self: !0,
                    __source: !0
                };

            function c(e, n, t) {
                var r, a = {},
                    c = null,
                    u = null;
                for (r in void 0 !== t && (c = "" + t), void 0 !== n.key && (c = "" + n.key), void 0 !== n.ref && (u = n.ref), n) o.call(n, r) && !l.hasOwnProperty(r) && (a[r] = n[r]);
                if (e && e.defaultProps)
                    for (r in n = e.defaultProps) void 0 === a[r] && (a[r] = n[r]);
                return {
                    $$typeof: i,
                    type: e,
                    key: c,
                    ref: u,
                    props: a,
                    _owner: s.current
                }
            }
            n.jsx = c, n.jsxs = c
        },
        54922: function(e, n, t) {
            t.d(n, {
                dw: function() {
                    return s
                },
                p7: function() {
                    return i
                },
                qX: function() {
                    return o
                }
            });
            var r = t(96540);

            function i(e, n) {
                var t = Object.create(null);
                return e && r.Children.map(e, (function(e) {
                    return e
                })).forEach((function(e) {
                    t[e.key] = function(e) {
                        return n && (0, r.isValidElement)(e) ? n(e) : e
                    }(e)
                })), t
            }

            function a(e, n, t) {
                return null != t[n] ? t[n] : e.props[n]
            }

            function s(e, n) {
                return i(e.children, (function(t) {
                    return (0, r.cloneElement)(t, {
                        onExited: n.bind(null, t),
                        in: !0,
                        appear: a(t, "appear", e),
                        enter: a(t, "enter", e),
                        exit: a(t, "exit", e)
                    })
                }))
            }

            function o(e, n, t) {
                var s = i(e.children),
                    o = function(e, n) {
                        function t(t) {
                            return t in n ? n[t] : e[t]
                        }
                        e = e || {}, n = n || {};
                        var r, i = Object.create(null),
                            a = [];
                        for (var s in e) s in n ? a.length && (i[s] = a, a = []) : a.push(s);
                        var o = {};
                        for (var l in n) {
                            if (i[l])
                                for (r = 0; r < i[l].length; r++) {
                                    var c = i[l][r];
                                    o[i[l][r]] = t(c)
                                }
                            o[l] = t(l)
                        }
                        for (r = 0; r < a.length; r++) o[a[r]] = t(a[r]);
                        return o
                    }(n, s);
                return Object.keys(o).forEach((function(i) {
                    var l = o[i];
                    if ((0, r.isValidElement)(l)) {
                        var c = i in n,
                            u = i in s,
                            d = n[i],
                            p = (0, r.isValidElement)(d) && !d.props.in;
                        !u || c && !p ? u || !c || p ? u && c && (0, r.isValidElement)(d) && (o[i] = (0, r.cloneElement)(l, {
                            onExited: t.bind(null, l),
                            in: d.props.in,
                            exit: a(l, "exit", e),
                            enter: a(l, "enter", e)
                        })) : o[i] = (0, r.cloneElement)(l, { in: !1
                        }) : o[i] = (0, r.cloneElement)(l, {
                            onExited: t.bind(null, l),
                            in: !0,
                            exit: a(l, "exit", e),
                            enter: a(l, "enter", e)
                        })
                    }
                })), o
            }
        },
        58168: function(e, n, t) {
            function r() {
                return r = Object.assign ? Object.assign.bind() : function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var t = arguments[n];
                        for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r])
                    }
                    return e
                }, r.apply(this, arguments)
            }
            t.d(n, {
                A: function() {
                    return r
                }
            })
        },
        68072: function(e, n, t) {
            var r = t(74848),
                i = t(84362);
            n.A = ({
                children: e,
                onClick: n,
                tag: t = "div",
                a11y: a
            }) => {
                const s = t,
                    o = n ? "button" : "span";
                return (0, r.jsx)(s, {
                    className: "csms-navigation-bar__logo",
                    "aria-hidden": a ? .ariaHidden || void 0,
                    id: "navigation-logo",
                    children: (0, r.jsxs)(o, {
                        className: "csms-navigation-bar__logo-action",
                        onClick: n,
                        "aria-hidden": a ? .ariaHidden || void 0,
                        "data-qa": "navbar-logo",
                        type: "button" === o ? "button" : void 0,
                        children: [e, (0, r.jsx)(i.A, {
                            children: a ? .label
                        })]
                    })
                })
            }
        },
        70922: function(e, n, t) {
            t.d(n, {
                A: function() {
                    return i
                }
            });
            var r = t(94243);

            function i(e, n) {
                e.classList ? e.classList.add(n) : (0, r.A)(e, n) || ("string" == typeof e.className ? e.className = e.className + " " + n : e.setAttribute("class", (e.className && e.className.baseVal || "") + " " + n))
            }
        },
        73510: function(e, n, t) {
            var r = t(58168),
                i = t(98587),
                a = t(25540),
                s = t(70922),
                o = t(78995),
                l = t(96540),
                c = t(80851),
                u = t(92403),
                d = function(e, n) {
                    return e && n && n.split(" ").forEach((function(n) {
                        return (0, o.A)(e, n)
                    }))
                },
                p = function(e) {
                    function n() {
                        for (var n, t = arguments.length, r = new Array(t), i = 0; i < t; i++) r[i] = arguments[i];
                        return (n = e.call.apply(e, [this].concat(r)) || this).appliedClasses = {
                            appear: {},
                            enter: {},
                            exit: {}
                        }, n.onEnter = function(e, t) {
                            var r = n.resolveArguments(e, t),
                                i = r[0],
                                a = r[1];
                            n.removeClasses(i, "exit"), n.addClass(i, a ? "appear" : "enter", "base"), n.props.onEnter && n.props.onEnter(e, t)
                        }, n.onEntering = function(e, t) {
                            var r = n.resolveArguments(e, t),
                                i = r[0],
                                a = r[1] ? "appear" : "enter";
                            n.addClass(i, a, "active"), n.props.onEntering && n.props.onEntering(e, t)
                        }, n.onEntered = function(e, t) {
                            var r = n.resolveArguments(e, t),
                                i = r[0],
                                a = r[1] ? "appear" : "enter";
                            n.removeClasses(i, a), n.addClass(i, a, "done"), n.props.onEntered && n.props.onEntered(e, t)
                        }, n.onExit = function(e) {
                            var t = n.resolveArguments(e)[0];
                            n.removeClasses(t, "appear"), n.removeClasses(t, "enter"), n.addClass(t, "exit", "base"), n.props.onExit && n.props.onExit(e)
                        }, n.onExiting = function(e) {
                            var t = n.resolveArguments(e)[0];
                            n.addClass(t, "exit", "active"), n.props.onExiting && n.props.onExiting(e)
                        }, n.onExited = function(e) {
                            var t = n.resolveArguments(e)[0];
                            n.removeClasses(t, "exit"), n.addClass(t, "exit", "done"), n.props.onExited && n.props.onExited(e)
                        }, n.resolveArguments = function(e, t) {
                            return n.props.nodeRef ? [n.props.nodeRef.current, e] : [e, t]
                        }, n.getClassNames = function(e) {
                            var t = n.props.classNames,
                                r = "string" == typeof t,
                                i = r ? "" + (r && t ? t + "-" : "") + e : t[e];
                            return {
                                baseClassName: i,
                                activeClassName: r ? i + "-active" : t[e + "Active"],
                                doneClassName: r ? i + "-done" : t[e + "Done"]
                            }
                        }, n
                    }(0, a.A)(n, e);
                    var t = n.prototype;
                    return t.addClass = function(e, n, t) {
                        var r = this.getClassNames(n)[t + "ClassName"],
                            i = this.getClassNames("enter").doneClassName;
                        "appear" === n && "done" === t && i && (r += " " + i), "active" === t && e && (0, u.F)(e), r && (this.appliedClasses[n][t] = r, function(e, n) {
                            e && n && n.split(" ").forEach((function(n) {
                                return (0, s.A)(e, n)
                            }))
                        }(e, r))
                    }, t.removeClasses = function(e, n) {
                        var t = this.appliedClasses[n],
                            r = t.base,
                            i = t.active,
                            a = t.done;
                        this.appliedClasses[n] = {}, r && d(e, r), i && d(e, i), a && d(e, a)
                    }, t.render = function() {
                        var e = this.props,
                            n = (e.classNames, (0, i.A)(e, ["classNames"]));
                        return l.createElement(c.Ay, (0, r.A)({}, n, {
                            onEnter: this.onEnter,
                            onEntered: this.onEntered,
                            onEntering: this.onEntering,
                            onExit: this.onExit,
                            onExiting: this.onExiting,
                            onExited: this.onExited
                        }))
                    }, n
                }(l.Component);
            p.defaultProps = {
                classNames: ""
            }, p.propTypes = {}, n.A = p
        },
        78995: function(e, n, t) {
            function r(e, n) {
                return e.replace(new RegExp("(^|\\s)" + n + "(?:\\s|$)", "g"), "$1").replace(/\s+/g, " ").replace(/^\s*|\s*$/g, "")
            }

            function i(e, n) {
                e.classList ? e.classList.remove(n) : "string" == typeof e.className ? e.className = r(e.className, n) : e.setAttribute("class", r(e.className && e.className.baseVal || "", n))
            }
            t.d(n, {
                A: function() {
                    return i
                }
            })
        },
        80004: function(e, n, t) {
            var r = t(98587),
                i = t(58168),
                a = t(9417),
                s = t(25540),
                o = t(96540),
                l = t(17241),
                c = t(54922),
                u = Object.values || function(e) {
                    return Object.keys(e).map((function(n) {
                        return e[n]
                    }))
                },
                d = function(e) {
                    function n(n, t) {
                        var r, i = (r = e.call(this, n, t) || this).handleExited.bind((0, a.A)(r));
                        return r.state = {
                            contextValue: {
                                isMounting: !0
                            },
                            handleExited: i,
                            firstRender: !0
                        }, r
                    }(0, s.A)(n, e);
                    var t = n.prototype;
                    return t.componentDidMount = function() {
                        this.mounted = !0, this.setState({
                            contextValue: {
                                isMounting: !1
                            }
                        })
                    }, t.componentWillUnmount = function() {
                        this.mounted = !1
                    }, n.getDerivedStateFromProps = function(e, n) {
                        var t = n.children,
                            r = n.handleExited;
                        return {
                            children: n.firstRender ? (0, c.dw)(e, r) : (0, c.qX)(e, t, r),
                            firstRender: !1
                        }
                    }, t.handleExited = function(e, n) {
                        var t = (0, c.p7)(this.props.children);
                        e.key in t || (e.props.onExited && e.props.onExited(n), this.mounted && this.setState((function(n) {
                            var t = (0, i.A)({}, n.children);
                            return delete t[e.key], {
                                children: t
                            }
                        })))
                    }, t.render = function() {
                        var e = this.props,
                            n = e.component,
                            t = e.childFactory,
                            i = (0, r.A)(e, ["component", "childFactory"]),
                            a = this.state.contextValue,
                            s = u(this.state.children).map(t);
                        return delete i.appear, delete i.enter, delete i.exit, null === n ? o.createElement(l.A.Provider, {
                            value: a
                        }, s) : o.createElement(l.A.Provider, {
                            value: a
                        }, o.createElement(n, i, s))
                    }, n
                }(o.Component);
            d.propTypes = {}, d.defaultProps = {
                component: "div",
                childFactory: function(e) {
                    return e
                }
            }, n.A = d
        },
        83852: function(e, n, t) {
            var r = t(74848),
                i = t(46942),
                a = t.n(i),
                s = t(93827);
            n.A = ({
                text: e,
                isDisabled: n,
                onClick: t,
                innerRef: i,
                dataQA: o
            }) => {
                const l = a()({
                    "csms-navigation-bar__button-text": !0,
                    "csms-navigation-bar__button-text--is-disabled": n
                });
                return (0, r.jsx)("button", {
                    className: l,
                    onClick: n ? void 0 : t,
                    ref: i,
                    "data-qa": "navbar-link",
                    "aria-disabled": n,
                    type: "button",
                    ...o,
                    children: (0, r.jsx)(s.Qi, {
                        children: e
                    })
                })
            }
        },
        94243: function(e, n, t) {
            function r(e, n) {
                return e.classList ? !!n && e.classList.contains(n) : -1 !== (" " + (e.className.baseVal || e.className) + " ").indexOf(" " + n + " ")
            }
            t.d(n, {
                A: function() {
                    return r
                }
            })
        }
    }
]);
//# sourceMappingURL=3705.caf11d264229311d4ec7.js.map
"use strict";
(self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
    [5747], {
        75747: function(e, t, s) {
            s.d(t, {
                de: function() {
                    return F
                }
            });
            class r extends Error {
                constructor(e) {
                    super(e), this.name = "DecodingError"
                }
            }
            class n extends Error {
                constructor(e) {
                    super(e), this.name = "EncodingError"
                }
            }
            class i extends Error {
                constructor(e) {
                    super(e), this.name = "GVLError"
                }
            }
            class o extends Error {
                constructor(e, t, s = "") {
                    super(`invalid value ${t} passed for ${e} ${s}`), this.name = "TCModelError"
                }
            }
            class a {
                static DICT = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
                static REVERSE_DICT = new Map([
                    ["A", 0],
                    ["B", 1],
                    ["C", 2],
                    ["D", 3],
                    ["E", 4],
                    ["F", 5],
                    ["G", 6],
                    ["H", 7],
                    ["I", 8],
                    ["J", 9],
                    ["K", 10],
                    ["L", 11],
                    ["M", 12],
                    ["N", 13],
                    ["O", 14],
                    ["P", 15],
                    ["Q", 16],
                    ["R", 17],
                    ["S", 18],
                    ["T", 19],
                    ["U", 20],
                    ["V", 21],
                    ["W", 22],
                    ["X", 23],
                    ["Y", 24],
                    ["Z", 25],
                    ["a", 26],
                    ["b", 27],
                    ["c", 28],
                    ["d", 29],
                    ["e", 30],
                    ["f", 31],
                    ["g", 32],
                    ["h", 33],
                    ["i", 34],
                    ["j", 35],
                    ["k", 36],
                    ["l", 37],
                    ["m", 38],
                    ["n", 39],
                    ["o", 40],
                    ["p", 41],
                    ["q", 42],
                    ["r", 43],
                    ["s", 44],
                    ["t", 45],
                    ["u", 46],
                    ["v", 47],
                    ["w", 48],
                    ["x", 49],
                    ["y", 50],
                    ["z", 51],
                    ["0", 52],
                    ["1", 53],
                    ["2", 54],
                    ["3", 55],
                    ["4", 56],
                    ["5", 57],
                    ["6", 58],
                    ["7", 59],
                    ["8", 60],
                    ["9", 61],
                    ["-", 62],
                    ["_", 63]
                ]);
                static BASIS = 6;
                static LCM = 24;
                static encode(e) {
                    if (!/^[0-1]+$/.test(e)) throw new n("Invalid bitField");
                    const t = e.length % this.LCM;
                    e += t ? "0".repeat(this.LCM - t) : "";
                    let s = "";
                    for (let t = 0; t < e.length; t += this.BASIS) s += this.DICT[parseInt(e.substr(t, this.BASIS), 2)];
                    return s
                }
                static decode(e) {
                    if (!/^[A-Za-z0-9\-_]+$/.test(e)) throw new r("Invalidly encoded Base64URL string");
                    let t = "";
                    for (let s = 0; s < e.length; s++) {
                        const r = this.REVERSE_DICT.get(e[s]).toString(2);
                        t += "0".repeat(this.BASIS - r.length) + r
                    }
                    return t
                }
            }
            class c {
                static langSet = new Set(["BG", "CA", "CS", "DA", "DE", "EL", "EN", "ES", "ET", "FI", "FR", "HR", "HU", "IT", "JA", "LT", "LV", "MT", "NL", "NO", "PL", "PT", "RO", "RU", "SK", "SL", "SV", "TR", "ZH"]);
                has(e) {
                    return c.langSet.has(e)
                }
                forEach(e) {
                    c.langSet.forEach(e)
                }
                get size() {
                    return c.langSet.size
                }
            }
            class l {
                static cmpId = "cmpId";
                static cmpVersion = "cmpVersion";
                static consentLanguage = "consentLanguage";
                static consentScreen = "consentScreen";
                static created = "created";
                static supportOOB = "supportOOB";
                static isServiceSpecific = "isServiceSpecific";
                static lastUpdated = "lastUpdated";
                static numCustomPurposes = "numCustomPurposes";
                static policyVersion = "policyVersion";
                static publisherCountryCode = "publisherCountryCode";
                static publisherCustomConsents = "publisherCustomConsents";
                static publisherCustomLegitimateInterests = "publisherCustomLegitimateInterests";
                static publisherLegitimateInterests = "publisherLegitimateInterests";
                static publisherConsents = "publisherConsents";
                static publisherRestrictions = "publisherRestrictions";
                static purposeConsents = "purposeConsents";
                static purposeLegitimateInterests = "purposeLegitimateInterests";
                static purposeOneTreatment = "purposeOneTreatment";
                static specialFeatureOptins = "specialFeatureOptins";
                static useNonStandardStacks = "useNonStandardStacks";
                static vendorConsents = "vendorConsents";
                static vendorLegitimateInterests = "vendorLegitimateInterests";
                static vendorListVersion = "vendorListVersion";
                static vendorsAllowed = "vendorsAllowed";
                static vendorsDisclosed = "vendorsDisclosed";
                static version = "version"
            }
            class u {
                clone() {
                    const e = new this.constructor;
                    return Object.keys(this).forEach((t => {
                        const s = this.deepClone(this[t]);
                        void 0 !== s && (e[t] = s)
                    })), e
                }
                deepClone(e) {
                    const t = typeof e;
                    if ("number" === t || "string" === t || "boolean" === t) return e;
                    if (null !== e && "object" === t) {
                        if ("function" == typeof e.clone) return e.clone();
                        if (e instanceof Date) return new Date(e.getTime());
                        if (void 0 !== e[Symbol.iterator]) {
                            const t = [];
                            for (const s of e) t.push(this.deepClone(s));
                            return e instanceof Array ? t : new e.constructor(t)
                        } {
                            const t = {};
                            for (const s in e) e.hasOwnProperty(s) && (t[s] = this.deepClone(e[s]));
                            return t
                        }
                    }
                }
            }
            var d, p, h, g;
            ! function(e) {
                e[e.NOT_ALLOWED = 0] = "NOT_ALLOWED", e[e.REQUIRE_CONSENT = 1] = "REQUIRE_CONSENT", e[e.REQUIRE_LI = 2] = "REQUIRE_LI"
            }(d || (d = {}));
            class m extends u {
                static hashSeparator = "-";
                purposeId_;
                restrictionType;
                constructor(e, t) {
                    super(), void 0 !== e && (this.purposeId = e), void 0 !== t && (this.restrictionType = t)
                }
                static unHash(e) {
                    const t = e.split(this.hashSeparator),
                        s = new m;
                    if (2 !== t.length) throw new o("hash", e);
                    return s.purposeId = parseInt(t[0], 10), s.restrictionType = parseInt(t[1], 10), s
                }
                get hash() {
                    if (!this.isValid()) throw new Error("cannot hash invalid PurposeRestriction");
                    return `${this.purposeId}${m.hashSeparator}${this.restrictionType}`
                }
                get purposeId() {
                    return this.purposeId_
                }
                set purposeId(e) {
                    this.purposeId_ = e
                }
                isValid() {
                    return Number.isInteger(this.purposeId) && this.purposeId > 0 && (this.restrictionType === d.NOT_ALLOWED || this.restrictionType === d.REQUIRE_CONSENT || this.restrictionType === d.REQUIRE_LI)
                }
                isSameAs(e) {
                    return this.purposeId === e.purposeId && this.restrictionType === e.restrictionType
                }
            }
            class f extends u {
                root = null;
                getRoot() {
                    return this.root
                }
                isEmpty() {
                    return !this.root
                }
                add(e) {
                    const t = {
                        value: e,
                        left: null,
                        right: null
                    };
                    let s;
                    if (this.isEmpty()) this.root = t;
                    else
                        for (s = this.root;;)
                            if (e < s.value) {
                                if (null === s.left) {
                                    s.left = t;
                                    break
                                }
                                s = s.left
                            } else {
                                if (!(e > s.value)) break;
                                if (null === s.right) {
                                    s.right = t;
                                    break
                                }
                                s = s.right
                            }
                }
                get() {
                    const e = [];
                    let t = this.root;
                    for (; t;)
                        if (t.left) {
                            let s = t.left;
                            for (; s.right && s.right != t;) s = s.right;
                            s.right == t ? (s.right = null, e.push(t.value), t = t.right) : (s.right = t, t = t.left)
                        } else e.push(t.value), t = t.right;
                    return e
                }
                contains(e) {
                    let t = !1,
                        s = this.root;
                    for (; s;) {
                        if (s.value === e) {
                            t = !0;
                            break
                        }
                        e > s.value ? s = s.right : e < s.value && (s = s.left)
                    }
                    return t
                }
                min(e = this.root) {
                    let t;
                    for (; e;) e.left ? e = e.left : (t = e.value, e = null);
                    return t
                }
                max(e = this.root) {
                    let t;
                    for (; e;) e.right ? e = e.right : (t = e.value, e = null);
                    return t
                }
                remove(e, t = this.root) {
                    let s = null,
                        r = "left";
                    for (; t;)
                        if (e < t.value) s = t, t = t.left, r = "left";
                        else if (e > t.value) s = t, t = t.right, r = "right";
                    else {
                        if (t.left || t.right)
                            if (t.left)
                                if (t.right) {
                                    const e = this.min(t.right);
                                    this.remove(e, t.right), t.value = e
                                } else s ? s[r] = t.left : this.root = t.left;
                        else s ? s[r] = t.right : this.root = t.right;
                        else s ? s[r] = null : this.root = null;
                        t = null
                    }
                }
                static build(e) {
                    if (e && 0 !== e.length) {
                        if (1 === e.length) {
                            const t = new f;
                            return t.add(e[0]), t
                        } {
                            const t = e.length >> 1,
                                s = new f;
                            s.add(e[t]);
                            const r = s.getRoot();
                            if (r) {
                                if (t + 1 < e.length) {
                                    const s = f.build(e.slice(t + 1));
                                    r.right = s ? s.getRoot() : null
                                }
                                if (t - 1 > 0) {
                                    const s = f.build(e.slice(0, t - 1));
                                    r.left = s ? s.getRoot() : null
                                }
                            }
                            return s
                        }
                    }
                    return null
                }
            }
            class v extends u {
                bitLength = 0;
                map = new Map;
                gvl_;
                has(e) {
                    return this.map.has(e)
                }
                isOkToHave(e, t, s) {
                    let r = !0;
                    if (this.gvl ? .vendors) {
                        const n = this.gvl.vendors[s];
                        if (n)
                            if (e === d.NOT_ALLOWED) r = n.legIntPurposes.includes(t) || n.purposes.includes(t);
                            else if (n.flexiblePurposes.length) switch (e) {
                            case d.REQUIRE_CONSENT:
                                r = n.flexiblePurposes.includes(t) && n.legIntPurposes.includes(t);
                                break;
                            case d.REQUIRE_LI:
                                r = n.flexiblePurposes.includes(t) && n.purposes.includes(t)
                        } else r = !1;
                        else r = !1
                    }
                    return r
                }
                add(e, t) {
                    if (this.isOkToHave(t.restrictionType, t.purposeId, e)) {
                        const s = t.hash;
                        this.has(s) || (this.map.set(s, new f), this.bitLength = 0), this.map.get(s).add(e)
                    }
                }
                restrictPurposeToLegalBasis(e) {
                    const t = this.gvl.vendorIds,
                        s = e.hash,
                        r = function() {
                            let e;
                            for (e of t);
                            return e
                        }(),
                        n = [...Array(r).keys()].map((e => e + 1));
                    for (let e = 1; e <= r; e++) this.has(s) || (this.map.set(s, f.build(n)), this.bitLength = 0), this.map.get(s).add(e)
                }
                getVendors(e) {
                    let t = [];
                    if (e) {
                        const s = e.hash;
                        this.has(s) && (t = this.map.get(s).get())
                    } else {
                        const e = new Set;
                        this.map.forEach((t => {
                            t.get().forEach((t => {
                                e.add(t)
                            }))
                        })), t = Array.from(e)
                    }
                    return t
                }
                getRestrictionType(e, t) {
                    let s;
                    return this.getRestrictions(e).forEach((e => {
                        e.purposeId === t && (void 0 === s || s > e.restrictionType) && (s = e.restrictionType)
                    })), s
                }
                vendorHasRestriction(e, t) {
                    let s = !1;
                    const r = this.getRestrictions(e);
                    for (let e = 0; e < r.length && !s; e++) s = t.isSameAs(r[e]);
                    return s
                }
                getMaxVendorId() {
                    let e = 0;
                    return this.map.forEach((t => {
                        e = Math.max(t.max(), e)
                    })), e
                }
                getRestrictions(e) {
                    const t = [];
                    return this.map.forEach(((s, r) => {
                        e ? s.contains(e) && t.push(m.unHash(r)) : t.push(m.unHash(r))
                    })), t
                }
                getPurposes() {
                    const e = new Set;
                    return this.map.forEach(((t, s) => {
                        e.add(m.unHash(s).purposeId)
                    })), Array.from(e)
                }
                remove(e, t) {
                    const s = t.hash,
                        r = this.map.get(s);
                    r && (r.remove(e), r.isEmpty() && (this.map.delete(s), this.bitLength = 0))
                }
                set gvl(e) {
                    this.gvl_ || (this.gvl_ = e, this.map.forEach(((e, t) => {
                        const s = m.unHash(t);
                        e.get().forEach((t => {
                            this.isOkToHave(s.restrictionType, s.purposeId, t) || e.remove(t)
                        }))
                    })))
                }
                get gvl() {
                    return this.gvl_
                }
                isEmpty() {
                    return 0 === this.map.size
                }
                get numRestrictions() {
                    return this.map.size
                }
            }! function(e) {
                e.COOKIE = "cookie", e.WEB = "web", e.APP = "app"
            }(p || (p = {})),
            function(e) {
                e.CORE = "core", e.VENDORS_DISCLOSED = "vendorsDisclosed", e.VENDORS_ALLOWED = "vendorsAllowed", e.PUBLISHER_TC = "publisherTC"
            }(h || (h = {}));
            class E {
                static ID_TO_KEY = [h.CORE, h.VENDORS_DISCLOSED, h.VENDORS_ALLOWED, h.PUBLISHER_TC];
                static KEY_TO_ID = {
                    [h.CORE]: 0,
                    [h.VENDORS_DISCLOSED]: 1,
                    [h.VENDORS_ALLOWED]: 2,
                    [h.PUBLISHER_TC]: 3
                }
            }
            class I extends u {
                bitLength = 0;
                maxId_ = 0;
                set_ = new Set;*[Symbol.iterator]() {
                    for (let e = 1; e <= this.maxId; e++) yield [e, this.has(e)]
                }
                values() {
                    return this.set_.values()
                }
                get maxId() {
                    return this.maxId_
                }
                has(e) {
                    return this.set_.has(e)
                }
                unset(e) {
                    Array.isArray(e) ? e.forEach((e => this.unset(e))) : "object" == typeof e ? this.unset(Object.keys(e).map((e => Number(e)))) : (this.set_.delete(Number(e)), this.bitLength = 0, e === this.maxId && (this.maxId_ = 0, this.set_.forEach((e => {
                        this.maxId_ = Math.max(this.maxId, e)
                    }))))
                }
                isIntMap(e) {
                    let t = "object" == typeof e;
                    return t = t && Object.keys(e).every((t => {
                        let s = Number.isInteger(parseInt(t, 10));
                        return s = s && this.isValidNumber(e[t].id), s = s && void 0 !== e[t].name, s
                    })), t
                }
                isValidNumber(e) {
                    return parseInt(e, 10) > 0
                }
                isSet(e) {
                    let t = !1;
                    return e instanceof Set && (t = Array.from(e).every(this.isValidNumber)), t
                }
                set(e) {
                    if (Array.isArray(e)) e.forEach((e => this.set(e)));
                    else if (this.isSet(e)) this.set(Array.from(e));
                    else if (this.isIntMap(e)) this.set(Object.keys(e).map((e => Number(e))));
                    else {
                        if (!this.isValidNumber(e)) throw new o("set()", e, "must be positive integer array, positive integer, Set<number>, or IntMap");
                        this.set_.add(e), this.maxId_ = Math.max(this.maxId, e), this.bitLength = 0
                    }
                }
                empty() {
                    this.set_ = new Set
                }
                forEach(e) {
                    for (let t = 1; t <= this.maxId; t++) e(this.has(t), t)
                }
                get size() {
                    return this.set_.size
                }
                setAll(e) {
                    this.set(e)
                }
            }
            class C {
                static[l.cmpId] = 12;
                static[l.cmpVersion] = 12;
                static[l.consentLanguage] = 12;
                static[l.consentScreen] = 6;
                static[l.created] = 36;
                static[l.isServiceSpecific] = 1;
                static[l.lastUpdated] = 36;
                static[l.policyVersion] = 6;
                static[l.publisherCountryCode] = 12;
                static[l.publisherLegitimateInterests] = 24;
                static[l.publisherConsents] = 24;
                static[l.purposeConsents] = 24;
                static[l.purposeLegitimateInterests] = 24;
                static[l.purposeOneTreatment] = 1;
                static[l.specialFeatureOptins] = 12;
                static[l.useNonStandardStacks] = 1;
                static[l.vendorListVersion] = 12;
                static[l.version] = 6;
                static anyBoolean = 1;
                static encodingType = 1;
                static maxId = 16;
                static numCustomPurposes = 6;
                static numEntries = 12;
                static numRestrictions = 12;
                static purposeId = 6;
                static restrictionType = 2;
                static segmentType = 3;
                static singleOrRange = 1;
                static vendorId = 16
            }
            class b {
                static encode(e, t) {
                    let s;
                    if ("string" == typeof e && (e = parseInt(e, 10)), s = e.toString(2), s.length > t || e < 0) throw new n(`${e} too large to encode into ${t}`);
                    return s.length < t && (s = "0".repeat(t - s.length) + s), s
                }
                static decode(e, t) {
                    if (t !== e.length) throw new r("invalid bit length");
                    return parseInt(e, 2)
                }
            }
            class S {
                static encode(e, t) {
                    return b.encode(Math.round(e.getTime() / 100), t)
                }
                static decode(e, t) {
                    if (t !== e.length) throw new r("invalid bit length");
                    const s = new Date;
                    return s.setTime(100 * b.decode(e, t)), s
                }
            }
            class L {
                static encode(e) {
                    return String(Number(e))
                }
                static decode(e) {
                    return "1" === e
                }
            }
            class y {
                static encode(e, t) {
                    let s = "";
                    for (let r = 1; r <= t; r++) s += L.encode(e.has(r));
                    return s
                }
                static decode(e, t) {
                    if (e.length !== t) throw new r("bitfield encoding length mismatch");
                    const s = new I;
                    for (let r = 1; r <= t; r++) L.decode(e[r - 1]) && s.set(r);
                    return s.bitLength = e.length, s
                }
            }
            class w {
                static encode(e, t) {
                    const s = (e = e.toUpperCase()).charCodeAt(0) - 65,
                        r = e.charCodeAt(1) - 65;
                    if (s < 0 || s > 25 || r < 0 || r > 25) throw new n(`invalid language code: ${e}`);
                    if (t % 2 == 1) throw new n(`numBits must be even, ${t} is not valid`);
                    t /= 2;
                    return b.encode(s, t) + b.encode(r, t)
                }
                static decode(e, t) {
                    let s;
                    if (t !== e.length || e.length % 2) throw new r("invalid bit length for language"); {
                        const t = 65,
                            r = e.length / 2,
                            n = b.decode(e.slice(0, r), r) + t,
                            i = b.decode(e.slice(r), r) + t;
                        s = String.fromCharCode(n) + String.fromCharCode(i)
                    }
                    return s
                }
            }
            class _ {
                static encode(e) {
                    let t = b.encode(e.numRestrictions, C.numRestrictions);
                    return e.isEmpty() || e.getRestrictions().forEach((s => {
                        t += b.encode(s.purposeId, C.purposeId), t += b.encode(s.restrictionType, C.restrictionType);
                        const r = e.getVendors(s),
                            n = r.length;
                        let i = 0,
                            o = 0,
                            a = "";
                        for (let t = 0; t < n; t++) {
                            const s = r[t];
                            0 === o && (i++, o = s);
                            const c = r[n - 1],
                                l = e.gvl.vendorIds,
                                u = e => {
                                    for (; ++e <= c && !l.has(e););
                                    return e
                                };
                            if (t === n - 1 || r[t + 1] > u(s)) {
                                const e = !(s === o);
                                a += L.encode(e), a += b.encode(o, C.vendorId), e && (a += b.encode(s, C.vendorId)), o = 0
                            }
                        }
                        t += b.encode(i, C.numEntries), t += a
                    })), t
                }
                static decode(e) {
                    let t = 0;
                    const s = new v,
                        n = b.decode(e.substr(t, C.numRestrictions), C.numRestrictions);
                    t += C.numRestrictions;
                    for (let i = 0; i < n; i++) {
                        const n = b.decode(e.substr(t, C.purposeId), C.purposeId);
                        t += C.purposeId;
                        const i = b.decode(e.substr(t, C.restrictionType), C.restrictionType);
                        t += C.restrictionType;
                        const o = new m(n, i),
                            a = b.decode(e.substr(t, C.numEntries), C.numEntries);
                        t += C.numEntries;
                        for (let n = 0; n < a; n++) {
                            const n = L.decode(e.substr(t, C.anyBoolean));
                            t += C.anyBoolean;
                            const i = b.decode(e.substr(t, C.vendorId), C.vendorId);
                            if (t += C.vendorId, n) {
                                const n = b.decode(e.substr(t, C.vendorId), C.vendorId);
                                if (t += C.vendorId, n < i) throw new r(`Invalid RangeEntry: endVendorId ${n} is less than ${i}`);
                                for (let e = i; e <= n; e++) s.add(e, o)
                            } else s.add(i, o)
                        }
                    }
                    return s.bitLength = t, s
                }
            }! function(e) {
                e[e.FIELD = 0] = "FIELD", e[e.RANGE = 1] = "RANGE"
            }(g || (g = {}));
            class V {
                static encode(e) {
                    const t = [];
                    let s, r = [],
                        n = b.encode(e.maxId, C.maxId),
                        i = "";
                    const o = C.maxId + C.encodingType,
                        a = o + e.maxId,
                        c = 2 * C.vendorId + C.singleOrRange + C.numEntries;
                    let l = o + C.numEntries;
                    return e.forEach(((n, o) => {
                        if (i += L.encode(n), s = e.maxId > c && l < a, s && n) {
                            e.has(o + 1) ? 0 === r.length && (r.push(o), l += C.singleOrRange, l += C.vendorId) : (r.push(o), l += C.vendorId, t.push(r), r = [])
                        }
                    })), s ? (n += String(g.RANGE), n += this.buildRangeEncoding(t)) : (n += String(g.FIELD), n += i), n
                }
                static decode(e, t) {
                    let s, n = 0;
                    const i = b.decode(e.substr(n, C.maxId), C.maxId);
                    n += C.maxId;
                    const o = b.decode(e.charAt(n), C.encodingType);
                    if (n += C.encodingType, o === g.RANGE) {
                        if (s = new I, 1 === t) {
                            if ("1" === e.substr(n, 1)) throw new r("Unable to decode default consent=1");
                            n++
                        }
                        const i = b.decode(e.substr(n, C.numEntries), C.numEntries);
                        n += C.numEntries;
                        for (let t = 0; t < i; t++) {
                            const t = L.decode(e.charAt(n));
                            n += C.singleOrRange;
                            const r = b.decode(e.substr(n, C.vendorId), C.vendorId);
                            if (n += C.vendorId, t) {
                                const t = b.decode(e.substr(n, C.vendorId), C.vendorId);
                                n += C.vendorId;
                                for (let e = r; e <= t; e++) s.set(e)
                            } else s.set(r)
                        }
                    } else {
                        const t = e.substr(n, i);
                        n += i, s = y.decode(t, i)
                    }
                    return s.bitLength = n, s
                }
                static buildRangeEncoding(e) {
                    const t = e.length;
                    let s = b.encode(t, C.numEntries);
                    return e.forEach((e => {
                        const t = 1 === e.length;
                        s += L.encode(!t), s += b.encode(e[0], C.vendorId), t || (s += b.encode(e[1], C.vendorId))
                    })), s
                }
            }

            function A() {
                return {
                    [l.version]: b,
                    [l.created]: S,
                    [l.lastUpdated]: S,
                    [l.cmpId]: b,
                    [l.cmpVersion]: b,
                    [l.consentScreen]: b,
                    [l.consentLanguage]: w,
                    [l.vendorListVersion]: b,
                    [l.policyVersion]: b,
                    [l.isServiceSpecific]: L,
                    [l.useNonStandardStacks]: L,
                    [l.specialFeatureOptins]: y,
                    [l.purposeConsents]: y,
                    [l.purposeLegitimateInterests]: y,
                    [l.purposeOneTreatment]: L,
                    [l.publisherCountryCode]: w,
                    [l.vendorConsents]: V,
                    [l.vendorLegitimateInterests]: V,
                    [l.publisherRestrictions]: _,
                    segmentType: b,
                    [l.vendorsDisclosed]: V,
                    [l.vendorsAllowed]: V,
                    [l.publisherConsents]: y,
                    [l.publisherLegitimateInterests]: y,
                    [l.numCustomPurposes]: b,
                    [l.publisherCustomConsents]: y,
                    [l.publisherCustomLegitimateInterests]: y
                }
            }
            class O {
                1 = {
                    [h.CORE]: [l.version, l.created, l.lastUpdated, l.cmpId, l.cmpVersion, l.consentScreen, l.consentLanguage, l.vendorListVersion, l.purposeConsents, l.vendorConsents]
                };
                2 = {
                    [h.CORE]: [l.version, l.created, l.lastUpdated, l.cmpId, l.cmpVersion, l.consentScreen, l.consentLanguage, l.vendorListVersion, l.policyVersion, l.isServiceSpecific, l.useNonStandardStacks, l.specialFeatureOptins, l.purposeConsents, l.purposeLegitimateInterests, l.purposeOneTreatment, l.publisherCountryCode, l.vendorConsents, l.vendorLegitimateInterests, l.publisherRestrictions],
                    [h.PUBLISHER_TC]: [l.publisherConsents, l.publisherLegitimateInterests, l.numCustomPurposes, l.publisherCustomConsents, l.publisherCustomLegitimateInterests],
                    [h.VENDORS_ALLOWED]: [l.vendorsAllowed],
                    [h.VENDORS_DISCLOSED]: [l.vendorsDisclosed]
                }
            }
            class T {
                1 = [h.CORE];
                2 = [h.CORE];
                constructor(e, t) {
                    if (2 === e.version)
                        if (e.isServiceSpecific) this[2].push(h.PUBLISHER_TC);
                        else {
                            const s = !(!t || !t.isForVendors);
                            s && !0 !== e[l.supportOOB] || this[2].push(h.VENDORS_DISCLOSED), s && (e[l.supportOOB] && e[l.vendorsAllowed].size > 0 && this[2].push(h.VENDORS_ALLOWED), this[2].push(h.PUBLISHER_TC))
                        }
                }
            }
            class R {
                static fieldSequence = new O;
                static encode(e, t) {
                    let s;
                    try {
                        s = this.fieldSequence[String(e.version)][t]
                    } catch (s) {
                        throw new n(`Unable to encode version: ${e.version}, segment: ${t}`)
                    }
                    let r = "";
                    t !== h.CORE && (r = b.encode(E.KEY_TO_ID[t], C.segmentType));
                    const i = A();
                    return s.forEach((s => {
                        const o = e[s],
                            a = i[s];
                        let c = C[s];
                        void 0 === c && this.isPublisherCustom(s) && (c = Number(e[l.numCustomPurposes]));
                        try {
                            r += a.encode(o, c)
                        } catch (e) {
                            throw new n(`Error encoding ${t}->${s}: ${e.message}`)
                        }
                    })), a.encode(r)
                }
                static decode(e, t, s) {
                    const n = a.decode(e);
                    let i = 0;
                    s === h.CORE && (t.version = b.decode(n.substr(i, C[l.version]), C[l.version])), s !== h.CORE && (i += C.segmentType);
                    const o = this.fieldSequence[String(t.version)][s],
                        c = A();
                    return o.forEach((e => {
                        const s = c[e];
                        let o = C[e];
                        if (void 0 === o && this.isPublisherCustom(e) && (o = Number(t[l.numCustomPurposes])), 0 !== o) {
                            const a = n.substr(i, o);
                            if (t[e] = s === V ? s.decode(a, t.version) : s.decode(a, o), Number.isInteger(o)) i += o;
                            else {
                                if (!Number.isInteger(t[e].bitLength)) throw new r(e);
                                i += t[e].bitLength
                            }
                        }
                    })), t
                }
                static isPublisherCustom(e) {
                    return 0 === e.indexOf("publisherCustom")
                }
            }
            class P {
                static processor = [e => e, (e, t) => {
                    e.publisherRestrictions.gvl = t, e.purposeLegitimateInterests.unset(1);
                    const s = new Map;
                    return s.set("legIntPurposes", e.vendorLegitimateInterests), s.set("purposes", e.vendorConsents), s.forEach(((s, r) => {
                        s.forEach(((n, i) => {
                            if (n) {
                                const n = t.vendors[i];
                                if (!n || n.deletedDate) s.unset(i);
                                else if (0 === n[r].length)
                                    if ("legIntPurposes" === r && 0 === n.purposes.length && 0 === n.legIntPurposes.length && n.specialPurposes.length > 0);
                                    else if (e.isServiceSpecific)
                                    if (0 === n.flexiblePurposes.length) s.unset(i);
                                    else {
                                        const t = e.publisherRestrictions.getRestrictions(i);
                                        let n = !1;
                                        for (let e = 0, s = t.length; e < s && !n; e++) n = t[e].restrictionType === d.REQUIRE_CONSENT && "purposes" === r || t[e].restrictionType === d.REQUIRE_LI && "legIntPurposes" === r;
                                        n || s.unset(i)
                                    }
                                else s.unset(i)
                            }
                        }))
                    })), e.vendorsDisclosed.set(t.vendors), e
                }];
                static process(e, t) {
                    const s = e.gvl;
                    if (!s) throw new n("Unable to encode TCModel without a GVL");
                    if (!s.isReady) throw new n("Unable to encode TCModel tcModel.gvl.readyPromise is not resolved");
                    (e = e.clone()).consentLanguage = s.language.toUpperCase(), t ? .version > 0 && t ? .version <= this.processor.length ? e.version = t.version : e.version = this.processor.length;
                    const r = e.version - 1;
                    if (!this.processor[r]) throw new n(`Invalid version: ${e.version}`);
                    return this.processor[r](e, s)
                }
            }
            class N {
                static absCall(e, t, s, r) {
                    return new Promise(((n, i) => {
                        const o = new XMLHttpRequest;
                        o.withCredentials = s, o.addEventListener("load", (() => {
                            if (o.readyState == XMLHttpRequest.DONE)
                                if (o.status >= 200 && o.status < 300) {
                                    let e = o.response;
                                    if ("string" == typeof e) try {
                                        e = JSON.parse(e)
                                    } catch (e) {}
                                    n(e)
                                } else i(new Error(`HTTP Status: ${o.status} response type: ${o.responseType}`))
                        })), o.addEventListener("error", (() => {
                            i(new Error("error"))
                        })), o.addEventListener("abort", (() => {
                            i(new Error("aborted"))
                        })), null === t ? o.open("GET", e, !0) : o.open("POST", e, !0), o.responseType = "json", o.timeout = r, o.ontimeout = () => {
                            i(new Error("Timeout " + r + "ms " + e))
                        }, o.send(t)
                    }))
                }
                static post(e, t, s = !1, r = 0) {
                    return this.absCall(e, JSON.stringify(t), s, r)
                }
                static fetch(e, t = !1, s = 0) {
                    return this.absCall(e, null, t, s)
                }
            }
            class U extends u {
                static LANGUAGE_CACHE = new Map;
                static CACHE = new Map;
                static LATEST_CACHE_KEY = 0;
                static DEFAULT_LANGUAGE = "EN";
                static consentLanguages = new c;
                static baseUrl_;
                static set baseUrl(e) {
                    if (/^https?:\/\/vendorlist\.consensu\.org\//.test(e)) throw new i("Invalid baseUrl!  You may not pull directly from vendorlist.consensu.org and must provide your own cache");
                    e.length > 0 && "/" !== e[e.length - 1] && (e += "/"), this.baseUrl_ = e
                }
                static get baseUrl() {
                    return this.baseUrl_
                }
                static latestFilename = "vendor-list.json";
                static versionedFilename = "archives/vendor-list-v[VERSION].json";
                static languageFilename = "purposes-[LANG].json";
                readyPromise;
                gvlSpecificationVersion;
                vendorListVersion;
                tcfPolicyVersion;
                lastUpdated;
                purposes;
                specialPurposes;
                features;
                specialFeatures;
                isReady_ = !1;
                vendors_;
                vendorIds;
                fullVendorList;
                byPurposeVendorMap;
                bySpecialPurposeVendorMap;
                byFeatureVendorMap;
                bySpecialFeatureVendorMap;
                stacks;
                lang_;
                isLatest = !1;
                constructor(e) {
                    super();
                    let t = U.baseUrl;
                    if (this.lang_ = U.DEFAULT_LANGUAGE, this.isVendorList(e)) this.populate(e), this.readyPromise = Promise.resolve();
                    else {
                        if (!t) throw new i("must specify GVL.baseUrl before loading GVL json");
                        if (e > 0) {
                            const s = e;
                            U.CACHE.has(s) ? (this.populate(U.CACHE.get(s)), this.readyPromise = Promise.resolve()) : (t += U.versionedFilename.replace("[VERSION]", String(s)), this.readyPromise = this.fetchJson(t))
                        } else U.CACHE.has(U.LATEST_CACHE_KEY) ? (this.populate(U.CACHE.get(U.LATEST_CACHE_KEY)), this.readyPromise = Promise.resolve()) : (this.isLatest = !0, this.readyPromise = this.fetchJson(t + U.latestFilename))
                    }
                }
                static emptyLanguageCache(e) {
                    let t = !1;
                    return void 0 === e && U.LANGUAGE_CACHE.size > 0 ? (U.LANGUAGE_CACHE = new Map, t = !0) : "string" == typeof e && this.consentLanguages.has(e.toUpperCase()) && (U.LANGUAGE_CACHE.delete(e.toUpperCase()), t = !0), t
                }
                static emptyCache(e) {
                    let t = !1;
                    return Number.isInteger(e) && e >= 0 ? (U.CACHE.delete(e), t = !0) : void 0 === e && (U.CACHE = new Map, t = !0), t
                }
                cacheLanguage() {
                    U.LANGUAGE_CACHE.has(this.lang_) || U.LANGUAGE_CACHE.set(this.lang_, {
                        purposes: this.purposes,
                        specialPurposes: this.specialPurposes,
                        features: this.features,
                        specialFeatures: this.specialFeatures,
                        stacks: this.stacks
                    })
                }
                async fetchJson(e) {
                    try {
                        this.populate(await N.fetch(e))
                    } catch (e) {
                        throw new i(e.message)
                    }
                }
                getJson() {
                    return JSON.parse(JSON.stringify({
                        gvlSpecificationVersion: this.gvlSpecificationVersion,
                        vendorListVersion: this.vendorListVersion,
                        tcfPolicyVersion: this.tcfPolicyVersion,
                        lastUpdated: this.lastUpdated,
                        purposes: this.purposes,
                        specialPurposes: this.specialPurposes,
                        features: this.features,
                        specialFeatures: this.specialFeatures,
                        stacks: this.stacks,
                        vendors: this.fullVendorList
                    }))
                }
                async changeLanguage(e) {
                    const t = e.toUpperCase();
                    if (!U.consentLanguages.has(t)) throw new i(`unsupported language ${e}`);
                    if (t !== this.lang_)
                        if (this.lang_ = t, U.LANGUAGE_CACHE.has(t)) {
                            const e = U.LANGUAGE_CACHE.get(t);
                            for (const t in e) e.hasOwnProperty(t) && (this[t] = e[t])
                        } else {
                            const t = U.baseUrl + U.languageFilename.replace("[LANG]", e);
                            try {
                                await this.fetchJson(t), this.cacheLanguage()
                            } catch (e) {
                                throw new i("unable to load language: " + e.message)
                            }
                        }
                }
                get language() {
                    return this.lang_
                }
                isVendorList(e) {
                    return void 0 !== e && void 0 !== e.vendors
                }
                populate(e) {
                    this.purposes = e.purposes, this.specialPurposes = e.specialPurposes, this.features = e.features, this.specialFeatures = e.specialFeatures, this.stacks = e.stacks, this.isVendorList(e) && (this.gvlSpecificationVersion = e.gvlSpecificationVersion, this.tcfPolicyVersion = e.tcfPolicyVersion, this.vendorListVersion = e.vendorListVersion, this.lastUpdated = e.lastUpdated, "string" == typeof this.lastUpdated && (this.lastUpdated = new Date(this.lastUpdated)), this.vendors_ = e.vendors, this.fullVendorList = e.vendors, this.mapVendors(), this.isReady_ = !0, this.isLatest && U.CACHE.set(U.LATEST_CACHE_KEY, this.getJson()), U.CACHE.has(this.vendorListVersion) || U.CACHE.set(this.vendorListVersion, this.getJson())), this.cacheLanguage()
                }
                mapVendors(e) {
                    this.byPurposeVendorMap = {}, this.bySpecialPurposeVendorMap = {}, this.byFeatureVendorMap = {}, this.bySpecialFeatureVendorMap = {}, Object.keys(this.purposes).forEach((e => {
                        this.byPurposeVendorMap[e] = {
                            legInt: new Set,
                            consent: new Set,
                            flexible: new Set
                        }
                    })), Object.keys(this.specialPurposes).forEach((e => {
                        this.bySpecialPurposeVendorMap[e] = new Set
                    })), Object.keys(this.features).forEach((e => {
                        this.byFeatureVendorMap[e] = new Set
                    })), Object.keys(this.specialFeatures).forEach((e => {
                        this.bySpecialFeatureVendorMap[e] = new Set
                    })), Array.isArray(e) || (e = Object.keys(this.fullVendorList).map((e => +e))), this.vendorIds = new Set(e), this.vendors_ = e.reduce(((e, t) => {
                        const s = this.vendors_[String(t)];
                        return s && void 0 === s.deletedDate && (s.purposes.forEach((e => {
                            this.byPurposeVendorMap[String(e)].consent.add(t)
                        })), s.specialPurposes.forEach((e => {
                            this.bySpecialPurposeVendorMap[String(e)].add(t)
                        })), s.legIntPurposes.forEach((e => {
                            this.byPurposeVendorMap[String(e)].legInt.add(t)
                        })), s.flexiblePurposes && s.flexiblePurposes.forEach((e => {
                            this.byPurposeVendorMap[String(e)].flexible.add(t)
                        })), s.features.forEach((e => {
                            this.byFeatureVendorMap[String(e)].add(t)
                        })), s.specialFeatures.forEach((e => {
                            this.bySpecialFeatureVendorMap[String(e)].add(t)
                        })), e[t] = s), e
                    }), {})
                }
                getFilteredVendors(e, t, s, r) {
                    const n = e.charAt(0).toUpperCase() + e.slice(1);
                    let i;
                    const o = {};
                    return i = "purpose" === e && s ? this["by" + n + "VendorMap"][String(t)][s] : this["by" + (r ? "Special" : "") + n + "VendorMap"][String(t)], i.forEach((e => {
                        o[String(e)] = this.vendors[String(e)]
                    })), o
                }
                getVendorsWithConsentPurpose(e) {
                    return this.getFilteredVendors("purpose", e, "consent")
                }
                getVendorsWithLegIntPurpose(e) {
                    return this.getFilteredVendors("purpose", e, "legInt")
                }
                getVendorsWithFlexiblePurpose(e) {
                    return this.getFilteredVendors("purpose", e, "flexible")
                }
                getVendorsWithSpecialPurpose(e) {
                    return this.getFilteredVendors("purpose", e, void 0, !0)
                }
                getVendorsWithFeature(e) {
                    return this.getFilteredVendors("feature", e)
                }
                getVendorsWithSpecialFeature(e) {
                    return this.getFilteredVendors("feature", e, void 0, !0)
                }
                get vendors() {
                    return this.vendors_
                }
                narrowVendorsTo(e) {
                    this.mapVendors(e)
                }
                get isReady() {
                    return this.isReady_
                }
                clone() {
                    const e = new U(this.getJson());
                    return this.lang_ !== U.DEFAULT_LANGUAGE && e.changeLanguage(this.lang_), e
                }
                static isInstanceOf(e) {
                    return "object" == typeof e && "function" == typeof e.narrowVendorsTo
                }
            }
            class D extends u {
                static consentLanguages = U.consentLanguages;
                isServiceSpecific_ = !1;
                supportOOB_ = !0;
                useNonStandardStacks_ = !1;
                purposeOneTreatment_ = !1;
                publisherCountryCode_ = "AA";
                version_ = 2;
                consentScreen_ = 0;
                policyVersion_ = 2;
                consentLanguage_ = "EN";
                cmpId_ = 0;
                cmpVersion_ = 0;
                vendorListVersion_ = 0;
                numCustomPurposes_ = 0;
                gvl_;
                created;
                lastUpdated;
                specialFeatureOptins = new I;
                purposeConsents = new I;
                purposeLegitimateInterests = new I;
                publisherConsents = new I;
                publisherLegitimateInterests = new I;
                publisherCustomConsents = new I;
                publisherCustomLegitimateInterests = new I;
                customPurposes;
                vendorConsents = new I;
                vendorLegitimateInterests = new I;
                vendorsDisclosed = new I;
                vendorsAllowed = new I;
                publisherRestrictions = new v;
                constructor(e) {
                    super(), e && (this.gvl = e), this.updated()
                }
                set gvl(e) {
                    U.isInstanceOf(e) || (e = new U(e)), this.gvl_ = e, this.publisherRestrictions.gvl = e
                }
                get gvl() {
                    return this.gvl_
                }
                set cmpId(e) {
                    if (e = Number(e), !(Number.isInteger(e) && e > 1)) throw new o("cmpId", e);
                    this.cmpId_ = e
                }
                get cmpId() {
                    return this.cmpId_
                }
                set cmpVersion(e) {
                    if (e = Number(e), !(Number.isInteger(e) && e > -1)) throw new o("cmpVersion", e);
                    this.cmpVersion_ = e
                }
                get cmpVersion() {
                    return this.cmpVersion_
                }
                set consentScreen(e) {
                    if (e = Number(e), !(Number.isInteger(e) && e > -1)) throw new o("consentScreen", e);
                    this.consentScreen_ = e
                }
                get consentScreen() {
                    return this.consentScreen_
                }
                set consentLanguage(e) {
                    this.consentLanguage_ = e
                }
                get consentLanguage() {
                    return this.consentLanguage_
                }
                set publisherCountryCode(e) {
                    if (!/^([A-z]){2}$/.test(e)) throw new o("publisherCountryCode", e);
                    this.publisherCountryCode_ = e.toUpperCase()
                }
                get publisherCountryCode() {
                    return this.publisherCountryCode_
                }
                set vendorListVersion(e) {
                    if ((e = Number(e) | 0) < 0) throw new o("vendorListVersion", e);
                    this.vendorListVersion_ = e
                }
                get vendorListVersion() {
                    return this.gvl ? this.gvl.vendorListVersion : this.vendorListVersion_
                }
                set policyVersion(e) {
                    if (this.policyVersion_ = parseInt(e, 10), this.policyVersion_ < 0) throw new o("policyVersion", e)
                }
                get policyVersion() {
                    return this.gvl ? this.gvl.tcfPolicyVersion : this.policyVersion_
                }
                set version(e) {
                    this.version_ = parseInt(e, 10)
                }
                get version() {
                    return this.version_
                }
                set isServiceSpecific(e) {
                    this.isServiceSpecific_ = e
                }
                get isServiceSpecific() {
                    return this.isServiceSpecific_
                }
                set useNonStandardStacks(e) {
                    this.useNonStandardStacks_ = e
                }
                get useNonStandardStacks() {
                    return this.useNonStandardStacks_
                }
                set supportOOB(e) {
                    this.supportOOB_ = e
                }
                get supportOOB() {
                    return this.supportOOB_
                }
                set purposeOneTreatment(e) {
                    this.purposeOneTreatment_ = e
                }
                get purposeOneTreatment() {
                    return this.purposeOneTreatment_
                }
                setAllVendorConsents() {
                    this.vendorConsents.set(this.gvl.vendors)
                }
                unsetAllVendorConsents() {
                    this.vendorConsents.empty()
                }
                setAllVendorsDisclosed() {
                    this.vendorsDisclosed.set(this.gvl.vendors)
                }
                unsetAllVendorsDisclosed() {
                    this.vendorsDisclosed.empty()
                }
                setAllVendorsAllowed() {
                    this.vendorsAllowed.set(this.gvl.vendors)
                }
                unsetAllVendorsAllowed() {
                    this.vendorsAllowed.empty()
                }
                setAllVendorLegitimateInterests() {
                    this.vendorLegitimateInterests.set(this.gvl.vendors)
                }
                unsetAllVendorLegitimateInterests() {
                    this.vendorLegitimateInterests.empty()
                }
                setAllPurposeConsents() {
                    this.purposeConsents.set(this.gvl.purposes)
                }
                unsetAllPurposeConsents() {
                    this.purposeConsents.empty()
                }
                setAllPurposeLegitimateInterests() {
                    this.purposeLegitimateInterests.set(this.gvl.purposes)
                }
                unsetAllPurposeLegitimateInterests() {
                    this.purposeLegitimateInterests.empty()
                }
                setAllSpecialFeatureOptins() {
                    this.specialFeatureOptins.set(this.gvl.specialFeatures)
                }
                unsetAllSpecialFeatureOptins() {
                    this.specialFeatureOptins.empty()
                }
                setAll() {
                    this.setAllVendorConsents(), this.setAllPurposeLegitimateInterests(), this.setAllSpecialFeatureOptins(), this.setAllPurposeConsents(), this.setAllVendorLegitimateInterests()
                }
                unsetAll() {
                    this.unsetAllVendorConsents(), this.unsetAllPurposeLegitimateInterests(), this.unsetAllSpecialFeatureOptins(), this.unsetAllPurposeConsents(), this.unsetAllVendorLegitimateInterests()
                }
                get numCustomPurposes() {
                    let e = this.numCustomPurposes_;
                    if ("object" == typeof this.customPurposes) {
                        const t = Object.keys(this.customPurposes).sort(((e, t) => Number(e) - Number(t)));
                        e = parseInt(t.pop(), 10)
                    }
                    return e
                }
                set numCustomPurposes(e) {
                    if (this.numCustomPurposes_ = parseInt(e, 10), this.numCustomPurposes_ < 0) throw new o("numCustomPurposes", e)
                }
                updated() {
                    const e = new Date,
                        t = new Date(Date.UTC(e.getUTCFullYear(), e.getUTCMonth(), e.getUTCDate()));
                    this.created = t, this.lastUpdated = t
                }
            }
            class F {
                static encode(e, t) {
                    let s, r = "";
                    return e = P.process(e, t), s = Array.isArray(t ? .segments) ? t.segments : new T(e, t)["" + e.version], s.forEach(((t, n) => {
                        let i = "";
                        n < s.length - 1 && (i = "."), r += R.encode(e, t) + i
                    })), r
                }
                static decode(e, t) {
                    const s = e.split("."),
                        r = s.length;
                    t || (t = new D);
                    for (let e = 0; e < r; e++) {
                        const r = s[e],
                            n = a.decode(r.charAt(0)).substr(0, C.segmentType),
                            i = E.ID_TO_KEY[b.decode(n, C.segmentType).toString()];
                        R.decode(r, t, i)
                    }
                    return t
                }
            }
        }
    }
]);
//# sourceMappingURL=5747.5fde4720823895a2c57b.js.map
/*1779552137,*/

/**
 * Copyright (c) 2017-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to use,
 * copy, modify, and distribute this software in source code or binary form for use
 * in connection with the web services and APIs provided by Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use of
 * this software is subject to the Facebook Platform Policy
 * [http://developers.facebook.com/policy/]. This copyright notice shall be
 * included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
(function _(e, t, n, r, o, a, i) {
    try {
        var l = window.console;
        if (l && Math.floor(new Date().getTime() / 1e3) - t > 10080 * 60 && l.warn("The Facebook JSSDK is more than 7 days old."), window[n] || !window.JSON) return;
        for (var s = window[n] = {
                __buffer: {
                    replay: function() {
                        for (var e = s.__buffer.calls, t = function() {
                                var t = window[n];
                                e[r][0].split(".").forEach(function(e) {
                                    return t = t[e]
                                }), t.apply(null, e[r][1])
                            }, r = 0; r < e.length; r++) t();
                        s.__buffer.calls = []
                    },
                    calls: [],
                    opts: null
                },
                getUserID: function() {
                    return ""
                },
                getAuthResponse: function() {
                    return null
                },
                getAccessToken: function() {
                    return null
                },
                init: function(e) {
                    s.__buffer.opts = e
                }
            }, u = 0; u < r.length; u++) {
            var c = r[u];
            if (!(c in s)) {
                for (var d = c.split("."), m = d.pop(), p = s, f = 0; f < d.length; f++) p = p[d[f]] || (p[d[f]] = {});
                p[m] = (function(e) {
                    if (e !== "init") return function() {
                        s.__buffer.calls.push([e, Array.from(arguments)])
                    }
                })(c)
            }
        }
        var g = document.createElement("script");
        g.src = e, g.async = !0, g.addEventListener("load", function() {
            window.FB_LOCAL_GLOBAL.require.call(null, "sdk.dynamic-module-loader").load(a)
        }), o && (g.crossOrigin = "anonymous");
        var h = document.getElementsByTagName("script")[0];
        h.parentNode && h.parentNode.insertBefore(g, h)
    } catch (e) {
        if (i) throw e;
        var y, C = a.JSSDKRuntimeConfig,
            b = C.revision,
            v = b === void 0 ? "" : b,
            S = C.scribeurl,
            R = S === void 0 ? "" : S,
            L = new Image;
        L.dataset.testid = "fbSDKErrorReport", L.crossOrigin = "anonymous";
        var E = {
                error: "LOAD",
                extra: {
                    name: e.name,
                    line: e.lineNumber || e.line,
                    script: e.fileName || e.sourceURL || e.script,
                    stack: e.stackTrace || e.stack,
                    revision: v,
                    namespace: n,
                    message: e.message
                }
            },
            k = encodeURIComponent(JSON.stringify(E));
        L.src = R + "?c=jssdk_error&m=" + k, (y = document.body) == null || y.appendChild(L)
    }
})("https:\/\/connect.facebook.net\/en_US\/bundle\/sdk.js\/", 1779552136, "FB", ["AppEvents.EventNames", "AppEvents.ParameterNames", "AppEvents.activateApp", "AppEvents.clearAppVersion", "AppEvents.clearUserID", "AppEvents.getAppVersion", "AppEvents.getUserID", "AppEvents.logEvent", "AppEvents.logPageView", "AppEvents.logPurchase", "AppEvents.setAppVersion", "AppEvents.setUserID", "AppEvents.updateUserProperties", "Canvas.Plugin.showPluginElement", "Canvas.Plugin.hidePluginElement", "Canvas.Prefetcher.addStaticResource", "Canvas.Prefetcher.setCollectionMode", "Canvas.getPageInfo", "Canvas.scrollTo", "Canvas.setAutoGrow", "Canvas.setDoneLoading", "Canvas.setSize", "Canvas.setUrlHandler", "Canvas.startTimer", "Canvas.stopTimer", "Event.subscribe", "Event.unsubscribe", "XFBML.parse", "addFriend", "api", "getAccessToken", "getAuthResponse", "getLoginStatus", "getUserID", "init", "login", "logout", "publish", "share", "ui"], true, {
    "JSSDKCanvasPrefetcherConfig": {
        "enabled": true,
        "excludedAppIds": [144959615576466, 768691303149786, 320528941393723],
        "sampleRate": 500
    },
    "JSSDKConfig": {
        "features": {
            "allow_non_canvas_app_events": false,
            "error_handling": {
                "rate": 4
            },
            "e2e_ping_tracking": {
                "rate": 0.1
            },
            "xd_timeout": {
                "rate": 1,
                "value": 60000
            },
            "use_bundle": false,
            "should_log_response_error": true,
            "popup_blocker_scribe_logging": {
                "rate": 100
            },
            "https_only_enforce_starting": 2538809200000,
            "https_only_learn_more": "https:\/\/developers.facebook.com\/blog\/post\/2018\/06\/08\/enforce-https-facebook-login\/",
            "https_only_scribe_logging": {
                "rate": 1
            },
            "log_perf": {
                "rate": 0.001
            },
            "use_x_xd": {
                "rate": 100
            },
            "cache_auth_response": {
                "rate": 100
            },
            "oauth_funnel_logger_version": 1,
            "force_popup_to_canvas_apps_with_id": [],
            "force_popup_to_all_canvas_app": false,
            "max_oauth_dialog_retries": {
                "rate": 100,
                "value": 10
            },
            "plugin_tags_blacklist": [],
            "idle_callback_wait_time_ms": 3000,
            "chat_plugin_facade_timeout_ms": 8000,
            "chat_plugin_facade_enabled_pageids": ["102493178867330", "107331571710078", "1032787970130843", "107771111665395", "261907812360345", "101305975654752", "275483104252055", "101664622285042", "112682113428700", "271628573687012", "385757598521443", "100545935690488"],
            "should_enable_ig_login_status_fetch": true,
            "log_cookies_usage": {
                "rate": 0.1
            },
            "allow_shadow_dom_for_apps_with_id": [520916077950649, 152351391599356, 132081130190180, 468663283258845, 409976882430412, 189845245141894, 360467581347, 274266067164],
            "allow_shadow_dom": true,
            "use_extended_dialog_path": {
                "rate": 100
            },
            "use_oauth_subdomain": {
                "rate": 100
            },
            "fedcm_enabled": true
        }
    },
    "JSSDKCssConfig": {
        "rules": ".fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0px;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:lucida grande,tahoma,verdana,arial,sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:400;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}\u0040keyframes fb_transform{0\u0025{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}\n\n.fb_dialog{background:#525252b3;position:absolute;top:-10000px;z-index:10001}.fb_dialog_advanced{border-radius:8px;padding:10px}.fb_dialog_content{background:#fff;color:#373737}.fb_dialog_close_icon{background:url(https:\/\/connect.facebook.net\/rsrc.php\/v4\/yq\/r\/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{left:5px;right:auto;top:5px}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https:\/\/connect.facebook.net\/rsrc.php\/v4\/yq\/r\/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent}.fb_dialog_close_icon:active{background:url(https:\/\/connect.facebook.net\/rsrc.php\/v4\/yq\/r\/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:700;margin:0}.fb_dialog_content .dialog_title>span{background:url(https:\/\/connect.facebook.net\/rsrc.php\/v4\/yd\/r\/Cou7n-nqK52.gif) no-repeat 5px 50\u0025;float:left;padding:5px 0 7px 26px}body.fb_hidden{height:100\u0025;left:0;margin:0;overflow:visible;position:absolute;top:-10000px;transform:none;width:100\u0025}.fb_dialog.fb_dialog_mobile.loading{background:url(https:\/\/connect.facebook.net\/rsrc.php\/v4\/ya\/r\/3rhSv5V8j3o.gif) #fff no-repeat 50\u0025 50\u0025;min-height:100\u0025;min-width:100\u0025;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{background:none;height:auto;min-height:initial;min-width:initial;width:auto}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100\u0025}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{clear:both;color:#fff;display:block;font-size:18px;padding-top:20px}#fb-root #fb_dialog_ipad_overlay{background:#0006;inset:0;min-height:100\u0025;position:absolute;width:100\u0025;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_mobile .fb_dialog_iframe{position:sticky;top:0}.fb_dialog_content .dialog_header{background:linear-gradient(from(#738aba),to(#2c4987));border-bottom:1px solid;border-color:#043b87;box-shadow:#fff 0 1px 1px -1px inset;color:#fff;font:700 14px Helvetica,sans-serif;text-overflow:ellipsis;text-shadow:rgba(0,30,84,.296875) 0px -1px 0px;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{height:43px;width:100\u0025}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:linear-gradient(from(#4267B2),to(#2a4887));background-clip:padding-box;border:1px solid #29487d;border-radius:3px;display:inline-block;line-height:18px;margin-top:3px;max-width:85px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{background:none;border:none;color:#fff;font:700 12px Helvetica,sans-serif;margin:2px -12px;padding:2px 6px 3px;text-shadow:rgba(0,30,84,.296875) 0px -1px 0px}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:700;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https:\/\/connect.facebook.net\/rsrc.php\/v4\/y9\/r\/jKEcVPZFk-2.gif) no-repeat 50\u0025 50\u0025;border:1px solid #4A4A4A;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f5f6f7;border:1px solid #4A4A4A;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https:\/\/connect.facebook.net\/rsrc.php\/v4\/y2\/r\/onuUJj0tCqE.png);background-position:50\u0025 50\u0025;background-repeat:no-repeat;height:24px;width:24px}\u0040keyframes rotateSpinner{0\u0025{transform:rotate(0)}to{transform:rotate(360deg)}}\n\n.fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100\u0025}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100\u0025}\n",
        "components": ["css:fb.css.base", "css:fb.css.dialog", "css:fb.css.iframewidget"]
    },
    "JSSDKRuntimeConfig": {
        "locale": "en_US",
        "revision": "1040066650",
        "rtl": false,
        "sdkab": null,
        "sdkns": "",
        "sdkurl": "https:\/\/connect.facebook.net\/en_US\/sdk.js",
        "scribeurl": "https:\/\/www.facebook.com\/platform\/scribe_endpoint.php\/"
    },
    "JSSDKXDConfig": {
        "XXdUrl": "\/x\/connect\/xd_arbiter\/?version=46",
        "useCdn": true
    },
    "UrlMapConfig": {
        "www": "www.facebook.com",
        "m": "m.facebook.com",
        "business": "business.facebook.com",
        "api": "api.facebook.com",
        "api_read": "api-read.facebook.com",
        "graph": "graph.facebook.com",
        "an": "an.facebook.com",
        "oauth": "oauth.facebook.com",
        "fbcdn": "static.xx.fbcdn.net",
        "cdn": "staticxx.facebook.com",
        "graph_facebook": "graph.facebook.com",
        "graph_gaming": "graph.fb.gg",
        "graph_instagram": "graph.instagram.com",
        "www_instagram": "www.instagram.com",
        "social_plugin": "socialplugin.facebook.net"
    },
    "JSSDKShadowCssConfig": {
        "css:fb.shadow.css.fb_login_button": ".fb_login_button_container{align-content:center;align-items:center;border:0;color:#fff;display:flex;font-family:Roboto,Freight Sans LF Pro,Helvetica,Arial,Lucida Grande,sans-serif;font-weight:700;margin:auto}.fb-button-main-element{display:flex;flex-wrap:nowrap;overflow:hidden}.fb-iframe-overlay{display:flex}.fb-button-main-element:hover{cursor:pointer}.fb-button-main-element:focus{filter:brightness(80\u0025)}.fb_button_label_element{align-items:center;display:flex;font-weight:700;justify-content:center}.fb_button_label{margin:auto;pointer-events:none}.fb_button_svg_logo{height:1.33em;margin-left:.4em;margin-right:.4em;padding:.065em}.login_fb_logo .f_logo_f{fill:transparent}.single_button_svg_logo{margin-bottom:.08em}\n"
    },
    "cr:6640": "PromiseImpl"
}, false);
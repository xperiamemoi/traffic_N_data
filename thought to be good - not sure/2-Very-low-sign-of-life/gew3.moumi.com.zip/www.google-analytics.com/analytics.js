(function() {
    var aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        p = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: aa(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        };
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var ba = this || self,
        q = function(a, b) {
            a = a.split(".");
            for (var c = ba, d; a.length && (d = a.shift());) a.length || b === void 0 ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = b
        };

    function r() {
        for (var a = t, b = {}, c = 0; c < a.length; ++c) b[a[c]] = c;
        return b
    }

    function u() {
        var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        a += a.toLowerCase() + "0123456789-_";
        return a + "."
    }
    var t, w;

    function ca(a) {
        function b(m) {
            for (; d < a.length;) {
                var l = a.charAt(d++),
                    k = w[l];
                if (k != null) return k;
                if (!/^[\s\xa0]*$/.test(l)) throw Error("Unknown base64 encoding at char: " + l);
            }
            return m
        }
        t = t || u();
        w = w || r();
        for (var c = "", d = 0;;) {
            var e = b(-1),
                f = b(0),
                g = b(64),
                h = b(64);
            if (h === 64 && e === -1) return c;
            c += String.fromCharCode(e << 2 | f >> 4);
            g !== 64 && (c += String.fromCharCode(f << 4 & 240 | g >> 2), h !== 64 && (c += String.fromCharCode(g << 6 & 192 | h)))
        }
    };
    var x = {};

    function y(a) {
        x.TAGGING = x.TAGGING || [];
        x.TAGGING[a] = !0
    };

    function da(a, b) {
        if (a && Array.isArray(a))
            for (var c = 0; c < a.length; c++)
                if (a[c] && b(a[c])) return a[c]
    }

    function z(a, b) {
        for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c])
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var A = function(a) {
        this.h = a
    };
    A.prototype.toString = function() {
        return this.h
    };
    new A("about:blank");
    new A("about:invalid#zClosurez");
    var B = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
    var C = window,
        D = window.history,
        E = document,
        F = navigator;

    function G() {
        var a = {},
            b = C.google_tag_data;
        C.google_tag_data = b === void 0 ? a : b;
        return C.google_tag_data
    };

    function ea(a) {
        var b = H();
        b.pending || (b.pending = []);
        da(b.pending, function(c) {
            return c.target.ctid === a.ctid && c.target.isDestination === a.isDestination
        }) || b.pending.push({
            target: a,
            onLoad: void 0
        })
    }

    function I() {
        var a = C.google_tags_first_party;
        Array.isArray(a) || (a = []);
        var b = {};
        a = p(a);
        for (var c = a.next(); !c.done; c = a.next()) b[c.value] = !0;
        return Object.freeze(b)
    }
    var fa = function() {
        this.container = {};
        this.destination = {};
        this.canonical = {};
        this.pending = [];
        this.injectedFirstPartyContainers = {};
        this.injectedFirstPartyContainers = I()
    };

    function H() {
        var a = G(),
            b = a.tidr;
        b && typeof b === "object" || (b = new fa, a.tidr = b);
        a = b;
        a.container || (a.container = {});
        a.destination || (a.destination = {});
        a.canonical || (a.canonical = {});
        a.pending || (a.pending = []);
        a.injectedFirstPartyContainers || (a.injectedFirstPartyContainers = I());
        return a
    };
    var J = /:[0-9]+$/;

    function K(a, b) {
        b && (b = String(b).toLowerCase());
        if (b === "protocol" || b === "port") a.protocol = L(a.protocol) || L(C.location.protocol);
        b === "port" ? a.port = String(Number(a.hostname ? a.port : C.location.port) || (a.protocol === "http" ? 80 : a.protocol === "https" ? 443 : "")) : b === "host" && (a.hostname = (a.hostname || C.location.hostname).replace(J, "").toLowerCase());
        return M(a, b)
    }

    function M(a, b, c) {
        var d = L(a.protocol);
        b && (b = String(b).toLowerCase());
        switch (b) {
            case "url_no_fragment":
                c = "";
                a && a.href && (c = a.href.indexOf("#"), c = c < 0 ? a.href : a.href.substring(0, c));
                a = c;
                break;
            case "protocol":
                a = d;
                break;
            case "host":
                a = a.hostname.replace(J, "").toLowerCase();
                c && (c = /^www\d*\./.exec(a)) && c[0] && (a = a.substring(c[0].length));
                break;
            case "port":
                a = String(Number(a.port) || (d === "http" ? 80 : d === "https" ? 443 : ""));
                break;
            case "path":
                a.pathname || a.hostname || y(1);
                a = a.pathname.substring(0, 1) === "/" ? a.pathname : "/" +
                    a.pathname;
                a = a.split("/");
                [].indexOf(a[a.length - 1]) >= 0 && (a[a.length - 1] = "");
                a = a.join("/");
                break;
            case "query":
                a = a.search.replace("?", "");
                break;
            case "extension":
                a = a.pathname.split(".");
                a = a.length > 1 ? a[a.length - 1] : "";
                a = a.split("/")[0];
                break;
            case "fragment":
                a = a.hash.replace("#", "");
                break;
            default:
                a = a && a.href
        }
        return a
    }

    function L(a) {
        return a ? a.replace(":", "").toLowerCase() : ""
    }
    var N = {},
        O = 0;

    function P(a) {
        var b = N[a];
        if (!b) {
            b = E.createElement("a");
            a && (b.href = a);
            var c = b.pathname;
            c[0] !== "/" && (a || y(1), c = "/" + c);
            var d = b.hostname.replace(J, "");
            b = {
                href: b.href,
                protocol: b.protocol,
                host: b.host,
                hostname: d,
                pathname: c,
                search: b.search,
                hash: b.hash,
                port: b.port
            };
            O < 5 && (N[a] = b, O++)
        }
        return b
    };
    var Q;

    function R() {
        function a(g) {
            c(g.target || g.srcElement || {})
        }

        function b(g) {
            d(g.target || g.srcElement || {})
        }
        var c = ha,
            d = ia,
            e = S();
        if (!e.init) {
            E.addEventListener && E.addEventListener("mousedown", a, !1);
            E.addEventListener && E.addEventListener("keyup", a, !1);
            E.addEventListener && E.addEventListener("submit", b, !1);
            var f = HTMLFormElement.prototype.submit;
            HTMLFormElement.prototype.submit = function() {
                d(this);
                f.call(this)
            };
            e.init = !0
        }
    }

    function T(a, b, c, d, e) {
        a = {
            callback: a,
            domains: b,
            fragment: c === 2,
            placement: c,
            forms: d,
            sameHost: e
        };
        S().decorators.push(a)
    }

    function U(a, b, c) {
        for (var d = S().decorators, e = {}, f = 0; f < d.length; ++f) {
            var g = d[f],
                h;
            if (h = !c || g.forms) a: {
                h = g.domains;
                var m = a,
                    l = !!g.sameHost;
                if (h && (l || m !== E.location.hostname))
                    for (var k = 0; k < h.length; k++)
                        if (h[k] instanceof RegExp) {
                            if (h[k].test(m)) {
                                h = !0;
                                break a
                            }
                        } else if (m.indexOf(h[k]) >= 0 || l && h[k].indexOf(m) >= 0) {
                    h = !0;
                    break a
                }
                h = !1
            }
            h && (h = g.placement, h === void 0 && (h = g.fragment ? 2 : 1), h === b && z(e, g.callback()))
        }
        return e
    }

    function S() {
        var a = G(),
            b = a.gl;
        b && b.decorators || (b = {
            decorators: []
        }, a.gl = b);
        return b
    };
    var V = [];

    function W(a) {
        return V[a] === void 0 ? !1 : V[a]
    };
    var ja = /(.*?)\*(.*?)\*(.*)/,
        ka = /([^?#]+)(\?[^#]*)?(#.*)?/;

    function X(a) {
        if (a = ka.exec(a)) return {
            g: a[1],
            query: a[2],
            fragment: a[3]
        }
    }

    function Y(a) {
        return new RegExp("(.*?)(^|&)" + a + "=([^&]*)&?(.*)")
    }

    function Z(a) {
        var b = [],
            c;
        for (c in a)
            if (a.hasOwnProperty(c)) {
                var d = a[c];
                if (d !== void 0 && d === d && d !== null && d.toString() !== "[object Object]") {
                    b.push(c);
                    var e = b,
                        f = e.push;
                    d = String(d);
                    t = t || u();
                    w = w || r();
                    for (var g = [], h = 0; h < d.length; h += 3) {
                        var m = h + 1 < d.length,
                            l = h + 2 < d.length,
                            k = d.charCodeAt(h),
                            n = m ? d.charCodeAt(h + 1) : 0,
                            v = l ? d.charCodeAt(h + 2) : 0,
                            ta = k >> 2;
                        k = (k & 3) << 4 | n >> 4;
                        n = (n & 15) << 2 | v >> 6;
                        v &= 63;
                        l || (v = 64, m || (n = 64));
                        g.push(t[ta], t[k], t[n], t[v])
                    }
                    f.call(e, g.join(""))
                }
            }
        a = b.join("*");
        return ["1", la(a), a].join("*")
    }

    function la(a, b) {
        a = [F.userAgent, (new Date).getTimezoneOffset(), F.userLanguage || F.language, Math.floor((new Date(Date.now())).getTime() / 60 / 1E3) - (b === void 0 ? 0 : b), a].join("*");
        if (!(b = Q)) {
            b = Array(256);
            for (var c = 0; c < 256; c++) {
                for (var d = c, e = 0; e < 8; e++) d = d & 1 ? d >>> 1 ^ 3988292384 : d >>> 1;
                b[c] = d
            }
        }
        Q = b;
        b = 4294967295;
        for (c = 0; c < a.length; c++) b = b >>> 8 ^ Q[(b ^ a.charCodeAt(c)) & 255];
        return ((b ^ -1) >>> 0).toString(36)
    }

    function ma(a) {
        return function(b) {
            var c = P(C.location.href),
                d = c.search.replace("?", "");
            var e = {};
            for (var f = p(d.split("&")), g = f.next(); !g.done; g = f.next()) {
                var h = p(g.value.split("="));
                g = h.next().value;
                for (var m, l = []; !(m = h.next()).done;) l.push(m.value);
                h = l;
                g = decodeURIComponent(g.replace(/\+/g, " "));
                g === "_gl" && (h = h.join("="), e[g] || (e[g] = []), e[g].push(h))
            }
            var k;
            e = (k = e._gl) == null ? void 0 : k[0];
            b.query = na(e || "") || {};
            k = K(c, "fragment");
            e = -1;
            k.length >= 4 && k.substring(0, 4) === "_gl=" ? e = 4 : (f = k.indexOf("&_gl="), f > 0 &&
                (e = f + 3 + 2));
            e < 0 ? e = void 0 : (f = k.indexOf("&", e), e = f < 0 ? k.substring(e) : k.substring(e, f));
            b.fragment = na(e || "") || {};
            a && oa(c, d, k)
        }
    }

    function pa(a, b) {
        if (a = Y(a).exec(b)) {
            var c = a[2],
                d = a[4];
            b = a[1];
            d && (b = b + c + d)
        }
        return b
    }

    function oa(a, b, c) {
        function d(f, g) {
            f = pa("_gl", f);
            f.length && (f = g + f);
            return f
        }
        if (D && D.replaceState) {
            var e = Y("_gl");
            if (e.test(b) || e.test(c)) a = K(a, "path"), b = d(b, "?"), c = d(c, "#"), D.replaceState({}, "", "" + a + b + c)
        }
    }
    var na = function(a) {
        try {
            a: {
                if (a) {
                    b: {
                        for (var b = 0; b < 3; ++b) {
                            var c = ja.exec(a);
                            if (c) {
                                var d = c;
                                break b
                            }
                            c: {
                                try {
                                    var e = decodeURIComponent(a);
                                    break c
                                } catch (v) {}
                                e = void 0
                            }
                            a = e || ""
                        }
                        d = void 0
                    }
                    if (d && d[1] === "1") {
                        var f = d[3];
                        b: {
                            var g = d[2];
                            for (d = 0; d < 3; ++d)
                                if (g === la(f, d)) {
                                    var h = !0;
                                    break b
                                }
                            h = !1
                        }
                        if (h) {
                            var m = f;
                            break a
                        }
                        y(7)
                    }
                }
                m = void 0
            }
            f = m;
            if (f !== void 0) {
                m = {};
                var l = f ? f.split("*") : [];
                for (f = 0; f + 1 < l.length; f += 2) {
                    var k = l[f],
                        n = ca(l[f + 1]);
                    m[k] = n
                }
                y(6);
                return m
            }
        }
        catch (v) {
            y(8)
        }
    };

    function qa(a, b, c, d, e) {
        function f(l) {
            l = pa(a, l);
            var k = l.charAt(l.length - 1);
            l && k !== "&" && (l += "&");
            return l + m
        }
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        c = X(c);
        if (!c) return "";
        var g = c.query || "",
            h = c.fragment || "",
            m = a + "=" + b;
        d ? h.substring(1).length !== 0 && e || (h = "#" + f(h.substring(1))) : g = "?" + f(g.substring(1));
        return "" + c.g + g + h
    }

    function ra(a, b) {
        function c(m, l, k) {
            a: {
                for (n in m)
                    if (m.hasOwnProperty(n)) {
                        var n = !0;
                        break a
                    }
                n = !1
            }
            n && (m = Z(m), d ? (W(3) || W(1) || !l) && sa("_gl", m, a, l, k) : ua("_gl", m, a, l, k))
        }
        var d = (a.tagName || "").toUpperCase() === "FORM",
            e = U(b, 1, d),
            f = U(b, 2, d),
            g = U(b, 4, d);
        b = U(b, 3, d);
        c(e, !1, !1);
        c(f, !0, !1);
        W(1) && c(g, !0, !0);
        for (var h in b) b.hasOwnProperty(h) && va(h, b[h], a)
    }

    function va(a, b, c, d) {
        c.tagName.toLowerCase() === "a" ? ua(a, b, c, d) : c.tagName.toLowerCase() === "form" && sa(a, b, c)
    }

    function ua(a, b, c, d, e) {
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        var f;
        if ((f = c.href) && !(f = !W(4) || d)) {
            var g = C.location.href;
            f = X(c.href);
            g = X(g);
            f = !(f && g && f.g === g.g && f.query === g.query && f.fragment)
        }
        f && (a = qa(a, b, c.href, d, e), B.test(a) && (c.href = a))
    }

    function sa(a, b, c, d, e) {
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        if (c) {
            var f = c.getAttribute("action") || "";
            if (f) {
                var g = (c.method || "").toLowerCase();
                if (g === "get" && !d) {
                    d = c.childNodes || [];
                    e = !1;
                    for (f = 0; f < d.length; f++)
                        if (g = d[f], g.name === a) {
                            g.setAttribute("value", b);
                            e = !0;
                            break
                        }
                    e || (d = E.createElement("input"), d.setAttribute("type", "hidden"), d.setAttribute("name", a), d.setAttribute("value", b), c.appendChild(d))
                } else if (g === "get" || g === "post") a = qa(a, b, f, d, e), B.test(a) && (c.action = a)
            }
        }
    }

    function ha(a) {
        try {
            a: {
                for (var b = 100; a && b > 0;) {
                    if (a.href && a.nodeName.match(/^a(?:rea)?$/i)) {
                        var c = a;
                        break a
                    }
                    a = a.parentNode;
                    b--
                }
                c = null
            }
            if (c) {
                var d = c.protocol;
                d !== "http:" && d !== "https:" || ra(c, c.hostname)
            }
        }
        catch (e) {}
    }

    function ia(a) {
        try {
            var b = a.getAttribute("action");
            if (b) {
                var c = K(P(b), "host");
                ra(a, c)
            }
        } catch (d) {}
    };
    q("google_tag_data.glBridge.auto", function(a, b, c, d) {
        R();
        c = c === "fragment" ? 2 : 1;
        d = !!d;
        T(a, b, c, d, !1);
        c === 2 && y(23);
        d && y(24)
    });
    q("google_tag_data.glBridge.passthrough", function(a, b, c) {
        R();
        T(a, [M(C.location, "host", !0)], b, !!c, !0)
    });
    q("google_tag_data.glBridge.decorate", function(a, b, c) {
        a = Z(a);
        va("_gl", a, b, !!c)
    });
    q("google_tag_data.glBridge.generate", Z);
    q("google_tag_data.glBridge.get", function(a, b) {
        var c = ma(!!b);
        b = S();
        b.data || (b.data = {
            query: {},
            fragment: {}
        }, c(b.data));
        c = {};
        if (b = b.data) z(c, b.query), a && z(c, b.fragment);
        return c
    });
    q("google_tag_data.tcBridge.registerUa", function(a, b) {
        a = a + "_" + b;
        var c = H(),
            d = c.destination[a];
        d ? (d.state = 2, d.containers = [], d.destinations = [b]) : c.destination[a] = {
            state: 2,
            containers: [],
            destinations: [b]
        }
    });
    q("google_tag_data.tcBridge.setSideload", function(a, b, c) {
        var d = {
            source: 5,
            fromContainerExecution: !0
        };
        a = {
            ctid: a + "_" + c,
            isDestination: !0
        };
        c = H().container[b];
        c && c.state !== 3 || (H().container[b] = {
            state: 1,
            context: d,
            parent: a
        }, ea({
            ctid: b,
            isDestination: !1
        }))
    });
    q("google_tag_data.tcBridge.isContainerLoaded", function(a) {
        return !!H().container[a]
    });
})(window);
(function() {
    function La(a) {
        var b = 1,
            c;
        if (a)
            for (b = 0, c = a.length - 1; c >= 0; c--) {
                var d = a.charCodeAt(c);
                b = (b << 6 & 268435455) + d + (d << 14);
                d = b & 266338304;
                b = d != 0 ? b ^ d >> 21 : b
            }
        return b
    };
    var $c = function(a) {
        this.C = a || []
    };
    $c.prototype.set = function(a) {
        this.C[a] = !0
    };
    $c.prototype.get = function(a) {
        return this.C[a]
    };
    $c.prototype.encode = function() {
        for (var a = [], b = 0; b < this.C.length; b++) this.C[b] && (a[Math.floor(b / 6)] ^= 1 << b % 6);
        for (b = 0; b < a.length; b++) a[b] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(a[b] || 0);
        return a.join("") + "~"
    };
    $c.prototype.union = function(a) {
        for (var b = this.C.slice(), c = 0; c < a.C.length; c++) b[c] = b[c] || a.C[c];
        return new $c(b)
    };
    var aa = window.GoogleAnalyticsObject,
        Y;
    if (Y = aa != void 0) Y = (aa.constructor + "").indexOf("String") > -1;
    var ha;
    if (ha = Y) {
        var wa = window.GoogleAnalyticsObject;
        ha = wa ? wa.replace(/^[\s\xa0]+|[\s\xa0]+$/g, "") : ""
    }
    var gb = ha || "ga",
        jd = /^(?:utma\.)?\d+\.\d+$/,
        kd = /^amp-[\w.-]{22,64}$/,
        Ba = !1;
    var vd = new $c;

    function J(a) {
        vd.set(a)
    }
    var Td = function(a) {
            a = Dd(a);
            return vd.union(new $c(a)).encode()
        },
        Dd = function(a) {
            a = a.get(Gd);
            ka(a) || (a = []);
            return a
        };
    var ea = function(a) {
            return typeof a == "function"
        },
        ka = function(a) {
            return Object.prototype.toString.call(Object(a)) == "[object Array]"
        },
        qa = function(a) {
            var b;
            if (b = a != void 0) b = (a.constructor + "").indexOf("String") > -1;
            return b
        },
        D = function(a, b) {
            return a.indexOf(b) == 0
        },
        sa = function(a) {
            return a ? a.replace(/^[\s\xa0]+|[\s\xa0]+$/g, "") : ""
        },
        ra = function() {
            for (var a = O.navigator.userAgent + (M.cookie ? M.cookie : "") + (M.referrer ? M.referrer : ""), b = a.length, c = O.history.length; c > 0;) a += c-- ^ b++;
            return [hd() ^ La(a) & 2147483647, Math.round((new Date).getTime() /
                1E3)].join(".")
        },
        ta = function(a) {
            var b = M.createElement("img");
            b.width = 1;
            b.height = 1;
            b.src = a;
            return b
        },
        ua = function() {},
        K = function(a) {
            if (encodeURIComponent instanceof Function) return encodeURIComponent(a);
            J(28);
            return a
        },
        L = function(a, b, c) {
            var d = M;
            try {
                d.addEventListener ? d.addEventListener(a, b, !!c) : d.attachEvent && d.attachEvent("on" + a, b)
            } catch (e) {
                J(27)
            }
        },
        f = /^[\w\-:/.?=&%!\[\]]+$/,
        Nd = /^[\w+/_-]+[=]{0,2}$/,
        ff = null,
        Id = function(a, b, c, d, e) {
            if (!ff) {
                ff = {
                    createScriptURL: function(ca) {
                        return ca
                    },
                    createHTML: function(ca) {
                        return ca
                    }
                };
                try {
                    ff = window.trustedTypes.createPolicy("google-analytics", ff)
                } catch (ca) {}
            }
            if (a) {
                var g = M.querySelector && M.querySelector("script[nonce]") || null;
                g = g ? g.nonce || g.getAttribute && g.getAttribute("nonce") || "" : "";
                c ? (e = d = "", b && f.test(b) && (d = ' id="' + b + '"'), g && Nd.test(g) && (e = ' nonce="' + g + '"'), f.test(a) && M.write(ff.createHTML("<script" + d + e + ' src="' + a + '">\x3c/script>'))) : (c = M.createElement("script"), c.type = "text/javascript", c.async = !0, c.src = ff.createScriptURL(a), d && (c.onload = d), e && (c.onerror = e), b && (c.id = b), g && c.setAttribute("nonce",
                    g), a = M.getElementsByTagName("script")[0], a.parentNode.insertBefore(c, a))
            }
        },
        be = function(a, b) {
            return E(M.location[b ? "href" : "search"], a)
        },
        E = function(a, b) {
            return (a = a.match("(?:&|#|\\?)" + K(b).replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1") + "=([^&#]*)")) && a.length == 2 ? a[1] : ""
        },
        xa = function() {
            var a = "" + M.location.hostname;
            return a.indexOf("www.") == 0 ? a.substring(4) : a
        },
        de = function(a, b) {
            var c = a.indexOf(b);
            if (c == 5 || c == 6)
                if (a = a.charAt(c + b.length), a == "/" || a == "?" || a == "" || a == ":") return !0;
            return !1
        },
        of = function(a, b) {
            var c =
                M.referrer;
            if (/^(https?|android-app):\/\//i.test(c)) {
                if (a) return c;
                a = "//" + M.location.hostname;
                if (!de(c, a)) return b && (b = a.replace(/\./g, "-") + ".cdn.ampproject.org", de(c, b)) ? void 0 : c
            }
        },
        za = function(a, b) {
            if (b.length == 1 && b[0] != null && typeof b[0] === "object") return b[0];
            for (var c = {}, d = Math.min(a.length + 1, b.length), e = 0; e < d; e++)
                if (typeof b[e] === "object") {
                    for (var g in b[e]) b[e].hasOwnProperty(g) && (c[g] = b[e][g]);
                    break
                } else e < a.length && (c[a[e]] = b[e]);
            return c
        },
        Ee = function(a, b) {
            for (var c = 0; c < a.length; c++)
                if (b ==
                    a[c]) return !0;
            return !1
        };
    var ee = function() {
        this.oa = [];
        this.ea = {};
        this.m = {}
    };
    ee.prototype.set = function(a, b, c) {
        this.oa.push(a);
        c ? this.m[":" + a] = b : this.ea[":" + a] = b
    };
    ee.prototype.get = function(a) {
        return this.m.hasOwnProperty(":" + a) ? this.m[":" + a] : this.ea[":" + a]
    };
    ee.prototype.map = function(a) {
        for (var b = 0; b < this.oa.length; b++) {
            var c = this.oa[b],
                d = this.get(c);
            d && a(c, d)
        }
    };
    var O = window,
        M = document,
        jf = document.currentScript ? document.currentScript.src : "",
        va = function(a, b) {
            return setTimeout(a, b)
        };
    var Qa = window,
        Za = document,
        G = function(a) {
            var b = Qa._gaUserPrefs;
            if (b && b.ioo && b.ioo() || Za.documentElement.hasAttribute("data-google-analytics-opt-out") || a && Qa["ga-disable-" + a] === !0) return !0;
            try {
                var c = Qa.external;
                if (c && c._gaUserPrefs && c._gaUserPrefs == "oo") return !0
            } catch (g) {}
            a = [];
            b = String(Za.cookie).split(";");
            for (c = 0; c < b.length; c++) {
                var d = b[c].split("="),
                    e = d[0].replace(/^\s*|\s*$/g, "");
                e && e == "AMP_TOKEN" && ((d = d.slice(1).join("=").replace(/^\s*|\s*$/g, "")) && (d = decodeURIComponent(d)), a.push(d))
            }
            for (b = 0; b <
                a.length; b++)
                if (a[b] == "$OPT_OUT") return !0;
            return Za.getElementById("__gaOptOutExtension") ? !0 : !1
        };
    var Ca = function(a) {
            var b = [],
                c = M.cookie.split(";");
            a = new RegExp("^\\s*" + a + "=\\s*(.*?)\\s*$");
            for (var d = 0; d < c.length; d++) {
                var e = c[d].match(a);
                e && b.push(e[1])
            }
            return b
        },
        zc = function(a, b, c, d, e, g, ca) {
            e = G(e) ? !1 : eb.test(M.location.hostname) || c == "/" && vc.test(d) ? !1 : !0;
            if (!e) return !1;
            b && b.length > 1200 && (b = b.substring(0, 1200));
            c = a + "=" + b + "; path=" + c + "; ";
            g && (c += "expires=" + (new Date((new Date).getTime() + g)).toGMTString() + "; ");
            d && d !== "none" && (c += "domain=" + d + ";");
            ca && (c += ca + ";");
            d = M.cookie;
            M.cookie = c;
            if (!(d = d != M.cookie)) a: {
                a =
                Ca(a);
                for (d = 0; d < a.length; d++)
                    if (b == a[d]) {
                        d = !0;
                        break a
                    }
                d = !1
            }
            return d
        },
        Cc = function(a) {
            return encodeURIComponent ? encodeURIComponent(a).replace(/\(/g, "%28").replace(/\)/g, "%29") : a
        },
        vc = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
        eb = /(^|\.)doubleclick\.net$/i;
    var ya = function(a) {
        var b = [],
            c = M.cookie.split(";");
        a = new RegExp("^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$");
        for (var d = 0; d < c.length; d++) {
            var e = c[d].match(a);
            e && b.push({
                ja: e[1],
                value: e[2],
                timestamp: Number(e[2].split(".")[1]) || 0
            })
        }
        b.sort(function(g, ca) {
            return ca.timestamp - g.timestamp
        });
        return b
    };

    function ob(a, b, c) {
        b = ya(b);
        var d = {};
        if (!b || !b.length) return d;
        for (var e = 0; e < b.length; e++) {
            var g = b[e].value.split(".");
            if (g[0] !== "1" || c && g.length < 3 || !c && g.length !== 3) a && (a.na = !0);
            else if (Number(g[1])) {
                d[b[e].ja] ? a && (a.pa = !0) : d[b[e].ja] = [];
                var ca = {
                    version: g[0],
                    timestamp: Number(g[1]) * 1E3,
                    qa: g[2]
                };
                c && g.length > 3 && (ca.labels = g.slice(3));
                d[b[e].ja].push(ca)
            }
        }
        return d
    };
    var Fa, Ga, fb, Ab, ja = /^https?:\/\/[^/]*cdn\.ampproject\.org\//,
        Ue = /^(?:www\.|m\.|amp\.)+/,
        Ub = [],
        da = function(a) {
            if (ye(a[Kd])) {
                if (Ab === void 0) {
                    var b;
                    if (b = (b = De.get()) && b._ga || void 0) Ab = b, J(81)
                }
                if (Ab !== void 0) return a[Q] || (a[Q] = Ab), !1
            }
            if (a[Kd]) {
                J(67);
                if (a[ac] && a[ac] != "cookie") return !1;
                if (Ab !== void 0) a[Q] || (a[Q] = Ab);
                else {
                    a: {
                        b = String(a[W] || xa());
                        var c = String(a[Yb] || "/"),
                            d = Ca(String(a[U] || "_ga"));b = na(d, b, c);
                        if (!b || jd.test(b)) b = !0;
                        else if (b = Ca("AMP_TOKEN"), b.length == 0) b = !0;
                        else {
                            if (b.length == 1 && (b = decodeURIComponent(b[0]),
                                    b == "$RETRIEVING" || b == "$OPT_OUT" || b == "$ERROR" || b == "$NOT_FOUND")) {
                                b = !0;
                                break a
                            }
                            b = !1
                        }
                    }
                    if (b && tc(ic, String(a[Na]))) return !0
                }
            }
            return !1
        },
        ic = function() {
            Z.D([ua])
        },
        tc = function(a, b) {
            var c = Ca("AMP_TOKEN");
            if (c.length > 1) return J(55), !1;
            c = decodeURIComponent(c[0] || "");
            if (c == "$OPT_OUT" || c == "$ERROR" || G(b)) return J(62), !1;
            if (!ja.test(M.referrer) && c == "$NOT_FOUND") return J(68), !1;
            if (Ab !== void 0) return J(56), va(function() {
                a(Ab)
            }, 0), !0;
            if (Fa) return Ub.push(a), !0;
            if (c == "$RETRIEVING") return J(57), va(function() {
                    tc(a, b)
                },
                1E4), !0;
            Fa = !0;
            c && c[0] != "$" || (xc("$RETRIEVING", 3E4), setTimeout(Mc, 3E4), c = "");
            return Pc(c, b) ? (Ub.push(a), !0) : !1
        },
        Pc = function(a, b, c) {
            if (!window.JSON) return J(58), !1;
            var d = O.XMLHttpRequest;
            if (!d) return J(59), !1;
            var e = new d;
            if (!("withCredentials" in e)) return J(60), !1;
            e.open("POST", (c || "https://ampcid.google.com/v1/publisher:getClientId") + "?key=AIzaSyA65lEHUEizIsNtlbNo-l2K18dT680nsaM", !0);
            e.withCredentials = !0;
            e.setRequestHeader("Content-Type", "text/plain");
            e.onload = function() {
                Fa = !1;
                if (e.readyState == 4) {
                    try {
                        e.status !=
                            200 && (J(61), Qc("", "$ERROR", 3E4));
                        var g = JSON.parse(e.responseText);
                        g.optOut ? (J(63), Qc("", "$OPT_OUT", 31536E6)) : g.clientId ? Qc(g.clientId, g.securityToken, 31536E6) : !c && g.alternateUrl ? (Ga && clearTimeout(Ga), Fa = !0, Pc(a, b, g.alternateUrl)) : (J(64), Qc("", "$NOT_FOUND", 36E5))
                    } catch (ca) {
                        J(65), Qc("", "$ERROR", 3E4)
                    }
                    e = null
                }
            };
            d = {
                originScope: "AMP_ECID_GOOGLE"
            };
            a && (d.securityToken = a);
            e.send(JSON.stringify(d));
            Ga = va(function() {
                J(66);
                Qc("", "$ERROR", 3E4)
            }, 1E4);
            return !0
        },
        Mc = function() {
            Fa = !1
        },
        xc = function(a, b) {
            if (fb === void 0) {
                fb =
                    "";
                for (var c = id(), d = 0; d < c.length; d++) {
                    var e = c[d];
                    if (zc("AMP_TOKEN", encodeURIComponent(a), "/", e, "", b)) {
                        fb = e;
                        return
                    }
                }
            }
            zc("AMP_TOKEN", encodeURIComponent(a), "/", fb, "", b)
        },
        Qc = function(a, b, c) {
            Ga && clearTimeout(Ga);
            b && xc(b, c);
            Ab = a;
            b = Ub;
            Ub = [];
            for (c = 0; c < b.length; c++) b[c](a)
        },
        ye = function(a) {
            a: {
                if (ja.test(M.referrer)) {
                    var b = M.location.hostname.replace(Ue, "");
                    b: {
                        var c = M.referrer;c = c.replace(/^https?:\/\//, "");
                        var d = c.replace(/^[^/]+/, "").split("/"),
                            e = d[2];d = (d = e == "s" ? d[3] : e) ? decodeURIComponent(d) : d;
                        if (!d) {
                            if (c.indexOf("xn--") ==
                                0) {
                                c = "";
                                break b
                            }(c = c.match(/(.*)\.cdn\.ampproject\.org\/?$/)) && c.length == 2 && (d = c[1].replace(/-/g, ".").replace(/\.\./g, "-"))
                        }
                        c = d ? d.replace(Ue, "") : ""
                    }(d = b === c) || (c = "." + c, d = b.substring(b.length - c.length, b.length) === c);
                    if (d) {
                        b = !0;
                        break a
                    } else J(78)
                }
                b = !1
            }
            return b && a !== !1
        };
    var bd = function(a) {
            return (a ? "https:" : Ba || "https:" == M.location.protocol ? "https:" : "http:") + "//www.google-analytics.com"
        },
        Ge = function(a) {
            switch (a) {
                default:
                    case 1:
                    return "https://www.google-analytics.com/gtm/js?id=";
                case 2:
                        return "https://www.googletagmanager.com/gtag/js?id="
            }
        },
        Da = function(a) {
            this.name = "len";
            this.message = a + "-8192"
        },
        ba = function(a, b, c) {
            c = c || ua;
            if (b.length <= 2036) wc(a, b, c);
            else if (b.length <= 8192) x(a, b, c) || wd(a, b, c) || wc(a, b, c);
            else throw new Da(b.length);
        },
        pe = function(a, b, c, d) {
            d = d || ua;
            wd(a +
                "?" + b, "", d, c)
        },
        wc = function(a, b, c) {
            var d = ta(a + "?" + b);
            d.onload = d.onerror = function() {
                d.onload = null;
                d.onerror = null;
                c()
            }
        },
        wd = function(a, b, c, d) {
            var e = O.XMLHttpRequest;
            if (!e) return !1;
            var g = new e;
            if (!("withCredentials" in g)) return !1;
            a = a.replace(/^http:/, "https:");
            g.open("POST", a, !0);
            g.withCredentials = !0;
            g.setRequestHeader("Content-Type", "text/plain");
            g.onreadystatechange = function() {
                if (g.readyState == 4) {
                    if (d && g.getResponseHeader("Content-Type") === "text/plain") try {
                        Ea(d, g.responseText, c)
                    } catch (ca) {
                        c()
                    } else c();
                    g = null
                }
            };
            g.send(b);
            return !0
        },
        Ea = function(a, b, c) {
            if (b.length < 1) c();
            else if (a.count++ > 3) c();
            else {
                var d = b.charAt(0);
                if (d === "1") oc(a, b.substring(1), c);
                else if (a.V && d === "2") {
                    var e = b.substring(1).split(","),
                        g = 0;
                    b = function() {
                        ++g === e.length && c()
                    };
                    for (d = 0; d < e.length; d++) oc(a, e[d], b)
                } else c()
            }
        },
        oc = function(a, b, c) {
            if (b.length === 0) c();
            else switch (b.charAt(0)) {
                case "d":
                    pe("https://stats.g.doubleclick.net/j/collect", a.U, a, c);
                    break;
                case "g":
                    wc("https://www.google.com/ads/ga-audiences", a.google, c);
                    (b = b.substring(1)) &&
                    /^[a-z.]{1,6}$/.test(b) && wc("https://www.google.%/ads/ga-audiences".replace("%", b), a.google, ua);
                    break;
                case "G":
                    if (a.V) {
                        a.V("G-" + b.substring(1));
                        c();
                        break
                    }
                case "x":
                    if (a.V) {
                        a.V();
                        c();
                        break
                    }
                case "c":
                    if (a.V) {
                        a.V(b.substring(1));
                        c();
                        break
                    }
                default:
                    c()
            }
        },
        x = function(a, b, c) {
            return O.navigator.sendBeacon ? O.navigator.sendBeacon(a, b) ? (c(), !0) : !1 : !1
        };
    var qc = function() {
            return O.gaData = O.gaData || {}
        },
        h = function(a) {
            var b = qc();
            return b[a] = b[a] || {}
        };
    var Ha = function() {
        this.M = []
    };
    Ha.prototype.add = function(a) {
        this.M.push(a)
    };
    Ha.prototype.D = function(a) {
        try {
            for (var b = 0; b < this.M.length; b++) {
                var c = a.get(this.M[b]);
                c && ea(c) && c.call(O, a)
            }
        } catch (d) {}
        b = a.get(Ia);
        b != ua && ea(b) && (a.set(Ia, ua, !0), setTimeout(b, 10))
    };

    function Ja(a) {
        if (a.get(Ka) != 100 && La(P(a, Q)) % 1E4 >= R(a, Ka) * 100) throw "abort";
    }

    function Ma(a) {
        if (G(P(a, Na))) throw "abort";
    }

    function Oa() {
        var a = M.location.protocol;
        if (a != "http:" && a != "https:") throw "abort";
    }

    function pf(a) {
        var b = !1,
            c = !1;
        if (vd.get(89)) {
            c = !0;
            var d = a.get(kb),
                e = M.location;
            if (e) {
                var g = e.pathname || "";
                g.charAt(0) != "/" && (g = "/" + g);
                e = e.protocol + "//" + e.hostname + g + e.search;
                d && d.indexOf(e) === 0 || (b = !0)
            }
        }!c && vd.get(90) && (c = !0, d = a.get(lb), e = of (!!a.get(ec), !!a.get(Kd)), d !== e && (b = !0));
        !c && vd.get(91) && (c = !0, a.get(qf) !== M.title && (b = !0));
        return c && !b
    }

    function Pa(a) {
        try {
            O.navigator.sendBeacon ? J(42) : O.XMLHttpRequest && "withCredentials" in new O.XMLHttpRequest && J(40)
        } catch (c) {}
        a.set(ld, Td(a), !0);
        a.set(Ac, R(a, Ac) + 1);
        var b = [];
        ue.map(function(c, d) {
            d.F && (c = a.get(c), c != void 0 && c != d.defaultValue && (typeof c == "boolean" && (c *= 1), b.push(d.F + "=" + K("" + c))))
        });
        a.get(xe) === !1 && b.push("npa=1");
        b.push("z=" + Bd());
        pf(a) && J(109);
        a.set(Ra, b.join("&"), !0)
    }

    function Sa(a) {
        var b = P(a, fa);
        !b && a.get(Vd) && (b = "beacon");
        var c = P(a, gd),
            d = P(a, oe),
            e = c || (d || bd(!1) + "") + "/collect",
            g = !(!c && !d),
            ca = a.Z(Ia),
            l = P(a, Ra),
            k = P(a, Na);
        switch (P(a, ad)) {
            case "d":
                if (!g && !P(a, Od)) {
                    ca && ca();
                    break
                }
                e = c || (d || bd(!1) + "") + "/j/collect";
                b = a.get(qe) || void 0;
                pe(e, l, b, ca);
                break;
            default:
                g ? b ? (ca = ca || ua, b == "image" ? wc(e, l, ca) : b == "xhr" && wd(e, l, ca) || b == "beacon" && x(e, l, ca) || ba(e, l, ca)) : ba(e, l, ca) : ca && ca()
        }
        l = h(k);
        ca = l.hitcount;
        l.hitcount = ca ? ca + 1 : 1;
        l.first_hit || (l.first_hit = (new Date).getTime());
        delete h(k).pending_experiments;
        a.set(Ia, ua, !0);
        if (rf(a))
            if (l = P(a, Na), k = sf[l])
                for (l = 0; l < k.length; ++l)(ca = tf(k[l]).q) && ca.length < 30 && ca.push && ca.push(uf(a));
            else vf[l] = vf[l] || [], vf[l].length < 30 && vf[l].push(uf(a))
    }

    function Hc(a) {
        qc().expId && a.set(Nc, qc().expId);
        qc().expVar && a.set(Oc, qc().expVar);
        var b = P(a, Na);
        if (b = h(b).pending_experiments) {
            var c = [];
            for (d in b) b.hasOwnProperty(d) && b[d] && c.push(encodeURIComponent(d) + "." + encodeURIComponent(b[d]));
            var d = c.join("!")
        } else d = void 0;
        d && ((b = a.get(m)) && (d = b + "!" + d), a.set(m, d, !0))
    }

    function cd() {
        if (O.navigator && O.navigator.loadPurpose == "preview") throw "abort";
    }

    function yd(a) {
        var b = O.gaDevIds || [];
        if (ka(b)) {
            var c = a.get("&did");
            qa(c) && c.length > 0 && (b = b.concat(c.split(",")));
            c = [];
            for (var d = 0; d < b.length; d++) Ee(c, b[d]) || c.push(b[d]);
            c.length != 0 && a.set("&did", c.join(","), !0)
        }
    }

    function vb(a) {
        if (!a.get(Na)) throw "abort";
    }

    function Pe(a) {
        try {
            if (!a.get(Qe) && (a.set(Qe, !0), !a.get("&gtm"))) {
                var b = void 0,
                    c = void 0;
                lf(be("gtm_debug")) && (b = 2);
                !b && D(M.referrer, "https://tagassistant.google.com/") && (b = 3);
                !b && Ee(M.cookie.split("; "), "__TAG_ASSISTANT=x") && (b = 4);
                b || (c = M.documentElement.getAttribute("data-tag-assistant-present"), lf(c) && (b = 5));
                if (b) {
                    O["google.tagmanager.debugui2.queue"] || (O["google.tagmanager.debugui2.queue"] = [], Id("https://www.google-analytics.com/debug/bootstrap?id=" + a.get(Na) + "&src=LEGACY&cond=" + b));
                    var d = M.currentScript;
                    O["google.tagmanager.debugui2.queue"].push({
                        messageType: "LEGACY_CONTAINER_STARTING",
                        data: {
                            id: a.get(Na),
                            scriptSource: d && d.src || ""
                        }
                    })
                }
            }
        } catch (e) {}
    }

    function lf(a) {
        if (a == null || a.length === 0) return !1;
        a = Number(a);
        var b = Date.now();
        return a < b + 3E5 && a > b - 9E5
    };
    var hd = function() {
            return Math.round(Math.random() * 2147483647)
        },
        Bd = function() {
            try {
                var a = new Uint32Array(1);
                O.crypto.getRandomValues(a);
                return a[0] & 2147483647
            } catch (b) {
                return hd()
            }
        };

    function Ta(a) {
        var b = R(a, Ua);
        b >= 500 && J(15);
        var c = P(a, Va);
        if (c != "transaction" && c != "item") {
            c = R(a, Wa);
            var d = (new Date).getTime(),
                e = R(a, Xa);
            e == 0 && a.set(Xa, d);
            e = Math.round((d - e) * 2 / 1E3);
            e > 0 && (c = Math.min(c + e, 20), a.set(Xa, d));
            if (c <= 0) throw "abort";
            a.set(Wa, --c)
        }
        a.set(Ua, ++b)
    };
    var Ya = function() {
        this.data = new ee
    };
    Ya.prototype.get = function(a) {
        var b = $a(a),
            c = this.data.get(a);
        b && c == void 0 && (c = ea(b.defaultValue) ? b.defaultValue() : b.defaultValue);
        return b && b.Z ? b.Z(this, a, c) : c
    };
    var P = function(a, b) {
            a = a.get(b);
            return a == void 0 ? "" : "" + a
        },
        R = function(a, b) {
            a = a.get(b);
            return a == void 0 || a === "" ? 0 : Number(a)
        };
    Ya.prototype.Z = function(a) {
        return (a = this.get(a)) && ea(a) ? a : ua
    };
    Ya.prototype.set = function(a, b, c) {
        if (a)
            if (typeof a === "object")
                for (var d in a) a.hasOwnProperty(d) && ab(this, d, a[d], c);
            else ab(this, a, b, c)
    };
    var ab = function(a, b, c, d) {
            if (c == void 0) switch (b) {
                case Na:
                case Va:
                case hb:
            } else switch (b) {
                case Va:
                case Ra:
                case pb:
                case kb:
                case lb:
                case mb:
                case sb:
                case nb:
                case qf:
                case qb:
                case rb:
                case Q:
                case tb:
                case Eb:
                case Fb:
                case Gb:
                case Hb:
                case Ib:
                case ub:
                case xb:
                case yb:
                case Bb:
                case Cb:
                case Db:
                case Mb:
                case Nb:
                case Ob:
                case Jb:
                case Kb:
                case Lb:
                case fc:
                case Ec:
                case U:
                case W:
                case Yb:
                case $b:
                case ac:
                case Fc:
                    break;
                case jb:
                case Fd:
                case Pb:
                case Zb:
                case Ka:
                case dc:
                    break;
                case zb:
                    break;
                case ge:
                case Oe:
                case "forceSSL":
                case bc:
                case cc:
                case ec:
                    break;
                case Ia:
                case Qb:
                case Rb:
                case Sb:
                case Tb:
                case Vb:
                case Wb:
                case Xb:
                    break;
                case V:
                    break;
                case Na:
                    wb.test(c);
                    break;
                case Ve:
                    break;
                case We:
            }
            var e = $a(b);
            e && e.o ? e.o(a, b, c, d) : a.data.set(b, c, d)
        },
        gf = {
            hitPayload: 88,
            location: 89,
            referrer: 90,
            title: 91,
            buildHitTask: 93,
            sendHitTask: 94,
            displayFeaturesTask: 95,
            customTask: 97,
            cookieName: 98,
            cookieDomain: 99,
            cookiePath: 100,
            cookieExpires: 101,
            cookieUpdate: 102,
            cookieFlags: 103,
            storage: 104,
            _x_19: 105,
            transportUrl: 106,
            allowAdFeatures: 107,
            sampleRate: 108
        };

    function hf(a, b) {
        var c = gf[a];
        c && J(c);
        a === "displayFeaturesTask" && b == void 0 && J(96);
        /.*Task$/.test(a) && J(92)
    }

    function mf(a, b) {
        if (a)
            if (typeof a === "object")
                for (var c in a) a.hasOwnProperty(c) && hf(c, b);
            else hf(a, b)
    };
    var ue = new ee,
        ve = [],
        bb = function(a, b, c, d, e) {
            this.name = a;
            this.F = b;
            this.Z = d;
            this.o = e;
            this.defaultValue = c
        };

    function $a(a) {
        var b = ue.get(a);
        if (!b)
            for (var c = 0; c < ve.length; c++) {
                var d = ve[c],
                    e = d[0].exec(a);
                if (e) {
                    b = d[1](e);
                    ue.set(b.name, b);
                    break
                }
            }
        return b
    }

    function yc(a) {
        var b;
        ue.map(function(c, d) {
            d.F == a && (b = d)
        });
        return b && b.name
    }

    function S(a, b, c, d, e) {
        a = new bb(a, b, c, d, e);
        ue.set(a.name, a);
        return a.name
    }

    function cb(a, b) {
        ve.push([new RegExp("^" + a + "$"), b])
    }

    function T(a, b, c) {
        return S(a, b, c, void 0, db)
    }

    function db() {};
    var hb = T("apiVersion", "v"),
        ib = T("clientVersion", "_v"),
        We = S("anonymizeIp", "aip"),
        jb = S("adSenseId", "a"),
        Va = S("hitType", "t"),
        Ia = S("hitCallback"),
        Ra = S("hitPayload"),
        ge = S("nonInteraction", "ni"),
        Fc = S("currencyCode", "cu");
    S("dataSource", "ds");
    var Vd = S("useBeacon", void 0, !1),
        fa = S("transport"),
        Ve = S("sessionControl", "sc", "");
    S("sessionGroup", "sg");
    var Fd = S("queueTime", "qt"),
        Ac = S("_s", "_s"),
        Ie = S("_no_slc"),
        pb = S("screenName", "cd"),
        kb = S("location", "dl", ""),
        lb = S("referrer", "dr"),
        mb = S("page", "dp", ""),
        sb = S("hostname", "dh"),
        nb = S("language", "ul"),
        qf = S("title", "dt", function() {
            return M.title || void 0
        });
    cb("contentGroup([0-9]+)", function(a) {
        return new bb(a[0], "cg" + a[1])
    });
    var qb = S("screenResolution", "sr"),
        rb = S("viewportSize", "vp"),
        tb = S("campaignId", "ci"),
        Eb = S("campaignName", "cn"),
        Fb = S("campaignSource", "cs"),
        Gb = S("campaignMedium", "cm"),
        Hb = S("campaignKeyword", "ck"),
        Ib = S("campaignContent", "cc"),
        ub = S("eventCategory", "ec"),
        xb = S("eventAction", "ea"),
        yb = S("eventLabel", "el"),
        zb = S("eventValue", "ev"),
        Bb = S("socialNetwork", "sn"),
        Cb = S("socialAction", "sa"),
        Db = S("socialTarget", "st");
    S("l1", "plt");
    S("l2", "pdt");
    S("l3", "dns");
    S("l4", "rrt");
    S("l5", "srt");
    S("l6", "tcp");
    S("l7", "dit");
    S("l8", "clt");
    S("l9", "_gst");
    S("l10", "_gbt");
    S("l11", "_cst");
    S("l12", "_cbt");
    var Mb = S("timingCategory", "utc"),
        Nb = S("timingVar", "utv"),
        Ob = S("timingLabel", "utl"),
        Pb = S("timingValue", "utt"),
        Jb = S("appName", "an"),
        Kb = S("appVersion", "av", ""),
        Lb = S("appId", "aid", ""),
        fc = S("appInstallerId", "aiid", ""),
        Ec = S("exDescription", "exd"),
        Oe = S("exFatal", "exf"),
        Nc = S("expId", "xid"),
        Oc = S("expVar", "xvar"),
        m = S("exp", "exp"),
        Rc = S("_utma", "_utma"),
        Sc = S("_utmz", "_utmz"),
        Tc = S("_utmht", "_utmht"),
        Ua = S("_hc", void 0, 0),
        Xa = S("_ti", void 0, 0),
        Wa = S("_to", void 0, 20);
    cb("dimension([0-9]+)", function(a) {
        return new bb(a[0], "cd" + a[1])
    });
    cb("metric([0-9]+)", function(a) {
        return new bb(a[0], "cm" + a[1])
    });
    S("linkerParam", void 0, void 0, Bc, db);
    var Ze = T("_cd2l", void 0, !1),
        ld = S("usage", "_u"),
        Gd = S("_um");
    S("forceSSL", void 0, void 0, function() {
        return Ba
    }, function(a, b, c) {
        J(34);
        Ba = !!c
    });
    var ed = S("_j1", "jid"),
        ia = S("_j2", "gjid");
    cb("\\&(.*)", function(a) {
        var b = new bb(a[0], a[1]),
            c = yc(a[0].substring(1));
        c && (b.Z = function(d) {
            return d.get(c)
        }, b.o = function(d, e, g, ca) {
            d.set(c, g, ca)
        }, b.F = void 0);
        return b
    });
    var Qb = T("_oot"),
        dd = S("previewTask"),
        Rb = S("checkProtocolTask"),
        md = S("validationTask"),
        Sb = S("checkStorageTask"),
        Uc = S("historyImportTask"),
        Tb = S("samplerTask"),
        Vb = S("_rlt"),
        Wb = S("buildHitTask"),
        Xb = S("sendHitTask"),
        Vc = S("ceTask"),
        zd = S("devIdTask"),
        Cd = S("timingTask"),
        Ld = S("displayFeaturesTask"),
        oa = S("customTask"),
        ze = S("fpsCrossDomainTask"),
        Re = T("_cta"),
        V = T("name"),
        Q = T("clientId", "cid"),
        n = T("clientIdTime"),
        xd = T("storedClientId"),
        Ad = S("userId", "uid"),
        Na = T("trackingId", "tid"),
        U = T("cookieName", void 0, "_ga"),
        W = T("cookieDomain"),
        Yb = T("cookiePath", void 0, "/"),
        Zb = T("cookieExpires", void 0, 63072E3),
        Hd = T("cookieUpdate", void 0, !0),
        Be = T("cookieFlags", void 0, ""),
        $b = T("legacyCookieDomain"),
        Wc = T("legacyHistoryImport", void 0, !0),
        ac = T("storage", void 0, "cookie"),
        bc = T("allowLinker", void 0, !1),
        cc = T("allowAnchor", void 0, !0),
        Ka = T("sampleRate", "sf", 100),
        dc = T("siteSpeedSampleRate", void 0, 1),
        ec = T("alwaysSendReferrer", void 0, !1),
        I = T("_gid", "_gid"),
        la = T("_gcn"),
        Kd = T("useAmpClientId"),
        ce = T("_gclid"),
        fe = T("_gt"),
        he = T("_ge", void 0,
            7776E6),
        ie = T("_gclsrc"),
        je = T("storeGac", void 0, !0),
        oe = S("_x_19"),
        Ae = S("_fplc", "_fplc"),
        F = T("_cs"),
        Je = T("_useUp", void 0, !1),
        Le = S("up", "up"),
        Qe = S("_tac", void 0, !1),
        Se = T("_gbraid"),
        Te = T("_gbt"),
        bf = T("_gbe", void 0, 7776E6),
        gd = S("transportUrl"),
        Md = S("_r", "_r"),
        Od = S("_slc", "_slc"),
        qe = S("_dp"),
        ad = S("_jt", void 0, "n"),
        Ud = S("allowAdFeatures", void 0, !0),
        xe = S("allowAdPersonalizationSignals", void 0, !0);

    function X(a, b, c, d) {
        b[a] = function() {
            try {
                return d && J(d), c.apply(this, arguments)
            } catch (e) {
                throw e;
            }
        }
    };
    var Ed = function(a) {
            if (a.get(ac) == "cookie") return a = Ca("FPLC"), a.length > 0 ? a[0] : void 0
        },
        Fe = function(a) {
            var b;
            if (b = P(a, oe) && a.get(Ze)) b = De.get(a.get(cc)), b = !(b && b._fplc);
            b && !Ed(a) && a.set(Ae, "0")
        };
    var hc = !1,
        mc = function(a) {
            if (P(a, ac) == "cookie") {
                if (a.get(Hd) || P(a, xd) != P(a, Q)) {
                    var b = 1E3 * R(a, Zb);
                    ma(a, Q, U, b);
                    a.data.set(xd, P(a, Q))
                }(a.get(Hd) || uc(a) != P(a, I)) && ma(a, I, la, 864E5);
                if (a.get(je)) {
                    if (b = P(a, ce)) {
                        var c = Math.min(R(a, he), R(a, Zb) * 1E3);
                        c = c === 0 ? 0 : Math.min(c, R(a, fe) * 1E3 + c - (new Date).getTime());
                        a.data.set(he, c);
                        var d = {},
                            e = P(a, fe),
                            g = P(a, ie),
                            ca = kc(P(a, Yb)),
                            l = lc(P(a, W)),
                            k = P(a, Na),
                            w = P(a, Be);
                        g && g != "aw.ds" ? d && (d.ua = !0) : (b = ["1", e, Cc(b)].join("."), c >= 0 && (d && (d.ta = !0), zc("_gac_" + Cc(k), b, ca, l, k, c, w)));
                        le(d)
                    }
                } else J(75);
                a.get(je) && (b = P(a, Se)) && (c = Math.min(R(a, bf), R(a, Zb) * 1E3), c = c === 0 ? 0 : Math.min(c, R(a, Te) * 1E3 + c - (new Date).getTime()), a.data.set(bf, c), d = {}, w = P(a, Te), ca = kc(P(a, Yb)), l = lc(P(a, W)), k = P(a, Na), a = P(a, Be), b = ["1", w, Cc(b)].join("."), c >= 0 && (d && (d.ta = !0), zc("_gac_gb_" + Cc(k), b, ca, l, k, c, a)), ef(d))
            }
        },
        ma = function(a, b, c, d) {
            var e = nd(a, b);
            if (e) {
                c = P(a, c);
                var g = kc(P(a, Yb)),
                    ca = lc(P(a, W)),
                    l = P(a, Be),
                    k = P(a, Na);
                if (ca != "auto") zc(c, e, g, ca, k, d, l) && (hc = !0);
                else {
                    J(32);
                    for (var w = id(), Ce = 0; Ce < w.length; Ce++)
                        if (ca = w[Ce], a.data.set(W,
                                ca), e = nd(a, b), zc(c, e, g, ca, k, d, l)) {
                            hc = !0;
                            return
                        }
                    a.data.set(W, "auto")
                }
            }
        },
        uc = function(a) {
            var b = Ca(P(a, la));
            return Xd(a, b)
        },
        nc = function(a) {
            if (P(a, ac) == "cookie" && !hc && (mc(a), !hc)) throw "abort";
        },
        Yc = function(a) {
            if (a.get(Wc)) {
                var b = P(a, W),
                    c = P(a, $b) || xa(),
                    d = Xc("__utma", c, b);
                d && (J(19), a.set(Tc, (new Date).getTime(), !0), a.set(Rc, d.R), (b = Xc("__utmz", c, b)) && d.hash == b.hash && a.set(Sc, b.R))
            }
        },
        nd = function(a, b) {
            b = Cc(P(a, b));
            var c = P(a, W);
            c = lc(c).split(".").length;
            a = jc(P(a, Yb));
            a > 1 && (c += "-" + a);
            return b ? ["GA1", c, b].join(".") :
                ""
        },
        Xd = function(a, b) {
            return na(b, P(a, W), P(a, Yb))
        },
        na = function(a, b, c) {
            if (!a || a.length < 1) J(12);
            else {
                for (var d = [], e = 0; e < a.length; e++) {
                    var g = a[e];
                    var ca = g.split(".");
                    var l = ca.shift();
                    (l == "GA1" || l == "1") && ca.length > 1 ? (g = ca.shift().split("-"), g.length == 1 && (g[1] = "1"), g[0] *= 1, g[1] *= 1, ca = {
                        H: g,
                        l: ca.join(".")
                    }) : ca = kd.test(g) ? {
                        H: [0, 0],
                        l: g
                    } : void 0;
                    ca && d.push(ca)
                }
                if (d.length == 1) return J(13), d[0].l;
                if (d.length == 0) J(12);
                else {
                    J(14);
                    d = Gc(d, lc(b).split(".").length, 0);
                    if (d.length == 1) return d[0].l;
                    d = Gc(d, jc(c), 1);
                    d.length >
                        1 && J(41);
                    return d[0] && d[0].l
                }
            }
        },
        Gc = function(a, b, c) {
            for (var d = [], e = [], g, ca = 0; ca < a.length; ca++) {
                var l = a[ca];
                l.H[c] == b ? d.push(l) : g == void 0 || l.H[c] < g ? (e = [l], g = l.H[c]) : l.H[c] == g && e.push(l)
            }
            return d.length > 0 ? d : e
        },
        lc = function(a) {
            return a.indexOf(".") == 0 ? a.substr(1) : a
        },
        id = function() {
            var a = [],
                b = xa().split(".");
            if (b.length == 4) {
                var c = b[b.length - 1];
                if (parseInt(c, 10) == c) return ["none"]
            }
            for (c = b.length - 2; c >= 0; c--) a.push(b.slice(c).join("."));
            b = M.location.hostname;
            eb.test(b) || vc.test(b) || a.push("none");
            return a
        },
        kc = function(a) {
            if (!a) return "/";
            a.length > 1 && a.lastIndexOf("/") == a.length - 1 && (a = a.substr(0, a.length - 1));
            a.indexOf("/") != 0 && (a = "/" + a);
            return a
        },
        jc = function(a) {
            a = kc(a);
            return a == "/" ? 1 : a.split("/").length
        },
        le = function(a) {
            a.ta && J(77);
            a.na && J(74);
            a.pa && J(73);
            a.ua && J(69)
        },
        ef = function(a) {
            a.ta && J(85);
            a.na && J(86);
            a.pa && J(87)
        };

    function Xc(a, b, c) {
        b == "none" && (b = "");
        var d = [],
            e = Ca(a);
        a = a == "__utma" ? 6 : 2;
        for (var g = 0; g < e.length; g++) {
            var ca = ("" + e[g]).split(".");
            ca.length >= a && d.push({
                hash: ca[0],
                R: e[g],
                O: ca
            })
        }
        if (d.length != 0) return d.length == 1 ? d[0] : Zc(b, d) || Zc(c, d) || Zc(null, d) || d[0]
    }

    function Zc(a, b) {
        if (a == null) var c = a = 1;
        else c = La(a), a = La(D(a, ".") ? a.substring(1) : "." + a);
        for (var d = 0; d < b.length; d++)
            if (b[d].hash == c || b[d].hash == a) return b[d]
    };
    var Jc = new RegExp(/^https?:\/\/([^\/:]+)/),
        De = O.google_tag_data.glBridge,
        Kc = RegExp("(.*)([?&#])(?:_ga=[^&#]*)(?:&?)(.*)"),
        od = RegExp("(.*)([?&#])(?:_gac=[^&#]*)(?:&?)(.*)");

    function Bc(a) {
        if (a.get(Ze)) return J(35), De.generate($e(a));
        var b = P(a, Q),
            c = P(a, I) || "";
        b = "_ga=2." + K(pa(c + b, 0) + "." + c + "-" + b);
        (a = af(a)) ? (J(44), a = "&_gac=1." + K([pa(a.qa, 0), a.timestamp, a.qa].join("."))) : a = "";
        return b + a
    }

    function Ic(a, b) {
        var c = new Date;
        return La([a, O.navigator.userAgent, c.getTimezoneOffset(), c.getYear(), c.getDate(), c.getHours(), c.getMinutes() + b].join("."))
    }

    function pa(a, b) {
        var c = new Date,
            d = O.navigator,
            e = c.getHours() + Math.floor((c.getMinutes() + b) / 60);
        return La([a, d.userAgent, d.language || "", c.getTimezoneOffset(), c.getYear(), c.getDate() + Math.floor(e / 24), (24 + e) % 24, (60 + c.getMinutes() + b) % 60].join("."))
    }
    var Dc = function(a) {
        J(48);
        this.target = a;
        this.T = !1
    };
    Dc.prototype.ca = function(a, b) {
        if (a) {
            if (this.target.get(Ze)) return De.decorate($e(this.target), a, b);
            if (a.tagName) {
                if (a.tagName.toLowerCase() == "a") {
                    a.href && (a.href = qd(this, a.href, b));
                    return
                }
                if (a.tagName.toLowerCase() == "form") return rd(this, a)
            }
            if (typeof a == "string") return qd(this, a, b)
        }
    };
    var qd = function(a, b, c) {
            var d = Kc.exec(b);
            d && d.length >= 3 && (b = d[1] + (d[3] ? d[2] + d[3] : ""));
            (d = od.exec(b)) && d.length >= 3 && (b = d[1] + (d[3] ? d[2] + d[3] : ""));
            a = a.target.get("linkerParam");
            d = b.indexOf("?");
            var e = b.indexOf("#");
            b = c ? b + ((e == -1 ? "#" : "&") + a) : e == -1 ? b + ((d === -1 ? "?" : "&") + a) : b.substring(0, e) + (d === -1 || d > e ? "?" : "&") + a + b.substring(e);
            b = b.replace(/&+_ga=/, "&_ga=");
            return b = b.replace(RegExp("&+_gac="), "&_gac=")
        },
        rd = function(a, b) {
            if (b && b.action)
                if (b.method.toLowerCase() == "get") {
                    a = a.target.get("linkerParam").split("&");
                    for (var c = 0; c < a.length; c++) {
                        var d = a[c].split("="),
                            e = d[1];
                        d = d[0];
                        for (var g = b.childNodes || [], ca = !1, l = 0; l < g.length; l++)
                            if (g[l].name == d) {
                                g[l].setAttribute("value", e);
                                ca = !0;
                                break
                            }
                        ca || (g = M.createElement("input"), g.setAttribute("type", "hidden"), g.setAttribute("name", d), g.setAttribute("value", e), b.appendChild(g))
                    }
                } else b.method.toLowerCase() == "post" && (b.action = qd(a, b.action))
        };
    Dc.prototype.S = function(a, b, c) {
        function d(g) {
            try {
                g = g || O.event;
                a: {
                    var ca = g.target || g.srcElement;
                    for (g = 100; ca && g > 0;) {
                        if (ca.href && ca.nodeName.match(/^a(?:rea)?$/i)) {
                            var l = ca;
                            break a
                        }
                        ca = ca.parentNode;
                        g--
                    }
                    l = {}
                }(l.protocol == "http:" || l.protocol == "https:") && sd(a, l.hostname || "") && l.href && (l.href = qd(e, l.href, b))
            } catch (k) {
                J(26)
            }
        }
        var e = this;
        this.target.get(Ze) ? De.auto(function() {
            return $e(e.target)
        }, a, b ? "fragment" : "", c) : (this.T || (this.T = !0, L("mousedown", d, !1), L("keyup", d, !1)), c && L("submit", function(g) {
            g = g || O.event;
            if ((g = g.target || g.srcElement) && g.action) {
                var ca = g.action.match(Jc);
                ca && sd(a, ca[1]) && rd(e, g)
            }
        }))
    };
    Dc.prototype.$ = function(a) {
        if (a) {
            var b = this,
                c = b.target.get(F);
            c !== void 0 && De.passthrough(function() {
                if (c("analytics_storage")) return {};
                var d = {};
                return d._ga = b.target.get(Q), d._up = "1", d
            }, 1, !0)
        }
    };

    function sd(a, b) {
        if (b == M.location.hostname) return !1;
        for (var c = 0; c < a.length; c++)
            if (a[c] instanceof RegExp) {
                if (a[c].test(b)) return !0
            } else if (b.indexOf(a[c]) >= 0) return !0;
        return !1
    }

    function ke(a, b) {
        return b != Ic(a, 0) && b != Ic(a, -1) && b != Ic(a, -2) && b != pa(a, 0) && b != pa(a, -1) && b != pa(a, -2)
    }

    function $e(a) {
        var b = af(a),
            c = {};
        c._ga = a.get(Q);
        c._gid = a.get(I) || void 0;
        c._gac = b ? [b.qa, b.timestamp].join(".") : void 0;
        b = a.get(Ae);
        a = Ed(a);
        return c._fplc = b && b !== "0" ? b : a, c
    }

    function af(a) {
        function b(e) {
            return e == void 0 || e === "" ? 0 : Number(e)
        }
        var c = a.get(ce);
        if (c && a.get(je)) {
            var d = b(a.get(fe));
            if (d * 1E3 + b(a.get(he)) <= (new Date).getTime()) J(76);
            else return {
                timestamp: d,
                qa: c
            }
        }
    };
    var p = /^(GTM|OPT)-[A-Z0-9]+$/,
        q = /;_gaexp=[^;]*/g,
        r = /;((__utma=)|([^;=]+=GAX?\d+\.))[^;]*/g,
        Aa = /^https?:\/\/[\w\-.]+\.google.com(:\d+)?\/optimize\/opt-launch\.html\?.*$/,
        nf = 0,
        wf = {},
        t = function(a) {
            function b(d, e) {
                e && (c += "&" + d + "=" + K(e))
            }
            var c = Ge(a.type) + K(a.id);
            a.B != "dataLayer" && b("l", a.B);
            b("cx", a.context);
            b("t", a.target);
            b("cid", a.clientId);
            b("cidt", a.ka);
            b("gac", a.la);
            b("aip", a.ia);
            a.sa && b("_slc", "1");
            a.sync && b("m", "sync");
            b("cycle", a.G);
            a.qa && b("gclid", a.qa);
            Aa.test(M.referrer) && b("cb", String(hd()));
            return c
        },
        He = function(a, b) {
            var c = (new Date).getTime();
            O[a.B] = O[a.B] || [];
            wf[a.B] || (wf[a.B] = !0, c = {
                "gtm.start": c
            }, a.sync || (c.event = "gtm.js"), O[a.B].push(c));
            a.type === 2 && function(d, e, g) {
                O[a.B].push(arguments)
            }("config", a.id, b)
        },
        Ke = function(a, b, c, d) {
            c = c || {};
            var e = O.google_tag_data.tcBridge;
            if (p.test(b)) var g = 1;
            else {
                var ca = b.split("-");
                ca.length > 1 && ca[0] !== "GTM" && ca[0] !== "UA" && (g = 2)
            }
            if (g) {
                ca = {
                    id: b,
                    type: g,
                    B: c.dataLayer || "dataLayer",
                    G: !1
                };
                var l = void 0;
                a.get("&gtm") == b && (ca.G = !0);
                switch (g) {
                    case 1:
                        ca.ia = !!a.get("anonymizeIp");
                        ca.sync = d;
                        b = String(a.get("name"));
                        b != "t0" && (ca.target = b);
                        G(String(a.get("trackingId"))) || (ca.clientId = String(a.get(Q)), ca.ka = Number(a.get(n)), b = c.palindrome ? r : q, b = (b = M.cookie.replace(/^|(; +)/g, ";").match(b)) ? b.sort().join("").substring(1) : void 0, ca.la = b, ca.qa = E(P(a, kb), "gclid"));
                        break;
                    case 2:
                        if (e.isContainerLoaded(b) || nf >= 20) return;
                        nf++;
                        ca.context = "c";
                        l = {};
                        l = (l.is_legacy_loaded = !0, l);
                        ca.sa = !0;
                        e.registerUa(a.get("name"), a.get("trackingId"));
                        e.setSideload(a.get("name"), b, a.get("trackingId"))
                }
                He(ca,
                    l);
                return t(ca)
            }
        };
    var Jd = function(a, b) {
            b || (b = (b = P(a, V)) && b != "t0" ? Wd.test(b) ? "_gat_" + Cc(P(a, Na)) : "_gat_" + Cc(b) : "_gat");
            this.Y = b
        },
        Rd = function(a, b) {
            var c = b.get(Wb);
            b.set(Wb, function(e) {
                Pd(a, e, ed);
                Pd(a, e, ia);
                var g = c(e);
                Qd(a, e);
                return g
            });
            var d = b.get(Xb);
            b.set(Xb, function(e) {
                var g = d(e);
                if (se(e)) {
                    J(80);
                    var ca = {
                        U: re(e, 1),
                        google: re(e, 2),
                        count: 0
                    };
                    pe("https://stats.g.doubleclick.net/j/collect", ca.U, ca);
                    e.set(ed, "", !0)
                }
                return g
            })
        },
        Pd = function(a, b, c) {
            b.get(Ud) === !1 || b.get(c) || (Ca(a.Y)[0] == "1" ? b.set(c, "", !0) : b.set(c, "" + hd(), !0))
        },
        Qd = function(a, b) {
            se(b) && zc(a.Y, "1", P(b, Yb), P(b, W), P(b, Na), 6E4, P(b, Be))
        },
        se = function(a) {
            return !!a.get(ed) && a.get(Ud) !== !1
        },
        Ne = function(a) {
            var b = P(a, Na);
            return !H[b] && rf(a)
        },
        re = function(a, b) {
            var c = new ee,
                d = function(g) {
                    $a(g).F && c.set($a(g).F, a.get(g))
                };
            d(hb);
            d(ib);
            d(Na);
            d(Q);
            d(ed);
            b == 1 && (d(Ad), d(ia), d(I));
            a.get(xe) === !1 && c.set("npa", "1");
            c.set($a(ld).F, Td(a));
            var e = "";
            c.map(function(g, ca) {
                e += K(g) + "=";
                e += K("" + ca) + "&"
            });
            e += "z=" + hd();
            b == 1 ? e = "t=dc&aip=1&_r=3&" + e : b == 2 && (e = "t=sr&aip=1&_r=4&slf_rd=1&" + e);
            return e
        },
        Me = function(a) {
            if (Ne(a)) {
                var b = P(a, Na);
                H[b] = !0;
                return function(c) {
                    if (c && !H[c]) {
                        var d = Ke(a, c);
                        if (d) {
                            var e = d.indexOf("&_slc=1") > 0;
                            H[c] = !0;
                            sf[b] || (sf[b] = []);
                            e && (sf[b].push(c), tf(c, vf[b]));
                            Id(d)
                        }
                    }
                }
            }
        },
        Wd = /^gtm\d+$/;
    var fd = function(a, b) {
        a = a.model;
        if (!a.get("dcLoaded")) {
            var c = new $c(Dd(a));
            c.set(29);
            a.set(Gd, c.C);
            b = b || {};
            var d;
            b[U] && (d = Cc(b[U]));
            b = new Jd(a, d);
            Rd(b, a);
            a.set("dcLoaded", !0)
        }
    };
    var Sd = function(a) {
        var b = a.get(ac) != "cookie" ? !1 : !0;
        if (b) {
            b = new Jd(a);
            var c = a.get("dcLoaded");
            c || (Pd(b, a, ed), Pd(b, a, ia), Qd(b, a));
            b = !c && se(a);
            c = Ne(a);
            b && a.set(Md, 1, !0);
            c && a.set(Od, 1, !0);
            if (b || c) a.set(ad, "d", !0), J(79), a.set(qe, {
                U: re(a, 1),
                google: re(a, 2),
                V: Me(a),
                count: 0
            }, !0)
        }
    };
    var Lc = function() {
        var a = O.gaGlobal = O.gaGlobal || {};
        return a.hid = a.hid || hd()
    };
    var wb = /^(UA|YT|MO|GP)-(\d+)-(\d+)$/,
        pc = function(a) {
            function b(e, g) {
                d.model.data.set(e, g);
                a.hasOwnProperty(e) && hf(e, g)
            }

            function c(e, g) {
                d.model.data.set(e, g);
                d.filters.add(e)
            }
            var d = this;
            this.model = new Ya;
            this.filters = new Ha;
            b(V, a[V]);
            b(Na, sa(a[Na]));
            b(U, a[U]);
            b(W, a[W] || xa());
            b(Yb, a[Yb]);
            b(Zb, a[Zb]);
            b(Hd, a[Hd]);
            b(Be, a[Be]);
            b($b, a[$b]);
            b(Wc, a[Wc]);
            b(bc, a[bc]);
            b(cc, a[cc]);
            b(Ka, a[Ka]);
            b(dc, a[dc]);
            b(ec, a[ec]);
            b(ac, a[ac]);
            b(Ad, a[Ad]);
            b(n, a[n]);
            b(Kd, a[Kd]);
            b(je, a[je]);
            b(Ze, a[Ze]);
            b(oe, a[oe]);
            b(Je, a[Je]);
            b(F, a[F]);
            b(hb, 1);
            b(ib, "j102");
            c(Re, Pe);
            c(Qb, Ma);
            c(oa, ua);
            c(dd, cd);
            c(Rb, Oa);
            c(md, vb);
            c(Sb, nc);
            c(Uc, Yc);
            c(Tb, Ja);
            c(Vb, Ta);
            c(Vc, Hc);
            c(zd, yd);
            c(Ld, Sd);
            c(ze, Fe);
            c(Wb, Pa);
            c(Xb, Sa);
            c(Cd, ua);
            pd(this.model);
            td(this.model, a[Q]);
            this.model.set(jb, Lc())
        };
    pc.prototype.get = function(a) {
        return this.model.get(a)
    };
    pc.prototype.set = function(a, b) {
        this.model.set(a, b);
        mf(a, b)
    };
    pc.prototype.send = function(a) {
        if (!(arguments.length < 1)) {
            if (typeof arguments[0] === "string") {
                var b = arguments[0];
                var c = [].slice.call(arguments, 1)
            } else b = arguments[0] && arguments[0][Va], c = arguments;
            b && (c = za(me[b] || [], c), c[Va] = b, mf(c), this.model.set(c, void 0, !0), this.filters.D(this.model), this.model.data.m = {})
        }
    };
    pc.prototype.ma = function(a, b) {
        var c = this;
        u(a, c, b) || (v(a, function() {
            u(a, c, b)
        }), y(String(c.get(V)), a, void 0, b, !0))
    };

    function td(a, b) {
        var c = P(a, U);
        a.data.set(la, c == "_ga" ? "_gid" : c + "_gid");
        if (P(a, ac) == "cookie") {
            hc = !1;
            c = Ca(P(a, U));
            c = Xd(a, c);
            if (!c) {
                c = P(a, W);
                var d = P(a, $b) || xa();
                c = Xc("__utma", d, c);
                c != void 0 ? (J(10), c = c.O[1] + "." + c.O[2]) : c = void 0
            }
            c && (hc = !0);
            if (d = c && !a.get(Hd))
                if (d = c.split("."), d.length != 2) d = !1;
                else if (d = Number(d[1])) {
                var e = R(a, Zb);
                d = d + e < (new Date).getTime() / 1E3
            } else d = !1;
            d && (c = void 0);
            c && (a.data.set(xd, c), a.data.set(Q, c), (c = uc(a)) && a.data.set(I, c));
            a.get(je) && (c = a.get(ce), d = a.get(ie), !c || d && d != "aw.ds") &&
                (c = {}, d = (M ? ob(c) : {})[P(a, Na)], le(c), d && d.length != 0 && (c = d[0], a.data.set(fe, c.timestamp / 1E3), a.data.set(ce, c.qa)));
            a.get(je) && (c = a.get(Se), d = {}, e = (M ? ob(d, "_gac_gb", !0) : {})[P(a, Na)], ef(d), e && e.length != 0 && (d = e[0], e = d.qa, c && c !== e || (d.labels && d.labels.length && (e += "." + d.labels.join(".")), a.data.set(Te, d.timestamp / 1E3), a.data.set(Se, e))))
        }
        if (a.get(Hd)) {
            c = be("_ga", !!a.get(cc));
            var g = be("_gl", !!a.get(cc));
            d = De.get(a.get(cc));
            e = d._ga;
            g && g.indexOf("_ga*") > 0 && !e && J(30);
            if (b || !a.get(Je)) g = !1;
            else if (g = a.get(F),
                g === void 0 || g("analytics_storage")) g = !1;
            else {
                J(84);
                a.data.set(Le, 1);
                if (g = d._up)
                    if (g = Jc.exec(M.referrer)) {
                        g = g[1];
                        var ca = M.location.hostname;
                        g = ca === g || ca.indexOf("." + g) >= 0 || g.indexOf("." + ca) >= 0 ? !0 : !1
                    } else g = !1;
                g = g ? !0 : !1
            }
            ca = d.gclid;
            var l = d._gac;
            if (c || e || ca || l)
                if (c && e && J(36), a.get(bc) || ye(a.get(Kd)) || g) {
                    if (e && (J(38), a.data.set(Q, e), d._gid && (J(51), a.data.set(I, d._gid))), ca ? (J(82), a.data.set(ce, ca), d.gclsrc && a.data.set(ie, d.gclsrc)) : l && (e = l.split(".")) && e.length === 2 && (J(37), a.data.set(ce, e[0]), a.data.set(fe,
                            e[1])), (d = d._fplc) && P(a, oe) && (J(83), a.data.set(Ae, d)), c) b: if (d = c.indexOf("."), d == -1) J(22);
                        else {
                            e = c.substring(0, d);
                            g = c.substring(d + 1);
                            d = g.indexOf(".");
                            c = g.substring(0, d);
                            g = g.substring(d + 1);
                            if (e == "1") {
                                if (d = g, ke(d, c)) {
                                    J(23);
                                    break b
                                }
                            } else if (e == "2") {
                                d = g.indexOf("-");
                                e = "";
                                d > 0 ? (e = g.substring(0, d), d = g.substring(d + 1)) : d = g.substring(1);
                                if (ke(e + d, c)) {
                                    J(53);
                                    break b
                                }
                                e && (J(2), a.data.set(I, e))
                            } else {
                                J(22);
                                break b
                            }
                            J(11);
                            a.data.set(Q, d);
                            if (c = be("_gac", !!a.get(cc))) c = c.split("."), c[0] != "1" || c.length != 4 ? J(72) : ke(c[3],
                                c[1]) ? J(71) : (a.data.set(ce, c[3]), a.data.set(fe, c[2]), J(70))
                        }
                } else J(21)
        }
        b && (J(9), a.data.set(Q, K(b)));
        a.get(Q) || (b = (b = O.gaGlobal) && b.from_cookie && P(a, ac) !== "cookie" ? void 0 : (b = b && b.vid) && b.search(jd) !== -1 ? b : void 0, b ? (J(17), a.data.set(Q, b)) : (J(8), a.data.set(Q, ra())));
        a.get(I) || (J(3), a.data.set(I, ra()));
        mc(a);
        b = O.gaGlobal = O.gaGlobal || {};
        c = P(a, Q);
        a = c === P(a, xd);
        if (b.vid == void 0 || a && !b.from_cookie) b.vid = c, b.from_cookie = a
    }

    function pd(a) {
        var b = O.navigator,
            c = O.screen,
            d = M.location;
        a.set(lb, of (!!a.get(ec), !!a.get(Kd)));
        if (d) {
            var e = d.pathname || "";
            e.charAt(0) != "/" && (J(31), e = "/" + e);
            a.set(kb, d.protocol + "//" + d.hostname + e + d.search)
        }
        c && a.set(qb, c.width + "x" + c.height);
        c = M.documentElement;
        var g = (e = M.body) && e.clientWidth && e.clientHeight,
            ca = [];
        c && c.clientWidth && c.clientHeight && (M.compatMode === "CSS1Compat" || !g) ? ca = [c.clientWidth, c.clientHeight] : g && (ca = [e.clientWidth, e.clientHeight]);
        c = ca[0] <= 0 || ca[1] <= 0 ? "" : ca.join("x");
        a.set(rb, c);
        a.set(nb, (b && (b.language || b.browserLanguage) || "").toLowerCase());
        a.data.set(ce, be("gclid", !0));
        a.data.set(ie, be("gclsrc", !0));
        a.data.set(fe, Math.round((new Date).getTime() / 1E3));
        a.get(ce) || (a.data.set(Se, be("wbraid", !0)), a.data.set(Te, Math.round((new Date).getTime() / 1E3)));
        if (d && a.get(cc) && (b = M.location.hash)) {
            b = b.split(/[?&#]+/);
            d = [];
            for (c = 0; c < b.length; ++c)(D(b[c], "utm_id") || D(b[c], "utm_campaign") || D(b[c], "utm_source") || D(b[c], "utm_medium") || D(b[c], "utm_term") || D(b[c], "utm_content") || D(b[c], "gclid") ||
                D(b[c], "dclid") || D(b[c], "gclsrc") || D(b[c], "wbraid")) && d.push(b[c]);
            d.length > 0 && (b = "#" + d.join("&"), a.set(kb, a.get(kb) + b))
        }
    }
    var me = {
        pageview: [mb],
        event: [ub, xb, yb, zb],
        social: [Bb, Cb, Db],
        timing: [Mb, Nb, Pb, Ob]
    };
    var rc = function(a) {
            if (M.visibilityState == "prerender") return !1;
            a();
            return !0
        },
        z = function(a) {
            if (!rc(a)) {
                J(16);
                var b = !1,
                    c = function() {
                        if (!b && rc(a)) {
                            b = !0;
                            var d = M;
                            d.removeEventListener ? d.removeEventListener("visibilitychange", c, !1) : d.detachEvent && d.detachEvent("onvisibilitychange", c)
                        }
                    };
                L("visibilitychange", c)
            }
        };
    var te = /^(?:(\w+)\.)?(?:(\w+):)?(\w+)$/,
        sc = function(a) {
            if (ea(a[0])) this.u = a[0];
            else {
                var b = te.exec(a[0]);
                b != null && b.length == 4 && (this.da = b[1] || "t0", this.K = b[2] || "", this.methodName = b[3], this.aa = [].slice.call(a, 1), this.K || (this.A = this.methodName == "create", this.i = this.methodName == "require", this.g = this.methodName == "provide", this.ba = this.methodName == "remove"), this.i && (this.aa.length >= 3 ? (this.X = this.aa[1], this.W = this.aa[2]) : this.aa[1] && (qa(this.aa[1]) ? this.X = this.aa[1] : this.W = this.aa[1])));
                b = a[1];
                a = a[2];
                if (!this.methodName) throw "abort";
                if (this.i && (!qa(b) || b == "")) throw "abort";
                if (this.g && (!qa(b) || b == "" || !ea(a))) throw "abort";
                if (ud(this.da) || ud(this.K)) throw "abort";
                if (this.g && this.da != "t0") throw "abort";
            }
        };

    function ud(a) {
        return a.indexOf(".") >= 0 || a.indexOf(":") >= 0
    };
    var Yd, Zd, $d, A;
    Yd = new ee;
    $d = new ee;
    A = new ee;
    Zd = {
        ec: 45,
        ecommerce: 46,
        linkid: 47
    };
    var u = function(a, b, c) {
            b == N || b.get(V);
            var d = Yd.get(a);
            if (!ea(d)) return !1;
            b.plugins_ = b.plugins_ || new ee;
            if (b.plugins_.get(a)) return !0;
            b.plugins_.set(a, new d(b, c || {}));
            return !0
        },
        y = function(a, b, c, d, e) {
            if (!ea(Yd.get(b)) && !$d.get(b)) {
                Zd.hasOwnProperty(b) && J(Zd[b]);
                var g = void 0;
                if (p.test(b)) {
                    J(52);
                    a = N.j(a);
                    if (!a) return !0;
                    c = Ke(a.model, b, d, e);
                    g = function() {
                        Z.D(["provide", b, function() {}]);
                        var l = O[d && d.dataLayer || "dataLayer"];
                        l && l.hide && ea(l.hide.end) && l.hide[b] && (l.hide.end(), l.hide.end = void 0)
                    }
                }!c && Zd.hasOwnProperty(b) ?
                    (J(39), c = b + ".js") : J(43);
                if (c) {
                    var ca;
                    d && (ca = d[oe]);
                    qa(ca) || (ca = void 0);
                    a = ae(cf(c, ca));
                    !ca || ne(a.protocol) && B(a) || (a = ae(cf(c)));
                    ne(a.protocol) && B(a) && (Id(a.url, void 0, e, void 0, g), $d.set(b, !0))
                }
            }
        },
        v = function(a, b) {
            var c = A.get(a) || [];
            c.push(b);
            A.set(a, c)
        },
        C = function(a, b) {
            Yd.set(a, b);
            b = A.get(a) || [];
            for (var c = 0; c < b.length; c++) b[c]();
            A.set(a, [])
        },
        B = function(a) {
            var b = ae(M.location.href);
            if (D(a.url, Ge(1)) || D(a.url, Ge(2))) return !0;
            if (a.query || a.url.indexOf("?") >= 0 || a.path.indexOf("://") >= 0) return !1;
            if (a.host ==
                b.host && a.port == b.port || jf && (b = M.createElement("a"), b.href = jf, b = kf(b), a.host === b[0] && a.port === b[1])) return !0;
            b = a.protocol == "http:" ? 80 : 443;
            return a.host == "www.google-analytics.com" && (a.port || b) == b && D(a.path, "/plugins/") ? !0 : !1
        },
        ne = function(a) {
            var b = M.location.protocol;
            return a == "https:" || a == b ? !0 : a != "http:" ? !1 : b == "http:"
        },
        kf = function(a) {
            var b = a.hostname || "",
                c = b.indexOf("]") >= 0;
            b = b.split(c ? "]" : ":")[0].toLowerCase();
            c && (b += "]");
            c = (a.protocol || "").toLowerCase();
            c = a.port * 1 || (c == "http:" ? 80 : c == "https:" ? 443 :
                "");
            a = a.pathname || "";
            D(a, "/") || (a = "/" + a);
            return [b, "" + c, a]
        },
        ae = function(a) {
            var b = M.createElement("a");
            b.href = M.location.href;
            var c = (b.protocol || "").toLowerCase(),
                d = kf(b),
                e = b.search || "",
                g = c + "//" + d[0] + (d[1] ? ":" + d[1] : "");
            D(a, "//") ? a = c + a : D(a, "/") ? a = g + a : !a || D(a, "?") ? a = g + d[2] + (a || e) : a.split("/")[0].indexOf(":") < 0 && (a = g + d[2].substring(0, d[2].lastIndexOf("/")) + "/" + a);
            b.href = a;
            c = kf(b);
            return {
                protocol: (b.protocol || "").toLowerCase(),
                host: c[0],
                port: c[1],
                path: c[2],
                query: b.search || "",
                url: a || ""
            }
        },
        cf = function(a, b) {
            return a &&
                a.indexOf("/") >= 0 ? a : (b || bd(!1)) + "/plugins/ua/" + a
        };
    var Z = {
        ga: function() {
            Z.fa = []
        }
    };
    Z.ga();
    Z.D = function(a) {
        var b = Z.J.apply(Z, arguments);
        b = Z.fa.concat(b);
        for (Z.fa = []; b.length > 0 && !Z.v(b[0]) && !(b.shift(), Z.fa.length > 0););
        Z.fa = Z.fa.concat(b)
    };
    Z.ra = function(a) {
        N.q && (N.q.length === 300 && (N.q.shift(), N.qd++), N.q.push(a))
    };
    Z.J = function(a) {
        for (var b = [], c = 0; c < arguments.length; c++) {
            var d = void 0;
            try {
                d = new sc(arguments[c]), d.g ? C(d.aa[0], d.aa[1]) : (d.i && (d.ha = y(d.da, d.aa[0], d.X, d.W)), b.push(d)), Z.ra(arguments[c])
            } catch (e) {}
        }
        return b
    };
    Z.v = function(a) {
        try {
            if (a.u) a.u.call(O, N.j("t0"));
            else {
                var b = a.da == gb ? N : N.j(a.da);
                if (a.A) {
                    if (a.da == "t0" && (b = N.create.apply(N, a.aa), b === null)) return !0
                } else if (a.ba) N.remove(a.da);
                else if (b)
                    if (a.i) {
                        if (a.ha && (a.ha = y(a.da, a.aa[0], a.X, a.W)), !u(a.aa[0], b, a.W)) return !0
                    } else if (a.K) {
                    var c = a.methodName,
                        d = a.aa,
                        e = b.plugins_.get(a.K);
                    e[c].apply(e, d)
                } else b[a.methodName].apply(b, a.aa)
            }
        } catch (g) {}
    };
    var H = {},
        sf = {},
        vf = {};

    function tf(a, b) {
        var c = O.google_tag_data;
        c || (c = O.google_tag_data = {});
        var d = c.slq;
        d || (d = c.slq = {});
        c = d[a];
        c || (c = {}, c = d[a] = (c.q = b ? b.slice() : [], c));
        return c
    }

    function uf(a) {
        return {
            allowAdFeatures: a.get(Ud),
            allowAdPersonalizationSignals: a.get(xe),
            cookieDomain: P(a, W),
            cookieExpires: a.get(Zb),
            cookieFlags: P(a, Be),
            cookieName: P(a, U),
            cookiePath: P(a, Yb),
            cookieUpdate: a.get(Hd),
            hitPayload: P(a, Ra)
        }
    }

    function rf(a) {
        return a.get(Ie) === void 0 && a.get(fa) === void 0 && a.get(gd) === void 0 && a.get(oe) === void 0
    };
    var N = function(a) {
        J(1);
        Z.D.apply(Z, [arguments])
    };
    N.h = {};
    N.P = [];
    N.answer = 42;
    var we = [Na, W, V];
    N.create = function(a) {
        var b = za(we, [].slice.call(arguments));
        b[V] || (b[V] = "t0");
        var c = "" + b[V];
        if (N.h[c]) return N.h[c];
        if (da(b)) return null;
        b = new pc(b);
        N.h[c] = b;
        N.P.push(b);
        c = qc().tracker_created;
        if (ea(c)) try {
            c(b)
        } catch (d) {}
        return b
    };
    N.remove = function(a) {
        for (var b = 0; b < N.P.length; b++)
            if (N.P[b].get(V) == a) {
                N.P.splice(b, 1);
                N.h[a] = null;
                break
            }
    };
    N.j = function(a) {
        return N.h[a]
    };
    N.getAll = function() {
        return N.P.slice(0)
    };
    N.init = function() {
        gb != "ga" && J(49);
        var a = O[gb];
        if (!a || a.answer != 42) {
            N.loaded = !0;
            var b = a && a.q,
                c = ka(b);
            a = [];
            c ? a = b.slice(0) : J(50);
            N.q = c ? b : [];
            N.q.splice(0);
            N.qd = 0;
            b = O[gb] = N;
            X("create", b, b.create);
            X("remove", b, b.remove);
            X("getByName", b, b.j, 5);
            X("getAll", b, b.getAll, 6);
            b = pc.prototype;
            X("get", b, b.get, 7);
            X("set", b, b.set, 4);
            X("send", b, b.send);
            X("requireSync", b, b.ma);
            b = Ya.prototype;
            X("get", b, b.get);
            X("set", b, b.set);
            if ("https:" != M.location.protocol && !Ba) {
                a: {
                    b = M.getElementsByTagName("script");
                    for (c = 0; c < b.length &&
                        c < 100; c++) {
                        var d = b[c].src;
                        if (d && 0 == d.indexOf(bd(!0) + "/analytics")) {
                            b = !0;
                            break a
                        }
                    }
                    b = !1
                }
                b && (Ba = !0)
            }(O.gaplugins = O.gaplugins || {}).Linker = Dc;
            b = Dc.prototype;
            C("linker", Dc);
            X("decorate", b, b.ca, 20);
            X("autoLink", b, b.S, 25);
            X("passthrough", b, b.$, 25);
            C("displayfeatures", fd);
            C("adfeatures", fd);
            Z.D.apply(N, a)
        }
    };
    var Xe = N.init,
        Ye = O[gb];
    Ye && Ye.r ? Xe() : z(Xe);
    z(function() {
        Z.D(["provide", "render", ua])
    });
})(window);
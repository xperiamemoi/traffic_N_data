! function() {
    "use strict";
    var t;
    t = {
        bma: {
            ClientSource: {
                CLIENT_SOURCE_UNSPECIFIED: 0
            }
        }
    }.bma.ClientSource, self.addEventListener("install", (function(t) {
        t.waitUntil(self.skipWaiting())
    })), self.addEventListener("activate", (function(t) {
        t.waitUntil(self.clients.claim())
    })), self.addEventListener("message", (function(t) {
        t.data && t.data.isTWA && self.indexedDB && function(t) {
            new Promise((function(e) {
                var n = self.indexedDB.open("BADOO_TWA", 1);
                n.onupgradeneeded = function(t) {
                    t.target.result.createObjectStore("flags", {
                        keyPath: "flag"
                    })
                }, n.onsuccess = function(n) {
                    var i = n.target.result.transaction("flags", "readwrite").objectStore("flags");
                    for (var o in t) i.put({
                        flag: o,
                        value: t[o]
                    });
                    e(t)
                }, n.onerror = function() {
                    e(!1)
                }
            }))
        }({
            isTWA: !0,
            twaVersion: t.data.twaVersion ? t.data.twaVersion : "-1"
        })
    })), self.addEventListener("push", (function(e) {
        if (e.data) {
            var n = e.data.json();
            e.waitUntil(function(e) {
                var n = e.redirect_page,
                    i = "/push/".concat(e.push_id, "/").concat(n.redirect_page);
                switch (n.user_id && (i += "/".concat(n.user_id)), e.call_id && (n.callId = e.call_id, i += "/".concat(e.call_id)), n.redirect_page) {
                    case t.CLIENT_SOURCE_EXTERNAL_WEB:
                    case t.CLIENT_SOURCE_EMBEDDED_WEB:
                        i += "?url=".concat(encodeURIComponent(n.url))
                }
                e.photo_url && (e.photo_url = e.photo_url.replace("http://", "https://"));
                var o = {
                    body: e.body,
                    icon: e.photo_url,
                    data: {
                        url: i,
                        notification: e
                    },
                    tag: e.tag
                };
                return ["badoo.com", "badoo.eu", "badoo.us", "badoo.d3"].some((function(t) {
                    return -1 !== location.origin.indexOf(t)
                })) && (o.badge = "https://badoocdn.com/i/big/mobileweb/badoo-icon-black.png"), self.registration.showNotification(e.title, o)
            }(n))
        } else console.error("PushNotificationsWorker: chrome<50 is not supported")
    })), self.addEventListener("notificationclick", (function(t) {
        function e(t, e, n) {
            t.postMessage(self.JSON.stringify({
                url: e,
                notification: n
            }))
        }

        function n(t) {
            return self.clients.openWindow(t)
        }

        function i(t, i, o, a) {
            return self.clients.matchAll({
                type: "window",
                includeUncontrolled: !0
            }).then((function(t) {
                if (a) return n(i);
                var r = t.filter((function(t) {
                    return "nested" !== t.frameType
                }));
                if (0 === r.length) return n(i);
                var c = r[0];
                return c.focus().then(e.bind(null, c, i, o)).catch(n.bind(null, i))
            }))
        }
        t.notification.close();
        var o, a, r = t.notification.data,
            c = r.url,
            s = r.notification;
        self.indexedDB ? t.waitUntil((o = "isTWA", a = new Promise((function(t) {
            var e = self.indexedDB.open("BADOO_TWA", 1);
            e.onupgradeneeded = function(t) {
                t.target.result.createObjectStore("flags", {
                    keyPath: "flag"
                })
            }, e.onsuccess = function(e) {
                var n = e.target.result.transaction("flags", "readwrite").objectStore("flags").get(o);
                n.onsuccess = function(e) {
                    e.target.result && e.target.result.value ? t(e.target.result.value) : t(!1)
                }, n.onerror = function() {
                    t(!1)
                }
            }, e.onerror = function() {
                t(!1)
            }
        })), a).then((function(t) {
            return i(0, c, s, t)
        }))) : t.waitUntil(i(0, c, s, !1))
    }))
}();
//# sourceMappingURL=serviceworker.3aec0a5aa3fa93a01c06.js.map
! function() {
    "use strict";
    var e = {
            offline: "offline-page-v".concat(1)
        },
        t = "/offline";
    self.addEventListener("install", (function(n) {
        self.skipWaiting(), n.waitUntil(caches.open(e.offline).then((function(e) {
            return e.add(t)
        })))
    })), self.addEventListener("activate", (function(t) {
        var n = [e.offline];
        t.waitUntil(caches.keys().then((function(e) {
            return Promise.all(e.filter((function(e) {
                return !n.includes(e)
            })).map((function(e) {
                return caches.delete(e)
            })))
        })))
    })), self.addEventListener("fetch", (function(e) {
        ("navigate" === e.request.mode || "GET" === e.request.method && e.request.headers.get("accept").includes("text/html")) && e.respondWith(fetch(e.request).catch((function() {
            return caches.match(t)
        })))
    }))
}();
//# sourceMappingURL=offline-page-worker.32dd7b73684325797b0b.js.map
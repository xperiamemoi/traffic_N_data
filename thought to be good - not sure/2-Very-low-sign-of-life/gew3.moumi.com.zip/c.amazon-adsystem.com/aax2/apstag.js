/*! web-client-bundle - v26.521.1658 - 2026-05-21 16:58:33 */ ! function() {
    "use strict";
    const t = new Uint8Array([42, 94, 79, 102, 182, 87, 18, 39, 206, 243, 126, 191, 4, 63, 77, 59, 162, 241, 193, 101, 74, 1, 189, 21, 73, 186, 68, 154, 111, 81, 242, 165, 135, 180, 163, 105, 50, 210, 243, 84, 28, 112, 180, 154, 121, 30, 77, 205, 244, 40, 170, 162, 232, 228, 11, 227, 246, 206, 15, 66, 249, 209, 155, 230, 40, 163, 9, 155, 225, 186, 136, 158, 220, 243, 29, 125, 108, 215, 138, 132, 162, 138, 154, 50, 162, 121, 25, 242, 186, 30, 94, 86, 163, 178, 51, 115, 114, 236, 70, 144, 3, 28, 80, 147, 126, 214, 189, 247, 91, 89, 174, 197, 197, 183, 170, 91, 8, 14, 57, 223, 112, 162, 142, 158, 85, 114, 94, 54, 177, 225, 193, 215, 183, 203, 176, 135, 119, 151, 106, 124, 147, 64, 185, 186, 154, 65, 115, 229, 149, 248, 103, 83, 0, 185, 239, 180, 180, 9, 121, 175, 91, 167, 210, 228, 224, 59, 152, 103, 84, 54, 29, 154, 26, 192, 30, 30, 230, 189, 46, 31, 44, 247, 213, 82, 224, 87, 119, 243, 198, 63, 123, 158, 78, 91, 6, 158, 34, 159, 215, 185, 65, 197, 90, 186, 113, 79, 40, 200, 209, 165, 199, 128, 110, 19, 63, 125, 229, 20, 205, 93, 22, 177, 73, 126, 222, 207, 218, 164, 126, 105, 197, 65, 146, 175, 93, 49, 99, 244, 146, 186, 117, 50, 116, 237, 57, 73, 29, 194, 250, 216, 125, 160, 101, 201, 143, 48, 173, 154, 169, 182, 163, 159, 150, 123, 175, 26, 29, 21, 75, 254, 6, 218, 88, 64, 9, 238, 70, 40, 48, 251, 227, 255, 14, 252, 121, 116, 203, 193, 211, 50, 29, 13, 120, 107, 88, 124, 129, 92, 214, 187, 203, 14, 234, 59, 113, 251, 68, 2, 197, 99, 211, 134, 234, 215, 62, 106, 160, 163, 205, 103, 10, 244, 47, 67, 229, 124, 164, 209, 86, 98, 250, 150, 19, 2, 48, 7, 217, 47, 108, 179, 137, 29, 118, 253, 240, 198, 209, 169, 123, 234, 193, 55, 151, 183, 196, 133, 243, 111, 68, 60, 109, 15, 222, 215, 190, 84, 32, 161, 155, 6, 221, 9, 91, 244, 252, 231, 34, 70, 249, 254, 126, 47, 145, 125, 203, 199, 164, 76, 200, 255, 242, 96, 213, 54, 245, 80, 152, 219, 38, 38, 88, 107, 171, 167, 140, 205, 250, 85, 42, 240, 247, 239, 122, 49, 163, 88, 77, 71, 185, 215, 102, 84, 142, 194, 238, 193, 69, 189, 200, 85, 4, 24, 127, 232, 164, 61, 27, 31, 192, 160, 81, 62, 75, 2, 248, 252, 158, 31, 229, 142, 61, 109, 149, 222, 245, 236, 130, 102, 181, 88, 110, 177, 25, 177, 190, 237, 122, 51, 60, 100, 33, 47, 94, 199, 39, 135, 90, 14, 29, 181, 6, 103, 45, 93, 144, 135, 188, 184, 179, 103, 222, 216, 182, 143, 162, 221, 15, 201, 102, 140, 100, 227, 179, 120, 252, 193, 19, 93, 250, 0, 27, 52, 240, 252, 40, 142, 218, 208, 81, 211, 133, 190, 65, 240, 215, 64, 205, 85, 247, 205, 210, 255, 193, 106, 149, 155, 120, 62, 145, 81, 139, 227, 62, 75, 159, 37, 244, 102, 106, 117, 36, 171, 31, 184, 50, 171, 235, 246, 36, 249, 88, 10, 214, 139, 224, 160, 86, 8, 144, 218, 183, 238, 141, 252, 130, 111, 200, 38, 91, 55, 119, 105, 134, 219, 12, 149, 106, 45, 35, 72, 102, 65, 91, 187, 244, 8, 73, 110, 250, 22, 186, 33, 176, 44, 135, 12, 192, 62, 60, 255, 35, 253, 44, 113, 58, 242, 222, 60, 145, 228, 207, 59, 23, 255, 173, 47, 234, 254, 254, 30, 171, 11, 60, 87, 79, 218, 109, 175, 23, 255, 197, 111, 134, 83, 200, 250, 202, 117, 111, 156, 243, 38, 157, 77, 88, 94, 63, 66, 101, 42, 51, 254, 208, 205, 13, 144, 240, 191, 7, 88, 9, 41, 57, 85, 18, 75, 218, 18, 4, 51, 179, 93, 145, 234, 147, 82, 72, 229, 77, 72, 78, 154, 75, 122, 93, 231, 240, 183, 141, 143, 122, 82, 255, 217, 76, 184, 75, 190, 91, 255, 116, 77, 254, 146, 211, 148, 177, 170, 158, 59, 112, 202, 57, 184, 41, 6, 139, 39, 65, 254, 166, 3, 217, 93, 41, 1, 215, 16, 112, 238, 62, 246, 183, 159, 46, 115, 207, 175, 144, 241, 71, 60, 233, 47, 94, 133, 51, 12, 63, 242, 171, 123, 235, 89, 106, 213, 255, 216, 235, 111, 31, 143, 216, 217, 236, 13, 80, 251, 192, 159, 47, 174, 114, 161, 77, 165, 139, 192, 238, 112, 134, 180, 106, 154, 56, 179, 162, 98, 57, 28, 59, 92, 133, 227, 113, 249, 102, 176, 3, 19, 245, 141, 159, 48, 231, 90, 228, 244, 229, 173, 100, 230, 33, 205, 22, 231, 123, 90, 139, 75, 252, 134, 220, 243, 170, 7, 32, 136, 69, 9, 234, 125, 27, 204, 31, 251, 163, 218, 1, 198, 246, 122, 98, 251, 1, 130, 98, 114, 236, 231, 115, 6, 233, 147, 232, 73, 29, 207, 229, 243, 63, 60, 165, 178, 226, 159, 13, 124, 200, 114, 54, 198, 102, 213, 255, 38, 213, 225, 4, 23, 105, 69, 166, 215, 113, 134, 2, 14, 129, 76, 64, 74, 48, 98, 159, 219, 73, 75, 62, 237, 120, 114, 144, 81, 242, 206, 66, 111, 175, 177, 86, 55, 129, 34, 198, 84, 63, 87, 242, 115, 43, 209, 149, 49, 107, 213, 179, 233, 105, 242, 134, 53, 61, 248, 11, 73, 195, 244, 184, 248, 93, 54, 242, 111, 65, 75, 63, 14, 180, 177, 71, 5, 55, 111, 129, 179, 168, 80, 72, 214, 13, 25, 75, 0, 191, 190, 72, 172, 141, 70, 104, 241, 169, 158, 104, 131, 130, 14, 249, 12, 42, 179, 87, 98, 173, 42, 195, 111, 205, 218, 226, 240, 165, 81, 158, 27, 103, 161, 128, 85, 250, 152, 147, 145, 116, 29, 119, 128, 252, 240, 95, 162, 6, 79, 188, 140, 183, 26, 150, 91, 184, 180, 8, 27, 7, 3, 74, 93, 70, 57, 169, 210, 36, 82, 24, 116, 234, 217, 241, 64, 24, 250, 172, 230, 109, 194, 235, 58, 37, 52, 127, 79, 77, 220, 86, 231, 178, 202, 42, 176, 114, 135, 215, 196, 161, 72, 101, 252, 107, 45, 222, 73, 102, 37, 205, 56, 177, 142, 100, 77, 183, 27, 245, 90, 2, 100, 38, 127, 199, 201, 115, 183, 142, 121, 56, 185, 179, 90, 168, 120, 45, 167, 207, 107, 182, 17, 85, 161, 78, 113, 92, 205, 213, 22, 210, 28, 189, 204, 118, 121, 163, 88, 52, 27, 19, 242, 41, 82, 180, 81, 186, 185, 166, 161, 253, 230, 93, 42, 154, 204, 123, 153, 128, 120, 17, 132, 49, 204, 55, 221, 213, 34, 121, 118, 143, 207, 100, 55, 24, 42, 12, 158, 55, 40, 177, 238, 135, 243, 29, 166, 26, 75, 99, 108, 190, 214, 17, 198, 250, 4, 14, 184, 180, 250, 160, 90, 190, 27, 76, 93, 81, 245, 104, 185, 104, 237, 35, 141, 66, 214, 86, 238, 166, 161, 207, 138, 195, 93, 9, 185, 67, 206, 174, 232, 109, 50, 107, 71, 114, 64, 208, 88, 81, 162, 242, 139, 120, 24, 41, 124, 172, 154, 159, 83, 112, 56, 54, 247, 211, 57, 20, 214, 42, 23, 19, 145, 84, 43, 126, 8, 212, 27, 49, 225, 85, 23, 9, 17, 82, 21, 251, 63, 148, 247, 25, 103, 122, 13, 92, 185, 231, 86, 161, 74, 83, 79, 88, 192, 168, 80, 110, 92, 183, 152, 96, 154, 128, 46, 223, 53, 127, 186, 254, 57, 189, 102, 111, 208, 211, 84, 164, 113, 114, 237, 75, 120, 78, 78, 198, 114, 208, 93, 125, 210, 183, 30, 18, 211, 237, 6, 191, 143, 86, 209, 162, 47, 231, 19, 70, 162, 23, 120, 237, 205, 49, 103, 117, 112, 64, 125, 12, 52, 112, 210, 225, 34, 14, 225, 72, 248, 198, 122, 239, 103, 22, 112, 159, 187, 116, 52, 35, 249, 228, 152, 96, 143, 210, 143, 75, 0]);

    function e(t) {
        const e = (new TextEncoder).encode(t);
        let n = 2166136261;
        for (let t = 0; t < e.length; ++t) n ^= e[t], n = Math.imul(n, 16777619);
        return n >>> 0
    }
    const n = (t, e) => `${t}_${e}_salt`,
        s = (t, e = 200) => t.length <= e ? t : `${t.substring(0,e)}...`;
    let o = !1;
    try {
        ((t, e) => {
            const n = new Set,
                o = [];
            try {
                const e = t.top ? .location.hostname;
                e && n.add(e)
            } catch (t) {
                const e = t;
                o.push(s(e.message))
            }
            try {
                n.add(t.location.hostname)
            } catch (t) {
                const e = t;
                o.push(s(e.message))
            }
            try {
                const e = t.location.href;
                n.add(new URL(e).hostname)
            } catch (t) {
                const e = t;
                o.push(s(e.message))
            }
            try {
                const t = e.URL;
                n.add(new URL(t).hostname)
            } catch (t) {
                const e = t;
                o.push(s(e.message))
            }
            if (0 === n.size) throw new Error(`Unable to determine hostname: ${JSON.stringify(o)}`);
            return n
        })(window, document).forEach((s => {
            o || (o = ((t, s) => {
                for (let o = 0; o < 14; o++) {
                    const a = e(n(t, o)) % 11033,
                        r = a % 8;
                    if (!(s[Math.floor(a / 8)] & 1 << r)) return !1
                }
                return !0
            })(s, t))
        }))
    } catch (t) {
        const e = t;
        window._aps_telemetry = window._aps_telemetry || {}, window._aps_telemetry.alarms = window._aps_telemetry.alarms || [], window._aps_telemetry.alarms.push({
            hash: "5ba43c",
            context: {
                message: e ? .message
            }
        })
    }
    if (o) throw new Error("Unauthorized");
    ! function() {
        "use strict";
        const t = "debugSession/end",
            e = "prepend/events",
            n = "populator/ran";
        var o, a, i, s, r;
        ! function(t) {
            t.ManagedWeb = "mw", t.SelfServeWeb = "ssw"
        }(o || (o = {})),
        function(t) {
            t.push = "push", t.listenerSuccess = "listenerSuccess", t.direct = "direct"
        }(a || (a = {})),
        function(t) {
            t.internal = "internal", t.apstag = "apstag", t.webpage = "webpage", t.dtbm = "dtbm"
        }(i || (i = {})),
        function(t) {
            t.completed = "completed", t.waiting = "waiting", t.cancelled = "cancelled"
        }(s || (s = {})),
        function(t) {
            t.started = "started", t.error = "error", t.unknown = "unknown", t.deactivated = "deactivated", t.analytics = "analytics"
        }(r || (r = {}));
        const c = { ...s,
                ...r
            },
            d = {
                key: "consent/hasPurposeOneConsent",
                default: !1
            };
        class l {
            constructor(t) {
                this.getItem = t => {
                    const e = this.globalContext.document.cookie.split("; ").reduce(((e, n) => {
                        const o = n.split("=");
                        return o[0] === t ? decodeURIComponent(o.slice(1).join("=")) : e
                    }), "");
                    return e.length > 0 ? e : null
                }, this.removeItem = (t, e = "/") => {
                    this.setItem(t, "", 0, e)
                }, this.setItem = (t, e, n, o = "/") => {
                    const a = new Date(n);
                    if (!this.isValidDate(a)) throw new Error("Invalid expiration date");
                    this.globalContext.document.cookie = `${t}=${e}; expires=${a.toUTCString()}; path=${o};`
                }, this.globalContext = t
            }
            isValidDate(t) {
                return t instanceof Date && !isNaN(t)
            }
        }
        const u = ["scope/objectName", t, e],
            p = ":";

        function m(t) {
            return null === t || "object" != typeof t ? t : t instanceof Date ? new Date(t.getTime()) : t instanceof Array ? t.reduce(((t, e) => (t.push(m(e)), t)), []) : t instanceof Set ? Array.from(t.values()).reduce(((t, e) => (t.add(m(e)), t)), new Set) : t instanceof Map ? Array.from(t.entries()).reduce(((t, e) => (t.set(e[0], m(e[1])), t)), new Map) : t instanceof Object ? Object.keys(t).reduce(((e, n) => (e[n] = m(t[n]), e)), {}) : t
        }
        class f {
            constructor(t, e) {
                const n = e.rootName;
                this.globalContext = e.globalContext, this.rootName = n;
                const o = this.globalContext[n].get(t);
                if (null == o) throw new Error(`Missing "${t}" account in userspace object`);
                this.id = t, this.store = o.store, this.queue = o.queue, this.store.has("listeners") || this.store.set("listeners", new Map)
            }
            async record(t, e) {
                return await new Promise(((n, o) => {
                    this.queue.push(new CustomEvent(t, {
                        detail: {
                            resolve: n,
                            reject: o,
                            source: i.internal,
                            ...e
                        }
                    }))
                }))
            }
            async recordListener(t, e) {
                return await new Promise(((n, o) => {
                    this.queue.push(new CustomEvent(t.name, {
                        detail: {
                            resolve: n,
                            reject: o,
                            source: i.internal,
                            ...e
                        }
                    }))
                }))
            }
            recordListenerNonBlocking(t, e) {
                this.recordListener(t, e).catch((t => {}))
            }
            read(t, e) {
                const n = this.store.get(t);
                if (void 0 !== n) return n;
                if (void 0 !== e ? .persist && e.persist) {
                    const n = this.readLocalStorage(t, {
                        usePrefix: !0,
                        throwOnDisallowed: e.throwOnDisallowed
                    });
                    if (void 0 !== n) return n
                }
                const o = e ? .default ? .generators ? .get(t);
                return void 0 !== o ? o(...e ? .default ? .args ? ? []) : void 0
            }
            write(t, e, n) {
                this.store.set(t, e), void 0 !== n ? .persist && n.persist && this.writeLocalStorage(t, e, {
                    usePrefix: !0,
                    throwOnDisallowed: n.throwOnDisallowed
                })
            }
            use(t, e) {
                let n;
                const o = this.store.get(t.key);
                if (void 0 !== o) n = o;
                else if (void 0 !== e ? .persist && e.persist) {
                    const o = this.readLocalStorage(t.key, {
                        usePrefix: !0,
                        throwOnDisallowed: e.throwOnDisallowed
                    });
                    null != o && (n = o)
                }
                const a = n ? ? t.default;
                if ("function" == typeof a || !1 === e ? .structuredClone) return a;
                try {
                    return structuredClone(a)
                } catch (t) {
                    try {
                        return m(a)
                    } catch (t) {
                        return vt.logCoreError({
                            id: "Core.library.Account.use",
                            account: null,
                            error: t
                        }), a
                    }
                }
            }
            useParent(t, e) {
                try {
                    const n = this.globalContext.parent,
                        o = n[this.rootName];
                    if (!o || "function" != typeof o.get) return t.default;
                    const a = o.get(e ? .accountId ? ? this.id);
                    if (!a || !a.store) return t.default;
                    let i;
                    const s = a.store.get(t.key);
                    if (void 0 !== s) i = s;
                    else if (e ? .persist) {
                        const o = e ? .accountId ? ? this.id,
                            a = `aps${p}${o}${p}${t.key}`;
                        try {
                            const t = n.localStorage.getItem(a);
                            null != t && (i = t)
                        } catch {}
                    }
                    const r = i ? ? t.default;
                    if ("function" == typeof r || !1 === e ? .structuredClone) return r;
                    try {
                        return structuredClone(r)
                    } catch {
                        try {
                            return m(r)
                        } catch {
                            return r
                        }
                    }
                } catch {
                    return t.default
                }
            }
            update(t, e, n) {
                let o = e(this.use(t, { ...n,
                    throwOnDisallowed: n ? .throwOnDisallowed
                }));
                if (void 0 !== t.postProcessor && (o = t.postProcessor(o)), this.store.set(t.key, o), void 0 !== n ? .persist && n.persist) {
                    if ("string" != typeof o) throw new Error(`${JSON.stringify(o)} must be a string to be writtable to browser storage`);
                    this.writeLocalStorage(t.key, o, {
                        usePrefix: !0,
                        throwOnDisallowed: n.throwOnDisallowed
                    })
                }
            }
            delete(t, e) {
                this.store.delete(t), void 0 !== e ? .persist && e.persist && this.deleteLocalStorage(t, {
                    usePrefix: !0,
                    throwOnDisallowed: e.throwOnDisallowed
                })
            }
            remove(t, e) {
                this.store.delete(t.key), void 0 !== e ? .persist && e.persist && this.deleteLocalStorage(t.key, {
                    usePrefix: !0,
                    throwOnDisallowed: e.throwOnDisallowed
                })
            }
            executeFuncWithConsent(t, e) {
                if (!this.isAllowedToAccessInfoOnDevice()) throw new Error("Invalid consent. API requires consent before execution.");
                return e.apply(t)
            }
            recordErrorEvent(t) {
                vt.logError({ ...t,
                    account: this
                })
            }
            recordStatusChangeEvent(t) {
                vt.logFeature({
                    id: t.id,
                    account: this,
                    feature: t.status,
                    analyticsSampleRateAdjustFactor: t.analyticsSampleRateAdjustFactor,
                    props: { ...t.props
                    }
                })
            }
            recordGenericEvent(t) {
                vt.logFeature({
                    id: t.id,
                    account: this,
                    feature: t.id,
                    analyticsSampleRateAdjustFactor: t.analyticsSampleRateAdjustFactor,
                    props: { ...t.props
                    }
                })
            }
            isAllowedToAccessInfoOnDevice() {
                return this.updateUserConsent(), this.use(d)
            }
            isAPStagAllowedToAccessInfoOnDevice() {
                return !0 === this.globalContext.apstag._atsaaiod()
            }
            updateUserConsent() {
                try {
                    const t = this.isAPStagAllowedToAccessInfoOnDevice();
                    this.update(d, (() => t))
                } catch (t) {}
            }
            getPersistedItemName(t) {
                return `aps${p}${this.id}${p}${t}`
            }
            isBrowserStorageAllowed(t) {
                let e = !1;
                try {
                    e = this.isAllowedToAccessInfoOnDevice()
                } catch {}
                return e || u.includes(t)
            }
            setCookieStorage(t, e, n, o) {
                const a = o ? .throwOnDisallowed ? ? !0;
                if (!this.isBrowserStorageAllowed(t)) {
                    if (a) throw new Error(`${t} is not allowed to be set on cookie storage`);
                    return
                }
                const i = o ? .usePrefix ? this.getPersistedItemName(t) : t;
                return new l(this.globalContext).setItem(i, e, n, o ? .path ? ? "/")
            }
            readCookieStorage(t, e) {
                const n = e ? .throwOnDisallowed ? ? !0;
                if (!this.isBrowserStorageAllowed(t)) {
                    if (n) throw new Error(`${t} is not allowed to be read from cookie storage`);
                    return
                }
                const o = e ? .usePrefix ? this.getPersistedItemName(t) : t;
                return new l(this.globalContext).getItem(o)
            }
            readLocalStorage(t, e) {
                const n = e ? .throwOnDisallowed ? ? !0;
                if (!this.isBrowserStorageAllowed(t)) {
                    if (n) throw new Error(`${t} is not allowed to be read from browser storage`);
                    return
                }
                const o = e ? .usePrefix ? this.getPersistedItemName(t) : t;
                return this.globalContext.localStorage.getItem(o) ? ? void 0
            }
            writeLocalStorage(t, e, n) {
                const o = n ? .throwOnDisallowed ? ? !0;
                if (!this.isBrowserStorageAllowed(t)) {
                    if (o) throw new Error(`${t} is not allowed to be written to browser storage`);
                    return
                }
                if ("string" != typeof e) throw new Error(`${JSON.stringify(e)} must be a string to be writtable to browser storage`);
                const a = n ? .usePrefix ? this.getPersistedItemName(t) : t;
                this.globalContext.localStorage.setItem(a, e)
            }
            deleteLocalStorage(t, e) {
                const n = e ? .throwOnDisallowed ? ? !0;
                if (!this.isBrowserStorageAllowed(t)) {
                    if (n) throw new Error(`${t} is not allowed to be touched/deleted in browser storage`);
                    return
                }
                const o = e ? .usePrefix ? this.getPersistedItemName(t) : t;
                this.globalContext.localStorage.removeItem(o)
            }
            readSessionStorage(t, e) {
                const n = e ? .throwOnDisallowed ? ? !0;
                if (!this.isBrowserStorageAllowed(t)) {
                    if (n) throw new Error(`${t} is not allowed to be read from browser storage`);
                    return
                }
                const o = e ? .usePrefix ? this.getPersistedItemName(t) : t;
                if (o in this.globalContext.sessionStorage) return this.globalContext.sessionStorage.getItem(o)
            }
            writeSessionStorage(t, e, n) {
                const o = n ? .throwOnDisallowed ? ? !0;
                if (!this.isBrowserStorageAllowed(t)) {
                    if (o) throw new Error(`${t} is not allowed to be written to browser storage`);
                    return
                }
                if ("string" != typeof e) throw new Error(`${JSON.stringify(e)} must be a string to be writable to browser storage`);
                const a = n ? .usePrefix ? this.getPersistedItemName(t) : t;
                this.globalContext.sessionStorage.setItem(a, e)
            }
            deleteSessionStorage(t, e) {
                const n = e ? .throwOnDisallowed ? ? !0;
                if (!this.isBrowserStorageAllowed(t)) {
                    if (n) throw new Error(`${t} is not allowed to be touched/deleted in browser storage`);
                    return
                }
                const o = e ? .usePrefix ? this.getPersistedItemName(t) : t;
                this.globalContext.sessionStorage.removeItem(o)
            }
        }
        const h = "_system";
        class v extends f {
            constructor(t, e) {
                super(h, {
                    globalContext: t,
                    rootName: e
                })
            }
        }
        const y = "listeners",
            g = "_internal/history",
            w = "_internal/pageLoadID",
            b = "_internal/externalEventCount";
        class E {
            constructor(t, e, n) {
                this.globalContext = t, this.rootName = e, this.dispatcher = n
            }
            getAccounts() {
                return this.globalContext[this.rootName]
            }
            createUserspaceRoot() {
                null == this.getAccounts() && (this.globalContext[this.rootName] = new Map)
            }
            createSystemAccount() {
                !1 === this.getAccounts().has(h) && (this.getAccounts().set(h, {
                    queue: [],
                    store: new Map
                }), new v(this.globalContext, this.rootName).store.set(w, Math.random()))
            }
            observeRootSet() {
                const t = this;
                this.getAccounts().set = function(e, n) {
                    Map.prototype.set.apply(this, [e, n]), t.equip()
                }
            }
            observeAccountQueuesPush() {
                const t = this;
                this.getAccounts().forEach((e => {
                    e.queue.push = function(...e) {
                        Array.prototype.push.apply(this, e), t.dispatcher.t({
                            reason: {
                                method: a.push,
                                events: e
                            }
                        })
                    }
                }))
            }
            overwriteAccountStoresGet() {
                this.getAccounts().forEach((t => {
                    t.store.get = function(...t) {
                        return Map.prototype.get.apply(this, t)
                    }
                }))
            }
            defineConvenienceFunctions() {
                const t = (t, e, n) => {
                        const o = this.getAccounts().get(t);
                        void 0 !== o && o.queue.push(new CustomEvent(e, {
                            detail: n ? ? {}
                        }))
                    },
                    e = this.globalContext[this.rootName];
                e.triggerFor = t, e.trigger = (e, n) => {
                    t(h, e, n)
                }, void 0 === e._private && (e._private = {}), e._private.CookieStorage = l
            }
            equip() {
                try {
                    this.createUserspaceRoot(), this.createSystemAccount(), this.observeRootSet(), this.observeAccountQueuesPush(), this.overwriteAccountStoresGet(), this.defineConvenienceFunctions()
                } catch (t) {
                    throw new v(this.globalContext, this.rootName).recordErrorEvent({
                        id: "Core.library.Equiper.equip",
                        error: t
                    }), t
                }
            }
        }
        var S;
        ! function(t) {
            t.info = "info", t.warn = "warn", t.error = "error"
        }(S || (S = {}));
        class x {
            static Instance() {
                return this.o
            }
            static SessionId() {
                return this.i
            }
            info(...t) {
                const e = new Date(Date.now()),
                    n = S.info;
                return console.log(this.getPrefix(e, n), ...t), {
                    timestamp: e,
                    logLevel: n
                }
            }
            warn(...t) {
                const e = new Date(Date.now()),
                    n = S.warn;
                return console.warn(this.getPrefix(e, n), ...t), {
                    timestamp: e,
                    logLevel: n
                }
            }
            error(...t) {
                const e = new Date(Date.now()),
                    n = S.error;
                return console.error(this.getPrefix(e, n), ...t), {
                    timestamp: e,
                    logLevel: n
                }
            }
            getPrefix(t, e) {
                return `${t.toISOString()} | ${x.SessionId()} | [${e.toUpperCase()}]`
            }
        }
        x.o = new x, x.i = `${Date.now()}`;
        const _ = x.Instance(),
            R = "26.521.1658",
            I = t => void 0 === t || !Array.isArray(t) || (() => {
                let e, n = window;
                do {
                    try {
                        const e = n ? .location ? .hostname;
                        if (e && (o = e, t.includes(o))) return !0
                    } catch (t) {
                        if (!(t instanceof DOMException && "SecurityError" === t.name || t instanceof Error && t.message.includes("cross-origin frame"))) throw t;
                        if (Math.random() < .001) throw t
                    }
                    if (n === window.top) break;
                    e = n, n = n.parent
                } while (e !== n && e !== window.top);
                var o;
                return !1
            })();

        function A(t) {
            return !(t >= 1 || Number.isNaN(t)) && (t <= 0 || Math.random() >= t)
        }

        function k() {
            try {
                return !!new URLSearchParams(window.top ? .location.search ? ? window.location.search).has("apscoredebug") || (window._aps ? .get("_system").store.get("_internal/coreDebugMode") ? ? !1)
            } catch {
                return !1
            }
        }
        const j = {
                key: "_internal/eventSources",
                default: new Map
            },
            $ = {
                key: "_internal/processedEventSources",
                default: new Set
            },
            C = {
                key: "analytics/sampleRateFactors",
                default: void 0
            },
            O = [c.completed, c.error, c.cancelled, c.analytics];
        class P {
            constructor(t, e) {
                this.globalContext = t, this.rootName = e
            }
            l(t) {
                return t.store.get("_config/events/deactivations") ? ? new Set
            }
            p(t, e) {
                return !0 === this.l(t).has(e.type) || ((t, e) => {
                    try {
                        const e = t.detail ? .restrictions ? .allow ? .hostnames;
                        if (void 0 !== e && !I(e)) return !0;
                        const n = t.detail ? .restrictions ? .block ? .hostnames;
                        if (void 0 !== n && I(n)) return !0
                    } catch (t) {
                        return e.recordErrorEvent({
                            id: "hostnames",
                            error: new Error(t)
                        }), !1
                    }
                    return !1
                })(e, t) || (t => {
                    const e = t ? .detail ? .restrictions ? .allow ? .libraryVersions,
                        n = t ? .detail ? .restrictions ? .block ? .libraryVersions;
                    return !(!Array.isArray(n) || !n.includes(R)) || !(!Array.isArray(e) || e.includes(R))
                })(e) || ((t, e) => {
                    const n = t ? .detail ? .restrictions ? .allow ? .accounts,
                        o = t ? .detail ? .restrictions ? .block ? .accounts;
                    return !(!Array.isArray(o) || !o.includes(e.id)) || !(!Array.isArray(n) || n.includes(e.id))
                })(e, t) || ((t, e) => {
                    const n = (t => {
                        if (!t) return null;
                        const e = Number(t);
                        return !Number.isNaN(e) && Number.isInteger(e) && e >= 0 ? o.ManagedWeb : o.SelfServeWeb
                    })(e.id);
                    if (null === n) return !1;
                    const a = t ? .detail ? .restrictions ? .allow ? .accountTypes,
                        i = t ? .detail ? .restrictions ? .block ? .accountTypes;
                    return !(!Array.isArray(i) || !i.includes(n)) || !(!Array.isArray(a) || a.includes(n))
                })(e, t) || (t => {
                    const e = t ? .detail ? .restrictions ? .allow ? .rate ? ? 1;
                    return !(!A(t ? .detail ? .restrictions ? .block ? .rate ? ? 1) && !A(e))
                })(e)
            }
            m() {
                return new v(this.globalContext, this.rootName).store.get(y) ? ? new Map
            }
            v(t) {
                return t.store.get("listeners") ? ? new Map
            }
            S(t, e) {
                return this.m().get(e.type) || this.v(t).get(e.type)
            }
            _(t) {
                const e = this.R(b);
                return (void 0 === t.externalEventCount || t.externalEventCount < e) && (t.externalEventCount = e, !0)
            }
            I(t) {
                if (void 0 === t.status) return !0;
                if (t.status === c.started) return !1;
                if (O.includes(t.status)) return !1;
                if (t.status === c.waiting) return !!this._(t);
                if (t.status === c.unknown) return !1;
                if (t.status === c.deactivated) return !1;
                throw new Error(`Event status not explicitely handled: ${t.status}`)
            }
            A(t, e) {
                void 0 !== e.detail ? .timeout && t.push(new Promise(((t, n) => {
                    setTimeout((() => n(new Error(`Event "${e.type}" timed out`))), e.detail.timeout)
                })))
            }
            j(t, e) {
                const n = new v(this.globalContext, this.rootName),
                    o = n.read(t) ? ? 0;
                n.write(t, o + e)
            }
            $(t) {
                new v(this.globalContext, this.rootName).write(t, 0)
            }
            R(t) {
                return new v(this.globalContext, this.rootName).read(t) ? ? 0
            }
            C(t, e, n, o, i) {
                if (!(e in c)) throw new Error(`Listener returned invalid status: ${t.type} returned ${e}`);
                if (this.O(t, e, o, i), e !== c.waiting && void 0 !== t.detail ? .resolve) try {
                    t.detail.resolve(n)
                } catch (t) {
                    _.error(t)
                }
                e !== c.waiting && this.P(t, o), this.t({
                    reason: {
                        method: a.listenerSuccess,
                        events: [t]
                    }
                })
            }
            P(t, e) {
                const n = this.S(e, t);
                !0 === n ? .shouldFlushAnalytics && vt.flush()
            }
            D(t, e, n) {
                void 0 !== e && "string" != typeof e || (e = new Error(e)), this.O(t, c.error, n), this.T(t, e), e.context = t.type, n.recordErrorEvent({
                    id: t.type,
                    analyticsSampleRateAdjustFactor: this.N(t),
                    error: e
                }), this.P(t, n)
            }
            L(t, e, n, o) {
                const a = this.S(n, e);
                if (void 0 === a) throw new Error(`No listener found for event: ${e.type}`);
                t.push(a({
                    customEvent: e,
                    account: n,
                    systemAccount: o,
                    detail: e.detail,
                    context: n.globalContext
                }))
            }
            M(t, e, n) {
                Promise.race(t).then((t => {
                    let o, a, i;
                    void 0 === t ? o = s.completed : "string" == typeof t ? o = t : "object" == typeof t && (o = t.status, a = t.value, i = t.analytics, !0 === e.detail ? .surfaceAnalytics && (void 0 === a && (a = {}), a.analytics = i)), this.C(e, o, a, n, i)
                })).catch((t => {
                    this.D(e, t, n)
                }))
            }
            U(t, e, n) {
                const o = [];
                this.L(o, t, e, n), this.A(o, t), this.M(o, t, e)
            }
            q(t, e) {
                if (void 0 !== t.status) return;
                const n = t.detail ? .error;
                if (void 0 !== n) {
                    t.status = c.error;
                    const o = this.V(n),
                        a = {
                            id: t.type,
                            analyticsSampleRateAdjustFactor: this.N(t),
                            error: o,
                            props: { ...t.detail.analytics,
                                eventDetailSource: t.detail.source
                            }
                        };
                    "string" == typeof t.detail.libraryVersion && (a.libraryVersion = t.detail.libraryVersion), e.recordErrorEvent(a)
                }
            }
            V(t) {
                let e;
                if (t instanceof Error) e = t;
                else if ("string" == typeof t) e = new Error(t);
                else if ("object" == typeof t && null !== t) {
                    let n = "Error object";
                    if ("message" in t && "string" == typeof t.message) n = t.message;
                    else if ("error" in t && "string" == typeof t.error) n = t.error;
                    else try {
                        n = JSON.stringify(t), n.length > 500 && (n = n.substring(0, 497) + "...")
                    } catch {
                        n = `Complex error object of type ${t.constructor?.name||"unknown"}`
                    }
                    e = new Error(n), e.originalError = t
                } else e = new Error(`Error value: ${String(t)}`);
                return e
            }
            F(t, e) {
                if (void 0 !== t.status) return;
                const n = t.detail ? .analytics;
                void 0 !== n && (t.status = c.analytics, e.recordStatusChangeEvent({
                    id: t.type,
                    status: t.status,
                    analyticsSampleRateAdjustFactor: this.N(t),
                    props: { ...n
                    }
                }))
            }
            B(t, e) {
                this.p(e, t) && this.O(t, c.deactivated, e)
            }
            J(t, e) {
                void 0 === t.status && void 0 === this.S(e, t) && this.O(t, c.unknown, e)
            }
            T(t, e) {
                if (k() && _.error(e), void 0 !== t.detail ? .reject) try {
                    t.detail.reject(e)
                } catch (t) {
                    _.error(t)
                }
            }
            H(t, e) {
                const n = new Error(`Invalid account ID: "${e.id}"`);
                this.D(t, n, e)
            }
            static G(t) {
                return "string" == typeof t && !["", "undefined", "true", "false"].includes(t.trim())
            }
            K(t, e, n) {
                P.G(e.id) ? (this.q(t, e), this.F(t, e), this.J(t, e), this.B(t, e), this.I(t) && (this.O(t, c.started, e), k() && _.info(`## Execute event: ${t.type} with initial status ${t.status??"undefined"}`), this.U(t, e, n))) : this.H(t, e)
            }
            W(t) {
                const e = new v(this.globalContext, this.rootName).use(j),
                    n = t.use($);
                e.forEach(((e, o) => {
                    if (n.has(o)) return;
                    const a = e.map((([t, e]) => new CustomEvent(t, {
                        detail: e
                    })));
                    t.queue.unshift(...a), t.update($, (t => t.add(o)))
                }))
            }
            Y(t, e, n) {
                this.W(t), t.queue.forEach((n => this.K(n, t, e)))
            }
            Z(t, e) {
                t.status = e, t.statusEvents = null != t.statusEvents ? t.statusEvents : [], t.statusEvents.push(new CustomEvent(e))
            }
            N(t) {
                if (t.detail ? .analyticsSampleRateAdjustFactor) return t.detail.analyticsSampleRateAdjustFactor;
                const e = new v(this.globalContext, this.rootName).use(C);
                return e ? .get(t.type)
            }
            X(t, e, n, o) {
                const a = new CustomEvent("now").timeStamp,
                    i = t.statusEvents ? .find((t => t.type === c.started)),
                    s = null != i ? a - i.timeStamp : void 0;
                n.recordStatusChangeEvent({
                    id: t.type,
                    status: e,
                    analyticsSampleRateAdjustFactor: this.N(t),
                    props: { ...o,
                        source: t.detail ? .source,
                        timers: {
                            sinceCreated: a - t.timeStamp,
                            sinceStarted: s
                        }
                    }
                })
            }
            O(t, e, n, o) {
                t.status !== e && (k() && _.info(`### Update ${t.type} from ${t.status??"undefined"} to ${e}`), this.Z(t, e), this.X(t, e, n, o))
            }
            tt() {
                const t = new Map;
                return this.globalContext[this.rootName].forEach(((e, n) => t.set(n, new f(n, {
                    globalContext: this.globalContext,
                    rootName: this.rootName
                })))), t
            }
            et(t) {
                if (k()) return;
                const e = t.store.get(g) ? ? [];
                if (e.length > 150) {
                    const n = e.slice(-100);
                    t.store.set(g, n)
                }
            }
            nt(t) {
                const e = t.store.get(g) ? ? [];
                e.push(...t.queue.filter((t => void 0 !== t.status && O.includes(t.status)))), t.store.set(g, e)
            }
            ot(t) {
                t.queue.splice(0, t.queue.length, ...t.queue.filter((t => void 0 === t.status || !O.includes(t.status))))
            }
            it() {
                this.tt().forEach((t => {
                    this.nt(t), this.et(t), this.ot(t)
                }))
            }
            st(t) {
                return t ? .filter((t => t.detail ? .source !== i.internal && t.detail ? .source !== i.apstag && t.status !== c.waiting))
            }
            rt(t) {
                const e = this.st(t);
                return e ? .length ? ? 0
            }
            ct(t) {
                const e = this.rt(t);
                this.j(b, e)
            }
            lt() {
                const t = "_internal/recentDispatches";
                this.j(t, 1);
                const e = this.R(t);
                if (e > 1e4) throw new Error("Too many dispatches. Aborting");
                e % 100 == 0 && new v(this.globalContext, this.rootName).recordGenericEvent({
                    id: "C.l.D.thr",
                    props: {
                        recentDispatchesCount: e
                    }
                }), setTimeout((() => {
                    this.$(t)
                }), 100)
            }
            t({
                reason: t
            }) {
                try {
                    this.lt(), k() && _.info(`# Dispatch from method "${t.method}" on event "${t.events?.[0].type??"undefined"}" with source "${t.events?.[0].detail?.source??"undefined"}"\n_________________________________________`), this.ct(t.events);
                    const e = new v(this.globalContext, this.rootName);
                    this.tt().forEach((n => this.Y(n, e, t))), this.it()
                } catch (t) {
                    throw new v(this.globalContext, this.rootName).recordErrorEvent({
                        id: "C.l.D.dis",
                        error: t
                    }), t
                }
            }
        }
        class D {
            constructor(t, e) {
                this.globalContext = t, this.rootName = e
            }
            subscribe(t) {
                try {
                    const e = new v(this.globalContext, this.rootName),
                        n = null != e.store.get(y) ? e.store.get(y) : new Map;
                    e.store.set(y, new Map([...n, ...t]))
                } catch (t) {
                    throw new v(this.globalContext, this.rootName).recordErrorEvent({
                        id: "Core.library.Subscriber.subscribe",
                        error: t
                    }), t
                }
            }
        }
        class T {
            constructor(t, e) {
                this.globalContext = t, this.rootName = e
            }
            populate() {
                try {
                    const t = new v(this.globalContext, this.rootName);
                    let e = !1;
                    try {
                        e = JSON.parse(t.read(n))
                    } catch {}
                    if (e) return;
                    t.write(n, JSON.stringify(!0)), this.populateFromPrependStore(), this.populateFromQueryParams()
                } catch (t) {
                    new v(this.globalContext, this.rootName).recordErrorEvent({
                        id: "Core.library.Populator.populate",
                        error: t
                    })
                }
            }
            populateFromPrependStore() {
                this.globalContext[this.rootName].forEach(((t, n) => {
                    const o = new f(n, {
                            globalContext: this.globalContext,
                            rootName: this.rootName
                        }),
                        a = o.read(e, {
                            persist: !0
                        }) ? ? "[]";
                    o.write(e, JSON.stringify([]));
                    try {
                        const t = JSON.parse(a);
                        if (0 === t.length) return;
                        o.queue.push(...t.map(L))
                    } catch (t) {
                        console.error("Error processing prepended events", t)
                    }
                }))
            }
            populateFromQueryParams() {
                const t = this.globalContext ? .location ? .search,
                    e = new URLSearchParams(t),
                    n = this.globalContext[this.rootName],
                    o = n.get(h);
                N(e, "aps.trigger").forEach((t => {
                    o.queue.push(L(t))
                })), N(e, "aps.triggerFor", !0).forEach((t => {
                    void 0 !== t.accountId && n.has(t.accountId) && n.get(t.accountId).queue.push(L(t))
                }));
                const a = N(e, "aps_event");
                n.forEach((t => {
                    a.forEach((e => {
                        t.queue.push(L(e))
                    }))
                }))
            }
        }
        const N = (t, e, n = !1) => {
                const o = t.getAll(e),
                    a = [];
                return o.forEach((t => {
                    const e = t.split(",");
                    let o;
                    n && (o = e.shift());
                    const i = e.shift();
                    if (void 0 !== i && i.length > 0) {
                        const t = decodeURIComponent(e.join(","));
                        let n;
                        if (t.length > 0) try {
                            n = JSON.parse(t)
                        } catch {
                            console.error("Error processing query param event", i, n)
                        }
                        a.push({
                            eventName: i.replace(/_/g, "/"),
                            eventDetail: n,
                            accountId: o
                        })
                    }
                })), a
            },
            L = t => new CustomEvent(t.eventName, {
                detail: { ...t.eventDetail ? ? {}
                }
            }),
            M = window;
        class U {
            constructor(t, e, n) {
                this.ID = t, this.rootName = n, this.globalContext = e, this.clear()
            }
            clear() {
                new v(this.globalContext, this.rootName).update(j, (t => (t.delete(this.ID), t)))
            }
            recordListener(t, e) {
                new v(this.globalContext, this.rootName).update(j, (n => {
                    const o = n.get(this.ID);
                    return void 0 !== o ? o.push([t.name, e]) : n.set(this.ID, [
                        [t.name, e]
                    ]), n
                }))
            }
        }
        class q {
            constructor(t = M, e = "_aps") {
                this.dispatcher = new P(t, e), this.equiper = new E(t, e, this.dispatcher), this.subscriber = new D(t, e), this.populator = new T(t, e), this.globalContext = t, this.rootName = e
            }
            createAccount(t) {
                if (void 0 === t) throw new Error("accountID must be provided");
                this.globalContext[this.rootName] = this.globalContext[this.rootName] ? ? new Map;
                const e = this.globalContext[this.rootName],
                    n = {
                        store: new Map,
                        queue: []
                    };
                return !1 === e.has(t) && e.set(t, n), new f(t, {
                    globalContext: this.globalContext,
                    rootName: this.rootName
                })
            }
            subscribe(t) {
                this.subscriber.subscribe(t)
            }
            equip() {
                this.equiper.equip()
            }
            dispatch({
                reason: t
            }) {
                this.dispatcher.t({
                    reason: t
                })
            }
            populate() {
                this.populator.populate()
            }
            load({
                listeners: t
            }) {
                this.equip(), this.subscribe(t), this.dispatch({
                    reason: {
                        method: a.direct
                    }
                }), this.populate()
            }
            registerEventSource(t) {
                return this.equip(), new U(t, this.globalContext, this.rootName)
            }
        }
        var V;
        ! function(t) {
            t.postulate = "postulate", t.genericError = "error"
        }(V || (V = {}));
        const F = "26.521.1658";

        function B(t, e, n) {
            const o = new URL("https://prod.tahoe-analytics.publishers.advertising.a2z.com/logevent/putRecord");
            let a = t;
            try {
                "web-client-scenarios.aps.amazon.dev" === n ? .hostname ? a = t + "-debug-only" : window.Cypress && (a = t + "-integration-test")
            } catch (t) {}
            const i = { ...n,
                eventSource: "aps_web_client_library",
                eventCategory: a,
                eventName: e,
                libraryVersion: F
            };
            Object.entries(i).forEach((([t, e]) => {
                o.searchParams.append(t, e)
            })), fetch(o.toString(), {
                method: "GET",
                keepalive: !0,
                headers: {
                    "x-api-key": "79db72eb0b5c7255afa54a253df24fb4a5ac916bf40b51c730df8850aa5665ca"
                }
            }).catch((() => {}))
        }
        const z = {
                ut: setInterval,
                ft: function() {
                    return window[J] ? .[H]
                },
                ht: function(t = window) {
                    try {
                        return t.top ? .location || {
                            href: "unknown",
                            hostname: "unknown"
                        }
                    } catch (t) {
                        return {
                            href: "unknown",
                            hostname: "unknown"
                        }
                    }
                },
                vt: B,
                yt: function(t, e) {
                    return {
                        eventTime: G((() => `${Date.now()}`)),
                        accountID: G((() => t ? .accountID)),
                        libraryVersion: F,
                        url: G((() => e().href)),
                        hostname: G((() => e().hostname)),
                        message: G((() => t ? .message)),
                        condition: G((() => t ? .condition))
                    }
                },
                gt: function(t, e) {
                    try {
                        (e ? ? B)(V.genericError, "telemetry_core_failure", {
                            errorName: t ? .name ? ? "unknown",
                            errorMessage: t ? .message ? ? "unknown"
                        })
                    } catch {
                        (e ? ? B)(V.genericError, "telemetry_core_failure")
                    }
                }
            },
            J = "_aps_telemetry",
            H = "alarms";

        function G(t) {
            try {
                return t() ? ? "undefined"
            } catch (t) {
                return function(t) {
                    try {
                        return t instanceof Error ? `Access Error: ${t.name} - ${t.message}` : "Access Error: Unknown error type"
                    } catch {
                        return "Access Error: Unable to provide more information"
                    }
                }(t)
            }
        }

        function K(t, e, n) {
            const o = () => !1;
            throw n || function(t, e, n) {
                const o = window;
                void 0 === o[J] && (o[J] = {}), void 0 === o[J][H] && (o[J][H] = []);
                const a = o[J][H],
                    i = e.toString();
                a.push({
                    hash: t,
                    context: { ...n,
                        condition: i
                    }
                })
            }(t, o, e), new Error(e ? .message ? ? `Postulate violation: ${t}, ${o}`)
        }
        const W = new WeakMap;

        function Q({
            debugKey: t,
            obj: e,
            validators: n,
            root: o,
            separator: a
        }) {
            o = o ? ? "root", a = a ? ? ".";
            const i = {
                    nonModifiable: {
                        set(t, e) {
                            throw new Error(`Cannot set property "${String(e)}": "${o}" is not marked as modifiable.`)
                        },
                        deleteProperty(t, e) {
                            throw new Error(`Cannot delete property "${String(e)}": "${o}" is not marked as modifiable.`)
                        },
                        defineProperty(t, e) {
                            throw new Error(`Cannot define property "${String(e)}": "${o}" is not marked as modifiable.`)
                        },
                        setPrototypeOf(t) {
                            throw new Error(`Cannot set prototype: "${o}" is not marked as modifiable.`)
                        }
                    },
                    modifiable: {
                        set(t, e, n, o) {
                            try {
                                return Reflect.set(t, e, n, o)
                            } catch (o) {
                                if ("TypeError" === o.name) return t[e] = n, !0;
                                throw o
                            }
                        }
                    },
                    validating: {
                        get(e, i, s) {
                            if ("raw" === i) return W.get(s) || e;
                            if ("symbol" == typeof i) return Reflect.get(e, i, s);
                            if ((t => {
                                    if (["asymmetricMatch", "nodeType"].includes(t)) return !0
                                })(i)) return Reflect.get(e, i, s);
                            let r;
                            try {
                                r = Reflect.get(e, i, s)
                            } catch (t) {
                                if ("TypeError" !== t.name) throw t;
                                r = e[i]
                            }
                            return Q({
                                obj: r,
                                validators: n,
                                root: `${o}${a}${String(i)}`,
                                debugKey: t
                            })
                        },
                        ownKeys: t => Reflect.ownKeys(t).filter((t => {
                            const e = `${o}${a}${String(t)}`;
                            return void 0 !== n[e]
                        }))
                    },
                    function: {
                        apply: (e, a, i) => {
                            const s = W.has(a) ? W.get(a) : a;
                            return Q({
                                obj: e.apply(s, i),
                                validators: n,
                                root: `${o}()`,
                                debugKey: t
                            })
                        },
                        get: (t, e, n) => "raw" === e ? W.get(n) || t : Reflect.get(t, e, n)
                    }
                },
                s = function(a) {
                    if (!1 === a.verifiable) return e;
                    if (e instanceof Set) return e.forEach((e => {
                        Q({
                            obj: e,
                            validators: n,
                            root: `${o}.value`,
                            debugKey: t
                        })
                    })), e;
                    if (e instanceof Map) return e.forEach(((e, a) => {
                        Q({
                            obj: a,
                            validators: n,
                            root: `${o}.key`,
                            debugKey: t
                        }), Q({
                            obj: e,
                            validators: n,
                            root: `${o}.value`,
                            debugKey: t
                        })
                    })), e;
                    if (Array.isArray(e)) return e.map((e => Q({
                        obj: e,
                        validators: n,
                        root: `${o}[]`,
                        debugKey: t
                    })));
                    if ("function" == typeof e) {
                        const t = new Proxy(e, i.function);
                        return W.set(t, e), t
                    }
                    const s = { ...i.validating,
                        ...a ? .modifiable ? i.modifiable : i.nonModifiable
                    };
                    try {
                        const t = new Proxy(e, s);
                        return W.set(t, e), t
                    } catch (t) {
                        if ("TypeError" === t.name) return e;
                        throw t
                    }
                }(function() {
                    const a = (t ? ? "").length > 0 ? `Location: ${t} - ` : "",
                        i = n[o ? ? ""];
                    if (void 0 === i) {
                        const t = ".constructor" === (o ? ? "").slice(-12) || ".toString" === (o ? ? "").slice(-9);
                        K("ea3914", {
                            message: `${a}Unauthorized usage for "${o}": No validator has been defined`
                        }, t)
                    }
                    if (null === i) return {
                        verifiable: !1
                    };
                    let s;
                    try {
                        s = i(e, o)
                    } catch (t) {
                        let n = "Error, could not convert to string";
                        try {
                            n = "string" == typeof e ? '"' + e + '"' : null != e && "function" == typeof e.toString ? e.toString() : Object.prototype.toString.call(e)
                        } catch (t) {}
                        throw new Error(`${a}Validation failed for "${o}": ${t.message} - Received: ${n}`)
                    }
                    return s ? ? {}
                }());
            return s
        }
        const Y = t => {
                if ("number" != typeof t) throw new Error("must be a number")
            },
            Z = t => {
                if ("string" != typeof t) throw new Error("must be a string")
            },
            X = t => {
                if ("boolean" != typeof t) throw new Error("must be a boolean")
            },
            tt = t => {
                if ("object" != typeof t || null === t || Array.isArray(t)) throw new Error("must be a standard object")
            };

        function et(t) {
            if (void 0 !== t ? .min && (t.min < 0 || t.min > 1)) throw new Error("min option must be between 0 and 1");
            if (void 0 !== t ? .max && (t.max < 0 || t.max > 1)) throw new Error("max option must be between 0 and 1");
            const e = t ? .min ? ? 0,
                n = t ? .max ? ? 1;
            if (e > n) throw new Error("min option cannot be greater than max option");
            return t => {
                if ("number" != typeof t) throw new Error("must be a number");
                if (t < e || t > n) throw new Error(`must be a percentage between ${e} and ${n} (where 1 = 100%)`)
            }
        }
        const nt = t => e => {
                let n = !1;
                for (const o of t) try {
                    o(e), n = !0
                } catch (t) {}
                if (!n) throw new Error("None of the validators passed")
            },
            ot = t => {
                if (!Array.isArray(t)) throw new Error("must be an array")
            };

        function at(t) {
            return e => {
                if (!1 === t.includes(e)) throw new Error(`must be one of the following values: ${JSON.stringify(t)}`)
            }
        }

        function it(t) {
            return (e, n) => ({
                modifiable: !0,
                ...t(e, n)
            })
        }

        function st(t) {
            return (e, n) => {
                if (t === ct) throw new Error("isAny cannot be used within isOptional");
                if (null != e) return t(e, n)
            }
        }
        const rt = t => {
                if ("function" != typeof t) throw new Error("must be a function")
            },
            ct = () => {},
            dt = () => ({
                verifiable: !1
            }),
            lt = t => {
                if (void 0 !== t) throw new Error("must be undefined")
            };
        class ut {
            constructor(t) {
                const {
                    scope: e,
                    object: n,
                    action: o,
                    validators: a,
                    handler: i,
                    shouldFlushAnalytics: s
                } = t, r = `${e}/${n}/${o}`;
                this.throwIfInvalid(e, n, o), this.name = `${e}/${n}/${o}`, this.handler = this.wrapHandler({
                    handler: i,
                    validators: a,
                    debugKey: r
                }), !0 === s && (this.handler.shouldFlushAnalytics = !0)
            }
            wrapHandler({
                debugKey: t,
                handler: e,
                validators: n
            }) {
                return async o => {
                    let a = o;
                    return a = { ...a,
                        detail: Q({
                            obj: a.customEvent.detail,
                            validators: this.getDetailValidators(n),
                            root: "detail",
                            debugKey: t
                        }),
                        context: Q({
                            obj: a.account.globalContext,
                            validators: this.getContextValidators(n),
                            root: "context",
                            debugKey: t
                        })
                    }, await e(a)
                }
            }
            getDetailValidators(t) {
                return t ? .detail && 0 !== Object.keys(t.detail).length ? t.detail : {
                    detail: ct
                }
            }
            getContextValidators(t) {
                return t ? .context && 0 !== Object.keys(t.context).length ? t.context : {
                    context: ct
                }
            }
            throwIfInvalid(t, e, n) {
                if (["consent/gppapi/attemptSync", "consent/gppapi/didChange", "consent/gppapi/syncData", "consent/tcfapi/attemptSync", "consent/tcfapi/didChange", "log/analytics/setInterval", "analytics/sampling/set"].includes(`${t}/${e}/${n}`)) return;
                const o = /^[a-z0-9][a-zA-Z0-9]*$/;
                if (!o.test(t) || !o.test(e) || !o.test(n)) throw new Error(`scope, object, and action must be alphanumeric and start with a lowercase. Received: ${t}, ${e}, ${n}`);
                if (/[A-Z]/.test(n) && !/^(will|did)/i.test(n)) throw new Error(`action must be a single verb (or a single verb prefixed by 'will' or 'did'). Received: ${n}`)
            }
        }

        function pt(t) {
            if (new Set(t.map((t => t.name))).size !== t.length) throw new Error("Duplicates found");
            return new Map(t.map((t => [t.name, t.handler])))
        }
        class mt {
            constructor() {
                this.wt = 300, this.bt = "https://prod.tahoe-analytics.publishers.advertising.a2z.com/logevent/putRecords", this.Et = "79db72eb0b5c7255afa54a253df24fb4a5ac916bf40b51c730df8850aa5665ca", this.St = 5e3, this.xt = [], this.clearAndUpdateEventProcessingInterval(5e3)
            }
            logEvent(t) {
                try {
                    const n = `${Date.now()}`,
                        o = null == (e = t.eventSampleRate) || isNaN(e) || e < 0 ? 0 : e >= 0 && e <= 1 ? e : 1,
                        a = {
                            Data: {
                                eventSource: "aps_web_client_library",
                                eventTime: n,
                                eventCategory: t.eventCategory,
                                eventName: t.eventName,
                                eventSampleRate: o,
                                eventProperties: { ...t.eventProperties,
                                    eventSampleRate: `${o}`
                                }
                            },
                            PartitionKey: n
                        };
                    this.xt.push(a)
                } catch (t) {
                    K("4daf34", {
                        message: t.message
                    })
                }
                var e;
                this.xt.length > this.St && this.safelyProcessRecordQueue()
            }
            flush() {
                this.safelyProcessRecordQueue()
            }
            clearAndUpdateEventProcessingInterval(t) {
                "number" != typeof t || t <= 0 || t !== this._t && (clearInterval(this.Rt), this.Rt = setInterval((() => this.safelyProcessRecordQueue()), t), this._t = t)
            }
            safelyProcessRecordQueue() {
                if (void 0 === this.xt || this.xt.length <= 0) return;
                const t = this.xt.filter((t => void 0 !== t && t.Data.eventSampleRate >= Math.random()));
                this.xt.length = 0, t.length <= 0 || this.batchSendRecords(t).catch((t => {
                    this.logEvent({
                        eventCategory: "error",
                        eventName: "tahoe/putRecords/didFail",
                        eventSampleRate: 1,
                        eventProperties: {
                            error: {
                                message: t ? .message
                            }
                        }
                    })
                }))
            }
            batchSendRecords(t) {
                const e = [];
                for (let n = 0; n < t.length; n += this.wt) {
                    const o = this.sendRecords(t.slice(n, n + this.wt));
                    e.push(o)
                }
                return Promise.all(e)
            }
            sendRecords(t) {
                return fetch(`${this.bt}?encoded=${k()?"false":"true"}`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "x-api-key": this.Et
                    },
                    body: JSON.stringify({
                        Records: k() ? t : (t => t.map((t => ({ ...t,
                            Data: window.btoa(JSON.stringify(t.Data))
                        }))))(t)
                    })
                })
            }
        }
        const ft = {
                key: "_config/requestViewer/countryCode",
                default: "unknown"
            },
            ht = {
                key: "video/analytics",
                default: void 0
            },
            vt = new class {
                constructor() {
                    this.STACK_MAX_LENGTH = 500, this.It = .001, this.At = 1e-4, this.kt = new mt
                }
                getVideoPlayerMetadata(t) {
                    const e = t.account ? .use(ht, {
                            structuredClone: !1
                        }),
                        n = "object" == typeof t.props ? .legacyPlayerEventProps;
                    return e ? .getMetadata && !n ? {
                        legacyPlayerEventProps: e.getMetadata()
                    } : {}
                }
                fireReferencePixel(t, e) {
                    this.logCoreError({
                        id: `REFERENCE-${t}`,
                        error: new Error(`REFERENCE-${t}`),
                        analyticsSampleRateAdjustFactor: e ? ? {
                            status: .01,
                            error: .01
                        },
                        account: null
                    })
                }
                logCoreError(t) {
                    this.logError({ ...t,
                        isCore: !0
                    })
                }
                logCoreFeature(t) {
                    this.logFeature({ ...t,
                        isCore: !0
                    })
                }
                logError(t) {
                    if (void 0 === t) return;
                    const e = this.getEventSampleRate({
                        eventCategory: "error",
                        rateFactor: {
                            error: t.analyticsSampleRateAdjustFactor ? .error,
                            status: t.analyticsSampleRateAdjustFactor ? .status
                        }
                    });
                    this.kt.logEvent({
                        eventCategory: "error",
                        eventName: t.id ? ? "unknown",
                        eventSampleRate: e,
                        eventProperties: { ...t.props,
                            ...this.getSharedEventProperties(t),
                            error: {
                                name: this.getErrorName(t.error),
                                message: this.getErrorMessage(t.error),
                                stack: this.getStackTraceMessage(t.error),
                                context: this.getErrorContext(t.error)
                            }
                        }
                    })
                }
                logFeature(t) {
                    if (void 0 === t) return;
                    const e = this.getEventSampleRate({
                        eventCategory: "feat",
                        rateFactor: {
                            error: t.analyticsSampleRateAdjustFactor ? .error,
                            status: t.analyticsSampleRateAdjustFactor ? .status
                        }
                    });
                    this.kt.logEvent({
                        eventCategory: "feat",
                        eventName: t.id ? ? "unknown",
                        eventSampleRate: e,
                        eventProperties: { ...t.props,
                            ...this.getSharedEventProperties(t),
                            status: t.feature
                        }
                    })
                }
                flush() {
                    this.kt.flush()
                }
                setEventProcessingInterval(t) {
                    if ("number" != typeof t) throw new Error("Event processing interval must be a number.");
                    this.kt.clearAndUpdateEventProcessingInterval(t)
                }
                setEventSamplingRates(t) {
                    const e = t => t < 0 ? 0 : t >= 0 && t <= 1 ? t : 1;
                    "number" == typeof t ? .error && (this.It = e(t.error)), "number" == typeof t ? .feature && (this.At = e(t.feature))
                }
                getEventSampleRate(t) {
                    let e = 0;
                    return e = "error" === t.eventCategory ? this.It * (t.rateFactor ? .error ? ? 1) : this.At * (t.rateFactor ? .status ? ? 1), Number.isNaN(e) || e < 0 ? 0 : e >= 0 && e <= 1 ? e : 1
                }
                getSharedEventProperties(t) {
                    return {
                        isCore: t.isCore ? ? !1,
                        accountID: this.safelyGetAccountID(t.account),
                        libraryVersion: t.libraryVersion ? ? R,
                        url: this.getLocationHref(),
                        hostname: this.getLocationHostname(),
                        viewerCountryCode: this.getViewerCountryCode(t.account),
                        ...this.getVideoPlayerMetadata(t)
                    }
                }
                safelyGetAccountID(t) {
                    let e = "unknown";
                    try {
                        void 0 !== t ? .id && (e = t.id)
                    } catch (t) {
                        try {
                            e = `Client Error: ${t.name.toString()} - ${t.message}`
                        } catch {
                            e = "Client Error: Unable to provide more information"
                        }
                    }
                    return e
                }
                getLocationHref() {
                    let t = "";
                    try {
                        t = window.top ? .location ? .href ? ? ""
                    } catch (e) {
                        try {
                            t = `Client Error: ${e.name.toString()} - ${e.message}`
                        } catch {
                            t = "Client Error: Unable to provide more information"
                        }
                    }
                    return t
                }
                getLocationHostname() {
                    let t = "";
                    try {
                        t = window.top ? .location ? .hostname ? ? ""
                    } catch (e) {
                        try {
                            t = `Client Error: ${e.name.toString()} - ${e.message}`
                        } catch {
                            t = "Client Error: Unable to provide more information"
                        }
                    }
                    return t
                }
                getViewerCountryCode(t) {
                    let e = "unknown";
                    try {
                        null !== t && (e = t.use(ft))
                    } catch (t) {
                        try {
                            e = `Client Error: ${t.name.toString()} - ${t.message}`
                        } catch {
                            e = "Client Error: Unable to provide more information"
                        }
                    }
                    return e
                }
                getStackTraceMessage(t) {
                    try {
                        if ("string" == typeof t) return "NO STACK: ERROR PASSED AS STRING";
                        if (void 0 === t.stack) return "NO STACK: error.stack IS UNDEFINED";
                        if (t.stack.length > this.STACK_MAX_LENGTH) {
                            const e = "[...]";
                            return t.stack.substring(0, this.STACK_MAX_LENGTH - e.length) + e
                        }
                        return t.stack
                    } catch (t) {
                        return "NO STACK: ERROR ON RETRIEVAL"
                    }
                }
                getErrorName(t) {
                    let e = "unknown";
                    try {
                        "string" == typeof t ? e = t : void 0 !== t.name && (e = t.name)
                    } catch (t) {
                        try {
                            e = `Client Error: ${t.name.toString()} - ${t.message}`
                        } catch {
                            e = "Client Error: Unable to provide more information"
                        }
                    }
                    return e
                }
                getErrorMessage(t) {
                    let e = "unknown";
                    try {
                        "string" == typeof t ? e = t : void 0 !== t.message && (e = t.message)
                    } catch (t) {
                        try {
                            e = `Client Error: ${t.name.toString()} - ${t.message}`
                        } catch {
                            e = "Client Error: Unable to provide more information"
                        }
                    }
                    return e
                }
                getErrorContext(t) {
                    let e = "unknown";
                    try {
                        "string" != typeof t && "context" in t && (e = t.context ? ? "")
                    } catch (t) {
                        try {
                            e = `Client Error: ${t.name.toString()} - ${t.message}`
                        } catch {
                            e = "Client Error: Unable to provide more information"
                        }
                    }
                    return e
                }
            },
            yt = new Map([
                ["_config/config/didLoad", async ({
                    account: t,
                    customEvent: e
                }) => (t.write("config/loaded", !0), s.completed)],
                ["_config/requestViewerCountry/define", async ({
                    account: t,
                    customEvent: e
                }) => {
                    if (void 0 === e.detail ? .code) throw new Error("Missing country code");
                    const {
                        code: n
                    } = e.detail;
                    if ("string" != typeof n || 0 === n.trim().length) throw new Error(`Invalid country code: "${n}"`);
                    return t.update(ft, (() => n)), s.completed
                }]
            ]),
            gt = "apstag/configuration/fetch",
            wt = new Map([
                [gt, async ({
                    account: t,
                    customEvent: e
                }) => {
                    const n = t.globalContext.document.createElement("script");
                    return n.setAttribute("src", `https://config.aps.amazon-adsystem.com/configs/${t.id}`), n.setAttribute("type", "text/javascript"), n.setAttribute("async", "async"), t.globalContext.document.head.appendChild(n), await new Promise(((t, e) => {
                        n.addEventListener("load", (() => {
                            t()
                        })), n.addEventListener("error", (t => {
                            e(t)
                        }))
                    })), s.completed
                }]
            ]),
            bt = "consent/GPPData",
            Et = "consent/isGPPListenerRegistered";
        var St = new ut({
                scope: "consent",
                object: "gppapi",
                action: "syncData",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.fromAddEvent": st(X),
                        "detail.eventListener": st(tt),
                        "detail.eventListener.pingData": st(tt),
                        "detail.eventListener.pingData.gppString": st(Z),
                        "detail.eventListener.pingData.gppVersion": st(nt([Z, Y])),
                        "detail.eventListener.pingData.cmpId": st(nt([Z, Y])),
                        "detail.eventListener.pingData.applicableSections": ot,
                        "detail.eventListener.pingData.applicableSections[]": nt([Z, Y])
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => {
                    let n, o, a, i;
                    (e ? .eventListener ? .pingData ? .gppString ? ? "").length > 0 ? (n = e ? .eventListener ? .pingData, i = "addEventListener") : ([n, a] = (t => {
                        let e, n;
                        try {
                            const n = t.globalContext.__gpp("ping", ((t, n) => {
                                n && "object" == typeof t && (e = t)
                            }));
                            void 0 === e && (n ? .gppString ? ? "").length > 0 && (e = n)
                        } catch (t) {
                            n = `E:ping: ${t}`
                        }
                        return [e, n]
                    })(t), i = "ping", "object" != typeof n && ([n, o] = (t => {
                        let e, n;
                        try {
                            const n = t.globalContext.__gpp("getGPPData");
                            e = { ...n,
                                ...n.pingData
                            }
                        } catch (t) {
                            n = `E:getGPPData: ${t}`
                        }
                        return [e, n]
                    })(t), i = "getGPPData"));
                    const r = {
                        gpp: {
                            gppLength: "string" == typeof n ? .gppString ? n.gppString.length : void 0,
                            isGPPTilde: (n ? .gppString ? ? "").includes("~"),
                            error10: o,
                            error: a,
                            gppVersion: n ? .gppVersion,
                            cmpId: n ? .cmpId,
                            method: i,
                            fromAddEvent: e ? .fromAddEvent
                        }
                    };
                    return t.write(bt, n), {
                        status: s.completed,
                        analytics: r
                    }
                }
            }),
            xt = new ut({
                scope: "consent",
                object: "gppapi",
                action: "didChange",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.fromAddEvent": st(X),
                        "detail.eventListener": st(tt),
                        "detail.eventListener.pingData": st(tt),
                        "detail.eventListener.pingData.gppString": st(Z),
                        "detail.eventListener.pingData.gppVersion": st(nt([Z, Y])),
                        "detail.eventListener.pingData.cmpId": st(nt([Z, Y])),
                        "detail.eventListener.pingData.applicableSections": ot,
                        "detail.eventListener.pingData.applicableSections[]": nt([Z, Y])
                    }
                },
                handler: async ({
                    account: t,
                    detail: {
                        eventListener: e,
                        fromAddEvent: n
                    }
                }) => (await t.recordListener(St, {
                    eventListener: e,
                    fromAddEvent: n
                }), {
                    status: s.completed
                })
            }),
            _t = new ut({
                scope: "consent",
                object: "gppapi",
                action: "attemptSync",
                handler: async ({
                    account: t
                }) => {
                    if (void 0 === t.globalContext.__gpp || !0 === t.read(Et)) return {
                        status: s.cancelled
                    };
                    await t.recordListener(St);
                    const e = t.globalContext.__gpp("addEventListener", (e => {
                        "error" !== e ? .eventName && t.recordListenerNonBlocking(xt, {
                            eventListener: e,
                            fromAddEvent: !0
                        })
                    }));
                    return t.write(Et, "listenerRegistered" === e ? .eventName && !0 === e ? .data), {
                        status: s.completed
                    }
                }
            });
        const Rt = {
                key: "consent/isTCFAPIListenerRegistered",
                default: !1
            },
            It = {
                key: "consent/TCData",
                default: void 0
            };

        function At(t, e) {
            return "string" == typeof e ? .tcString && e ? .tcString.length > 0 || !0 === t ? .globalContext ? .apstag ? .isGDPRRegion || !0 === e ? .gdprApplies
        }

        function kt(t, e) {
            return !0 === t.vendor ? .consents ? .[793] && (n = e, o = t.purpose ? .consents, (n ? ? []).reduce(((t, e) => t && !0 === o ? .[e]), !0));
            var n, o
        }
        var jt = new ut({
            scope: "consent",
            object: "tcfapi",
            action: "didChange",
            validators: {
                detail: {
                    detail: tt,
                    "detail.success": st(X),
                    "detail.tcData": st(dt)
                }
            },
            handler: async ({
                account: t,
                detail: {
                    success: e,
                    tcData: n
                }
            }) => (t.update(Rt, (t => t || !0 === e)), t.update(It, (t => void 0 !== n || !0 === e ? n : t)), "object" != typeof n ? {
                status: s.completed
            } : {
                status: s.completed,
                analytics: $t(t, n)
            })
        });
        const $t = (t, e) => {
            const n = {
                    tcData: e,
                    consents: [1]
                },
                o = t => {
                    try {
                        return t()
                    } catch {
                        return "error"
                    }
                };
            return {
                tcT: o((() => t.isAPStagAllowedToAccessInfoOnDevice())),
                tcCC: o((() => function({
                    account: t,
                    tcData: e,
                    consents: n
                }) {
                    if (!At(t, e)) return !0;
                    if ("object" != typeof e) return !1;
                    if ((e.tcfPolicyVersion ? ? 0) < 2) return !1;
                    if (e.useNonStandardStacks) return !1;
                    if (!e.isServiceSpecific) return !1;
                    let o = !1;
                    return n.forEach((t => {
                        const a = e.publisher ? .restrictions ? .[t] ? .[793];
                        switch (a) {
                            case 0:
                            case 2:
                                o = !0;
                                break;
                            default:
                                kt(e, n) || (o = !0)
                        }
                    })), !o
                }({ ...n,
                    account: t
                }))),
                tcCF: o((() => 0 === function({
                    tcData: t,
                    consents: e
                }) {
                    if (0 === (e ? ? []).length) return ["No consents param passed"];
                    const n = [];
                    try {
                        if ("object" != typeof t) {
                            let e = "";
                            try {
                                e = JSON.stringify(t)
                            } catch {}
                            n.push(`Invalid tcData: ${e}`)
                        }
                        return !1 === t.gdprApplies ? [] : ((t.tcfPolicyVersion ? ? 0) < 2 && n.push(`tcData version not supported: ${t.tcfPolicyVersion}`), t.useNonStandardStacks && n.push("tcData's useNonStandardStacks should not be true"), t.isServiceSpecific || n.push("tcData needs to be service specific"), e.forEach((o => {
                            const a = t.publisher ? .restrictions ? .[o] ? .[793];
                            switch (a) {
                                case 0:
                                    n.push(`Invalid publisher restrictions 0, consent ${o}`);
                                    break;
                                case 2:
                                    n.push(`Invalid publisher restrictions 2, consent ${o}`);
                                    break;
                                default:
                                    kt(t, e) || n.push(`Invalid publisher restrictions default, consent ${o}`)
                            }
                        })), n)
                    } catch (t) {
                        if (n.length > 0) return n;
                        throw t
                    }
                }(n).length)),
                PRA: o((() => At(t, e)))
            }
        };
        var Ct = new ut({
            scope: "consent",
            object: "tcfapi",
            action: "attemptSync",
            handler: async ({
                account: t
            }) => {
                const e = t.use(Rt);
                return void 0 === t.globalContext.__tcfapi || e ? {
                    status: s.cancelled
                } : (t.globalContext.__tcfapi("addEventListener", 2, ((e, n) => {
                    t.recordListenerNonBlocking(jt, {
                        tcData: e,
                        success: n
                    })
                })), {
                    status: s.completed
                })
            }
        });
        const Ot = pt([_t, xt, St, Ct, jt]),
            Pt = "vnd_prx_segments",
            Dt = "aps_targeting_comscore";
        var Tt = new ut({
            scope: "cxm",
            object: "comscore",
            action: "set",
            handler: async ({
                account: t,
                customEvent: e
            }) => ({
                status: Nt(t)
            })
        });
        const Nt = t => {
                const e = t.readSessionStorage(Dt);
                if (t.deleteSessionStorage(Dt), null == e) return s.cancelled;
                try {
                    const n = JSON.parse(e)[Pt];
                    if (null == n) throw new Error;
                    const {
                        googletag: o
                    } = t.globalContext;
                    return o.pubads().getSlots().forEach((t => {
                        t.setTargeting(Pt, n)
                    })), s.completed
                } catch (t) {
                    throw new Error(`Malformed targeting object at ${Dt}`)
                }
            },
            Lt = "aps_targeting_ias";
        var Mt = new ut({
            scope: "cxm",
            object: "ias",
            action: "set",
            handler: async ({
                account: t,
                customEvent: e
            }) => ({
                status: Ut(t)
            })
        });
        const Ut = t => {
                const e = (t => {
                    const {
                        iasApsArtifact: e
                    } = t.globalContext;
                    if (e) return e;
                    const n = t.readSessionStorage(Lt);
                    return n ? (t.deleteSessionStorage(Lt), JSON.parse(n)) : void 0
                })(t);
                if (null == e) return s.cancelled;
                try {
                    const {
                        googletag: n
                    } = t.globalContext;
                    n.pubads().getSlots().forEach((t => {
                        const n = e.targeting.slots[t.getSlotElementId()];
                        null != n && Object.keys(n).forEach((e => {
                            t.setTargeting(e, n[e])
                        }))
                    }));
                    const {
                        brandSafety: o,
                        fr: a,
                        custom: i
                    } = e.targeting;
                    return null != o && Object.keys(o).forEach((t => {
                        n.pubads().setTargeting(t, o[t])
                    })), null != i && Object.keys(i).forEach((t => {
                        const e = i[t];
                        n.cmd.push((() => n.pubads().setTargeting(t, e)))
                    })), null != a && n.pubads().setTargeting("fr", a), s.completed
                } catch (t) {
                    throw new Error(`Malformed targeting object at ${Lt}`)
                }
            },
            qt = "aps_targeting_illuma";
        var Vt = new ut({
            scope: "cxm",
            object: "illuma",
            action: "set",
            handler: async ({
                account: t,
                customEvent: e
            }) => ({
                status: Ft(t)
            })
        });
        const Ft = t => {
            const e = t.readSessionStorage(qt);
            if (t.deleteSessionStorage(qt), null == e) return s.cancelled;
            const n = JSON.parse(e).results;
            if (null == n) throw new Error(`Malformed targeting object at ${qt}`);
            const {
                googletag: o
            } = t.globalContext;
            return Object.keys(n).forEach((t => {
                const e = n[t];
                o.pubads().setTargeting(`illuma_${t}`, JSON.stringify(e))
            })), s.completed
        };
        var Bt = new ut({
            scope: "cxm",
            object: "contextual",
            action: "set",
            handler: async ({
                account: t,
                customEvent: e
            }) => (await Promise.all([t.recordListener(Tt), t.recordListener(Mt), t.recordListener(Vt)]), {
                status: s.completed
            })
        });
        const zt = pt([Tt, Bt, Mt, Vt]),
            Jt = {
                key: "customPlacement/hints",
                default: {}
            },
            Ht = {
                key: "customPlacement/bidResponses",
                default: {}
            };
        class Gt {
            constructor(t, e, n) {
                this.CLICK_PREFIX_MACRO = "%%CLICK_URL_PREFIX%%", this.PROGRAM_CUSTOM_PLACEMENTS = "customPlacements", this.getPageStyles = (t = ["p", "h1", "h2"]) => t.map(this.getTagStyle).filter((t => Object.keys(t).length > 0)).reduce(((t, e) => ({ ...t,
                    ...e
                })), {}), this.getContainerStyles = t => {
                    try {
                        if (!t) return {};
                        const e = window.getComputedStyle(t),
                            n = "--aps-custom-container-",
                            o = new Map;
                        return o.set(`${n}width`, e.width), o.set(`${n}margin`, e.margin), o.set(`${n}padding`, e.padding), Object.fromEntries(o.entries())
                    } catch (t) {
                        return {}
                    }
                }, this.slotProps = t, this.rawResponse = e, this.jt = n
            }
            getTagStyle(t) {
                const e = this.jt.getElementsByTagName(t);
                if (e && e[0]) {
                    const e = window.getComputedStyle(this.jt.getElementsByTagName(t)[0]),
                        n = new Map,
                        o = "--aps-custom-page-";
                    return n.set(`${o}${t}-color`, e.color), n.set(`${o}${t}-fontFamily`, e.fontFamily), n.set(`${o}${t}-fontSize`, e.fontSize), n.set(`${o}${t}-fontWeight`, e.fontWeight), n.set(`${o}${t}-lineHeight`, e.lineHeight), Object.fromEntries(n)
                }
                return {}
            }
            getDynamicFrameBodyHeight(t, e, n) {
                if (e) {
                    const n = e ? .contentDocument || e ? .contentWindow ? .document,
                        o = n ? .body.scrollHeight;
                    e.style.height = `${o}px`;
                    try {
                        const e = { ...this.getPageStyles(),
                            ...this.getContainerStyles(t)
                        };
                        Object.keys(e).forEach((t => {
                            n ? .documentElement.style.setProperty(t, e[t])
                        }))
                    } catch (t) {}
                }
            }
            render(t) {
                return this.$t(t)
            }
            $t(t) {
                if (!this.rawResponse || !this.slotProps) return !1;
                try {
                    const e = this.rawResponse.size.split("x"),
                        n = this.rawResponse.targeting ? .amzniid || this.rawResponse.amzniid,
                        o = this.rawResponse.targeting ? .amznadm || this.rawResponse.amznadm;
                    if (!n) return !1;
                    let a = this.slotProps.Ct;
                    if (this.slotProps.location && this.slotProps.id) {
                        const t = this.jt.createElement("div");
                        this.jt.getElementById(this.slotProps.id) ? .insertAdjacentElement(this.slotProps.location, t), a = t
                    }
                    if (!a) return !1;
                    const i = this.jt.createElement("iframe");
                    return i.style.marginLeft = "0", i.style.marginTop = "0", i.style.height = `${e[1]}px`, i.style.width = "100%", i.setAttribute("data-testid", "amzn-asr-ad"), i.setAttribute("scrolling", "no"), i.setAttribute("frameborder", "0"), i.onload = () => this.getDynamicFrameBodyHeight(a, i, o ? "amznadm" : "admi"), i.srcdoc = o || "", t && t.clickPrefix && (i.srcdoc = i.srcdoc.replace(this.CLICK_PREFIX_MACRO, t.clickPrefix)), a.appendChild(i), this.updateSlotAttribute("status", "rendered"), !0
                } catch (t) {
                    throw new Error("CustomPlacements: Error while rendering")
                }
            }
            updateSlotAttribute(t, e) {
                this.slotProps.Ct ? .setAttribute(`data-aps-custom-${t}`, e)
            }
        }
        const Kt = {
                key: "customPlacement/timings",
                default: []
            },
            Wt = (t, e, n = 0, o = 0) => {
                try {
                    const a = {
                            effectiveType: e ? .effectiveType,
                            rtt: e ? .rtt,
                            downlink: e ? .downlink
                        },
                        i = function(t, e, n) {
                            try {
                                return `${isNaN(e)||0===e?t.body.clientWidth:e}x${isNaN(n)||0===n?t.body.clientHeight:n}`
                            } catch (t) {}
                            return "x"
                        }(t, n, o);
                    return {
                        connection: a,
                        screen: i
                    }
                } catch (t) {
                    return {}
                }
            },
            Qt = (t, e, n) => {
                t.update(Kt, (t => (t.push({
                    time: performance.now(),
                    key: `${e}/${n}`
                }), t)))
            },
            Yt = "customPlacements";
        var Zt = new ut({
                scope: "customPlacement",
                object: "hint",
                action: "process",
                validators: {},
                handler: async ({
                    account: t,
                    detail: e,
                    customEvent: n
                }) => {
                    const o = e => {
                            Qt(t, Yt, `hint/process/${e}`);
                            const n = t.use(Jt),
                                o = t.use(Ht);
                            n[e].isRendered || (Object.values(o).forEach((o => {
                                if (o.isRendered) return;
                                const a = t.globalContext.document.getElementById(e);
                                if (null == a) return;
                                const i = new Gt({
                                    id: e,
                                    Ct: a
                                }, o, t.globalContext.document);
                                Qt(t, Yt, `widget/render/${e}`), i.render(n[e].hintMetadata) && (o.isRendered = !0, n[e].isRendered = !0)
                            })), t.update(Jt, (() => n)), t.update(Ht, (() => o)))
                        },
                        a = t.use(Jt);
                    return Object.keys(a).filter((t => a[t].default)).forEach(o), Object.keys(a).filter((t => !a[t].default)).forEach(o), {
                        status: s.completed,
                        analytics: {
                            browserInfo: Wt(t.globalContext.document, t.globalContext.navigator ? .connection, t.globalContext.innerWidth, t.globalContext.innerHeight)
                        }
                    }
                }
            }),
            Xt = new ut({
                scope: "customPlacement",
                object: "hint",
                action: "define",
                validators: {},
                handler: async ({
                    account: t,
                    detail: e,
                    customEvent: n
                }) => {
                    if (void 0 === n.detail ? .id) throw new Error("Hint `id` must be defined");
                    const {
                        id: o,
                        isDefault: a,
                        hintMetadata: i
                    } = n.detail;
                    Qt(t, Yt, `hint/define/${o}`);
                    const r = t.use(Jt);
                    return r[o] = {
                        default: "default" === a,
                        isRendered: !1,
                        hintMetadata: i ? ? {}
                    }, t.update(Jt, (() => r)), t.recordListenerNonBlocking(Zt), {
                        status: s.completed,
                        analytics: {
                            browserInfo: Wt(t.globalContext.document, t.globalContext.navigator ? .connection, t.globalContext.innerWidth, t.globalContext.innerHeight)
                        }
                    }
                }
            });
        const te = {
                key: "customPlacement/placementResponseDispatched",
                default: !1
            },
            ee = {
                key: "customPlacement/placementResponse",
                default: void 0
            },
            ne = {
                key: "customPlacement/contextURL",
                default: void 0
            },
            oe = {
                key: "customPlacement/placementEndpoint",
                default: "https://c.aps.amazon-adsystem.com/e/placements"
            },
            ae = {
                key: "ad/context",
                default: void 0
            };
        var ie = new ut({
            scope: "customPlacement",
            object: "placement",
            action: "fetch",
            validators: {},
            handler: async ({
                account: t,
                detail: e,
                customEvent: n
            }) => {
                Qt(t, Yt, "placementFetch/start");
                const o = await async function(t) {
                    const e = {
                            ortb2: se(t)
                        },
                        n = t.use(ne),
                        o = t.use(oe),
                        a = function(t, e) {
                            try {
                                const n = e ? ? function(t) {
                                    try {
                                        if (void 0 !== t.globalContext.top ? .location.href) return t.globalContext.top ? .location.href
                                    } catch (t) {}
                                    try {
                                        if (t.globalContext.top !== t.globalContext.self) return t.globalContext.document.referrer
                                    } catch (t) {}
                                }(t);
                                if (void 0 !== n) return encodeURIComponent(n)
                            } catch (t) {}
                            return ""
                        }(t, n),
                        i = encodeURIComponent(JSON.stringify(e)),
                        s = await fetch(`${o}?account=${t.id}&u=${a}&sg=${i}`);
                    return await s.json()
                }(t);
                return Qt(t, Yt, "placementFetch/end"), {
                    status: s.completed,
                    value: {
                        placementResponse: o
                    },
                    analytics: {
                        browserInfo: Wt(t.globalContext.document, t.globalContext.navigator ? .connection, t.globalContext.innerWidth, t.globalContext.innerHeight)
                    }
                }
            }
        });

        function se(t) {
            const e = t.use(ae);
            if (void 0 !== e && "user" in e) {
                const {
                    user: t,
                    ...n
                } = e;
                return n
            }
            return e
        }
        const re = {
                key: "customPlacement/bidEndpoint",
                default: "c.aps.amazon-adsystem.com"
            },
            ce = {
                key: "customPlacement/bidIsKey",
                default: "86355855cc6ed9e335d0382c8563aa10"
            };
        var de = new ut({
                scope: "customPlacement",
                object: "bids",
                action: "fetch",
                validators: {},
                handler: async ({
                    account: t,
                    detail: e,
                    customEvent: n
                }) => {
                    const o = Wt(t.globalContext.document, t.globalContext.navigator ? .connection, t.globalContext.innerWidth, t.globalContext.innerHeight);
                    if (void 0 === t.globalContext.apstag ? .clientFetchBids) return {
                        status: s.waiting,
                        analytics: {
                            browserInfo: o
                        }
                    };
                    Qt(t, Yt, "fetchBids/start");
                    const a = await async function(t) {
                        const e = {
                                slots: [{
                                    slotID: "93b7dd52-a8ce-11ed-afa1-0242ac120002:1",
                                    sizes: [
                                        [999, 999]
                                    ]
                                }],
                                timeout: 6e4,
                                _endpointDomain: t.use(re),
                                params: {
                                    program: "apscustom",
                                    is: t.use(ce)
                                }
                            },
                            n = {
                                pubID: t.id,
                                isSelfServePub: 36 === t.id.length,
                                deals: !0
                            },
                            o = t.use(ne);
                        return await new Promise((a => {
                            t.globalContext.apstag ? .clientFetchBids(e, (t => {
                                a(t)
                            }), {
                                initConfig: n,
                                contextURL: o
                            })
                        }))
                    }(t);
                    return Qt(t, Yt, "fetchBids/end"), {
                        status: s.completed,
                        value: {
                            bidResponses: a
                        },
                        analytics: {
                            browserInfo: o
                        }
                    }
                }
            }),
            le = new ut({
                scope: "customPlacement",
                object: "service",
                action: "enable",
                validators: {},
                handler: async ({
                    account: t,
                    detail: e,
                    customEvent: n
                }) => (Qt(t, Yt, "service/enable"), t.update(te, (() => !1)), await Promise.all([t.recordListener(ie).then((({
                    placementResponse: e
                }) => {
                    ue(t, !0, e), t.update(ee, (() => e))
                })), t.recordListener(de).then((({
                    bidResponses: e
                }) => {
                    e.forEach((e => {
                        const n = e.targeting ? .amzniid ? ? e.amzniid;
                        let o = !1;
                        if ("" !== n) {
                            const a = t.use(Ht);
                            a[n] = e, t.update(Ht, (() => a)), o = !0
                        }
                        ue(t, !1, {
                            aps: [{
                                active: o,
                                dispatchEventOnValidBid: !0
                            }]
                        })
                    }))
                })).then((() => {
                    t.recordListenerNonBlocking(Zt)
                }))]), {
                    status: s.completed,
                    analytics: {
                        browserInfo: Wt(t.globalContext.document, t.globalContext.navigator ? .connection, t.globalContext.innerWidth, t.globalContext.innerHeight)
                    }
                })
            });

        function ue(t, e, n) {
            if (t.use(te)) return;
            const o = n ? .aps ? .find((t => t.dispatchEventOnValidBid));
            e && void 0 !== o || (Qt(t, Yt, "placementResponseEvent/dispatch"), t.record("customPlacement/placement/didRespond", n).catch((t => {})), t.update(te, (() => !0)))
        }
        const pe = new Map([...pt([Xt, de, Zt, le, ie])]),
            me = {
                key: "ortbVendors/vm",
                default: {}
            },
            fe = "anonymised";
        var he = new ut({
                scope: "ortbVendors",
                object: "anonymised",
                action: "set",
                handler: async ({
                    account: t
                }) => {
                    const e = function(t) {
                        const e = t.readLocalStorage("cohort_ids");
                        if ("string" == typeof e) {
                            const t = JSON.parse(e);
                            let n = "";
                            for (let e = 0; e < t.length; e++) n += t[e], n += e < t.length - 1 ? "," : "";
                            return {
                                data: {
                                    default: {
                                        user: {
                                            keywords: n
                                        }
                                    }
                                }
                            }
                        }
                    }(t);
                    return void 0 === e ? {
                        status: s.cancelled
                    } : (t.update(me, (t => ({ ...t,
                        [fe]: e
                    }))), {
                        status: s.completed
                    })
                }
            }),
            ve = new ut({
                scope: "ortbVendors",
                object: "arcspan",
                action: "set",
                handler: async ({
                    account: t
                }) => {
                    const e = function(t) {
                        const e = t.globalContext[ye],
                            n = t.globalContext[ge];
                        let o = [],
                            a = [],
                            i = [];
                        if (void 0 !== e) {
                            if (void 0 !== e.page_iab_codes.text && (o = o.concat(e.page_iab_codes.text)), void 0 !== e.page_iab_codes.images && (o = o.concat(e.page_iab_codes.images)), void 0 !== e.page_keywords) {
                                const t = "string" == typeof e.page_keywords ? e.page_keywords.split(",") : e.page_keywords;
                                i = i.concat(t), void 0 !== n ? .compcohorts && (i = i.concat(n.compcohorts))
                            }
                            void 0 !== e.page_iab_newcodes.text && (a = [...new Set([...a, ...e.page_iab_newcodes.text])]), void 0 !== e.page_iab_newcodes.images && (a = [...new Set([...a, ...e.page_iab_newcodes.images])]);
                            const s = {
                                name: "arcspan",
                                segment: [],
                                ext: {
                                    segtax: 6
                                }
                            };
                            a.forEach((function(t) {
                                s.segment = s.segment.concat({
                                    id: t
                                })
                            }));
                            const r = {
                                data: []
                            };
                            return r.data = r.data.concat(s), {
                                data: {
                                    default: {
                                        site: {
                                            name: "arcspan",
                                            cat: o,
                                            sectioncat: o,
                                            pagecat: o,
                                            keywords: i.toString(),
                                            content: r,
                                            domain: new URL(t.globalContext.location.href).hostname,
                                            page: t.globalContext.location.href,
                                            ref: t.globalContext.document.referrer
                                        }
                                    }
                                }
                            }
                        }
                    }(t);
                    return void 0 === e ? {
                        status: s.cancelled
                    } : (t.update(me, (t => ({ ...t,
                        arcspan: e
                    }))), {
                        status: s.completed
                    })
                }
            });
        const ye = "arcobj1",
            ge = "arcobj2",
            we = {
                key: "idVendors/ids",
                default: void 0
            },
            be = {
                key: "idVendors/metadata",
                default: void 0
            };

        function Ee(t, e) {
            const n = t(e);
            return null != n ? (e.update(we, (t => ({ ...t,
                ...n
            }))), {
                status: s.completed
            }) : {
                status: s.cancelled
            }
        }
        class Se {
            constructor(t) {
                return this.parser = null, this.keys = null, this.account = null, this.read = t => null, this.anyAttributesMissing = () => [this.parser, this.keys, this.account, this.egressNodeKey, this.read].some((t => null == t)), this.egressNodeKey = t, this
            }
            using(t) {
                return this.parser = t, this
            }
            fromCookieKeys(t) {
                return this.keys = t, this.read = t => this.account ? .readCookieStorage(t), this
            }
            fromLocalStorageKeys(t) {
                return this.keys = t, this.read = t => this.account ? .readLocalStorage(t), this
            }
            fromCookieOrLocalStorageKeys(t) {
                return this.keys = t, this.read = t => this.account ? .readCookieStorage(t) ? ? this.account ? .readLocalStorage(t), this
            }
            fromLocalStorageOrCookieKeys(t) {
                return this.keys = t, this.read = t => this.account ? .readLocalStorage(t) ? ? this.account ? .readCookieStorage(t), this
            }
            forAccount(t) {
                return this.account = t, this
            }
            getRunner() {
                if (this.anyAttributesMissing()) throw new Error("Missing attribute(s) - unable to return a runner.");
                return () => {
                    if (this.anyAttributesMissing()) throw new Error("Missing attribute(s) - runner execution failed.");
                    for (const t of this.keys) {
                        const e = this.parser(this.read(t));
                        if (null != e) return {
                            [this.egressNodeKey]: e
                        }
                    }
                    return null
                }
            }
        }
        const xe = function(t) {
                return "string" == typeof t ? t : null
            },
            _e = function(t) {
                return "string" == typeof t ? atob(t) : null
            };

        function Re(t) {
            return function(e) {
                return "string" == typeof e ? t(JSON.parse(e)) : null
            }
        }

        function Ie(t) {
            return function(e) {
                if ("string" != typeof e) return null;
                let n = e,
                    o = null;
                for (let e = 0; ++e <= 5;) try {
                    n = decodeURIComponent(n), o = Re(t)(n);
                    break
                } catch (t) {
                    if (e >= 5) throw t
                }
                return o
            }
        }
        const Ae = "growthcode",
            ke = "temp",
            je = ["gceb"];
        var $e = new ut({
            scope: "ortbVendors",
            object: "growthcode",
            action: "set",
            handler: async ({
                account: t
            }) => {
                const e = new Se(ke).using(xe).fromLocalStorageKeys(je).forAccount(t).getRunner()();
                if (!e) return {
                    status: s.cancelled
                };
                const n = JSON.parse(e[ke]);
                if (!(n instanceof Array)) return {
                    status: s.cancelled
                };
                const o = n.filter((t => Ce(t)));
                if (0 === o.length) return {
                    status: s.cancelled
                };
                const a = {
                    data: {
                        default: {
                            user: {
                                ext: {
                                    eids: o
                                }
                            }
                        }
                    }
                };
                return t.update(me, (t => ({ ...t,
                    [Ae]: a
                }))), {
                    status: s.completed
                }
            }
        });
        const Ce = t => !!t && !!t.source && t.uids instanceof Array && 0 !== t.uids.length && t.uids.every((t => void 0 !== t ? .id)),
            Oe = "liveintent",
            Pe = {
                nonId: {
                    noExtraDefaults: !0,
                    source: "liveintent.com",
                    atype: 3
                },
                bidswitch: {
                    source: "bidswitch.net",
                    atype: 3
                },
                openx: {
                    source: "openx.net",
                    atype: 3
                },
                magnite: {
                    source: "rubiconproject.com",
                    atype: 3
                },
                medianet: {
                    source: "media.net",
                    atype: 3
                },
                pubmatic: {
                    source: "pubmatic.com",
                    atype: 3
                },
                index: {
                    source: "liveintent.indexexchange.com",
                    atype: 3
                },
                uid2: {
                    source: "uidapi.com",
                    atype: 3
                },
                sovrn: {
                    source: "liveintent.sovrn.com",
                    atype: 3
                },
                thetradedesk: {
                    source: "adserver.org",
                    atype: 1
                },
                vidazoo: {
                    source: "liveintent.vidazoo.com",
                    atype: 3
                },
                triplelift: {
                    source: "liveintent.triplelift.com",
                    atype: 3
                },
                sharethrough: {
                    source: "sharethrough.com",
                    atype: 3
                },
                sonobi: {
                    source: "liveintent.sonobi.com",
                    atype: 3
                },
                nexxen: {
                    source: "liveintent.unrulymedia.com",
                    atype: 3
                },
                zetassp: {
                    source: "zeta-ssp.liveintent.com",
                    atype: 3
                }
            };
        var De = new ut({
            scope: "ortbVendors",
            object: "liveintent",
            action: "set",
            handler: async ({
                account: t
            }) => {
                const e = function(t) {
                    const e = t.readLocalStorage("__tamLIResolveResult");
                    if (null != e && (void 0 === t.globalContext.liModuleEnabled && (t.globalContext.liModuleEnabled = Math.random() < .95, t.globalContext ? .googletag ? .cmd.push((() => {
                            t.globalContext.googletag.pubads().setTargeting("li-module-enabled", t.globalContext.liModuleEnabled ? ["on"] : ["off"])
                        }))), t.globalContext.liModuleEnabled)) {
                        let t;
                        try {
                            t = Te(JSON.parse(e))
                        } catch (n) {
                            t = Te(JSON.parse(decodeURIComponent(e)))
                        }
                        if (void 0 !== t) return {
                            data: {
                                default: t
                            }
                        }
                    }
                }(t);
                return void 0 === e ? {
                    status: s.cancelled
                } : (t.update(me, (t => ({ ...t,
                    [Oe]: e
                }))), {
                    status: s.completed
                })
            }
        });

        function Te(t) {
            const e = [],
                n = {
                    user: {
                        ext: {
                            eids: e
                        }
                    }
                };
            return Object.entries(Pe).forEach((n => {
                const o = n[0],
                    a = n[1];
                if (void 0 === t[o]) return;
                const i = {
                    source: a.source,
                    uids: [{
                        id: t[o],
                        atype: a.atype
                    }]
                };
                !0 !== a.noExtraDefaults && (i.uids[0].ext = {
                    provider: "liveintent.com"
                }), e.push(i)
            })), n
        }
        const Ne = "optable",
            Le = "temp";
        var Me = new ut({
            scope: "ortbVendors",
            object: "optable",
            action: "set",
            handler: async ({
                account: t
            }) => {
                const e = new Se(Le).using(xe).fromLocalStorageKeys(["OPTABLE_RESOLVED"]).forAccount(t).getRunner()();
                if (!e) return {
                    status: s.cancelled
                };
                const n = function(t) {
                        return t && t.ortb2 ? t.ortb2 : t
                    }(JSON.parse(e[Le])),
                    o = {
                        data: {
                            default: n
                        }
                    };
                return t.update(me, (t => ({ ...t,
                    [Ne]: o
                }))), {
                    status: s.completed
                }
            }
        });
        const Ue = "permutive",
            qe = "permutive_temp",
            Ve = ["_pamzn_ids"];
        var Fe = new ut({
            scope: "ortbVendors",
            object: "permutive",
            action: "set",
            handler: async ({
                account: t
            }) => {
                const e = new Se(qe).using(xe).fromLocalStorageKeys(Ve).forAccount(t).getRunner()();
                if (!e) return {
                    status: s.cancelled
                };
                const n = JSON.parse(e[qe]);
                if (!Array.isArray(n)) return {
                    status: s.cancelled
                };
                const o = n.filter((t => Be(t)));
                if (0 === o.length) return {
                    status: s.cancelled
                };
                const a = {
                    data: {
                        default: {
                            user: {
                                ext: {
                                    eids: o
                                }
                            }
                        }
                    }
                };
                return t.update(me, (t => ({ ...t,
                    [Ue]: a
                }))), {
                    status: s.completed
                }
            }
        });
        const Be = t => !!t && !!t.source && !!Array.isArray(t.uids) && 0 !== t.uids.length && t.uids.every((t => void 0 !== t ? .id)),
            ze = "utiq",
            Je = "utiqtemp";
        var He = new ut({
            scope: "ortbVendors",
            object: "utiq",
            action: "set",
            handler: async ({
                account: t
            }) => {
                const e = new Se(Je).using(xe).fromLocalStorageKeys(["utiq_openrtb_eids"]).forAccount(t).getRunner()();
                if (!e) return {
                    status: s.cancelled
                };
                const n = JSON.parse(e[Je]);
                if (!Array.isArray(n)) return {
                    status: s.cancelled
                };
                const o = n.filter((t => Ge(t)));
                if (0 === o.length) return {
                    status: s.cancelled
                };
                const a = {
                    data: {
                        default: {
                            user: {
                                ext: {
                                    eids: o
                                }
                            }
                        }
                    }
                };
                return t.update(me, (t => ({ ...t,
                    [ze]: a
                }))), {
                    status: s.completed
                }
            }
        });
        const Ge = t => !!t && !!t.source && !!Array.isArray(t.uids) && 0 !== t.uids.length && t.uids.every((t => void 0 !== t ? .id));
        var Ke = new ut({
            scope: "ortbVendors",
            object: "all",
            action: "process",
            handler: async ({
                account: t
            }) => (await Promise.all([t.recordListener(he), t.recordListener(ve), t.recordListener($e), t.recordListener(De), t.recordListener(Me), t.recordListener(Fe), t.recordListener(He)]), {
                status: s.completed
            })
        });
        const We = pt([he, ve, $e, De, Me, Fe, He, Ke]),
            Qe = "33across",
            Ye = "33acrossId";
        var Ze = new ut({
            scope: "idVendors",
            object: "33across",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => {
                const n = Ee(Xe, t),
                    o = t.readLocalStorage(Ye);
                if (o && o.length > 1500) {
                    const t = {
                        idLength: 100 * Math.ceil(o.length / 100)
                    };
                    return { ...n,
                        analytics: t
                    }
                }
                return n
            }
        });
        const Xe = t => {
                const e = t.readLocalStorage(Ye);
                return null != e ? {
                    [Qe]: decodeURIComponent(e)
                } : null
            },
            tn = ["amxId"];
        var en = new ut({
            scope: "idVendors",
            object: "amx",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(new Se("amx").using(xe).fromLocalStorageKeys(tn).forAccount(t).getRunner(), t)
        });
        const nn = "audigent";
        var on = new ut({
            scope: "idVendors",
            object: "audigent",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(an, t)
        });
        const an = t => {
                const e = t.readLocalStorage("hadronId") ? ? t.readLocalStorage("auHadronId");
                return null != e ? {
                    [nn]: e
                } : null
            },
            sn = ["cto_bidid"];
        var rn = new ut({
            scope: "idVendors",
            object: "criteo",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(new Se("criteo").using(xe).fromLocalStorageKeys(sn).forAccount(t).getRunner(), t)
        });
        const cn = "firstid",
            dn = ["firstid"];
        var ln = new ut({
            scope: "idVendors",
            object: "firstid",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(new Se(cn).using(xe).fromCookieKeys(dn).forAccount(t).getRunner(), t)
        });
        const un = {
                key: "idVendors/enabled",
                default: void 0
            },
            pn = {
                "context.apstag": tt,
                "context.apstag.bids": rt,
                "context.apstag.bids()": lt,
                "context.apstag._atsaaiod": nt([lt, rt]),
                "context.apstag.setDisplayBids": rt,
                "context.apstag.setDisplayBids()": null,
                "context._apstag": st(tt),
                "context._apstag.bids": st(rt),
                "context._apstag.bids()": st(lt),
                "context._apstag._atsaaiod": st(nt([lt, rt])),
                "context._apstag.setDisplayBids": st(rt),
                "context._apstag.setDisplayBids()": null
            };
        var mn = new ut({
            scope: "idVendors",
            object: "enabled",
            action: "set",
            handler: async ({
                account: t,
                detail: e,
                context: n
            }) => fn(n) ? (t.update(un, (() => JSON.stringify(e.bidParameterKeys)), {
                persist: !0
            }), {
                status: s.completed
            }) : {
                status: s.waiting
            },
            validators: {
                detail: {
                    detail: tt,
                    "detail.bidParameterKeys": ot,
                    "detail.bidParameterKeys[]": Z
                },
                context: {
                    context: tt,
                    ...pn,
                    "context.apstag": nt([lt, tt]),
                    "context._apstag": st(nt([lt, tt]))
                }
            }
        });
        const fn = t => void 0 !== t.apstag ? ._atsaaiod,
            hn = {
                key: "idVendors/newConfigFlowEnabled",
                default: !1
            };
        var vn = new ut({
            scope: "idVendors",
            object: "newConfigFlowEnabled",
            action: "set",
            validators: {
                detail: {
                    detail: tt,
                    "detail.value": X
                },
                context: {
                    context: tt
                }
            },
            handler: async ({
                account: t,
                detail: e
            }) => (t.update(hn, (() => e.value)), {
                status: s.completed,
                analytics: {
                    enabled: e.value
                }
            })
        });
        const yn = ["1ad7261b-91ea-4b6f-b9e9-b83522205b75", "3161", "0ab198dd-b265-462a-ae36-74e163ad6159"];
        var gn = new ut({
            scope: "idVendors",
            object: "newConfigFlow",
            action: "initialize",
            validators: {
                detail: {
                    detail: tt
                },
                context: {
                    context: tt
                }
            },
            handler: async ({
                account: t
            }) => (t.recordListenerNonBlocking(vn, {
                value: !1
            }), t.recordListenerNonBlocking(vn, {
                value: !0,
                restrictions: {
                    block: {
                        accounts: yn
                    }
                }
            }), {
                status: s.completed
            })
        });
        const wn = "fabrick";
        var bn = new ut({
            scope: "idVendors",
            object: "fabrick",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(En, t)
        });
        const En = t => {
                let e = null;
                const n = t.readCookieStorage("pbjs_fabrickId");
                if (null != n) {
                    const t = decodeURIComponent(n);
                    e = JSON.parse(t).fabrickId
                }
                return null != e ? {
                    [wn]: e
                } : null
            },
            Sn = ["FTrackId"],
            xn = t => t ? .DeviceID ? .pop ? t ? .DeviceID ? .pop() ? ? null : null;
        var _n = new ut({
            scope: "idVendors",
            object: "fTrack",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(new Se("fTrack").using(Ie(xn)).fromLocalStorageKeys(Sn).forAccount(t).getRunner(), t)
        });
        const Rn = "id5",
            In = "id5id";
        var An = new ut({
            scope: "idVendors",
            object: "id5",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(kn, t)
        });
        const kn = t => {
                const e = t.readLocalStorage(In);
                return null != e ? {
                    [Rn]: JSON.parse(decodeURIComponent(e)).universal_uid
                } : null
            },
            jn = ["IDP"];
        var $n = new ut({
            scope: "idVendors",
            object: "idPlus",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(new Se("idPlus").using(_e).fromCookieOrLocalStorageKeys(jn).forAccount(t).getRunner(), t)
        });
        const Cn = ["__im_uid", "__im_ppid"];
        var On = new ut({
            scope: "idVendors",
            object: "intimateMerger",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(new Se("intimateMerger").using(xe).fromLocalStorageKeys(Cn).forAccount(t).getRunner(), t)
        });
        const Pn = "liveRamp",
            Dn = "_lr_env",
            Tn = "idl_env",
            Nn = "apstagLiveRampTimestamp";
        var Ln;
        ! function(t) {
            t[t.oldTimestamp = 0] = "oldTimestamp", t[t.newTimestamp = 1] = "newTimestamp", t[t.noTimestamp = 2] = "noTimestamp"
        }(Ln || (Ln = {}));
        var Mn = new ut({
            scope: "idVendors",
            object: "liveramp",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => {
                const n = qn(Un(t), t),
                    o = Ee((() => null != n ? {
                        [Pn]: n.id
                    } : null), t);
                return o.status === s.completed ? function(t, e) {
                    const o = null != n ? {
                        [Pn]: n.newGen
                    } : null;
                    return null != o ? (e.update(be, (t => ({ ...t,
                        ...o
                    }))), {
                        status: s.completed
                    }) : {
                        status: s.cancelled
                    }
                }(0, t) : o
            }
        });
        const Un = t => {
                const e = t.readLocalStorage(Dn);
                if (null != e) return e;
                const n = t.readCookieStorage(Dn);
                if (null != n) return n;
                const o = t.readLocalStorage(Tn);
                if (null != o) return o;
                const a = t.readCookieStorage(Tn);
                return null != a ? a : null
            },
            qn = (t, e) => {
                if (null != t && "" !== t) try {
                    const n = JSON.parse(atob(decodeURIComponent(t))),
                        o = Array.isArray(n.envelope) ? n.envelope[0] : n.envelope;
                    if ("string" != typeof o) return null;
                    const a = {
                        id: o,
                        newGen: Ln.noTimestamp
                    };
                    if (null != n.timestamp) {
                        const t = e.readLocalStorage(Nn);
                        null == t || t < n.timestamp ? (a.newGen = Ln.newTimestamp, e.writeLocalStorage(Nn, n.timestamp.toString())) : a.newGen = Ln.oldTimestamp
                    }
                    return a
                } catch (e) {
                    return {
                        id: decodeURIComponent(t),
                        newGen: Ln.noTimestamp
                    }
                }
                return null
            },
            Vn = {},
            Fn = new Set([In, Tn, Dn]),
            Bn = {};
        var zn = new ut({
            scope: "idVendors",
            object: "lockr",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(Jn, t)
        });
        const Jn = t => {
                const e = t.readLocalStorage("lockr_identity_providers");
                if (e) {
                    const n = {};
                    return e.split(",").filter((t => !Fn.has(t))).forEach((e => {
                        const o = Hn(t, e);
                        null !== o && (n[Vn[e] || e] = decodeURIComponent(o))
                    })), n
                }
                return null
            },
            Hn = (t, e) => {
                let n = t.readLocalStorage(e);
                if (!n) return null;
                if (Bn[e]) try {
                    n = JSON.parse(decodeURIComponent(n)), Bn[e].split(".").forEach((t => {
                        n = n ? .[t]
                    }))
                } catch (t) {
                    throw new Error(`Malformed json at ${e}: ${t}`)
                }
                return n || null
            },
            Gn = "lotame";
        var Kn = new ut({
            scope: "idVendors",
            object: "lotame",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(Wn, t)
        });
        const Wn = t => {
                const e = t.readLocalStorage("panoramaId");
                return null != e ? {
                    [Gn]: e
                } : null
            },
            Qn = ["pbjs-merkleId"],
            Yn = t => t ? .merkleId ? .pop ? t ? .merkleId ? .pop() ? .id ? ? null : null;
        var Zn = new ut({
            scope: "idVendors",
            object: "merkle",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(new Se("merkle").using(Ie(Yn)).fromLocalStorageKeys(Qn).forAccount(t).getRunner(), t)
        });
        const Xn = "pair",
            to = ["pairId"],
            eo = ["_lr_pairId"],
            no = t => t ? .envelope ? .pop ? t ? .envelope ? .pop() ? ? null : null;
        var oo = new ut({
            scope: "idVendors",
            object: "pair",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee((t => new Se(Xn).using(_e).fromCookieOrLocalStorageKeys(to).forAccount(t).getRunner()() ? ? new Se(Xn).using(function(t) {
                return function(e) {
                    return "string" == typeof e ? Re(t)(atob(decodeURIComponent(e))) : null
                }
            }(no)).fromCookieOrLocalStorageKeys(eo).forAccount(t).getRunner()()), t)
        });
        const ao = "pubcommon",
            io = ["_pubcid", "_sharedID"];
        var so = new ut({
            scope: "idVendors",
            object: "pubcommon",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(new Se(ao).using(xe).fromLocalStorageOrCookieKeys(io).forAccount(t).getRunner(), t)
        });
        const ro = "publink",
            co = ["_publink_srv", "_publink", "pbjs_publink"];
        var lo = new ut({
            scope: "idVendors",
            object: "publink",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(uo, t)
        });
        const uo = t => {
                for (const e of co) {
                    const n = t.readCookieStorage(e);
                    if (null != n) {
                        let t;
                        try {
                            t = JSON.parse(n).publink
                        } catch {
                            t = n
                        }
                        if (null != t) return {
                            [ro]: t
                        }
                    }
                }
                return null
            },
            po = ["__qca"];
        var mo = new ut({
            scope: "idVendors",
            object: "quantcast",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(new Se("quantcast").using(xe).fromCookieKeys(po).forAccount(t).getRunner(), t)
        });
        const fo = ["__uid2_advertising_token"],
            ho = t => t ? .latestToken ? .advertising_token ? ? null;
        var vo = new ut({
            scope: "idVendors",
            object: "uid",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(new Se("uid").using(Re(ho)).fromLocalStorageKeys(fo).forAccount(t).getRunner(), t)
        });
        const yo = ["pbjs_unifiedID", "pbjs-unifiedid"],
            go = t => t ? .TDID ? ? null;
        var wo = new ut({
            scope: "idVendors",
            object: "unifiedid",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => Ee(new Se("unifiedid").using(Ie(go)).fromLocalStorageOrCookieKeys(yo).forAccount(t).getRunner(), t)
        });
        const bo = "yahoo",
            Eo = ["connectId"],
            So = t => t ? .connectid ? ? t ? .connectId ? ? null;
        var xo = new ut({
            scope: "idVendors",
            object: "yahoo",
            action: "get",
            handler: async ({
                account: t
            }) => Ee(new Se(bo).using(Ie(So)).fromLocalStorageKeys(Eo).forAccount(t).getRunner(), t)
        });
        const _o = "liveRamp/envelope",
            Ro = {
                key: "liveRamp/envelope",
                default: void 0
            },
            Io = {
                key: "liveRamp/envelopeHost",
                default: "https://api.rlcdn.com"
            };
        var Ao = new ut({
                scope: "liveRamp",
                object: "envelope",
                action: "fetch",
                handler: async ({
                    account: t
                }) => {
                    if (void 0 === t.globalContext.apstag ? ._atsaaiod) return {
                        status: s.waiting
                    };
                    const e = t.use(Io),
                        n = new URL(`${e}/api/identity/envelope`);
                    n.searchParams.append("pid", "13310");
                    const o = t.use(It),
                        a = t.read(bt);
                    !0 === o ? .gdprApplies && o.tcString && (n.searchParams.append("gdpr", "1"), n.searchParams.append("gdpr_consent", o.tcString)), a ? .gppString && a.applicableSections ? .length > 0 && (n.searchParams.append("gpp", a.gppString), n.searchParams.append("gpp_sid", a.applicableSections.join(",")));
                    const i = await t.globalContext.fetch(n.toString(), {
                            method: "GET",
                            credentials: "include"
                        }),
                        r = {
                            statusCode: i.status,
                            responseOk: i.ok
                        };
                    if (200 !== i.status) return {
                        status: s.cancelled,
                        analytics: { ...r,
                            ...204 === i.status && {
                                reason: "No Content"
                            }
                        }
                    };
                    const c = await i.json();
                    if (!c.envelope) return {
                        status: s.cancelled,
                        analytics: { ...r,
                            reason: "missing_envelope"
                        }
                    };
                    const d = JSON.stringify({
                        value: c.envelope,
                        createdAt: Date.now()
                    });
                    return t.update(Ro, (() => c.envelope)), t.writeLocalStorage(_o, d, {
                        usePrefix: !0
                    }), {
                        status: s.completed,
                        analytics: r
                    }
                }
            }),
            ko = new ut({
                scope: "liveRamp",
                object: "envelope",
                action: "sync",
                handler: async ({
                    account: t
                }) => {
                    if (void 0 === t.globalContext.apstag ? ._atsaaiod) return {
                        status: s.waiting
                    };
                    const e = t.readLocalStorage(_o, {
                        usePrefix: !0
                    });
                    if (e) {
                        const {
                            createdAt: n,
                            value: o
                        } = JSON.parse(e);
                        if (o && jo(n, Date.now()) < 15) return t.update(Ro, (() => o)), {
                            status: s.completed
                        }
                    }
                    return await t.recordListener(Ao), {
                        status: s.completed
                    }
                }
            });
        const jo = (t, e) => {
            const n = new Date(t),
                o = new Date(e);
            return (n.getTime() - o.getTime()) / 864e5
        };
        var $o = new ut({
            scope: "idVendors",
            object: "rtisLiveRamp",
            action: "get",
            handler: async ({
                account: t
            }) => (t.recordListenerNonBlocking(ko), {
                status: s.completed
            })
        });
        const Co = {
                "33across": Ze,
                amx: en,
                audigent: on,
                criteo: rn,
                ddb_key_638: zn,
                firstid: ln,
                fabrick: bn,
                fTrack: _n,
                id5: An,
                idPlus: $n,
                intimateMerger: On,
                liveRamp: Mn,
                lotame: Kn,
                merkle: Zn,
                pair: oo,
                pubcommon: so,
                publink: lo,
                quantcast: mo,
                uid: vo,
                unifiedid: wo,
                yahoo: xo,
                rtisLiveRamp: $o
            },
            Oo = Object.keys(Co);
        var Po = new ut({
            scope: "idVendors",
            object: "ids",
            action: "get",
            handler: async ({
                account: t
            }) => {
                let e = Object.values(Co);
                const n = t.use(un, {
                    persist: !0,
                    throwOnDisallowed: !1
                });
                if (n) {
                    const t = JSON.parse(n);
                    if (o = t, !Array.isArray(o) || !o.every((t => "string" == typeof t))) throw new Error("Received invalid 3P bid param key");
                    const a = new Set(t);
                    e = Oo.filter((t => a.has(t))).map((t => Co[t]))
                } else if (!t.use(d)) return {
                    status: s.cancelled,
                    analytics: {
                        reason: "consent_pending",
                        enabledIdVendors: `${n}`
                    }
                };
                var o;
                const a = n ? e : e.filter((t => t !== $o));
                return await Promise.all(a.map((e => t.recordListener(e)))), {
                    status: s.completed,
                    analytics: {
                        enabledIdVendors: `${n}`
                    }
                }
            }
        });
        const Do = {
            key: "idVendors/recordVendorsLoadedEndpoint",
            default: "https://prod.us-east-1.cxm-bcn.publisher-services.amazon.dev/v1/recordVendorsLoaded"
        };
        var To = new ut({
                scope: "idVendors",
                object: "vendorsLoaded",
                action: "record",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.accountId": Z,
                        "detail.sourceId": Z,
                        "detail.vendorId": st(Z),
                        "detail.propertyId": st(Z),
                        "detail.failure": st(Z),
                        "detail.errorName": st(Z),
                        "detail.errorMessage": st(Z)
                    },
                    context: {
                        context: tt,
                        "context.fetch": rt,
                        "context.fetch()": null
                    }
                },
                handler: async ({
                    detail: t,
                    account: e,
                    context: n
                }) => {
                    const o = [{
                            publisherId: t.accountId,
                            sourceId: t.sourceId,
                            clientName: "aps-listener",
                            vendorId: t.vendorId,
                            propertyId: t.propertyId,
                            ...t.failure && {
                                failure: t.failure,
                                errorName: t.errorName,
                                errorMessage: t.errorMessage
                            }
                        }],
                        a = e.use(Do),
                        i = await n.fetch(a, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify(o),
                            keepalive: !0
                        });
                    if (!i.ok) throw new Error(`HTTP ${i.status}`);
                    return {
                        status: s.completed,
                        analytics: {
                            vendorId: t.vendorId
                        }
                    }
                }
            }),
            No = new ut({
                scope: "idVendors",
                object: "integration",
                action: "execute",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.accountId": Z,
                        "detail.sourceId": Z,
                        "detail.vendorId": Z,
                        "detail.countryCode": Z,
                        "detail.vendorLoadedSampleRate": st(Y),
                        "detail.allowedRegions": st(ot),
                        "detail.allowedRegions[]": Z,
                        "detail.blockedRegions": st(ot),
                        "detail.blockedRegions[]": Z,
                        "detail.domainPrecedence": ot,
                        "detail.domainPrecedence[]": tt,
                        "detail.domainPrecedence[].hostnames": ot,
                        "detail.domainPrecedence[].hostnames[]": Z,
                        "detail.domainPrecedence[].script": st(rt),
                        "detail.domainPrecedence[].script()": ct,
                        "detail.domainPrecedence[].propertyId": st(Z),
                        "detail.defaultScript": st(rt),
                        "detail.defaultScript()": ct,
                        "detail.defaultPropertyId": st(Z)
                    },
                    context: {
                        context: dt
                    }
                },
                handler: async ({
                    detail: t,
                    account: e,
                    context: n
                }) => {
                    const o = e.use(hn),
                        a = (t => t ? t.toLowerCase().trim().replace(/^www\./, "") : "")(n.location.hostname);
                    if (!o) return k() && _.info(`[idVendors/integration/execute] cancelled: vendorId=${t.vendorId} hostname=${a} reason=sdk-flow-disabled`), {
                        status: s.cancelled,
                        analytics: {
                            vendorId: t.vendorId,
                            hostname: a,
                            cancellationReason: "sdk-flow-disabled"
                        }
                    };
                    let i, r, c, d;
                    for (const e of t.domainPrecedence) {
                        if (e.hostnames.includes(a)) {
                            if (d = a, void 0 === e.script) return k() && _.info(`[idVendors/integration/execute] cancelled: vendorId=${t.vendorId} hostname=${a} reason=script-undefined-exact-match matchedRoute=${a}`), {
                                status: s.cancelled,
                                analytics: {
                                    vendorId: t.vendorId,
                                    matchType: "blocked",
                                    matchedRoute: a,
                                    hostname: a,
                                    cancellationReason: "script-undefined-exact-match"
                                }
                            };
                            i = e.script, r = e.propertyId, c = "exact";
                            break
                        }
                        const n = e.hostnames.find((t => a.endsWith("." + t)));
                        if (n) {
                            if (d = n, void 0 === e.script) return k() && _.info(`[idVendors/integration/execute] cancelled: vendorId=${t.vendorId} hostname=${a} reason=script-undefined-configDomain-match matchedRoute=${n}`), {
                                status: s.cancelled,
                                analytics: {
                                    vendorId: t.vendorId,
                                    matchType: "blocked",
                                    matchedRoute: n,
                                    hostname: a,
                                    cancellationReason: "script-undefined-configDomain-match"
                                }
                            };
                            i = e.script, r = e.propertyId, c = "configDomain";
                            break
                        }
                    }
                    if (!i) {
                        if (!t.defaultScript) return k() && _.info(`[idVendors/integration/execute] cancelled: vendorId=${t.vendorId} hostname=${a} reason=no-route-no-default`), {
                            status: s.cancelled,
                            analytics: {
                                vendorId: t.vendorId,
                                matchType: "none",
                                hostname: a,
                                cancellationReason: "no-route-no-default"
                            }
                        };
                        i = t.defaultScript, r = t.defaultPropertyId, c = "default", d = "default"
                    }
                    const l = t.countryCode;
                    if (t.allowedRegions ? .length && !t.allowedRegions.includes(l)) return {
                        status: s.cancelled,
                        analytics: {
                            vendorId: t.vendorId,
                            reason: "region_blocked"
                        }
                    };
                    if (t.blockedRegions ? .length && t.blockedRegions.includes(l)) return {
                        status: s.cancelled,
                        analytics: {
                            vendorId: t.vendorId,
                            reason: "region_blocked"
                        }
                    };
                    let u, p, m;
                    try {
                        i()
                    } catch (t) {
                        u = "vendor-script-execution-error", p = t instanceof Error ? t.name : "Error", m = t instanceof Error ? t.message : String(t)
                    }
                    if (e.recordListenerNonBlocking(To, {
                            accountId: t.accountId,
                            sourceId: t.sourceId,
                            vendorId: t.vendorId,
                            propertyId: r,
                            ...u && {
                                failure: u,
                                errorName: p,
                                errorMessage: m
                            },
                            restrictions: {
                                allow: {
                                    rate: (t.vendorLoadedSampleRate ? ? 5) / 100
                                }
                            }
                        }), u) throw k() && _.error(`[idVendors/integration/execute] vendorId=${t.vendorId} hostname=${a} matchType=${c} matchedRoute=${d} propertyId=${r} failure=${u} errorName=${p} errorMessage=${m}`), new Error(m);
                    return k() && _.info(`[idVendors/integration/execute] vendorId=${t.vendorId} hostname=${a} matchType=${c} matchedRoute=${d} propertyId=${r}`), {
                        status: s.completed,
                        analytics: {
                            vendorId: t.vendorId,
                            propertyId: r,
                            matchType: c,
                            matchedRoute: d,
                            hostname: a
                        }
                    }
                }
            });
        const Lo = pt([Ze, en, on, rn, ln, mn, vn, gn, bn, _n, An, $n, Po, No, On, Mn, zn, Kn, Zn, oo, so, lo, mo, vo, wo, To, xo, $o]);
        var Mo = new ut({
            scope: "analytics",
            object: "sampleRateFactors",
            action: "set",
            validators: {
                detail: {
                    detail: ct,
                    "detail.sampleRateFactors": dt
                }
            },
            handler: async ({
                account: t,
                detail: {
                    sampleRateFactors: e
                }
            }) => (t.update(C, (() => e)), {
                status: s.completed
            })
        });
        const Uo = pt([new ut({
            scope: "analytics",
            object: "sampling",
            action: "set",
            validators: {
                detail: {
                    detail: ct,
                    "detail.rates": ct,
                    "detail.rates.error": ct,
                    "detail.rates.status": ct
                }
            },
            handler: async ({
                detail: t
            }) => void 0 === t ? .rates ? {
                status: s.cancelled
            } : (void 0 !== t ? .rates ? .error && vt.setEventSamplingRates({
                error: t ? .rates ? .error
            }), void 0 !== t ? .rates ? .status && vt.setEventSamplingRates({
                feature: t ? .rates ? .status
            }), {
                status: s.completed
            })
        }), new ut({
            scope: "log",
            object: "analytics",
            action: "setInterval",
            validators: {
                detail: {
                    detail: tt,
                    "detail.interval": Y
                }
            },
            handler: async ({
                detail: t
            }) => (vt.setEventProcessingInterval(t.interval), {
                status: s.completed
            })
        }), Mo]);
        var qo = new ut({
            scope: "debug",
            object: "version",
            action: "show",
            handler: async ({
                account: t,
                customEvent: e
            }) => ({
                status: s.completed,
                value: {
                    LIBRARY_VERSION: R
                }
            })
        });
        const Vo = "debug/events/show",
            Fo = "debug/prepend/add",
            Bo = "debug/prepend/remove",
            zo = "debug/store/show",
            Jo = "ad/debugSession/start",
            Ho = new Map([
                [Vo, async ({
                    account: t
                }) => {
                    const e = [...(null != t.store.get(g) ? t.store.get(g) : []).map((t => ({
                        type: t.type,
                        status: "created",
                        detail: t.detail,
                        timestamp: t.timeStamp
                    }))), ...t.queue.map((t => ({
                        type: t.type,
                        status: "created",
                        detail: t.detail,
                        timestamp: t.timeStamp
                    }))), ...(null != t.store.get(g) ? t.store.get(g) : []).map((t => null != t.statusEvents ? t.statusEvents.map((e => ({
                        type: t.type,
                        status: e.type,
                        detail: t.detail,
                        timestamp: e.timeStamp
                    }))) : [])).flat(), ...t.queue.map((t => null != t.statusEvents ? t.statusEvents.map((e => ({
                        type: t.type,
                        status: e.type,
                        detail: t.detail,
                        timestamp: e.timeStamp
                    }))) : [])).flat()].filter((t => !t.type.startsWith("debug/")));
                    return e.sort(((t, e) => t.timestamp - e.timestamp)), console.groupCollapsed(`⌂ Account ID: ${t.id}`), console.table(e), console.groupEnd(), s.completed
                }],
                [Fo, async ({
                    account: t,
                    customEvent: n
                }) => {
                    if (void 0 === n.detail ? .eventName) throw new Error("Missing event information");
                    const o = t.read(e, {
                            persist: !0
                        }) ? ? "[]",
                        a = JSON.parse(o),
                        {
                            eventName: i,
                            eventDetail: r
                        } = n.detail;
                    return a.unshift({
                        eventName: i,
                        eventDetail: r
                    }), t.write(e, JSON.stringify(a), {
                        persist: !0
                    }), s.completed
                }],
                ["debug/prepend/clear", async ({
                    account: t
                }) => (t.delete(e, {
                    persist: !0
                }), s.completed)],
                [Bo, async ({
                    account: t,
                    customEvent: n
                }) => {
                    if (void 0 === n.detail ? .eventName) throw new Error("Missing event information");
                    const o = t.read(e, {
                            persist: !0
                        }) ? ? "[]",
                        a = JSON.parse(o),
                        {
                            eventName: i
                        } = n.detail,
                        r = a.filter((t => t.eventName !== i));
                    return t.write(e, JSON.stringify(r), {
                        persist: !0
                    }), s.completed
                }],
                [zo, async ({
                    account: t
                }) => {
                    const e = [...t.store.entries()];
                    return console.groupCollapsed(`⌂ Account ID: ${t.id}`), console.table(e), console.groupEnd(), s.completed
                }],
                [Jo, async ({
                    account: e,
                    customEvent: n
                }) => function(t) {
                    return t.status !== s.waiting
                }(n) && (function(e, n) {
                    void 0 !== e.detail ? .minutes && function(e, n) {
                            const o = new Date;
                            e.write(t, o.setMinutes(Number(o.getMinutes()) + Number(n.detail ? .minutes)).toString(), {
                                persist: !0
                            })
                        }(n, e),
                        function(t) {
                            t.globalContext.apstagDEBUG = t.globalContext.apstagDEBUG ? ? {}, t.globalContext.apstagDEBUG.url = function(t) {
                                const e = new URL(t ? .top ? .location ? .href ? ? t ? .document ? .referrer);
                                return e.searchParams.set("amzn_debug_mode", "1"), e.toString()
                            }(t.globalContext)
                        }(n)
                }(n, e), function(t) {
                    return t.queue.filter((t => t.type === Jo)).length > 1
                }(e)) ? s.completed : function(e) {
                    const n = e.read(t, {
                        persist: !0
                    });
                    return void 0 !== n && new Date >= new Date(Number(n))
                }(e) ? (function(e) {
                    e.delete(t, {
                            persist: !0
                        }),
                        function(t) {
                            delete t.globalContext.apstagDEBUG ? .url
                        }(e)
                }(e), s.completed) : (function(t) {
                    t.record(Vo).catch((t => {})), t.record(zo).catch((t => {}))
                }(e), s.waiting)],
                ["debug/listeners/show", async ({
                    systemAccount: t
                }) => {
                    const e = [...t.store.get(y).entries()];
                    return console.groupCollapsed("⌂ Listeners"), console.table(e), console.groupEnd(), s.completed
                }]
            ]),
            Go = new Map([...Ho, ...pt([qo])]);
        var Ko;
        ! function(t) {
            t[t.unspecifiedUnknown = 0] = "unspecifiedUnknown", t[t.lowEntropy = 1] = "lowEntropy", t[t.highEntropy = 2] = "highEntropy"
        }(Ko || (Ko = {}));
        const Wo = ["brands", "mobile", "platform"],
            Qo = ["architecture", "bitness", "fullVersionList", "model", "platformVersion"];
        var Yo = new ut({
            scope: "deviceSignal",
            object: "sua",
            action: "set",
            validators: {
                context: {
                    context: tt,
                    ...pn,
                    "context.navigator": tt,
                    "context.navigator.userAgentData": tt,
                    "context.navigator.userAgentData.getHighEntropyValues": rt,
                    "context.navigator.userAgentData.architecture": st(Z),
                    "context.navigator.userAgentData.bitness": st(Z),
                    "context.navigator.userAgentData.mobile": st(X),
                    "context.navigator.userAgentData.model": st(Z),
                    "context.navigator.userAgentData.platform": st(Z),
                    "context.navigator.userAgentData.platformVersion": st(Z),
                    "context.navigator.userAgentData.fullVersionList": st(ot),
                    "context.navigator.userAgentData.fullVersionList[]": tt,
                    "context.navigator.userAgentData.fullVersionList[].brand": Z,
                    "context.navigator.userAgentData.fullVersionList[].version": Z,
                    "context.navigator.userAgentData.brands": st(ot),
                    "context.navigator.userAgentData.brands[]": tt,
                    "context.navigator.userAgentData.brands[].brand": Z,
                    "context.navigator.userAgentData.brands[].version": Z
                }
            },
            handler: async ({
                account: t
            }) => {
                if (void 0 === t.globalContext.apstag ? .isGDPRRegion) return {
                    status: s.waiting
                };
                const e = "deviceSignal/sua",
                    n = t.globalContext.navigator ? .userAgentData,
                    o = t.read(e, {
                        persist: !0,
                        throwOnDisallowed: !1
                    });
                return "string" == typeof o ? t.write(e, o) : n instanceof Object && function(t, e, n) {
                    t.write(e, JSON.stringify(Zo(n)))
                }(t, e, n), !1 !== t.globalContext.apstag ? .isGDPRRegion || "function" == typeof n ? .getHighEntropyValues && await async function(t, e, n) {
                    const o = await n.getHighEntropyValues([...Wo, ...Qo]);
                    return t.write(e, JSON.stringify(Zo(o)), {
                        persist: !0,
                        throwOnDisallowed: !1
                    }), s.completed
                }(t, e, n), {
                    status: s.completed
                }
            }
        });

        function Zo(t) {
            const e = {};
            let n;
            return e.architecture = t.architecture, e.bitness = t.bitness, e.mobile = t.mobile ? 1 : 0, e.model = t.model, e.source = (o = t, Qo.some((t => o[t])) ? Ko.highEntropy : Wo.some((t => o[t])) ? Ko.lowEntropy : Ko.unspecifiedUnknown), "string" == typeof t.platform && (e.platform = {
                brand: t.platform,
                version: t.platformVersion ? .split(".")
            }), Array.isArray(t.fullVersionList) ? n = t.fullVersionList : Array.isArray(t.brands) && (n = t.brands), n instanceof Array && (e.browsers = n.map((t => ({
                brand: t.brand,
                version: t.version ? .split(".")
            })))), e;
            var o
        }
        const Xo = pt([Yo]),
            ta = {
                key: "deviceSignal/cookieDeprecationLabel",
                default: void 0
            };
        var ea = new ut({
            scope: "deviceSignal",
            object: "cookieDeprecationLabel",
            action: "set",
            handler: async ({
                account: t,
                customEvent: e
            }) => {
                const {
                    cookieDeprecationLabel: n
                } = t.globalContext.navigator;
                if (void 0 === n ? .getValue || "function" != typeof n.getValue) return {
                    status: s.cancelled
                };
                const o = await t.executeFuncWithConsent(n, n.getValue);
                return void 0 === o || "" === o ? {
                    status: s.cancelled
                } : (t.update(ta, (() => o)), {
                    status: s.completed,
                    analytics: {
                        gcdl: o
                    }
                })
            }
        });
        const na = pt([ea]),
            oa = {
                key: "_monitoring/statusesByEventIdentifier",
                default: new Map
            };
        var aa = async ({
                account: t,
                customEvent: e
            }) => {
                const n = e.detail ? .eventIdentifier;
                if (void 0 === n) throw new Error("Missing eventIdentifier parameter");
                const o = t.use(oa),
                    a = `${e.type}:${n}`,
                    i = o.get(a);
                return void 0 !== i ? i : s.waiting
            },
            ia = async ({
                account: t,
                customEvent: e
            }) => {
                const n = e.detail ? .eventIdentifier;
                if (void 0 === n) throw new Error("Missing eventIdentifier parameter");
                const o = e.detail ? .statusUpdate;
                if (void 0 === o) throw new Error("Missing statusUpdate parameter");
                if (!(o in s)) throw new Error(`Invalid statusUpdate parameter. Expected one of ${Object.values(s).join(", ")}`);
                const a = e.detail ? .pairedEvents;
                if (void 0 === a || a.length < 1 || a.some((t => "string" != typeof t))) throw new Error("Parameter pairedEvents must be a non-empty array of string");
                return a.forEach((e => {
                    const a = `${e}:${n}`;
                    t.update(oa, (t => t.set(a, o)))
                })), s.completed
            };
        const sa = new Map([
            ["_monitor/testing/only", aa],
            ["_update/testing/only", ia],
            ["_legacy/bidRequest/monitor", aa],
            ["_legacy/bidRequest/didComplete", ia]
        ]);
        var ra = new ut({
            scope: "prebid",
            object: "analyticsEvent",
            action: "track",
            handler: async ({
                account: t,
                customEvent: e
            }) => {
                if (void 0 === e.detail ? .eventType || void 0 === e.detail ? .eventArgs || void 0 === e.detail ? .config ? .options ? .accountID) return {
                    status: s.cancelled
                };
                const n = {
                        eventType: e.detail.eventType,
                        metadata: e.detail.metadata,
                        config: e.detail.config
                    },
                    o = await t.globalContext.fetch("https://prod.us-east-1.cxm-bcn.publisher-services.amazon.dev/v1/events/prebid", ca(e.detail));
                return o.ok ? {
                    status: s.completed,
                    analytics: n
                } : {
                    status: s.cancelled,
                    analytics: { ...n,
                        message: `Request failed: ${o.status}`
                    }
                }
            }
        });
        const ca = t => {
                const e = {
                    accountId: t.config.options.accountID,
                    events: [{
                        eventArgs: t.eventArgs,
                        eventType: t.eventType
                    }]
                };
                return {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(e)
                }
            },
            da = {
                key: "prebid/config",
                default: void 0
            };
        var la;
        ! function(t) {
            t.NotStarted = "NOT STARTED", t.Loading = "LOADING", t.Complete = "COMPLETE"
        }(la || (la = {}));
        const ua = {
            key: "prebid/configRequestState",
            default: la.NotStarted
        };
        var pa = new ut({
            scope: "prebid",
            object: "config",
            action: "fetch",
            handler: async ({
                account: t,
                customEvent: e
            }) => {
                const n = t.use(ua);
                if (n === la.Loading) return {
                    status: s.waiting
                };
                const o = {
                    metadata: e ? .detail ? .metadata
                };
                if (n === la.Complete) {
                    const e = t.use(da);
                    if (void 0 !== e) return {
                        status: s.completed,
                        value: JSON.parse(e),
                        analytics: o
                    }
                }
                try {
                    t.update(ua, (() => la.Loading));
                    const e = `https://c.amazon-adsystem.com/cdn/prod/config?src=${t.id}`,
                        n = await t.globalContext.fetch(e);
                    if (t.update(ua, (() => la.Complete)), !n.ok) return {
                        status: s.cancelled,
                        analytics: { ...o,
                            message: "Config request failed"
                        }
                    };
                    const a = await n.json(),
                        i = ma(t, a);
                    return t.update(da, (() => JSON.stringify(i)), {
                        persist: !0
                    }), {
                        status: s.completed,
                        value: i,
                        analytics: o
                    }
                } catch (t) {
                    return {
                        status: s.cancelled,
                        analytics: { ...o,
                            message: t.message
                        }
                    }
                }
            }
        });
        const ma = (t, e) => ({
                analyticsConfig: {
                    options: {
                        accountID: t.id,
                        sampling: e.pbjs ? .sampleRate
                    },
                    includeEvents: e.pbjs ? .allowedEvents
                },
                idConfig: {
                    params: {
                        accountID: t.id,
                        enabled: e.pbjs ? .enabled,
                        treatments: e.pbjs ? .treatments
                    }
                }
            }),
            fa = {
                key: "prebid/eidsConfig",
                default: "{}"
            };
        var ha;
        ! function(t) {
            t.APSSignalIQ = "_apsIdTreatment", t.Audigent = "hadronId", t.FirstID = "firstId", t.ID5 = "id5id", t.Liveramp = "idl_env", t.Lotame = "lotamePanoramaId", t.Pubcommon = "pubcid", t.Publink = "publinkId", t.ThirtyThree = "33acrossId", t.Yahoo = "connectId"
        }(ha || (ha = {}));
        const va = new Map([
                [nn, ha.Audigent],
                [cn, ha.FirstID],
                ["id5", ha.ID5],
                [Pn, ha.Liveramp],
                [Gn, ha.Lotame],
                [ao, ha.Pubcommon],
                [ro, ha.Publink],
                [Qe, ha.ThirtyThree],
                [bo, ha.Yahoo]
            ]),
            ya = {
                [ha.Audigent]: {
                    source: "audigent.com",
                    atype: 1
                },
                [ha.FirstID]: {
                    source: "first-id.fr",
                    atype: 1
                },
                [ha.ID5]: {
                    source: "id5-sync.com",
                    atype: 1
                },
                [ha.Liveramp]: {
                    source: "liveramp.com",
                    atype: 3
                },
                [ha.Lotame]: {
                    source: "crwdcntrl.net",
                    atype: 1
                },
                [ha.Pubcommon]: {
                    source: "pubcid.org",
                    atype: 1
                },
                [ha.Publink]: {
                    source: "epsilon.com",
                    atype: 3
                },
                [ha.ThirtyThree]: {
                    source: "33across.com",
                    atype: 1
                },
                [ha.Yahoo]: {
                    source: "yahoo.com",
                    atype: 3
                }
            };
        var ga = new ut({
            scope: "prebid",
            object: "eidsConfig",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => {
                if (void 0 === t.globalContext.apstag ? ._atsaaiod) return {
                    status: s.waiting
                };
                t.update(fa, (() => JSON.stringify({ ...ya
                })), {
                    persist: !0
                });
                const n = {
                    metadata: e ? .detail ? .metadata,
                    config: e ? .detail ? .config
                };
                return {
                    status: s.completed,
                    analytics: n
                }
            }
        });
        const wa = new Set(["CONTROL_HOLD_OUT", "CLEAN", ...va.keys()]);
        const ba = {
            key: "prebid/ids",
            default: void 0
        };
        var Ea = new ut({
            scope: "prebid",
            object: "ids",
            action: "get",
            handler: async ({
                account: t,
                customEvent: e
            }) => {
                if (void 0 === t.globalContext.apstag ? ._atsaaiod) return {
                    status: s.waiting
                };
                t.recordListenerNonBlocking(Po);
                const n = t.use(we);
                let o;
                void 0 !== n && (o = Object.fromEntries(Object.entries(n).map((([t, e]) => [va.get(t), e]))));
                const a = await t.recordListener(pa, {
                        metadata: e ? .detail ? .metadata
                    }),
                    i = {
                        metadata: e ? .detail ? .metadata
                    };
                return a.idConfig.params.enabled ? (null != a.idConfig.params.treatments && (o = function(t, e) {
                    if (! function(t) {
                            const e = 100 === t.reduce(((t, {
                                    percent: e
                                }) => t + e), 0),
                                n = t.reduce(((t, {
                                    treatment: e
                                }) => t && wa.has(e)), !0);
                            return e && n
                        }(e)) return t;
                    const n = function(t) {
                        const e = 100 * Math.random();
                        let n = 0;
                        for (const o of t)
                            if (n += o.percent, e <= n) return o.treatment;
                        throw new Error("Invalid treatment percentages")
                    }(e);
                    return function(t, e) {
                        const n = {
                                [ha.APSSignalIQ]: e
                            },
                            o = va.get(e);
                        switch (e) {
                            case "CONTROL_HOLD_OUT":
                                return { ...t,
                                    ...n
                                };
                            case "CLEAN":
                                return n;
                            default:
                                return void 0 !== o && void 0 !== t ? .[o] && (n[o] = t[o]), n
                        }
                    }(t, n)
                }(o, a.idConfig.params.treatments)), t.update(ba, (() => o)), {
                    status: s.completed,
                    value: o,
                    analytics: i
                }) : {
                    status: s.cancelled,
                    analytics: i
                }
            }
        });
        const Sa = pt([ra, pa, ga, Ea]),
            xa = t => t === _a.noConsent ? "AMZN-NoCookieConsent" : "AMZN-Token";
        var _a;
        ! function(t) {
            t[t.noConsent = 0] = "noConsent", t[t.token = 1] = "token"
        }(_a || (_a = {}));
        const Ra = t => {
                t.setCookieStorage(xa(_a.token), "", 0), t.setCookieStorage(xa(_a.noConsent), "", 0)
            },
            Ia = ({
                account: t,
                hashedRecords: e,
                ttl: n,
                isGDPRRegion: o,
                tcString: a,
                setToken: i
            }) => (Ra(t), "boolean" != typeof i && (i = !0), Aa({
                account: t,
                hashedRecords: e,
                ttl: n,
                isGDPRRegion: o,
                tcString: a
            }).then((({
                AIPToken: e,
                cookieExpiry: n
            }) => ka({
                AIPToken: e,
                cookieExpiry: n,
                account: t,
                setToken: i
            })))),
            Aa = ({
                account: t,
                hashedRecords: e,
                ttl: n,
                isGDPRRegion: o,
                tcString: a
            }) => fetch("https://tk.amazon-adsystem.com/envelope", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(ja({
                    account: t,
                    hashedRecords: e,
                    ttl: n,
                    isGDPRRegion: o,
                    tcString: a
                }))
            }).then((t => {
                if (!t.ok) throw new Error(`Token http status error: ${t.status}`);
                return t.json()
            })),
            ka = ({
                AIPToken: t,
                cookieExpiry: e,
                account: n,
                setToken: o
            }) => {
                if ("string" != typeof t || "number" != typeof e) throw new Error("Invalid AIPES response");
                if ("" === t) throw n.setCookieStorage(xa(_a.noConsent), "1", e), new Error("Empty token");
                (o || "boolean" != typeof o) && n.setCookieStorage(xa(_a.token), t, e)
            },
            ja = ({
                account: t,
                hashedRecords: e,
                ttl: n,
                isGDPRRegion: o,
                tcString: a
            }) => {
                const i = {
                    publisherId: t.id,
                    hashedRecords: e
                };
                return void 0 !== n && (i.ttl = n), o ? (i.gdpr = 1, a && (i.gdprConsent = a)) : i.gdpr = 0, i
            };
        var $a = new ut({
            scope: "ad",
            object: "record",
            action: "delete",
            handler: async ({
                account: t
            }) => {
                if (!t.globalContext.apstag ? ._atsaaiod) return {
                    status: s.waiting
                };
                if (!t.isAllowedToAccessInfoOnDevice()) throw new Error("Not allowed to access storage on device");
                return Ra(t), {
                    status: s.completed
                }
            }
        });
        const Ca = {
            detail: tt,
            "detail.setCookie": st(X),
            "detail.config": tt,
            "detail.config.optOut": st(X),
            "detail.config.ttl": st(Y),
            "detail.config.gdpr": st(tt),
            "detail.config.gdpr.cmpTimeout": st(Y),
            "detail.config.gdpr.enabled": st(dt),
            "detail.config.gdpr.consent": st(Z),
            "detail.config.gdpr.cmpGlobal": st(Z),
            "detail.config.gdpr.cmpGlobalv2": st(Z),
            "detail.config.hashedRecords": ot,
            "detail.config.hashedRecords[]": tt,
            "detail.config.hashedRecords[].type": Z,
            "detail.config.hashedRecords[].record": Z,
            "detail.config.hashedRecords[].encrypted": st(Y),
            "detail.config.hashedRecords[].toJSON": ct,
            "detail.config.hashedRecords[].$$typeof": ct,
            "detail.config.hashedRecords[].constructor": ct,
            "detail.config.hashedRecords[].tagName": ct,
            "detail.config.hashedRecords[].@@__IMMUTABLE_ITERABLE__@@": ct,
            "detail.config.hashedRecords[].@@__IMMUTABLE_RECORD__@@": ct
        };
        var Oa, Pa, Da = new ut({
            scope: "ad",
            object: "record",
            action: "renew",
            validators: {
                detail: Ca,
                context: {
                    context: tt
                }
            },
            handler: async ({
                account: t,
                detail: e
            }) => {
                if (!t.globalContext.apstag ? ._atsaaiod) return {
                    status: s.waiting
                };
                if (void 0 === e ? .config) throw new Error("Missing tokenConfig object");
                if (!t.isAllowedToAccessInfoOnDevice()) throw new Error("Not allowed to access storage on device");
                if ((t.readCookieStorage(xa(_a.token)) ? ? "").length > 0) return {
                    status: s.cancelled
                };
                const n = t.globalContext.apstag.isGDPRRegion,
                    o = t.use(It);
                var a;
                return await (a = {
                    account: t,
                    hashedRecords: e.config.hashedRecords,
                    ttl: e.config.ttl,
                    isGDPRRegion: n,
                    tcString: o ? .tcString
                }, Ia(a)), {
                    status: s.completed
                }
            }
        });
        ! function(t) {
            t.email = "email"
        }(Oa || (Oa = {})),
        function(t) {
            t.Display = "display", t.Video = "video", t.MultiFormat = "multi-format"
        }(Pa || (Pa = {}));
        const Ta = /^[0-9a-fA-F]{64}$/,
            Na = t => Ta.test(t || ""),
            La = t => t.then((t => Array.from(new Uint8Array(t)).map((t => t.toString(16).padStart(2, "0"))).join(""))).then((t => "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855" !== t ? t : "")),
            Ma = (t, e) => "string" == typeof t && (e === Oa.email ? /\S+@\S+\.\S+/.test(t) || Na(t) : t.trim().length > 0),
            Ua = (t, e, n) => e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement ? Ma(e.value, n) ? La(t.globalContext.crypto.subtle.digest("SHA-256", (new t.globalContext.TextEncoder).encode(e.value || ""))) : Promise.resolve("") : Ma(e.innerText, n) ? La(t.globalContext.crypto.subtle.digest("SHA-256", (new t.globalContext.TextEncoder).encode(e.innerText || ""))) : Promise.resolve(""),
            qa = (t, e, n) => {
                const o = t.readLocalStorage(e);
                return o && Ma(o, n) ? o : ""
            },
            Va = (t, e, n) => {
                n = n ? ? t.globalContext.location.href, e = e.replace(/[[\]]/g, "\\$&");
                const o = new RegExp("[?&#]" + e + "(=([^&#?]*)|&|#|$)").exec(n);
                return Array.isArray(o) && "string" == typeof o[2] && 0 !== decodeURIComponent(o[2].replace(/\+/g, " ")).trim().length && Na(decodeURIComponent(o[2].replace(/\+/g, " "))) ? Promise.resolve(decodeURIComponent(o[2].replace(/\+/g, " "))) : new Promise((t => t("")))
            };
        var Fa;
        ! function(t) {
            t.LOCAL_STORAGE = "LOCAL", t.CSS_SELECTOR = "CSS", t.URL = "URL"
        }(Fa || (Fa = {}));
        const Ba = (t, e = {}, n) => {
                (t => {
                    const e = {
                            [Fa.LOCAL_STORAGE]: 5,
                            [Fa.URL]: 4,
                            [Fa.CSS_SELECTOR]: 3
                        },
                        n = {};
                    t.forEach((t => {
                        n[t.method] = (n[t.method] || 0) + 1, t.priority = n[t.method]
                    })), t.sort(((t, n) => t.method === n.method ? (t.priority || 0) > (n.priority || 0) ? 1 : -1 : e[t.method] > e[n.method] ? -1 : 1))
                })(e.methods || []);
                const o = [];
                let a;
                for (const i of e.methods || []) {
                    const {
                        method: e,
                        target: s,
                        type: r
                    } = i;
                    let c = "";
                    switch (e) {
                        case Fa.LOCAL_STORAGE:
                            c = qa(t, s, r);
                            break;
                        case Fa.URL:
                            o.push(Va(t, s).then((t => ({
                                type: r,
                                value: t
                            }))));
                            break;
                        case Fa.CSS_SELECTOR:
                            a = i
                    }
                    if (c.length > 0) return void n({
                        value: c,
                        type: r
                    })
                }
                const i = () => {
                    if (!a || !0 !== a.isGlobalSubmit && ("string" != typeof a.eventTarget || "string" != typeof a.event)) return void n(!1);
                    const {
                        eventTarget: e,
                        target: o,
                        type: i,
                        isGlobalSubmit: s
                    } = a, r = s ? "submit" : a.event;
                    if ("string" != typeof r || 0 === r.length) return void n(!1);
                    const c = a => (({
                        account: t,
                        e: e,
                        eventTarget: n,
                        event: o,
                        isGlobalSubmit: a,
                        target: i,
                        type: s,
                        onDone: r,
                        listener: c
                    }) => {
                        if (!(a || "window" === n || e.target && "function" == typeof e.target.matches && "string" == typeof n && e.target.matches(n))) return void r(!1);
                        let d;
                        a && e instanceof Event && e.target && (d = e.target.querySelectorAll('input[type="email"]')), ((t, e, n, o) => {
                            const a = o || t.globalContext.document.querySelectorAll(e);
                            if (0 === a.length) return new Promise((t => t("")));
                            if (1 === a.length) return Ua(t, a[0], n);
                            const i = [];
                            for (const e of a) i.push(Ua(t, e, n));
                            return Promise.all(i).then((t => {
                                let e = null;
                                for (const n of t)
                                    if ("" !== n) {
                                        if (null !== e && ("string" != typeof e || e !== n)) return "";
                                        e = n
                                    }
                                return e ? ? ""
                            }))
                        })(t, i, s, d).then((e => {
                            "function" == typeof c && t.globalContext.removeEventListener(o, c), r(!(e.length < 1) && {
                                value: e,
                                type: s
                            })
                        }))
                    })({
                        account: t,
                        e: a,
                        event: r,
                        eventTarget: e,
                        isGlobalSubmit: s,
                        target: o,
                        type: i,
                        onDone: n,
                        listener: c
                    });
                    t.globalContext.addEventListener(r, c)
                };
                if (0 !== o.length) return Promise.all(o).then((t => {
                    for (const e of t)
                        if (e.value.length > 0) return void n(e);
                    i()
                }));
                i()
            },
            za = {
                called: !1
            };
        const Ja = pt([$a, Da, new ut({
                scope: "ad",
                object: "record",
                action: "rr",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.config": tt,
                        "detail.config.$$typeof": ct,
                        "detail.config.tagName": ct,
                        "detail.config.@@__IMMUTABLE_ITERABLE__@@": ct,
                        "detail.config.@@__IMMUTABLE_RECORD__@@": ct,
                        "detail.config.accountID": st(Z),
                        "detail.config.overrideLimit": st(X),
                        "detail.config.methods": ot,
                        "detail.config.methods[].tagName": ct,
                        "detail.config.methods[]": it(tt),
                        "detail.config.methods[].$$typeof": ct,
                        "detail.config.methods[].@@__IMMUTABLE_ITERABLE__@@": ct,
                        "detail.config.methods[].@@__IMMUTABLE_RECORD__@@": ct,
                        "detail.config.methods[].type": at(Object.values(Oa)),
                        "detail.config.methods[].method": at(Object.values(Fa)),
                        "detail.config.methods[].target": st(Z),
                        "detail.config.methods[].event": st(Z),
                        "detail.config.methods[].eventTarget": st(Z),
                        "detail.config.methods[].isGlobalSubmit": st(X),
                        "detail.config.methods[].priority": st(Y)
                    },
                    context: {
                        context: tt,
                        "context.Promise": rt,
                        "context.crypto": tt,
                        "context.crypto.subtle": rt
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => {
                    if (!t.globalContext.apstag ? ._atsaaiod) return {
                        status: s.waiting
                    };
                    if (!t.isAllowedToAccessInfoOnDevice()) throw new Error("Not allowed to access storage on device");
                    const n = await
                    function(t, e) {
                        return new Promise(((n, o) => {
                            if (za.called && !e.overrideLimit) throw new Error("rr should only be called once per page load");
                            za.called = !0;
                            let a = 0;
                            const i = () => {
                                const s = (() => {
                                        const a = t.use(It);
                                        return (!t.globalContext.apstag ? .isGDPRRegion || void 0 !== a) && (void 0 === a || t.isAllowedToAccessInfoOnDevice() ? (Ba(t, e, (e => {
                                            if (!1 === e) return n("no retrieval");
                                            Ia({
                                                account: t,
                                                hashedRecords: [{
                                                    type: e.type,
                                                    record: e.value
                                                }],
                                                source: "rr",
                                                tcString: a ? .tcString
                                            }).then((() => {
                                                n("token generated")
                                            })).catch(o)
                                        })) ? .catch(o), !0) : "canceled")
                                    })(),
                                    r = a > 6400;
                                if (s || r) return "canceled" === s && o(new Error("tcf timeout")), void(r && o(new Error("interval over")));
                                setTimeout(i, a), a = 0 === a ? 200 : 2 * a
                            };
                            i()
                        }))
                    }(t, e.config);
                    return {
                        status: s.completed,
                        analytics: {
                            rr: n
                        }
                    }
                }
            }), new ut({
                scope: "ad",
                object: "record",
                action: "update",
                validators: {
                    detail: Ca,
                    context: {
                        context: tt
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => {
                    if (!t.globalContext.apstag ? ._atsaaiod) return {
                        status: s.waiting
                    };
                    if (!t.isAllowedToAccessInfoOnDevice()) throw new Error("Not allowed to access storage on device");
                    const n = t.globalContext.apstag.isGDPRRegion,
                        o = t.use(It);
                    return e.config.optOut ? Ra(t) : await Ia({
                        account: t,
                        hashedRecords: e.config.hashedRecords,
                        ttl: e.config.ttl,
                        isGDPRRegion: n,
                        tcString: o ? .tcString,
                        setToken: e ? .setCookie
                    }), {
                        status: s.completed
                    }
                }
            })]),
            Ha = new Map([
                ["ad/ASRSlot/render", async ({
                    account: t,
                    customEvent: e
                }) => {
                    if (void 0 === e.detail ? .id || void 0 === e.detail ? .targeting) throw new Error("Missing event detail");
                    return ((t, e, n, o) => {
                        const a = n.globalContext.document.createElement("iframe"),
                            i = e.get("amznsz") ? .split("x"),
                            s = e.get("amzniid"),
                            r = t;
                        if (void 0 === s || void 0 === r || void 0 === i || i.length < 2) return;
                        a.style.marginLeft = "0", a.style.marginTop = "0", a.style.height = `${i[1]}px`, a.style.width = "100%", a.setAttribute("scrolling", "no"), a.setAttribute("frameborder", "0");
                        const c = n.globalContext.document.createElement("div"),
                            d = o ? .location ? ? "afterend",
                            l = n.globalContext.document.getElementById(r);
                        if (null == l) return;
                        l.insertAdjacentElement(d, c), c.appendChild(a);
                        const u = a ? .contentWindow ? .document;
                        void 0 !== u && (u.open(), u.write('<!DOCTYPE html><html><head><meta charset="UTF-8"><style>html{height:100%}body{height:100%;margin:0;overflow:hidden}</style></head><body><script>window.parent.apstag.renderImp(document, "' + s + '", {"inheritSize": true});<\/script></body></html>'), u.close())
                    })(e.detail.id, e.detail.targeting, t), s.completed
                }]
            ]);
        async function Ga(t) {
            try {
                const e = await crypto.subtle.importKey("jwk", {
                        alg: "A128CTR",
                        ext: !0,
                        k: "ERTYQsuodPO_Um-5jFmOLg",
                        key_ops: ["encrypt"],
                        kty: "oct"
                    }, "AES-CTR", !0, ["encrypt"]),
                    n = (new TextEncoder).encode(t),
                    o = new Uint8Array(await crypto.subtle.encrypt({
                        name: "AES-CTR",
                        counter: new Uint8Array(16),
                        length: 128
                    }, e, n));
                return btoa(String.fromCharCode(...o))
            } catch (t) {
                return null
            }
        }
        const Ka = "google/secureSignals/initialize",
            Wa = new Map([
                ["google/secureSignals/set", async ({
                    account: t,
                    customEvent: e
                }) => (void 0 === t.globalContext.googletag && (t.globalContext.googletag = {}), void 0 === t.globalContext.googletag.secureSignalProviders && (t.globalContext.googletag.secureSignalProviders = []), t.globalContext.googletag.secureSignalProviders.push({
                    networkCode: "amazon.com",
                    collectorFunction: async () => {
                        const {
                            encryptedSignal: e
                        } = await t.record(Ka);
                        return e
                    }
                }), s.completed)],
                [Ka, async ({
                    account: t,
                    customEvent: e
                }) => {
                    const n = t.globalContext.apstag ? ._getSlotIdToNameMapping;
                    let o;
                    if (void 0 === n) return {
                        status: s.waiting
                    };
                    if (o = n(), 0 === Object.keys(o).length) return {
                        status: s.waiting
                    };
                    let a = t.globalContext.location ? .href;
                    void 0 === a && (a = "");
                    const i = `${a};${JSON.stringify(o)}`.substr(0, 225);
                    return {
                        status: s.completed,
                        value: {
                            encryptedSignal: await Ga(i)
                        }
                    }
                }]
            ]);
        var Qa;
        ! function(t) {
            t.Googletag = "googletag", t.AppNexus = "appnexus", t.SAS = "sas"
        }(Qa || (Qa = {}));
        const Ya = ["187", "189", "306", "312", "313", "314", "317", "318", "290", "291", "292", "293", "294", "296", "297", "300", "301", "302", "303", "304", "305", "307", "308", "310", "311", "405", "454", "456", "457", "458", "459", "460", "461", "462", "463"],
            Za = ["Rm3SiT", "Z7rJBM", "HxqYV1", "pg0WhF", "j9PaO9", "mm3UXx", "6i4dB6", "8FD8nI"],
            Xa = {
                3: [...["4-10", "5-14", "6-1", "7-6", "7-7", "6-7", "6-8", "7-2", "7-3", "7-8", "7-9", "7-10", "7-11", "7-12", "7-13", "7-14", "7-16", "7-18", "7-20", "7-21", "7-22", "7-23", "7-27", "7-28", "7-29", "7-30", "7-34", "7-36", "7-37", "7-39", "7-40", "7-41", "7-42", "7-43", "7-44", "13-2", "14-2", "14-3", "14-8", "15-1", "23-1", "23-2", "23-3", "23-4", "23-5", "23-6", "23-7", "23-8", "23-9", "23-10", "25", "25-1", "25-2", "25-3", "25-4", "25-5", "25-6", "25-7", "26", "26-1", "26-2", "26-3", "26-4"].map((t => `IAB${t}`))],
                4: [...Ya],
                5: [...Ya],
                6: [...Ya, ...Za],
                7: [...Ya, ...Za]
            },
            ti = {
                site: {
                    id: "id",
                    name: "name",
                    domain: "domain",
                    cattax: 1,
                    cat: ["1"],
                    sectioncat: ["first", "second"],
                    pagecat: ["first", "second"],
                    page: "page",
                    ref: "ref",
                    search: "search",
                    mobile: 1,
                    privacypolicy: 1,
                    publisher: {
                        id: "id",
                        name: "name",
                        cattax: 1,
                        cat: ["1"],
                        domain: "domain",
                        ext: {}
                    },
                    content: {
                        id: "id",
                        episode: 1,
                        title: "title",
                        series: "series",
                        season: "season",
                        artist: "artist",
                        genre: "genre",
                        album: "album",
                        isrc: "isrc",
                        producer: {
                            id: "id",
                            name: "name",
                            cattax: 1,
                            cat: ["1"],
                            domain: "domain",
                            ext: {}
                        },
                        url: "url",
                        cattax: 1,
                        cat: ["1"],
                        prodq: 1,
                        context: 1,
                        contentrating: "contentrating",
                        userrating: "userrating",
                        qagmediarating: 1,
                        keywords: "first, second",
                        kwarray: ["first", "second"],
                        livestream: 1,
                        sourcerelationship: 1,
                        len: 1,
                        language: "language",
                        langb: "langb",
                        embeddable: 1,
                        data: [{
                            id: "id",
                            name: "name",
                            segment: [{
                                id: "id",
                                name: "name",
                                value: "value",
                                ext: {}
                            }],
                            ext: {}
                        }],
                        network: {
                            id: "id",
                            name: "name",
                            domain: "domain",
                            ext: {}
                        },
                        channel: {
                            id: "id",
                            name: "name",
                            domain: "domain",
                            ext: {}
                        },
                        ext: {}
                    },
                    keywords: "first, second",
                    kwarray: ["first", "second"],
                    ext: {}
                }
            },
            ei = (t, e) => Object.keys(t).reduce(((n, o) => {
                const a = o;
                if (void 0 !== e ? .[a]) {
                    const o = t[a];
                    "object" == typeof(i = o) && !Array.isArray(i) && Object.keys(i).length > 0 ? n[a] = ei(o, e[a]) : n[a] = ((t, e) => {
                        const n = e.cattax,
                            o = e[t];
                        return (Xa[n] ? ? []).length > 0 && ("cat" === t || "sectcat" === t || "sectioncat" === t || "pagecat" === t) && Array.isArray(o) ? o.filter((t => !Xa[n].includes(`${t}`))) : o
                    })(a, e)
                }
                var i;
                return n
            }), {});

        function ni(t) {
            return t.get = function(...t) {
                const e = Map.prototype.get.apply(this, t);
                return Map.prototype.delete.apply(this, t), e
            }, t
        }
        const oi = {
            key: "ad/targeting",
            default: new Map,
            postProcessor: ni
        };
        var ai = new ut({
            scope: "ad",
            object: "targeting",
            action: "attach",
            validators: {
                detail: {
                    detail: tt,
                    "detail.itemIds": st(ot),
                    "detail.itemIds[]": Z,
                    "detail.adServer": at(Object.values(Qa))
                },
                context: {
                    context: tt,
                    ...pn
                }
            },
            handler: async ({
                account: t,
                detail: e,
                context: n
            }) => {
                const o = {
                    pubID: t.id
                };
                return n.apstag.setDisplayBids(e.itemIds, {
                    initConfig: o,
                    adServer: e.adServer
                }), ii(t, {
                    itemIds: e.itemIds
                }), {
                    status: s.completed
                }
            }
        });
        const ii = (t, e) => {
                e.itemIds ? e.itemIds.forEach((e => {
                    t.update(oi, (t => (t.delete(e), t)))
                })) : t.update(oi, (t => (t.clear(), t)))
            },
            si = {
                key: "ad/slots",
                default: new Map
            },
            ri = {
                key: "cxm/isConfigLoadInitiated",
                default: !1
            },
            ci = t => {
                const e = new Map,
                    n = t => {
                        e.set(JSON.stringify(t), t)
                    };
                return t.w && t.h && n([t.w, t.h]), t.format ? .forEach((t => {
                    t.w && t.h && n([t.w, t.h])
                })), e.size > 0 ? Array.from(e.values()) : void 0
            },
            di = t => {
                if (t.bidfloor) {
                    if (void 0 !== t.bidfloorcur && "USD" !== t.bidfloorcur) throw new Error('imp.bidfloorcur: only "USD" is currently supported');
                    return {
                        value: t.bidfloor,
                        currency: "USD"
                    }
                }
            },
            li = (t, e) => {
                const n = {};
                return Object.keys(t).forEach((o => {
                    "object" == typeof t[o] && null !== t[o] && (o === e ? Object.assign(n, t[o]) : Object.assign(n, li(t[o], e)))
                })), n
            },
            ui = t => {
                const e = li(t, "ext");
                return Object.entries(e).forEach((([t, n]) => {
                    "string" != typeof n && (e[t] = JSON.stringify(n))
                })), 0 !== Object.keys(e).length ? e : void 0
            },
            pi = "ad/targeting/fetch",
            mi = "ad/signals/define",
            fi = "cxm/config/load",
            hi = new Map([
                ["ad_slot_import", async ({
                    account: t,
                    customEvent: e
                }) => {
                    if (void 0 === e.detail ? .adServer) throw new Error("adServer: a valid value must be provided");
                    if (e.detail.adServer === Qa.Googletag) return t.write("ad/googletagSlotAutoImport", !0), s.completed;
                    throw new Error("adServer: value provided isn't currently supported")
                }],
                ["ad/schain/define", async ({
                    account: t,
                    customEvent: e
                }) => {
                    if (void 0 === e.detail ? .schain) throw new Error("Missing schain object");
                    return t.write("ad/schain", e.detail.schain), s.completed
                }],
                [pi, async ({
                    account: e,
                    customEvent: n
                }) => {
                    if (void 0 === e.globalContext.apstag || void 0 === e.globalContext.apstag.clientFetchBids) return s.waiting;
                    const o = e.use(hn);
                    void 0 === o && e.record("idVendors/legacy/didExecuteFirst", {
                            analytics: {
                                context: "ad_targeting_fetch",
                                timing: "legacy-first"
                            }
                        }).catch((() => {})), !0 !== o && function(t) {
                            t.use(ri) || (t.update(ri, (() => !0)), t.record(fi).catch((t => {})))
                        }(e),
                        function(e) {
                            (function(e) {
                                if (function(t) {
                                        for (const e of t.queue)
                                            if (e.type === Jo && e.status === s.waiting) return !0;
                                        return !1
                                    }(e)) return !1;
                                return void 0 !== e.read(t, {
                                    persist: !0
                                })
                            })(e) && e.record(Jo).catch((t => {}))
                        }(e);
                    const a = function(t) {
                            return Array.from(t.use(si).values())
                        }(e),
                        i = function(t, e) {
                            let n = t;
                            return void 0 !== e && e.length > 0 && (n = t.filter((t => e.includes(t.id)))), n
                        }(a, n.detail ? .itemIds),
                        r = n.detail ? .publisherParams,
                        c = n.detail ? .tid,
                        d = n.detail ? .tidBySlotId;
                    return await async function({
                        account: t,
                        selectedSlots: e,
                        publisherParams: n,
                        timeout: o,
                        _endpointDomain: a,
                        tid: i,
                        tidBySlotId: s,
                        initConfig: r
                    }) {
                        const c = function(t) {
                            return t.map((t => (t => {
                                const e = {
                                    slotID: t.id,
                                    slotName: t.tagid,
                                    floor: di({
                                        bidfloor: t.bidfloor,
                                        bidfloorcur: t.bidfloorcur
                                    }),
                                    slotParams: ui(t)
                                };
                                if (t.banner && t.video) {
                                    e.mediaType = Pa.MultiFormat;
                                    const n = ci({
                                            w: t.video.w,
                                            h: t.video.h
                                        }),
                                        o = ci({
                                            w: t.banner.w,
                                            h: t.banner.h,
                                            format: t.banner.format
                                        });
                                    o && (e.multiFormatProperties = { ...e.multiFormatProperties,
                                        display: {
                                            sizes: o
                                        }
                                    }), n && (e.multiFormatProperties = { ...e.multiFormatProperties,
                                        video: {
                                            sizes: n
                                        }
                                    })
                                } else t.video ? (e.mediaType = Pa.Video, e.sizes = ci({
                                    w: t.video.w,
                                    h: t.video.h
                                })) : t.banner && (e.mediaType = Pa.Display, e.sizes = ci({
                                    w: t.banner.w,
                                    h: t.banner.h,
                                    format: t.banner.format
                                }));
                                return t.video ? .companionad && (e.companions = [], t.video.companionad.forEach((t => {
                                    t.id && e.companions ? .push(t.id)
                                }))), e
                            })(t)))
                        }(e);
                        return ((t, e) => {
                            e && t.forEach((t => {
                                const n = e[t.slotID];
                                n && (t.tid = n)
                            }))
                        })(c, s), await async function({
                            account: t,
                            legacySlots: e,
                            publisherParams: n,
                            timeout: o,
                            _endpointDomain: a,
                            tid: i,
                            initConfig: s
                        }) {
                            return await new Promise((r => {
                                if (void 0 === t.globalContext.apstag) throw new Error("apstag undefined in global scope");
                                t.globalContext.apstag.clientFetchBids({
                                    slots: e,
                                    params: n,
                                    timeout: o ? ? 6e4,
                                    _endpointDomain: a,
                                    tid: i
                                }, (t => {
                                    r(t)
                                }), {
                                    initConfig: s
                                })
                            }))
                        }({
                            account: t,
                            legacySlots: c,
                            publisherParams: n,
                            timeout: o,
                            _endpointDomain: a,
                            tid: i,
                            initConfig: r
                        })
                    }({
                        account: e,
                        selectedSlots: i,
                        publisherParams: r,
                        timeout: n.detail ? .timeout,
                        _endpointDomain: n.detail ? ._endpointDomain,
                        tid: c,
                        tidBySlotId: d,
                        initConfig: {
                            pubID: e.id,
                            isSelfServePub: 36 === e.id.length,
                            deals: !0
                        }
                    }), s.completed
                }],
                [mi, async ({
                    account: t,
                    customEvent: e
                }) => {
                    if (void 0 === e.detail || !("context" in e.detail)) throw new Error("Missing detail object");
                    const n = null != e.detail.context ? ei(ti, e.detail.context) : e.detail.context;
                    return t.update(ae, (() => n)), s.completed
                }],
                [fi, async ({
                    account: t,
                    customEvent: e
                }) => {
                    if (void 0 === t.globalContext.apstag ? ._load3PLibraryConfig) return s.waiting;
                    let n, o = t.id;
                    return 36 === t.id.length && (o = "600", n = t.id), await new Promise(((e, a) => {
                        if (void 0 === t.globalContext.apstag ? ._load3PLibraryConfig) throw new Error("apstag._load3PLibraryConfig is undefined");
                        t.globalContext.apstag._load3PLibraryConfig(t.id, {
                            sourceID: o,
                            publisherUUID: n
                        }, e, a)
                    })), s.completed
                }]
            ]),
            vi = new Map([...hi, ...pt([ai])]),
            yi = "widget/toolbox/open",
            gi = "widget/toolbox/start",
            wi = new Map([
                ["widget/toolbox/end", async ({
                    account: t
                }) => (t.record(Bo, {
                    eventName: gi
                }).catch((t => {})), s.completed)],
                [yi, async ({
                    account: t,
                    customEvent: e
                }) => (function(t, e) {
                    const n = e.globalContext.document.createElement("script");
                    n.src = "https://c.toolbox.aps.amazon-adsystem.com/toolbox.js", n.async = !0, e.globalContext.document.head.appendChild(n)
                }(0, t), s.completed)],
                [gi, async ({
                    account: t,
                    customEvent: e
                }) => (t.record(Fo, {
                    eventName: e.type
                }).catch((t => {})), t.record(yi).catch((t => {})), s.completed)]
            ]),
            bi = "_config/events/activations",
            Ei = "_config/events/deactivations",
            Si = new Map([
                ["_config/events/activate", async ({
                    customEvent: t,
                    account: e
                }) => {
                    const n = null != e.store.get(bi) ? e.store.get(bi) : new Set;
                    return n.add(t.detail.name), e.store.set(bi, n), s.completed
                }],
                ["_config/events/deactivate", async ({
                    customEvent: t,
                    account: e
                }) => {
                    const n = null != e.store.get(Ei) ? e.store.get(Ei) : new Set;
                    return n.add(t.detail.name), e.store.set(Ei, n), s.completed
                }]
            ]),
            xi = {
                key: "sessionMarker/marker",
                default: void 0
            },
            _i = new Map([
                ["sessionMarker/marker/sync", async ({
                    account: t
                }) => "object" != typeof t.globalContext.crypto || "function" != typeof t.globalContext.crypto.randomUUID ? s.cancelled : ((t => {
                    const e = t.use(xi, {
                        persist: !0
                    });
                    if (0 === (e ? ? "").length) return !1;
                    const n = e ? .split("_")[1] ? ? "";
                    if (0 === n.length) return !1;
                    const o = new Date(n);
                    return !((new Date).valueOf() - o.valueOf() >= 2592e6)
                })(t) || ((t => {
                    t.delete(xi.key, {
                        persist: !0
                    })
                })(t), (t => {
                    const e = t.globalContext.crypto.randomUUID();
                    if (36 !== e.length) throw new Error(`Invalid PEID generated: ${e}`);
                    const n = `${e}_${(new Date).toISOString()}`;
                    t.update(xi, (() => n), {
                        persist: !0
                    })
                })(t)), (t => {
                    const e = t.use(xi, {
                        persist: !0
                    });
                    t.update(xi, (() => e))
                })(t), s.completed)]
            ]);
        var Ri = new ut({
                scope: "legacy",
                object: "rpa",
                action: "enqueue",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.tokenConfig": null,
                        "detail.callback": null,
                        "detail.setCookie": st(X)
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => void 0 === t.globalContext.apstag ? .rpa || void 0 === t.globalContext.apstag ? .debug ? {
                    status: s.waiting
                } : (t.globalContext.apstag.rpa(e.tokenConfig, e.callback, e.setCookie, t.id), {
                    status: s.completed
                })
            }),
            Ii = new ut({
                scope: "legacy",
                object: "dpa",
                action: "enqueue",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.callback": null
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => void 0 === t.globalContext.apstag ? .dpa || void 0 === t.globalContext.apstag ? .debug ? {
                    status: s.waiting
                } : (t.globalContext.apstag.dpa(e.callback), {
                    status: s.completed
                })
            }),
            Ai = new ut({
                scope: "legacy",
                object: "upa",
                action: "enqueue",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.tokenConfig": null,
                        "detail.callback": null,
                        "detail.setCookie": st(X)
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => void 0 === t.globalContext.apstag ? .upa || void 0 === t.globalContext.apstag ? .debug ? {
                    status: s.waiting
                } : (t.globalContext.apstag.upa(e.tokenConfig, e.callback, e.setCookie, "bootstrap", t.id), {
                    status: s.completed
                })
            }),
            ki = new ut({
                scope: "legacy",
                object: "queue",
                action: "push",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.callback": null
                    }
                },
                handler: async ({
                    detail: t
                }) => (void 0 !== t.callback && null !== t.callback && t.callback(), {
                    status: s.completed
                })
            });
        const ji = new Map([
                ["legacy/init/enqueue", async ({
                    account: t,
                    customEvent: e
                }) => void 0 === t.globalContext.apstag ? .init || void 0 === t.globalContext.apstag ? .debug ? s.waiting : (t.globalContext.apstag.init(e.detail ? .config, e.detail ? .callback), s.completed)],
                ["legacy/fetchBids/enqueue", async ({
                    account: t,
                    customEvent: e
                }) => void 0 === t.globalContext.apstag ? .fetchBids || void 0 === t.globalContext.apstag ? .debug ? s.waiting : (t.globalContext.apstag.fetchBids(e.detail ? .bidConfig, e.detail ? .callback), s.completed)]
            ]),
            $i = new Map([...ji, ...pt([Ai, Ii, Ri, ki])]),
            Ci = {
                key: "a3pes/isDeactivated",
                default: !1
            };
        var Oi = new ut({
            scope: "adExchange",
            object: "a3pes",
            action: "deactivate",
            validators: {
                detail: {
                    detail: tt
                },
                context: {
                    context: tt
                }
            },
            handler: async ({
                account: t
            }) => (t.update(Ci, (() => !0)), {
                status: s.completed
            })
        });
        const Pi = {
            key: "ad/attachTargeting",
            default: void 0
        };
        var Di = new ut({
            scope: "bidResponse",
            object: "targeting",
            action: "save",
            validators: {
                detail: {
                    detail: tt,
                    "detail.aaxResp": tt,
                    "detail.aaxResp.cb": st(Z),
                    "detail.aaxResp.slots": st(ot),
                    "detail.aaxResp.host": st(Z),
                    "detail.aaxResp.slots[]": dt
                }
            },
            handler: async ({
                account: t,
                detail: e
            }) => {
                const n = e.aaxResp;
                return function(t, e) {
                        t.update(oi, (t => (function(t, e) {
                            e ? .slots ? .forEach((e => {
                                t.set(e.slotID, new Map)
                            }))
                        }(t, e), function(t, e) {
                            e ? .slots ? .forEach((n => {
                                n.targeting.forEach((e => {
                                    Map.prototype.get.apply(t, [n.slotID]).set(e, n[e])
                                })), e.host && Map.prototype.get.apply(t, [n.slotID]).set("amznhost", e.host)
                            }))
                        }(t, e), t)))
                    }(t, n),
                    function(t) {
                        const e = ({
                            adServer: e,
                            itemIds: n
                        }) => {
                            t.recordListenerNonBlocking(ai, {
                                itemIds: n,
                                adServer: e
                            })
                        };
                        t.update(Pi, (() => e))
                    }(t), n.slots ? {
                        status: s.completed
                    } : {
                        status: s.cancelled
                    }
            }
        });
        const Ti = {
                key: "a3pes/bidURL",
                default: "https://web-banner.ads.aps.amazon-adsystem.com/e/dtb/bid"
            },
            Ni = {
                key: "a3pes/videoBidURL",
                default: "https://web-video.ads.aps.amazon-adsystem.com/e/dtb/bid"
            },
            Li = {
                key: "a3pes/mockBidder",
                default: void 0
            };
        var Mi, Ui = new ut({
            scope: "adExchange",
            object: "a3pes",
            action: "fetch",
            validators: {
                detail: {
                    detail: tt,
                    "detail.requestBody": Z,
                    "detail.slotType": at(["banner", "video", "banner+video"])
                },
                context: {
                    context: tt,
                    "context.fetch": rt,
                    "context.fetch()": tt,
                    "context.fetch().ok": X,
                    "context.fetch().then": rt,
                    "context.fetch().then()": dt,
                    ...pn
                }
            },
            handler: async ({
                account: t,
                context: e,
                detail: n
            }) => {
                let o = "video" === n.slotType || "banner+video" === n.slotType ? t.use(Ni) : t.use(Ti);
                if (k()) {
                    const e = t.use(Li);
                    if (void 0 !== e) {
                        const t = new URL(o);
                        t.searchParams.set("mockBidderIds", e.id), t.searchParams.set("mockBidderUrls", e.url), o = t.toString()
                    }
                }
                const a = await e.fetch(o, {
                    method: "POST",
                    credentials: "include",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: n.requestBody
                });
                if (!a.ok) throw new Error(`Fetch failed with status: ${a.status}`);
                const i = a.status,
                    r = a.statusText,
                    c = a.type,
                    d = await a.json(),
                    {
                        contextual: l
                    } = d;
                if (!l) throw new Error("Bid response missing contextual object");
                return t.recordListenerNonBlocking(Di, {
                    aaxResp: l
                }), e.apstag.bids(l), {
                    status: s.completed,
                    analytics: {
                        statusCode: i,
                        statusText: r,
                        responseType: c,
                        slotType: n.slotType
                    }
                }
            }
        });
        ! function(t) {
            t.DISPLAY = "d", t.VIDEO = "v", t.MULTI_FORMAT = "mf"
        }(Mi || (Mi = {}));
        const qi = t => (void 0 === t.mt || t.mt === Mi.DISPLAY) && void 0 === t.native,
            Vi = t => t.mt === Mi.VIDEO,
            Fi = t => t.mt === Mi.MULTI_FORMAT,
            Bi = t => Fi(t) ? Mi.MULTI_FORMAT : Vi(t) ? Mi.VIDEO : qi(t) ? Mi.DISPLAY : null,
            zi = (t, ...e) => {
                const n = new Set;
                for (const o of t) {
                    const t = Bi(o);
                    if (null === t || !e.includes(t)) return !1;
                    n.add(t)
                }
                return e.every((t => n.has(t)))
            },
            Ji = t => t.sd || t.id,
            Hi = "primary",
            Gi = "canary",
            Ki = Hi;

        function Wi(t, e, n = !1) {
            if ("object" == typeof t.aps_prebid && null !== t.aps_prebid) {
                if ("object" == typeof t.aps_prebid[e] && null !== t.aps_prebid[e]) return t.aps_prebid[e];
                if (n) return t.aps_prebid[e] = {}, t.aps_prebid[e]
            } else if (n) return t.aps_prebid = {}, t.aps_prebid[e] = {}, t.aps_prebid[e];
            return null
        }

        function Qi(t, e, n) {
            const o = t(`aps_prebid_${e}`);
            if (o) try {
                return JSON.parse(o)
            } catch (t) {
                n.push(`Failed to parse stored configuration for account '${e}': ${t}`)
            }
            return null
        }

        function Yi(t) {
            const e = Number(t);
            return isNaN(e) || e < 0 || e > 1 ? null : e
        }

        function Zi(t, e, n) {
            const o = Wi(t, e);
            return o && o.currentRoles ? o.currentRoles[n] : void 0
        }

        function Xi(t, e, n, o, a) {
            if (o === Hi) return !0;
            if (o === Gi) {
                const o = function(t, e, n, o) {
                    const a = Wi(t, e);
                    if (a && ("number" == typeof a.canaryRate || "string" == typeof a.canaryRate)) {
                        const t = Yi(a.canaryRate);
                        if (null !== t) return t
                    }
                    const i = Qi(n, e, o);
                    if (i && ("number" == typeof i.canaryRate || "string" == typeof i.canaryRate)) {
                        const t = Yi(i.canaryRate);
                        if (null !== t) return t
                    }
                    return .02
                }(t, e, n, a);
                return Math.random() < o
            }
            return !1
        }

        function ts({
            context: t,
            accountID: e,
            readFromStorage: n,
            currentLibrary: o = "webclient",
            otherLibrary: a = "prebid"
        }) {
            const i = [],
                s = function(t, e, n, o, a, i) {
                    const s = Zi(t, e, o),
                        r = function(t, e, n, o, a) {
                            const i = Wi(t, e);
                            if (i && i.roleInstructions && "string" == typeof i.roleInstructions[o]) return i.roleInstructions[o];
                            const s = Qi(n, e, a);
                            return s && s.roleInstructions && "string" == typeof s.roleInstructions[o] ? s.roleInstructions[o] : Ki
                        }(t, e, n, o, i);
                    return s && s === Hi && r === Gi ? Zi(t, e, a) === Hi ? Gi : Hi : r
                }(t, e, n, o, a, i);
            return function(t, e, n, o) {
                const a = Wi(t, e, !0);
                a.currentRoles = a.currentRoles || {}, a.currentRoles[n] = o
            }(t, e, o, s), {
                isValid: Xi(t, e, n, s, i),
                errors: i
            }
        }
        const es = {
            key: "pathSelection/isPathBlocked",
            default: !1
        };
        var ns = new ut({
            scope: "pathSelection",
            object: "path",
            action: "evaluate",
            validators: {
                context: {
                    context: dt
                }
            },
            handler: async ({
                account: t,
                context: e
            }) => {
                const n = ts({
                        context: e,
                        accountID: t.id,
                        readFromStorage: e => t.readLocalStorage(e, {
                            throwOnDisallowed: !1
                        })
                    }),
                    o = !n.isValid;
                return t.update(es, (() => o)), {
                    status: s.completed,
                    analytics: {
                        isPathBlocked: o,
                        errors: n.errors
                    }
                }
            }
        });
        const os = {
            key: "bidURL/pj",
            default: new Map,
            postProcessor: ni
        };
        var as = new ut({
            scope: "bidURL",
            object: "pj",
            action: "update",
            validators: {
                detail: {
                    detail: tt,
                    "detail.bidRequestIndex": Z,
                    "detail.pj": st(Z)
                }
            },
            handler: async ({
                account: t,
                detail: e
            }) => {
                let n = {};
                if (void 0 !== e.pj && (n = JSON.parse(e.pj)), "object" != typeof n || Array.isArray(n)) throw new Error(`Unexpected value for search param pj: ${n}`);
                const o = t.use(Ro),
                    a = {
                        rtisAdded: !1
                    };
                return o && (n = { ...n,
                    apsRtisLiveRampCookieSync: o
                }, a.rtisAdded = !0), Object.keys(n).length > 0 && t.update(os, (t => t.set(e.bidRequestIndex, n))), {
                    status: s.completed,
                    analytics: a
                }
            }
        });
        const is = {
                key: "bidURL/slots",
                default: new Map,
                postProcessor: ni
            },
            ss = {
                key: "adExchangeBidRequests/slotIDs",
                default: new Set
            };
        var rs, cs, ds, ls;
        ! function(t) {
            t[t.Sponsored = 1] = "Sponsored", t[t.Desc = 2] = "Desc", t[t.Rating = 3] = "Rating", t[t.Likes = 4] = "Likes", t[t.Downloads = 5] = "Downloads", t[t.Price = 6] = "Price", t[t.SalePrice = 7] = "SalePrice", t[t.Phone = 8] = "Phone", t[t.Address = 9] = "Address", t[t.Desc2 = 10] = "Desc2", t[t.DisplayUrl = 11] = "DisplayUrl", t[t.CTAText = 12] = "CTAText", t[t.AmazonDealBadge = 507] = "AmazonDealBadge", t[t.AmazonCustomerReview = 508] = "AmazonCustomerReview", t[t.AmazonClimatePledge = 511] = "AmazonClimatePledge", t[t.AmazonCoupon = 512] = "AmazonCoupon"
        }(rs || (rs = {})),
        function(t) {
            t[t.Img = 1] = "Img", t[t.JS = 2] = "JS"
        }(cs || (cs = {})),
        function(t) {
            t[t.Impression = 1] = "Impression", t[t.ViewableMRC50 = 2] = "ViewableMRC50", t[t.ViewableMRC100 = 3] = "ViewableMRC100", t[t.ViewableVideo50 = 4] = "ViewableVideo50"
        }(ds || (ds = {})),
        function(t) {
            t[t.Icon = 1] = "Icon", t[t.Main = 3] = "Main", t[t.AmazonPrimeLogo = 512] = "AmazonPrimeLogo", t[t.AmazonBrandingLogo = 513] = "AmazonBrandingLogo"
        }(ls || (ls = {}));
        const us = (t, e) => t.some((t => t.event === e)),
            ps = {
                key: "gpid/activation",
                default: !0
            },
            ms = {
                key: "gpid/optOut",
                default: !1
            },
            fs = {
                key: "gpid/cache",
                default: new Map
            },
            hs = {
                key: "gpid/delimiter",
                default: "#"
            },
            vs = {
                context: tt,
                "context.googletag": st(tt),
                "context.googletag.pubads": st(rt),
                "context.googletag.pubads()": st(tt),
                "context.googletag.pubads().getSlots": st(rt),
                "context.googletag.pubads().getSlots()": st(ot),
                "context.googletag.pubads().getSlots()[]": st(tt),
                "context.googletag.pubads().getSlots()[].getAdUnitPath": st(rt),
                "context.googletag.pubads().getSlots()[].getSlotElementId": st(rt),
                "context.googletag.pubads().getSlots()[].getAdUnitPath()": st(Z),
                "context.googletag.pubads().getSlots()[].getSlotElementId()": st(Z)
            };
        var ys = new ut({
            scope: "gpid",
            object: "generation",
            action: "attempt",
            validators: {
                detail: {
                    detail: tt,
                    "detail.slotIds": ot,
                    "detail.slotIds[]": Z
                },
                context: vs
            },
            handler: async ({
                account: t,
                detail: e,
                context: n
            }) => {
                const o = t.use(ps),
                    a = t.use(ms);
                if (!o || a) return {
                    status: s.cancelled
                };
                const i = n.googletag ? .pubads ? .() ? .getSlots;
                if (!i) return {
                    status: s.cancelled
                };
                const r = t.use(hs),
                    c = t.use(fs),
                    d = i();
                return e.slotIds.forEach((e => {
                    if (c.has(e)) return;
                    const n = d.filter((t => t.getSlotElementId() === e || t.getAdUnitPath().includes(e)));
                    if (0 === n.length) return;
                    const o = n[0].getAdUnitPath();
                    let a;
                    if (1 === d.filter((t => t.getAdUnitPath() === o)).length) a = o;
                    else {
                        const t = n[0].getSlotElementId();
                        a = `${o}${r}${t}`
                    }
                    t.update(fs, (t => (t.set(e, a), t)))
                })), {
                    status: s.completed
                }
            }
        });
        const gs = {
            context: tt
        };
        var ws = new ut({
            scope: "gpid",
            object: "slots",
            action: "enhance",
            validators: {
                detail: {
                    detail: tt,
                    "detail.slots": ot,
                    "detail.slots[]": it(tt),
                    "detail.slots[].id": st(Z),
                    "detail.slots[].sd": st(Z),
                    "detail.slots[].ext": st(it(tt)),
                    "detail.slots[].ext.gpid": it(st(Z))
                },
                context: gs
            },
            handler: async ({
                account: t,
                detail: e
            }) => {
                const n = t.use(ps),
                    o = t.use(ms);
                if (!n || o) return {
                    status: s.cancelled
                };
                const a = t.use(fs),
                    i = [];
                e.slots.forEach((t => {
                    const e = t.id || t.sd;
                    e && (a.has(e) || i.push(e))
                })), i.length > 0 && t.recordListenerNonBlocking(ys, {
                    slotIds: i
                });
                const r = t.use(fs);
                return e.slots.forEach((t => {
                    const e = t.id || t.sd;
                    if (!e) return;
                    const n = r.get(e);
                    n && (t.ext || (t.ext = {}), t.ext.gpid = n)
                })), {
                    status: s.completed
                }
            }
        });
        const bs = {
            key: "gpid/mapping",
            default: {}
        };
        var Es, Ss, xs, _s, Rs, Is, As, ks, js, $s, Cs, Os, Ps, Ds, Ts, Ns, Ls, Ms, Us, qs;
        ! function(t) {
            t[t.VPAID_1_0 = 1] = "VPAID_1_0", t[t.VPAID_2_0 = 2] = "VPAID_2_0", t[t.MRAID_1_0 = 3] = "MRAID_1_0", t[t.ORMMA = 4] = "ORMMA", t[t.MRAID_2_0 = 5] = "MRAID_2_0", t[t.MRAID_3_0 = 6] = "MRAID_3_0", t[t.OMID_1_0 = 7] = "OMID_1_0", t[t.SIMID_1_0 = 8] = "SIMID_1_0", t[t.SIMID_1_1 = 9] = "SIMID_1_1"
        }(Es || (Es = {})),
        function(t) {
            t[t.VAST_1_0 = 1] = "VAST_1_0", t[t.VAST_2_0 = 2] = "VAST_2_0", t[t.VAST_3_0 = 3] = "VAST_3_0", t[t.VAST_1_0_WRAPPER = 4] = "VAST_1_0_WRAPPER", t[t.VAST_2_0_WRAPPER = 5] = "VAST_2_0_WRAPPER", t[t.VAST_3_0_WRAPPER = 6] = "VAST_3_0_WRAPPER", t[t.VAST_4_0 = 7] = "VAST_4_0", t[t.VAST_4_0_WRAPPER = 8] = "VAST_4_0_WRAPPER", t[t.DAAST_1_0 = 9] = "DAAST_1_0", t[t.DAAST_1_0_WRAPPER = 10] = "DAAST_1_0_WRAPPER", t[t.VAST_4_1 = 11] = "VAST_4_1", t[t.VAST_4_1_WRAPPER = 12] = "VAST_4_1_WRAPPER", t[t.VAST_4_2 = 13] = "VAST_4_2", t[t.VAST_4_2_WRAPPER = 14] = "VAST_4_2_WRAPPER", t[t.VAST_4_3 = 15] = "VAST_4_3", t[t.VAST_4_3_WRAPPER = 16] = "VAST_4_3_WRAPPER"
        }(Ss || (Ss = {})),
        function(t) {
            t[t.IABTechLabContentCategoryTaxonomy1_0 = 1] = "IABTechLabContentCategoryTaxonomy1_0", t[t.IABTechLabContentCategoryTaxonomy2_0 = 2] = "IABTechLabContentCategoryTaxonomy2_0", t[t.IABTechLabAdProductTaxonomy1_0 = 3] = "IABTechLabAdProductTaxonomy1_0", t[t.IABTechLabAudienceTaxonomy1_1 = 4] = "IABTechLabAudienceTaxonomy1_1", t[t.IABTechLabContentTaxonomy2_1 = 5] = "IABTechLabContentTaxonomy2_1", t[t.IABTechLabContentTaxonomy2_2 = 6] = "IABTechLabContentTaxonomy2_2", t[t.IABTechLabContentTaxonomy3_0 = 7] = "IABTechLabContentTaxonomy3_0", t[t.IABTechLabAdProductTaxonomy2_0 = 8] = "IABTechLabAdProductTaxonomy2_0"
        }(xs || (xs = {})),
        function(t) {
            t[t.NonClickable = 0] = "NonClickable", t[t.ClickableDetailsUnknown = 1] = "ClickableDetailsUnknown", t[t.ClickableEmbeddedBrowserOrWebview = 2] = "ClickableEmbeddedBrowserOrWebview", t[t.ClickableNativeBrowser = 3] = "ClickableNativeBrowser"
        }(_s || (_s = {})),
        function(t) {
            t[t.Static = 1] = "Static", t[t.HTML = 2] = "HTML", t[t.iFrame = 3] = "iFrame"
        }(Rs || (Rs = {})),
        function(t) {
            t[t.AudioAdAutoplay = 1] = "AudioAdAutoplay", t[t.AudioAdUserInitiated = 2] = "AudioAdUserInitiated", t[t.ExpandableAutomatic = 3] = "ExpandableAutomatic", t[t.ExpandableUserInitiatedClick = 4] = "ExpandableUserInitiatedClick", t[t.ExpandableUserInitiatedRollover = 5] = "ExpandableUserInitiatedRollover", t[t.InBannerVideoAdAutoplay = 6] = "InBannerVideoAdAutoplay", t[t.InBannerVideoAdUserInitiated = 7] = "InBannerVideoAdUserInitiated", t[t.Pop = 8] = "Pop", t[t.ProvocativeOrSuggestiveImagery = 9] = "ProvocativeOrSuggestiveImagery", t[t.ShakyFlashingFlickeringExtremeAnimationSmileys = 10] = "ShakyFlashingFlickeringExtremeAnimationSmileys", t[t.Surveys = 11] = "Surveys", t[t.TextOnly = 12] = "TextOnly", t[t.UserInteractive = 13] = "UserInteractive", t[t.WindowsDialogOrAlertStyle = 14] = "WindowsDialogOrAlertStyle", t[t.HasAudioOnOffButton = 15] = "HasAudioOnOffButton", t[t.AdProvidesSkipButton = 16] = "AdProvidesSkipButton", t[t.AdobeFlash = 17] = "AdobeFlash", t[t.Responsive = 18] = "Responsive"
        }(Is || (Is = {})),
        function(t) {
            t[t.Streaming = 1] = "Streaming", t[t.Progressive = 2] = "Progressive", t[t.Downloade = 3] = "Downloade"
        }(As || (As = {})),
        function(t) {
            t[t.ContentCentric = 10] = "ContentCentric", t[t.Article = 11] = "Article", t[t.Video = 12] = "Video", t[t.Audio = 13] = "Audio", t[t.Image = 14] = "Image", t[t.UserGenerated = 15] = "UserGenerated", t[t.Social = 20] = "Social", t[t.Email = 21] = "Email", t[t.Chat = 22] = "Chat", t[t.Product = 30] = "Product", t[t.Marketplace = 31] = "Marketplace", t[t.ProductReview = 32] = "ProductReview"
        }(ks || (ks = {})),
        function(t) {
            t[t.HTML = 1] = "HTML", t[t.AMPHTML = 2] = "AMPHTML", t[t.Image = 3] = "Image", t[t.Native = 4] = "Native"
        }(js || (js = {})),
        function(t) {
            t[t.InFeed = 1] = "InFeed", t[t.InAtomic = 2] = "InAtomic", t[t.Outside = 3] = "Outside", t[t.RecommendationWidget = 4] = "RecommendationWidget"
        }($s || ($s = {})),
        function(t) {
            t[t.Left = 1] = "Left", t[t.Right = 2] = "Right", t[t.Up = 3] = "Up", t[t.Down = 4] = "Down", t[t.FullScreen = 5] = "FullScreen", t[t.Resize = 6] = "Resize"
        }(Cs || (Cs = {})),
        function(t) {
            t[t.Linear = 1] = "Linear", t[t.NonLinear = 2] = "NonLinear"
        }(Os || (Os = {})),
        function(t) {
            t[t.Unknown = 0] = "Unknown", t[t.AboveTheFold = 1] = "AboveTheFold", t[t.Locked = 2] = "Locked", t[t.BelowTheFold = 3] = "BelowTheFold", t[t.Header = 4] = "Header", t[t.Footer = 5] = "Footer", t[t.Sidebar = 6] = "Sidebar", t[t.Fullscreen = 7] = "Fullscreen"
        }(Ps || (Ps = {})),
        function(t) {
            t[t.VideoCompletion = 1] = "VideoCompletion", t[t.LeavingViewport = 2] = "LeavingViewport", t[t.LeavingViewportContinues = 3] = "LeavingViewportContinues"
        }(Ds || (Ds = {})),
        function(t) {
            t[t.PageLoadSoundOn = 1] = "PageLoadSoundOn", t[t.PageLoadSoundOff = 2] = "PageLoadSoundOff", t[t.ClickSoundOn = 3] = "ClickSoundOn", t[t.MouseOverSoundOn = 4] = "MouseOverSoundOn", t[t.EnterViewportSoundOn = 5] = "EnterViewportSoundOn", t[t.EnterViewportSoundOff = 6] = "EnterViewportSoundOff", t[t.Continuous = 7] = "Continuous"
        }(Ts || (Ts = {})),
        function(t) {
            t[t.Last = -1] = "Last", t[t.Any = 0] = "Any", t[t.First = 1] = "First"
        }(Ns || (Ns = {})),
        function(t) {
            t[t.DIPS = 1] = "DIPS", t[t.Inches = 2] = "Inches", t[t.Centimeters = 3] = "Centimeters"
        }(Ls || (Ls = {})),
        function(t) {
            t[t.Last = -1] = "Last", t[t.Any = 0] = "Any", t[t.First = 1] = "First", t[t.FirstOrLast = 2] = "FirstOrLast"
        }(Ms || (Ms = {})),
        function(t) {
            t[t.InStream = 1] = "InStream", t[t.InBanner = 2] = "InBanner", t[t.InArticle = 3] = "InArticle", t[t.InFeed = 4] = "InFeed", t[t.Interstitial = 5] = "Interstitial"
        }(Us || (Us = {})),
        function(t) {
            t[t.Instream = 1] = "Instream", t[t.Accompanying = 2] = "Accompanying", t[t.Interstitial = 3] = "Interstitial", t[t.Standalone = 4] = "Standalone"
        }(qs || (qs = {}));
        const Vs = {
            key: "window/initialViewportHeight",
            default: void 0
        };
        var Fs = new ut({
            scope: "ad",
            object: "slotPos",
            action: "detect",
            validators: {
                detail: {
                    detail: tt,
                    "detail.slotIds": ot,
                    "detail.slotIds[]": Z
                },
                context: {
                    context: tt,
                    "context.document": t => {
                        if (!t || 9 !== t.nodeType) throw new Error("must be a Document");
                        return {
                            verifiable: !1
                        }
                    },
                    "context.window": tt,
                    "context.window.scrollY": Y
                }
            },
            handler: async ({
                account: t,
                detail: e,
                context: n
            }) => {
                if (0 === e.slotIds.length) return {
                    status: s.cancelled,
                    analytics: {
                        reason: "no_slots_provided"
                    }
                };
                const o = t.use(Vs);
                if (void 0 === o) return {
                    status: s.cancelled,
                    analytics: {
                        reason: "viewport_height_not_captured"
                    }
                };
                const a = t.use(si);
                let i = 0,
                    r = 0;
                const c = new Set,
                    d = {},
                    l = new Map;
                e.slotIds.forEach((t => {
                    const e = a.get(t);
                    if (!e) {
                        const e = "slot_not_found";
                        return c.add(e), void(d[t] = e)
                    }
                    if (!zs(e)) return void i++;
                    const s = n.document.getElementById(t);
                    if (!s) {
                        const e = "dom_element_not_found";
                        return c.add(e), void(d[t] = e)
                    }
                    const u = s.getBoundingClientRect().top + n.window.scrollY < o ? Ps.AboveTheFold : Ps.BelowTheFold,
                        p = Js(e, u);
                    if (p) l.set(t, p), r++;
                    else {
                        const e = "no_fields_to_update";
                        c.add(e), d[t] = e
                    }
                })), l.size > 0 && t.update(si, (t => (l.forEach(((e, n) => {
                    t = t.set(n, e)
                })), t)));
                const u = Object.keys(d).length,
                    p = c.size > 0 ? Array.from(c) : null,
                    m = Object.keys(d).length > 0 ? d : null;
                return {
                    status: s.completed,
                    analytics: {
                        slots: {
                            successCount: r,
                            failureCount: u,
                            skippedCount: i,
                            failureReasons: p,
                            failedSlots: m
                        }
                    }
                }
            }
        });
        const Bs = t => void 0 !== t && (void 0 === t.pos || t.pos === Ps.Unknown),
            zs = t => Bs(t.banner) || Bs(t.video),
            Js = (t, e) => {
                const n = {};
                return Bs(t.banner) && (n.banner = { ...t.banner,
                    pos: e
                }), Bs(t.video) && (n.video = { ...t.video,
                    pos: e
                }), Object.keys(n).length > 0 ? { ...t,
                    ...n
                } : null
            };
        var Hs = new ut({
            scope: "bidURL",
            object: "slots",
            action: "update",
            validators: {
                detail: {
                    detail: tt,
                    "detail.bidRequestIndex": Z,
                    "detail.slots": st(Z)
                }
            },
            handler: async ({
                account: t,
                detail: e
            }) => {
                let n = [];
                if (void 0 !== e.slots && (n = JSON.parse(e.slots)), !Array.isArray(n)) throw new Error(`Unexpected value for search param slots: ${JSON.stringify(n)}`);
                t.recordListenerNonBlocking(ws, {
                    slots: n
                });
                const o = n.flatMap((t => {
                    const e = t.sd || t.id;
                    return e ? [e] : []
                }));
                return o.length > 0 && t.recordListenerNonBlocking(Fs, {
                    slotIds: o
                }), n.forEach((e => {
                    Gs(t, e), Ks(t, e), Ws(t, e), e.native = ((t, e) => {
                        const n = e.sd || e.id;
                        if (!n) return;
                        const o = t.use(si).get(n);
                        return o && o.native ? (o.native.request.eventtrackers = (t => {
                            const e = t.request.eventtrackers ? ? [];
                            return us(e, ds.Impression) || e.push({
                                event: ds.Impression,
                                methods: [cs.Img, cs.JS]
                            }), us(e, ds.ViewableMRC50) || e.push({
                                event: ds.ViewableMRC50,
                                methods: [cs.Img, cs.JS]
                            }), e
                        })(o.native), o.native) : void 0
                    })(t, e)
                })), n.length > 0 && t.update(is, (t => t.set(e.bidRequestIndex, n))), {
                    status: s.completed
                }
            }
        });
        const Gs = (t, e) => {
                const n = e.sd || e.id;
                n && t.update(ss, (t => t.add(n)))
            },
            Ks = (t, e) => {
                const n = t.use(si);
                if (void 0 === e.id && void 0 === e.sd) return;
                const o = n.get(e.id ? ? "") ? ? n.get(e.sd ? ? "");
                if (!o) return;
                const {
                    banner: a,
                    video: i
                } = o;
                if ("object" == typeof a && void 0 !== a.pos && (e.banner = {
                        pos: a.pos
                    }), "object" == typeof i) {
                    const {
                        pos: t,
                        startdelay: n,
                        plcmt: o,
                        placement: a
                    } = i;
                    void 0 !== t && (e.video = e.video ? ? {}, e.video.pos = t), void 0 !== n && (e.video = e.video ? ? {}, e.video.startdelay = n), void 0 !== o && (e.video = e.video ? ? {}, e.video.plcmt = o), void 0 !== a && (e.video = e.video ? ? {}, e.video.placement = a)
                }
            },
            Ws = (t, e) => {
                const n = t.use(bs);
                if (void 0 === e.id && void 0 === e.sd) return;
                const o = n[e.id ? ? e.sd ? ? ""];
                o && (e.ext = e.ext ? ? {}, e.ext.gpid = o)
            },
            Qs = {
                key: "adExchangeBidFetching/bidURLs",
                default: new Map,
                postProcessor: ni
            },
            Ys = {
                key: "regulations/regsString",
                default: ""
            },
            Zs = {
                key: "regulations/dsa",
                default: void 0
            };
        var Xs;
        ! function(t) {
            t[t.CHILD = 1] = "CHILD", t[t.TEEN = 2] = "TEEN", t[t.ADULT = 3] = "ADULT", t[t.UNKNOWN = 0] = "UNKNOWN"
        }(Xs || (Xs = {}));
        const tr = {
            key: "regulations/agerange",
            default: void 0
        };
        var er = new ut({
                scope: "regulations",
                object: "regsString",
                action: "update",
                handler: async ({
                    account: t
                }) => {
                    const e = {},
                        n = t.use(Zs),
                        o = t.use(tr);
                    return null != n && (e.dsa = n), null != o && (e.ext = e.ext ? ? {}, e.ext.agerange = o), t.update(Ys, (() => Object.keys(e).length > 0 ? JSON.stringify(e) : "")), {
                        status: s.completed
                    }
                }
            }),
            nr = new ut({
                scope: "adExchangeBidFetching",
                object: "bidURLs",
                action: "update",
                handler: async ({
                    account: t,
                    customEvent: e
                }) => {
                    if (void 0 === e.detail || void 0 === e.detail.legacyURL) throw new Error("Missing legacyURL");
                    const n = e.detail ? .bidRequestIndex,
                        o = new URL(e.detail.legacyURL);
                    t.recordListenerNonBlocking(er);
                    const a = t.use(Ys);
                    a.length > 0 && o.searchParams.set("regs", a), o.searchParams.set("rt", "j"), t.recordListenerNonBlocking(Hs, {
                        bidRequestIndex: n,
                        slots: o.searchParams.get("slots") ? ? void 0
                    });
                    const i = t.use(is).get(n);
                    null != i && o.searchParams.set("slots", JSON.stringify(i)), t.recordListenerNonBlocking(as, {
                        bidRequestIndex: n,
                        pj: o.searchParams.get("pj") ? ? void 0
                    });
                    const r = t.use(os).get(n);
                    null != r && o.searchParams.set("pj", JSON.stringify(r));
                    const c = o.toString();
                    t.update(Qs, (t => {
                        if (void 0 === e.detail || void 0 === n) throw new Error("Missing bidRequestIndex");
                        return t.set(e.detail.bidRequestIndex, c)
                    }));
                    let d = {
                        urlLength: c.length
                    };
                    const l = function(t) {
                        const e = {};
                        try {
                            const n = new URL(t);
                            return [...new URLSearchParams(n.search)].forEach((([t, n]) => {
                                e[t] = n.length
                            })), e
                        } catch (t) {}
                    }(c);
                    return void 0 !== l && (d = { ...d,
                        urlParamLengths: l
                    }), {
                        status: s.completed,
                        analytics: d
                    }
                }
            });
        const or = {
            key: "amazonAdExchange/basePostUrl",
            default: "https://aax.amazon-adsystem.com/e/dtb/bid"
        };
        var ar = new ut({
            scope: "adExchangeBidFetching",
            object: "amazonAdExchange",
            action: "post",
            validators: {
                detail: {
                    detail: tt,
                    "detail.requestBody": Z
                },
                context: {
                    context: tt,
                    "context.fetch": rt,
                    "context.fetch()": tt,
                    "context.fetch().ok": X,
                    "context.fetch().then": rt,
                    "context.fetch().then()": dt,
                    ...pn
                }
            },
            handler: async ({
                account: t,
                context: e,
                detail: n
            }) => {
                const o = t.use(or),
                    a = await e.fetch(o, {
                        method: "POST",
                        credentials: "include",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: n.requestBody
                    });
                if (!a.ok) throw new Error(`Fetch failed with status: ${a.status}`);
                const i = a.status,
                    r = a.statusText,
                    c = a.type,
                    d = await a.json(),
                    {
                        contextual: l
                    } = d;
                return void 0 !== l && (t.recordListenerNonBlocking(Di, {
                    aaxResp: l
                }), e.apstag.bids(l)), {
                    status: s.completed,
                    analytics: {
                        statusCode: i,
                        statusText: r,
                        responseType: c
                    }
                }
            }
        });
        const ir = {
                key: "a3pesBanner/isActivated",
                default: !0
            },
            sr = {
                key: "a3pesVideo/isActivated",
                default: !0
            },
            rr = {
                key: "bidResponses/slotIDs",
                default: new Set
            },
            cr = {
                key: "bidRequest/sampleRate",
                default: 1
            },
            dr = {
                key: "bidRequest/sampleRateOverride",
                default: void 0
            },
            lr = {
                key: "tid/isEnabled",
                default: !1
            };
        var ur = new ut({
            scope: "adExchange",
            object: "bid",
            action: "fetch",
            validators: {
                detail: {
                    detail: tt,
                    "detail.URL": Z,
                    "detail.fetchBidsConfig": st(tt),
                    "detail.fetchBidsConfig.tid": st(Z),
                    "detail.fetchBidsConfig.slots": st(ot),
                    "detail.fetchBidsConfig.slots[]": tt,
                    "detail.fetchBidsConfig.slots[].slotID": st(Z),
                    "detail.fetchBidsConfig.slots[].tid": st(Z)
                },
                context: {
                    context: tt,
                    "context.crypto": st(tt),
                    "context.crypto.randomUUID": st(rt),
                    "context.crypto.randomUUID()": st(Z)
                }
            },
            handler: async ({
                account: t,
                detail: e,
                context: n
            }) => {
                if (t.recordListenerNonBlocking(ns), t.use(es)) return {
                    status: s.cancelled
                };
                const o = t.use(cr),
                    a = t.use(dr),
                    i = a ? ? o;
                if (Math.random() >= i) return {
                    status: s.cancelled,
                    analytics: {
                        sampleRate: o,
                        sampleRateOverride: a
                    }
                };
                const r = new URL(e.URL).searchParams.get("cb") || "unknown";
                await t.recordListener(nr, {
                    legacyURL: e.URL,
                    bidRequestIndex: r
                });
                const c = t.use(Qs).get(r);
                if (!c) throw new Error("Missing URL for provided bid request index");
                const d = (t => {
                    const e = new URL(t),
                        n = Array.from(e.searchParams.entries()),
                        o = {};
                    return n.forEach((([t, e]) => {
                        try {
                            o[t] = JSON.parse(e)
                        } catch (n) {
                            o[t] = e
                        }
                    })), o
                })(c);
                let l;
                t.use(lr) && (l = {
                    requestTid: mr(d, {
                        providedTid: e.fetchBidsConfig ? .tid,
                        crypto: n.crypto
                    }),
                    slotTid: fr(d.slots, {
                        configSlots: e.fetchBidsConfig ? .slots,
                        crypto: n.crypto
                    })
                });
                const u = d.slots,
                    p = JSON.stringify(d),
                    m = t.use(Ci),
                    f = t.use(ir),
                    h = t.use(sr),
                    v = !m && h;
                let y = "AAX";
                !m && f && zi(u, Mi.DISPLAY) ? (y = "3PES", await t.recordListener(Ui, {
                    requestBody: p,
                    slotType: "banner"
                })) : v && zi(u, Mi.VIDEO) ? (y = "3PES", await t.recordListener(Ui, {
                    requestBody: p,
                    slotType: "video"
                })) : v && zi(u, Mi.VIDEO, Mi.DISPLAY) ? (y = "3PES", await t.recordListener(Ui, {
                    requestBody: p,
                    slotType: "banner+video"
                })) : await t.recordListener(ar, {
                    requestBody: p
                }), (t => {
                    const e = new Set;
                    return t ? .forEach((t => {
                        const n = Ji(t);
                        n && e.add(n)
                    })), e
                })(u).forEach((e => {
                    t.update(rr, (t => t.add(e)))
                }));
                const g = hr(u);
                return {
                    status: s.completed,
                    analytics: {
                        sampleRate: o,
                        sampleRateOverride: a,
                        adExchange: y,
                        slotMetadata: g,
                        tidMetadata: l
                    }
                }
            }
        });
        const pr = t => {
                try {
                    const e = t ? .randomUUID();
                    return e && 36 === e.length ? e : void 0
                } catch (t) {
                    return
                }
            },
            mr = (t, e) => {
                const {
                    providedTid: n,
                    crypto: o
                } = e;
                let a = n,
                    i = "provided";
                return a || (a = pr(o), i = a ? "autogenerated" : "failed"), a && (t.source = t.source || {}, t.source.tid = a), i
            },
            fr = (t, e) => {
                const {
                    configSlots: n,
                    crypto: o
                } = e;
                if (!(void 0 !== (a = n) && a.length > 0 && "slotID" in a[0])) return "unsupported";
                var a;
                const i = new Map;
                n.forEach((t => {
                    t.tid && i.set(t.slotID, t.tid)
                }));
                let s = 0,
                    r = 0;
                return t.forEach((t => {
                    const e = Ji(t);
                    if (!e) return;
                    let n = i.get(e);
                    n || (n = pr(o), n ? s++ : r++), n && (t.ext = t.ext || {}, t.ext.tid = n)
                })), r > 0 ? "failed" : 0 === s ? "all-provided" : 0 === i.size ? "all-autogenerated" : "partial"
            },
            hr = t => {
                const e = {
                        display: 0,
                        video: 0,
                        native: 0,
                        multiFormat: 0,
                        unknown: 0,
                        total: t.length
                    },
                    n = new Set;
                t.forEach((t => {
                    qi(t) ? (e.display++, n.add("display")) : Vi(t) ? (e.video++, n.add("video")) : (t => void 0 !== t.native)(t) ? (e.native++, n.add("native")) : Fi(t) ? (e.multiFormat++, n.add("multiFormat")) : (e.unknown++, n.add("unknown"))
                }));
                const o = Array.from(n).sort(),
                    a = o.join("+");
                return {
                    typesPresent: o,
                    combinationKey: a,
                    counts: e
                }
            };
        var vr = new ut({
                scope: "bidRequest",
                object: "sampleRate",
                action: "set",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.rate": et({
                            min: 0,
                            max: 1
                        })
                    },
                    context: {
                        context: tt
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => (t.update(cr, (() => e.rate)), {
                    status: s.completed
                })
            }),
            yr = new ut({
                scope: "bidRequest",
                object: "sampleRateOverride",
                action: "set",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.rate": et({
                            min: 0,
                            max: 1
                        })
                    },
                    context: {
                        context: tt
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => (t.update(dr, (() => e.rate)), {
                    status: s.completed
                })
            }),
            gr = new ut({
                scope: "a3pes",
                object: "banner",
                action: "deactivate",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.bypassCountryCheck": st(X)
                    },
                    context: {
                        context: tt
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => {
                    const n = t.use(ft);
                    return e.bypassCountryCheck || "US" !== n ? (t.update(ir, (() => !1)), {
                        status: s.completed
                    }) : {
                        status: s.cancelled
                    }
                }
            }),
            wr = new ut({
                scope: "a3pes",
                object: "video",
                action: "deactivate",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.bypassCountryCheck": st(X)
                    },
                    context: {
                        context: tt
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => {
                    const n = t.use(ft);
                    return e.bypassCountryCheck || "US" !== n ? (t.update(sr, (() => !1)), {
                        status: s.completed
                    }) : {
                        status: s.cancelled
                    }
                }
            }),
            br = new ut({
                scope: "a3pes",
                object: "mockBidder",
                action: "set",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.id": Z,
                        "detail.url": Z
                    },
                    context: {
                        context: tt
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => (t.update(Li, (() => ({
                    id: e.id,
                    url: e.url
                }))), {
                    status: s.completed
                })
            });
        const Er = pt([Oi, Ui, br, ur, ar, nr, Di, vr, yr, as, Hs, gr, wr]);
        var Sr = new ut({
            scope: "cellophane",
            object: "xhrBidOnLoad",
            action: "enter",
            handler: async () => ({
                status: s.completed
            })
        });
        const xr = t => {
                const e = {
                    id: t.slotID,
                    tagid: t.slotName,
                    bidfloor: t.floor ? .value,
                    bidfloorcur: t.floor ? .currency,
                    ext: { ...t.slotParams
                    }
                };
                switch (t.mediaType) {
                    case Pa.MultiFormat:
                        e.video = Rr({
                            sizes: t.multiFormatProperties ? .video ? .sizes ? ? [],
                            companions: t.companions ? ? []
                        }), e.banner = Ir({
                            sizes: t.multiFormatProperties ? .display ? .sizes ? ? []
                        });
                        break;
                    case Pa.Video:
                        e.video = Rr({
                            sizes: t.sizes ? ? [],
                            companions: t.companions ? ? []
                        });
                        break;
                    default:
                        e.banner = Ir({
                            sizes: t.sizes ? ? []
                        })
                }
                return e
            },
            _r = t => t.filter((t => Array.isArray(t) && t.every((t => "number" == typeof t)))).map((([t, e]) => ({
                w: t,
                h: e
            }))),
            Rr = t => {
                const e = {
                        mimes: []
                    },
                    n = _r(t.sizes);
                if (n.length > 0 && (e.w = n[0].w, e.h = n[0].h), t.companions.length > 0) {
                    const n = [];
                    t.companions.forEach((t => {
                        const e = {
                            id: t
                        };
                        n.push(e)
                    })), e.companionad = n
                }
                return e
            },
            Ir = t => {
                const e = {},
                    n = _r(t.sizes);
                if (n.length > 0) {
                    e.w = n[0].w, e.h = n[0].h;
                    const t = [];
                    n.forEach((e => {
                        t.push({
                            w: e.w,
                            h: e.h
                        })
                    })), e.format = t
                }
                return e
            },
            Ar = t => {
                const e = kr({
                        display: t.spec.placement.display
                    }),
                    n = $r({
                        video: t.spec.placement.video
                    });
                return {
                    id: t.id,
                    banner: e,
                    video: n,
                    displaymanager: t.spec.placement.sdk,
                    displaymanagerver: t.spec.placement.sdkver,
                    instl: t.spec.placement.display ? .instl,
                    tagid: t.spec.placement.tagid,
                    bidfloor: t.flr,
                    bidfloorcur: t.flrcur,
                    secure: t.spec.placement.secure,
                    iframebuster: t.spec.placement.display ? .ifrbust,
                    rwdd: t.spec.placement.reward,
                    ssai: t.spec.placement.ssai,
                    exp: t.exp,
                    dt: t.dt,
                    ext: { ...t.ext,
                        ...t.spec.placement.ext
                    }
                }
            },
            kr = t => {
                if (void 0 !== t.display) return {
                    format: jr({
                        displayFmt: t.display.displayfmt
                    }),
                    w: t.display.w,
                    h: t.display.h,
                    pos: t.display.pos,
                    mimes: t.display.mime,
                    topframe: t.display.topframe,
                    api: t.display.api,
                    ext: t.display.ext
                }
            },
            jr = t => {
                if (void 0 === t.displayFmt || 0 === t.displayFmt.length) return;
                const e = [];
                return t.displayFmt.forEach((t => {
                    e.push({
                        w: t.w,
                        h: t.h,
                        wratio: t.wratio,
                        hratio: t.hratio,
                        ext: t.ext
                    })
                })), e
            },
            $r = t => {
                if (void 0 === t.video) return;
                const e = {
                    mimes: t.video.mime,
                    minduration: t.video.mindur,
                    maxduration: t.video.maxdur,
                    startdelay: t.video.delay,
                    maxseq: t.video.maxseq,
                    poddur: t.video.poddur,
                    protocols: t.video.ctype,
                    w: t.video.w,
                    h: t.video.h,
                    podid: t.video.podid ? `${t.video.podid}` : void 0,
                    podseq: t.video.podseq,
                    rqddurs: t.video.rqddurs,
                    plcmt: t.video.ptype,
                    linearity: t.video.linear,
                    skip: t.video.skip,
                    skipmin: t.video.skipmin,
                    skipafter: t.video.skipafter,
                    slotinpod: t.video.slotinpod,
                    mincpmpersec: t.video.mincpmpersec,
                    maxextended: t.video.maxext,
                    minbitrate: t.video.minbitr,
                    maxbitrate: t.video.maxbitr,
                    boxingallowed: t.video.boxing,
                    playbackmethod: t.video.playmethod,
                    playbackend: t.video.playend,
                    delivery: t.video.delivery,
                    pos: t.video.pos,
                    api: t.video.api,
                    ext: t.video.ext
                };
                if (void 0 !== t.video.comp && t.video.comp.length > 0) {
                    const n = t.video.comp.map((t => ({
                        id: t.id
                    })));
                    e.companionad = n
                }
                return e
            },
            Cr = {
                "detail.slots": st(ot),
                "detail.slots[]": st(tt),
                "detail.slots[].slotID": Z,
                "detail.slots[].slotName": st(Z),
                "detail.slots[].sizes": st(ot),
                "detail.slots[].sizes[]": null,
                "detail.slots[].mediaType": st(at([Pa.Display, Pa.Video, Pa.MultiFormat])),
                "detail.slots[].slotParams": dt,
                "detail.slots[].floor": st(tt),
                "detail.slots[].floor.currency": at(["USD"]),
                "detail.slots[].floor.value": Y,
                "detail.slots[].multiFormatProperties": st(tt),
                "detail.slots[].multiFormatProperties.display": st(tt),
                "detail.slots[].multiFormatProperties.display.sizes": st(ot),
                "detail.slots[].multiFormatProperties.display.sizes[]": ot,
                "detail.slots[].multiFormatProperties.display.sizes[][]": Y,
                "detail.slots[].multiFormatProperties.video": st(tt),
                "detail.slots[].multiFormatProperties.video.sizes": st(ot),
                "detail.slots[].multiFormatProperties.video.sizes[]": ot,
                "detail.slots[].multiFormatProperties.video.sizes[][]": Y,
                "detail.slots[].companions": st(ot),
                "detail.slots[].companions[]": Z
            },
            Or = t => ({
                [`${t}.banner`]: st(tt),
                [`${t}.banner.format`]: st(ot),
                [`${t}.banner.format[]`]: tt,
                [`${t}.banner.format[].w`]: st(Y),
                [`${t}.banner.format[].h`]: st(Y),
                [`${t}.banner.format[].wratio`]: st(Y),
                [`${t}.banner.format[].hratio`]: st(Y),
                [`${t}.banner.format[].wmin`]: st(Y),
                [`${t}.banner.format[].ext`]: dt,
                [`${t}.banner.w`]: st(Y),
                [`${t}.banner.h`]: st(Y),
                [`${t}.banner.btype`]: st(ot),
                [`${t}.banner.btype[]`]: Y,
                [`${t}.banner.battr`]: st(ot),
                [`${t}.banner.battr[]`]: at(Object.values(Is)),
                [`${t}.banner.pos`]: st(at(Object.values(Ps))),
                [`${t}.banner.mimes`]: st(ot),
                [`${t}.banner.mimes[]`]: Z,
                [`${t}.banner.topframe`]: st(Y),
                [`${t}.banner.expdir`]: st(ot),
                [`${t}.banner.expdir[]`]: at(Object.values(Cs)),
                [`${t}.banner.api`]: st(ot),
                [`${t}.banner.api[]`]: at(Object.values(Es)),
                [`${t}.banner.id`]: st(Z),
                [`${t}.banner.vcm`]: st(Y),
                [`${t}.banner.ext`]: dt
            }),
            Pr = {
                "detail.imp": st(ot),
                "detail.imp[]": tt,
                "detail.imp[].id": Z,
                ...Or("detail.imp[]"),
                "detail.imp[].video": st(tt),
                "detail.imp[].video.mimes": ot,
                "detail.imp[].video.mimes[]": Z,
                "detail.imp[].video.minduration": st(Y),
                "detail.imp[].video.maxduration": st(Y),
                "detail.imp[].video.startdelay": st(Y),
                "detail.imp[].video.maxseq": st(Y),
                "detail.imp[].video.poddur": st(Y),
                "detail.imp[].video.protocols": st(ot),
                "detail.imp[].video.protocols[]": at(Object.values(Ss)),
                "detail.imp[].video.w": st(Y),
                "detail.imp[].video.h": st(Y),
                "detail.imp[].video.podid": st(Z),
                "detail.imp[].video.podseq": st(at(Object.values(Ns))),
                "detail.imp[].video.rqddurs": st(ot),
                "detail.imp[].video.rqddurs[]": Y,
                "detail.imp[].video.placement": st(Y),
                "detail.imp[].video.plcmt": st(at(Object.values(qs))),
                "detail.imp[].video.linearity": st(at(Object.values(Os))),
                "detail.imp[].video.skip": st(Y),
                "detail.imp[].video.skipmin": st(Y),
                "detail.imp[].video.skipafter": st(Y),
                "detail.imp[].video.sequence": st(Y),
                "detail.imp[].video.slotinpod": st(Y),
                "detail.imp[].video.mincpmpersec": st(Y),
                "detail.imp[].video.battr": st(ot),
                "detail.imp[].video.battr[]": at(Object.values(Is)),
                "detail.imp[].video.maxextended": st(Y),
                "detail.imp[].video.minbitrate": st(Y),
                "detail.imp[].video.maxbitrate": st(Y),
                "detail.imp[].video.boxingallowed": st(Y),
                "detail.imp[].video.playbackmethod": st(ot),
                "detail.imp[].video.playbackmethod[]": at(Object.values(Ts)),
                "detail.imp[].video.playbackend": st(at(Object.values(Ds))),
                "detail.imp[].video.delivery": st(ot),
                "detail.imp[].video.delivery[]": at(Object.values(As)),
                "detail.imp[].video.pos": st(at(Object.values(Ps))),
                "detail.imp[].video.companionad": st(ot),
                "detail.imp[].video.companionad[]": tt,
                ...Or("detail.imp[].video.companionad[]"),
                "detail.imp[].video.ext": dt,
                "detail.imp[].native": st(tt),
                "detail.imp[].native.request": it(tt),
                "detail.imp[].native.request.ver": st(Z),
                "detail.imp[].native.request.context": st(Y),
                "detail.imp[].native.request.contextsubtype": st(Y),
                "detail.imp[].native.request.plcmttype": st(Y),
                "detail.imp[].native.request.plcmtcnt": st(Y),
                "detail.imp[].native.request.seq": st(Y),
                "detail.imp[].native.request.assets": ot,
                "detail.imp[].native.request.assets[]": tt,
                "detail.imp[].native.request.assets[].id": Y,
                "detail.imp[].native.request.assets[].required": st(Y),
                "detail.imp[].native.request.assets[].title": st(tt),
                "detail.imp[].native.request.assets[].title.len": Y,
                "detail.imp[].native.request.assets[].title.ext": dt,
                "detail.imp[].native.request.assets[].img": st(tt),
                "detail.imp[].native.request.assets[].img.type": st(Y),
                "detail.imp[].native.request.assets[].img.w": st(Y),
                "detail.imp[].native.request.assets[].img.wmin": st(Y),
                "detail.imp[].native.request.assets[].img.h": st(Y),
                "detail.imp[].native.request.assets[].img.hmin": st(Y),
                "detail.imp[].native.request.assets[].img.mimes": st(ot),
                "detail.imp[].native.request.assets[].img.mimes[]": Z,
                "detail.imp[].native.request.assets[].img.ext": dt,
                "detail.imp[].native.request.assets[].data": st(tt),
                "detail.imp[].native.request.assets[].data.type": Y,
                "detail.imp[].native.request.assets[].data.len": st(Y),
                "detail.imp[].native.request.assets[].data.ext": dt,
                "detail.imp[].native.request.assets[].ext": dt,
                "detail.imp[].native.request.aurlsupport": st(Y),
                "detail.imp[].native.request.durlsupport": st(Y),
                "detail.imp[].native.request.eventtrackers": st(ot),
                "detail.imp[].native.request.eventtrackers[]": tt,
                "detail.imp[].native.request.eventtrackers[].event": Y,
                "detail.imp[].native.request.eventtrackers[].methods": ot,
                "detail.imp[].native.request.eventtrackers[].methods[]": Y,
                "detail.imp[].native.request.eventtrackers[].ext": dt,
                "detail.imp[].native.request.privacy": st(Y),
                "detail.imp[].native.request.ext": dt,
                "detail.imp[].native.ver": st(Z),
                "detail.imp[].native.api": st(ot),
                "detail.imp[].native.api[]": Y,
                "detail.imp[].native.battr": st(ot),
                "detail.imp[].native.battr[]": Y,
                "detail.imp[].native.ext": dt,
                "detail.imp[].displaymanager": st(Z),
                "detail.imp[].displaymanagerver": st(Z),
                "detail.imp[].instl": st(Y),
                "detail.imp[].tagid": st(Z),
                "detail.imp[].bidfloor": st(Y),
                "detail.imp[].bidfloorcur": st(Z),
                "detail.imp[].clickbrowser": st(Y),
                "detail.imp[].secure": st(Y),
                "detail.imp[].iframebuster": st(ot),
                "detail.imp[].iframebuster[]": Z,
                "detail.imp[].rwdd": st(Y),
                "detail.imp[].ssai": st(Y),
                "detail.imp[].exp": st(Y),
                "detail.imp[].dt": st(Y),
                "detail.imp[].ext": dt
            },
            Dr = {
                "detail.item": st(ot),
                "detail.item[]": st(tt),
                "detail.item[].version": st(Z),
                "detail.item[].id": Z,
                "detail.item[].qty": st(Y),
                "detail.item[].qtyflt": st(Y),
                "detail.item[].seq": st(Y),
                "detail.item[].flr": st(Y),
                "detail.item[].flrcur": st(Z),
                "detail.item[].exp": st(Y),
                "detail.item[].dt": st(Y),
                "detail.item[].dlvy": st(Y),
                "detail.item[].deal": st(ot),
                "detail.item[].deal[]": st(tt),
                "detail.item[].deal[].id": st(Z),
                "detail.item[].private": st(Y),
                "detail.item[].spec": tt,
                "detail.item[].spec.placement": tt,
                "detail.item[].spec.placement.tagid": st(Z),
                "detail.item[].spec.placement.ssai": st(Y),
                "detail.item[].spec.placement.sdk": st(Z),
                "detail.item[].spec.placement.sdkver": st(Z),
                "detail.item[].spec.placement.reward": st(Z),
                "detail.item[].spec.placement.wlang": st(ot),
                "detail.item[].spec.placement.wlang[]": Z,
                "detail.item[].spec.placement.secure": st(Y),
                "detail.item[].spec.placement.admx": st(Y),
                "detail.item[].spec.placement.curlx": st(Y),
                "detail.item[].spec.placement.display": st(tt),
                "detail.item[].spec.placement.display.pos": st(Y),
                "detail.item[].spec.placement.display.instl": st(Y),
                "detail.item[].spec.placement.display.topframe": st(Y),
                "detail.item[].spec.placement.display.ifrbust": st(ot),
                "detail.item[].spec.placement.display.ifrbust[]": Z,
                "detail.item[].spec.placement.display.clktype": st(at(Object.values(_s))),
                "detail.item[].spec.placement.display.ampren": st(Y),
                "detail.item[].spec.placement.display.ptype": st(at(Object.values($s))),
                "detail.item[].spec.placement.display.context": st(at(Object.values(ks))),
                "detail.item[].spec.placement.display.mime": st(ot),
                "detail.item[].spec.placement.display.mime[]": Z,
                "detail.item[].spec.placement.display.api": st(ot),
                "detail.item[].spec.placement.display.api[]": at(Object.values(Es)),
                "detail.item[].spec.placement.display.ctype": st(ot),
                "detail.item[].spec.placement.display.ctype[]": at(Object.values(js)),
                "detail.item[].spec.placement.display.w": st(Y),
                "detail.item[].spec.placement.display.h": st(Y),
                "detail.item[].spec.placement.display.unit": st(at(Object.values(Ls))),
                "detail.item[].spec.placement.display.priv": st(Y),
                "detail.item[].spec.placement.display.displayfmt": st(ot),
                "detail.item[].spec.placement.display.displayfmt[]": st(tt),
                "detail.item[].spec.placement.display.displayfmt[].w": st(Y),
                "detail.item[].spec.placement.display.displayfmt[].h": st(Y),
                "detail.item[].spec.placement.display.displayfmt[].wratio": st(Y),
                "detail.item[].spec.placement.display.displayfmt[].hratio": st(Y),
                "detail.item[].spec.placement.display.displayfmt[].expdir": st(ot),
                "detail.item[].spec.placement.display.displayfmt[].expdir[]": at(Object.values(Cs)),
                "detail.item[].spec.placement.display.displayfmt[].ext": dt,
                "detail.item[].spec.placement.display.ext": dt,
                "detail.item[].spec.placement.video": st(tt),
                "detail.item[].spec.placement.video.ptype": st(Y),
                "detail.item[].spec.placement.video.pos": st(Y),
                "detail.item[].spec.placement.video.delay": st(Y),
                "detail.item[].spec.placement.video.skip": st(Y),
                "detail.item[].spec.placement.video.skipmin": st(Y),
                "detail.item[].spec.placement.video.skipafter": st(Y),
                "detail.item[].spec.placement.video.playmethod": st(at(Object.values(Ts))),
                "detail.item[].spec.placement.video.playend": st(at(Object.values(Ds))),
                "detail.item[].spec.placement.video.clktype": st(at(Object.values(_s))),
                "detail.item[].spec.placement.video.mime": st(ot),
                "detail.item[].spec.placement.video.mime[]": Z,
                "detail.item[].spec.placement.video.api": st(ot),
                "detail.item[].spec.placement.video.api[]": at(Object.values(Es)),
                "detail.item[].spec.placement.video.ctype": st(at(Object.values(Ss))),
                "detail.item[].spec.placement.video.w": st(Y),
                "detail.item[].spec.placement.video.h": st(Y),
                "detail.item[].spec.placement.video.unit": st(at(Object.values(Ls))),
                "detail.item[].spec.placement.video.mindur": st(Y),
                "detail.item[].spec.placement.video.maxdur": st(Y),
                "detail.item[].spec.placement.video.rqddurs": st(ot),
                "detail.item[].spec.placement.video.rqddurs[]": Y,
                "detail.item[].spec.placement.video.maxext": st(Y),
                "detail.item[].spec.placement.video.minbitr": st(Y),
                "detail.item[].spec.placement.video.maxbitr": st(Y),
                "detail.item[].spec.placement.video.delivery": st(at(Object.values(As))),
                "detail.item[].spec.placement.video.maxseq": st(Y),
                "detail.item[].spec.placement.video.poddur": st(Y),
                "detail.item[].spec.placement.video.podid": st(Y),
                "detail.item[].spec.placement.video.podseq": st(at(Object.values(Ns))),
                "detail.item[].spec.placement.video.slotinpod": st(at(Object.values(Ms))),
                "detail.item[].spec.placement.video.mincpmpersec": st(Y),
                "detail.item[].spec.placement.video.linear": st(at(Object.values(Os))),
                "detail.item[].spec.placement.video.boxing": st(Y),
                "detail.item[].spec.placement.video.comp": st(ot),
                "detail.item[].spec.placement.video.comp[]": tt,
                "detail.item[].spec.placement.video.comp[].id": st(Z),
                "detail.item[].spec.placement.video.comp[].vcm": st(Y),
                "detail.item[].spec.placement.video.comp[].ext": dt,
                "detail.item[].spec.placement.video.comptype": st(at(Object.values(Rs))),
                "detail.item[].spec.placement.video.expdir": st(ot),
                "detail.item[].spec.placement.video.expdir[]": at(Object.values(Cs)),
                "detail.item[].spec.placement.video.overlayexpdir": st(ot),
                "detail.item[].spec.placement.video.overlayexpdir[]": at(Object.values(Cs)),
                "detail.item[].spec.placement.video.ext": dt,
                "detail.item[].spec.placement.ext": dt,
                "detail.item[].ext": dt
            },
            Tr = t => {
                const e = {
                    id: t.getSlotId().getDomId(),
                    tagid: t.getAdUnitPath()
                };
                return e.banner = Nr({
                    sizes: t.getSizes()
                }), e
            },
            Nr = t => {
                const e = {},
                    n = t.sizes.filter((t => "string" != typeof t)).map((({
                        width: t,
                        height: e
                    }) => ({
                        w: t,
                        h: e
                    })));
                if (n.length > 0) {
                    e.w = n[0].w, e.h = n[0].h;
                    const t = [];
                    n.forEach((e => {
                        t.push({
                            w: e.w,
                            h: e.h
                        })
                    })), e.format = t
                }
                return e
            },
            Lr = {
                "detail.gamSlots": st(ot),
                "detail.gamSlots[]": st(tt),
                "detail.gamSlots[].getAdUnitPath": st(rt),
                "detail.gamSlots[].getAdUnitPath()": st(Z),
                "detail.gamSlots[].getSizes": st(rt),
                "detail.gamSlots[].getSizes()": st(ot),
                "detail.gamSlots[].getSizes()[]": st(nt([Z, tt])),
                "detail.gamSlots[].getSizes()[].width": st(Y),
                "detail.gamSlots[].getSizes()[].height": st(Y),
                "detail.gamSlots[].getSlotId": st(rt),
                "detail.gamSlots[].getSlotId()": st(tt),
                "detail.gamSlots[].getSlotId().getDomId": st(rt),
                "detail.gamSlots[].getSlotId().getDomId()": st(Z)
            };
        var Mr = new ut({
            scope: "ad",
            object: "slot",
            action: "define",
            validators: {
                detail: {
                    detail: tt,
                    ...Cr,
                    ...Pr,
                    ...Dr,
                    ...Lr
                }
            },
            handler: async ({
                account: t,
                detail: e
            }) => {
                const n = [...e.imp ? ? [], ...e.item ? .map(Ar) ? ? [], ...e.slots ? .map(xr) ? ? [], ...e.gamSlots ? .map(Tr) ? ? []];
                if (0 === n.length) throw new Error("Expecting a non-empty array for 'imp' (OpenRTB 2.6), 'item' (OpenRTB 3.0), or 'slots' (APS legacy).");
                n.forEach((e => {
                    t.update(si, (t => t.set(e.id, e)))
                }));
                const o = n.map((t => t.id));
                return t.recordListenerNonBlocking(Fs, {
                    slotIds: o
                }), t.recordListenerNonBlocking(ys, {
                    slotIds: o
                }), {
                    status: s.completed
                }
            }
        });
        const Ur = {
            key: "simplerGPT/isActivated",
            default: !1
        };
        var qr = new ut({
            scope: "cellophane",
            object: "fetchBids",
            action: "enter",
            validators: {
                detail: {
                    detail: tt,
                    "detail.bidConfig": tt,
                    "detail.bidConfig.slots": nt([ot, lt]),
                    "detail.bidConfig.slots[]": null,
                    "detail.bidConfig.timeout": st(Y),
                    "detail.bidConfig.params": dt,
                    "detail.bidConfig.blockedBidders": st(ot),
                    "detail.bidConfig.blockedBidders[]": Z,
                    "detail.bidConfig._endpointDomain": st(Z)
                }
            },
            handler: async ({
                account: t,
                detail: e
            }) => {
                const n = t.use(Ur);
                let o;
                o = !e ? .bidConfig ? .slots ? .length && n ? t.globalContext.googletag.pubads().getSlots() : [...e.bidConfig.slots ? ? []];
                const {
                    apsSlots: a,
                    gamSlots: i
                } = function(t) {
                    const {
                        apsSlots: e,
                        gamSlots: n
                    } = t.reduce(((t, e) => (function(t) {
                        return "slotID" in t
                    }(e) ? t.apsSlots.push(e) : t.gamSlots.push(e), t)), {
                        apsSlots: [],
                        gamSlots: []
                    });
                    return {
                        apsSlots: e,
                        gamSlots: n
                    }
                }(o);
                return await t.recordListener(Mr, {
                    slots: a,
                    gamSlots: i
                }), {
                    status: s.completed
                }
            }
        });
        const Vr = {
            key: "cellophane/config",
            default: void 0
        };
        var Fr = new ut({
                scope: "regulations",
                object: "agerange",
                action: "define",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.agerange": at(Object.values(Xs).filter((t => "number" == typeof t)))
                    },
                    context: {}
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => (t.update(tr, (() => e.agerange)), {
                    status: s.completed,
                    analytics: {
                        agerange: e.agerange
                    }
                })
            }),
            Br = new ut({
                scope: "cellophane",
                object: "init",
                action: "enter",
                handler: async ({
                    account: t,
                    customEvent: e
                }) => {
                    const n = e.detail ? .config,
                        o = [];
                    return o.push(t.record(mi, {
                        context: n ? .signals ? .ortb2
                    })), !0 !== n ? .disableConfigCall && o.push(t.record(gt)), n ? .simplerGPT && t.update(Ur, (() => n.simplerGPT)), void 0 !== n ? .bidRequestSampleRate && o.push(t.record(vr.name, {
                        rate: n ? .bidRequestSampleRate
                    })), null != n ? .agerange && o.push(t.recordListener(Fr, {
                        agerange: n.agerange
                    })), t.update(Vr, (() => n)), await Promise.all(o), {
                        status: s.completed
                    }
                }
            });
        const zr = {
                key: "ad/amzniidRenderHistory",
                default: new Set
            },
            Jr = pt([Sr, qr, Br, new ut({
                scope: "cellophane",
                object: "renderImp",
                action: "enter",
                handler: async ({
                    account: t,
                    customEvent: e
                }) => {
                    if (void 0 === e.detail ? .renderImpArgs) throw new Error("renderImpArgs must be defined.");
                    const {
                        bidID: n,
                        doc: o
                    } = e.detail.renderImpArgs, a = n ? ? o.amzniid;
                    if (void 0 === a) throw new Error("Invalid bID.");
                    if (t.use(zr).has(a)) throw new Error("Targeting reuse detected.");
                    return t.update(zr, (t => t.add(a))), {
                        status: s.completed
                    }
                }
            }), new ut({
                scope: "cellophane",
                object: "setDisplayBids",
                action: "enter",
                handler: async () => ({
                    status: s.completed
                })
            })]);
        var Hr = new ut({
            scope: "regulations",
            object: "dsa",
            action: "define",
            validators: {
                detail: {
                    detail: tt,
                    "detail.dsa": st((t => {
                        try {
                            JSON.stringify(t)
                        } catch (t) {
                            throw new Error("must be JSON stringifiable")
                        }
                    }))
                }
            },
            handler: async ({
                account: t,
                customEvent: e
            }) => {
                const n = e.detail;
                if (void 0 === n) throw new Error("A dsa object is expected as parameter");
                const {
                    dsa: o
                } = n;
                return t.update(Zs, (() => o)), {
                    status: s.completed,
                    analytics: {
                        dsa: null != o ? Gr(o) : 0
                    }
                }
            }
        });
        const Gr = t => JSON.stringify(t).length,
            Kr = pt([Fr, Hr, er]),
            Wr = {
                key: "documentReady/readyState",
                default: void 0
            };
        var Qr = new ut({
                scope: "window",
                object: "initialViewportHeight",
                action: "capture",
                validators: {
                    context: {
                        context: tt,
                        "context.window": tt,
                        "context.window.innerHeight": Y
                    }
                },
                handler: async ({
                    account: t,
                    context: e
                }) => {
                    if (void 0 !== t.use(Vs)) return {
                        status: s.cancelled,
                        analytics: {
                            reason: "already_captured"
                        }
                    };
                    const n = t.use(Wr);
                    if (void 0 === n || "loading" === n) return {
                        status: s.cancelled,
                        analytics: {
                            reason: "dom_still_loading",
                            readyState: n ? ? null
                        }
                    };
                    const o = e.window.innerHeight;
                    return o < 0 ? {
                        status: s.cancelled,
                        analytics: {
                            reason: "invalid_viewport_height",
                            viewportHeight: o
                        }
                    } : (t.update(Vs, (() => o)), {
                        status: s.completed
                    })
                }
            }),
            Yr = new ut({
                scope: "documentReady",
                object: "readyState",
                action: "didChange",
                handler: async ({
                    account: t
                }) => {
                    const e = t.globalContext.document.readyState;
                    return t.update(Wr, (() => e)), "loading" !== e && t.recordListenerNonBlocking(Qr), {
                        status: s.completed
                    }
                }
            }),
            Zr = new ut({
                scope: "documentReady",
                object: "eventListeners",
                action: "add",
                handler: async ({
                    account: t
                }) => (t.recordListenerNonBlocking(Yr), t.globalContext.document.addEventListener("readystatechange", (() => t.recordListenerNonBlocking(Yr, {
                    source: i.webpage
                }))), {
                    status: s.completed
                })
            });
        const Xr = pt([Zr, Yr]),
            tc = {
                key: "nativeCommerceAds/timings",
                default: []
            },
            ec = t => {
                const e = /(.*\/x\/c\/[a-zA-Z0-9_-]*\/)(.*)(https.*)/;
                try {
                    if (e.test(t)) {
                        const n = e.exec(t);
                        return null !== n && n.length >= 3 && n[2].startsWith("{") && n[2].endsWith("}") ? `${n[1]}${encodeURI(n[2])}${n[3]}` : t
                    }
                } catch (e) {
                    return t
                }
                return t
            };

        function nc(t) {
            const e = new Image;
            return e.src = t, e
        }
        const oc = (t, e, n) => {
                t.update(tc, (t => (t.push({
                    time: performance.now(),
                    key: `${e}/${n}`
                }), t)))
            },
            ac = async (t, e) => await new Promise((e => {
                setTimeout(e, t)
            })).then((async () => await e)),
            ic = "NCA",
            sc = {
                key: "nativeCommerceAds/asinPerRequest",
                default: 14
            },
            rc = {
                key: "nativeCommerceAds/asinProcessIter",
                default: 5
            },
            cc = {
                key: "nativeCommerceAds/asinProcessDelay",
                default: 250
            },
            dc = {
                key: "nativeCommerceAds/contextURL",
                default: void 0
            },
            lc = {
                key: "nativeCommerceAds/getAdsEndpoint",
                default: "https://c.aps.amazon-adsystem.com/e/dtb/custombid"
            },
            uc = {
                key: "nativeCommerceAds/getAdsIsKey",
                default: "082f8778403939df819c59b1e735a614"
            },
            pc = {
                key: "nativeCommerceAds/bidParams",
                default: {}
            },
            mc = {
                key: "nativeCommerceAds/recordMaps",
                default: new Map
            };
        var fc = new ut({
                scope: "nativeCommerceAds",
                object: "adMarkup",
                action: "append",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.response": null,
                        "detail.iteration": Y
                    }
                },
                handler: async ({
                    account: t,
                    detail: e,
                    customEvent: n
                }) => {
                    const o = e.response,
                        a = Wt(t.globalContext.document, t.globalContext.navigator ? .connection, t.globalContext.innerWidth, t.globalContext.innerHeight);
                    return "loading" === t.use(Wr) ? {
                        status: s.waiting,
                        analytics: {
                            browserInfo: a
                        }
                    } : (null != o ? .amznadm && "" !== o ? .amznadm && (oc(t, ic, `${e.iteration}:appendAdMarkup/start`), function(t, e) {
                        const n = t.querySelector("a[data-aps-asin]") ? ? void 0;
                        if (null == n) return;
                        const o = t.createElement("iframe");
                        o.style.marginLeft = "0", o.style.marginTop = "0", o.style.height = "1px", o.style.width = "1px", o.setAttribute("data-testid", "amzn-nca-ad"), o.setAttribute("scrolling", "no"), o.setAttribute("frameborder", "0"), o.srcdoc = e ? ? "", n ? .insertAdjacentElement("afterend", o)
                    }(t.globalContext.document, o ? .amznadm), oc(t, ic, `${e.iteration}:appendAdMarkup/end`)), {
                        status: s.completed,
                        analytics: {
                            browserInfo: a
                        }
                    })
                }
            }),
            hc = new ut({
                scope: "nativeCommerceAds",
                object: "krypton",
                action: "didRespond",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.response": null,
                        "detail.iteration": Y,
                        "detail.map": null
                    }
                },
                handler: async ({
                    account: t,
                    detail: e,
                    customEvent: n
                }) => {
                    oc(t, ic, `${e.iteration}:processKryptonResponse/start`);
                    const o = Wt(t.globalContext.document, t.globalContext.navigator ? .connection, t.globalContext.innerWidth, t.globalContext.innerHeight),
                        a = e.response,
                        i = e.map;
                    if ("loading" === t.use(Wr)) return {
                        status: s.waiting,
                        value: {
                            didRespond: !1
                        },
                        analytics: {
                            browserInfo: o
                        }
                    };
                    if (!Array.isArray(a ? .slotBids) || 0 === a ? .slotBids.length) return oc(t, ic, `${e.iteration}:processKryptonResponse/empty`), {
                        status: s.cancelled,
                        value: {
                            didRespond: !1
                        },
                        analytics: {
                            browserInfo: o
                        }
                    };
                    const r = t.use(mc);
                    for (const e of a.slotBids) {
                        const n = e.asin;
                        if ("" !== n && null != n) {
                            const t = r.get(n) ? ? {
                                apsAsin: "",
                                apsAscTag: "",
                                apsAscSubtag: "",
                                response: void 0,
                                elementStatus: new Map
                            };
                            r.set(n, { ...t,
                                clickUrl: e.clickUrl,
                                impUrl: e.impUrl,
                                tqUrl: e.tqUrl
                            })
                        }
                        "r" === e.mode && await vc(t, e, i)
                    }
                    return t.update(mc, (() => r)), oc(t, ic, `${e.iteration}:processKryptonResponse/end`), {
                        status: s.completed,
                        value: {
                            didRespond: !0
                        },
                        analytics: {
                            browserInfo: o
                        }
                    }
                }
            });
        async function vc(t, e, n) {
            const o = async (e, n) => {
                try {
                    const o = "nativeCommerceAds/clickUrl/update",
                        a = t.read("listeners"),
                        i = a ? .get(o);
                    if (void 0 !== i) {
                        const a = await t.record(o, {
                            url: e,
                            element: n
                        });
                        return null == new URL(a.url) ? e : a.url
                    }
                } catch (t) {}
                return e
            };
            if (null == n) {
                n = new Map;
                const o = Array.from(t.globalContext.document.querySelectorAll(`[data-aps-asin=${e.asin}]`));
                n.set(e.asin, o)
            }
            if (n.has(e.asin)) {
                const t = n.get(e.asin) ? ? [];
                for (const n of t) {
                    if (null === e.clickUrl || void 0 === e.clickUrl || "" === e.clickUrl) return;
                    nc(e.impUrl), n.href = await o(ec(e.clickUrl), n), n.setAttribute("data-aps-status", "success")
                }
            }
        }
        var yc = new ut({
            scope: "nativeCommerceAds",
            object: "krypton",
            action: "fetch",
            validators: {
                detail: {
                    detail: tt,
                    "detail.bidUrl": Z,
                    "detail.iteration": Y
                }
            },
            handler: async ({
                account: t,
                detail: e,
                customEvent: n
            }) => {
                oc(t, ic, `${e.iteration}:fetchKryptonResponse/start`);
                const o = await (await fetch(e.bidUrl, {
                    credentials: "include"
                })).json();
                return oc(t, ic, `${e.iteration}:fetchKryptonResponse/end`), {
                    status: s.completed,
                    value: {
                        kryptonResponse: o
                    },
                    analytics: {
                        browserInfo: Wt(t.globalContext.document, t.globalContext.navigator ? .connection, t.globalContext.innerWidth, t.globalContext.innerHeight)
                    }
                }
            }
        });
        const gc = {
                key: "nativeCommerceAds/injectTQ",
                default: void 0
            },
            wc = {
                key: "nativeCommerceAds/tqLibUrl",
                default: "https://c.aps.amazon-adsystem.com/tqsmartpixel.js"
            };
        var bc = new ut({
                scope: "nativeCommerceAds",
                object: "trafficQuality",
                action: "load",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.iteration": Y
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => {
                    const n = Wt(t.globalContext.document, t.globalContext.navigator ? .connection, t.globalContext.innerWidth, t.globalContext.innerHeight),
                        o = t.use(wc);
                    return null != t.use(gc) || (oc(t, ic, `${e.iteration}:loadTQModule/start`), await
                        import (o).then((n => {
                            t.update(gc, (() => n)), oc(t, ic, `${e.iteration}:loadTQModule/end`)
                        }))), {
                        status: s.completed,
                        analytics: {
                            browserInfo: n
                        }
                    }
                }
            }),
            Ec = new ut({
                scope: "nativeCommerceAds",
                object: "trafficQualityUrls",
                action: "process",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.response": null,
                        "detail.iteration": Y
                    }
                },
                handler: async ({
                    account: t,
                    detail: e,
                    customEvent: n
                }) => {
                    const o = Wt(t.globalContext.document, t.globalContext.navigator ? .connection, t.globalContext.innerWidth, t.globalContext.innerHeight),
                        a = e.response;
                    if (!Array.isArray(a ? .slotBids) || 0 === a ? .slotBids.length) return {
                        status: s.cancelled,
                        value: {
                            isProcessed: !1
                        },
                        analytics: {
                            browserInfo: o
                        }
                    };
                    const i = a ? .slotBids.map((t => t.tqUrl));
                    return await t.recordListener(bc, {
                        iteration: e.iteration
                    }).then((() => {
                        oc(t, ic, `${e.iteration}:injectTQ/start`);
                        const n = t.use(gc);
                        i.forEach((t => n ? .default ? .(t))), oc(t, ic, `${e.iteration}:injectTQ/end`)
                    })), {
                        status: s.completed,
                        value: {
                            isProcessed: !0
                        },
                        analytics: {
                            browserInfo: o
                        }
                    }
                }
            }),
            Sc = new ut({
                scope: "nativeCommerceAds",
                object: "ads",
                action: "get",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.nativeContentConfig": null,
                        "detail.iteration": Y,
                        "detail.asinMap": null
                    }
                },
                handler: async ({
                    account: t,
                    detail: e,
                    systemAccount: n
                }) => (await async function(t, e, n, o, a) {
                    const i = t.id,
                        s = 36 === t.id.length;
                    let r = {
                        src: i,
                        pubid: i,
                        u: _c(t, t.use(dc)),
                        sg: encodeURIComponent(JSON.stringify(xc(t, e))),
                        pj: encodeURIComponent(JSON.stringify({
                            is: t.use(uc)
                        })),
                        pid: Rc(o)
                    };
                    s && (r.src = "600"), r = { ...r,
                        ...t.use(pc)
                    };
                    const c = Object.keys(r).filter((t => "undefined" !== r[t] && "" !== r[t] && null !== r[t])).map((t => {
                            const e = r[t];
                            return void 0 !== e ? `${t}=${String(e)}` : null
                        })).filter((t => null !== t)).join("&"),
                        d = t.use(mc);
                    e.sourceAsins ? .forEach((t => {
                        "object" == typeof t && null !== t && d.set(t.apsAsin, { ...t,
                            elements: a ? .get(t.apsAsin)
                        })
                    })), t.update(mc, (() => d));
                    const {
                        kryptonResponse: l
                    } = await t.recordListener(yc, {
                        bidUrl: `${t.use(lc)}?${c}`,
                        iteration: n
                    });
                    await Promise.all([t.recordListener(hc, {
                        response: l,
                        iteration: n,
                        map: a
                    }), t.recordListener(Ec, {
                        response: l,
                        iteration: n
                    }), t.recordListener(fc, {
                        response: l,
                        iteration: n
                    })])
                }(t, e.nativeContentConfig, e.iteration, n, e.asinMap), {
                    status: s.completed,
                    analytics: {
                        browserInfo: Wt(t.globalContext.document, t.globalContext.navigator ? .connection, t.globalContext.innerWidth, t.globalContext.innerHeight)
                    }
                })
            });

        function xc(t, e) {
            const n = {
                    ortb2: {}
                },
                o = function(t) {
                    try {
                        const e = t.use(ae);
                        if (void 0 !== e && "user" in e) {
                            const {
                                user: t,
                                ...n
                            } = e;
                            return {
                                ortb2: n
                            }
                        }
                        return {
                            ortb2: e
                        }
                    } catch (t) {
                        return {}
                    }
                }(t);
            return n.ortb2 = o.ortb2, n.ortb2 = { ...n.ortb2 ? ? {},
                site : { ...n.ortb2 ? .site ? ? {},
                    ext : { ...n.ortb2 ? .site ? .ext ? ? {},
                        ...e
                    }
                }
            }, n
        }

        function _c(t, e) {
            try {
                const n = e ? ? function(t) {
                    try {
                        if (void 0 !== t.globalContext.top ? .location.href) return t.globalContext.top ? .location.href
                    } catch (t) {}
                    try {
                        if (t.globalContext.top !== t.globalContext.self) return t.globalContext.document.referrer
                    } catch (t) {}
                }(t);
                if (void 0 !== n) return encodeURIComponent(n)
            } catch (t) {}
            return ""
        }

        function Rc(t) {
            return t.store.get(w)
        }
        const Ic = ["apsStatus"];
        var Ac = new ut({
            scope: "nativeCommerceAds",
            object: "service",
            action: "enable",
            validators: {},
            handler: async ({
                account: t,
                detail: e,
                customEvent: n
            }) => {
                const o = Wt(t.globalContext.document, t.globalContext.navigator ? .connection, t.globalContext.innerWidth, t.globalContext.innerHeight);
                if ("loading" === t.use(Wr)) return {
                    status: s.waiting,
                    analytics: {
                        browserInfo: o
                    }
                };
                await kc(t, 0);
                const a = t.use(cc);
                for (let e = 1; e <= t.use(rc); e++) await ac(a, kc(t, e));
                return {
                    status: s.completed,
                    analytics: {
                        browserInfo: o
                    }
                }
            }
        });
        const kc = async (t, e = 0) => {
                const n = $c(t, e);
                if (0 === n.size) return await Promise.resolve();
                const o = [];
                ((t, e) => {
                    const n = [];
                    for (let o = 0; o < t.length; o += e) n.push(t.slice(o, o + e));
                    return n
                })(Array.from(n.keys()), t.use(sc)).forEach((t => o.push({
                    sourceAsins: t.map((t => jc((n.get(t) ? ? [])[0])))
                })));
                const a = [];
                for (const i of o) a.push(t.recordListener(Sc, {
                    nativeContentConfig: i,
                    iteration: e,
                    asinMap: n
                }));
                return await Promise.all(a).then((() => {}))
            },
            jc = t => {
                const e = {};
                return void 0 !== t && Object.keys(t.dataset).filter((e => e.startsWith("aps") && !Ic.includes(e) && t.dataset[e])).forEach((n => e[n] = t.dataset[n])), e
            },
            $c = (t, e = 0) => {
                oc(t, ic, `${e}:fetchEligibleElements/start`);
                let n = 0;
                const o = Array.from(t.globalContext.document.querySelectorAll("a[data-aps-asin]")).map((t => t)).filter((t => (t => null !== t.dataset.apsAsin && void 0 !== t.dataset.apsAsin && "" !== t.dataset.apsAsin && "null" !== t.dataset.apsAsin)(t) && "read" !== t.dataset.apsStatus && "success" !== t.dataset.apsStatus)).reduce(((t, e) => {
                    const o = e.dataset.apsAsin;
                    return void 0 !== o && (void 0 === t.get(o) && t.set(o, []), t.get(o) ? .push(e), e.setAttribute("data-aps-status", "read"), n++), t
                }), new Map);
                return 0 === o.size ? oc(t, ic, `${e}:fetchEligibleElements/empty`) : oc(t, ic, `${e}:fetchEligibleElements/asins/${o.size}/elements/${n}`), o
            },
            Cc = pt([Ac, Sc, fc, hc, Ec, yc, bc]);
        var Oc = new ut({
                scope: "googleAdManagerSlotRequested",
                object: "slotRequestedEvent",
                action: "didTrigger",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.event": tt,
                        "detail.event.slot": tt,
                        "detail.event.slot.getSizes": rt,
                        "detail.event.slot.getSizes()": ot,
                        "detail.event.slot.getSizes()[]": nt([Z, tt]),
                        "detail.event.slot.getSizes()[].width": Y,
                        "detail.event.slot.getSizes()[].height": Y,
                        "detail.event.slot.getSlotId": rt,
                        "detail.event.slot.getSlotId()": tt,
                        "detail.event.slot.getSlotId().getDomId": rt,
                        "detail.event.slot.getSlotId().getDomId()": Z,
                        "detail.event.slot.getSlotId().getName": rt,
                        "detail.event.slot.getSlotId().getName()": Z,
                        "detail.event.slot.getTargeting": rt
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => {
                    const n = e.event.slot,
                        o = t.use(si),
                        a = n.getSlotId().getDomId(),
                        i = n.getSlotId().getName(),
                        r = n.getSizes().map((t => "object" == typeof t && null !== t && "width" in t && "height" in t ? { ...t
                        } : t)),
                        {
                            mediaType: c,
                            hasMatchingSlot: d
                        } = function(t, e) {
                            const n = e.get(t),
                                o = Boolean(n);
                            if (!o) return {
                                mediaType: "unknown",
                                hasMatchingSlot: o
                            };
                            let a;
                            return a = n ? .banner && n.video ? Pa.MultiFormat : n ? .video ? Pa.Video : Pa.Display, {
                                mediaType: a,
                                hasMatchingSlot: o
                            }
                        }(a, o),
                        l = {
                            mediaType: c,
                            slotId: a,
                            slotName: i,
                            slotSizes: r
                        };
                    return d ? (t.record("googleAdManagerSlotRequested/matchingSlotDefinition/didExist", {
                        analytics: l
                    }), function(t, e) {
                        return e.use(ss).has(t)
                    }(a, t) ? (t.record("googleAdManagerSlotRequested/matchingBidRequest/didExist", {
                        analytics: l
                    }), function(t, e) {
                        return e.use(rr).has(t)
                    }(a, t) ? (t.record("googleAdManagerSlotRequested/matchingBidResponse/didExist", {
                        analytics: l
                    }), {
                        status: s.completed
                    }) : (t.record("googleAdManagerSlotRequested/matchingBidResponse/didNotExist", {
                        analytics: l
                    }), {
                        status: s.completed
                    })) : (t.record("googleAdManagerSlotRequested/matchingBidRequest/didNotExist", {
                        analytics: l
                    }), {
                        status: s.completed
                    })) : (t.record("googleAdManagerSlotRequested/matchingSlotDefinition/didNotExist", {
                        analytics: l
                    }), {
                        status: s.completed
                    })
                }
            }),
            Pc = new ut({
                scope: "googlePublisherTag",
                object: "slotRequestedEvent",
                action: "listen",
                handler: async ({
                    account: t
                }) => void 0 === t.globalContext.googletag ? .cmd ? {
                    status: s.waiting
                } : (t.globalContext.googletag.cmd.push((function() {
                    if (void 0 === t.globalContext.googletag ? .pubads) throw new Error("Undefined googletag.pubads");
                    t.globalContext.googletag ? .pubads().addEventListener("slotRequested", (e => {
                        t.recordListener(Oc, {
                            event: e
                        })
                    }))
                })), {
                    status: s.completed
                })
            });
        const Dc = pt([Pc, Oc]),
            Tc = pt([Mr, Fs]),
            Nc = pt([Ao, ko]),
            Lc = pt([new ut({
                scope: "gpid",
                object: "autoGeneration",
                action: "disable",
                validators: {
                    detail: {
                        detail: tt
                    },
                    context: {
                        context: tt
                    }
                },
                handler: async ({
                    account: t
                }) => (t.update(ms, (() => !0)), {
                    status: s.completed
                })
            }), ys, ws]),
            Mc = pt([new ut({
                scope: "ad",
                object: "gpid",
                action: "define",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.map": dt
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => {
                    var n;
                    return n = e.map, Object.entries(n).forEach((([t, e]) => {
                        if ("string" != typeof t || "string" != typeof e) throw new Error(`Invalid GPID mapping: key and value must be strings. Got key: ${typeof t}, value: ${typeof e}`)
                    })), t.update(bs, (t => ({ ...t,
                        ...e.map
                    }))), {
                        status: s.completed
                    }
                }
            })]),
            Uc = ["primary", "canary"],
            qc = pt([new ut({
                scope: "prebidAdapter",
                object: "roleConfiguration",
                action: "update",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.toJSON": lt,
                        "detail.roleInstructions": tt,
                        "detail.roleInstructions.toJSON": lt,
                        "detail.roleInstructions.prebid": at(Uc),
                        "detail.roleInstructions.prebid.toJSON": lt,
                        "detail.roleInstructions.webclient": at(Uc),
                        "detail.roleInstructions.webclient.toJSON": lt,
                        "detail.canaryRate": et({
                            min: 0,
                            max: 1
                        })
                    },
                    context: {
                        context: it(tt),
                        "context.aps_prebid": st(dt)
                    }
                },
                handler: async ({
                    detail: t,
                    context: e,
                    account: n
                }) => {
                    e.aps_prebid || (e.aps_prebid = {});
                    const o = {
                        roleInstructions: {
                            prebid: t.roleInstructions.prebid,
                            webclient: t.roleInstructions.webclient
                        },
                        canaryRate: t.canaryRate
                    };
                    return e.aps_prebid[n.id] = o, {
                        status: s.completed
                    }
                }
            })]),
            Vc = pt([ns]),
            Fc = pt([new ut({
                scope: "tid",
                object: "config",
                action: "set",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.enabled": X
                    },
                    context: {
                        context: tt
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => (t.update(lr, (() => e.enabled)), {
                    status: s.completed
                })
            })]),
            Bc = pt([Qr]),
            zc = new class {
                select(t) {
                    return t.length ? t[Math.floor(Math.random() * t.length)] : void 0
                }
            };
        class Jc {
            static getEnabledFormats(t, e) {
                const n = e.replace(/\/$/, "").replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/#.*$/, "").toLowerCase(),
                    o = Object.entries(t).sort((([t], [e]) => {
                        const n = t.length - (t.match(/\*/g) || []).length;
                        return e.length - (e.match(/\*/g) || []).length - n
                    }));
                for (const [t, e] of o) {
                    if ("*" === t) return [...e];
                    const o = t.replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/^\*\\\./, "([^.]+\\.)*").replace(/\/\*/g, "/.+").replace(/\*/g, "[^/]*");
                    if (new RegExp(`^${o}(?:\\?[^#]*)?(?:#.*)?$`).test(n)) return [...e]
                }
                return []
            }
        }
        Jc.selectFormat = t => zc.select(t), new ut({
            scope: "customFormats",
            object: "ad",
            action: "fetch",
            validators: {
                detail: {
                    detail: tt,
                    "detail.amzniid": Z,
                    "detail.amznbid": Z,
                    "detail.amznp": Z,
                    "detail.amznhost": Z
                }
            },
            handler: async ({
                account: t,
                systemAccount: e,
                detail: n
            }) => {
                const o = new URL(`${n.amznhost}/e/dtb/admi`),
                    a = e.store.get(w);
                o.searchParams.set("b", n.amzniid), o.searchParams.set("rnd", a), o.searchParams.set("pp", n.amznbid), o.searchParams.set("p", n.amznp);
                const i = await t.globalContext.fetch(o.toString(), {
                    method: "GET",
                    headers: {
                        Accept: "application/json"
                    }
                });
                if (!i.ok) throw new Error(`Ad markup request failed with status ${i.status}.`);
                const r = await i.text();
                return {
                    status: s.completed,
                    value: {
                        ad: {
                            adHtml: r
                        }
                    }
                }
            }
        }), new ut({
            scope: "customFormats",
            object: "slot",
            action: "define",
            validators: {
                detail: {
                    detail: tt,
                    "detail.slotID": Z,
                    "detail.w": Y,
                    "detail.h": Y
                }
            },
            handler: async ({
                account: t,
                detail: e
            }) => {
                const n = {
                    id: e.slotID,
                    banner: {
                        format: [{
                            w: e.w,
                            h: e.h
                        }]
                    }
                };
                return await t.recordListener(Mr, {
                    imp: [n]
                }), {
                    status: s.completed
                }
            }
        }), new ut({
            scope: "customFormats",
            object: "targeting",
            action: "fetch",
            validators: {
                detail: {
                    detail: tt,
                    "detail.slotID": Z
                }
            },
            handler: async ({
                account: t,
                detail: e
            }) => (await t.record(pi, {
                itemIds: [e.slotID]
            }), {
                status: s.completed
            })
        });
        const Hc = {
                key: "customFormats/enabledFormats",
                default: []
            },
            Gc = {
                key: "customFormats/microClientUrl",
                default: "https://client.aps.amazon-adsystem.com/publisher-custom_formats.js"
            },
            Kc = pt([new ut({
                scope: "customFormats",
                object: "client",
                action: "bootstrap",
                validators: {
                    detail: {
                        detail: tt,
                        "detail.config": tt,
                        "detail.config.pages": dt,
                        "detail.config.pages.key()": Z,
                        "detail.config.pages.*": ot,
                        "detail.config.pages.*[]": Z
                    }
                },
                handler: async ({
                    account: t,
                    detail: e
                }) => {
                    const n = t.use(ft);
                    if (!n) return {
                        status: s.waiting
                    };
                    if ("US" !== n) return {
                        status: s.cancelled
                    };
                    const o = e.config,
                        a = Jc.getEnabledFormats(o.pages, t.globalContext.location.href);
                    if (0 === a.length) throw new Error("No enabled custom formats for this page.");
                    return t.update(Hc, (() => a)),
                        function(t) {
                            const e = t.globalContext.document,
                                n = e.createElement("script");
                            n.src = t.use(Gc), n.async = !0, e.head.appendChild(n)
                        }(t), {
                            status: s.completed
                        }
                }
            })]),
            Wc = "publisher";
        ! function(t = {}) {
            const {
                ut: e,
                gt: n
            } = { ...z,
                ...t
            };
            try {
                e((() => {
                    ! function(t = {}) {
                        const {
                            ft: e,
                            vt: n,
                            yt: o,
                            gt: a
                        } = { ...z,
                            ...t
                        };
                        try {
                            const a = e();
                            if (void 0 === a || 0 === a.length) return;
                            ! function(t, e) {
                                if (!e()) {
                                    B(V.postulate, t);
                                    let n = `Assertion failed: ${e.toString()}`;
                                    throw t && (n += ` - ${t}`), new Error(n)
                                }
                            }("5c098d", (() => Array.isArray(a)));
                            const i = function(t) {
                                return t.shift()
                            }(a);
                            if (void 0 === i) return;
                            n(V.postulate, i.hash, o(i.context, t.ht || z.ht))
                        } catch (t) {
                            a(t)
                        }
                    }({ ...z,
                        ...t
                    })
                }), 3e3)
            } catch (t) {
                n(t)
            }
        }();
        try {
            vt.fireReferencePixel(Wc);
            const t = new Map([...wt, ...wi, ...Go, ...vi, ...Ha, ...yt, ...Si, ...Wa, ...pe, ...sa, ..._i, ...$i, ...We, ...Uo, ...na, ...Ot, ...zt, ...Xo, ...Lo, ...Er, ...Jr, ...Sa, ...Ja, ...Kr, ...Xr, ...Cc, ...Dc, ...Tc, ...Nc, ...Lc, ...Mc, ...Kc, ...qc, ...Vc, ...Fc, ...Bc]),
                e = new q,
                n = e.registerEventSource(Wc);
            n.recordListener(ea, {
                restrictions: {
                    block: {
                        accounts: [h]
                    }
                }
            }), n.recordListener(Zr, {
                restrictions: {
                    block: {
                        accounts: [h]
                    }
                }
            }), n.recordListener(Pc, {
                restrictions: {
                    block: {
                        accounts: [h]
                    }
                }
            }), n.recordListener(Ct, {
                restrictions: {
                    block: {
                        accounts: [h]
                    }
                }
            }), n.recordListener(_t, {
                restrictions: {
                    block: {
                        accounts: [h]
                    }
                }
            }), n.recordListener(Yo, {
                restrictions: {
                    block: {
                        accounts: [h]
                    }
                }
            }), n.recordListener(gn, {
                restrictions: {
                    block: {
                        accounts: [h]
                    }
                }
            }), e.load({
                listeners: t
            })
        } catch (t) {
            vt.logCoreError({
                id: Wc,
                error: t,
                account: null
            }), k() && _.error(t)
        }
    }();
    /*! @amzn/apswebapstaglibrary - apstag-legacy - 26.521.1658 */
    ! function(t) {
        var e = {};

        function n(r) {
            var o;
            return (e[r] || (o = e[r] = {
                i: r,
                l: !1,
                exports: {}
            }, t[r].call(o.exports, o, o.exports, n), o.l = !0, o)).exports
        }
        n.m = t, n.c = e, n.d = function(t, e, r) {
            n.o(t, e) || Object.defineProperty(t, e, {
                enumerable: !0,
                get: r
            })
        }, n.r = function(t) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(t, "__esModule", {
                value: !0
            })
        }, n.t = function(t, e) {
            if (1 & e && (t = n(t)), 8 & e) return t;
            if (4 & e && "object" == typeof t && t && t.__esModule) return t;
            var r = Object.create(null);
            if (n.r(r), Object.defineProperty(r, "default", {
                    enumerable: !0,
                    value: t
                }), 2 & e && "string" != typeof t)
                for (var o in t) n.d(r, o, function(e) {
                    return t[e]
                }.bind(null, o));
            return r
        }, n.n = function(t) {
            var e = t && t.__esModule ? function() {
                return t.default
            } : function() {
                return t
            };
            return n.d(e, "a", e), e
        }, n.o = function(t, e) {
            return Object.prototype.hasOwnProperty.call(t, e)
        }, n.p = "", n(n.s = 38)
    }([function(t, e, n) {
        "use strict";

        function r(t) {
            return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function o(t) {
            try {
                var e = parseInt(t, 10);
                if (!isNaN(e)) return !(e <= 0) && (100 <= e || 100 * Math.random() <= e)
            } catch (t) {}
            return !1
        }

        function i() {
            return "".concat(Math.round(1e12 * Math.random())).concat(Date.now())
        }

        function a(t) {
            for (var e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", n = new Array(t), r = 0; r < t; r++) n[r] = e[Math.floor(Math.random() * e.length)];
            return n.join("")
        }

        function c(t) {
            return "object" === r(t) && null !== t
        }

        function s(t) {
            return "[object Array]" === Object.prototype.toString.call(t)
        }

        function u(t, e) {
            return c(t) && void 0 !== t[e] && "" !== t[e]
        }

        function l(t, e) {
            return -1 !== t.indexOf(e)
        }

        function f(t) {
            var e = new Date;
            return e.setDate(e.getDate() + t), e.toUTCString()
        }

        function d(t) {
            try {
                var e = t.innerWidth || t.document.documentElement.clientWidth || t.document.body.clientWidth,
                    n = t.innerHeight || t.document.documentElement.clientHeight || t.document.body.clientHeight;
                return "".concat(e, "x").concat(n)
            } catch (t) {}
            return "x"
        }

        function b(t, e) {
            return decodeURIComponent(t).split("?")[0].split("#")[0] === decodeURIComponent(e).split("?")[0].split("#")[0]
        }

        function p(t) {
            var e = Object.keys(t);
            return e.filter((function(e) {
                return t[e]
            })).length === e.length
        }
        n.d(e, "k", (function() {
            return o
        })), n.d(e, "c", (function() {
            return i
        })), n.d(e, "d", (function() {
            return a
        })), n.d(e, "i", (function() {
            return c
        })), n.d(e, "h", (function() {
            return s
        })), n.d(e, "j", (function() {
            return u
        })), n.d(e, "g", (function() {
            return l
        })), n.d(e, "e", (function() {
            return f
        })), n.d(e, "f", (function() {
            return d
        })), n.d(e, "b", (function() {
            return b
        })), n.d(e, "a", (function() {
            return p
        }))
    }, function(t, e, n) {
        "use strict";
        n.d(e, "b", (function() {
            return f
        })), n.d(e, "c", (function() {
            return d
        })), n.d(e, "d", (function() {
            return b
        })), n.d(e, "a", (function() {
            return p
        }));
        e = n(0);
        var r = n(2),
            o = n(6),
            i = n(9),
            a = n(15),
            c = n(3),
            s = Object(e.k)(10),
            u = [],
            l = (!0 === Object(o.c)("exposeErrors") && (window.apstagErrors = u), function(t, e, n) {
                try {
                    var r = Date.now(),
                        o = {
                            eventSource: "apstag",
                            eventTime: r,
                            eventCategory: "error",
                            eventName: null != n ? n : "unknown",
                            eventProperties: {
                                accountID: t,
                                libraryVersion: c.l,
                                url: Object(i.f)(window),
                                error: {
                                    name: "string" == typeof e ? e : e.name,
                                    message: "string" == typeof e ? e : e.message
                                }
                            }
                        },
                        a = {
                            Data: window.btoa(JSON.stringify(o)),
                            PartitionKey: r
                        };
                    fetch("https://prod.tahoe-analytics.publishers.advertising.a2z.com/logevent/putRecords?encoded=true", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "x-api-key": "5e0b19374596b1c8abfb0560fcb956220131d0a7f7100979de5d18cfada355d5"
                        },
                        body: JSON.stringify({
                            Records: [a]
                        })
                    }).catch((function() {}))
                } catch (t) {}
            });

        function f(t, e, n) {
            try {
                (null != n && n.makeVisibleToAllUsers || Object(o.d)("errors")) && console.error(t);
                var c, f, d = {
                    ts: Date.now(),
                    url: encodeURIComponent(Object(i.f)(window)),
                    r: encodeURIComponent(Object(i.g)(window)),
                    _type: "apsLibraryError",
                    e: {
                        et: t.name,
                        el: e,
                        msg: t.message
                    }
                };
                return u.push(d), r.a.dispatch({
                    type: "LOG_ERROR",
                    error: d
                }), Math.random() <= .001 && (f = null != (c = null == n ? void 0 : n.accountId) ? c : Object(a.unsafelyGuessAccountID)(), l(f, t, e)), !!s
            } catch (t) {
                console.error(t)
            }
            return !1
        }

        function d(t, e, n, r) {
            return f({
                name: e,
                message: "".concat(t, " was of type '").concat(e, "' instead of '").concat(n, "'")
            }, "TypeError-".concat(t), r)
        }

        function b(t, e) {
            return function() {
                try {
                    return t.apply(null, arguments)
                } catch (t) {
                    return f(t, e, {
                        makeVisibleToAllUsers: !0
                    }), null
                }
            }
        }

        function p(t) {
            (1 < arguments.length && void 0 !== arguments[1] && arguments[1] || Object(o.d)("errors")) && console.warn(t)
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return p
        }));
        var r, o = n(3),
            i = (e = n(7), n(0));
        n = n(6);

        function a(t) {
            return (a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function c(t, e) {
            var n, r = Object.keys(t);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), r.push.apply(r, n)), r
        }

        function s(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? c(Object(n), !0).forEach((function(e) {
                    u(t, e, n[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                }))
            }
            return t
        }

        function u(t, e, n) {
            return (e = function(t) {
                return t = function(t, e) {
                    if ("object" !== a(t) || null === t) return t;
                    var n = t[Symbol.toPrimitive];
                    if (void 0 === n) return String(t);
                    if ("object" !== a(n = n.call(t, e))) return n;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }(t, "string"), "symbol" === a(t) ? t : String(t)
            }(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n, t
        }

        function l(t) {
            return function(t) {
                if (Array.isArray(t)) return f(t)
            }(t) || function(t) {
                if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t)
            }(t) || function(t, e) {
                var n;
                if (t) return "string" == typeof t ? f(t, e) : "Map" === (n = "Object" === (n = Object.prototype.toString.call(t).slice(8, -1)) && t.constructor ? t.constructor.name : n) || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? f(t, e) : void 0
            }(t) || function() {
                throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }()
        }

        function f(t, e) {
            (null == e || e > t.length) && (e = t.length);
            for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
            return r
        }
        var d = {
            AAXReqs: [],
            aaxViewabilityEnabled: !1,
            bidConfigs: {},
            bidReqs: {},
            bsPixels: {},
            cfg: {
                v: -1,
                CSM_JS: "//c.amazon-adsystem.com/aax2/csm.js.gz",
                CSM_RTB_COMMUNICATOR_JS: "".concat(o.v, "c.amazon-adsystem.com/bao-csm/aps-comm/aps_csm.js"),
                DEBUG_APP_HTML: "//c.amazon-adsystem.com/aax2/debugApp.html",
                DEBUG_APP_HTML_V2: "//c.amazon-adsystem.com/aax2/debug_app_v2.html",
                DEFAULT_TIMEOUT: 2e3,
                DTB_PATH: "/e/dtb",
                TEST_PATH_FREQUENCY: 0,
                TEST_BID_ENDPOINT: null,
                TEST_PATH_LATENCY_SAMPLE_RATE: null,
                PIXEL_PATH: "/x/px/",
                LATENCY_SAMPLING_RATE: 1,
                COOKIE_MATCH_DELAY: 0,
                MAX_SLOTS_PER_REQUEST: 1,
                SLOT_RENDER_SAMPLING_RATE: 1,
                FEATURE_SAMPLING_RATE: 1,
                CONFIG_CALL_ENABLED: !1,
                LIB_CONFIG_PATH: "/cdn/prod/config"
            },
            cmpFired: !1,
            config: {
                pubID: ""
            },
            displayAdServer: {
                noBidSlotIDs: [],
                shouldSampleRender: !1,
                slotRenderEndedSet: !1
            },
            errors: [],
            eventLog: [],
            experiments: {},
            gamSlotFetchLog: [],
            gamSlotRenderPixel: {
                aaxReqOffset: 0,
                gamSlotFetchLogOffset: 0
            },
            hosts: {
                DEFAULT_AAX_BID_HOST: "aax.amazon-adsystem.com",
                DEFAULT_AAX_PIXEL_HOST: "aax.amazon-adsystem.com",
                DEFAULT_CXM_HOST: "c.amazon-adsystem.com",
                DEFAULT_BS_HOST: "cxm-bcn.publisher-services.amazon.dev"
            },
            identityState: {},
            libraryLoadCallLatency: 0,
            Q: [],
            slotBids: {},
            targetingKeys: {},
            tcfParseTime: 0,
            outstream: {
                renderStart: 0,
                shouldSample: !1
            },
            consentManagementPlatform: {}
        };

        function b() {
            var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : d,
                e = 1 < arguments.length ? arguments[1] : void 0;
            return {
                AAXReqs: function(t, e) {
                    switch (e.type) {
                        case "RECORD_AAX_REQUEST":
                            return [].concat(l(t), [e.data]);
                        case "RECORD_AAX_REQ_PROP":
                            return t.map((function(t) {
                                return (t = s({}, t)).bidReqID === e.bidReqID && (t[e.key] = e.value), t
                            }));
                        default:
                            return l(t)
                    }
                }(t.AAXReqs, e),
                aaxViewabilityEnabled: function(t, e) {
                    return "SET_VIEWABILITY" !== e.type ? t : e.viewability
                }(t.aaxViewabilityEnabled, e),
                bidConfigs: function(t, e) {
                    return "RECORD_ORIGINAL_BID_CONFIG" !== e.type ? s({}, t) : s(s({}, t), {}, u({}, e.bidConfig.bidReqID, e.bidConfig))
                }(t.bidConfigs, e),
                bidReqs: function(t, e) {
                    var n;
                    switch (e.type) {
                        case "ADD_CHUNKED_REQUESTS":
                            return s(s({}, t), {}, u({}, e.fid, s(s({}, t[e.fid]), {}, {
                                networkReqs: new Array(e.numChunks)
                            })));
                        case "NEW_FETCH_BID_REQUEST":
                            return s(s({}, t), {}, u({}, e.fid, {
                                pto: e.pto,
                                hasCallbackExecuted: !1,
                                networkReqs: []
                            }));
                        case "RECORD_CALLBACK":
                            return s(s({}, t), {}, u({}, e.fid, s(s({}, t[e.fid]), {}, {
                                hasCallbackExecuted: !0
                            })));
                        case "RECORD_NETWORK_EXCHANGE":
                            var r = t[e.fid].networkReqs;
                            return r[e.networkID] = s(s({}, r[e.networkID]), {}, (u(n = {}, "".concat(e.exchangeType, "Time"), e.timestamp), u(n, "inFlight", "request" === e.exchangeType), n)), s(s({}, t), {}, u({}, e.fid, s(s({}, t[e.fid]), {}, {
                                networkReqs: r
                            })));
                        case "RECORD_TIMEOUT":
                            return s(s({}, t), {}, u({}, e.fid, s(s({}, t[e.fid]), {}, {
                                networkReqs: t[e.fid].networkReqs.map((function(t) {
                                    return t.inFlight ? s(s({}, t), {}, {
                                        timeOut: e.timeOut
                                    }) : t
                                }))
                            })));
                        default:
                            return s({}, t)
                    }
                }(t.bidReqs, e),
                bsPixels: function(t, e) {
                    return "RECORD_BID_INFO_SENT" !== e.type ? s({}, t) : s(s({}, t), {}, u({}, e.bidInfo.iid, e.bidInfo.state))
                }(t.bsPixels, e),
                cfg: function(t, e) {
                    return "SET_CFG" !== e.type ? s({}, t) : s(s({}, t), e.cfg)
                }(t.cfg, e),
                cmpFired: function(t, e) {
                    return "CMP_FIRED" === e.type || t
                }(t.cmpFired, e),
                config: function(t, e) {
                    return "SET_CONFIG" !== e.type ? s({}, t) : s(s({}, e.config), {}, {
                        gdpr: s({
                            cmpTimeout: e.defaultCmpTimeout
                        }, e.config.gdpr),
                        isSelfServePub: void 0 !== e.config.pubID && 5 <= e.config.pubID.length
                    })
                }(t.config, e),
                displayAdServer: function(t, e) {
                    switch (e.type) {
                        case "SLOT_RENDER_ENDED_SET":
                            return s(s({}, t), {}, {
                                slotRenderEndedSet: !0
                            });
                        case "NO_BID_ON_ADSERVER_SLOTS":
                            return s(s({}, t), {}, {
                                noBidSlotIDs: t.noBidSlotIDs.concat(e.slotIDs)
                            });
                        case "REQUESTED_BID_FOR_ADSERVER_SLOTS":
                            return s(s({}, t), {}, {
                                noBidSlotIDs: t.noBidSlotIDs.filter((function(t) {
                                    return !Object(i.g)(e.slotIDs, t)
                                }))
                            });
                        case "SHOULD_SAMPLE_SLOT_RENDER":
                            return s(s({}, t), {}, {
                                shouldSampleRender: e.value
                            });
                        default:
                            return s(s({}, t), {}, {
                                noBidSlotIDs: l(t.noBidSlotIDs)
                            })
                    }
                }(t.displayAdServer, e),
                errors: function(t, e) {
                    return "LOG_ERROR" !== e.type ? l(t) : [].concat(l(t), [s({}, e.error)])
                }(t.errors, e),
                eventLog: function(t, e) {
                    return "LOG_EVENT" !== e.type ? l(t) : [].concat(l(t), [s({}, e.event)])
                }(t.eventLog, e),
                experiments: function(t, e) {
                    switch (e.type) {
                        case "SHOULD_CHUNK_REQUESTS":
                            return s({
                                chunkRequests: !0 === t.shouldSampleLatency && e.value
                            }, t);
                        case "SHOULD_SAMPLE_LATENCY":
                            return s(s({}, t), {}, {
                                shouldSampleLatency: e.value
                            });
                        case "SHOULD_SAMPLE_FEATURES":
                            return s(s({}, t), {}, {
                                shouldSampleFeatures: e.value
                            });
                        case "SHOULD_USE_TEST_BID_ENDPOINT":
                            return s(s({}, t), {}, {
                                shouldUseTestBidEndpoint: e.value
                            });
                        default:
                            return s({}, t)
                    }
                }(t.experiments, e),
                gamSlotFetchLog: function(t, e) {
                    return "LOG_GAM_EVENT" !== e.type ? l(t) : [].concat(l(t), [s({}, e.event)])
                }(t.gamSlotFetchLog, e),
                gamSlotRenderPixel: function(t, e) {
                    return "UPDATE_RENDER_OFFSETS" !== e.type ? s({}, t) : s(s({}, t), e.offsets)
                }(t.gamSlotRenderPixel, e),
                hosts: function(t, e) {
                    return "SET_HOST" !== e.type ? s({}, t) : s(s({}, t), {}, u({}, e.hostName, e.hostValue))
                }(t.hosts, e),
                identityState: function(t, e) {
                    return "RECORD_IDENTITY_STATE" !== e.type ? t : s(s({}, t), {}, u({}, e.vendor, Object(i.j)(t, e.vendor) ? t[e.vendor] : e.identityState))
                }(t.identityState, e),
                libraryLoadCallLatency: function(t, e) {
                    return "RECORD_LIBRARY_LOAD_CALL_LATENCY" !== e.type ? t : e.latency
                }(t.libraryLoadCallLatency, e),
                Q: function(t, e) {
                    return "SET_Q" !== e.type ? l(t) : l(e.Q)
                }(t.Q, e),
                slotBids: function(t, e) {
                    switch (e.type) {
                        case "BID_STATE_CHANGE":
                            return s(s({}, t), {}, u({}, e.slotID, t[e.slotID].map((function(t) {
                                return t._targetingSetID === e._targetingSetID && (t.bidState = e.bidState, e.bidState === o.c.rendered ? t.timing.renderTime = e.ts : e.bidState === o.c.set && t.timing.setAtTimes.push(e.ts)), t
                            }))));
                        case "UPDATE_BID_INFO_PROP":
                            return void 0 === t[e.slotID] || t[e.slotID].filter((function(t) {
                                return t.matchesBidCacheId(e.iid)
                            })).length < 1 ? s({}, t) : s(s({}, t), {}, u({}, e.slotID, t[e.slotID].map((function(t) {
                                return t.matchesBidCacheId(e.iid) && (t[e.key] = e.value), t
                            }))));
                        case "UPDATE_SLOT_BIDS":
                            return s(s({}, t), e.bids.reduce((function(e, n) {
                                return Object(i.j)(e, n.slotID) ? e[n.slotID] = [].concat(l(e[n.slotID]), [n]) : Object(i.j)(t, n.slotID) ? e[n.slotID] = [].concat(l(t[n.slotID]), [n]) : e[n.slotID] = [n], e
                            }), {}));
                        default:
                            return s({}, t)
                    }
                }(t.slotBids, e),
                targetingKeys: function(t, e) {
                    return "UPDATE_SLOT_BIDS" !== e.type ? s({}, t) : s(s({}, t), e.bids.reduce((function(e, n) {
                        return Object(i.j)(t, n.slotID) ? e[n.slotID] = [].concat(l(t[n.slotID]), l((n.bidConfig.targeting || o.i).filter((function(e) {
                            return -1 === t[n.slotID].indexOf(e)
                        })))) : e[n.slotID] = n.bidConfig.targeting || o.i, e
                    }), {}))
                }(t.targetingKeys, e),
                tcfParseTime: function(t, e) {
                    return "RECORD_TCF_PARSE_TIME" !== e.type ? t : e.time
                }(t.tcfParseTime, e),
                outstream: function(t, e) {
                    switch (e.type) {
                        case "RECORD_OUTSTREAM_RENDER_START_TIME":
                            return s(s({}, t), {}, {
                                renderStart: e.time
                            });
                        case "OUTSTREAM_SHOULD_SAMPLE":
                            return s(s({}, t), {}, {
                                shouldSample: e.shouldSample
                            });
                        default:
                            return t
                    }
                }(t.outstream, e),
                consentManagementPlatform: function(t, e) {
                    switch (e.type) {
                        case "RECORD_CMP_LISTENED_TO":
                            return s(s({}, t), {}, {
                                isListenedTo: e.isListenedTo
                            });
                        case "RECORD_CMP_CONSENT_DATA":
                            return s(s({}, t), {}, {
                                tcData: e.tcData
                            });
                        default:
                            return t
                    }
                }(t.consentManagementPlatform, e)
            }
        }
        var p = {
            getState: function() {
                return r
            },
            dispatch: function(t) {
                r = b(r, t)
            }
        };
        (p = Object(n.d)("redux") && Object(e.b)() && Object(i.j)(window, "__REDUX_DEVTOOLS_EXTENSION__") ? window.__REDUX_DEVTOOLS_EXTENSION__(b) : p).dispatch({
            type: "NOOP"
        })
    }, function(t, e, n) {
        "use strict";
        n.d(e, "m", (function() {
            return a
        })), n.d(e, "i", (function() {
            return c
        })), n.d(e, "z", (function() {
            return s
        })), n.d(e, "c", (function() {
            return r
        })), n.d(e, "h", (function() {
            return u
        })), n.d(e, "y", (function() {
            return l
        })), n.d(e, "f", (function() {
            return f
        })), n.d(e, "g", (function() {
            return d
        })), n.d(e, "d", (function() {
            return b
        })), n.d(e, "p", (function() {
            return p
        })), n.d(e, "n", (function() {
            return y
        })), n.d(e, "e", (function() {
            return m
        })), n.d(e, "x", (function() {
            return g
        })), n.d(e, "w", (function() {
            return h
        })), n.d(e, "o", (function() {
            return o
        })), n.d(e, "u", (function() {
            return O
        })), n.d(e, "j", (function() {
            return v
        })), n.d(e, "t", (function() {
            return i
        })), n.d(e, "s", (function() {
            return j
        })), n.d(e, "l", (function() {
            return S
        })), n.d(e, "r", (function() {
            return w
        })), n.d(e, "v", (function() {
            return T
        })), n.d(e, "b", (function() {
            return E
        })), n.d(e, "k", (function() {
            return D
        })), n.d(e, "a", (function() {
            return _
        })), n.d(e, "q", (function() {
            return I
        })), n.d(e, "A", (function() {
            return P
        }));
        var r, o, i, a = 25,
            c = ["amznbid", "amzniid", "amznsz", "amznp"],
            s = ["amznbid", "amzniid", "amznp", "r_amznbid", "r_amzniid", "r_amznp"],
            u = ((n = r = r || {}).new = "NEW", n.exposed = "EXPOSED", n.set = "SET", n.rendered = "RENDERED", "apstagDebug"),
            l = ["redux", "fake_bids", "verbose", "console", "console_v2", "errors"],
            f = "apstagDebugHeight",
            d = "apstagDEBUG",
            b = "apstagCfg",
            p = 0,
            y = 0,
            m = "apstagCxMEnabled",
            g = "3pmetadata",
            h = 5,
            O = ((e = o = o || {}).amznbid = "testBid", e.amzniid = "testImpression", e.amznp = "testP", e.crid = "testCrid", ["amznbid", "amznp"]),
            v = new Map([
                ["__apsid", "ck"],
                ["__aps_id_p", "ckp"]
            ]),
            j = ((n = i = i || {}).noRequest = "0", n.bidInFlight = "1", n.noBid = "2", "600"),
            S = "26.521.1658",
            w = "https://",
            T = "http".concat("s://"),
            E = "".concat(w, "aax.amazon-adsystem.com/e/dtb/vast?"),
            D = "function" == typeof XMLHttpRequest && void 0 !== (new XMLHttpRequest).withCredentials,
            _ = "apstagLOADED",
            I = 13,
            P = '<!DOCTYPE html>\n<html>\n  <head>\n    <title>APS Video Ads</title>\n    <script src="https://client.aps.amazon-adsystem.com/video-player.js" onerror="$$apsvidonerror$$"><\/script>\n  </head>\n  <body>\n    <div id="amazon-ads-container" style="height: 100%; width: 100%; position: absolute;">\n    </div>\n    <script type="text/javascript">\nconst adsContainer = document.querySelector("#amazon-ads-container")\nconst companionContainers =\n  window.AmazonVideoAds.findCompanionDivs($$apstagCompanionContainers$$)\nconst videoPlayerProps = $$videoPlayerProps$$\n\nconst amazonVideoAds = new window.AmazonVideoAds(adsContainer,\n{ ...videoPlayerProps,\n  companions: companionContainers });\nwindow.adsM;\n\nfunction addListeners(adsM, amazonVideoAds) {\n  adsM.addListener(amazonVideoAds.eventNames.AdVideoPlayerEvents.COMPLETED, (e) => {\n    window.top.postMessage({"apsVideoPlayer": true, "event": "completed"}, window.top.location.origin);\n  })\n  adsM.addListener(amazonVideoAds.eventNames.AdVideoPlayerEvents.LOADED, (e) => {\n    window.top.postMessage({"apsVideoPlayer": true, "event": "loaded"}, window.top.location.origin);\n  })\n}\n \nwindow.requestAndPlay = () => {\n  amazonVideoAds.fetchAdsFromUrl("$$apstagVastTag$$")\n    .then(adsManager => {\n      adsM = adsManager;\n \n      adsM.init({\n        fullscreen: true,\n        muted: true,\n        volume: .3,\n        autoplay: false,\n        controls: false,\n        preload: "auto"\n      })\n\n      addListeners(adsM, amazonVideoAds);\n      adsM.startAds(2000, {shouldVideoRemainAfterPlay: true});\n    })\n    .catch(function(err) {\n      console.log("apstag failed to get APS ads manager", err);\n    });\n  }\n \n  requestAndPlay();\n    <\/script>\n  </body>\n</html>'
    }, function(t, e, n) {
        "use strict";
        var r, o;

        function i(t) {
            return void 0 !== t.amzniid
        }

        function a(t) {
            return void 0 !== t.kvMap
        }
        n.d(e, "a", (function() {
            return r
        })), n.d(e, "b", (function() {
            return o
        })), n.d(e, "d", (function() {
            return i
        })), n.d(e, "c", (function() {
            return a
        })), (n = r = r || {}).DISPLAY = "display", n.VIDEO = "video", n.MULTI_FORMAT = "multi-format", (e = o = o || {}).MANAGED_WEB = "mw", e.SELF_SERVE_WEB = "ssw"
    }, function(t, e, n) {
        "use strict";

        function r(t) {
            return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function o(t, e) {
            var n, r = Object.keys(t);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), r.push.apply(r, n)), r
        }

        function i(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, c(r.key), r)
            }
        }

        function a(t, e, n) {
            (e = c(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function c(t) {
            return t = function(t, e) {
                if ("object" !== r(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== r(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === r(t) ? t : String(t)
        }
        n.d(e, "a", (function() {
            return l
        }));
        var s = function() {
                function t(e) {
                    if (e = e.accountID, !(this instanceof t)) throw new TypeError("Cannot call a class as a function");
                    a(this, "accountID", void 0), this.accountID = e, this.init()
                }
                var e, n;
                return e = t, (n = [{
                    key: "queue",
                    get: function() {
                        var t;
                        return null == (t = window._aps.get(this.accountID)) ? void 0 : t.queue
                    }
                }, {
                    key: "init",
                    value: function() {
                        window._aps = window._aps || new Map, window._aps.has(this.accountID) || window._aps.set(this.accountID, {
                            queue: [],
                            store: new Map
                        })
                    }
                }, {
                    key: "safelyRecord",
                    value: function(t, e) {
                        this.record(t, e).catch((function() {}))
                    }
                }, {
                    key: "record",
                    value: function(t, e) {
                        var n = this;
                        return new Promise((function(r, i) {
                            window._aps.get(n.accountID).queue.push(new window.CustomEvent(t, {
                                detail: function(t) {
                                    for (var e = 1; e < arguments.length; e++) {
                                        var n = null != arguments[e] ? arguments[e] : {};
                                        e % 2 ? o(Object(n), !0).forEach((function(e) {
                                            a(t, e, n[e])
                                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach((function(e) {
                                            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                                        }))
                                    }
                                    return t
                                }({
                                    resolve: r,
                                    reject: i,
                                    source: "apstag"
                                }, e)
                            }))
                        }))
                    }
                }, {
                    key: "read",
                    value: function(t) {
                        var e;
                        return null == (e = window._aps) ? void 0 : e.get(this.accountID).store.get(t)
                    }
                }]) && i(e.prototype, n), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t
            }(),
            u = {},
            l = function(t) {
                return "string" != typeof t && (t = t.toString()), window._aps && window._aps.has(t) && u[t] || (u[t] = new s({
                    accountID: t
                })), u[t]
            }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return l
        })), n.d(e, "b", (function() {
            return m
        })), n.d(e, "d", (function() {
            return T
        })), n.d(e, "c", (function() {
            return D
        })), n.d(e, "e", (function() {
            return I
        }));
        var r = n(2),
            o = n(7),
            i = n(0),
            a = n(3),
            c = n(8),
            s = n(1),
            u = ["getLog", "getState"];

        function l(t, e, n) {
            try {
                switch (Object(i.g)(u, t) && (Object(s.b)(new Error("Debug call made: ".concat(t)), "debugPublicApi-call-".concat(t)), u = u.filter((function(e) {
                    return e !== t
                }))), t) {
                    case "getLog":
                        return r.a.getState().eventLog;
                    case "getState":
                        return r.a.getState();
                    case "enable":
                        return E("fake_bids", !0), "DEBUG MODE ENABLED";
                    case "disable":
                        return E("fake_bids", !1), "DEBUG MODE DISABLED";
                    case "enableConsole":
                        return m(!1, "command"), "Debug console enabled";
                    case "enableConsoleV2":
                        return m(!0, "command"), "Debug console v2 enabled";
                    case "disableConsole":
                        try {
                            E("console", !1), E("console_v2", !1), null !== f && document.body.removeChild(f), y = !1, Object(o.b)() && o.a.getDefault().localStorage.removeItem(a.f)
                        } catch (e) {
                            Object(s.b)(e, "disableDebugConsole", {
                                makeVisibleToAllUsers: !0
                            })
                        }
                        return "Debug console disabled";
                    case "setDebug":
                        return (E(e, n) ? "Set debug mode '" : "Failed to set debug mode '").concat(e, "' to '").concat(n, "'");
                    default:
                        return "unknown debug argument"
                }
            } catch (e) {
                return Object(s.b)(e, "debugPublicApi", {
                    makeVisibleToAllUsers: !0
                }), "error"
            }
        }
        var f, d, b, p, y = !1;

        function m() {
            var t, e = 0 < arguments.length && void 0 !== arguments[0] && arguments[0];
            try {
                E(e ? "console_v2" : "console", !0), y || (t = {
                    url: e ? r.a.getState().cfg.DEBUG_APP_HTML_V2 : r.a.getState().cfg.DEBUG_APP_HTML,
                    onload: g,
                    onerror: function() {
                        return Object(s.b)(new Error("Error Loading Debug Console"), "enableDebugConsole-".concat(e ? "v2" : "v1", "-onerror"), {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }, Object(c.d)(t), setTimeout((function() {
                    try {
                        Object(i.j)(r.a.getState().config, "pubID") && r.a.getState().config.pubID
                    } catch (t) {
                        Object(s.b)(t, "enableDebugConsole-setTimeout", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }), 5e3))
            } catch (t) {
                Object(s.b)(t, "enableDebugConsole", {
                    makeVisibleToAllUsers: !0
                })
            }
        }

        function g(t) {
            try {
                var e = t.responseText,
                    n = (f = document.createElement("div"), d = document.createElement("div"), b = document.createElement("iframe"), 200);
                T("console_v2") && (n = 330), Object(o.b)() && null !== o.a.getDefault().localStorage.getItem(a.f) && (n = parseInt(o.a.getDefault().localStorage.getItem(a.f), 10)), (isNaN(n) || n > window.innerHeight) && (n = 200), f.style.background = "#eaeded", f.style.zIndex = "2147483647", f.style.bottom = "0", f.style.position = "fixed !important", f.style.display = "block !important", f.style.left = "0", f.style.right = "0", f.style.height = "".concat(n, "px"), d.style.cursor = "row-resize", d.style.height = "2px", d.style.position = "absolute", d.style.top = "0", d.style.left = "0", d.style.right = "0", d.style.backgroundColor = "RGBA(0,0,0,0)", f.appendChild(d), b.frameBorder = "0", b.marginHeight = "0", b.marginWidth = "0", b.scrolling = "no", b.id = "apstag-debug-iframe", b.src = "about:blank", b.style.display = "block", b.style.width = "100%", b.style.height = "".concat(n, "px"), f.appendChild(b), document.body.appendChild(f), null !== b.contentDocument && (b.contentDocument.open(), b.contentDocument.write(e), b.contentDocument.close()), d.addEventListener("mousedown", v)
            } catch (t) {
                Object(s.b)(t, "renderDebugConsole", {
                    makeVisibleToAllUsers: !0
                })
            }
        }

        function h(t) {
            try {
                var e = window.innerHeight - t.clientY;
                return e < 200 && (e = 200), f.style.height = "".concat(e, "px"), b.style.height = "".concat(e, "px"), e
            } catch (t) {
                return Object(s.b)(t, "resizeDebugConsole", {
                    makeVisibleToAllUsers: !0
                }), 200
            }
        }

        function O(t) {
            try {
                return t.stopPropagation && t.stopPropagation(), t.preventDefault && t.preventDefault(), t.cancelBubble = !0, t.returnValue = !1
            } catch (t) {
                return Object(s.b)(t, "preventEvent", {
                    makeVisibleToAllUsers: !0
                }), !1
            }
        }

        function v() {
            try {
                void 0 === p && ((p = document.createElement("div")).style.position = "fixed", p.style.left = "0", p.style.right = "0", p.style.top = "0", p.style.bottom = "0", p.style.zIndex = "9999999999"), f.appendChild(p), window.addEventListener("mouseup", S), window.addEventListener("mousemove", j)
            } catch (t) {
                Object(s.b)(t, "resizeBarMouseDownListener", {
                    makeVisibleToAllUsers: !0
                })
            }
        }

        function j(t) {
            try {
                return h(t), O(t)
            } catch (t) {
                return Object(s.b)(t, "resizeBarMouseMoveListener", {
                    makeVisibleToAllUsers: !0
                }), !1
            }
        }

        function S(t) {
            try {
                null !== p && f.removeChild(p), window.removeEventListener("mousemove", j), window.removeEventListener("mouseup", S);
                var e = h(t);
                return Object(o.b)() && o.a.getDefault().localStorage.setItem(a.f, "".concat(e)), O(t)
            } catch (t) {
                return Object(s.b)(t, "resizeBarMouseUpListener", {
                    makeVisibleToAllUsers: !0
                }), !1
            }
        }

        function w() {
            try {
                if (!Object(o.b)()) return [];
                var t = o.a.getDefault().localStorage.getItem(a.h, {
                        ignoreFailure: !0
                    }),
                    e = (null === t || "false" === t ? t = "[]" : "true" === t && (t = '["fake_bids"]'), []);
                try {
                    e = JSON.parse(t)
                } catch (t) {}
                return (e = Object(i.h)(e) ? e : []).filter((function(t) {
                    return Object(i.g)(a.y, t)
                }))
            } catch (t) {
                return []
            }
        }

        function T(t) {
            try {
                return Object(i.g)(w(), t)
            } catch (t) {
                return !1
            }
        }

        function E(t, e) {
            try {
                var n;
                if (Object(o.b)() && -1 !== a.y.indexOf(t)) return n = w(), e && -1 === n.indexOf(t) ? n.push(t) : e || (n = n.filter((function(e) {
                    return e !== t
                }))), 0 === n.length ? o.a.getDefault().localStorage.removeItem(a.h) : o.a.getDefault().localStorage.setItem(a.h, JSON.stringify(n)), I(), 1
            } catch (e) {
                Object(s.b)(e, "setDebugMode")
            }
        }

        function D(t) {
            var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : null;
            try {
                if (Object(i.j)(window, a.g) && Object(i.j)(window[a.g], t)) return window[a.g][t]
            } catch (t) {
                Object(s.b)(t, "getDebugValue")
            }
            return e
        }
        var _ = [];

        function I() {
            try {
                w().filter((function(t) {
                    return -1 === _.indexOf(t)
                })).forEach((function(t) {
                    Object(s.b)(new Error("Debug method enabled: ".concat(t)), "debugPublicApi-enabled-".concat(t), {
                        makeVisibleToAllUsers: !0
                    }), _.push(t)
                }))
            } catch (t) {
                Object(s.b)(t, "pixelDebugModes")
            }
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "b", (function() {
            return j
        })), n.d(e, "a", (function() {
            return D
        }));
        var r, o, i, a, c = n(1),
            s = n(16),
            u = n(24),
            l = n(2);

        function f(t) {
            return (f = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function d(t, e) {
            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
            t.prototype = Object.create(e && e.prototype, {
                constructor: {
                    value: t,
                    writable: !0,
                    configurable: !0
                }
            }), Object.defineProperty(t, "prototype", {
                writable: !1
            }), e && function(t, e) {
                (Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                    return t.__proto__ = e, t
                })(t, e)
            }(t, e)
        }

        function b(t) {
            var e = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (t) {
                    return !1
                }
            }();
            return function() {
                var n, r = y(t);
                n = e ? (n = y(this).constructor, Reflect.construct(r, arguments, n)) : r.apply(this, arguments), r = this;
                if (n && ("object" === f(n) || "function" == typeof n)) return n;
                if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                return p(r)
            }
        }

        function p(t) {
            if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return t
        }

        function y(t) {
            return (y = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
                return t.__proto__ || Object.getPrototypeOf(t)
            })(t)
        }

        function m(t, e) {
            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
        }

        function g(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, v(r.key), r)
            }
        }

        function h(t, e, n) {
            e && g(t.prototype, e), n && g(t, n), Object.defineProperty(t, "prototype", {
                writable: !1
            })
        }

        function O(t, e, n) {
            (e = v(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function v(t) {
            return t = function(t, e) {
                if ("object" !== f(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== f(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === f(t) ? t : String(t)
        }

        function j() {
            try {
                var t, e, n, r;
                return !(null == (t = window) || null == (e = t.localStorage) || !e.setItem || null == (n = window) || null == (r = n.localStorage) || !r.removeItem)
            } catch (t) {
                return !1
            }
        }(e = r = r || {}).sessionStorage = "sessionStorage", e.localStorage = "localStorage", (o = o || {}).document = "document", (n = i = i || {}).clear = "clear", n.getItem = "getItem", n.key = "key", n.removeItem = "removeItem", n.setItem = "setItem", n.length = "length", (a = a || {}).cookie = "cookie";
        var S = ["AMZN-NoCookieConsent"],
            w = function() {
                function t(e, n) {
                    m(this, t), O(this, "globalContext", void 0), O(this, "stateContainer", void 0), this.globalContext = e, this.stateContainer = n
                }
                return h(t, [{
                    key: "privacyRegulationApplies",
                    value: function() {
                        var t = null == (e = u.a.readStoredConsentData(this.stateContainer)) ? void 0 : e.tcString,
                            e = null == e ? void 0 : e.gdprApplies;
                        return !!("string" == typeof t && 0 < t.length || null != (t = this.globalContext.apstag) && t.isGDPRRegion || e)
                    }
                }, {
                    key: "allowedToStoreAndAccessInformationOnDevice",
                    value: function() {
                        if (this.privacyRegulationApplies()) {
                            var t;
                            if (!(t = null == (t = u.a.readStoredConsentData(this.stateContainer)) ? void 0 : t.tcString) || "string" != typeof t) return {
                                allowed: !1,
                                failures: ["Invalid tcString: ".concat(t)]
                            };
                            var e = Object(s.c)(t);
                            if (!e) return {
                                allowed: !1,
                                failures: ["Invalid tcString: ".concat(t)]
                            };
                            if ((t = Object(s.b)(e)).length) return {
                                allowed: !1,
                                failures: t
                            }
                        }
                        return {
                            allowed: !0,
                            failures: []
                        }
                    }
                }, {
                    key: "ensureStorageUsageIsAllowedOrThrowOnError",
                    value: function(t, e, n) {
                        var r = (o = this.allowedToStoreAndAccessInformationOnDevice()).allowed,
                            o = o.failures;
                        if (!(r || n && 0 < n.length && 0 <= S.indexOf(n[0]))) throw new Error("Not allowed to store or access information on device: ".concat(o));
                        if (!(r = this.globalContext[t])) throw new ReferenceError("Object ".concat(t, " isn't available"));
                        if (void 0 === r[e]) throw new ReferenceError("Method ".concat(e, " isn't available"))
                    }
                }, {
                    key: "executeFunction",
                    value: function(t, e, n, r, o) {
                        return e = this.globalContext[e], (n = (r = r || e[n]).apply(e, t)) && null != o && o.isJson ? JSON.parse(n) : n
                    }
                }, {
                    key: "executeFunctionOrThrowOnError",
                    value: function(t, e, n, r, o) {
                        return this.ensureStorageUsageIsAllowedOrThrowOnError(e, n, t), this.executeFunction(t, e, n, r, o)
                    }
                }, {
                    key: "regulatedMethod",
                    value: function(t, e, n, r) {
                        var o = this;
                        return function() {
                            try {
                                for (var i = arguments.length, a = new Array(i), s = 0; s < i; s++) a[s] = arguments[s];
                                return o.executeFunctionOrThrowOnError(a, t, e, n, r)
                            } catch (i) {
                                if (null == r || !r.ignoreFailure) throw Object(c.b)(i, "RegulatedDataContainer-regulatedMethod"), i
                            }
                        }
                    }
                }]), t
            }(),
            T = function() {
                d(e, w);
                var t = b(e);

                function e() {
                    var n;
                    m(this, e);
                    for (var r = arguments.length, i = new Array(r), c = 0; c < r; c++) i[c] = arguments[c];
                    return O(p(n = t.call.apply(t, [this].concat(i))), "_getItem", (function(t) {
                        var e = n.globalContext.document.cookie.split("; ").reduce((function(e, n) {
                            return (n = n.split("="))[0] === t ? decodeURIComponent(n.slice(1).join("=")) : e
                        }), "");
                        return 0 < e.length ? e : null
                    })), O(p(n), "_removeItem", (function(t) {
                        n.setItem(t, "", 0, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "/")
                    })), O(p(n), "_setItem", (function(t, e, r) {
                        var o = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : "/";
                        r = new Date(r);
                        if (!n.isValidDate(r)) throw new Error("Invalid expiration date");
                        n.globalContext.document.cookie = "".concat(t, "=").concat(e, "; expires=").concat(r.toUTCString(), "; path=").concat(o, ";")
                    })), O(p(n), "getItem", (function(t, e) {
                        return n.regulatedMethod(o.document, a.cookie, n._getItem, e)(t)
                    })), O(p(n), "setItem", (function(t, e, r) {
                        var i = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : "/";
                        return n.regulatedMethod(o.document, a.cookie, n._setItem, 4 < arguments.length ? arguments[4] : void 0)(t, e, r, i)
                    })), O(p(n), "removeItem", (function(t, e) {
                        return n.regulatedMethod(o.document, a.cookie, n._removeItem, e)(t)
                    })), n
                }
                return h(e, [{
                    key: "isValidDate",
                    value: function(t) {
                        return t instanceof Date && !isNaN(t)
                    }
                }]), e
            }(),
            E = function() {
                d(e, w);
                var t = b(e);

                function e(n, r, o) {
                    var a;
                    return m(this, e), O(p(a = t.call(this, n, r)), "storageType", void 0), O(p(a), "clear", (function(t) {
                        return a.regulatedMethod(a.storageType, i.clear, null, t)()
                    })), O(p(a), "getItem", (function(t, e) {
                        return a.regulatedMethod(a.storageType, i.getItem, null, e)(t)
                    })), O(p(a), "key", (function(t, e) {
                        return a.regulatedMethod(a.storageType, i.key, null, e)(t)
                    })), O(p(a), "removeItem", (function(t, e) {
                        return a.regulatedMethod(a.storageType, i.removeItem, null, e)(t)
                    })), O(p(a), "setItem", (function(t, e, n) {
                        return a.regulatedMethod(a.storageType, i.setItem, null, n)(t, e)
                    })), a.storageType = o, a
                }
                return h(e, [{
                    key: "length",
                    get: function() {
                        return this.ensureStorageUsageIsAllowedOrThrowOnError(this.storageType, i.length), this.globalContext[this.storageType].length
                    }
                }]), e
            }(),
            D = function() {
                function t(e) {
                    m(this, t), O(this, "globalContext", void 0), O(this, "stateContainer", void 0), this.globalContext = e.globalContext, this.stateContainer = e.stateContainer
                }
                return h(t, [{
                    key: "sessionStorage",
                    get: function() {
                        try {
                            return new E(this.globalContext, this.stateContainer, r.sessionStorage)
                        } catch (t) {
                            throw Object(c.b)(t, "RegulatedDataContainers-sessionStorage"), t
                        }
                    }
                }, {
                    key: "localStorage",
                    get: function() {
                        try {
                            return new E(this.globalContext, this.stateContainer, r.localStorage)
                        } catch (t) {
                            throw Object(c.b)(t, "RegulatedDataContainers-localStorage"), t
                        }
                    }
                }, {
                    key: "cookie",
                    get: function() {
                        try {
                            return new T(this.globalContext, this.stateContainer)
                        } catch (t) {
                            throw Object(c.b)(t, "RegulatedDataContainers-cookie"), t
                        }
                    }
                }, {
                    key: "indexedDB",
                    get: function() {
                        throw new ReferenceError("Interface isn't yet defined")
                    }
                }, {
                    key: "allowedToStoreAndAccessInformationOnDevice",
                    value: function() {
                        try {
                            return new w(this.globalContext, this.stateContainer).allowedToStoreAndAccessInformationOnDevice().allowed
                        } catch (t) {
                            return Object(c.b)(t, "RegulatedDataContainers-allowedToStoreAndAccessInformationOnDevice"), !1
                        }
                    }
                }], [{
                    key: "getDefault",
                    value: function() {
                        return new t({
                            globalContext: window,
                            stateContainer: l.a
                        })
                    }
                }]), t
            }()
    }, function(t, e, n) {
        "use strict";
        n.d(e, "d", (function() {
            return i
        })), n.d(e, "b", (function() {
            return a
        })), n.d(e, "a", (function() {
            return c
        })), n.d(e, "c", (function() {
            return s
        }));
        var r = n(1);

        function o(t) {
            return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function i(t) {
            var e, n = t.url,
                i = t.onload,
                a = t.onerror,
                c = t.ontimeout,
                s = t.withCredentials,
                u = void 0 === (u = t.body) ? null : u,
                l = void 0 === (e = t.headers) ? null : e,
                f = (t = void 0 === (e = t.trustTokenParameter) ? null : e, new window.XMLHttpRequest);
            try {
                if ("" === n) void 0 !== a && a.call(f, "error");
                else {
                    f.onload = i.bind(null, f), void 0 !== a && (f.onerror = a), void 0 !== c && (f.ontimeout = c), void 0 !== s && (f.withCredentials = s);
                    var d = null !== u ? "POST" : "GET";
                    f.open(d, n), null !== l && "object" === o(l) && Object.keys(l).forEach((function(t) {
                        f.setRequestHeader(t, l[t])
                    }));
                    try {
                        null !== t && "object" === o(t) && window.location === window.parent.location && f.setTrustToken(t)
                    } catch (t) {
                        Object(r.b)(t, "setTrustToken")
                    }
                    f.send(u)
                }
            } catch (t) {
                void 0 !== a && a.call(f, "error"), Object(r.b)(t, "xhrRequest")
            }
        }

        function a(t, e, n, o) {
            try {
                if (void 0 === n && (n = document), void 0 === t) return "function" == typeof e && e(!0), !1;
                var i = n.getElementsByTagName("script")[0] || n.body.firstChild,
                    a = n.createElement("script");
                if (a.type = "text/javascript", a.async = !0, a.src = t, e && c(a, e), c(a, o || function() {
                        Object(r.b)(new Error("Error Loading Script Tag"), "loadScriptTag-onerror")
                    }, [], "onerror"), null !== i.parentNode) return i.parentNode.insertBefore(a, i), !0
            } catch (t) {
                Object(r.b)(t, "loadScriptTag", {
                    makeVisibleToAllUsers: !0
                })
            }
            return !1
        }

        function c(t, e) {
            var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : [],
                o = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : "onload";
            try {
                return "function" == typeof e && (t[o] = function() {
                    e.apply(null, n)
                }, !0)
            } catch (t) {
                return Object(r.b)(t, "addCallbackFunction"), !1
            }
        }

        function s(t) {
            try {
                return encodeURIComponent(JSON.stringify(t))
            } catch (t) {
                return Object(r.b)(t, "objToUrlParam"), ""
            }
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "b", (function() {
            return f
        })), n.d(e, "f", (function() {
            return d
        })), n.d(e, "g", (function() {
            return b
        })), n.d(e, "c", (function() {
            return p
        })), n.d(e, "d", (function() {
            return y
        })), n.d(e, "e", (function() {
            return m
        })), n.d(e, "h", (function() {
            return h
        })), n.d(e, "a", (function() {
            return O
        })), n.d(e, "i", (function() {
            return v
        }));
        var r = n(6),
            o = n(0),
            i = n(7),
            a = n(1),
            c = n(3),
            s = n(2),
            u = n(15);

        function l(t) {
            return (l = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function f(t) {
            try {
                return t.split("_").pop()
            } catch (t) {
                return Object(a.b)(t, "getAmpAmznBidValue"), ""
            }
        }

        function d(t) {
            try {
                var e, n = Object(r.c)("url");
                if (null !== n) return encodeURIComponent(n);
                try {
                    v(t, !1) ? (e = null, t.context && (e = t.context.canonicalUrl || t.context.sourceUrl)) : e = t.top.location.href
                } catch (t) {
                    e = null
                }
                if (null === e || !e || void 0 === e) {
                    e = "";
                    try {
                        t.top !== t.self && (e = t.document.referrer)
                    } catch (t) {}
                }
                return encodeURIComponent(e)
            } catch (t) {
                return Object(a.b)(t, "getCurrentUrl"), ""
            }
        }

        function b(t) {
            try {
                var e, n = "",
                    o = Object(r.c)("url");
                if (null !== o) return encodeURIComponent(o);
                try {
                    try {
                        e = (v(t, !1) && t.context || t.top.document).referrer
                    } catch (n) {
                        e = t.document.referrer
                    }
                    n = encodeURIComponent(e)
                } catch (n) {}
                return n
            } catch (n) {
                return Object(a.b)(n, "getReferrerUrl"), ""
            }
        }

        function p() {
            try {
                var t = {
                    cookiesParams: ""
                };
                return c.j.forEach((function(e, n) {
                    (n = i.a.getDefault().cookie.getItem(n)) && (t.cookiesParams += "&".concat(e, "=").concat(n))
                })), t
            } catch (t) {
                return Object(a.b)(t, "getApsFirstPartyCookies"), {
                    cookiesParams: ""
                }
            }
        }

        function y(t, e) {
            try {
                var n = Object(u._getInitConfig)({
                        overrides: null == e ? void 0 : e.initConfig
                    }).blockedBidders,
                    r = (Object(o.j)(t, "blockedBidders") && Object(o.h)(t.blockedBidders) && (n = t.blockedBidders), "");
                return Object(o.h)(n) ? JSON.stringify(n) : r
            } catch (t) {
                return Object(a.b)(t, "getBlockedBidders", {
                    makeVisibleToAllUsers: !0
                }), ""
            }
        }

        function m() {
            try {
                var t;
                return Object(i.b)() ? (t = s.a.getState(), Object(o.j)(t, "cfg") && Object(o.j)(t.cfg, "v") && -1 !== t.cfg.v ? t.cfg.v : null) : c.p
            } catch (t) {
                return Object(a.b)(t, "getCfgVersion"), null
            }
        }

        function g(t) {
            try {
                if (-1 === ["string", "number"].indexOf(l(t))) return !1;
                var e = Math.floor(Number(t));
                if (e > c.n) return e
            } catch (t) {
                Object(a.b)(t, "parseTimeout", {
                    makeVisibleToAllUsers: !0
                })
            }
            return !1
        }

        function h(t, e) {
            try {
                var n = g(t.timeout);
                return !1 === (n = !1 === n ? g(e.config.bidTimeout) : n) ? g(e.cfg.DEFAULT_TIMEOUT) : n
            } catch (t) {
                return Object(a.b)(t, "getTimeout", {
                    makeVisibleToAllUsers: !0
                }), 2e3
            }
        }

        function O(t, e) {
            var n, r = !1;

            function o(e) {
                if (!r) try {
                    t(e)
                } catch (e) {
                    Object(a.b)(e, "executeFunctionOnceWithTimeout-wrappedFunction", {
                        makeVisibleToAllUsers: !0
                    })
                }
                clearTimeout(n), r = !0
            }
            try {
                return n = setTimeout(o, e, !0), o.bind(null, !1)
            } catch (e) {
                return Object(a.b)(e, "executeFunctionOnceWithTimeout", {
                        makeVisibleToAllUsers: !0
                    }),
                    function() {}
            }
        }

        function v(t, e) {
            try {
                var n = e ? t.AMP_CONTEXT_DATA : t.context;
                return Boolean(n && Object(o.j)(n, "tagName") && "AMP-AD" === n.tagName)
            } catch (t) {
                return Object(a.b)(t, "isInAmpAd"), !1
            }
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return a
        })), n.d(e, "b", (function() {
            return c
        }));
        var r = n(1),
            o = n(0);

        function i(t) {
            return (i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function a(t) {
            try {
                return function(t) {
                    try {
                        var e;
                        return !!c(t, ["number", "string"]) && !(isNaN(t) || "number" != typeof t && (e = parseInt(t, 10), isNaN(e)))
                    } catch (t) {
                        return Object(r.b)(t, "isNumber"), !0
                    }
                }(t) || void 0 === t
            } catch (t) {
                return Object(r.b)(t, "isNumberOrUndefined"), !0
            }
        }

        function c(t, e) {
            try {
                return Object(o.g)(e, i(t))
            } catch (t) {
                return Object(r.b)(t, "isVarOfTypes"), !0
            }
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "b", (function() {
            return i
        })), n.d(e, "a", (function() {
            return a
        })), n.d(e, "d", (function() {
            return c
        })), n.d(e, "c", (function() {
            return s
        }));
        var r = n(1),
            o = n(0);

        function i(t) {
            var e = [];
            try {
                t.hasAdServerObjectLoaded() && (e = t.getSlots())
            } catch (t) {
                Object(r.b)(t, "getDisplayAdServerSlots")
            }
            return e
        }

        function a(t) {
            try {
                return Object(o.j)(t, "sizes") && Object(o.h)(t.sizes) && 0 !== t.sizes.length
            } catch (t) {
                return Object(r.b)(t, "doesSlotHaveSizes"), !1
            }
        }

        function c() {
            for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
            return function(t) {
                try {
                    return !t.mediaType || -1 < e.indexOf(t.mediaType)
                } catch (t) {
                    return Object(r.b)(t, "isSlotOfType"), !0
                }
            }
        }

        function s(t) {
            try {
                return t.slotID
            } catch (t) {
                return Object(r.b)(t, "getSlotID"), ""
            }
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return I
        })), n.d(e, "g", (function() {
            return C
        })), n.d(e, "c", (function() {
            return k
        })), n.d(e, "f", (function() {
            return z
        })), n.d(e, "b", (function() {
            return R
        })), n.d(e, "e", (function() {
            return L
        })), n.d(e, "d", (function() {
            return x
        }));
        var r = n(2),
            o = n(6),
            i = n(3),
            a = n(0),
            c = n(8),
            s = n(1),
            u = n(9),
            l = n(11),
            f = n(4),
            d = n(18),
            b = n(10),
            p = n(17),
            y = n(27),
            m = n(15),
            g = n(5);

        function h(t) {
            return (h = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function O(t) {
            return function(t) {
                if (Array.isArray(t)) return T(t)
            }(t) || function(t) {
                if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t)
            }(t) || w(t) || function() {
                throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }()
        }

        function v(t, e) {
            var n, r = Object.keys(t);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), r.push.apply(r, n)), r
        }

        function j(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? v(Object(n), !0).forEach((function(e) {
                    D(t, e, n[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : v(Object(n)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                }))
            }
            return t
        }

        function S(t, e) {
            return function(t) {
                if (Array.isArray(t)) return t
            }(t) || function(t, e) {
                var n = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                if (null != n) {
                    var r, o, i, a, c = [],
                        s = !0,
                        u = !1;
                    try {
                        if (i = (n = n.call(t)).next, 0 === e) {
                            if (Object(n) !== n) return;
                            s = !1
                        } else
                            for (; !(s = (r = i.call(n)).done) && (c.push(r.value), c.length !== e); s = !0);
                    } catch (t) {
                        u = !0, o = t
                    } finally {
                        try {
                            if (!s && null != n.return && (a = n.return(), Object(a) !== a)) return
                        } finally {
                            if (u) throw o
                        }
                    }
                    return c
                }
            }(t, e) || w(t, e) || function() {
                throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }()
        }

        function w(t, e) {
            var n;
            if (t) return "string" == typeof t ? T(t, e) : "Map" === (n = "Object" === (n = Object.prototype.toString.call(t).slice(8, -1)) && t.constructor ? t.constructor.name : n) || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? T(t, e) : void 0
        }

        function T(t, e) {
            (null == e || e > t.length) && (e = t.length);
            for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
            return r
        }

        function E(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, _(r.key), r)
            }
        }

        function D(t, e, n) {
            (e = _(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function _(t) {
            return t = function(t, e) {
                if ("object" !== h(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== h(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === h(t) ? t : String(t)
        }
        var I = function() {
                function t(e) {
                    if (!(this instanceof t)) throw new TypeError("Cannot call a class as a function");
                    D(this, "bidConfig", void 0), D(this, "bidState", i.c.new), D(this, "_targetingSetID", void 0), D(this, "timing", {
                        setAtTimes: []
                    }), D(this, "pixelSent", !1), D(this, "useSafeFrames", !1), D(this, "bidReqID", ""), D(this, "host", void 0), D(this, "ev", void 0), D(this, "cfe", void 0), D(this, "isAmp", !1), D(this, "doc", void 0), D(this, "inheritSize", void 0), this.bidConfig = e, this._targetingSetID = Object(a.c)(), r.a.getState().config.useSafeFrames && (this.useSafeFrames = !0), this.useSafeFrames && Object(a.j)(e, "targeting") && e.targeting.push("amznhost"), Object(a.j)(e, "meta") ? Object(a.h)(e.meta) || (this.reportError({
                        name: "TypeError",
                        message: "'meta' is not an 'array': ".concat(JSON.stringify(e.meta))
                    }, "constructor-meta"), e.meta = []) : e.meta = [];
                    try {
                        var n = [];
                        Object(a.j)(this.bidConfig, "amzndeals") && (n = this.bidConfig.amzndeals.map((function(t) {
                            return "".concat(t, "amzniid")
                        }))), this.bidConfig.targeting.filter((function(t) {
                            return -1 !== t.indexOf("amzniid") && !Object(a.g)(n, t)
                        }))
                    } catch (e) {
                        this.reportError(e, "pixeling")
                    }
                }
                var e, n;
                return e = t, (n = [{
                    key: "reportError",
                    value: function(t, e, n) {
                        Object(s.b)(t, "Bid-".concat(e), n)
                    }
                }, {
                    key: "mediaType",
                    get: function() {
                        var t = "d";
                        return this.bidConfig.mediaType !== f.a.VIDEO && "v" !== this.bidConfig.mediaType && "v" !== this.bidConfig.mediaType_sp ? t : f.a.VIDEO
                    }
                }, {
                    key: "targeting",
                    get: function() {
                        var t = this;
                        try {
                            return this.bidConfig.targeting.map((function(e) {
                                return "amznhost" === e ? [e, encodeURIComponent(t.host)] : Object(a.j)(t.bidConfig, e) && Object(a.h)(t.bidConfig[e]) ? [e, encodeURIComponent(t.bidConfig[e].join(","))] : Object(a.j)(t.bidConfig, e) ? [e, encodeURIComponent(t.bidConfig[e])] : [e, ""]
                            })).map((function(t) {
                                var e = (t = S(t, 2))[0];
                                t = t[1];
                                return "&".concat(e, "=").concat(t)
                            })).join("")
                        } catch (t) {
                            return this.reportError(t, "targeting"), ""
                        }
                    }
                }, {
                    key: "bidObject",
                    get: function() {
                        try {
                            var t = {
                                slotID: this.bidConfig.slotID,
                                amzniid: this.bidConfig.amzniid,
                                amznbid: this.bidConfig.amznbid,
                                amznp: this.bidConfig.amznp,
                                amznsz: this.bidConfig.amznsz,
                                size: this.bidConfig.amznsz
                            };
                            return this.bidConfig.amznactt && (t.amznactt = this.bidConfig.amznactt), Object(a.j)(this.bidConfig, "amznadm") && (t.amznadm = this.bidConfig.amznadm), this.mediaType === f.a.VIDEO && (t.mediaType = f.a.VIDEO, t.qsParams = this.targeting, t.encodedQsParams = encodeURIComponent(this.targeting), t.r_amznbid = this.bidConfig.r_amznbid, t.r_amzniid = this.bidConfig.r_amzniid, t.r_amznp = this.bidConfig.r_amznp), this.useSafeFrames && (t.amznhost = this.host), t
                        } catch (t) {
                            return this.reportError(t, "bidObject", {
                                makeVisibleToAllUsers: !0
                            }), {
                                slotID: "",
                                amzniid: "error",
                                amznbid: "error",
                                amznp: "error",
                                amznsz: "error",
                                size: "error"
                            }
                        }
                    }
                }, {
                    key: "newBidObject",
                    get: function() {
                        var t = this;
                        try {
                            var e = {
                                    slotID: this.bidConfig.slotID,
                                    size: this.bidConfig.amznsz,
                                    mediaType: this.mediaType,
                                    targeting: {},
                                    helpers: {
                                        targetingKeys: this.bidConfig.targeting,
                                        qsParams: function() {
                                            return t.targeting
                                        },
                                        encodedQsParams: function() {
                                            return encodeURIComponent(t.targeting)
                                        }
                                    }
                                },
                                n = ["slotID", "size", "mediaType"];
                            return this.bidConfig.meta.filter((function(t) {
                                return -1 === n.indexOf(t)
                            })).forEach((function(n) {
                                e[n] = t.bidConfig[n]
                            })), this.bidConfig.targeting.forEach((function(n) {
                                e.targeting[n] = "amznhost" === n ? t.host : t.bidConfig[n]
                            })), void 0 !== this.slotID && -1 !== this.slotID.indexOf("_") && (e.sasTargeting = e.helpers.targetingKeys.map((function(n) {
                                return "".concat(n, "_").concat(t.slotID.split("_")[1], "=").concat(e.targeting[n])
                            })).join(";")), e
                        } catch (t) {
                            return this.reportError(t, "newBidObject", {
                                makeVisibleToAllUsers: !0
                            }), {
                                slotID: "",
                                size: "",
                                mediaType: "d",
                                targeting: {},
                                helpers: {
                                    targetingKeys: [],
                                    qsParams: function() {
                                        return ""
                                    },
                                    encodedQsParams: function() {
                                        return ""
                                    }
                                }
                            }
                        }
                    }
                }, {
                    key: "slotID",
                    get: function() {
                        try {
                            return this.bidConfig.slotID
                        } catch (t) {
                            return this.reportError(t, "slotID"), ""
                        }
                    }
                }, {
                    key: "matchesBidCacheId",
                    value: function(t) {
                        var e = this;
                        try {
                            return this.bidConfig.targeting.reduce((function(n, r) {
                                return n || -1 !== r.indexOf("amzniid") && e.bidConfig[r] === t
                            }), !1)
                        } catch (t) {
                            return this.reportError(t, "matchesBidCacheId"), !1
                        }
                    }
                }]) && E(e.prototype, n), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t
            }(),
            P = Object(a.d)(i.q);

        function A(t, e, n) {
            try {
                var r = Object(a.i)(t.config.params) ? t.config.params : {},
                    o = Object(a.i)(e.params) ? e.params : {},
                    i = "string" == typeof n ? function(t) {
                        if (t = Object(g.a)(t).read("deviceSignal/sua")) try {
                            return {
                                device: {
                                    sua: JSON.parse(t)
                                }
                            }
                        } catch (t) {
                            Object(s.b)(t, "getDeviceNode")
                        }
                        return {}
                    }(n) : {},
                    u = j(j(j({}, r), o), i);
                return 0 === Object.keys(u).length ? "" : Object(c.c)(u)
            } catch (t) {
                return Object(s.b)(t, "getBidParams", {
                    makeVisibleToAllUsers: !0
                }), ""
            }
        }

        function C(t) {
            var e = "validateSupplyChainObject",
                n = !1;

            function r(t, r) {
                return Object(s.b)({
                    name: "TypeError",
                    message: r
                }, "".concat(e, "-").concat(t), {
                    makeVisibleToAllUsers: !0
                }), !(n = !0)
            }
            try {
                return Object(a.i)(t) ? (Object(a.j)(t, "complete") ? -1 === [1, 0].indexOf(t.complete) && r("schain-complete-type", "The `schain.complete` property must be a `1` or `0`") : r("schain-complete", "The `schain.complete` property must be provided"), Object(a.j)(t, "ver") ? Object(b.b)(t.ver, ["string"]) || r("schain-ver-type", "The `schain.ver` property must be a string") : r("schain-ver", "The `schain.ver` property must be provided"), Object(a.j)(t, "nodes") ? Object(a.h)(t.nodes) ? t.nodes.reduce((function(t, e) {
                    return Object(a.i)(e) ? (Object(a.j)(e, "asi") ? Object(b.b)(e.asi, ["string"]) || r("schain-node-asi-type", "All `schain.nodes` items must have an `asi` property of type `string`") : r("schain-node-asi", "All `schain.nodes` items must have an `asi` property"), Object(a.j)(e, "sid") ? Object(b.b)(e.sid, ["string"]) || r("schain-node-sid-type", "All `schain.nodes` items must have an `sid` property of type `string`") : r("schain-node-sid", "All `schain.nodes` items must have an `sid` property"), Object(a.j)(e, "hp") ? -1 === [1, 0].indexOf(e.hp) && r("schain-node-hp-type", "All `schain.nodes` items must have an `hp` property which is `1` or `0`") : r("schain-node-hp", "All `schain.nodes` items must have an `hp` property"), Object(b.b)(e.rid, ["string", "undefined"]) || r("schain-node-rid-type", "If provided, the `rid` property on an `schain.nodes` item must be of type `string`"), Object(b.b)(e.name, ["string", "undefined"]) || r("schain-node-name-type", "If provided, the `name` property on an `schain.nodes` item must be of type `string`"), Object(b.b)(e.domain, ["string", "undefined"]) || r("schain-node-domain-type", "If provided, the `domain` property on an `schain.nodes` item must be of type `string`"), t && !n) : r("schain-node-type", "All `schain.nodes` items must be objects")
                }), !n) : r("schain-nodes-type", "The `schain.nodes` property must be an `Array`") : r("schain-nodes", "The `schain.nodes` property must be provided")) : r("schain", "The `schain` value must be an object")
            } catch (t) {
                return Object(s.b)(t, e, {
                    makeVisibleToAllUsers: !0
                }), !1
            }
        }

        function k(t, e, n, l, b) {
            try {
                var h, v, S, w, T = null != (h = null == b || null == (v = b.initConfig) ? void 0 : v.pubID) ? h : null == (S = r.a.getState().config) ? void 0 : S.pubID,
                    E = r.a.getState(),
                    D = t._endpointDomain || Object(o.c)("host", E.hosts.DEFAULT_AAX_BID_HOST),
                    _ = E.cfg.DTB_PATH,
                    I = "bid",
                    k = (E.experiments.shouldUseTestBidEndpoint && null !== E.cfg.TEST_BID_ENDPOINT && (I = E.cfg.TEST_BID_ENDPOINT), {
                        src: Object(m._getInitConfig)({
                            overrides: null == b ? void 0 : b.initConfig
                        }).pubID,
                        u: null != b && b.contextURL ? encodeURIComponent(b.contextURL) : Object(u.f)(window),
                        pr: Object(u.g)(window),
                        pid: P,
                        cb: t.bidReqID,
                        ws: Object(a.f)(window),
                        v: i.l,
                        t: e,
                        slots: function(t) {
                            try {
                                return Object(c.c)(t.map((function(t) {
                                    var e;
                                    if (Object(a.j)(t, "mediaType") && t.mediaType === f.a.VIDEO || t.mediaType === f.a.MULTI_FORMAT) e = t.aaxSlot;
                                    else {
                                        if (!(Object(a.j)(t, "sizes") && 0 < t.sizes.length && Object(a.j)(t, "slotID"))) return Object(s.b)({
                                            name: "SlotError",
                                            message: "There was an error with the configuration for this slot: ".concat(JSON.stringify(t.rawSlot))
                                        }, "buildSlotsUrlParam-invalidSlot", {
                                            makeVisibleToAllUsers: !0
                                        }), {
                                            id: "ERROR",
                                            mt: d.a.VIDEO,
                                            error: !0
                                        };
                                        var n = t.aaxSlot;
                                        Object(a.j)(t, "slotName") && t.slotName !== t.slotID && (n.sd = t.slotID, n.sn = t.slotName), e = n
                                    }
                                    return e
                                })).filter((function(t) {
                                    return !0 !== t.error
                                })))
                            } catch (t) {
                                return Object(s.b)(t, "buildSlotsUrlParam", {
                                    makeVisibleToAllUsers: !0
                                }), ""
                            }
                        }(t.validSlots),
                        pj: A(E, t, T),
                        sg: Object(y.a)(T),
                        cfgv: Object(u.e)(),
                        bb: Object(u.d)(t),
                        schain: function(t, e) {
                            try {
                                var n, r = Object(g.a)(e).read("ad/schain");
                                if (Object(a.j)(t.config, "schain")) n = t.config.schain;
                                else {
                                    if (!r || !C(r)) return "";
                                    n = r
                                }
                                return encodeURIComponent(["".concat(n.ver, ",").concat(n.complete)].concat(O(n.nodes.map((function(t) {
                                    return ["asi", "sid", "hp", "rid", "name", "domain"].map((function(e) {
                                        return Object(a.j)(t, e) ? t[e] : ""
                                    })).map((function(t) {
                                        return encodeURIComponent(t)
                                    })).map((function(t) {
                                        return t.replace(/\!/g, "%21")
                                    })).join(",")
                                })))).join("!"))
                            } catch (t) {
                                return Object(s.b)(t, "getSupplyChainObject", {
                                    makeVisibleToAllUsers: !0
                                }), ""
                            }
                        }(E, T)
                    });
                try {
                    var z = Object(g.a)(T).read("deviceSignal/cookieDeprecationLabel");
                    z && "" !== z && (k.cdep = encodeURIComponent(z))
                } catch (t) {}
                try {
                    var R = Object(g.a)(T).read("consent/GPPData") || {},
                        L = R.gppString,
                        x = R.applicableSections,
                        U = 0 < (L || "").length,
                        B = 0 < (x || []).length;
                    U && (k.gpp = encodeURIComponent(L)), B && (k.gpp_sid = encodeURIComponent(JSON.stringify(x)))
                } catch (t) {
                    Object(s.b)(t, "gpp")
                }
                if ("[]" === k.slots || "" === k.slots) throw new Error("No slots available for bid request");
                try {
                    var V = Object(g.a)(T).read("sessionMarker/marker");
                    0 < (null != V ? V : "").length && (k.sm = encodeURIComponent(V.split("_")[0]))
                } catch (t) {}
                r.a.dispatch({
                    type: "RECORD_AAX_REQUEST",
                    data: {
                        bidConfig: t,
                        bidReqID: t.bidReqID,
                        timeout: e,
                        ws: k.ws,
                        url: k.u,
                        rqTs: Date.now()
                    }
                }), E.experiments.chunkRequests && (w = t.bidReqID.split("-"), r.a.dispatch({
                    type: "RECORD_NETWORK_EXCHANGE",
                    fid: w[0],
                    networkID: parseInt(w[1], 10),
                    timestamp: Date.now(),
                    exchangeType: "request"
                })), Object(m._getInitConfig)({
                    overrides: null == b ? void 0 : b.initConfig
                }).isSelfServePub && (k.pubid = k.src, k.src = 600);
                var M = Object(u.c)(),
                    N = Object(o.c)("bidParams"),
                    F = (Object(a.i)(N) && (k = j(j({}, k), N)), Object(a.i)(n) && (Object(a.j)(n, "enabled") && (k.gdpre = encodeURIComponent(n.enabled)), Object(a.j)(n, "consent") && (k.gdprc = encodeURIComponent(n.consent)), Object(a.j)(n, "log")) && (k.gdprl = Object(c.c)(n.log)), Object(a.j)(Object(m._getInitConfig)({
                        overrides: null == b ? void 0 : b.initConfig
                    }), "useSafeFrames") && Object(m._getInitConfig)({
                        overrides: null == b ? void 0 : b.initConfig
                    }).useSafeFrames && (k.sf = "1"), Object(p.b)()),
                    q = (F && (l.ids.at = F), k.vm = function(t, e) {
                        var n = !t || 0 === Object.keys(t.ids).length,
                            r = n ? "" : Object(c.c)({
                                ids: t.ids,
                                md: t.md
                            });
                        try {
                            Object(g.a)(e).safelyRecord("ortbVendors/all/process");
                            var o = Object(g.a)(e).read("ortbVendors/vm");
                            o && (r = n ? Object(c.c)({
                                vendors: o
                            }) : Object(c.c)({
                                ids: t.ids,
                                md: t.md,
                                vendors: o
                            }))
                        } catch (t) {
                            Object(s.b)(t, "getVmParam")
                        }
                        return r
                    }(l, T), Object.keys(k).filter((function(t) {
                        return Object(a.j)(k, t) && "undefined" !== k[t] && "" !== k[t] && null !== k[t]
                    })).map((function(t) {
                        return "".concat(t, "=").concat(k[t])
                    })).join("&"));
                M.cookiesParams && (q += M.cookiesParams);
                var H = "".concat(i.r).concat(D).concat(_, "/").concat(I, "?").concat(q);
                return r.a.dispatch({
                    type: "RECORD_AAX_REQ_PROP",
                    bidReqID: t.bidReqID,
                    key: "urlLength",
                    value: H.length
                }), H
            } catch (t) {
                return Object(s.b)(t, "buildBidUrl", {
                    makeVisibleToAllUsers: !0
                }), ""
            }
        }

        function z(t, e) {
            try {
                return Object(a.j)(t, "deals") && !0 === t.deals || !0 === e.needNewBidObject
            } catch (t) {
                return Object(s.b)(t, "isNewBidObjectRequired"), !1
            }
        }

        function R(t, e, n) {
            try {
                var r = t.map(l.c),
                    o = e.slots.filter(Object(l.d)(f.a.DISPLAY, f.a.MULTI_FORMAT)).map(l.c).filter((function(t) {
                        return !Object(a.g)(r, t)
                    })),
                    c = n ? i.t.bidInFlight : i.t.noBid;
                return t.concat(o.map((function(t) {
                    return new I({
                        size: "0x0",
                        crid: "",
                        slotID: t,
                        mediaType: "d",
                        meta: ["slotID", "mediaType", "size"],
                        amznbid: c,
                        amzniid: "",
                        amznp: c,
                        amznsz: "0x0",
                        targeting: ["amzniid", "amznbid", "amznp", "amznsz"]
                    })
                })))
            } catch (e) {
                return Object(s.b)(e, "addStateTrackingBidsToRealBids"), t
            }
        }

        function L(t, e) {
            try {
                var n;
                return !Object(a.g)(r.a.getState().displayAdServer.noBidSlotIDs, t.slotID) && (n = r.a.getState().AAXReqs.filter((function(e) {
                    return e.bidReqID === t.bidReqID
                }))[0], !(Object(a.j)(n, "rqTs") && Date.now() - n.rqTs > 24e4 || Object(a.j)(n, "url") && !Object(a.b)(n.url, null != e && e.contextURL ? encodeURIComponent(e.contextURL) : Object(u.f)(window)) || t.bidState === i.c.rendered))
            } catch (e) {
                return Object(s.b)(e, "isBidEligible"), !1
            }
        }

        function x(t, e) {
            try {
                var n = t.map(l.c),
                    o = r.a.getState();
                return Object.keys(o.slotBids).filter((function(t) {
                    return Object(a.g)(n, t)
                })).reduce((function(t, n) {
                    var a = o.slotBids[n].filter((function(t) {
                        return t.bidState === i.c.new
                    })).filter((function(t) {
                        return L(t, e)
                    }));
                    return 0 < a.length && (a = a[a.length - 1], r.a.dispatch({
                        type: "BID_STATE_CHANGE",
                        slotID: n,
                        _targetingSetID: a._targetingSetID,
                        bidState: i.c.exposed
                    }), t[n] = a), t
                }), {})
            } catch (t) {
                return Object(s.b)(t, "getNewSlotBidsAndExposeForRequestedSlots"), {}
            }
        }
    }, function(t, e, n) {
        "use strict";

        function r(t) {
            return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function o(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, a(r.key), r)
            }
        }

        function i(t, e, n) {
            (e = a(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function a(t) {
            return t = function(t, e) {
                if ("object" !== r(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== r(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === r(t) ? t : String(t)
        }
        n.d(e, "a", (function() {
            return c
        }));
        var c = function() {
            function t() {
                if (!(this instanceof t)) throw new TypeError("Cannot call a class as a function");
                i(this, "isSupported", !1), i(this, "needNewBidObject", !1)
            }
            var e, n;
            return e = t, (n = [{
                key: "cmdQueuePush",
                value: function(t) {}
            }, {
                key: "slotRenderEndedEvent",
                value: function(t) {}
            }, {
                key: "setTargeting",
                value: function(t, e) {}
            }, {
                key: "getTargeting",
                value: function(t) {
                    return []
                }
            }, {
                key: "clearTargeting",
                value: function(t, e) {}
            }, {
                key: "hasAdServerObjectLoaded",
                value: function() {
                    return !1
                }
            }, {
                key: "isCommandQueueDefined",
                value: function() {
                    return !1
                }
            }, {
                key: "getSlots",
                value: function() {
                    return []
                }
            }]) && o(e.prototype, n), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t
        }()
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return l
        }));
        var r = n(0),
            o = n(1),
            i = n(4);

        function a(t) {
            return (a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function c(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, u(r.key), r)
            }
        }

        function s(t, e, n) {
            (e = u(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function u(t) {
            return t = function(t, e) {
                if ("object" !== a(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== a(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === a(t) ? t : String(t)
        }
        var l = function() {
            function t(e) {
                if (!(this instanceof t)) throw new TypeError("Cannot call a class as a function");
                s(this, "_slotConfig", void 0), s(this, "rawSlot", void 0), this._slotConfig = e, this.rawSlot = e
            }
            var e, n;
            return e = t, (n = [{
                key: "slotID",
                get: function() {
                    return this._slotConfig.slotID
                }
            }, {
                key: "slotName",
                get: function() {
                    return this._slotConfig.slotName
                }
            }, {
                key: "slotParams",
                get: function() {
                    return this._slotConfig.slotParams
                }
            }, {
                key: "companions",
                get: function() {
                    return this._slotConfig.companions
                }
            }, {
                key: "slotConfig",
                get: function() {
                    return {
                        slotID: this.slotID,
                        slotName: this.slotName,
                        sizes: this.sizes
                    }
                }
            }, {
                key: "mediaType",
                get: function() {
                    return i.a.DISPLAY
                }
            }, {
                key: "sizes",
                get: function() {
                    return []
                }
            }, {
                key: "floor",
                get: function() {
                    var t;
                    return Object(r.j)(this._slotConfig, "floor") && "USD" === this._slotConfig.floor.currency && this.validateFloorValue(this._slotConfig.floor.value) ? this._slotConfig.floor : t
                }
            }, {
                key: "aaxSlotParams",
                get: function() {
                    var t = this;
                    try {
                        return Object(r.j)(this, "slotParams") && Object(r.i)(this.slotParams) ? Object.keys(this.slotParams).filter((function(e) {
                            return t.validateSlotParamValue(t.slotParams[e])
                        })).reduce((function(e, n) {
                            return e[n] = t.slotParams[n], e
                        }), {}) : void 0
                    } catch (t) {
                        return this.reportError(t, "aaxSlotParams"), this.slotParams
                    }
                }
            }, {
                key: "aaxSlot",
                get: function() {
                    var t = {
                        kv: this.aaxSlotParams
                    };
                    return this.floor && (t.fc = this.floor.currency, t.fp = this.floor.value), t
                }
            }, {
                key: "isValid",
                value: function() {
                    var t, e, n = [],
                        o = [];
                    return void 0 === this.slotID ? n.push("'slotID' must be provided and a string") : "string" != typeof this.slotID && o.push("'slotID' must be a string"), Object(r.j)(this._slotConfig, "floor") && Object(r.i)(this._slotConfig.floor) && (t = (e = this._slotConfig.floor).currency, e = e.value, "USD" !== t && o.push("'floor' currency only supports USD"), this.validateFloorValue(e) || o.push("'floor' value must be a positive integer")), Object(r.j)(this, "companions") && (Object(r.h)(this.companions) ? this.companions.forEach((function(t) {
                        "string" != typeof t && n.push("'companions' contains a non-string item : ".concat(t))
                    })) : n.push("'companions' contains non-array")), 0 < n.length ? (this.reportIsValidMessages([].concat(n, o), !0), !1) : (0 < o.length && this.reportIsValidMessages(o, !1), !0)
                }
            }, {
                key: "reportError",
                value: function(t, e, n) {
                    Object(o.b)(t, "Slot-".concat(e), n)
                }
            }, {
                key: "setTargeting",
                value: function(t, e) {}
            }, {
                key: "getTargeting",
                value: function(t) {
                    return []
                }
            }, {
                key: "clearTargeting",
                value: function(t) {}
            }, {
                key: "reportIsValidMessages",
                value: function(t, e) {
                    this.reportError({
                        name: "SlotValidationError",
                        message: this.buildIsValidMessage(t, this._slotConfig)
                    }, "validation-".concat(e ? "error" : "warn"), {
                        makeVisibleToAllUsers: !0
                    })
                }
            }, {
                key: "validateSlotParamValue",
                value: function(t) {
                    var e = this;
                    try {
                        return Object(r.h)(t) ? 0 < t.length && t.reduce((function(t, n) {
                            return t && e.validateSlotParamValue(n)
                        }), !0) : "string" == typeof t && 0 < t.length
                    } catch (t) {
                        return Object(o.b)(t, "validateSlotParamValue"), !1
                    }
                }
            }, {
                key: "validateFloorValue",
                value: function(t) {
                    return "number" == typeof t && 0 < t && t % 1 == 0
                }
            }, {
                key: "buildIsValidMessage",
                value: function(t, e) {
                    return "There was an issue with the configuration for this slot: ".concat(JSON.stringify(e), "\n") + t.map((function(t) {
                        return "- ".concat(t)
                    })).join("\n")
                }
            }]) && c(e.prototype, n), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t
        }()
    }, function(i, t, e) {
        "use strict";
        e.r(t), e.d(t, "unsafelyGuessAccountID", (function() {
            return Jt
        })), e.d(t, "_getInitConfig", (function() {
            return te
        }));
        var Dt = e(16),
            Tt = e(2),
            _t = e(9),
            Et = e(0),
            It = e(11),
            Pt = e(6),
            At = e(3),
            Ct = e(29),
            kt = e(23),
            Rt = e(20),
            zt = e(1),
            Lt = e(8),
            ee = e(26),
            n = e(30),
            xt = e(28),
            Ut = e(12),
            a = e(13),
            Nt = e(4),
            Bt = e(10),
            Vt = e(19),
            Mt = e(17),
            Ft = e(31),
            ne = e(35),
            qt = e(22),
            re = e(37),
            oe = e(24),
            Ht = e(5),
            Gt = e(7),
            Qt = e(32),
            ie = e(27),
            ae = e(36);

        function Xt(t) {
            return l(t) || u(t) || s(t) || c()
        }

        function c() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }

        function s(t, e) {
            var n;
            if (t) return "string" == typeof t ? r(t, e) : "Map" === (n = "Object" === (n = Object.prototype.toString.call(t).slice(8, -1)) && t.constructor ? t.constructor.name : n) || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? r(t, e) : void 0
        }

        function u(t) {
            if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t)
        }

        function l(t) {
            if (Array.isArray(t)) return r(t)
        }

        function r(t, e) {
            (null == e || e > t.length) && (e = t.length);
            for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
            return r
        }

        function Wt(t) {
            return (Wt = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function o(t, e) {
            var n, r = Object.keys(t);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), r.push.apply(r, n)), r
        }

        function Yt(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? o(Object(n), !0).forEach((function(e) {
                    $t(t, e, n[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                }))
            }
            return t
        }

        function $t(t, e, n) {
            return (e = f(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n, t
        }

        function f(t) {
            return "symbol" === Wt(t = d(t, "string")) ? t : String(t)
        }

        function d(t, e) {
            if ("object" !== Wt(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === e ? String : Number)(t);
            if ("object" !== Wt(n = n.call(t, e || "default"))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }
        var Kt = new a.a;

        function Jt(t) {
            try {
                var e;
                if ("string" == typeof t && 0 < t.trim().length) return t;
                if ("number" == typeof t && 0 < t) return t.toString();
                var n = null == (e = Tt.a.getState().config) ? void 0 : e.pubID;
                if (n && "number" == typeof n && 0 < n) return n.toString();
                if (n && "string" == typeof n && "" !== n) return n;
                var r = Array.from(window._aps.keys()).filter((function(t) {
                    return "_system" !== t && "" !== t
                }))[0];
                if (r) return r
            } catch (t) {}
            return "_system"
        }

        function Zt(t, e, n, r) {
            try {
                Object(Ht.a)(t).safelyRecord("cellophane/".concat(e, "/enter"), $t({}, r, n));
                var o = Object(Ht.a)(t).read("cellophane/".concat(r));
                void 0 !== n && void 0 === o ? Object(Et.k)(1) && Object(zt.b)(new Error("Missing ".concat(r, " from client")), "cellophaneWrap") : n = o
            } catch (t) {
                Object(zt.b)(t, "cellophaneWrap")
            }
            return n
        }

        function te(t) {
            return t = t.overrides, Yt(Yt({}, Tt.a.getState().config), t)
        }
        try {
            var b = Object(n.b)(window.apstag);
            b ? Object(zt.b)(new Error("apstag has already loaded - preventing duplicate load"), "apstag-duplicateLoad") : (Object(n.a)(window) && Object(zt.b)(new Error("apstag was loaded and then destroyed"), "apstag-destroyReload", {
                makeVisibleToAllUsers: !0
            }), window.apstagLOADED = !0, function() {
                Object(Et.k)(1) && Object(zt.b)(new Error("apstag-".concat(At.l, " reference pixel - Used to compute ratios for other errors")), "REFERENCE");
                var a = new oe.a({
                        stateContainer: Tt.a,
                        globalContext: window
                    }),
                    t = (a.attemptConsentDataSync(), "ls"),
                    n = Object(Pt.d)("console") || function() {
                        try {
                            return -1 !== window.location.href.indexOf("amzn_debug_console=1") && (t = "url", !0)
                        } catch (t) {
                            return !1
                        }
                    }(),
                    r = Object(Pt.d)("console_v2") || function() {
                        try {
                            return -1 !== window.location.href.indexOf("amzn_debug_console=2") && (t = "url", !0)
                        } catch (t) {
                            return !1
                        }
                    }();

                function o(t) {
                    try {
                        return !Tt.a.getState().experiments.chunkRequests || 0 === Tt.a.getState().bidReqs[t.split("-")[0]].networkReqs.filter((function(t) {
                            return t.inFlight
                        })).length
                    } catch (t) {
                        return Object(zt.b)(t, "_isRequestComplete"), 1
                    }
                }

                function c(t, e) {
                    try {
                        !Tt.a.getState().bidReqs[t].hasCallbackExecuted && o(t) && (Tt.a.dispatch({
                            type: "RECORD_CALLBACK",
                            fid: t
                        }), e())
                    } catch (t) {
                        Object(zt.b)(t, "_checkAndCallCallback")
                    }
                }

                function s(t) {
                    try {
                        Tt.a.getState().experiments.chunkRequests && Tt.a.dispatch({
                            type: "RECORD_NETWORK_EXCHANGE",
                            fid: t[0],
                            timestamp: Date.now(),
                            exchangeType: "response",
                            networkID: parseInt(t[1], 10)
                        })
                    } catch (t) {
                        Object(zt.b)(t, "_recordResponse")
                    }
                }

                function b(t, e, n, r, o) {
                    var i = n.split("-");
                    Object(Ht.a)(r).record("adExchange/bid/fetch", {
                        URL: t,
                        fetchBidsConfig: o
                    }).catch((function() {})).finally((function() {
                        s(i), c(i[0], e)
                    }))
                }

                function i(t) {
                    try {
                        var e = new Date;
                        return e.setTime(e.getTime() + 1e3 * t), e.toUTCString()
                    } catch (t) {
                        return Object(zt.b)(t, "_getCookieExpiry"), "Thu, 01 Jan 1970 00:00:00 GMT"
                    }
                }

                function e(t) {
                    try {
                        Object(Et.j)(t, "cr") && t.cr.forEach((function(t) {
                            var e = -1 !== t.exp ? i(t.exp) : Object(Et.e)(365);
                            Gt.a.getDefault().cookie.setItem(t.k, t.v, e)
                        }))
                    } catch (t) {
                        Object(zt.b)(t, "_setFirstPartyCookies")
                    }
                }

                function x(t, e, n) {
                    try {
                        var r;
                        Object(Et.j)(t, "cb") && (Tt.a.dispatch({
                            type: "RECORD_AAX_REQ_PROP",
                            bidReqID: t.cb,
                            key: "resTs",
                            value: Date.now()
                        }), r = new RegExp("e/dtb/bid.*cb=".concat(t.cb)), Tt.a.dispatch({
                            type: "RECORD_AAX_REQ_PROP",
                            bidReqID: t.cb,
                            key: "perf",
                            value: Object(Ct.b)(window, r)
                        })), Object(Et.j)(t, "cfg") && Tt.a.dispatch({
                            type: "SET_CFG",
                            cfg: t.cfg
                        }), nt(t, e, n)
                    } catch (t) {
                        Object(zt.b)(t, "_doOnAaxResponse", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function U(t) {
                    try {
                        Object(Qt.b)(t), e(t), Object(Et.j)(t, "cfg") && Gt.a.getDefault().localStorage.setItem(At.d, JSON.stringify(t.cfg), {
                            ignoreFailure: !0
                        }), N(t)
                    } catch (t) {
                        Object(zt.b)(t, "_doAfterAaxResponse", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function N(t) {
                    try {
                        var e;
                        Object(Et.j)(t, "fp") && (e = t.fp, Object(Et.j)(e, "length")) && e.forEach((function(t) {
                            var e = t.d || 0;
                            setTimeout((function() {
                                Object(ae.a)(t.s)
                            }), e)
                        }))
                    } catch (t) {
                        Object(zt.b)(t, "fireAAXPixels")
                    }
                }

                function B() {
                    try {
                        Tt.a.getState().Q.forEach((function(t) {
                            var e = "init";
                            switch (t[0]) {
                                case "i":
                                    e = "init";
                                    break;
                                case "f":
                                    e = "fetchBids";
                                    break;
                                case "di":
                                    e = "deleteId";
                                    break;
                                case "ri":
                                    e = "renewId";
                                    break;
                                case "ui":
                                    e = "updateId";
                                    break;
                                default:
                                    return
                            }
                            window.apstag[e].apply(null, t[1])
                        }))
                    } catch (t) {
                        Object(zt.b)(t, "_QHandler", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function V(t) {
                    try {
                        Object(Et.i)(t) || (Object(zt.c)("init.config", Wt(t), "object"), t = {
                            pubID: "err"
                        }), Object(Bt.b)(t.pubID, ["string", "number"]) ? "number" == typeof t.pubID && (t.pubID = "".concat(t.pubID)) : Object(zt.c)("init.config.pubID", Wt(t.pubID), "string"), Object(Bt.b)(t.adServer, ["undefined", "string"]) || Object(zt.c)("init.config.adServer", Wt(t.adServer), "string"), Object(Bt.a)(t.bidTimeout) || ("string" == typeof t.bidTimeout ? Object(zt.b)({
                            name: "string-".concat(t.bidTimeout),
                            message: "init.config.bidTimeout was a non-numeric string '".concat(t.bidTimeout, "'")
                        }, "TypeError-init.config.bidTimeout", {
                            makeVisibleToAllUsers: !0
                        }) : Object(zt.c)("init.config.bidTimeout", Wt(t.bidTimeout), "number")), Object(Bt.b)(t.gdpr, ["undefined", "object"]) ? "object" !== Wt(t.gdpr) || Object(Bt.a)(t.gdpr.cmpTimeout) || (Object(Bt.b)(t.gdpr.cmpTimeout, ["string", "undefined"]) ? Object(zt.b)({
                            name: "string-".concat(t.bidTimeout),
                            message: "init.config.gdpr.cmpTimeout was a non-numeric string '".concat(t.gdpr.cmpTimeout, "'")
                        }, "TypeError-init.config.gdpr.cmpTimeout", {
                            makeVisibleToAllUsers: !0
                        }) : Object(zt.c)("init.config.gdpr.cmpTimeout", Wt(t.gdpr.cmpTimeout), "number")) : Object(zt.c)("init.config.gdpr", Wt(t.gdpr), "object"), Object(Et.j)(t, "params") && !Object(Et.i)(t.params) ? Object(zt.c)("init.config.params", Wt(t.params), "object") : Object(Et.j)(t, "params") && Object.keys(t.params).forEach((function(e) {
                            return !(!Object(Et.j)(t, "params") || "string" != typeof t.params[e] && "number" != typeof t.params[e] && (Object(Et.h)(t.params[e]) ? !t.params[e].reduce((function(t, e) {
                                return t && ("string" == typeof e || "number" == typeof e)
                            }), !0) && (Object(zt.b)({
                                name: "non-string array item",
                                message: "'init.config.params.".concat(e, " contains a non-string item")
                            }, "TypeError-init.config.params.".concat(e), {
                                makeVisibleToAllUsers: !0
                            }), 1) : (Object(zt.c)("init.config.params.".concat(e), Wt(t.params[e]), "string' or 'array"), 1)))
                        })), Object(Et.j)(t, "blockedBidders") && !Object(Et.h)(t.blockedBidders) ? Object(zt.c)("init.config.blockedBidders", Wt(t.blockedBidders), "array") : Object(Et.j)(t, "blockedBidders") && Object(Et.h)(t.blockedBidders) && (t.blockedBidders.reduce((function(t, e) {
                            return t && ("string" == typeof e || "number" == typeof e)
                        }), !0) || Object(zt.b)({
                            name: "non-string array item",
                            message: "'init.config.blockedBidders contains a non-string item"
                        }, "TypeError-init.config.blockedBidders", {
                            makeVisibleToAllUsers: !0
                        })), Object(Bt.b)(t.simplerGPT, ["undefined", "boolean"]) || Object(zt.c)("init.config.simplerGPT", Wt(t.simplerGPT), "boolean"), Object(Bt.b)(t.deals, ["undefined", "boolean"]) || Object(zt.c)("init.config.deals", Wt(t.deals), "boolean"), Object(Bt.b)(t.schain, ["undefined", "object"]) && null !== t.schain ? Object(Et.j)(t, "schain") && !Object(Ut.g)(t.schain) && delete t.schain : (Object(zt.c)("init.config.schain", Wt(t.schain), "object"), delete t.schain), Object(Bt.b)(t.useSafeFrames, ["undefined", "boolean"]) || (Object(zt.c)("init.config.useSafeFrames", Wt(t.useSafeFrames), "boolean"), delete t.useSafeFrames), Object(Bt.b)(t.signals, ["undefined", "object"]) ? delete t.signals : Object(zt.c)("init.config.signals", Wt(t.signals), "object")
                    } catch (e) {
                        Object(zt.b)(e, "_validateAndStoreConfig-validateConfig")
                    }
                    try {
                        var e = Tt.a.getState().config;
                        Object(Et.j)(e, "pubID") && Object(Et.j)(t, "pubID") && e.pubID !== t.pubID && Object(zt.b)(new Error("`apstag.init` was called multiple times with different pubIDs (".concat(e.pubID, " then ").concat(t.pubID, ")")), "_validateAndStoreConfig-diffPubId", {
                            makeVisibleToAllUsers: !0
                        }), Tt.a.dispatch({
                            type: "SET_CONFIG",
                            config: t,
                            defaultCmpTimeout: Tt.a.getState().cfg.GDPR_CMP_TIMEOUT
                        })
                    } catch (e) {
                        Object(zt.b)(e, "_validateAndStoreConfig", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function u(t, e, n) {
                    try {
                        var r = t.slotID,
                            o = !1;
                        Object(Et.j)(t.bidConfig, "amznbid") && "o_" === t.bidConfig.amznbid.slice(0, 2) && (o = !0), Object(Et.j)(t.bidConfig, "mediaType") && "v" === t.bidConfig.mediaType && !1 === o || (!window.IntersectionObserver && o ? Object(zt.b)({
                            name: "IntersectionObserver",
                            message: "IntersectionObserver not supported "
                        }, "_safeApplySlotTargeting") : e.hasAdServerObjectLoaded() ? e.isCommandQueueDefined() ? e.hasAdServerObjectLoaded() ? null !== l(r, e) ? y(t, e, n) : Object(zt.a)("".concat(r, " isn't defined when trying to set amazon bid!")) : e.cmdQueuePush((function() {
                            u(t, e, n)
                        })) : Object(zt.a)("displayAdServer Object's cmd queue hasn't been defined", !0) : Object(zt.a)("displayAdServer Object hasn't been defined", !0))
                    } catch (t) {
                        Object(zt.b)(t, "_safeApplySlotTargeting", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function l(t, e) {
                    var n = null;
                    try {
                        n = Object(It.b)(e).filter((function(e) {
                            return e.slotID === t
                        }))[0] || null
                    } catch (e) {
                        Object(zt.b)(e, "_getAdServerSlot")
                    }
                    return n
                }

                function f(t, e) {
                    try {
                        var n = Tt.a.getState().targetingKeys[t.slotID];
                        e.hasAdServerObjectLoaded() && Object(Et.h)(n) && n.forEach((function(e) {
                            return 0 < t.getTargeting(e).length && t.clearTargeting(e)
                        }))
                    } catch (e) {
                        Object(zt.b)(e, "_clearTargetingFromSlot", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function d(t) {
                    try {
                        var e;
                        Object(Et.j)(Tt.a.getState().slotBids, t.slotID) && (e = Tt.a.getState().slotBids[t.slotID].filter((function(t) {
                            return t.bidState === At.c.set
                        }))[0]) && e.bidState === At.c.set && Tt.a.dispatch({
                            type: "BID_STATE_CHANGE",
                            slotID: t.slotID,
                            _targetingSetID: e._targetingSetID,
                            bidState: At.c.exposed
                        })
                    } catch (t) {
                        Object(zt.b)(t, "_clearBidSetOnSlot", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function M(t, e) {
                    try {
                        return t.map((function(t) {
                            return Object(Et.g)(e, t)
                        })).filter((function(t) {
                            return t
                        })).length === t.length
                    } catch (t) {
                        Object(zt.b)(t, "_hasAllItemsInArray")
                    }
                }

                function p(t) {
                    var e = {};
                    try {
                        Object.keys(Tt.a.getState().slotBids).forEach((function(n) {
                            var r = Tt.a.getState().slotBids[n].filter((function(e) {
                                return Object(Ut.e)(e, t)
                            }));
                            0 < r.length && (e[n] = r.map((function(t) {
                                var e = Tt.a.getState().AAXReqs.filter((function(e) {
                                        return e.bidReqID === t.bidReqID
                                    })),
                                    n = 0;
                                return 0 < e.length ? n = e[0].rqTs : (e = Tt.a.getState().AAXReqs.map((function(t) {
                                    return t.bidReqID
                                })).join(", "), Object(zt.b)({
                                    name: "BidError",
                                    message: "Request not found: ".concat(t.bidReqID, " not found in ").concat(e)
                                }, "_getCurrentSlotBids-noRequest")), {
                                    rqTs: n,
                                    bid: t
                                }
                            })).reduce((function(t, e) {
                                return t.rqTs > e.rqTs ? t : e
                            })).bid)
                        }))
                    } catch (t) {
                        Object(zt.b)(t, "_getCurrentSlotBids", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                    return e
                }

                function F(t, e) {
                    try {
                        return Object(Et.h)(Tt.a.getState().targetingKeys[t]) ? e ? ["amzniid_sp"] : Tt.a.getState().targetingKeys[t].filter((function(t) {
                            return -1 < t.indexOf("amzniid") && t.indexOf("amzniid_sp") < 0
                        })) : ["amzniid"]
                    } catch (t) {
                        return Object(zt.b)(t, "_getAllBidIdKeys"), []
                    }
                }

                function q(t, e) {
                    var n, r;
                    try {
                        var o = Tt.a.getState().slotBids;
                        Object.keys(o).forEach((function(i) {
                            o[i].forEach((function(o) {
                                F(i, e).forEach((function(e) {
                                    o.bidConfig[e] === t && (n = o, "amzniid_sp" === e ? r = "sp" : "amzniid" !== e && (r = e.substr(0, e.indexOf("amzniid"))))
                                }))
                            }))
                        }))
                    } catch (t) {
                        Object(zt.b)(t, "_findSlotBidByBidID", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                    return {
                        slotBid: n,
                        dealId: r
                    }
                }

                function H(t, e, n) {
                    var r = "";
                    try {
                        e.bidConfig[n + "amzniid"] === t && (r = n.split("_").pop().trim())
                    } catch (t) {
                        Object(zt.b)(t, "_getPMPBidSize")
                    }
                    return r
                }

                function G(t) {
                    try {
                        var e;
                        return void 0 === t.slots ? [] : (e = {}, t.slots.forEach((function(t) {
                            t.mediaType !== Nt.a.VIDEO && "v" !== t.mediaType && "v" !== t.mediaType_sp || (0 <= t.slotID.indexOf("rsv-") && (t = {
                                slotID: t.slotID.substring(4),
                                r_amznbid: t.amznbid,
                                r_amzniid: t.amzniid,
                                r_amznp: t.amznp,
                                mediaType: Nt.a.VIDEO,
                                targeting: ["r_amznbid", "r_amzniid", "r_amznp"],
                                amznsz: t.amznsz,
                                size: t.size,
                                crid: t.crid,
                                meta: t.meta
                            }), !Object(Et.j)(e, t.slotID)) ? e[t.slotID] = new Ut.a(t) : t.targeting.forEach((function(n) {
                                e[t.slotID].bidConfig[n] = t[n], -1 === e[t.slotID].bidConfig.targeting.indexOf(n) && e[t.slotID].bidConfig.targeting.push(n)
                            }))
                        })), Object.keys(e).map((function(t) {
                            return e[t]
                        })))
                    } catch (t) {
                        return Object(zt.b)(t, "_mergeVideoBids"), []
                    }
                }

                function Q(t) {
                    var e = G(t),
                        n = [];
                    try {
                        n = e.map((function(e) {
                            return e.bidReqID = t.cb, e.host = t.host, e.ev = t.ev, e.cfe = t.cfe, e
                        }))
                    } catch (e) {
                        Object(zt.b)(e, "_convertAaxResponse")
                    }
                    return n
                }

                function y(t, e, n) {
                    try {
                        var r, o, i = t.slotID,
                            a = t._targetingSetID;
                        t.bidState !== At.c.set && null !== (r = l(i, e)) && (d(r), o = t.newBidObject, Object(Vt.a)(n), Object.keys(o.targeting).forEach((function(t) {
                            return r.setTargeting(t, o.targeting[t])
                        })), Tt.a.dispatch({
                            type: "BID_STATE_CHANGE",
                            slotID: i,
                            _targetingSetID: a,
                            bidState: At.c.set,
                            ts: Date.now()
                        }))
                    } catch (t) {
                        Object(zt.b)(t, "_applyTargetingToAdServerSlot", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function X(t, e, n, r) {
                    try {
                        var o = p(r);
                        t.forEach((function(t) {
                            o[t] && u(o[t], e, n)
                        }))
                    } catch (t) {
                        Object(zt.b)(t, "_applySuppliedSlotBidsToAdServerObject", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function W(t, e, n) {
                    try {
                        var r = p(n);
                        Object.keys(r).forEach((function(n) {
                            return u(r[n], t, e)
                        }))
                    } catch (n) {
                        Object(zt.b)(n, "_applyAllCurrentSlotBidsTargetingToAdServerObject", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function Y(t, e, n, r) {
                    try {
                        n ? X(n, t, e, r) : W(t, e, r), Tt.a.getState().displayAdServer.slotRenderEndedSet || (t.cmdQueuePush((function() {
                            try {
                                t.slotRenderEndedEvent((function(e) {
                                    try {
                                        f(e, t), d(e)
                                    } catch (e) {
                                        Object(zt.b)(e, "_applySlotTargeting-cmdQueue-slotCb", {
                                            makeVisibleToAllUsers: !0
                                        })
                                    }
                                }))
                            } catch (t) {
                                Object(zt.b)(t, "_applySlotTargeting-cmdQueue", {
                                    makeVisibleToAllUsers: !0
                                })
                            }
                        })), Tt.a.dispatch({
                            type: "SLOT_RENDER_ENDED_SET"
                        }))
                    } catch (e) {
                        Object(zt.b)(e, "_applySlotTargeting", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function m(t, e) {
                    function n() {
                        if (!o)
                            if (20 <= i++) Object(zt.b)({
                                name: "LoopError",
                                message: "Too many attempts to append to document.body"
                            }, "_safeDocumentBodyAppendChild-callback-loops", {
                                makeVisibleToAllUsers: !0
                            });
                            else {
                                try {
                                    if (t && t.body && null !== t.body && "function" == typeof t.body.appendChild) return t.body.appendChild(e), r(), void(o = !0)
                                } catch (t) {
                                    Object(zt.b)(t, "_safeDocumentBodyAppendChild-callback")
                                }
                                setTimeout(n, 100)
                            }
                    }
                    var r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : function() {},
                        o = !1,
                        i = 0;
                    try {
                        "complete" === t.readyState || "interactive" === t.readyState ? n() : t.addEventListener("DOMContentLoaded", n)
                    } catch (t) {
                        Object(zt.b)(t, "_safeDocumentBodyAppendChild")
                    }
                }

                function $(t) {
                    try {
                        var e = "".concat(t.host).concat(Tt.a.getState().cfg.DTB_PATH, "/imp"),
                            n = "".concat(t.host).concat(Tt.a.getState().cfg.DTB_PATH, "/adm");
                        return t.cfe || t.isAmp || t.isSf ? n : e
                    } catch (t) {
                        return Object(zt.b)(t, "determineCreativeFetchEndpoint"), ""
                    }
                }

                function w(t) {
                    try {
                        var e = "?b=".concat(t.bidID, "&rnd=").concat(Object(Et.c)()),
                            n = (Object(Et.j)(t, "pp") && (e += "&pp=".concat(t.pp)), Object(Et.j)(t, "amznp") && (e += "&p=".concat(t.amznp)), Object(Et.j)(t, "crID") && (e += "&crid=".concat(t.crID)), Object(Et.j)(t, "isSharedPMP") && !0 === t.isSharedPMP && (e += "&sp=true"), Object(Vt.e)() && (e += "&ep=%7B%22ce%22%3A%221%22%7D"), $(t));
                        return (t.fif ? "".concat(n, "j") : "".concat(n, "i")).concat(e)
                    } catch (t) {
                        return Object(zt.b)(t, "_creativeURL"), ""
                    }
                }

                function g(t) {
                    try {
                        var e = t.doc.createElement("iframe");
                        return e.frameBorder = "0", e.marginHeight = "0", e.marginWidth = "0", e.style.marginTop = "0", e.style.marginLeft = "0", e.scrolling = "no", t.inheritSize ? (e.style.width = "100%", e.style.height = "100%") : (e.style.width = "".concat(t.sizes[0], "px"), e.style.height = "".concat(t.sizes[1], "px")), e
                    } catch (t) {
                        return Object(zt.b)(t, "_baseIframe"), window.document.createElement("iframe")
                    }
                }

                function K(t) {
                    try {
                        if (Object(Et.j)(t, "bidType")) {
                            var e, n = t.kvMap;
                            switch (t.bidType) {
                                case "sharedPMP":
                                    return {
                                        bidID: n.amzniid_sp[0],
                                        pp: n.amznbid_sp[0],
                                        sizes: n.amznsz_sp[0].split("x"),
                                        amznp: n.amznp_sp[0],
                                        inheritSize: t.inheritSize,
                                        isSharedPMP: t.isSharedPMP
                                    };
                                case "preferredPMP":
                                    if (Object(Nt.c)(t) && Object(Et.j)(t, "amzndeal")) return e = t.amzndeal.split("_").pop().trim(), {
                                        bidID: n["".concat(t.amzndeal, "amzniid")][0],
                                        sizes: C(e)
                                    };
                                    break;
                                case "openAuction":
                                    if (Object(Nt.c)(t)) return {
                                        bidID: n.amzniid[0],
                                        pp: Object(_t.b)(n.amznbid[0]),
                                        amznp: n.amznp[0],
                                        inheritSize: t.inheritSize,
                                        sizes: n.amznsz[0].split("x")
                                    };
                                    if (Object(Nt.d)(t)) return {
                                        bidID: t.amzniid,
                                        pp: Object(_t.b)(t.amznbid),
                                        amznp: t.amznp,
                                        sizes: t.amznsz.split("x")
                                    };
                                    break;
                                default:
                                    Object(zt.b)({
                                        name: "Invalid AMP Bid Type: ".concat(t.bidType),
                                        message: "No valid AMP bid type"
                                    }, "getAmpAdData-invalidBidType")
                            }
                        }
                    } catch (t) {
                        Object(zt.b)(t, "getAmpAdData")
                    }
                    return {
                        bidID: "ERROR",
                        sizes: []
                    }
                }

                function D(t, e, n) {
                    try {
                        var r, o = null;
                        void 0 !== e && (Object(Et.j)(e, "ampEnv") && e.ampEnv || Object(Et.j)(e, "sfEnv") && e.sfEnv) && (o = e, Object(Et.j)(e, "bidType") && "sharedPMP" === e.bidType ? o.isSharedPMP = !0 : o.isSharedPMP = !1, o.document = t, o.amznhost = o.kvMap.amznhost[0]), A(t) && ((o = t).bidType = "openAuction", o.ampEnv = !0), null === o ? Object(zt.b)(new Error("Invalid AMP parameters"), "_renderAmpImpression-invalidParams", {
                            makeVisibleToAllUsers: !0
                        }) : "ERROR" !== (r = K(o)).bidID && (r.doc = o.document, r.host = o.amznhost.replace("http://", "https://"), r.adID = "amznad".concat(Object(Et.c)()), r.isAmp = o.ampEnv, r.isSf = Object(kt.c)(window), Tt.a.getState().aaxViewabilityEnabled ? R(r, r.doc, n) : _(r))
                    } catch (t) {
                        Object(zt.b)(t, "_renderAmpImpression")
                    }
                }

                function T(t) {
                    var e, n = "unknown";

                    function r(r) {
                        try {
                            r && (t.hasTimedOut = !0), r && !t.hasRendered && Object(zt.b)({
                                name: "RenderTimeout",
                                message: "renderAd was called from timeout. fifFlowMethod: ".concat(n)
                            }, "__loadAdIntoFriendlyIframe-renderAd-timeout-isOutstream:".concat(t.isOutstream)), null === e.contentDocument ? Object(zt.b)({
                                name: "NoDocument",
                                message: "iframe.contentDocument was null inside renderAd. isFromTimeout: ".concat(r, ". fifFlowMethod: ").concat(n)
                            }, "__loadAdIntoFriendlyIframe-renderAd-noDocument-isOutstream:".concat(t.isOutstream), {
                                makeVisibleToAllUsers: !0
                            }) : t.hasRendered && !t.hasTimedOut ? Object(zt.b)({
                                name: "DupeRender",
                                message: "Render was called twice"
                            }, "__loadAdIntoFriendlyIframe-renderAd-rerender-isOutstream:".concat(t.isOutstream), {
                                makeVisibleToAllUsers: !0
                            }) : t.hasRendered || (t.hasRendered = !0, e.contentDocument.open(), e.contentDocument.write(t.html), e.contentDocument.close())
                        } catch (r) {
                            Object(zt.b)(r, "__loadAdIntoFriendlyIframe-renderAd-isOutstream:".concat(t.isOutstream))
                        }
                    }

                    function o() {
                        var o = r.bind(null, !1);
                        try {
                            n = null !== e.contentDocument && Object(Et.g)(["complete", "interactive"], e.contentDocument.readyState) ? (o(), "doc-ready") : null !== e.contentDocument && "uninitialized" !== e.contentDocument.readyState ? (e.contentDocument.addEventListener("DOMContentLoaded", o), "dom-listener") : (e.addEventListener("load", o), "iframe-listener"), setTimeout(r, 1e3, !0)
                        } catch (o) {
                            Object(zt.b)(o, "_loadAdIntoFriendlyIframe-setAttributes-isOutstream:".concat(t.isOutstream))
                        }
                    }
                    try {
                        if (void 0 === t.html) throw new Error("No HTML available for ad, most likely the creative has expired");
                        if (t = Yt({
                                hasRendered: !1,
                                hasTimedOut: !1
                            }, t), (e = g(t)).id = "apstag-f-iframe-".concat(Object(Et.c)()), t.isOutstream) try {
                            var i = Object(Rt.d)(document, t);
                            if (void 0 === i) throw new Error("gpt video div element is undefined");
                            i && i.firstElementChild && i.firstElementChild.style.setProperty("display", "none", "important");
                            var a = Object(Rt.f)(t.sizes);
                            Object(Rt.a)(a, i), Object(Rt.e)(a, e), o(), Object(Rt.g)(a, e, t.bidID)
                        } catch (o) {
                            Object(zt.b)(o, "_loadAdIntoFriendlyIframe-outstream", {
                                makeVisibleToAllUsers: !0
                            })
                        } else m(t.doc, e, o)
                    } catch (o) {
                        Object(zt.b)(o, "_loadAdIntoFriendlyIframe", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function _(t) {
                    var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {
                            states: {
                                csmLoaded: !1,
                                iframeLoaded: !1,
                                shouldRunViewability: !1
                            }
                        },
                        n = 2 < arguments.length ? arguments[2] : void 0;
                    try {
                        var r, o = g(t);
                        o.id = t.adID, o.setAttribute("sandbox", "allow-forms allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation"), Object(Pt.d)("fake_bids") ? (r = '<body style="background-color: #FF9900;">'.concat(50 < parseInt(t.sizes[1], 10) ? "<h3>apstag Test Creative</h3>" : "", "<h4>amzniid - ").concat(t.bidID, " | amznbid: ").concat(t.pp, " | size: ").concat(t.sizes.join("x"), "</h4></body>"), o.src = "javascript:'".concat(r, "'")) : o.src = w(t), !(t.isAmp && t.isSf && Object(kt.b)(window)) && (!t.isSf || t.isAmp || t.inheritSize) || Object(kt.a)(t.sizes, window), m(t.doc, o), (e.iframe = o).onload = function() {
                            e.states.iframeLoaded = !0, n && n()
                        }
                    } catch (t) {
                        Object(zt.b)(t, "_loadAdIntoUnfriendlyIframe", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function J(t, e) {
                    var n, r = t.states,
                        o = t.doc,
                        i = t.bidID;
                    t = t.iframe;
                    try {
                        Object(Et.a)(r) || (r.shouldRunViewability = !1, Object(Et.j)(window, "amzncsm") ? n = window.amzncsm : void 0 !== o && null !== o.defaultView && Object(Et.j)(o.defaultView, "amzncsm") && (n = o.defaultView.amzncsm), void 0 !== o && void 0 !== n && Object(Et.j)(n, "rmD") && (n.host = Object(Pt.c)("host", Tt.a.getState().hosts.DEFAULT_AAX_PIXEL_HOST), n.rmD(t, i, o.defaultView, o, te({
                            overrides: null == e ? void 0 : e.initConfig
                        }).pubID)))
                    } catch (t) {
                        Object(zt.b)(t, "_triggerViewability")
                    }
                }

                function Z(t, e, n, r) {
                    return function(o) {
                        try {
                            var i = Object(Ut.d)(e.slots, r),
                                a = Object.keys(i),
                                c = [],
                                s = (o && (Tt.a.dispatch({
                                    type: "RECORD_AAX_REQ_PROP",
                                    bidReqID: e.bidReqID,
                                    key: "timedOutAt",
                                    value: Date.now()
                                }), Tt.a.getState().experiments.chunkRequests) && Tt.a.dispatch({
                                    type: "RECORD_TIMEOUT",
                                    fid: e.bidReqID,
                                    timeOut: Date.now()
                                }), a.forEach((function(t) {
                                    Object(Et.j)(i, t) && (t = i[t], Object(Ut.f)(te({
                                        overrides: null == r ? void 0 : r.initConfig
                                    }), n) || Object(Et.j)(t.bidConfig, "amznbid") ? Object(Et.j)(t.bidConfig, "amznp") || (t.bidConfig.amznp = "") : (t.mediaType !== Nt.a.VIDEO && (t.bidConfig.targeting.unshift("amznsz"), t.bidConfig.amznsz = "0x0"), t.bidConfig.targeting.unshift("amzniid", "amznbid", "amznp"), t.bidConfig.amzniid = "", t.bidConfig.amznbid = At.t.noBid, t.bidConfig.amznp = At.t.noBid), c.push(t))
                                })), n.isSupported && (c = Object(Ut.b)(c, e, o)), {
                                    fromTimeout: o
                                }),
                                u = Object(Ut.f)(te({
                                    overrides: null == r ? void 0 : r.initConfig
                                }), n);
                            try {
                                t(c.map((function(t) {
                                    return u ? t.newBidObject : t.bidObject
                                })), s)
                            } catch (a) {
                                console.error(a)
                            }
                        } catch (a) {
                            Object(zt.b)(a, "_bidCallbackHandler", {
                                makeVisibleToAllUsers: !0
                            });
                            try {
                                t([], {
                                    fromTimeout: o,
                                    fromError: !0
                                })
                            } catch (a) {
                                console.error(a)
                            }
                        }
                    }
                }

                function tt(t, e) {
                    try {
                        var n, r;
                        e.inheritSize || (r = t.defaultView && t.defaultView.frameElement ? (n = t.defaultView.frameElement, "defaultView") : (n = window.frameElement, "frameElement"), null !== n ? (n.style.width = "".concat(e.sizes[0], "px"), n.style.height = "".concat(e.sizes[1], "px")) : Object(zt.b)({
                            name: "FrameNotFound",
                            message: "'win' is 'null'. Method used: ".concat(r)
                        }, "_resizeIframe-win"))
                    } catch (t) {
                        Object(zt.b)(t, "_resizeIframe")
                    }
                }

                function h(t) {
                    try {
                        return "".concat(t[0], "x").concat(t[1])
                    } catch (t) {
                        return Object(zt.b)(t, "_sizeArrayToSring"), "x"
                    }
                }

                function O(t) {
                    try {
                        return 1 === t.length ? h(t[0]) : h(t[Math.floor(t.length * Math.random())])
                    } catch (t) {
                        return Object(zt.b)(t, "_pickRandomSizeForMockBid", {
                            makeVisibleToAllUsers: !0
                        }), ""
                    }
                }

                function et(t) {
                    try {
                        var e, n = Object(Pt.c)("host", Tt.a.getState().hosts.DEFAULT_AAX_BID_HOST),
                            r = Object(_t.f)(window),
                            o = t.bidReqID,
                            i = Object(Et.f)(window),
                            a = Object(Pt.c)("testBidTimeout", 200);
                        Tt.a.dispatch({
                            type: "RECORD_AAX_REQUEST",
                            data: {
                                bidConfig: t,
                                timeout: a,
                                bidReqID: o,
                                ws: i,
                                url: r,
                                rqTs: Date.now()
                            }
                        }), e = t.slots.map((function(t) {
                            var e = O(t.sizes),
                                n = (e = "testDeal".concat(Object(Et.c)(), "_").concat(e), "testDealIi-".concat(Object(Et.c)())),
                                r = O(t.sizes);
                            $t(r = {
                                slotID: t.slotID,
                                crid: "".concat(At.o.crid, "-").concat(Object(Et.c)()),
                                size: r,
                                amzniid: "".concat(At.o.amzniid, "-").concat(Object(Et.c)()),
                                amznbid: At.o.amznbid,
                                amznp: At.o.amznp,
                                amznsz: r,
                                amzniid_sp: "".concat(At.o.amzniid, "-").concat(Object(Et.c)()),
                                amznbid_sp: "".concat(At.o.amznbid, "SP"),
                                amznp_sp: "".concat(At.o.amznp, "SP"),
                                amznsz_sp: O(t.sizes),
                                amzndeals: [e]
                            }, "".concat(e, "amzniid"), n), $t(r, "mediaType", "d"), $t(r, "meta", ["slotID", "mediaType", "size"]), $t(r, "targeting", ["amzniid", "amznbid", "amznp", "amznsz", "amzniid_sp", "amznbid_sp", "amznp_sp", "amznsz_sp", "amzndeal_sp", "amzndeals", "".concat(e, "amzniid")]), n = r;
                            return t.mediaType === Nt.a.VIDEO && (n.mediaType = Nt.a.VIDEO, n.amznbid = "v_".concat(n.amznbid)), n
                        })), setTimeout((function() {
                            window.apstag.bids({
                                slots: e,
                                host: n,
                                status: "ok",
                                cb: o
                            })
                        }), a)
                    } catch (t) {
                        Object(zt.b)(t, "_doMockBid", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function nt(t, e, n) {
                    try {
                        var r, o, i, a = Tt.a.getState().AAXReqs.filter((function(e) {
                            return e.bidReqID === t.cb
                        }))[0];
                        a && a.bidConfig && a.bidConfig.slots && (r = a.bidConfig.slots.filter(Object(It.d)(Nt.a.DISPLAY, Nt.a.MULTI_FORMAT)).map((function(t) {
                            return t.slotID
                        })), o = Object(Et.j)(t, "slots") ? t.slots.map((function(t) {
                            return t.slotID
                        })) : [], i = r.filter((function(t) {
                            return !Object(Et.g)(o, t)
                        })), Tt.a.dispatch({
                            type: "NO_BID_ON_ADSERVER_SLOTS",
                            slotIDs: i
                        }), e.hasAdServerObjectLoaded() ? j(e, n) : e.isCommandQueueDefined() && e.cmdQueuePush((function() {
                            j(e, n)
                        })))
                    } catch (e) {
                        Object(zt.b)(e, "_determineNoBidStateForAdServerObject")
                    }
                }

                function rt(t) {
                    return Object(Et.g)(Tt.a.getState().AAXReqs.filter((function(t) {
                        return !t.resTs
                    })).map((function(t) {
                        return t.bidConfig.slots
                    })).reduce((function(t, e) {
                        return t.concat(e)
                    }), []).map(It.c), t)
                }

                function v(t) {
                    try {
                        var e = t.getTargeting("amznbid");
                        return 0 < e.length && 2 < e[0].length
                    } catch (t) {
                        return Object(zt.b)(t, "_isRealAmznbidTargetingSetOnSlot"), 1
                    }
                }

                function j(t, e) {
                    try {
                        t.hasAdServerObjectLoaded() && "1" === t.getTargeting("amznbid")[0] && E(t), Object(It.b)(t).forEach((function(t) {
                            !Object(Et.g)(Tt.a.getState().displayAdServer.noBidSlotIDs, t.slotID) || rt(t.slotID) || v(t) || "2" === t.getTargeting("amznbid")[0] || (S("noBid", t), Object(Vt.a)(e))
                        }))
                    } catch (t) {
                        Object(zt.b)(t, "_applyNoBidFromAAXState")
                    }
                }

                function S(t, e) {
                    At.u.forEach((function(n) {
                        return e.setTargeting(n, At.t[t])
                    }))
                }

                function E(t) {
                    At.u.forEach((function(e) {
                        return t.clearTargeting(e)
                    }))
                }! function() {
                    var t;
                    Object(Gt.b)() && (t = Gt.a.getDefault().localStorage.getItem(At.d, {
                        ignoreFailure: !0
                    })) && null !== (t = JSON.parse(t)) && Tt.a.dispatch({
                        type: "SET_CFG",
                        cfg: t
                    })
                }(), Object(Vt.d)();
                var ot = 0;

                function I() {
                    try {
                        Object(Et.j)(window, "googletag") && Object(Et.j)(window.googletag, "cmd") ? (new ee.a).cmdQueuePush((function() {
                            try {
                                window.googletag.pubads().addEventListener("slotRequested", (function(t) {
                                    try {
                                        var e = t.slot;
                                        Tt.a.dispatch({
                                            type: "LOG_GAM_EVENT",
                                            event: Yt(Yt({}, new qt.a(e).slotConfig), {}, {
                                                ts: Date.now(),
                                                targeting: e.getTargetingMap()
                                            })
                                        })
                                    } catch (t) {
                                        Object(zt.b)(t, "_initializeSlotRequestedEventListener-cmdQueue-listener")
                                    }
                                }))
                            } catch (t) {
                                Object(zt.b)(t, "_initializeSlotRequestedEventListener-cmdQueue")
                            }
                        })) : ++ot < 5 && setTimeout(I, 100)
                    } catch (t) {
                        Object(zt.b)(t, "_initializeSlotRequestedEventListener")
                    }
                }

                function it(t) {
                    try {
                        var e = t.AAXReqs.slice(t.gamSlotRenderPixel.aaxReqOffset).reduce((function(t, e) {
                                return t.concat(e.bidConfig.slots)
                            }), []).map((function(t) {
                                return Yt(Yt({}, t), {}, {
                                    type: "a"
                                })
                            })).filter((function(t) {
                                return t.mediaType !== Nt.a.VIDEO
                            })),
                            n = t.gamSlotFetchLog.slice(t.gamSlotRenderPixel.gamSlotFetchLogOffset).map((function(t) {
                                return Yt(Yt({}, t), {}, {
                                    type: "g"
                                })
                            })),
                            r = [].concat(Xt(e), Xt(n)).reduce((function(t, e) {
                                return void 0 === t[e.slotID] && (t[e.slotID] = {
                                    sd: e.slotID,
                                    a: {
                                        c: 0
                                    },
                                    g: {
                                        c: 0
                                    }
                                }), t[e.slotID][e.type].c++, t[e.slotID][e.type].s = e.sizes, t[e.slotID][e.type].sn = e.slotName || "", t
                            }), {});
                        return Object.keys(r).map((function(t) {
                            return r[t]
                        })).filter((function(t) {
                            return 0 !== t.a.c || 0 !== t.g.c
                        }))
                    } catch (t) {
                        return Object(zt.b)(t, "getSlotFetchCounts"), []
                    }
                }

                function at(t) {
                    try {
                        var e = ut(t),
                            n = [];
                        return null !== e && Object.keys(Tt.a.getState().slotBids).forEach((function(t) {
                            Tt.a.getState().slotBids[t][0].bidConfig.mediaType !== Nt.a.VIDEO && Tt.a.getState().slotBids[t].filter((function(t) {
                                return Object(Et.j)(t.bidConfig, "amzniid")
                            })).forEach((function(r) {
                                var o, i, a;
                                null !== e && (o = {
                                    state: -1,
                                    slotID: t,
                                    iid: r.bidConfig.amzniid,
                                    fid: r.bidReqID
                                }, a = [], i = [], t in e && (a = e[t].fetchedAt.filter((function(t) {
                                    return t.AAXReqInfo && t.AAXReqInfo.bidReqID === r.bidReqID
                                })), i = e[t].targetedAt.filter((function(t) {
                                    return t.targeting === r.bidConfig.amzniid
                                }))), 0 < a.length ? 0 < a.length && i.length >= a.length && a.slice(a.length - 1)[0].ts > i.slice(a.length - 1)[0].ts ? 1 === e[t].fetchWithIID.filter((function(t) {
                                    return t === r.bidConfig.amzniid
                                })).length ? o.state = 1 : o.state = 4 : Object(Et.g)(e[t].fetchWithIID, r.bidConfig.amzniid) ? o.state = 3 : o.state = 2 : o.state = 0, 1 !== o.state && 2 !== o.state || (a = P(i = Tt.a.getState().AAXReqs.filter((function(t) {
                                    return t.bidReqID === r.bidReqID
                                }))[0].resTs, e[t].fetchedAt, 2 === o.state)) && Object(Et.j)(a, "ts") && (o.delta = i - a.ts), n.push(o))
                            }))
                        })), n
                    } catch (t) {
                        return Object(zt.b)(t, "_getBidSetInfo"), []
                    }
                }

                function P(t, e, n) {
                    var r = e.map((function(e) {
                        return e = t - e.ts, !n && e <= 0 ? -e : n && 0 <= e ? e : null
                    }));
                    return e[ct(r)]
                }

                function ct(t) {
                    for (var e = -1, n = -1, r = 0; r < t.length; r++) null !== t[r] && (-1 === n || t[r] < e) && (e = t[n = r]);
                    return n
                }

                function st(t, e) {
                    return Tt.a.getState().AAXReqs.filter((function(t) {
                        return Object(Et.g)(t.bidConfig.slots.map((function(t) {
                            return t.slotID
                        })), e)
                    }))[t]
                }

                function ut(t) {
                    try {
                        var e;
                        return t.hasAdServerObjectLoaded() ? (e = Tt.a.getState().gamSlotFetchLog.reduce((function(t, e) {
                            Object(Et.j)(t, e.slotID) || (t[e.slotID] = {
                                fetchedAt: [],
                                targetedAt: []
                            });
                            var n = t[e.slotID];
                            return n.fetchedAt.push({
                                ts: e.ts,
                                AAXReqInfo: st(n.fetchedAt.length, e.slotID)
                            }), Object(Et.j)(e.targeting, "amzniid") && 0 < e.targeting.amzniid.length ? n.targetedAt.push({
                                ts: e.ts - 1,
                                targeting: e.targeting.amzniid[0]
                            }) : n.targetedAt.push({
                                ts: e.ts - 1,
                                targeting: ""
                            }), t
                        }), {}), Object.keys(e).forEach((function(t) {
                            var n;
                            Object(Et.j)(e, t) && ((n = e[t]).fetchWithIID = n.fetchedAt.map((function(t) {
                                return (t = P(t.ts, n.targetedAt, !0)) ? t.targeting : 0
                            })), e[t] = n)
                        })), e) : null
                    } catch (t) {
                        return Object(zt.b)(t, "_getDFPSlotFetches"), null
                    }
                }

                function lt(t) {
                    try {
                        t.hasAdServerObjectLoaded() ? S("noRequest", t) : t.isCommandQueueDefined() && t.cmdQueuePush((function() {
                            S("noRequest", t)
                        }))
                    } catch (t) {
                        Object(zt.b)(t, "_applyNoRequestToAAXState")
                    }
                }

                function ft(t, e) {
                    try {
                        Tt.a.dispatch({
                            type: "REQUESTED_BID_FOR_ADSERVER_SLOTS",
                            slotIDs: t
                        }), e.isCommandQueueDefined() && e.cmdQueuePush((function() {
                            try {
                                var n = Object(It.b)(e);
                                "0" === e.getTargeting("amznbid")[0] && E(e), M(t.filter((function(t) {
                                    return void 0 !== t
                                })), n.map((function(t) {
                                    return t.slotID
                                }))) ? n.forEach((function(e) {
                                    Object(Et.g)(t, e.slotID) && !v(e) && S("bidInFlight", e)
                                })) : e.cmdQueuePush((function() {
                                    try {
                                        S("bidInFlight", e)
                                    } catch (t) {
                                        Object(zt.b)(t, "_setRequestToAAXInFlightState-cmdQueue-cmdQueue")
                                    }
                                }))
                            } catch (n) {
                                Object(zt.b)(n, "_setRequestToAAXInFlightState-cmdQueue")
                            }
                        }))
                    } catch (t) {
                        Object(zt.b)(t, "_setRequestToAAXInFlightState")
                    }
                }

                function A(t) {
                    try {
                        return Object(Et.j)(t, "type") && !(t instanceof Document) && "amp" === t.type
                    } catch (t) {
                        return Object(zt.b)(t, "_isLegacyAmpCreative"), !1
                    }
                }

                function dt(t, e) {
                    try {
                        return void 0 !== e && Object(Et.j)(e, "ampEnv") && e.ampEnv || A(t)
                    } catch (t) {
                        Object(zt.b)(t, "_isAmpImpression")
                    }
                }

                function C(t) {
                    return t.split("x")
                }

                function bt(t, e, n, r) {
                    var o = Zt(Jt(), "renderImp", {
                        doc: t,
                        bidID: e,
                        kvBidObject: n
                    }, "renderImpArgs");
                    t = o.doc, e = o.bidID, n = o.kvBidObject;
                    try {
                        if (dt(t, n) && Object(_t.i)(window, !0)) D(t, n, r);
                        else if (Object(kt.c)(window) && void 0 !== n && Object(Et.j)(n, "kvMap") && Object(Et.j)(n.kvMap, "amznhost")) D(t, n, r);
                        else {
                            var i = !1,
                                a = ("string" == typeof e && 0 === e.indexOf("sp|") && (e = e.substring(3), i = !0), e || t.amzniid),
                                c = q(a, i),
                                s = c.slotBid,
                                u = c.dealId,
                                l = !1;
                            if (void 0 !== n && Object(Et.j)(n, "bidType") && "outstream" === n.bidType && (l = !0), s) {
                                var f, d, b, p, y, m, g, h, O, v, j, S = u && 1 <= u.length ? C("sp" === u ? s.bidConfig.amznsz_sp : H(a, s, u)) : C(s.bidConfig.amznsz);
                                1 === arguments.length ? T({
                                    doc: s.doc,
                                    bidID: s.bidConfig.amzniid,
                                    sizes: S,
                                    html: t.html,
                                    inheritSize: s.inheritSize || !1,
                                    isOutstream: l
                                }) : (f = s.host, d = s.bidConfig.slotID, b = "amznad".concat(Math.round(1e6 * Math.random())), p = {
                                    bidID: a,
                                    doc: t,
                                    slotID: d,
                                    pp: k("amznbid", s, u),
                                    host: f,
                                    adID: b,
                                    sizes: S,
                                    amznp: k("amznp", s, u),
                                    crID: k("crid", s, u),
                                    fif: !1,
                                    dealId: u,
                                    isSharedPMP: i,
                                    cfe: s.cfe,
                                    isOutstream: l,
                                    inheritSize: Object(Et.i)(n) && Object(Et.j)(n, "inheritSize") && !0 === n.inheritSize
                                }, "1" === s.bidConfig.fif && !1 === l && !1 === i ? (p.fif = !0, Tt.a.dispatch({
                                    type: "UPDATE_BID_INFO_PROP",
                                    slotID: s.slotID,
                                    iid: e,
                                    key: "doc",
                                    value: t
                                }), Tt.a.dispatch({
                                    type: "UPDATE_BID_INFO_PROP",
                                    slotID: s.slotID,
                                    iid: e,
                                    key: "inheritSize",
                                    value: p.inheritSize
                                }), Object(Lt.b)(w(p), (function() {}), document, (function() {
                                    return Object(zt.b)(new Error("Error Loading JSONP Render Callback"), "renderImp-fif-callback-load", {
                                        makeVisibleToAllUsers: !0
                                    })
                                }))) : l ? (Tt.a.dispatch({
                                    type: "OUTSTREAM_SHOULD_SAMPLE",
                                    shouldSample: Object(Et.k)(10)
                                }), h = Object(Rt.c)(p, At.b), v = 1 <= (null == (O = null == (y = Tt.a.getState().bidConfigs[s.bidReqID]) || null == (m = y.slots) ? void 0 : m.filter((function(t) {
                                    return (null == t ? void 0 : t.slotID) === (null == p ? void 0 : p.slotID)
                                }))) ? void 0 : O.length) ? null == (g = O[0]) ? void 0 : g.companions : [], j = Object(Rt.b)(h, At.A, p, v), p.html = j, T(p)) : Tt.a.getState().aaxViewabilityEnabled ? R(p, t, r) : _(p), l || tt(t, p))
                            } else try {
                                Object(zt.b)(new Error("Invalid bid ID. '".concat("(bidID value: " + e + ", bID value: " + a + ")", "' tried to render into document ").concat(t instanceof Document ? t.documentURI : "with type " + Wt(t))), "_renderImp-invalidId", {
                                    makeVisibleToAllUsers: !0
                                })
                            } catch (t) {
                                Object(zt.b)(t, "_renderImp-invalidId")
                            }
                        }
                    } catch (t) {
                        Object(zt.b)(t, "_renderImp", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function k(t, e, n) {
                    try {
                        var r, o = "";
                        return void 0 !== n && 1 <= n.length ? (r = "".concat(t, "_sp"), "sp" === n && Object(Et.j)(e.bidConfig, r) && (o = e.bidConfig[r])) : Object(Et.j)(e.bidConfig, t) && (o = e.bidConfig[t]), o
                    } catch (t) {
                        return Object(zt.b)(t, "_getProperBidInfoValue"), ""
                    }
                }

                function R(t, e, n) {
                    try {
                        var r = e.createElement("script"),
                            o = (r.type = "text/javascript", r.async = !0, {
                                doc: e,
                                bidID: t.bidID,
                                states: {
                                    csmLoaded: !1,
                                    iframeLoaded: !1,
                                    shouldRunViewability: !0
                                }
                            }),
                            i = J.bind(null, o, n);
                        Object(Lt.a)(r, (function() {
                            o.states.csmLoaded = !0, i()
                        })), _(t, o, i), r.src = Tt.a.getState().cfg.CSM_JS, m(e, r)
                    } catch (t) {
                        Object(zt.b)(t, "_loadViewabilityAd")
                    }
                }

                function z(t) {
                    var e = Jt();
                    try {
                        t = Zt(e, "bids", t, "aaxResp"), Object(Ht.a)(e).safelyRecord("_legacy/bidRequest/didComplete", {
                            pairedEvents: ["_legacy/bidRequest/monitor"],
                            eventIdentifier: t.cb,
                            statusUpdate: "completed"
                        })
                    } catch (t) {}
                    var n = Kt;
                    try {
                        x(t, n, e), Object(Et.j)(t, "slots") && (Tt.a.dispatch({
                            type: "UPDATE_SLOT_BIDS",
                            bids: Q(t)
                        }), Object(Et.j)(t, "ev") && Tt.a.dispatch({
                            type: "SET_VIEWABILITY",
                            viewability: t.ev
                        }), Object(Et.j)(t, "cfn")) && Tt.a.dispatch({
                            type: "SET_CFG",
                            cfg: {
                                CSM_JS: "//" === t.cfn.substring(0, 2) ? t.cfn : "//c.amazon-adsystem.com/".concat(t.cfn)
                            }
                        }), U(t)
                    } catch (t) {
                        Object(zt.b)(t, "_bids", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function pt() {
                    return "number" == typeof Tt.a.getState().cfg.MAX_SLOTS_PER_REQUEST && 0 < Tt.a.getState().cfg.MAX_SLOTS_PER_REQUEST
                }

                function yt(t, e, n) {
                    var r, o = null != (r = null == n || null == (r = n.initConfig) ? void 0 : r.pubID) ? r : Tt.a.getState().config.pubID;
                    t = Zt(o, "fetchBids", t, "bidConfig");
                    try {
                        Object(Ht.a)(o).safelyRecord("consent/tcfapi/attemptSync"), Object(Ht.a)(o).safelyRecord("consent/gppapi/attemptSync"), a.attemptConsentDataSync();
                        var i = Object(Vt.b)(o);
                        Object(Dt.a)(Tt.a.getState().config.gdpr, (function(r) {
                            L(t, e, r, i, {
                                initConfig: null == n ? void 0 : n.initConfig,
                                contextURL: null == n ? void 0 : n.contextURL,
                                accountID: o
                            })
                        }), o)
                    } catch (r) {
                        Object(zt.b)(r, "_getConfigsAndFetchBids", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function mt(t, e, n) {
                    var r = n.initConfig.pubID,
                        o = (Object(Ht.a)(r).safelyRecord("consent/tcfapi/attemptSync"), Object(Ht.a)(r).safelyRecord("consent/gppapi/attemptSync"), a.attemptConsentDataSync(), Object(Vt.b)(r));
                    Object(Dt.a)(Tt.a.getState().config.gdpr, (function(i) {
                        L(t, e, i, o, {
                            initConfig: null == n ? void 0 : n.initConfig,
                            contextURL: null == n ? void 0 : n.contextURL,
                            accountID: r
                        })
                    }), r)
                }

                function L(t, e, n, r, o) {
                    var i = o.accountID,
                        a = (Object(Ht.a)(i).safelyRecord("deviceSignal/cookieDeprecationLabel/set"), null != o && o.adServer ? Object(xt.a)(o.adServer) : Kt);
                    Object(Ht.a)(i).safelyRecord("sessionMarker/marker/sync");
                    try {
                        Object(Bt.b)(e, ["function", "undefined"]) || Object(zt.c)("fetchBids.callback", Wt(e), "function"), "function" != typeof e && (e = function() {}), Object(Et.i)(t) || (Object(zt.c)("fetchBids.bidConfig", Wt(t), "object"), t = {}), Object(Bt.a)(t.timeout) || ("string" == typeof t.timeout ? Object(zt.b)({
                            name: "string-".concat(t.timeout),
                            message: "fetchBids.bidConfig.timeout was a non-numeric string '".concat(t.timeout, "'")
                        }, "TypeError-fetchBids.bidConfig.timeout", {
                            makeVisibleToAllUsers: !0
                        }) : Object(zt.c)("fetchBids.bidConfig.timeout", Wt(t.timeout), "number")), Object(Et.j)(t, "params") && !Object(Et.i)(t.params) ? Object(zt.c)("fetchBids.bidConfig.params", Wt(t.params), "object") : Object(Et.j)(t, "params") && Object(Et.i)(t.params) && Object.keys(t.params).forEach((function(e) {
                            return !(void 0 === t.params || "string" != typeof t.params[e] && "number" != typeof t.params[e] && (Object(Et.h)(t.params[e]) ? !t.params[e].reduce((function(t, e) {
                                return t && ("string" == typeof e || "number" == typeof e)
                            }), !0) && (Object(zt.b)({
                                name: "non-string array item",
                                message: "'fetchBids.bidConfig.params.".concat(e, " contains a non-string item")
                            }, "TypeError-fetchBids.bidConfig.params.".concat(e), {
                                makeVisibleToAllUsers: !0
                            }), 1) : (Object(zt.c)("fetchBids.bidConfig.params.".concat(e), Wt(t.params[e]), "string' or 'array"), 1)))
                        })), Object(Et.j)(t, "blockedBidders") && !Object(Et.h)(t.blockedBidders) ? Object(zt.c)("fetchBids.bidConfig.blockedBidders", Wt(t.blockedBidders), "array") : Object(Et.j)(t, "blockedBidders") && Object(Et.h)(t.blockedBidders) && (t.blockedBidders.reduce((function(t, e) {
                            return t && ("string" == typeof e || "number" == typeof e)
                        }), !0) || Object(zt.b)({
                            name: "non-string array item",
                            message: "'fetchBids.bidConfig.blockedBidders contains a non-string item"
                        }, "TypeError-fetchBids.bidConfig.blockedBidders", {
                            makeVisibleToAllUsers: !0
                        })), Object(Et.j)(t, "slots") && !Object(Et.h)(t.slots) && Object(zt.c)("fetchBids.bidConfig.slots", Wt(t.slots), "array")
                    } catch (a) {
                        Object(zt.b)(a, "_fetchBids-validation", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                    var c = !1,
                        s = ((te({
                            overrides: null == o ? void 0 : o.initConfig
                        }).simplerGPT || Object(Ht.a)(i).read("ad/googletagSlotAutoImport")) && (c = !0), Yt(Yt({}, t), {}, {
                            bidReqID: "".concat(Tt.a.getState().AAXReqs.length),
                            slots: [],
                            validSlots: [],
                            networkReqs: []
                        })),
                        u = !1;
                    try {
                        !0 === c && (!Object(Et.j)(t, "slots") || Object(Et.j)(t, "slots") && Object(Et.h)(t.slots) && 0 < t.slots.length && Object(Et.j)(t.slots[0], "getSlotElementId")) ? 0 === Object(It.b)(a).length ? (Object(zt.b)(new Error("fetchBids was called in simplerGPT mode before any slots were defined in GPT"), "_fetchBids-simplerGpt-NoSlots", {
                            makeVisibleToAllUsers: !0
                        }), u = !0, s.slots = []) : (t.slots ? s.slots = t.slots.map((function(t) {
                            return new qt.a(t)
                        })) : s.slots = Object(It.b)(a), s.slots = s.slots.filter(It.a), 0 === s.slots.length && (Object(zt.b)(new Error("No GPT slots provided to apstag.fetchBids() had valid sizes"), "_fetchBids-simplerGpt-NoValidSizes", {
                            makeVisibleToAllUsers: !0
                        }), u = !0)) : Object(Et.j)(t, "slots") && Object(Et.h)(t.slots) && (s.slots = t.slots.map((function(t) {
                            switch (t.mediaType) {
                                case Nt.a.DISPLAY:
                                    return new Ft.a(t);
                                case Nt.a.VIDEO:
                                    return new ne.a(t);
                                case Nt.a.MULTI_FORMAT:
                                    return new re.a(t);
                                default:
                                    return new Ft.a(t)
                            }
                        }))), s.validSlots = s.slots.filter((function(t) {
                            return t.isValid()
                        })), s.validSlots.length > At.m && (s.validSlots = s.validSlots.slice(s.validSlots.length - At.m))
                    } catch (a) {
                        Object(zt.b)(a, "_fetchBids-getSlots", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                    var l = Object(_t.h)(s, Tt.a.getState());
                    try {
                        e = Object(_t.a)(Z(e, s, a, o), l)
                    } catch (a) {
                        Object(zt.b)(a, "_fetchBids-wrapCallback", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                    try {
                        if (0 === s.validSlots.length) !1 === u && Object(zt.b)(new Error("No valid slots provided to apstag.fetchBids"), "_fetchBids-noSlots", {
                            makeVisibleToAllUsers: !0
                        }), setTimeout(e.bind(null, []), 10);
                        else if (ft(s.slots.filter(Object(It.d)(Nt.a.DISPLAY, Nt.a.MULTI_FORMAT)).map(It.c), a), Tt.a.dispatch({
                                type: "NEW_FETCH_BID_REQUEST",
                                fid: s.bidReqID,
                                pto: l
                            }), Tt.a.dispatch({
                                type: "RECORD_ORIGINAL_BID_CONFIG",
                                bidConfig: s
                            }), Object(Ht.a)(i).safelyRecord("_legacy/bidRequest/monitor", {
                                eventIdentifier: s.bidReqID,
                                analyticsSampleRateAdjustFactor: {
                                    status: .3
                                }
                            }), Object(Pt.d)("fake_bids")) et(s);
                        else if (At.k)
                            if (Tt.a.dispatch({
                                    type: "SHOULD_CHUNK_REQUESTS",
                                    value: Object(Et.k)(Tt.a.getState().cfg.CHUNK_BID_REQUESTS_PROPORTION)
                                }), Tt.a.getState().experiments.chunkRequests && pt()) {
                                for (var f = gt(s), d = 0; d < f.length; d++) f[d].bidReqID = "".concat(s.bidReqID, "-").concat(d);
                                Tt.a.dispatch({
                                    type: "ADD_CHUNKED_REQUESTS",
                                    fid: s.bidReqID,
                                    numChunks: f.length
                                }), f.forEach((function(a) {
                                    b(Object(Ut.c)(a, l, n, r, o), e, a.bidReqID, i, t)
                                }))
                            } else b(Object(Ut.c)(s, l, n, r, o), e, s.bidReqID, i, t);
                        else Object(Lt.b)(Object(Ut.c)(s, l, n, r, o), e)
                    } catch (a) {
                        Object(zt.b)(a, "_fetchBids", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function gt(t) {
                    try {
                        for (var e = Math.ceil(t.validSlots.length / Tt.a.getState().cfg.MAX_SLOTS_PER_REQUEST), n = new Array(e), r = 0; r < e; r++) {
                            var o = r * Tt.a.getState().cfg.MAX_SLOTS_PER_REQUEST;
                            n[r] = {
                                slots: t.validSlots.slice(o, o + Tt.a.getState().cfg.MAX_SLOTS_PER_REQUEST)
                            }
                        }
                        return n.map((function(e) {
                            return Yt(Yt({}, t), e)
                        }))
                    } catch (e) {
                        return Object(zt.b)(e, "chunkConfig", {
                            makeVisibleToAllUsers: !0
                        }), []
                    }
                }

                function ht(t, e) {
                    var n = null != (n = null == e || null == (n = e.initConfig) ? void 0 : n.pubID) ? n : Tt.a.getState().config.pubID;
                    try {
                        t = Zt(n, "setDisplayBids", t, "slotIDList")
                    } catch (t) {}
                    var r = null != e && e.adServer ? Object(xt.a)(e.adServer) : Kt;
                    try {
                        null != e && e.adServer || Object(Et.j)(Tt.a.getState().config, "adServer") ? r.isSupported ? (Y(r, n, t, e), j(r, n)) : Object(zt.b)(new Error("apstag.setDisplayBids called with unsupported ad server: ".concat(Tt.a.getState().config.adServer)), "_setDisplayBids-invalidAdServer", {
                            makeVisibleToAllUsers: !0
                        }) : Object(zt.b)(new Error("apstag.setDisplayBids called without specifying ad server"), "_setDisplayBids-noAdServer", {
                            makeVisibleToAllUsers: !0
                        })
                    } catch (t) {
                        Object(zt.b)(t, "_setDisplayBids", {
                            makeVisibleToAllUsers: !0
                        })
                    }
                }

                function Ot(t, e) {
                    var n;
                    (null != (n = t.gdpr) && n.consent || null != (n = t.gdpr) && n.enabled) && (n = {
                        tcString: null == (n = t.gdpr) ? void 0 : n.consent,
                        gdprApplies: null == (n = t.gdpr) ? void 0 : n.enabled
                    }, a.writeConsentDataToStore(n)), a.attemptConsentDataSync(), V(t), "function" == typeof e && e()
                }

                function vt(t, e) {
                    var n = t.pubID;
                    t = Zt(n, "init", t, "config");
                    try {
                        var r = Kt = t.adServer ? Object(xt.a)(t.adServer) : Kt,
                            o = (Ot(t), lt(r), Object(ie.b)(), Object(Ht.a)(n).read("idVendors/newConfigFlowEnabled"));
                        !0 !== o && (void 0 === o && Object(Ht.a)(n).safelyRecord("idVendors/legacy/didExecuteFirst", {
                            analytics: {
                                context: "load3PLibraryConfig",
                                timing: "legacy-first"
                            }
                        }), Object(Vt.c)(n))
                    } catch (t) {
                        Object(zt.b)(t, "_init")
                    }
                    "function" == typeof e && e()
                }

                function jt() {
                    var t, e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "display",
                        n = Kt,
                        r = Tt.a.getState();
                    try {
                        switch (e) {
                            case Nt.a.DISPLAY:
                                return r.config.useSafeFrames ? [].concat(Xt(At.i), ["amznhost"]) : At.i;
                            case Nt.a.VIDEO:
                                return r.config.useSafeFrames ? [].concat(Xt(At.z), ["amznhost"]) : At.z;
                            default:
                                return Object(Ut.f)(null == (t = Tt.a.getState()) ? void 0 : t.config, n) && Object(Et.h)(Tt.a.getState().targetingKeys[e]) ? Tt.a.getState().targetingKeys[e] : []
                        }
                    } catch (t) {
                        return Object(zt.b)(t, "_targetingKeys", {
                            makeVisibleToAllUsers: !0
                        }), []
                    }
                }

                function St() {
                    try {
                        return Tt.a.getState().AAXReqs.reduce((function(t, e) {
                            return e.bidConfig.slots.reduce((function(t, e) {
                                return t[e.slotID] = e.slotName, t
                            }), t)
                        }), {})
                    } catch (t) {
                        return Object(zt.b)(t, "_getSlotIdToNameMapping", {
                            makeVisibleToAllUsers: !0
                        }), {}
                    }
                }

                function wt() {
                    return Gt.a.getDefault().allowedToStoreAndAccessInformationOnDevice()
                }
                try {
                    Object(Et.j)(window, "apstag") && Object(Et.j)(window.apstag, "_Q") && 0 < window.apstag._Q.length && Tt.a.dispatch({
                        type: "SET_Q",
                        Q: window.apstag._Q
                    })
                } catch (t) {
                    Object(zt.b)(t, "apstag-storeQ", {
                        makeVisibleToAllUsers: !0
                    })
                }
                window.apstag = function() {
                        var e = {
                            punt: z,
                            init: vt,
                            debug: Pt.a,
                            _getSlotIdToNameMapping: St,
                            targetingKeys: jt,
                            fetchBids: yt,
                            setDisplayBids: ht,
                            renderImp: bt,
                            bids: z,
                            deleteId: Mt.a,
                            updateId: Mt.e,
                            renewId: Mt.c,
                            dpa: Mt.a,
                            upa: Mt.e,
                            rpa: Mt.c,
                            thirdPartyData: {},
                            isGDPRRegion: !1,
                            rr: Mt.d,
                            re: zt.b,
                            _load3PLibraryConfig: Vt.c,
                            _atsaaiod: wt,
                            clientFetchBids: mt
                        };
                        return Object.keys(e).forEach((function(t) {
                            "function" == typeof e[t] && (e[t] = Object(Qt.a)(t, e[t]), e[t] = Object(zt.d)(e[t], t))
                        })), r ? Object(Pt.b)(!0, t) : n && Object(Pt.b)(!1, t), !0 === Object(Pt.c)("exposeApi") && (e._api = {
                            _getBidSetInfo: at,
                            _applyTargetingToGPTSlot: y,
                            dispatch: Tt.a.dispatch,
                            _clearTargetingFromGPTSlot: f,
                            _clearBidSetOnSlot: d,
                            _getCurrentSlotBids: p,
                            _creativeURL: w,
                            getSlotFetchCounts: it,
                            buildBidUrl: Ut.c
                        }), Yt(Yt({}, window.apstag), e)
                    }(),
                    function() {
                        try {
                            var t, e = (Tt.a.dispatch({
                                type: "SHOULD_SAMPLE_FEATURES",
                                value: Object(Et.k)(Tt.a.getState().cfg.FEATURE_SAMPLING_RATE)
                            }), Tt.a.dispatch({
                                type: "SET_HOST",
                                hostName: "DEFAULT_AAX_BID_HOST",
                                hostValue: "aax.amazon-adsystem.com"
                            }), Tt.a.dispatch({
                                type: "SHOULD_SAMPLE_LATENCY",
                                value: Object(Et.k)(Tt.a.getState().cfg.LATENCY_SAMPLING_RATE)
                            }), null !== Tt.a.getState().cfg.TEST_BID_ENDPOINT && (t = Object(Et.k)(Tt.a.getState().cfg.TEST_PATH_FREQUENCY), Tt.a.dispatch({
                                type: "SHOULD_USE_TEST_BID_ENDPOINT",
                                value: t
                            }), t) && null !== Tt.a.getState().cfg.TEST_PATH_LATENCY_SAMPLE_RATE && Tt.a.dispatch({
                                type: "SHOULD_SAMPLE_LATENCY",
                                value: Object(Et.k)(Tt.a.getState().cfg.TEST_PATH_LATENCY_SAMPLE_RATE)
                            }), Tt.a.dispatch({
                                type: "SHOULD_SAMPLE_SLOT_RENDER",
                                value: Object(Et.k)(Tt.a.getState().cfg.SLOT_RENDER_SAMPLING_RATE)
                            }), Tt.a.getState());
                            (e.experiments.shouldSampleLatency || e.displayAdServer.shouldSampleRender) && I()
                        } catch (t) {
                            Object(zt.b)(t, "apstag-sampleLatency")
                        }
                        try {
                            B()
                        } catch (t) {
                            Object(zt.b)(t, "apstag-doLast")
                        }
                        if (!Object(_t.i)(window, !0)) try {
                            var n = function(t) {
                                t && "object" !== Wt(t) || (t = "Request Timeout or Error"), Object(zt.b)({
                                    message: "csm-rtb-comm-js loading failed",
                                    name: t
                                }, "__csm-rtb-comm-js__")
                            };
                            Object(Lt.d)({
                                url: Tt.a.getState().cfg.CSM_RTB_COMMUNICATOR_JS,
                                onload: function t(e) {
                                    e.readyState === XMLHttpRequest.DONE && 200 === e.status ? eval(e.responseText) : n(JSON.stringify({
                                        status: e.statusText,
                                        response: e.responseXML
                                    }))
                                },
                                onerror: n,
                                ontimeout: n
                            })
                        } catch (t) {
                            Object(zt.b)(t, "__load-csm-rtb-comm-js__")
                        }
                        Object(Pt.e)()
                    }()
            }(), Object(Ht.a)("_system").safelyRecord("apstag/library/didLoad", {
                source: "bundle"
            }))
        } catch (t) {
            Object(zt.b)(t, "apstag")
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return d
        })), n.d(e, "c", (function() {
            return g
        })), n.d(e, "b", (function() {
            return h
        })), n.d(e, "d", (function() {
            return O
        }));
        var r = n(1),
            o = n(0),
            i = n(2),
            a = n(5);

        function c(t) {
            return (c = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function s(t, e) {
            var n, r = Object.keys(t);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), r.push.apply(r, n)), r
        }

        function u(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? s(Object(n), !0).forEach((function(e) {
                    var r, o;
                    r = t, o = n[e = e], (e = function(t) {
                        return t = function(t, e) {
                            if ("object" !== c(t) || null === t) return t;
                            var n = t[Symbol.toPrimitive];
                            if (void 0 === n) return String(t);
                            if ("object" !== c(n = n.call(t, e))) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }(t, "string"), "symbol" === c(t) ? t : String(t)
                    }(e)) in r ? Object.defineProperty(r, e, {
                        value: o,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : r[e] = o
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                }))
            }
            return t
        }
        var l = Number.isInteger || function(t) {
                return "number" == typeof t && isFinite(t) && Math.floor(t) === t
            },
            f = "__tcfapi";

        function d(t, e, n) {
            if (b = Object(a.a)(n).read("consent/TCData")) e({
                enabled: b.gdprApplies ? 1 : 0,
                consent: b.tcString,
                log: {
                    status: "tcfv2-success"
                },
                gdprApplies: b.gdprApplies
            });
            else {
                Object(a.a)(n).safelyRecord("_legacy/getGdprConfig_legacy/willExecute");
                var i, s = !1,
                    d = {
                        log: {
                            status: "no-status"
                        }
                    },
                    b = 50,
                    p = "global-func-error";
                e = Object(r.d)(e, "GdprCallback");
                try {
                    if (!1 === (t = Object(o.i)(t) ? u({}, t) : {}).enabled || 0 === t.enabled ? (d.log.status = "explicit-no-gdpr", d.enabled = 0) : !0 === t.enabled || 1 === t.enabled ? (d.log.status = Object(o.j)(t, "consent") ? "explicit-consent-passed" : "explicit-no-consent-passed", d.enabled = 1, d.consent = t.consent) : Object(o.j)(t, "enabled") && (d.log.status = Object(o.j)(t, "consent") ? "malformed-with-consent" : "malformed-without-consent", d.consent = t.consent, l(t.enabled) ? d.enabled = t.enabled : d.enabled = 1), Object(o.j)(t, "enabled") && (d.log.enabled = t.enabled), Object(o.j)(t, "cmpTimeout") && l(t.cmpTimeout) && (b = t.cmpTimeout, d.log.cmpTimeout = b), void 0 !== d.enabled) return Object(o.j)(d, "consent") && "string" != typeof d.consent && (delete d.consent, Object(r.b)(new Error("Invalid consent: must be string, given ".concat(c(d.consent))), "getGdprConfig-pub-consent-invalid", {
                        makeVisibleToAllUsers: !0
                    })), void y()
                } catch (t) {
                    Object(r.b)(t, "getGdprConfig-parseConfig", {
                        makeVisibleToAllUsers: !0
                    })
                }
                try {
                    Object(o.j)(window, f) && "function" == typeof window[f] ? (i = "tcfv2", setTimeout((function() {
                        d.log.status = "".concat(i, "-timeout"), y()
                    }), b), p = "".concat(i, "-internal-error"), window[f]("getTCData", 2, (function(t, e) {
                        try {
                            e && Object(o.i)(t) ? (d.log.status = "".concat(i, "-success"), Object(o.j)(t, "tcString") ? d.consent = t.tcString : Object(o.j)(t, "consentData") && (d.consent = t.consentData), d.enabled = t.gdprApplies ? 1 : 0, 0 === d.enabled && delete d.consent, d.gdprApplies = t.gdprApplies, y()) : (d.log.status = "".concat(i, "-error"), y())
                        } catch (t) {
                            d.log.status = "func-error", y(), Object(r.b)(t, "cmpCallback-".concat(i), {
                                makeVisibleToAllUsers: !0
                            })
                        }
                    }))) : (d.log.status = "no-cmp", y())
                } catch (t) {
                    d.log.status = p, y(), Object(r.b)(t, "getGdprConfig-".concat(p), {
                        makeVisibleToAllUsers: !0
                    })
                }
            }

            function y() {
                s || (s = !0, d.consent && Object(r.b)(new Error("Legacy getTCData logic was successful when addEventListener logic wasn't"), "LEGACY-TCFAPI-SUCCESS", {
                    makeVisibleToAllUsers: !1,
                    accountId: n
                }), e(u(u({}, d), {}, {
                    log: u({}, d.log)
                })))
            }
        }

        function b(t) {
            for (var e = [], n = -1; 0 <= (n = t.indexOf("1", n + 1));) e.push(n + 1);
            return e
        }

        function p(t) {
            for (var e = [], n = parseInt(m(t, 12), 2), r = 0; r < n; r++) {
                var o = parseInt(m(t, 1), 2),
                    i = parseInt(m(t, 16), 2);
                if (e.push(i), o)
                    for (var a = parseInt(m(t, 16), 2), c = i + 1; c <= a; c++) e.push(c)
            }
            return e
        }

        function y(t) {
            var e = parseInt(m(t, 16), 2);
            return parseInt(m(t, 1), 2) ? p(t) : b(m(t, e))
        }

        function m(t, e) {
            var n = t.bits.substr(t.index, e);
            return t.index += e, n
        }

        function g(t) {
            try {
                var e, n, o;
                return !!t && (!((e = function(t) {
                    try {
                        for (var e = (t = (t = t.replace(/-/g, "+")).replace(/_/g, "/")).split(".")[0], n = window.atob(e), o = "", i = 0; i < n.length; i++) o += ("0000000" + n.charCodeAt(i).toString(2)).substr(-8);
                        return o
                    } catch (e) {
                        return Object(r.b)(new Error("TCF string conversion failed. (TCF string: ".concat(t, ")")), "TCFToBinary", {
                            makeVisibleToAllUsers: !0
                        }), ""
                    }
                }(t)).length < 230) && (o = {
                    bits: e,
                    index: 0
                }, (n = {}).version = parseInt(m(o, 6), 2), 2 === n.version) && (n.created = parseInt(m(o, 36), 2), n.lastUpdated = parseInt(m(o, 36), 2), n.cmpId = parseInt(m(o, 12), 2), n.cmpVersion = parseInt(m(o, 12), 2), n.consentScreen = parseInt(m(o, 6), 2), n.consentLanguage = String.fromCharCode(parseInt(m(o, 6), 2) + 65) + String.fromCharCode(parseInt(m(o, 6), 2) + 65), n.vendorListVersion = parseInt(m(o, 12), 2), n.tcfPolicyVersion = parseInt(m(o, 6), 2), n.isServiceSpecific = "1" === m(o, 1), n.useNonStandardStacks = "1" === m(o, 1), n.specialFeatureOptIns = b(m(o, 12)), n.purposesConsent = b(m(o, 24)), n.purposesLITransparency = b(m(o, 24)), n.purposeOneTreatment = "1" === m(o, 1), n.publisherCC = String.fromCharCode(parseInt(m(o, 6), 2) + 65) + String.fromCharCode(parseInt(m(o, 6), 2) + 65), n.vendorConsents = y(o), n.vendorLegitimateInterests = y(o), n.publisherRestrictions = function(t) {
                    for (var e = parseInt(m(t, 12), 2), n = [], r = 0; r < e; r++) {
                        var o = parseInt(m(t, 6), 2),
                            i = parseInt(m(t, 2), 2);
                        n.push({
                            purposeId: o,
                            restrictionType: i,
                            vendorIds: p(t)
                        })
                    }
                    return n
                }(o), n))
            } catch (t) {
                return Object(r.b)(t, "parseTCFString", {
                    makeVisibleToAllUsers: !0
                }), !1
            }
        }

        function h(t) {
            var e = [];
            try {
                var n = Date.now(),
                    r = (t || e.push("Invalid tcString: ".concat(t)), 2 !== t.version && e.push("tcString version not supported: ".concat(t.version)), t.useNonStandardStacks && e.push("tcString's useNonStandardStacks should not be true"), t.isServiceSpecific || e.push("tcString needs to be service specific"), t.publisherRestrictions ? t.publisherRestrictions.filter((function(t) {
                        return 1 === t.purposeId && 0 <= t.vendorIds.indexOf(793)
                    })) : []);
                if (0 === r.length) v(t) || e.push("Invalid publisher restrictions");
                else switch (r[0].restrictionType) {
                    case 0:
                    case 2:
                        e.push("Invalid publisher restrictions");
                        break;
                    default:
                        v(t) || e.push("Invalid publisher restrictions")
                }
                return i.a.dispatch({
                    type: "RECORD_TCF_PARSE_TIME",
                    time: Date.now() - n
                }), e
            } catch (t) {
                if (e.length) return e;
                throw t
            }
        }

        function O(t, e) {
            if (!t) return !!window.apstag && !window.apstag.isGDPRRegion && !0 !== e;
            if (window.apstag && !window.apstag.isGDPRRegion && !1 === e) return !0;
            if (2 !== t.version) return !1;
            if (t.useNonStandardStacks) return !1;
            if (!t.isServiceSpecific) return !1;
            if (0 === (e = t.publisherRestrictions.filter((function(t) {
                    return 1 === t.purposeId && 0 <= t.vendorIds.indexOf(793)
                }))).length) return v(t);
            switch (e[0].restrictionType) {
                case 0:
                case 2:
                    return !1;
                default:
                    return v(t)
            }
        }

        function v(t) {
            return !(!Object(o.j)(t, "vendorConsents") || !Object(o.j)(t, "purposesConsent")) && 0 <= t.vendorConsents.indexOf(793) && 0 <= t.purposesConsent.indexOf(1)
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "b", (function() {
            return l
        })), n.d(e, "a", (function() {
            return f
        })), n.d(e, "e", (function() {
            return d
        })), n.d(e, "c", (function() {
            return b
        })), n.d(e, "d", (function() {
            return p
        }));
        var r, o = n(1),
            i = n(7),
            a = n(2),
            c = n(5),
            s = "AMZN-Token",
            u = "AMZN-NoCookieConsent";

        function l() {
            var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : r.token;
            try {
                var e = i.a.getDefault().cookie.getItem(t === r.noConsent ? u : s);
                return e || ""
            } catch (e) {
                return Object(o.b)(e, "getAmznToken-".concat(t)), ""
            }
        }

        function f(t) {
            var e = a.a.getState().config.pubID;
            return Object(c.a)(e).record("ad/record/delete").then((function() {
                "function" == typeof t && t()
            })).catch((function() {
                "function" == typeof t && t()
            }))
        }

        function d(t, e, n) {
            "boolean" != typeof n && (n = !0);
            var r = a.a.getState().config.pubID;
            return Object(c.a)(r).record("ad/record/update", {
                config: t,
                setCookie: n
            }).then((function() {
                "function" == typeof e && e()
            })).catch((function() {
                "function" == typeof e && e()
            }))
        }

        function b(t, e, n) {
            "boolean" != typeof n && (n = !0);
            var r = a.a.getState().config.pubID;
            return Object(c.a)(r).record("ad/record/renew", {
                config: t,
                setCookie: n
            }).then((function() {
                "function" == typeof e && e()
            })).catch((function() {
                "function" == typeof e && e()
            }))
        }

        function p(t) {
            var e = a.a.getState().config.pubID;
            return Object(c.a)(e).safelyRecord("ad/record/rr", {
                config: t
            })
        }(e = r = r || {})[e.noConsent = 0] = "noConsent", e[e.token = 1] = "token"
    }, function(t, e, n) {
        "use strict";
        var r;
        n.d(e, "a", (function() {
            return r
        })), (n = r = r || {}).DISPLAY = "d", n.VIDEO = "v", n.MULTI_FORMAT = "mf"
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return v
        })), n.d(e, "c", (function() {
            return j
        })), n.d(e, "e", (function() {
            return S
        })), n.d(e, "d", (function() {
            return w
        })), n.d(e, "b", (function() {
            return D
        }));
        var c = n(8),
            s = n(1),
            u = n(33),
            l = n(3),
            f = n(2),
            d = n(7),
            r = n(0),
            b = n(16),
            o = n(34),
            p = n(25),
            i = n(5);

        function a(t) {
            return (a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function y(t, e) {
            var n, r = Object.keys(t);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), r.push.apply(r, n)), r
        }

        function m(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? y(Object(n), !0).forEach((function(e) {
                    g(t, e, n[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : y(Object(n)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                }))
            }
            return t
        }

        function g(t, e, n) {
            (e = h(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function h(t) {
            return "symbol" === a(t = O(t, "string")) ? t : String(t)
        }

        function O(t, e) {
            if ("object" !== a(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === e ? String : Number)(t);
            if ("object" !== a(n = n.call(t, e || "default"))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }

        function v(t) {
            Object(i.a)(t).record("cxm/contextual/set").catch((function() {}))
        }

        function j(r, o, i, e) {
            var a = Date.now(),
                t = Object(u.a)(window.location, window.top.location, o);
            if (null !== t) {
                var n = {
                    url: t,
                    withCredentials: !0,
                    onload: function t(e) {
                        if (200 === e.status) try {
                            f.a.dispatch({
                                type: "RECORD_LIBRARY_LOAD_CALL_LATENCY",
                                latency: Date.now() - a
                            });
                            var n = JSON.parse(e.response);
                            eval(n["3pvendor"]), Object(b.a)(f.a.getState().config.gdpr, (function(t) {
                                var e;
                                t && (e = Object(b.c)(t.consent), Object(d.b)()) && Object(b.d)(e, t.gdprApplies) && d.a.getDefault().localStorage.setItem(l.e, "1")
                            }), r), Object(p.b)(n, o)
                        } catch (t) {
                            Object(s.b)(t, "load3PLibraryConfig-onload"), Object(p.a)(t, "load3PLibraryConfig-onload", o)
                        }
                        null != i && i()
                    },
                    onerror: function(t) {
                        t = new Error("".concat(t.type, ": ").concat(t.loaded, " bytes transferred")), Object(s.b)(t, "load3PLibraryConfig-onerror"), Object(p.a)(t, "load3PLibraryConfig-onerror", o), null != e && e(t)
                    }
                };
                try {
                    Object(c.d)(n)
                } catch (t) {
                    Object(s.b)(t, "load3PLibraryConfig"), Object(p.a)(t, "load3PLibraryConfig", o), null != e && e(t)
                }
            }
        }

        function S() {
            return Object(r.j)(window, "creativeVendorLibraryLoaded") && !0 === window.creativeVendorLibraryLoaded || Object(r.j)(window, "confiant")
        }

        function w() {
            var t = {
                renderTimes: {}
            };
            window.addEventListener("message", (function(e) {
                Object(o.a)(t, e)
            }))
        }

        function D(t) {
            var e = {
                ids: {}
            };
            try {
                if (!0 !== Object(i.a)(t).read("idVendors/newConfigFlowEnabled") && "1" !== d.a.getDefault().localStorage.getItem(l.e)) return e;
                Object(i.a)(t).record("idVendors/ids/get").catch((function() {})), e.ids = m({}, Object(i.a)(t).read("idVendors/ids"));
                var n = Object(i.a)(t).read("idVendors/metadata");
                n && (e.md = n)
            } catch (t) {
                Object(s.b)(t, "getIdentityConfig")
            }
            return e
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "d", (function() {
            return d
        })), n.d(e, "c", (function() {
            return b
        })), n.d(e, "b", (function() {
            return p
        })), n.d(e, "g", (function() {
            return h
        })), n.d(e, "a", (function() {
            return S
        })), n.d(e, "e", (function() {
            return w
        })), n.d(e, "f", (function() {
            return T
        }));
        var r = n(1),
            o = n(0),
            i = n(2),
            a = n(3),
            c = n(4);

        function s(t) {
            return (s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function u(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, l(r.key), r)
            }
        }

        function l(t) {
            return t = function(t, e) {
                if ("object" !== s(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== s(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === s(t) ? t : String(t)
        }
        var f = function() {
            function t() {
                var e, n = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {},
                    r = this,
                    o = t;
                if (!(r instanceof o)) throw new TypeError("Cannot call a class as a function");
                r = this, o = void 0, (e = l(e = "_rawProps")) in r ? Object.defineProperty(r, e, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : r[e] = o, this._rawProps = n
            }
            var e, n;
            return e = t, (n = [{
                key: "source",
                get: function() {
                    return "web"
                }
            }, {
                key: "omsdkAccessMode",
                get: function() {
                    return "limited"
                }
            }, {
                key: "publisherType",
                get: function() {
                    var t = i.a.getState().config;
                    return t && !0 === t.isSelfServePub ? c.b.SELF_SERVE_WEB : c.b.MANAGED_WEB
                }
            }, {
                key: "publisherUUID",
                get: function() {
                    var t = i.a.getState().config;
                    if (t) return t.pubID
                }
            }, {
                key: "integratorVersion",
                get: function() {
                    return a.l
                }
            }, {
                key: "bidId",
                get: function() {
                    var t = this._rawProps.bidId;
                    if ("string" == typeof t) return t
                }
            }, {
                key: "dealId",
                get: function() {
                    var t = this._rawProps.dealId;
                    if ("string" == typeof t) return t
                }
            }, {
                key: "hostName",
                get: function() {
                    var t = this._rawProps.hostName;
                    if ("string" == typeof t) return t
                }
            }, {
                key: "pricePoint",
                get: function() {
                    var t = this._rawProps.pricePoint;
                    if ("string" == typeof t) return t
                }
            }, {
                key: "targetingMap",
                get: function() {
                    var t = this._rawProps.targetingMap;
                    if ("string" == typeof t) return t
                }
            }, {
                key: "adServerType",
                get: function() {
                    var t = i.a.getState().config;
                    if (t) return t.adServer
                }
            }, {
                key: "adServerAdUnitId",
                get: function() {
                    var t = this._rawProps.adServerAdUnitId;
                    if ("string" == typeof t) return t
                }
            }, {
                key: "apsAdUnitId",
                get: function() {
                    var t = this._rawProps.apsAdUnitId;
                    if ("string" == typeof t) return t
                }
            }, {
                key: "getProperties",
                value: function() {
                    return JSON.stringify({
                        source: this.source,
                        omsdkAccessMode: this.omsdkAccessMode,
                        publisherType: this.publisherType,
                        publisherUUID: this.publisherUUID,
                        integratorVersion: this.integratorVersion,
                        bidId: this.bidId,
                        hostName: this.hostName,
                        dealId: this.dealId,
                        pricePoint: this.pricePoint,
                        targetingMap: this.targetingMap,
                        adServerType: this.adServerType,
                        adServerAdUnitId: this.adServerAdUnitId,
                        apsAdUnitId: this.apsAdUnitId
                    })
                }
            }]) && u(e.prototype, n), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t
        }();

        function d(t, e) {
            try {
                if (Object(o.j)(e, "slotID")) {
                    var n = e.slotID,
                        i = t.getElementById(n);
                    if (i instanceof HTMLDivElement) return i
                }
            } catch (t) {
                Object(r.b)(t, "getVideoDivElement-outstream")
            }
        }

        function b(t, e) {
            try {
                Object(o.j)(t, "bidID") && (e += "b=".concat(t.bidID)), Object(o.j)(t, "pp") && void 0 === t.dealId && (e += "&pp=".concat(t.pp)), e += "&rnd=".concat(Object(o.c)())
            } catch (t) {
                Object(r.b)(t, "constructVastTag")
            }
            return e
        }

        function p(t, e, n, o) {
            try {
                var i = {
                        bidId: null == n ? void 0 : n.bidID,
                        hostName: null == n ? void 0 : n.host,
                        dealId: null == n ? void 0 : n.dealId,
                        pricePoint: null == n ? void 0 : n.pp,
                        apsAdUnitId: null == n ? void 0 : n.slotID
                    },
                    a = {
                        key: "$$videoPlayerProps$$",
                        value: new f(i).getProperties()
                    },
                    c = {
                        key: "$$apstagVastTag$$",
                        value: t
                    },
                    s = {
                        key: "$$apstagCompanionContainers$$",
                        value: JSON.stringify(o || [])
                    },
                    u = e;
                return [a, c, s, {
                    key: "$$apsvidonerror$$",
                    value: "try { window.parent.apstag.re(new Error('video player load error'), 'vsdk-load-fail'); } catch(e) {}"
                }].forEach((function(t) {
                    var e = t.key;
                    t = t.value;
                    return u = u.replace(e, t)
                })), u
            } catch (t) {
                return Object(r.b)(t, "constructVastTag"), ""
            }
        }
        var y = {},
            m = function(t) {
                return y[t] || (y[t] = {
                    started: !1,
                    completed: !1,
                    loaded: !1,
                    isPaused: !1
                }), y[t]
            },
            g = {
                root: null,
                rootMargin: "0px",
                threshold: .5
            };

        function h(t, e, n) {
            try {
                var o;
                window.addEventListener("message", (function(t) {
                    ! function(t, e) {
                        if (t.origin === window.top.location.origin && !0 === t.data.apsVideoPlayer) switch (t.data.event) {
                            case "completed":
                                m(e).completed = !0;
                                break;
                            case "loaded":
                                m(e).loaded = !0
                        }
                    }(t, n)
                })), window.IntersectionObserver ? (o = new window.IntersectionObserver((function(r) {
                    r.forEach((function(r) {
                        .5 < r.intersectionRatio && e.contentWindow && (O(e, t, n), o.disconnect())
                    }))
                }), g)).observe(t) : Object(r.b)({
                    name: "IntersectionObserver",
                    message: "IntersectionObserver not supported "
                }, "startVideoAndHandlePlayback")
            } catch (t) {
                Object(r.b)(t, "startVideoAndHandlePlayback")
            }
        }

        function O(t, e, n) {
            try {
                null !== t.contentDocument && Object(o.g)(["complete", "interactive"], t.contentDocument.readyState) ? j(t, e, n) : null !== t.contentDocument && "uninitialized" !== t.contentDocument.readyState ? t.contentDocument.addEventListener("DOMContentLoaded", (function() {
                    j(t, e, n)
                })) : t.addEventListener("load", (function() {
                    j(t, e, n)
                })), setTimeout(j, 1e3, !0)
            } catch (t) {
                Object(r.b)(t, "loadVideoAd")
            }
        }

        function v(t, e, n) {
            try {
                var o;
                window.IntersectionObserver && (o = new window.IntersectionObserver((function(e) {
                    e.forEach((function(e) {
                        m(n).completed && o.disconnect(), e.intersectionRatio < .5 && !m(n).isPaused ? t.contentWindow && t.contentWindow.adsM && (t.contentWindow.adsM.pause(), m(n).isPaused = !0) : m(n).isPaused && t.contentWindow && t.contentWindow.adsM && (t.contentWindow.adsM.play(), m(n).isPaused = !1)
                    }))
                }), {
                    threshold: .5
                })).observe(e)
            } catch (e) {
                Object(r.b)(e, "handleAutoPauseAndPlay")
            }
        }

        function j(t, e, n) {
            t.contentWindow && !m(n).started && (m(n).started = !0, function(t, e, n) {
                var r = Number(new Date) + (e || 2e3);
                return n = n || 100, new Promise((function e(o, i) {
                    var a = t();
                    a ? o(a) : Number(new Date) < r ? setTimeout(e, n, o, i) : i(new Error("apsVideoPlayer timed out"))
                }))
            }((function() {
                return m(n).loaded
            }), 3e4, 100).then((function() {
                t.contentWindow && t.contentWindow.adsM && (t.contentWindow.adsM.play(), v(t, e, n))
            })).catch((function() {
                v(t, e, n), Object(r.b)({
                    name: "VideoPlayerTimeout",
                    message: "video player took more than 30 seconds to load"
                }, "startAd")
            })))
        }

        function S(t, e) {
            try {
                e && e.appendChild(t)
            } catch (t) {
                Object(r.b)(t, "_appendDivElement")
            }
        }

        function w(t, e) {
            try {
                t.appendChild(e)
            } catch (t) {
                Object(r.b)(t, "_insertVideoIframeInsideDiv")
            }
        }

        function T(t) {
            var e = document.createElement("div");
            return e.style.width = "".concat(t[0], "px"), e.style.height = "".concat(t[1], "px"), e.style.margin = "0 auto", e.id = "apsVideoDiv-".concat(Object(o.c)()), e
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return u
        }));
        var r = n(0),
            o = n(1);

        function i(t) {
            return (i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function a(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, s(r.key), r)
            }
        }

        function c(t, e, n) {
            (e = s(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function s(t) {
            return t = function(t, e) {
                if ("object" !== i(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== i(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === i(t) ? t : String(t)
        }
        var u = function() {
            function t(e) {
                var n = !(1 < arguments.length && void 0 !== arguments[1]) || arguments[1],
                    r = 2 < arguments.length && void 0 !== arguments[2] && arguments[2],
                    o = this,
                    i = t;
                if (!(o instanceof i)) throw new TypeError("Cannot call a class as a function");
                c(this, "validSizeStringRegex", /^[0-9]+x[0-9]+$/), c(this, "numberStringRegex", /^[0-9]+$/), c(this, "_sizes", void 0), c(this, "_permit1D", !0), c(this, "_allowUndefined", !1), this._sizes = e, this._permit1D = n, this._allowUndefined = r
            }
            var e, n;
            return e = t, (n = [{
                key: "isValid",
                value: function() {
                    return !(void 0 !== this._sizes || !this._allowUndefined) || 0 < this.sizes.length
                }
            }, {
                key: "sizes",
                get: function() {
                    var t = this;
                    try {
                        var e = [];
                        if (Object(r.h)(this._sizes)) {
                            this._sizes = this._sizes.filter((function(t) {
                                return "fluid" !== t
                            }));
                            var n = "2d",
                                i = this._sizes;
                            if (i && 0 < i.length && !Object(r.h)(i[0]) && ("string" != typeof i[0] || !this.validSizeStringRegex.test(i[0]))) {
                                if (!this._permit1D) throw new Error("Sizes must be 2d array");
                                n = "1d", i = [i]
                            }
                            e = i.filter((function(e) {
                                return t.isValidSize(n, e)
                            })).map((function(t) {
                                return Object(r.h)(t) ? t : t.split("x").map((function(t) {
                                    return parseInt(t, 10)
                                }))
                            }))
                        }
                        return e
                    } catch (e) {
                        return Object(o.b)(e, "SizesDelegate-getSizes"), []
                    }
                }
            }, {
                key: "aaxSizes",
                get: function() {
                    if (void 0 !== this._sizes || !this._allowUndefined) return this.sizes.filter(r.h).map((function(t) {
                        return t.join("x")
                    }))
                }
            }, {
                key: "isValidSize",
                value: function(t, e) {
                    var n = this,
                        i = [];

                    function a(t) {
                        t = JSON.stringify(t), -1 === i.indexOf(t) && (i.push(t), Object(o.b)({
                            name: "SizesDelegate-isValidSize-invalid",
                            message: "Invalid Slot Size: ".concat(JSON.stringify(e))
                        }, "SizesDelegate-isValidSize-invalid"))
                    }
                    try {
                        return !("string" != typeof e || !this.validSizeStringRegex.test(e)) || (Object(r.h)(e) && 1 !== e.length ? (2 < e.length && a(e), e.slice(0, 2).reduce((function(t, e) {
                            return t && !("number" != typeof e && "string" != typeof e || "string" == typeof e && !n.numberStringRegex.test(e))
                        }), !0)) : (a(e), !1))
                    } catch (t) {
                        return Object(o.b)(t, "isValidSize"), !0
                    }
                }
            }]) && a(e.prototype, n), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t
        }()
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return g
        }));
        e = n(14);
        var r = n(0),
            o = n(1),
            i = n(4);

        function a(t) {
            return (a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function c(t, e) {
            var n, r = Object.keys(t);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), r.push.apply(r, n)), r
        }

        function s(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? c(Object(n), !0).forEach((function(e) {
                    y(t, e, n[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                }))
            }
            return t
        }

        function u(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, m(r.key), r)
            }
        }

        function l() {
            return (l = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function(t, e, n) {
                var r = function(t, e) {
                    for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = p(t)););
                    return t
                }(t, e);
                if (r) return (r = Object.getOwnPropertyDescriptor(r, e)).get ? r.get.call(arguments.length < 3 ? t : n) : r.value
            }).apply(this, arguments)
        }

        function f(t, e) {
            return (f = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                return t.__proto__ = e, t
            })(t, e)
        }

        function d(t) {
            var e = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (t) {
                    return !1
                }
            }();
            return function() {
                var n, r = p(t);
                n = e ? (n = p(this).constructor, Reflect.construct(r, arguments, n)) : r.apply(this, arguments), r = this;
                if (n && ("object" === a(n) || "function" == typeof n)) return n;
                if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                return b(r)
            }
        }

        function b(t) {
            if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return t
        }

        function p(t) {
            return (p = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
                return t.__proto__ || Object.getPrototypeOf(t)
            })(t)
        }

        function y(t, e, n) {
            (e = m(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function m(t) {
            return t = function(t, e) {
                if ("object" !== a(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== a(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === a(t) ? t : String(t)
        }
        var g = function(t) {
            var e = a;
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t && f(e, t);
            var n = d(a);

            function a(t) {
                var e;
                if (this instanceof a) return y(b(e = n.call(this, {
                    slotID: t.getSlotElementId(),
                    slotName: t.getAdUnitPath()
                })), "rawSlot", void 0), e.rawSlot = t, e;
                throw new TypeError("Cannot call a class as a function")
            }
            return e = a, (t = [{
                key: "mediaType",
                get: function() {
                    return i.a.DISPLAY
                }
            }, {
                key: "sizes",
                get: function() {
                    try {
                        var t = Object(r.f)(window).split("x").map((function(t) {
                                return Number(t)
                            })),
                            e = this.rawSlot.getSizes(t[0], t[1]);
                        return null === e ? [] : e.filter((function(t) {
                            return "fluid" !== t
                        })).map((function(t) {
                            return [t.getWidth(), t.getHeight()]
                        }))
                    } catch (t) {
                        return this.reportError(t, "sizes"), []
                    }
                }
            }, {
                key: "aaxSlot",
                get: function() {
                    var t = s(s({}, l(p(a.prototype), "aaxSlot", this)), {}, {
                        sd: this.slotID,
                        s: this.sizes.filter(r.h).map((function(t) {
                            return t.join("x")
                        }))
                    });
                    return this.slotID !== this.slotName && (t.sn = this.slotName), t
                }
            }, {
                key: "isValid",
                value: function() {
                    return !(!l(p(a.prototype), "isValid", this).call(this) || 0 === this.sizes.length && (this.reportIsValidMessages(["'sizes' must have at least 1 valid item"], !0), 1))
                }
            }, {
                key: "reportError",
                value: function(t, e, n) {
                    Object(o.b)(t, "GptSlot-".concat(e), n)
                }
            }, {
                key: "setTargeting",
                value: function(t, e) {
                    try {
                        this.rawSlot.setTargeting(t, e)
                    } catch (t) {
                        this.reportError(t, "setTargeting")
                    }
                }
            }, {
                key: "getTargeting",
                value: function(t) {
                    try {
                        return this.rawSlot.getTargeting(t)
                    } catch (t) {
                        return this.reportError(t, "getTargeting"), []
                    }
                }
            }, {
                key: "clearTargeting",
                value: function(t) {
                    try {
                        this.rawSlot.clearTargeting(t)
                    } catch (t) {
                        this.reportError(t, "clearTargeting")
                    }
                }
            }]) && u(e.prototype, t), Object.defineProperty(e, "prototype", {
                writable: !1
            }), a
        }(e.a)
    }, function(t, e, n) {
        "use strict";
        n.d(e, "c", (function() {
            return i
        })), n.d(e, "a", (function() {
            return a
        })), n.d(e, "b", (function() {
            return c
        }));
        var r = n(1),
            o = n(0);

        function i(t) {
            try {
                return !(!Object(o.j)(t, "$sf") || !Object(o.j)(t.$sf, "ext"))
            } catch (t) {
                return Object(r.b)(t, "isSafeFrame"), !1
            }
        }

        function a(t, e) {
            try {
                var n, o, i, a = e.innerWidth,
                    c = e.innerHeight,
                    s = parseInt(t[0], 10),
                    u = parseInt(t[1], 10),
                    l = s - a,
                    f = u - c,
                    d = e.sfAPI || (null == (n = e.$sf) ? void 0 : n.ext);
                !d || a === s && c === u || (null != (o = d.register) && o.call(d, s, u), null != (i = d.expand) && i.call(d, {
                    r: l,
                    b: f,
                    push: !0
                }))
            } catch (t) {
                Object(r.b)(t, "expandSf")
            }
        }

        function c(t) {
            try {
                return 1 === t.innerWidth && 1 === t.innerHeight
            } catch (t) {
                return Object(r.b)(t, "is1x1Creative"), !1
            }
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return f
        }));
        var r = n(1);

        function o(t) {
            return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function i(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, c(r.key), r)
            }
        }

        function a(t, e, n) {
            return (e = c(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n, t
        }

        function c(t) {
            return t = function(t, e) {
                if ("object" !== o(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== o(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === o(t) ? t : String(t)
        }
        var s = "__tcfapi",
            u = "isListenedTo",
            l = "consentManagementPlatform",
            f = function() {
                function t(e) {
                    if (!(this instanceof t)) throw new TypeError("Cannot call a class as a function");
                    a(this, "store", void 0), a(this, "globalContext", void 0), this.store = e.stateContainer, this.globalContext = e.globalContext
                }
                var e, n, o;
                return e = t, o = [{
                    key: "readStoredConsentData",
                    value: function(t) {
                        return null == (t = t.getState()[l]) ? void 0 : t.tcData
                    }
                }], (n = [{
                    key: "isListenerActive",
                    get: function() {
                        return this.isListenedTo
                    }
                }, {
                    key: "isListenedTo",
                    get: function() {
                        var t;
                        return (null == (t = this.store.getState()[l]) ? void 0 : t[u]) || !1
                    },
                    set: function(t) {
                        this.store.dispatch(a({
                            type: "RECORD_CMP_LISTENED_TO"
                        }, u, t))
                    }
                }, {
                    key: "writeConsentDataToStore",
                    value: function(t) {
                        this.store.dispatch(a({
                            type: "RECORD_CMP_CONSENT_DATA"
                        }, "tcData", t))
                    }
                }, {
                    key: "onConsentDataChange",
                    value: function(t, e, n) {
                        try {
                            e ? (this.isListenedTo = !0, t && this.writeConsentDataToStore(t), null != n && n(!0)) : null != n && n(!1)
                        } catch (t) {
                            Object(r.b)(t, "attemptConsentDataSync-onConsentDataChange")
                        }
                    }
                }, {
                    key: "syncConsentData",
                    value: function(t) {
                        var e = this;
                        this.globalContext[s] ? this.globalContext[s]("addEventListener", 2, (function(n, r) {
                            return e.onConsentDataChange(n, r, t)
                        })) : null != t && t(!1)
                    }
                }, {
                    key: "syncConsentDataIfNotSynced",
                    value: function(t) {
                        this.isListenedTo ? null != t && t(!0) : this.syncConsentData(t)
                    }
                }, {
                    key: "attemptConsentDataSync",
                    value: function(t) {
                        try {
                            this.syncConsentDataIfNotSynced(t)
                        } catch (e) {
                            Object(r.b)(e, "attemptConsentDataSync"), null != t && t(!1)
                        }
                    }
                }]) && i(e.prototype, n), o && i(e, o), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t
            }()
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return d
        })), n.d(e, "b", (function() {
            return b
        }));
        var r = n(8),
            o = n(1),
            i = n(2),
            a = n(3),
            c = n(6),
            s = n(0);

        function u(t) {
            return (u = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function l(t, e) {
            var n, r = Object.keys(t);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), r.push.apply(r, n)), r
        }

        function f(t) {
            var e = Object(c.c)("bsHost", i.a.getState().hosts.DEFAULT_BS_HOST);
            e = {
                url: "".concat(a.r).concat("prod", ".").concat("us-east-1", ".").concat(e).concat("/v1/recordVendorsLoaded"),
                body: JSON.stringify(t),
                headers: {
                    "Content-Type": "application/json"
                },
                onload: function() {}
            };
            try {
                Object(r.d)(e)
            } catch (t) {
                Object(o.b)(t, "load3PLibraryConfig-VendorLoadedEvent-SendError")
            }
        }

        function d(t, e, n) {
            if (Object(s.k)(a.w)) try {
                var r = i.a.getState().config;
                f([{
                    publisherId: ("600" === (null == n ? void 0 : n.sourceID) ? null == n ? void 0 : n.publisherUUID : null == n ? void 0 : n.sourceID) || r.pubID,
                    sourceId: (null == n ? void 0 : n.sourceID) || (r.isSelfServePub ? a.s : r.pubID),
                    failure: e,
                    errorName: t.name,
                    errorMessage: t.message
                }])
            } catch (t) {
                Object(o.b)(t, "load3PLibraryConfig-VendorLoadedEventError-ConstructError")
            }
        }

        function b(t, e) {
            var n;
            if (n = t, Object(s.k)("number" == typeof n["3psamplerate"] ? n["3psamplerate"] : a.w)) try {
                var r = JSON.parse(t[a.x]),
                    c = (c = "600" === (null == e ? void 0 : e.sourceID) ? null == e ? void 0 : e.publisherUUID : null == e ? void 0 : e.sourceID) || i.a.getState().config.pubID;
                f(r.map((function(t) {
                    return function(t) {
                        for (var e = 1; e < arguments.length; e++) {
                            var n = null != arguments[e] ? arguments[e] : {};
                            e % 2 ? l(Object(n), !0).forEach((function(e) {
                                var r, o;
                                r = t, o = n[e = e], (e = function(t) {
                                    return t = function(t, e) {
                                        if ("object" !== u(t) || null === t) return t;
                                        var n = t[Symbol.toPrimitive];
                                        if (void 0 === n) return String(t);
                                        if ("object" !== u(n = n.call(t, e))) return n;
                                        throw new TypeError("@@toPrimitive must return a primitive value.")
                                    }(t, "string"), "symbol" === u(t) ? t : String(t)
                                }(e)) in r ? Object.defineProperty(r, e, {
                                    value: o,
                                    enumerable: !0,
                                    configurable: !0,
                                    writable: !0
                                }) : r[e] = o
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : l(Object(n)).forEach((function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                            }))
                        }
                        return t
                    }({
                        publisherId: c
                    }, t)
                })))
            } catch (t) {
                Object(o.b)(t, "load3PLibraryConfig-VendorLoadedEvent-ConstructError")
            }
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return b
        }));
        var r = n(0),
            o = (e = n(13), n(1)),
            i = n(22);

        function a(t) {
            return (a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function c(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, d(r.key), r)
            }
        }

        function s(t, e) {
            return (s = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                return t.__proto__ = e, t
            })(t, e)
        }

        function u(t) {
            var e = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (t) {
                    return !1
                }
            }();
            return function() {
                var n, r = f(t);
                n = e ? (n = f(this).constructor, Reflect.construct(r, arguments, n)) : r.apply(this, arguments), r = this;
                if (n && ("object" === a(n) || "function" == typeof n)) return n;
                if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                return l(r)
            }
        }

        function l(t) {
            if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return t
        }

        function f(t) {
            return (f = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
                return t.__proto__ || Object.getPrototypeOf(t)
            })(t)
        }

        function d(t) {
            return t = function(t, e) {
                if ("object" !== a(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== a(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === a(t) ? t : String(t)
        }
        var b = function(t) {
            var e = a;
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t && s(e, t);
            var n = u(a);

            function a() {
                var t = this,
                    e = a;
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
                for (var r, o, i = arguments.length, c = new Array(i), s = 0; s < i; s++) c[s] = arguments[s];
                return e = l(t = n.call.apply(n, [this].concat(c))), o = !0, (r = d(r = "isSupported")) in e ? Object.defineProperty(e, r, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[r] = o, t
            }
            return e = a, (t = [{
                key: "reportError",
                value: function(t, e) {
                    Object(o.b)(t, "GoogletagAdServer-".concat(e))
                }
            }, {
                key: "cmdQueuePush",
                value: function(t) {
                    try {
                        window.googletag.cmd.push(t)
                    } catch (t) {
                        this.reportError(t, "cmdQueuePush")
                    }
                }
            }, {
                key: "slotRenderEndedEvent",
                value: function(t) {
                    try {
                        window.googletag.pubads().addEventListener("slotRenderEnded", (function(e) {
                            e = new i.a(e.slot), t(e)
                        }))
                    } catch (t) {
                        this.reportError(t, "slotRenderEndedEvent")
                    }
                }
            }, {
                key: "setTargeting",
                value: function(t, e) {
                    try {
                        window.googletag.pubads().setTargeting(t, e)
                    } catch (t) {
                        this.reportError(t, "setTargeting")
                    }
                }
            }, {
                key: "getTargeting",
                value: function(t) {
                    try {
                        return window.googletag.pubads().getTargeting(t) || []
                    } catch (t) {
                        return this.reportError(t, "getTargeting"), []
                    }
                }
            }, {
                key: "clearTargeting",
                value: function(t) {
                    try {
                        window.googletag.pubads().clearTargeting(t)
                    } catch (t) {
                        this.reportError(t, "clearTargeting")
                    }
                }
            }, {
                key: "hasAdServerObjectLoaded",
                value: function() {
                    try {
                        return Object(r.j)(window, "googletag") && Object(r.j)(window.googletag, "apiReady") && !0 === window.googletag.apiReady
                    } catch (t) {
                        return this.reportError(t, "hasAdServerObjectLoaded"), !1
                    }
                }
            }, {
                key: "isCommandQueueDefined",
                value: function() {
                    try {
                        return Object(r.j)(window, "googletag") && Object(r.j)(window.googletag, "cmd")
                    } catch (t) {
                        return this.reportError(t, "isCommandQueueDefined"), !1
                    }
                }
            }, {
                key: "getSlots",
                value: function() {
                    try {
                        return window.googletag.pubads().getSlots().map((function(t) {
                            return new i.a(t)
                        }))
                    } catch (t) {
                        return this.reportError(t, "getSlots"), []
                    }
                }
            }]) && c(e.prototype, t), Object.defineProperty(e, "prototype", {
                writable: !1
            }), a
        }(e.a)
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return j
        })), n.d(e, "b", (function() {
            return S
        }));
        var r = n(1),
            o = n(8),
            i = n(0),
            a = n(5),
            c = n(3),
            s = n(9),
            u = n(6),
            l = n(2);

        function f(t) {
            return (f = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function d() { /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */
            d = function() {
                return t
            };
            var t = {},
                e = Object.prototype,
                n = e.hasOwnProperty,
                r = Object.defineProperty || function(t, e, n) {
                    t[e] = n.value
                },
                o = (m = "function" == typeof Symbol ? Symbol : {}).iterator || "@@iterator",
                i = m.asyncIterator || "@@asyncIterator",
                a = m.toStringTag || "@@toStringTag";

            function c(t, e, n) {
                return Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }), t[e]
            }
            try {
                c({}, "")
            } catch (e) {
                c = function(t, e, n) {
                    return t[e] = n
                }
            }

            function s(t, e, n, o) {
                var i, a, c, s;
                e = e && e.prototype instanceof b ? e : b, e = Object.create(e.prototype), o = new w(o || []);
                return r(e, "_invoke", {
                    value: (i = t, a = n, c = o, s = "suspendedStart", function(t, e) {
                        if ("executing" === s) throw new Error("Generator is already running");
                        if ("completed" === s) {
                            if ("throw" === t) throw e;
                            return {
                                value: void 0,
                                done: !0
                            }
                        }
                        for (c.method = t, c.arg = e;;) {
                            var n = c.delegate;
                            if (n && (n = function t(e, n) {
                                    var r = n.method,
                                        o = e.iterator[r];
                                    return void 0 === o ? (n.delegate = null, "throw" === r && e.iterator.return && (n.method = "return", n.arg = void 0, t(e, n), "throw" === n.method) || "return" !== r && (n.method = "throw", n.arg = new TypeError("The iterator does not provide a '" + r + "' method")), l) : "throw" === (r = u(o, e.iterator, n.arg)).type ? (n.method = "throw", n.arg = r.arg, n.delegate = null, l) : (o = r.arg) ? o.done ? (n[e.resultName] = o.value, n.next = e.nextLoc, "return" !== n.method && (n.method = "next", n.arg = void 0), n.delegate = null, l) : o : (n.method = "throw", n.arg = new TypeError("iterator result is not an object"), n.delegate = null, l)
                                }(n, c))) {
                                if (n === l) continue;
                                return n
                            }
                            if ("next" === c.method) c.sent = c._sent = c.arg;
                            else if ("throw" === c.method) {
                                if ("suspendedStart" === s) throw s = "completed", c.arg;
                                c.dispatchException(c.arg)
                            } else "return" === c.method && c.abrupt("return", c.arg);
                            if (s = "executing", "normal" === (n = u(i, a, c)).type) {
                                if (s = c.done ? "completed" : "suspendedYield", n.arg === l) continue;
                                return {
                                    value: n.arg,
                                    done: c.done
                                }
                            }
                            "throw" === n.type && (s = "completed", c.method = "throw", c.arg = n.arg)
                        }
                    })
                }), e
            }

            function u(t, e, n) {
                try {
                    return {
                        type: "normal",
                        arg: t.call(e, n)
                    }
                } catch (t) {
                    return {
                        type: "throw",
                        arg: t
                    }
                }
            }
            t.wrap = s;
            var l = {};

            function b() {}

            function p() {}

            function y() {}
            var m, g, h = ((g = (g = (c(m = {}, o, (function() {
                return this
            })), Object.getPrototypeOf)) && g(g(T([])))) && g !== e && n.call(g, o) && (m = g), y.prototype = b.prototype = Object.create(m));

            function O(t) {
                ["next", "throw", "return"].forEach((function(e) {
                    c(t, e, (function(t) {
                        return this._invoke(e, t)
                    }))
                }))
            }

            function v(t, e) {
                var o;
                r(this, "_invoke", {
                    value: function(r, i) {
                        function a() {
                            return new e((function(o, a) {
                                ! function r(o, i, a, c) {
                                    var s;
                                    if ("throw" !== (o = u(t[o], t, i)).type) return (i = (s = o.arg).value) && "object" == f(i) && n.call(i, "__await") ? e.resolve(i.__await).then((function(t) {
                                        r("next", t, a, c)
                                    }), (function(t) {
                                        r("throw", t, a, c)
                                    })) : e.resolve(i).then((function(t) {
                                        s.value = t, a(s)
                                    }), (function(t) {
                                        return r("throw", t, a, c)
                                    }));
                                    c(o.arg)
                                }(r, i, o, a)
                            }))
                        }
                        return o = o ? o.then(a, a) : a()
                    }
                })
            }

            function j(t) {
                var e = {
                    tryLoc: t[0]
                };
                1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e)
            }

            function S(t) {
                var e = t.completion || {};
                e.type = "normal", delete e.arg, t.completion = e
            }

            function w(t) {
                this.tryEntries = [{
                    tryLoc: "root"
                }], t.forEach(j, this), this.reset(!0)
            }

            function T(t) {
                if (t) {
                    var e, r = t[o];
                    if (r) return r.call(t);
                    if ("function" == typeof t.next) return t;
                    if (!isNaN(t.length)) return e = -1, (r = function r() {
                        for (; ++e < t.length;)
                            if (n.call(t, e)) return r.value = t[e], r.done = !1, r;
                        return r.value = void 0, r.done = !0, r
                    }).next = r
                }
                return {
                    next: E
                }
            }

            function E() {
                return {
                    value: void 0,
                    done: !0
                }
            }
            return r(h, "constructor", {
                value: p.prototype = y,
                configurable: !0
            }), r(y, "constructor", {
                value: p,
                configurable: !0
            }), p.displayName = c(y, a, "GeneratorFunction"), t.isGeneratorFunction = function(t) {
                return !!(t = "function" == typeof t && t.constructor) && (t === p || "GeneratorFunction" === (t.displayName || t.name))
            }, t.mark = function(t) {
                return Object.setPrototypeOf ? Object.setPrototypeOf(t, y) : (t.__proto__ = y, c(t, a, "GeneratorFunction")), t.prototype = Object.create(h), t
            }, t.awrap = function(t) {
                return {
                    __await: t
                }
            }, O(v.prototype), c(v.prototype, i, (function() {
                return this
            })), t.AsyncIterator = v, t.async = function(e, n, r, o, i) {
                void 0 === i && (i = Promise);
                var a = new v(s(e, n, r, o), i);
                return t.isGeneratorFunction(n) ? a : a.next().then((function(t) {
                    return t.done ? t.value : a.next()
                }))
            }, O(h), c(h, a, "Generator"), c(h, o, (function() {
                return this
            })), c(h, "toString", (function() {
                return "[object Generator]"
            })), t.keys = function(t) {
                var e, n = Object(t),
                    r = [];
                for (e in n) r.push(e);
                return r.reverse(),
                    function t() {
                        for (; r.length;) {
                            var e = r.pop();
                            if (e in n) return t.value = e, t.done = !1, t
                        }
                        return t.done = !0, t
                    }
            }, t.values = T, w.prototype = {
                constructor: w,
                reset: function(t) {
                    if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(S), !t)
                        for (var e in this) "t" === e.charAt(0) && n.call(this, e) && !isNaN(+e.slice(1)) && (this[e] = void 0)
                },
                stop: function() {
                    this.done = !0;
                    var t = this.tryEntries[0].completion;
                    if ("throw" === t.type) throw t.arg;
                    return this.rval
                },
                dispatchException: function(t) {
                    if (this.done) throw t;
                    var e = this;

                    function r(n, r) {
                        return a.type = "throw", a.arg = t, e.next = n, r && (e.method = "next", e.arg = void 0), !!r
                    }
                    for (var o = this.tryEntries.length - 1; 0 <= o; --o) {
                        var i = this.tryEntries[o],
                            a = i.completion;
                        if ("root" === i.tryLoc) return r("end");
                        if (i.tryLoc <= this.prev) {
                            var c = n.call(i, "catchLoc"),
                                s = n.call(i, "finallyLoc");
                            if (c && s) {
                                if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                            } else if (c) {
                                if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                            } else {
                                if (!s) throw new Error("try statement without catch or finally");
                                if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                            }
                        }
                    }
                },
                abrupt: function(t, e) {
                    for (var r = this.tryEntries.length - 1; 0 <= r; --r) {
                        var o = this.tryEntries[r];
                        if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) {
                            var i = o;
                            break
                        }
                    }
                    var a = (i = i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc ? null : i) ? i.completion : {};
                    return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, l) : this.complete(a)
                },
                complete: function(t, e) {
                    if ("throw" === t.type) throw t.arg;
                    return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), l
                },
                finish: function(t) {
                    for (var e = this.tryEntries.length - 1; 0 <= e; --e) {
                        var n = this.tryEntries[e];
                        if (n.finallyLoc === t) return this.complete(n.completion, n.afterLoc), S(n), l
                    }
                },
                catch: function(t) {
                    for (var e = this.tryEntries.length - 1; 0 <= e; --e) {
                        var n, r, o = this.tryEntries[e];
                        if (o.tryLoc === t) return "throw" === (n = o.completion).type && (r = n.arg, S(o)), r
                    }
                    throw new Error("illegal catch attempt")
                },
                delegateYield: function(t, e, n) {
                    return this.delegate = {
                        iterator: T(t),
                        resultName: e,
                        nextLoc: n
                    }, "next" === this.method && (this.arg = void 0), l
                }
            }, t
        }

        function b(t, e, n, r, o, i, a) {
            try {
                var c = t[i](a),
                    s = c.value
            } catch (t) {
                return void n(t)
            }
            c.done ? e(s) : Promise.resolve(s).then(r, o)
        }

        function p(t, e) {
            var n, r = Object.keys(t);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), r.push.apply(r, n)), r
        }

        function y(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? p(Object(n), !0).forEach((function(e) {
                    O(t, e, n[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : p(Object(n)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                }))
            }
            return t
        }

        function m(t, e) {
            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
        }

        function g(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, v(r.key), r)
            }
        }

        function h(t, e, n) {
            e && g(t.prototype, e), n && g(t, n), Object.defineProperty(t, "prototype", {
                writable: !1
            })
        }

        function O(t, e, n) {
            (e = v(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function v(t) {
            return t = function(t, e) {
                if ("object" !== f(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== f(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === f(t) ? t : String(t)
        }

        function j(t) {
            try {
                var e = function(t) {
                    try {
                        var e = Object(a.a)(t).read("ad/context");
                        return Object(i.i)(e) ? {
                            ortb2: e
                        } : {}
                    } catch (t) {
                        return Object(r.b)(t, "getSignals"), {}
                    }
                }(t);
                return 0 === Object.keys(e).length ? "" : Object(o.c)(e)
            } catch (t) {
                return Object(r.b)(t, "getSignalsParams"), ""
            }
        }

        function S() {
            P.get().log(E, "init");
            var t = window.apscustom || [];
            if (window.apscustom = {
                    push: _,
                    loaded: !0
                }, Array.isArray(t))
                for (; t.length;) _(t.shift())
        }
        var w = Object(u.c)("ASR_ENDPOINT_HOST", "c.aps.amazon-adsystem.com"),
            T = Object(u.c)("ASR_ENDPOINT_IS", "86355855cc6ed9e335d0382c8563aa10"),
            E = (e = function() {
                function t() {
                    m(this, t), O(this, "ignoreKeys", ["apsCustomSlotname", "apsCustomProgram"]), O(this, "programKey", "apscustom"), O(this, "dataParamPrefix", "apsCustom")
                }
                return h(t, [{
                    key: "init",
                    value: function(t) {
                        var e, n, r, o = this;
                        t && t.id && (n = document.getElementById(t.id)) && (t._element = n, e = Object.assign({}, n.dataset), n.setAttribute("data-aps-custom-status", "read"), n = {
                            program: e.apsCustomProgram || this.programKey,
                            is: T
                        }, Object.keys(e).filter((function(t) {
                            return t.indexOf(o.dataParamPrefix) <= -1 || o.ignoreKeys.includes(t)
                        })).forEach((function(t) {
                            return delete e[t]
                        })), r = {
                            slotID: t.id,
                            slotName: e.apsCustomSlotname || t.id,
                            sizes: [
                                [999, 999]
                            ]
                        }, this.fetchBidsAndRender(r, t, y(y({}, n), e)))
                    }
                }, {
                    key: "fetchBidsAndRender",
                    value: function(t, e, n) {
                        var r = this;
                        (t = (P.get().log(E, "fetchBids/start"), {
                            slots: [t],
                            params: n
                        })).timeout = null != (n = e.timeout) ? n : 6e4, t._endpointDomain = w, window.apstag.fetchBids(t, (function(t) {
                            P.get().log(E, "fetchBids/end"), r.renderBids(t, e)
                        }))
                    }
                }, {
                    key: "renderBids",
                    value: function(t, e) {
                        t.forEach((function(t) {
                            new I(e, t).render()
                        }))
                    }
                }]), t
            }(), "customPlacements"),
            D = new e;

        function _(t) {
            P.get().log(E, "implementation/legacyPush", .01), t = Object.assign({}, t), D.init(t)
        }
        var I = function() {
                function t(e, n) {
                    var r = this;
                    m(this, t), O(this, "slotProps", void 0), O(this, "rawResponse", void 0), O(this, "getPageStyles", (function() {
                        return (0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : ["p", "h1", "h2"]).map(r.getTagStyle).filter((function(t) {
                            return 0 < Object.keys(t).length
                        })).reduce((function(t, e) {
                            return y(y({}, t), e)
                        }), {})
                    })), O(this, "getContainerStyles", (function(t) {
                        try {
                            var e, n, r;
                            return t ? (e = window.getComputedStyle(t), n = "--aps-custom-container-", (r = new Map).set("".concat(n, "width"), e.width), r.set("".concat(n, "margin"), e.margin), r.set("".concat(n, "padding"), e.padding), Object.fromEntries(r.entries())) : {}
                        } catch (t) {
                            return {}
                        }
                    })), this.slotProps = e, this.rawResponse = n
                }
                return h(t, [{
                    key: "getTagStyle",
                    value: function(t) {
                        var e, n, r = document.getElementsByTagName(t);
                        return r && r[0] ? (r = window.getComputedStyle(document.getElementsByTagName(t)[0]), (e = new Map).set("".concat(n = "--aps-custom-page-").concat(t, "-color"), r.color), e.set("".concat(n).concat(t, "-fontFamily"), r.fontFamily), e.set("".concat(n).concat(t, "-fontSize"), r.fontSize), e.set("".concat(n).concat(t, "-fontWeight"), r.fontWeight), e.set("".concat(n).concat(t, "-lineHeight"), r.lineHeight), Object.fromEntries(e)) : {}
                    }
                }, {
                    key: "getDynamicFrameBodyHeight",
                    value: function(t, e, n) {
                        if (e) {
                            P.get().log(E, "render/".concat(n, "/").concat(this.slotProps.id, "/loaded"));
                            var r = (null == e ? void 0 : e.contentDocument) || (null == e || null == (o = e.contentWindow) ? void 0 : o.document),
                                o = null == r ? void 0 : r.body.scrollHeight;
                            e.style.height = "".concat(o, "px");
                            try {
                                var i = y(y({}, this.getPageStyles()), this.getContainerStyles(t));
                                Object.keys(i).forEach((function(t) {
                                    null != r && r.documentElement.style.setProperty(t, i[t])
                                })), P.get().trackEvent(E, "renderComplete", {
                                    asrEndpoint: w,
                                    height: o,
                                    source: n
                                })
                            } catch (t) {}
                        }
                    }
                }, {
                    key: "render",
                    value: function() {
                        return this._renderInIframe()
                    }
                }, {
                    key: "_renderInIframe",
                    value: function() {
                        var t = this;
                        if (!this.rawResponse || !this.slotProps) return !1;
                        try {
                            var e, n, o = this.rawResponse.size.split("x"),
                                i = (null == (e = this.rawResponse.targeting) ? void 0 : e.amzniid) || this.rawResponse.amzniid,
                                a = (null == (n = this.rawResponse.targeting) ? void 0 : n.amznadm) || this.rawResponse.amznadm;
                            if (!i) return !1;
                            P.get().log(E, "render/".concat(this.slotProps.id, "/start"));
                            var c, s, u, l, f = this.slotProps._element;
                            return this.slotProps.location && this.slotProps.id && (s = document.createElement("div"), null != (c = document.getElementById(this.slotProps.id)) && c.insertAdjacentElement(this.slotProps.location, s), f = s), !!f && ((u = document.createElement("iframe")).style.marginLeft = "0", u.style.marginTop = "0", u.style.height = "".concat(o[1], "px"), u.style.width = "100%", u.setAttribute("scrolling", "no"), u.setAttribute("frameborder", "0"), u.onload = function() {
                                return t.getDynamicFrameBodyHeight(f, u, a ? "amznadm" : "admi")
                            }, l = '\n      <!DOCTYPE html>\n      <html>\n        <head>\n          <meta charset="UTF-8">\n          <style>html{height:100%}body{height:100%;margin:0;overflow:hidden}</style>\n        </head>\n        <body>\n          <script>\n            window.parent.apstag.renderImp(document, "'.concat(i, '", {"inheritSize": true});\n          <\/script>\n        </body>\n      </html>'), u.srcdoc = a || l, f.appendChild(u), this.updateSlotAttribute("status", "rendered"), !0)
                        } catch (t) {
                            return Object(r.b)(new Error("Error while rendering"), "CustomPlacements"), !1
                        }
                    }
                }, {
                    key: "updateSlotAttribute",
                    value: function(t, e) {
                        var n;
                        null != (n = this.slotProps._element) && n.setAttribute("data-aps-custom-".concat(t), e)
                    }
                }]), t
            }(),
            P = function() {
                function t() {
                    var e = this,
                        n = (m(this, t), O(this, "TAHOE_PROD", "04a6c6a40ec6c493437745b4ff085efb826e05c276ad857733462915bc4c35e0"), O(this, "TAHOE_PROD_URL", "https://prod.tahoe-analytics.publishers.advertising.a2z.com/logevent/postEquinoxEvent"), O(this, "level", Object(u.c)("APS_ANALYTICS_LEVEL", "TAHOE")), O(this, "config", void 0), O(this, "timings", void 0), O(this, "log", void 0), O(this, "setLevel", (function(t) {
                            e.level = t
                        })), O(this, "trackEvent", function() {
                            n = d().mark((function n(r, o) {
                                var i, a, u = arguments;
                                return d().wrap((function(n) {
                                    for (;;) switch (n.prev = n.next) {
                                        case 0:
                                            return i = 2 < u.length && void 0 !== u[2] ? u[2] : {}, a = 3 < u.length && void 0 !== u[3] ? u[3] : t.getDefaultSamplingRate(), n.abrupt("return", new Promise((function(t) {
                                                try {
                                                    var n, u;
                                                    Math.random() > a ? t(!1) : (n = y({
                                                        url: decodeURIComponent(Object(s.f)(window)),
                                                        libraryVersion: c.l,
                                                        timings: e.timings
                                                    }, e.getBrowserInfo()), u = JSON.stringify({
                                                        eventSource: "apstag",
                                                        eventCategory: r,
                                                        eventName: o,
                                                        eventTime: String(Date.now()),
                                                        eventProperties: y(y(y({}, e.config), n), i)
                                                    }), "DEBUG" === e.level && console.info("<analytics> ", JSON.parse(u)), "TAHOE" === e.level && fetch(e.TAHOE_PROD_URL, {
                                                        method: "POST",
                                                        headers: {
                                                            "Content-Type": "application/json",
                                                            "x-api-key": e.TAHOE_PROD
                                                        },
                                                        body: JSON.stringify({
                                                            Data: window.btoa(u),
                                                            PartitionKey: String(Date.now())
                                                        })
                                                    }), t(!0))
                                                } catch (n) {
                                                    t(!1)
                                                }
                                            })));
                                        case 3:
                                        case "end":
                                            return n.stop()
                                    }
                                }), n)
                            }));
                            var n, r = function() {
                                var t = this,
                                    e = arguments;
                                return new Promise((function(r, o) {
                                    var i = n.apply(t, e);

                                    function a(t) {
                                        b(i, r, o, a, c, "next", t)
                                    }

                                    function c(t) {
                                        b(i, r, o, a, c, "throw", t)
                                    }
                                    a(void 0)
                                }))
                            };
                            return function(t, e) {
                                return r.apply(this, arguments)
                            }
                        }()), l.a.getState());
                    this.config = n.config, this.timings = [], this.log = function(t, n, r) {
                        try {
                            e.timings.push({
                                time: performance.now(),
                                key: "".concat(t, "/").concat(n)
                            }), r && e.trackEvent(t, n, {}, r)
                        } catch (t) {}
                    }
                }
                return h(t, [{
                    key: "getBrowserInfo",
                    value: function() {
                        try {
                            var t, e = navigator.connection;
                            return {
                                connection: {
                                    effectiveType: null == e ? void 0 : e.effectiveType,
                                    rtt: null == e ? void 0 : e.rtt,
                                    downlink: null == e ? void 0 : e.downlink
                                },
                                screen: Object(i.f)(window),
                                userAgent: null == (t = navigator) ? void 0 : t.userAgent
                            }
                        } catch (t) {
                            return {}
                        }
                    }
                }], [{
                    key: "get",
                    value: function() {
                        return null === this._analytics && (this._analytics = new t), this._analytics
                    }
                }]), t
            }();
        O(P, "_analytics", null), O(P, "getDefaultSamplingRate", (function() {
            var t = Object(u.c)("APS_ANALYTICS_RATE", .1);
            try {
                return Number(t)
            } catch (t) {
                return .1
            }
        }))
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return L
        }));
        var r = n(13),
            o = n(0),
            i = n(1),
            a = (e = n(14), n(4));

        function c(t) {
            return (c = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function s(t, e) {
            var n, r = Object.keys(t);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), r.push.apply(r, n)), r
        }

        function u(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? s(Object(n), !0).forEach((function(e) {
                    m(t, e, n[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                }))
            }
            return t
        }

        function l(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, g(r.key), r)
            }
        }

        function f() {
            return (f = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function(t, e, n) {
                var r = function(t, e) {
                    for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = y(t)););
                    return t
                }(t, e);
                if (r) return (r = Object.getOwnPropertyDescriptor(r, e)).get ? r.get.call(arguments.length < 3 ? t : n) : r.value
            }).apply(this, arguments)
        }

        function d(t, e) {
            return (d = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                return t.__proto__ = e, t
            })(t, e)
        }

        function b(t) {
            var e = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (t) {
                    return !1
                }
            }();
            return function() {
                var n, r = y(t);
                n = e ? (n = y(this).constructor, Reflect.construct(r, arguments, n)) : r.apply(this, arguments), r = this;
                if (n && ("object" === c(n) || "function" == typeof n)) return n;
                if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                return p(r)
            }
        }

        function p(t) {
            if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return t
        }

        function y(t) {
            return (y = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
                return t.__proto__ || Object.getPrototypeOf(t)
            })(t)
        }

        function m(t, e, n) {
            (e = g(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function g(t) {
            return t = function(t, e) {
                if ("object" !== c(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== c(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === c(t) ? t : String(t)
        }
        var h = function(t) {
            var e = r;
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t && d(e, t);
            var n = b(r);

            function r(t) {
                var e;
                if (this instanceof r) return e = {
                    slotID: t.targetId,
                    slotName: Object(o.j)(t, "invCode") ? t.invCode : Object(o.j)(t, "tagId") ? t.tagId : t.targetId
                }, m(p(e = n.call(this, e)), "rawSlot", void 0), e.rawSlot = t, e;
                throw new TypeError("Cannot call a class as a function")
            }
            return e = r, (t = [{
                key: "mediaType",
                get: function() {
                    return a.a.DISPLAY
                }
            }, {
                key: "sizes",
                get: function() {
                    try {
                        return this.rawSlot.sizes
                    } catch (t) {
                        return this.reportError(t, "sizes"), []
                    }
                }
            }, {
                key: "aaxSlot",
                get: function() {
                    try {
                        var t = u(u({}, f(y(r.prototype), "aaxSlot", this)), {}, {
                            sd: this.slotID,
                            s: this.sizes.filter(o.h).map((function(t) {
                                return t.join("x")
                            }))
                        });
                        return this.slotID !== this.slotName && (t.sn = this.slotName), t
                    } catch (t) {
                        return {
                            sd: "",
                            s: [],
                            kv: {}
                        }
                    }
                }
            }, {
                key: "reportError",
                value: function(t, e, n) {
                    Object(i.b)(t, "ApnSlot-".concat(e), n)
                }
            }, {
                key: "isValid",
                value: function() {
                    return !(!f(y(r.prototype), "isValid", this).call(this) || 0 === this.sizes.length && (this.reportIsValidMessages(["'sizes' must have at least 1 valid item"], !0), 1))
                }
            }, {
                key: "initKeywords",
                value: function() {
                    try {
                        Object(o.j)(this.rawSlot, "keywords") || (this.rawSlot.keywords = {})
                    } catch (t) {
                        this.reportError(t, "initKeywords")
                    }
                }
            }, {
                key: "setTargeting",
                value: function(t, e) {
                    try {
                        this.initKeywords(), this.rawSlot.keywords[t] = e
                    } catch (t) {
                        this.reportError(t, "setTargeting")
                    }
                }
            }, {
                key: "getTargeting",
                value: function(t) {
                    try {
                        return this.initKeywords(), Object(o.j)(this.rawSlot.keywords, t) ? [this.rawSlot.keywords[t]] : []
                    } catch (t) {
                        return this.reportError(t, "getTargeting"), []
                    }
                }
            }, {
                key: "clearTargeting",
                value: function(t) {
                    try {
                        this.initKeywords(), delete this.rawSlot.keywords[t]
                    } catch (t) {
                        this.reportError(t, "clearTargeting")
                    }
                }
            }]) && l(e.prototype, t), Object.defineProperty(e, "prototype", {
                writable: !1
            }), r
        }(e.a);

        function O(t) {
            return (O = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function v(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, T(r.key), r)
            }
        }

        function j(t, e) {
            return (j = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                return t.__proto__ = e, t
            })(t, e)
        }

        function S(t) {
            if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return t
        }

        function w(t) {
            return (w = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
                return t.__proto__ || Object.getPrototypeOf(t)
            })(t)
        }

        function T(t) {
            return t = function(t, e) {
                if ("object" !== O(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== O(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === O(t) ? t : String(t)
        }
        var E = function(t) {
                var e = r;
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                e.prototype = Object.create(t && t.prototype, {
                    constructor: {
                        value: e,
                        writable: !0,
                        configurable: !0
                    }
                }), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t && j(e, t);
                var n = function(t) {
                    var e = function() {
                        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                        if (Reflect.construct.sham) return !1;
                        if ("function" == typeof Proxy) return !0;
                        try {
                            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                        } catch (t) {
                            return !1
                        }
                    }();
                    return function() {
                        var n, r = w(t);
                        n = e ? (n = w(this).constructor, Reflect.construct(r, arguments, n)) : r.apply(this, arguments), r = this;
                        if (n && ("object" === O(n) || "function" == typeof n)) return n;
                        if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                        return S(r)
                    }
                }(r);

                function r() {
                    var t = this,
                        e = r;
                    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
                    for (var o, i, a = arguments.length, c = new Array(a), s = 0; s < a; s++) c[s] = arguments[s];
                    return e = S(t = n.call.apply(n, [this].concat(c))), i = !0, (o = T(o = "isSupported")) in e ? Object.defineProperty(e, o, {
                        value: i,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[o] = i, t
                }
                return e = r, (t = [{
                    key: "reportError",
                    value: function(t, e) {
                        Object(i.b)(t, "AppNexusAdServer-".concat(e))
                    }
                }, {
                    key: "cmdQueuePush",
                    value: function(t) {
                        try {
                            window.apntag.anq.push(t)
                        } catch (t) {
                            this.reportError(t, "cmdQueuePush")
                        }
                    }
                }, {
                    key: "setTargeting",
                    value: function(t, e) {
                        try {
                            Object(o.j)(window, "apntag") && Object(o.j)(window.apntag, "requests") && (Object(o.j)(window.apntag.requests, "keywords") || (window.apntag.requests.keywords = {}), window.apntag.requests.keywords[t] = e)
                        } catch (t) {
                            this.reportError(t, "setTargeting")
                        }
                    }
                }, {
                    key: "getTargeting",
                    value: function(t) {
                        try {
                            if (!Object(o.j)(window, "apntag") || !Object(o.j)(window.apntag, "requests")) return [];
                            Object(o.j)(window.apntag.requests, "keywords") || (window.apntag.requests.keywords = {});
                            var e = window.apntag.requests.keywords[t];
                            return void 0 === e ? [] : [e]
                        } catch (t) {
                            return this.reportError(t, "getTargeting"), []
                        }
                    }
                }, {
                    key: "clearTargeting",
                    value: function(t) {
                        try {
                            Object(o.j)(window, "apntag") && Object(o.j)(window.apntag, "requests") && Object(o.j)(window.apntag.requests, "keywords") && delete window.apntag.requests.keywords[t]
                        } catch (t) {
                            this.reportError(t, "clearTargeting")
                        }
                    }
                }, {
                    key: "hasAdServerObjectLoaded",
                    value: function() {
                        try {
                            return Object(o.j)(window, "apntag") && Object(o.j)(window.apntag, "loaded") && !0 === window.apntag.loaded
                        } catch (t) {
                            return this.reportError(t, "hasAdServerObjectLoaded"), !1
                        }
                    }
                }, {
                    key: "isCommandQueueDefined",
                    value: function() {
                        try {
                            return Object(o.j)(window, "apntag") && Object(o.j)(window.apntag, "anq")
                        } catch (t) {
                            return this.reportError(t, "isCommandQueueDefined"), !1
                        }
                    }
                }, {
                    key: "getSlots",
                    value: function() {
                        try {
                            var t = [];
                            return Object(o.j)(window, "apntag") && Object(o.j)(window.apntag, "requests") && Object(o.j)(window.apntag.requests, "tags") && Object(o.i)(window.apntag.requests.tags) && Object.keys(window.apntag.requests.tags).forEach((function(e) {
                                e = window.apntag.requests.tags[e], t.push(new h(e))
                            })), t
                        } catch (t) {
                            return this.reportError(t, "getSlots"), []
                        }
                    }
                }]) && v(e.prototype, t), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), r
            }(r.a),
            D = n(26);

        function _(t) {
            return (_ = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function I(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, z(r.key), r)
            }
        }

        function P(t, e) {
            return (P = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                return t.__proto__ = e, t
            })(t, e)
        }

        function A(t) {
            if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return t
        }

        function C(t) {
            return (C = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
                return t.__proto__ || Object.getPrototypeOf(t)
            })(t)
        }

        function k(t, e, n) {
            (e = z(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function z(t) {
            return t = function(t, e) {
                if ("object" !== _(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== _(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === _(t) ? t : String(t)
        }
        var R = function(t) {
            var e = r;
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t && P(e, t);
            var n = function(t) {
                var e = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (t) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = C(t);
                    n = e ? (n = C(this).constructor, Reflect.construct(r, arguments, n)) : r.apply(this, arguments), r = this;
                    if (n && ("object" === _(n) || "function" == typeof n)) return n;
                    if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                    return A(r)
                }
            }(r);

            function r() {
                var t = this,
                    e = r;
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
                for (var o = arguments.length, i = new Array(o), a = 0; a < o; a++) i[a] = arguments[a];
                return k(A(t = n.call.apply(n, [this].concat(i))), "isSupported", !0), k(A(t), "needNewBidObject", !0), t
            }
            return e = r, (t = [{
                key: "reportError",
                value: function(t, e) {
                    Object(i.b)(t, "SmartAdServer-".concat(e))
                }
            }, {
                key: "cmdQueuePush",
                value: function(t) {
                    try {
                        window.sas.cmd.push(t)
                    } catch (t) {
                        this.reportError(t, "cmdQueuePush")
                    }
                }
            }, {
                key: "hasAdServerObjectLoaded",
                value: function() {
                    try {
                        return Object(o.j)(window, "sas") && Object(o.j)(window.sas, "__smartLoaded") && !0 === window.sas.__smartLoaded
                    } catch (t) {
                        return this.reportError(t, "hasAdServerObjectLoaded"), !1
                    }
                }
            }, {
                key: "isCommandQueueDefined",
                value: function() {
                    try {
                        return Object(o.j)(window, "sas") && Object(o.j)(window.sas, "cmd")
                    } catch (t) {
                        return this.reportError(t, "isCommandQueueDefined"), !1
                    }
                }
            }]) && I(e.prototype, t), Object.defineProperty(e, "prototype", {
                writable: !1
            }), r
        }(r.a);

        function L(t) {
            var e = new r.a;
            try {
                switch (t) {
                    case "appnexus":
                        e = new E;
                        break;
                    case "googletag":
                        e = new D.a;
                        break;
                    case "sas":
                        e = new R
                }
            } catch (t) {
                Object(i.b)(t, "getDisplayAdServer")
            }
            return e
        }
    }, function(t, e, n) {
        "use strict";

        function r(t, e) {
            try {
                var n = o(t, e)[0];
                if (void 0 !== n) return n
            } catch (t) {}
            return null
        }

        function o(t, e) {
            try {
                return t.performance.getEntriesByType("resource").filter((function(t) {
                    return e.test(t.name)
                }))
            } catch (t) {
                return []
            }
        }
        n.d(e, "b", (function() {
            return r
        })), n.d(e, "a", (function() {
            return o
        }))
    }, function(t, e, n) {
        "use strict";
        n.d(e, "b", (function() {
            return a
        })), n.d(e, "a", (function() {
            return c
        }));
        var r = n(3),
            o = n(0),
            i = n(1);

        function a(t) {
            try {
                return Object(o.j)(t, "debug")
            } catch (t) {
                return Object(i.b)(t, "isApstagLibrary"), !1
            }
        }

        function c(t) {
            try {
                return !!Object(o.j)(t, r.a) && !0 === t[r.a]
            } catch (t) {
                return Object(i.b)(t, "hasApstagJsLoaded"), !1
            }
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return y
        }));
        e = n(14);
        var r = n(21);

        function o(t) {
            return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function i(t, e) {
            var n, r = Object.keys(t);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), r.push.apply(r, n)), r
        }

        function a(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? i(Object(n), !0).forEach((function(e) {
                    b(t, e, n[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                }))
            }
            return t
        }

        function c(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, p(r.key), r)
            }
        }

        function s() {
            return (s = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function(t, e, n) {
                var r = function(t, e) {
                    for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = d(t)););
                    return t
                }(t, e);
                if (r) return (r = Object.getOwnPropertyDescriptor(r, e)).get ? r.get.call(arguments.length < 3 ? t : n) : r.value
            }).apply(this, arguments)
        }

        function u(t, e) {
            return (u = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                return t.__proto__ = e, t
            })(t, e)
        }

        function l(t) {
            var e = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (t) {
                    return !1
                }
            }();
            return function() {
                var n, r = d(t);
                n = e ? (n = d(this).constructor, Reflect.construct(r, arguments, n)) : r.apply(this, arguments), r = this;
                if (n && ("object" === o(n) || "function" == typeof n)) return n;
                if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                return f(r)
            }
        }

        function f(t) {
            if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return t
        }

        function d(t) {
            return (d = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
                return t.__proto__ || Object.getPrototypeOf(t)
            })(t)
        }

        function b(t, e, n) {
            (e = p(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function p(t) {
            return t = function(t, e) {
                if ("object" !== o(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== o(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === o(t) ? t : String(t)
        }
        var y = function(t) {
            var e = o;
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t && u(e, t);
            var n = l(o);

            function o(t) {
                if (this instanceof o) return b(f(t = n.call(this, t)), "_sizesDelegate", void 0), t._sizesDelegate = new r.a(t.rawSlot.sizes), t;
                throw new TypeError("Cannot call a class as a function")
            }
            return e = o, (t = [{
                key: "sizes",
                get: function() {
                    return this._sizesDelegate.sizes
                }
            }, {
                key: "aaxSizes",
                get: function() {
                    return this._sizesDelegate.aaxSizes || []
                }
            }, {
                key: "aaxSlot",
                get: function() {
                    var t = {
                        sd: this.slotID,
                        s: this.aaxSizes
                    };
                    return this.slotID !== this.slotName && (t.sn = this.slotName), a(a({}, t), s(d(o.prototype), "aaxSlot", this))
                }
            }, {
                key: "isValid",
                value: function() {
                    return !(!s(d(o.prototype), "isValid", this).call(this) || 0 === this.sizes.length && (this.reportIsValidMessages(["'sizes' must have at least 1 valid item"], !0), 1))
                }
            }]) && c(e.prototype, t), Object.defineProperty(e, "prototype", {
                writable: !1
            }), o
        }(e.a)
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return s
        })), n.d(e, "b", (function() {
            return c
        }));
        var r = n(2),
            o = n(1),
            i = n(0),
            a = n(8);

        function c(t) {
            try {
                var e = r.a.getState().cfg.COOKIE_MATCH_DELAY;
                setTimeout((function() {
                    try {
                        if (Object(i.j)(t, "cmp")) {
                            var e = t.cmp;

                            function n(t) {
                                try {
                                    var e;
                                    r.a.getState().cmpFired || (r.a.dispatch({
                                        type: "CMP_FIRED"
                                    }), (e = document.createElement("iframe")).style.display = "none", e.src = t, document.body.appendChild(e))
                                } catch (t) {
                                    Object(o.b)(t, "_doCookieMatch-ready")
                                }
                            }
                            try {
                                "loading" === document.readyState ? document.addEventListener && document.addEventListener("DOMContentLoaded", (function() {
                                    n(e)
                                }), !1) : n(e)
                            } catch (e) {
                                Object(o.b)(e, "_doCookieMatch")
                            }
                        } else Object(i.j)(t, "cmpjs") && Object(a.b)(t.cmpjs)
                    } catch (e) {
                        Object(o.b)(e, "_tryCookieMatch-setTimeout")
                    }
                }), e)
            } catch (e) {
                Object(o.b)(e, "_tryCookieMatch")
            }
        }

        function s(t, e) {
            var n = e;
            return function() {
                var e = {
                    method: t,
                    args: arguments
                };
                try {
                    e.ts = Date.now(), r.a.dispatch({
                        type: "LOG_EVENT",
                        event: e
                    })
                } catch (e) {
                    Object(o.b)(e, "_logEvent")
                }
                return n.apply(void 0, arguments)
            }
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return c
        }));
        var r = n(2),
            o = n(1),
            i = n(6),
            a = n(3);

        function c(t, e, n) {
            try {
                var c, s = r.a.getState(),
                    u = s.config,
                    l = Object(i.c)("host", s.hosts.DEFAULT_CXM_HOST),
                    f = s.cfg.LIB_CONFIG_PATH;
                try {
                    if (0 <= ["http:", "https:"].indexOf(t.protocol)) c = t.protocol + "//" + t.hostname;
                    else {
                        if (!(0 <= ["http:", "https:"].indexOf(e.protocol))) return null;
                        c = e.protocol + "//" + e.hostname
                    }
                } catch (t) {
                    if (t instanceof window.DOMException) return null;
                    throw t
                }
                var d, b = (b = null == n ? void 0 : n.sourceID) || (u.isSelfServePub ? a.s : u.pubID),
                    p = null == n ? void 0 : n.publisherUUID,
                    y = (p || u.isSelfServePub && (p = u.pubID), {
                        src: b,
                        u: encodeURIComponent(c)
                    });
                return p && (y.pubid = p), !y.src || isNaN(Number(y.src)) ? null : (d = Object.keys(y).map((function(t) {
                    return "".concat(t.trim(), "=").concat(String(y[t]).trim())
                })).join("&"), "".concat(a.v).concat(l).concat(f, "?").concat(d))
            } catch (t) {
                return Object(o.b)(t, "buildLibraryConfigUrl"), null
            }
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return o
        }));
        var r = n(0);

        function o(t, e) {
            var n, o, i;
            Object(r.i)(e.data) && (Object(r.j)(e.data, "bidInfo") && (Object(r.j)(e.data.bidInfo, "src") ? (n = e.data.bidInfo.src, n = new URL(n).searchParams.get("b")) : Object(r.j)(e.data.bidInfo, "jsonp") && (i = e.data.bidInfo.jsonp, n = JSON.parse(i.substr(17, i.length - 20)).amzniid)), Object(r.j)(e.data, "renderData")) && (e = (i = e.data.renderData).id, Object(r.j)(i, "renderStart") || Object(r.j)(i, "renderEnd")) && (o = i.renderStart, i = i.renderEnd, o ? (t.renderTimes[e] = {
                timeStamp: o
            }, n && (t.renderTimes[e].bidId = n)) : i && Object(r.j)(t.renderTimes, e) && 0 !== t.renderTimes[e].timeStamp && t.renderTimes[e].bidId && t.renderTimes[e].bidId)
        }
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return g
        }));
        e = n(14);
        var r = n(21),
            o = n(4),
            i = n(18);

        function a(t) {
            return (a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function c(t, e) {
            var n, r = Object.keys(t);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), r.push.apply(r, n)), r
        }

        function s(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? c(Object(n), !0).forEach((function(e) {
                    y(t, e, n[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                }))
            }
            return t
        }

        function u(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, m(r.key), r)
            }
        }

        function l() {
            return (l = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function(t, e, n) {
                var r = function(t, e) {
                    for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = p(t)););
                    return t
                }(t, e);
                if (r) return (r = Object.getOwnPropertyDescriptor(r, e)).get ? r.get.call(arguments.length < 3 ? t : n) : r.value
            }).apply(this, arguments)
        }

        function f(t, e) {
            return (f = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                return t.__proto__ = e, t
            })(t, e)
        }

        function d(t) {
            var e = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (t) {
                    return !1
                }
            }();
            return function() {
                var n, r = p(t);
                n = e ? (n = p(this).constructor, Reflect.construct(r, arguments, n)) : r.apply(this, arguments), r = this;
                if (n && ("object" === a(n) || "function" == typeof n)) return n;
                if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                return b(r)
            }
        }

        function b(t) {
            if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return t
        }

        function p(t) {
            return (p = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
                return t.__proto__ || Object.getPrototypeOf(t)
            })(t)
        }

        function y(t, e, n) {
            (e = m(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function m(t) {
            return t = function(t, e) {
                if ("object" !== a(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== a(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === a(t) ? t : String(t)
        }
        var g = function(t) {
            var e = a;
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t && f(e, t);
            var n = d(a);

            function a(t) {
                if (this instanceof a) return y(b(t = n.call(this, t)), "_sizesDelegate", void 0), t._sizesDelegate = new r.a(t.rawSlot.sizes), t;
                throw new TypeError("Cannot call a class as a function")
            }
            return e = a, (t = [{
                key: "mediaType",
                get: function() {
                    return o.a.VIDEO
                }
            }, {
                key: "aaxMediaType",
                get: function() {
                    return i.a.VIDEO
                }
            }, {
                key: "sizes",
                get: function() {
                    return this._sizesDelegate.sizes
                }
            }, {
                key: "aaxSizes",
                get: function() {
                    return this._sizesDelegate.aaxSizes || []
                }
            }, {
                key: "aaxSlot",
                get: function() {
                    var t = s(s({}, l(p(a.prototype), "aaxSlot", this)), {}, {
                        id: this.slotID,
                        mt: this.aaxMediaType
                    });
                    return 0 < this.sizes.length && (t.s = this.aaxSizes), t
                }
            }]) && u(e.prototype, t), Object.defineProperty(e, "prototype", {
                writable: !1
            }), a
        }(e.a)
    }, function(t, e, n) {
        "use strict";

        function r(t) {
            var e = new Image;
            return e.src = t, e
        }
        n.d(e, "a", (function() {
            return r
        }))
    }, function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return I
        }));
        e = n(14);
        var r = n(4),
            o = n(18),
            i = n(0),
            a = n(1),
            c = n(21);

        function s(t) {
            return (s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function u(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, f(r.key), r)
            }
        }

        function l(t, e, n) {
            (e = f(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function f(t) {
            return t = function(t, e) {
                if ("object" !== s(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== s(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === s(t) ? t : String(t)
        }
        var d = function() {
            function t() {
                var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {},
                    n = this,
                    r = t;
                if (!(n instanceof r)) throw new TypeError("Cannot call a class as a function");
                l(this, "_propertyConfig", void 0), l(this, "_sizesDelegate", void 0), this._propertyConfig = e, this._sizesDelegate = new c.a(null == e ? void 0 : e.sizes, !1, !0)
            }
            var e, n;
            return e = t, (n = [{
                key: "sizes",
                get: function() {
                    return this._sizesDelegate.sizes
                }
            }, {
                key: "validSizes",
                get: function() {
                    return this._sizesDelegate.isValid()
                }
            }, {
                key: "propertyConfig",
                get: function() {
                    return this._propertyConfig
                }
            }, {
                key: "aaxPropertyConfig",
                get: function() {
                    var t = {};
                    return this.aaxSizes && (t.s = this.aaxSizes), t
                }
            }, {
                key: "aaxSizes",
                get: function() {
                    return this._sizesDelegate.aaxSizes
                }
            }, {
                key: "isValid",
                value: function() {
                    return !Object(i.i)(this.propertyConfig) || Array.isArray(this.propertyConfig) ? (Object(a.b)({
                        name: "MultiFormatSlot-InvalidMultiFormatSlotProperty",
                        message: "multiFormatProperty must be an object"
                    }, "MultiFormatSlotProperty-isValid", {
                        makeVisibleToAllUsers: !0
                    }), !1) : !!this.validSizes
                }
            }]) && u(e.prototype, n), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t
        }();

        function b(t) {
            return (b = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function p(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, m(r.key), r)
            }
        }

        function y(t, e, n) {
            (e = m(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function m(t) {
            return t = function(t, e) {
                if ("object" !== b(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== b(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === b(t) ? t : String(t)
        }
        var g = function() {
            function t(e) {
                var n = this;
                if (!(this instanceof t)) throw new TypeError("Cannot call a class as a function");
                y(this, "_multiFormatProperties", void 0), e && Object(i.i)(e) && !Array.isArray(e) && (this._multiFormatProperties = {}, this.toMultiFormatMediaTypes(e).forEach((function(t) {
                    n._multiFormatProperties && (n._multiFormatProperties[t] = new d(e[t]))
                })))
            }
            var e, n;
            return e = t, (n = [{
                key: "convertMultiFormatMediaType",
                value: function(t) {
                    var e;
                    return y(e = {}, r.a.VIDEO, o.a.VIDEO), y(e, r.a.DISPLAY, o.a.DISPLAY), e[t]
                }
            }, {
                key: "isMultiFormatMediaType",
                value: function(t) {
                    return Boolean(this.convertMultiFormatMediaType(t))
                }
            }, {
                key: "toMultiFormatMediaTypes",
                value: function(t) {
                    var e = this;
                    return Object.keys(t).filter((function(t) {
                        return e.isMultiFormatMediaType(t)
                    }))
                }
            }, {
                key: "multiFormatMediaTypes",
                get: function() {
                    return this._multiFormatProperties ? this.toMultiFormatMediaTypes(this._multiFormatProperties) : []
                }
            }, {
                key: "aaxMultiFormatProperties",
                get: function() {
                    var t, e = this;
                    return this._multiFormatProperties ? (t = {}, this.multiFormatMediaTypes.forEach((function(n) {
                        var r = e.convertMultiFormatMediaType(n);
                        r && (t[r] = null == (r = e._multiFormatProperties[n]) ? void 0 : r.aaxPropertyConfig)
                    })), t) : {}
                }
            }, {
                key: "isValid",
                value: function() {
                    var t = this,
                        e = !0;
                    return this._multiFormatProperties ? (this.multiFormatMediaTypes.forEach((function(n) {
                        t._multiFormatProperties[n].isValid() || (e = !1)
                    })), e) : (Object(a.b)({
                        name: "MultiFormatSlot-InvalidMultiFormatProperties",
                        message: "multiFormatProperties must be an object"
                    }, "MultiFormatProperties-isValid", {
                        makeVisibleToAllUsers: !0
                    }), !1)
                }
            }]) && p(e.prototype, n), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t
        }();

        function h(t) {
            return (h = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            })(t)
        }

        function O(t, e) {
            var n, r = Object.keys(t);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), r.push.apply(r, n)), r
        }

        function v(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? O(Object(n), !0).forEach((function(e) {
                    D(t, e, n[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : O(Object(n)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                }))
            }
            return t
        }

        function j(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, _(r.key), r)
            }
        }

        function S() {
            return (S = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function(t, e, n) {
                var r = function(t, e) {
                    for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = E(t)););
                    return t
                }(t, e);
                if (r) return (r = Object.getOwnPropertyDescriptor(r, e)).get ? r.get.call(arguments.length < 3 ? t : n) : r.value
            }).apply(this, arguments)
        }

        function w(t, e) {
            return (w = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                return t.__proto__ = e, t
            })(t, e)
        }

        function T(t) {
            if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return t
        }

        function E(t) {
            return (E = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
                return t.__proto__ || Object.getPrototypeOf(t)
            })(t)
        }

        function D(t, e, n) {
            (e = _(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n
        }

        function _(t) {
            return t = function(t, e) {
                if ("object" !== h(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== h(n = n.call(t, e))) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }(t, "string"), "symbol" === h(t) ? t : String(t)
        }
        var I = function(t) {
            var e = i;
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t && w(e, t);
            var n = function(t) {
                var e = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (t) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = E(t);
                    n = e ? (n = E(this).constructor, Reflect.construct(r, arguments, n)) : r.apply(this, arguments), r = this;
                    if (n && ("object" === h(n) || "function" == typeof n)) return n;
                    if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                    return T(r)
                }
            }(i);

            function i(t) {
                var e;
                if (this instanceof i) return D(T(e = n.call(this, t)), "_multiFormatPropertiesDelegate", void 0), e._multiFormatPropertiesDelegate = new g(t.multiFormatProperties), e;
                throw new TypeError("Cannot call a class as a function")
            }
            return e = i, (t = [{
                key: "mediaType",
                get: function() {
                    return r.a.MULTI_FORMAT
                }
            }, {
                key: "aaxMediaType",
                get: function() {
                    return o.a.MULTI_FORMAT
                }
            }, {
                key: "aaxMultiFormatProperties",
                get: function() {
                    return this._multiFormatPropertiesDelegate.aaxMultiFormatProperties
                }
            }, {
                key: "multiFormatPropertiesIsValid",
                get: function() {
                    return this._multiFormatPropertiesDelegate.isValid()
                }
            }, {
                key: "aaxSlot",
                get: function() {
                    return v(v({}, S(E(i.prototype), "aaxSlot", this)), {}, {
                        id: this.slotID,
                        sd: this.slotID,
                        sn: this.slotName || this.slotID,
                        mt: this.aaxMediaType,
                        mfp: this.aaxMultiFormatProperties
                    })
                }
            }, {
                key: "isValid",
                value: function() {
                    return S(E(i.prototype), "isValid", this).call(this) && this.multiFormatPropertiesIsValid
                }
            }]) && j(e.prototype, t), Object.defineProperty(e, "prototype", {
                writable: !1
            }), i
        }(e.a)
    }, function(t, e, n) {
        t.exports = n(15)
    }]);
}();
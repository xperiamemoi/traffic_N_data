! function() {
    try {
        var t = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            e = (new t.Error).stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "2a950a89-6f0f-46e9-afe6-0f29ed1ba634", t._sentryDebugIdIdentifier = "sentry-dbid-2a950a89-6f0f-46e9-afe6-0f29ed1ba634")
    } catch (t) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3535], {
        43216: function(t, e, r) {
            "use strict";
            r.d(e, {
                Z: function() {
                    return y
                }
            });
            var a = {};
            r.r(a), r.d(a, {
                daDK: function() {
                    return l
                },
                deAT: function() {
                    return o
                },
                deCH: function() {
                    return u
                },
                deDE: function() {
                    return c
                },
                enCA: function() {
                    return g
                },
                enGB: function() {
                    return d
                },
                enIE: function() {
                    return p
                },
                enNZ: function() {
                    return v
                },
                enUS: function() {
                    return h
                },
                esES: function() {
                    return w
                },
                fiFI: function() {
                    return f
                },
                frBE: function() {
                    return x
                },
                frFR: function() {
                    return x
                },
                itIT: function() {
                    return m
                },
                jaJP: function() {
                    return R
                },
                nbNO: function() {
                    return b
                },
                nlBE: function() {
                    return I
                },
                nlNL: function() {
                    return A
                },
                plPL: function() {
                    return G
                },
                ptBR: function() {
                    return N
                },
                ptPT: function() {
                    return T
                },
                ruRU: function() {
                    return Z
                },
                svSE: function() {
                    return V
                }
            });
            var n = r(85893),
                s = r(36408);
            let i = {
                xs: "84px",
                s: "108px",
                m: "128px",
                l: "216px",
                responsive: "100%"
            };
            var l = {
                    "star-rating/alt-text/product": "Gennemsnitlig stjernebed\xf8mmelse [RATING] ud af 5 stjerner",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] ud af 5",
                    "star-rating/alt-text/review": "Bed\xf8mt til [RATING] ud af 5 stjerner"
                },
                o = {
                    "star-rating/alt-text/product": "Durchschnittliche Sternebewertung [RATING] von 5 Sternen",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] von 5",
                    "star-rating/alt-text/review": "Bewertet mit [RATING] von 5 Sternen"
                },
                u = {
                    "star-rating/alt-text/product": "Durchschnittliche Sternebewertung [RATING] von 5 Sternen",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] von 5",
                    "star-rating/alt-text/review": "Bewertet mit [RATING] von 5 Sternen"
                },
                c = {
                    "star-rating/alt-text/product": "Durchschnittliche Sternebewertung [RATING] von 5 Sternen",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] von 5",
                    "star-rating/alt-text/review": "Bewertet mit [RATING] von 5 Sternen"
                },
                g = {
                    "star-rating/alt-text/product": "Average star rating [RATING] out of 5 stars",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] out of 5",
                    "star-rating/alt-text/review": "Rated [RATING] out of 5 stars"
                },
                d = {
                    "star-rating/alt-text/product": "Average star rating [RATING] out of 5 stars",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] out of 5",
                    "star-rating/alt-text/review": "Rated [RATING] out of 5 stars"
                },
                p = {
                    "star-rating/alt-text/product": "Average star rating [RATING] out of 5 stars",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] out of 5",
                    "star-rating/alt-text/review": "Rated [RATING] out of 5 stars"
                },
                v = {
                    "star-rating/alt-text/product": "Average star rating [RATING] out of 5 stars",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] out of 5",
                    "star-rating/alt-text/review": "Rated [RATING] out of 5 stars"
                },
                h = {
                    "star-rating/alt-text/product": "Average star rating [RATING] out of 5 stars",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] out of 5",
                    "star-rating/alt-text/review": "Rated [RATING] out of 5 stars"
                },
                w = {
                    "star-rating/alt-text/product": "Valoraci\xf3n media en estrellas: [RATING] sobre 5",
                    "star-rating/alt-text/businessunit": "TrustScore: [RATING] sobre 5",
                    "star-rating/alt-text/review": "Valorada con [RATING] estrellas sobre 5"
                },
                f = {
                    "star-rating/alt-text/product": "Keskim\xe4\xe4r\xe4inen arvosana [RATING]/5 t\xe4hte\xe4",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING]/5 t\xe4hte\xe4",
                    "star-rating/alt-text/review": "Saanut [RATING]/5 t\xe4hte\xe4"
                },
                x = {
                    "star-rating/alt-text/product": "Note en \xe9toile moyenne [RATING] sur 5",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] sur 5",
                    "star-rating/alt-text/review": "Not\xe9 [RATING] sur 5 \xe9toiles"
                },
                m = {
                    "star-rating/alt-text/product": "Valutazione in stelle media [RATING] su 5",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] su 5",
                    "star-rating/alt-text/review": "Valutata [RATING] stelle su 5"
                },
                R = {
                    "star-rating/alt-text/product": "5つ星のうち平均[RATING]の星評価",
                    "star-rating/alt-text/businessunit": "TrustScore 5段階評価の[RATING]",
                    "star-rating/alt-text/review": "5つ星のうち[RATING]の評価"
                },
                b = {
                    "star-rating/alt-text/product": "Gjennomsnittlig stjernerangering [RATING] av 5 stjerner",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] av 5",
                    "star-rating/alt-text/review": "Vurdert til [RATING] av 5 stjerner"
                },
                I = {
                    "star-rating/alt-text/product": "Gemiddelde sterrenscore [RATING] van de 5 sterren",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] uit 5",
                    "star-rating/alt-text/review": "Beoordeeld met [RATING] van de 5 sterren"
                },
                A = {
                    "star-rating/alt-text/product": "Gemiddelde sterrenscore [RATING] van de 5 sterren",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] uit 5",
                    "star-rating/alt-text/review": "Beoordeeld met [RATING] van de 5 sterren"
                },
                G = {
                    "star-rating/alt-text/product": "Ocena: [RATING] na 5",
                    "star-rating/alt-text/businessunit": "Wynik TrustScore: [RATING] na 5",
                    "star-rating/alt-text/review": "Oceniono na [RATING] z 5"
                },
                N = {
                    "star-rating/alt-text/product": "A classifica\xe7\xe3o m\xe9dia por estrelas \xe9 [RATING] de um total de 5",
                    "star-rating/alt-text/businessunit": "O TrustScore \xe9 [RATING] de um total de 5",
                    "star-rating/alt-text/review": "Avaliado com [RATING] de um total de 5 estrelas"
                },
                T = {
                    "star-rating/alt-text/product": "Classifica\xe7\xe3o m\xe9dia por estrelas: [RATING] em 5",
                    "star-rating/alt-text/businessunit": "TrustScore: [RATING] em 5",
                    "star-rating/alt-text/review": "Classificada [RATING] em 5 estrelas"
                },
                Z = {
                    "star-rating/alt-text/product": "Средний звездный рейтинг [RATING] из 5 звезд",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] из 5",
                    "star-rating/alt-text/review": "Рейтинг [RATING] из 5 звезд"
                },
                V = {
                    "star-rating/alt-text/product": "Genomsnittligt stj\xe4rnbetyg [RATING] av 5 stj\xe4rnor",
                    "star-rating/alt-text/businessunit": "TrustScore [RATING] av 5",
                    "star-rating/alt-text/review": "Betygsatt [RATING] av 5 stj\xe4rnor"
                },
                H = r(74320),
                S = ".CDS_StarRating_starRating__8ae3cf{display:block}.CDS_StarRating_starRating__8ae3cf,.CDS_StarRating_starRating__8ae3cf :after,.CDS_StarRating_starRating__8ae3cf :before{box-sizing:border-box;margin:0;padding:0}.CDS_StarRating_starRatingResponsive__8ae3cf{max-height:64px;max-width:342px;width:100%}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9jb21wb25lbnRzL1N0YXJSYXRpbmcvU3RhclJhdGluZy5tb2R1bGUuc2NzcyIsInNyYy9zaGFyZWQvc3R5bGVzL19jb21wb25lbnQtcmVzZXQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQSxtQ0FFRSxhQUFjLENBRmhCLHdIQ0RFLHFCQUFzQixDQUN0QixRQUFTLENBQ1QsU0FNWSxDREZkLDZDQUlFLGVBQWdCLENBRGhCLGVBQWdCLENBRGhCLFVBRWdCIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCBcIi4uLy4uL3NoYXJlZC9zdHlsZXMvX2NvbXBvbmVudC1yZXNldC5zY3NzXCI7XG5cbi5zdGFyUmF0aW5nIHtcbiAgQGluY2x1ZGUgY29tcG9uZW50LXJlc2V0O1xuICBkaXNwbGF5OiBibG9jaztcbn1cblxuLnN0YXJSYXRpbmdSZXNwb25zaXZlIHtcbiAgLyogV2hlbiByZXNwb25zaXZlLCB0aGUgbWF4aW11bSB3aWR0aCAvIGhlaWdodCBpcyAzNDJweCB4IDY0cHggKi9cbiAgd2lkdGg6IDEwMCU7XG4gIG1heC13aWR0aDogMzQycHg7XG4gIG1heC1oZWlnaHQ6IDY0cHg7XG59XG4iLCJAbWl4aW4gY29tcG9uZW50LXJlc2V0IHtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nOiAwO1xuXG4gIDo6YmVmb3JlLFxuICA6OmFmdGVyIHtcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICAgIG1hcmdpbjogMDtcbiAgICBwYWRkaW5nOiAwO1xuICB9XG59XG5cbiVjb21wb25lbnQtcmVzZXQge1xuICBAaW5jbHVkZSBjb21wb25lbnQtcmVzZXQ7XG59Il19 */",
                L = !1,
                B = {
                    get starRating() {
                        return L || (L = !0, (0, H.Z)(S, {
                            prepend: !0
                        })), "CDS_StarRating_starRating__8ae3cf"
                    },
                    get starRatingResponsive() {
                        return L || (L = !0, (0, H.Z)(S, {
                            prepend: !0
                        })), "CDS_StarRating_starRatingResponsive__8ae3cf"
                    },
                    inject() {
                        L || (L = !0, (0, H.Z)(S, {
                            prepend: !0
                        }))
                    }
                },
                C = r(11206);
            let y = ({
                alt: t,
                className: e,
                context: r,
                "data-testid": l,
                rating: o = 0,
                size: u = "m"
            }) => {
                let {
                    strings: c
                } = (0, C.q)(a), g = t || (() => {
                    switch (r) {
                        case "product":
                            return c["star-rating/alt-text/product"].replace("[RATING]", o.toString());
                        case "businessunit":
                            return c["star-rating/alt-text/businessunit"].replace("[RATING]", o.toString());
                        case "review":
                            return c["star-rating/alt-text/review"].replace("[RATING]", o.toString());
                        default:
                            return ""
                    }
                })();
                return (0, n.jsx)("img", {
                    className: (0, s.Z)(B.starRating, {
                        [B.starRatingResponsive]: "responsive" === u
                    }, e),
                    "data-testid": l,
                    alt: g,
                    width: i[u],
                    src: `https://cdn.trustpilot.net/brand-assets/4.1.0/stars/stars-${o}.svg`
                })
            }
        },
        96437: function(t, e, r) {
            "use strict";
            r.d(e, {
                _: function() {
                    return g
                }
            });
            var a = r(81177),
                n = r.n(a),
                s = r(92752),
                i = r(93967),
                l = r.n(i),
                o = r(67294),
                u = function(t, e) {
                    var r = {};
                    for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && 0 > e.indexOf(a) && (r[a] = t[a]);
                    if (null != t && "function" == typeof Object.getOwnPropertySymbols)
                        for (var n = 0, a = Object.getOwnPropertySymbols(t); n < a.length; n++) 0 > e.indexOf(a[n]) && Object.prototype.propertyIsEnumerable.call(t, a[n]) && (r[a[n]] = t[a[n]]);
                    return r
                };
            let c = () => o.createElement("svg", {
                    viewBox: "0 0 198 149",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    "data-testid": "businessunitprofile-fallback",
                    className: n().fallbackImage
                }, o.createElement("path", {
                    d: "M0 8C0 3.58172 3.58172 0 8 0H190C194.418 0 198 3.58172 198 8V141C198 145.418 194.418 149 190 149H8C3.58172 149 0 145.418 0 141V8Z",
                    fill: s.T.y2J
                }), o.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M100 70.5H89.5V68.5H100V70.5Z",
                    fill: s.T.VQA
                }), o.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M94 82.5H89.5V80.5H94V82.5Z",
                    fill: s.T.VQA
                }), o.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M94 76.5H89.5V74.5H94V76.5Z",
                    fill: s.T.VQA
                }), o.createElement("path", {
                    d: "M99 76.5H101V78.5H99V76.5Z",
                    fill: s.T.VQA
                }), o.createElement("path", {
                    d: "M99 80.5H101V82.5H99V80.5Z",
                    fill: s.T.VQA
                }), o.createElement("path", {
                    d: "M105.5 76.5H107.5V78.5H105.5V76.5Z",
                    fill: s.T.VQA
                }), o.createElement("path", {
                    d: "M105.5 80.5H107.5V82.5H105.5V80.5Z",
                    fill: s.T.VQA
                }), o.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M110.5 74.5H96V84.5H110.5V74.5ZM94 72.5V86.5H112.5V72.5H94Z",
                    fill: s.T.VQA
                }), o.createElement("path", {
                    d: "M87.5 64.5H102V72.5H104V62.5H85.5V86.5H94V84.5H87.5V64.5Z",
                    fill: s.T.VQA
                })),
                g = t => {
                    var {
                        className: e,
                        src: r,
                        srcSet: a,
                        alt: s = ""
                    } = t, i = u(t, ["className", "src", "srcSet", "alt"]);
                    let [g, d] = o.useState(r);
                    return g ? o.createElement("picture", {
                        className: l()(n().containmentWrapper, e)
                    }, a && a.avif && o.createElement("source", {
                        srcSet: a.avif,
                        type: "image/avif"
                    }), a && a.jpg && o.createElement("source", {
                        srcSet: a.jpg,
                        type: "image/jpeg"
                    }), o.createElement("img", Object.assign({
                        className: n().image,
                        src: g,
                        alt: s,
                        ref: t => {
                            t && (t.src = t.src, t.onerror = () => {
                                d(null)
                            })
                        }
                    }, i))) : o.createElement("span", {
                        className: l()(n().containmentWrapper, e)
                    }, o.createElement(c, null))
                }
        },
        81177: function(t) {
            t.exports = {
                containmentWrapper: "business-profile-image_containmentWrapper__xJZjr",
                image: "business-profile-image_image__V14jr",
                fallbackImage: "business-profile-image_fallbackImage__Yp1_q"
            }
        },
        4298: function(t, e, r) {
            t.exports = r(23381)
        },
        68997: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path d="m3.2 7.987 6.344-6.343.375-.344.687.687-.344.375-5.656 5.625 6 6-.687.72-.375-.345-6-6-.344-.375Z"/></svg>'
        },
        19559: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path d="m8.019 12.806-.375-.343-6-6-.344-.375.719-.688 6 6 5.625-5.656.375-.344.687.688-.343.375-6.344 6.343Z"/></svg>'
        },
        26684: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path d="m12.806 7.987-.343.375-6.344 6.344-.719-.718 6-6-5.656-5.626-.344-.375.719-.687 6.687 6.687Z"/></svg>'
        },
        36187: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><g fill-rule="evenodd" clip-rule="evenodd" clip-path="url(#a)"><path d="M3.05 3.05a7 7 0 1 0 9.9 9.9 7 7 0 0 0-9.9-9.9Zm-.707 10.607A8 8 0 1 1 13.657 2.343 8 8 0 0 1 2.343 13.657Z"/><path d="m8.707 8 2.396 2.397-.707.707L8 8.707l-2.397 2.397-.707-.707L7.293 8 4.896 5.604l.708-.708L8 7.293l2.396-2.396.707.707L8.707 8Z"/></g><defs><clipPath id="a"><path d="M0 0h16v16H0z"/></clipPath></defs></svg>'
        },
        63864: function(t) {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" class="trustpilot-icon"><path d="M1 10.594 5.406 15h5.157L15 10.594V5.438L10.562 1H5.407L1 5.438v5.156ZM5 0h6l5 5v6l-5 5H5l-5-5V5l5-5Zm3.5 4v5h-1V4h1Zm-1.25 6h1.5v1.5h-1.5V10Z"/></svg>'
        },
        47209: function(t) {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" class="trustpilot-icon"><path d="M.563 14.25 7.405 2.281 8 1.25l.563 1.031 6.843 11.969.594 1H0l.563-1Zm13.687 0L8 3.281 1.719 14.25H14.25Zm-6.75-8h1v4.5h-1v-4.5Zm1.25 7h-1.5v-1.5h1.5v1.5Z"/></svg>'
        },
        43721: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.694 1.537c.217.281.415.592.593.923.321.6.59 1.287.793 2.04h1.983a7.027 7.027 0 0 0-3.37-2.963ZM14.54 5.5h-2.235c.143.789.22 1.63.22 2.5 0 .87-.077 1.711-.22 2.5h2.235c.297-.776.46-1.62.46-2.5 0-.88-.163-1.724-.46-2.5Zm-.476 6H12.08a9.655 9.655 0 0 1-.793 2.04 6.698 6.698 0 0 1-.593.923 7.027 7.027 0 0 0 3.37-2.963Zm-8.758 2.963a6.708 6.708 0 0 1-.593-.923 9.654 9.654 0 0 1-.792-2.04H1.936a7.027 7.027 0 0 0 3.37 2.963ZM1.46 10.5h2.236c-.144-.789-.22-1.63-.22-2.5 0-.87.076-1.711.22-2.5H1.46A6.984 6.984 0 0 0 1 8c0 .88.163 1.724.46 2.5Zm.476-6h1.985c.203-.753.47-1.44.792-2.04.178-.331.376-.642.593-.923A7.027 7.027 0 0 0 1.936 4.5ZM8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0M5.595 2.933c-.247.46-.461.987-.635 1.567H7.5V1.075c-.677.204-1.35.822-1.905 1.858Zm4.81 0c.247.46.462.987.635 1.567H8.5V1.075c.677.204 1.35.822 1.906 1.858ZM8.5 5.5h2.787c.153.774.238 1.616.238 2.5 0 .884-.085 1.726-.238 2.5H8.5v-5Zm0 6h2.54a8.428 8.428 0 0 1-.634 1.567c-.557 1.036-1.229 1.654-1.906 1.858V11.5Zm-1 0v3.425c-.677-.204-1.35-.822-1.905-1.858A8.426 8.426 0 0 1 4.96 11.5H7.5Zm0-1H4.713A12.91 12.91 0 0 1 4.475 8c0-.884.085-1.726.238-2.5H7.5v5Z"/></svg>'
        },
        27335: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path fill-rule="evenodd" clip-rule="evenodd" d="M0 2.5h16v11H0v-11Zm1.789 1L8 9.173 14.211 3.5H1.79ZM15 4.134l-7 6.393-7-6.393V12.5h14V4.134Z"/></svg>'
        },
        77448: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path d="M12 7.5H4v1h8v-1Z"/><path fill-rule="evenodd" clip-rule="evenodd" d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0ZM1 8a7 7 0 1 1 14 0A7 7 0 0 1 1 8Z"/></svg>'
        },
        53520: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><g clip-path="url(#a)"><path fill-rule="evenodd" clip-rule="evenodd" d="m4.622.933.04.057.003.006L6.37 3.604l.002.003a1.7 1.7 0 0 1-.442 2.29l-.036.029c-.392.325-.627.519-.652.85-.026.364.206 1.09 1.562 2.445 1.356 1.357 2.073 1.58 2.426 1.55.318-.027.503-.252.816-.632l.057-.069a1.7 1.7 0 0 1 2.29-.442l.003.002 2.608 1.705.006.004c.204.141.454.37.649.645.188.267.376.655.31 1.09-.031.213-.147.495-.305.774a4.534 4.534 0 0 1-.715.941C14.323 15.422 13.377 16 12.1 16c-1.236 0-2.569-.483-3.877-1.246-1.315-.768-2.642-1.84-3.877-3.075C3.112 10.444 2.033 9.118 1.26 7.8.49 6.49 0 5.15 0 3.9c0-1.274.52-2.215 1.144-2.845C1.751.442 2.478.098 2.954.03c.507-.072.896.088 1.182.327.224.187.387.43.486.576Zm-1.127.191a.46.46 0 0 0-.4-.104c-.223.032-.758.25-1.24.738C1.393 2.227 1 2.924 1 3.9c0 1.001.398 2.161 1.122 3.394.72 1.226 1.74 2.486 2.932 3.678 1.19 1.19 2.45 2.204 3.673 2.918 1.23.718 2.384 1.11 3.373 1.11.949 0 1.652-.422 2.138-.914.245-.247.43-.508.556-.73.134-.237.181-.393.186-.43.01-.065-.014-.19-.139-.366a1.737 1.737 0 0 0-.396-.396l-2.59-1.693a.7.7 0 0 0-.946.19l-.011.017-.013.016-.08.098c-.261.33-.723.91-1.491.975-.841.07-1.85-.47-3.218-1.838-1.369-1.37-1.912-2.381-1.85-3.225.056-.783.638-1.25.97-1.517l.09-.072.016-.013.016-.011a.7.7 0 0 0 .191-.946l-1.694-2.59-.051-.076c-.104-.152-.182-.265-.29-.355Z"/></g><defs><clipPath id="a"><path d="M0 0h16v16H0z"/></clipPath></defs></svg>'
        },
        54955: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.143 16 16 0 0 6.857l5.714 3.429L9.143 16ZM6 9.295l-3.815-2.29 10.683-4.578L6 9.295Zm.705.705 6.868-6.868-4.578 10.683L6.705 10Z"/></svg>'
        },
        90964: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path fill-rule="evenodd" clip-rule="evenodd" d="M5.5 1.5a5.5 5.5 0 1 0 0 11v3.068l3.462-2.885-.822-.617-1.64 1.366V11.5h-1a4.5 4.5 0 1 1 0-9h5a4.5 4.5 0 0 1 2.896 7.944l.004.013h1.378A5.5 5.5 0 0 0 10.5 1.5h-5Zm6.95 12.055L12 13.22l-.45.335-.59.442.234-.735.163-.51-.43-.32-.661-.492h1.35l.165-.523.219-.689.219.689.166.523H13.734l-.662.492-.43.32.164.51.234.735-.59-.442ZM9.532 16l1.034-.773L12 14.156l1.433 1.071 1.034.773-.393-1.23-.554-1.736 1.471-1.094L16 11.19h-3.067l-.54-1.7L12 8.25l-.393 1.24-.54 1.7H8l1.009.75 1.471 1.094-.554 1.736L9.533 16Z"/></svg>'
        },
        45218: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.997 5.268 2.38 11.825l-.76-.65 6.377-7.443 6.383 7.442-.76.652-5.623-6.558Z"/></svg>'
        },
        32430: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><g clip-path="url(#a)" fill-rule="evenodd" clip-rule="evenodd"><path d="M6 13a3 3 0 1 1-3.5-2.959V0h1v10.041A3 3 0 0 1 6 13Zm-1 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0ZM12.5 5.959V16h1V5.959a3 3 0 1 0-1 0ZM13.002 5h-.004a2 2 0 1 1 .004 0Z"/></g><defs><clipPath id="a"><path transform="rotate(-180 8 8)" d="M0 0h16v16H0z"/></clipPath></defs></svg>'
        },
        79429: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path d="M2 1v2H0v1h2v2h1V4h2V3H3V1H2Zm0 9v2H0v1h2v2h1v-2h2v-1H3v-2H2Zm2.875-1.438L8 9.75l1.188 3.125.562 1.375.563-1.375L11.5 9.75l3.125-1.188L16 8l-1.375-.563L11.5 6.25l-1.188-3.125L9.75 1.75l-.563 1.375L8 6.25 4.875 7.438 3.5 8l1.375.563Zm4.031.75L8.75 9l-.313-.156L6 8l2.438-.844L8.75 7l.156-.313.844-2.437.844 2.438.156.312.313.156L13.5 8l-2.438.844L10.75 9l-.156.313-.844 2.437-.844-2.438Z"/></svg>'
        }
    }
]);
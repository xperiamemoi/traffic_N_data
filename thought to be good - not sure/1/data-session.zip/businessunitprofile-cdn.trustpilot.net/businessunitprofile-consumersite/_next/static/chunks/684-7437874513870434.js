! function() {
    try {
        var t = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            e = (new t.Error).stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "e6631272-b72e-4ff6-a4ca-a87e497180f5", t._sentryDebugIdIdentifier = "sentry-dbid-e6631272-b72e-4ff6-a4ca-a87e497180f5")
    } catch (t) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [684], {
        94120: function(t, e, i) {
            "use strict";
            i.r(e), i.d(e, {
                ERROR_API_KEY_EXPIRED: function() {
                    return m
                },
                ERROR_API_KEY_INVALID: function() {
                    return g
                },
                ERROR_API_KEY_MISSING: function() {
                    return O
                },
                ERROR_BAD_REQUEST_FORMAT: function() {
                    return w
                },
                ERROR_BAD_RESPONSE_FORMAT: function() {
                    return a
                },
                ERROR_CLIENT_TIMEOUT: function() {
                    return l
                },
                ERROR_CSP_BLOCK: function() {
                    return d
                },
                ERROR_FORBIDDEN_ENDPOINT: function() {
                    return E
                },
                ERROR_FORBIDDEN_HEADER: function() {
                    return P
                },
                ERROR_FORBIDDEN_ORIGIN: function() {
                    return T
                },
                ERROR_GENERAL_SERVER_FAILURE: function() {
                    return y
                },
                ERROR_INSTALLATION_METHOD_RESTRICTED: function() {
                    return v
                },
                ERROR_INTEGRATION_FAILURE: function() {
                    return _
                },
                ERROR_INVALID_ENDPOINT: function() {
                    return p
                },
                ERROR_NETWORK_ABORT: function() {
                    return c
                },
                ERROR_NETWORK_CONNECTION: function() {
                    return u
                },
                ERROR_RATE_LIMIT: function() {
                    return N
                },
                ERROR_SCRIPT_LOAD_FAIL: function() {
                    return C
                },
                ERROR_SERVER_TIMEOUT: function() {
                    return I
                },
                ERROR_SUBSCRIPTION_NOT_ACTIVE: function() {
                    return f
                },
                ERROR_TOKEN_EXPIRED: function() {
                    return A
                },
                ERROR_TOKEN_INVALID: function() {
                    return b
                },
                ERROR_TOKEN_MISSING: function() {
                    return S
                },
                ERROR_UNSUPPORTED_VERSION: function() {
                    return h
                },
                ERROR_WRONG_REGION: function() {
                    return R
                },
                default: function() {
                    return Z
                },
                defaultEndpoint: function() {
                    return o
                },
                defaultScriptUrlPattern: function() {
                    return M
                },
                defaultTlsEndpoint: function() {
                    return s
                },
                load: function() {
                    return x
                }
            });
            var n = i(97582);

            function r(t) {
                for (var e = "", i = 0; i < t.length; ++i)
                    if (i > 0) {
                        var n = t[i].toLowerCase();
                        n !== t[i] ? e += " ".concat(n) : e += t[i]
                    } else e += t[i].toUpperCase();
                return e
            }
            var o = {
                    default: "endpoint"
                },
                s = {
                    default: "tlsEndpoint"
                },
                l = "Client timeout",
                u = "Network connection error",
                c = "Network request aborted",
                a = "Response cannot be parsed",
                d = "Blocked by CSP",
                p = "The endpoint parameter is not a valid URL",
                R = r("WrongRegion"),
                f = r("SubscriptionNotActive"),
                h = r("UnsupportedVersion"),
                v = r("InstallationMethodRestricted"),
                E = r("HostnameRestricted"),
                _ = r("IntegrationFailed"),
                O = "API key required",
                g = "API key not found",
                m = "API key expired",
                w = "Request cannot be parsed",
                y = "Request failed",
                I = "Request failed to process",
                N = "Too many requests, rate limit exceeded",
                T = "Not available for this origin",
                P = "Not available with restricted header",
                S = O,
                b = g,
                A = m,
                D = "9319",
                L = "https://fpnpmcdn.net/v<version>/<apiKey>/loader_v<loaderVersion>.js",
                M = L,
                C = "Failed to load the JS script of the agent";

            function x(t) {
                t.scriptUrlPattern;
                var e, i, r = t.token,
                    o = t.apiKey,
                    s = void 0 === o ? r : o,
                    l = (0, n.__rest)(t, ["scriptUrlPattern", "token", "apiKey"]),
                    u = null !== (e = "scriptUrlPattern", i = Object.prototype.hasOwnProperty.call(t, e) ? t[e] : void 0) && void 0 !== i ? i : L;
                return Promise.resolve().then(function() {
                    var t, e, i;
                    if (!s || "string" != typeof s) throw Error(O);
                    return (t = (Array.isArray(u) ? u : [u]).map(function(t) {
                        var e, i;
                        return e = String(t), i = encodeURIComponent, e.replace(/<[^<>]+>/g, function(t) {
                            return "<version>" === t ? "3" : "<apiKey>" === t ? i(s) : "<loaderVersion>" === t ? i("3.8.5") : t
                        })
                    }), e = V, i = [], (function(t, e) {
                        var i, r, o = (r = (0, n.__spreadArray)([], t, !0), {
                                current: function() {
                                    return r[0]
                                },
                                postpone: function() {
                                    var t = r.shift();
                                    void 0 !== t && r.push(t)
                                },
                                exclude: function() {
                                    r.shift()
                                }
                            }),
                            s = (i = 0, function() {
                                return Math.random() * Math.min(3e3, 100 * Math.pow(2, i++))
                            }),
                            l = o.current();
                        if (void 0 === l) return Promise.reject(TypeError("The list of script URL patterns is empty"));
                        var u = function(t, i) {
                            return e(t).catch(function(t) {
                                if (i + 1 >= 5) throw t;
                                (function(t) {
                                    if (!(t instanceof Error)) return !1;
                                    var e = t.message;
                                    return e === d || e === D
                                })(t) ? o.exclude(): o.postpone();
                                var e, n = o.current();
                                if (void 0 === n) throw t;
                                return (e = s(), new Promise(function(t) {
                                    return setTimeout(t, e)
                                })).then(function() {
                                    return u(n, i + 1)
                                })
                            })
                        };
                        return u(l, 0)
                    })(t, function(t) {
                        var n = new Date,
                            r = function(e) {
                                return i.push({
                                    url: t,
                                    startedAt: n,
                                    finishedAt: new Date,
                                    error: e
                                })
                            },
                            o = e(t);
                        return o.then(function() {
                            return r()
                        }, r), o
                    }).then(function(t) {
                        return [t, {
                            attempts: i
                        }]
                    })).catch(U)
                }).then(function(t) {
                    var e = t[0],
                        i = t[1];
                    return e.load((0, n.__assign)((0, n.__assign)({}, l), {
                        ldi: i
                    }))
                })
            }

            function V(t) {
                var e, i, n, r, o, s, l;
                return (e = function() {
                    return new Promise(function(e, i) {
                        var n = document.createElement("script"),
                            r = function() {
                                var t;
                                return null === (t = n.parentNode) || void 0 === t ? void 0 : t.removeChild(n)
                            },
                            o = document.head || document.getElementsByTagName("head")[0];
                        n.onload = function() {
                            r(), e()
                        }, n.onerror = function() {
                            r(), i(Error(C))
                        }, n.async = !0, n.src = t, o.appendChild(n)
                    })
                }, i = function() {
                    throw Error(d)
                }, r = document, o = "securitypolicyviolation", s = function(e) {
                    var i = new URL(t, location.href),
                        r = e.blockedURI;
                    r !== i.href && r !== i.protocol.slice(0, -1) && r !== i.origin || (n = e, l())
                }, r.addEventListener(o, s), l = function() {
                    return r.removeEventListener(o, s)
                }, Promise.resolve().then(e).then(function(t) {
                    return l(), t
                }, function(t) {
                    return new Promise(function(t) {
                        return setTimeout(t)
                    }).then(function() {
                        if (l(), n) return i(n);
                        throw t
                    })
                })).then(B)
            }

            function B() {
                var t, e, i = window,
                    n = "__fpjs_p_l_b",
                    r = i[n];
                if ((null == (e = null === (t = Object.getOwnPropertyDescriptor) || void 0 === t ? void 0 : t.call(Object, i, n)) ? void 0 : e.configurable) ? delete i[n] : e && !e.writable || (i[n] = void 0), "function" != typeof(null == r ? void 0 : r.load)) throw Error(D);
                return r
            }

            function U(t) {
                throw t instanceof Error && t.message === D ? Error(C) : t
            }
            var Z = {
                load: x,
                defaultScriptUrlPattern: M,
                ERROR_SCRIPT_LOAD_FAIL: C,
                ERROR_API_KEY_EXPIRED: m,
                ERROR_API_KEY_INVALID: g,
                ERROR_API_KEY_MISSING: O,
                ERROR_BAD_REQUEST_FORMAT: w,
                ERROR_BAD_RESPONSE_FORMAT: a,
                ERROR_CLIENT_TIMEOUT: l,
                ERROR_CSP_BLOCK: d,
                ERROR_FORBIDDEN_ENDPOINT: E,
                ERROR_FORBIDDEN_HEADER: P,
                ERROR_FORBIDDEN_ORIGIN: T,
                ERROR_GENERAL_SERVER_FAILURE: y,
                ERROR_INSTALLATION_METHOD_RESTRICTED: v,
                ERROR_INTEGRATION_FAILURE: _,
                ERROR_INVALID_ENDPOINT: p,
                ERROR_NETWORK_ABORT: c,
                ERROR_NETWORK_CONNECTION: u,
                ERROR_RATE_LIMIT: N,
                ERROR_SERVER_TIMEOUT: I,
                ERROR_SUBSCRIPTION_NOT_ACTIVE: f,
                ERROR_TOKEN_EXPIRED: A,
                ERROR_TOKEN_INVALID: b,
                ERROR_TOKEN_MISSING: S,
                ERROR_UNSUPPORTED_VERSION: h,
                ERROR_WRONG_REGION: R,
                defaultEndpoint: o,
                defaultTlsEndpoint: s
            }
        },
        10354: function(t, e, i) {
            "use strict";
            var n = this && this.__createBinding || (Object.create ? function(t, e, i, n) {
                    void 0 === n && (n = i);
                    var r = Object.getOwnPropertyDescriptor(e, i);
                    (!r || ("get" in r ? !e.__esModule : r.writable || r.configurable)) && (r = {
                        enumerable: !0,
                        get: function() {
                            return e[i]
                        }
                    }), Object.defineProperty(t, n, r)
                } : function(t, e, i, n) {
                    void 0 === n && (n = i), t[n] = e[i]
                }),
                r = this && this.__exportStar || function(t, e) {
                    for (var i in t) "default" === i || Object.prototype.hasOwnProperty.call(e, i) || n(e, t, i)
                };
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0, r(i(10655), e);
            var o = i(62764);
            Object.defineProperty(e, "default", {
                enumerable: !0,
                get: function() {
                    return o.SimplicityProvider
                }
            })
        },
        15011: function(t, e, i) {
            "use strict";
            var n = this && this.__createBinding || (Object.create ? function(t, e, i, n) {
                    void 0 === n && (n = i);
                    var r = Object.getOwnPropertyDescriptor(e, i);
                    (!r || ("get" in r ? !e.__esModule : r.writable || r.configurable)) && (r = {
                        enumerable: !0,
                        get: function() {
                            return e[i]
                        }
                    }), Object.defineProperty(t, n, r)
                } : function(t, e, i, n) {
                    void 0 === n && (n = i), t[n] = e[i]
                }),
                r = this && this.__setModuleDefault || (Object.create ? function(t, e) {
                    Object.defineProperty(t, "default", {
                        enumerable: !0,
                        value: e
                    })
                } : function(t, e) {
                    t.default = e
                }),
                o = this && this.__importStar || function(t) {
                    if (t && t.__esModule) return t;
                    var e = {};
                    if (null != t)
                        for (var i in t) "default" !== i && Object.prototype.hasOwnProperty.call(t, i) && n(e, t, i);
                    return r(e, t), e
                },
                s = this && this.__awaiter || function(t, e, i, n) {
                    return new(i || (i = Promise))(function(r, o) {
                        function s(t) {
                            try {
                                u(n.next(t))
                            } catch (t) {
                                o(t)
                            }
                        }

                        function l(t) {
                            try {
                                u(n.throw(t))
                            } catch (t) {
                                o(t)
                            }
                        }

                        function u(t) {
                            var e;
                            t.done ? r(t.value) : ((e = t.value) instanceof i ? e : new i(function(t) {
                                t(e)
                            })).then(s, l)
                        }
                        u((n = n.apply(t, e || [])).next())
                    })
                };
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.SimplicityDataProviderImpl = void 0;
            let l = o(i(94120));
            class u {
                constructor(t) {
                    var e;
                    this.options = t, this.fingerprintEnabled = (null === (e = this.options) || void 0 === e ? void 0 : e.useFingerprint) || !1, (null == t ? void 0 : t.lazyInitialize) || "undefined" == typeof window || (this.initSimplicityPromise = this.loadSimplicity())
                }
                loadSimplicity() {
                    return new Promise(t => {
                        var e, i;
                        window.onSimplicityDataAvailable = e => {
                            this.fingerprintEnabled && this.loadFingerprint(), t(e)
                        };
                        let n = document.getElementsByTagName("script"),
                            r = !1,
                            o = (null === (e = this.options) || void 0 === e ? void 0 : e.simplicityScriptUrl) || "https://simplicity.trustpilot.com/simplicity.js";
                        for (let t = 0; t < n.length; t++) n[t].src === o && (r = !0);
                        if (!1 === r) {
                            let e = document.getElementsByTagName("script")[0],
                                n = document.createElement("script");
                            n.src = (null === (i = this.options) || void 0 === i ? void 0 : i.simplicityScriptUrl) || "https://simplicity.trustpilot.com/simplicity.js", n.onerror = e => {
                                var i;
                                (null === (i = this.options) || void 0 === i ? void 0 : i.onError) && this.options.onError(e), t("")
                            }, e && e.parentNode && e.parentNode.insertBefore(n, e)
                        }
                    })
                }
                getSimplicity(t = 5e3) {
                    return s(this, void 0, void 0, function*() {
                        let e = !1;
                        this.initSimplicityPromise || (this.initSimplicityPromise = this.loadSimplicity());
                        let i = Date.now();
                        return Promise.race([this.initSimplicityPromise, new Promise(n => {
                            setTimeout(() => {
                                var t;
                                e || ((null === (t = this.options) || void 0 === t ? void 0 : t.onTimeout) && this.options.onTimeout(Date.now() - i), n(""))
                            }, Math.max(0, t))
                        })]).finally(() => {
                            e = !0
                        })
                    })
                }
                loadFingerprint() {
                    this.initFingerprintPromise = new Promise(t => l.load({
                        region: "eu",
                        scriptUrlPattern: ["https://fp-prx.trustpilot.com/gZcjjCCkyc7DCVJLywfD/szRz2YviSTyJDNV2mNP7?apiKey=<apiKey>&version=<version>&loaderVersion=<loaderVersion>", l.defaultScriptUrlPattern],
                        endpoint: ["https://fp-prx.trustpilot.com/gZcjjCCkyc7DCVJLywfD/2g9FcYZzrQkzcZ4tVXk7?region=eu", l.defaultEndpoint],
                        apiKey: "4bhpfCxkCrdBIJkus95S"
                    }).then(e => t(e)).catch(e => {
                        var i;
                        (null === (i = this.options) || void 0 === i ? void 0 : i.onError) && this.options.onError("Error loading fingerprint agent", e), t(void 0)
                    }))
                }
                getFingerprint(t = 5e3) {
                    return s(this, void 0, void 0, function*() {
                        let e = !1;
                        try {
                            let t = sessionStorage.getItem("TP.fp") || "";
                            if (t && "" !== t) return e = !0, t
                        } catch (t) {}
                        this.initFingerprintPromise || this.loadFingerprint();
                        let i = Date.now();
                        return Promise.race([new Promise(e => {
                            var i;
                            null === (i = this.initFingerprintPromise) || void 0 === i || i.then(i => {
                                if (!i || void 0 === i) return e("");
                                i.get({
                                    timeout: t
                                }).then(t => (sessionStorage.setItem("TP.fp", JSON.stringify(t)), e(JSON.stringify(t)))).catch(t => {
                                    var i;
                                    (null === (i = this.options) || void 0 === i ? void 0 : i.onError) && this.options.onError("Error getting fingerprint", t), e("")
                                })
                            }).catch(t => {
                                var i;
                                (null === (i = this.options) || void 0 === i ? void 0 : i.onError) && this.options.onError("Error loading fingerprint agent from unreachable catch", t), e("")
                            })
                        }), new Promise(n => {
                            setTimeout(() => {
                                var t;
                                e || ((null === (t = this.options) || void 0 === t ? void 0 : t.onTimeout) && this.options.onTimeout(Date.now() - i), n(""))
                            }, Math.max(0, t))
                        })]).finally(() => {
                            e = !0
                        })
                    })
                }
                getSimplicityData(t = 5e3) {
                    var e, i, n, r;
                    return s(this, void 0, void 0, function*() {
                        let o;
                        if (!this.fingerprintEnabled) return yield this.getSimplicity(t);
                        let s = "",
                            l = {};
                        try {
                            l = (s = yield this.getSimplicity(t)) && "" !== s ? JSON.parse(s) : {}
                        } catch (t) {
                            (null === (e = this.options) || void 0 === e ? void 0 : e.onError) && this.options.onError("Error getting simplicity", t)
                        }
                        if (!s || "" === s) try {
                            let t = sessionStorage.getItem("TP.um") || "";
                            l = t && "" !== t ? JSON.parse(t) : {}
                        } catch (t) {
                            (null === (i = this.options) || void 0 === i ? void 0 : i.onError) && this.options.onError("Error reading tp.Um from session storage", t)
                        }
                        let u = {};
                        try {
                            u = (o = yield this.getFingerprint(t)) && "" !== o ? JSON.parse(o) : {}
                        } catch (t) {
                            (null === (n = this.options) || void 0 === n ? void 0 : n.onError) && this.options.onError("Error getting fingerprint", t)
                        }
                        try {
                            let t = Object.assign(Object.assign({}, l), {
                                fingerprint: u
                            });
                            return JSON.stringify(t)
                        } catch (t) {
                            return (null === (r = this.options) || void 0 === r ? void 0 : r.onError) && this.options.onError("Error combining fingerprint", t), ""
                        }
                    })
                }
            }
            e.SimplicityDataProviderImpl = u
        },
        62764: function(t, e, i) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.SimplicityProvider = void 0;
            let n = i(15011);
            class r {
                constructor() {
                    this.alreadyBuilt = !1
                }
                get instance() {
                    if (!this._instance) throw TypeError("This instance has not been built yet - Please call .build() before .instance");
                    return this._instance
                }
                withOptions(t) {
                    return this._options = t, this
                }
                build() {
                    if (this.alreadyBuilt) throw TypeError("This instance has already been built");
                    return this._instance = new n.SimplicityDataProviderImpl(this._options), this.alreadyBuilt = !0, this._instance
                }
            }
            e.SimplicityProvider = r
        },
        10655: function(t, e) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            })
        },
        32979: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path fill-rule="evenodd" clip-rule="evenodd" d="M14 4.62 6.233 12 2 8.16l.658-.633 3.56 3.228L13.326 4l.673.62Z"/></svg>'
        },
        21364: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path fill-rule="evenodd" clip-rule="evenodd" d="M5.5 0H5v2.5H1.5V16H11v-2.5h3.5V3.718l-.146-.147L10.929.146 10.782 0H5.5Zm1.575 2.5H6V1h4v3.5h3.5v8H11V6.218l-.146-.147-3.425-3.425-.147-.146h-.207Zm5.793 1L11 1.632V3.5h1.868ZM2.5 3.5V15H10V7H6.5V3.5h-4Zm5 .632V6h1.868L7.5 4.132Z"/></svg>'
        },
        80950: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path fill-rule="evenodd" clip-rule="evenodd" d="M3.404 1.904A6.5 6.5 0 0 1 14.5 6.5v.01c0 .194 0 .396-.029.627l-.004.03-.023.095c-.267 2.493-1.844 4.601-3.293 6.056a18.723 18.723 0 0 1-2.634 2.19 11.015 11.015 0 0 1-.234.154l-.013.01-.004.002h-.002L8 15.25l-.261.426h-.002l-.004-.003-.014-.009a13.842 13.842 0 0 1-.233-.152 18.388 18.388 0 0 1-2.64-2.178c-1.46-1.46-3.05-3.587-3.318-6.132l-.003-.026v-.068c-.025-.2-.025-.414-.025-.591V6.5a6.5 6.5 0 0 1 1.904-4.596ZM8 15.25l-.261.427.263.16.262-.162L8 15.25Zm-.002-.598a17.736 17.736 0 0 0 2.444-2.04c1.4-1.405 2.79-3.322 3.01-5.488l.004-.035.026-.105c.018-.153.018-.293.018-.484a5.5 5.5 0 0 0-11 0c0 .21.001.371.02.504l.005.035v.084c.24 2.195 1.632 4.109 3.029 5.505a17.389 17.389 0 0 0 2.444 2.024Z"/><path fill-rule="evenodd" clip-rule="evenodd" d="M8 4a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5ZM4.5 6.5a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0Z"/></svg>'
        },
        50141: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path fill-rule="evenodd" clip-rule="evenodd" d="M7 12.244a4.5 4.5 0 1 1 0-8.487A5.489 5.489 0 0 0 5 8c0 1.708.779 3.235 2 4.244Zm1-.502A4.496 4.496 0 0 1 6 8c0-1.56.794-2.935 2-3.742C9.206 5.065 10 6.44 10 8s-.794 2.935-2 3.742ZM8 12.9a5.5 5.5 0 1 1 0-9.8 5.5 5.5 0 1 1 0 9.8Zm1-9.144a4.5 4.5 0 1 1 0 8.487A5.489 5.489 0 0 0 11 8a5.489 5.489 0 0 0-2-4.244Z"/></svg>'
        },
        13127: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path d="m15 7.431-4.353-4.356-.707.707 3.145 3.146H4.5c-.545 0-1.393.099-2.124.519C1.61 7.887 1 8.669 1 9.928c0 1.205.619 1.98 1.368 2.43.723.433 1.568.57 2.132.57v-1c-.436 0-1.09-.112-1.618-.428-.5-.3-.882-.776-.882-1.572 0-.869.39-1.336.874-1.614.52-.298 1.17-.386 1.626-.386h8.588L9.94 11.075l.707.707 4.354-4.35Z"/></svg>'
        },
        73345: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path fill-rule="evenodd" clip-rule="evenodd" d="M8.36 1.528v3.48c3.46.124 5.38 1.531 6.403 3.316 1.04 1.817 1.097 3.938 1.097 5.176v1.914l-.936-1.67c-1.048-1.869-2.15-2.778-3.278-3.24-1.012-.415-2.09-.49-3.286-.502v3.47L0 7.5l8.36-5.972ZM8.024 6H7.36V3.472L1.72 7.5l5.64 4.028V9h.5c1.384 0 2.808.023 4.165.578.977.4 1.893 1.064 2.747 2.135-.109-.942-.35-1.97-.877-2.891C13.042 7.332 11.387 6.04 8.024 6Z"/></svg>'
        },
        75849: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path fill-rule="evenodd" clip-rule="evenodd" d="M13 1a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm-3 2a3 3 0 1 1 .583 1.778L5.867 7.115a3 3 0 0 1 0 1.77l4.716 2.337a3 3 0 1 1-.45.893L5.417 9.778a3 3 0 1 1 0-3.556l4.716-2.337A3.002 3.002 0 0 1 10 3ZM1 8a2 2 0 1 1 4 0 2 2 0 0 1-4 0Zm10 5a2 2 0 1 1 4 0 2 2 0 0 1-4 0Z"/></svg>'
        },
        8081: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path fill-rule="evenodd" clip-rule="evenodd" d="m8.003 10.289 5.617-6.557.76.65-6.377 7.444L1.62 4.383l.76-.651 5.623 6.557Z"/></svg>'
        },
        8706: function(t) {
            t.exports = '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" class="trustpilot-icon"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.94.94A1.5 1.5 0 0 1 10.5 2a20.774 20.774 0 0 1-.384 4H14.5A1.5 1.5 0 0 1 16 7.5v.066l-1.845 6.9-.094.095A1.5 1.5 0 0 1 13 15H9c-.32 0-.685-.078-1.038-.174-.357-.097-.743-.226-1.112-.349l-.008-.003c-.378-.126-.74-.246-1.067-.335C5.44 14.047 5.18 14 5 14v.941l-5 .625V6h5v.788c.913-.4 1.524-1.357 1.926-2.418A10.169 10.169 0 0 0 7.5 1.973 1.5 1.5 0 0 1 7.94.939ZM8 2l.498.045v.006l-.002.013a4.507 4.507 0 0 1-.026.217 11.166 11.166 0 0 1-.609 2.443C7.396 5.951 6.541 7.404 5 7.851V13c.32 0 .685.078 1.038.174.357.097.743.226 1.112.349l.008.003c.378.126.74.246 1.067.335.335.092.594.139.775.139h4a.5.5 0 0 0 .265-.076l1.732-6.479A.5.5 0 0 0 14.5 7H8.874l.138-.61c.326-1.44.49-2.913.488-4.39a.5.5 0 0 0-1 0v.023l-.002.022L8 2ZM4 7H1v7.434l3-.375V7Zm-1.5 5.75a.25.25 0 1 0 0-.5.25.25 0 0 0 0 .5Zm-.75-.25a.75.75 0 1 1 1.5 0 .75.75 0 0 1-1.5 0Z"/></svg>'
        }
    }
]);
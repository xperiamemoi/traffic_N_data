! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "0e8e9c91-d559-44d7-9ee7-616b7e2d7c99", e._sentryDebugIdIdentifier = "sentry-dbid-0e8e9c91-d559-44d7-9ee7-616b7e2d7c99")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9496], {
        79008: function(e, t, r) {
            "use strict";
            r.d(t, {
                mr: function() {
                    return u
                },
                Tm: function() {
                    return l
                }
            });
            var n = r(85893),
                i = r(67294),
                a = r(37575),
                s = r(71981);
            let o = (e, t) => {
                    let {
                        tracking: r
                    } = i.useContext(s.Il);
                    i.useEffect(() => {
                        e && !t && r.pageView("Own company profile")
                    }, [r, e, t])
                },
                c = i.createContext({
                    id: "",
                    identifyingName: "",
                    displayName: "",
                    numberOfReviews: 0,
                    trustScore: 0,
                    websiteUrl: "",
                    websiteTitle: "",
                    profileImageUrl: "",
                    stars: 0,
                    isB2BUserForCurrentBusiness: !1,
                    isClaimed: !1,
                    isClosed: !1,
                    consumerAlert: null,
                    consumerAlerts: [],
                    relevanceSortingEnabled: !1,
                    hasCollectedIncentivisedReviews: !1,
                    locationId: "",
                    hasBusinessUnitMergeHistory: !1,
                    hasUsedUnsupportedInvitationMethods: !1,
                    isUsingAIResponses: !1
                }),
                l = () => i.useContext(c),
                u = e => {
                    let {
                        children: t,
                        businessUnit: {
                            id: r,
                            displayName: i,
                            identifyingName: s,
                            numberOfReviews: l = 0,
                            trustScore: u = 0,
                            websiteUrl: d = "",
                            websiteTitle: m = "",
                            profileImageUrl: f = "",
                            stars: O = 0,
                            isClaimed: I = !1,
                            isClosed: v = !1,
                            consumerAlert: h = null,
                            consumerAlerts: R = [],
                            promotion: E,
                            hasHeaderBanner: _ = !1,
                            hideCompetitorModule: b = !1
                        },
                        identifyB2BUser: S = !1,
                        preventPageTracking: T = !1,
                        relevanceSortingEnabled: p = !1,
                        hasCollectedIncentivisedReviews: g = !1,
                        locationId: w = "",
                        hasBusinessUnitMergeHistory: C = !1,
                        hasUsedUnsupportedInvitationMethods: A = !1,
                        isUsingAIResponses: D = !1
                    } = e, y = (0, a.e)(r, S);
                    return o(y, T), (0, n.jsx)(c.Provider, {
                        value: {
                            id: r,
                            identifyingName: s,
                            displayName: i,
                            numberOfReviews: l,
                            trustScore: u,
                            websiteUrl: d,
                            websiteTitle: m,
                            profileImageUrl: f,
                            stars: O,
                            isB2BUserForCurrentBusiness: y,
                            isClaimed: I,
                            isClosed: v,
                            consumerAlert: h,
                            consumerAlerts: R,
                            relevanceSortingEnabled: p,
                            promotion: E,
                            hasHeaderBanner: _,
                            hideCompetitorModule: b,
                            hasCollectedIncentivisedReviews: g,
                            locationId: w,
                            hasBusinessUnitMergeHistory: C,
                            hasUsedUnsupportedInvitationMethods: A,
                            isUsingAIResponses: D
                        },
                        children: t
                    })
                }
        },
        99082: function(e, t, r) {
            "use strict";
            r.d(t, {
                i: function() {
                    return l
                }
            });
            var n = r(85893);
            r(67294);
            var i = r(38283),
                a = r(84676),
                s = r(65487),
                o = r(76722),
                c = r.n(o);
            let l = e => {
                let {
                    publishedDate: t,
                    reportedDate: r,
                    updatedDate: o,
                    className: l,
                    dataName: u
                } = e, d = [{
                    date: t,
                    actionPerformed: "published"
                }, {
                    date: r,
                    actionPerformed: "flagged"
                }, {
                    date: o,
                    actionPerformed: "updated"
                }].filter(e => !!e.date).sort((e, t) => new Date(t.date).getTime() - new Date(e.date).getTime());
                return 1 === d.length ? (0, n.jsx)(i.b, {
                    date: t,
                    className: l,
                    name: u
                }) : (0, n.jsx)(a.u, {
                    placement: "bottom",
                    trackingProps: {
                        name: "Review dates popover"
                    },
                    tooltipText: (0, n.jsx)("ol", {
                        className: c().dateList,
                        children: d.map((e, t) => (0, n.jsx)("li", {
                            className: c().dateItem,
                            children: (0, n.jsx)(s.ZT, {
                                variant: "body-m",
                                appearance: 0 === t ? "default" : "subtle",
                                children: (0, n.jsx)(i.b, { ...e
                                })
                            })
                        }, e.actionPerformed))
                    }),
                    children: (0, n.jsx)(i.b, {
                        date: d[0].date,
                        actionPerformed: d[0].actionPerformed,
                        className: l,
                        name: u
                    })
                })
            }
        },
        14209: function(e, t, r) {
            "use strict";
            r.d(t, {
                Z: function() {
                    return E
                }
            });
            var n = r(85893),
                i = r(67294),
                a = r(5152),
                s = r.n(a),
                o = r(94343),
                c = r(8075),
                l = r(36567),
                u = r(4359),
                d = r(65487),
                m = r(56847),
                f = r.n(m),
                O = r(19912),
                I = r(384),
                v = r.n(I);
            let h = i.forwardRef((e, t) => {
                    let {
                        onClick: r,
                        loading: i,
                        disabled: a
                    } = e, [s] = (0, o.T)();
                    return (0, n.jsxs)("button", {
                        ref: t,
                        className: (0, O.AK)(v().iconButton, a && v().disabled),
                        disabled: a,
                        onClick: r,
                        "aria-label": s["notifyingflow/flag-button-label"],
                        title: s["notifyingflow/flag-button-label"],
                        "data-report-review-button": !0,
                        children: [i ? (0, n.jsx)(l.$, {
                            size: 12
                        }) : (0, n.jsx)(u.J, {
                            name: "report",
                            content: f()
                        }), a && (0, n.jsx)(d.ZT, {
                            variant: "body-m",
                            className: v().alreadyFlagged,
                            children: (0, n.jsx)(c.x, {
                                id: "notifyingflow/already-flagged"
                            })
                        })]
                    })
                }),
                R = s()(() => Promise.all([r.e(5526), r.e(1600)]).then(r.bind(r, 8784)), {
                    loadableGenerated: {
                        webpack: () => [8784]
                    }
                });
            var E = e => {
                let {
                    reviewId: t,
                    reviewText: r,
                    reviewTitle: a,
                    highlightingEnabled: s,
                    onOpenHandler: o,
                    onCloseHandler: c,
                    onSubmit: l,
                    loading: u,
                    disabled: d,
                    isModalOpen: m,
                    businessUnitId: f,
                    businessUnitIdentifyingName: O,
                    businessLinkUrl: I,
                    hideViolationOptions: v,
                    disabledReasonsReasons: E = {}
                } = e, _ = i.useRef(null), [b, S] = i.useState(!1);
                return i.useEffect(() => {
                    var e;

                    function t() {
                        S(!0)
                    }
                    return null === (e = _.current) || void 0 === e || e.addEventListener("touchstart", t), () => {
                        var e;
                        null === (e = _.current) || void 0 === e || e.removeEventListener("touchstart", t)
                    }
                }, []), (0, n.jsxs)(n.Fragment, {
                    children: [(0, n.jsx)(h, {
                        ref: _,
                        onClick: o,
                        loading: u,
                        disabled: d
                    }), m && (0, n.jsx)(R, {
                        onSubmit: l,
                        onClose: c,
                        businessUnitId: f,
                        reviewId: t,
                        reviewText: r,
                        reviewTitle: a,
                        businessUnitIdentifyingName: O,
                        businessLinkUrl: I,
                        disabledReasonsReasons: E,
                        hideViolationOptions: v,
                        initiatedByTouch: b,
                        highlightingEnabled: s
                    })]
                })
            }
        },
        70189: function(e, t, r) {
            "use strict";
            var n, i;
            r.d(t, {
                J: function() {
                    return n
                }
            }), (i = n || (n = {})).IncludesPromotionalCodeOrDiscountCode = "INCLUDES_PROMOTIONAL_CODE_OR_DISCOUNT_CODE", i.PromotesAnotherBusinessOrUnrelatedProduct = "PROMOTES_ANOTHER_BUSINESS_OR_UNRELATED_PRODUCT", i.PromotesScam = "PROMOTES_SCAM", i.Other = "OTHER"
        },
        28488: function(e, t, r) {
            "use strict";
            var n, i;
            r.d(t, {
                Z: function() {
                    return n
                }
            }), (i = n || (n = {})).WrittenByEmployeeOrCompetitor = "WRITTEN_BY_EMPLOYEE_OR_COMPETITOR", i.PaidReviewer = "PAID_REVIEWER", i.CopyPaste = "COPY_PASTE", i.SuspiciousPattern = "SUSPICIOUS_PATTERN", i.Other = "OTHER"
        },
        423: function(e, t, r) {
            "use strict";
            var n, i;
            r.d(t, {
                w: function() {
                    return n
                }
            }), (i = n || (n = {})).HateSpeechOrDiscrimination = "HATE_SPEECH_OR_DISCRIMINATION", i.Terrorism = "TERRORISM", i.ThreatsOrViolence = "THREATS_OR_VIOLENCE", i.Obscene = "OBSCENE"
        },
        91638: function(e, t, r) {
            "use strict";
            var n, i;
            r.d(t, {
                t: function() {
                    return n
                }
            }), (i = n || (n = {})).Start = "START", i.ViolationSelector = "VIOLATION_SELETOR", i.HarmfulOrIllegal = "HARMFUL_OR_ILLEGAL", i.HateSpeechOrDiscriminationDisclaimer = "HATE_SPEECH_OR_DISCRIMINATION_DISCLAIMER", i.TerrorismDisclaimer = "TERRORISM_DISCLAIMER", i.ThreatsOrViolenceDisclaimer = "THREATS_OR_VIOLENCE_DISCLAIMER", i.ObsceneDisclaimer = "OBSCENE_DISCLAIMER", i.AdvertisingOrPromotional = "ADVERTISING_OR_PROMOTIONAL", i.AdvertisingOrPromotionalDisclaimer = "ADVERTISING_OR_PROMOTIONAL_DISCLAIMER", i.SensitiveInformationDisclaimer = "SENSITIVE_INFORMATION_DISCLAIMER", i.Highlight = "HIGHLIGHT", i.Fabricated = "FABRICATED", i.FabricatedDisclaimer = "FABRICATED_DISCLAIMER", i.FabricatedOnlyOnce = "FABRICATED_ONLY_ONCE", i.Sign = "SIGN", i.ThankYou = "THANK_YOU"
        },
        65541: function(e, t, r) {
            "use strict";
            var n, i;
            r.d(t, {
                i: function() {
                    return n
                }
            }), (i = n || (n = {})).HarmfulOrIllegal = "HARMFUL_OR_ILLEGAL", i.AdvertisingOrPromotional = "ADVERTISING_OR_PROMOTIONAL", i.SensitiveInformation = "SENSITIVE_INFORMATION", i.Fabricated = "FABRICATED"
        },
        25810: function(e, t, r) {
            "use strict";
            r.d(t, {
                E: function() {
                    return o
                }
            });
            var n = r(70189),
                i = r(28488),
                a = r(423),
                s = r(65541);

            function o(e) {
                switch (e) {
                    case s.i.SensitiveInformation:
                        return {
                            reason: "sensitiveInformation"
                        };
                    case n.J.IncludesPromotionalCodeOrDiscountCode:
                        return {
                            reason: "marketingOrSpam",
                            comment: "It includes a promotional or discount code"
                        };
                    case n.J.PromotesAnotherBusinessOrUnrelatedProduct:
                        return {
                            reason: "marketingOrSpam",
                            comment: "Its purpose is not to help consumers, but to promote another business or an unrelated product"
                        };
                    case n.J.PromotesScam:
                        return {
                            reason: "marketingOrSpam",
                            comment: "It promotes another service that’s probably a scam e.g. cryptocurrency investment, hacker services, etc."
                        };
                    case n.J.Other:
                        return {
                            reason: "marketingOrSpam",
                            comment: "Other"
                        };
                    case a.w.HateSpeechOrDiscrimination:
                        return {
                            reason: "harmfulOrIllegalContentHateSpeechOrDiscrimination"
                        };
                    case a.w.Terrorism:
                        return {
                            reason: "harmfulOrIllegalContentTerrorism"
                        };
                    case a.w.ThreatsOrViolence:
                        return {
                            reason: "harmfulOrIllegalContentThreatsOrViolence"
                        };
                    case a.w.Obscene:
                        return {
                            reason: "harmfulOrIllegalContentObscene"
                        };
                    case i.Z.WrittenByEmployeeOrCompetitor:
                        return {
                            reason: "fabricatedReview",
                            comment: "The review was written by an employee or a competitor"
                        };
                    case i.Z.SuspiciousPattern:
                        return {
                            reason: "fabricatedReview",
                            comment: "The pattern of reviews for this company is suspicious"
                        };
                    case i.Z.PaidReviewer:
                        return {
                            reason: "fabricatedReview",
                            comment: "The reviewer was paid to write this review"
                        };
                    case i.Z.CopyPaste:
                        return {
                            reason: "fabricatedReview",
                            comment: "It’s a copy/paste of another review"
                        };
                    case i.Z.Other:
                        return {
                            reason: "fabricatedReview",
                            comment: "Other"
                        }
                }
            }
        },
        89217: function(e, t, r) {
            "use strict";
            r.d(t, {
                DQ: function() {
                    return o
                },
                Fe: function() {
                    return s
                },
                ns: function() {
                    return a
                }
            });
            var n = r(91638),
                i = r(65541);

            function a(e) {
                return (e.violation || "").toLocaleLowerCase()
            }

            function s(e) {
                switch (e.violation) {
                    case i.i.AdvertisingOrPromotional:
                        return (e.advertisingOrPromotionalReason || "").toLocaleLowerCase();
                    case i.i.HarmfulOrIllegal:
                        return (e.harmfulOrIllegalReason || "").toLocaleLowerCase();
                    case i.i.SensitiveInformation:
                    default:
                        return ""
                }
            }

            function o(e) {
                var t;
                return {
                    step: null !== (t = function(e) {
                        switch (e.currentStep) {
                            case n.t.Start:
                                return "i-am-consumer";
                            case n.t.ViolationSelector:
                                return "reason-selected";
                            case n.t.HarmfulOrIllegal:
                                return "subreason-selected";
                            case n.t.AdvertisingOrPromotional:
                            case n.t.SensitiveInformationDisclaimer:
                            case n.t.AdvertisingOrPromotionalDisclaimer:
                            case n.t.ObsceneDisclaimer:
                            case n.t.HateSpeechOrDiscriminationDisclaimer:
                            case n.t.TerrorismDisclaimer:
                            case n.t.ThreatsOrViolenceDisclaimer:
                                return "education";
                            case n.t.Highlight:
                                return "highlight";
                            case n.t.Sign:
                                return "submit";
                            case n.t.ThankYou:
                                return "success"
                        }
                    }(e)) && void 0 !== t ? t : "",
                    reason: a(e),
                    subreason: s(e)
                }
            }
        },
        56479: function(e, t, r) {
            "use strict";
            r.d(t, {
                v: function() {
                    return s
                }
            });
            var n = r(85893),
                i = r(25935);
            r(67294);
            var a = r(85124);
            let s = e => {
                let {
                    children: t,
                    withLineBreaks: r,
                    escapeHTML: s,
                    withEmphasis: o
                } = e, c = t;
                return c = s ? (0, a.r)(c) : c, c = r ? (0, a.zc)(c) : c, c = o ? (0, a.eI)(c) : c, (0, n.jsx)(n.Fragment, {
                    children: (0, i.ZP)(c)
                })
            }
        },
        37575: function(e, t, r) {
            "use strict";
            r.d(t, {
                e: function() {
                    return d
                }
            });
            var n = r(67294),
                i = r(47193),
                a = r(11752),
                s = r.n(a),
                o = r(23181);
            let {
                trustpilotApiHost: c
            } = s()().publicRuntimeConfig, l = () => (0, o.e)("tp-b2b-access-token");
            async function u(e, t) {
                let r = l();
                if (!r) return !1;
                let n = async e => await (await t("".concat(c).concat(e), {
                    headers: {
                        Authorization: "Bearer ".concat(r)
                    }
                })).json();
                try {
                    let {
                        businessUser: t
                    } = await n("/v1/private/me"), {
                        businessUnits: r
                    } = await n("/v1/private/business-users/".concat(t.id, "/business-units"));
                    return r.some(t => {
                        let {
                            id: r
                        } = t;
                        return r === e
                    })
                } catch (e) {
                    return !1
                }
            }
            let d = (e, t) => {
                let {
                    fetch: r
                } = (0, i.i)(), [a, s] = n.useState(!1), [o, c] = n.useState(!1);
                return n.useEffect(() => {
                    async function n() {
                        c(await u(e, r)), s(!0)
                    }
                    t && !a && n()
                }, [e, t, a, r]), o
            }
        },
        66522: function(e, t, r) {
            "use strict";

            function n(e) {
                var t, r;
                return null !== (r = null == e ? void 0 : null === (t = e.reasons) || void 0 === t ? void 0 : t.some(e => null == e ? void 0 : e.toLowerCase().includes("harmfulorillegal"))) && void 0 !== r && r
            }

            function i(e) {
                return (null == e ? void 0 : e.reviewVisibility) === "hidden"
            }
            r.d(t, {
                J: function() {
                    return i
                },
                c: function() {
                    return n
                }
            })
        },
        76722: function(e) {
            e.exports = {
                dateList: "styles_dateList__A_MZx",
                dateItem: "styles_dateItem__S4260"
            }
        },
        384: function(e) {
            e.exports = {
                iconButton: "styles_iconButton__Sr5FD",
                disabled: "styles_disabled__aoyYp",
                alreadyFlagged: "styles_alreadyFlagged__z4wlr"
            }
        }
    }
]);
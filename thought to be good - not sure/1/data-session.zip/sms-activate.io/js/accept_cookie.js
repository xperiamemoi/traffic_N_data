function setCookie(el) {
    win = $(el).parents('.acceptCookieNotice')[0];
    cookiewin.classList.remove('show');
    let cookieValue = '',
        type = el.getAttribute('data-type'),
        expire = 120;


    if (type == 'selected') {
        win.querySelectorAll(".checkbox__input:checked").forEach(function(c) {
            cookieValue += c.getAttribute("value") + "_";

        });
        cookieValue = cookieValue.substring(0, cookieValue.length - 1);

    } else if (type == 'no') {
        cookieValue = 'no';
        expire = 3;

    } else
        cookieValue = 'all';


    let date = new Date;
    date.setDate(date.getDate() + expire);
    document.cookie = "accept_cookie=" + cookieValue + "; path=/; expires=" + date.toUTCString();
}
let cookieWins = document.getElementsByClassName('acceptCookieNotice'),
    accept_cookie = getCookie("accept_cookie"),
    cookiewin = cookieWins[0];


document.addEventListener("DOMContentLoaded", () => {
    if (accept_cookie == undefined) {
        cookiewin.classList.add('show');

        document.querySelectorAll(".cookie_close").forEach(function(el) {
            el.addEventListener('click', () => {
                setCookie(el)
            });
        });

    }
})
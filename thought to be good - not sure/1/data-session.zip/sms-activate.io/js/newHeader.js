const newHeader = {
    MAX_RANK: 10,

    userBtn: document.querySelector('#userSetting'),
    userDetails: document.querySelector('.user__details'),
    menuBtn: document.querySelector(".newHeader__mobile-menu.mobile-burger"),
    asideBtn: document.querySelector(".newHeader__mobile-menu.aside-menu"),
    tabletMenuWrapper: document.querySelectorAll(".newHeader__tablet-menu-wrapper"),
    header: document.querySelector(".newHeader"),
    apiBox: document.querySelector('#darkBoxMain'),
    userRankInfo: document.querySelector('#userRankInfo'),

    langSelect: document.querySelectorAll('.newHeader__lang.select-lang'),

    logout: document.querySelector('.user__enter .user__logout'),
    modalEnter: document.querySelector('#myModal'),
    copy: document.querySelectorAll('[data-copy]'),

    registration: document.querySelector('.user__enter .user__registration'),
    leftMenu: document.querySelector('.left-menu'),
    aside: document.querySelector('#newLeft'),
    asideApi: document.querySelector('.aside.api__aside'),

    body: document.querySelector('body'),
    wrapper: document.querySelector('.wrapper'),

    spollers: document.querySelectorAll('[data-spollers]'),

    openModalLogoutOrRegistration: function(nameBody) {
        const modalBody = this.modalEnter.querySelectorAll('.modal-body .display')
        const body = this.modalEnter.querySelector(`.modal-body [${nameBody}]`)
        const title = this.modalEnter.querySelector('#myModalLabel')
        const lang = document.querySelector("html").getAttribute("lang")

        const langTitle = {
            logout: {
                en: 'Login',
                ru: 'Вход',
                es: 'INICIAR SESIÓN',
                cn: "登录",

            },
            registration: {
                en: "Registration",
                ru: 'Регистрация',
                es: 'REGISTRO',
                cn: "注册",
            }
        }

        const changeTitle = function(nameBody) {
            title.innerHTML = langTitle[nameBody][lang]
        }

        changeTitle(nameBody);
        modalBody.forEach(function(body) {
            body.classList.contains('hide') ? null : body.classList.add('hide');
        })

        body.classList.remove('hide')

    },

    langChange: function(params) {
        Cache.unset('serviceCache')
        Cache.unset('servicesCached')

        fetch("/api/api.php?act=changeLang&lang=" + params.lang + "&csrf=" + $("#csrf").val())
            .then(response => {
                window.location = params.langHref
            }).catch(() => {
                window.location = params.langHref
            })
    },


    copyId: function(text) {
        if (!navigator.clipboard) {
            newHeader.fallbackCopyTextToClipboard(text);
            return;
        }
        navigator.clipboard.writeText(text).then(function() {
            globalAlert(_('Id скопирован'))
        }, function(err) {
            console.error('Async: Could not copy text: ', err);
        });
    },
    fallbackCopyTextToClipboard: function(text) {
        let textArea = document.createElement("textarea");
        textArea.value = text;

        // Avoid scrolling to bottom
        textArea.style.top = "0";
        textArea.style.left = "0";
        textArea.style.position = "fixed";

        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
            let successful = document.execCommand('copy');
            let msg = successful ? 'successful' : 'unsuccessful';
            globalAlert(_('Id скопирован'))
        } catch (err) {
            console.error('Fallback: Oops, unable to copy', err);
        }

        document.body.removeChild(textArea);
    },
    toggleShow: function(block) {
        block.classList.toggle('isShow');
    },
    removeClassList: function(block) {
        if (block.classList.contains('lock')) block.classList.remove('lock')
    },
    changeLangValue: function(params) {
        const select = params.container
        const langSelectTitle = select.querySelector('.select-lang__title')

        const langSelectContent = select.querySelector('.select-lang__list')
        const langSelectTitleImage = langSelectTitle.querySelector('img')
        const langSelectTitleLang = langSelectTitle.querySelector('.select-lang__title-lang')

        langSelectTitleImage.src = params.img
        langSelectTitleLang.innerHTML = params.langText
        langSelectContent.classList.remove('isShow')

        newHeader.langChange(params)
    },
    addListener: function() {
        if (this.userBtn) {
            this.userBtn.addEventListener('click', function() {
                newHeader.toggleShow(newHeader.userDetails)
            })
        }
        if (this.menuBtn) {
            this.menuBtn.addEventListener('click', function() {
                newHeader.toggleShow(newHeader.leftMenu)
                newHeader.toggleShow(newHeader.menuBtn)
                newHeader.body.classList.toggle('lock')
            })
        }
        if (this.asideBtn) {
            this.asideBtn.addEventListener('click', function() {
                newHeader.aside = document.querySelector('#newLeft')
                newHeader.aside ? newHeader.toggleShow(newHeader.aside) : newHeader.toggleShow(newHeader.asideApi)
                newHeader.toggleShow(newHeader.asideBtn)
                newHeader.body.classList.toggle('lock')
            })
        }
        if (newHeader.asideApi) {
            const apiLink = newHeader.asideApi.querySelectorAll('a')
            apiLink.forEach(link => {
                link.addEventListener('click', function() {
                    if (!link.closest('.accordion-toggle')) {
                        newHeader.toggleShow(newHeader.asideApi)
                        newHeader.toggleShow(newHeader.asideBtn)
                        newHeader.removeClassList(newHeader.body)
                    }
                })

            })
        }
        if (this.copy) {
            newHeader.copy.forEach(function(copyBtn) {
                copyBtn.addEventListener('click', function() {
                    const text = copyBtn.querySelector('[data-copy-text]').innerHTML
                    newHeader.copyId(text)
                })
            })
        }
        if (this.tabletMenuWrapper) {
            newHeader.tabletMenuWrapper.forEach(function(wrapper) {
                const btn = wrapper.querySelector(".newHeader__tablet-menu-btn")
                const menu = wrapper.querySelector(".newHeader__tablet-menu-list")

                btn.addEventListener("click", function() {
                    menu.classList.toggle('isActive')
                    btn.classList.toggle('isActive')

                })
            })
        }
        if (window.location.pathname == "/api2") {
            window.addEventListener('scroll', function() {
                const headerVisible = newHeader.header.getBoundingClientRect().top + newHeader.header.clientHeight
                headerVisible > 0 ? document.querySelector('#darkBoxMain').style.top = headerVisible + 'px' : document.querySelector('#darkBoxMain').style.top = '0'
            })
        }
        if (this.langSelect ? .length > 0) {
            newHeader.langSelect.forEach(select => {
                const langtSelectTitle = select.querySelector('.select-lang__title')

                const allLangs = []

                const langtSelectContent = select.querySelector('.select-lang__list')
                const langtSelectOptionsBtn = langtSelectContent.querySelectorAll('.select-lang__item')

                langtSelectTitle.addEventListener('click', function() {
                    langtSelectContent.classList.toggle('isShow')
                })
                langtSelectOptionsBtn.forEach(function(btn) {
                    allLangs.push(btn.getAttribute('data-value'))
                    btn.addEventListener('click', function() {
                        let img = this.querySelector("img")
                        let lang = this.querySelector('.select-lang__option-lang')

                        const params = {
                            langText: lang.textContent,
                            img: img.src,
                            container: select,
                            langHref: btn.getAttribute('data-href'),
                            lang: btn.getAttribute('data-value')
                        }

                        let currentLang = getCookie('lang'),
                            referrer = getCookie('ref'),
                            isRequireVPN = currentLang == 'ru' && params.lang !== 'ru',
                            isDomainChanging = isRequireVPN || currentLang != 'ru' && params.lang == 'ru'

                        if (referrer && isDomainChanging) {
                            params.langHref += `?ref=${referrer}`
                        }

                        if (isRequireVPN) {
                            bus.$emit('open-change-lang-info-modal', params)
                            return langtSelectContent.classList.remove('isShow')
                        } else {
                            newHeader.changeLangValue(params)
                        }

                    })
                })
            })
        }
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.user__setting') && !e.target.closest('.user__details') && newHeader.userDetails.classList.contains('isShow')) {
                newHeader.userDetails.classList.remove('isShow');
            }
        })
        window.addEventListener('resize', newHeader.addHeightLeftMenu)
    },
    spollersInit: function() {
        this.spollers.forEach(spoller => {
            const butons = spoller.querySelectorAll('[data-spollers-btn]')
            const content = spoller.querySelectorAll('[data-spollers-content]')

            const removeActive = function(elem) {
                elem.forEach(function(e) {
                    e.classList.remove('isActive');
                    e.style.height = '';
                })
            }

            butons.forEach(function(btn, index) {
                btn.addEventListener('click', function() {
                    if (btn.classList.contains('isActive')) {
                        btn.classList.remove('isActive')
                        content[index].style.height = "";
                        content[index].classList.remove('isActive')


                    } else {
                        removeActive(butons);
                        removeActive(content);
                        content[index].style.height = content[index].scrollHeight + 'px'
                        btn.classList.add('isActive')
                        content[index].classList.add('isActive')

                    }

                })
            })

        })
    },
    checkApi2Page: function() {
        if (window.location.pathname == "/api2") {
            newHeader.wrapper.classList.add('api-page')
        }
    },
    initializeModalOpeners: function() {
        const modalOpeners = document.querySelectorAll('[data-toggle="modal"][data-v-modal]');
        modalOpeners.forEach((opener) => {
            if (opener.dataset.modalInitialized) return
            opener.dataset.modalInitialized = true;
            opener.addEventListener('click', (e) => {
                const modalName = opener.dataset.vModal;
                window[modalName].openModal();
            });
        });
    },
    addHeightLeftMenu: function() {
        if (newHeader.leftMenu) {
            newHeader.leftMenu.style.height = document.documentElement.clientHeight - newHeader.header.offsetHeight + 'px';
        }
    },
    getHeaderHeight: function() {
        if (newHeader.header) {
            return newHeader.header.offsetHeight
        }
    },
    setOneVh: function() {
        newHeader.body.style.setProperty('--vh', window.innerHeight * 0.01 + 'px')
    },
    setHeaderHightProperty: function() {
        if (newHeader.header) {
            newHeader.body.style.setProperty('--header-height', newHeader.getHeaderHeight() + 'px')
        }
        if (newHeader.aside) {
            newHeader.aside.style.display = 'block';
        }
    },
    getUserRankInfo: function() {
        if (newHeader.userRankInfo) {
            let currentRank = getRank() > newHeader.MAX_RANK ? getRank() - newHeader.MAX_RANK : getRank()
            currentRank = currentRank ? _('Ранг: ') + currentRank : _('Нет ранга');
            newHeader.userRankInfo.innerHTML = currentRank
        }
    },
    init: function() {
        this.getUserRankInfo()
        this.spollersInit()
        this.setOneVh()
        this.checkApi2Page()
        this.setHeaderHightProperty()
        document.addEventListener('DOMContentLoaded', () => {
            this.addHeightLeftMenu()
            this.addListener()
            newHeader.initializeModalOpeners()
            const observer = new MutationObserver(newHeader.initializeModalOpeners)
            observer.observe(document, {
                childList: true,
                subtree: true
            })
        });
        bus.$on('modal-change-lang', (params) => {
            newHeader.changeLangValue(params)
        })
    }
}

let headerListener = new ResizeObserver(newHeader.setHeaderHightProperty)

newHeader.init()
if (newHeader.header) headerListener.observe(newHeader.header)
window.addEventListener('resize', newHeader.setOneVh)
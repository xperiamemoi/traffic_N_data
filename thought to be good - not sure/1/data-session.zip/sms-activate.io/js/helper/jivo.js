function createJivoScript() {
    return new Promise((resolve, reject) => {
        let jivoId = document.getElementById("jivo-widget-id") ? .value;
        let el = document.createElement("script");
        el.src = `https://code-ya.jivosite.com/widget/${jivoId}`;
        el.type = "text/javascript";
        window.jivo_onLoadCallback = function jivo_onLoadCallback() {
            const jivo_custom_widget = true;
            resolve();
        };
        document.body.appendChild(el);
    });
}

async function sendUserDataToJivo() {
    jivo_api.setContactInfo({
        'email': document.querySelector('#userEmail').value
    })
    let params = [{
            'content': getCookie('userid'),
            'key': 'user_id',
            'title': 'ID пользователя'
        },
        {
            'content': getRank().toString(),
            'key': 'rank',
            'title': 'Ранг'
        },
    ];

    let income = await getIncomeForLastPeriod()
    if (income) {
        params.push({
            'content': income.sum + ' ' + getCurrency(income.currency),
            'key': 'income_sum',
            'title': 'Сумма пополнений за последний период'
        })
    }

    jivo_api.setCustomData(params)
}
const addJivoScript = () => {
    let wrapper = document.querySelector(".jivo-widget");
    let btn = document.querySelector(".jivo-widget__main-btn");
    let menuBtn = document.querySelectorAll(".jivo-widget__menu-btn");

    if (menuBtn.length > 0) {
        menuBtn.forEach((btn) => {
            btn.addEventListener("click", async () => {
                let clickedId = btn.getAttribute("id") || "unknown";

                let eventName = '';
                switch (clickedId) {
                    case 'openTgSupport':
                        eventName = isAuth() ? 'jivo_telegram_authorized' : 'jivo_telegram_unauthorized';
                        break;
                    case 'openJivoBtn':
                        eventName = isAuth() ? 'jivo_chat_inside_authorized' : 'jivo_chat_inside_unauthorized';
                        break;
                }

                pushGoogleAnalyicsEvent(eventName);

                wrapper.classList.remove("isActive");
                if (clickedId === "openJivoBtn") {
                    wrapper.classList.add("hidden");
                    jivo_api.open();
                }
            });
        });
    }

    if (btn) {
        btn.addEventListener("click", () => {
            wrapper.classList.toggle("isActive");

            const isActive = wrapper.classList.contains("isActive");

            if (isActive) {
                const eventName = isAuth() ? 'jivo_chat_click_authorized' : 'jivo_chat_click_unauthorized';
                pushGoogleAnalyicsEvent(eventName);
            }
        });
    }

    window.jivo_onClose = function jivo_onClose() {
        wrapper.classList.remove("hidden");
    };
    // При отправке формы с данными пользователя
    window.jivo_onIntroduction = async function jivo_onIntroduction() {
        if (isAuth()) {
            await sendUserDataToJivo()
        }
    }

    // При первом сообщении от клиента
    window.jivo_onClientStartChat = async function jivo_onClientStartChat() {
        if (isAuth()) {
            await sendUserDataToJivo()
        }
    }
};
window.addEventListener("load", (e) => {
    if (document.querySelector(".jivo-widget")) {
        setTimeout(() => {
            createJivoScript().then(() => {
                if (isJivoJiv()) document.querySelector(".jivo-widget").classList.remove("hidden");
                addJivoScript();
            }, 5000);
        })
    }
});
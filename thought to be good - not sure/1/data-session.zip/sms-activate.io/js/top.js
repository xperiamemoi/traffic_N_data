let getBalance = function() {}

$(document).ready(function() {
    const BALANCE_PERIOD = 40000,
        BALANCE_RETRY = 4000

    let authed = isAuth(),
        csrf = document.querySelector("#csrf").value,
        interval_getBalance = 0,
        wait_balance = false

    function setIntervalBalance() {
        clearInterval(interval_getBalance)
        interval_getBalance = setInterval(getBalance, BALANCE_PERIOD, true)
    }

    function setBalance(balance, cashback, purchases, totals = false) {
        document.querySelector('.balance').innerHTML = `${balance} ${CURRENCY_ICO} <span class="caret"></span>`
        document.querySelector('.cashBackBalans').innerHTML = cashback

        if (!objEmpty(purchases)) {
            for (let name in purchases) {
                let elem = $('.newHeadLink[href="/' + name + '"]').children('.activePurchasesInfo');

                if (purchases[name] > 0) {
                    elem.html(purchases[name]).css({
                        'font-weight': 'bold',
                        display: 'block'
                    });

                    continue;
                }

                elem.empty().css({
                    display: "none"
                });
            }

            return;
        }

        if (totals) {
            $('.newHeadLink .activePurchasesInfo').empty().css({
                display: "none"
            });
        }
    }

    function setBalanceCache(balance, cashback, purchases, totals) {
        let purchasesStr = ''

        if (!totals) {
            let cache = Cache.get('balance')
            purchasesStr = cache ? cache.split(';')[2] : '';
        } else purchasesStr = Object.values(purchases).join()

        let str = [balance, cashback, purchasesStr, (new Date()).getTime(), 1].join(';')
        Cache.set('balance', str)
    }

    function updBalanceCacheStatus(status) {
        let cache = Cache.get('balance')

        if (!cache) return;

        cache = cache.substring(0, cache.length - 1) + status
        Cache.set('balance', cache)
    }

    function checkBalanceCache() {
        let cache = Cache.get('balance')

        if (cache) {
            let [balance, cashback, purchasesStr, lastDate, status] = cache.split(';'),
                now = (new Date()).getTime()

            if (now - safeNum(lastDate) < BALANCE_PERIOD) {
                let purchases = {},
                    purchasesArr = purchasesStr.split(',')

                purchases.getNumber = purchasesArr[0]
                purchases.rent = purchasesArr[1]

                setBalance(balance, cashback, purchases, true)
                return true;
            }

            if (status == 2) {
                clearInterval(interval_getBalance)

                setTimeout(function() {
                    getBalance()
                    setIntervalBalance()
                }, BALANCE_RETRY)

                return true;
            }
        }

        return false;
    }

    getBalance = function(totals = false, force = false) {
        if (!force && checkBalanceCache()) return;

        clearInterval(interval_getBalance)
        updBalanceCacheStatus(2)
        wait_balance = true

        $.ajax({
            url: '/api/api.php',
            type: 'POST',
            dataType: "json",
            data: {
                act: "getBalance",
                csrf: csrf,
                totals: totals
            },
            success: function(data) {
                setIntervalBalance()

                if (data.status !== 'success') {
                    updBalanceCacheStatus(1)
                    wait_balance = false
                    return;
                }

                let balance = safeNum(data.balance),
                    cashback = safeNum(data.cashbackBalance)

                setBalanceCache(balance, cashback, [data.purchases.getNumber, data.purchases.rent], totals)
                setBalance(balance, cashback, data.purchases, totals)
                wait_balance = false
            },
            error: function() {
                updBalanceCacheStatus(1)
            }
        })
    }

    window.addEventListener('beforeunload', function() {
        if (wait_balance) updBalanceCacheStatus(1)
    })

    if (authed) setIntervalBalance()
    else Cache.unset('balance')

    for (let m of document.querySelectorAll(".modal")) document.body.appendChild(m)

    if ($.fn.dataTable) $.fn.dataTable.ext.errMode = 'none'

    $('body').on('error.dt', 'table', function(e, $dataTable) {
        let table = e.currentTarget,
            colsCount = table.querySelector('thead tr').childElementCount,
            error = $dataTable.jqXHR ? .responseText

        if (!error) return;

        let msg = SaApiErr(error)

        table.querySelector('tbody').innerHTML = `<tr><td colspan='${colsCount}' class='text-center' style='font-size:1rem'>${msg}</td></tr>`;
    })

    let appHref = 'https://play.google.com/store/apps/details?id=ru.startandroid.smsactivate',
        banners = 'https://smsactivate.s3.eu-central-1.amazonaws.com/assets/img/banners/main/',
        appImg = 'main',
        lang = getCookie('lang')
    appLang = lang,
        iosHref = 'https://apps.apple.com/ru/app/smsactivate-%D0%B2%D0%B8%D1%80%D1%82%D1%83%D0%B0%D0%BB%D1%8C%D0%BD%D1%8B%D0%B5-%D0%BD%D0%BE%D0%BC%D0%B5%D1%80%D0%B0/id1584333244'
    if (appLang == 'es') appLang = 'en'
    if (isApple()) {
        appHref = iosHref
        appImg = 'ios'
    }
    let s = document.querySelector('#mslider-mobapp')
    if (s) {
        s.querySelector('a').href = appHref
        s.querySelector('img').src = banners + appImg + '_' + appLang + '.webp'
    }

    const requiredModal = new URLSearchParams(location.search).get('modal')
    switch (requiredModal) {
        case 'modalUserRefOut':
            document.getElementById('referralMoneyOut').click()
            break
    }
});

window.onbeforeunload = function() {
    $.removeCookie("firstOpen");
};
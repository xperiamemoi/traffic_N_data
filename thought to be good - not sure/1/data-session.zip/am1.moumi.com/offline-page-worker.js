! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            n = (new Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "9d56bd59-d216-4d36-8abd-713ed2ee9627", e._sentryDebugIdIdentifier = "sentry-dbid-9d56bd59-d216-4d36-8abd-713ed2ee9627")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        "use strict";
        var e = {
                offline: "offline-page-v".concat(1)
            },
            n = "/offline";
        self.addEventListener("install", (function(t) {
            self.skipWaiting(), t.waitUntil(caches.open(e.offline).then((function(e) {
                return e.add(n)
            })))
        })), self.addEventListener("activate", (function(n) {
            var t = [e.offline];
            n.waitUntil(caches.keys().then((function(e) {
                return Promise.all(e.filter((function(e) {
                    return !t.includes(e)
                })).map((function(e) {
                    return caches.delete(e)
                })))
            })))
        })), self.addEventListener("fetch", (function(e) {
            ("navigate" === e.request.mode || "GET" === e.request.method && e.request.headers.get("accept").includes("text/html")) && e.respondWith(fetch(e.request).catch((function() {
                return caches.match(n)
            })))
        }))
    }();
//# sourceMappingURL=offline-page-worker.f6cd800cecbcd6414f47.js.map
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "227f7714-4f1b-46a1-ab74-90045077704e", e._sentryDebugIdIdentifier = "sentry-dbid-227f7714-4f1b-46a1-ab74-90045077704e")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        "use strict";
        var e;
        e = {
            bma: {
                ClientSource: {
                    CLIENT_SOURCE_UNSPECIFIED: 0
                }
            }
        }.bma.ClientSource, self.addEventListener("install", (function(e) {
            e.waitUntil(self.skipWaiting())
        })), self.addEventListener("activate", (function(e) {
            e.waitUntil(self.clients.claim())
        })), self.addEventListener("message", (function(e) {
            e.data && e.data.isTWA && self.indexedDB && function(e) {
                new Promise((function(t) {
                    var n = self.indexedDB.open("MOUMI_TWA", 1);
                    n.onupgradeneeded = function(e) {
                        e.target.result.createObjectStore("flags", {
                            keyPath: "flag"
                        })
                    }, n.onsuccess = function(n) {
                        var o = n.target.result.transaction("flags", "readwrite").objectStore("flags");
                        for (var i in e) o.put({
                            flag: i,
                            value: e[i]
                        });
                        t(e)
                    }, n.onerror = function() {
                        t(!1)
                    }
                }))
            }({
                isTWA: !0,
                twaVersion: e.data.twaVersion ? e.data.twaVersion : "-1"
            })
        })), self.addEventListener("push", (function(t) {
            if (t.data) {
                var n = t.data.json();
                t.waitUntil(function(t) {
                    var n = t.redirect_page,
                        o = "/push/".concat(t.push_id, "/").concat(n.redirect_page);
                    switch (n.user_id && (o += "/".concat(n.user_id)), t.call_id && (n.callId = t.call_id, o += "/".concat(t.call_id)), n.redirect_page) {
                        case e.CLIENT_SOURCE_EXTERNAL_WEB:
                        case e.CLIENT_SOURCE_EMBEDDED_WEB:
                            o += "?url=".concat(encodeURIComponent(n.url))
                    }
                    t.photo_url && (t.photo_url = t.photo_url.replace("http://", "https://"));
                    var i = {
                        body: t.body,
                        icon: t.photo_url,
                        data: {
                            url: o,
                            notification: t
                        },
                        tag: t.tag
                    };
                    return ["moumi.com", "moumi.eu", "moumi.us", "moumi.d3"].some((function(e) {
                        return -1 !== location.origin.indexOf(e)
                    })) && (i.badge = "https://moumicdn.com/i/big/mobileweb/moumi-icon-black.png"), self.registration.showNotification(t.title, i)
                }(n))
            } else console.error("PushNotificationsWorker: chrome<50 is not supported")
        })), self.addEventListener("notificationclick", (function(e) {
            function t(e, t, n) {
                e.postMessage(self.JSON.stringify({
                    url: t,
                    notification: n
                }))
            }

            function n(e) {
                return self.clients.openWindow(e)
            }

            function o(e, o, i, a) {
                return self.clients.matchAll({
                    type: "window",
                    includeUncontrolled: !0
                }).then((function(e) {
                    if (a) return n(o);
                    var r = e.filter((function(e) {
                        return "nested" !== e.frameType
                    }));
                    if (0 === r.length) return n(o);
                    var c = r[0];
                    return c.focus().then(t.bind(null, c, o, i)).catch(n.bind(null, o))
                }))
            }
            e.notification.close();
            var i, a, r = e.notification.data,
                c = r.url,
                s = r.notification;
            self.indexedDB ? e.waitUntil((i = "isTWA", a = new Promise((function(e) {
                var t = self.indexedDB.open("MOUMI_TWA", 1);
                t.onupgradeneeded = function(e) {
                    e.target.result.createObjectStore("flags", {
                        keyPath: "flag"
                    })
                }, t.onsuccess = function(t) {
                    var n = t.target.result.transaction("flags", "readwrite").objectStore("flags").get(i);
                    n.onsuccess = function(t) {
                        t.target.result && t.target.result.value ? e(t.target.result.value) : e(!1)
                    }, n.onerror = function() {
                        e(!1)
                    }
                }, t.onerror = function() {
                    e(!1)
                }
            })), a).then((function(e) {
                return o(0, c, s, e)
            }))) : e.waitUntil(o(0, c, s, !1))
        }))
    }();
//# sourceMappingURL=serviceworker.ff87efb0b9fc80638616.js.map
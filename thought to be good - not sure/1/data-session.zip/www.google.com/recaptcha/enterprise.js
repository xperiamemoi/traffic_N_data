/* PLEASE DO NOT COPY AND PASTE THIS CODE. */
(function() {
    var w = window,
        C = '___grecaptcha_cfg',
        cfg = w[C] = w[C] || {},
        N = 'grecaptcha';
    var E = 'enterprise',
        a = w[N] = w[N] || {},
        gr = a[E] = a[E] || {};
    gr.ready = gr.ready || function(f) {
        (cfg['fns'] = cfg['fns'] || []).push(f);
    };
    w['__recaptcha_api'] = 'https://www.google.com/recaptcha/enterprise/';
    (cfg['enterprise'] = cfg['enterprise'] || []).push(true);
    (cfg['enterprise2fa'] = cfg['enterprise2fa'] || []).push(true);
    (cfg['render'] = cfg['render'] || []).push('6Lcxp2UaAAAAABkIC5izuDmTEeXYfgfaoQ9v69Q4');
    (cfg['onload'] = cfg['onload'] || []).push('grecaptchaAppshellOnLoadCallback');
    (cfg['clr'] = cfg['clr'] || []).push('true');
    (cfg['anchor-ms'] = cfg['anchor-ms'] || []).push(20000);
    (cfg['execute-ms'] = cfg['execute-ms'] || []).push(15000);
    w['__google_recaptcha_client'] = true;
    var d = document,
        po = d.createElement('script');
    po.type = 'text/javascript';
    po.async = true;
    po.charset = 'utf-8';
    var v = w.navigator,
        m = d.createElement('meta');
    m.httpEquiv = 'origin-trial';
    m.content = 'A7vZI3v+Gz7JfuRolKNM4Aff6zaGuT7X0mf3wtoZTnKv6497cVMnhy03KDqX7kBz/q/iidW7srW31oQbBt4VhgoAAACUeyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGUuY29tOjQ0MyIsImZlYXR1cmUiOiJEaXNhYmxlVGhpcmRQYXJ0eVN0b3JhZ2VQYXJ0aXRpb25pbmczIiwiZXhwaXJ5IjoxNzU3OTgwODAwLCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==';
    if (v && v.cookieDeprecationLabel) {
        v.cookieDeprecationLabel.getValue().then(function(l) {
            if (l !== 'treatment_1.1' && l !== 'treatment_1.2' && l !== 'control_1.1') {
                d.head.prepend(m);
            }
        });
    } else {
        d.head.prepend(m);
    }
    po.src = 'https://www.gstatic.com/recaptcha/releases/h7qt2xUGz2zqKEhSc8DD8baZ/recaptcha__en_gb.js';
    po.crossOrigin = 'anonymous';
    po.integrity = 'sha384-n47q77MzYudkoaSjHoFx1VczMxAu6arq/eiYB9FiesS7jhtuB4uCQhoY65jy4QrR';
    var e = d.querySelector('script[nonce]'),
        n = e && (e['nonce'] || e.getAttribute('nonce'));
    if (n) {
        po.setAttribute('nonce', n);
    }
    var s = d.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(po, s);
})();
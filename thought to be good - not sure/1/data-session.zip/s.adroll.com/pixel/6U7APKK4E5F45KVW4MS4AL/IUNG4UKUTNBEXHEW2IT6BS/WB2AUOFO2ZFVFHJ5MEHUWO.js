(function() {
    var scheme = (("https:" == document.location.protocol) ? "https" : "http");
    var adnxs_domain = 'secure.adnxs.com';
    var aol_domain = 'secure.leadback.advertising.com';
    window.adroll_seg_eid = "WB2AUOFO2ZFVFHJ5MEHUWO";
    window.adroll_sendrolling_cross_device = true;
    window.adroll_form_fields = {};
    window.adroll_third_party_forms = {};
    window.adroll_third_party_detected = {};
    window.adroll_snippet_errors = [];
    if (typeof __adroll._form_attach != 'undefined') {
        __adroll._form_attach();
    }
    if (typeof __adroll._form_tp_attach != 'undefined') {
        __adroll._form_tp_attach();
    }
    window.adroll_rule_type = "p";
    var rule = ["*", "*"];
    if (scheme == 'http') {
        adnxs_domain = 'ib.adnxs.com';
        aol_domain = 'leadback.advertising.com';
    }
    var el = document.createElement("div");
    el.style["width"] = "1px";
    el.style["height"] = "1px";
    el.style["display"] = "inline";
    el.style["position"] = "absolute";
    var content = '';

    if (__adroll.consent_allowed(__adroll.consent_networks.facebook)) {
        ! function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function() {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window,
            document, 'script', '//connect.facebook.net/en_US/fbevents.js');
    }

    try {
        try {

            (function() {
                var rtb = document.createElement("div");
                rtb.style["width"] = "1px";
                rtb.style["height"] = "1px";
                rtb.style["display"] = "inline";
                rtb.style["position"] = "absolute";
                rtb.innerHTML = ["/cm/b/out?advertisable=6U7APKK4E5F45KVW4MS4AL", "/cm/bombora/out?advertisable=6U7APKK4E5F45KVW4MS4AL", "/cm/experian/out?advertisable=6U7APKK4E5F45KVW4MS4AL", "/cm/g/out?advertisable=6U7APKK4E5F45KVW4MS4AL", "/cm/index/out?advertisable=6U7APKK4E5F45KVW4MS4AL", "/cm/l/out?advertisable=6U7APKK4E5F45KVW4MS4AL", "/cm/n/out?advertisable=6U7APKK4E5F45KVW4MS4AL", "/cm/o/out?advertisable=6U7APKK4E5F45KVW4MS4AL", "/cm/outbrain/out?advertisable=6U7APKK4E5F45KVW4MS4AL", "/cm/pubmatic/out?advertisable=6U7APKK4E5F45KVW4MS4AL", "/cm/taboola/out?advertisable=6U7APKK4E5F45KVW4MS4AL", "/cm/triplelift/out?advertisable=6U7APKK4E5F45KVW4MS4AL", "/cm/x/out?advertisable=6U7APKK4E5F45KVW4MS4AL"].reduce(function(acc, cmURL) {
                    return acc + '<img height="1" width="1" style="border-style:none;" alt="" src="' + __adroll._srv(cmURL) + '"/>';
                }, '');
                __adroll._head().appendChild(rtb);
            })();

        } catch (e) {
            window.adroll_snippet_errors['maya_snippet'] = e;
        }
        try {

            (function() {
                var scr = document.createElement("script");
                scr.type = "text/javascript";
                scr.src = "//s.adroll.com/j/sendrolling.js";
                ((document.getElementsByTagName("head") || [null])[0] || document.getElementsByTagName("script")[0].parentNode).appendChild(scr);
            }());

        } catch (e) {
            window.adroll_snippet_errors['sendrolling'] = e;
        }
        try {

            (function() {
                if (__adroll.consent_allowed(__adroll.consent_networks.linkedin)) {
                    if (__adroll._has_global('adroll_segments')) {

                        if (__adroll._global('adroll_segments') === '8c94b72b') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'https://px.ads.linkedin.com/collect/?pid=27007&conversionId=19672012&fmt=gif');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === 'a2508cf7') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'https://px.ads.linkedin.com/collect/?pid=27007&conversionId=19672004&fmt=gif');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === '6399cc5e') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'https://px.ads.linkedin.com/collect/?pid=27007&conversionId=19671996&fmt=gif');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === 'e0f72646') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'https://px.ads.linkedin.com/collect/?pid=27007&conversionId=19671988&fmt=gif');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === 'afdd5cdb') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'https://px.ads.linkedin.com/collect/?pid=27007&conversionId=19671980&fmt=gif');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === '40d6ec58') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'https://px.ads.linkedin.com/collect/?pid=27007&conversionId=19671972&fmt=gif');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === '5d573223') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'https://px.ads.linkedin.com/collect/?pid=27007&conversionId=19671964&fmt=gif');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === 'e8d9dea0') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'https://px.ads.linkedin.com/collect/?pid=27007&conversionId=19671956&fmt=gif');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === 'b39febf0') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'https://px.ads.linkedin.com/collect/?pid=27007&conversionId=19671948&fmt=gif');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === '50975432') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'https://px.ads.linkedin.com/collect/?pid=27007&conversionId=11250420&fmt=gif');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === 'b2f7ae1f') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'None');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === 'c6308a29') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'None');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === 'b1fca9de') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'None');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === '7249ab22') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'None');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === 'cee32059') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'None');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === 'f743f796') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'None');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === '2cdb1ad8') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'None');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === '1b490442') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'None');

                            document.body.appendChild(conversion_tag);
                        }


                        if (__adroll._global('adroll_segments') === 'c318a855') {
                            var conversion_tag = document.createElement("img");

                            conversion_tag.setAttribute('height', '1');
                            conversion_tag.setAttribute('width', '1');
                            conversion_tag.setAttribute('style', 'display:none;');
                            conversion_tag.setAttribute('alt', '');
                            conversion_tag.setAttribute('src', 'None');

                            document.body.appendChild(conversion_tag);
                        }

                    }
                }
            })();

        } catch (e) {
            window.adroll_snippet_errors['linkedinjsconversion'] = e;
        }
        try {
            (function() {
                "use strict";
                var SITE_PERSONALIZATION_CB = "onB2BPersonalizationDataReady";
                var RW_GA_EVENT = "rw_personalization_data";
                var GA_ID = "";
                var USE_GTM = "true";
                var ENABLE_EMPTY_ATTRIBUTES_CALLBACK = "true";

                function getPersonalizationData(onPersonalizationDataReady) {
                    __adroll._b2bPersonalizationDataCb = onPersonalizationDataReady;
                    __adroll.add_script_element(
                        __adroll._srv("/user_attrs?advertisable_eid=6U7APKK4E5F45KVW4MS4AL&keys_eid=EDXJOCL53NE6LC7NLN8ATK&first_party=false&jsonp=__adroll._b2bPersonalizationDataCb&include_first_party_company_data=true", true)
                    );
                }
                getPersonalizationData(function(personalizationDataResponse) {

                    function runPersonalizationCallback(personalizationData) {
                        setTimeout(function() {
                            __adroll._global(SITE_PERSONALIZATION_CB)(personalizationData);
                        });
                    }

                    function configureSitePersonalizationCallback(personalizationData) {
                        if (!__adroll._has_global(SITE_PERSONALIZATION_CB)) {
                            Object.defineProperty(window, SITE_PERSONALIZATION_CB, {
                                configurable: true,
                                set: function(cb) {
                                    __adroll._unset_global(SITE_PERSONALIZATION_CB);
                                    __adroll._set_global(SITE_PERSONALIZATION_CB, cb);
                                    runPersonalizationCallback(personalizationData);
                                }
                            });
                        } else {
                            runPersonalizationCallback(personalizationData);
                        }
                    }

                    function configureGoogleAnalytics(personalizationData) {
                        __adroll._ensure_global("dataLayer", []);

                        function gtag() {
                            __adroll._global("dataLayer").push(arguments);
                        }
                        gtag("config", GA_ID, {
                            "send_page_view": false,
                            "custom_map": {
                                "dimension1": "domain",
                                "dimension2": "company_name",
                                "dimension3": "company_industry",
                                "dimension4": "company_revenue",
                                "dimension5": "company_size"
                            },
                        });
                        gtag("event", RW_GA_EVENT, personalizationData);
                        if (!__adroll._global("gtag") && __adroll._global("ga")) {
                            const payload = {};
                            const dimensions = {
                                "dimension1": "domain",
                                "dimension2": "company_name",
                                "dimension3": "company_industry",
                                "dimension4": "company_revenue",
                                "dimension5": "company_size"
                            };
                            var keys = Object.keys(dimensions);
                            for (var k in keys) {
                                payload[keys[k]] = personalizationData[dimensions[keys[k]]];
                            }
                            __adroll._global("ga")("send", "event", payload);
                        }
                    }

                    function getDataLayerPersonalizationData(personalizationData) {
                        return {
                            rwCompanyDomain: personalizationData["domain"],
                            rwCompanyName: personalizationData["company_name"],
                            rwCompanyIndustry: personalizationData["company_industry"],
                            rwCompanyRevenue: personalizationData["company_revenue"],
                            rwCompanySize: personalizationData["company_size"]
                        }
                    }

                    function configureGoogleTagManager(personalizationData) {
                        __adroll._ensure_global("dataLayer", []);
                        const dataLayerPersonalizationData = getDataLayerPersonalizationData(personalizationData);
                        dataLayerPersonalizationData["event"] = RW_GA_EVENT;
                        const dataLayer = __adroll._global("dataLayer");
                        if (dataLayer.constructor === Array) {
                            dataLayer.push(dataLayerPersonalizationData);
                        }
                    }
                    var personalizationData = personalizationDataResponse.user_attributes;
                    if (Object.keys(personalizationData).length > 0 || ENABLE_EMPTY_ATTRIBUTES_CALLBACK === "true") {
                        configureSitePersonalizationCallback(personalizationData);
                        if (GA_ID && Object.keys(personalizationData).length > 0) {
                            configureGoogleAnalytics(personalizationData);
                        } else if (USE_GTM && Object.keys(personalizationData).length > 0) {
                            configureGoogleTagManager(personalizationData);
                        }
                    }
                });
            })();

        } catch (e) {
            window.adroll_snippet_errors['rw_personalization'] = e;
        }
        try {
            (function() {
                var ua = window.navigator.userAgent.toLowerCase();
                if (window === window.top && ua.indexOf('safari') !== -1 && ua.indexOf('chrome') === -1 && ua.indexOf('crios') === -1) {
                    window.document.body.className += ' adroll_safari_light_theme';
                    var b = window.document.createElement('script');
                    b.language = 'javascript';
                    b.src = '//d.adroll.com/bounce/pre/6U7APKK4E5F45KVW4MS4AL/IUNG4UKUTNBEXHEW2IT6BS/?d=' + encodeURIComponent('//s.adroll.com/j/bounce.js');
                    window.__adroll._head().appendChild(b);
                }
            })();
        } catch (e) {
            window.adroll_snippet_errors['bouncejs'] = e;
        }
        try {
            try {
                /* Custom (SE) snippet to refresh pixel on SPA sites using pushstate. */
                (function(history) {
                    /* Only run on business.trustpilot.com */
                    if (!window.location.href.match('business.trustpilot.com/')) {
                        return;
                    }

                    function track() {
                        setTimeout(function() {
                            try {
                                __adroll.record_user({});
                            } catch (e) {}
                        }, 500)
                    }
                    var pushState = history.pushState;
                    window.adroll_custsnip_enabled = window.adroll_custsnip_enabled || false;
                    if (window.adroll_custsnip_enabled !== true) {
                        window.adroll_custsnip_enabled = true;
                        history.pushState = function(state) {
                            if (typeof history.onpushstate == "function") {
                                history.onpushstate({
                                    state: state
                                });
                            }
                            track();
                            return pushState.apply(history, arguments);
                        };
                        window.addEventListener('popstate', track);
                    }
                })(window.history);
            } catch (e) {}
        } catch (e) {
            window.adroll_snippet_errors['se_custom_track_pushstate'] = e;
        }
        try {
            if (__adroll.consent_allowed(__adroll.consent_networks.facebook)) {
                var fbLimitedDataUse = true;
                if (typeof __adroll.fb === 'undefined') {
                    if (fbLimitedDataUse) {
                        fbq('dataProcessingOptions', ['LDU'], 0, 0);
                    }
                    fbq('init', '2654126451330155');
                    fbq('set', 'autoConfig', 'false', '2654126451330155');
                    __adroll.fb = true;

                    var __fbcd = {
                        segment_eid: "WB2AUOFO2ZFVFHJ5MEHUWO"
                    };
                    for (var prop in __adroll.get_external_data()) {
                        __fbcd['ar_' + prop] = __adroll.get_external_data()[prop];
                    }

                    fbq('track', "PageView", __fbcd);
                } else {
                    var __fbcd = {
                        event: "EventSegment",
                        segment_eid: "WB2AUOFO2ZFVFHJ5MEHUWO"
                    };
                    for (var prop in __adroll.get_external_data()) {
                        __fbcd['ar_' + prop] = __adroll.get_external_data()[prop];
                    }

                    fbq('track', "CustomEvent", __fbcd);
                }
            }

        } catch (e) {
            window.adroll_snippet_errors['FacebookExternalDataWCASnippet'] = e;
        }
    } catch (e) {}

    var r = Math.random() * 10000000000000000;
    content = content.replace(/\[ord\]/gi, r);
    content = content.replace(/\[protocol\]/gi, scheme);
    content = content.replace(/\[adnxs_domain\]/gi, adnxs_domain);
    content = content.replace(/\[aol_domain\]/gi, aol_domain);
    var adroll_tpc = __adroll._global('adroll_tpc');
    if (adroll_tpc) {
        var srv_parts = __adroll._srv().split('?');
        var srv_host = srv_parts[0].substr(srv_parts[0].indexOf(':') + 1);
        var srv_re = new RegExp(srv_host + '([^\?\"\'\>\#\S]+)\\?*', 'gi');
        content = content.replace(srv_re, srv_host + '$1?' + srv_parts[1] + '&');
    }
    content = __adroll.replace_external_data(content);
    el.innerHTML = content;
    __adroll._head().appendChild(el);
    if (typeof __adroll.set_pixel_cookie != 'undefined') {
        __adroll.set_pixel_cookie(adroll_adv_id, adroll_pix_id, "WB2AUOFO2ZFVFHJ5MEHUWO");
    }
}());
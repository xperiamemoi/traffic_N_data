window.hjSiteSettings = window.hjSiteSettings || {
    "site_id": 391767,
    "rec_value": 0.5115719724284722,
    "state_change_listen_mode": "automatic",
    "record": true,
    "continuous_capture_enabled": true,
    "recording_capture_keystrokes": false,
    "session_capture_console_consent": false,
    "anonymize_digits": false,
    "anonymize_emails": false,
    "suppress_all": false,
    "suppress_all_on_specific_pages": [],
    "suppress_text": null,
    "suppress_location": false,
    "user_attributes_enabled": true,
    "legal_name": "Trustpilot",
    "privacy_policy_url": "https://legal.trustpilot.com/end-user-privacy-terms",
    "deferred_page_contents": [],
    "record_targeting_rules": [{
        "component": "url",
        "match_operation": "contains",
        "pattern": "/evaluate/",
        "negate": false
    }, {
        "component": "url",
        "match_operation": "contains",
        "pattern": "/review/",
        "negate": false
    }, {
        "component": "trigger",
        "match_operation": "exact",
        "pattern": "use_fuzzy_search",
        "negate": false
    }, {
        "component": "trigger",
        "match_operation": "exact",
        "pattern": "use_fuzzy_search_ignore_location",
        "negate": false
    }],
    "heatmaps": [],
    "polls": [{
        "id": 1609037,
        "created_epoch_time": 1744807682,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "3ab8d6a8-84ed-4d95-8540-9d76f48ba012",
                "type": "reaction",
                "text": "Was this summary useful in helping you make decision about this company?",
                "required": true,
                "labels": [{
                    "text": "Not useful at all"
                }, {
                    "text": "Extremely useful"
                }],
                "reaction_style": "emoji",
                "next": "byOrder"
            }, {
                "uuid": "95b34ea6-f29f-4292-b02c-65ec0fe0daa8",
                "type": "single-open-ended-multiple-line",
                "text": "Can you tell us more about your experience with AI Summary?",
                "required": false,
                "nextIfSkipped": "question:e14c2f9b-6dad-49aa-b453-35534ad7adb0",
                "next": "question:e14c2f9b-6dad-49aa-b453-35534ad7adb0"
            }, {
                "uuid": "e14c2f9b-6dad-49aa-b453-35534ad7adb0",
                "type": "single-open-ended-multiple-line",
                "text": "What specific information or details did you find most helpful in the summary?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }, {
                "uuid": "b1820eb9-a965-4511-ae11-34df88820572",
                "type": "single-open-ended-multiple-line",
                "text": "What would make this summary more useful for your decision?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for your feedback!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "immediate",
        "display_delay": 0,
        "persist_condition": "always",
        "targeting_percentage": 10,
        "targeting": [{
            "component": "url",
            "match_operation": "starts_with",
            "negate": false,
            "pattern": "https://ie.trustpilot.com/review/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "starts_with",
            "negate": false,
            "pattern": "https://ca.trustpilot.com/review/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "starts_with",
            "negate": false,
            "pattern": "https://uk.trustpilot.com/review/",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "starts_with",
            "negate": false,
            "pattern": "https://www.trustpilot.com/review/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "starts_with",
            "negate": false,
            "pattern": "https://au.trustpilot.com/review/",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "starts_with",
            "negate": false,
            "pattern": "https://nz.trustpilot.com/review/",
            "name": null,
            "rule_type": null
        }],
        "uuid": "d87bad0b-03e2-460b-8135-ffb228be94e3",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "inline",
        "auto_screenshot": true,
        "etr_enabled": false,
        "show_legal": true,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": "#hotjar-ai-summaries-inline-feedback",
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 1604105,
        "created_epoch_time": 1744118439,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": true,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "3ab8d6a8-84ed-4d95-8540-9d76f48ba012",
                "type": "rating-scale-5",
                "text": "How satisfied are you with your overall search experience on Trustpilot?",
                "required": true,
                "scaleCount": 5,
                "labels": [{
                    "text": "Very Dissatisfied"
                }, {
                    "text": "Very Satisfied"
                }],
                "next": "byOrder"
            }, {
                "uuid": "95b34ea6-f29f-4292-b02c-65ec0fe0daa8",
                "type": "single-open-ended-multiple-line",
                "text": "Tell us more about your experience...",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for your feedback!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "delay",
        "display_delay": 5,
        "persist_condition": "response",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "consumer-site-show-feedback-module",
            "name": null,
            "rule_type": null
        }],
        "uuid": "03730d18-5443-408c-8a3a-dc595e05adff",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": true,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 1023651,
        "created_epoch_time": 1716467582,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "a4166ded-ee31-4842-a585-1dc34993359e",
                "type": "rating-scale-5",
                "text": "Please rate how much you agree or disagree with the following statement: The content I see on Trustpilot appears authentic, and it increases my confidence in making purchasing decisions.",
                "required": true,
                "scaleCount": 5,
                "labels": [{
                    "text": "Strongly disagree"
                }, {
                    "text": "Strongly agree"
                }],
                "next": "byOrder"
            }, {
                "uuid": "807de9ac-7724-4682-bc42-9e9ec8b65cca",
                "type": "single-open-ended-multiple-line",
                "text": "Explain your choice.",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thank you for answering this survey. Your feedback is highly appreciated!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "immediate",
        "display_delay": 0,
        "persist_condition": "response",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "url",
            "match_operation": "contains",
            "negate": false,
            "pattern": "/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "5f171cfd-8c91-453e-b669-c04c4ce479f9",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "inline",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": "#filtered-reviews-hotjar-survey",
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 1013113,
        "created_epoch_time": 1713535842,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": true,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "2931b5be-1ee0-4f1b-835f-3f343fda260a",
                "type": "rating-scale-5",
                "text": "Please rate how much you agree or disagree with the following statement. \nI find the Trustpilot chrome extension useful.",
                "required": true,
                "scaleCount": 5,
                "labels": [{
                    "text": "Strongly disagree"
                }, {
                    "text": "Strongly agree"
                }],
                "next": "byOrder"
            }, {
                "uuid": "4c29302c-9e6c-48e3-abd8-bf6e1099cc1d",
                "type": "rating-scale-5",
                "text": "Please rate how much you agree or disagree with the following statement. \nI anticipate using the chrome extension often, when browsing online.",
                "required": true,
                "scaleCount": 5,
                "labels": [{
                    "text": "Strongly disagree"
                }, {
                    "text": "Strongly agree"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e6c24678-1107-4e9c-a5fb-55eab5d6db96",
                "type": "multiple-close-ended",
                "text": "What specific features of the Trustpilot chrome extension do you find most useful?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Trustscore tab",
                    "comments": false
                }, {
                    "text": "Company information",
                    "comments": false
                }, {
                    "text": "Link to Trustpilot profile",
                    "comments": false
                }, {
                    "text": "1 - 5 star ratings",
                    "comments": false
                }, {
                    "text": "Most recent reviews",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "e1db8160-fcd7-4e92-a992-db561b25dcb1",
                "type": "single-close-ended",
                "text": "Have you used a previous version of the Trustpilot chrome extension?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "8f275426-84f9-412d-8605-fed47fd66696",
                "type": "single-open-ended-single-line",
                "text": "Please share any feedback or suggestions for improving the Trustpilot chrome extension.",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "immediate",
        "display_delay": 0,
        "persist_condition": "always",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "contains",
            "negate": false,
            "pattern": "/",
            "name": null,
            "rule_type": null
        }],
        "uuid": "6527565f-40c2-4f52-bfd7-5ec74b5d1351",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "external_link",
        "auto_screenshot": true,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": "surveys/logo/8899a8a4eee3474fa0b7d9a1b4bae6a7",
        "button_color": "#00B67A",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 969535,
        "created_epoch_time": 1702036127,
        "skin": "light",
        "background": "#FCFBF3",
        "effective_show_branding": true,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "af2ebc1f-a2ca-40aa-b5b1-e2b448a42e2a",
                "type": "single-close-ended",
                "text": "How useful was the free trial experience?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Not at all useful",
                    "comments": false
                }, {
                    "text": " Somewhat useful",
                    "comments": false
                }, {
                    "text": "Very useful",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "53a5a6ae-8336-4764-ab1b-f0f5b0d3edf2",
                "type": "rating-scale-5",
                "text": "To what extent do you agree or disagree that Trustpilot's paid subscription will add significant value to your company?",
                "required": true,
                "scaleCount": 5,
                "labels": [{
                    "text": "Strongly disagree"
                }, {
                    "text": "Strongly agree"
                }],
                "next": "byOrder"
            }, {
                "uuid": "252f1fae-55dd-4426-b836-c7835ece7160",
                "type": "single-close-ended",
                "text": "Did you successfully implement the widget?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "f4bdab67-4a85-4c8e-8569-00a6917b2c83",
                "type": "single-close-ended",
                "text": "How long did you have the widget implemented? ",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Less than 7 days",
                    "comments": false
                }, {
                    "text": "Between 7 and 13 days",
                    "comments": false
                }, {
                    "text": "14 days",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "13adb70b-1197-4dfd-a6c0-360981baa47f",
                "type": "rating-scale-5",
                "text": "Following the free trial how likely are you to purchase a paid Trustpilot plan",
                "required": true,
                "scaleCount": 5,
                "labels": [{
                    "text": "Very Unlikely"
                }, {
                    "text": "Very Likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "dfc86595-9a86-4fcc-83bd-110e8672908b",
                "type": "rating-scale-5",
                "text": "Following the free trial how likely are you to book a demo to learn more?",
                "required": true,
                "scaleCount": 5,
                "labels": [{
                    "text": "Very Unlikely"
                }, {
                    "text": "Very Likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "b46834e4-c414-4ddb-a75f-7c48d56bfab1",
                "type": "rating-scale-5",
                "text": "Following the free trial how likely are you to consider a paid plan in future?",
                "required": true,
                "scaleCount": 5,
                "labels": [{
                    "text": "Very Unlikely"
                }, {
                    "text": "Very Likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "b7114a39-917d-4a34-ba17-4481e1a768ce",
                "type": "multiple-close-ended",
                "text": "What factors would influence your decision to purchase a paid Trustpilot plan?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Positive reviews from other users",
                    "comments": false
                }, {
                    "text": "Additional features offered in the paid plan",
                    "comments": false
                }, {
                    "text": "Cost of the paid plan",
                    "comments": false
                }, {
                    "text": "Reliability and reputation of Trustpilot",
                    "comments": false
                }, {
                    "text": "Other",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "61c16788-318b-4b5e-a28f-6f056b99e2dc",
                "type": "single-open-ended-multiple-line",
                "text": "Is there anything else you’d like to share about your trial experience?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "immediate",
        "display_delay": 0,
        "persist_condition": "response",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "contains",
            "negate": false,
            "pattern": "/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }],
        "uuid": "d17a9eff-16a0-4855-98b8-9cacdfee9574",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "external_link",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": "surveys/logo/5755abdc225045f5b569eefc7fb30fe6",
        "button_color": "#205CD4",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 960486,
        "created_epoch_time": 1700062200,
        "skin": "light",
        "background": "#FCFBF3",
        "effective_show_branding": true,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "0c8344d4-2ed7-434f-934b-6ddf7f62b977",
                "type": "multiple-close-ended",
                "text": "Why did you decide to delete the widget from your website? (Please select all that apply)",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": true,
                "answers": [{
                    "text": "Difficulty implementing the TrustBox Widget",
                    "comments": false
                }, {
                    "text": "Difficulty in understanding its functionality",
                    "comments": false
                }, {
                    "text": "Found a better alternative",
                    "comments": false
                }, {
                    "text": "Unsatisfactory features",
                    "comments": false
                }, {
                    "text": "Something else",
                    "comments": true
                }],
                "next": "byOrder"
            }, {
                "uuid": "72429511-a6be-450b-90af-d0b0191ca88d",
                "type": "rating-scale-5",
                "text": "How easy or difficult was it to set up the TrustBox widget?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "scaleCount": 5,
                "labels": [{
                    "text": "Very difficult"
                }, {
                    "text": "Very easy"
                }],
                "next": "byOrder"
            }, {
                "uuid": "0c5fc8d2-f028-46ef-a07e-e3ff7887239f",
                "type": "single-open-ended-multiple-line",
                "text": "Is there anything else you'd like to share with us about your experience?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "immediate",
        "display_delay": 0,
        "persist_condition": "response",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "contains",
            "negate": false,
            "pattern": "/",
            "name": null,
            "rule_type": null
        }],
        "uuid": "4e3cf1a8-c5db-49df-ba0a-d5d9afdf0375",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "external_link",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": "surveys/logo/d795e4cd527c4b8f8440dd072620790f",
        "button_color": "#205CD4",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842863,
        "created_epoch_time": 1663239116,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Hur sannolikt är det att du skulle rekommendera Trustpilot.com till en vän eller kollega?",
                "required": true,
                "labels": [{
                    "text": "Inte alls sannolikt"
                }, {
                    "text": "Ytterst sannolikt"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Kan du berätta lite mer om varför du känner så?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Tack för att du fyllde i undersökningen!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "sv",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_sv-SE",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }],
        "uuid": "70f19d10-4776-42c4-b2de-8e6e9ac36941",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842861,
        "created_epoch_time": 1663238988,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Hoe waarschijnlijk is het dat je Trustpilot.com zou aanbevelen aan een vriend of collega?",
                "required": true,
                "labels": [{
                    "text": "Zeer onwaarschijnlijk"
                }, {
                    "text": "Zeer waarschijnlijk"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Licht je antwoord toe.",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Bedankt voor het invullen van de enquête!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "nl",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_nl-BE",
            "name": null,
            "rule_type": null
        }],
        "uuid": "d1df66ed-3af6-4f33-9a26-22f7894cff9e",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842860,
        "created_epoch_time": 1663238969,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Hoe waarschijnlijk is het dat je Trustpilot.com zou aanbevelen aan een vriend of collega?",
                "required": true,
                "labels": [{
                    "text": "Zeer onwaarschijnlijk"
                }, {
                    "text": "Zeer waarschijnlijk"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Licht je antwoord toe.",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Bedankt voor het invullen van de enquête!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "nl",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_nl-NL",
            "name": null,
            "rule_type": null
        }],
        "uuid": "6be0b801-3a15-4aae-ab93-0242db91aa4f",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842857,
        "created_epoch_time": 1663238887,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Quanto è probabile che consiglieresti Trustpilot.com a un amico o un collega?",
                "required": true,
                "labels": [{
                    "text": "Del tutto improbabile"
                }, {
                    "text": "Estremamente probabile"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Potresti spiegarci perché?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Grazie per aver completato il sondaggio!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "it",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_it-IT",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "1e61d4cf-ef72-4ca6-9656-67212f433bc7",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842856,
        "created_epoch_time": 1663238863,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Est-il probable que vous recommandiez Trustpilot.com à un ami ou à un collègue ?",
                "required": true,
                "labels": [{
                    "text": "Pas du tout probable"
                }, {
                    "text": "Extrêmement probable"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Pourriez-vous nous dire pourquoi ? ",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Merci d'avoir répondu au sondage !"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "fr",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_fr-BE",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "341ad52d-bb84-4d3e-a3d0-af35fb514fa9",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842854,
        "created_epoch_time": 1663238844,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Est-il probable que vous recommandiez Trustpilot.com à un ami ou à un collègue ?",
                "required": true,
                "labels": [{
                    "text": "Pas du tout probable"
                }, {
                    "text": "Extrêmement probable"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Pourriez-vous nous dire pourquoi ? ",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Merci d'avoir répondu au sondage !"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "fr",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_fr-FR",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }],
        "uuid": "bcd21643-1ecd-4d23-8fda-fbd784f20dbc",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842853,
        "created_epoch_time": 1663238809,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "¿Con qué probabilidad recomendarías Trustpilot.com a un amigo o compañero de trabajo?",
                "required": true,
                "labels": [{
                    "text": "Muy improbable"
                }, {
                    "text": "Muy probable"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "¿Podrías explicar por qué?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "¡Gracias por completar la encuesta!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "es",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_es-ES",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }],
        "uuid": "2fb29f01-94dc-4243-8e31-6d849e36ba8e",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842852,
        "created_epoch_time": 1663238764,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Wie wahrscheinlich ist es, dass Sie Trustpilot.com an Freunde oder Kollegen weiterempfehlen würden?",
                "required": true,
                "labels": [{
                    "text": "Sehr unwahrscheinlich"
                }, {
                    "text": "Sehr wahrscheinlich"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Könnten Sie uns auch sagen, weswegen Sie diesen Score gegeben haben?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Vielen dank für das ausfüllen der umfrage!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "de",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_de-CH",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }],
        "uuid": "c2bc00e2-97f0-404a-b7e3-81569a8a64b8",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842850,
        "created_epoch_time": 1663238744,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Wie wahrscheinlich ist es, dass Sie Trustpilot.com an Freunde oder Kollegen weiterempfehlen würden?",
                "required": true,
                "labels": [{
                    "text": "Sehr unwahrscheinlich"
                }, {
                    "text": "Sehr wahrscheinlich"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Könnten Sie uns auch sagen, weswegen Sie diesen Score gegeben haben?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Vielen dank für das ausfüllen der umfrage!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "de",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_de-AT",
            "name": null,
            "rule_type": null
        }],
        "uuid": "f3683009-f421-4def-a7ac-175eb5237e3f",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842849,
        "created_epoch_time": 1663238713,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Wie wahrscheinlich ist es, dass Sie Trustpilot.com an Freunde oder Kollegen weiterempfehlen würden?",
                "required": true,
                "labels": [{
                    "text": "Sehr unwahrscheinlich"
                }, {
                    "text": "Sehr wahrscheinlich"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Könnten Sie uns auch sagen, weswegen Sie diesen Score gegeben haben?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Vielen dank für das ausfüllen der umfrage!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "de",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_de-DE",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }],
        "uuid": "2193f22c-26f7-4e28-8290-e4dab810af44",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842848,
        "created_epoch_time": 1663238683,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Hvor sandsynligt er det, at du vil anbefale Trustpilot.com til en ven eller kollega?",
                "required": true,
                "labels": [{
                    "text": "Meget usandsynligt"
                }, {
                    "text": "Meget sandsynligt"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Hvorfor har du valgt at give os denne score?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Tak, fordi du udfyldte undersøgelsen!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "da",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_da-DK",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "8e2b56b2-466b-4eca-a139-10dbc1b8cbfd",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842847,
        "created_epoch_time": 1663238635,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "How likely is it that you would recommend Trustpilot.com to a friend or colleague?",
                "required": true,
                "labels": [{
                    "text": "Not likely at all"
                }, {
                    "text": "Extremely likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Please could you tell us why you gave that score?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_en-NZ",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "1822cce8-24b0-4232-80fe-76941434b2b8",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842846,
        "created_epoch_time": 1663238604,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "How likely is it that you would recommend Trustpilot.com to a friend or colleague?",
                "required": true,
                "labels": [{
                    "text": "Not likely at all"
                }, {
                    "text": "Extremely likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Please could you tell us why you gave that score?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_en-CA",
            "name": null,
            "rule_type": null
        }],
        "uuid": "f7041e4f-5ddf-4658-93bd-0e7894e0a290",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842842,
        "created_epoch_time": 1663238343,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "How likely is it that you would recommend Trustpilot.com to a friend or colleague?",
                "required": true,
                "labels": [{
                    "text": "Not likely at all"
                }, {
                    "text": "Extremely likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Please could you tell us why you gave that score?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_en-IE",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }],
        "uuid": "a0b282a9-f701-40e9-98d8-e03c85e4ceac",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842841,
        "created_epoch_time": 1663238315,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "How likely is it that you would recommend Trustpilot.com to a friend or colleague?",
                "required": true,
                "labels": [{
                    "text": "Not likely at all"
                }, {
                    "text": "Extremely likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Please could you tell us why you gave that score?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_en-AU",
            "name": null,
            "rule_type": null
        }],
        "uuid": "b5ab510f-604e-4f37-b05b-1e597532a0ff",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842835,
        "created_epoch_time": 1663238221,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "How likely is it that you would recommend Trustpilot.com to a friend or colleague?",
                "required": true,
                "labels": [{
                    "text": "Not likely at all"
                }, {
                    "text": "Extremely likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Please could you tell us why you gave that score?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_en-US",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "626da349-b385-42fe-a0a3-4f7be09d05e2",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842827,
        "created_epoch_time": 1663238106,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "How likely is it that you would recommend Trustpilot.com to a friend or colleague?",
                "required": true,
                "labels": [{
                    "text": "Not likely at all"
                }, {
                    "text": "Extremely likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Please could you tell us why you gave that score?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_writers_en-GB",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }],
        "uuid": "c6d2da0f-13cf-4a49-b6c2-519dfda0f8c5",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842814,
        "created_epoch_time": 1663236673,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Est-il probable que vous recommandiez Trustpilot.com à un ami ou à un collègue ?",
                "required": true,
                "labels": [{
                    "text": "Pas du tout probable"
                }, {
                    "text": "Extrêmement probable"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Pourriez-vous nous dire pourquoi ? ",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Merci d'avoir répondu au sondage !"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "fr",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_fr-BE",
            "name": null,
            "rule_type": null
        }],
        "uuid": "12cef553-444e-4666-abd9-1d0fa23b9c41",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842813,
        "created_epoch_time": 1663236617,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Hoe waarschijnlijk is het dat je Trustpilot.com zou aanbevelen aan een vriend of collega?",
                "required": true,
                "labels": [{
                    "text": "Zeer onwaarschijnlijk"
                }, {
                    "text": "Zeer waarschijnlijk"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Licht je antwoord toe.",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Bedankt voor het invullen van de enquête!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "nl",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_nl-BE",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }],
        "uuid": "6e0f000a-ea32-4c0b-b2ad-b7452e6c89d5",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842812,
        "created_epoch_time": 1663236565,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Wie wahrscheinlich ist es, dass Sie Trustpilot.com an Freunde oder Kollegen weiterempfehlen würden?",
                "required": true,
                "labels": [{
                    "text": "Sehr unwahrscheinlich"
                }, {
                    "text": "Sehr wahrscheinlich"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Könnten Sie uns auch sagen, weswegen Sie diesen Score gegeben haben?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Vielen dank für das ausfüllen der umfrage!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "de",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_de-CH",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }],
        "uuid": "021185cb-0df4-49c3-9912-6a0cec807600",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842810,
        "created_epoch_time": 1663236479,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Wie wahrscheinlich ist es, dass Sie Trustpilot.com an Freunde oder Kollegen weiterempfehlen würden?",
                "required": true,
                "labels": [{
                    "text": "Sehr unwahrscheinlich"
                }, {
                    "text": "Sehr wahrscheinlich"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Könnten Sie uns auch sagen, weswegen Sie diesen Score gegeben haben?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Vielen dank für das ausfüllen der umfrage!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "de",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_de-AT",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "a133c1e4-7479-4622-9dff-5ad3764572f7",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842801,
        "created_epoch_time": 1663235829,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Hur sannolikt är det att du skulle rekommendera Trustpilot.com till en vän eller kollega?",
                "required": true,
                "labels": [{
                    "text": "Inte alls sannolikt"
                }, {
                    "text": "Ytterst sannolikt"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Kan du berätta lite mer om varför du känner så?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Tack för att du fyllde i undersökningen!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "sv",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_sv-SE",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "32d93fb4-8745-4b34-85b9-dd269e9fd4d5",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842799,
        "created_epoch_time": 1663235655,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Hoe waarschijnlijk is het dat je Trustpilot.com zou aanbevelen aan een vriend of collega?",
                "required": true,
                "labels": [{
                    "text": "Zeer onwaarschijnlijk"
                }, {
                    "text": "Zeer waarschijnlijk"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Licht je antwoord toe.",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Bedankt voor het invullen van de enquête!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "nl",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_nl-NL",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }],
        "uuid": "4928f50e-bf42-48b2-bfe1-093795204e43",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842798,
        "created_epoch_time": 1663235327,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Quanto è probabile che consiglieresti Trustpilot.com a un amico o un collega?",
                "required": true,
                "labels": [{
                    "text": "Del tutto improbabile"
                }, {
                    "text": "Estremamente probabile"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Potresti spiegarci perché?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Grazie per aver completato il sondaggio!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "it",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_it-IT",
            "name": null,
            "rule_type": null
        }],
        "uuid": "6070d6fd-3f8d-4793-b3ec-bb580de7ed9f",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842796,
        "created_epoch_time": 1663235185,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Est-il probable que vous recommandiez Trustpilot.com à un ami ou à un collègue ?",
                "required": true,
                "labels": [{
                    "text": "Pas du tout probable"
                }, {
                    "text": "Extrêmement probable"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Pourriez-vous nous dire pourquoi ? ",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Merci d'avoir répondu au sondage !"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "fr",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_fr-FR",
            "name": null,
            "rule_type": null
        }],
        "uuid": "1a41b299-e6d5-4e02-ad2f-2f4376e002eb",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842789,
        "created_epoch_time": 1663234827,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "¿Con qué probabilidad recomendarías Trustpilot.com a un amigo o compañero de trabajo?",
                "required": true,
                "labels": [{
                    "text": "Muy improbable"
                }, {
                    "text": "Muy probable"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "¿Podrías explicar por qué?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "¡Gracias por completar la encuesta!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "es",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_es-ES",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }],
        "uuid": "c71b437c-bc73-401d-9b5b-e27ae7061c1c",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842783,
        "created_epoch_time": 1663234599,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Wie wahrscheinlich ist es, dass Sie Trustpilot.com an Freunde oder Kollegen weiterempfehlen würden?",
                "required": true,
                "labels": [{
                    "text": "Sehr unwahrscheinlich"
                }, {
                    "text": "Sehr wahrscheinlich"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Könnten Sie uns auch sagen, weswegen Sie diesen Score gegeben haben?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Vielen dank für das ausfüllen der umfrage!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "de",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_de-DE",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }],
        "uuid": "ba2f178e-3e6d-41fd-b856-492664ba73d4",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842780,
        "created_epoch_time": 1663234383,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "Hvor sandsynligt er det, at du vil anbefale Trustpilot.com til en ven eller kollega?",
                "required": true,
                "labels": [{
                    "text": "Meget usandsynligt"
                }, {
                    "text": "Meget sandsynligt"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Hvorfor har du valgt at give os denne score?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Tak, fordi du udfyldte undersøgelsen!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "da",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_da-DK",
            "name": null,
            "rule_type": null
        }],
        "uuid": "078c1bee-ef03-4eb7-a04d-d3e2c76113d6",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842739,
        "created_epoch_time": 1663230829,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "How likely is it that you would recommend Trustpilot.com to a friend or colleague?",
                "required": true,
                "labels": [{
                    "text": "Not likely at all"
                }, {
                    "text": "Extremely likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Please could you tell us why you gave that score?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_en-NZ",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }],
        "uuid": "0b865a56-4323-418e-bc26-f3b12dd16e17",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842738,
        "created_epoch_time": 1663230808,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "How likely is it that you would recommend Trustpilot.com to a friend or colleague?",
                "required": true,
                "labels": [{
                    "text": "Not likely at all"
                }, {
                    "text": "Extremely likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Please could you tell us why you gave that score?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_en-CA",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }],
        "uuid": "4a06aab5-c62a-4ecf-9207-78308d5e76e9",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842737,
        "created_epoch_time": 1663230779,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "How likely is it that you would recommend Trustpilot.com to a friend or colleague?",
                "required": true,
                "labels": [{
                    "text": "Not likely at all"
                }, {
                    "text": "Extremely likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Please could you tell us why you gave that score?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_en-IE",
            "name": null,
            "rule_type": null
        }],
        "uuid": "397b300b-10fe-47c1-8ef5-0d85897ccdb4",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842735,
        "created_epoch_time": 1663230704,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "How likely is it that you would recommend Trustpilot.com to a friend or colleague?",
                "required": true,
                "labels": [{
                    "text": "Not likely at all"
                }, {
                    "text": "Extremely likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Please could you tell us why you gave that score?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_en-AU",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }],
        "uuid": "11849615-b1f1-45c8-9b97-6ee3382918f8",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842734,
        "created_epoch_time": 1663230674,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "How likely is it that you would recommend Trustpilot.com to a friend or colleague?",
                "required": true,
                "labels": [{
                    "text": "Not likely at all"
                }, {
                    "text": "Extremely likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Please could you tell us why you gave that score?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_en-US",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }],
        "uuid": "4910c0e9-ab79-47ab-97e6-a6eeb1289379",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 842733,
        "created_epoch_time": 1663230631,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "c0437918-1fa5-4857-a11e-efc21e87f599",
                "type": "net-promoter-score",
                "text": "How likely is it that you would recommend Trustpilot.com to a friend or colleague?",
                "required": true,
                "labels": [{
                    "text": "Not likely at all"
                }, {
                    "text": "Extremely likely"
                }],
                "next": "byOrder"
            }, {
                "uuid": "e3ac8450-f6e8-4243-aa47-9e3e741a1313",
                "type": "single-open-ended-multiple-line",
                "text": "Please could you tell us why you gave that score?",
                "required": false,
                "nextIfSkipped": "byOrder",
                "next": "byOrder"
            }],
            "thankyou": "Thanks for completing the survey!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "delay",
        "display_delay": 90,
        "persist_condition": "once",
        "targeting_percentage": 98,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "trigger",
            "match_operation": "exact",
            "negate": false,
            "pattern": "nps_readers_en-GB",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "e4591b8d-ebdf-4f06-8672-28ee2a5f99c2",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#04da8d",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 668008,
        "created_epoch_time": 1615798594,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "a606b61a-2ea7-437b-8c27-37e79a160f30",
                "type": "single-close-ended",
                "text": "Do you trust the information on Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "57100316-872c-4910-87a9-1c74b4b378f8",
                "type": "single-close-ended",
                "text": "Do you trust Trustpilot to do the right thing when handling reviews?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "c2b3ff2e-d41c-4224-add7-2900c36ddd93",
                "type": "single-close-ended",
                "text": "Does Trustpilot provide you with relevant information?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "de25e76c-8778-4f51-945d-5e366b323bea",
                "type": "single-close-ended",
                "text": "Would you recommend Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "1e9b78b5-097c-4e7f-838c-2fbcd3cfe175",
                "type": "single-close-ended",
                "text": "Do you consider Trustpilot a transparent and open company?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Thank you for answering this poll. Your feedback is highly appreciated!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 73,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://au.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }],
        "uuid": "99e8d608-a96d-498e-abd9-2dfffef4f5c0",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#00C764",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 440706,
        "created_epoch_time": 1568206728,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "671fb999-9ec3-404f-ae9c-781d16515f14",
                "type": "single-close-ended",
                "text": "Vertrouw je de informatie die op Trustpilot staat?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nee",
                    "comments": false
                }, {
                    "text": "Weet ik niet",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "94ad4f66-9d9d-4539-bdb6-8be10a6d4082",
                "type": "single-close-ended",
                "text": "Vertrouw je erop dat Trustpilot op correcte wijze reviews beheert en verwerkt?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nee",
                    "comments": false
                }, {
                    "text": "Weet ik niet",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "ce1c3a8c-a07c-4065-950e-0af543eb533e",
                "type": "single-close-ended",
                "text": "Voorziet Trustpilot je van genoeg relevante informatie?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nee",
                    "comments": false
                }, {
                    "text": "Weet ik niet",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "427b4069-2a8b-4a11-965c-75fb1d8c521e",
                "type": "single-close-ended",
                "text": "Zou je Trustpilot aan anderen aanraden?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nee",
                    "comments": false
                }, {
                    "text": "Weet ik niet",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "2e6e3d3d-04b3-4775-837f-d84c5a805cd2",
                "type": "single-close-ended",
                "text": "Beschouw je Trustpilot als een open en transparant bedrijf?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nee",
                    "comments": false
                }, {
                    "text": "Weet ik niet",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Veel dank!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "nl",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 96,
        "targeting": [{
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://nl-be.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }],
        "uuid": "ee95d9f6-aa72-4908-a06c-bad0f3b6fe41",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 365329,
        "created_epoch_time": 1541435165,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "6c04a35b-5d57-4fba-8571-31b119425500",
                "type": "single-close-ended",
                "text": "Luotatko Trustpilotin sivuilla oleviin tietoihin?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Kyllä",
                    "comments": false
                }, {
                    "text": "En",
                    "comments": false
                }, {
                    "text": "En tiedä",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "163d78da-b308-4375-9894-ef018c89f792",
                "type": "single-close-ended",
                "text": "Luotatko siihen, että Trustpilot käsittelee arvosteluja oikealla tavalla?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Kyllä",
                    "comments": false
                }, {
                    "text": "En",
                    "comments": false
                }, {
                    "text": "En tiedä",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "b7c71f9c-5c1a-48b2-83b5-fcab4ae354fe",
                "type": "single-close-ended",
                "text": "Saatko Trustpilotin sivuilta tarvitsemaasi informaatiota?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Kyllä",
                    "comments": false
                }, {
                    "text": "En",
                    "comments": false
                }, {
                    "text": "En tiedä",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "d6acf40e-3f2d-4f1a-b21b-aac91d39a57c",
                "type": "single-close-ended",
                "text": "Suosittelisitko Trustpilotia muille?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Kyllä",
                    "comments": false
                }, {
                    "text": "En",
                    "comments": false
                }, {
                    "text": "En tiedä",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "06e64ed1-1ec3-436d-a174-181f5fda9b24",
                "type": "single-close-ended",
                "text": "Pidätkö Trustpilotia rehellisenä ja avoimena yrityksenä?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Kyllä",
                    "comments": false
                }, {
                    "text": "En",
                    "comments": false
                }, {
                    "text": "En tiedä",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Kiitos!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "fi",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://fi.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "095ef1a6-77ec-4b67-809d-765a367993d7",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 365326,
        "created_epoch_time": 1541434802,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "76f443c0-f19e-4dd7-a110-25bef0dee229",
                "type": "single-close-ended",
                "text": "Доверяете ли вы информации на Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Да",
                    "comments": false
                }, {
                    "text": "Нет",
                    "comments": false
                }, {
                    "text": "Я не знаю",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "b4f189c9-a459-4a05-95f4-8eb41637ef5d",
                "type": "single-close-ended",
                "text": "Считаете ли вы, что Trustpilot обрабатывает отзывы должным образом?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Да",
                    "comments": false
                }, {
                    "text": "Нет",
                    "comments": false
                }, {
                    "text": "Я не знаю",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "aa3d0200-2850-4712-83f9-c984246b8619",
                "type": "single-close-ended",
                "text": "Предоставляет ли Trustpilot актуальную информацию?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Да",
                    "comments": false
                }, {
                    "text": "Нет",
                    "comments": false
                }, {
                    "text": "Я не знаю",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "36e7a2d8-fcd9-4bf0-b4e9-96d3690337e0",
                "type": "single-close-ended",
                "text": "Порекомендовали ли бы вы Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Да",
                    "comments": false
                }, {
                    "text": "Нет",
                    "comments": false
                }, {
                    "text": "Я не знаю",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "d6770535-87d0-4c1a-b2c8-8acbac84db38",
                "type": "single-close-ended",
                "text": "Считаете ли вы, что Trustpilot - открытая и честная компания?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Да",
                    "comments": false
                }, {
                    "text": "Нет",
                    "comments": false
                }, {
                    "text": "Я не знаю",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "большое спасибо!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "ru",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 91,
        "targeting": [{
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://ru.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "abf6960c-beae-4247-a17c-5c318eaa5126",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 365319,
        "created_epoch_time": 1541433950,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "2f3e0077-a157-4f14-8f8e-0d9763da5b5d",
                "type": "single-close-ended",
                "text": "Confia na informação publicada na Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sim",
                    "comments": false
                }, {
                    "text": "Não",
                    "comments": false
                }, {
                    "text": "Não sei",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "f0dc1311-b0d4-4ea8-b9e1-3fdfe4da2d05",
                "type": "single-close-ended",
                "text": "Acredita que a Trustpilot gere as opiniões correctamente?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sim",
                    "comments": false
                }, {
                    "text": "Não",
                    "comments": false
                }, {
                    "text": "Não sei",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "47edd959-1629-4f44-9b79-b7c8090446f1",
                "type": "single-close-ended",
                "text": "Acha que a Trustpilot lhe fornece informação relevante?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sim",
                    "comments": false
                }, {
                    "text": "Não",
                    "comments": false
                }, {
                    "text": "Não sei",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "e01ce4c7-1aaf-4e18-9de4-cb21e104b6f3",
                "type": "single-close-ended",
                "text": "Recomendaria a Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sim",
                    "comments": false
                }, {
                    "text": "Não",
                    "comments": false
                }, {
                    "text": "Não sei",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "46fe6685-9924-434e-8954-935f6c219cac",
                "type": "single-close-ended",
                "text": "Considera a Trustpilot uma empresa transparente e aberta?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sim",
                    "comments": false
                }, {
                    "text": "Não",
                    "comments": false
                }, {
                    "text": "Não sei",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Obrigada pela sua resposta!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "pt",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 89,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://pt.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }],
        "uuid": "d12a0da7-7ca6-4660-8e87-c6ed026e37e1",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 365317,
        "created_epoch_time": 1541433641,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "b4122728-2d3d-489a-bbe4-35ef47d0f4ef",
                "type": "single-close-ended",
                "text": "Stoler du på informasjonen du finner hos Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nei",
                    "comments": false
                }, {
                    "text": "Jeg vet ikke",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "b64b19c9-dd3f-4f7c-9f6c-122dbcb36d05",
                "type": "single-close-ended",
                "text": "Stoler du på at Trustpilot håndterer anmeldelser korrekt?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nei",
                    "comments": false
                }, {
                    "text": "Jeg vet ikke",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "c7f2fcc7-d396-441f-9e93-f33cfc3b0ddb",
                "type": "single-close-ended",
                "text": "Gir Trustpilot deg relevant informasjon?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nei",
                    "comments": false
                }, {
                    "text": "Jeg vet ikke",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "6c0af84f-e5fd-44f1-ac43-08a043e4f7e9",
                "type": "single-close-ended",
                "text": "Ville du anbefalt Trustpilot til andre?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nei",
                    "comments": false
                }, {
                    "text": "Jeg vet ikke",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "5f56fbf9-ea89-40f8-9220-4e7935fe5a6b",
                "type": "single-close-ended",
                "text": "Føler du at Trustpilot er en åpen og gjennomsiktig virksomhet?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nei",
                    "comments": false
                }, {
                    "text": "Jeg vet ikke",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Takk for hjelpen!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "nb",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 91,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://no.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "ce8fdf07-bee6-456c-bf69-cbc31fa6f520",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 365315,
        "created_epoch_time": 1541433436,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "947324da-42f5-4268-a770-eb80800df383",
                "type": "single-close-ended",
                "text": "Litar du på informationen som finns på Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nej",
                    "comments": false
                }, {
                    "text": "Jag vet inte",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "93e254cc-539f-4183-b391-536f6aa8bc3a",
                "type": "single-close-ended",
                "text": "Litar du på att Trustpilot gör det rätta i hanteringen av omdömen?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nej",
                    "comments": false
                }, {
                    "text": "Jag vet inte",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "69acaefd-264d-498b-804e-0fb338ce2bc6",
                "type": "single-close-ended",
                "text": "Ger Trustpilot dig relevant information?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nej",
                    "comments": false
                }, {
                    "text": "Jag vet inte",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "edd336d3-1751-4821-a529-91c1cc464a94",
                "type": "single-close-ended",
                "text": "Skulle du rekommendera Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nej",
                    "comments": false
                }, {
                    "text": "Jag vet inte",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "c482d175-5d83-4ae1-a87a-bca6d1bfdb50",
                "type": "single-close-ended",
                "text": "Anser du Trustpilot vara ett öppet och transparent företag?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nej",
                    "comments": false
                }, {
                    "text": "Jag vet inte",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Tack för din hjälp!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "sv",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 90,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://se.trustpilot.com/",
            "name": null,
            "rule_type": null
        }],
        "uuid": "a7b88823-b12b-4446-9067-e228981bba87",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 365312,
        "created_epoch_time": 1541433171,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "29a553e6-e24f-414d-9f3f-fd3689f85d9c",
                "type": "single-close-ended",
                "text": "Ti fidi delle informazioni che trovi sul sito di Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sí",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "Non so",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "23940421-2364-472b-9845-75b0a3f44b4f",
                "type": "single-close-ended",
                "text": "Credi che Trustpilot gestisca correttamente ed equamente le recensioni?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sí",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "Non so",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "86bb8ba0-4624-4b7b-acec-57eb3b91a13d",
                "type": "single-close-ended",
                "text": "Trovi che le informazioni fornite da Trustpilot siano rilevanti?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sí",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "Non so",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "c2d403be-3186-4d01-94eb-fa3f1fda7147",
                "type": "single-close-ended",
                "text": "Raccomanderesti Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sí",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "Non so",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "c2828245-c6be-46b2-9236-44954ff0cf9f",
                "type": "single-close-ended",
                "text": "Pensi che Trustpilot sia un'azienda aperta e trasparente?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sí",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "Non so",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Grazie per la tua risposta!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "it",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 53,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://it.trustpilot.com/",
            "name": null,
            "rule_type": null
        }],
        "uuid": "89b1924f-7a54-4248-92b1-0172aefbaa0d",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 365308,
        "created_epoch_time": 1541432804,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "671fb999-9ec3-404f-ae9c-781d16515f14",
                "type": "single-close-ended",
                "text": "Vertrouw je de informatie die op Trustpilot staat?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nee",
                    "comments": false
                }, {
                    "text": "Weet ik niet",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "94ad4f66-9d9d-4539-bdb6-8be10a6d4082",
                "type": "single-close-ended",
                "text": "Vertrouw je erop dat Trustpilot op correcte wijze reviews beheert en verwerkt?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nee",
                    "comments": false
                }, {
                    "text": "Weet ik niet",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "ce1c3a8c-a07c-4065-950e-0af543eb533e",
                "type": "single-close-ended",
                "text": "Voorziet Trustpilot je van genoeg relevante informatie?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nee",
                    "comments": false
                }, {
                    "text": "Weet ik niet",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "427b4069-2a8b-4a11-965c-75fb1d8c521e",
                "type": "single-close-ended",
                "text": "Zou je Trustpilot aan anderen aanraden?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nee",
                    "comments": false
                }, {
                    "text": "Weet ik niet",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "2e6e3d3d-04b3-4775-837f-d84c5a805cd2",
                "type": "single-close-ended",
                "text": "Beschouw je Trustpilot als een open en transparant bedrijf?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nee",
                    "comments": false
                }, {
                    "text": "Weet ik niet",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Veel dank!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "nl",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 96,
        "targeting": [{
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://nl.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }],
        "uuid": "e73c14ab-e889-4803-b1fa-16e098f0d283",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 365304,
        "created_epoch_time": 1541432272,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "f05d814d-24c0-4aff-aabc-58ced02c7b86",
                "type": "single-close-ended",
                "text": "¿Se fía de la información publicada en Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sí",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "No sé",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "b6f52984-2679-4252-838a-96771a93e22a",
                "type": "single-close-ended",
                "text": "¿Se fía de cómo trata Trustpilot las opiniones? ¿Cree que lo hace correctamente?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sí",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "No sé",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "b2311cf1-4842-40f0-a714-4c8171a7e469",
                "type": "single-close-ended",
                "text": "¿Considera útil la información que le proporciona Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sí",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "No sé",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "137e75bd-16bd-4d97-bfcf-3b404250ad02",
                "type": "single-close-ended",
                "text": "¿Recomendaría usted Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sí",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "No sé",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "a2af1407-624e-4f65-b27e-a815cb740ef2",
                "type": "single-close-ended",
                "text": "¿Considera que Trustpilot es una empresa abierta y transparente?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sí",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "No sé",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Gracias por su respuesta!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "es",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 91,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://es.trustpilot.com/",
            "name": null,
            "rule_type": null
        }],
        "uuid": "c0a935b2-1af2-4bf9-aa99-1186ace0088b",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 365300,
        "created_epoch_time": 1541431862,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "8ff2950b-2c6f-4f0e-9135-428700bcf921",
                "type": "single-close-ended",
                "text": "Você confia nas informações no site da Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sim",
                    "comments": false
                }, {
                    "text": "Não",
                    "comments": false
                }, {
                    "text": "Não sei",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "f39bd1c6-5ac0-4df3-9433-cc7d9965f67c",
                "type": "single-close-ended",
                "text": "Você acredita que a Trustpilot age corretamente ao lidar com avaliações?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sim",
                    "comments": false
                }, {
                    "text": "Não",
                    "comments": false
                }, {
                    "text": "Não sei",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "53be70b2-4511-4132-a29c-742097dca287",
                "type": "single-close-ended",
                "text": "A Trustpilot te fornece informações relevantes?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sim",
                    "comments": false
                }, {
                    "text": "Não",
                    "comments": false
                }, {
                    "text": "Não sei",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "829e8d26-7ae4-42d0-86c0-2f2c520b61f3",
                "type": "single-close-ended",
                "text": "Você recomendaria a Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sim",
                    "comments": false
                }, {
                    "text": "Não",
                    "comments": false
                }, {
                    "text": "Não sei",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "4a2fb207-0d56-49c5-889b-bf12c192d474",
                "type": "single-close-ended",
                "text": "Você considera a Trustpilot uma empresa transparente e franca?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Sim",
                    "comments": false
                }, {
                    "text": "Não",
                    "comments": false
                }, {
                    "text": "Não sei",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Obrigada por sua resposta!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "pt_BR",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 90,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://br.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "3b18d75b-ab0a-4c9f-ba78-3a742e1f0296",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 365297,
        "created_epoch_time": 1541431624,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "a164b77d-754e-441a-8229-8dce90d6d541",
                "type": "single-close-ended",
                "text": "Vertrauen Sie den Informationen auf Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nein",
                    "comments": false
                }, {
                    "text": "Weiß nicht",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "562d7743-c819-411d-bd80-64760cc8f613",
                "type": "single-close-ended",
                "text": "Haben Sie Vertrauen, dass Trustpilot Bewertungen richtig handhabt?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nein",
                    "comments": false
                }, {
                    "text": "Weiß nicht",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "5d161516-5209-4c04-a2ab-6745b8f7d5f2",
                "type": "single-close-ended",
                "text": "Bietet Trustpilot Ihnen relevante Informationen?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nein",
                    "comments": false
                }, {
                    "text": "Weiß nicht",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "042dd0e8-2a9b-40e3-a87a-1845f7e8e053",
                "type": "single-close-ended",
                "text": "Würden Sie Trustpilot weiterempfehlen?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nein",
                    "comments": false
                }, {
                    "text": "Weiß nicht",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "5b14e430-6162-44ed-a3c4-d7d74e72b56f",
                "type": "single-close-ended",
                "text": "Halten Sie Trustpilot für ein transparentes und offenes Unternehmen?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nein",
                    "comments": false
                }, {
                    "text": "Weiß nicht",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Vielen Dank für Ihre Hilfe!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "de",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 82,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://at.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://ch.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://de.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "e87982a9-ecc5-4627-afc3-589bf72c6788",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 365292,
        "created_epoch_time": 1541431208,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "20e19de5-6c6a-4aec-aef7-8825a69ed8b4",
                "type": "single-close-ended",
                "text": "Do you trust the information on Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "21584fc4-2315-4c15-ba2b-ce51a0658562",
                "type": "single-close-ended",
                "text": "Do you trust Trustpilot to do the right thing when handling reviews?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "3df2575e-6266-4de1-aa2c-c03b7747442e",
                "type": "single-close-ended",
                "text": "Does Trustpilot provide you with relevant information?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "53c6342d-1cff-4621-8b13-8d1404580b39",
                "type": "single-close-ended",
                "text": "Would you recommend Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "571d1923-c1ec-4cb6-8784-353ed391b78b",
                "type": "single-close-ended",
                "text": "Do you consider Trustpilot a transparent and open company?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Thank you for answering this poll. Your feedback is highly appreciated!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 40,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://www.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }],
        "uuid": "5416e5d3-bcca-4e3c-b15c-cd4d4bd49e3a",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 365289,
        "created_epoch_time": 1541431036,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "20175d4f-77ee-4d7d-8b3d-08d8fa9be7b7",
                "type": "single-close-ended",
                "text": "Faites-vous confiance aux informations sur Trustpilot ?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Oui",
                    "comments": false
                }, {
                    "text": "Non",
                    "comments": false
                }, {
                    "text": "Je ne sais pas",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "cb5d0718-2380-48bc-8ac4-020c8ed85cb0",
                "type": "single-close-ended",
                "text": "Pensez-vous que Trustpilot gère les avis correctement ?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Oui",
                    "comments": false
                }, {
                    "text": "Non",
                    "comments": false
                }, {
                    "text": "Je ne sais pas",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "025f0182-dca0-49ee-81b6-4f1bbc941ef8",
                "type": "single-close-ended",
                "text": "Est-ce que Trustpilot vous fournit des informations utiles ?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Oui",
                    "comments": false
                }, {
                    "text": "Non",
                    "comments": false
                }, {
                    "text": "Je ne sais pas",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "33546fe3-37dc-4fea-a2d2-089f1ec54d2f",
                "type": "single-close-ended",
                "text": "Recommanderiez-vous Trustpilot ?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Oui",
                    "comments": false
                }, {
                    "text": "Non",
                    "comments": false
                }, {
                    "text": "Je ne sais pas",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "af07d478-1924-4f3e-b8ec-4a800b01b46e",
                "type": "single-close-ended",
                "text": "Considérez-vous Trustpilot comme une entreprise transparente et ouverte ?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Oui",
                    "comments": false
                }, {
                    "text": "non",
                    "comments": false
                }, {
                    "text": "Je ne sais pas",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Merci pour votre réponse !"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "fr",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 51,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://fr.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }],
        "uuid": "07f05b62-527a-4f3e-849e-016d211b1e88",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 365283,
        "created_epoch_time": 1541430630,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "1a91cbd8-4db3-49b7-a9c0-3f939680ae04",
                "type": "single-close-ended",
                "text": "Czy ufasz informacjom na portalu Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Tak",
                    "comments": false
                }, {
                    "text": "Nie",
                    "comments": false
                }, {
                    "text": "Nie wiem",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "181d34ac-9b28-45b2-a5cc-1b718d993871",
                "type": "single-close-ended",
                "text": "Czy ufasz, że Trustpilot podejmuje odpowiednie kroki przetwarzając recenzje?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Tak",
                    "comments": false
                }, {
                    "text": "Nie",
                    "comments": false
                }, {
                    "text": "Nie wiem",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "46db5384-911d-4114-800e-13578a08af63",
                "type": "single-close-ended",
                "text": "Czy otrzymujesz od Trustpilota odpowiednie informacje?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Tak",
                    "comments": false
                }, {
                    "text": "Nie",
                    "comments": false
                }, {
                    "text": "Nie wiem",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "fe5a023e-3880-430d-b383-7967e410117b",
                "type": "single-close-ended",
                "text": "Czy polecił(a)byś portal Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Tak",
                    "comments": false
                }, {
                    "text": "Nie",
                    "comments": false
                }, {
                    "text": "Nie wiem",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "d3142ea7-844f-467d-9163-cc1ed55eee69",
                "type": "single-close-ended",
                "text": "Czy uważasz Trustpilota za transparentną i otwartą firmę?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Tak",
                    "comments": false
                }, {
                    "text": "Nie",
                    "comments": false
                }, {
                    "text": "Nie wiem",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Dziękuję!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "pl",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 94,
        "targeting": [{
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://pl.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }],
        "uuid": "0bc0b436-0cee-44e2-a440-5d5cb0f30536",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 365272,
        "created_epoch_time": 1541429889,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "a606b61a-2ea7-437b-8c27-37e79a160f30",
                "type": "single-close-ended",
                "text": "Do you trust the information on Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "57100316-872c-4910-87a9-1c74b4b378f8",
                "type": "single-close-ended",
                "text": "Do you trust Trustpilot to do the right thing when handling reviews?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "c2b3ff2e-d41c-4224-add7-2900c36ddd93",
                "type": "single-close-ended",
                "text": "Does Trustpilot provide you with relevant information?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "de25e76c-8778-4f51-945d-5e366b323bea",
                "type": "single-close-ended",
                "text": "Would you recommend Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "1e9b78b5-097c-4e7f-838c-2fbcd3cfe175",
                "type": "single-close-ended",
                "text": "Do you consider Trustpilot a transparent and open company?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Yes",
                    "comments": false
                }, {
                    "text": "No",
                    "comments": false
                }, {
                    "text": "I don't know",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Thank you for answering this poll. Your feedback is highly appreciated!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 40,
        "targeting": [{
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://uk.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "a1ab6391-9679-417f-885e-65e59e710490",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#00C764",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }, {
        "id": 363997,
        "created_epoch_time": 1541079756,
        "skin": "dark",
        "background": "#000032",
        "effective_show_branding": false,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "uuid": "7ec1a461-fdba-4bd4-b0fa-d469594db7e0",
                "type": "single-close-ended",
                "text": "Stoler du på oplysningerne, du finder på Trustpilot?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nej",
                    "comments": false
                }, {
                    "text": "Ved ikke",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "e886b207-3f88-4d93-97e7-ac20915a4d9c",
                "type": "single-close-ended",
                "text": "Har du tillid til, at Trustpilot håndterer anmeldelser korrekt?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nej",
                    "comments": false
                }, {
                    "text": "Ved ikke",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "fdc48274-ace8-45cc-9600-64b365dea98d",
                "type": "single-close-ended",
                "text": "Giver Trustpilot dig relevante oplysninger?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nej",
                    "comments": false
                }, {
                    "text": "Ved ikke",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "b2f2c95b-8b58-481f-bce9-42cc3fd5f8de",
                "type": "single-close-ended",
                "text": "Vil du anbefale Trustpilot til andre?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nej",
                    "comments": false
                }, {
                    "text": "Ved ikke",
                    "comments": false
                }],
                "next": "byOrder"
            }, {
                "uuid": "ebbbff4d-3083-4be7-a378-b1a9f8e31b07",
                "type": "single-close-ended",
                "text": "Anser du Trustpilot for at være en gennemsigtig og åben virksomhed?",
                "required": true,
                "randomize_answer_order": false,
                "pin_last_to_bottom": false,
                "answers": [{
                    "text": "Ja",
                    "comments": false
                }, {
                    "text": "Nej",
                    "comments": false
                }, {
                    "text": "Ved ikke",
                    "comments": false
                }],
                "next": "byOrder"
            }],
            "thankyou": "Tak for hjælpen!"
        },
        "connect_visit_data": "never",
        "ask_for_consent": false,
        "language": "da",
        "display_condition": "scroll",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 86,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://dk.trustpilot.com/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "ee217749-aee9-43ff-b1b7-88a475b994d6",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "auto_screenshot": false,
        "etr_enabled": false,
        "show_legal": false,
        "logo_path": null,
        "button_color": "#324FBE",
        "parent_element_selector": null,
        "button_survey_label": null,
        "custom_css": null,
        "targeting_user_attribute_match_logic": "and"
    }],
    "integrations": {
        "optimizely": {
            "tag_recordings": false
        },
        "abtasty": {
            "tag_recordings": false
        },
        "kissmetrics": {
            "send_user_id": false
        },
        "mixpanel": {
            "send_events": false
        },
        "unbounce": {
            "tag_recordings": false
        },
        "hubspot": {
            "enabled": false,
            "send_recordings": false,
            "send_surveys": false
        }
    },
    "features": ["ask.popover_redesign", "client_script.compression.pc", "csq_theme", "error_reporting", "feedback.embeddable_widget", "feedback.widgetV2", "feedback.widget_telemetry", "settings.billing_v2", "survey.embeddable_widget", "survey.image_question", "survey.screenshots", "survey.type_button", "tcvs_v2"],
    "tracking_code_verified": true,
    "cs_project_id": null,
    "account_id": 245590,
    "account_signature": "c10e893c32b5d9935fdce7cedabf6002a1c3fd4a5bcecaa3986eae81d34f2551"
};

! function() {
    "use strict";

    function e(t) {
        return e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        }, e(t)
    }

    function t(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, r(i.key), i)
        }
    }

    function r(t) {
        var r = function(t, r) {
            if ("object" != e(t) || !t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 !== n) {
                var i = n.call(t, "string");
                if ("object" != e(i)) return i;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }
            return String(t)
        }(t);
        return "symbol" == e(r) ? r : String(r)
    }
    var n, i = function() {
        function e(t) {
            var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 10,
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1e3;
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, e), this.send = t, this.batchSize = r, this.flushInterval = n, this.buffer = [], this.flushTimer = null
        }
        var r, n;
        return r = e, (n = [{
            key: "getBuffer",
            value: function() {
                return this.buffer
            }
        }, {
            key: "add",
            value: function(e) {
                var t = this;
                this.buffer.push(e), this.buffer.length >= this.batchSize ? this.flush() : this.flushTimer || (this.flushTimer = setTimeout((function() {
                    t.flush()
                }), this.flushInterval))
            }
        }, {
            key: "flush",
            value: function() {
                this.buffer.length > 0 && (this.send(this.buffer), this.buffer = []), this.flushTimer && (clearTimeout(this.flushTimer), this.flushTimer = null)
            }
        }]) && t(r.prototype, n), Object.defineProperty(r, "prototype", {
            writable: !1
        }), e
    }();

    function a() {
        return a = Object.assign ? Object.assign.bind() : function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var r = arguments[t];
                for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
            }
            return e
        }, a.apply(this, arguments)
    }
    var o, s = function() {
            try {
                return "performance" in window && "now" in window.performance
            } catch (e) {
                return !1
            }
        },
        u = {
            version: 6,
            metricsUrl: (null === (n = window._hjSettings) || void 0 === n ? void 0 : n.metricsUrl) || "https://metrics.hotjar.io",
            sampling: {
                metrics: .1,
                fieldMetrics: .01,
                debug: .5,
                universalDebug: .05 * .1
            },
            browser: {
                hasPerformance: !1,
                shouldLogMetrics: !1,
                inLab: !1
            },
            buffer: {
                bufferSize: 40,
                flushInterval: 3e3
            }
        },
        c = {
            isDebugEnabled: !1,
            isMetricsEnabled: !1,
            isFieldMetricsEnabled: !1,
            loggedMetrics: {},
            genericTags: {}
        },
        l = function(e, t, r) {
            var n;
            c.loggedMetrics[e] = a(a({}, c.loggedMetrics[e]), {}, ((n = {})[t] = r || {}, n))
        },
        d = function(e) {
            if (!e) return "value";
            var t = Object.keys(e)[0];
            return t && e[t] || "value"
        },
        g = function(e) {
            var t, r = null !== (t = e.tag) && void 0 !== t ? t : void 0;
            return c.isDebugEnabled ? a(a(a({}, r), e.extraTags), c.genericTags) : r
        },
        h = function(e, t) {
            if (!o) return !1;
            var r = c.isMetricsEnabled || c.isDebugEnabled;
            return "lab" === e && (r = u.browser.inLab), "field" === e && (r = c.isFieldMetricsEnabled), t ? r && t.flush : r
        },
        f = function(e) {
            var t = !1,
                r = "v=".concat(u.version),
                n = "".concat(u.metricsUrl, "?").concat(r, "&site_id=").concat(window.hjSiteSettings.site_id) + (c.isDebugEnabled ? "&debug=true" : ""),
                i = JSON.stringify(e);
            if ("sendBeacon" in navigator) try {
                t = navigator.sendBeacon.bind(navigator)(n, i)
            } catch (e) {}
            if (!1 === t) try {
                var a = new XMLHttpRequest;
                a.open("POST", n), a.timeout = 1e4, a.send(i)
            } catch (e) {}
            u.browser.shouldLogMetrics && console.debug("New Metrics: ", e)
        },
        p = {
            getConfig: function(e) {
                return u[e]
            },
            getState: function(e) {
                return c[e]
            },
            start: function() {
                try {
                    u.browser = {
                        hasPerformance: s(),
                        shouldLogMetrics: /hjMetrics=1/.test(location.search),
                        inLab: /hjLab=true/.test(location.search)
                    };
                    var e = p.time(),
                        t = window.hjSiteSettings || {},
                        r = t.features,
                        n = t.site_id,
                        a = new Set(r),
                        l = u.sampling;
                    return c.genericTags = {
                        site_id: n
                    }, c.isDebugEnabled = Math.random() <= l.universalDebug || a.has("client_script.metrics.debug") && Math.random() <= l.debug, c.isMetricsEnabled = Math.random() <= l.metrics, c.isFieldMetricsEnabled = c.isMetricsEnabled && Math.random() <= l.fieldMetrics, o = new i(f, u.buffer.bufferSize, u.buffer.flushInterval), e
                } catch (e) {
                    console.debug("Error in metrics.start", {
                        error: e
                    })
                }
            },
            reset: function() {
                c.loggedMetrics = {}
            },
            stop: function() {
                c.isDebugEnabled = !1, c.isMetricsEnabled = !1, c.genericTags = {}
            },
            count: function(e, t) {
                var r = t.incr,
                    n = t.tag,
                    i = t.extraTags,
                    s = t.type;
                try {
                    var u, l = d(n),
                        f = c.loggedMetrics[e],
                        p = 0;
                    if (r ? (p = (f && f[l] || 0) + (r.value || 1), c.loggedMetrics[e] = a(a({}, f), {}, ((u = {})[l] = null != r && r.flush ? 0 : p, u))) : p = 1, h(s, r)) {
                        var m = {
                            name: e,
                            type: "count",
                            value: p,
                            tags: g({
                                tag: n,
                                extraTags: i
                            })
                        };
                        o.add(m)
                    }
                } catch (e) {}
            },
            distr: function(e, t) {
                var r = t.task,
                    n = t.value,
                    i = t.extraTags;
                h() && o.add({
                    name: e,
                    type: "distribution",
                    value: n,
                    tags: g({
                        tag: {
                            task: r
                        },
                        extraTags: i
                    })
                })
            },
            time: function() {
                try {
                    if (!u.browser.hasPerformance) return;
                    return performance.now()
                } catch (e) {}
            },
            timeEnd: function(e, t) {
                var r = t.tag,
                    n = t.start,
                    i = t.total,
                    a = t.extraTags,
                    s = t.type;
                try {
                    var u = p.time();
                    if (!i && !u) return;
                    var c = d(r),
                        f = i || (n && u ? u - n : void 0);
                    if (l(e, c, {}), f && f > 0 && h(s)) {
                        var m = {
                            name: e,
                            type: "distribution",
                            value: Math.round(f),
                            tags: g({
                                tag: r,
                                extraTags: a
                            })
                        };
                        o.add(m)
                    }
                    return u
                } catch (t) {
                    console.debug("Failed to send timer metric: ", {
                        name: e,
                        tag: r,
                        error: t
                    })
                }
            },
            timeIncr: function(e, t) {
                var r, n, i, a, o = t.tag,
                    s = t.start,
                    u = t.flush,
                    g = t.extraTags,
                    h = t.type,
                    f = hj.metrics.time(),
                    m = s && f ? f - s : void 0,
                    v = (r = e, {
                        tagName: n = d(o),
                        start: (a = (i = c.loggedMetrics[r]) && i[n] || {}).start,
                        total: a.total
                    }),
                    w = m ? m + (v.total || 0) : v.total;
                return l(e, v.tagName, {
                    total: w
                }), u && p.timeEnd(e, {
                    tag: o,
                    total: w,
                    extraTags: g,
                    type: h
                }), w
            },
            timeWatcher: function() {
                var e, t = 0,
                    r = !1,
                    n = function() {
                        var r, n = p.time();
                        return t += null !== (r = e && n && n - e) && void 0 !== r ? r : 0, e = p.time(), t
                    };
                return {
                    start: function() {
                        if (!r) return r = !0, e = p.time()
                    },
                    incr: n,
                    end: function() {
                        var r = n();
                        return t = 0, e = void 0, r
                    }
                }
            },
            getErrorMessage: function(e) {
                return e instanceof Error ? e.message : "string" == typeof e ? e : ""
            }
        };

    function m() {
        return m = Object.assign ? Object.assign.bind() : function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var r = arguments[t];
                for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
            }
            return e
        }, m.apply(this, arguments)
    }
    var v = "https://voc.hotjar.com",
        w = [v, "https://voc.ew1-integration-1.hotjarians.net", "https://hj-engage-unmoderated-review.s3.eu-west-1.amazonaws.com"],
        b = "hj-uut",
        y = {
            get: function() {
                var e = window.sessionStorage.getItem(b);
                return e ? JSON.parse(e) : null
            },
            getValue: function(e) {
                var t = y.get();
                return null == t ? void 0 : t[e]
            },
            set: function(e) {
                if (e) {
                    var t, r = null !== (t = y.get()) && void 0 !== t ? t : {};
                    window.sessionStorage.setItem(b, JSON.stringify(m(m({}, r), e)))
                }
            },
            clear: function() {
                window.sessionStorage.removeItem(b)
            },
            validDomains: w
        },
        j = function(e) {
            var t = new URLSearchParams(e);
            return !!t.has("project_uuid") || ("1" === t.get("is_preview") ? t.has("task_uuid") : t.has("response_uuid") && t.has("task_uuid") && t.has("participation_uuid"))
        };

    function _(e, t, r) {
        if (t && !Array.isArray(t) && "number" == typeof t.length) {
            var n = t.length;
            return T(t, void 0 !== r && r < n ? r : n)
        }
        return e(t, r)
    }

    function S(e) {
        return function(e) {
            if (Array.isArray(e)) return T(e)
        }(e) || function(e) {
            if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
        }(e) || function(e, t) {
            if (e) {
                if ("string" == typeof e) return T(e, t);
                var r = Object.prototype.toString.call(e).slice(8, -1);
                return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? T(e, t) : void 0
            }
        }(e) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function T(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var R = function(e) {
            return e.replayRecordingMaskedUrlRegex = "replayRecordingMaskedUrlRegex", e.replayRecordingMaskedUrlRegexRules = "replayRecordingMaskedUrlRegexRules", e
        }(R || {}),
        E = function(e) {
            return e.START = "start", e.NOT_START = "not-start", e.END = "end", e.NOT_END = "not-end", e.CONTAIN = "contain", e.NOT_CONTAIN = "not-contain", e.EXACT = "exact", e.NOT_EXACT = "not-exact", e
        }(E || {});
    var M, O;
    window.hj = window.hj || function() {
        for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++) t[r] = arguments[r];
        (window.hj.q = window.hj.q || []).push(t)
    }, window.hj.metrics = p;
    var I, x, C, N, A, k, U, P, L, B, D, F, z, V, H, q, Y = hj.metrics.start(),
        X = !(!window.CS_CONF || null === (M = window.CS_CONF.voc) || void 0 === M || !M.enabled),
        J = !(window.CS_CONF || !(null !== (O = window.hjSiteSettings.features) && void 0 !== O && O.includes("cs_lite") || window._hjSettings.csid));
    if (window.hjLazyModules = window.hjLazyModules || {
            SURVEY_V2: {
                js: "survey-v2.cb0fd7dc670e59cd4621.js"
            },
            SURVEY_BOOTSTRAPPER: {
                js: "survey-bootstrapper.31d6cfe0d16ae931b73c.js"
            },
            SURVEY_ISOLATED: {
                js: "survey-isolated.31d6cfe0d16ae931b73c.js"
            },
            HEATMAP_RETAKER: {
                js: "heatmap-retaker.f79c0c7bb13d8a14bddc.js"
            },
            SURVEY_INVITATION: {
                js: "survey-invitation.8ae5f08d3bdf8e521bff.js"
            },
            NOTIFICATION: {
                js: "notification.ed2bca043f1d9f8c6b56.js"
            },
            SENTRY: {
                js: "sentry.58c81e3e25532810f6fd.js"
            },
            BROWSER_PERF: {
                js: "browser-perf.8417c6bba72228fa2e29.js"
            },
            USER_TEST: {
                js: "user-test.efa067dac50cab89ea4e.js"
            }
        }, X) window._uxa.push(["start:hotjar", window.hjSiteSettings]), window.hj.scriptLoaded = !0;
    else if (J) {
        var W = (k = (I = window.hjSiteSettings).suppress_all || I.suppress_text || (null === (x = I.suppress_all_on_specific_pages) || void 0 === x ? void 0 : x.length), U = function(e) {
                var t, r, n, i, a, o = {
                    anonymisationMethod: null,
                    replayRecordingMaskedUrlRegex: null,
                    replayRecordingMaskedUrlRegexRules: null
                };
                if ((e.suppress_all || e.suppress_text) && (o.anonymisationMethod = R.replayRecordingMaskedUrlRegex, o.replayRecordingMaskedUrlRegex = ".*"), null !== (t = e.suppress_all_on_specific_pages) && void 0 !== t && t.length) {
                    o.anonymisationMethod = R.replayRecordingMaskedUrlRegexRules;
                    var s = (r = e.suppress_all_on_specific_pages, n = {
                        contains: E.CONTAIN,
                        regex: E.CONTAIN,
                        simple: E.CONTAIN,
                        ends_with: E.END,
                        exact: E.EXACT,
                        starts_with: E.START
                    }, i = [], a = Object.keys(n), r.forEach((function(e) {
                        if (e.pattern && a.includes(e.match_operation)) {
                            var t = {
                                operator: n[e.match_operation],
                                value: e.pattern,
                                ignoreQueryParams: "simple" === e.match_operation,
                                ignoreURIFragments: "simple" === e.match_operation,
                                ignoreCaseSensitivity: "simple" === e.match_operation,
                                notOperator: e.negate
                            };
                            i.push(t)
                        }
                    })), i.length ? i : void 0);
                    o.replayRecordingMaskedUrlRegexRules = s || null
                }
                return o
            }(I), P = U.anonymisationMethod, L = U.replayRecordingMaskedUrlRegex, B = U.replayRecordingMaskedUrlRegexRules, D = !(null === (C = _hjSettings) || void 0 === C || !C.environment || "live" === _hjSettings.environment), {
                CS_CONF_BASE: {
                    projectId: I.cs_project_id,
                    smbConfig: {
                        siteId: I.site_id,
                        record: !!hjSiteSettings.record,
                        useCSTC: !0,
                        useSentry: !0,
                        csLiteDomain: D ? "insights-integration.live.eks.hotjar.com" : "insights.hotjar.com"
                    },
                    hostnames: [window.location.hostname],
                    voc: null !== (N = I.polls) && void 0 !== N && N.length || (V = null !== (z = function() {
                        var e = document.referrer;
                        if ("string" == typeof e && function(e) {
                                if ("string" != typeof e) return !1;
                                try {
                                    var t = new URL(e),
                                        r = "1" === t.searchParams.get("is_preview");
                                    return !!w.some((function(t) {
                                        return null == e ? void 0 : e.includes(t)
                                    })) || !!r && t.hostname.endsWith(".hotjar.com") && t.pathname.includes("research/projects/tests")
                                } catch (e) {
                                    return !1
                                }
                            }(e) && j(new URL(e).search)) return e
                    }()) && void 0 !== z ? z : function() {
                        var e = new URLSearchParams(window.location.search).get("hj_uut");
                        if (w.some((function(e) {
                                var t;
                                return null === (t = document.referrer) || void 0 === t ? void 0 : t.includes(e)
                            })) && e) {
                            var t = window.atob(e);
                            if (j(t)) {
                                var r = new URL(v);
                                return r.search = t, r.toString()
                            }
                        }
                    }(), H = void 0 !== V, q = null !== y.get(), H && y.set({
                        referrer: V
                    }), q || H) ? {
                        enabled: 1,
                        siteId: I.site_id
                    } : {
                        enabled: 0
                    },
                    whitelistedAttributes: [],
                    anonymizeDigits: !!k || I.anonymize_digits,
                    implementations: (A = I, _(S, (F = A.state_change_listen_mode, "manual" === F ? [] : [{
                        template: {
                            name: "ArtificialPageview",
                            args: {}
                        },
                        triggers: [{
                            name: "HistoryChange",
                            args: {
                                listeners: "popstate, pushState, replaceState" + ("automatic_with_fragments" === F ? ", hashchange" : ""),
                                useDebounce: "no",
                                window: 400
                            }
                        }]
                    }]))),
                    recordTargetingRules: _(S, I.record_targeting_rules),
                    anonymisationMethod: P,
                    replayRecordingMaskedUrlRegex: L,
                    replayRecordingMaskedUrlRegexRules: B
                },
                PII_SELECTORS: I.suppress_all ? ["picture, img, video, audio"] : null
            }),
            K = W.CS_CONF_BASE,
            Q = W.PII_SELECTORS;
        window.CS_CONF_BASE = K, window._uxa = window._uxa || [], Q && window._uxa.push(["setPIISelectors", {
            PIISelectors: Q
        }]);
        var $ = window._hjSettings.environment,
            G = "t.contentsquare.net";
        $ && "live" !== $ && (window._hjSettings.csid && (window.CS_CONF_BASE.projectId = window._hjSettings.csid), G = "t-staging.contentsquare.net");
        var Z = document.createElement("script");
        Z.type = "text/javascript", Z.async = !0, Z.src = "//".concat(G, "/uxa/smb/tag.js"), document.getElementsByTagName("head")[0].appendChild(Z)
    } else window.hjBootstrap = window.hjBootstrap || function(e, t, r) {
        var n, i = new RegExp("bot|google|headless|baidu|bing|msn|duckduckbot|teoma|slurp|yandex|phantomjs|pingdom|ahrefsbot|facebook", "i"),
            a = (null === (n = window.navigator) || void 0 === n ? void 0 : n.userAgent) || "unknown";
        if (i.test(a)) return hj.metrics.count("session-rejection", {
            tag: {
                reason: "bot"
            }
        }), void console.warn("Hotjar not launching due to suspicious userAgent:", a);
        var o = "http:" === window.location.protocol,
            s = Boolean(window._hjSettings.preview);
        if (o && !s) return hj.metrics.count("session-rejection", {
            tag: {
                reason: "https"
            }
        }), void console.warn("For security reasons, Hotjar only works over HTTPS. Learn more: https://help.hotjar.com/hc/en-us/articles/115011624047");
        var u = function(e, t, r) {
            window.hjBootstrapCalled = (window.hjBootstrapCalled || []).concat(r), window.hj && window.hj._init && window.hj._init._verifyInstallation && hj._init._verifyInstallation()
        };
        u(0, 0, r);
        var c = window.document,
            l = c.head || c.getElementsByTagName("head")[0];
        hj.scriptDomain = e;
        var d = c.createElement("script");
        d.async = 1, d.src = hj.scriptDomain + t, d.charset = "utf-8", l.appendChild(d), u.revision = "b9f8175", window.hjBootstrap = u
    }, window.hjBootstrap("https://script.hotjar.com/", "modules.3128f1ee3ce5b65c4961.js", "391767"), hj.metrics.timeEnd("resource-blocking-time", {
        tag: {
            resource: "hotjar-js"
        },
        start: Y,
        type: "lab"
    })
}();
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            n = (new Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "a64e6e4a-87ff-5adf-ae46-ade1dfba84eb")
    } catch (e) {}
}();
//# debugId=a64e6e4a-87ff-5adf-ae46-ade1dfba84eb
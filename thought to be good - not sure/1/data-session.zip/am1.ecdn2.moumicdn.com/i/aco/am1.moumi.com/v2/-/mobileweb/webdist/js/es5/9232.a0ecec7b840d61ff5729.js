var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "9dd054af-9b9e-4368-89c5-610b6af02a3e", e._sentryDebugIdIdentifier = "sentry-dbid-9dd054af-9b9e-4368-89c5-610b6af02a3e")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "9dd054af-9b9e-4368-89c5-610b6af02a3e", e._sentryDebugIdIdentifier = "sentry-dbid-9dd054af-9b9e-4368-89c5-610b6af02a3e")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [9232], {
            19232: function(e, t, r) {
                r.d(t, {
                    A: function() {
                        return x
                    }
                });
                r(27495), r(5746), r(74423), r(21699), r(71761), r(26099), r(3362), r(51629), r(23500), r(79432), r(62062), r(25276), r(60739), r(27208), r(45700), r(89572), r(52675), r(89463), r(2892), r(84185), r(2008), r(83851), r(81278), r(67945);
                var o = r(36521),
                    n = r(99417),
                    i = r(85208),
                    s = r(89610),
                    a = r(1978),
                    u = r(18084),
                    p = r(58544),
                    c = r(76598),
                    d = r(58385),
                    l = r(3508),
                    f = r(27378),
                    h = r(71672),
                    v = r(32308),
                    _ = r(31709),
                    m = r(92105),
                    g = r(5586),
                    b = r(73090),
                    w = r(84256);
                var y = r(65297);

                function A(e, t) {
                    var r = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var o = Object.getOwnPropertySymbols(e);
                        t && (o = o.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), r.push.apply(r, o)
                    }
                    return r
                }

                function R(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? A(Object(r), !0).forEach((function(t) {
                            I(e, t, r[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : A(Object(r)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                        }))
                    }
                    return e
                }

                function I(e, t, r) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var r = e[Symbol.toPrimitive];
                            if (void 0 !== r) {
                                var o = r.call(e, t || "default");
                                if ("object" != typeof o) return o;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: r,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = r, e
                }
                var P = u.A.getLogger("ExternalProvider"),
                    E = function(e) {
                        if (e || "undefined" == typeof window) {
                            if (!e) return ""
                        } else e = n.A.location.hostname;
                        var t = e.match(/\w+\.\w+$/);
                        return t ? t[0] : ""
                    }(),
                    S = "cb.html",
                    O = ["https://localhost." + E + "/" + S],
                    k = {
                        FOUND_CONNECTION_BLOCK: 1,
                        NOT_FOUND_CONNECTION_BLOCK: 3,
                        AUTH_ERROR: 2
                    },
                    C = l.A.get("persistence.auth.key");

                function j() {}

                function T(e) {
                    return (e = R({}, e)).startImport && !e.returnRoute && (e.returnRoute = d.A.getUrl()), e
                }(0, i.A)(j.prototype, p.zb, {
                    init: function() {
                        (0, m.A)(this), y.A.on(y.A.Session.LOGOUT, this.onSessionLogout_, this).on(y.A.Session.SESSION_CHANGED, this.deleteProvidersCache, this), this.providers_ = {}
                    },
                    EVENTS: k,
                    providers_: {},
                    authenticationState_: null,
                    popupWindow_: null,
                    popupCheckTimer_: null,
                    handleAuthenticationFailure_: function() {
                        this.startImportReject_ && this.startImportReject_(), this.trigger(k.AUTH_ERROR)
                    },
                    onExternalProviderMessage_: function(e) {
                        var t, r, o = e.origin.search(E) >= 0,
                            i = null == e || null == (t = e.data) ? void 0 : t.href,
                            s = (null == i ? void 0 : i.includes(S)) && (null == i ? void 0 : i.includes(E));
                        if (o && s) {
                            var a = e.data.success,
                                u = this.authenticationState_;
                            if (!a) return this.removeStoredAuthData(), this.handleAuthenticationFailure_(), null;
                            this.authenticationState_.success = a, this.stopPopupCheckTimer_(), n.A.removeEventListener("message", this.onExternalProviderMessage_);
                            var p = null == e || null == (r = e.data) ? void 0 : r.href.match(W());
                            return p && (this.authenticationState_ = null, u.startImport ? this.startImportProgress(u) : this.processOauthState(u)), this.removeStoredAuthData(), this.popupWindow_.close(), this.popupWindow_ = null, p
                        }
                    },
                    login: function(e) {
                        void 0 === e && (e = {});
                        var t = e,
                            r = t.personId,
                            o = t.provider,
                            n = t.providerContext,
                            i = t.providerType;
                        if (!(0, v.Rg)(i) || !(0, v.Rg)(n)) {
                            var s = "The providerType or providerContext is not valid: type: " + i + " context: " + n;
                            return P.error(s), Promise.reject(new Error(s))
                        }
                        if (r) {
                            if (o) return this.onLogin_(e, o)
                        } else {
                            var a = this.getCachedProvider_(n, i) || o;
                            if (a) return this.onLogin_(e, a)
                        }
                        return this.getProvider({
                            providerType: i,
                            providerContext: n,
                            personId: r,
                            referrer: e.referrer,
                            useSync: e.useSync
                        }).then(this.onLogin_.bind(this, e))
                    },
                    loginAsPromise: function(e) {
                        var t = this;
                        return new Promise((function(r, o) {
                            function n(e) {
                                this.off(k.AUTH_ERROR, n, this), e ? o(e) : r(!1)
                            }
                            t.on(k.AUTH_ERROR, n, t), t.login(R(R({}, e), {}, {
                                callback: function(e) {
                                    t.off(k.AUTH_ERROR, n, t), r(e)
                                }
                            }))
                        }))
                    },
                    onLogin_: function(e, t) {
                        var r;
                        e.provider = t, e.providerId = t.id;
                        var i = this.authenticationState_ = e;
                        if (this.popupWindow_ && !this.popupWindow_.closed) try {
                            this.popupWindow_.close(), this.popupWindow_ = null
                        } catch (e) {
                            return
                        }
                        n.A.removeEventListener("message", this.onExternalProviderMessage_), n.A.addEventListener("message", this.onExternalProviderMessage_);
                        var s, a = null == (r = t.auth_data) ? void 0 : r.oauth_url;
                        o.A.cantCloseWindows && !e.dontRedirect || (0, c.a)() ? this.popupBlockedFlow_(i, a, e) : (n.A._moumi_noLoginPopup || (s = this.popupWindow_ = n.A.open(a, "_externalProvider")), !this.isWindowBlocked_(s) || e.dontRedirect ? (this.setStoredAuthData(T(i)), this.startPopupCheckTimer_()) : this.popupBlockedFlow_(i, a, e))
                    },
                    isWindowBlocked_: function(e) {
                        return !e || e.closed
                    },
                    popupBlockedFlow_: function(e, t, r) {
                        n.A.removeEventListener("message", this.onExternalProviderMessage_), this.popupWindow_ = null, this.setStoredAuthData(T(e)), r.skipRememberStates || d.A.saveHistory(2), r.callback && r.callback(), n.A.location = t
                    },
                    startPopupCheckTimer_: function() {
                        var e = this;
                        this.popupCheckTimer_ || (this.popupCheckTimer_ = setInterval((function() {
                            e.popupWindow_ && !e.popupWindow_.closed && e.popupWindow_.top || (e.stopPopupCheckTimer_(), e.popupWindow_ = null, e.authenticationState_.success || e.handleAuthenticationFailure_())
                        }), 500))
                    },
                    stopPopupCheckTimer_: function() {
                        clearInterval(this.popupCheckTimer_), this.popupCheckTimer_ = null
                    },
                    deleteProvidersCache: function() {
                        this.providers_ = {}
                    },
                    getProvider: function(e) {
                        return this.getSupportedProviders(e).then((function(t) {
                            var r = t[e.providerType];
                            if (!r) throw new Error("No matching external provider.");
                            return r
                        }))
                    },
                    getCachedProvider_: function(e, t) {
                        var r = this.providers_[e] || null;
                        return t ? r && (r[t] || null) : r
                    },
                    setProviderData: function(e, t) {
                        var r = this;
                        e && t && (this.providers_[e] || (this.providers_[e] = {}), t.forEach((function(t) {
                            r.providers_[e][t.type] = t
                        })))
                    },
                    getSupportedProviders: function(e) {
                        var t = this,
                            r = e.personId;
                        if (!r) {
                            var o = this.getCachedProvider_(e.providerContext);
                            if (o) return Promise.resolve(o)
                        }
                        return "boolean" == typeof e.referrer && (e.trackJinba = e.referrer, e.referrer = null), new Promise((function(o, n) {
                            var i = {
                                context: e.providerContext
                            };
                            r && (i.person_id = r), e.referrer && (i.referrer = e.referrer);
                            var s = new _.Ay(362, i).onResponse(363, (function(n) {
                                if (r) {
                                    var i = function(e) {
                                        var t = {};
                                        return e.forEach((function(e) {
                                            t[e.type] = e
                                        })), t
                                    }(n.providers);
                                    o(i)
                                } else void 0 !== n.providers && t.setProviderData(e.providerContext, n.providers), o(t.providers_[e.providerContext] || {})
                            })).onResponse(1, (function(e) {
                                L(e), n(e)
                            })).onError(n);
                            e.trackJinba && f.A.trackRPC(s), s.setIsSynchronous(e.useSync), s.request()
                        }))
                    },
                    onSessionLogout_: function() {
                        this.stopPopupCheckTimer_(), this.popupWindow_ = null, this.authenticationState_ = null, this.removeStoredAuthData(), this.deleteProvidersCache()
                    },
                    startImport: function(e) {
                        var t = this;
                        e.startImport = !0;
                        var r = new Promise((function(e, r) {
                            t.startImportResolve_ = e, t.startImportReject_ = r
                        }));
                        return e.returnRoute && d.A.navigate(e.returnRoute, e.replaceCurrentUrl, R(R({}, e), {}, {
                            importPromise: r
                        })), this.login(e), r
                    },
                    startImportProgress: function(e) {
                        var t = this,
                            r = e.providerId,
                            o = e.providerContext,
                            n = e.referrer,
                            i = e.personId,
                            s = e.importFlow,
                            a = e.inviteFlow,
                            u = e.albumType,
                            p = e.allAlbums,
                            c = e.limit;
                        if (!r) return Promise.reject(new Error("No provider ID given or found"));
                        if ("1" === r) return P.error("Wrong provider ID: 1"), Promise.reject(new Error("Wrong provider ID: 1"));
                        var d = {
                            auth_credentials: {
                                provider_id: r,
                                context: o,
                                natively_authenticated: !1
                            }
                        };
                        if (n && (d.context = n), 1 === o) {
                            var l = {};
                            i && (l.person_id = i), s && (l.flow = s), a && (l.invite_flow = a), Object.keys(l).length > 0 && (d.start_contact_import_data = l)
                        } else if (2 === o || 14 === o) {
                            var f = {
                                all_albums: Boolean(p)
                            };
                            u && (f.album_type = u), d.start_photo_import_data = f, c && (d.limit = c), d.force_new_import = !0
                        }
                        return new Promise((function(e, r) {
                            var o = function(e) {
                                P.error("Start import failed: " + e), t.startImportReject_ && (t.startImportReject_(e), t.startImportReject_ = null), r(e)
                            };
                            new _.Ay(364, d).onResponse(365, (function(o) {
                                t.checkImport_(e, r, o)
                            })).onResponse(1, (function(e) {
                                L(e), o(e)
                            })).onError(o).request()
                        }))
                    },
                    checkImport_: function(e, t, r, o) {
                        var n = this;
                        if (r.complete) r.success ? this.startImportResolve_ ? (this.startImportResolve_(r), this.startImportResolve_ = null) : e(r) : this.startImportReject_ ? (this.startImportReject_(r), this.startImportReject_ = null) : t(r);
                        else {
                            var i = function(e) {
                                    P.error("Check import failed: " + e), n.startImportReject_ && (n.startImportReject_(e), n.startImportReject_ = null), t(e)
                                },
                                s = new _.Ay(366, {
                                    import_id: r.import_id
                                }).onResponse(365, (function(r) {
                                    n.checkImport_(e, t, r, o)
                                })).onResponse(1, (function(e) {
                                    L(e), i(e)
                                })).onError(i);
                            (o = ("number" == typeof o ? o : 0) + 500) > 7500 ? (this.startImportReject_ && (this.startImportReject_(r), this.startImportResolve_ = null), t(r)) : setTimeout(s.request.bind(s), o)
                        }
                    },
                    finishImport: function(e, t, r) {
                        return t || (t = {}), e && (t.import_id = e), r && (t.status = r), new Promise((function(e, r) {
                            new _.Ay(367, t).onResponse(369, (function(t) {
                                t.getSuccess() ? e(t) : r(new Error("Finish import returned unsuccessful result"))
                            })).onResponse(1, (function(e) {
                                L(e), r(e)
                            })).onError(r).request()
                        }))
                    },
                    finishFriendsImport: function(e, t, r, o) {
                        var n = {
                            contacts: (t = t || []).map((function(e) {
                                return {
                                    contacts: [{
                                        contact: e,
                                        type: r
                                    }],
                                    name: ""
                                }
                            })),
                            sms_already_sent: !1
                        };
                        return "string" == typeof o && (n.facebook_request_id = o), this.finishImport(e, {
                            finish_contact_import_data: n
                        })
                    },
                    processOauthState: function(e, t) {
                        (0, s.A)(e.callback) && e.callback(e), 3 === e.providerContext && e.needsAppLogin ? function(e) {
                            var t = e.authState,
                                r = e.redirectUrl,
                                o = t.providerId,
                                n = t.providerType,
                                i = t.returnRoute,
                                s = t.activationPlace;
                            b.A.loginExternalProvider({
                                providerId: o,
                                redirectUrl: r,
                                providerType: n,
                                callback: function(e) {
                                    e && (i ? d.A.navigate(i, t, !0) : (0, w.A)(e, d.A, g.A) || d.A.navigate(l.A.get("default.page"), !0))
                                },
                                activationPlace: s
                            })
                        }({
                            authState: e,
                            redirectUrl: this.getRedirectUrl(e.providerType)
                        }) : (0, a.A)((function() {
                            var r = "string" == typeof e.returnRoute ? e.returnRoute.replace("__ID__", e.providerId) : l.A.get("default.page");
                            d.A.navigate(r, !!t || e.replaceCurrentUrl, e)
                        }))
                    },
                    getStoredAuthData: function() {
                        return h.A.getObject(C)
                    },
                    setStoredAuthData: function(e) {
                        return h.A.saveObject(C, e)
                    },
                    removeStoredAuthData: function() {
                        return h.A.remove(C)
                    },
                    getRedirectUrl: function(e) {
                        var t = W();
                        return 4 === e && -1 === O.indexOf(t) && (t = O[0]), t
                    }
                });
                var D = new j;
                D.init();
                var x = D;

                function W() {
                    return "https://" + n.A.location.hostname + "/" + S
                }

                function L(e) {
                    _.aV.send(new _.XX(1, e).toJSON())
                }
            }
        }
    ]);
//# sourceMappingURL=9232.a0ecec7b840d61ff5729.js.map
var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "c44b6dc4-3f7e-4639-930a-e1abe42af393", e._sentryDebugIdIdentifier = "sentry-dbid-c44b6dc4-3f7e-4639-930a-e1abe42af393")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "c44b6dc4-3f7e-4639-930a-e1abe42af393", e._sentryDebugIdIdentifier = "sentry-dbid-c44b6dc4-3f7e-4639-930a-e1abe42af393")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [349], {
            3388: function(e, t, o) {
                var n = o(58544);
                t.A = (0, n.lh)()
            },
            17001: function(e, t, o) {
                o(69085), o(62062), o(26099), o(3362), o(51629), o(23500);
                var n, r = o(73090),
                    a = o(15566),
                    i = o(23735),
                    c = o(79860),
                    u = o(33263),
                    p = o(58336),
                    l = o(31087),
                    s = o(58544),
                    d = o(3388),
                    f = o(64058),
                    T = ((n = {})[1] = 1, n[12] = 4, n[9] = 7, n[3] = 6, n[2] = 5, n),
                    P = (0, p.A)("PHOTO", "VIDEO"),
                    g = (0, p.A)("PHOTO_UPLOADED"),
                    y = Object.assign({}, s.zb, {
                        uploadMedia: function(e) {
                            e.mediaType === P.VIDEO ? function(e) {
                                e.photos.forEach((function(t) {
                                    var o = {
                                            video_id: t,
                                            num_added: 1,
                                            num_videos: 1
                                        },
                                        n = f.A[e.providerType];
                                    void 0 !== n && (o.source = n);
                                    var r = T[e.providerType];
                                    void 0 !== r && (o.import_source = r), void 0 !== e.activationPlace && (o.activation_place = e.activationPlace), (0, c.sx)(126, o)
                                }))
                            }(e) : function(e) {
                                e.photos.forEach((function(t) {
                                    var o = {
                                            photo_id: t
                                        },
                                        n = T[e.providerType];
                                    void 0 !== n && (o.photo_import_method = n), void 0 !== e.activationPlace && (o.activation_place = e.activationPlace), (0, c.sx)(19, o)
                                }))
                            }(e);
                            var t = {
                                photos: e.photos.map((function(t) {
                                    return u.A.createProtoInstance(a.ryQ, {
                                        external_album_id: e.albumId,
                                        external_provider_id: e.providerId,
                                        photo_id: t,
                                        photo_source: 3
                                    })
                                }))
                            };
                            t.album_type = e.albumType, e.requestedByUserId && (t.requested_by_user_id = e.requestedByUserId);
                            var o = u.A.createProtoInstance(a.UYE, t);
                            e.photoToReplace && o.setPhotosToReplace([e.photoToReplace]);
                            return new Promise((function(t, n) {
                                new i.Ay(495, o).on(496, (function(o, a) {
                                    if (o) n(o);
                                    else {
                                        e.mediaType === P.PHOTO && y.trigger(g.PHOTO_UPLOADED), e.mediaType === P.VIDEO && (r.A.getUser().video_count > 0 || l.A.getInstance().invalidateAll()), d.A.trigger();
                                        var i = a.getAlbum();
                                        t(i)
                                    }
                                })).request()
                            }))
                        },
                        MediaType: P,
                        EVENTS: g
                    });
                t.A = y
            },
            64266: function(e, t, o) {
                o.d(t, {
                    A: function() {
                        return f
                    }
                });
                var n, r = o(15566),
                    a = o(73090),
                    i = o(93529),
                    c = o(40075),
                    u = o(18084),
                    p = o(25093),
                    l = 124,
                    s = 25,
                    d = u.A.getLogger("session");

                function f(e, t) {
                    return !! function(e, t) {
                        if (t === l) return !0;
                        return e instanceof r.beZ && ("1" === e.getErrorCode() || e.getType() === s)
                    }(e, t) && (function(e) {
                        var t, o = (0, p.A)(e);
                        o && d.error("Attempt to use failed session", {
                            error: e,
                            url: null == (t = window) ? void 0 : t.location.href
                        });
                        if (e instanceof r.beZ && "1002" === e.getErrorCode()) return;
                        if (n && Date.now() < n + 3e4) return void(p.A && d.error("Additional attempt to use failed session, could lead to infinite loader", {
                            error: e
                        }));
                        n = Date.now(), a.A.logout(!0), i.A.showNotification({
                            type: i.A.TYPES.INFO,
                            text: c.Ay.get(521)
                        })
                    }(e), !0)
                }
            },
            85608: function(e, t, o) {
                o.d(t, {
                    T: function() {
                        return B
                    }
                });
                o(45700), o(89572), o(52675), o(89463), o(2892), o(84185), o(2008), o(83851), o(51629), o(23500), o(81278), o(67945), o(50113), o(26099), o(74423), o(3362), o(23792), o(47764), o(62953), o(27495), o(25276), o(79432), o(38781), o(60739), o(27208), o(69085);
                var n, r, a, i, c, u, p = o(85208),
                    l = o(42302),
                    s = o(58544),
                    d = o(35837),
                    f = o(58385),
                    T = o(5586),
                    P = o(47632),
                    g = o(18084),
                    y = o(49683),
                    m = o(26935),
                    A = o(41025),
                    E = o(17001),
                    _ = o(49952),
                    I = o(58336),
                    v = o(3208),
                    O = o(15566),
                    b = o(74389),
                    S = o(63620);

                function h(e, t) {
                    var o = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var n = Object.getOwnPropertySymbols(e);
                        t && (n = n.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), o.push.apply(o, n)
                    }
                    return o
                }

                function D(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var o = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? h(Object(o), !0).forEach((function(t) {
                            k(e, t, o[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : h(Object(o)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t))
                        }))
                    }
                    return e
                }

                function k(e, t, o) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var o = e[Symbol.toPrimitive];
                            if (void 0 !== o) {
                                var n = o.call(e, t || "default");
                                if ("object" != typeof n) return n;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: o,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = o, e
                }
                var w = g.A.getLogger("BannersHelper"),
                    N = (0, I.A)("START_PAYMENT", "END_PAYMENT"),
                    R = ((n = {})[127] = b.x.ATTENTION_BOOST_EXPLANATION, n[32] = b.x.EXTRA_SHOWS_EXPLANATION, n[28] = b.x.RISEUP_EXPLANATION, n[175] = b.x.BUNDLE_SALE_EXPLANATION, n[226] = b.x.CRUSH_EXPLANATION, n),
                    B = {
                        ADD_PHOTO: "add-photo",
                        ATTENTION_BOOST: "attention-boost",
                        BUNDLE_SALE: "bundle-sale",
                        CHAT_WITH_NEWBIES: "chat-with-newbies",
                        CHAT_WITH_TIRED: "chat-with-tired",
                        CRUSH: "crush",
                        ENCOUNTERS: "encounters",
                        EXTRA_SHOWS: "extra-shows",
                        ENABLE_NOTIFICATIONS: "enable-notifications",
                        FAVOURITES: "favourites",
                        GET_VERIFIED: "get-verified",
                        INVISIBLE_MODE: "invisible-mode",
                        LIKED_YOU: "liked-you",
                        LIKED_YOU_PREMIUM_PLUS: "liked-you-premium-plus",
                        MESSENGER_MINI_GAME: "messenger-mini-game",
                        PREMIUM_PLUS: "premium-plus",
                        QUALITY_WALKTHROUGH: "quality-walkthrough",
                        QUESTIONS_IN_PROFILE: "questions-in-profile",
                        RISEUP: "riseup",
                        SPECIAL_DELIVERY: "special-delivery",
                        SPP: "premium",
                        STICKERS: "stickers",
                        UNDO_VOTE: "undo",
                        VIDEO_CHAT: "video-chat-explanation"
                    },
                    L = ((r = {})[326] = B.LIKED_YOU_PREMIUM_PLUS, r[558] = B.PREMIUM_PLUS, r),
                    U = ((a = {})[12] = B.ADD_PHOTO, a[56] = B.ATTENTION_BOOST, a[57] = B.BUNDLE_SALE, a[4] = B.CHAT_WITH_NEWBIES, a[5] = B.CHAT_WITH_TIRED, a[96] = B.CRUSH, a[106] = B.ENABLE_NOTIFICATIONS, a[11] = B.EXTRA_SHOWS, a[10] = B.EXTRA_SHOWS, a[6] = B.FAVOURITES, a[35] = B.UNDO_VOTE, a[7] = B.LIKED_YOU, a[38] = B.LIKED_YOU, a[1] = B.RISEUP, a[16] = B.SPECIAL_DELIVERY, a[3] = B.SPECIAL_DELIVERY, a[65] = B.SPP, a[8] = B.SPP, a[22] = B.STICKERS, a[40] = B.SPECIAL_DELIVERY, a[43] = B.UNDO_VOTE, a[37] = B.INVISIBLE_MODE, a[10017] = B.VIDEO_CHAT, a[165] = B.MESSENGER_MINI_GAME, a[68] = B.GET_VERIFIED, a[199] = B.QUALITY_WALKTHROUGH, a[61] = B.ENCOUNTERS, a[326] = B.LIKED_YOU, a[346] = B.QUESTIONS_IN_PROFILE, a[48] = B.SPP, a[195] = null, a[107] = null, a[557] = B.PREMIUM_PLUS, a[558] = B.PREMIUM_PLUS, a),
                    F = ((i = {})[1] = 8, i[3] = 59, i[4] = 48, i[5] = 24, i[6] = 10, i[7] = 1, i[12] = 58, i[14] = 64, i[16] = 27, i[18] = 58, i[20] = 7, i[21] = 56, i[22] = 57, i[23] = 65, i[25] = 96, i),
                    x = ((c = {})[21] = 127, c[22] = 175, c[25] = 226, c[6] = 32, c[7] = 28, c[66] = 415, c[1] = 19, c[23] = 19, c[47] = 324, c[13] = 38, c),
                    M = ((u = {})[96] = 76, u),
                    C = (0, p.A)({}, s.zb, {
                        EVENTS: N,
                        getFeatureName: function(e, t) {
                            var o;
                            return void 0 === t && (t = !1), t && (o = L[e]), o || (o = U[e]), void 0 === o && w.error("Invalid PROMO_BLOCK_TO_FEATURE_NAME_MAPPING", {
                                promoBlockType: e
                            }), o
                        },
                        getButtonName: function(e) {
                            return M[e]
                        },
                        getFeatureFromPaymentProductType: function(e) {
                            var t = x[e];
                            return t || w.error("Invalid PRODUCT_TYPE_TO_FEATURE_MAPPING", {
                                paymentProductType: e
                            }), t
                        },
                        isFeatureConfigurable: function(e) {
                            return Boolean(e) && 19 !== e && 324 !== e
                        },
                        unifyPromoType: function(e) {
                            switch (e) {
                                case 3:
                                case 16:
                                case 40:
                                    return 40;
                                case 43:
                                case 35:
                                    return 43;
                                default:
                                    return e
                            }
                        },
                        getBadgeTypeForPromoBlock: function(e) {
                            return P.A.getBadgeTypeFromPromoBlock(e)
                        },
                        getPromoBlockForProduct: function(e) {
                            var t = F[e];
                            return t || w.error("Invalid PRODUCT_TO_PROMO_BLOCK", {
                                productType: e
                            }), t
                        },
                        getPictureForPromoBlock: function(e, t) {
                            var o = function(e, t) {
                                t = t || 0;
                                var o = e.getPictures(),
                                    n = o && e.getPictures()[t];
                                if (o && (t < 0 || t >= o.length)) return null;
                                return n ? n.getDisplayImages() : e.getImageId() && e.getImageId()[t]
                            }(e, t.index);
                            return o ? {
                                disableMasking: H(e.getPromoBlockType()),
                                type: P.A.IMAGE_TYPE.URL,
                                value: o
                            } : P.A.getPlaceholderForGender(t.gender)
                        },
                        getPictureForPromoBlockTS: function(e, t) {
                            var o = function(e, t) {
                                var o;
                                void 0 === t && (t = 0);
                                var n = e.pictures,
                                    r = null == n ? void 0 : n[t];
                                if (n && (t < 0 || t >= n.length)) return null;
                                return r ? r.display_images : null == (o = e.image_id) ? void 0 : o[t]
                            }(e, t.index);
                            return o ? {
                                disableMasking: H(e.promo_block_type),
                                type: P.A.IMAGE_TYPE.URL,
                                value: o
                            } : P.A.getPlaceholderForGender(t.gender)
                        },
                        buyCrush: function(e, t, o) {
                            var n = {
                                    from: f.A.getUrl()
                                },
                                r = {
                                    userId: e,
                                    productType: 25
                                };
                            return y.A.getInstance().fetchProductExplanation(25, e).then((function(e) {
                                var a = (0, d.A)(e);
                                if (o) {
                                    var i = a.getPromo().getPictures([])[0];
                                    if (i) {
                                        var c = i.getDisplayImages(),
                                            u = o.getLargeUrl(c);
                                        i.setDisplayImages(u)
                                    }
                                }
                                return V({
                                    hotPanelData: t,
                                    context: n,
                                    params: r,
                                    clientProductExplanation: a,
                                    onAction: l.A
                                })
                            }))
                        },
                        handlePromoSelected: function(e, t, o) {
                            var n, r = e.productType;
                            r && (n = C.getFeatureFromPaymentProductType(r));
                            var a = e.action,
                                i = e.activationPlace,
                                c = e.cost,
                                u = !!e.paymentTransitionInFlow,
                                s = e.popState,
                                P = C.unifyPromoType(e.banner),
                                g = C.isFeatureConfigurable(n),
                                E = e.crossSellTransaction;
                            (t = t || {}).from || w.warn('No "from" parameter given to BannersController. What should we do once payment is completed?');
                            var I = (o = o || {}).onAction || l.A;
                            41 === P && (r = 13, n = 38);
                            var O = {
                                    activationPlace: i,
                                    cost: c,
                                    promoBlockType: P
                                },
                                h = (0, p.A)(O, e.hotPanelData || {});
                            switch (v.A.generate(), a) {
                                case 60:
                                    ! function(e) {
                                        var t, o = e.context,
                                            n = e.cost,
                                            r = e.crossSellTransaction,
                                            a = e.hotPanelData,
                                            i = e.paymentTransitionInFlow,
                                            c = e.popState,
                                            u = e.productType,
                                            p = e.onAction,
                                            l = null == r || null == (t = r.purchase_params) ? void 0 : t.cross_sell_order_id;
                                        if (!l) return void w.error("Trying to perform cross/pack without required transaction id", {
                                            context: o,
                                            hotPanelData: a
                                        });
                                        var s = new Promise((function(e) {
                                                return (0, _.cj)(e)
                                            })),
                                            d = new Promise((function(e) {
                                                m.A.purchase({
                                                    back: o.from,
                                                    cost: n,
                                                    hotPanelData: a,
                                                    paymentTransitionInFlow: i,
                                                    popState: c,
                                                    productType: u,
                                                    purchaseTransactionSetup: {
                                                        crossSellOrderId: l,
                                                        uid: r.uid,
                                                        providerId: r.provider_id
                                                    },
                                                    complete: function(t, n) {
                                                        C.trigger(N.END_PAYMENT, o, {
                                                            isSuccess: t,
                                                            cancelled: n
                                                        }), e(t)
                                                    }
                                                })
                                            }));
                                        Promise.race([s, d]).then((function() {
                                            p(60)
                                        }))
                                    }({
                                        context: t,
                                        cost: c,
                                        crossSellTransaction: E,
                                        hotPanelData: h,
                                        paymentTransitionInFlow: u,
                                        popState: s,
                                        productType: r,
                                        onAction: I
                                    });
                                    break;
                                case 9:
                                    ! function(e) {
                                        var t = e.context,
                                            o = e.cost,
                                            n = e.hotPanelData,
                                            r = e.paymentTransitionInFlow,
                                            a = e.popState,
                                            i = e.productType,
                                            c = e.promoBlockType,
                                            u = e.onAction,
                                            p = null,
                                            l = new Promise((function(e) {
                                                return (0, _.cj)(e)
                                            }));
                                        C.trigger(N.START_PAYMENT, t), p = j(i) ? new Promise((function(e) {
                                            m.A.purchase({
                                                back: t.from,
                                                cost: o,
                                                hotPanelData: n,
                                                paymentTransitionInFlow: r,
                                                popState: a,
                                                productType: i,
                                                promoBlockType: c,
                                                complete: function(o) {
                                                    C.trigger(N.END_PAYMENT, t), e(o)
                                                }
                                            })
                                        })) : new Promise((function(e) {
                                            var p = {
                                                    back: t.from,
                                                    cost: o,
                                                    productType: i,
                                                    hotPanelData: n,
                                                    promoBlockType: c,
                                                    callback: function(t) {
                                                        W(t, {
                                                            productType: i,
                                                            onAction: u
                                                        }), e(t)
                                                    }
                                                },
                                                l = {
                                                    paymentTransitionInFlow: r,
                                                    replace: a
                                                };
                                            A.A.navigateToPayment(p, l)
                                        }));
                                        Promise.race([l, p]).then((function() {
                                            u(60)
                                        }))
                                    }({
                                        context: t,
                                        cost: c,
                                        hotPanelData: h,
                                        paymentTransitionInFlow: u,
                                        popState: s,
                                        productType: r,
                                        promoBlockType: P,
                                        onAction: I
                                    });
                                    break;
                                case 4:
                                    ! function(e) {
                                        var t = e.context,
                                            o = e.cost,
                                            n = e.featureType,
                                            r = e.hotPanelData,
                                            a = e.isFeatureConfigurable,
                                            i = e.paymentTransitionInFlow,
                                            c = e.popState,
                                            u = e.productToActivate,
                                            p = e.productType,
                                            l = e.promoBlockType,
                                            s = e.promoData,
                                            f = e.onAction;
                                        if (C.trigger(N.START_PAYMENT, t), j(p)) a ? y.A.getInstance().fetchProductExplanation(p).then((function(e) {
                                            var o = (0, d.A)(e);
                                            V({
                                                hotPanelData: r,
                                                context: t,
                                                params: s,
                                                clientProductExplanation: o,
                                                onAction: f
                                            })
                                        })).then((function() {
                                            f(60), 1 === p && f(6)
                                        })).catch((function(e) {
                                            if (f(60), e instanceof Error) throw e
                                        })) : Y({
                                            feature: n,
                                            params: {
                                                cost: o,
                                                hotPanelData: r,
                                                popState: c,
                                                productType: p,
                                                promoBlockType: l
                                            },
                                            context: t,
                                            onAction: f
                                        }).then((function() {
                                            f(60), 1 === p && f(6)
                                        })).catch((function() {
                                            f(60)
                                        }));
                                        else {
                                            var T, P = new Promise((function(e) {
                                                    (0, _.cj)(e)
                                                })),
                                                g = new Promise((function(e) {
                                                    T = e
                                                })),
                                                m = {
                                                    back: t.from,
                                                    cost: o,
                                                    hotPanelData: r,
                                                    paymentTransitionInFlow: i,
                                                    productToActivate: u,
                                                    productType: p,
                                                    promoBlockType: l,
                                                    callback: function(e) {
                                                        W(e, {
                                                            productType: p,
                                                            onAction: f
                                                        }), T()
                                                    }
                                                },
                                                E = {};
                                            c && (E.replace = c), A.A.navigateToPayment(m, E), Promise.race([P, g]).then((function() {
                                                f(60)
                                            }))
                                        }
                                    }({
                                        context: t,
                                        cost: c,
                                        featureType: n,
                                        hotPanelData: h,
                                        isFeatureConfigurable: g,
                                        paymentTransitionInFlow: u,
                                        popState: s,
                                        productToActivate: e.productToActivate,
                                        productType: r,
                                        promoBlockType: P,
                                        promoData: e,
                                        onAction: I
                                    });
                                    break;
                                case 2:
                                    (0, _.cj)((function() {
                                        return I(60)
                                    })), G(e).then((function() {
                                        I(2)
                                    }));
                                    break;
                                case 63:
                                    (0, _.cj)((function() {
                                        return I(60)
                                    })),
                                    function(e) {
                                        var t = e.redirectPage,
                                            o = e.redirectPageParams,
                                            n = D(D({}, e), o),
                                            r = T.A.getRouteFromRedirectPage(t.toJSON());
                                        f.A.navigate(r, !!e.popState, n)
                                    }(e);
                                    break;
                                case 13:
                                    (0, _.cj)((function() {
                                        return I(60)
                                    })), f.A.navigate(b.x.OWN_PROFILE_EDIT, {
                                        anchor: S.l.VERIFICATION
                                    });
                                    break;
                                case 52:
                                    (0, _.cj)((function() {
                                        return I(60)
                                    })), f.A.navigate(b.x.SHARE_PROFILE, e.navigateOpts);
                                    break;
                                case 6:
                                    ! function(e) {
                                        var t = e.context,
                                            o = e.productType,
                                            n = e.paymentTransitionInFlow,
                                            r = e.hotPanelData,
                                            a = e.promoBlockType,
                                            i = e.onAction,
                                            c = e.popState;
                                        C.trigger(N.START_PAYMENT, t);
                                        var u, p = new Promise((function(e) {
                                                (0, _.cj)(e)
                                            })),
                                            l = new Promise((function(e) {
                                                u = e
                                            })),
                                            s = {
                                                back: t.from,
                                                productType: o,
                                                paymentTransitionInFlow: n,
                                                hotPanelData: r,
                                                promoBlockType: a,
                                                callback: function(e) {
                                                    W(e, {
                                                        productType: o,
                                                        onAction: i
                                                    }), u()
                                                }
                                            },
                                            d = {};
                                        c && (d.replace = c);
                                        A.A.navigateToPayment(s, d), Promise.race([p, l]).then((function() {
                                            i(60)
                                        }))
                                    }({
                                        context: t,
                                        hotPanelData: h,
                                        paymentTransitionInFlow: u,
                                        popState: s,
                                        productType: r,
                                        promoBlockType: P,
                                        onAction: I
                                    });
                                    break;
                                case 100:
                                    C.trigger(N.START_PAYMENT, t), f.A.navigate(b.x.SPP_TRIAL, !1, {
                                        returnTo: t.from,
                                        context: t.context,
                                        activationPlace: i,
                                        fromBanner: !0
                                    });
                                    break;
                                default:
                                    w.error("Unknown action type", {
                                        actionType: a,
                                        context: t,
                                        params: o,
                                        promoData: e
                                    })
                            }
                        },
                        getActionTypeFromPromoBlock: function(e, t) {
                            t = t || {};
                            var o = e.getOkAction();
                            if (!o) {
                                var n, r = e.getButtons([]);
                                if (r.length > 0)(n = t.ctaType ? r.find((function(e) {
                                    return e.getType() === t.ctaType
                                })) : r[0]) instanceof O.E0i && (o = n.getAction())
                            }
                            return o || t.defaultActionType
                        },
                        getRedirectPageFromPromoBlock: function(e, t) {
                            t = t || {};
                            var o = e.getRedirectPage();
                            if (!o) {
                                var n, r = e.getButtons([]);
                                if (r.length > 0)(n = t.ctaType ? r.find((function(e) {
                                    return e.getType() === t.ctaType
                                })) : r.find((function(e) {
                                    return e.hasRedirectPage()
                                }))) instanceof O.E0i && (o = n.getRedirectPage())
                            }
                            return o
                        },
                        getTrackingData: function(e, t) {
                            var o = {},
                                n = e.getPromoBlockType && e.getPromoBlockType() || e.promo_block_type,
                                r = e.getPromoBlockPosition && e.getPromoBlockPosition() || e.promo_block_position,
                                a = e.getVariantId && e.getVariantId(),
                                i = e.getContext && e.getContext() || e.context,
                                c = function(e) {
                                    void 0 === e && (e = {});
                                    var t = e.getCallToActionType && e.getCallToActionType() || e.call_to_action_type;
                                    if (!t) {
                                        var o = (e.getButtons && e.getButtons() || e.buttons || [])[0] || {};
                                        t = o.getType && o.getType() || o.type || null || 1
                                    }
                                    return t
                                }(e),
                                u = {
                                    banner_id: n,
                                    position_id: r,
                                    context: i,
                                    variation_id: a
                                };
                            return 138 === t && (o = u), 139 === t && (o = D(D({}, u), {}, {
                                call_to_action_type: c
                            })), o
                        }
                    });

                function H(e) {
                    return [65, 41, 57].includes(e)
                }

                function Y(e) {
                    var t = e.feature,
                        o = e.params,
                        n = e.context,
                        r = e.onAction;
                    return r = r || l.A, new Promise((function(e, a) {
                        if (o && o.promoBlock instanceof O.d4N && function(e) {
                                return e && 2 === e.getOkAction()
                            }(o.promoBlock)) return a(new Error("Photos are required to continue with this action")), G({
                            feature: t,
                            back: n.from
                        }).then((function() {
                            r && r(2)
                        }));
                        if (o.isSkipExplanationScreen || -1 === Object.keys(R).indexOf(t.toString())) {
                            var i = o.cost,
                                c = o.promoBlock,
                                u = o.productType,
                                p = o.promoBlockType;
                            u = u || c && c.getOkPaymentProductType(), p = p || c && c.getPromoBlockType(), m.A.purchase({
                                back: n.from,
                                cost: i,
                                hotPanelData: o.hotPanelData,
                                popState: o.popState,
                                productType: u,
                                promoBlockType: p,
                                userId: o.userId,
                                success: function(t) {
                                    return e(t)
                                },
                                error: function(e) {
                                    return a(e)
                                },
                                complete: function() {
                                    return C.trigger(N.END_PAYMENT, n)
                                }
                            })
                        } else {
                            var l = R[t],
                                s = {
                                    promoBlock: o.promoBlock.toJSON(),
                                    reject: a,
                                    resolve: e,
                                    userId: o.userId
                                };
                            (0, _.cj)((function() {
                                return r(60)
                            })), f.A.navigate(l, o.popState, s)
                        }
                    }))
                }

                function j(e) {
                    return 1 !== e && 13 !== e && 47 !== e && 66 !== e
                }

                function V(e) {
                    var t = e.hotPanelData,
                        o = e.context,
                        n = e.params,
                        r = e.clientProductExplanation,
                        a = e.onAction,
                        i = r.getPromo(),
                        c = i.getOkPaymentProductType(),
                        u = C.getFeatureFromPaymentProductType(c),
                        p = i.getPaymentAmount();
                    return !i.getScreenHeader() && r.getScreenHeader() && i.setScreenHeader(r.getScreenHeader()), Object.assign(n, {
                        cost: p,
                        hotPanelData: t,
                        promoBlock: i
                    }), Y({
                        feature: u,
                        params: n,
                        context: o,
                        onAction: a
                    })
                }

                function G(e) {
                    return new Promise((function(t) {
                        f.A.navigate(b.x.ADD_PHOTOS, !1, D(D({}, e), {}, {
                            callback: t
                        })), E.A.once(E.A.EVENTS.PHOTO_UPLOADED, t)
                    }))
                }

                function W(e, t) {
                    var o = t.productType,
                        n = t.onAction;
                    null != e && e.success && 1 === o && n(6)
                }
                t.A = C
            }
        }
    ]);
//# sourceMappingURL=349.171c29bbeeb10c3365c8.js.map
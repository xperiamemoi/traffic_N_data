var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "728be092-0a4f-48e3-8075-2b654b33af0c", e._sentryDebugIdIdentifier = "sentry-dbid-728be092-0a4f-48e3-8075-2b654b33af0c")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "728be092-0a4f-48e3-8075-2b654b33af0c", e._sentryDebugIdIdentifier = "sentry-dbid-728be092-0a4f-48e3-8075-2b654b33af0c")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [1087], {
            15880: function(e, t, r) {
                r(50113), r(26099), r(28706), r(62062), r(79432), r(2892), r(2008), r(51629), r(23500), r(25276);
                var n, i = r(51168),
                    o = r(46996),
                    s = r(44757),
                    a = r(79860),
                    c = r(19420),
                    u = r(64058);
                t.A = {
                    trackAppearance: function(e, t) {
                        f.forEach((function(r) {
                            var n, i = l[r],
                                o = t && t[i] || "",
                                s = e && e[i] || "";
                            o !== s && (n = p(o) ? 3 : p(s) && o ? 1 : 2, (0, a.sx)(33, {
                                field_name: r,
                                update_type: n
                            }))
                        }))
                    },
                    trackInterests: function(e, t, r) {
                        var n;
                        n = 0 === e && t > 0 ? 1 : r > 0 && e <= r ? 3 : 2;
                        (0, a.sx)(33, {
                            field_name: 21,
                            update_type: n
                        })
                    },
                    track: function(e, t, r) {
                        h.forEach((function(n) {
                            var i, c = g(n, t),
                                l = g(n, e);
                            null === l && r || (null === c || (0, o.A)(c, l) || (n in d ? (i = c ? !l && c ? 1 : 2 : 3, (0, a.sx)(33, {
                                field_name: n,
                                update_type: i
                            })) : function(e, t, r) {
                                var n = {
                                    field_name: e
                                };
                                if (6 === e) {
                                    var i = r || "",
                                        o = t || "";
                                    n.about_me_length = i.length, 0 === i.length ? n.update_type = 3 : 0 === o.length ? n.update_type = 1 : n.update_type = 2, (0, a.sx)(33, n)
                                } else if (17 === e) {
                                    var c = t,
                                        d = r;
                                    (0, s.A)(d, c).forEach((function(t) {
                                        (0, a.sx)(33, {
                                            field_name: e,
                                            update_type: 1,
                                            source: u.A[t]
                                        })
                                    })), (0, s.A)(c, d).forEach((function(t) {
                                        (0, a.sx)(33, {
                                            field_name: e,
                                            update_type: 3,
                                            source: u.A[t]
                                        })
                                    }))
                                } else -1 === f.indexOf(e) && (p(r) ? n.update_type = 3 : p(t) && r ? n.update_type = 1 : n.update_type = 2, (0, a.sx)(33, n))
                            }(n, l, c)))
                        }))
                    }
                };
                var d = ((n = {})[1] = "Age", n[4] = "Name", n[7] = "Email", n[8] = "Dob", n[9] = "Gender", n[10] = "Wish", n[12] = "Phone", n[15] = "City", n),
                    l = (0, i.A)(c.QL),
                    f = [26, 28, 27, 22, 23],
                    h = [].concat(Object.keys(l).map(Number), Object.keys(d).map(Number), f, [17]);

                function g(e, t) {
                    if (e in l) return function(e, t) {
                        var r = t.getProfileFields([]).find((function(t) {
                            return t.getType() === e
                        }));
                        return r ? r.getDisplayValue(r.getValue()) : null
                    }(Number(l[e]), t);
                    if (e in d) {
                        var r = t["get" + d[e]](null);
                        return 15 === e && (r = r ? r.getId() : null), r
                    }
                    if (17 === e) {
                        var n = t.getVerifiedInformation();
                        return n ? n.getMethods().filter((function(e) {
                            return e.getIsConnected()
                        })).map((function(e) {
                            return e.getType()
                        })) : null
                    }
                    return null
                }

                function p(e) {
                    return "None" === e || "" === e || "0" === e
                }
            },
            19420: function(e, t, r) {
                var n, i, o, s, a;
                r.d(t, {
                    QL: function() {
                        return l
                    },
                    fn: function() {
                        return c
                    },
                    og: function() {
                        return f
                    },
                    q0: function() {
                        return h
                    },
                    sj: function() {
                        return u
                    },
                    zc: function() {
                        return d
                    }
                });
                var c = 8792 == r.j ? [2, 3, 4, 13, 7, 8, 9, 11, 10, 21, 12, 26, 29, 32, 33, 36, 34, 35] : null,
                    u = 8792 == r.j ? [3, 4, 13, 7, 8, 9, 11, 30, 28, 21, 32, 34, 33, 35, 36] : null,
                    d = ((n = {})[3] = "generic-heart", n[4] = "generic-sexuality", n[13] = "generic-measure", n[7] = "generic-children", n[8] = "generic-smoking", n[9] = "generic-drinking", n[11] = "generic-languages", n[30] = "generic-non-binary", n[28] = "navigation-bar-checkbox-unselected", n[27] = "generic-intentions", n[32] = "generic-zodiac", n[34] = "generic-religion", n[33] = "generic-paw", n[35] = "generic-persona", n[36] = "generic-education", n[21] = "generic-interests", n),
                    l = ((i = {})[13] = 22, i[2] = 6, i[7] = 30, i[9] = 32, i[10] = 3, i[11] = 20, i[3] = 25, i[4] = 24, i[8] = 31, i[12] = 2, i[27] = 11, i[32] = 60, i[34] = 58, i[33] = 61, i[35] = 94, i[36] = 69, i),
                    f = ((o = {})[0] = "unknown", o[1] = "location", o[2] = "about_me", o[3] = "relationship", o[4] = "sexuality", o[5] = "appearance", o[7] = "children", o[8] = "smoking", o[9] = "drinking", o[10] = "education", o[11] = "languages", o[12] = "work", o[13] = "height", o[18] = "work_job", o[19] = "work_company", o[20] = "work_income", o[21] = "interested_in", o[22] = "work_general", o[27] = "looking_for", o[28] = "verified_by_photo", o[32] = "zodiac", o[34] = "religion", o[33] = "pets", o[35] = "personality", o[36] = "education_level", o[10001] = "exp_facebook_institution", o[10002] = "exp_facebook_graduation_year", o[10003] = "exp_facebook_profession", o[10004] = "exp_facebook_company_name", o),
                    h = ((s = {})[27] = 899, s[28] = 31, s[11] = 150, s[13] = 490, s[4] = 143, s[3] = 142, s[7] = 139, s[9] = 140, s[8] = 144, s[34] = 914, s[33] = 1571, s[32] = 905, s[36] = 912, s[35] = 1579, s[0] = 1579, s);
                (a = {})[11] = 272, a[5] = 275, a[13] = 275, a[9] = 280, a[7] = 276, a[3] = 278, a[4] = 279, a[8] = 281, a[2] = 288
            },
            31087: function(e, t, r) {
                r.d(t, {
                    A: function() {
                        return V
                    }
                });
                r(26099), r(3362), r(50113), r(2008), r(23792), r(62953), r(62062), r(51629), r(23500), r(5506), r(60739), r(27208), r(38781), r(25276), r(2892), r(88431), r(74423), r(21699);
                var n, i = r(32308),
                    o = r(23735),
                    s = r(35837),
                    a = (r(99417), r(44757)),
                    c = r(23149),
                    u = r(57917),
                    d = r(73090),
                    l = r(37905),
                    f = r(18084),
                    h = r(33263),
                    g = r(15880),
                    p = r(41298),
                    _ = (r(79432), r(26910), r(69085), r(57456)),
                    v = r(89610),
                    y = r(62748),
                    m = r(92283),
                    A = r(15566),
                    b = {
                        Age: 210,
                        AllowChat: 660,
                        AllowCrush: 732,
                        Count: 310,
                        Email: 10,
                        Gender: 230,
                        IsFavourite: 610,
                        IsVerified: 290,
                        Name: 200,
                        ProfilePhoto: 340,
                        QuickChat: 1200,
                        ReceivedGifts: 750,
                        VerificationStatus: 291,
                        VerifiedInformation: 100,
                        VideoCount: 311
                    },
                    P = {
                        hasOverlay: !1,
                        isLoading: !0,
                        viewSize: {
                            width: 125,
                            height: 125
                        }
                    },
                    w = {
                        mergeUser: function(e, t) {
                            if (t instanceof A.KJW) {
                                var r = (0, _.A)(Object.keys(t.toJSON()), "projection", "user_id", "$gpb", "client_source", "access_level");
                                if (!r.length) return !1;
                                for (var n = e.getProjection() || [], i = t.getProjection([]).slice(), o = 0; o < r.length; o++) {
                                    var s = h.A.getPropertyKey(r[o]),
                                        a = "get" + s;
                                    (0, v.A)(e[a]) && (e["set" + s](t[a]()), i.push(b[s]))
                                }
                                var c = (0, y.A)(n, i.filter(Boolean));
                                return e.setProjection(c), !0
                            }
                            return !1
                        },
                        createCard: function(e, t) {
                            return new m.A(e, Object.assign({}, P, t))
                        },
                        createMedia: function(e, t) {
                            t = Object.assign({}, P, t);
                            var r = e.find((function(e) {
                                    return 2 === e.getAlbumType()
                                })),
                                n = r ? r.getPhotos([]) : [],
                                i = n.length,
                                o = n.map((function(e) {
                                    return new m.A(e, t)
                                })),
                                s = [];
                            return s.length || i ? {
                                otherCards: s,
                                photoOfMeCards: o,
                                photosOfMeCount: i
                            } : null
                        }
                    },
                    I = w,
                    C = r(54864),
                    k = r(77361),
                    U = r(8054),
                    F = f.A.getLogger("ProfilesModel"),
                    T = "CRUSH_TOOLTIP_VIEW_FLAG",
                    S = u.A.extend({
                        name: "Profiles",
                        getRequestMessageType: 403,
                        getResponseMessageType: [404],
                        setRequestMessageType: 405,
                        setResponseMessageType: (0, o.jU)(404, 1),
                        preventMultiple: !0,
                        commitCache: !1,
                        get: function(e) {
                            var t = E(e);
                            return t ? t instanceof A.u1Q ? this.fetch_.apply(this, j(t)).then(q) : this.get_.apply(this, j(t)).then(this.compareCachedUserFields_.bind(this, t)).then(q) : Promise.reject(new Error("Invalid arguments provided when try to get user."))
                        },
                        fetch: function(e) {
                            var t = E(e);
                            return t ? this.fetch_.apply(this, j(t)).then(q) : Promise.reject(new Error("Invalid arguments provided when try to fetch user."))
                        },
                        getMatchingPendingRequest: function(e, t) {
                            var r = t.getUserFieldFilter().getProjection(),
                                n = this.getCacheKey_(e, t),
                                i = (this.pendingRequests_[n] || []).find((function(e) {
                                    var t, n = e.projection;
                                    return t = n, r.every((function(e) {
                                        return t.includes(e)
                                    }))
                                }));
                            return null == i ? void 0 : i.request
                        },
                        addPendingRequest: function(e, t, r) {
                            var n = this.getCacheKey_(e, t);
                            this.pendingRequests_[n] || (this.pendingRequests_[n] = []);
                            var i = t.getUserFieldFilter().getProjection();
                            this.pendingRequests_[n].push({
                                projection: i,
                                request: r
                            })
                        },
                        removePendingRequest: function(e, t, r) {
                            var n = this.getCacheKey_(e, t);
                            this.pendingRequests_[n] && (this.pendingRequests_[n] = this.pendingRequests_[n].filter((function(e) {
                                return e.request !== r
                            })))
                        },
                        compareCachedUserFields_: function(e, t) {
                            var r = t[0];
                            if (!t.fromCache) return t;
                            if (r instanceof A.KJW) {
                                var n = e.getUserFieldFilter().getProjection(),
                                    i = r.getProjection(),
                                    o = (0, a.A)(n, i);
                                if (o.length > 0) return e.getUserFieldFilter().setProjection(o), this.fetch_.apply(this, j(e))
                            }
                            return t
                        },
                        set: function(e, t, r) {
                            var n = this;
                            if (!(e instanceof A.KJW && t && 0 !== t.length)) return Promise.reject(new Error("Wrong params passed to User.set"));
                            var i = d.A.getUserId();
                            e.setUserId(i);
                            var o = C.h.getOwnProfileFilter(t);
                            i || 1 !== t.length || 231 !== t[0] || o.setProjection(t);
                            var s = (new A.KkJ).setProjection(t),
                                a = (new A.S80).setUser(e).setSaveFieldFilter(s).setReturnFieldFilter(o);
                            r && a.setContext(r);
                            var c = this.getCacheKeyForUser_(i),
                                l = this.getUserFromCache_(c),
                                f = !1;
                            return l || (l = e, f = !0), S._super.set.call(this, a).then((function(e) {
                                var t = e[0],
                                    r = e[1];
                                return r ? Promise.reject(r) : (n.trigger(u.A.EVENTS.INVALIDATED, {
                                    keys: [i]
                                }), g.A.track(l, t, f), n.updateCache(i, t))
                            }))
                        },
                        shouldCache_: function(e, t) {
                            return t instanceof A.hcA && (191 !== t.getClientSource() && this.useCache_)
                        },
                        getCacheKey_: function(e, t) {
                            return this.getCacheKeyForUser_(t.getUserId(), t.getToken())
                        },
                        getCacheKeyForUser_: function(e, t) {
                            return this.getRequestMessageType + ":" + e + (t ? ":" + t : "")
                        },
                        invalidate: function(e, t, r) {
                            var n = null;
                            e && (n = this.getCacheKeyForUser_(e)), S._super.invalidate.call(this, n, t, r)
                        },
                        onCacheInvalidated_: function(e) {
                            this.trigger(u.A.EVENTS.INVALIDATED, {
                                all: e.all,
                                keys: e.keys && Array.isArray(e.keys) ? e.keys.map(R) : []
                            })
                        },
                        updateCache: function(e, t, r) {
                            var n = this.getCacheKeyForUser_(e),
                                i = this.getUserFromCache_(n);
                            if (i) return t instanceof A.KJW ? i = t : (0, c.A)(t) ? Object.entries(t).forEach((function(e) {
                                var t = e[0],
                                    r = e[1];
                                x(i, t, r)
                            })) : x(i, t, r), this.cacheResponse_(n, this.getCacheTime_(), [i]), i
                        },
                        cacheResponse_: function(e, t, r) {
                            var n = r[0],
                                i = this.getUserFromCache_(e);
                            if (i && (I.mergeUser(i, n), r[0] = i), n.getUserId() === d.A.getUserId()) {
                                var o = (0, s.A)(d.A.getUser(), A.KJW);
                                I.mergeUser(o, n), d.A.updateUser(o.toJSON())
                            }
                            return S._super.cacheResponse_.apply(this, arguments)
                        },
                        getUserFromCache_: function(e) {
                            var t = this.cache_.get(e);
                            return t && Array.isArray(t) && (t = t[0]), t ? (0, s.A)(t) : null
                        },
                        informVote: function(e, t) {
                            var r = e.getPersonId(),
                                n = e.getVote();
                            if (r) {
                                if (!((0, i.Rg)(n) && t instanceof A.R_p)) return this.invalidate(r), void this.log.warn("Failed to update cache with vote data, invalidating profile instead");
                                var o = {
                                    myVote: n,
                                    isMatch: 3 === t.getVoteResponseType()
                                };
                                t.hasCanChat() && (o.allowChat = t.getCanChat()), this.updateCache(r, o)
                            } else this.log.warn("Failed to update cache with vote data, no id provided")
                        },
                        markGiftAsUnboxed: function(e) {
                            var t = d.A.getUserId(),
                                r = this.getCacheKeyForUser_(t),
                                n = this.getUserFromCache_(r);
                            if (n) {
                                var i = n.getReceivedGifts();
                                if (i) {
                                    var s = i.getGifts([]),
                                        a = s.find((function(t) {
                                            return t.getPurchaseId() === e
                                        }));
                                    a && (a.setIsBoxed(!1), i.setGifts(s), this.updateCache(t, {
                                        receivedGifts: i
                                    }))
                                }
                            }
                            var c = (new A.coP).setAction(2).setGiftPurchaseId([e]);
                            new o.Ay(445, c).request()
                        },
                        deleteGifts: function(e) {
                            var t = d.A.getUserId(),
                                r = this.getCacheKeyForUser_(t),
                                n = e.map((function(e) {
                                    return e.toString()
                                })),
                                i = this.getUserFromCache_(r);
                            if (i) {
                                var s = i.getReceivedGifts();
                                if (s) {
                                    var a = s.getGifts([]).filter((function(e) {
                                        return -1 === n.indexOf(e.getPurchaseId())
                                    }));
                                    s.setGifts(a), this.updateCache(t, {
                                        receivedGifts: s
                                    })
                                }
                            }
                            var c = (new A.coP).setAction(1).setGiftPurchaseId(n);
                            return new Promise((function(e, t) {
                                new o.Ay(445, c).on(387, (function(r, n) {
                                    r ? t(r) : e(n)
                                })).request()
                            }))
                        },
                        canShowCrushTooltip: function() {
                            return !this.cache_.get(T)
                        },
                        markCrushTooltipAsViewed: function() {
                            this.canShowCrushTooltip() && this.cache_.put(T, 1, {
                                ttl: 864e5
                            })
                        },
                        getVersion_: function() {
                            return 3
                        },
                        sendVisiting: function(e) {
                            if (!(0, c.A)(e) || !e.fromCache) return;
                            if (!d.A.isLoggedIn()) return;
                            if (!e.id) return void F.warn("No id provided");
                            var t = (new A.gkr).setPersonId(e.id);
                            (0, i.Rg)(e.source) && t.setVisitingSource(e.source);
                            (0, i.Rg)(e.folder) && t.setSourceFolder(e.folder);
                            "string" == typeof e.section && t.setSectionId(e.section);
                            "boolean" == typeof e.fromCache && t.setPrefetched(e.fromCache);
                            new o.Ay(150, t).request()
                        }
                    }, "UserModel");

                function j(e, t) {
                    var r, n;
                    return e instanceof A.u1Q ? (r = 484, n = 485) : (r = 403, n = 404), [r, n, e, t]
                }

                function R(e) {
                    var t = e.split(":");
                    return 2 === t.length ? t[1] : 3 === t.length ? t[2] : e
                }

                function E(e) {
                    if (!(0, c.A)(e) || !e.id && !e.token) return F.error("requesting profile with no id or token", e), !1;
                    var t;
                    if (!(0, i.Rg)(e.clientSource)) {
                        var r = l.A.controller;
                        e.clientSource = (null == r ? void 0 : r.clientSource) || 0
                    }
                    if (e.id && Array.isArray(e.id)) {
                        if (t = (new A.u1Q).setUsersIds(e.id), !e.requestedFields) return F.error("Requesting multiple users without profile fields"), !1
                    } else {
                        t = new A.hcA;
                        var n = e.defaultPhotoId;
                        if (n && t.setDefaultPhotoId(n), e.id) {
                            t.setUserId(e.id);
                            var o = function(e) {
                                if (e.id === d.A.getUserId()) return;
                                var t = (new A.gkr).setPersonId(e.id),
                                    r = e.inAppData || e;
                                (0, i.Rg)(r.folderType) && t.setSourceFolder(r.folderType);
                                "string" == typeof r.sectionId && t.setSectionId(r.sectionId);
                                (0, i.Rg)(r.clientSource) && t.setVisitingSource(r.clientSource);
                                r.isPrefetch && t.setPrefetched(!0);
                                "string" == typeof r.notificationType && t.setNotificationType(r.notificationType);
                                return t
                            }(e);
                            o && t.setVisitingSource(o)
                        } else e.token && t.setToken(e.token)
                    }
                    return e.isPrefetch && t.setIsPrefetch(!0), t.setClientSource(e.clientSource), t.setUserFieldFilter(function(e) {
                        var t;
                        e.requestedFields && Array.isArray(e.requestedFields) ? (t = C.h.getProfileFilter(null, e.clientSource)).setProjection(e.requestedFields) : t = e.userFieldFilter instanceof A.KkJ ? e.userFieldFilter : e.id === d.A.getUserId() ? C.h.getOwnProfileFilter() : C.h.getProfileFilter(e.id || e.token, e.clientSource);
                        if (e.clientSource && 3 === e.clientSource) {
                            var r = t.getProjection([]);
                            t.setProjection(r.filter((function(e) {
                                return 220 !== e
                            })))
                        }
                        return t
                    }(e)), t
                }

                function q(e) {
                    var t = e[0];
                    return t instanceof A.KJW && t.hasAlbums() && k.A.getInstance().inform(t.getAlbums()), t
                }

                function x(e, t, r) {
                    void 0 === r ? e[h.A.getPropertyKey(t, "del")]() : e[h.A.getPropertyKey(t, "set")](r)
                }
                S.prototype.getRequestBody = E, S.getInstance = function() {
                    return n || (n = new S)
                }, S.canBeShared = function(e) {
                    var t, r = e.social_networks;
                    return r && r.length > 0 && (t = r[0]), !!t
                }, S.getUserById = function(e) {
                    var t = e.id,
                        r = e.forced,
                        n = e.clientSource,
                        i = e.folderType,
                        o = S.getInstance().trackNext(),
                        s = r ? "fetch" : "get";
                    return r && S.getInstance().invalidate(t, !1, !0), (0, p.A)(o[s]({
                        id: t,
                        clientSource: n,
                        folderType: i
                    }))
                };
                var V = S;
                (0, U.A)({
                    clearUserCache: function() {
                        S.getInstance().invalidateAll()
                    }
                })
            },
            33263: function(e, t, r) {
                r(26099), r(38781), r(51629), r(23500), r(79432), r(27495), r(48598), r(62062);
                var n = {
                    createProtoInstance: function(e, t) {
                        var r = new e;
                        return "[object Object]" === Object.prototype.toString.call(t) && Object.keys(t).forEach((function(e) {
                            var n = t[e];
                            if (void 0 !== n) {
                                var o = "set" + e.split("_").map(i).join("");
                                "function" == typeof r[o] && r[o](n)
                            }
                        })), r
                    },
                    getPropertyKey: function(e, t) {
                        var r = t || "";
                        return e.split(/_/g).forEach((function(e) {
                            return r += i(e)
                        })), r
                    }
                };

                function i(e) {
                    return e.charAt(0).toUpperCase() + e.substr(1)
                }
                t.A = n
            },
            77361: function(e, t, r) {
                r(26099), r(3362), r(62062), r(2008), r(27495), r(23792), r(62953);
                var n, i = r(57917),
                    o = r(23735),
                    s = r(33263),
                    a = r(15566),
                    c = r(32308),
                    u = r(72537),
                    d = 0,
                    l = i.A.extend({
                        name: "Albums",
                        getRequestMessageType: 86,
                        getResponseMessageType: 87,
                        preventMultiple: !0,
                        allowAddVideo: function() {
                            var e = u.A.getSync(106);
                            return e.enabled || 2 === e.required_action
                        },
                        update: function() {},
                        createNewAlbum: function(e) {
                            return (new a.YZ5).setAlbumType(e.type).setOwnerId(e.ownerId).setUid(e.uid || "default").setName(e.name || "default").setAdult(e.isAdult || !1).setAccessable(e.isAccessible || !0)
                        },
                        reorderPhotos: function(e, t) {
                            if (!t || !e) return Promise.reject(new Error("[AlbumsModel::reorderPhotos]: You have to provide proper method arguments"));
                            var r = e.map((function(e, t) {
                                return void 0 === e.id && "" === e.id ? Promise.reject(new Error("[AlbumsModel::reorderPhotos]: You have to provide a correct data, photo id by index " + t + " is undefined or empty")) : e
                            }));
                            if (r.length < 1) return Promise.reject(new Error("[AlbumsModel::reorderPhotos]: You have to provide more that 1 photo id to perform a reorder"));
                            var n = r.map((function(e) {
                                    return (new a.$_D).setId(e.id)
                                })),
                                i = this.createNewAlbum({
                                    uid: t.uid,
                                    name: t.name,
                                    type: t.album_type,
                                    ownerId: t.owner_id,
                                    isAdult: t.adult,
                                    isAccessible: t.accessable
                                }).setPhotos(n);
                            return this.fetch_(392, (0, o.jU)(87, 1), i)
                        },
                        get: function(e, t) {
                            if ("string" != typeof e || !e.length) return Promise.reject(new Error("Invalid 'User Id' provided: " + e));
                            if (!(0, c.Rg)(t)) return Promise.reject(new Error("Invalid 'Album Type' provided: " + t));
                            var r = (new a.Nij).setAlbumType(t).setPersonId(e);
                            return l._super.get.call(this, r)
                        },
                        getExternalPhotoBlockers: function(e) {
                            return e.filter((function(e) {
                                return 10 === e.getAlbumType()
                            })).filter((function(e) {
                                return 6 === e.getAccessLevel()
                            })).map((function(e) {
                                return e.getAlbumBlocker()
                            }))
                        },
                        setAsDefault: function(e) {
                            e = e.replace(/^.*id=(\d+)/, (function(e, t) {
                                return t
                            }));
                            var t = (new a.Z_u).setAction(d).setImageId(e);
                            return this.fetch_(329, 330, t)
                        },
                        deletePhoto: function(e) {
                            var t = (new a.JTz).setPhotoId(e);
                            return this.fetch_(117, 87, t)
                        },
                        deletePhotosList: function(e) {
                            var t = (new a.JTz).setPhotoIdList(e);
                            return this.fetch_(117, 87, t)
                        },
                        makePublic: function(e) {
                            var t = (new a.rhH).setSourcePhotoId(e).setDestinationAlbumType(2);
                            return this.fetch_(426, 87, t)
                        },
                        makePhotosListPublic: function(e) {
                            var t = (new a.rhH).setSourcePhotoIdList(e).setDestinationAlbumType(2);
                            return this.fetch_(426, 87, t)
                        },
                        getCacheKey_: function(e, t) {
                            return t.getPersonId().replace("-", "") + "-" + t.getAlbumType("")
                        },
                        shouldCache_: function(e, t) {
                            return this.useCache_ && t instanceof a.Nij && 4 !== t.getAlbumType()
                        },
                        getRequestTypeByObject_: function() {
                            return this.getRequestMessageType
                        },
                        getRequestByObject_: function(e) {
                            return e = Array.isArray(e) ? e[0] : e, (new a.Nij).setAlbumType(2).setPersonId(e.getOwnerId())
                        },
                        getCacheByObject_: function(e) {
                            return e
                        },
                        getVersion_: function() {
                            return 2
                        },
                        onCacheInvalidated_: function(e) {
                            var t, r, n = {
                                all: e.all,
                                keys: []
                            };
                            if (Array.isArray(e.keys))
                                for (r = e.keys.length, t = 0; t < r; t += 1) n.keys.push(e.keys[t].split("-")[0]);
                            l._super.onCacheInvalidated_.call(this, n)
                        },
                        sendPhotoUploadConfirm: function(e) {
                            this.invalidate();
                            var t = s.A.createProtoInstance(a.pM1, e);
                            return new Promise((function(e, r) {
                                new o.Ay(93, t).on(143, e).on(144, r).request()
                            }))
                        }
                    }, "Albums");
                l.EVENTS = i.A.EVENTS, l.getInstance = function() {
                    return n || (n = new l)
                }, t.A = l
            },
            92283: function(e, t, r) {
                r(25276), r(27495);
                var n = r(99417),
                    i = r(79880),
                    o = i.A.DENSITY,
                    s = function(e, t, r) {
                        var n = 100 * (e + t) / 2 / r;
                        return n > 100 && (n = 100), n
                    };

                function a(e, t, r, n) {
                    return e <= t ? r : e > n - t ? n : e
                }
                var c = function(e, t) {
                    var r = e.getLargeUrl(),
                        n = e.getLargePhotoSize();
                    if (t) {
                        var s = t.width,
                            a = t.height;
                        if (n) {
                            var c = n.getWidth() * o,
                                d = n.getHeight() * o,
                                l = c > d,
                                f = c / s,
                                h = d / a,
                                g = Math.round(1e3 * Math.min(f, h)) / 1e3,
                                p = u.computeFaceCenterPosition(e),
                                _ = p.x / 100,
                                v = p.y / 100,
                                y = 0,
                                m = 0;
                            if (l) {
                                var A = s;
                                s = a, a = A
                            }
                            f > h ? y = Math.round((c / h - s) * (1 - _) * h) : m = Math.round((d / f - a) * v * f), r = -1 !== r.indexOf("vp_x1=__vp_x1__") ? r.replace("__vp_x1__", c - Math.round(s * g) - y).replace("__vp_x2__", c - y).replace("__vp_y1__", m).replace("__vp_y2__", m + Math.round(a * g)).replace("__vp_scale__", g) : r.replace("__offset__", 10 + y + "y" + (10 + m)).replace("__scale__", g)
                        }
                        r = (0, i.A)(r, s, a, "y")
                    }
                    return r
                };

                function u(e, t) {
                    var r = e.getPhotoCoaching(),
                        n = e.getVideo();
                    t = t || {}, this.centerPercentages = u.computeFaceCenterPosition(e), this.hasOverlay = t.hasOverlay, this.id = e.getId(), this.isLoading = t.isLoading, this.isPrivate = t.isPrivate, this.isProcessing = null, this.isProfileImage = e.getIsProfilePhoto(!1), this.isVideo = !!n, this.photoCoachingData = null, this.src = c(e, t.viewSize), this.videoUrl = null, this.isVideo && (this.isProcessing = n.getIsProcessing(), this.videoUrl = n.getUrl()), r && (this.photoCoachingData = {
                        status: r.getStatus()
                    })
                }
                u.addWatermarksToAlbum = function(e) {
                    return e ? (u.addWatermarksToPhotos(e.getPhotos()), e) : e
                }, u.addWatermarksToPhotos = function(e) {
                    if (!e) return e;
                    var t = {
                        width: n.A.innerWidth,
                        height: n.A.innerHeight
                    };
                    if (e)
                        for (var r = 0, i = e.length; r < i; r++) {
                            var o = e[r],
                                s = c(o, t);
                            o.setLargeUrl(s)
                        }
                    return e
                }, u.computeFaceCenterPosition = function(e) {
                    var t = e.getFaceTopLeft(),
                        r = e.getFaceBottomRight(),
                        n = e.getLargePhotoSize(),
                        i = {
                            x: 50,
                            y: 50
                        };
                    return t && r && n && (i.x = a(s(t.getX(), r.getX(), n.getWidth()), 25, 0, 100), i.y = a(s(t.getY(), r.getY(), n.getHeight()), 25, 0, 100)), i
                }, t.A = u
            }
        }
    ]);
//# sourceMappingURL=1087.9950bc9cd4d3bdac59ea.js.map
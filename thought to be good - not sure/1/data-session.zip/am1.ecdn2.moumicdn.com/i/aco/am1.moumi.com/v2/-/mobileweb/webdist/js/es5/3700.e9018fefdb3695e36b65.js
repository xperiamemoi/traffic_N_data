var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "24d55b06-4da4-47a4-8349-bac3b196e443", e._sentryDebugIdIdentifier = "sentry-dbid-24d55b06-4da4-47a4-8349-bac3b196e443")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "24d55b06-4da4-47a4-8349-bac3b196e443", e._sentryDebugIdIdentifier = "sentry-dbid-24d55b06-4da4-47a4-8349-bac3b196e443")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [3700], {
            1765: function(e, t, n) {
                n(45700), n(89572), n(52675), n(89463), n(2892), n(84185), n(2008), n(83851), n(81278), n(67945), n(79432), n(60739), n(27208), n(26099), n(3362), n(50113), n(51629), n(23500), n(25276), n(15086);
                var r, i, o = n(85208),
                    a = n(97286),
                    s = n(1978),
                    c = n(3508),
                    d = n(58544),
                    f = n(58385),
                    u = n(5586),
                    l = n(73090),
                    p = n(58336),
                    g = n(19232),
                    v = n(37905),
                    y = n(79860),
                    h = n(18084),
                    b = n(41025),
                    m = n(47294),
                    A = n(31087),
                    T = n(32308),
                    P = n(74389),
                    I = n(63620);

                function O(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function w(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? O(Object(n), !0).forEach((function(t) {
                            E(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : O(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function E(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var _ = n(13242).A.hasRecentlyPassedVerification,
                    R = ((r = {})[1] = {
                        id: "facebook",
                        hotpanel: 6,
                        element: 120
                    }, r[2] = {
                        id: "vk",
                        hotpanel: 9,
                        element: 178
                    }, r[3] = {
                        id: "ok",
                        hotpanel: 10,
                        element: 179
                    }, r[4] = {
                        id: "google",
                        hotpanel: 11,
                        element: 301
                    }, r[12] = {
                        id: "instagram",
                        hotpanel: 13,
                        element: 44
                    }, r[14] = {
                        id: "linkedin",
                        hotpanel: 8,
                        element: 302
                    }, r[15] = {
                        id: "twitter",
                        hotpanel: 7,
                        element: 201
                    }, r),
                    S = "phone",
                    V = "spp",
                    D = ((i = {})[1] = "facebook", i[2] = "vkontakte", i[3] = "odnoklassniki", i[4] = "google", i[15] = "twitter", i[12] = "instagram", i[14] = "linkedin", i),
                    x = h.A.getLogger("VerificationUtil"),
                    F = (0, p.A)("FAIL", "SUCCESS"),
                    N = (0, o.A)({
                        verify: function(e) {
                            var t, n = v.A.controller,
                                r = {
                                    context: n.activationPlace,
                                    destination: e.destination || f.A.getUrl(),
                                    isForced: !1,
                                    isNotification: !1,
                                    requireVerification: e.isForced || !1,
                                    verifyForUser: e.verifyForUser
                                };
                            switch (e.activationPlace && (r.activationPlace = e.activationPlace), (0, o.A)(r, (0, a.A)(e, Object.keys(r))), e.methodType) {
                                case 5:
                                    var i;
                                    t = 5;
                                    var s = r.isForced ? P.x.FORCED_PHOTO_VERIFICATION : P.x.PHOTO_VERIFICATION;
                                    f.A.navigate(s, {
                                        callback: r.callback,
                                        clientSource: r.clientSource,
                                        destination: r.destination,
                                        isNotification: r.isNotification,
                                        promo: null == (i = r.promo) ? void 0 : i.toJSON()
                                    });
                                    break;
                                case 1:
                                    t = 2, f.A.navigate(P.x.PHONE_VERIFICATION, w(w({}, r), {}, {
                                        verificationMethod: e.verificationMethod
                                    }));
                                    break;
                                case 2:
                                    t = 12;
                                    var c = {
                                        back: r.destination,
                                        hotPanelData: {
                                            activationPlace: r.activationPlace
                                        },
                                        productType: 1
                                    };
                                    return Promise.resolve(b.A.navigateToPayment(c));
                                case 3:
                                    if (!e.providerType) return x.error("no provider type", e), Promise.reject(new Error("No provider type given for VERIFY_SOURCE_EXTERNAL_PROVIDER"));
                                    R[e.providerType] && (t = R[e.providerType].hotpanel), this.login_(e)
                            }
                            return (0, T.Rg)(n.getScreenName()) && t && (0, y.sx)(164, {
                                verification_method: t,
                                activation_place: r.activationPlace || n.activationPlace
                            }), Promise.resolve()
                        },
                        verifyByPhoto: function(e) {
                            var t = this;
                            return e = e || {}, A.A.getInstance().get({
                                id: l.A.getUserId(),
                                requestedFields: [100]
                            }).then((function(n) {
                                var r = n.getVerifiedInformation().getMethods([]),
                                    i = r.find((function(e) {
                                        return 5 === e.getType()
                                    })),
                                    a = i.getIsConfirmed(!1),
                                    s = i.getIsConnected(!1),
                                    c = !a && !!i.getSecondsToWait(),
                                    d = s && c;
                                return s && a || d ? !!d && f.A.navigate(P.x.OWN_PROFILE_EDIT, {
                                    anchor: I.l.VERIFICATION
                                }) : t.verify((0, o.A)(e, {
                                    methodType: 5
                                }))
                            }), x.error)
                        },
                        login_: function(e) {
                            g.A.off(g.A.EVENTS.AUTH_ERROR, this.onFail_), g.A.on(g.A.EVENTS.AUTH_ERROR, this.onFail_.bind(this));
                            var t = e.destination || u.A.encodeRoute(P.x.VERIFY, {
                                    returnRoute: f.A.getUrl(),
                                    methodType: e.methodType,
                                    providerType: e.providerType
                                }),
                                n = {
                                    callback: this.setVerified.bind(this, e),
                                    methodType: e.methodType,
                                    providerContext: e.providerContext || 3,
                                    context: e.context || null,
                                    providerType: e.providerType,
                                    returnRoute: t,
                                    startVerification: !0
                                };
                            g.A.login(n)
                        },
                        setVerified: function(e, t) {
                            var n = this,
                                r = t.providerId,
                                i = t.providerType,
                                o = g.A.getStoredAuthData();
                            t.provider && (r = t.provider.id, i = t.provider.type), o && (r = o.providerId, g.A.removeStoredAuthData());
                            var a = {
                                methodType: t.methodType,
                                providerId: r,
                                providerType: i,
                                verifyForUser: e.verifyForUser,
                                context: t.context
                            };
                            return m.A.getInstance().setVerified(a).then((function(t) {
                                k(e.destination), t && t.getSuccess() ? n.trigger(F.SUCCESS, t) : n.onFail_(t)
                            })).catch((function(t) {
                                k(e.destination), n.onFail_(t)
                            }))
                        },
                        registerProviders: function(e, t) {
                            var n = [];
                            e.forEach((function(e) {
                                var t = e.getExternalProviderData();
                                t && n.push(t.toJSON())
                            })), g.A.setProviderData(t || 3, n)
                        },
                        disconnect: function(e) {
                            m.A.getInstance().remove({
                                methodType: e.methodType,
                                providerType: e.providerType
                            }).then(e.callback)
                        },
                        onFail_: function(e) {
                            x.error("Verification Failed", e), this.trigger(F.FAIL, e)
                        },
                        createContextForMethod: function(e, t, n) {
                            var r, i = e.getType(),
                                o = c.A.get("verification.providers"),
                                a = null,
                                s = e.getVerificationData() || e.getDisplayMessage();
                            l.A.isLoggedIn() || (s = e.getDisplayMessage() || e.getVerificationData());
                            var d = {
                                hideMessage: n,
                                isConfigurable: t && e.getIsConfirmed() && e.hasAccessRestrictions(),
                                isInactive: !e.getIsConfirmed() || e.hasAccessRequestPromo(),
                                message: s,
                                methodType: e.getType(),
                                name: e.getName(),
                                verified: e.getIsConfirmed(!1)
                            };
                            switch (i) {
                                case 1:
                                    a = S;
                                    break;
                                case 2:
                                    a = V;
                                    break;
                                case 5:
                                    var f = e.getPhotoVerification(),
                                        u = e.getIsConfirmed(),
                                        p = e.getIsConnected(),
                                        g = f && f.hasError();
                                    d.isProcessing = !1, u || (!f || p && !g) && (d.isProcessing = !0), d.verificationError = g, d.secondsToWait = e.getSecondsToWait(0);
                                    break;
                                case 3:
                                    if (!(r = e.getExternalProviderData())) return void this.log.error("broken provider", e);
                                    var v = d.providerType = r.getType();
                                    if (-1 === o.indexOf(v)) return null;
                                    a = D[v]
                            }
                            return d.className = a, d[a] = {
                                verified: e.getIsConfirmed()
                            }, d
                        },
                        createKeyForMethod: function(e) {
                            var t = e.getType();
                            return 1 === t ? "phone" : 2 === t ? "spp" : 3 === t ? R[e.getExternalProviderData().getType()].id : void 0
                        },
                        createHotPanelVerificationMethod: function(e) {
                            var t = e.getType();
                            if (1 === t) {
                                var n = e.getPhoneNumberVerificationType();
                                if (2 === n) return 2;
                                if (3 === n) return 1
                            } else {
                                if (5 === t) return 5;
                                if (3 === t) return R[e.getExternalProviderData().getType()].hotpanel
                            }
                        },
                        getVerificationHotPanelElement: function(e) {
                            var t = e.getType();
                            return 1 === t ? 300 : 2 === t ? 130 : 3 === t ? R[e.getExternalProviderData().getType()].element : void 0
                        },
                        handleNotification: function(e) {
                            var t = e.getVerifiedInformation().getMethods(),
                                n = t.find((function(e) {
                                    return 1 === e.getType()
                                }));
                            if (n) f.A.navigate(P.x.PHONE_VERIFICATION, {
                                requireVerification: e.getBlocking() ? "true" : "false",
                                isNotification: "true",
                                verificationMethod: n
                            });
                            else if (t.some((function(e) {
                                    return 5 === e.getType()
                                }))) {
                                var r;
                                if (_()) return;
                                var i = e.getBlocking() ? P.x.FORCED_PHOTO_VERIFICATION : P.x.PHOTO_VERIFICATION;
                                f.A.navigate(i, {
                                    promo: null == (r = e.getPromoBlock()) ? void 0 : r.toJSON(),
                                    isNotification: !0
                                })
                            } else;
                        }
                    }, d.zb);

                function k(e) {
                    e && (0, s.A)((function() {
                        f.A.navigate(e, !0, {
                            date: +new Date
                        })
                    }))
                }
                N.ACTIONS = F, t.A = N
            },
            13242: function(e, t) {
                var n;
                t.A = {
                    notifyVerificationPassed: function() {
                        n = Date.now()
                    },
                    hasRecentlyPassedVerification: function() {
                        return n && Date.now() < n + 3e4
                    }
                }
            },
            31247: function(e, t, n) {
                n.d(t, {
                    b: function() {
                        return r
                    }
                });
                n(48598), n(2008), n(26099);

                function r(e, t) {
                    return e.filter((function(e) {
                        return void 0 !== e && "" !== e
                    })).join(t || ", ")
                }
            },
            37445: function(e, t, n) {
                var r = n(32675),
                    i = n(74848);
                t.A = function(e) {
                    var t = e.text,
                        n = e.size,
                        o = e.onClick,
                        a = e.icon;
                    return (0, i.jsx)(r.A, {
                        onClick: o,
                        text: t,
                        size: n,
                        icon: a
                    })
                }
            },
            42616: function(e, t, n) {
                n.d(t, {
                    h: function() {
                        return o
                    }
                });
                var r = n(40075),
                    i = n(31247);

                function o(e) {
                    var t, n = e.userName,
                        o = e.isProfilePhoto,
                        a = e.type,
                        s = void 0 === a ? "photo" : a,
                        c = e.provider,
                        d = e.position,
                        f = e.total,
                        u = e.extraAction,
                        l = e.hasOpenFullScreenAction ? r.Ay.get(548) : void 0,
                        p = d && f ? r.Ay.get(547, {
                            position: d,
                            total: f
                        }) : void 0;
                    return n ? (t = r.Ay.get(692, {
                        name: n
                    }), o && (t = r.Ay.get(686, {
                        name: n
                    })), "video" === s && (t = r.Ay.get(693, {
                        name: n
                    })), 12 === c && (t = r.Ay.get(690, {
                        name: n
                    }), "video" === s && (t = r.Ay.get(691, {
                        name: n
                    }))), d && f && (t = r.Ay.get(687, {
                        name: n,
                        num: d,
                        total: f
                    }), "video" === s && (t = r.Ay.get(688, {
                        name: n,
                        num: d,
                        total: f
                    })), 12 === c && (t = r.Ay.get(689, {
                        name: n,
                        n: d,
                        total: f
                    }), "video" === s && (t = r.Ay.get(691, {
                        name: n
                    }), t = (0, i.b)([t, p])))), (0, i.b)([t, u || l])) : (t = "video" === s ? r.Ay.get(564) : r.Ay.get(549), (0, i.b)([t, p, u || l]))
                }
            },
            44523: function(e, t, n) {
                n(52675), n(89463), n(45700), n(89572), n(26099), n(2892), n(84185), n(79432), n(2008), n(83851), n(51629), n(23500), n(81278), n(67945);
                var r = n(96540),
                    i = n(93827),
                    o = n(47667),
                    a = n(17380),
                    s = n(36693),
                    c = n(8483),
                    d = n(74848);

                function f(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function u(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? f(Object(n), !0).forEach((function(t) {
                            l(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : f(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function l(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                t.A = function(e) {
                    var t = e.header,
                        n = e.description,
                        f = e.icon,
                        l = e.type,
                        p = e.isStandalone,
                        g = e.isSelected,
                        v = e.onOptionClick,
                        y = {
                            align: "left",
                            color: "black",
                            dataQA: {
                                "data-qa-tiw-option-header": l || ""
                            }
                        },
                        h = p ? (0, d.jsx)(i.Zb, u(u({}, y), {}, {
                            children: t
                        })) : (0, d.jsxs)(r.Fragment, {
                            children: [(0, d.jsx)(i.ZS, u(u({}, y), {}, {
                                children: t
                            })), n ? (0, d.jsx)(s.A, {
                                top: "xsm",
                                children: (0, d.jsx)(i.P2, {
                                    align: "left",
                                    color: "gray-80",
                                    children: n
                                })
                            }) : null]
                        });
                    return (0, d.jsx)(o.A, {
                        media: null != f && f.name ? (0, d.jsx)(c.A, {
                            name: f.name,
                            size: "xlg",
                            color: f.color
                        }) : null,
                        mediaAlign: "center",
                        content: h,
                        extra: p ? null : (0, d.jsx)(a.A, {
                            isChecked: g,
                            type: "radio"
                        }),
                        color: g ? "selected" : "gray-10",
                        onClick: v,
                        dataQA: l ? {
                            "data-qa-tiw-option-type": l
                        } : void 0
                    })
                }
            },
            47294: function(e, t, n) {
                n(26099), n(3362), n(50113);
                var r, i = n(32308),
                    o = n(23735),
                    a = n(57917),
                    s = n(73090),
                    c = n(88651),
                    d = n(31087),
                    f = n(64266),
                    u = n(15566),
                    l = a.A.extend({
                        name: "Verification",
                        commitCache: !1,
                        getRequestMessageType: 260,
                        getResponseMessageType: 261,
                        setRequestMessageType: 262,
                        setResponseMessageType: [263, 261],
                        removeRequestMessageType: 264,
                        removeResponseMessageType: 265,
                        waitingApproval_: !1,
                        photoVerificationUploadedData_: null,
                        get: function(e) {
                            var t = this;
                            return s.A.isLoggedIn() ? this.waitingApproval_ ? this.fetch(e) : d.A.getInstance().get(this.getRequest_(e)).then((function(e) {
                                return t.onResult_(e)
                            })).catch((function(e) {
                                return t.onError_(e)
                            })) : Promise.reject(new Error("Cannot verify without being logged in"))
                        },
                        fetch: function(e) {
                            var t = this;
                            return d.A.getInstance().fetch(this.getRequest_(e)).then((function(e) {
                                return t.onResult_(e)
                            })).catch((function(e) {
                                return t.onError_(e)
                            }))
                        },
                        getRequest_: function(e) {
                            return {
                                context: e.context,
                                id: s.A.getUserId(),
                                requestedFields: [100]
                            }
                        },
                        onResult_: function(e) {
                            var t = e.getVerifiedInformation();
                            return this.waitingApproval_ = 0 !== function(e) {
                                var t = e.getMethods([]),
                                    n = t.find((function(e) {
                                        return 5 === e.getType()
                                    }));
                                return n && n.getSecondsToWait(0)
                            }(t), [t, this.uploadedPhotoVerificationData]
                        },
                        onError_: function(e) {
                            if (e instanceof u.beZ && 51 === e.getType()) throw e;
                            if (!(0, f.A)(e)) throw new Error("Error while fetching USER_FIELD_VERIFIED_INFORMATION.")
                        },
                        setRestriction: function(e, t) {
                            var n = (new u.ve9).setType(e.getType());
                            e.hasExternalProviderData() && n.setProviderType(e.getExternalProviderData().getType()), new o.Ay(507, (new u.Mrk).setMethod(n).setAccessType(t)).request()
                        },
                        setRequest_: function(e, t) {
                            return new o.Ay(this.setRequestMessageType, e).setRetryCount(this.maxRetries_).on(o.jU.apply(null, this.setResponseMessageType), t, this).request()
                        },
                        setVerified: function(e) {
                            var t = this,
                                n = (new u.aYs).setType(e.methodType);
                            return 1 === e.methodType && e.phoneVerificationType && n.setSwitchPhoneNumberVerificationType(e.phoneVerificationType), "string" == typeof e.pin ? n.setPinCode(e.pin) : 1 === e.methodType ? (e.token && (n.setPhoneNumber(e.token), n.setPhonePinRequest(!0)), e.phonePrefix && n.setPhonePrefix(e.phonePrefix), e.reset && n.setReset(!0)) : 5 === e.methodType ? "string" == typeof e.photoId && n.setPhotoId(e.photoId) : n.setExternalProviderDetails((new u.TlF).setProviderId(e.providerId)), e.verifyForUser && n.setVerifyForUser(e.verifyForUser), e.context && n.setContext(e.context), l._super.set.call(this, n).then((function(t) {
                                var n = t[0],
                                    r = t[1];
                                return p(e, n, r), n
                            })).catch((function(e) {
                                return t.onError_(e)
                            }))
                        },
                        getPhotoVerificationUploadedData: function() {
                            return this.photoVerificationUploadedData_
                        },
                        setPhotoVerificationUploadedData: function(e) {
                            this.photoVerificationUploadedData_ = e
                        },
                        clearPhotoVerificationUploadedData: function() {
                            this.setPhotoVerificationUploadedData(null)
                        },
                        remove: function(e) {
                            var t = this,
                                n = new u.Wgd;
                            return n.setVerificationType(e.methodType), (0, i.Rg)(e.providerType) && n.setExternalProviderType(e.providerType), new Promise((function(r, i) {
                                new o.Ay(t.removeRequestMessageType, n).on(t.removeResponseMessageType, (function(t, n) {
                                    t ? i(t) : (p(e, n.getVerifiedSource()), r(n))
                                })).request()
                            }))
                        }
                    }, "Verification");

                function p(e, t, n) {
                    d.A.getInstance().invalidateAll(), c.A.getInstance().invalidateAll(), t && (t = t instanceof u.JnN ? t : t.getVerifiedSource(), g(s.A.getUserId(), t)), null != e && e.verifyForUser && n instanceof u.JnN && g(e.verifyForUser, n)
                }

                function g(e, t) {
                    if (t) {
                        var n = {
                            verifiedInformation: t
                        };
                        t.hasVerificationStatus() && (n.verificationStatus = t.getVerificationStatus()), d.A.getInstance().updateCache(e, n)
                    }
                }
                l.getInstance = function() {
                    return r || (r = new l)
                }, t.A = l
            },
            63620: function(e, t, n) {
                var r;
                n.d(t, {
                        l: function() {
                            return r
                        }
                    }),
                    function(e) {
                        e.ADD_INTERESTS = "add-interests", e.OWN_INTERESTS = "own-interests", e.ADD_PHOTOS = "add-photos", e.PREVIEW_PROFILE = "preview-profile", e.VERIFICATION = "verification", e.ANCHOR_MOOD_STATUS = "mood-status", e.PLANS_TAB = "plans", e.SAFETY_TAB = "safety"
                    }(r || (r = {}))
            },
            93019: function(e, t, n) {
                n.d(t, {
                    I: function() {
                        return o
                    },
                    p: function() {
                        return a
                    }
                });
                n(62062);
                var r, i = ((r = {})[0] = "unknown", r[1] = "friends", r[2] = "chat", r[3] = "date", r[4] = "casual", r[5] = "serious", r[6] = "dont_mind", r[7] = "business", r[8] = "long_commitment", r),
                    o = function(e) {
                        switch (e) {
                            case 2:
                                return {
                                    name: "generic-bubble",
                                    color: "default"
                                };
                            case 3:
                                return {
                                    name: "generic-cup",
                                    color: "default"
                                };
                            case 5:
                                return {
                                    name: "generic-heart",
                                    color: "default"
                                };
                            default:
                                return
                        }
                    },
                    a = function(e, t, n) {
                        return e.map((function(e) {
                            var r = o(e.type);
                            return {
                                id: e.tiw_phrase_id,
                                header: e.tiw_phrase,
                                description: e.tiw_description,
                                isSelected: e.tiw_phrase_id === t,
                                onOptionClick: function() {
                                    return n(e.tiw_phrase_id)
                                },
                                type: i[e.type || 0],
                                icon: r
                            }
                        }))
                    }
            }
        }
    ]);
//# sourceMappingURL=3700.e9018fefdb3695e36b65.js.map
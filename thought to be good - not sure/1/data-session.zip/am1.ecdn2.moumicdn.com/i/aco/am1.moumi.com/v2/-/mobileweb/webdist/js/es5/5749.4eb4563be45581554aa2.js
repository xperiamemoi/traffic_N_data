var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            n = (new Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "bbb363a6-9040-4c8b-a13c-b57f48313080", e._sentryDebugIdIdentifier = "sentry-dbid-bbb363a6-9040-4c8b-a13c-b57f48313080")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                n = (new Error).stack;
            n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "bbb363a6-9040-4c8b-a13c-b57f48313080", e._sentryDebugIdIdentifier = "sentry-dbid-bbb363a6-9040-4c8b-a13c-b57f48313080")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [5749], {
            426: function(e, n, t) {
                "use strict";
                var i = t(74848),
                    r = t(32485),
                    a = t.n(r),
                    o = t(25275);
                n.A = ({
                    type: e = "base",
                    id: n = "chat-composer-mini-input",
                    name: t,
                    value: r,
                    iconName: s,
                    iconColor: c,
                    iconColorCustomValue: l,
                    isActionDisabled: u,
                    onFocus: d,
                    onChange: f,
                    onBlur: p,
                    onSubmit: m,
                    inputRef: b,
                    a11y: h
                }) => {
                    const y = a()({
                            "csms-chat-composer-mini": !0,
                            [`csms-chat-composer-mini--${e}`]: e
                        }),
                        x = a()({
                            "csms-chat-composer-mini__action": !0,
                            "csms-chat-composer-mini__action--is-disabled": u
                        });
                    return (0, i.jsxs)("form", {
                        className: y,
                        onSubmit: m,
                        "aria-label": h.formLabel,
                        noValidate: !0,
                        children: [(0, i.jsxs)("div", {
                            className: "csms-chat-composer-mini__input",
                            children: [r ? null : (0, i.jsx)("label", {
                                className: "csms-chat-composer-mini__input-label",
                                "aria-hidden": !0,
                                htmlFor: n,
                                children: h.inputLabel
                            }), (0, i.jsx)("input", {
                                className: "csms-chat-composer-mini__input-field",
                                type: "text",
                                id: n,
                                name: t,
                                value: r,
                                onFocus: d,
                                onChange: f,
                                onBlur: p,
                                autoComplete: "off",
                                ref: b,
                                "data-qa": "quick-chat-text-input",
                                "aria-label": h.inputLabel
                            })]
                        }), (0, i.jsx)("div", {
                            className: "csms-chat-composer-mini__focus-ring"
                        }), (0, i.jsx)("div", {
                            className: x,
                            children: (0, i.jsx)(o.A, {
                                icon: s,
                                color: c,
                                colorCustomValue: l,
                                isDisabled: u,
                                a11y: {
                                    label: h.actionLabel
                                },
                                buttonAttrs: {
                                    type: "submit"
                                },
                                dataQA: {
                                    "data-qa": "quick-chat-send"
                                }
                            })
                        })]
                    })
                }
            },
            842: function(e, n, t) {
                "use strict";
                var i = t(74848),
                    r = t(96540);
                n.A = ({
                    children: e,
                    onClick: n,
                    innerRef: t,
                    dataQA: a,
                    a11y: o
                }) => {
                    const s = {
                        "data-qa": "overlay-action",
                        ...a
                    };
                    return n ? (0, i.jsx)("button", {
                        className: "csms-a11y-stretched-touch",
                        onClick: n,
                        ref: t,
                        tabIndex: o ? .tabIndex,
                        "aria-hidden": o ? .ariaHidden || !e,
                        "aria-describedby": o ? .ariaDescribedby,
                        type: "button",
                        ...s,
                        children: e
                    }) : (0, i.jsx)(r.Fragment, {
                        children: e
                    })
                }
            },
            2694: function(e, n, t) {
                "use strict";
                var i = t(6925);

                function r() {}

                function a() {}
                a.resetWarningCache = r, e.exports = function() {
                    function e(e, n, t, r, a, o) {
                        if (o !== i) {
                            var s = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
                            throw s.name = "Invariant Violation", s
                        }
                    }

                    function n() {
                        return e
                    }
                    e.isRequired = e;
                    var t = {
                        array: e,
                        bigint: e,
                        bool: e,
                        func: e,
                        number: e,
                        object: e,
                        string: e,
                        symbol: e,
                        any: e,
                        arrayOf: n,
                        element: e,
                        elementType: e,
                        instanceOf: n,
                        node: e,
                        objectOf: n,
                        oneOf: n,
                        oneOfType: n,
                        shape: n,
                        exact: n,
                        checkPropTypes: a,
                        resetWarningCache: r
                    };
                    return t.PropTypes = t, t
                }
            },
            3368: function(e, n) {
                "use strict";
                n.A = function(e) {
                    return function(n) {
                        return null == e ? void 0 : e[n]
                    }
                }
            },
            3809: function(e, n, t) {
                "use strict";
                var i = t(74848),
                    r = t(32485),
                    a = t.n(r);
                n.A = ({
                    id: e,
                    name: n,
                    value: t,
                    maxLength: r,
                    autoFocus: o,
                    maxHeight: s,
                    minHeight: c,
                    autoResize: l,
                    rows: u = 1,
                    isFocused: d,
                    status: f,
                    onFocus: p,
                    onChange: m,
                    onBlur: b,
                    onKeyUp: h,
                    textareaRef: y,
                    dataQA: x,
                    dataQATextarea: v,
                    a11y: g = {}
                }) => {
                    const _ = a()({
                            "csms-text-area": !0,
                            "csms-text-area--is-focused": d,
                            [`csms-text-area--status-${f}`]: f
                        }),
                        E = {
                            "data-qa": "text-area",
                            ...x
                        },
                        w = {
                            maxHeight: s ? `${s}px` : void 0,
                            minHeight: c ? `${c}px` : void 0
                        };
                    return (0, i.jsxs)("div", {
                        className: _,
                        ...E,
                        children: [l ? (0, i.jsx)("div", {
                            className: "csms-text-area__mirror",
                            "aria-hidden": !0,
                            style: w,
                            children: t
                        }) : null, (0, i.jsx)("textarea", {
                            className: "csms-text-area__input",
                            id: e,
                            name: n,
                            value: t,
                            maxLength: r,
                            autoFocus: o,
                            style: w,
                            rows: u,
                            onFocus: p,
                            onChange: m,
                            onKeyUp: h,
                            onBlur: b,
                            ref: y,
                            dir: "auto",
                            "data-qa": v || "text-area-input",
                            "aria-label": g ? .textareaLabel,
                            "aria-describedby": g.ariaDescribedby,
                            "aria-required": g.ariaRequired,
                            "aria-invalid": "error" === f || void 0
                        }), (0, i.jsx)("div", {
                            className: "csms-text-area__focus-ring"
                        })]
                    })
                }
            },
            5556: function(e, n, t) {
                e.exports = t(2694)()
            },
            6925: function(e) {
                "use strict";
                e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
            },
            9417: function(e, n, t) {
                "use strict";

                function i(e) {
                    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return e
                }
                t.d(n, {
                    A: function() {
                        return i
                    }
                })
            },
            10901: function(e, n, t) {
                "use strict";
                t.d(n, {
                    A: function() {
                        return s
                    }
                });
                var i = t(3456),
                    r = (0, t(3368).A)({
                        "&amp;": "&",
                        "&lt;": "<",
                        "&gt;": ">",
                        "&quot;": '"',
                        "&#39;": "'"
                    }),
                    a = /&(?:amp|lt|gt|quot|#39);/g,
                    o = RegExp(a.source);
                var s = function(e) {
                    return (e = (0, i.A)(e)) && o.test(e) ? e.replace(a, r) : e
                }
            },
            25275: function(e, n, t) {
                "use strict";
                var i = t(74848),
                    r = t(32485),
                    a = t.n(r),
                    o = t(8483);
                n.A = ({
                    icon: e,
                    color: n = "base",
                    colorCustomValue: t,
                    onClick: r,
                    isDisabled: s,
                    buttonAttrs: c,
                    dataQA: l,
                    a11y: u
                }) => {
                    const d = a()({
                        "csms-chat-composer-action": !0,
                        [`csms-chat-composer-action--${n}`]: n
                    });
                    let f;
                    "custom" === n && (f = {
                        color: t
                    });
                    const p = !!r || !!c ? .type,
                        m = p ? "button" : "span",
                        b = {
                            className: d,
                            style: f,
                            onClick: s ? void 0 : r,
                            type: p ? c ? .type || "button" : void 0,
                            "aria-disabled": p && s ? s : void 0,
                            "aria-pressed": "toggle" === u.role ? Boolean(u.ariaPressed) : void 0,
                            ...l
                        };
                    return (0, i.jsx)(m, { ...b,
                        children: (0, i.jsx)(o.A, {
                            name: e,
                            a11y: {
                                label: u.label
                            }
                        })
                    })
                }
            },
            41562: function(e, n, t) {
                "use strict";

                function i(e) {
                    if (!e) return !1;
                    if (!0 === e.isTrusted) return !0;
                    var n = e;
                    return 0 !== n.pageX || 0 !== n.pageY
                }
                t.d(n, {
                    Z: function() {
                        return i
                    }
                })
            },
            54922: function(e, n, t) {
                "use strict";
                t.d(n, {
                    dw: function() {
                        return o
                    },
                    p7: function() {
                        return r
                    },
                    qX: function() {
                        return s
                    }
                });
                var i = t(96540);

                function r(e, n) {
                    var t = Object.create(null);
                    return e && i.Children.map(e, (function(e) {
                        return e
                    })).forEach((function(e) {
                        t[e.key] = function(e) {
                            return n && (0, i.isValidElement)(e) ? n(e) : e
                        }(e)
                    })), t
                }

                function a(e, n, t) {
                    return null != t[n] ? t[n] : e.props[n]
                }

                function o(e, n) {
                    return r(e.children, (function(t) {
                        return (0, i.cloneElement)(t, {
                            onExited: n.bind(null, t),
                            in: !0,
                            appear: a(t, "appear", e),
                            enter: a(t, "enter", e),
                            exit: a(t, "exit", e)
                        })
                    }))
                }

                function s(e, n, t) {
                    var o = r(e.children),
                        s = function(e, n) {
                            function t(t) {
                                return t in n ? n[t] : e[t]
                            }
                            e = e || {}, n = n || {};
                            var i, r = Object.create(null),
                                a = [];
                            for (var o in e) o in n ? a.length && (r[o] = a, a = []) : a.push(o);
                            var s = {};
                            for (var c in n) {
                                if (r[c])
                                    for (i = 0; i < r[c].length; i++) {
                                        var l = r[c][i];
                                        s[r[c][i]] = t(l)
                                    }
                                s[c] = t(c)
                            }
                            for (i = 0; i < a.length; i++) s[a[i]] = t(a[i]);
                            return s
                        }(n, o);
                    return Object.keys(s).forEach((function(r) {
                        var c = s[r];
                        if ((0, i.isValidElement)(c)) {
                            var l = r in n,
                                u = r in o,
                                d = n[r],
                                f = (0, i.isValidElement)(d) && !d.props.in;
                            !u || l && !f ? u || !l || f ? u && l && (0, i.isValidElement)(d) && (s[r] = (0, i.cloneElement)(c, {
                                onExited: t.bind(null, c),
                                in: d.props.in,
                                exit: a(c, "exit", e),
                                enter: a(c, "enter", e)
                            })) : s[r] = (0, i.cloneElement)(c, { in: !1
                            }) : s[r] = (0, i.cloneElement)(c, {
                                onExited: t.bind(null, c),
                                in: !0,
                                exit: a(c, "exit", e),
                                enter: a(c, "enter", e)
                            })
                        }
                    })), s
                }
            },
            55015: function(e, n, t) {
                "use strict";
                var i = t(74848),
                    r = t(32485),
                    a = t.n(r),
                    o = t(842),
                    s = t(93827);
                n.A = ({
                    header: e,
                    children: n,
                    hpadded: t
                }) => {
                    const r = a()({
                        "csms-view-profile-block": !0,
                        "csms-view-profile-block--hpadded": t
                    });
                    return (0, i.jsxs)("section", {
                        className: r,
                        children: [e ? (0, i.jsxs)("div", {
                            className: "csms-view-profile-block__header",
                            children: [e.title ? (0, i.jsx)("div", {
                                className: "csms-view-profile-block__header-title",
                                children: (0, i.jsx)(s.gT, {
                                    color: "gray-80",
                                    ellipsis: !0,
                                    tag: e.titleTag || "h3",
                                    children: (0, i.jsx)(o.A, {
                                        onClick: e.onClickTitle,
                                        children: e.title
                                    })
                                })
                            }) : null, e.text ? (0, i.jsx)("div", {
                                className: "csms-view-profile-block__header-text",
                                children: (0, i.jsx)(s.Sz, {
                                    color: "black",
                                    children: e.text
                                })
                            }) : null, e.action ? (0, i.jsx)("button", {
                                className: "csms-view-profile-block__header-action",
                                onClick: e.onClickAction,
                                type: "button",
                                children: (0, i.jsx)(s.rc, {
                                    children: e.action
                                })
                            }) : null]
                        }) : null, n ? (0, i.jsx)("div", {
                            className: "csms-view-profile-block__content",
                            children: n
                        }) : null]
                    })
                }
            },
            80004: function(e, n, t) {
                "use strict";
                var i = t(98587),
                    r = t(58168),
                    a = t(9417),
                    o = t(25540),
                    s = t(96540),
                    c = t(17241),
                    l = t(54922),
                    u = Object.values || function(e) {
                        return Object.keys(e).map((function(n) {
                            return e[n]
                        }))
                    },
                    d = function(e) {
                        function n(n, t) {
                            var i, r = (i = e.call(this, n, t) || this).handleExited.bind((0, a.A)(i));
                            return i.state = {
                                contextValue: {
                                    isMounting: !0
                                },
                                handleExited: r,
                                firstRender: !0
                            }, i
                        }(0, o.A)(n, e);
                        var t = n.prototype;
                        return t.componentDidMount = function() {
                            this.mounted = !0, this.setState({
                                contextValue: {
                                    isMounting: !1
                                }
                            })
                        }, t.componentWillUnmount = function() {
                            this.mounted = !1
                        }, n.getDerivedStateFromProps = function(e, n) {
                            var t = n.children,
                                i = n.handleExited;
                            return {
                                children: n.firstRender ? (0, l.dw)(e, i) : (0, l.qX)(e, t, i),
                                firstRender: !1
                            }
                        }, t.handleExited = function(e, n) {
                            var t = (0, l.p7)(this.props.children);
                            e.key in t || (e.props.onExited && e.props.onExited(n), this.mounted && this.setState((function(n) {
                                var t = (0, r.A)({}, n.children);
                                return delete t[e.key], {
                                    children: t
                                }
                            })))
                        }, t.render = function() {
                            var e = this.props,
                                n = e.component,
                                t = e.childFactory,
                                r = (0, i.A)(e, ["component", "childFactory"]),
                                a = this.state.contextValue,
                                o = u(this.state.children).map(t);
                            return delete r.appear, delete r.enter, delete r.exit, null === n ? s.createElement(c.A.Provider, {
                                value: a
                            }, o) : s.createElement(c.A.Provider, {
                                value: a
                            }, s.createElement(n, r, o))
                        }, n
                    }(s.Component);
                d.propTypes = {}, d.defaultProps = {
                    component: "div",
                    childFactory: function(e) {
                        return e
                    }
                }, n.A = d
            }
        }
    ]);
//# sourceMappingURL=5749.4eb4563be45581554aa2.js.map
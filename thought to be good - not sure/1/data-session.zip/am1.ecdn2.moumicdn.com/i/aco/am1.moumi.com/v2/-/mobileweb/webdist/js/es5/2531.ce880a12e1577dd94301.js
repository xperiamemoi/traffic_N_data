var _global;
! function() {
    try {
        var _ = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            O = (new Error).stack;
        O && (_._sentryDebugIds = _._sentryDebugIds || {}, _._sentryDebugIds[O] = "9125a2c4-16b2-4ffe-8ddb-57c3f49482c2", _._sentryDebugIdIdentifier = "sentry-dbid-9125a2c4-16b2-4ffe-8ddb-57c3f49482c2")
    } catch (_) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var _ = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                O = (new Error).stack;
            O && (_._sentryDebugIds = _._sentryDebugIds || {}, _._sentryDebugIds[O] = "9125a2c4-16b2-4ffe-8ddb-57c3f49482c2", _._sentryDebugIdIdentifier = "sentry-dbid-9125a2c4-16b2-4ffe-8ddb-57c3f49482c2")
        } catch (_) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [2531], {
            82531: function(_, O, T) {
                T.r(O), T.d(O, {
                    TOKEN_A11Y_FOCUS_RING_FIELD_COLOR: function() {
                        return E
                    },
                    TOKEN_A11Y_FOCUS_RING_FIELD_OFFSET: function() {
                        return n
                    },
                    TOKEN_A11Y_FOCUS_RING_FIELD_WIDTH: function() {
                        return N
                    },
                    TOKEN_A11Y_FOCUS_RING_INNER_COLOR: function() {
                        return C
                    },
                    TOKEN_A11Y_FOCUS_RING_INNER_OFFSET: function() {
                        return A
                    },
                    TOKEN_A11Y_FOCUS_RING_INNER_WIDTH: function() {
                        return S
                    },
                    TOKEN_A11Y_FOCUS_RING_OUTER_COLOR: function() {
                        return R
                    },
                    TOKEN_A11Y_FOCUS_RING_OUTER_OFFSET: function() {
                        return I
                    },
                    TOKEN_A11Y_FOCUS_RING_OUTER_WIDTH: function() {
                        return t
                    },
                    TOKEN_A11Y_MIN_TARGET_SIZE: function() {
                        return u
                    },
                    TOKEN_ACTIONSHEET_FOOTER_PADDING_BOTTOM: function() {
                        return r
                    },
                    TOKEN_ACTIONSHEET_FOOTER_PADDING_HORIZONTAL: function() {
                        return L
                    },
                    TOKEN_ACTIONSHEET_GRAVITY: function() {
                        return K
                    },
                    TOKEN_ACTIONSHEET_HEADER_BACKGROUND_BASE: function() {
                        return M
                    },
                    TOKEN_ACTIONSHEET_HEADER_BACKGROUND_PRIMARY: function() {
                        return e
                    },
                    TOKEN_ACTIONSHEET_HEADER_EXTRA_MARGIN_TOP: function() {
                        return F
                    },
                    TOKEN_ACTIONSHEET_HEADER_MEDIA_BADGE_SIZE: function() {
                        return D
                    },
                    TOKEN_ACTIONSHEET_HEADER_MEDIA_MARGIN_BOTTOM: function() {
                        return i
                    },
                    TOKEN_ACTIONSHEET_HEADER_PADDING_HORIZONTAL: function() {
                        return c
                    },
                    TOKEN_ACTIONSHEET_HEADER_PADDING_TOP: function() {
                        return o
                    },
                    TOKEN_ACTIONSHEET_HEADER_PADDING_VERTICAL: function() {
                        return f
                    },
                    TOKEN_ACTIONSHEET_HEADER_TEXT_MARGIN_TOP: function() {
                        return G
                    },
                    TOKEN_ACTIONSHEET_ITEM_BORDER_COLOR: function() {
                        return B
                    },
                    TOKEN_ACTIONSHEET_ITEM_BORDER_WIDTH: function() {
                        return P
                    },
                    TOKEN_ACTIONSHEET_ITEM_COLOR_DESTRUCTIVE: function() {
                        return U
                    },
                    TOKEN_ACTIONSHEET_ITEM_COLOR_GENERIC: function() {
                        return H
                    },
                    TOKEN_ACTIONSHEET_ITEM_HEIGHT: function() {
                        return p
                    },
                    TOKEN_ACTIONSHEET_ITEM_PADDING_HORIZONTAL: function() {
                        return x
                    },
                    TOKEN_ACTIONSHEET_ITEM_PADDING_VERTICAL: function() {
                        return Y
                    },
                    TOKEN_ACTIONSHEET_LIST_MARGIN_BOTTOM: function() {
                        return V
                    },
                    TOKEN_ACTIONSHEET_LIST_MARGIN_TOP: function() {
                        return W
                    },
                    TOKEN_ACTIONSHEET_SPACING_HEADER_FOOTER: function() {
                        return Z
                    },
                    TOKEN_ACTIONSHEET_SPACING_LIST_FOOTER: function() {
                        return X
                    },
                    TOKEN_ACTION_CELL_BASE_BACKGROUND_COLOR: function() {
                        return s
                    },
                    TOKEN_ACTION_CELL_BASE_TEXT_COLOR: function() {
                        return a
                    },
                    TOKEN_ACTION_CELL_BORDER_RADIUS: function() {
                        return l
                    },
                    TOKEN_ACTION_CELL_EXTRA_HEIGHT: function() {
                        return d
                    },
                    TOKEN_ACTION_CELL_EXTRA_MARGIN_LEFT: function() {
                        return b
                    },
                    TOKEN_ACTION_CELL_EXTRA_MIN_WIDTH: function() {
                        return m
                    },
                    TOKEN_ACTION_CELL_MAX_WIDTH: function() {
                        return y
                    },
                    TOKEN_ACTION_CELL_MEDIA_MARGIN_RIGHT: function() {
                        return w
                    },
                    TOKEN_ACTION_CELL_MEDIA_SIZE: function() {
                        return g
                    },
                    TOKEN_ACTION_CELL_PADDING_HORIZONTAL: function() {
                        return Q
                    },
                    TOKEN_ACTION_CELL_PADDING_VERTICAL: function() {
                        return h
                    },
                    TOKEN_ACTION_CELL_SELECTED_BACKGROUND_COLOR: function() {
                        return J
                    },
                    TOKEN_ACTION_CELL_SELECTED_TEXT_COLOR: function() {
                        return k
                    },
                    TOKEN_ACTION_ROW_EXTRA_COLOR: function() {
                        return v
                    },
                    TOKEN_ACTION_ROW_EXTRA_MARGIN_LEFT: function() {
                        return j
                    },
                    TOKEN_ACTION_ROW_EXTRA_MEDIUM_HEIGHT: function() {
                        return q
                    },
                    TOKEN_ACTION_ROW_EXTRA_MEDIUM_MIN_WIDTH: function() {
                        return z
                    },
                    TOKEN_ACTION_ROW_EXTRA_SMALL_HEIGHT: function() {
                        return $
                    },
                    TOKEN_ACTION_ROW_EXTRA_SMALL_MIN_WIDTH: function() {
                        return __
                    },
                    TOKEN_ACTION_ROW_HINT_COLOR: function() {
                        return O_
                    },
                    TOKEN_ACTION_ROW_HINT_MARGIN_TOP: function() {
                        return T_
                    },
                    TOKEN_ACTION_ROW_MEDIA_COLOR: function() {
                        return E_
                    },
                    TOKEN_ACTION_ROW_MEDIA_MARGIN_RIGHT: function() {
                        return n_
                    },
                    TOKEN_ACTION_ROW_MEDIA_SIZE: function() {
                        return N_
                    },
                    TOKEN_ACTION_ROW_PADDING_HORIZONTAL: function() {
                        return C_
                    },
                    TOKEN_ACTION_ROW_PADDING_VERTICAL: function() {
                        return A_
                    },
                    TOKEN_ACTION_ROW_STATUS_PRESSED_BACKGROUND_COLOR: function() {
                        return S_
                    },
                    TOKEN_ACTION_ROW_STATUS_PRESSED_BACKGROUND_OPACITY: function() {
                        return R_
                    },
                    TOKEN_ACTION_ROW_TITLE_COLOR: function() {
                        return I_
                    },
                    TOKEN_ACTION_ROW_TITLE_COLOR_BASE: function() {
                        return t_
                    },
                    TOKEN_ACTION_ROW_TITLE_COLOR_DANGER: function() {
                        return u_
                    },
                    TOKEN_ACTION_ROW_VALUE_ICON_COLOR: function() {
                        return r_
                    },
                    TOKEN_ACTION_ROW_VALUE_ICON_MARGIN_RIGHT: function() {
                        return L_
                    },
                    TOKEN_ACTION_ROW_VALUE_ICON_SIZE: function() {
                        return K_
                    },
                    TOKEN_ACTION_ROW_VALUE_MARGIN_LEFT: function() {
                        return M_
                    },
                    TOKEN_ACTION_ROW_VALUE_TEXT_COLOR: function() {
                        return e_
                    },
                    TOKEN_ADAPTOR_ACTION_COLOR: function() {
                        return F_
                    },
                    TOKEN_ADAPTOR_CHEVRON_COLOR: function() {
                        return D_
                    },
                    TOKEN_ADAPTOR_CHEVRON_SIZE: function() {
                        return i_
                    },
                    TOKEN_ADAPTOR_MESSAGE_COLOR: function() {
                        return c_
                    },
                    TOKEN_ADAPTOR_MESSAGE_MARGIN_TOP: function() {
                        return o_
                    },
                    TOKEN_ADAPTOR_TITLE_COLOR: function() {
                        return f_
                    },
                    TOKEN_AVATAR_BACKGROUND_COLOR: function() {
                        return G_
                    },
                    TOKEN_AVATAR_PLACEHOLDER_COLOR_DEFAULT: function() {
                        return B_
                    },
                    TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_1: function() {
                        return P_
                    },
                    TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_2: function() {
                        return U_
                    },
                    TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_3: function() {
                        return H_
                    },
                    TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_4: function() {
                        return p_
                    },
                    TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_5: function() {
                        return x_
                    },
                    TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_6: function() {
                        return Y_
                    },
                    TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_7: function() {
                        return V_
                    },
                    TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_8: function() {
                        return W_
                    },
                    TOKEN_AVATAR_PLACEHOLDER_COLOR_VARIANT_9: function() {
                        return Z_
                    },
                    TOKEN_BADGE_LARGE_BORDER_RADIUS: function() {
                        return X_
                    },
                    TOKEN_BADGE_LARGE_END_ICON_SIZE: function() {
                        return s_
                    },
                    TOKEN_BADGE_LARGE_HEIGHT: function() {
                        return a_
                    },
                    TOKEN_BADGE_LARGE_MEDIA_SIZE: function() {
                        return l_
                    },
                    TOKEN_BADGE_LARGE_PADDING_HORIZONTAL: function() {
                        return d_
                    },
                    TOKEN_BADGE_LARGE_SPACING_MEDIA_TEXT: function() {
                        return b_
                    },
                    TOKEN_BADGE_LARGE_SPACING_TEXT_ICON: function() {
                        return m_
                    },
                    TOKEN_BADGE_MEDIUM_BORDER_RADIUS: function() {
                        return y_
                    },
                    TOKEN_BADGE_MEDIUM_END_ICON_SIZE: function() {
                        return w_
                    },
                    TOKEN_BADGE_MEDIUM_HEIGHT: function() {
                        return g_
                    },
                    TOKEN_BADGE_MEDIUM_MEDIA_SIZE: function() {
                        return Q_
                    },
                    TOKEN_BADGE_MEDIUM_PADDING_HORIZONTAL: function() {
                        return h_
                    },
                    TOKEN_BADGE_MEDIUM_SPACING_MEDIA_TEXT: function() {
                        return J_
                    },
                    TOKEN_BADGE_MEDIUM_SPACING_TEXT_ICON: function() {
                        return k_
                    },
                    TOKEN_BADGE_SMALL_BORDER_RADIUS: function() {
                        return v_
                    },
                    TOKEN_BADGE_SMALL_END_ICON_SIZE: function() {
                        return j_
                    },
                    TOKEN_BADGE_SMALL_HEIGHT: function() {
                        return q_
                    },
                    TOKEN_BADGE_SMALL_MEDIA_SIZE: function() {
                        return z_
                    },
                    TOKEN_BADGE_SMALL_PADDING_HORIZONTAL: function() {
                        return $_
                    },
                    TOKEN_BADGE_SMALL_SPACING_MEDIA_TEXT: function() {
                        return _O
                    },
                    TOKEN_BADGE_SMALL_SPACING_TEXT_ICON: function() {
                        return OO
                    },
                    TOKEN_BORDER_RADIUS_LG: function() {
                        return TO
                    },
                    TOKEN_BORDER_RADIUS_MD: function() {
                        return EO
                    },
                    TOKEN_BORDER_RADIUS_SM: function() {
                        return nO
                    },
                    TOKEN_BORDER_RADIUS_XLG: function() {
                        return NO
                    },
                    TOKEN_BORDER_RADIUS_XXLG: function() {
                        return CO
                    },
                    TOKEN_BRICKGROUP_CASCADE_MD_OVERLAP: function() {
                        return AO
                    },
                    TOKEN_BRICKGROUP_CASCADE_SM_OVERLAP: function() {
                        return SO
                    },
                    TOKEN_BRICKGROUP_CASCADE_XXSM_OVERLAP: function() {
                        return RO
                    },
                    TOKEN_BRICKGROUP_DOUBLE_MM_OVERLAP: function() {
                        return IO
                    },
                    TOKEN_BRICKGROUP_TRIPLE_MMM_OVERLAP: function() {
                        return tO
                    },
                    TOKEN_BRICKGROUP_TRIPLE_MXLM_OVERLAP: function() {
                        return uO
                    },
                    TOKEN_BRICKGROUP_TRIPLE_SMS_OVERLAP: function() {
                        return rO
                    },
                    TOKEN_BRICK_BADGE_SIZE_LG: function() {
                        return LO
                    },
                    TOKEN_BRICK_BADGE_SIZE_MD: function() {
                        return KO
                    },
                    TOKEN_BRICK_BADGE_SIZE_RATIO: function() {
                        return MO
                    },
                    TOKEN_BRICK_BADGE_SIZE_SM: function() {
                        return eO
                    },
                    TOKEN_BRICK_BORDER_RADIUS_CIRCLE: function() {
                        return FO
                    },
                    TOKEN_BRICK_BORDER_RADIUS_SQUARED: function() {
                        return DO
                    },
                    TOKEN_BRICK_BORDER_RADIUS_SQUARED_FIXED: function() {
                        return iO
                    },
                    TOKEN_BRICK_HALO_COLOR_LIKED_YOU: function() {
                        return cO
                    },
                    TOKEN_BRICK_HALO_COLOR_PRIMARY: function() {
                        return oO
                    },
                    TOKEN_BRICK_HALO_GAP: function() {
                        return fO
                    },
                    TOKEN_BRICK_HALO_WIDTH: function() {
                        return GO
                    },
                    TOKEN_BRICK_MD_BADGE_SIZE: function() {
                        return BO
                    },
                    TOKEN_BRICK_OVERLAY_DARK_BACKGROUND_COLOR: function() {
                        return PO
                    },
                    TOKEN_BRICK_OVERLAY_DARK_BACKGROUND_OPACITY: function() {
                        return UO
                    },
                    TOKEN_BRICK_OVERLAY_PRIMARY_BACKGROUND_COLOR: function() {
                        return HO
                    },
                    TOKEN_BRICK_OVERLAY_PRIMARY_BACKGROUND_OPACITY: function() {
                        return pO
                    },
                    TOKEN_BRICK_SIZE_LG: function() {
                        return xO
                    },
                    TOKEN_BRICK_SIZE_MD: function() {
                        return YO
                    },
                    TOKEN_BRICK_SIZE_SM: function() {
                        return VO
                    },
                    TOKEN_BRICK_SIZE_XLG: function() {
                        return WO
                    },
                    TOKEN_BRICK_SIZE_XXSM: function() {
                        return ZO
                    },
                    TOKEN_BRICK_SM_BADGE_SIZE: function() {
                        return XO
                    },
                    TOKEN_BRICK_XXSM_BADGE_SIZE: function() {
                        return sO
                    },
                    TOKEN_BUTTON_MAX_WIDTH: function() {
                        return aO
                    },
                    TOKEN_BUTTON_MEDIUM_BORDER_RADIUS: function() {
                        return lO
                    },
                    TOKEN_BUTTON_MEDIUM_HEIGHT: function() {
                        return dO
                    },
                    TOKEN_BUTTON_MEDIUM_ICON_SIZE: function() {
                        return bO
                    },
                    TOKEN_BUTTON_MEDIUM_LOADER_SIZE: function() {
                        return mO
                    },
                    TOKEN_BUTTON_MEDIUM_PADDING_HORIZONTAL: function() {
                        return yO
                    },
                    TOKEN_BUTTON_MEDIUM_PADDING_VERTICAL: function() {
                        return wO
                    },
                    TOKEN_BUTTON_MEDIUM_SPACING_ICON_TEXT: function() {
                        return gO
                    },
                    TOKEN_BUTTON_SMALL_BORDER_RADIUS: function() {
                        return QO
                    },
                    TOKEN_BUTTON_SMALL_HEIGHT: function() {
                        return hO
                    },
                    TOKEN_BUTTON_SMALL_ICON_SIZE: function() {
                        return JO
                    },
                    TOKEN_BUTTON_SMALL_LOADER_SIZE: function() {
                        return kO
                    },
                    TOKEN_BUTTON_SMALL_PADDING_HORIZONTAL: function() {
                        return vO
                    },
                    TOKEN_BUTTON_SMALL_PADDING_VERTICAL: function() {
                        return jO
                    },
                    TOKEN_BUTTON_SMALL_SPACING_ICON_TEXT: function() {
                        return qO
                    },
                    TOKEN_BUTTON_STATUS_DISABLED_OPACITY: function() {
                        return zO
                    },
                    TOKEN_BUTTON_STATUS_FOCUSED_OVERLAY_DARK_BACKGROUND_COLOR: function() {
                        return $O
                    },
                    TOKEN_BUTTON_STATUS_FOCUSED_OVERLAY_DARK_OPACITY: function() {
                        return _T
                    },
                    TOKEN_BUTTON_STATUS_PRESSED_OVERLAY_DARK_BACKGROUND_COLOR: function() {
                        return OT
                    },
                    TOKEN_BUTTON_STATUS_PRESSED_OVERLAY_DARK_OPACITY: function() {
                        return TT
                    },
                    TOKEN_BUTTON_VARIANT_STROKE_BORDER_WIDTH: function() {
                        return ET
                    },
                    TOKEN_CHAT_BUBBLE_BASE_BACKGROUND_COLOR: function() {
                        return nT
                    },
                    TOKEN_CHAT_BUBBLE_FIX_WIDTH: function() {
                        return NT
                    },
                    TOKEN_CHAT_BUBBLE_INSET_HORIZONTAL: function() {
                        return CT
                    },
                    TOKEN_CHAT_BUBBLE_INSET_VERTICAL: function() {
                        return AT
                    },
                    TOKEN_CHAT_BUBBLE_IN_BACKGROUND_COLOR: function() {
                        return ST
                    },
                    TOKEN_CHAT_BUBBLE_IN_TEXT_COLOR: function() {
                        return RT
                    },
                    TOKEN_CHAT_BUBBLE_OUT_BACKGROUND_COLOR: function() {
                        return IT
                    },
                    TOKEN_CHAT_BUBBLE_OUT_TEXT_COLOR: function() {
                        return tT
                    },
                    TOKEN_CHAT_BUBBLE_RADIUS: function() {
                        return uT
                    },
                    TOKEN_CHAT_BUBBLE_RADIUS_SMALL: function() {
                        return rT
                    },
                    TOKEN_CHAT_BUBBLE_REL_WIDTH: function() {
                        return LT
                    },
                    TOKEN_CHAT_COMPOSER_ACTION_ACTIVE_COLOR: function() {
                        return KT
                    },
                    TOKEN_CHAT_COMPOSER_ACTION_BASE_COLOR: function() {
                        return MT
                    },
                    TOKEN_CHAT_COMPOSER_ACTION_DISABLED_COLOR: function() {
                        return eT
                    },
                    TOKEN_CHAT_COMPOSER_FRAME_HEIGHT: function() {
                        return FT
                    },
                    TOKEN_CHAT_COMPOSER_FRAME_ITEM_GAP: function() {
                        return DT
                    },
                    TOKEN_CHAT_COMPOSER_FRAME_ITEM_SIZE: function() {
                        return iT
                    },
                    TOKEN_CHAT_COMPOSER_MINI_ACTION_ICON_SIZE: function() {
                        return cT
                    },
                    TOKEN_CHAT_COMPOSER_MINI_ACTION_MARGIN_LEFT: function() {
                        return oT
                    },
                    TOKEN_CHAT_COMPOSER_MINI_INPUT_FIELD_HEIGHT: function() {
                        return fT
                    },
                    TOKEN_CHAT_COMPOSER_MINI_PADDING_START: function() {
                        return GT
                    },
                    TOKEN_CHAT_DATE_MARGIN_VERTICAL: function() {
                        return BT
                    },
                    TOKEN_CHAT_DATE_PILL_ELEVATED_BACKGROUND_COLOR: function() {
                        return PT
                    },
                    TOKEN_CHAT_DATE_PILL_ELEVATED_OUTER_BORDER_OPACITY: function() {
                        return UT
                    },
                    TOKEN_CHAT_DATE_PILL_ELEVATED_OUTER_BORDER_SIZE: function() {
                        return HT
                    },
                    TOKEN_CHAT_DATE_PILL_ELEVATED_RADIUS: function() {
                        return pT
                    },
                    TOKEN_CHAT_DATE_PILL_ELEVATED_SHADOW_BLUR_RADIUS: function() {
                        return xT
                    },
                    TOKEN_CHAT_DATE_PILL_ELEVATED_SHADOW_COLOR: function() {
                        return YT
                    },
                    TOKEN_CHAT_DATE_PILL_ELEVATED_SHADOW_OPACITY: function() {
                        return VT
                    },
                    TOKEN_CHAT_DATE_PILL_ELEVATED_SHADOW_VERTICAL_OFFSET: function() {
                        return WT
                    },
                    TOKEN_CHAT_DATE_PILL_HEIGHT: function() {
                        return ZT
                    },
                    TOKEN_CHAT_DATE_PILL_PADDING_HORIZONTAL: function() {
                        return XT
                    },
                    TOKEN_CHAT_DATE_PILL_TEXT_COLOR: function() {
                        return sT
                    },
                    TOKEN_CHAT_INPUT_FIELD_FONT_SIZE: function() {
                        return aT
                    },
                    TOKEN_CHAT_INPUT_FIELD_HEIGHT: function() {
                        return lT
                    },
                    TOKEN_CHAT_INPUT_FIELD_ICON_SIZE: function() {
                        return dT
                    },
                    TOKEN_CHAT_INPUT_FIELD_INSET_HORIZONTAL: function() {
                        return bT
                    },
                    TOKEN_CHAT_INPUT_FIELD_LINE_HEIGHT: function() {
                        return mT
                    },
                    TOKEN_CHAT_INPUT_MESSAGE_BACKGROUND_COLOR: function() {
                        return yT
                    },
                    TOKEN_CHAT_INPUT_MESSAGE_BORDER_COLOR: function() {
                        return wT
                    },
                    TOKEN_CHAT_INPUT_MESSAGE_CONTENT_COLOR: function() {
                        return gT
                    },
                    TOKEN_CHAT_INPUT_MESSAGE_PLACEHOLDER_COLOR: function() {
                        return QT
                    },
                    TOKEN_CHAT_INPUT_SEARCH_BACKGROUND_COLOR: function() {
                        return hT
                    },
                    TOKEN_CHAT_INPUT_SEARCH_BORDER_COLOR: function() {
                        return JT
                    },
                    TOKEN_CHAT_INPUT_SEARCH_CONTENT_COLOR: function() {
                        return kT
                    },
                    TOKEN_CHAT_INPUT_SEARCH_ICON_COLOR: function() {
                        return vT
                    },
                    TOKEN_CHAT_INPUT_SEARCH_ICON_MARGIN_LEFT: function() {
                        return jT
                    },
                    TOKEN_CHAT_INPUT_SEARCH_ICON_MARGIN_RIGHT: function() {
                        return qT
                    },
                    TOKEN_CHAT_INPUT_SEARCH_ICON_SIZE: function() {
                        return zT
                    },
                    TOKEN_CHAT_INPUT_SEARCH_PLACEHOLDER_COLOR: function() {
                        return $T
                    },
                    TOKEN_CHAT_ITEM_CONTENT_WIDTH_FIXED: function() {
                        return _E
                    },
                    TOKEN_CHAT_ITEM_CONTENT_WIDTH_RELATIVE: function() {
                        return OE
                    },
                    TOKEN_CHAT_ITEM_GROUP_AVATAR_BORDER_RADIUS: function() {
                        return TE
                    },
                    TOKEN_CHAT_ITEM_GROUP_AVATAR_MARGIN_BOTTOM: function() {
                        return EE
                    },
                    TOKEN_CHAT_ITEM_GROUP_AVATAR_OVERALL_SPACE: function() {
                        return nE
                    },
                    TOKEN_CHAT_ITEM_GROUP_AVATAR_SIZE: function() {
                        return NE
                    },
                    TOKEN_CHAT_ITEM_GROUP_SUPPORT: function() {
                        return CE
                    },
                    TOKEN_CHAT_ITEM_GROUP_TITLE_MARGIN_BOTTOM: function() {
                        return AE
                    },
                    TOKEN_CHAT_ITEM_MARGIN_TOP: function() {
                        return SE
                    },
                    TOKEN_CHAT_ITEM_MARGIN_TOP_CONTINUATION: function() {
                        return RE
                    },
                    TOKEN_CHAT_ITEM_REACTION_BACKGROUND_COLOR: function() {
                        return IE
                    },
                    TOKEN_CHAT_ITEM_REACTION_BORDER_COLOR: function() {
                        return tE
                    },
                    TOKEN_CHAT_ITEM_REACTION_BORDER_RADIUS: function() {
                        return uE
                    },
                    TOKEN_CHAT_ITEM_REACTION_BORDER_WIDTH: function() {
                        return rE
                    },
                    TOKEN_CHAT_ITEM_REACTION_EXTRA_MARGIN_BOTTOM: function() {
                        return LE
                    },
                    TOKEN_CHAT_ITEM_REACTION_SIZE: function() {
                        return KE
                    },
                    TOKEN_CHAT_ITEM_SELECT_OVERALL_SPACE: function() {
                        return ME
                    },
                    TOKEN_CHAT_ITEM_STATUS_COLOR_BASE: function() {
                        return eE
                    },
                    TOKEN_CHAT_ITEM_STATUS_COLOR_ERROR: function() {
                        return FE
                    },
                    TOKEN_CHAT_ITEM_STATUS_COLOR_INFO: function() {
                        return DE
                    },
                    TOKEN_CHAT_ITEM_STATUS_COLOR_READ_RECEIPT: function() {
                        return iE
                    },
                    TOKEN_CHAT_ITEM_STATUS_ICON_MARGIN_RIGHT: function() {
                        return cE
                    },
                    TOKEN_CHAT_ITEM_STATUS_ICON_SIZE: function() {
                        return oE
                    },
                    TOKEN_CHAT_ITEM_STATUS_MARGIN_TOP: function() {
                        return fE
                    },
                    TOKEN_CHAT_LIST_INSET_HORIZONTAL: function() {
                        return GE
                    },
                    TOKEN_CHAT_MESSAGE_AUDIO_BAR_GAP: function() {
                        return BE
                    },
                    TOKEN_CHAT_MESSAGE_AUDIO_BAR_MAX_HEIGHT: function() {
                        return PE
                    },
                    TOKEN_CHAT_MESSAGE_AUDIO_BAR_OPACITY: function() {
                        return UE
                    },
                    TOKEN_CHAT_MESSAGE_AUDIO_BAR_RADIUS: function() {
                        return HE
                    },
                    TOKEN_CHAT_MESSAGE_AUDIO_BAR_WIDTH: function() {
                        return pE
                    },
                    TOKEN_CHAT_MESSAGE_AUDIO_ICON_BAR_SPACING_SIZE: function() {
                        return xE
                    },
                    TOKEN_CHAT_MESSAGE_AUDIO_ICON_SIZE: function() {
                        return YE
                    },
                    TOKEN_CHAT_MESSAGE_EMOJI_FONT_SIZE: function() {
                        return VE
                    },
                    TOKEN_CHAT_MESSAGE_EMOJI_SIZE: function() {
                        return WE
                    },
                    TOKEN_CHAT_MESSAGE_FORWARD_HEADER_TEXT_OPACITY: function() {
                        return ZE
                    },
                    TOKEN_CHAT_MESSAGE_GIFT_WIDTH: function() {
                        return XE
                    },
                    TOKEN_CHAT_MESSAGE_INSET_HORIZONTAL: function() {
                        return sE
                    },
                    TOKEN_CHAT_MESSAGE_INSET_VERTICAL: function() {
                        return aE
                    },
                    TOKEN_CHAT_MESSAGE_LOCATION_ICON_MARGIN_LEFT: function() {
                        return lE
                    },
                    TOKEN_CHAT_MESSAGE_LOCATION_ICON_SIZE: function() {
                        return dE
                    },
                    TOKEN_CHAT_MESSAGE_LOCATION_NOTE_COLOR: function() {
                        return bE
                    },
                    TOKEN_CHAT_MESSAGE_LOCATION_NOTE_MARGIN_TOP: function() {
                        return mE
                    },
                    TOKEN_CHAT_MESSAGE_LOCATION_TITLE_COLOR: function() {
                        return yE
                    },
                    TOKEN_CHAT_MESSAGE_PRIVATE_PHOTO_COLOR: function() {
                        return wE
                    },
                    TOKEN_CHAT_MESSAGE_SONG_INSET_HORIZONTAL: function() {
                        return gE
                    },
                    TOKEN_CHAT_MESSAGE_SONG_INSET_VERTICAL: function() {
                        return QE
                    },
                    TOKEN_CHAT_MESSAGE_SONG_MIN_WIDTH: function() {
                        return hE
                    },
                    TOKEN_CHAT_MESSAGE_STICKER_WIDTH: function() {
                        return JE
                    },
                    TOKEN_CHAT_MESSAGE_TEXT_WITH_LINK_DESCRIPTION_COLOR: function() {
                        return kE
                    },
                    TOKEN_CHAT_MESSAGE_TEXT_WITH_LINK_DESCRIPTION_MARGIN_BOTTOM: function() {
                        return vE
                    },
                    TOKEN_CHAT_MESSAGE_TEXT_WITH_LINK_DOMAIN_COLOR: function() {
                        return jE
                    },
                    TOKEN_CHAT_MESSAGE_TEXT_WITH_LINK_PREVIEW_IMAGE_RATIO: function() {
                        return qE
                    },
                    TOKEN_CHAT_MESSAGE_TEXT_WITH_LINK_TITLE_COLOR: function() {
                        return zE
                    },
                    TOKEN_CHAT_MESSAGE_TEXT_WITH_LINK_TITLE_MARGIN_BOTTOM: function() {
                        return $E
                    },
                    TOKEN_CHAT_MESSAGE_VIDEO_TELESCOPE_BACKGROUND_COLOR: function() {
                        return _n
                    },
                    TOKEN_CHAT_MESSAGE_VIDEO_TELESCOPE_INDICATOR_SIZE: function() {
                        return On
                    },
                    TOKEN_CHAT_MESSAGE_VIDEO_TELESCOPE_SIZE: function() {
                        return Tn
                    },
                    TOKEN_CHAT_PANEL_PILLS_ITEM_BACKGROUND_COLOR: function() {
                        return En
                    },
                    TOKEN_CHAT_PANEL_PILLS_ITEM_BACKGROUND_COLOR_ACTIVE: function() {
                        return nn
                    },
                    TOKEN_CHAT_PANEL_PILLS_ITEM_BORDER_RADIUS: function() {
                        return Nn
                    },
                    TOKEN_CHAT_PANEL_PILLS_ITEM_CONTENT_COLOR: function() {
                        return Cn
                    },
                    TOKEN_CHAT_PANEL_PILLS_ITEM_CONTENT_COLOR_ACTIVE: function() {
                        return An
                    },
                    TOKEN_CHAT_PANEL_PILLS_ITEM_HEIGHT: function() {
                        return Sn
                    },
                    TOKEN_CHAT_PANEL_PILLS_ITEM_MEDIA_SIZE: function() {
                        return Rn
                    },
                    TOKEN_CHAT_PANEL_PILLS_ITEM_PADDING_HORIZONTAL: function() {
                        return In
                    },
                    TOKEN_CHAT_PANEL_PILLS_ITEM_SPACING_HORIZONTAL: function() {
                        return tn
                    },
                    TOKEN_CHAT_PREVIEW_MESSAGE_MEDIA_SHAPE_CIRCLE_BORDER_RADIUS: function() {
                        return un
                    },
                    TOKEN_CHAT_PREVIEW_MESSAGE_MEDIA_SHAPE_SQUARED_BORDER_RADIUS: function() {
                        return rn
                    },
                    TOKEN_CHAT_PREVIEW_MESSAGE_MEDIA_SIZE: function() {
                        return Ln
                    },
                    TOKEN_CHAT_PREVIEW_MESSAGE_QUOTE_DECORATION_IN_BACKGROUND_COLOR: function() {
                        return Kn
                    },
                    TOKEN_CHAT_PREVIEW_MESSAGE_QUOTE_DECORATION_OUT_BACKGROUND_COLOR: function() {
                        return Mn
                    },
                    TOKEN_CHAT_PREVIEW_MESSAGE_QUOTE_DECORATION_RADIUS: function() {
                        return en
                    },
                    TOKEN_CHAT_PREVIEW_MESSAGE_QUOTE_DECORATION_WIDTH: function() {
                        return Fn
                    },
                    TOKEN_CHAT_SCROLL_TO_BOTTOM_ICON_COLOR: function() {
                        return Dn
                    },
                    TOKEN_CHAT_SCROLL_TO_BOTTOM_ICON_SIZE: function() {
                        return cn
                    },
                    TOKEN_CHAT_SCROLL_TO_BOTTOM_NOTIFICATION_SIZE: function() {
                        return on
                    },
                    TOKEN_CHAT_SCROLL_TO_BOTTOM_OUTER_BORDER_OPACITY: function() {
                        return fn
                    },
                    TOKEN_CHAT_SCROLL_TO_BOTTOM_OUTER_BORDER_SIZE: function() {
                        return Gn
                    },
                    TOKEN_CHAT_SCROLL_TO_BOTTOM_SHADOW_BLUR_RADIUS: function() {
                        return Bn
                    },
                    TOKEN_CHAT_SCROLL_TO_BOTTOM_SHADOW_COLOR: function() {
                        return Pn
                    },
                    TOKEN_CHAT_SCROLL_TO_BOTTOM_SHADOW_OPACITY: function() {
                        return Un
                    },
                    TOKEN_CHAT_SCROLL_TO_BOTTOM_SHADOW_VERTICAL_OFFSET: function() {
                        return Hn
                    },
                    TOKEN_CHAT_SCROLL_TO_BOTTOM_SIZE: function() {
                        return pn
                    },
                    TOKEN_CHERRYPICKER_ADD_CONTENT_OPACITY: function() {
                        return xn
                    },
                    TOKEN_CHERRYPICKER_ICON_SHIFT: function() {
                        return Yn
                    },
                    TOKEN_CHERRYPICKER_ICON_SIZE: function() {
                        return Vn
                    },
                    TOKEN_CHIP_BASE_BACKGROUND_COLOR: function() {
                        return Wn
                    },
                    TOKEN_CHIP_BASE_TEXT_COLOR: function() {
                        return Zn
                    },
                    TOKEN_CHIP_BORDER_RADIUS: function() {
                        return Xn
                    },
                    TOKEN_CHIP_DISABLED_BACKGROUND_COLOR: function() {
                        return sn
                    },
                    TOKEN_CHIP_DISABLED_TEXT_COLOR: function() {
                        return an
                    },
                    TOKEN_CHIP_HEIGHT: function() {
                        return ln
                    },
                    TOKEN_CHIP_MEDIUM_BORDER_RADIUS_ROUNDED: function() {
                        return dn
                    },
                    TOKEN_CHIP_MEDIUM_BORDER_RADIUS_SQUARED: function() {
                        return bn
                    },
                    TOKEN_CHIP_MEDIUM_FONT_SIZE: function() {
                        return mn
                    },
                    TOKEN_CHIP_MEDIUM_HEIGHT: function() {
                        return yn
                    },
                    TOKEN_CHIP_MEDIUM_ICON_SIZE: function() {
                        return wn
                    },
                    TOKEN_CHIP_MEDIUM_PADDING_HORIZONTAL_ICON: function() {
                        return gn
                    },
                    TOKEN_CHIP_MEDIUM_PADDING_HORIZONTAL_TEXT: function() {
                        return Qn
                    },
                    TOKEN_CHIP_MEDIUM_SPACING_ICON_TEXT: function() {
                        return hn
                    },
                    TOKEN_CHIP_MINI_BORDER_RADIUS_ROUNDED: function() {
                        return Jn
                    },
                    TOKEN_CHIP_MINI_BORDER_RADIUS_SQUARED: function() {
                        return kn
                    },
                    TOKEN_CHIP_MINI_FONT_SIZE: function() {
                        return vn
                    },
                    TOKEN_CHIP_MINI_HEIGHT: function() {
                        return jn
                    },
                    TOKEN_CHIP_MINI_PADDING_HORIZONTAL: function() {
                        return qn
                    },
                    TOKEN_CHIP_SELECTED_BACKGROUND_COLOR: function() {
                        return zn
                    },
                    TOKEN_CHIP_SELECTED_TEXT_COLOR: function() {
                        return $n
                    },
                    TOKEN_CHIP_SMALL_BORDER_RADIUS_ROUNDED: function() {
                        return _N
                    },
                    TOKEN_CHIP_SMALL_BORDER_RADIUS_SQUARED: function() {
                        return ON
                    },
                    TOKEN_CHIP_SMALL_FONT_SIZE: function() {
                        return TN
                    },
                    TOKEN_CHIP_SMALL_HEIGHT: function() {
                        return EN
                    },
                    TOKEN_CHIP_SMALL_ICON_SIZE: function() {
                        return nN
                    },
                    TOKEN_CHIP_SMALL_PADDING_HORIZONTAL_ICON: function() {
                        return NN
                    },
                    TOKEN_CHIP_SMALL_PADDING_HORIZONTAL_TEXT: function() {
                        return CN
                    },
                    TOKEN_CHIP_SMALL_SPACING_ICON_TEXT: function() {
                        return AN
                    },
                    TOKEN_COLOR_BLACK: function() {
                        return SN
                    },
                    TOKEN_COLOR_ERROR: function() {
                        return RN
                    },
                    TOKEN_COLOR_FEATURE_ATTENTION_BOOST: function() {
                        return IN
                    },
                    TOKEN_COLOR_FEATURE_BILLING: function() {
                        return tN
                    },
                    TOKEN_COLOR_FEATURE_BOOST: function() {
                        return uN
                    },
                    TOKEN_COLOR_FEATURE_BUMP: function() {
                        return rN
                    },
                    TOKEN_COLOR_FEATURE_BUNDLE_SALE: function() {
                        return LN
                    },
                    TOKEN_COLOR_FEATURE_CHAT_QUOTA: function() {
                        return KN
                    },
                    TOKEN_COLOR_FEATURE_CHAT_WITH_NEWBIES: function() {
                        return MN
                    },
                    TOKEN_COLOR_FEATURE_CHAT_WITH_TIRED: function() {
                        return eN
                    },
                    TOKEN_COLOR_FEATURE_CRITERIA: function() {
                        return FN
                    },
                    TOKEN_COLOR_FEATURE_CRUSH: function() {
                        return DN
                    },
                    TOKEN_COLOR_FEATURE_DEFAULT: function() {
                        return iN
                    },
                    TOKEN_COLOR_FEATURE_DEFAULT_LIGHT: function() {
                        return cN
                    },
                    TOKEN_COLOR_FEATURE_EXTRA_SHOWS: function() {
                        return oN
                    },
                    TOKEN_COLOR_FEATURE_FAVOURITES: function() {
                        return fN
                    },
                    TOKEN_COLOR_FEATURE_ICEBREAKER: function() {
                        return GN
                    },
                    TOKEN_COLOR_FEATURE_INVISIBLE_MODE: function() {
                        return BN
                    },
                    TOKEN_COLOR_FEATURE_LIKED_YOU: function() {
                        return PN
                    },
                    TOKEN_COLOR_FEATURE_LIKED_YOU_DARK: function() {
                        return UN
                    },
                    TOKEN_COLOR_FEATURE_LIVE: function() {
                        return HN
                    },
                    TOKEN_COLOR_FEATURE_NEVER_LOOSE_ACCOUNT: function() {
                        return pN
                    },
                    TOKEN_COLOR_FEATURE_PREMIUM: function() {
                        return xN
                    },
                    TOKEN_COLOR_FEATURE_PREMIUM_ALT_GRADIENT_START: function() {
                        return YN
                    },
                    TOKEN_COLOR_FEATURE_PREMIUM_ALT_GRADIENT_STOP: function() {
                        return VN
                    },
                    TOKEN_COLOR_FEATURE_PREMIUM_GRADIENT_START: function() {
                        return WN
                    },
                    TOKEN_COLOR_FEATURE_PREMIUM_GRADIENT_STOP: function() {
                        return ZN
                    },
                    TOKEN_COLOR_FEATURE_PREMIUM_LIGHT: function() {
                        return XN
                    },
                    TOKEN_COLOR_FEATURE_PREMIUM_PLUS: function() {
                        return sN
                    },
                    TOKEN_COLOR_FEATURE_PREMIUM_PLUS_ALT: function() {
                        return aN
                    },
                    TOKEN_COLOR_FEATURE_PREMIUM_PLUS_ALT_GRADIENT_START: function() {
                        return lN
                    },
                    TOKEN_COLOR_FEATURE_PREMIUM_PLUS_ALT_GRADIENT_STOP: function() {
                        return dN
                    },
                    TOKEN_COLOR_FEATURE_PREMIUM_PLUS_GRADIENT_START: function() {
                        return bN
                    },
                    TOKEN_COLOR_FEATURE_PREMIUM_PLUS_GRADIENT_STOP: function() {
                        return mN
                    },
                    TOKEN_COLOR_FEATURE_QUESTIONS_GAME: function() {
                        return yN
                    },
                    TOKEN_COLOR_FEATURE_QUESTIONS_GAME_DARK: function() {
                        return wN
                    },
                    TOKEN_COLOR_FEATURE_READ_RECEIPT: function() {
                        return gN
                    },
                    TOKEN_COLOR_FEATURE_REVENUE: function() {
                        return QN
                    },
                    TOKEN_COLOR_FEATURE_REVENUE_ALT: function() {
                        return hN
                    },
                    TOKEN_COLOR_FEATURE_REVENUE_LIGHT: function() {
                        return JN
                    },
                    TOKEN_COLOR_FEATURE_RISEUP: function() {
                        return kN
                    },
                    TOKEN_COLOR_FEATURE_SPECIAL_DELIVERY: function() {
                        return vN
                    },
                    TOKEN_COLOR_FEATURE_SPOTLIGHT: function() {
                        return jN
                    },
                    TOKEN_COLOR_FEATURE_UNDO: function() {
                        return qN
                    },
                    TOKEN_COLOR_FEATURE_VERIFICATION: function() {
                        return zN
                    },
                    TOKEN_COLOR_GENERIC_BLUE: function() {
                        return $N
                    },
                    TOKEN_COLOR_GENERIC_CORAL: function() {
                        return _C
                    },
                    TOKEN_COLOR_GENERIC_GREEN: function() {
                        return OC
                    },
                    TOKEN_COLOR_GENERIC_GREEN_DARK: function() {
                        return TC
                    },
                    TOKEN_COLOR_GENERIC_ORANGE: function() {
                        return EC
                    },
                    TOKEN_COLOR_GENERIC_PINK: function() {
                        return nC
                    },
                    TOKEN_COLOR_GENERIC_PINK_LIGHT: function() {
                        return NC
                    },
                    TOKEN_COLOR_GENERIC_PURPLE: function() {
                        return CC
                    },
                    TOKEN_COLOR_GENERIC_RED: function() {
                        return AC
                    },
                    TOKEN_COLOR_GENERIC_YELLOW: function() {
                        return SC
                    },
                    TOKEN_COLOR_GENERIC_YELLOW_DARK: function() {
                        return RC
                    },
                    TOKEN_COLOR_GRAY: function() {
                        return IC
                    },
                    TOKEN_COLOR_GRAY_10: function() {
                        return tC
                    },
                    TOKEN_COLOR_GRAY_20: function() {
                        return uC
                    },
                    TOKEN_COLOR_GRAY_30: function() {
                        return rC
                    },
                    TOKEN_COLOR_GRAY_50: function() {
                        return LC
                    },
                    TOKEN_COLOR_GRAY_80: function() {
                        return KC
                    },
                    TOKEN_COLOR_GRAY_DARK: function() {
                        return MC
                    },
                    TOKEN_COLOR_GRAY_LIGHT: function() {
                        return eC
                    },
                    TOKEN_COLOR_NOTIFICATION: function() {
                        return FC
                    },
                    TOKEN_COLOR_POPULARITY_AVERAGE: function() {
                        return DC
                    },
                    TOKEN_COLOR_POPULARITY_HIGH: function() {
                        return iC
                    },
                    TOKEN_COLOR_POPULARITY_LOW: function() {
                        return cC
                    },
                    TOKEN_COLOR_POPULARITY_VERYHIGH: function() {
                        return oC
                    },
                    TOKEN_COLOR_POPULARITY_VERYLOW: function() {
                        return fC
                    },
                    TOKEN_COLOR_PRIMARY: function() {
                        return GC
                    },
                    TOKEN_COLOR_PRIMARY_DARK: function() {
                        return BC
                    },
                    TOKEN_COLOR_PRIMARY_LIGHT: function() {
                        return PC
                    },
                    TOKEN_COLOR_PRIMARY_LIGHTER: function() {
                        return UC
                    },
                    TOKEN_COLOR_PROVIDER_APPLE: function() {
                        return HC
                    },
                    TOKEN_COLOR_PROVIDER_FACEBOOK: function() {
                        return pC
                    },
                    TOKEN_COLOR_PROVIDER_GOOGLE: function() {
                        return xC
                    },
                    TOKEN_COLOR_PROVIDER_INSTAGRAM: function() {
                        return YC
                    },
                    TOKEN_COLOR_PROVIDER_LINKEDIN: function() {
                        return VC
                    },
                    TOKEN_COLOR_PROVIDER_ODNOKLASSNIKI: function() {
                        return WC
                    },
                    TOKEN_COLOR_PROVIDER_SPOTIFY: function() {
                        return ZC
                    },
                    TOKEN_COLOR_PROVIDER_TWITTER: function() {
                        return XC
                    },
                    TOKEN_COLOR_PROVIDER_VKONTAKTE: function() {
                        return sC
                    },
                    TOKEN_COLOR_SECONDARY: function() {
                        return aC
                    },
                    TOKEN_COLOR_STATUS_ERROR: function() {
                        return lC
                    },
                    TOKEN_COLOR_STATUS_NOTIFICATION: function() {
                        return dC
                    },
                    TOKEN_COLOR_STATUS_POSITIVE: function() {
                        return bC
                    },
                    TOKEN_COLOR_STATUS_POSITIVE_DARK: function() {
                        return mC
                    },
                    TOKEN_COLOR_STATUS_WARNING: function() {
                        return yC
                    },
                    TOKEN_COLOR_STATUS_WARNING_DARK: function() {
                        return wC
                    },
                    TOKEN_COLOR_WHITE: function() {
                        return gC
                    },
                    TOKEN_COSMOS_ACTIONCARD_BORDER_RADIUS: function() {
                        return QC
                    },
                    TOKEN_COSMOS_ACTIONCARD_COLOR_BACKGROUND_BRAND: function() {
                        return hC
                    },
                    TOKEN_COSMOS_ACTIONCARD_COLOR_BACKGROUND_DEFAULT: function() {
                        return JC
                    },
                    TOKEN_COSMOS_ACTIONCARD_COLOR_DESCRIPTION_BRAND: function() {
                        return kC
                    },
                    TOKEN_COSMOS_ACTIONCARD_COLOR_DESCRIPTION_DEFAULT: function() {
                        return vC
                    },
                    TOKEN_COSMOS_ACTIONCARD_COLOR_ICON_BRAND: function() {
                        return jC
                    },
                    TOKEN_COSMOS_ACTIONCARD_COLOR_ICON_DEFAULT: function() {
                        return qC
                    },
                    TOKEN_COSMOS_ACTIONCARD_COLOR_TITLE_BRAND: function() {
                        return zC
                    },
                    TOKEN_COSMOS_ACTIONCARD_COLOR_TITLE_DEFAULT: function() {
                        return $C
                    },
                    TOKEN_COSMOS_ACTIONCARD_SHADOW_BRAND_BLUR: function() {
                        return _A
                    },
                    TOKEN_COSMOS_ACTIONCARD_SHADOW_BRAND_COLOR: function() {
                        return OA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SHADOW_BRAND_SPREAD: function() {
                        return TA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SHADOW_BRAND_X: function() {
                        return EA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SHADOW_BRAND_Y: function() {
                        return nA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SHADOW_DEFAULT_BLUR: function() {
                        return NA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SHADOW_DEFAULT_COLOR: function() {
                        return CA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SHADOW_DEFAULT_SPREAD: function() {
                        return AA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SHADOW_DEFAULT_X: function() {
                        return SA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SHADOW_DEFAULT_Y: function() {
                        return RA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SIZING_ICON_END: function() {
                        return IA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SIZING_ICON_START_LARGE: function() {
                        return tA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SIZING_ICON_START_SMALL: function() {
                        return uA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SPACING_GAP_HORIZONTAL_SMALL: function() {
                        return rA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SPACING_GAP_VERTICAL: function() {
                        return LA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SPACING_HORIZONTAL: function() {
                        return KA
                    },
                    TOKEN_COSMOS_ACTIONCARD_SPACING_VERTICAL: function() {
                        return MA
                    },
                    TOKEN_COSMOS_ACTIONCARD_TYPOGRAPHY_DESCRIPTION: function() {
                        return eA
                    },
                    TOKEN_COSMOS_ACTIONCARD_TYPOGRAPHY_TITLE: function() {
                        return FA
                    },
                    TOKEN_COSMOS_ACTIONCELL_BORDER_RADIUS: function() {
                        return DA
                    },
                    TOKEN_COSMOS_ACTIONCELL_COLOR_BACKGROUND_DEFAULT: function() {
                        return iA
                    },
                    TOKEN_COSMOS_ACTIONCELL_COLOR_BACKGROUND_ERROR: function() {
                        return cA
                    },
                    TOKEN_COSMOS_ACTIONCELL_COLOR_BACKGROUND_OVERLAY_HOVER: function() {
                        return oA
                    },
                    TOKEN_COSMOS_ACTIONCELL_COLOR_BACKGROUND_OVERLAY_PRESSED: function() {
                        return fA
                    },
                    TOKEN_COSMOS_ACTIONCELL_COLOR_BACKGROUND_SELECTED: function() {
                        return GA
                    },
                    TOKEN_COSMOS_ACTIONCELL_COLOR_CONTENT_DEFAULT: function() {
                        return BA
                    },
                    TOKEN_COSMOS_ACTIONCELL_COLOR_CONTENT_ERROR: function() {
                        return PA
                    },
                    TOKEN_COSMOS_ACTIONCELL_COLOR_CONTENT_SELECTED: function() {
                        return UA
                    },
                    TOKEN_COSMOS_ACTIONCELL_COLOR_ICON: function() {
                        return HA
                    },
                    TOKEN_COSMOS_ACTIONCELL_SIZING_EMOJI: function() {
                        return pA
                    },
                    TOKEN_COSMOS_ACTIONCELL_SIZING_ICON: function() {
                        return xA
                    },
                    TOKEN_COSMOS_ACTIONCELL_SPACING_GAP: function() {
                        return YA
                    },
                    TOKEN_COSMOS_ACTIONCELL_SPACING_HORIZONTAL: function() {
                        return VA
                    },
                    TOKEN_COSMOS_ACTIONCELL_SPACING_VERTICAL: function() {
                        return WA
                    },
                    TOKEN_COSMOS_ACTIONCELL_TYPOGRAPHY_CONTENT: function() {
                        return ZA
                    },
                    TOKEN_COSMOS_ACTIONROW_COLOR_BACKGROUND_OVERLAY_HOVER: function() {
                        return XA
                    },
                    TOKEN_COSMOS_ACTIONROW_COLOR_BACKGROUND_RESTING: function() {
                        return sA
                    },
                    TOKEN_COSMOS_ACTIONROW_COLOR_CHEVRON: function() {
                        return aA
                    },
                    TOKEN_COSMOS_ACTIONROW_COLOR_DESCRIPTION: function() {
                        return lA
                    },
                    TOKEN_COSMOS_ACTIONROW_COLOR_ICON_END: function() {
                        return dA
                    },
                    TOKEN_COSMOS_ACTIONROW_COLOR_ICON_LEFT: function() {
                        return bA
                    },
                    TOKEN_COSMOS_ACTIONROW_COLOR_LABEL: function() {
                        return mA
                    },
                    TOKEN_COSMOS_ACTIONROW_COLOR_TITLE: function() {
                        return yA
                    },
                    TOKEN_COSMOS_ACTIONROW_SIZING_CHEVRON: function() {
                        return wA
                    },
                    TOKEN_COSMOS_ACTIONROW_SIZING_ICON_END: function() {
                        return gA
                    },
                    TOKEN_COSMOS_ACTIONROW_SIZING_ICON_START: function() {
                        return QA
                    },
                    TOKEN_COSMOS_ACTIONROW_SPACING_GAP_HORIZONTAL_MEDIUM: function() {
                        return hA
                    },
                    TOKEN_COSMOS_ACTIONROW_SPACING_GAP_HORIZONTAL_SMALL: function() {
                        return JA
                    },
                    TOKEN_COSMOS_ACTIONROW_SPACING_GAP_HORIZONTAL_XSMALL: function() {
                        return kA
                    },
                    TOKEN_COSMOS_ACTIONROW_SPACING_GAP_VERTICAL: function() {
                        return vA
                    },
                    TOKEN_COSMOS_ACTIONROW_SPACING_HORIZONTAL: function() {
                        return jA
                    },
                    TOKEN_COSMOS_ACTIONROW_SPACING_VERTICAL: function() {
                        return qA
                    },
                    TOKEN_COSMOS_ACTIONROW_TYPOGRAPHY_DESCRIPTION: function() {
                        return zA
                    },
                    TOKEN_COSMOS_ACTIONROW_TYPOGRAPHY_LABEL: function() {
                        return $A
                    },
                    TOKEN_COSMOS_ACTIONROW_TYPOGRAPHY_TITLE_LARGE: function() {
                        return _S
                    },
                    TOKEN_COSMOS_ACTIONROW_TYPOGRAPHY_TITLE_SMALL: function() {
                        return OS
                    },
                    TOKEN_COSMOS_ACTIONSHEET_BORDER_RADIUS_ROUNDED: function() {
                        return TS
                    },
                    TOKEN_COSMOS_ACTIONSHEET_BORDER_RADIUS_SQUARED: function() {
                        return ES
                    },
                    TOKEN_COSMOS_ACTIONSHEET_COLOR_BACKGROUND_CONTAINER: function() {
                        return nS
                    },
                    TOKEN_COSMOS_ACTIONSHEET_COLOR_BACKGROUND_OVERLAY: function() {
                        return NS
                    },
                    TOKEN_COSMOS_ACTIONSHEET_COLOR_ICON: function() {
                        return CS
                    },
                    TOKEN_COSMOS_ACTIONSHEET_SIZING_ICON: function() {
                        return AS
                    },
                    TOKEN_COSMOS_ACTIONSHEET_SPACING_GAP: function() {
                        return SS
                    },
                    TOKEN_COSMOS_ACTIONSHEET_SPACING_HORIZONTAL: function() {
                        return RS
                    },
                    TOKEN_COSMOS_ACTIONSHEET_SPACING_VERTICAL: function() {
                        return IS
                    },
                    TOKEN_COSMOS_BADGE_BORDER_RADIUS: function() {
                        return tS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_BLACK: function() {
                        return uS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_BLACK_TRANSPARENCY: function() {
                        return rS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_CHAT: function() {
                        return LS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_DEFAULT: function() {
                        return KS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_LIKED_YOU: function() {
                        return MS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_LIKED_YOU_TRANSPARENCY: function() {
                        return eS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_OVERLAY_HOVER: function() {
                        return FS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_OVERLAY_PRESSED: function() {
                        return DS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_PREMIUM_ALT: function() {
                        return iS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_PREMIUM_PLUS: function() {
                        return cS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_SELECTED: function() {
                        return oS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_TRANSPARENT: function() {
                        return fS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_WHITE: function() {
                        return GS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_WHITE_TRANSPARENCY_BLACK_FOREGROUND: function() {
                        return BS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_BACKGROUND_WHITE_TRANSPARENCY_WHITE_FOREGROUND: function() {
                        return PS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_CONTENT_BLACK: function() {
                        return US
                    },
                    TOKEN_COSMOS_BADGE_COLOR_CONTENT_BLACK_TRANSPARENCY: function() {
                        return HS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_CONTENT_CHAT: function() {
                        return pS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_CONTENT_DEFAULT: function() {
                        return xS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_CONTENT_LIKED_YOU: function() {
                        return YS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_CONTENT_LIKED_YOU_TRANSPARENCY: function() {
                        return VS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_CONTENT_PREMIUM_ALT: function() {
                        return WS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_CONTENT_PREMIUM_PLUS: function() {
                        return ZS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_CONTENT_SELECTED: function() {
                        return XS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_CONTENT_TRANSPARENT: function() {
                        return sS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_CONTENT_WHITE: function() {
                        return aS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_CONTENT_WHITE_TRANSPARENCY_BLACK_FOREGROUND: function() {
                        return lS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_CONTENT_WHITE_TRANSPARENCY_WHITE_FOREGROUND: function() {
                        return dS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_ICON_BLACK: function() {
                        return bS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_ICON_BLACK_TRANSPARENCY: function() {
                        return mS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_ICON_CHAT: function() {
                        return yS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_ICON_DEFAULT: function() {
                        return wS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_ICON_LIKED_YOU: function() {
                        return gS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_ICON_LIKED_YOU_TRANSPARENCY: function() {
                        return QS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_ICON_PREMIUM_ALT: function() {
                        return hS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_ICON_PREMIUM_PLUS: function() {
                        return JS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_ICON_SELECTED: function() {
                        return kS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_ICON_TRANSPARENT: function() {
                        return vS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_ICON_WHITE: function() {
                        return jS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_ICON_WHITE_TRANSPARENCY_BLACK_FOREGROUND: function() {
                        return qS
                    },
                    TOKEN_COSMOS_BADGE_COLOR_ICON_WHITE_TRANSPARENCY_WHITE_FOREGROUND: function() {
                        return zS
                    },
                    TOKEN_COSMOS_BADGE_SIZING_EMOJI_MINI: function() {
                        return $S
                    },
                    TOKEN_COSMOS_BADGE_SIZING_EMOJI_SMALL: function() {
                        return _R
                    },
                    TOKEN_COSMOS_BADGE_SIZING_ICON_MINI: function() {
                        return OR
                    },
                    TOKEN_COSMOS_BADGE_SIZING_ICON_SMALL: function() {
                        return TR
                    },
                    TOKEN_COSMOS_BADGE_SPACING_GAP_MINI: function() {
                        return ER
                    },
                    TOKEN_COSMOS_BADGE_SPACING_GAP_SMALL: function() {
                        return nR
                    },
                    TOKEN_COSMOS_BADGE_SPACING_HORIZONTAL_MINI: function() {
                        return NR
                    },
                    TOKEN_COSMOS_BADGE_SPACING_HORIZONTAL_SMALL: function() {
                        return CR
                    },
                    TOKEN_COSMOS_BADGE_SPACING_VERTICAL_MINI: function() {
                        return AR
                    },
                    TOKEN_COSMOS_BADGE_SPACING_VERTICAL_SMALL: function() {
                        return SR
                    },
                    TOKEN_COSMOS_BADGE_TYPOGRAPHY_MINI: function() {
                        return RR
                    },
                    TOKEN_COSMOS_BADGE_TYPOGRAPHY_SMALL: function() {
                        return IR
                    },
                    TOKEN_COSMOS_BUBBLE_COLOR_BACKGROUND_GRAY: function() {
                        return tR
                    },
                    TOKEN_COSMOS_BUBBLE_COLOR_BACKGROUND_PRIMARY: function() {
                        return uR
                    },
                    TOKEN_COSMOS_BUBBLE_COLOR_BACKGROUND_QUESTION: function() {
                        return rR
                    },
                    TOKEN_COSMOS_BUBBLE_COLOR_BACKGROUND_WHITE: function() {
                        return LR
                    },
                    TOKEN_COSMOS_BUBBLE_COLOR_CONTENT: function() {
                        return KR
                    },
                    TOKEN_COSMOS_BUTTONGROUP_SPACING_GAP_VERTICAL: function() {
                        return MR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_RADIUS_MEDIUM: function() {
                        return eR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_RADIUS_MICRO: function() {
                        return FR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_RADIUS_MINI: function() {
                        return DR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_RADIUS_SMALL: function() {
                        return iR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_PRIMARY_BRAND: function() {
                        return cR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_PRIMARY_DEFAULT: function() {
                        return oR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_PRIMARY_DESTRUCTIVE: function() {
                        return fR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_PRIMARY_ERROR: function() {
                        return GR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_PRIMARY_INVERSE: function() {
                        return BR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_PRIMARY_REVENUE: function() {
                        return PR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_SECONDARY_BRAND: function() {
                        return UR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_SECONDARY_DEFAULT: function() {
                        return HR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_SECONDARY_DESTRUCTIVE: function() {
                        return pR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_SECONDARY_ERROR: function() {
                        return xR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_SECONDARY_INVERSE: function() {
                        return YR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_SECONDARY_REVENUE: function() {
                        return VR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_TERTIARY_BRAND: function() {
                        return WR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_TERTIARY_DEFAULT: function() {
                        return ZR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_TERTIARY_DESTRUCTIVE: function() {
                        return XR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_TERTIARY_ERROR: function() {
                        return sR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_TERTIARY_INVERSE: function() {
                        return aR
                    },
                    TOKEN_COSMOS_BUTTON_BORDER_WIDTH_TERTIARY_REVENUE: function() {
                        return lR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_OVERLAY_DEFAULT_HOVER: function() {
                        return dR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_OVERLAY_DEFAULT_PRESSED: function() {
                        return bR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_OVERLAY_HOVER: function() {
                        return mR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_OVERLAY_INVERSE_HOVER: function() {
                        return yR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_OVERLAY_INVERSE_PRESSED: function() {
                        return wR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_OVERLAY_PRESSED: function() {
                        return gR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_APPLE: function() {
                        return QR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_BRAND: function() {
                        return hR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_DEFAULT: function() {
                        return JR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_DESTRUCTIVE: function() {
                        return kR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_ERROR: function() {
                        return vR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_FACEBOOK: function() {
                        return jR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_GOOGLE: function() {
                        return qR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_INSTAGRAM: function() {
                        return zR
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_INVERSE: function() {
                        return $R
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_LINKEDIN: function() {
                        return _I
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_ODNOKLASSNIKI: function() {
                        return OI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_REVENUE: function() {
                        return TI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_SPOTIFY: function() {
                        return EI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_TWITTER: function() {
                        return nI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_PRIMARY_VKONTAKTE: function() {
                        return NI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_SECONDARY_BRAND: function() {
                        return CI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_SECONDARY_DEFAULT: function() {
                        return AI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_SECONDARY_DESTRUCTIVE: function() {
                        return SI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_SECONDARY_ERROR: function() {
                        return RI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_SECONDARY_INVERSE: function() {
                        return II
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_SECONDARY_REVENUE: function() {
                        return tI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_TERTIARY_BRAND: function() {
                        return uI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_TERTIARY_DEFAULT: function() {
                        return rI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_TERTIARY_DESTRUCTIVE: function() {
                        return LI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_TERTIARY_ERROR: function() {
                        return KI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_TERTIARY_INVERSE: function() {
                        return MI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BACKGROUND_TERTIARY_REVENUE: function() {
                        return eI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_APPLE: function() {
                        return FI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_BRAND: function() {
                        return DI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_DEFAULT: function() {
                        return iI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_DESTRUCTIVE: function() {
                        return cI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_ERROR: function() {
                        return oI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_FACEBOOK: function() {
                        return fI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_GOOGLE: function() {
                        return GI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_INSTAGRAM: function() {
                        return BI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_INVERSE: function() {
                        return PI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_LINKEDIN: function() {
                        return UI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_ODNOKLASSNIKI: function() {
                        return HI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_REVENUE: function() {
                        return pI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_SPOTIFY: function() {
                        return xI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_TWITTER: function() {
                        return YI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_PRIMARY_VKONTAKTE: function() {
                        return VI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_SECONDARY_BRAND: function() {
                        return WI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_SECONDARY_DEFAULT: function() {
                        return ZI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_SECONDARY_DESTRUCTIVE: function() {
                        return XI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_SECONDARY_ERROR: function() {
                        return sI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_SECONDARY_INVERSE: function() {
                        return aI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_SECONDARY_REVENUE: function() {
                        return lI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_TERTIARY_BRAND: function() {
                        return dI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_TERTIARY_DEFAULT: function() {
                        return bI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_TERTIARY_DESTRUCTIVE: function() {
                        return mI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_TERTIARY_ERROR: function() {
                        return yI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_TERTIARY_INVERSE: function() {
                        return wI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_BORDER_TERTIARY_REVENUE: function() {
                        return gI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_APPLE: function() {
                        return QI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_BRAND: function() {
                        return hI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_DEFAULT: function() {
                        return JI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_DESTRUCTIVE: function() {
                        return kI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_ERROR: function() {
                        return vI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_FACEBOOK: function() {
                        return jI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_GOOGLE: function() {
                        return qI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_INSTAGRAM: function() {
                        return zI
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_INVERSE: function() {
                        return $I
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_LINKEDIN: function() {
                        return _t
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_ODNOKLASSNIKI: function() {
                        return Ot
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_REVENUE: function() {
                        return Tt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_SPOTIFY: function() {
                        return Et
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_TWITTER: function() {
                        return nt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_PRIMARY_VKONTAKTE: function() {
                        return Nt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_SECONDARY_BRAND: function() {
                        return Ct
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_SECONDARY_DEFAULT: function() {
                        return At
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_SECONDARY_DESTRUCTIVE: function() {
                        return St
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_SECONDARY_ERROR: function() {
                        return Rt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_SECONDARY_INVERSE: function() {
                        return It
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_SECONDARY_REVENUE: function() {
                        return tt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_TERTIARY_BRAND: function() {
                        return ut
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_TERTIARY_DEFAULT: function() {
                        return rt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_TERTIARY_DESTRUCTIVE: function() {
                        return Lt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_TERTIARY_ERROR: function() {
                        return Kt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_TERTIARY_INVERSE: function() {
                        return Mt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_CONTENT_TERTIARY_REVENUE: function() {
                        return et
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_APPLE: function() {
                        return Ft
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_BRAND: function() {
                        return Dt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_DEFAULT: function() {
                        return it
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_DESTRUCTIVE: function() {
                        return ct
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_ERROR: function() {
                        return ot
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_FACEBOOK: function() {
                        return ft
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_GOOGLE: function() {
                        return Gt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_INSTAGRAM: function() {
                        return Bt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_INVERSE: function() {
                        return Pt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_LINKEDIN: function() {
                        return Ut
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_ODNOKLASSNIKI: function() {
                        return Ht
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_REVENUE: function() {
                        return pt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_SPOTIFY: function() {
                        return xt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_TWITTER: function() {
                        return Yt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_PRIMARY_VKONTAKTE: function() {
                        return Vt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_SECONDARY_BRAND: function() {
                        return Wt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_SECONDARY_DEFAULT: function() {
                        return Zt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_SECONDARY_DESTRUCTIVE: function() {
                        return Xt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_SECONDARY_ERROR: function() {
                        return st
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_SECONDARY_INVERSE: function() {
                        return at
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_SECONDARY_REVENUE: function() {
                        return lt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_TERTIARY_BRAND: function() {
                        return dt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_TERTIARY_DEFAULT: function() {
                        return bt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_TERTIARY_DESTRUCTIVE: function() {
                        return mt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_TERTIARY_ERROR: function() {
                        return yt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_TERTIARY_INVERSE: function() {
                        return wt
                    },
                    TOKEN_COSMOS_BUTTON_COLOR_ICON_TERTIARY_REVENUE: function() {
                        return gt
                    },
                    TOKEN_COSMOS_BUTTON_SIZING_ICON_MEDIUM: function() {
                        return Qt
                    },
                    TOKEN_COSMOS_BUTTON_SIZING_ICON_MICRO: function() {
                        return ht
                    },
                    TOKEN_COSMOS_BUTTON_SIZING_ICON_MINI: function() {
                        return Jt
                    },
                    TOKEN_COSMOS_BUTTON_SIZING_ICON_SMALL: function() {
                        return kt
                    },
                    TOKEN_COSMOS_BUTTON_SIZING_LOADER_MEDIUM: function() {
                        return vt
                    },
                    TOKEN_COSMOS_BUTTON_SIZING_LOADER_MICRO: function() {
                        return jt
                    },
                    TOKEN_COSMOS_BUTTON_SIZING_LOADER_MINI: function() {
                        return qt
                    },
                    TOKEN_COSMOS_BUTTON_SIZING_LOADER_SMALL: function() {
                        return zt
                    },
                    TOKEN_COSMOS_BUTTON_SIZING_MAX_WIDTH: function() {
                        return $t
                    },
                    TOKEN_COSMOS_BUTTON_SIZING_MIN_HEIGHT_MEDIUM: function() {
                        return _u
                    },
                    TOKEN_COSMOS_BUTTON_SIZING_MIN_HEIGHT_MICRO: function() {
                        return Ou
                    },
                    TOKEN_COSMOS_BUTTON_SIZING_MIN_HEIGHT_MINI: function() {
                        return Tu
                    },
                    TOKEN_COSMOS_BUTTON_SIZING_MIN_HEIGHT_SMALL: function() {
                        return Eu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_GAP_MEDIUM: function() {
                        return nu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_GAP_MICRO: function() {
                        return Nu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_GAP_MINI: function() {
                        return Cu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_GAP_SMALL: function() {
                        return Au
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_HORIZONTAL_MEDIUM: function() {
                        return Su
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_HORIZONTAL_MICRO: function() {
                        return Ru
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_HORIZONTAL_MINI: function() {
                        return Iu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_HORIZONTAL_SMALL: function() {
                        return tu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_MEDIUM_GAP: function() {
                        return uu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_MEDIUM_HORIZONTAL: function() {
                        return ru
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_MEDIUM_VERTICAL: function() {
                        return Lu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_MICRO_GAP: function() {
                        return Ku
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_MICRO_HORIZONTAL: function() {
                        return Mu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_MICRO_VERTICAL: function() {
                        return eu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_MINI_GAP: function() {
                        return Fu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_MINI_HORIZONTAL: function() {
                        return Du
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_MINI_VERTICAL: function() {
                        return iu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_SMALL_GAP: function() {
                        return cu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_SMALL_HORIZONTAL: function() {
                        return ou
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_SMALL_VERTICAL: function() {
                        return fu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_VERTICAL_MEDIUM: function() {
                        return Gu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_VERTICAL_MICRO: function() {
                        return Bu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_VERTICAL_MINI: function() {
                        return Pu
                    },
                    TOKEN_COSMOS_BUTTON_SPACING_VERTICAL_SMALL: function() {
                        return Uu
                    },
                    TOKEN_COSMOS_BUTTON_TYPOGRAPHY_MEDIUM: function() {
                        return Hu
                    },
                    TOKEN_COSMOS_BUTTON_TYPOGRAPHY_MICRO: function() {
                        return pu
                    },
                    TOKEN_COSMOS_BUTTON_TYPOGRAPHY_MINI: function() {
                        return xu
                    },
                    TOKEN_COSMOS_BUTTON_TYPOGRAPHY_SMALL: function() {
                        return Yu
                    },
                    TOKEN_COSMOS_CHECKBOX_BORDER_RADIUS: function() {
                        return Vu
                    },
                    TOKEN_COSMOS_CHECKBOX_BORDER_WIDTH_ERROR: function() {
                        return Wu
                    },
                    TOKEN_COSMOS_CHECKBOX_BORDER_WIDTH_SELECTED: function() {
                        return Zu
                    },
                    TOKEN_COSMOS_CHECKBOX_BORDER_WIDTH_UNSELECTED: function() {
                        return Xu
                    },
                    TOKEN_COSMOS_CHECKBOX_COLOR_BACKGROUND_ERROR: function() {
                        return su
                    },
                    TOKEN_COSMOS_CHECKBOX_COLOR_BACKGROUND_SELECTED: function() {
                        return au
                    },
                    TOKEN_COSMOS_CHECKBOX_COLOR_BACKGROUND_UNSELECTED: function() {
                        return lu
                    },
                    TOKEN_COSMOS_CHECKBOX_COLOR_BORDER_ERROR: function() {
                        return du
                    },
                    TOKEN_COSMOS_CHECKBOX_COLOR_BORDER_SELECTED: function() {
                        return bu
                    },
                    TOKEN_COSMOS_CHECKBOX_COLOR_BORDER_UNSELECTED: function() {
                        return mu
                    },
                    TOKEN_COSMOS_CHECKBOX_COLOR_ICON_ERROR: function() {
                        return yu
                    },
                    TOKEN_COSMOS_CHECKBOX_COLOR_ICON_SELECTED: function() {
                        return wu
                    },
                    TOKEN_COSMOS_CHECKBOX_COLOR_ICON_UNSELECTED: function() {
                        return gu
                    },
                    TOKEN_COSMOS_CHECKBOX_SIZING: function() {
                        return Qu
                    },
                    TOKEN_COSMOS_CTABOX_COLOR_DESCRIPTION: function() {
                        return hu
                    },
                    TOKEN_COSMOS_CTABOX_COLOR_ICON: function() {
                        return Ju
                    },
                    TOKEN_COSMOS_CTABOX_COLOR_TITLE: function() {
                        return ku
                    },
                    TOKEN_COSMOS_CTABOX_SIZING_BADGE: function() {
                        return vu
                    },
                    TOKEN_COSMOS_CTABOX_SIZING_BRICK: function() {
                        return ju
                    },
                    TOKEN_COSMOS_CTABOX_SIZING_ICON: function() {
                        return qu
                    },
                    TOKEN_COSMOS_CTABOX_SIZING_ILLUSTRATION: function() {
                        return zu
                    },
                    TOKEN_COSMOS_CTABOX_SPACING_GAP_LARGE: function() {
                        return $u
                    },
                    TOKEN_COSMOS_CTABOX_SPACING_GAP_MEDIUM: function() {
                        return _r
                    },
                    TOKEN_COSMOS_CTABOX_SPACING_GAP_SMALL: function() {
                        return Or
                    },
                    TOKEN_COSMOS_CTABOX_SPACING_GAP_XLARGE: function() {
                        return Tr
                    },
                    TOKEN_COSMOS_CTABOX_SPACING_GAP_XSMALL: function() {
                        return Er
                    },
                    TOKEN_COSMOS_CTABOX_TYPOGRAPHY_DESCRIPTION: function() {
                        return nr
                    },
                    TOKEN_COSMOS_CTABOX_TYPOGRAPHY_TITLE_COMPACT: function() {
                        return Nr
                    },
                    TOKEN_COSMOS_CTABOX_TYPOGRAPHY_TITLE_EXTENDED: function() {
                        return Cr
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_BORDER_RADIUS: function() {
                        return Ar
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_BORDER_WIDTH_DEFAULT: function() {
                        return Sr
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_BORDER_WIDTH_NONE: function() {
                        return Rr
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_COLOR_BACKGROUND: function() {
                        return Ir
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_COLOR_BACKGROUND_ERROR: function() {
                        return tr
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_COLOR_BACKGROUND_NOTIFICATIONS: function() {
                        return ur
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_COLOR_BORDER_DEFAULT: function() {
                        return rr
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_COLOR_BORDER_NONE: function() {
                        return Lr
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_COLOR_CONTENT: function() {
                        return Kr
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_COLOR_TEXT_ERROR: function() {
                        return Mr
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_COLOR_TEXT_NOTIFICATION: function() {
                        return er
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_SIZING_CIRCLE: function() {
                        return Fr
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_SPACING_HORIZONTAL: function() {
                        return Dr
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_SPACING_VERTICAL: function() {
                        return ir
                    },
                    TOKEN_COSMOS_DOTCOUNTERNOTIFICATION_TYPOGRAPHY_CONTENT: function() {
                        return cr
                    },
                    TOKEN_COSMOS_FILTERS_SPACING_GAP: function() {
                        return or
                    },
                    TOKEN_COSMOS_FORMS_BORDER_RADIUS_ROUNDED: function() {
                        return fr
                    },
                    TOKEN_COSMOS_FORMS_BORDER_RADIUS_SQUARED: function() {
                        return Gr
                    },
                    TOKEN_COSMOS_FORMS_BORDER_WIDTH_DEFAULT_FOCUSED: function() {
                        return Br
                    },
                    TOKEN_COSMOS_FORMS_BORDER_WIDTH_DEFAULT_RESTING: function() {
                        return Pr
                    },
                    TOKEN_COSMOS_FORMS_BORDER_WIDTH_ERROR_FOCUSED: function() {
                        return Ur
                    },
                    TOKEN_COSMOS_FORMS_BORDER_WIDTH_ERROR_RESTING: function() {
                        return Hr
                    },
                    TOKEN_COSMOS_FORMS_BORDER_WIDTH_SUCCESS_FOCUSED: function() {
                        return pr
                    },
                    TOKEN_COSMOS_FORMS_BORDER_WIDTH_SUCCESS_RESTING: function() {
                        return xr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_BACKGROUND: function() {
                        return Yr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_BAR: function() {
                        return Vr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_BORDER_DEFAULT_FOCUSED: function() {
                        return Wr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_BORDER_DEFAULT_RESTING: function() {
                        return Zr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_BORDER_ERROR_FOCUSED: function() {
                        return Xr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_BORDER_ERROR_RESTING: function() {
                        return sr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_BORDER_SUCCESS_FOCUSED: function() {
                        return ar
                    },
                    TOKEN_COSMOS_FORMS_COLOR_BORDER_SUCCESS_RESTING: function() {
                        return lr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_CONTENT_ACTION: function() {
                        return dr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_CONTENT_HELPER_TEXT_DEFAULT: function() {
                        return br
                    },
                    TOKEN_COSMOS_FORMS_COLOR_CONTENT_HELPER_TEXT_ERROR: function() {
                        return mr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_CONTENT_HELPER_TEXT_SUCCESS: function() {
                        return yr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_CONTENT_LABEL: function() {
                        return wr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_CONTENT_PLACEHOLDER: function() {
                        return gr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_CONTENT_PREFIX: function() {
                        return Qr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_CONTENT_SUFIX: function() {
                        return hr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_ICON_END: function() {
                        return Jr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_ICON_FOREGROUND: function() {
                        return kr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_ICON_START_DEFAULT: function() {
                        return vr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_ICON_START_ERROR: function() {
                        return jr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_ICON_START_SUCCESS: function() {
                        return qr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_ITEM_BACKGROUND_DEFAULT: function() {
                        return zr
                    },
                    TOKEN_COSMOS_FORMS_COLOR_ITEM_BACKGROUND_SELECTED: function() {
                        return $r
                    },
                    TOKEN_COSMOS_FORMS_COLOR_ITEM_CONTENT: function() {
                        return _L
                    },
                    TOKEN_COSMOS_FORMS_COLOR_ITEM_ICON: function() {
                        return OL
                    },
                    TOKEN_COSMOS_FORMS_SIZING_ICON_END: function() {
                        return TL
                    },
                    TOKEN_COSMOS_FORMS_SIZING_ICON_START: function() {
                        return EL
                    },
                    TOKEN_COSMOS_FORMS_SPACING_GAP_HORIZONTAL_MEDIUM: function() {
                        return nL
                    },
                    TOKEN_COSMOS_FORMS_SPACING_GAP_HORIZONTAL_SMALL: function() {
                        return NL
                    },
                    TOKEN_COSMOS_FORMS_SPACING_GAP_VERTICAL_MEDIUM: function() {
                        return CL
                    },
                    TOKEN_COSMOS_FORMS_SPACING_GAP_VERTICAL_SMALL: function() {
                        return AL
                    },
                    TOKEN_COSMOS_FORMS_SPACING_HORIZONTAL_MEDIUM: function() {
                        return SL
                    },
                    TOKEN_COSMOS_FORMS_SPACING_HORIZONTAL_SMALL: function() {
                        return RL
                    },
                    TOKEN_COSMOS_FORMS_SPACING_ITEM_GAP: function() {
                        return IL
                    },
                    TOKEN_COSMOS_FORMS_SPACING_ITEM_HORIZONTAL: function() {
                        return tL
                    },
                    TOKEN_COSMOS_FORMS_SPACING_ITEM_VERTICAL: function() {
                        return uL
                    },
                    TOKEN_COSMOS_FORMS_SPACING_VERTICAL_MEDIUM: function() {
                        return rL
                    },
                    TOKEN_COSMOS_FORMS_SPACING_VERTICAL_SMALL: function() {
                        return LL
                    },
                    TOKEN_COSMOS_FORMS_TYPOGRAPHY_ACTION: function() {
                        return KL
                    },
                    TOKEN_COSMOS_FORMS_TYPOGRAPHY_CONTENT: function() {
                        return ML
                    },
                    TOKEN_COSMOS_FORMS_TYPOGRAPHY_HELPER_TEXT: function() {
                        return eL
                    },
                    TOKEN_COSMOS_FORMS_TYPOGRAPHY_ITEM: function() {
                        return FL
                    },
                    TOKEN_COSMOS_FORMS_TYPOGRAPHY_LABEL: function() {
                        return DL
                    },
                    TOKEN_COSMOS_FORMS_TYPOGRAPHY_PREFIX: function() {
                        return iL
                    },
                    TOKEN_COSMOS_FORMS_TYPOGRAPHY_SUFIX: function() {
                        return cL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_BORDER_RADIUS: function() {
                        return oL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_BACKGROUND: function() {
                        return fL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_ICON_ACCEPT: function() {
                        return GL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_ICON_CHEVRON: function() {
                        return BL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_ICON_DECLINE: function() {
                        return PL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_TEXT: function() {
                        return UL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_TITLE: function() {
                        return HL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_UNDERLAY_END: function() {
                        return pL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_COLOR_UNDERLAY_START: function() {
                        return xL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_SIZING_ICON_CALL: function() {
                        return YL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_SIZING_ICON_CHEVRON: function() {
                        return VL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_HORIZONTAL: function() {
                        return WL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_ITEM_GAP_HORIZONTAL_MEDIUM: function() {
                        return ZL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_ITEM_GAP_HORIZONTAL_SMALL: function() {
                        return XL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_ITEM_GAP_VERTICAL_MEDIUM: function() {
                        return sL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_ITEM_GAP_VERTICAL_SMALL: function() {
                        return aL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_ITEM_HORIZONTAL: function() {
                        return lL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_ITEM_VERTICAL: function() {
                        return dL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_VERTICAL_BOTTOM: function() {
                        return bL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_SPACING_VERTICAL_TOP: function() {
                        return mL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_TYPOGRAPHY_TEXT: function() {
                        return yL
                    },
                    TOKEN_COSMOS_INAPPNOTIFICATION_TYPOGRAPHY_TITLE: function() {
                        return wL
                    },
                    TOKEN_COSMOS_MARK_BORDER_RADIUS: function() {
                        return gL
                    },
                    TOKEN_COSMOS_MARK_BORDER_WIDTH_INVERSE: function() {
                        return QL
                    },
                    TOKEN_COSMOS_MARK_BORDER_WIDTH_TRANSPARENT: function() {
                        return hL
                    },
                    TOKEN_COSMOS_MARK_COLOR_BACKGROUND_INVERSE: function() {
                        return JL
                    },
                    TOKEN_COSMOS_MARK_COLOR_BACKGROUND_LIKED_YOU: function() {
                        return kL
                    },
                    TOKEN_COSMOS_MARK_COLOR_BACKGROUND_NOTIFICATION: function() {
                        return vL
                    },
                    TOKEN_COSMOS_MARK_COLOR_BACKGROUND_PREMIUM_PLUS: function() {
                        return jL
                    },
                    TOKEN_COSMOS_MARK_COLOR_BACKGROUND_WHITE: function() {
                        return qL
                    },
                    TOKEN_COSMOS_MARK_COLOR_BORDER_INVERSE: function() {
                        return zL
                    },
                    TOKEN_COSMOS_MARK_COLOR_BORDER_TRANSPARENT: function() {
                        return $L
                    },
                    TOKEN_COSMOS_MARK_COLOR_ICON_INVERSE: function() {
                        return _K
                    },
                    TOKEN_COSMOS_MARK_COLOR_ICON_LIKED_YOU: function() {
                        return OK
                    },
                    TOKEN_COSMOS_MARK_COLOR_ICON_NOTIFICATION: function() {
                        return TK
                    },
                    TOKEN_COSMOS_MARK_COLOR_ICON_PREMIUM_PLUS: function() {
                        return EK
                    },
                    TOKEN_COSMOS_MARK_COLOR_ICON_WHITE: function() {
                        return nK
                    },
                    TOKEN_COSMOS_MARK_COLOR_TEXT_INVERSE: function() {
                        return NK
                    },
                    TOKEN_COSMOS_MARK_COLOR_TEXT_LIKED_YOU: function() {
                        return CK
                    },
                    TOKEN_COSMOS_MARK_COLOR_TEXT_NOTIFICATION: function() {
                        return AK
                    },
                    TOKEN_COSMOS_MARK_COLOR_TEXT_PREMIUM_PLUS: function() {
                        return SK
                    },
                    TOKEN_COSMOS_MARK_COLOR_TEXT_WHITE: function() {
                        return RK
                    },
                    TOKEN_COSMOS_MARK_SHADOW_BLUR: function() {
                        return IK
                    },
                    TOKEN_COSMOS_MARK_SHADOW_COLOR: function() {
                        return tK
                    },
                    TOKEN_COSMOS_MARK_SHADOW_SPREAD: function() {
                        return uK
                    },
                    TOKEN_COSMOS_MARK_SHADOW_X: function() {
                        return rK
                    },
                    TOKEN_COSMOS_MARK_SHADOW_Y: function() {
                        return LK
                    },
                    TOKEN_COSMOS_MARK_SIZING_ICON: function() {
                        return KK
                    },
                    TOKEN_COSMOS_MARK_SPACING_GAP: function() {
                        return MK
                    },
                    TOKEN_COSMOS_MARK_SPACING_HORIZONTAL: function() {
                        return eK
                    },
                    TOKEN_COSMOS_MARK_SPACING_VERTICAL: function() {
                        return FK
                    },
                    TOKEN_COSMOS_MARK_TYPOGRAPHY_TEXT: function() {
                        return DK
                    },
                    TOKEN_COSMOS_MODAL_BORDER_RADIUS: function() {
                        return iK
                    },
                    TOKEN_COSMOS_MODAL_COLOR_BACKGROUND_CONTAINER: function() {
                        return cK
                    },
                    TOKEN_COSMOS_MODAL_COLOR_BACKGROUND_OVERLAY: function() {
                        return oK
                    },
                    TOKEN_COSMOS_MODAL_SPACING_HORIZONTAL: function() {
                        return fK
                    },
                    TOKEN_COSMOS_MODAL_SPACING_OUTSET: function() {
                        return GK
                    },
                    TOKEN_COSMOS_MODAL_SPACING_VERTICAL: function() {
                        return BK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_COLOR_ACTION_DEFAULT: function() {
                        return PK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_COLOR_ACTION_DISABLED: function() {
                        return UK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_COLOR_BACKGROUND: function() {
                        return HK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_COLOR_DESCRIPTION: function() {
                        return pK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_COLOR_ICON: function() {
                        return xK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_COLOR_SUBHEADING: function() {
                        return YK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_COLOR_TITLE: function() {
                        return VK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_SIZING_ICON: function() {
                        return WK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_SPACING_GAP_HORIZONTAL_LARGE: function() {
                        return ZK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_SPACING_GAP_HORIZONTAL_MEDIUM: function() {
                        return XK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_SPACING_GAP_HORIZONTAL_SMALL: function() {
                        return sK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_SPACING_GAP_HORIZONTAL_XLARGE: function() {
                        return aK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_SPACING_GAP_VERTICAL_SMALL: function() {
                        return lK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_SPACING_HORIZONTAL_MEDIUM: function() {
                        return dK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_SPACING_HORIZONTAL_SMALL: function() {
                        return bK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_SPACING_ICON: function() {
                        return mK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_SPACING_VERTICAL: function() {
                        return yK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_TYPOGRAPHY_ACTION: function() {
                        return wK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_TYPOGRAPHY_DESCRIPTION: function() {
                        return gK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_TYPOGRAPHY_SUBHEADING: function() {
                        return QK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_TYPOGRAPHY_TITLE_PRIMARY: function() {
                        return hK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_TYPOGRAPHY_TITLE_QUATERNARY: function() {
                        return JK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_TYPOGRAPHY_TITLE_SECONDARY: function() {
                        return kK
                    },
                    TOKEN_COSMOS_NAVIGATIONBAR_TYPOGRAPHY_TITLE_TERTIARY: function() {
                        return vK
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_BORDER_WIDTH_DEFAULT_SELECTED: function() {
                        return jK
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_BORDER_WIDTH_DEFAULT_UNSELECTED: function() {
                        return qK
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_BORDER_WIDTH_INVERSE_SELECTED: function() {
                        return zK
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_BORDER_WIDTH_INVERSE_UNSELECTED: function() {
                        return $K
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_COLOR_BACKGROUND_DEFAULT_SELECTED: function() {
                        return _M
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_COLOR_BACKGROUND_DEFAULT_UNSELECTED: function() {
                        return OM
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_COLOR_BACKGROUND_INVERSE_SELECTED: function() {
                        return TM
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_COLOR_BACKGROUND_INVERSE_UNSELECTED: function() {
                        return EM
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_COLOR_BORDER_DEFAULT_SELECTED: function() {
                        return nM
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_COLOR_BORDER_DEFAULT_UNSELECTED: function() {
                        return NM
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_COLOR_BORDER_INVERSE_SELECTED: function() {
                        return CM
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_COLOR_BORDER_INVERSE_UNSELECTED: function() {
                        return AM
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_SIZING_CIRCLE_LARGE: function() {
                        return SM
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_SIZING_CIRCLE_MEDIUM: function() {
                        return RM
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_SIZING_CIRCLE_SMALL: function() {
                        return IM
                    },
                    TOKEN_COSMOS_PAGINATIONDOTS_SPACING_GAP: function() {
                        return tM
                    },
                    TOKEN_COSMOS_PROGRESSBAR_BORDER_RADIUS: function() {
                        return uM
                    },
                    TOKEN_COSMOS_PROGRESSBAR_COLOR_BACKGROUND_DEFAULT: function() {
                        return rM
                    },
                    TOKEN_COSMOS_PROGRESSBAR_COLOR_BACKGROUND_INVERSE: function() {
                        return LM
                    },
                    TOKEN_COSMOS_PROGRESSBAR_COLOR_BAR_DEFAULT: function() {
                        return KM
                    },
                    TOKEN_COSMOS_PROGRESSBAR_COLOR_BAR_INVERSE: function() {
                        return MM
                    },
                    TOKEN_COSMOS_PROGRESSCIRCLE_BORDER_RADIUS: function() {
                        return eM
                    },
                    TOKEN_COSMOS_PROGRESSCIRCLE_COLOR_BACKGROUND_DEFAULT: function() {
                        return FM
                    },
                    TOKEN_COSMOS_PROGRESSCIRCLE_COLOR_BACKGROUND_INVERSE: function() {
                        return DM
                    },
                    TOKEN_COSMOS_PROGRESSCIRCLE_COLOR_BAR_DEFAULT: function() {
                        return iM
                    },
                    TOKEN_COSMOS_PROGRESSCIRCLE_COLOR_BAR_INVERSE: function() {
                        return cM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_BORDER_RADIUS: function() {
                        return oM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_BORDER_WIDTH_ERROR: function() {
                        return fM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_BORDER_WIDTH_SELECTED: function() {
                        return GM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_BORDER_WIDTH_UNSELECTED: function() {
                        return BM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_COLOR_BACKGROUND_ERROR: function() {
                        return PM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_COLOR_BACKGROUND_SELECTED: function() {
                        return UM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_COLOR_BACKGROUND_UNSELECTED: function() {
                        return HM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_COLOR_BORDER_ERROR: function() {
                        return pM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_COLOR_BORDER_SELECTED: function() {
                        return xM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_COLOR_BORDER_UNSELECTED: function() {
                        return YM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_COLOR_ICON_ERROR: function() {
                        return VM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_COLOR_ICON_SELECTED: function() {
                        return WM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_COLOR_ICON_UNSELECTED: function() {
                        return ZM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_SIZING_MEDIUM: function() {
                        return XM
                    },
                    TOKEN_COSMOS_RADIOBUTTON_SIZING_SMALL: function() {
                        return sM
                    },
                    TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_16_9_HEIGHT: function() {
                        return aM
                    },
                    TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_16_9_WIDTH: function() {
                        return lM
                    },
                    TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_1_1_HEIGHT: function() {
                        return dM
                    },
                    TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_1_1_WIDTH: function() {
                        return bM
                    },
                    TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_3_2_HEIGHT: function() {
                        return mM
                    },
                    TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_3_2_WIDTH: function() {
                        return yM
                    },
                    TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_3_4_HEIGHT: function() {
                        return wM
                    },
                    TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_3_4_WIDTH: function() {
                        return gM
                    },
                    TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_4_3_HEIGHT: function() {
                        return QM
                    },
                    TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_4_3_WIDTH: function() {
                        return hM
                    },
                    TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_4_5_HEIGHT: function() {
                        return JM
                    },
                    TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_4_5_WIDTH: function() {
                        return kM
                    },
                    TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_9_16_HEIGHT: function() {
                        return vM
                    },
                    TOKEN_COSMOS_SEMANTIC_ASPECT_RATIO_9_16_WIDTH: function() {
                        return jM
                    },
                    TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_0: function() {
                        return qM
                    },
                    TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_12: function() {
                        return zM
                    },
                    TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_16: function() {
                        return $M
                    },
                    TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_19: function() {
                        return _e
                    },
                    TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_24: function() {
                        return Oe
                    },
                    TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_32: function() {
                        return Te
                    },
                    TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_4: function() {
                        return Ee
                    },
                    TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_8: function() {
                        return ne
                    },
                    TOKEN_COSMOS_SEMANTIC_BORDER_RADIUS_FULL: function() {
                        return Ne
                    },
                    TOKEN_COSMOS_SEMANTIC_BORDER_WIDTH_NONE: function() {
                        return Ce
                    },
                    TOKEN_COSMOS_SEMANTIC_BORDER_WIDTH_THICK: function() {
                        return Ae
                    },
                    TOKEN_COSMOS_SEMANTIC_BORDER_WIDTH_THIN: function() {
                        return Se
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_BORDER_DEFAULT: function() {
                        return Re
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_BORDER_INVERSE: function() {
                        return Ie
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_BORDER_SELECTED: function() {
                        return te
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_BORDER_SUBTLE: function() {
                        return ue
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_BRAND_1: function() {
                        return re
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_BRAND_2: function() {
                        return Le
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_BRAND_3: function() {
                        return Ke
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_DEFAULT: function() {
                        return Me
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_DESTRUCTIVE: function() {
                        return ee
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_DISABLED: function() {
                        return Fe
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_INVERSE: function() {
                        return De
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_SELECTED: function() {
                        return ie
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_SUBTLE_1: function() {
                        return ce
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_SUBTLE_2: function() {
                        return oe
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_SUBTLE_3: function() {
                        return fe
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_CONTAINER_BACKGROUNDS_TRANSPARENT: function() {
                        return Ge
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_DEFAULT: function() {
                        return Be
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_DEFAULT_ICON: function() {
                        return Pe
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_LIKED_YOU: function() {
                        return Ue
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_LIKED_YOU_ICON: function() {
                        return He
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_PREMIUM: function() {
                        return pe
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_PREMIUM_ALT: function() {
                        return xe
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_PREMIUM_ICON: function() {
                        return Ye
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_PREMIUM_PLUS: function() {
                        return Ve
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_PREMIUM_PLUS_ALT: function() {
                        return We
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_PREMIUM_PLUS_ICON: function() {
                        return Ze
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_REVENUE: function() {
                        return Xe
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_REVENUE_ICON: function() {
                        return se
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_TIER_EXTRA: function() {
                        return ae
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_TIER_EXTRA_ALT: function() {
                        return le
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_TIER_EXTRA_ICON: function() {
                        return de
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_TIER_PREMIUM: function() {
                        return be
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_TIER_PREMIUM_ALT: function() {
                        return me
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_TIER_PREMIUM_ICON: function() {
                        return ye
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_FEATURES_VERIFICATION: function() {
                        return we
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_BLUE: function() {
                        return ge
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_BLUE_STRONG: function() {
                        return Qe
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_BLUE_SUBTLE: function() {
                        return he
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_GREEN: function() {
                        return Je
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_GREEN_STRONG: function() {
                        return ke
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_GREEN_SUBTLE: function() {
                        return ve
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_ORANGE: function() {
                        return je
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_ORANGE_STRONG: function() {
                        return qe
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_ORANGE_SUBTLE: function() {
                        return ze
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_PURPLE: function() {
                        return $e
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_PURPLE_STRONG: function() {
                        return _F
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_PURPLE_SUBTLE: function() {
                        return OF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_RED: function() {
                        return TF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_RED_STRONG: function() {
                        return EF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_RED_SUBTLE: function() {
                        return nF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_YELLOW: function() {
                        return NF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_YELLOW_STRONG: function() {
                        return CF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_GENERIC_YELLOW_SUBTLE: function() {
                        return AF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_ICON_BRAND: function() {
                        return SF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_ICON_DEFAULT: function() {
                        return RF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_ICON_DISABLED: function() {
                        return IF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_ICON_INVERSE: function() {
                        return tF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_ICON_SELECTED: function() {
                        return uF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_ICON_SUBTLE: function() {
                        return rF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_BRAND_1: function() {
                        return LF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_BRAND_2: function() {
                        return KF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_BRAND_3: function() {
                        return MF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_DEFAULT: function() {
                        return eF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_OVERLAY: function() {
                        return FF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_OVERLAY_GRADIENT_END: function() {
                        return DF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_OVERLAY_GRADIENT_START: function() {
                        return iF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_STRONG: function() {
                        return cF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_PAGE_BACKGROUNDS_SUBTLE: function() {
                        return oF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_REACTIVE_DEFAULT_HOVER: function() {
                        return fF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_REACTIVE_DEFAULT_PRESSED: function() {
                        return GF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_REACTIVE_INVERSE_HOVER: function() {
                        return BF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_REACTIVE_INVERSE_PRESSED: function() {
                        return PF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_APPLE: function() {
                        return UF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_FACEBOOK: function() {
                        return HF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_GOOGLE: function() {
                        return pF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_INSTAGRAM: function() {
                        return xF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_LINKEDIN: function() {
                        return YF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_ODNOKLASSNIKI: function() {
                        return VF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_SPOTIFY: function() {
                        return WF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_TWITTER: function() {
                        return ZF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SOCIALS_VKONTAKTE: function() {
                        return XF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SUPPORTIVE_FEEDBACK_ALERT: function() {
                        return sF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SUPPORTIVE_FEEDBACK_ALERT_SUBTLE: function() {
                        return aF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SUPPORTIVE_FEEDBACK_ERROR: function() {
                        return lF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SUPPORTIVE_FEEDBACK_ERROR_SUBTLE: function() {
                        return dF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SUPPORTIVE_FEEDBACK_NOTIFICATION: function() {
                        return bF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SUPPORTIVE_FEEDBACK_SUCCESS: function() {
                        return mF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_SUPPORTIVE_FEEDBACK_SUCCESS_SUBTLE: function() {
                        return yF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_DEFAULT: function() {
                        return wF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_DESTRUCTIVE: function() {
                        return gF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_DISABLED: function() {
                        return QF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_ERROR: function() {
                        return hF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_INVERSE: function() {
                        return JF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_LINKS: function() {
                        return kF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_POSITIVE: function() {
                        return vF
                    },
                    TOKEN_COSMOS_SEMANTIC_COLOR_TEXT_SUBDUED: function() {
                        return jF
                    },
                    TOKEN_COSMOS_SEMANTIC_OPACITY_0: function() {
                        return qF
                    },
                    TOKEN_COSMOS_SEMANTIC_OPACITY_10: function() {
                        return zF
                    },
                    TOKEN_COSMOS_SEMANTIC_OPACITY_100: function() {
                        return $F
                    },
                    TOKEN_COSMOS_SEMANTIC_OPACITY_20: function() {
                        return _D
                    },
                    TOKEN_COSMOS_SEMANTIC_OPACITY_30: function() {
                        return OD
                    },
                    TOKEN_COSMOS_SEMANTIC_OPACITY_40: function() {
                        return TD
                    },
                    TOKEN_COSMOS_SEMANTIC_OPACITY_5: function() {
                        return ED
                    },
                    TOKEN_COSMOS_SEMANTIC_OPACITY_50: function() {
                        return nD
                    },
                    TOKEN_COSMOS_SEMANTIC_OPACITY_60: function() {
                        return ND
                    },
                    TOKEN_COSMOS_SEMANTIC_OPACITY_70: function() {
                        return CD
                    },
                    TOKEN_COSMOS_SEMANTIC_OPACITY_80: function() {
                        return AD
                    },
                    TOKEN_COSMOS_SEMANTIC_OPACITY_90: function() {
                        return SD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_1_BLUR: function() {
                        return RD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_1_COLOR: function() {
                        return ID
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_1_SPREAD: function() {
                        return tD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_1_X: function() {
                        return uD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_1_Y: function() {
                        return rD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_2_BLUR: function() {
                        return LD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_2_COLOR: function() {
                        return KD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_2_SPREAD: function() {
                        return MD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_2_X: function() {
                        return eD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_FLOATING_ELEVATION_2_Y: function() {
                        return FD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_NONE_BLUR: function() {
                        return DD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_NONE_COLOR: function() {
                        return iD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_NONE_SPREAD: function() {
                        return cD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_NONE_X: function() {
                        return oD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_NONE_Y: function() {
                        return fD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_1_BLUR: function() {
                        return GD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_1_COLOR: function() {
                        return BD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_1_SPREAD: function() {
                        return PD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_1_X: function() {
                        return UD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_1_Y: function() {
                        return HD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_2_BLUR: function() {
                        return pD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_2_COLOR: function() {
                        return xD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_2_SPREAD: function() {
                        return YD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_2_X: function() {
                        return VD
                    },
                    TOKEN_COSMOS_SEMANTIC_SHADOWS_STATIC_ELEVATION_2_Y: function() {
                        return WD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_0: function() {
                        return ZD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_100: function() {
                        return XD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_12: function() {
                        return sD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_16: function() {
                        return aD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_2: function() {
                        return lD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_20: function() {
                        return dD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_24: function() {
                        return bD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_32: function() {
                        return mD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_4: function() {
                        return yD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_40: function() {
                        return wD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_48: function() {
                        return gD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_56: function() {
                        return QD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_6: function() {
                        return hD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_64: function() {
                        return JD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_72: function() {
                        return kD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_8: function() {
                        return vD
                    },
                    TOKEN_COSMOS_SEMANTIC_SIZING_80: function() {
                        return jD
                    },
                    TOKEN_COSMOS_SEMANTIC_SPACING_0: function() {
                        return qD
                    },
                    TOKEN_COSMOS_SEMANTIC_SPACING_1: function() {
                        return zD
                    },
                    TOKEN_COSMOS_SEMANTIC_SPACING_12: function() {
                        return $D
                    },
                    TOKEN_COSMOS_SEMANTIC_SPACING_16: function() {
                        return _i
                    },
                    TOKEN_COSMOS_SEMANTIC_SPACING_2: function() {
                        return Oi
                    },
                    TOKEN_COSMOS_SEMANTIC_SPACING_20: function() {
                        return Ti
                    },
                    TOKEN_COSMOS_SEMANTIC_SPACING_24: function() {
                        return Ei
                    },
                    TOKEN_COSMOS_SEMANTIC_SPACING_3: function() {
                        return ni
                    },
                    TOKEN_COSMOS_SEMANTIC_SPACING_32: function() {
                        return Ni
                    },
                    TOKEN_COSMOS_SEMANTIC_SPACING_4: function() {
                        return Ci
                    },
                    TOKEN_COSMOS_SEMANTIC_SPACING_40: function() {
                        return Ai
                    },
                    TOKEN_COSMOS_SEMANTIC_SPACING_48: function() {
                        return Si
                    },
                    TOKEN_COSMOS_SEMANTIC_SPACING_56: function() {
                        return Ri
                    },
                    TOKEN_COSMOS_SEMANTIC_SPACING_8: function() {
                        return Ii
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_FONT_FAMILY: function() {
                        return ti
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_FONT_SIZE: function() {
                        return ui
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_FONT_WEIGHT: function() {
                        return ri
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_LINE_HEIGHT: function() {
                        return Li
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_MINI_FONT_FAMILY: function() {
                        return Ki
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_MINI_FONT_SIZE: function() {
                        return Mi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_MINI_FONT_WEIGHT: function() {
                        return ei
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_MINI_LINE_HEIGHT: function() {
                        return Fi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_SMALL_FONT_FAMILY: function() {
                        return Di
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_SMALL_FONT_SIZE: function() {
                        return ii
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_SMALL_FONT_WEIGHT: function() {
                        return ci
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_ACTION_SMALL_LINE_HEIGHT: function() {
                        return oi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_CAPTION_FONT_FAMILY: function() {
                        return fi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_CAPTION_FONT_SIZE: function() {
                        return Gi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_CAPTION_FONT_WEIGHT: function() {
                        return Bi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_CAPTION_LINE_HEIGHT: function() {
                        return Pi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D1_FONT_FAMILY: function() {
                        return Ui
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D1_FONT_SIZE: function() {
                        return Hi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D1_FONT_WEIGHT: function() {
                        return pi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D1_LINE_HEIGHT: function() {
                        return xi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D2_FONT_FAMILY: function() {
                        return Yi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D2_FONT_SIZE: function() {
                        return Vi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D2_FONT_WEIGHT: function() {
                        return Wi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D2_LINE_HEIGHT: function() {
                        return Zi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D3_FONT_FAMILY: function() {
                        return Xi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D3_FONT_SIZE: function() {
                        return si
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D3_FONT_WEIGHT: function() {
                        return ai
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_D3_LINE_HEIGHT: function() {
                        return li
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_FONT_FAMILY: function() {
                        return di
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_FONT_SIZE: function() {
                        return bi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_FONT_WEIGHT: function() {
                        return mi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_LINE_HEIGHT: function() {
                        return yi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_FONT_FAMILY: function() {
                        return wi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_FONT_SIZE: function() {
                        return gi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_FONT_WEIGHT: function() {
                        return Qi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_LINE_HEIGHT: function() {
                        return hi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_FONT_FAMILY: function() {
                        return Ji
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_FONT_SIZE: function() {
                        return ki
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_FONT_WEIGHT: function() {
                        return vi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_LINE_HEIGHT: function() {
                        return ji
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H4_FONT_FAMILY: function() {
                        return qi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H4_FONT_SIZE: function() {
                        return zi
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H4_FONT_WEIGHT: function() {
                        return $i
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H4_LINE_HEIGHT: function() {
                        return _c
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_1_FONT_FAMILY: function() {
                        return Oc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_1_FONT_SIZE: function() {
                        return Tc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_1_FONT_WEIGHT: function() {
                        return Ec
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_1_LINE_HEIGHT: function() {
                        return nc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_2_FONT_FAMILY: function() {
                        return Nc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_2_FONT_SIZE: function() {
                        return Cc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_2_FONT_WEIGHT: function() {
                        return Ac
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_2_LINE_HEIGHT: function() {
                        return Sc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_3_FONT_FAMILY: function() {
                        return Rc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_3_FONT_SIZE: function() {
                        return Ic
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_3_FONT_WEIGHT: function() {
                        return tc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_LINK_3_LINE_HEIGHT: function() {
                        return uc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_BOLDER_FONT_FAMILY: function() {
                        return rc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_BOLDER_FONT_SIZE: function() {
                        return Lc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_BOLDER_FONT_WEIGHT: function() {
                        return Kc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_BOLDER_LINE_HEIGHT: function() {
                        return Mc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_FONT_FAMILY: function() {
                        return ec
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_FONT_SIZE: function() {
                        return Fc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_FONT_WEIGHT: function() {
                        return Dc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P1_LINE_HEIGHT: function() {
                        return ic
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_BOLDER_FONT_FAMILY: function() {
                        return cc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_BOLDER_FONT_SIZE: function() {
                        return oc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_BOLDER_FONT_WEIGHT: function() {
                        return fc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_BOLDER_LINE_HEIGHT: function() {
                        return Gc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_FONT_FAMILY: function() {
                        return Bc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_FONT_SIZE: function() {
                        return Pc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_FONT_WEIGHT: function() {
                        return Uc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P2_LINE_HEIGHT: function() {
                        return Hc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_BOLDER_FONT_FAMILY: function() {
                        return pc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_BOLDER_FONT_SIZE: function() {
                        return xc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_BOLDER_FONT_WEIGHT: function() {
                        return Yc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_BOLDER_LINE_HEIGHT: function() {
                        return Vc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_FONT_FAMILY: function() {
                        return Wc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_FONT_SIZE: function() {
                        return Zc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_FONT_WEIGHT: function() {
                        return Xc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_P3_LINE_HEIGHT: function() {
                        return sc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_TITLE_FONT_FAMILY: function() {
                        return ac
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_TITLE_FONT_SIZE: function() {
                        return lc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_TITLE_FONT_WEIGHT: function() {
                        return dc
                    },
                    TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_TITLE_LINE_HEIGHT: function() {
                        return bc
                    },
                    TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_APPLE: function() {
                        return mc
                    },
                    TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_FACEBOOK: function() {
                        return yc
                    },
                    TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_GOOGLE: function() {
                        return wc
                    },
                    TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_INSTAGRAM: function() {
                        return gc
                    },
                    TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_LINKEDIN: function() {
                        return Qc
                    },
                    TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_ODNOKLASSNIKI: function() {
                        return hc
                    },
                    TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_OVERLAY_HOVER: function() {
                        return Jc
                    },
                    TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_OVERLAY_PRESSED: function() {
                        return kc
                    },
                    TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_SPOTIFY: function() {
                        return vc
                    },
                    TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_TWITTER: function() {
                        return jc
                    },
                    TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_BACKGROUND_VKONTAKTE: function() {
                        return qc
                    },
                    TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_CONTENT: function() {
                        return zc
                    },
                    TOKEN_COSMOS_SOCIALMEDIABUTTON_COLOR_ICON: function() {
                        return $c
                    },
                    TOKEN_COSMOS_TABBAR_COLOR_BACKGROUND: function() {
                        return _o
                    },
                    TOKEN_COSMOS_TABBAR_COLOR_ICON_DEFAULT: function() {
                        return Oo
                    },
                    TOKEN_COSMOS_TABBAR_COLOR_ICON_SELECTED: function() {
                        return To
                    },
                    TOKEN_COSMOS_TABBAR_COLOR_TEXT_DEFAULT: function() {
                        return Eo
                    },
                    TOKEN_COSMOS_TABBAR_COLOR_TEXT_SELECTED: function() {
                        return no
                    },
                    TOKEN_COSMOS_TABBAR_SIZING_ICON: function() {
                        return No
                    },
                    TOKEN_COSMOS_TABBAR_SPACING_GAP: function() {
                        return Co
                    },
                    TOKEN_COSMOS_TABBAR_SPACING_HORIZONTAL: function() {
                        return Ao
                    },
                    TOKEN_COSMOS_TABBAR_SPACING_VERTICAL_BOTTOM: function() {
                        return So
                    },
                    TOKEN_COSMOS_TABBAR_SPACING_VERTICAL_TOP: function() {
                        return Ro
                    },
                    TOKEN_COSMOS_TABBAR_TYPOGRAPHY_TEXT: function() {
                        return Io
                    },
                    TOKEN_COSMOS_TABS_BORDER_WIDTH_DEFAULT_DEFAULT: function() {
                        return to
                    },
                    TOKEN_COSMOS_TABS_BORDER_WIDTH_DEFAULT_SELECTED: function() {
                        return uo
                    },
                    TOKEN_COSMOS_TABS_BORDER_WIDTH_INVERSE_DEFAULT: function() {
                        return ro
                    },
                    TOKEN_COSMOS_TABS_BORDER_WIDTH_INVERSE_SELECTED: function() {
                        return Lo
                    },
                    TOKEN_COSMOS_TABS_COLOR_BACKGROUND_DEFAULT: function() {
                        return Ko
                    },
                    TOKEN_COSMOS_TABS_COLOR_BACKGROUND_INVERSE: function() {
                        return Mo
                    },
                    TOKEN_COSMOS_TABS_COLOR_BORDER_DEFAULT_DEFAULT: function() {
                        return eo
                    },
                    TOKEN_COSMOS_TABS_COLOR_BORDER_DEFAULT_SELECTED: function() {
                        return Fo
                    },
                    TOKEN_COSMOS_TABS_COLOR_BORDER_INVERSE_DEFAULT: function() {
                        return Do
                    },
                    TOKEN_COSMOS_TABS_COLOR_BORDER_INVERSE_SELECTED: function() {
                        return io
                    },
                    TOKEN_COSMOS_TABS_COLOR_ICON_DEFAULT_DEFAULT: function() {
                        return co
                    },
                    TOKEN_COSMOS_TABS_COLOR_ICON_DEFAULT_SELECTED: function() {
                        return oo
                    },
                    TOKEN_COSMOS_TABS_COLOR_ICON_INVERSE_DEFAULT: function() {
                        return fo
                    },
                    TOKEN_COSMOS_TABS_COLOR_ICON_INVERSE_SELECTED: function() {
                        return Go
                    },
                    TOKEN_COSMOS_TABS_COLOR_TEXT_DEFAULT_DEFAULT: function() {
                        return Bo
                    },
                    TOKEN_COSMOS_TABS_COLOR_TEXT_DEFAULT_SELECTED: function() {
                        return Po
                    },
                    TOKEN_COSMOS_TABS_COLOR_TEXT_INVERSE_DEFAULT: function() {
                        return Uo
                    },
                    TOKEN_COSMOS_TABS_COLOR_TEXT_INVERSE_SELECTED: function() {
                        return Ho
                    },
                    TOKEN_COSMOS_TABS_SIZING_ICON: function() {
                        return po
                    },
                    TOKEN_COSMOS_TABS_SPACING_GAP: function() {
                        return xo
                    },
                    TOKEN_COSMOS_TABS_SPACING_HORIZONTAL: function() {
                        return Yo
                    },
                    TOKEN_COSMOS_TABS_SPACING_ITEM_GAP: function() {
                        return Vo
                    },
                    TOKEN_COSMOS_TABS_SPACING_ITEM_HORIZONTAL: function() {
                        return Wo
                    },
                    TOKEN_COSMOS_TABS_SPACING_ITEM_VERTICAL: function() {
                        return Zo
                    },
                    TOKEN_COSMOS_TABS_TYPOGRAPHY_TEXT: function() {
                        return Xo
                    },
                    TOKEN_COSMOS_TIP_BORDER_RADIUS: function() {
                        return so
                    },
                    TOKEN_COSMOS_TIP_COLOR_BACKGROUND_BRAND: function() {
                        return ao
                    },
                    TOKEN_COSMOS_TIP_COLOR_BACKGROUND_DEFAULT: function() {
                        return lo
                    },
                    TOKEN_COSMOS_TIP_COLOR_BACKGROUND_SUBTLE: function() {
                        return bo
                    },
                    TOKEN_COSMOS_TIP_COLOR_DESCRIPTION_BRAND: function() {
                        return mo
                    },
                    TOKEN_COSMOS_TIP_COLOR_DESCRIPTION_DEFAULT: function() {
                        return yo
                    },
                    TOKEN_COSMOS_TIP_COLOR_DESCRIPTION_SUBTLE: function() {
                        return wo
                    },
                    TOKEN_COSMOS_TIP_COLOR_DIVIDER_BRAND: function() {
                        return go
                    },
                    TOKEN_COSMOS_TIP_COLOR_DIVIDER_DEFAULT: function() {
                        return Qo
                    },
                    TOKEN_COSMOS_TIP_COLOR_DIVIDER_SUBTLE: function() {
                        return ho
                    },
                    TOKEN_COSMOS_TIP_COLOR_ICON_BRAND: function() {
                        return Jo
                    },
                    TOKEN_COSMOS_TIP_COLOR_ICON_DEFAULT: function() {
                        return ko
                    },
                    TOKEN_COSMOS_TIP_COLOR_ICON_SUBTLE: function() {
                        return vo
                    },
                    TOKEN_COSMOS_TIP_COLOR_LINK_BRAND: function() {
                        return jo
                    },
                    TOKEN_COSMOS_TIP_COLOR_LINK_DEFAULT: function() {
                        return qo
                    },
                    TOKEN_COSMOS_TIP_COLOR_LINK_SUBTLE: function() {
                        return zo
                    },
                    TOKEN_COSMOS_TIP_COLOR_TITLE_BRAND: function() {
                        return $o
                    },
                    TOKEN_COSMOS_TIP_COLOR_TITLE_DEFAULT: function() {
                        return _f
                    },
                    TOKEN_COSMOS_TIP_COLOR_TITLE_SUBTLE: function() {
                        return Of
                    },
                    TOKEN_COSMOS_TIP_SHADOW_DEFAULT_BLUR: function() {
                        return Tf
                    },
                    TOKEN_COSMOS_TIP_SHADOW_DEFAULT_COLOR: function() {
                        return Ef
                    },
                    TOKEN_COSMOS_TIP_SHADOW_DEFAULT_SPREAD: function() {
                        return nf
                    },
                    TOKEN_COSMOS_TIP_SHADOW_DEFAULT_X: function() {
                        return Nf
                    },
                    TOKEN_COSMOS_TIP_SHADOW_DEFAULT_Y: function() {
                        return Cf
                    },
                    TOKEN_COSMOS_TIP_SHADOW_OTHERS_BLUR: function() {
                        return Af
                    },
                    TOKEN_COSMOS_TIP_SHADOW_OTHERS_COLOR: function() {
                        return Sf
                    },
                    TOKEN_COSMOS_TIP_SHADOW_OTHERS_SPREAD: function() {
                        return Rf
                    },
                    TOKEN_COSMOS_TIP_SHADOW_OTHERS_X: function() {
                        return If
                    },
                    TOKEN_COSMOS_TIP_SHADOW_OTHERS_Y: function() {
                        return tf
                    },
                    TOKEN_COSMOS_TIP_SIZING_ICON_END: function() {
                        return uf
                    },
                    TOKEN_COSMOS_TIP_SIZING_ICON_START_LARGE: function() {
                        return rf
                    },
                    TOKEN_COSMOS_TIP_SIZING_ICON_START_SMALL: function() {
                        return Lf
                    },
                    TOKEN_COSMOS_TIP_SPACING_GAP_HORIZONTAL_SMALL: function() {
                        return Kf
                    },
                    TOKEN_COSMOS_TIP_SPACING_GAP_VERTICAL_LARGE: function() {
                        return Mf
                    },
                    TOKEN_COSMOS_TIP_SPACING_GAP_VERTICAL_MEDIUM: function() {
                        return ef
                    },
                    TOKEN_COSMOS_TIP_SPACING_GAP_VERTICAL_SMALL: function() {
                        return Ff
                    },
                    TOKEN_COSMOS_TIP_SPACING_HORIZONTAL: function() {
                        return Df
                    },
                    TOKEN_COSMOS_TIP_SPACING_VERTICAL: function() {
                        return cf
                    },
                    TOKEN_COSMOS_TIP_TYPOGRAPHY_DESCRIPTION: function() {
                        return of
                    },
                    TOKEN_COSMOS_TIP_TYPOGRAPHY_LINK: function() {
                        return ff
                    },
                    TOKEN_COSMOS_TIP_TYPOGRAPHY_TITLE: function() {
                        return Gf
                    },
                    TOKEN_COSMOS_TOGGLE_BORDER_RADIUS: function() {
                        return Bf
                    },
                    TOKEN_COSMOS_TOGGLE_BORDER_WIDTH_SELECTED: function() {
                        return Pf
                    },
                    TOKEN_COSMOS_TOGGLE_BORDER_WIDTH_UNSELECTED: function() {
                        return Uf
                    },
                    TOKEN_COSMOS_TOGGLE_COLOR_BACKGROUND_SELECTED: function() {
                        return Hf
                    },
                    TOKEN_COSMOS_TOGGLE_COLOR_BACKGROUND_UNSELECTED: function() {
                        return pf
                    },
                    TOKEN_COSMOS_TOGGLE_COLOR_BORDER_SELECTED: function() {
                        return xf
                    },
                    TOKEN_COSMOS_TOGGLE_COLOR_BORDER_UNSELECTED: function() {
                        return Yf
                    },
                    TOKEN_COSMOS_TOGGLE_COLOR_HANDLE_SELECTED: function() {
                        return Vf
                    },
                    TOKEN_COSMOS_TOGGLE_COLOR_HANDLE_UNSELECTED: function() {
                        return Wf
                    },
                    TOKEN_COSMOS_TOGGLE_SIZING_HANDLE: function() {
                        return Zf
                    },
                    TOKEN_COSMOS_TOGGLE_SPACING_HORIZONTAL_END_SELECTED: function() {
                        return Xf
                    },
                    TOKEN_COSMOS_TOGGLE_SPACING_HORIZONTAL_END_UNSELECTED: function() {
                        return sf
                    },
                    TOKEN_COSMOS_TOGGLE_SPACING_HORIZONTAL_START_SELECTED: function() {
                        return af
                    },
                    TOKEN_COSMOS_TOGGLE_SPACING_HORIZONTAL_START_UNSELECTED: function() {
                        return lf
                    },
                    TOKEN_COSMOS_TOGGLE_SPACING_VERTICAL: function() {
                        return df
                    },
                    TOKEN_COSMOS_TOOLTIP_BORDER_RADIUS: function() {
                        return bf
                    },
                    TOKEN_COSMOS_TOOLTIP_COLOR_BACKGROUND: function() {
                        return mf
                    },
                    TOKEN_COSMOS_TOOLTIP_COLOR_CONTENT: function() {
                        return yf
                    },
                    TOKEN_COSMOS_TOOLTIP_SIZING_BEAK_HEIGHT: function() {
                        return wf
                    },
                    TOKEN_COSMOS_TOOLTIP_SIZING_BEAK_WIDTH: function() {
                        return gf
                    },
                    TOKEN_COSMOS_TOOLTIP_SPACING_HORIZONTAL: function() {
                        return Qf
                    },
                    TOKEN_COSMOS_TOOLTIP_SPACING_VERTICAL: function() {
                        return hf
                    },
                    TOKEN_COSMOS_TOOLTIP_TYPOGRAPHY_CONTENT: function() {
                        return Jf
                    },
                    TOKEN_CTABOX_COMPACT_ADDITIONAL_MARGIN_TOP: function() {
                        return kf
                    },
                    TOKEN_CTABOX_COMPACT_BUTTONS_MARGIN_TOP: function() {
                        return vf
                    },
                    TOKEN_CTABOX_COMPACT_CONTENT_MARGIN_TOP: function() {
                        return jf
                    },
                    TOKEN_CTABOX_COMPACT_HEADER_MARGIN_BOTTOM: function() {
                        return qf
                    },
                    TOKEN_CTABOX_COMPACT_MEDIA_ICON_SIZE: function() {
                        return zf
                    },
                    TOKEN_CTABOX_COMPACT_MEDIA_MARGIN_BOTTOM: function() {
                        return $f
                    },
                    TOKEN_CTABOX_COMPACT_TEXT_GAP: function() {
                        return _G
                    },
                    TOKEN_CTABOX_MAX_WIDTH: function() {
                        return OG
                    },
                    TOKEN_CTABOX_NORMAL_ADDITIONAL_MARGIN_TOP: function() {
                        return TG
                    },
                    TOKEN_CTABOX_NORMAL_BUTTONS_MARGIN_TOP: function() {
                        return EG
                    },
                    TOKEN_CTABOX_NORMAL_CONTENT_MARGIN_TOP: function() {
                        return nG
                    },
                    TOKEN_CTABOX_NORMAL_HEADER_MARGIN_BOTTOM: function() {
                        return NG
                    },
                    TOKEN_CTABOX_NORMAL_MEDIA_ICON_SIZE: function() {
                        return CG
                    },
                    TOKEN_CTABOX_NORMAL_MEDIA_MARGIN_BOTTOM: function() {
                        return AG
                    },
                    TOKEN_CTABOX_NORMAL_TEXT_GAP: function() {
                        return SG
                    },
                    TOKEN_DATE_FIELD_ITEM_HORIZONTAL_GAP: function() {
                        return RG
                    },
                    TOKEN_DATE_FIELD_ITEM_MIN_WIDTH_2: function() {
                        return IG
                    },
                    TOKEN_DATE_FIELD_ITEM_MIN_WIDTH_4: function() {
                        return tG
                    },
                    TOKEN_DOTCOUNTERNOTIFICATION_ANIMATION_TIMING_BOUNCE: function() {
                        return uG
                    },
                    TOKEN_DOTCOUNTERNOTIFICATION_ANIMATION_TIMING_POPOUT: function() {
                        return rG
                    },
                    TOKEN_DOTCOUNTERNOTIFICATION_COUNTER_FONT_SIZE: function() {
                        return LG
                    },
                    TOKEN_DOTCOUNTERNOTIFICATION_COUNTER_MIN_SIZE: function() {
                        return KG
                    },
                    TOKEN_DOTCOUNTERNOTIFICATION_COUNTER_OUTER_BORDER_WIDTH: function() {
                        return MG
                    },
                    TOKEN_DOTCOUNTERNOTIFICATION_DOT_OUTER_BORDER_WIDTH: function() {
                        return eG
                    },
                    TOKEN_DOTCOUNTERNOTIFICATION_DOT_SIZE: function() {
                        return FG
                    },
                    TOKEN_EDIT_PROFILE_BLOCK_BACKGROUND_COLOR: function() {
                        return DG
                    },
                    TOKEN_EDIT_PROFILE_BLOCK_BORDER_RADIUS: function() {
                        return iG
                    },
                    TOKEN_EDIT_PROFILE_BLOCK_CHEVRON_COLOR: function() {
                        return cG
                    },
                    TOKEN_EDIT_PROFILE_BLOCK_CHEVRON_MARGIN_LEFT: function() {
                        return oG
                    },
                    TOKEN_EDIT_PROFILE_BLOCK_CHEVRON_SIZE: function() {
                        return fG
                    },
                    TOKEN_EDIT_PROFILE_BLOCK_GAP: function() {
                        return GG
                    },
                    TOKEN_EDIT_PROFILE_BLOCK_HEADER_ICON_SIZE: function() {
                        return BG
                    },
                    TOKEN_EDIT_PROFILE_BLOCK_HEADER_ITEM_GAP: function() {
                        return PG
                    },
                    TOKEN_EDIT_PROFILE_BLOCK_HEADER_MARGIN_BOTTOM: function() {
                        return UG
                    },
                    TOKEN_EDIT_PROFILE_BLOCK_PADDING_HORIZONTAL: function() {
                        return HG
                    },
                    TOKEN_EDIT_PROFILE_BLOCK_PADDING_VERTICAL: function() {
                        return pG
                    },
                    TOKEN_FONT_FAMILY_ACTION: function() {
                        return xG
                    },
                    TOKEN_FONT_FAMILY_ACTION_MINI: function() {
                        return YG
                    },
                    TOKEN_FONT_FAMILY_ACTION_SMALL: function() {
                        return VG
                    },
                    TOKEN_FONT_FAMILY_CUSTOM: function() {
                        return WG
                    },
                    TOKEN_FONT_FAMILY_DISPLAY_1: function() {
                        return ZG
                    },
                    TOKEN_FONT_FAMILY_DISPLAY_2: function() {
                        return XG
                    },
                    TOKEN_FONT_FAMILY_DISPLAY_3: function() {
                        return sG
                    },
                    TOKEN_FONT_FAMILY_HEADER_1: function() {
                        return aG
                    },
                    TOKEN_FONT_FAMILY_HEADER_2: function() {
                        return lG
                    },
                    TOKEN_FONT_FAMILY_HEADER_3: function() {
                        return dG
                    },
                    TOKEN_FONT_FAMILY_HEADER_4: function() {
                        return bG
                    },
                    TOKEN_FONT_FAMILY_PARAGRAPH_1: function() {
                        return mG
                    },
                    TOKEN_FONT_FAMILY_PARAGRAPH_1_BOLDER: function() {
                        return yG
                    },
                    TOKEN_FONT_FAMILY_PARAGRAPH_2: function() {
                        return wG
                    },
                    TOKEN_FONT_FAMILY_PARAGRAPH_2_BOLDER: function() {
                        return gG
                    },
                    TOKEN_FONT_FAMILY_PARAGRAPH_3: function() {
                        return QG
                    },
                    TOKEN_FONT_FAMILY_PARAGRAPH_3_BOLDER: function() {
                        return hG
                    },
                    TOKEN_FONT_FAMILY_TITLE: function() {
                        return JG
                    },
                    TOKEN_FONT_SIZE_ACTION: function() {
                        return kG
                    },
                    TOKEN_FONT_SIZE_ACTION_MINI: function() {
                        return vG
                    },
                    TOKEN_FONT_SIZE_ACTION_SMALL: function() {
                        return jG
                    },
                    TOKEN_FONT_SIZE_DISPLAY_1: function() {
                        return qG
                    },
                    TOKEN_FONT_SIZE_DISPLAY_2: function() {
                        return zG
                    },
                    TOKEN_FONT_SIZE_DISPLAY_3: function() {
                        return $G
                    },
                    TOKEN_FONT_SIZE_HEADER_1: function() {
                        return _B
                    },
                    TOKEN_FONT_SIZE_HEADER_2: function() {
                        return OB
                    },
                    TOKEN_FONT_SIZE_HEADER_3: function() {
                        return TB
                    },
                    TOKEN_FONT_SIZE_HEADER_4: function() {
                        return EB
                    },
                    TOKEN_FONT_SIZE_PARAGRAPH_1: function() {
                        return nB
                    },
                    TOKEN_FONT_SIZE_PARAGRAPH_1_BOLDER: function() {
                        return NB
                    },
                    TOKEN_FONT_SIZE_PARAGRAPH_2: function() {
                        return CB
                    },
                    TOKEN_FONT_SIZE_PARAGRAPH_2_BOLDER: function() {
                        return AB
                    },
                    TOKEN_FONT_SIZE_PARAGRAPH_3: function() {
                        return SB
                    },
                    TOKEN_FONT_SIZE_PARAGRAPH_3_BOLDER: function() {
                        return RB
                    },
                    TOKEN_FONT_SIZE_TITLE: function() {
                        return IB
                    },
                    TOKEN_FONT_WEIGHT_ACTION: function() {
                        return tB
                    },
                    TOKEN_FONT_WEIGHT_ACTION_MINI: function() {
                        return uB
                    },
                    TOKEN_FONT_WEIGHT_ACTION_SMALL: function() {
                        return rB
                    },
                    TOKEN_FONT_WEIGHT_DISPLAY_1: function() {
                        return LB
                    },
                    TOKEN_FONT_WEIGHT_DISPLAY_2: function() {
                        return KB
                    },
                    TOKEN_FONT_WEIGHT_DISPLAY_3: function() {
                        return MB
                    },
                    TOKEN_FONT_WEIGHT_HEADER_1: function() {
                        return eB
                    },
                    TOKEN_FONT_WEIGHT_HEADER_2: function() {
                        return FB
                    },
                    TOKEN_FONT_WEIGHT_HEADER_3: function() {
                        return DB
                    },
                    TOKEN_FONT_WEIGHT_HEADER_4: function() {
                        return iB
                    },
                    TOKEN_FONT_WEIGHT_PARAGRAPH_1: function() {
                        return cB
                    },
                    TOKEN_FONT_WEIGHT_PARAGRAPH_1_BOLDER: function() {
                        return oB
                    },
                    TOKEN_FONT_WEIGHT_PARAGRAPH_2: function() {
                        return fB
                    },
                    TOKEN_FONT_WEIGHT_PARAGRAPH_2_BOLDER: function() {
                        return GB
                    },
                    TOKEN_FONT_WEIGHT_PARAGRAPH_3: function() {
                        return BB
                    },
                    TOKEN_FONT_WEIGHT_PARAGRAPH_3_BOLDER: function() {
                        return PB
                    },
                    TOKEN_FONT_WEIGHT_TITLE: function() {
                        return UB
                    },
                    TOKEN_FORM_ACTIONS_MARGIN_TOP: function() {
                        return HB
                    },
                    TOKEN_FORM_CONTROL_GAP_VERTICAL: function() {
                        return pB
                    },
                    TOKEN_FORM_HINT_MARGIN_TOP: function() {
                        return xB
                    },
                    TOKEN_FORM_LABEL_COLOR: function() {
                        return YB
                    },
                    TOKEN_FORM_LABEL_MARGIN_BOTTOM: function() {
                        return VB
                    },
                    TOKEN_FORM_MAX_WIDTH: function() {
                        return WB
                    },
                    TOKEN_FORM_NOTE_COLOR_ERROR: function() {
                        return ZB
                    },
                    TOKEN_FORM_NOTE_COLOR_HINT: function() {
                        return XB
                    },
                    TOKEN_FORM_NOTE_COLOR_SUCCESS: function() {
                        return sB
                    },
                    TOKEN_FORM_NOTE_EXTRA_MARGIN_LEFT: function() {
                        return aB
                    },
                    TOKEN_FORM_NOTE_ICON_MARGIN_RIGHT: function() {
                        return lB
                    },
                    TOKEN_FORM_NOTE_ICON_SIZE: function() {
                        return dB
                    },
                    TOKEN_FORM_NOTE_MARGIN_TOP: function() {
                        return bB
                    },
                    TOKEN_FORM_TEXT_GAP: function() {
                        return mB
                    },
                    TOKEN_FORM_TEXT_MARGIN_BOTTOM: function() {
                        return yB
                    },
                    TOKEN_GIFT_WRAP_COLOR_DEFAULT: function() {
                        return wB
                    },
                    TOKEN_GIFT_WRAP_COLOR_VARIANT_1: function() {
                        return gB
                    },
                    TOKEN_GIFT_WRAP_COLOR_VARIANT_2: function() {
                        return QB
                    },
                    TOKEN_GIFT_WRAP_COLOR_VARIANT_3: function() {
                        return hB
                    },
                    TOKEN_GIFT_WRAP_COLOR_VARIANT_4: function() {
                        return JB
                    },
                    TOKEN_GIFT_WRAP_COLOR_VARIANT_5: function() {
                        return kB
                    },
                    TOKEN_GIFT_WRAP_COLOR_VARIANT_6: function() {
                        return vB
                    },
                    TOKEN_GIFT_WRAP_COLOR_VARIANT_7: function() {
                        return jB
                    },
                    TOKEN_GIFT_WRAP_COLOR_VARIANT_8: function() {
                        return qB
                    },
                    TOKEN_GIFT_WRAP_COLOR_VARIANT_9: function() {
                        return zB
                    },
                    TOKEN_GRID_LIST_SPACING_LG: function() {
                        return $B
                    },
                    TOKEN_GRID_LIST_SPACING_MD: function() {
                        return _P
                    },
                    TOKEN_GRID_LIST_SPACING_SM: function() {
                        return OP
                    },
                    TOKEN_GRID_LIST_SPACING_XLG: function() {
                        return TP
                    },
                    TOKEN_HINT_FONT_FAMILY: function() {
                        return EP
                    },
                    TOKEN_HINT_FONT_SIZE: function() {
                        return nP
                    },
                    TOKEN_HINT_FONT_WEIGHT: function() {
                        return NP
                    },
                    TOKEN_HINT_GAP_VERTICAL: function() {
                        return CP
                    },
                    TOKEN_HINT_LINE_HEIGHT: function() {
                        return AP
                    },
                    TOKEN_ICON_JUMBO_SIZE_LG: function() {
                        return SP
                    },
                    TOKEN_ICON_JUMBO_SIZE_MD: function() {
                        return RP
                    },
                    TOKEN_ICON_JUMBO_SIZE_SM: function() {
                        return IP
                    },
                    TOKEN_ICON_SIZE_LG: function() {
                        return tP
                    },
                    TOKEN_ICON_SIZE_MD: function() {
                        return uP
                    },
                    TOKEN_ICON_SIZE_SM: function() {
                        return rP
                    },
                    TOKEN_ICON_SIZE_XLG: function() {
                        return LP
                    },
                    TOKEN_ICON_SIZE_XSM: function() {
                        return KP
                    },
                    TOKEN_ICON_SIZE_XXLG: function() {
                        return MP
                    },
                    TOKEN_INAPPNOTIFICATION_BACKGROUND_COLOR: function() {
                        return eP
                    },
                    TOKEN_INAPPNOTIFICATION_BADGE_SIZE: function() {
                        return FP
                    },
                    TOKEN_INAPPNOTIFICATION_BORDER_RADIUS: function() {
                        return DP
                    },
                    TOKEN_INAPPNOTIFICATION_CONTENT_COLOR: function() {
                        return iP
                    },
                    TOKEN_INAPPNOTIFICATION_ICON_COLOR: function() {
                        return cP
                    },
                    TOKEN_INAPPNOTIFICATION_ICON_SIZE: function() {
                        return oP
                    },
                    TOKEN_INAPPNOTIFICATION_IMAGE_MARGIN_RIGHT: function() {
                        return fP
                    },
                    TOKEN_INAPPNOTIFICATION_IMAGE_SIZE: function() {
                        return GP
                    },
                    TOKEN_INAPPNOTIFICATION_INSET_HORIZONTAL: function() {
                        return BP
                    },
                    TOKEN_INAPPNOTIFICATION_INSET_VERTICAL: function() {
                        return PP
                    },
                    TOKEN_INPUT_CHOICE_BORDER_RADIUS_CHECKBOX: function() {
                        return UP
                    },
                    TOKEN_INPUT_CHOICE_BORDER_RADIUS_RADIO: function() {
                        return HP
                    },
                    TOKEN_INPUT_CHOICE_COLOR_BASE_SELECTED: function() {
                        return pP
                    },
                    TOKEN_INPUT_CHOICE_COLOR_BASE_SELECTED_BACKGROUND: function() {
                        return xP
                    },
                    TOKEN_INPUT_CHOICE_COLOR_BASE_SELECTED_FOREGROUND: function() {
                        return YP
                    },
                    TOKEN_INPUT_CHOICE_COLOR_BASE_STATUS_ERROR_BACKGROUND: function() {
                        return VP
                    },
                    TOKEN_INPUT_CHOICE_COLOR_BASE_STATUS_ERROR_FOREGROUND: function() {
                        return WP
                    },
                    TOKEN_INPUT_CHOICE_COLOR_BASE_UNSELECTED: function() {
                        return ZP
                    },
                    TOKEN_INPUT_CHOICE_COLOR_BASE_UNSELECTED_BACKGROUND: function() {
                        return XP
                    },
                    TOKEN_INPUT_CHOICE_COLOR_BASE_UNSELECTED_FOREGROUND: function() {
                        return sP
                    },
                    TOKEN_INPUT_CHOICE_COLOR_WHITE_SELECTED_BACKGROUND: function() {
                        return aP
                    },
                    TOKEN_INPUT_CHOICE_COLOR_WHITE_SELECTED_FOREGROUND: function() {
                        return lP
                    },
                    TOKEN_INPUT_CHOICE_COLOR_WHITE_STATUS_ERROR_BACKGROUND: function() {
                        return dP
                    },
                    TOKEN_INPUT_CHOICE_COLOR_WHITE_STATUS_ERROR_FOREGROUND: function() {
                        return bP
                    },
                    TOKEN_INPUT_CHOICE_COLOR_WHITE_UNSELECTED_BACKGROUND: function() {
                        return mP
                    },
                    TOKEN_INPUT_CHOICE_COLOR_WHITE_UNSELECTED_FOREGROUND: function() {
                        return yP
                    },
                    TOKEN_INPUT_CHOICE_SIZE: function() {
                        return wP
                    },
                    TOKEN_INPUT_CHOICE_STATUS_DISABLED_OPACITY: function() {
                        return gP
                    },
                    TOKEN_INPUT_SEARCH_BORDER_RADIUS_ROUNDED: function() {
                        return QP
                    },
                    TOKEN_INPUT_SEARCH_BORDER_RADIUS_SQUARED: function() {
                        return hP
                    },
                    TOKEN_INPUT_SEARCH_CLEAR_COLOR: function() {
                        return JP
                    },
                    TOKEN_INPUT_SEARCH_CLEAR_MARGIN_RIGHT: function() {
                        return kP
                    },
                    TOKEN_INPUT_SEARCH_CLEAR_SIZE: function() {
                        return vP
                    },
                    TOKEN_INPUT_SEARCH_HEIGHT: function() {
                        return jP
                    },
                    TOKEN_INPUT_SEARCH_ICON_COLOR: function() {
                        return qP
                    },
                    TOKEN_INPUT_SEARCH_ICON_MARGIN_LEFT: function() {
                        return zP
                    },
                    TOKEN_INPUT_SEARCH_ICON_MARGIN_RIGHT: function() {
                        return $P
                    },
                    TOKEN_INPUT_SEARCH_ICON_SIZE: function() {
                        return _U
                    },
                    TOKEN_INPUT_SEARCH_INPUT_MARGIN_RIGHT: function() {
                        return OU
                    },
                    TOKEN_INPUT_SEARCH_INPUT_PLACEHOLDER_COLOR: function() {
                        return TU
                    },
                    TOKEN_INPUT_SEARCH_INPUT_TEXT_COLOR: function() {
                        return EU
                    },
                    TOKEN_INPUT_TOGGLE_ANIMATION_TRANSITION_DURATION: function() {
                        return nU
                    },
                    TOKEN_INPUT_TOGGLE_BORDER_WIDTH: function() {
                        return NU
                    },
                    TOKEN_INPUT_TOGGLE_COLOR_BASE_SELECTED: function() {
                        return CU
                    },
                    TOKEN_INPUT_TOGGLE_COLOR_BASE_SELECTED_BACKGROUND: function() {
                        return AU
                    },
                    TOKEN_INPUT_TOGGLE_COLOR_BASE_SELECTED_BORDER: function() {
                        return SU
                    },
                    TOKEN_INPUT_TOGGLE_COLOR_BASE_SELECTED_THUMB: function() {
                        return RU
                    },
                    TOKEN_INPUT_TOGGLE_COLOR_BASE_UNSELECTED: function() {
                        return IU
                    },
                    TOKEN_INPUT_TOGGLE_COLOR_BASE_UNSELECTED_BACKGROUND: function() {
                        return tU
                    },
                    TOKEN_INPUT_TOGGLE_COLOR_BASE_UNSELECTED_BORDER: function() {
                        return uU
                    },
                    TOKEN_INPUT_TOGGLE_COLOR_BASE_UNSELECTED_THUMB: function() {
                        return rU
                    },
                    TOKEN_INPUT_TOGGLE_HEIGHT: function() {
                        return LU
                    },
                    TOKEN_INPUT_TOGGLE_THUMB_SIZE: function() {
                        return KU
                    },
                    TOKEN_INPUT_TOGGLE_WIDTH: function() {
                        return MU
                    },
                    TOKEN_INTEREST_CATEGORY_BOOKS_BACKGROUND_COLOR_SELECTED: function() {
                        return eU
                    },
                    TOKEN_INTEREST_CATEGORY_BOOKS_BACKGROUND_COLOR_UNSELECTED: function() {
                        return FU
                    },
                    TOKEN_INTEREST_CATEGORY_CINEMA_BACKGROUND_COLOR_SELECTED: function() {
                        return DU
                    },
                    TOKEN_INTEREST_CATEGORY_CINEMA_BACKGROUND_COLOR_UNSELECTED: function() {
                        return iU
                    },
                    TOKEN_INTEREST_CATEGORY_CUSTOM_BACKGROUND_COLOR_SELECTED: function() {
                        return cU
                    },
                    TOKEN_INTEREST_CATEGORY_CUSTOM_BACKGROUND_COLOR_UNSELECTED: function() {
                        return oU
                    },
                    TOKEN_INTEREST_CATEGORY_FASHION_BACKGROUND_COLOR_SELECTED: function() {
                        return fU
                    },
                    TOKEN_INTEREST_CATEGORY_FASHION_BACKGROUND_COLOR_UNSELECTED: function() {
                        return GU
                    },
                    TOKEN_INTEREST_CATEGORY_FOOD_BACKGROUND_COLOR_SELECTED: function() {
                        return BU
                    },
                    TOKEN_INTEREST_CATEGORY_FOOD_BACKGROUND_COLOR_UNSELECTED: function() {
                        return PU
                    },
                    TOKEN_INTEREST_CATEGORY_GAMES_BACKGROUND_COLOR_SELECTED: function() {
                        return UU
                    },
                    TOKEN_INTEREST_CATEGORY_GAMES_BACKGROUND_COLOR_UNSELECTED: function() {
                        return HU
                    },
                    TOKEN_INTEREST_CATEGORY_HOBBY_BACKGROUND_COLOR_SELECTED: function() {
                        return pU
                    },
                    TOKEN_INTEREST_CATEGORY_HOBBY_BACKGROUND_COLOR_UNSELECTED: function() {
                        return xU
                    },
                    TOKEN_INTEREST_CATEGORY_JOBS_BACKGROUND_COLOR_SELECTED: function() {
                        return YU
                    },
                    TOKEN_INTEREST_CATEGORY_JOBS_BACKGROUND_COLOR_UNSELECTED: function() {
                        return VU
                    },
                    TOKEN_INTEREST_CATEGORY_MUSIC_BACKGROUND_COLOR_SELECTED: function() {
                        return WU
                    },
                    TOKEN_INTEREST_CATEGORY_MUSIC_BACKGROUND_COLOR_UNSELECTED: function() {
                        return ZU
                    },
                    TOKEN_INTEREST_CATEGORY_NONE_BACKGROUND_COLOR_SELECTED: function() {
                        return XU
                    },
                    TOKEN_INTEREST_CATEGORY_NONE_BACKGROUND_COLOR_UNSELECTED: function() {
                        return sU
                    },
                    TOKEN_INTEREST_CATEGORY_OTHER_BACKGROUND_COLOR_SELECTED: function() {
                        return aU
                    },
                    TOKEN_INTEREST_CATEGORY_OTHER_BACKGROUND_COLOR_UNSELECTED: function() {
                        return lU
                    },
                    TOKEN_INTEREST_CATEGORY_SPORTS_BACKGROUND_COLOR_SELECTED: function() {
                        return dU
                    },
                    TOKEN_INTEREST_CATEGORY_SPORTS_BACKGROUND_COLOR_UNSELECTED: function() {
                        return bU
                    },
                    TOKEN_INTEREST_CATEGORY_TRAVEL_BACKGROUND_COLOR_SELECTED: function() {
                        return mU
                    },
                    TOKEN_INTEREST_CATEGORY_TRAVEL_BACKGROUND_COLOR_UNSELECTED: function() {
                        return yU
                    },
                    TOKEN_INTEREST_LARGE_BORDER_RADIUS: function() {
                        return wU
                    },
                    TOKEN_INTEREST_LARGE_HEIGHT: function() {
                        return gU
                    },
                    TOKEN_INTEREST_LARGE_PADDING_HORIZONTAL: function() {
                        return QU
                    },
                    TOKEN_INTEREST_NORMAL_BORDER_RADIUS: function() {
                        return hU
                    },
                    TOKEN_INTEREST_NORMAL_HEIGHT: function() {
                        return JU
                    },
                    TOKEN_INTEREST_NORMAL_PADDING_HORIZONTAL: function() {
                        return kU
                    },
                    TOKEN_INTEREST_TEXT_COLOR_SELECTED: function() {
                        return vU
                    },
                    TOKEN_INTEREST_TEXT_COLOR_UNSELECTED: function() {
                        return jU
                    },
                    TOKEN_INTEREST_TEXT_OPTICAL_COMPENSATION_SHIFT: function() {
                        return qU
                    },
                    TOKEN_LIFESTYLEBADGE_BASE_BACKGROUND_COLOR: function() {
                        return zU
                    },
                    TOKEN_LIFESTYLEBADGE_BASE_TEXT_COLOR: function() {
                        return $U
                    },
                    TOKEN_LIFESTYLEBADGE_BORDER_RADIUS: function() {
                        return _H
                    },
                    TOKEN_LIFESTYLEBADGE_DISABLED_BACKGROUND_COLOR: function() {
                        return OH
                    },
                    TOKEN_LIFESTYLEBADGE_DISABLED_TEXT_COLOR: function() {
                        return TH
                    },
                    TOKEN_LIFESTYLEBADGE_HEIGHT: function() {
                        return EH
                    },
                    TOKEN_LIFESTYLEBADGE_ICON_SIZE: function() {
                        return nH
                    },
                    TOKEN_LIFESTYLEBADGE_LARGE_BORDER_RADIUS: function() {
                        return NH
                    },
                    TOKEN_LIFESTYLEBADGE_LARGE_HEIGHT: function() {
                        return CH
                    },
                    TOKEN_LIFESTYLEBADGE_LARGE_PADDING_END: function() {
                        return AH
                    },
                    TOKEN_LIFESTYLEBADGE_LARGE_PADDING_START: function() {
                        return SH
                    },
                    TOKEN_LIFESTYLEBADGE_NORMAL_BORDER_RADIUS: function() {
                        return RH
                    },
                    TOKEN_LIFESTYLEBADGE_NORMAL_HEIGHT: function() {
                        return IH
                    },
                    TOKEN_LIFESTYLEBADGE_NORMAL_PADDING_END: function() {
                        return tH
                    },
                    TOKEN_LIFESTYLEBADGE_NORMAL_PADDING_START: function() {
                        return uH
                    },
                    TOKEN_LIFESTYLEBADGE_PADDING_END: function() {
                        return rH
                    },
                    TOKEN_LIFESTYLEBADGE_PADDING_START: function() {
                        return LH
                    },
                    TOKEN_LIFESTYLEBADGE_SELECTED_BACKGROUND_COLOR: function() {
                        return KH
                    },
                    TOKEN_LIFESTYLEBADGE_SELECTED_TEXT_COLOR: function() {
                        return MH
                    },
                    TOKEN_LIFESTYLEBADGE_SPACING_ICON_TEXT: function() {
                        return eH
                    },
                    TOKEN_LINE_HEIGHT_ACTION: function() {
                        return FH
                    },
                    TOKEN_LINE_HEIGHT_ACTION_MINI: function() {
                        return DH
                    },
                    TOKEN_LINE_HEIGHT_ACTION_SMALL: function() {
                        return iH
                    },
                    TOKEN_LINE_HEIGHT_DISPLAY_1: function() {
                        return cH
                    },
                    TOKEN_LINE_HEIGHT_DISPLAY_2: function() {
                        return oH
                    },
                    TOKEN_LINE_HEIGHT_DISPLAY_3: function() {
                        return fH
                    },
                    TOKEN_LINE_HEIGHT_HEADER_1: function() {
                        return GH
                    },
                    TOKEN_LINE_HEIGHT_HEADER_2: function() {
                        return BH
                    },
                    TOKEN_LINE_HEIGHT_HEADER_3: function() {
                        return PH
                    },
                    TOKEN_LINE_HEIGHT_HEADER_4: function() {
                        return UH
                    },
                    TOKEN_LINE_HEIGHT_PARAGRAPH_1: function() {
                        return HH
                    },
                    TOKEN_LINE_HEIGHT_PARAGRAPH_1_BOLDER: function() {
                        return pH
                    },
                    TOKEN_LINE_HEIGHT_PARAGRAPH_2: function() {
                        return xH
                    },
                    TOKEN_LINE_HEIGHT_PARAGRAPH_2_BOLDER: function() {
                        return YH
                    },
                    TOKEN_LINE_HEIGHT_PARAGRAPH_3: function() {
                        return VH
                    },
                    TOKEN_LINE_HEIGHT_PARAGRAPH_3_BOLDER: function() {
                        return WH
                    },
                    TOKEN_LINE_HEIGHT_TITLE: function() {
                        return ZH
                    },
                    TOKEN_LISTBOX_BORDER_COLOR: function() {
                        return XH
                    },
                    TOKEN_LISTBOX_BORDER_RADIUS: function() {
                        return sH
                    },
                    TOKEN_LISTBOX_BORDER_WIDTH: function() {
                        return aH
                    },
                    TOKEN_LISTBOX_HINT_PADDING_HORIZONTAL: function() {
                        return lH
                    },
                    TOKEN_LISTBOX_HINT_PADDING_VERTICAL: function() {
                        return dH
                    },
                    TOKEN_LISTBOX_HINT_TEXT_COLOR: function() {
                        return bH
                    },
                    TOKEN_LISTBOX_ITEM_BASE_BACKGROUND_COLOR: function() {
                        return mH
                    },
                    TOKEN_LISTBOX_ITEM_BASE_TEXT_COLOR: function() {
                        return yH
                    },
                    TOKEN_LISTBOX_ITEM_ICON_MARGIN_START: function() {
                        return wH
                    },
                    TOKEN_LISTBOX_ITEM_ICON_SIZE: function() {
                        return gH
                    },
                    TOKEN_LISTBOX_ITEM_PADDING_HORIZONTAL: function() {
                        return QH
                    },
                    TOKEN_LISTBOX_ITEM_PADDING_VERTICAL: function() {
                        return hH
                    },
                    TOKEN_LISTBOX_ITEM_SELECTED_BACKGROUND_COLOR: function() {
                        return JH
                    },
                    TOKEN_LISTBOX_ITEM_SELECTED_TEXT_COLOR: function() {
                        return kH
                    },
                    TOKEN_LISTBOX_PADDING_VERTICAL: function() {
                        return vH
                    },
                    TOKEN_MARK_BORDER_RADIUS: function() {
                        return jH
                    },
                    TOKEN_MARK_ICON_SIZE: function() {
                        return qH
                    },
                    TOKEN_MARK_PADDING_HORIZONTAL: function() {
                        return zH
                    },
                    TOKEN_MARK_SHADOW_BLUR_RADIUS: function() {
                        return $H
                    },
                    TOKEN_MARK_SHADOW_COLOR: function() {
                        return _p
                    },
                    TOKEN_MARK_SHADOW_OPACITY: function() {
                        return Op
                    },
                    TOKEN_MARK_SHADOW_VERTICAL_OFFSET: function() {
                        return Tp
                    },
                    TOKEN_MARK_SIZE: function() {
                        return Ep
                    },
                    TOKEN_MARK_SPACING_ICON_TEXT: function() {
                        return np
                    },
                    TOKEN_MATCH_PHOTOS_BORDER_COLOR: function() {
                        return Np
                    },
                    TOKEN_MATCH_PHOTOS_BORDER_RADIUS: function() {
                        return Cp
                    },
                    TOKEN_MATCH_PHOTOS_ICON_TO_IMAGE_SIZE_RATIO: function() {
                        return Ap
                    },
                    TOKEN_MATCH_PHOTOS_IMAGE_LEFT_ROTATE: function() {
                        return Sp
                    },
                    TOKEN_MATCH_PHOTOS_IMAGE_LEFT_STACK_INDEX: function() {
                        return Rp
                    },
                    TOKEN_MATCH_PHOTOS_IMAGE_LEFT_TRANSLATE_X: function() {
                        return Ip
                    },
                    TOKEN_MATCH_PHOTOS_IMAGE_LEFT_TRANSLATE_Y: function() {
                        return tp
                    },
                    TOKEN_MATCH_PHOTOS_IMAGE_RIGHT_ROTATE: function() {
                        return up
                    },
                    TOKEN_MATCH_PHOTOS_IMAGE_RIGHT_STACK_INDEX: function() {
                        return rp
                    },
                    TOKEN_MATCH_PHOTOS_IMAGE_RIGHT_TRANSLATE_X: function() {
                        return Lp
                    },
                    TOKEN_MATCH_PHOTOS_IMAGE_RIGHT_TRANSLATE_Y: function() {
                        return Kp
                    },
                    TOKEN_MATCH_PHOTOS_LG_BORDER_WIDTH: function() {
                        return Mp
                    },
                    TOKEN_MATCH_PHOTOS_LG_IMAGE_SIZE: function() {
                        return ep
                    },
                    TOKEN_MATCH_PHOTOS_MD_BORDER_WIDTH: function() {
                        return Fp
                    },
                    TOKEN_MATCH_PHOTOS_MD_IMAGE_SIZE: function() {
                        return Dp
                    },
                    TOKEN_MATCH_PHOTOS_XLG_BORDER_WIDTH: function() {
                        return ip
                    },
                    TOKEN_MATCH_PHOTOS_XLG_IMAGE_SIZE: function() {
                        return cp
                    },
                    TOKEN_MOCKCARD_BORDER_COLOR: function() {
                        return op
                    },
                    TOKEN_MOCKCARD_BORDER_RADIUS_ROUNDED: function() {
                        return fp
                    },
                    TOKEN_MOCKCARD_BORDER_RADIUS_SQUARED: function() {
                        return Gp
                    },
                    TOKEN_MOCKCARD_BORDER_WIDTH: function() {
                        return Bp
                    },
                    TOKEN_MOCKCARD_CLOSE_ICON_MARGIN_RIGHT: function() {
                        return Pp
                    },
                    TOKEN_MOCKCARD_CLOSE_ICON_MARGIN_TOP: function() {
                        return Up
                    },
                    TOKEN_MOCKCARD_CLOSE_ICON_SIZE: function() {
                        return Hp
                    },
                    TOKEN_MOCKCARD_CORNER_ICON_COLOR: function() {
                        return pp
                    },
                    TOKEN_MOCKCARD_CORNER_ICON_SIZE: function() {
                        return xp
                    },
                    TOKEN_MOCKCARD_MIN_HEIGHT: function() {
                        return Yp
                    },
                    TOKEN_MOCKCARD_PADDING_HORIZONTAL: function() {
                        return Vp
                    },
                    TOKEN_MOCKCARD_PADDING_VERTICAL: function() {
                        return Wp
                    },
                    TOKEN_MOCKCARD_SPACING_ACTION_MARGIN_TOP: function() {
                        return Zp
                    },
                    TOKEN_MOCKCARD_SPACING_MEDIA_CONTENT: function() {
                        return Xp
                    },
                    TOKEN_MOCKCARD_SPACING_TITLE_TEXT: function() {
                        return sp
                    },
                    TOKEN_MOCKCARD_TEXT_MAX_LINES: function() {
                        return ap
                    },
                    TOKEN_MOCKCARD_TITLE_MAX_LINES: function() {
                        return lp
                    },
                    TOKEN_MODAL_BORDER_RADIUS: function() {
                        return dp
                    },
                    TOKEN_MODAL_BOTTOM_DRAWER_PADDING_EXTRA_BOTTOM: function() {
                        return bp
                    },
                    TOKEN_MODAL_BOTTOM_OUTSET_SPACE: function() {
                        return mp
                    },
                    TOKEN_MODAL_MAX_HEIGHT: function() {
                        return yp
                    },
                    TOKEN_MODAL_MAX_WIDTH: function() {
                        return wp
                    },
                    TOKEN_MODAL_NAVIGATION_ICON_COLOR: function() {
                        return gp
                    },
                    TOKEN_MODAL_NAVIGATION_ICON_SIZE: function() {
                        return Qp
                    },
                    TOKEN_MODAL_NAVIGATION_PADDING_BOTTOM: function() {
                        return hp
                    },
                    TOKEN_MODAL_PADDING_HORIZONTAL: function() {
                        return Jp
                    },
                    TOKEN_MODAL_PADDING_VERTICAL: function() {
                        return kp
                    },
                    TOKEN_MODAL_POPUP_OUTSET_SPACE: function() {
                        return vp
                    },
                    TOKEN_MODAL_SHADOW_OPACITY: function() {
                        return jp
                    },
                    TOKEN_NAVIGATION_BAR_BASE_SLOT_SIZE: function() {
                        return qp
                    },
                    TOKEN_NAVIGATION_BAR_BUTTON_TEXT_COLOR_BASE: function() {
                        return zp
                    },
                    TOKEN_NAVIGATION_BAR_COLOR_ACTIVE: function() {
                        return $p
                    },
                    TOKEN_NAVIGATION_BAR_COLOR_BASE: function() {
                        return _x
                    },
                    TOKEN_NAVIGATION_BAR_COLOR_DISABLED_OPACITY: function() {
                        return Ox
                    },
                    TOKEN_NAVIGATION_BAR_COLOR_INVERTED: function() {
                        return Tx
                    },
                    TOKEN_NAVIGATION_BAR_HEIGHT: function() {
                        return Ex
                    },
                    TOKEN_NAVIGATION_BAR_ICON_SIZE: function() {
                        return nx
                    },
                    TOKEN_NAVIGATION_BAR_LOGO_HEIGHT: function() {
                        return Nx
                    },
                    TOKEN_NAVIGATION_BAR_LOGO_WIDTH: function() {
                        return Cx
                    },
                    TOKEN_NAVIGATION_BAR_OPTICAL_HALF_GAP: function() {
                        return Ax
                    },
                    TOKEN_NAVIGATION_BAR_PROFILE_ADDITIONAL_COLOR: function() {
                        return Sx
                    },
                    TOKEN_NAVIGATION_BAR_PROFILE_AVATAR_SIZE: function() {
                        return Rx
                    },
                    TOKEN_NAVIGATION_BAR_PROFILE_INFO_COLOR: function() {
                        return Ix
                    },
                    TOKEN_NAVIGATION_BAR_PROFILE_SPACING_AVATAR_TEXT: function() {
                        return tx
                    },
                    TOKEN_NUDGE_BASE_BACKGROUND_COLOR: function() {
                        return ux
                    },
                    TOKEN_NUDGE_BASE_TEXT_COLOR: function() {
                        return rx
                    },
                    TOKEN_NUDGE_BORDER_RADIUS: function() {
                        return Lx
                    },
                    TOKEN_NUDGE_ICON_COLOR: function() {
                        return Kx
                    },
                    TOKEN_NUDGE_ICON_SIZE: function() {
                        return Mx
                    },
                    TOKEN_NUDGE_PADDING_HORIZONTAL: function() {
                        return ex
                    },
                    TOKEN_NUDGE_PADDING_VERTICAL: function() {
                        return Fx
                    },
                    TOKEN_NUDGE_SPACING_ACTION_MARGIN_TOP: function() {
                        return Dx
                    },
                    TOKEN_NUDGE_SPACING_HINT_MARGIN_TOP: function() {
                        return ix
                    },
                    TOKEN_NUDGE_SPACING_MEDIA_MARGIN_BOTTOM: function() {
                        return cx
                    },
                    TOKEN_NUDGE_SPACING_TITLE_TEXT: function() {
                        return ox
                    },
                    TOKEN_ONLINE_STATUS_COLOR_IDLE: function() {
                        return fx
                    },
                    TOKEN_ONLINE_STATUS_COLOR_ONLINE: function() {
                        return Gx
                    },
                    TOKEN_ONLINE_STATUS_SIZE: function() {
                        return Bx
                    },
                    TOKEN_PAGINATION_BAR_ACTION_PRESSED_SHIFT: function() {
                        return Px
                    },
                    TOKEN_PAGINATION_BAR_ACTION_SHADOW_BLUR_RADIUS: function() {
                        return Ux
                    },
                    TOKEN_PAGINATION_BAR_ACTION_SHADOW_COLOR: function() {
                        return Hx
                    },
                    TOKEN_PAGINATION_BAR_ACTION_SHADOW_OPACITY: function() {
                        return px
                    },
                    TOKEN_PAGINATION_BAR_ACTION_SHADOW_VERTICAL_OFFSET: function() {
                        return xx
                    },
                    TOKEN_PAGINATION_BAR_ACTION_SIZE: function() {
                        return Yx
                    },
                    TOKEN_PAGINATION_BAR_SPACING_ACTION_CONTENT: function() {
                        return Vx
                    },
                    TOKEN_PAGINATION_DOTS_ANIMATION_TIMING_TRANSITION: function() {
                        return Wx
                    },
                    TOKEN_PAGINATION_DOTS_DOT_EXPLORATION_SCALING_FACTOR_P1: function() {
                        return Zx
                    },
                    TOKEN_PAGINATION_DOTS_DOT_EXPLORATION_SCALING_FACTOR_P2: function() {
                        return Xx
                    },
                    TOKEN_PAGINATION_DOTS_DOT_EXPLORATION_SCALING_FACTOR_P3: function() {
                        return sx
                    },
                    TOKEN_PAGINATION_DOTS_DOT_EXPLORATION_SCALING_FACTOR_P4: function() {
                        return ax
                    },
                    TOKEN_PAGINATION_DOTS_DOT_GAP: function() {
                        return lx
                    },
                    TOKEN_PAGINATION_DOTS_DOT_OPACITY_ACTIVE: function() {
                        return dx
                    },
                    TOKEN_PAGINATION_DOTS_DOT_OPACITY_BASE: function() {
                        return bx
                    },
                    TOKEN_PAGINATION_DOTS_DOT_SIZE: function() {
                        return mx
                    },
                    TOKEN_PHONE_FIELD_COUNTRY_CODE_WIDTH: function() {
                        return yx
                    },
                    TOKEN_PHONE_FIELD_NUMBER_OVERLAP: function() {
                        return wx
                    },
                    TOKEN_PLACARD_BORDER_COLOR: function() {
                        return gx
                    },
                    TOKEN_PLACARD_BORDER_RADIUS: function() {
                        return Qx
                    },
                    TOKEN_PLACARD_BORDER_WIDTH: function() {
                        return hx
                    },
                    TOKEN_PLACARD_EXTRA_SIZE: function() {
                        return Jx
                    },
                    TOKEN_PLACARD_MEDIA_SIZE: function() {
                        return kx
                    },
                    TOKEN_PLACARD_PADDING_HORIZONTAL: function() {
                        return vx
                    },
                    TOKEN_PLACARD_PADDING_VERTICAL: function() {
                        return jx
                    },
                    TOKEN_PLACARD_SPACING_CONTENT_EXTRA: function() {
                        return qx
                    },
                    TOKEN_PLACARD_SPACING_MEDIA_CONTENT: function() {
                        return zx
                    },
                    TOKEN_PREFIXED_FIELD_ITEM_COLOR: function() {
                        return $x
                    },
                    TOKEN_PREFIXED_FIELD_ITEM_HORIZONTAL_GAP: function() {
                        return _Y
                    },
                    TOKEN_PROGRESS_BAR_HEIGHT: function() {
                        return OY
                    },
                    TOKEN_SCROLL_LIST_SPACING_LG: function() {
                        return TY
                    },
                    TOKEN_SCROLL_LIST_SPACING_MD: function() {
                        return EY
                    },
                    TOKEN_SCROLL_LIST_SPACING_SM: function() {
                        return nY
                    },
                    TOKEN_SCROLL_LIST_SPACING_XLG: function() {
                        return NY
                    },
                    TOKEN_SCROLL_LIST_SPACING_XXLG: function() {
                        return CY
                    },
                    TOKEN_SELECT_BASE_BACKGROUND_COLOR: function() {
                        return AY
                    },
                    TOKEN_SELECT_BASE_BORDER_COLOR: function() {
                        return SY
                    },
                    TOKEN_SELECT_BASE_BORDER_WIDTH: function() {
                        return RY
                    },
                    TOKEN_SELECT_BASE_TEXT_COLOR: function() {
                        return IY
                    },
                    TOKEN_SELECT_BORDER_RADIUS: function() {
                        return tY
                    },
                    TOKEN_SELECT_FOCUSED_BORDER_COLOR: function() {
                        return uY
                    },
                    TOKEN_SELECT_FOCUSED_BORDER_WIDTH: function() {
                        return rY
                    },
                    TOKEN_SELECT_FONT_FAMILY: function() {
                        return LY
                    },
                    TOKEN_SELECT_FONT_SIZE: function() {
                        return KY
                    },
                    TOKEN_SELECT_FONT_WEIGHT: function() {
                        return MY
                    },
                    TOKEN_SELECT_HEIGHT: function() {
                        return eY
                    },
                    TOKEN_SELECT_ICON_COLOR: function() {
                        return FY
                    },
                    TOKEN_SELECT_ICON_MARGIN_LEFT: function() {
                        return DY
                    },
                    TOKEN_SELECT_ICON_SIZE: function() {
                        return iY
                    },
                    TOKEN_SELECT_LINE_HEIGHT: function() {
                        return cY
                    },
                    TOKEN_SELECT_PADDING_HORIZONTAL: function() {
                        return oY
                    },
                    TOKEN_SELECT_STATUS_ERROR_BORDER_COLOR: function() {
                        return fY
                    },
                    TOKEN_SELECT_STATUS_ERROR_BORDER_WIDTH: function() {
                        return GY
                    },
                    TOKEN_SELECT_STATUS_SUCCESS_BORDER_COLOR: function() {
                        return BY
                    },
                    TOKEN_SELECT_STATUS_SUCCESS_BORDER_WIDTH: function() {
                        return PY
                    },
                    TOKEN_SHOWCASE_ITEM_TITLE_ICON_SIZE: function() {
                        return UY
                    },
                    TOKEN_SNACKPILL_BORDER_RADIUS: function() {
                        return HY
                    },
                    TOKEN_SNACKPILL_ICON_SIZE: function() {
                        return pY
                    },
                    TOKEN_SNACKPILL_PADDING_HORIZONTAL: function() {
                        return xY
                    },
                    TOKEN_SNACKPILL_PADDING_VERTICAL: function() {
                        return YY
                    },
                    TOKEN_SNACKPILL_SHADOW_BLUR_RADIUS: function() {
                        return VY
                    },
                    TOKEN_SNACKPILL_SHADOW_COLOR: function() {
                        return WY
                    },
                    TOKEN_SNACKPILL_SHADOW_OPACITY: function() {
                        return ZY
                    },
                    TOKEN_SNACKPILL_SHADOW_VERTICAL_OFFSET: function() {
                        return XY
                    },
                    TOKEN_SNACKPILL_SPACING_ICON_TEXT: function() {
                        return sY
                    },
                    TOKEN_SONGBOX_ACTION_PADDING: function() {
                        return aY
                    },
                    TOKEN_SONGBOX_BACKGROUND_COLOR: function() {
                        return lY
                    },
                    TOKEN_SONGBOX_BORDER_RADIUS: function() {
                        return dY
                    },
                    TOKEN_SONGBOX_PADDING: function() {
                        return bY
                    },
                    TOKEN_SONGBOX_SPACING_SONG_ACTION: function() {
                        return mY
                    },
                    TOKEN_SONGBUTTON_BACKGROUND_COLOR: function() {
                        return yY
                    },
                    TOKEN_SONGBUTTON_BORDER_COLOR: function() {
                        return wY
                    },
                    TOKEN_SONGBUTTON_BORDER_RADIUS: function() {
                        return gY
                    },
                    TOKEN_SONGBUTTON_BORDER_WIDTH: function() {
                        return QY
                    },
                    TOKEN_SONGBUTTON_SIZE: function() {
                        return hY
                    },
                    TOKEN_SONG_ARTIST_TEXT_OPACITY: function() {
                        return JY
                    },
                    TOKEN_SONG_MEDIA_BACKGROUND_COLOR: function() {
                        return kY
                    },
                    TOKEN_SONG_MEDIA_BACKGROUND_OPACITY: function() {
                        return vY
                    },
                    TOKEN_SONG_MEDIA_BORDER_RADIUS: function() {
                        return jY
                    },
                    TOKEN_SONG_MEDIA_ICON_SIZE: function() {
                        return qY
                    },
                    TOKEN_SONG_MEDIA_OVERLAY_COLOR: function() {
                        return zY
                    },
                    TOKEN_SONG_MEDIA_OVERLAY_OPACITY: function() {
                        return $Y
                    },
                    TOKEN_SONG_MEDIA_SIZE: function() {
                        return _V
                    },
                    TOKEN_SONG_SPACING_MEDIA_CONTENT: function() {
                        return OV
                    },
                    TOKEN_SONG_SPACING_TITLE_ARTIST: function() {
                        return TV
                    },
                    TOKEN_SONG_TITLE_ICON_MARGIN_RIGHT: function() {
                        return EV
                    },
                    TOKEN_SONG_TITLE_ICON_SIZE: function() {
                        return nV
                    },
                    TOKEN_SPACING_GAP: function() {
                        return NV
                    },
                    TOKEN_SPACING_LG: function() {
                        return CV
                    },
                    TOKEN_SPACING_MD: function() {
                        return AV
                    },
                    TOKEN_SPACING_SM: function() {
                        return SV
                    },
                    TOKEN_SPACING_XLG: function() {
                        return RV
                    },
                    TOKEN_SPACING_XSM: function() {
                        return IV
                    },
                    TOKEN_SPACING_XXLG: function() {
                        return tV
                    },
                    TOKEN_SPRINGBOX_SPACING_CONTENT_EXTRA: function() {
                        return uV
                    },
                    TOKEN_SPRINGBOX_SPACING_MEDIA_CONTENT: function() {
                        return rV
                    },
                    TOKEN_SPRINGBOX_SPACING_MEDIA_CONTENT_COMPACT: function() {
                        return LV
                    },
                    TOKEN_STACK_SPACING_COMPACT: function() {
                        return KV
                    },
                    TOKEN_STACK_SPACING_LOOSE: function() {
                        return MV
                    },
                    TOKEN_STICKER_LOADER_COLOR: function() {
                        return eV
                    },
                    TOKEN_STICKER_LOADER_MIN_SIZE: function() {
                        return FV
                    },
                    TOKEN_STICKER_LOADER_SIZE: function() {
                        return DV
                    },
                    TOKEN_TABBAR_COLOR_ACTIVE: function() {
                        return iV
                    },
                    TOKEN_TABBAR_COLOR_BASE: function() {
                        return cV
                    },
                    TOKEN_TABBAR_HEIGHT: function() {
                        return oV
                    },
                    TOKEN_TABBAR_LABEL_COLOR_ACTIVE: function() {
                        return fV
                    },
                    TOKEN_TABBAR_LABEL_COLOR_BASE: function() {
                        return GV
                    },
                    TOKEN_TABBAR_LABEL_FONT_FAMILY: function() {
                        return BV
                    },
                    TOKEN_TABBAR_LABEL_FONT_SIZE: function() {
                        return PV
                    },
                    TOKEN_TABBAR_LABEL_LINE_HEIGHT: function() {
                        return UV
                    },
                    TOKEN_TABBAR_MEDIA_COLOR_ACTIVE: function() {
                        return HV
                    },
                    TOKEN_TABBAR_MEDIA_COLOR_BASE: function() {
                        return pV
                    },
                    TOKEN_TABBAR_MEDIA_MARGIN_BOTTOM: function() {
                        return xV
                    },
                    TOKEN_TABBAR_MEDIA_SIZE: function() {
                        return YV
                    },
                    TOKEN_TABBAR_NOTIFICATION_CENTER_POSITION_LEFT: function() {
                        return VV
                    },
                    TOKEN_TABBAR_NOTIFICATION_CENTER_POSITION_TOP: function() {
                        return WV
                    },
                    TOKEN_TABBAR_PADDING_TOP: function() {
                        return ZV
                    },
                    TOKEN_TABS_ITEM_ACTIVE_DARK_COLOR: function() {
                        return XV
                    },
                    TOKEN_TABS_ITEM_ACTIVE_FEATURE_REVENUE_ALT_COLOR: function() {
                        return sV
                    },
                    TOKEN_TABS_ITEM_ACTIVE_LIGHT_COLOR: function() {
                        return aV
                    },
                    TOKEN_TABS_ITEM_ACTIVE_PRIMARY_COLOR: function() {
                        return lV
                    },
                    TOKEN_TABS_ITEM_BASE_DARK_COLOR: function() {
                        return dV
                    },
                    TOKEN_TABS_ITEM_BASE_LIGHT_COLOR: function() {
                        return bV
                    },
                    TOKEN_TABS_ITEM_BASE_LIGHT_OPACITY: function() {
                        return mV
                    },
                    TOKEN_TABS_ITEM_DISABLED_OPACITY: function() {
                        return yV
                    },
                    TOKEN_TABS_ITEM_MARK_MARGIN_LEFT: function() {
                        return wV
                    },
                    TOKEN_TABS_ITEM_MEDIA_DARK_ACTIVE_COLOR: function() {
                        return gV
                    },
                    TOKEN_TABS_ITEM_MEDIA_DARK_BASE_COLOR: function() {
                        return QV
                    },
                    TOKEN_TABS_ITEM_MEDIA_LIGHT_ACTIVE_COLOR: function() {
                        return hV
                    },
                    TOKEN_TABS_ITEM_MEDIA_LIGHT_BASE_COLOR: function() {
                        return JV
                    },
                    TOKEN_TABS_ITEM_MEDIA_MARGIN_BOTTOM: function() {
                        return kV
                    },
                    TOKEN_TABS_ITEM_MEDIA_SIZE: function() {
                        return vV
                    },
                    TOKEN_TABS_ITEM_MEDIUM_LABEL_FONT_FAMILY: function() {
                        return jV
                    },
                    TOKEN_TABS_ITEM_MEDIUM_LABEL_FONT_SIZE: function() {
                        return qV
                    },
                    TOKEN_TABS_ITEM_MEDIUM_LABEL_FONT_WEIGHT: function() {
                        return zV
                    },
                    TOKEN_TABS_ITEM_MEDIUM_LABEL_HEIGHT: function() {
                        return $V
                    },
                    TOKEN_TABS_ITEM_MEDIUM_LABEL_LINE_HEIGHT: function() {
                        return _W
                    },
                    TOKEN_TABS_ITEM_MEDIUM_PADDING_BOTTOM: function() {
                        return OW
                    },
                    TOKEN_TABS_ITEM_MEDIUM_PADDING_HORIZONTAL: function() {
                        return TW
                    },
                    TOKEN_TABS_ITEM_MEDIUM_PADDING_TOP: function() {
                        return EW
                    },
                    TOKEN_TABS_ITEM_MIN_WIDTH: function() {
                        return nW
                    },
                    TOKEN_TABS_ITEM_SMALL_LABEL_FONT_FAMILY: function() {
                        return NW
                    },
                    TOKEN_TABS_ITEM_SMALL_LABEL_FONT_SIZE: function() {
                        return CW
                    },
                    TOKEN_TABS_ITEM_SMALL_LABEL_FONT_WEIGHT: function() {
                        return AW
                    },
                    TOKEN_TABS_ITEM_SMALL_LABEL_HEIGHT: function() {
                        return SW
                    },
                    TOKEN_TABS_ITEM_SMALL_LABEL_LINE_HEIGHT: function() {
                        return RW
                    },
                    TOKEN_TABS_ITEM_SMALL_PADDING_BOTTOM: function() {
                        return IW
                    },
                    TOKEN_TABS_ITEM_SMALL_PADDING_HORIZONTAL: function() {
                        return tW
                    },
                    TOKEN_TABS_ITEM_SMALL_PADDING_TOP: function() {
                        return uW
                    },
                    TOKEN_TABS_ITEM_UNDERLINE_HEIGHT: function() {
                        return rW
                    },
                    TOKEN_TABS_PADDING_HORIZONTAL: function() {
                        return LW
                    },
                    TOKEN_TABS_SHADOW_DARK_COLOR: function() {
                        return KW
                    },
                    TOKEN_TABS_SHADOW_DARK_OPACITY: function() {
                        return MW
                    },
                    TOKEN_TABS_SHADOW_HEIGHT: function() {
                        return eW
                    },
                    TOKEN_TABS_SHADOW_LIGHT_COLOR: function() {
                        return FW
                    },
                    TOKEN_TABS_SHADOW_LIGHT_OPACITY: function() {
                        return DW
                    },
                    TOKEN_TEXT_AREA_BASE_BACKGROUND_COLOR: function() {
                        return iW
                    },
                    TOKEN_TEXT_AREA_BASE_BORDER_COLOR: function() {
                        return cW
                    },
                    TOKEN_TEXT_AREA_BASE_BORDER_WIDTH: function() {
                        return oW
                    },
                    TOKEN_TEXT_AREA_BASE_TEXT_COLOR: function() {
                        return fW
                    },
                    TOKEN_TEXT_AREA_BORDER_RADIUS: function() {
                        return GW
                    },
                    TOKEN_TEXT_AREA_FOCUSED_BORDER_COLOR: function() {
                        return BW
                    },
                    TOKEN_TEXT_AREA_FOCUSED_BORDER_WIDTH: function() {
                        return PW
                    },
                    TOKEN_TEXT_AREA_FONT_FAMILY: function() {
                        return UW
                    },
                    TOKEN_TEXT_AREA_FONT_SIZE: function() {
                        return HW
                    },
                    TOKEN_TEXT_AREA_FONT_WEIGHT: function() {
                        return pW
                    },
                    TOKEN_TEXT_AREA_LINE_HEIGHT: function() {
                        return xW
                    },
                    TOKEN_TEXT_AREA_MIN_HEIGHT: function() {
                        return YW
                    },
                    TOKEN_TEXT_AREA_PADDING_HORIZONTAL: function() {
                        return VW
                    },
                    TOKEN_TEXT_AREA_PADDING_VERTICAL: function() {
                        return WW
                    },
                    TOKEN_TEXT_AREA_STATUS_ERROR_BORDER_COLOR: function() {
                        return ZW
                    },
                    TOKEN_TEXT_AREA_STATUS_ERROR_BORDER_WIDTH: function() {
                        return XW
                    },
                    TOKEN_TEXT_AREA_STATUS_SUCCESS_BORDER_COLOR: function() {
                        return sW
                    },
                    TOKEN_TEXT_AREA_STATUS_SUCCESS_BORDER_WIDTH: function() {
                        return aW
                    },
                    TOKEN_TEXT_FIELD_BASE_BACKGROUND_COLOR: function() {
                        return lW
                    },
                    TOKEN_TEXT_FIELD_BASE_BORDER_COLOR: function() {
                        return dW
                    },
                    TOKEN_TEXT_FIELD_BASE_BORDER_WIDTH: function() {
                        return bW
                    },
                    TOKEN_TEXT_FIELD_BASE_TEXT_COLOR: function() {
                        return mW
                    },
                    TOKEN_TEXT_FIELD_BORDER_RADIUS: function() {
                        return yW
                    },
                    TOKEN_TEXT_FIELD_FOCUSED_BORDER_COLOR: function() {
                        return wW
                    },
                    TOKEN_TEXT_FIELD_FOCUSED_BORDER_WIDTH: function() {
                        return gW
                    },
                    TOKEN_TEXT_FIELD_FONT_FAMILY: function() {
                        return QW
                    },
                    TOKEN_TEXT_FIELD_FONT_SIZE: function() {
                        return hW
                    },
                    TOKEN_TEXT_FIELD_FONT_WEIGHT: function() {
                        return JW
                    },
                    TOKEN_TEXT_FIELD_HEIGHT: function() {
                        return kW
                    },
                    TOKEN_TEXT_FIELD_ICON_COLOR: function() {
                        return vW
                    },
                    TOKEN_TEXT_FIELD_ICON_SIZE: function() {
                        return jW
                    },
                    TOKEN_TEXT_FIELD_LINE_HEIGHT: function() {
                        return qW
                    },
                    TOKEN_TEXT_FIELD_PADDING_HORIZONTAL: function() {
                        return zW
                    },
                    TOKEN_TEXT_FIELD_SPACING_ICON_ACTION: function() {
                        return $W
                    },
                    TOKEN_TEXT_FIELD_STATUS_ERROR_BORDER_COLOR: function() {
                        return _Z
                    },
                    TOKEN_TEXT_FIELD_STATUS_ERROR_BORDER_WIDTH: function() {
                        return OZ
                    },
                    TOKEN_TEXT_FIELD_STATUS_SUCCESS_BORDER_COLOR: function() {
                        return TZ
                    },
                    TOKEN_TEXT_FIELD_STATUS_SUCCESS_BORDER_WIDTH: function() {
                        return EZ
                    },
                    TOKEN_TOOLTIP_ARROW_OFFSET: function() {
                        return nZ
                    },
                    TOKEN_TOOLTIP_ARROW_SIZE: function() {
                        return NZ
                    },
                    TOKEN_TOOLTIP_BACKGROUND_COLOR: function() {
                        return CZ
                    },
                    TOKEN_TOOLTIP_BORDER_RADIUS: function() {
                        return AZ
                    },
                    TOKEN_TOOLTIP_OFFSET: function() {
                        return SZ
                    },
                    TOKEN_TOOLTIP_PADDING_HORIZONTAL: function() {
                        return RZ
                    },
                    TOKEN_TOOLTIP_PADDING_VERTICAL: function() {
                        return IZ
                    },
                    TOKEN_TOOLTIP_SHADOW_BLUR_RADIUS: function() {
                        return tZ
                    },
                    TOKEN_TOOLTIP_SHADOW_COLOR: function() {
                        return uZ
                    },
                    TOKEN_TOOLTIP_SHADOW_OPACITY: function() {
                        return rZ
                    },
                    TOKEN_TOOLTIP_SHADOW_VERTICAL_OFFSET: function() {
                        return LZ
                    },
                    TOKEN_TOOLTIP_TEXT_COLOR: function() {
                        return KZ
                    },
                    TOKEN_USERCARD_ACTIONS_HEIGHT: function() {
                        return MZ
                    },
                    TOKEN_USERCARD_ACTION_ICON_SIZE: function() {
                        return eZ
                    },
                    TOKEN_USERCARD_BACKGROUND_COLOR: function() {
                        return FZ
                    },
                    TOKEN_USERCARD_BORDER_RADIUS: function() {
                        return DZ
                    },
                    TOKEN_USERCARD_CONTENT_INSET: function() {
                        return iZ
                    },
                    TOKEN_USERCARD_HALO_OPACITY: function() {
                        return cZ
                    },
                    TOKEN_USERCARD_HALO_WIDTH: function() {
                        return oZ
                    },
                    TOKEN_USERCARD_MEDIA_GRADIENT_BOTTOM_HEIGHT: function() {
                        return fZ
                    },
                    TOKEN_USERCARD_MEDIA_GRADIENT_BOTTOM_OPACITY: function() {
                        return GZ
                    },
                    TOKEN_USERCARD_MEDIA_GRADIENT_TOP_HEIGHT: function() {
                        return BZ
                    },
                    TOKEN_USERCARD_MEDIA_GRADIENT_TOP_OPACITY: function() {
                        return PZ
                    },
                    TOKEN_USERCARD_PORTRAIT_RATIO: function() {
                        return UZ
                    },
                    TOKEN_USERCARD_THIN_BORDER_OPACITY: function() {
                        return HZ
                    },
                    TOKEN_USERCARD_THIN_BORDER_WIDTH: function() {
                        return pZ
                    },
                    TOKEN_USERLIST_CELL_GAP_HORIZONTAL: function() {
                        return xZ
                    },
                    TOKEN_USERLIST_CELL_GAP_VERTICAL_CHESS: function() {
                        return YZ
                    },
                    TOKEN_USERLIST_CELL_GAP_VERTICAL_GRID: function() {
                        return VZ
                    },
                    TOKEN_USERLIST_CELL_MAX_WIDTH: function() {
                        return WZ
                    },
                    TOKEN_USERLIST_CELL_MEDIA_PORTRAIT_RATIO: function() {
                        return ZZ
                    },
                    TOKEN_USERLIST_CELL_MIN_WIDTH: function() {
                        return XZ
                    },
                    TOKEN_USERLIST_CELL_SHIFT_VERTICAL_CHESS: function() {
                        return sZ
                    },
                    TOKEN_USERLIST_CELL_TEXT_ICON_MARGIN_END: function() {
                        return aZ
                    },
                    TOKEN_USERLIST_CELL_TEXT_ICON_SIZE: function() {
                        return lZ
                    },
                    TOKEN_USERLIST_CELL_TEXT_MARGIN_TOP: function() {
                        return dZ
                    }
                });
                var E = "#121212",
                    n = "-2px",
                    N = "2px",
                    C = "#0974B0",
                    A = "-3px",
                    S = "2px",
                    R = "#0974B0",
                    I = "2px",
                    t = "1px",
                    u = "44px",
                    r = "24px",
                    L = "24px",
                    K = "center",
                    M = "#FFFFFF",
                    e = "#121212",
                    F = "16px",
                    D = "64px",
                    i = "12px",
                    c = "24px",
                    o = "24px",
                    f = "24px",
                    G = "8px",
                    B = "#F6F6F6",
                    P = "1px",
                    U = "#C8001A",
                    H = "#121212",
                    p = "48px",
                    x = "24px",
                    Y = "8px",
                    V = "12px",
                    W = "12px",
                    Z = "24px",
                    X = "16px",
                    s = "#F6F6F6",
                    a = "#121212",
                    l = "24px",
                    d = "24px",
                    b = "8px",
                    m = "24px",
                    y = "480px",
                    w = "8px",
                    g = "24px",
                    Q = "16px",
                    h = "12px",
                    J = "#E9D8FF",
                    k = "#121212",
                    v = "#121212",
                    j = "8px",
                    q = "24px",
                    z = "24px",
                    $ = "16px",
                    __ = "16px",
                    O_ = "#717171",
                    T_ = "4px",
                    E_ = "#121212",
                    n_ = "12px",
                    N_ = "24px",
                    C_ = "24px",
                    A_ = "16px",
                    S_ = "#121212",
                    R_ = "0.1",
                    I_ = "#121212",
                    t_ = "#121212",
                    u_ = "#C8001A",
                    r_ = "#121212",
                    L_ = "4px",
                    K_ = "16px",
                    M_ = "12px",
                    e_ = "#717171",
                    F_ = "#121212",
                    D_ = "#CCCCCC",
                    i_ = "16px",
                    c_ = "#717171",
                    o_ = "4px",
                    f_ = "#121212",
                    G_ = "#EAEAEA",
                    B_ = "#717171",
                    P_ = "#FF4000",
                    U_ = "#FF4278",
                    H_ = "#FF8201",
                    p_ = "#FFC831",
                    x_ = "#00CAA8",
                    Y_ = "#17D417",
                    V_ = "#B500E3",
                    W_ = "#1AB0FF",
                    Z_ = "#2B8CFC",
                    X_ = "22px",
                    s_ = "18px",
                    a_ = "44px",
                    l_ = "18px",
                    d_ = "16px",
                    b_ = "4px",
                    m_ = "4px",
                    y_ = "18px",
                    w_ = "16px",
                    g_ = "36px",
                    Q_ = "16px",
                    h_ = "12px",
                    J_ = "4px",
                    k_ = "4px",
                    v_ = "12px",
                    j_ = "12px",
                    q_ = "24px",
                    z_ = "12px",
                    $_ = "8px",
                    _O = "4px",
                    OO = "4px",
                    TO = "16px",
                    EO = "12px",
                    nO = "8px",
                    NO = "24px",
                    CO = "32px",
                    AO = "24px",
                    SO = "16px",
                    RO = "8px",
                    IO = "28px",
                    tO = "32px",
                    uO = "24px",
                    rO = "16px",
                    LO = "36px",
                    KO = "24px",
                    MO = "37.5%",
                    eO = "12px",
                    FO = "50%",
                    DO = "16%",
                    iO = "16px",
                    cO = "#C8001A",
                    oO = "#121212",
                    fO = "2.5px",
                    GO = "1.5px",
                    BO = "36px",
                    PO = "#000000",
                    UO = "0.4",
                    HO = "#121212",
                    pO = "0.4",
                    xO = "120px",
                    YO = "96px",
                    VO = "64px",
                    WO = "150px",
                    ZO = "32px",
                    XO = "24px",
                    sO = "12px",
                    aO = "480px",
                    lO = "26px",
                    dO = "52px",
                    bO = "22px",
                    mO = "24px",
                    yO = "32px",
                    wO = "8px",
                    gO = "8px",
                    QO = "22px",
                    hO = "44px",
                    JO = "22px",
                    kO = "24px",
                    vO = "32px",
                    jO = "4px",
                    qO = "8px",
                    zO = "0.7",
                    $O = "#000000",
                    _T = "0.05",
                    OT = "#000000",
                    TT = "0.1",
                    ET = "1px",
                    nT = "#FFFFFF",
                    NT = "250px",
                    CT = "12px",
                    AT = "8px",
                    ST = "#F6F6F6",
                    RT = "#121212",
                    IT = "#F3EAFF",
                    tT = "#121212",
                    uT = "19px",
                    rT = "4px",
                    LT = "80%",
                    KT = "#121212",
                    MT = "#121212",
                    eT = "#CCCCCC",
                    FT = "48px",
                    DT = "8px",
                    iT = "36px",
                    cT = "32px",
                    oT = "8px",
                    fT = "36px",
                    GT = "16px",
                    BT = "6px",
                    PT = "#FFFFFF",
                    UT = "0.04",
                    HT = "1px",
                    pT = "14px",
                    xT = "8px",
                    YT = "#000000",
                    VT = "0.08",
                    WT = "4px",
                    ZT = "28px",
                    XT = "12px",
                    sT = "#717171",
                    aT = "16px",
                    lT = "36px",
                    dT = "24px",
                    bT = "12px",
                    mT = "22.4px",
                    yT = "#FFFFFF",
                    wT = "#717171",
                    gT = "#121212",
                    QT = "#717171",
                    hT = "#F6F6F6",
                    JT = "#F6F6F6",
                    kT = "#121212",
                    vT = "#121212",
                    jT = "12px",
                    qT = "6px",
                    zT = "16px",
                    $T = "#717171",
                    _E = "250px",
                    OE = "80%",
                    TE = "16px",
                    EE = "2px",
                    nE = "40px",
                    NE = "32px",
                    CE = "false",
                    AE = "6px",
                    SE = "8px",
                    RE = "4px",
                    IE = "#FFFFFF",
                    tE = "#FFFFFF",
                    uE = "11px",
                    rE = "2px",
                    LE = "11px",
                    KE = "22px",
                    ME = "36px",
                    eE = "#717171",
                    FE = "#C8001A",
                    DE = "#717171",
                    iE = "#121212",
                    cE = "4px",
                    oE = "16px",
                    fE = "6px",
                    GE = "10px",
                    BE = "1px",
                    PE = "16.8px",
                    UE = "0.24",
                    HE = "1.5px",
                    pE = "3px",
                    xE = "8px",
                    YE = "18px",
                    VE = "48px",
                    WE = "46px",
                    ZE = "0.48",
                    XE = "90px",
                    sE = "12px",
                    aE = "8px",
                    lE = "12px",
                    dE = "22px",
                    bE = "#717171",
                    mE = "4px",
                    yE = "#121212",
                    wE = "#000000",
                    gE = "12px",
                    QE = "12px",
                    hE = "200px",
                    JE = "150px",
                    kE = "#121212",
                    vE = "4px",
                    jE = "#717171",
                    qE = "175%",
                    zE = "#121212",
                    $E = "4px",
                    _n = "#F6F6F6",
                    On = "22px",
                    Tn = "160px",
                    En = "#FFFFFF",
                    nn = "#F6F6F6",
                    Nn = "8px",
                    Cn = "#CCCCCC",
                    An = "#717171",
                    Sn = "36px",
                    Rn = "22px",
                    In = "10px",
                    tn = "4px",
                    un = "50%",
                    rn = "4px",
                    Ln = "32px",
                    Kn = "#121212",
                    Mn = "#121212",
                    en = "1px",
                    Fn = "2px",
                    Dn = "#121212",
                    cn = "24px",
                    on = "12px",
                    fn = "0.04",
                    Gn = "1px",
                    Bn = "8px",
                    Pn = "#000000",
                    Un = "0.08",
                    Hn = "4px",
                    pn = "40px",
                    xn = "0.16",
                    Yn = "-4px",
                    Vn = "22px",
                    Wn = "#F6F6F6",
                    Zn = "#121212",
                    Xn = "17px",
                    sn = "#F6F6F6",
                    an = "#CCCCCC",
                    ln = "34px",
                    dn = "15px",
                    bn = "6px",
                    mn = "14px",
                    yn = "30px",
                    wn = "18px",
                    gn = "8px",
                    Qn = "12px",
                    hn = "4px",
                    Jn = "8px",
                    kn = "3px",
                    vn = "10px",
                    jn = "16px",
                    qn = "6px",
                    zn = "#F3EAFF",
                    $n = "#121212",
                    _N = "11px",
                    ON = "5px",
                    TN = "12px",
                    EN = "22px",
                    nN = "12px",
                    NN = "6px",
                    CN = "8px",
                    AN = "4px",
                    SN = "#121212",
                    RN = "#C8001A",
                    IN = "#121212",
                    tN = "#121212",
                    uN = "#121212",
                    rN = "#121212",
                    LN = "#121212",
                    KN = "#121212",
                    MN = "#121212",
                    eN = "#121212",
                    FN = "#121212",
                    DN = "#121212",
                    iN = "#121212",
                    cN = "#E9D8FF",
                    oN = "#121212",
                    fN = "#FFA800",
                    GN = "#121212",
                    BN = "#121212",
                    PN = "#C8001A",
                    UN = "#FFFFFF",
                    HN = "#121212",
                    pN = "#121212",
                    xN = "#121212",
                    YN = "#121212",
                    VN = "#121212",
                    WN = "#E9D8FF",
                    ZN = "#E9D8FF",
                    XN = "#E9D8FF",
                    sN = "#29131D",
                    aN = "#FFFFFF",
                    lN = "#FFFFFF",
                    dN = "#FFFFFF",
                    bN = "#29131D",
                    mN = "#29131D",
                    yN = "#F3EAFF",
                    wN = "#E9D8FF",
                    gN = "#121212",
                    QN = "#121212",
                    hN = "#121212",
                    JN = "#E9D8FF",
                    kN = "#121212",
                    vN = "#121212",
                    jN = "#121212",
                    qN = "#121212",
                    zN = "#0974B0",
                    $N = "#0974B0",
                    _C = "#121212",
                    OC = "#5CA500",
                    TC = "#407300",
                    EC = "#121212",
                    nC = "#E9D8FF",
                    NC = "#F3EAFF",
                    CC = "#121212",
                    AC = "#C8001A",
                    SC = "#FFA800",
                    RC = "#B04F16",
                    IC = "#CCCCCC",
                    tC = "#F6F6F6",
                    uC = "#EAEAEA",
                    rC = "#CCCCCC",
                    LC = "#979797",
                    KC = "#717171",
                    MC = "#717171",
                    eC = "#F6F6F6",
                    FC = "#C8001A",
                    DC = "#FFA800",
                    iC = "#5CA500",
                    cC = "#C8001A",
                    oC = "#5CA500",
                    fC = "#C8001A",
                    GC = "#121212",
                    BC = "#121212",
                    PC = "#E9D8FF",
                    UC = "#E9D8FF",
                    HC = "#000000",
                    pC = "#1672E9",
                    xC = "#DC4A3D",
                    YC = "#D93175",
                    VC = "#0076B7",
                    WC = "#FF8201",
                    ZC = "#1DB954",
                    XC = "#1AB0FF",
                    sC = "#507299",
                    aC = "#F3EAFF",
                    lC = "#C8001A",
                    dC = "#C8001A",
                    bC = "#5CA500",
                    mC = "#407300",
                    yC = "#FFA800",
                    wC = "#B04F16",
                    gC = "#FFFFFF",
                    QC = "24px",
                    hC = "#E9D8FF",
                    JC = "#FFFFFF",
                    kC = "#121212",
                    vC = "#121212",
                    jC = "#121212",
                    qC = "#121212",
                    zC = "#121212",
                    $C = "#121212",
                    _A = "16px",
                    OA = "#14141433",
                    TA = "0px",
                    EA = "0px",
                    nA = "4px",
                    NA = "16px",
                    CA = "#1414140D",
                    AA = "0px",
                    SA = "0px",
                    RA = "4px",
                    IA = "16px",
                    tA = "40px",
                    uA = "24px",
                    rA = "12px",
                    LA = "2px",
                    KA = "16px",
                    MA = "16px",
                    eA = "p3",
                    FA = "p2-bolder",
                    DA = "1000px",
                    iA = "#F6F6F6",
                    cA = "#F6F6F6",
                    oA = "#1212120D",
                    fA = "#1212121A",
                    GA = "#F3EAFF",
                    BA = "#121212",
                    PA = "#121212",
                    UA = "#121212",
                    HA = "#121212",
                    pA = "24px",
                    xA = "24px",
                    YA = "8px",
                    VA = "16px",
                    WA = "12px",
                    ZA = "p2-bolder",
                    XA = "#1212120D",
                    sA = "#FFFFFF00",
                    aA = "#121212",
                    lA = "#717171",
                    dA = "#121212",
                    bA = "#121212",
                    mA = "#717171",
                    yA = "#121212",
                    wA = "16px",
                    gA = "16px",
                    QA = "24px",
                    hA = "12px",
                    JA = "8px",
                    kA = "4px",
                    vA = "4px",
                    jA = "24px",
                    qA = "16px",
                    zA = "p3",
                    $A = "p3",
                    _S = "h3",
                    OS = "p2-bolder",
                    TS = "32px",
                    ES = "0px",
                    nS = "#FFFFFF",
                    NS = "#12121299",
                    CS = "#121212",
                    AS = "24px",
                    SS = "16px",
                    RS = "24px",
                    IS = "24px",
                    tS = "1000px",
                    uS = "#121212",
                    rS = "#12121266",
                    LS = "#F3EAFF",
                    KS = "#F6F6F6",
                    MS = "#C8001A",
                    eS = "#C8001A99",
                    FS = "#1212120D",
                    DS = "#1212121A",
                    iS = "#121212",
                    cS = "#29131D",
                    oS = "#F3EAFF",
                    fS = "#FFFFFF00",
                    GS = "#FFFFFF",
                    BS = "#FFFFFF66",
                    PS = "#FFFFFF66",
                    US = "#FFFFFF",
                    HS = "#FFFFFF",
                    pS = "#121212",
                    xS = "#121212",
                    YS = "#FFFFFF",
                    VS = "#FFFFFF",
                    WS = "#FFFFFF",
                    ZS = "#FFFFFF",
                    XS = "#121212",
                    sS = "#121212",
                    aS = "#121212",
                    lS = "#121212",
                    dS = "#FFFFFF",
                    bS = "#FFFFFF",
                    mS = "#FFFFFF",
                    yS = "#121212",
                    wS = "#121212",
                    gS = "#FFFFFF",
                    QS = "#FFFFFF",
                    hS = "#FFFFFF",
                    JS = "#FFFFFF",
                    kS = "#121212",
                    vS = "#121212",
                    jS = "#121212",
                    qS = "#121212",
                    zS = "#FFFFFF",
                    $S = "12px",
                    _R = "16px",
                    OR = "12px",
                    TR = "16px",
                    ER = "4px",
                    nR = "4px",
                    NR = "8px",
                    CR = "16px",
                    AR = "4px",
                    SR = "8px",
                    RR = "p3",
                    IR = "p2-bolder",
                    tR = "#F6F6F6",
                    uR = "#E9D8FF",
                    rR = "#F3EAFF",
                    LR = "#FFFFFF",
                    KR = "#121212",
                    MR = "12px",
                    eR = "26px",
                    FR = "12px",
                    DR = "18px",
                    iR = "22px",
                    cR = "0px",
                    oR = "0px",
                    fR = "0px",
                    GR = "0px",
                    BR = "0px",
                    PR = "0px",
                    UR = "1px",
                    HR = "1px",
                    pR = "1px",
                    xR = "1px",
                    YR = "1px",
                    VR = "1px",
                    WR = "0px",
                    ZR = "0px",
                    XR = "0px",
                    sR = "0px",
                    aR = "0px",
                    lR = "0px",
                    dR = "#1212120D",
                    bR = "#1212121A",
                    mR = "#1212120D",
                    yR = "#FFFFFF0D",
                    wR = "#FFFFFF1A",
                    gR = "#1212121A",
                    QR = "#000000",
                    hR = "#121212",
                    JR = "#121212",
                    kR = "#C8001A",
                    vR = "#C8001A",
                    jR = "#1672E9",
                    qR = "#DC4A3D",
                    zR = "#D93175",
                    $R = "#FFFFFF",
                    _I = "#0076B7",
                    OI = "#FF8201",
                    TI = "#121212",
                    EI = "#1DB954",
                    nI = "#1AB0FF",
                    NI = "#507299",
                    CI = "#FFFFFF",
                    AI = "#FFFFFF00",
                    SI = "#FFFFFF00",
                    RI = "#FFFFFF",
                    II = "#FFFFFF00",
                    tI = "#FFFFFF",
                    uI = "#FFFFFF00",
                    rI = "#FFFFFF00",
                    LI = "#FFFFFF00",
                    KI = "#FFFFFF00",
                    MI = "#FFFFFF00",
                    eI = "#FFFFFF00",
                    FI = "#FFFFFF00",
                    DI = "#FFFFFF00",
                    iI = "#717171",
                    cI = "#C8001A",
                    oI = "#FFFFFF00",
                    fI = "#FFFFFF00",
                    GI = "#FFFFFF00",
                    BI = "#FFFFFF00",
                    PI = "#FFFFFF00",
                    UI = "#FFFFFF00",
                    HI = "#FFFFFF00",
                    pI = "#FFFFFF00",
                    xI = "#FFFFFF00",
                    YI = "#FFFFFF00",
                    VI = "#FFFFFF00",
                    WI = "#121212",
                    ZI = "#121212",
                    XI = "#C8001A",
                    sI = "#C8001A",
                    aI = "#FFFFFF",
                    lI = "#121212",
                    dI = "#FFFFFF00",
                    bI = "#717171",
                    mI = "#C8001A",
                    yI = "#FFFFFF00",
                    wI = "#FFFFFF",
                    gI = "#FFFFFF00",
                    QI = "#FFFFFF",
                    hI = "#FFFFFF",
                    JI = "#FFFFFF",
                    kI = "#FFFFFF",
                    vI = "#FFFFFF",
                    jI = "#FFFFFF",
                    qI = "#FFFFFF",
                    zI = "#FFFFFF",
                    $I = "#121212",
                    _t = "#FFFFFF",
                    Ot = "#FFFFFF",
                    Tt = "#FFFFFF",
                    Et = "#FFFFFF",
                    nt = "#FFFFFF",
                    Nt = "#FFFFFF",
                    Ct = "#121212",
                    At = "#121212",
                    St = "#C8001A",
                    Rt = "#C8001A",
                    It = "#FFFFFF",
                    tt = "#121212",
                    ut = "#121212",
                    rt = "#121212",
                    Lt = "#C8001A",
                    Kt = "#C8001A",
                    Mt = "#FFFFFF",
                    et = "#121212",
                    Ft = "#FFFFFF",
                    Dt = "#FFFFFF",
                    it = "#FFFFFF",
                    ct = "#FFFFFF",
                    ot = "#FFFFFF",
                    ft = "#FFFFFF",
                    Gt = "#FFFFFF",
                    Bt = "#FFFFFF",
                    Pt = "#121212",
                    Ut = "#FFFFFF",
                    Ht = "#FFFFFF",
                    pt = "#FFFFFF",
                    xt = "#FFFFFF",
                    Yt = "#FFFFFF",
                    Vt = "#FFFFFF",
                    Wt = "#121212",
                    Zt = "#121212",
                    Xt = "#C8001A",
                    st = "#C8001A",
                    at = "#FFFFFF",
                    lt = "#121212",
                    dt = "#121212",
                    bt = "#121212",
                    mt = "#C8001A",
                    yt = "#C8001A",
                    wt = "#FFFFFF",
                    gt = "#121212",
                    Qt = "22px",
                    ht = "12px",
                    Jt = "16px",
                    kt = "22px",
                    vt = "22px",
                    jt = "12px",
                    qt = "16px",
                    zt = "22px",
                    $t = "480px",
                    _u = "52px",
                    Ou = "24px",
                    Tu = "36px",
                    Eu = "44px",
                    nu = "8px",
                    Nu = "4px",
                    Cu = "4px",
                    Au = "8px",
                    Su = "32px",
                    Ru = "8px",
                    Iu = "16px",
                    tu = "32px",
                    uu = "8px",
                    ru = "32px",
                    Lu = "8px",
                    Ku = "4px",
                    Mu = "8px",
                    eu = "4px",
                    Fu = "4px",
                    Du = "16px",
                    iu = "4px",
                    cu = "8px",
                    ou = "32px",
                    fu = "4px",
                    Gu = "16px",
                    Bu = "4px",
                    Pu = "8px",
                    Uu = "12px",
                    Hu = "action",
                    pu = "p3",
                    xu = "action-small",
                    Yu = "action-small",
                    Vu = "8px",
                    Wu = "2px",
                    Zu = "0px",
                    Xu = "2px",
                    su = "#FFFFFF",
                    au = "#121212",
                    lu = "#FFFFFF",
                    du = "#C8001A",
                    bu = "#121212",
                    mu = "#717171",
                    yu = "#FFFFFF",
                    wu = "#FFFFFF",
                    gu = "#FFFFFF",
                    Qu = "24px",
                    hu = "#717171",
                    Ju = "#121212",
                    ku = "#121212",
                    vu = "48px",
                    ju = "72px",
                    qu = "24px",
                    zu = "72px",
                    $u = "16px",
                    _r = "12px",
                    Or = "8px",
                    Tr = "24px",
                    Er = "0px",
                    nr = "p1",
                    Nr = "h2",
                    Cr = "h1",
                    Ar = "1000px",
                    Sr = "2px",
                    Rr = "0px",
                    Ir = "#C8001A",
                    tr = "#C8001A",
                    ur = "#C8001A",
                    rr = "#FFFFFF",
                    Lr = "#FFFFFF",
                    Kr = "#FFFFFF",
                    Mr = "#FFFFFF",
                    er = "#FFFFFF",
                    Fr = "8px",
                    Dr = "4px",
                    ir = "4px",
                    cr = "caption",
                    or = "8px",
                    fr = "16px",
                    Gr = "0px",
                    Br = "2px",
                    Pr = "1px",
                    Ur = "2px",
                    Hr = "1px",
                    pr = "2px",
                    xr = "1px",
                    Yr = "#FFFFFF",
                    Vr = "#717171",
                    Wr = "#717171",
                    Zr = "#717171",
                    Xr = "#C8001A",
                    sr = "#C8001A",
                    ar = "#5CA500",
                    lr = "#5CA500",
                    dr = "#121212",
                    br = "#717171",
                    mr = "#C8001A",
                    yr = "#5CA500",
                    wr = "#121212",
                    gr = "#121212",
                    Qr = "#121212",
                    hr = "#121212",
                    Jr = "#121212",
                    kr = "#FFFFFF",
                    vr = "#717171",
                    jr = "#C8001A",
                    qr = "#5CA500",
                    zr = "#FFFFFF00",
                    $r = "#F6F6F6",
                    _L = "#121212",
                    OL = "#121212",
                    TL = "24px",
                    EL = "16px",
                    nL = "12px",
                    NL = "8px",
                    CL = "8px",
                    AL = "0px",
                    SL = "16px",
                    RL = "8px",
                    IL = "12px",
                    tL = "16px",
                    uL = "8px",
                    rL = "16px",
                    LL = "2px",
                    KL = "action",
                    ML = "p1-bolder",
                    eL = "p3",
                    FL = "p2-bolder",
                    DL = "p2-bolder",
                    iL = "p1-bolder",
                    cL = "p1-bolder",
                    oL = "32px",
                    fL = "#FFFFFF",
                    GL = "#5CA500",
                    BL = "#717171",
                    PL = "#C8001A",
                    UL = "#121212",
                    HL = "#121212",
                    pL = "#00000000",
                    xL = "#12121280",
                    YL = "48px",
                    VL = "16px",
                    WL = "12px",
                    ZL = "16px",
                    XL = "8px",
                    sL = "12px",
                    aL = "4px",
                    lL = "16px",
                    dL = "16px",
                    bL = "32px",
                    mL = "48px",
                    yL = "p1",
                    wL = "title",
                    gL = "1000px",
                    QL = "1px",
                    hL = "1px",
                    JL = "#FFFFFF",
                    kL = "#C8001A",
                    vL = "#C8001A",
                    jL = "#29131D",
                    qL = "#FFFFFF",
                    zL = "#CCCCCC",
                    $L = "#FFFFFF00",
                    _K = "#121212",
                    OK = "#FFFFFF",
                    TK = "#FFFFFF",
                    EK = "#FFFFFF",
                    nK = "#121212",
                    NK = "#121212",
                    CK = "#FFFFFF",
                    AK = "#FFFFFF",
                    SK = "#FFFFFF",
                    RK = "#121212",
                    IK = "16px",
                    tK = "#1414140D",
                    uK = "0px",
                    rK = "0px",
                    LK = "4px",
                    KK = "12px",
                    MK = "4px",
                    eK = "8px",
                    FK = "4px",
                    DK = "p3",
                    iK = "32px",
                    cK = "#FFFFFF",
                    oK = "#12121299",
                    fK = "24px",
                    GK = "16px",
                    BK = "24px",
                    PK = "#121212",
                    UK = "#717171",
                    HK = "#FFFFFF",
                    pK = "#717171",
                    xK = "#121212",
                    YK = "#121212",
                    VK = "#121212",
                    WK = "24px",
                    ZK = "12px",
                    XK = "8px",
                    sK = "0px",
                    aK = "16px",
                    lK = "0px",
                    dK = "16px",
                    bK = "8px",
                    mK = "8px",
                    yK = "4px",
                    wK = "p1",
                    gK = "p3",
                    QK = "p3-bolder",
                    hK = "h1",
                    JK = "title",
                    kK = "h2",
                    vK = "h3",
                    jK = "1px",
                    qK = "0px",
                    zK = "1px",
                    $K = "0px",
                    _M = "#121212",
                    OM = "#CCCCCC",
                    TM = "#121212",
                    EM = "#FFFFFF00",
                    nM = "#121212",
                    NM = "#717171",
                    CM = "#FFFFFF",
                    AM = "#717171",
                    SM = "8px",
                    RM = "4px",
                    IM = "2px",
                    tM = "8px",
                    uM = "1000px",
                    rM = "#F6F6F6",
                    LM = "#F6F6F6",
                    KM = "#121212",
                    MM = "#FFFFFF",
                    eM = "1000px",
                    FM = "#F6F6F6",
                    DM = "#F6F6F6",
                    iM = "#121212",
                    cM = "#FFFFFF",
                    oM = "1000px",
                    fM = "2px",
                    GM = "0px",
                    BM = "2px",
                    PM = "#FFFFFF",
                    UM = "#121212",
                    HM = "#FFFFFF",
                    pM = "#C8001A",
                    xM = "#121212",
                    YM = "#717171",
                    VM = "#FFFFFF",
                    WM = "#FFFFFF",
                    ZM = "#FFFFFF",
                    XM = "24px",
                    sM = "12px",
                    aM = "56.25%",
                    lM = "100%",
                    dM = "100%",
                    bM = "100%",
                    mM = "66.6%",
                    yM = "100%",
                    wM = "100%",
                    gM = "75%",
                    QM = "75%",
                    hM = "100%",
                    JM = "80%",
                    kM = "100%",
                    vM = "100%",
                    jM = "56.25%",
                    qM = "0px",
                    zM = "12px",
                    $M = "16px",
                    _e = "19px",
                    Oe = "24px",
                    Te = "32px",
                    Ee = "4px",
                    ne = "8px",
                    Ne = "1000px",
                    Ce = "0px",
                    Ae = "2px",
                    Se = "1px",
                    Re = "#717171",
                    Ie = "#FFFFFF",
                    te = "#121212",
                    ue = "#CCCCCC",
                    re = "#E9D8FF",
                    Le = "#B492DE",
                    Ke = "#600436",
                    Me = "#FFFFFF",
                    ee = "#C8001A",
                    Fe = "#CCCCCC",
                    De = "#121212",
                    ie = "#E9D8FF",
                    ce = "#F6F6F6",
                    oe = "#F3EAFF",
                    fe = "#E9D8FF",
                    Ge = "#FFFFFF00",
                    Be = "#E9D8FF",
                    Pe = "#121212",
                    Ue = "#C8001A",
                    He = "#FFFFFF",
                    pe = "#E9D8FF",
                    xe = "#B492DE",
                    Ye = "#121212",
                    Ve = "#29131D",
                    We = "#FFFFFF",
                    Ze = "#FFFFFF",
                    Xe = "#E9D8FF",
                    se = "#121212",
                    ae = "#600436",
                    le = "#F3EAFF",
                    de = "#FFFFFF",
                    be = "#29131D",
                    me = "#E9D8FF",
                    ye = "#FFFFFF",
                    we = "#0974B0",
                    ge = "#45B2EF",
                    Qe = "#0974B0",
                    he = "#BFE8FF",
                    Je = "#5CA500",
                    ke = "#407300",
                    ve = "#DFF2AF",
                    je = "#FF4B23",
                    qe = "#CD2500",
                    ze = "#FFBDB4",
                    $e = "#E9D8FF",
                    _F = "#B492DE",
                    OF = "#F3EAFF",
                    TF = "#C8001A",
                    EF = "#600436",
                    nF = "#FFB6C8",
                    NF = "#FFA800",
                    CF = "#B04F16",
                    AF = "#FFF1A4",
                    SF = "#C8001A",
                    RF = "#121212",
                    IF = "#CCCCCC",
                    tF = "#FFFFFF",
                    uF = "#121212",
                    rF = "#717171",
                    LF = "#E9D8FF",
                    KF = "#B492DE",
                    MF = "#600436",
                    eF = "#FFFFFF",
                    FF = "#12121299",
                    DF = "#00000000",
                    iF = "#12121280",
                    cF = "#121212",
                    oF = "#F6F6F6",
                    fF = "#1212120D",
                    GF = "#1212121A",
                    BF = "#FFFFFF0D",
                    PF = "#FFFFFF1A",
                    UF = "#000000",
                    HF = "#1672E9",
                    pF = "#DC4A3D",
                    xF = "#D93175",
                    YF = "#0076B7",
                    VF = "#FF8201",
                    WF = "#1DB954",
                    ZF = "#1AB0FF",
                    XF = "#507299",
                    sF = "#FFA800",
                    aF = "#FFF1A4",
                    lF = "#C8001A",
                    dF = "#FFB6C8",
                    bF = "#C8001A",
                    mF = "#5CA500",
                    yF = "#DFF2AF",
                    wF = "#121212",
                    gF = "#C8001A",
                    QF = "#717171",
                    hF = "#C8001A",
                    JF = "#FFFFFF",
                    kF = "#121212",
                    vF = "#5CA500",
                    jF = "#717171",
                    qF = "0%",
                    zF = "10%",
                    $F = "100%",
                    _D = "20%",
                    OD = "30%",
                    TD = "40%",
                    ED = "5%",
                    nD = "50%",
                    ND = "60%",
                    CD = "70%",
                    AD = "80%",
                    SD = "90%",
                    RD = "20px",
                    ID = "#14141433",
                    tD = "0px",
                    uD = "0px",
                    rD = "6px",
                    LD = "20px",
                    KD = "#1414144D",
                    MD = "0px",
                    eD = "0px",
                    FD = "6px",
                    DD = "0px",
                    iD = "#FFFFFF00",
                    cD = "0px",
                    oD = "0px",
                    fD = "0px",
                    GD = "16px",
                    BD = "#1414140D",
                    PD = "0px",
                    UD = "0px",
                    HD = "4px",
                    pD = "16px",
                    xD = "#14141433",
                    YD = "0px",
                    VD = "0px",
                    WD = "4px",
                    ZD = "0px",
                    XD = "100%",
                    sD = "12px",
                    aD = "16px",
                    lD = "2px",
                    dD = "20px",
                    bD = "24px",
                    mD = "32px",
                    yD = "4px",
                    wD = "40px",
                    gD = "48px",
                    QD = "56px",
                    hD = "6px",
                    JD = "64px",
                    kD = "72px",
                    vD = "8px",
                    jD = "80px",
                    qD = "0px",
                    zD = "1px",
                    $D = "12px",
                    _i = "16px",
                    Oi = "2px",
                    Ti = "20px",
                    Ei = "24px",
                    ni = "3px",
                    Ni = "32px",
                    Ci = "4px",
                    Ai = "40px",
                    Si = "48px",
                    Ri = "56px",
                    Ii = "8px",
                    ti = "Beausite Classic",
                    ui = "16px",
                    ri = "semibold",
                    Li = "22.4px",
                    Ki = "Beausite Classic",
                    Mi = "12px",
                    ei = "semibold",
                    Fi = "16.8px",
                    Di = "Beausite Classic",
                    ii = "14px",
                    ci = "semibold",
                    oi = "19.6px",
                    fi = "Beausite Classic",
                    Gi = "10px",
                    Bi = "medium",
                    Pi = "12px",
                    Ui = "Beausite Classic",
                    Hi = "60px",
                    pi = "bold",
                    xi = "67.2px",
                    Yi = "Beausite Classic",
                    Vi = "49px",
                    Wi = "bold",
                    Zi = "54.9px",
                    Xi = "Beausite Classic",
                    si = "34px",
                    ai = "bold",
                    li = "38.1px",
                    di = "Beausite Classic",
                    bi = "24px",
                    mi = "semibold",
                    yi = "28.8px",
                    wi = "Beausite Classic",
                    gi = "21px",
                    Qi = "semibold",
                    hi = "25.2px",
                    Ji = "Beausite Classic",
                    ki = "18px",
                    vi = "semibold",
                    ji = "21.6px",
                    qi = "Beausite Classic",
                    zi = "15px",
                    $i = "semibold",
                    _c = "18px",
                    Oc = "Beausite Classic",
                    Tc = "16px",
                    Ec = "medium",
                    nc = "22.4px",
                    Nc = "Beausite Classic",
                    Cc = "14px",
                    Ac = "medium",
                    Sc = "19.6px",
                    Rc = "Beausite Classic",
                    Ic = "12px",
                    tc = "medium",
                    uc = "16.8px",
                    rc = "Beausite Classic",
                    Lc = "16px",
                    Kc = "semibold",
                    Mc = "22.4px",
                    ec = "Beausite Classic",
                    Fc = "16px",
                    Dc = "clear",
                    ic = "22.4px",
                    cc = "Beausite Classic",
                    oc = "14px",
                    fc = "semibold",
                    Gc = "19.6px",
                    Bc = "Beausite Classic",
                    Pc = "14px",
                    Uc = "clear",
                    Hc = "19.6px",
                    pc = "Beausite Classic",
                    xc = "12px",
                    Yc = "semibold",
                    Vc = "16.8px",
                    Wc = "Beausite Classic",
                    Zc = "12px",
                    Xc = "clear",
                    sc = "16.8px",
                    ac = "Beausite Classic",
                    lc = "16px",
                    dc = "semibold",
                    bc = "19.2px",
                    mc = "#000000",
                    yc = "#1672E9",
                    wc = "#DC4A3D",
                    gc = "#D93175",
                    Qc = "#0076B7",
                    hc = "#FF8201",
                    Jc = "#1212120D",
                    kc = "#1212121A",
                    vc = "#1DB954",
                    jc = "#1AB0FF",
                    qc = "#507299",
                    zc = "#FFFFFF",
                    $c = "#FFFFFF",
                    _o = "#FFFFFF",
                    Oo = "#717171",
                    To = "#121212",
                    Eo = "#717171",
                    no = "#121212",
                    No = "24px",
                    Co = "4px",
                    Ao = "8px",
                    So = "2px",
                    Ro = "6px",
                    Io = "caption",
                    to = "1px",
                    uo = "2px",
                    ro = "1px",
                    Lo = "2px",
                    Ko = "#FFFFFF",
                    Mo = "#FFFFFF00",
                    eo = "#CCCCCC",
                    Fo = "#121212",
                    Do = "#FFFFFF",
                    io = "#FFFFFF",
                    co = "#717171",
                    oo = "#121212",
                    fo = "#FFFFFF",
                    Go = "#FFFFFF",
                    Bo = "#717171",
                    Po = "#121212",
                    Uo = "#FFFFFF",
                    Ho = "#FFFFFF",
                    po = "32px",
                    xo = "8px",
                    Yo = "16px",
                    Vo = "8px",
                    Wo = "16px",
                    Zo = "12px",
                    Xo = "action-small",
                    so = "24px",
                    ao = "#E9D8FF",
                    lo = "#FFFFFF",
                    bo = "#F6F6F6",
                    mo = "#121212",
                    yo = "#121212",
                    wo = "#121212",
                    go = "#FFFFFF",
                    Qo = "#CCCCCC",
                    ho = "#CCCCCC",
                    Jo = "#121212",
                    ko = "#121212",
                    vo = "#121212",
                    jo = "#121212",
                    qo = "#121212",
                    zo = "#121212",
                    $o = "#121212",
                    _f = "#121212",
                    Of = "#121212",
                    Tf = "20px",
                    Ef = "#14141433",
                    nf = "0px",
                    Nf = "0px",
                    Cf = "6px",
                    Af = "0px",
                    Sf = "#FFFFFF00",
                    Rf = "0px",
                    If = "0px",
                    tf = "0px",
                    uf = "16px",
                    rf = "40px",
                    Lf = "24px",
                    Kf = "12px",
                    Mf = "16px",
                    ef = "8px",
                    Ff = "2px",
                    Df = "16px",
                    cf = "16px",
                    of = "p2",
                    ff = "action-mini",
                    Gf = "p2-bolder",
                    Bf = "1000px",
                    Pf = "0px",
                    Uf = "2px",
                    Hf = "#121212",
                    pf = "#FFFFFF",
                    xf = "#FFFFFF00",
                    Yf = "#717171",
                    Vf = "#FFFFFF",
                    Wf = "#717171",
                    Zf = "16px",
                    Xf = "4px",
                    sf = "20px",
                    af = "20px",
                    lf = "4px",
                    df = "4px",
                    bf = "20px",
                    mf = "#F3EAFF",
                    yf = "#121212",
                    wf = "8px",
                    gf = "12px",
                    Qf = "16px",
                    hf = "12px",
                    Jf = "p3-bolder",
                    kf = "12px",
                    vf = "24px",
                    jf = "16px",
                    qf = "8px",
                    zf = "64px",
                    $f = "12px",
                    _G = "8px",
                    OG = "480px",
                    TG = "16px",
                    EG = "24px",
                    nG = "16px",
                    NG = "12px",
                    CG = "64px",
                    AG = "16px",
                    SG = "12px",
                    RG = "8px",
                    IG = "56px",
                    tG = "78px",
                    uG = "0.9s",
                    rG = "3.0s",
                    LG = "11px",
                    KG = "18px",
                    MG = "2px",
                    eG = "2px",
                    FG = "6px",
                    DG = "#FFFFFF",
                    iG = "12px",
                    cG = "#121212",
                    oG = "8px",
                    fG = "16px",
                    GG = "8px",
                    BG = "22px",
                    PG = "8px",
                    UG = "8px",
                    HG = "16px",
                    pG = "16px",
                    xG = "Beausite Classic",
                    YG = "Beausite Classic",
                    VG = "Beausite Classic",
                    WG = "Beausite Classic",
                    ZG = "Beausite Classic",
                    XG = "Beausite Classic",
                    sG = "Beausite Classic",
                    aG = "Beausite Classic",
                    lG = "Beausite Classic",
                    dG = "Beausite Classic",
                    bG = "Beausite Classic",
                    mG = "Beausite Classic",
                    yG = "Beausite Classic",
                    wG = "Beausite Classic",
                    gG = "Beausite Classic",
                    QG = "Beausite Classic",
                    hG = "Beausite Classic",
                    JG = "Beausite Classic",
                    kG = "16px",
                    vG = "12px",
                    jG = "14px",
                    qG = "60px",
                    zG = "49px",
                    $G = "34px",
                    _B = "24px",
                    OB = "21px",
                    TB = "18px",
                    EB = "15px",
                    nB = "16px",
                    NB = "16px",
                    CB = "14px",
                    AB = "14px",
                    SB = "12px",
                    RB = "12px",
                    IB = "16px",
                    tB = "semibold",
                    uB = "semibold",
                    rB = "semibold",
                    LB = "bold",
                    KB = "bold",
                    MB = "bold",
                    eB = "semibold",
                    FB = "semibold",
                    DB = "semibold",
                    iB = "semibold",
                    cB = "clear",
                    oB = "semibold",
                    fB = "clear",
                    GB = "semibold",
                    BB = "clear",
                    PB = "semibold",
                    UB = "semibold",
                    HB = "24px",
                    pB = "24px",
                    xB = "16px",
                    YB = "#121212",
                    VB = "8px",
                    WB = "480px",
                    ZB = "#C8001A",
                    XB = "#717171",
                    sB = "#5CA500",
                    aB = "8px",
                    lB = "8px",
                    dB = "16px",
                    bB = "8px",
                    mB = "12px",
                    yB = "16px",
                    wB = "#CCCCCC",
                    gB = "#FD7F7E",
                    QB = "#F99DF0",
                    hB = "#FF8201",
                    JB = "#FED759",
                    kB = "#15CC79",
                    vB = "#17D417",
                    jB = "#783BF9",
                    qB = "#44A3EA",
                    zB = "#2B8CFC",
                    $B = "8px",
                    _P = "4px",
                    OP = "1px",
                    TP = "12px",
                    EP = "Beausite Classic",
                    nP = "12px",
                    NP = "clear",
                    CP = "8px",
                    AP = "16.8px",
                    SP = "120px",
                    RP = "96px",
                    IP = "64px",
                    tP = "30px",
                    uP = "22px",
                    rP = "16px",
                    LP = "36px",
                    KP = "10px",
                    MP = "46px",
                    eP = "#FFFFFF",
                    FP = "24px",
                    DP = "24px",
                    iP = "#121212",
                    cP = "#121212",
                    oP = "16px",
                    fP = "16px",
                    GP = "48px",
                    BP = "16px",
                    PP = "16px",
                    UP = "8px",
                    HP = "12px",
                    pP = "#121212",
                    xP = "#FFFFFF",
                    YP = "#121212",
                    VP = "#FFFFFF",
                    WP = "#C8001A",
                    ZP = "#CCCCCC",
                    XP = "#FFFFFF",
                    sP = "#121212",
                    aP = "#121212",
                    lP = "#FFFFFF",
                    dP = "#FFFFFF",
                    bP = "#C8001A",
                    mP = "#00000000",
                    yP = "#FFFFFF",
                    wP = "24px",
                    gP = "0.5",
                    QP = "18px",
                    hP = "8px",
                    JP = "#121212",
                    kP = "8px",
                    vP = "20px",
                    jP = "36px",
                    qP = "#121212",
                    zP = "12px",
                    $P = "8px",
                    _U = "18px",
                    OU = "12px",
                    TU = "#717171",
                    EU = "#121212",
                    nU = "0.2s",
                    NU = "2px",
                    CU = "#121212",
                    AU = "#121212",
                    SU = "#00000000",
                    RU = "#FFFFFF",
                    IU = "#121212",
                    tU = "#FFFFFF",
                    uU = "#121212",
                    rU = "#121212",
                    LU = "24px",
                    KU = "16px",
                    MU = "40px",
                    eU = "#F3EAFF",
                    FU = "#F6F6F6",
                    DU = "#F3EAFF",
                    iU = "#F6F6F6",
                    cU = "#F3EAFF",
                    oU = "#F6F6F6",
                    fU = "#F3EAFF",
                    GU = "#F6F6F6",
                    BU = "#F3EAFF",
                    PU = "#F6F6F6",
                    UU = "#F3EAFF",
                    HU = "#F6F6F6",
                    pU = "#F3EAFF",
                    xU = "#F6F6F6",
                    YU = "#F3EAFF",
                    VU = "#F6F6F6",
                    WU = "#F3EAFF",
                    ZU = "#F6F6F6",
                    XU = "#F3EAFF",
                    sU = "#F6F6F6",
                    aU = "#F3EAFF",
                    lU = "#F6F6F6",
                    dU = "#F3EAFF",
                    bU = "#F6F6F6",
                    mU = "#F3EAFF",
                    yU = "#F6F6F6",
                    wU = "20px",
                    gU = "37px",
                    QU = "14px",
                    hU = "13px",
                    JU = "26px",
                    kU = "9px",
                    vU = "#121212",
                    jU = "#121212",
                    qU = "0px",
                    zU = "#F6F6F6",
                    $U = "#121212",
                    _H = "17px",
                    OH = "#F6F6F6",
                    TH = "#CCCCCC",
                    EH = "34px",
                    nH = "22px",
                    NH = "19px",
                    CH = "37px",
                    AH = "14px",
                    SH = "14px",
                    RH = "17px",
                    IH = "34px",
                    tH = "12px",
                    uH = "12px",
                    rH = "12px",
                    LH = "12px",
                    KH = "#F3EAFF",
                    MH = "#121212",
                    eH = "4px",
                    FH = "22.4px",
                    DH = "16.8px",
                    iH = "19.6px",
                    cH = "67.2px",
                    oH = "54.9px",
                    fH = "38.1px",
                    GH = "28.8px",
                    BH = "25.2px",
                    PH = "21.6px",
                    UH = "18px",
                    HH = "22.4px",
                    pH = "22.4px",
                    xH = "19.6px",
                    YH = "22.4px",
                    VH = "16.8px",
                    WH = "16.8px",
                    ZH = "19.2px",
                    XH = "#717171",
                    sH = "16px",
                    aH = "1px",
                    lH = "16px",
                    dH = "8px",
                    bH = "#717171",
                    mH = "#FFFFFF",
                    yH = "#121212",
                    wH = "12px",
                    gH = "16px",
                    QH = "16px",
                    hH = "8px",
                    JH = "#F6F6F6",
                    kH = "#121212",
                    vH = "8px",
                    jH = "12px",
                    qH = "12px",
                    zH = "6px",
                    $H = "4px",
                    _p = "#000000",
                    Op = "0.1",
                    Tp = "2px",
                    Ep = "24px",
                    np = "4px",
                    Np = "#00000000",
                    Cp = "16%",
                    Ap = "50%",
                    Sp = "-10",
                    Rp = "2",
                    Ip = "6%",
                    tp = "5%",
                    up = "10",
                    rp = "1",
                    Lp = "-6%",
                    Kp = "15%",
                    Mp = "0px",
                    ep = "128px",
                    Fp = "0px",
                    Dp = "96px",
                    ip = "0px",
                    cp = "168px",
                    op = "#121212",
                    fp = "12px",
                    Gp = "2px",
                    Bp = "5px",
                    Pp = "12px",
                    Up = "12px",
                    Hp = "24px",
                    pp = "#717171",
                    xp = "24px",
                    Yp = "200px",
                    Vp = "16px",
                    Wp = "16px",
                    Zp = "16px",
                    Xp = "16px",
                    sp = "6px",
                    ap = "2",
                    lp = "1",
                    dp = "32px",
                    bp = "24px",
                    mp = "16px",
                    yp = "90%",
                    wp = "528px",
                    gp = "#121212",
                    Qp = "24px",
                    hp = "12px",
                    Jp = "24px",
                    kp = "24px",
                    vp = "16px",
                    jp = "0.6",
                    qp = "40px",
                    zp = "#121212",
                    $p = "#121212",
                    _x = "#121212",
                    Ox = "0.4",
                    Tx = "#FFFFFF",
                    Ex = "50px",
                    nx = "24px",
                    Nx = "36px",
                    Cx = "36px",
                    Ax = "8px",
                    Sx = "#717171",
                    Rx = "36px",
                    Ix = "#121212",
                    tx = "8px",
                    ux = "#F6F6F6",
                    rx = "#121212",
                    Lx = "24px",
                    Kx = "#717171",
                    Mx = "24px",
                    ex = "24px",
                    Fx = "24px",
                    Dx = "16px",
                    ix = "16px",
                    cx = "8px",
                    ox = "6px",
                    fx = "#FFA800",
                    Gx = "#5CA500",
                    Bx = "6px",
                    Px = "2px",
                    Ux = "10px",
                    Hx = "#000000",
                    px = "0.08",
                    xx = "4px",
                    Yx = "48px",
                    Vx = "40px",
                    Wx = "0.3s",
                    Zx = "1",
                    Xx = "0.666",
                    sx = "0.333",
                    ax = "0",
                    lx = "4px",
                    dx = "1",
                    bx = "0.4",
                    mx = "6px",
                    yx = "110px",
                    wx = "2px",
                    gx = "#CCCCCC",
                    Qx = "24px",
                    hx = "1px",
                    Jx = "24px",
                    kx = "36px",
                    vx = "16px",
                    jx = "16px",
                    qx = "12px",
                    zx = "12px",
                    $x = "#121212",
                    _Y = "12px",
                    OY = "4px",
                    TY = "8px",
                    EY = "4px",
                    nY = "1px",
                    NY = "16px",
                    CY = "24px",
                    AY = "#FFFFFF",
                    SY = "#717171",
                    RY = "1px",
                    IY = "#121212",
                    tY = "16px",
                    uY = "#121212",
                    rY = "2px",
                    LY = "Beausite Classic",
                    KY = "16px",
                    MY = "clear",
                    eY = "56px",
                    FY = "#121212",
                    DY = "4px",
                    iY = "16px",
                    cY = "22.4px",
                    oY = "16px",
                    fY = "#C8001A",
                    GY = "2px",
                    BY = "#5CA500",
                    PY = "2px",
                    UY = "10px",
                    HY = "16px",
                    pY = "16px",
                    xY = "15px",
                    YY = "7px",
                    VY = "10px",
                    WY = "#000000",
                    ZY = "0.2",
                    XY = "5px",
                    sY = "5px",
                    aY = "6px",
                    lY = "#F6F6F6",
                    dY = "10px",
                    bY = "6px",
                    mY = "12px",
                    yY = "#FFFFFF",
                    wY = "#CCCCCC",
                    gY = "16px",
                    QY = "1px",
                    hY = "32px",
                    JY = "0.6",
                    kY = "#000000",
                    vY = "0.2",
                    jY = "0px",
                    qY = "12px",
                    zY = "#000000",
                    $Y = "0.2",
                    _V = "48px",
                    OV = "12px",
                    TV = "4px",
                    EV = "4px",
                    nV = "16px",
                    NV = "16px",
                    CV = "16px",
                    AV = "12px",
                    SV = "8px",
                    RV = "24px",
                    IV = "4px",
                    tV = "32px",
                    uV = "12px",
                    rV = "16px",
                    LV = "12px",
                    KV = "8px",
                    MV = "12px",
                    eV = "#CCCCCC",
                    FV = "15px",
                    DV = "25%",
                    iV = "#121212",
                    cV = "#717171",
                    oV = "48px",
                    fV = "#121212",
                    GV = "#717171",
                    BV = "system",
                    PV = "10px",
                    UV = "12px",
                    HV = "#121212",
                    pV = "#979797",
                    xV = "4px",
                    YV = "24px",
                    VV = "23px",
                    WV = "5px",
                    ZV = "6px",
                    XV = "#121212",
                    sV = "#121212",
                    aV = "#FFFFFF",
                    lV = "#121212",
                    dV = "#121212",
                    bV = "#FFFFFF",
                    mV = "1",
                    yV = "0.5",
                    wV = "8px",
                    gV = "#121212",
                    QV = "#121212",
                    hV = "#FFFFFF",
                    JV = "#FFFFFF",
                    kV = "4px",
                    vV = "24px",
                    jV = "Beausite Classic",
                    qV = "14px",
                    zV = "semibold",
                    $V = "24px",
                    _W = "19.6px",
                    OW = "12px",
                    TW = "16px",
                    EW = "12px",
                    nW = "44px",
                    NW = "Beausite Classic",
                    CW = "12px",
                    AW = "semibold",
                    SW = "24px",
                    RW = "16.8px",
                    IW = "12px",
                    tW = "8px",
                    uW = "12px",
                    rW = "3px",
                    LW = "16px",
                    KW = "#EAEAEA",
                    MW = "1",
                    eW = "1px",
                    FW = "#EAEAEA",
                    DW = "1",
                    iW = "#FFFFFF",
                    cW = "#717171",
                    oW = "1px",
                    fW = "#121212",
                    GW = "16px",
                    BW = "#121212",
                    PW = "2px",
                    UW = "Beausite Classic",
                    HW = "16px",
                    pW = "clear",
                    xW = "22.4px",
                    YW = "84px",
                    VW = "16px",
                    WW = "16px",
                    ZW = "#C8001A",
                    XW = "2px",
                    sW = "#5CA500",
                    aW = "2px",
                    lW = "#FFFFFF",
                    dW = "#717171",
                    bW = "1px",
                    mW = "#121212",
                    yW = "16px",
                    wW = "#121212",
                    gW = "2px",
                    QW = "Beausite Classic",
                    hW = "16px",
                    JW = "clear",
                    kW = "56px",
                    vW = "#121212",
                    jW = "24px",
                    qW = "22.4px",
                    zW = "16px",
                    $W = "8px",
                    _Z = "#C8001A",
                    OZ = "2px",
                    TZ = "#5CA500",
                    EZ = "2px",
                    nZ = "20px",
                    NZ = "14px",
                    CZ = "#E9D8FF",
                    AZ = "20px",
                    SZ = "16px",
                    RZ = "16px",
                    IZ = "12px",
                    tZ = "10px",
                    uZ = "#000000",
                    rZ = "0.08",
                    LZ = "4px",
                    KZ = "#121212",
                    MZ = "44px",
                    eZ = "22px",
                    FZ = "#F6F6F6",
                    DZ = "12px",
                    iZ = "8.6%",
                    cZ = ".8",
                    oZ = "2px",
                    fZ = "50%",
                    GZ = ".25",
                    BZ = "50%",
                    PZ = ".15",
                    UZ = "133.333%",
                    HZ = ".05",
                    pZ = "1px",
                    xZ = "12px",
                    YZ = "16px",
                    VZ = "16px",
                    WZ = "120px",
                    ZZ = "125%",
                    XZ = "80px",
                    sZ = "50%",
                    aZ = "4px",
                    lZ = "16px",
                    dZ = "8px"
            }
        }
    ]);
//# sourceMappingURL=2531.ce880a12e1577dd94301.js.map
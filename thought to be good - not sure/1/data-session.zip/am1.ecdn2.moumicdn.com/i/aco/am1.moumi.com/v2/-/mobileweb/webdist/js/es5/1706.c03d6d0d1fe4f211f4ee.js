var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "a4bd73a1-e9fd-4cf2-a7aa-d2c9e3239c08", e._sentryDebugIdIdentifier = "sentry-dbid-a4bd73a1-e9fd-4cf2-a7aa-d2c9e3239c08")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "a4bd73a1-e9fd-4cf2-a7aa-d2c9e3239c08", e._sentryDebugIdIdentifier = "sentry-dbid-a4bd73a1-e9fd-4cf2-a7aa-d2c9e3239c08")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [1706], {
            1725: function(e, t, r) {
                r.d(t, {
                    F: function() {
                        return s
                    }
                });
                var n = r(32017),
                    i = r(96540),
                    o = r(49134);

                function s(e, t, r) {
                    const [s, a] = (0, i.useState)((() => t(e))), c = (0, i.useCallback)((() => {
                        const i = t(e);
                        n(s, i) || (a(i), r && r())
                    }), [s, e, r]);
                    return (0, o.E)(c), [s, c]
                }
            },
            9534: function(e, t, r) {
                function n(e, t, r) {
                    const n = r.getRegistry(),
                        i = n.addTarget(e, t);
                    return [i, () => n.removeTarget(i)]
                }

                function i(e, t, r) {
                    const n = r.getRegistry(),
                        i = n.addSource(e, t);
                    return [i, () => n.removeSource(i)]
                }
                r.d(t, {
                    V: function() {
                        return i
                    },
                    l: function() {
                        return n
                    }
                })
            },
            19959: function(e, t, r) {
                r.d(t, {
                    Q: function() {
                        return me
                    }
                });
                var n = r(74848),
                    i = r(96540),
                    o = r(84931);
                const s = "dnd-core/INIT_COORDS",
                    a = "dnd-core/BEGIN_DRAG",
                    c = "dnd-core/PUBLISH_DRAG_SOURCE",
                    u = "dnd-core/HOVER",
                    d = "dnd-core/DROP",
                    l = "dnd-core/END_DRAG";

                function h(e, t) {
                    return {
                        type: s,
                        payload: {
                            sourceClientOffset: t || null,
                            clientOffset: e || null
                        }
                    }
                }

                function g(e) {
                    return "object" == typeof e
                }
                const f = {
                    type: s,
                    payload: {
                        clientOffset: null,
                        sourceClientOffset: null
                    }
                };

                function p(e) {
                    return function(t = [], r = {
                        publishSource: !0
                    }) {
                        const {
                            publishSource: n = !0,
                            clientOffset: i,
                            getSourceClientOffset: s
                        } = r, c = e.getMonitor(), u = e.getRegistry();
                        e.dispatch(h(i)),
                            function(e, t, r) {
                                (0, o.V)(!t.isDragging(), "Cannot call beginDrag while dragging."), e.forEach((function(e) {
                                    (0, o.V)(r.getSource(e), "Expected sourceIds to be registered.")
                                }))
                            }(t, c, u);
                        const d = function(e, t) {
                            let r = null;
                            for (let n = e.length - 1; n >= 0; n--)
                                if (t.canDragSource(e[n])) {
                                    r = e[n];
                                    break
                                }
                            return r
                        }(t, c);
                        if (null == d) return void e.dispatch(f);
                        let l = null;
                        if (i) {
                            if (!s) throw new Error("getSourceClientOffset must be defined");
                            ! function(e) {
                                (0, o.V)("function" == typeof e, "When clientOffset is provided, getSourceClientOffset must be a function.")
                            }(s), l = s(d)
                        }
                        e.dispatch(h(i, l));
                        const p = u.getSource(d).beginDrag(c, d);
                        if (null == p) return;
                        ! function(e) {
                            (0, o.V)(g(e), "Item must be an object.")
                        }(p), u.pinSource(d);
                        const v = u.getSourceType(d);
                        return {
                            type: a,
                            payload: {
                                itemType: v,
                                item: p,
                                sourceId: d,
                                clientOffset: i || null,
                                sourceClientOffset: l || null,
                                isSourcePublic: !!n
                            }
                        }
                    }
                }

                function v(e) {
                    return function() {
                        if (e.getMonitor().isDragging()) return {
                            type: c
                        }
                    }
                }

                function m(e, t) {
                    return null === t ? null === e : Array.isArray(e) ? e.some((e => e === t)) : e === t
                }

                function y(e) {
                    return function(t, {
                        clientOffset: r
                    } = {}) {
                        ! function(e) {
                            (0, o.V)(Array.isArray(e), "Expected targetIds to be an array.")
                        }(t);
                        const n = t.slice(0),
                            i = e.getMonitor(),
                            s = e.getRegistry();
                        ! function(e, t, r) {
                            (0, o.V)(t.isDragging(), "Cannot call hover while not dragging."), (0, o.V)(!t.didDrop(), "Cannot call hover after drop.");
                            for (let t = 0; t < e.length; t++) {
                                const n = e[t];
                                (0, o.V)(e.lastIndexOf(n) === t, "Expected targetIds to be unique in the passed array.");
                                const i = r.getTarget(n);
                                (0, o.V)(i, "Expected targetIds to be registered.")
                            }
                        }(n, i, s);
                        return function(e, t, r) {
                                for (let n = e.length - 1; n >= 0; n--) {
                                    const i = e[n];
                                    m(t.getTargetType(i), r) || e.splice(n, 1)
                                }
                            }(n, s, i.getItemType()),
                            function(e, t, r) {
                                e.forEach((function(e) {
                                    r.getTarget(e).hover(t, e)
                                }))
                            }(n, i, s), {
                                type: u,
                                payload: {
                                    targetIds: n,
                                    clientOffset: r || null
                                }
                            }
                    }
                }

                function b(e, t, r) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: r,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = r, e
                }

                function D(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = null != arguments[t] ? arguments[t] : {},
                            n = Object.keys(r);
                        "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter((function(e) {
                            return Object.getOwnPropertyDescriptor(r, e).enumerable
                        })))), n.forEach((function(t) {
                            b(e, t, r[t])
                        }))
                    }
                    return e
                }

                function S(e) {
                    return function(t = {}) {
                        const r = e.getMonitor(),
                            n = e.getRegistry();
                        ! function(e) {
                            (0, o.V)(e.isDragging(), "Cannot call drop while not dragging."), (0, o.V)(!e.didDrop(), "Cannot call drop twice during one drag operation.")
                        }(r);
                        const i = function(e) {
                            const t = e.getTargetIds().filter(e.canDropOnTarget, e);
                            return t.reverse(), t
                        }(r);
                        i.forEach(((i, s) => {
                            const a = function(e, t, r, n) {
                                    const i = r.getTarget(e);
                                    let s = i ? i.drop(n, e) : void 0;
                                    (function(e) {
                                        (0, o.V)(void 0 === e || g(e), "Drop result must either be an object or undefined.")
                                    })(s), void 0 === s && (s = 0 === t ? {} : n.getDropResult());
                                    return s
                                }(i, s, n, r),
                                c = {
                                    type: d,
                                    payload: {
                                        dropResult: D({}, t, a)
                                    }
                                };
                            e.dispatch(c)
                        }))
                    }
                }

                function O(e) {
                    return function() {
                        const t = e.getMonitor(),
                            r = e.getRegistry();
                        ! function(e) {
                            (0, o.V)(e.isDragging(), "Cannot call endDrag while not dragging.")
                        }(t);
                        const n = t.getSourceId();
                        if (null != n) {
                            r.getSource(n, !0).endDrag(t, n), r.unpinSource()
                        }
                        return {
                            type: l
                        }
                    }
                }
                class T {
                    receiveBackend(e) {
                        this.backend = e
                    }
                    getMonitor() {
                        return this.monitor
                    }
                    getBackend() {
                        return this.backend
                    }
                    getRegistry() {
                        return this.monitor.registry
                    }
                    getActions() {
                        const e = this,
                            {
                                dispatch: t
                            } = this.store;
                        const r = function(e) {
                            return {
                                beginDrag: p(e),
                                publishDragSource: v(e),
                                hover: y(e),
                                drop: S(e),
                                endDrag: O(e)
                            }
                        }(this);
                        return Object.keys(r).reduce(((n, i) => {
                            const o = r[i];
                            var s;
                            return n[i] = (s = o, (...r) => {
                                const n = s.apply(e, r);
                                void 0 !== n && t(n)
                            }), n
                        }), {})
                    }
                    dispatch(e) {
                        this.store.dispatch(e)
                    }
                    constructor(e, t) {
                        this.isSetUp = !1, this.handleRefCountChange = () => {
                            const e = this.store.getState().refCount > 0;
                            this.backend && (e && !this.isSetUp ? (this.backend.setup(), this.isSetUp = !0) : !e && this.isSetUp && (this.backend.teardown(), this.isSetUp = !1))
                        }, this.store = e, this.monitor = t, e.subscribe(this.handleRefCountChange)
                    }
                }

                function w(e) {
                    return "Minified Redux error #" + e + "; visit https://redux.js.org/Errors?code=" + e + " for the full message or use the non-minified dev environment for full errors. "
                }
                var E = "function" == typeof Symbol && Symbol.observable || "@@observable",
                    I = function() {
                        return Math.random().toString(36).substring(7).split("").join(".")
                    },
                    C = {
                        INIT: "@@redux/INIT" + I(),
                        REPLACE: "@@redux/REPLACE" + I(),
                        PROBE_UNKNOWN_ACTION: function() {
                            return "@@redux/PROBE_UNKNOWN_ACTION" + I()
                        }
                    };

                function N(e) {
                    if ("object" != typeof e || null === e) return !1;
                    for (var t = e; null !== Object.getPrototypeOf(t);) t = Object.getPrototypeOf(t);
                    return Object.getPrototypeOf(e) === t
                }

                function P(e, t, r) {
                    var n;
                    if ("function" == typeof t && "function" == typeof r || "function" == typeof r && "function" == typeof arguments[3]) throw new Error(w(0));
                    if ("function" == typeof t && void 0 === r && (r = t, t = void 0), void 0 !== r) {
                        if ("function" != typeof r) throw new Error(w(1));
                        return r(P)(e, t)
                    }
                    if ("function" != typeof e) throw new Error(w(2));
                    var i = e,
                        o = t,
                        s = [],
                        a = s,
                        c = !1;

                    function u() {
                        a === s && (a = s.slice())
                    }

                    function d() {
                        if (c) throw new Error(w(3));
                        return o
                    }

                    function l(e) {
                        if ("function" != typeof e) throw new Error(w(4));
                        if (c) throw new Error(w(5));
                        var t = !0;
                        return u(), a.push(e),
                            function() {
                                if (t) {
                                    if (c) throw new Error(w(6));
                                    t = !1, u();
                                    var r = a.indexOf(e);
                                    a.splice(r, 1), s = null
                                }
                            }
                    }

                    function h(e) {
                        if (!N(e)) throw new Error(w(7));
                        if (void 0 === e.type) throw new Error(w(8));
                        if (c) throw new Error(w(9));
                        try {
                            c = !0, o = i(o, e)
                        } finally {
                            c = !1
                        }
                        for (var t = s = a, r = 0; r < t.length; r++) {
                            (0, t[r])()
                        }
                        return e
                    }
                    return h({
                        type: C.INIT
                    }), (n = {
                        dispatch: h,
                        subscribe: l,
                        getState: d,
                        replaceReducer: function(e) {
                            if ("function" != typeof e) throw new Error(w(10));
                            i = e, h({
                                type: C.REPLACE
                            })
                        }
                    })[E] = function() {
                        var e, t = l;
                        return (e = {
                            subscribe: function(e) {
                                if ("object" != typeof e || null === e) throw new Error(w(11));

                                function r() {
                                    e.next && e.next(d())
                                }
                                return r(), {
                                    unsubscribe: t(r)
                                }
                            }
                        })[E] = function() {
                            return this
                        }, e
                    }, n
                }
                const M = (e, t) => e === t;

                function x(e, t, r) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: r,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = r, e
                }
                const R = {
                    initialSourceClientOffset: null,
                    initialClientOffset: null,
                    clientOffset: null
                };

                function _(e = R, t) {
                    const {
                        payload: r
                    } = t;
                    switch (t.type) {
                        case s:
                        case a:
                            return {
                                initialSourceClientOffset: r.sourceClientOffset,
                                initialClientOffset: r.clientOffset,
                                clientOffset: r.clientOffset
                            };
                        case u:
                            return n = e.clientOffset, i = r.clientOffset, !n && !i || n && i && n.x === i.x && n.y === i.y ? e : function(e) {
                                for (var t = 1; t < arguments.length; t++) {
                                    var r = null != arguments[t] ? arguments[t] : {},
                                        n = Object.keys(r);
                                    "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter((function(e) {
                                        return Object.getOwnPropertyDescriptor(r, e).enumerable
                                    })))), n.forEach((function(t) {
                                        x(e, t, r[t])
                                    }))
                                }
                                return e
                            }({}, e, {
                                clientOffset: r.clientOffset
                            });
                        case l:
                        case d:
                            return R;
                        default:
                            return e
                    }
                    var n, i
                }
                const L = "dnd-core/ADD_SOURCE",
                    k = "dnd-core/ADD_TARGET",
                    j = "dnd-core/REMOVE_SOURCE",
                    A = "dnd-core/REMOVE_TARGET";

                function V(e, t, r) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: r,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = r, e
                }

                function H(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = null != arguments[t] ? arguments[t] : {},
                            n = Object.keys(r);
                        "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter((function(e) {
                            return Object.getOwnPropertyDescriptor(r, e).enumerable
                        })))), n.forEach((function(t) {
                            V(e, t, r[t])
                        }))
                    }
                    return e
                }
                const U = {
                    itemType: null,
                    item: null,
                    sourceId: null,
                    targetIds: [],
                    dropResult: null,
                    didDrop: !1,
                    isSourcePublic: null
                };

                function F(e = U, t) {
                    const {
                        payload: r
                    } = t;
                    switch (t.type) {
                        case a:
                            return H({}, e, {
                                itemType: r.itemType,
                                item: r.item,
                                sourceId: r.sourceId,
                                isSourcePublic: r.isSourcePublic,
                                dropResult: null,
                                didDrop: !1
                            });
                        case c:
                            return H({}, e, {
                                isSourcePublic: !0
                            });
                        case u:
                            return H({}, e, {
                                targetIds: r.targetIds
                            });
                        case A:
                            return -1 === e.targetIds.indexOf(r.targetId) ? e : H({}, e, {
                                targetIds: (n = e.targetIds, i = r.targetId, n.filter((e => e !== i)))
                            });
                        case d:
                            return H({}, e, {
                                dropResult: r.dropResult,
                                didDrop: !0,
                                targetIds: []
                            });
                        case l:
                            return H({}, e, {
                                itemType: null,
                                item: null,
                                sourceId: null,
                                dropResult: null,
                                didDrop: !1,
                                isSourcePublic: null,
                                targetIds: []
                            });
                        default:
                            return e
                    }
                    var n, i
                }

                function B(e = 0, t) {
                    switch (t.type) {
                        case L:
                        case k:
                            return e + 1;
                        case j:
                        case A:
                            return e - 1;
                        default:
                            return e
                    }
                }
                const X = [],
                    Y = [];

                function q(e = X, t) {
                    switch (t.type) {
                        case u:
                            break;
                        case L:
                        case k:
                        case A:
                        case j:
                            return X;
                        default:
                            return Y
                    }
                    const {
                        targetIds: r = [],
                        prevTargetIds: n = []
                    } = t.payload, i = function(e, t) {
                        const r = new Map,
                            n = e => {
                                r.set(e, r.has(e) ? r.get(e) + 1 : 1)
                            };
                        e.forEach(n), t.forEach(n);
                        const i = [];
                        return r.forEach(((e, t) => {
                            1 === e && i.push(t)
                        })), i
                    }(r, n);
                    if (!(i.length > 0 || ! function(e, t, r = M) {
                            if (e.length !== t.length) return !1;
                            for (let n = 0; n < e.length; ++n)
                                if (!r(e[n], t[n])) return !1;
                            return !0
                        }(r, n))) return X;
                    const o = n[n.length - 1],
                        s = r[r.length - 1];
                    return o !== s && (o && i.push(o), s && i.push(s)), i
                }

                function G(e = 0) {
                    return e + 1
                }

                function K(e, t, r) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: r,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = r, e
                }

                function W(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = null != arguments[t] ? arguments[t] : {},
                            n = Object.keys(r);
                        "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter((function(e) {
                            return Object.getOwnPropertyDescriptor(r, e).enumerable
                        })))), n.forEach((function(t) {
                            K(e, t, r[t])
                        }))
                    }
                    return e
                }

                function z(e = {}, t) {
                    return {
                        dirtyHandlerIds: q(e.dirtyHandlerIds, {
                            type: t.type,
                            payload: W({}, t.payload, {
                                prevTargetIds: (r = e, n = "dragOperation.targetIds", i = [], n.split(".").reduce(((e, t) => e && e[t] ? e[t] : i || null), r))
                            })
                        }),
                        dragOffset: _(e.dragOffset, t),
                        refCount: B(e.refCount, t),
                        dragOperation: F(e.dragOperation, t),
                        stateId: G(e.stateId)
                    };
                    var r, n, i
                }

                function $(e, t) {
                    return {
                        x: e.x - t.x,
                        y: e.y - t.y
                    }
                }
                X.__IS_NONE__ = !0, Y.__IS_ALL__ = !0;
                class Q {
                    subscribeToStateChange(e, t = {}) {
                        const {
                            handlerIds: r
                        } = t;
                        (0, o.V)("function" == typeof e, "listener must be a function."), (0, o.V)(void 0 === r || Array.isArray(r), "handlerIds, when specified, must be an array of strings.");
                        let n = this.store.getState().stateId;
                        return this.store.subscribe((() => {
                            const t = this.store.getState(),
                                i = t.stateId;
                            try {
                                const o = i === n || i === n + 1 && ! function(e, t) {
                                    return e !== X && (e === Y || void 0 === t || (r = e, t.filter((e => r.indexOf(e) > -1))).length > 0);
                                    var r
                                }(t.dirtyHandlerIds, r);
                                o || e()
                            } finally {
                                n = i
                            }
                        }))
                    }
                    subscribeToOffsetChange(e) {
                        (0, o.V)("function" == typeof e, "listener must be a function.");
                        let t = this.store.getState().dragOffset;
                        return this.store.subscribe((() => {
                            const r = this.store.getState().dragOffset;
                            r !== t && (t = r, e())
                        }))
                    }
                    canDragSource(e) {
                        if (!e) return !1;
                        const t = this.registry.getSource(e);
                        return (0, o.V)(t, `Expected to find a valid source. sourceId=${e}`), !this.isDragging() && t.canDrag(this, e)
                    }
                    canDropOnTarget(e) {
                        if (!e) return !1;
                        const t = this.registry.getTarget(e);
                        if ((0, o.V)(t, `Expected to find a valid target. targetId=${e}`), !this.isDragging() || this.didDrop()) return !1;
                        return m(this.registry.getTargetType(e), this.getItemType()) && t.canDrop(this, e)
                    }
                    isDragging() {
                        return Boolean(this.getItemType())
                    }
                    isDraggingSource(e) {
                        if (!e) return !1;
                        const t = this.registry.getSource(e, !0);
                        if ((0, o.V)(t, `Expected to find a valid source. sourceId=${e}`), !this.isDragging() || !this.isSourcePublic()) return !1;
                        return this.registry.getSourceType(e) === this.getItemType() && t.isDragging(this, e)
                    }
                    isOverTarget(e, t = {
                        shallow: !1
                    }) {
                        if (!e) return !1;
                        const {
                            shallow: r
                        } = t;
                        if (!this.isDragging()) return !1;
                        const n = this.registry.getTargetType(e),
                            i = this.getItemType();
                        if (i && !m(n, i)) return !1;
                        const o = this.getTargetIds();
                        if (!o.length) return !1;
                        const s = o.indexOf(e);
                        return r ? s === o.length - 1 : s > -1
                    }
                    getItemType() {
                        return this.store.getState().dragOperation.itemType
                    }
                    getItem() {
                        return this.store.getState().dragOperation.item
                    }
                    getSourceId() {
                        return this.store.getState().dragOperation.sourceId
                    }
                    getTargetIds() {
                        return this.store.getState().dragOperation.targetIds
                    }
                    getDropResult() {
                        return this.store.getState().dragOperation.dropResult
                    }
                    didDrop() {
                        return this.store.getState().dragOperation.didDrop
                    }
                    isSourcePublic() {
                        return Boolean(this.store.getState().dragOperation.isSourcePublic)
                    }
                    getInitialClientOffset() {
                        return this.store.getState().dragOffset.initialClientOffset
                    }
                    getInitialSourceClientOffset() {
                        return this.store.getState().dragOffset.initialSourceClientOffset
                    }
                    getClientOffset() {
                        return this.store.getState().dragOffset.clientOffset
                    }
                    getSourceClientOffset() {
                        return function(e) {
                            const {
                                clientOffset: t,
                                initialClientOffset: r,
                                initialSourceClientOffset: n
                            } = e;
                            return t && r && n ? $((o = n, {
                                x: (i = t).x + o.x,
                                y: i.y + o.y
                            }), r) : null;
                            var i, o
                        }(this.store.getState().dragOffset)
                    }
                    getDifferenceFromInitialOffset() {
                        return function(e) {
                            const {
                                clientOffset: t,
                                initialClientOffset: r
                            } = e;
                            return t && r ? $(t, r) : null
                        }(this.store.getState().dragOffset)
                    }
                    constructor(e, t) {
                        this.store = e, this.registry = t
                    }
                }
                let J = 0;
                var Z;

                function ee(e, t) {
                    t && Array.isArray(e) ? e.forEach((e => ee(e, !1))) : (0, o.V)("string" == typeof e || "symbol" == typeof e, t ? "Type can only be a string, a symbol, or an array of either." : "Type can only be a string or a symbol.")
                }! function(e) {
                    e.SOURCE = "SOURCE", e.TARGET = "TARGET"
                }(Z || (Z = {}));
                const te = "undefined" != typeof global ? global : self,
                    re = te.MutationObserver || te.WebKitMutationObserver;

                function ne(e) {
                    return function() {
                        const t = setTimeout(n, 0),
                            r = setInterval(n, 50);

                        function n() {
                            clearTimeout(t), clearInterval(r), e()
                        }
                    }
                }
                const ie = "function" == typeof re ? function(e) {
                    let t = 1;
                    const r = new re(e),
                        n = document.createTextNode("");
                    return r.observe(n, {
                            characterData: !0
                        }),
                        function() {
                            t = -t, n.data = t
                        }
                } : ne;
                class oe {
                    call() {
                        try {
                            this.task && this.task()
                        } catch (e) {
                            this.onError(e)
                        } finally {
                            this.task = null, this.release(this)
                        }
                    }
                    constructor(e, t) {
                        this.onError = e, this.release = t, this.task = null
                    }
                }
                const se = new class {
                        enqueueTask(e) {
                            const {
                                queue: t,
                                requestFlush: r
                            } = this;
                            t.length || (r(), this.flushing = !0), t[t.length] = e
                        }
                        constructor() {
                            this.queue = [], this.pendingErrors = [], this.flushing = !1, this.index = 0, this.capacity = 1024, this.flush = () => {
                                const {
                                    queue: e
                                } = this;
                                for (; this.index < e.length;) {
                                    const t = this.index;
                                    if (this.index++, e[t].call(), this.index > this.capacity) {
                                        for (let t = 0, r = e.length - this.index; t < r; t++) e[t] = e[t + this.index];
                                        e.length -= this.index, this.index = 0
                                    }
                                }
                                e.length = 0, this.index = 0, this.flushing = !1
                            }, this.registerPendingError = e => {
                                this.pendingErrors.push(e), this.requestErrorThrow()
                            }, this.requestFlush = ie(this.flush), this.requestErrorThrow = ne((() => {
                                if (this.pendingErrors.length) throw this.pendingErrors.shift()
                            }))
                        }
                    },
                    ae = new class {
                        create(e) {
                            const t = this.freeTasks,
                                r = t.length ? t.pop() : new oe(this.onError, (e => t[t.length] = e));
                            return r.task = e, r
                        }
                        constructor(e) {
                            this.onError = e, this.freeTasks = []
                        }
                    }(se.registerPendingError);

                function ce(e) {
                    const t = (J++).toString();
                    switch (e) {
                        case Z.SOURCE:
                            return `S${t}`;
                        case Z.TARGET:
                            return `T${t}`;
                        default:
                            throw new Error(`Unknown Handler Role: ${e}`)
                    }
                }

                function ue(e) {
                    switch (e[0]) {
                        case "S":
                            return Z.SOURCE;
                        case "T":
                            return Z.TARGET;
                        default:
                            throw new Error(`Cannot parse handler ID: ${e}`)
                    }
                }

                function de(e, t) {
                    const r = e.entries();
                    let n = !1;
                    do {
                        const {
                            done: e,
                            value: [, i]
                        } = r.next();
                        if (i === t) return !0;
                        n = !!e
                    } while (!n);
                    return !1
                }
                class le {
                    addSource(e, t) {
                        ee(e),
                            function(e) {
                                (0, o.V)("function" == typeof e.canDrag, "Expected canDrag to be a function."), (0, o.V)("function" == typeof e.beginDrag, "Expected beginDrag to be a function."), (0, o.V)("function" == typeof e.endDrag, "Expected endDrag to be a function.")
                            }(t);
                        const r = this.addHandler(Z.SOURCE, e, t);
                        return this.store.dispatch(function(e) {
                            return {
                                type: L,
                                payload: {
                                    sourceId: e
                                }
                            }
                        }(r)), r
                    }
                    addTarget(e, t) {
                        ee(e, !0),
                            function(e) {
                                (0, o.V)("function" == typeof e.canDrop, "Expected canDrop to be a function."), (0, o.V)("function" == typeof e.hover, "Expected hover to be a function."), (0, o.V)("function" == typeof e.drop, "Expected beginDrag to be a function.")
                            }(t);
                        const r = this.addHandler(Z.TARGET, e, t);
                        return this.store.dispatch(function(e) {
                            return {
                                type: k,
                                payload: {
                                    targetId: e
                                }
                            }
                        }(r)), r
                    }
                    containsHandler(e) {
                        return de(this.dragSources, e) || de(this.dropTargets, e)
                    }
                    getSource(e, t = !1) {
                        (0, o.V)(this.isSourceId(e), "Expected a valid source ID.");
                        return t && e === this.pinnedSourceId ? this.pinnedSource : this.dragSources.get(e)
                    }
                    getTarget(e) {
                        return (0, o.V)(this.isTargetId(e), "Expected a valid target ID."), this.dropTargets.get(e)
                    }
                    getSourceType(e) {
                        return (0, o.V)(this.isSourceId(e), "Expected a valid source ID."), this.types.get(e)
                    }
                    getTargetType(e) {
                        return (0, o.V)(this.isTargetId(e), "Expected a valid target ID."), this.types.get(e)
                    }
                    isSourceId(e) {
                        return ue(e) === Z.SOURCE
                    }
                    isTargetId(e) {
                        return ue(e) === Z.TARGET
                    }
                    removeSource(e) {
                        var t;
                        (0, o.V)(this.getSource(e), "Expected an existing source."), this.store.dispatch(function(e) {
                            return {
                                type: j,
                                payload: {
                                    sourceId: e
                                }
                            }
                        }(e)), t = () => {
                            this.dragSources.delete(e), this.types.delete(e)
                        }, se.enqueueTask(ae.create(t))
                    }
                    removeTarget(e) {
                        (0, o.V)(this.getTarget(e), "Expected an existing target."), this.store.dispatch(function(e) {
                            return {
                                type: A,
                                payload: {
                                    targetId: e
                                }
                            }
                        }(e)), this.dropTargets.delete(e), this.types.delete(e)
                    }
                    pinSource(e) {
                        const t = this.getSource(e);
                        (0, o.V)(t, "Expected an existing source."), this.pinnedSourceId = e, this.pinnedSource = t
                    }
                    unpinSource() {
                        (0, o.V)(this.pinnedSource, "No source is pinned at the time."), this.pinnedSourceId = null, this.pinnedSource = null
                    }
                    addHandler(e, t, r) {
                        const n = ce(e);
                        return this.types.set(n, t), e === Z.SOURCE ? this.dragSources.set(n, r) : e === Z.TARGET && this.dropTargets.set(n, r), n
                    }
                    constructor(e) {
                        this.types = new Map, this.dragSources = new Map, this.dropTargets = new Map, this.pinnedSourceId = null, this.pinnedSource = null, this.store = e
                    }
                }

                function he(e, t = void 0, r = {}, n = !1) {
                    const i = function(e) {
                            const t = "undefined" != typeof window && window.__REDUX_DEVTOOLS_EXTENSION__;
                            return P(z, e && t && t({
                                name: "dnd-core",
                                instanceId: "dnd-core"
                            }))
                        }(n),
                        o = new Q(i, new le(i)),
                        s = new T(i, o),
                        a = e(s, t, r);
                    return s.receiveBackend(a), s
                }
                var ge = r(38127);

                function fe(e, t) {
                    if (null == e) return {};
                    var r, n, i = function(e, t) {
                        if (null == e) return {};
                        var r, n, i = {},
                            o = Object.keys(e);
                        for (n = 0; n < o.length; n++) r = o[n], t.indexOf(r) >= 0 || (i[r] = e[r]);
                        return i
                    }(e, t);
                    if (Object.getOwnPropertySymbols) {
                        var o = Object.getOwnPropertySymbols(e);
                        for (n = 0; n < o.length; n++) r = o[n], t.indexOf(r) >= 0 || Object.prototype.propertyIsEnumerable.call(e, r) && (i[r] = e[r])
                    }
                    return i
                }
                let pe = 0;
                const ve = Symbol.for("__REACT_DND_CONTEXT_INSTANCE__");
                var me = (0, i.memo)((function(e) {
                    var {
                        children: t
                    } = e, r = fe(e, ["children"]);
                    const [o, s] = function(e) {
                        if ("manager" in e) {
                            return [{
                                dragDropManager: e.manager
                            }, !1]
                        }
                        const t = function(e, t = ye(), r, n) {
                                const i = t;
                                i[ve] || (i[ve] = {
                                    dragDropManager: he(e, t, r, n)
                                });
                                return i[ve]
                            }(e.backend, e.context, e.options, e.debugMode),
                            r = !e.context;
                        return [t, r]
                    }(r);
                    return (0, i.useEffect)((() => {
                        if (s) {
                            const e = ye();
                            return ++pe, () => {
                                0 == --pe && (e[ve] = null)
                            }
                        }
                    }), []), (0, n.jsx)(ge.M.Provider, {
                        value: o,
                        children: t
                    })
                }));

                function ye() {
                    return "undefined" != typeof global ? global : window
                }
            },
            23506: function(e, t, r) {
                r.d(t, {
                    i: function() {
                        return s
                    }
                });
                var n = r(84931),
                    i = r(96540);

                function o(e) {
                    return (t = null, r = null) => {
                        if (!(0, i.isValidElement)(t)) {
                            const n = t;
                            return e(n, r), n
                        }
                        const o = t;
                        ! function(e) {
                            if ("string" == typeof e.type) return;
                            const t = e.type.displayName || e.type.name || "the component";
                            throw new Error(`Only native element nodes can now be passed to React DnD connectors.You can either wrap ${t} into a <div>, or turn it into a drag source or a drop target itself.`)
                        }(o);
                        return function(e, t) {
                            const r = e.ref;
                            return (0, n.V)("string" != typeof r, "Cannot connect React DnD to an element with an existing string ref. Please convert it to use a callback ref instead, or wrap it into a <span> or <div>. Read more: https://reactjs.org/docs/refs-and-the-dom.html#callback-refs"), r ? (0, i.cloneElement)(e, {
                                ref: e => {
                                    a(r, e), a(t, e)
                                }
                            }) : (0, i.cloneElement)(e, {
                                ref: t
                            })
                        }(o, r ? t => e(t, r) : e)
                    }
                }

                function s(e) {
                    const t = {};
                    return Object.keys(e).forEach((r => {
                        const n = e[r];
                        if (r.endsWith("Ref")) t[r] = e[r];
                        else {
                            const e = o(n);
                            t[r] = () => e
                        }
                    })), t
                }

                function a(e, t) {
                    "function" == typeof e ? e(t) : e.current = t
                }
            },
            25110: function(e, t, r) {
                r.d(t, {
                    u: function() {
                        return s
                    }
                });
                var n = r(96540),
                    i = r(84931),
                    o = r(38127);

                function s() {
                    const {
                        dragDropManager: e
                    } = (0, n.useContext)(o.M);
                    return (0, i.V)(null != e, "Expected drag drop context"), e
                }
            },
            30908: function(e, t, r) {
                r.d(t, {
                    qi: function() {
                        return f
                    }
                });
                var n, i = r(84931);
                ! function(e) {
                    e.mouse = "mouse", e.touch = "touch", e.keyboard = "keyboard"
                }(n || (n = {}));
                const o = 1,
                    s = 0;

                function a(e) {
                    return void 0 === e.button || e.button === s
                }

                function c(e) {
                    return !!e.targetTouches
                }

                function u(e, t) {
                    return c(e) ? function(e, t) {
                        return 1 === e.targetTouches.length ? u(e.targetTouches[0]) : t && 1 === e.touches.length && e.touches[0].target === t.target ? u(e.touches[0]) : void 0
                    }(e, t) : {
                        x: e.clientX,
                        y: e.clientY
                    }
                }
                const d = (() => {
                    let e = !1;
                    try {
                        addEventListener("test", (() => {}), Object.defineProperty({}, "passive", {
                            get() {
                                return e = !0, !0
                            }
                        }))
                    } catch (e) {}
                    return e
                })();
                class l {
                    get delay() {
                        var e;
                        return null !== (e = this.args.delay) && void 0 !== e ? e : 0
                    }
                    get scrollAngleRanges() {
                        return this.args.scrollAngleRanges
                    }
                    get getDropTargetElementsAtPoint() {
                        return this.args.getDropTargetElementsAtPoint
                    }
                    get ignoreContextMenu() {
                        var e;
                        return null !== (e = this.args.ignoreContextMenu) && void 0 !== e && e
                    }
                    get enableHoverOutsideTarget() {
                        var e;
                        return null !== (e = this.args.enableHoverOutsideTarget) && void 0 !== e && e
                    }
                    get enableKeyboardEvents() {
                        var e;
                        return null !== (e = this.args.enableKeyboardEvents) && void 0 !== e && e
                    }
                    get enableMouseEvents() {
                        var e;
                        return null !== (e = this.args.enableMouseEvents) && void 0 !== e && e
                    }
                    get enableTouchEvents() {
                        var e;
                        return null === (e = this.args.enableTouchEvents) || void 0 === e || e
                    }
                    get touchSlop() {
                        return this.args.touchSlop || 0
                    }
                    get delayTouchStart() {
                        var e, t, r, n;
                        return null !== (n = null !== (r = null === (e = this.args) || void 0 === e ? void 0 : e.delayTouchStart) && void 0 !== r ? r : null === (t = this.args) || void 0 === t ? void 0 : t.delay) && void 0 !== n ? n : 0
                    }
                    get delayMouseStart() {
                        var e, t, r, n;
                        return null !== (n = null !== (r = null === (e = this.args) || void 0 === e ? void 0 : e.delayMouseStart) && void 0 !== r ? r : null === (t = this.args) || void 0 === t ? void 0 : t.delay) && void 0 !== n ? n : 0
                    }
                    get window() {
                        return this.context && this.context.window ? this.context.window : "undefined" != typeof window ? window : void 0
                    }
                    get document() {
                        var e;
                        return (null === (e = this.context) || void 0 === e ? void 0 : e.document) ? this.context.document : this.window ? this.window.document : void 0
                    }
                    get rootElement() {
                        var e;
                        return (null === (e = this.args) || void 0 === e ? void 0 : e.rootElement) || this.document
                    }
                    constructor(e, t) {
                        this.args = e, this.context = t
                    }
                }
                const h = {
                    [n.mouse]: {
                        start: "mousedown",
                        move: "mousemove",
                        end: "mouseup",
                        contextmenu: "contextmenu"
                    },
                    [n.touch]: {
                        start: "touchstart",
                        move: "touchmove",
                        end: "touchend"
                    },
                    [n.keyboard]: {
                        keydown: "keydown"
                    }
                };
                class g {
                    profile() {
                        var e;
                        return {
                            sourceNodes: this.sourceNodes.size,
                            sourcePreviewNodes: this.sourcePreviewNodes.size,
                            sourcePreviewNodeOptions: this.sourcePreviewNodeOptions.size,
                            targetNodes: this.targetNodes.size,
                            dragOverTargetIds: (null === (e = this.dragOverTargetIds) || void 0 === e ? void 0 : e.length) || 0
                        }
                    }
                    get document() {
                        return this.options.document
                    }
                    setup() {
                        const e = this.options.rootElement;
                        e && ((0, i.V)(!g.isSetUp, "Cannot have two Touch backends at the same time."), g.isSetUp = !0, this.addEventListener(e, "start", this.getTopMoveStartHandler()), this.addEventListener(e, "start", this.handleTopMoveStartCapture, !0), this.addEventListener(e, "move", this.handleTopMove), this.addEventListener(e, "move", this.handleTopMoveCapture, !0), this.addEventListener(e, "end", this.handleTopMoveEndCapture, !0), this.options.enableMouseEvents && !this.options.ignoreContextMenu && this.addEventListener(e, "contextmenu", this.handleTopMoveEndCapture), this.options.enableKeyboardEvents && this.addEventListener(e, "keydown", this.handleCancelOnEscape, !0))
                    }
                    teardown() {
                        const e = this.options.rootElement;
                        e && (g.isSetUp = !1, this._mouseClientOffset = {}, this.removeEventListener(e, "start", this.handleTopMoveStartCapture, !0), this.removeEventListener(e, "start", this.handleTopMoveStart), this.removeEventListener(e, "move", this.handleTopMoveCapture, !0), this.removeEventListener(e, "move", this.handleTopMove), this.removeEventListener(e, "end", this.handleTopMoveEndCapture, !0), this.options.enableMouseEvents && !this.options.ignoreContextMenu && this.removeEventListener(e, "contextmenu", this.handleTopMoveEndCapture), this.options.enableKeyboardEvents && this.removeEventListener(e, "keydown", this.handleCancelOnEscape, !0), this.uninstallSourceNodeRemovalObserver())
                    }
                    addEventListener(e, t, r, n = !1) {
                        const i = d ? {
                            capture: n,
                            passive: !1
                        } : n;
                        this.listenerTypes.forEach((function(n) {
                            const o = h[n][t];
                            o && e.addEventListener(o, r, i)
                        }))
                    }
                    removeEventListener(e, t, r, n = !1) {
                        const i = d ? {
                            capture: n,
                            passive: !1
                        } : n;
                        this.listenerTypes.forEach((function(n) {
                            const o = h[n][t];
                            o && e.removeEventListener(o, r, i)
                        }))
                    }
                    connectDragSource(e, t) {
                        const r = this.handleMoveStart.bind(this, e);
                        return this.sourceNodes.set(e, t), this.addEventListener(t, "start", r), () => {
                            this.sourceNodes.delete(e), this.removeEventListener(t, "start", r)
                        }
                    }
                    connectDragPreview(e, t, r) {
                        return this.sourcePreviewNodeOptions.set(e, r), this.sourcePreviewNodes.set(e, t), () => {
                            this.sourcePreviewNodes.delete(e), this.sourcePreviewNodeOptions.delete(e)
                        }
                    }
                    connectDropTarget(e, t) {
                        const r = this.options.rootElement;
                        if (!this.document || !r) return () => {};
                        const n = n => {
                            if (!this.document || !r || !this.monitor.isDragging()) return;
                            let i;
                            switch (n.type) {
                                case h.mouse.move:
                                    i = {
                                        x: n.clientX,
                                        y: n.clientY
                                    };
                                    break;
                                case h.touch.move:
                                    var o, s;
                                    i = {
                                        x: (null === (o = n.touches[0]) || void 0 === o ? void 0 : o.clientX) || 0,
                                        y: (null === (s = n.touches[0]) || void 0 === s ? void 0 : s.clientY) || 0
                                    }
                            }
                            const a = null != i ? this.document.elementFromPoint(i.x, i.y) : void 0,
                                c = a && t.contains(a);
                            return a === t || c ? this.handleMove(n, e) : void 0
                        };
                        return this.addEventListener(this.document.body, "move", n), this.targetNodes.set(e, t), () => {
                            this.document && (this.targetNodes.delete(e), this.removeEventListener(this.document.body, "move", n))
                        }
                    }
                    getTopMoveStartHandler() {
                        return this.options.delayTouchStart || this.options.delayMouseStart ? this.handleTopMoveStartDelay : this.handleTopMoveStart
                    }
                    installSourceNodeRemovalObserver(e) {
                        this.uninstallSourceNodeRemovalObserver(), this.draggedSourceNode = e, this.draggedSourceNodeRemovalObserver = new MutationObserver((() => {
                            e && !e.parentElement && (this.resurrectSourceNode(), this.uninstallSourceNodeRemovalObserver())
                        })), e && e.parentElement && this.draggedSourceNodeRemovalObserver.observe(e.parentElement, {
                            childList: !0
                        })
                    }
                    resurrectSourceNode() {
                        this.document && this.draggedSourceNode && (this.draggedSourceNode.style.display = "none", this.draggedSourceNode.removeAttribute("data-reactid"), this.document.body.appendChild(this.draggedSourceNode))
                    }
                    uninstallSourceNodeRemovalObserver() {
                        this.draggedSourceNodeRemovalObserver && this.draggedSourceNodeRemovalObserver.disconnect(), this.draggedSourceNodeRemovalObserver = void 0, this.draggedSourceNode = void 0
                    }
                    constructor(e, t, r) {
                        this.getSourceClientOffset = e => {
                            const t = this.sourceNodes.get(e);
                            return t && function(e) {
                                const t = 1 === e.nodeType ? e : e.parentElement;
                                if (!t) return;
                                const {
                                    top: r,
                                    left: n
                                } = t.getBoundingClientRect();
                                return {
                                    x: n,
                                    y: r
                                }
                            }(t)
                        }, this.handleTopMoveStartCapture = e => {
                            a(e) && (this.moveStartSourceIds = [])
                        }, this.handleMoveStart = e => {
                            Array.isArray(this.moveStartSourceIds) && this.moveStartSourceIds.unshift(e)
                        }, this.handleTopMoveStart = e => {
                            if (!a(e)) return;
                            const t = u(e);
                            t && (c(e) && (this.lastTargetTouchFallback = e.targetTouches[0]), this._mouseClientOffset = t), this.waitingForDelay = !1
                        }, this.handleTopMoveStartDelay = e => {
                            if (!a(e)) return;
                            const t = e.type === h.touch.start ? this.options.delayTouchStart : this.options.delayMouseStart;
                            this.timeout = setTimeout(this.handleTopMoveStart.bind(this, e), t), this.waitingForDelay = !0
                        }, this.handleTopMoveCapture = () => {
                            this.dragOverTargetIds = []
                        }, this.handleMove = (e, t) => {
                            this.dragOverTargetIds && this.dragOverTargetIds.unshift(t)
                        }, this.handleTopMove = e => {
                            if (this.timeout && clearTimeout(this.timeout), !this.document || this.waitingForDelay) return;
                            const {
                                moveStartSourceIds: t,
                                dragOverTargetIds: r
                            } = this, n = this.options.enableHoverOutsideTarget, i = u(e, this.lastTargetTouchFallback);
                            if (!i) return;
                            if (this._isScrolling || !this.monitor.isDragging() && function(e, t, r, n, i) {
                                    if (!i) return !1;
                                    const o = 180 * Math.atan2(n - t, r - e) / Math.PI + 180;
                                    for (let e = 0; e < i.length; ++e) {
                                        const t = i[e];
                                        if (t && (null == t.start || o >= t.start) && (null == t.end || o <= t.end)) return !0
                                    }
                                    return !1
                                }(this._mouseClientOffset.x || 0, this._mouseClientOffset.y || 0, i.x, i.y, this.options.scrollAngleRanges)) return void(this._isScrolling = !0);
                            var o, s, a, c;
                            if (!this.monitor.isDragging() && this._mouseClientOffset.hasOwnProperty("x") && t && (o = this._mouseClientOffset.x || 0, s = this._mouseClientOffset.y || 0, a = i.x, c = i.y, Math.sqrt(Math.pow(Math.abs(a - o), 2) + Math.pow(Math.abs(c - s), 2)) > (this.options.touchSlop ? this.options.touchSlop : 0)) && (this.moveStartSourceIds = void 0, this.actions.beginDrag(t, {
                                    clientOffset: this._mouseClientOffset,
                                    getSourceClientOffset: this.getSourceClientOffset,
                                    publishSource: !1
                                })), !this.monitor.isDragging()) return;
                            const d = this.sourceNodes.get(this.monitor.getSourceId());
                            this.installSourceNodeRemovalObserver(d), this.actions.publishDragSource(), e.cancelable && e.preventDefault();
                            const l = (r || []).map((e => this.targetNodes.get(e))).filter((e => !!e)),
                                h = this.options.getDropTargetElementsAtPoint ? this.options.getDropTargetElementsAtPoint(i.x, i.y, l) : this.document.elementsFromPoint(i.x, i.y),
                                g = [];
                            for (const e in h) {
                                if (!h.hasOwnProperty(e)) continue;
                                let t = h[e];
                                for (null != t && g.push(t); t;) t = t.parentElement, t && -1 === g.indexOf(t) && g.push(t)
                            }
                            const f = g.filter((e => l.indexOf(e) > -1)).map((e => this._getDropTargetId(e))).filter((e => !!e)).filter(((e, t, r) => r.indexOf(e) === t));
                            if (n)
                                for (const e in this.targetNodes) {
                                    const t = this.targetNodes.get(e);
                                    if (d && t && t.contains(d) && -1 === f.indexOf(e)) {
                                        f.unshift(e);
                                        break
                                    }
                                }
                            f.reverse(), this.actions.hover(f, {
                                clientOffset: i
                            })
                        }, this._getDropTargetId = e => {
                            const t = this.targetNodes.keys();
                            let r = t.next();
                            for (; !1 === r.done;) {
                                const n = r.value;
                                if (e === this.targetNodes.get(n)) return n;
                                r = t.next()
                            }
                        }, this.handleTopMoveEndCapture = e => {
                            this._isScrolling = !1, this.lastTargetTouchFallback = void 0,
                                function(e) {
                                    return void 0 === e.buttons || !(e.buttons & o)
                                }(e) && (this.monitor.isDragging() && !this.monitor.didDrop() ? (e.cancelable && e.preventDefault(), this._mouseClientOffset = {}, this.uninstallSourceNodeRemovalObserver(), this.actions.drop(), this.actions.endDrag()) : this.moveStartSourceIds = void 0)
                        }, this.handleCancelOnEscape = e => {
                            "Escape" === e.key && this.monitor.isDragging() && (this._mouseClientOffset = {}, this.uninstallSourceNodeRemovalObserver(), this.actions.endDrag())
                        }, this.options = new l(r, t), this.actions = e.getActions(), this.monitor = e.getMonitor(), this.sourceNodes = new Map, this.sourcePreviewNodes = new Map, this.sourcePreviewNodeOptions = new Map, this.targetNodes = new Map, this.listenerTypes = [], this._mouseClientOffset = {}, this._isScrolling = !1, this.options.enableMouseEvents && this.listenerTypes.push(n.mouse), this.options.enableTouchEvents && this.listenerTypes.push(n.touch), this.options.enableKeyboardEvents && this.listenerTypes.push(n.keyboard)
                    }
                }
                const f = function(e, t = {}, r = {}) {
                    return new g(e, t, r)
                }
            },
            31768: function(e, t, r) {
                function n(e) {
                    return null !== e && "object" == typeof e && Object.prototype.hasOwnProperty.call(e, "current")
                }
                r.d(t, {
                    i: function() {
                        return n
                    }
                })
            },
            32017: function(e) {
                e.exports = function e(t, r) {
                    if (t === r) return !0;
                    if (t && r && "object" == typeof t && "object" == typeof r) {
                        if (t.constructor !== r.constructor) return !1;
                        var n, i, o;
                        if (Array.isArray(t)) {
                            if ((n = t.length) != r.length) return !1;
                            for (i = n; 0 != i--;)
                                if (!e(t[i], r[i])) return !1;
                            return !0
                        }
                        if (t.constructor === RegExp) return t.source === r.source && t.flags === r.flags;
                        if (t.valueOf !== Object.prototype.valueOf) return t.valueOf() === r.valueOf();
                        if (t.toString !== Object.prototype.toString) return t.toString() === r.toString();
                        if ((n = (o = Object.keys(t)).length) !== Object.keys(r).length) return !1;
                        for (i = n; 0 != i--;)
                            if (!Object.prototype.hasOwnProperty.call(r, o[i])) return !1;
                        for (i = n; 0 != i--;) {
                            var s = o[i];
                            if (!e(t[s], r[s])) return !1
                        }
                        return !0
                    }
                    return t != t && r != r
                }
            },
            33771: function(e, t, r) {
                var n = r(46518),
                    i = r(84373),
                    o = r(6469);
                n({
                    target: "Array",
                    proto: !0
                }, {
                    fill: i
                }), o("fill")
            },
            38127: function(e, t, r) {
                r.d(t, {
                    M: function() {
                        return n
                    }
                });
                const n = (0, r(96540).createContext)({
                    dragDropManager: void 0
                })
            },
            43613: function(e, t, r) {
                r.d(t, {
                    V: function() {
                        return s
                    }
                });
                var n = r(96540),
                    i = r(25110),
                    o = r(1725);

                function s(e) {
                    const t = (0, i.u)().getMonitor(),
                        [r, s] = (0, o.F)(t, e);
                    return (0, n.useEffect)((() => t.subscribeToOffsetChange(s))), (0, n.useEffect)((() => t.subscribeToStateChange(s))), r
                }
            },
            46946: function(e, t, r) {
                r.d(t, {
                    I: function() {
                        return i
                    }
                });
                var n = r(96540);

                function i(e, t) {
                    const r = [...t || []];
                    return null == t && "function" != typeof e && r.push(e), (0, n.useMemo)((() => "function" == typeof e ? e() : e), r)
                }
            },
            48590: function(e, t, r) {
                r.d(t, {
                    H: function() {
                        return b
                    }
                });
                var n = r(9534),
                    i = r(25110),
                    o = r(49134),
                    s = r(84931),
                    a = r(96540);
                class c {
                    canDrop() {
                        const e = this.spec,
                            t = this.monitor;
                        return !e.canDrop || e.canDrop(t.getItem(), t)
                    }
                    hover() {
                        const e = this.spec,
                            t = this.monitor;
                        e.hover && e.hover(t.getItem(), t)
                    }
                    drop() {
                        const e = this.spec,
                            t = this.monitor;
                        if (e.drop) return e.drop(t.getItem(), t)
                    }
                    constructor(e, t) {
                        this.spec = e, this.monitor = t
                    }
                }

                function u(e, t, r) {
                    const u = (0, i.u)(),
                        d = function(e, t) {
                            const r = (0, a.useMemo)((() => new c(e, t)), [t]);
                            return (0, a.useEffect)((() => {
                                r.spec = e
                            }), [e]), r
                        }(e, t),
                        l = function(e) {
                            const {
                                accept: t
                            } = e;
                            return (0, a.useMemo)((() => ((0, s.V)(null != e.accept, "accept must be defined"), Array.isArray(t) ? t : [t])), [t])
                        }(e);
                    (0, o.E)((function() {
                        const [e, i] = (0, n.l)(l, d, u);
                        return t.receiveHandlerId(e), r.receiveHandlerId(e), i
                    }), [u, t, d, r, l.map((e => e.toString())).join("|")])
                }
                var d = r(46946);
                let l = !1;
                class h {
                    receiveHandlerId(e) {
                        this.targetId = e
                    }
                    getHandlerId() {
                        return this.targetId
                    }
                    subscribeToStateChange(e, t) {
                        return this.internalMonitor.subscribeToStateChange(e, t)
                    }
                    canDrop() {
                        if (!this.targetId) return !1;
                        (0, s.V)(!l, "You may not call monitor.canDrop() inside your canDrop() implementation. Read more: http://react-dnd.github.io/react-dnd/docs/api/drop-target-monitor");
                        try {
                            return l = !0, this.internalMonitor.canDropOnTarget(this.targetId)
                        } finally {
                            l = !1
                        }
                    }
                    isOver(e) {
                        return !!this.targetId && this.internalMonitor.isOverTarget(this.targetId, e)
                    }
                    getItemType() {
                        return this.internalMonitor.getItemType()
                    }
                    getItem() {
                        return this.internalMonitor.getItem()
                    }
                    getDropResult() {
                        return this.internalMonitor.getDropResult()
                    }
                    didDrop() {
                        return this.internalMonitor.didDrop()
                    }
                    getInitialClientOffset() {
                        return this.internalMonitor.getInitialClientOffset()
                    }
                    getInitialSourceClientOffset() {
                        return this.internalMonitor.getInitialSourceClientOffset()
                    }
                    getSourceClientOffset() {
                        return this.internalMonitor.getSourceClientOffset()
                    }
                    getClientOffset() {
                        return this.internalMonitor.getClientOffset()
                    }
                    getDifferenceFromInitialOffset() {
                        return this.internalMonitor.getDifferenceFromInitialOffset()
                    }
                    constructor(e) {
                        this.targetId = null, this.internalMonitor = e.getMonitor()
                    }
                }
                var g = r(73353),
                    f = r(23506),
                    p = r(31768);
                class v {
                    get connectTarget() {
                        return this.dropTarget
                    }
                    reconnect() {
                        const e = this.didHandlerIdChange() || this.didDropTargetChange() || this.didOptionsChange();
                        e && this.disconnectDropTarget();
                        const t = this.dropTarget;
                        this.handlerId && (t ? e && (this.lastConnectedHandlerId = this.handlerId, this.lastConnectedDropTarget = t, this.lastConnectedDropTargetOptions = this.dropTargetOptions, this.unsubscribeDropTarget = this.backend.connectDropTarget(this.handlerId, t, this.dropTargetOptions)) : this.lastConnectedDropTarget = t)
                    }
                    receiveHandlerId(e) {
                        e !== this.handlerId && (this.handlerId = e, this.reconnect())
                    }
                    get dropTargetOptions() {
                        return this.dropTargetOptionsInternal
                    }
                    set dropTargetOptions(e) {
                        this.dropTargetOptionsInternal = e
                    }
                    didHandlerIdChange() {
                        return this.lastConnectedHandlerId !== this.handlerId
                    }
                    didDropTargetChange() {
                        return this.lastConnectedDropTarget !== this.dropTarget
                    }
                    didOptionsChange() {
                        return !(0, g.b)(this.lastConnectedDropTargetOptions, this.dropTargetOptions)
                    }
                    disconnectDropTarget() {
                        this.unsubscribeDropTarget && (this.unsubscribeDropTarget(), this.unsubscribeDropTarget = void 0)
                    }
                    get dropTarget() {
                        return this.dropTargetNode || this.dropTargetRef && this.dropTargetRef.current
                    }
                    clearDropTarget() {
                        this.dropTargetRef = null, this.dropTargetNode = null
                    }
                    constructor(e) {
                        this.hooks = (0, f.i)({
                            dropTarget: (e, t) => {
                                this.clearDropTarget(), this.dropTargetOptions = t, (0, p.i)(e) ? this.dropTargetRef = e : this.dropTargetNode = e, this.reconnect()
                            }
                        }), this.handlerId = null, this.dropTargetRef = null, this.dropTargetOptionsInternal = null, this.lastConnectedHandlerId = null, this.lastConnectedDropTarget = null, this.lastConnectedDropTargetOptions = null, this.backend = e
                    }
                }
                var m = r(69143);

                function y(e) {
                    return (0, a.useMemo)((() => e.hooks.dropTarget()), [e])
                }

                function b(e, t) {
                    const r = (0, d.I)(e, t),
                        n = function() {
                            const e = (0, i.u)();
                            return (0, a.useMemo)((() => new h(e)), [e])
                        }(),
                        s = function(e) {
                            const t = (0, i.u)(),
                                r = (0, a.useMemo)((() => new v(t.getBackend())), [t]);
                            return (0, o.E)((() => (r.dropTargetOptions = e || null, r.reconnect(), () => r.disconnectDropTarget())), [e]), r
                        }(r.options);
                    return u(r, n, s), [(0, m.j)(r.collect, n, s), y(s)]
                }
            },
            49134: function(e, t, r) {
                r.d(t, {
                    E: function() {
                        return i
                    }
                });
                var n = r(96540);
                const i = "undefined" != typeof window ? n.useLayoutEffect : n.useEffect
            },
            51239: function(e, t, r) {
                r.d(t, {
                    i: function() {
                        return S
                    }
                });
                var n = r(9534),
                    i = r(49134),
                    o = r(96540);
                class s {
                    beginDrag() {
                        const e = this.spec,
                            t = this.monitor;
                        let r = null;
                        return r = "object" == typeof e.item ? e.item : "function" == typeof e.item ? e.item(t) : {}, null != r ? r : null
                    }
                    canDrag() {
                        const e = this.spec,
                            t = this.monitor;
                        return "boolean" == typeof e.canDrag ? e.canDrag : "function" != typeof e.canDrag || e.canDrag(t)
                    }
                    isDragging(e, t) {
                        const r = this.spec,
                            n = this.monitor,
                            {
                                isDragging: i
                            } = r;
                        return i ? i(n) : t === e.getSourceId()
                    }
                    endDrag() {
                        const e = this.spec,
                            t = this.monitor,
                            r = this.connector,
                            {
                                end: n
                            } = e;
                        n && n(t.getItem(), t), r.reconnect()
                    }
                    constructor(e, t, r) {
                        this.spec = e, this.monitor = t, this.connector = r
                    }
                }
                var a = r(25110),
                    c = r(84931);

                function u(e, t, r) {
                    const u = (0, a.u)(),
                        d = function(e, t, r) {
                            const n = (0, o.useMemo)((() => new s(e, t, r)), [t, r]);
                            return (0, o.useEffect)((() => {
                                n.spec = e
                            }), [e]), n
                        }(e, t, r),
                        l = function(e) {
                            return (0, o.useMemo)((() => {
                                const t = e.type;
                                return (0, c.V)(null != t, "spec.type must be defined"), t
                            }), [e])
                        }(e);
                    (0, i.E)((function() {
                        if (null != l) {
                            const [e, i] = (0, n.V)(l, d, u);
                            return t.receiveHandlerId(e), r.receiveHandlerId(e), i
                        }
                    }), [u, t, r, d, l])
                }
                var d = r(46946);
                let l = !1,
                    h = !1;
                class g {
                    receiveHandlerId(e) {
                        this.sourceId = e
                    }
                    getHandlerId() {
                        return this.sourceId
                    }
                    canDrag() {
                        (0, c.V)(!l, "You may not call monitor.canDrag() inside your canDrag() implementation. Read more: http://react-dnd.github.io/react-dnd/docs/api/drag-source-monitor");
                        try {
                            return l = !0, this.internalMonitor.canDragSource(this.sourceId)
                        } finally {
                            l = !1
                        }
                    }
                    isDragging() {
                        if (!this.sourceId) return !1;
                        (0, c.V)(!h, "You may not call monitor.isDragging() inside your isDragging() implementation. Read more: http://react-dnd.github.io/react-dnd/docs/api/drag-source-monitor");
                        try {
                            return h = !0, this.internalMonitor.isDraggingSource(this.sourceId)
                        } finally {
                            h = !1
                        }
                    }
                    subscribeToStateChange(e, t) {
                        return this.internalMonitor.subscribeToStateChange(e, t)
                    }
                    isDraggingSource(e) {
                        return this.internalMonitor.isDraggingSource(e)
                    }
                    isOverTarget(e, t) {
                        return this.internalMonitor.isOverTarget(e, t)
                    }
                    getTargetIds() {
                        return this.internalMonitor.getTargetIds()
                    }
                    isSourcePublic() {
                        return this.internalMonitor.isSourcePublic()
                    }
                    getSourceId() {
                        return this.internalMonitor.getSourceId()
                    }
                    subscribeToOffsetChange(e) {
                        return this.internalMonitor.subscribeToOffsetChange(e)
                    }
                    canDragSource(e) {
                        return this.internalMonitor.canDragSource(e)
                    }
                    canDropOnTarget(e) {
                        return this.internalMonitor.canDropOnTarget(e)
                    }
                    getItemType() {
                        return this.internalMonitor.getItemType()
                    }
                    getItem() {
                        return this.internalMonitor.getItem()
                    }
                    getDropResult() {
                        return this.internalMonitor.getDropResult()
                    }
                    didDrop() {
                        return this.internalMonitor.didDrop()
                    }
                    getInitialClientOffset() {
                        return this.internalMonitor.getInitialClientOffset()
                    }
                    getInitialSourceClientOffset() {
                        return this.internalMonitor.getInitialSourceClientOffset()
                    }
                    getSourceClientOffset() {
                        return this.internalMonitor.getSourceClientOffset()
                    }
                    getClientOffset() {
                        return this.internalMonitor.getClientOffset()
                    }
                    getDifferenceFromInitialOffset() {
                        return this.internalMonitor.getDifferenceFromInitialOffset()
                    }
                    constructor(e) {
                        this.sourceId = null, this.internalMonitor = e.getMonitor()
                    }
                }
                var f = r(23506),
                    p = r(31768),
                    v = r(73353);
                class m {
                    receiveHandlerId(e) {
                        this.handlerId !== e && (this.handlerId = e, this.reconnect())
                    }
                    get connectTarget() {
                        return this.dragSource
                    }
                    get dragSourceOptions() {
                        return this.dragSourceOptionsInternal
                    }
                    set dragSourceOptions(e) {
                        this.dragSourceOptionsInternal = e
                    }
                    get dragPreviewOptions() {
                        return this.dragPreviewOptionsInternal
                    }
                    set dragPreviewOptions(e) {
                        this.dragPreviewOptionsInternal = e
                    }
                    reconnect() {
                        const e = this.reconnectDragSource();
                        this.reconnectDragPreview(e)
                    }
                    reconnectDragSource() {
                        const e = this.dragSource,
                            t = this.didHandlerIdChange() || this.didConnectedDragSourceChange() || this.didDragSourceOptionsChange();
                        return t && this.disconnectDragSource(), this.handlerId ? e ? (t && (this.lastConnectedHandlerId = this.handlerId, this.lastConnectedDragSource = e, this.lastConnectedDragSourceOptions = this.dragSourceOptions, this.dragSourceUnsubscribe = this.backend.connectDragSource(this.handlerId, e, this.dragSourceOptions)), t) : (this.lastConnectedDragSource = e, t) : t
                    }
                    reconnectDragPreview(e = !1) {
                        const t = this.dragPreview,
                            r = e || this.didHandlerIdChange() || this.didConnectedDragPreviewChange() || this.didDragPreviewOptionsChange();
                        r && this.disconnectDragPreview(), this.handlerId && (t ? r && (this.lastConnectedHandlerId = this.handlerId, this.lastConnectedDragPreview = t, this.lastConnectedDragPreviewOptions = this.dragPreviewOptions, this.dragPreviewUnsubscribe = this.backend.connectDragPreview(this.handlerId, t, this.dragPreviewOptions)) : this.lastConnectedDragPreview = t)
                    }
                    didHandlerIdChange() {
                        return this.lastConnectedHandlerId !== this.handlerId
                    }
                    didConnectedDragSourceChange() {
                        return this.lastConnectedDragSource !== this.dragSource
                    }
                    didConnectedDragPreviewChange() {
                        return this.lastConnectedDragPreview !== this.dragPreview
                    }
                    didDragSourceOptionsChange() {
                        return !(0, v.b)(this.lastConnectedDragSourceOptions, this.dragSourceOptions)
                    }
                    didDragPreviewOptionsChange() {
                        return !(0, v.b)(this.lastConnectedDragPreviewOptions, this.dragPreviewOptions)
                    }
                    disconnectDragSource() {
                        this.dragSourceUnsubscribe && (this.dragSourceUnsubscribe(), this.dragSourceUnsubscribe = void 0)
                    }
                    disconnectDragPreview() {
                        this.dragPreviewUnsubscribe && (this.dragPreviewUnsubscribe(), this.dragPreviewUnsubscribe = void 0, this.dragPreviewNode = null, this.dragPreviewRef = null)
                    }
                    get dragSource() {
                        return this.dragSourceNode || this.dragSourceRef && this.dragSourceRef.current
                    }
                    get dragPreview() {
                        return this.dragPreviewNode || this.dragPreviewRef && this.dragPreviewRef.current
                    }
                    clearDragSource() {
                        this.dragSourceNode = null, this.dragSourceRef = null
                    }
                    clearDragPreview() {
                        this.dragPreviewNode = null, this.dragPreviewRef = null
                    }
                    constructor(e) {
                        this.hooks = (0, f.i)({
                            dragSource: (e, t) => {
                                this.clearDragSource(), this.dragSourceOptions = t || null, (0, p.i)(e) ? this.dragSourceRef = e : this.dragSourceNode = e, this.reconnectDragSource()
                            },
                            dragPreview: (e, t) => {
                                this.clearDragPreview(), this.dragPreviewOptions = t || null, (0, p.i)(e) ? this.dragPreviewRef = e : this.dragPreviewNode = e, this.reconnectDragPreview()
                            }
                        }), this.handlerId = null, this.dragSourceRef = null, this.dragSourceOptionsInternal = null, this.dragPreviewRef = null, this.dragPreviewOptionsInternal = null, this.lastConnectedHandlerId = null, this.lastConnectedDragSource = null, this.lastConnectedDragSourceOptions = null, this.lastConnectedDragPreview = null, this.lastConnectedDragPreviewOptions = null, this.backend = e
                    }
                }
                var y = r(69143);

                function b(e) {
                    return (0, o.useMemo)((() => e.hooks.dragSource()), [e])
                }

                function D(e) {
                    return (0, o.useMemo)((() => e.hooks.dragPreview()), [e])
                }

                function S(e, t) {
                    const r = (0, d.I)(e, t);
                    (0, c.V)(!r.begin, "useDrag::spec.begin was deprecated in v14. Replace spec.begin() with spec.item(). (see more here - https://react-dnd.github.io/react-dnd/docs/api/use-drag)");
                    const n = function() {
                            const e = (0, a.u)();
                            return (0, o.useMemo)((() => new g(e)), [e])
                        }(),
                        s = function(e, t) {
                            const r = (0, a.u)(),
                                n = (0, o.useMemo)((() => new m(r.getBackend())), [r]);
                            return (0, i.E)((() => (n.dragSourceOptions = e || null, n.reconnect(), () => n.disconnectDragSource())), [n, e]), (0, i.E)((() => (n.dragPreviewOptions = t || null, n.reconnect(), () => n.disconnectDragPreview())), [n, t]), n
                        }(r.options, r.previewOptions);
                    return u(r, n, s), [(0, y.j)(r.collect, n, s), b(s), D(s)]
                }
            },
            69143: function(e, t, r) {
                r.d(t, {
                    j: function() {
                        return o
                    }
                });
                var n = r(49134),
                    i = r(1725);

                function o(e, t, r) {
                    return function(e, t, r) {
                        const [o, s] = (0, i.F)(e, t, r);
                        return (0, n.E)((function() {
                            const t = e.getHandlerId();
                            if (null != t) return e.subscribeToStateChange(s, {
                                handlerIds: [t]
                            })
                        }), [e, s]), o
                    }(t, e || (() => ({})), (() => r.reconnect()))
                }
            },
            73353: function(e, t, r) {
                function n(e, t, r, n) {
                    let i = r ? r.call(n, e, t) : void 0;
                    if (void 0 !== i) return !!i;
                    if (e === t) return !0;
                    if ("object" != typeof e || !e || "object" != typeof t || !t) return !1;
                    const o = Object.keys(e),
                        s = Object.keys(t);
                    if (o.length !== s.length) return !1;
                    const a = Object.prototype.hasOwnProperty.bind(t);
                    for (let s = 0; s < o.length; s++) {
                        const c = o[s];
                        if (!a(c)) return !1;
                        const u = e[c],
                            d = t[c];
                        if (i = r ? r.call(n, u, d, c) : void 0, !1 === i || void 0 === i && u !== d) return !1
                    }
                    return !0
                }
                r.d(t, {
                    b: function() {
                        return n
                    }
                })
            },
            84931: function(e, t, r) {
                function n(e, t, ...r) {
                    if ("undefined" != typeof process && void 0 === t) throw new Error("invariant requires an error message argument");
                    if (!e) {
                        let e;
                        if (void 0 === t) e = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                        else {
                            let n = 0;
                            e = new Error(t.replace(/%s/g, (function() {
                                return r[n++]
                            }))), e.name = "Invariant Violation"
                        }
                        throw e.framesToPop = 1, e
                    }
                }
                r.d(t, {
                    V: function() {
                        return n
                    }
                })
            },
            85517: function(e, t, r) {
                r.d(t, {
                    t2: function() {
                        return w
                    }
                });
                var n = {};

                function i(e) {
                    let t = null;
                    return () => (null == t && (t = e()), t)
                }
                r.r(n), r.d(n, {
                    FILE: function() {
                        return h
                    },
                    HTML: function() {
                        return p
                    },
                    TEXT: function() {
                        return f
                    },
                    URL: function() {
                        return g
                    }
                });
                class o {
                    enter(e) {
                        const t = this.entered.length;
                        return this.entered = function(e, t) {
                            const r = new Set,
                                n = e => r.add(e);
                            e.forEach(n), t.forEach(n);
                            const i = [];
                            return r.forEach((e => i.push(e))), i
                        }(this.entered.filter((t => this.isNodeInDocument(t) && (!t.contains || t.contains(e)))), [e]), 0 === t && this.entered.length > 0
                    }
                    leave(e) {
                        const t = this.entered.length;
                        var r, n;
                        return this.entered = (r = this.entered.filter(this.isNodeInDocument), n = e, r.filter((e => e !== n))), t > 0 && 0 === this.entered.length
                    }
                    reset() {
                        this.entered = []
                    }
                    constructor(e) {
                        this.entered = [], this.isNodeInDocument = e
                    }
                }
                const s = i((() => /firefox/i.test(navigator.userAgent))),
                    a = i((() => Boolean(window.safari)));
                class c {
                    interpolate(e) {
                        const {
                            xs: t,
                            ys: r,
                            c1s: n,
                            c2s: i,
                            c3s: o
                        } = this;
                        let s = t.length - 1;
                        if (e === t[s]) return r[s];
                        let a, c = 0,
                            u = o.length - 1;
                        for (; c <= u;) {
                            a = Math.floor(.5 * (c + u));
                            const n = t[a];
                            if (n < e) c = a + 1;
                            else {
                                if (!(n > e)) return r[a];
                                u = a - 1
                            }
                        }
                        s = Math.max(0, u);
                        const d = e - t[s],
                            l = d * d;
                        return r[s] + n[s] * d + i[s] * l + o[s] * d * l
                    }
                    constructor(e, t) {
                        const {
                            length: r
                        } = e, n = [];
                        for (let e = 0; e < r; e++) n.push(e);
                        n.sort(((t, r) => e[t] < e[r] ? -1 : 1));
                        const i = [],
                            o = [],
                            s = [];
                        let a, c;
                        for (let n = 0; n < r - 1; n++) a = e[n + 1] - e[n], c = t[n + 1] - t[n], o.push(a), i.push(c), s.push(c / a);
                        const u = [s[0]];
                        for (let e = 0; e < o.length - 1; e++) {
                            const t = s[e],
                                r = s[e + 1];
                            if (t * r <= 0) u.push(0);
                            else {
                                a = o[e];
                                const n = o[e + 1],
                                    i = a + n;
                                u.push(3 * i / ((i + n) / t + (i + a) / r))
                            }
                        }
                        u.push(s[s.length - 1]);
                        const d = [],
                            l = [];
                        let h;
                        for (let e = 0; e < u.length - 1; e++) {
                            h = s[e];
                            const t = u[e],
                                r = 1 / o[e],
                                n = t + u[e + 1] - h - h;
                            d.push((h - t - n) * r), l.push(n * r * r)
                        }
                        this.xs = e, this.ys = t, this.c1s = u, this.c2s = d, this.c3s = l
                    }
                }

                function u(e) {
                    const t = 1 === e.nodeType ? e : e.parentElement;
                    if (!t) return null;
                    const {
                        top: r,
                        left: n
                    } = t.getBoundingClientRect();
                    return {
                        x: n,
                        y: r
                    }
                }

                function d(e) {
                    return {
                        x: e.clientX,
                        y: e.clientY
                    }
                }

                function l(e, t, r, n, i) {
                    const o = "IMG" === (d = t).nodeName && (s() || !(null === (l = document.documentElement) || void 0 === l ? void 0 : l.contains(d)));
                    var d, l;
                    const h = u(o ? e : t),
                        g = {
                            x: r.x - h.x,
                            y: r.y - h.y
                        },
                        {
                            offsetWidth: f,
                            offsetHeight: p
                        } = e,
                        {
                            anchorX: v,
                            anchorY: m
                        } = n,
                        {
                            dragPreviewWidth: y,
                            dragPreviewHeight: b
                        } = function(e, t, r, n) {
                            let i = e ? t.width : r,
                                o = e ? t.height : n;
                            return a() && e && (o /= window.devicePixelRatio, i /= window.devicePixelRatio), {
                                dragPreviewWidth: i,
                                dragPreviewHeight: o
                            }
                        }(o, t, f, p),
                        {
                            offsetX: D,
                            offsetY: S
                        } = i,
                        O = 0 === S || S;
                    return {
                        x: 0 === D || D ? D : new c([0, .5, 1], [g.x, g.x / f * y, g.x + y - f]).interpolate(v),
                        y: O ? S : (() => {
                            let e = new c([0, .5, 1], [g.y, g.y / p * b, g.y + b - p]).interpolate(m);
                            return a() && o && (e += (window.devicePixelRatio - 1) * b), e
                        })()
                    }
                }
                const h = "__NATIVE_FILE__",
                    g = "__NATIVE_URL__",
                    f = "__NATIVE_TEXT__",
                    p = "__NATIVE_HTML__";

                function v(e, t, r) {
                    const n = t.reduce(((t, r) => t || e.getData(r)), "");
                    return null != n ? n : r
                }
                const m = {
                    [h]: {
                        exposeProperties: {
                            files: e => Array.prototype.slice.call(e.files),
                            items: e => e.items,
                            dataTransfer: e => e
                        },
                        matchesTypes: ["Files"]
                    },
                    [p]: {
                        exposeProperties: {
                            html: (e, t) => v(e, t, ""),
                            dataTransfer: e => e
                        },
                        matchesTypes: ["Html", "text/html"]
                    },
                    [g]: {
                        exposeProperties: {
                            urls: (e, t) => v(e, t, "").split("\n"),
                            dataTransfer: e => e
                        },
                        matchesTypes: ["Url", "text/uri-list"]
                    },
                    [f]: {
                        exposeProperties: {
                            text: (e, t) => v(e, t, ""),
                            dataTransfer: e => e
                        },
                        matchesTypes: ["Text", "text/plain"]
                    }
                };
                class y {
                    initializeExposedProperties() {
                        Object.keys(this.config.exposeProperties).forEach((e => {
                            Object.defineProperty(this.item, e, {
                                configurable: !0,
                                enumerable: !0,
                                get() {
                                    return console.warn(`Browser doesn't allow reading "${e}" until the drop event.`), null
                                }
                            })
                        }))
                    }
                    loadDataTransfer(e) {
                        if (e) {
                            const t = {};
                            Object.keys(this.config.exposeProperties).forEach((r => {
                                const n = this.config.exposeProperties[r];
                                null != n && (t[r] = {
                                    value: n(e, this.config.matchesTypes),
                                    configurable: !0,
                                    enumerable: !0
                                })
                            })), Object.defineProperties(this.item, t)
                        }
                    }
                    canDrag() {
                        return !0
                    }
                    beginDrag() {
                        return this.item
                    }
                    isDragging(e, t) {
                        return t === e.getSourceId()
                    }
                    endDrag() {}
                    constructor(e) {
                        this.config = e, this.item = {}, this.initializeExposedProperties()
                    }
                }

                function b(e) {
                    if (!e) return null;
                    const t = Array.prototype.slice.call(e.types || []);
                    return Object.keys(m).filter((e => {
                        const r = m[e];
                        return !!(null == r ? void 0 : r.matchesTypes) && r.matchesTypes.some((e => t.indexOf(e) > -1))
                    }))[0] || null
                }
                class D {
                    get window() {
                        return this.globalContext ? this.globalContext : "undefined" != typeof window ? window : void 0
                    }
                    get document() {
                        var e;
                        return (null === (e = this.globalContext) || void 0 === e ? void 0 : e.document) ? this.globalContext.document : this.window ? this.window.document : void 0
                    }
                    get rootElement() {
                        var e;
                        return (null === (e = this.optionsArgs) || void 0 === e ? void 0 : e.rootElement) || this.window
                    }
                    constructor(e, t) {
                        this.ownerDocument = null, this.globalContext = e, this.optionsArgs = t
                    }
                }

                function S(e, t, r) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: r,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = r, e
                }

                function O(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = null != arguments[t] ? arguments[t] : {},
                            n = Object.keys(r);
                        "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter((function(e) {
                            return Object.getOwnPropertyDescriptor(r, e).enumerable
                        })))), n.forEach((function(t) {
                            S(e, t, r[t])
                        }))
                    }
                    return e
                }
                class T {
                    profile() {
                        var e, t;
                        return {
                            sourcePreviewNodes: this.sourcePreviewNodes.size,
                            sourcePreviewNodeOptions: this.sourcePreviewNodeOptions.size,
                            sourceNodeOptions: this.sourceNodeOptions.size,
                            sourceNodes: this.sourceNodes.size,
                            dragStartSourceIds: (null === (e = this.dragStartSourceIds) || void 0 === e ? void 0 : e.length) || 0,
                            dropTargetIds: this.dropTargetIds.length,
                            dragEnterTargetIds: this.dragEnterTargetIds.length,
                            dragOverTargetIds: (null === (t = this.dragOverTargetIds) || void 0 === t ? void 0 : t.length) || 0
                        }
                    }
                    get window() {
                        return this.options.window
                    }
                    get document() {
                        return this.options.document
                    }
                    get rootElement() {
                        return this.options.rootElement
                    }
                    setup() {
                        const e = this.rootElement;
                        if (void 0 !== e) {
                            if (e.__isReactDndBackendSetUp) throw new Error("Cannot have two HTML5 backends at the same time.");
                            e.__isReactDndBackendSetUp = !0, this.addEventListeners(e)
                        }
                    }
                    teardown() {
                        const e = this.rootElement;
                        var t;
                        void 0 !== e && (e.__isReactDndBackendSetUp = !1, this.removeEventListeners(this.rootElement), this.clearCurrentDragSourceNode(), this.asyncEndDragFrameId && (null === (t = this.window) || void 0 === t || t.cancelAnimationFrame(this.asyncEndDragFrameId)))
                    }
                    connectDragPreview(e, t, r) {
                        return this.sourcePreviewNodeOptions.set(e, r), this.sourcePreviewNodes.set(e, t), () => {
                            this.sourcePreviewNodes.delete(e), this.sourcePreviewNodeOptions.delete(e)
                        }
                    }
                    connectDragSource(e, t, r) {
                        this.sourceNodes.set(e, t), this.sourceNodeOptions.set(e, r);
                        const n = t => this.handleDragStart(t, e),
                            i = e => this.handleSelectStart(e);
                        return t.setAttribute("draggable", "true"), t.addEventListener("dragstart", n), t.addEventListener("selectstart", i), () => {
                            this.sourceNodes.delete(e), this.sourceNodeOptions.delete(e), t.removeEventListener("dragstart", n), t.removeEventListener("selectstart", i), t.setAttribute("draggable", "false")
                        }
                    }
                    connectDropTarget(e, t) {
                        const r = t => this.handleDragEnter(t, e),
                            n = t => this.handleDragOver(t, e),
                            i = t => this.handleDrop(t, e);
                        return t.addEventListener("dragenter", r), t.addEventListener("dragover", n), t.addEventListener("drop", i), () => {
                            t.removeEventListener("dragenter", r), t.removeEventListener("dragover", n), t.removeEventListener("drop", i)
                        }
                    }
                    addEventListeners(e) {
                        e.addEventListener && (e.addEventListener("dragstart", this.handleTopDragStart), e.addEventListener("dragstart", this.handleTopDragStartCapture, !0), e.addEventListener("dragend", this.handleTopDragEndCapture, !0), e.addEventListener("dragenter", this.handleTopDragEnter), e.addEventListener("dragenter", this.handleTopDragEnterCapture, !0), e.addEventListener("dragleave", this.handleTopDragLeaveCapture, !0), e.addEventListener("dragover", this.handleTopDragOver), e.addEventListener("dragover", this.handleTopDragOverCapture, !0), e.addEventListener("drop", this.handleTopDrop), e.addEventListener("drop", this.handleTopDropCapture, !0))
                    }
                    removeEventListeners(e) {
                        e.removeEventListener && (e.removeEventListener("dragstart", this.handleTopDragStart), e.removeEventListener("dragstart", this.handleTopDragStartCapture, !0), e.removeEventListener("dragend", this.handleTopDragEndCapture, !0), e.removeEventListener("dragenter", this.handleTopDragEnter), e.removeEventListener("dragenter", this.handleTopDragEnterCapture, !0), e.removeEventListener("dragleave", this.handleTopDragLeaveCapture, !0), e.removeEventListener("dragover", this.handleTopDragOver), e.removeEventListener("dragover", this.handleTopDragOverCapture, !0), e.removeEventListener("drop", this.handleTopDrop), e.removeEventListener("drop", this.handleTopDropCapture, !0))
                    }
                    getCurrentSourceNodeOptions() {
                        const e = this.monitor.getSourceId(),
                            t = this.sourceNodeOptions.get(e);
                        return O({
                            dropEffect: this.altKeyPressed ? "copy" : "move"
                        }, t || {})
                    }
                    getCurrentDropEffect() {
                        return this.isDraggingNativeItem() ? "copy" : this.getCurrentSourceNodeOptions().dropEffect
                    }
                    getCurrentSourcePreviewNodeOptions() {
                        const e = this.monitor.getSourceId();
                        return O({
                            anchorX: .5,
                            anchorY: .5,
                            captureDraggingState: !1
                        }, this.sourcePreviewNodeOptions.get(e) || {})
                    }
                    isDraggingNativeItem() {
                        const e = this.monitor.getItemType();
                        return Object.keys(n).some((t => n[t] === e))
                    }
                    beginDragNativeItem(e, t) {
                        this.clearCurrentDragSourceNode(), this.currentNativeSource = function(e, t) {
                            const r = m[e];
                            if (!r) throw new Error(`native type ${e} has no configuration`);
                            const n = new y(r);
                            return n.loadDataTransfer(t), n
                        }(e, t), this.currentNativeHandle = this.registry.addSource(e, this.currentNativeSource), this.actions.beginDrag([this.currentNativeHandle])
                    }
                    setCurrentDragSourceNode(e) {
                        this.clearCurrentDragSourceNode(), this.currentDragSourceNode = e;
                        this.mouseMoveTimeoutTimer = setTimeout((() => {
                            var e;
                            return null === (e = this.rootElement) || void 0 === e ? void 0 : e.addEventListener("mousemove", this.endDragIfSourceWasRemovedFromDOM, !0)
                        }), 1e3)
                    }
                    clearCurrentDragSourceNode() {
                        if (this.currentDragSourceNode) {
                            var e;
                            if (this.currentDragSourceNode = null, this.rootElement) null === (e = this.window) || void 0 === e || e.clearTimeout(this.mouseMoveTimeoutTimer || void 0), this.rootElement.removeEventListener("mousemove", this.endDragIfSourceWasRemovedFromDOM, !0);
                            return this.mouseMoveTimeoutTimer = null, !0
                        }
                        return !1
                    }
                    handleDragStart(e, t) {
                        e.defaultPrevented || (this.dragStartSourceIds || (this.dragStartSourceIds = []), this.dragStartSourceIds.unshift(t))
                    }
                    handleDragEnter(e, t) {
                        this.dragEnterTargetIds.unshift(t)
                    }
                    handleDragOver(e, t) {
                        null === this.dragOverTargetIds && (this.dragOverTargetIds = []), this.dragOverTargetIds.unshift(t)
                    }
                    handleDrop(e, t) {
                        this.dropTargetIds.unshift(t)
                    }
                    constructor(e, t, r) {
                        this.sourcePreviewNodes = new Map, this.sourcePreviewNodeOptions = new Map, this.sourceNodes = new Map, this.sourceNodeOptions = new Map, this.dragStartSourceIds = null, this.dropTargetIds = [], this.dragEnterTargetIds = [], this.currentNativeSource = null, this.currentNativeHandle = null, this.currentDragSourceNode = null, this.altKeyPressed = !1, this.mouseMoveTimeoutTimer = null, this.asyncEndDragFrameId = null, this.dragOverTargetIds = null, this.lastClientOffset = null, this.hoverRafId = null, this.getSourceClientOffset = e => {
                            const t = this.sourceNodes.get(e);
                            return t && u(t) || null
                        }, this.endDragNativeItem = () => {
                            this.isDraggingNativeItem() && (this.actions.endDrag(), this.currentNativeHandle && this.registry.removeSource(this.currentNativeHandle), this.currentNativeHandle = null, this.currentNativeSource = null)
                        }, this.isNodeInDocument = e => Boolean(e && this.document && this.document.body && this.document.body.contains(e)), this.endDragIfSourceWasRemovedFromDOM = () => {
                            const e = this.currentDragSourceNode;
                            null == e || this.isNodeInDocument(e) || this.clearCurrentDragSourceNode() && this.monitor.isDragging() && this.actions.endDrag()
                        }, this.handleTopDragStartCapture = () => {
                            this.clearCurrentDragSourceNode(), this.dragStartSourceIds = []
                        }, this.handleTopDragStart = e => {
                            if (e.defaultPrevented) return;
                            const {
                                dragStartSourceIds: t
                            } = this;
                            this.dragStartSourceIds = null;
                            const r = d(e);
                            this.monitor.isDragging() && this.actions.endDrag(), this.actions.beginDrag(t || [], {
                                publishSource: !1,
                                getSourceClientOffset: this.getSourceClientOffset,
                                clientOffset: r
                            });
                            const {
                                dataTransfer: n
                            } = e, i = b(n);
                            if (this.monitor.isDragging()) {
                                if (n && "function" == typeof n.setDragImage) {
                                    const e = this.monitor.getSourceId(),
                                        t = this.sourceNodes.get(e),
                                        i = this.sourcePreviewNodes.get(e) || t;
                                    if (i) {
                                        const {
                                            anchorX: e,
                                            anchorY: o,
                                            offsetX: s,
                                            offsetY: a
                                        } = this.getCurrentSourcePreviewNodeOptions(), c = l(t, i, r, {
                                            anchorX: e,
                                            anchorY: o
                                        }, {
                                            offsetX: s,
                                            offsetY: a
                                        });
                                        n.setDragImage(i, c.x, c.y)
                                    }
                                }
                                try {
                                    null == n || n.setData("application/json", {})
                                } catch (e) {}
                                this.setCurrentDragSourceNode(e.target);
                                const {
                                    captureDraggingState: t
                                } = this.getCurrentSourcePreviewNodeOptions();
                                t ? this.actions.publishDragSource() : setTimeout((() => this.actions.publishDragSource()), 0)
                            } else if (i) this.beginDragNativeItem(i);
                            else {
                                if (n && !n.types && (e.target && !e.target.hasAttribute || !e.target.hasAttribute("draggable"))) return;
                                e.preventDefault()
                            }
                        }, this.handleTopDragEndCapture = () => {
                            this.clearCurrentDragSourceNode() && this.monitor.isDragging() && this.actions.endDrag()
                        }, this.handleTopDragEnterCapture = e => {
                            var t;
                            (this.dragEnterTargetIds = [], this.isDraggingNativeItem()) && (null === (t = this.currentNativeSource) || void 0 === t || t.loadDataTransfer(e.dataTransfer));
                            if (!this.enterLeaveCounter.enter(e.target) || this.monitor.isDragging()) return;
                            const {
                                dataTransfer: r
                            } = e, n = b(r);
                            n && this.beginDragNativeItem(n, r)
                        }, this.handleTopDragEnter = e => {
                            const {
                                dragEnterTargetIds: t
                            } = this;
                            if (this.dragEnterTargetIds = [], !this.monitor.isDragging()) return;
                            this.altKeyPressed = e.altKey, t.length > 0 && this.actions.hover(t, {
                                clientOffset: d(e)
                            });
                            t.some((e => this.monitor.canDropOnTarget(e))) && (e.preventDefault(), e.dataTransfer && (e.dataTransfer.dropEffect = this.getCurrentDropEffect()))
                        }, this.handleTopDragOverCapture = e => {
                            var t;
                            (this.dragOverTargetIds = [], this.isDraggingNativeItem()) && (null === (t = this.currentNativeSource) || void 0 === t || t.loadDataTransfer(e.dataTransfer))
                        }, this.handleTopDragOver = e => {
                            const {
                                dragOverTargetIds: t
                            } = this;
                            if (this.dragOverTargetIds = [], !this.monitor.isDragging()) return e.preventDefault(), void(e.dataTransfer && (e.dataTransfer.dropEffect = "none"));
                            this.altKeyPressed = e.altKey, this.lastClientOffset = d(e), null === this.hoverRafId && "undefined" != typeof requestAnimationFrame && (this.hoverRafId = requestAnimationFrame((() => {
                                this.monitor.isDragging() && this.actions.hover(t || [], {
                                    clientOffset: this.lastClientOffset
                                }), this.hoverRafId = null
                            })));
                            (t || []).some((e => this.monitor.canDropOnTarget(e))) ? (e.preventDefault(), e.dataTransfer && (e.dataTransfer.dropEffect = this.getCurrentDropEffect())) : this.isDraggingNativeItem() ? e.preventDefault() : (e.preventDefault(), e.dataTransfer && (e.dataTransfer.dropEffect = "none"))
                        }, this.handleTopDragLeaveCapture = e => {
                            this.isDraggingNativeItem() && e.preventDefault();
                            this.enterLeaveCounter.leave(e.target) && this.isDraggingNativeItem() && setTimeout((() => this.endDragNativeItem()), 0)
                        }, this.handleTopDropCapture = e => {
                            var t;
                            (this.dropTargetIds = [], this.isDraggingNativeItem()) ? (e.preventDefault(), null === (t = this.currentNativeSource) || void 0 === t || t.loadDataTransfer(e.dataTransfer)) : b(e.dataTransfer) && e.preventDefault();
                            this.enterLeaveCounter.reset()
                        }, this.handleTopDrop = e => {
                            const {
                                dropTargetIds: t
                            } = this;
                            this.dropTargetIds = [], this.actions.hover(t, {
                                clientOffset: d(e)
                            }), this.actions.drop({
                                dropEffect: this.getCurrentDropEffect()
                            }), this.isDraggingNativeItem() ? this.endDragNativeItem() : this.monitor.isDragging() && this.actions.endDrag()
                        }, this.handleSelectStart = e => {
                            const t = e.target;
                            "function" == typeof t.dragDrop && ("INPUT" === t.tagName || "SELECT" === t.tagName || "TEXTAREA" === t.tagName || t.isContentEditable || (e.preventDefault(), t.dragDrop()))
                        }, this.options = new D(t, r), this.actions = e.getActions(), this.monitor = e.getMonitor(), this.registry = e.getRegistry(), this.enterLeaveCounter = new o(this.isNodeInDocument)
                    }
                }
                const w = function(e, t, r) {
                    return new T(e, t, r)
                }
            }
        }
    ]);
//# sourceMappingURL=1706.c03d6d0d1fe4f211f4ee.js.map
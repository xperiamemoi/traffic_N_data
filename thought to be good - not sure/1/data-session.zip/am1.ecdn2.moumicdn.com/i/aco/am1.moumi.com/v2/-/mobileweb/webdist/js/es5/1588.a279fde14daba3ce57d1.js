var _global;
! function() {
    try {
        var t = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            e = (new Error).stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "9aba0882-e353-40f5-8454-7c23d0fd530b", t._sentryDebugIdIdentifier = "sentry-dbid-9aba0882-e353-40f5-8454-7c23d0fd530b")
    } catch (t) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var t = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                e = (new Error).stack;
            e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "9aba0882-e353-40f5-8454-7c23d0fd530b", t._sentryDebugIdIdentifier = "sentry-dbid-9aba0882-e353-40f5-8454-7c23d0fd530b")
        } catch (t) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [1588], {
            24500: function(t, e, i) {
                i(52675), i(89463), i(50113), i(26099), i(48980);
                var n = i(96540),
                    o = i(80021),
                    a = i(93019),
                    r = i(79860),
                    c = i(4571),
                    s = i(46770),
                    f = i(51634),
                    u = i(40578),
                    l = i(30784),
                    d = i(20017),
                    h = i(74848);
                e.A = function(t) {
                    var e, i = t.header,
                        p = t.description,
                        A = t.buttonText,
                        g = t.intentions,
                        v = t.onConfirm,
                        N = t.preselectedIntentionId,
                        b = (0, n.useState)(N || (null == (e = g.find((function(t) {
                            return t.default_for_new_users
                        }))) ? void 0 : e.tiw_phrase_id)),
                        I = b[0],
                        _ = b[1],
                        T = (0, a.p)(g, I, (function(t) {
                            _(t), (0, r.sx)(332, {
                                element: 1767,
                                position: g.findIndex((function(e) {
                                    return e.tiw_phrase_id === t
                                }))
                            })
                        }));
                    return (0, h.jsxs)(c.A, {
                        isCompact: !0,
                        children: [(0, h.jsx)(u.A, {
                            text: i,
                            tag: "h2"
                        }), (0, h.jsx)(l.A, {
                            text: p
                        }), (0, h.jsx)(f.A, {
                            children: (0, h.jsx)(o.A, {
                                intentions: T
                            })
                        }), (0, h.jsx)(s.A, {
                            children: (0, h.jsx)(d.A, {
                                text: A,
                                onClick: function() {
                                    I && v(I), (0, r.sx)(332, {
                                        element: 395
                                    })
                                },
                                dataQA: {
                                    "data-qa": "tiw-save-button"
                                }
                            })
                        })]
                    })
                }
            },
            31190: function(t, e, i) {
                i(25276), i(28706), i(11392), i(60739), i(27208), i(50113), i(26099), i(27495), i(74423), i(21699), i(48980), i(10287);
                var n = i(1978),
                    o = i(3508),
                    a = i(31709),
                    r = i(61155),
                    c = i(13264),
                    s = i(65297),
                    f = i(58385),
                    u = i(40075),
                    l = i(36521),
                    d = i(73090),
                    h = i(93529),
                    p = i(37414),
                    A = i(30685),
                    g = i(61405),
                    v = i(75248),
                    N = i(13614),
                    b = i(65422),
                    I = i(41025),
                    _ = i(30922),
                    T = i(7541),
                    y = i(1168),
                    w = i(39778),
                    O = i(88309),
                    m = i(28030),
                    E = i(20387),
                    R = i(31087),
                    S = i(49952),
                    k = i(37905),
                    x = i(1765),
                    P = i(59977),
                    C = i(48788),
                    U = i(15566),
                    M = i(35837),
                    D = i(74389),
                    B = i(60808),
                    V = i(83186),
                    j = i(95773),
                    L = i(74848);

                function H(t, e) {
                    return H = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                        return t.__proto__ = e, t
                    }, H(t, e)
                }
                var F, q = [81, 60, 66, 50, 3, 56, 78, 73, 44, 89, 120, 2, 112, 163, 170, 171, 140],
                    G = [7, 1],
                    Q = [D.x.SPP_TRIAL, D.x.PAY];

                function Y(t) {
                    return -1 !== q.indexOf(t.getType())
                }
                var J = function(t) {
                    var e, i;

                    function c() {
                        for (var e, i = arguments.length, n = new Array(i), o = 0; o < i; o++) n[o] = arguments[o];
                        return (e = t.call.apply(t, [this].concat(n)) || this).queue = [], e.ignorePhoneVerificationNotification = !1, e.currentNotification = null, e
                    }
                    i = t, (e = c).prototype = Object.create(i.prototype), e.prototype.constructor = e, H(e, i);
                    var F = c.prototype;
                    return F.init = function() {
                        return y.A.onUnblock(this.onAppUnblocked_, this), this.ignorePhoneVerificationNotification = !1, this.queue = [], this
                    }, F.onAppUnblocked_ = function() {
                        this.advanceQueue()
                    }, F.onStart = function() {
                        v.A.getInstance().on(v.A.Type.NOTIFICATION, this.onClientNotification, this), v.A.getInstance().on(v.A.Type.SYSTEM_NOTIFICATION, this.onSystemNotification, this)
                    }, F.onStop = function() {
                        return v.A.getInstance().off(v.A.Type.NOTIFICATION, this.onClientNotification, this), v.A.getInstance().off(v.A.Type.SYSTEM_NOTIFICATION, this.onSystemNotification, this), t.prototype.onStop.call(this)
                    }, F.onSystemNotification = function(t) {
                        switch (t.id) {
                            case 5:
                            case 2:
                            case 6:
                                R.A.getInstance().invalidate(d.A.getUserId())
                        }
                    }, F.onClientNotification = function(t) {
                        this.addToQueue((0, M.A)(t, U.z5N)), this.advanceQueue()
                    }, F.addToQueue = function(t) {
                        if (t instanceof U.z5N && "string" == typeof t.getId() && !this.isDuplicated(t) && !(t.getMessage("").startsWith("Connected to QA") || l.A.selenium && t.getMessage("").startsWith("Connected to "))) {
                            var e = k.A.controller;
                            null != e && e.discardGenericPromos && 81 === t.getType() || this.ignorePhoneVerificationNotification && W(t) || this.queue.push(t)
                        }
                    }, F.isDuplicated = function(t) {
                        var e, i = t.getId();
                        if (i === (null == (e = this.currentNotification) ? void 0 : e.getId())) return !0;
                        for (var n = 0; n < this.queue.length; n += 1)
                            if (this.queue[n].getId() === i) return !0;
                        return !1
                    }, F.advanceQueue = function() {
                        var t;
                        this.queue.length && null === this.currentNotification && (this.currentNotification = this.queue.shift(), Y(t = this.currentNotification) || -1 === G.indexOf(t.getAction()) || function(t) {
                            return 96 === t.getType()
                        }(t) ? Y(this.currentNotification) ? this.overlayNotification() : ! function(t) {
                            return !Y(t) && 9 === t.getAction()
                        }(this.currentNotification) ? this.notificationHandled() : this.spendCredits() : this.notifyMessage())
                    }, F.performNotificationAction = function() {
                        var t, e;
                        12 === (null == (t = this.currentNotification) ? void 0 : t.getType()) ? (e = {
                            back: o.A.get("default.page"),
                            hotPanelData: {
                                activationPlace: 48
                            },
                            productType: 1
                        }, I.A.navigateToPayment(e), this.notificationHandled()) : h.A.showNotification({
                            type: h.A.TYPES.ERROR
                        })
                    }, F.overlayNotification = function() {
                        var t = this.currentNotification;
                        if (t) {
                            var e = t.getType(),
                                i = t.getPromoBlock(),
                                n = i ? i.getPromoBlockType() : null,
                                o = t.toJSON();
                            this.handleOverlayNotification({
                                type: e,
                                promo: i,
                                promoBlockType: n,
                                notificationJSON: o,
                                notification: t
                            }) && (0, S.cj)(this.notificationHandled.bind(this))
                        }
                    }, F.handleOverlayNotification = function(t) {
                        var e, i = t.type,
                            n = t.promo,
                            o = t.promoBlockType,
                            a = t.notificationJSON,
                            c = t.notification,
                            s = !0;
                        switch (i) {
                            case 78:
                                ! function(t, e) {
                                    var i, n;
                                    t && null != e && null != (i = e.pictures) && null != (i = i[0]) && i.video && (0, N.NN)(null == (n = e.pictures) || null == (n = n[0].video) ? void 0 : n.url).then((function(e) {
                                        var i = e[0];
                                        f.A.navigate(D.x.UPLOAD_VIDEO, {
                                            clientNotification: t,
                                            src: i
                                        })
                                    })).catch((function(t) {
                                        return (0, j.gf)(t, "Upload video")
                                    }))
                                }(a, n.toJSON());
                                break;
                            case 120:
                                this.showPassiveMatches(a), s = !1;
                                break;
                            case 2:
                                this.showTiwMappingPopup(a), s = !1;
                                break;
                            case 3:
                                setTimeout((function() {
                                    return f.A.navigate(D.x.MODERATED_PHOTOS, {
                                        notification: a
                                    })
                                }), 700);
                                break;
                            case 81:
                                if (61 === o) return;
                                if (153 === o && !m.A.isDevFeatureEnabled(P.v.STILL_YOUR_NUMBER)) return;
                                s = this.handleOverlayNotificationGenericPromo({
                                    promo: n,
                                    promoBlockType: o,
                                    notificationJSON: a
                                });
                                break;
                            case 50:
                                f.A.navigate(D.x.NICE_NAME, !1, {
                                    notification: a
                                });
                                break;
                            case 44:
                                f.A.navigate(D.x.ABUSE_WARNING, !1, {
                                    notification: a
                                });
                                break;
                            case 73:
                                92 === o ? f.A.navigate(D.x.NEVER_LOOSE_ACCOUNT, !1, {
                                    notification: a,
                                    isNotification: "true"
                                }) : x.A.handleNotification(c);
                                break;
                            case 60:
                                T.A.show(c);
                                break;
                            case 56:
                                var u = f.A.getUrl();
                                Q.find((function(t) {
                                    return u.startsWith(t)
                                })) || f.A.navigate(D.x.SPP_TRIAL, !1, {
                                    returnTo: u,
                                    context: 45
                                });
                                break;
                            case 89:
                                if (148 === (null == (e = a.promo_block) ? void 0 : e.promo_block_type)) {
                                    r.A.setAsReached(), f.A.navigate(D.x.ENCOUNTERS_ONBOARDING_PROMO, !1, {
                                        notification: a
                                    });
                                    break
                                }
                                f.A.navigate(D.x.NEW_USER_SUBSTITUTE, !1, {
                                    notification: a
                                });
                                break;
                            case 112:
                                this.showCreditsFeatureFinished(a);
                                break;
                            case 163:
                                this.showAppInstallNudgeNotification(a);
                                break;
                            case 170:
                                this.showGroupPhotoUpload(a), this.notificationHandled(), s = !1;
                                break;
                            case 171:
                                f.A.navigate(D.x.PHOTOS_AUTO_BLUR, !1, {
                                    notification: a
                                }), this.notificationHandled(), s = !1;
                                break;
                            case 140:
                                this.showUnavailableSubscriptionFeaturesNotification(a), this.notificationHandled();
                                break;
                            default:
                                s = !1
                        }
                        return s
                    }, F.handleOverlayNotificationGenericPromo = function(t) {
                        var e = t.promo,
                            i = t.promoBlockType,
                            o = t.notificationJSON;
                        if (165 === i) return f.A.navigate(D.x.MESSENGER_MINI_GAME_PROMO, {
                            notification: o,
                            promoBlock: e
                        }), !1;
                        if (69 === i) return f.A.navigate(D.x.CONFIRM_EMAIL, {
                            notification: o
                        }), !1;
                        if (222 === i) return f.A.navigate(D.x.MODERATED_PHOTOS, {
                            notification: o
                        }), !1;
                        if (346 === i) return f.A.navigate(D.x.PROFILE_QUESTIONS_CHAT_BLOCKER, {
                            notification: o
                        }), !1;
                        var a = o.id.replace(/_/g, "-"),
                            r = [D.x.MARKETING_SUBSCRIPTION];
                        return [].concat(r, [D.x.ATTENTION_BOOST_REMINDER, D.x.EXTRA_SHOWS_REMINDER, D.x.RISE_UP_REMINDER, D.x.IS_THIS_STILL_YOUR_NUMBER]).includes(a) ? (0, n.A)((function() {
                            f.A.navigate(a, {
                                notification: o
                            })
                        })) : this.log.error("The notification with id " + o.id + " has no matching route."), r.includes(a)
                    }, F.spendCredits = function() {
                        var t, e, i, n = this;
                        if (f.A.getLocation().routeName !== D.x.PAY) {
                            C.A.set(!0);
                            var o = (0, O.A)();
                            this.renderReactView((0, L.jsx)(w.A, {
                                header: null == (t = this.currentNotification) ? void 0 : t.getTitle(),
                                message: null == (e = this.currentNotification) ? void 0 : e.getMessage(),
                                confirmLabel: null == (i = this.currentNotification) ? void 0 : i.getActionText(),
                                cancelLabel: u.Ay.get(451),
                                isOpen: !0,
                                onConfirm: function() {
                                    n.performNotificationAction(), C.A.set(!1), n.removeReactView(o)
                                },
                                onCancel: function() {
                                    n.handleDecline(), C.A.set(!1), n.removeReactView(o)
                                }
                            }), o)
                        } else this.notificationHandled()
                    }, F.showPassiveMatches = function(t) {
                        var e = this;
                        C.A.set(!0);
                        var i = this.renderReactView((0, L.jsx)(A.A, {
                            promoBlocks: t.promo_blocks,
                            onClose: function() {
                                C.A.set(!1), e.removeReactView(i)
                            }
                        }), this.createElement()[0])
                    }, F.showTiwMappingPopup = function(t) {
                        var e = this;
                        C.A.set(!0);
                        var i = this.renderReactView((0, L.jsx)(B.A, {
                            promoBlocks: t.promo_blocks,
                            onClose: function() {
                                C.A.set(!1), e.removeReactView(i)
                            }
                        }), this.createElement()[0])
                    }, F.showCreditsFeatureFinished = function(t) {
                        var e = this;
                        C.A.set(!0);
                        var i = this.renderReactView((0, L.jsx)(b.A, {
                            promoBlock: t.promo_block,
                            onClose: function() {
                                C.A.set(!1), e.removeReactView(i)
                            }
                        }), this.createElement()[0])
                    }, F.showAppInstallNudgeNotification = function(t) {
                        var e = this;
                        C.A.set(!0);
                        var i = this.renderReactView((0, L.jsx)(V.A, {
                            promoBlock: t.promo_block,
                            onClose: function() {
                                C.A.set(!1), e.removeReactView(i)
                            }
                        }), this.createElement()[0])
                    }, F.showGroupPhotoUpload = function(t) {
                        var e = this;
                        C.A.set(!0);
                        var i = this.renderReactView((0, L.jsx)(p.A, {
                            notification: t,
                            onClose: function() {
                                C.A.set(!1), e.removeReactView(i)
                            }
                        }), this.createElement()[0])
                    }, F.showUnavailableSubscriptionFeaturesNotification = function(t) {
                        var e = this;
                        C.A.set(!0);
                        var i = this.renderReactView((0, L.jsx)(g.A, {
                            notification: t,
                            onClose: function() {
                                C.A.set(!1), e.removeReactView(i)
                            }
                        }), this.createElement()[0])
                    }, F.notifyMessage = function() {
                        var t = this.currentNotification;
                        this.clearCurrentNotification(), t && (t.getTransactionIdentifier() ? _.A.processClientNotification(t.toJSON()) : s.A.trigger(s.A.SHOW_NOTIFICATION, t))
                    }, F.handleDecline = function() {
                        var t;
                        12 === (null == (t = this.currentNotification) ? void 0 : t.getType()) && (R.A.getInstance().invalidate(d.A.getUserId()), E.A.getInstance().invalidateSppFolders()), this.notificationHandled()
                    }, F.notificationHandled = function(t) {
                        this.currentNotification && (t = "string" == typeof t ? t : this.currentNotification.getId()) === this.currentNotification.getId() && (new a.Ay(159, {
                            value: t
                        }).request(), this.clearCurrentNotification(), this.advanceQueue())
                    }, F.clearCurrentNotification = function() {
                        this.currentNotification = null
                    }, F.clearPhoneVerificationNotification = function() {
                        var t = this.queue.findIndex(W);
                        this.ignorePhoneVerificationNotification = !0, t > -1 && this.queue.splice(t, 1)
                    }, c
                }(c.A);

                function W(t) {
                    var e = t.getPromoBlock();
                    return !!Boolean(e) && 94 === e.getPromoBlockType()
                }
                J.getInstance = function() {
                    return F || (F = new J)
                }, e.A = J
            },
            62536: function(t, e, i) {
                i.d(e, {
                    M: function() {
                        return r
                    }
                });
                i(2892);
                var n = i(31087),
                    o = i(73090),
                    a = i(15566),
                    r = function(t) {
                        var e = (new a.KJW).setUserId(o.A.getUserId()).setTiwIdea((new a._oR).setTiwPhraseId(Number(t)));
                        return n.A.getInstance().set(e, [494])
                    }
            }
        }
    ]);
//# sourceMappingURL=1588.a279fde14daba3ce57d1.js.map
/*! For license information please see 8819.44794e59ca17963a952e.js.LICENSE.txt */
var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "90508083-7e9a-4547-ae4e-056782400211", e._sentryDebugIdIdentifier = "sentry-dbid-90508083-7e9a-4547-ae4e-056782400211")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "90508083-7e9a-4547-ae4e-056782400211", e._sentryDebugIdIdentifier = "sentry-dbid-90508083-7e9a-4547-ae4e-056782400211")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [8819], {
            107: function(e, t, n) {
                n.d(t, {
                    M: function() {
                        return i
                    }
                });
                var r = n(72537),
                    i = function() {
                        return r.A.isAllowed(r.A.getSync(415)) && r.A.isAllowed(r.A.getSync(418))
                    }
            },
            254: function(e, t, n) {
                n.d(t, {
                    XQ: function() {
                        return E
                    },
                    py: function() {
                        return b
                    },
                    Ay: function() {
                        return I
                    },
                    qD: function() {
                        return N
                    }
                });
                n(58940), n(11392), n(79432), n(60739), n(27208), n(26099), n(38781), n(74423), n(27495), n(62062), n(71761), n(72712);
                var r = n(73090),
                    i = n(40075),
                    a = (n(25276), n(2008), n(79601)),
                    o = (n(90906), n(48598), n(28706), n(84864), n(57465), n(87745), [].concat("[\\u2700-\\u27bf]", "(?:\\ud83c[\\udde6-\\uddff]){2}", "[\\ud800-\\udbff][\\udc00-\\udfff]", "[\\u0023-\\u0039]\\ufe0f?\\u20e3", ["\\u3299", "\\u3297"], ["\\u303d", "\\u3030"], ["\\u24c2"], ["\\ud83c[\\udd70-\\udd71]", "\\ud83c[\\udd7e-\\udd7f]", "\\ud83c\\udd8e", "\\ud83c[\\udd91-\\udd9a]", "\\ud83c[\\udde6-\\uddff]"], ["[\\ud83c[\\ude01-\\ude02]", "\\ud83c\\ude1a", "\\ud83c\\ude2f", "[\\ud83c[\\ude32-\\ude3a]", "[\\ud83c[\\ude50-\\ude51]"], ["\\u203c", "\\u2049"], ["[\\u25aa-\\u25ab]", "\\u25b6", "\\u25c0", "[\\u25fb-\\u25fe]"], ["\\u00a9", "\\u00ae"], ["\\u2122", "\\u2139"], ["\\ud83c\\udc04"], "[\\u2600-\\u26FF]", ["\\u2b05", "\\u2b06", "\\u2b07", "\\u2b1b", "\\u2b1c", "\\u2b50", "\\u2b55"], ["\\u231a", "\\u231b", "\\u2328", "\\u23cf", "[\\u23e9-\\u23f3]", "[\\u23f8-\\u23fa]"], ["\\ud83c\\udccf"], ["\\u2934", "\\u2935"], ["[\\u2190-\\u21ff]"]).join("|")),
                    s = new RegExp("(?:" + o + ")");
                var c = {
                    EMOJI_SIZE: {
                        EXTRA_EXTRA_LARGE: "xxlg",
                        EXTRA_LARGE: "xlg",
                        LARGE: "lg",
                        MEDIUM: "md"
                    },
                    isEmoji: function(e) {
                        if (!e || e.indexOf("\n") > -1) return !1;
                        var t = u(e = e.replace(/\s/g, "")).length,
                            n = c.emojiCount(e);
                        return t === n && n <= 3
                    },
                    emojiCount: function(e) {
                        return e ? u(e).map((function(e) {
                            return t = e, s.test(t);
                            var t
                        })).filter(Boolean).length : 0
                    },
                    emojiSize: function(e) {
                        switch (c.emojiCount(e)) {
                            case 1:
                                return c.EMOJI_SIZE.EXTRA_EXTRA_LARGE;
                            case 2:
                                return c.EMOJI_SIZE.EXTRA_LARGE;
                            case 3:
                                return c.EMOJI_SIZE.LARGE;
                            default:
                                return c.EMOJI_SIZE.MEDIUM
                        }
                    }
                };

                function u(e) {
                    return (0, a.A)(e.replace(/\s/g, ""))
                }
                var l = c,
                    d = n(47632),
                    p = n(20175),
                    f = n(7929),
                    h = n(28030),
                    g = n(35837),
                    v = n(15566),
                    m = [2, 4],
                    y = /.{3}/g,
                    A = 86400,
                    P = 604800,
                    E = {
                        DELIVERED: "DELIVERED",
                        FAILED: "FAILED",
                        INAPPROPRIATE: "INAPPROPRIATE",
                        READ: "READ",
                        SENDING: "SENDING",
                        UPLOADING: "UPLOADING"
                    },
                    _ = {
                        IN: "in",
                        OUT: "out"
                    },
                    b = "TEMP_ID:",
                    T = 0;

                function S(e, t, n) {
                    this.actions = void 0, this.chatDate = void 0, this.context = 10;
                    var r = parseInt(Date.now() / 1e3 + 3600, 10);
                    this.dateCreated = r, this.dateModified = r, this.direction = _.OUT, this.displayMessage = void 0, this.fromPersonId = void 0, this.gif = void 0, this.gift = void 0, this.id = void 0, this.image = void 0, this.audio = void 0, this.isContinuation = void 0, this.isLiked = void 0, this.isMasked = void 0, this.isNew = void 0, this.isOffensive = void 0, this.isInappropriate = void 0, this.isResentAfterInappropriateMark = void 0, this.isRead = void 0, this.isSelectable = !1, this.isSelected = !1, this.hasLewdPhoto = !1, this.message = void 0, this.messageType = void 0, this.originalMessageType = void 0, this.notice = void 0, this.promoType = void 0, this.replyToUid = void 0, this.request = void 0, this.size = void 0, this.status = {
                        text: ""
                    }, this.statusType = void 0, this.toPersonId = void 0, this.isReplyFeatureAllowed = Boolean(null == n ? void 0 : n.isReplyFeatureAllowed), this.repliedMessage = void 0, this.allowLike = !1, this.allowReply = !1, this.readMessagesTimestamp = null == n ? void 0 : n.readMessagesTimestamp, this._isFemale = void 0, this.position = void 0, this.question = void 0, this.isLikelyOffensive = !1, this.reaction = void 0, this.update(e, t)
                }
                S.prototype = {
                    DIRECTIONS: _,
                    STATUS: E,
                    isYours: function() {
                        return this.direction === _.OUT
                    },
                    isTemporary: function() {
                        return (this.id || "").startsWith("TEMP")
                    },
                    _updateFromJSON: function(e, t) {
                        for (var n in e) this.hasOwnProperty(n) && (this[n] = e[n]);
                        this.messageType = L(this), this.originalMessageType = e.message_type, this.size || (this.size = U(this.message)), !this.gift || this.gift instanceof v.sz8 || (this.gift = new v.sz8(this.gift)), this.image && Object.keys(this.image).length || (this.image = C(this, t)), this.video && Object.keys(this.video).length || (this.video = O(this)), this.audio && Object.keys(this.audio).length || (this.audio = R(this)), this.repliedMessage && (this.isReplyFeatureAllowed ? this.repliedMessage = new S(this.repliedMessage, t) : this.repliedMessage = void 0)
                    },
                    _updateFromGPB: function(e, t) {
                        var n, r, i, a, o = function(e) {
                                return e.getMssg("")
                            }(e),
                            s = function(e, t) {
                                var n = 10 === e.getMessageType() && e.hasGift() && e.getGift();
                                if (!n) return;
                                return n.setFromUserName(t ? t.getName() : ""), n.setFromUserId(e.getFromPersonId()), n.setToUserId(e.getToPersonId()), n
                            }(e, t),
                            c = function(e) {
                                var t;
                                return e.hasReaction() ? {
                                    emoji: e.getReaction().getEmoji(),
                                    reactedPhotoSrc: null == (t = e.getReaction().getReactionElement()) || null == (t = t.getPhoto()) ? void 0 : t.getLargeUrl()
                                } : void 0
                            }(e);
                        this.actions = void 0, this.chatDate = e.getSectionTitle(), this.dateCreated = e.getDateCreated(), this.dateModified = e.getDateModified(), this.direction = w(e) ? _.OUT : _.IN, this.displayMessage = e.getDisplayMessage(o), this.fromPersonId = e.getFromPersonId(), this.gif = e.hasGifMessageInfo() ? new f.A(e, e.getGifMessageInfo().getType()) : void 0, this.gift = s, this.id = e.getUid(), this.image = null != (n = this.image) && n.src ? this.image : C(e, t), this.video = null != (r = this.video) && r.src ? this.video : O(e), this.audio = null != (i = this.audio) && i.src ? this.audio : R(e), this.isLiked = e.getIsLiked(!1), this.isMasked = e.getIsMasked(!1), this.isNew = void 0, this.isOffensive = e.getOffensive(!1), this.isRead = e.getRead(!1), this.hasLewdPhoto = e.getHasLewdPhoto(!1), this.message = o, this.messageType = L(e), this.originalMessageType = e.getMessageType(), this.notice = void 0, this.replyToUid = e.getReplyToUid(this.replyToUid), this.request = function(e) {
                            if (! function(e) {
                                    return [28, 25, 3].includes(D(e))
                                }(e)) return;
                            var t = e.getVerificationMethod(),
                                n = e.getAccessResponseType(0),
                                r = !w(e) && 0 === n;
                            return {
                                canAnswer: r,
                                providerType: t && t.getProviderType(),
                                type: t && t.getType()
                            }
                        }(e), this.size = U(o), this.toPersonId = e.getToPersonId(), this.location = function(e) {
                            var t = e.getLiveLocation();
                            if (t) {
                                var n = t.getGeoLocation();
                                if (n) return {
                                    longitude: n.getLongitudePrecise(),
                                    latitude: n.getLatitudePrecise()
                                }
                            }
                            var r = e.getTheirLocation();
                            if (r) return {
                                longitude: r.getLongitude(),
                                latitude: r.getLatitude()
                            }
                        }(e), this.locationExpiresAt = function(e) {
                            var t = e.getLiveLocation(),
                                n = Math.floor(Date.now() / 1e3);
                            if (t) return t.getExpiresAt(n);
                            return n
                        }(e), this.allowLike = e.getAllowLike(!1), this.allowReply = e.getAllowReply(!1), this.question = null == (a = e.getQuestion()) ? void 0 : a.toJSON(), this.isLikelyOffensive = e.getIsLikelyOffensive(!1), this.reaction = c, e.hasBanner() && (this.banner = e.getBanner().toJSON()), this.isReplyFeatureAllowed && e.hasRepliedChatMessage() && (this.repliedMessage = new S(e.getRepliedChatMessage(), t))
                    },
                    _updateFromPromo: function(e) {
                        var t = e.getButtons();
                        this.actions = {
                            primary: t[0] && t[0].getText(),
                            secondary: t[1] && t[1].getText()
                        }, this.direction = _.IN, this.id = e.getUniqueId(), this.message = e.getMssg(), this.messageType = function(e) {
                            return "PROMO_ID:" + e.getPromoBlockType()
                        }(e), this.notice = e.getHeader(), this.promoType = e.getPromoBlockType(), this.request = {
                            canAnswer: !0
                        }
                    },
                    setReadMessagesTimestamp: function(e) {
                        this.readMessagesTimestamp = e
                    },
                    setStatus: function(e, t) {
                        var n, r, a = "info";
                        switch (this.isRead = e === E.READ, this.statusType = e, e) {
                            case E.READ:
                                if (this.image || this.gif) {
                                    t = i.Ay.get(422);
                                    break
                                }
                                if (n = "generic-read-receipt", r = "read-receipt", this.readMessagesTimestamp > 1) {
                                    var o = this.readMessagesTimestamp - this.dateCreated;
                                    t = o <= A ? i.Ay.get(147, {
                                        str: (0, p.Cp)(this.readMessagesTimestamp)
                                    }) : o <= P ? i.Ay.get(148, {
                                        num: Math.floor(o / A)
                                    }) : o <= 2678400 ? i.Ay.get(149, {
                                        num: Math.floor(o / P)
                                    }) : i.Ay.get(150)
                                }
                                break;
                            case E.SENDING:
                                t = i.Ay.get(432);
                                break;
                            case E.FAILED:
                                t = t || i.Ay.get(432), a = "error", n = "generic-error", r = "error";
                                break;
                            case E.INAPPROPRIATE:
                                t = i.Ay.get(27), a = "info", n = "generic-tap", this.isInappropriate = !0;
                                break;
                            case E.UPLOADING:
                                t = i.Ay.get(751);
                                break;
                            case E.DELIVERED:
                                n = "generic-read-receipt", t = i.Ay.get(146)
                        }
                        this.status = {
                            text: t,
                            textColor: undefined,
                            level: a,
                            icon: n,
                            iconColor: r
                        }
                    },
                    update: function(e, t) {
                        if (e instanceof v.cMz ? this._updateFromGPB(e, t) : e instanceof v.d4N ? this._updateFromPromo(e) : this._updateFromJSON(e, t), w(this) && !this.isTemporary()) {
                            var n = this.statusType;
                            e instanceof v.cMz && (n = this.dateCreated <= this.readMessagesTimestamp ? E.READ : E.DELIVERED), this.setStatus(n, void 0)
                        }
                        var i;
                        this._isFemale = 2 === ((i = t) instanceof v.KJW ? i.getGender() : null == i ? void 0 : i.gender), this.fromPersonId || (this.fromPersonId = r.A.getUserId()), this.toPersonId || (this.toPersonId = t && (t.id || t.getUserId())), this.id || (this.id = "" + b + ++T)
                    },
                    toGPB: function() {
                        var e = "string" == typeof this.messageType ? 1 : this.messageType || 1,
                            t = (new v.cMz).setFromPersonId(this.fromPersonId).setMessageType(e).setMssg(this.message || "").setRead(Boolean(this.isRead)).setToPersonId(this.toPersonId).setUid(String(this.id));
                        switch (this.context && t.setContext(this.context), this.replyToUid && t.setReplyToUid(String(this.replyToUid)), this.isResentAfterInappropriateMark && t.setResentAfterInappropriateMark(!0), e) {
                            case 23:
                                t.setSticker((new v.CSG).setImageId(String(this.image.src)).setId(String(this.image.id)));
                                break;
                            case 36:
                                t.setMssg(this.gif.url).setGifMessageInfo((new v.c3O).setType(this.gif.provider));
                                break;
                            case 10:
                                t.setGift(this.gift);
                                break;
                            case 50:
                                t.setQuestion((new v.vNH).setId(this.question.id))
                        }
                        var n = function(e) {
                            try {
                                var t = e.image,
                                    n = e.audio,
                                    r = new v.U0R;
                                if (n) {
                                    var i = (new v.SzZ).setType(n.format.type).setSampleRateHz(n.format.sample_rate_hz).setBitRateKbps(n.format.bit_rate_kbps).setAudioStereo(n.format.audio_stereo).setVbrEnable(n.format.vbr_enable),
                                        a = (new v.fP5).setId(n.id.toString()).setWaveform(n.waveformSrv).setFormat(i).setDurationMs(1e3 * n.duration),
                                        o = (new v.anE).setVisibilityType(4);
                                    r.setFormat(3).setAudio(a).setVisibility(o)
                                } else {
                                    var s = (new v.$_D).setId(t.id),
                                        c = (new v.anE).setVisibilityType(t.visibility);
                                    r.setFormat(t.format || 1).setPhoto(s).setVisibility(c)
                                }
                                return r
                            } catch (e) {
                                return
                            }
                        }(this);
                        return n && t.setMultimedia(n), t
                    }
                };
                var I = S;

                function C(e, t) {
                    if (e.gif || e.hasGifMessageInfo && e.hasGifMessageInfo()) return {};
                    var n = function(e, t) {
                        var n;
                        return function(e, t) {
                            var n = (0, g.A)(r.A.getUser(), v.KJW);
                            !w(e) && t || (t = n);
                            var i = t && t.getProfilePhoto() || n && n.getProfilePhoto();
                            return 4 === D(e) && i && i.getLargeUrl()
                        }(e, t) || function(e) {
                            var t = e.gift || (null == e.getGift ? void 0 : e.getGift()),
                                n = null == t || null == t.getGift ? void 0 : t.getGift();
                            if (!n) return;
                            return n.getThumbUrl()
                        }(e) || (null == (n = e.gif) ? void 0 : n.src) || function(e) {
                            return e.hasSticker && e.hasSticker() && e.getSticker().getImageId()
                        }(e) || function(e) {
                            var t = e.getMultimedia && e.getMultimedia(),
                                n = t && t.getPhoto();
                            return n && n.getLargeUrl()
                        }(e)
                    }(e, t);
                    if (n) {
                        var i = e.getMultimedia && e.getMultimedia(),
                            a = i && i.getFormat();
                        if (!m.includes(a)) {
                            var o = i && i.getPhoto(),
                                s = o && o.getLargePhotoSize(),
                                c = s && s.getHeight() || 0,
                                u = s && s.getWidth() || 0,
                                l = o && o.getId() || e.hasSticker && e.hasSticker() && e.getSticker().getId(),
                                d = c / u,
                                p = i && i.getViewDate(),
                                f = i && i.getVisibility().getVisibilityType(),
                                h = function(e) {
                                    var t = e.gift || e.getGift && e.getGift();
                                    return t && t.getIsBoxed() ? t.getBoxThumbUrl() : void 0
                                }(e);
                            return {
                                format: a,
                                height: c,
                                id: l,
                                ratio: d,
                                src: n,
                                srcBox: h,
                                viewDate: p,
                                visibility: f,
                                width: u
                            }
                        }
                    }
                }

                function O(e) {
                    var t = e.getMultimedia && e.getMultimedia();
                    if (t) {
                        var n = t.getFormat();
                        if (m.includes(n)) {
                            var r = t.getPhoto();
                            if (r) {
                                var i = r.getId(),
                                    a = r.getVideo(),
                                    o = r.getVideoExpirationTs(),
                                    s = r.getLargeUrl();
                                return s && (s = d.A.getImageUrlForSize(s, 160)), {
                                    format: n,
                                    id: i,
                                    previewUrl: s,
                                    src: a && a.getUrl(),
                                    expirationTs: o,
                                    visibility: t.getVisibility().getVisibilityType()
                                }
                            }
                        }
                    }
                }

                function R(e) {
                    var t = e.getMultimedia && e.getMultimedia();
                    if (t) {
                        var n = t.getFormat();
                        if (3 === n) {
                            var r = t.getAudio();
                            if (r) {
                                var i = r.getId(),
                                    a = r.getExpirationTs(),
                                    o = r.getUrl(),
                                    s = t.getVisibility().getVisibilityType();
                                return {
                                    expirationTs: a,
                                    waveform: N(r.getWaveform([])),
                                    duration: r.getDurationMs(0) / 1e3,
                                    format: n,
                                    id: i,
                                    src: o,
                                    visibility: s
                                }
                            }
                        }
                    }
                }

                function w(e) {
                    return r.A.getUserId() === (e.fromPersonId || e.getFromPersonId && e.getFromPersonId())
                }

                function D(e) {
                    return e instanceof v.cMz ? e.getMessageType() : e.messageType
                }

                function L(e) {
                    if (e.getOffensive && e.getOffensive()) return "REPORTED_XP";
                    var t = D(e);
                    if (1 === t) {
                        var n = e.message || e.getMssg && e.getMssg() || "";
                        if (l.isEmoji(n)) return ["♥︎", "♥", "❤️", "❤"].includes(n.replace(/\s/g, "")) ? "ANIMATED_EMOJI" : "EMOJI"
                    }
                    return t
                }

                function U(e) {
                    return l.isEmoji(e) ? l.emojiSize(e) : void 0
                }

                function N(e) {
                    var t, n = h.A.getSettings(),
                        r = (null == n || null == (t = n.chat_settings) || null == (t = t.audio_recording_settings) ? void 0 : t.waveform_length) || 3;
                    return e.map((function(e) {
                        for (var t = e.toString(2), n = 10 * r - t.length; n > 0;) t = "0" + t, n--;
                        return t.match(y)
                    })).reduce((function(e, t) {
                        for (var n = t.length - 1; n >= 0; --n) e.push(parseInt(t[n], 2));
                        return e
                    }), [])
                }
            },
            484: function(e, t, n) {
                n.d(t, {
                    X: function() {
                        return r
                    }
                });
                n(50113), n(26099);

                function r(e, t) {
                    if (!e || !t) return "";
                    var n = (e.providers || []).find((function(e) {
                        return e.provider_id === t
                    }));
                    return (null == n ? void 0 : n.price_token) || ""
                }
            },
            1064: function(e, t, n) {
                var r;
                n.d(t, {
                    $1: function() {
                        return o
                    },
                    UH: function() {
                        return i
                    },
                    rw: function() {
                        return a
                    }
                });
                var i = ((r = {})[4] = "badge-feature-match", r[30] = "badge-feature-liked-you", r[23] = "badge-feature-favourites", r[2] = "badge-nearby", r[22] = "badge-visited-you", r);

                function a(e) {
                    return i[e]
                }

                function o(e) {
                    if (void 0 !== e.initialScreen && null !== e.initialScreen && e.initialScreen.user) {
                        var t = e.initialScreen.user;
                        if (!t.hasCameFrom() && !t.getCameFromText()) return;
                        if (!a(t.getCameFrom())) return;
                        return {
                            id: e.initialScreen.user.getCameFrom(),
                            text: e.initialScreen.user.getCameFromText(),
                            counter: 1
                        }
                    }
                    if (void 0 !== e.sourceOfMessage && e.sourceOfMessage.counter > 0) return e.sourceOfMessage.counter--, e.sourceOfMessage
                }
            },
            1977: function(e, t, n) {
                n.d(t, {
                    m: function() {
                        return i
                    }
                });
                n(27495), n(90906);
                var r = /^[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i;

                function i(e) {
                    return r.test(e)
                }
            },
            3208: function(e, t, n) {
                var r, i = n(67311);

                function a() {
                    r = (0, i.A)()
                }
                t.A = {
                    generate: a,
                    get: function() {
                        return r || a(), r
                    }
                }
            },
            4803: function(e, t, n) {
                function r(e) {
                    return 193 === (null == e ? void 0 : e.provider)
                }
                n.d(t, {
                    W: function() {
                        return r
                    }
                })
            },
            7802: function(e, t, n) {
                n.d(t, {
                    q: function() {
                        return r
                    }
                });
                var r = (0, n(99306).A)(!1)
            },
            7815: function(e, t, n) {
                n.d(t, {
                    VB: function() {
                        return a
                    },
                    jq: function() {
                        return r.jq
                    }
                });
                var r = n(64975),
                    i = n(18084).A.getLogger("PaymentResultChannel"),
                    a = new r.j0(i)
            },
            7929: function(e, t, n) {
                n(79432), n(2892), n(9868);
                var r = n(85208),
                    i = n(97286),
                    a = n(26666),
                    o = n(36721),
                    s = n(15566);

                function c(e, t) {
                    this.id = null, this.image = null, this.provider = t, this.url = null, this.setup(e)
                }
                c.fromJSON = function(e) {
                    var t = new c;
                    return (0, r.A)(t, (0, i.A)(e, Object.keys(t)))
                }, c.prototype.setup = function(e) {
                    if (e) {
                        if (e instanceof s.cMz) return 2 === this.provider ? this.id = e.getGifMessageInfo().getId() : (this.url = e.getMssg(""), this.id = (0, a.A)(this.url.split("/"))), void(this.image = {
                            ratio: e.getGifMessageInfo().getAspectRatio(),
                            extraText: "GIPHY"
                        });
                        if (1 === this.provider) {
                            var t = o.A.canUseWebP(),
                                n = e.images.fixed_width_downsampled || {},
                                r = n.height,
                                i = e.images.original || {},
                                c = t && n.webp && Number(n.size) > Number(n.webp_size),
                                u = t && i.webp && Number(i.size) > Number(i.webp_size),
                                l = n.width;
                            return this.id = e.id, this.url = e.embed_url, void(this.image = {
                                height: r,
                                preview: c ? n.webp : n.url,
                                ratio: (r / l * 100).toFixed(3),
                                url: u ? i.webp : i.url,
                                width: l,
                                extraText: "GIPHY"
                            })
                        }
                        if (2 === this.provider) {
                            this.id = e.id, this.url = e.url;
                            var d = e.media[0].gif;
                            this.image = {
                                height: d.dims[1],
                                preview: d.url,
                                ratio: (d.dims[1] / d.dims[0] * 100).toFixed(3),
                                url: d.url,
                                width: d.dims[0],
                                isExtraIconHidden: !0,
                                extraText: "Via Tenor"
                            }
                        }
                    }
                }, t.A = c
            },
            10031: function(e, t, n) {
                function r(e) {
                    if (!e) return !1;
                    var t = e.form_error,
                        n = null == t ? void 0 : t.failure;
                    return 63 === (null == n ? void 0 : n.type)
                }
                n.d(t, {
                    Q: function() {
                        return r
                    }
                })
            },
            11927: function(e, t, n) {
                n.d(t, {
                    F: function() {
                        return o
                    }
                });
                n(23792), n(26099), n(47764), n(62953), n(48408), n(48598), n(38781);
                var r = n(99417),
                    i = "moumi://moumi/googleplaypayment?",
                    a = {
                        TRANSACTION_ID: "transaction_id_param",
                        CONSUME_TRANSACTION: "consume_transaction",
                        CONSUME_ALL: "consume_all",
                        PURCHASE_TOKEN: "purchase_token",
                        SKU: "sku_param",
                        IS_SUBSCRIPTION: "is_subscription",
                        RESULT_URL: "result_url_param"
                    };

                function o(e) {
                    var t = e.consumeAll,
                        n = e.consumeTransaction,
                        o = e.isSubscription,
                        s = e.purchaseToken,
                        c = e.resultUrl,
                        u = e.sku,
                        l = e.transactionId,
                        d = new r.A.URL(i),
                        p = d.searchParams;
                    if (n && p.set(a.CONSUME_TRANSACTION, "1"), l && ("string" == typeof l ? p.set(a.TRANSACTION_ID, l) : p.set(a.TRANSACTION_ID, l.join(","))), s && p.set(a.PURCHASE_TOKEN, s), t && p.set(a.CONSUME_ALL, "1"), void 0 !== o) {
                        var f = o ? "1" : "0";
                        p.set(a.IS_SUBSCRIPTION, f)
                    }
                    return c && p.set(a.RESULT_URL, c), u && p.set(a.SKU, u), d.toString()
                }
            },
            12632: function(e, t, n) {
                function r(e) {
                    var t = e.metaKey || e.altKey || e.ctrlKey || e.shiftKey;
                    return 0 === e.button && !t && (e.preventDefault(), !0)
                }
                n.d(t, {
                    s: function() {
                        return r
                    }
                })
            },
            12702: function(e, t, n) {
                n.d(t, {
                    Kl: function() {
                        return c
                    },
                    BX: function() {
                        return s
                    },
                    FW: function() {
                        return m
                    },
                    jh: function() {
                        return y
                    }
                });
                n(84185), n(79432), n(2008), n(83851), n(51629), n(23500), n(81278), n(67945), n(25276), n(45700), n(89572), n(52675), n(89463), n(26099), n(2892);
                var r = n(96540),
                    i = n(86812),
                    a = n(484),
                    o = n(70271);
                n(50113);
                var s, c, u = n(74848),
                    l = ["children"];

                function d(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function p(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? d(Object(n), !0).forEach((function(t) {
                            f(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : d(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function f(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function h(e) {
                    var t = e.paymentOptions,
                        n = e.selectedProduct,
                        r = e.selectedProvider,
                        i = e.storedProvider,
                        a = e.nonStoredProviders,
                        o = e.defaultUcbRecap;
                    return {
                        isLoading: !1,
                        billingEmail: "",
                        isStoredProviderPressed: !1,
                        emailErrorLabel: "",
                        currentTransaction: void 0,
                        autoTopUpValue: Boolean((null == o ? void 0 : o.is_auto_topup_available) && (null == o ? void 0 : o.auto_top_up_default_state)),
                        ignoreStoredDetails: !1,
                        ccFormUrl: "",
                        isCcPayment: !1,
                        isCcFormFullscreen: !1,
                        paymentOptions: t,
                        selectedProduct: n,
                        selectedProvider: r,
                        storedProvider: i,
                        nonStoredProviders: a,
                        currentUcbRecap: void 0,
                        ccFormState: void 0,
                        deviceProfilingId: void 0,
                        userPickedPaymentMethod: !1,
                        toBeClosed: !1
                    }
                }

                function g(e, t) {
                    var n, r, c, u, l = p({}, e);
                    switch (t.type) {
                        case s.UPDATE_IS_LOADING:
                            l.isLoading = t.value;
                            break;
                        case s.UPDATE_BILLING_EMAIL:
                            l.billingEmail = t.value;
                            break;
                        case s.UPDATE_STORE_PROVIDER_PRESSED:
                            l.isStoredProviderPressed = t.value;
                            break;
                        case s.UPDATE_EMAIL_ERROR_LABEL:
                            l.emailErrorLabel = t.value;
                            break;
                        case s.UPDATE_CURRENT_TRANSACTION:
                            var d;
                            l.currentTransaction = t.value, l.ccFormUrl = null == (d = l.currentTransaction) ? void 0 : d.redirect_url;
                            break;
                        case s.UPDATE_AUTO_TOP_UP_VALUE:
                            l.autoTopUpValue = t.value, l.paymentOptions = p(p({}, l.paymentOptions), {}, {
                                autoTopup: t.value
                            });
                            break;
                        case s.UPDATE_IGNORE_STORED_DETAILS:
                            l.ignoreStoredDetails = t.value;
                            break;
                        case s.UPDATE_IS_CC_PAYMENT:
                            l.isCcPayment = t.value;
                            break;
                        case s.UPDATE_IS_CC_FORM_FULLSCREEN:
                            l.isCcFormFullscreen = t.value;
                            break;
                        case s.UPDATE_PAYMENT_OPTIONS:
                            l.paymentOptions = t.value;
                            break;
                        case s.UPDATE_SELECTED_PROVIDER:
                            var f = t.value;
                            l.selectedProvider = f;
                            var h = p(p({}, l.paymentOptions), {}, {
                                extraDataModalFlow: (0, i.A)(f),
                                priceToken: (0, a.X)(l.selectedProduct, null == f ? void 0 : f.provider_id),
                                provider: null == f ? void 0 : f.provider,
                                providerId: null == f ? void 0 : f.provider_id,
                                providerName: null == f ? void 0 : f.provider_name
                            });
                            l.paymentOptions = h;
                            var g = Boolean((null == f ? void 0 : f.provider) && (0, o.n)(null == f ? void 0 : f.provider_id) && !(100001 === (null == f ? void 0 : f.provider)));
                            l.isCcPayment = g;
                            var v = (n = l.selectedProduct, r = null == f ? void 0 : f.provider_id, null == (u = null == n || null == (c = n.providers) ? void 0 : c.find((function(e) {
                                return e.provider_id === r
                            }))) ? void 0 : u.ucb_recap);
                            l.currentUcbRecap = v;
                            break;
                        case s.UPDATE_STORED_PROVIDER:
                            l.storedProvider = t.value;
                            break;
                        case s.UPDATE_SELECTED_PRODUCT:
                            l.selectedProduct = t.value;
                            break;
                        case s.UPDATE_CURRENT_UCB_RECAP:
                            l.currentUcbRecap = t.value;
                            break;
                        case s.UPDATE_CC_FORM_STATE:
                            l.ccFormState = t.value;
                            break;
                        case s.UPDATE_DEVICE_PROFILING_ID:
                            l.deviceProfilingId = t.value;
                            break;
                        case s.UPDATE_USER_PICKED_PAYMENT_METHOD:
                            l.userPickedPaymentMethod = t.value;
                            break;
                        case s.FIRE_SIGNAL_CLOSE:
                            l.toBeClosed = t.value;
                            break;
                        default:
                            throw new Error("ucbReducer - Unhandled action type")
                    }
                    return l
                }! function(e) {
                    e.UPDATE_IS_LOADING = "UPDATE_IS_LOADING", e.UPDATE_BILLING_EMAIL = "UPDATE_BILLING_EMAIL", e.UPDATE_STORE_PROVIDER_PRESSED = "UPDATE_STORE_PROVIDER_PRESSED", e.UPDATE_EMAIL_ERROR_LABEL = "UPDATE_EMAIL_ERROR_LABEL", e.UPDATE_CURRENT_TRANSACTION = "UPDATE_CURRENT_TRANSACTION", e.UPDATE_AUTO_TOP_UP_VALUE = "UPDATE_AUTO_TOP_UP_VALUE", e.UPDATE_IGNORE_STORED_DETAILS = "UPDATE_IGNORE_STORED_DETAILS", e.UPDATE_CC_FORM_URL = "UPDATE_CC_FORM_URL", e.UPDATE_IS_CC_PAYMENT = "UPDATE_IS_CC_PAYMENT", e.UPDATE_IS_CC_FORM_FULLSCREEN = "UPDATE_IS_CC_FORM_FULLSCREEN", e.UPDATE_PAYMENT_OPTIONS = "UPDATE_PAYMENT_OPTIONS", e.UPDATE_SELECTED_PRODUCT = "UPDATE_SELECTED_PRODUCT", e.UPDATE_SELECTED_PROVIDER = "UPDATE_SELECTED_PROVIDER", e.UPDATE_STORED_PROVIDER = "UPDATE_STORED_PROVIDER", e.UPDATE_CURRENT_UCB_RECAP = "UPDATE_CURRENT_UCB_RECAP", e.UPDATE_CC_FORM_STATE = "UPDATE_CC_FORM_STATE", e.UPDATE_DEVICE_PROFILING_ID = "UPDATE_DEVICE_PROFILING_ID", e.UPDATE_USER_PICKED_PAYMENT_METHOD = "UPDATE_USER_PICKED_PAYMENT_METHOD", e.FIRE_SIGNAL_CLOSE = "FIRE_SIGNAL_CLOSE"
                }(s || (s = {})),
                function(e) {
                    e.NORMAL = "NORMAL", e.SECURITY_STEP = "SECURITY_STEP"
                }(c || (c = {}));
                var v = (0, r.createContext)({
                        state: h({}),
                        dispatch: function() {}
                    }),
                    m = function(e) {
                        var t = e.children,
                            n = function(e, t) {
                                if (null == e) return {};
                                var n, r, i = {},
                                    a = Object.keys(e);
                                for (r = 0; r < a.length; r++) n = a[r], t.indexOf(n) >= 0 || (i[n] = e[n]);
                                return i
                            }(e, l),
                            i = (0, r.useReducer)(g, h(p({}, n))),
                            a = {
                                state: i[0],
                                dispatch: i[1]
                            };
                        return (0, u.jsx)(v.Provider, {
                            value: a,
                            children: t
                        })
                    };

                function y() {
                    var e = (0, r.useContext)(v);
                    if (void 0 === e) throw new Error("useUcbContext must be used within a UcbContextProvider");
                    return e
                }
            },
            13315: function(e, t, n) {
                n(72712), n(26099), n(2008), n(23792), n(47764), n(62953), n(48408), n(28706), n(10287);
                var r = n(78029),
                    i = n(71672),
                    a = n(23735);

                function o(e, t) {
                    return o = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, o(e, t)
                }
                var s;
                ! function(e) {
                    e.SUCCESS = "SUCCESS", e.PENDING = "PENDING", e.FAILURE = "FAILURE", e.CANCEL = "CANCEL"
                }(s || (s = {}));
                var c = "payment-state",
                    u = function(e) {
                        var t, n;

                        function r() {
                            var t;
                            return t = e.call(this) || this, a.Kj.on(455, (function() {
                                t.setResult(r.RESULTS.SUCCESS)
                            })), t
                        }
                        n = e, (t = r).prototype = Object.create(n.prototype), t.prototype.constructor = t, o(t, n), r.getInstance = function() {
                            return null === r.instance && (r.instance = new r), r.instance
                        };
                        var s = r.prototype;
                        return s.getBackRoute = function() {
                            return this.getValue("back")
                        }, s.getBackAction = function() {
                            return this.getValue("action")
                        }, s.getResult = function() {
                            return this.getValue("result")
                        }, s.getTrustedOrigins = function() {
                            return this.getValue("trustedOrigins") || []
                        }, s.setBackRoute = function(e) {
                            this.setValue("back", e), this.persistState()
                        }, s.setBackAction = function(e) {
                            this.setValue("action", e), this.persistState()
                        }, s.setResult = function(e) {
                            this.setValue("result", e)
                        }, s.setTrustedOrigins = function(e, t) {
                            var n = e.filter(Boolean).reduce((function(e, t) {
                                var n = "";
                                try {
                                    n = new URL(t).origin
                                } catch (e) {}
                                return n ? [].concat(e, [n]) : e
                            }), t ? this.getTrustedOrigins() : []);
                            this.setValue("trustedOrigins", n)
                        }, s.clear = function() {
                            this.setBackRoute(null), this.setBackAction(null), this.setResult(null), i.A.remove(c)
                        }, s.retrieveState = function() {
                            var e = i.A.getObject(c);
                            e && (this.setBackAction(e.action), this.setBackRoute(e.back))
                        }, s.persistState = function() {
                            i.A.saveObject(c, {
                                back: this.getBackRoute(),
                                action: this.getBackAction()
                            })
                        }, r
                    }((0, r.tG)(function() {
                        return function() {}
                    }()));
                u.RESULTS = s, u.instance = null, t.A = u
            },
            18826: function(e, t, n) {
                n(62062), n(60739), n(27208), n(69085), n(26910), n(51629), n(26099), n(23500), n(48980), n(25276), n(45700), n(89572), n(52675), n(89463), n(2892), n(84185), n(79432), n(2008), n(83851), n(81278), n(67945), n(99417);
                var r = n(13614),
                    i = n(254),
                    a = n(15566),
                    o = n(1064);

                function s(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function c(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? s(Object(n), !0).forEach((function(t) {
                            u(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function u(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var l = {},
                    d = void 0;

                function p(e) {
                    return h({
                        chatMessage: e.chatMessage,
                        clientChatMessages: e.clientChatMessages,
                        clientOpenChat: e.clientOpenChat,
                        userId: e.userId
                    })
                }

                function f(e) {
                    var t = e.blockingFeature,
                        n = e.chatMessage,
                        i = e.clientChatMessages,
                        a = e.clientOpenChat,
                        s = e.chatSettings,
                        c = e.initialScreen,
                        u = e.userId,
                        l = p({
                            clientOpenChat: a,
                            userId: u,
                            clientChatMessages: i,
                            chatMessage: n
                        });
                    return a && function(e) {
                        var t = e.clientOpenChat,
                            n = e.userId,
                            i = h({
                                clientOpenChat: t,
                                userId: n
                            });
                        if (!t) return i;
                        var a = t.getChatInstance(),
                            s = t.getChatSettings(),
                            c = t.getChatUser(i.chatUser),
                            u = function(e) {
                                if (!e.hasInitialChatScreen()) return;
                                var t = e.getInitialChatScreen(),
                                    n = t.hasGifts() && t.getGifts().getSections()[0].getGiftProducts();
                                return {
                                    blockingFeature: t.getBlockingFeature(),
                                    gifts: n && n.map((function(e) {
                                        return e.toJSON()
                                    })),
                                    message: t.getMessage(""),
                                    promo: t.getPromo(),
                                    subtitle: t.getSubtitle(""),
                                    title: t.getTitle(""),
                                    type: t.getType(),
                                    user: t.getUser()
                                }
                            }(t),
                            l = function(e) {
                                var t = e.getChatUser();
                                if (!(0, o.rw)(t.getCameFrom())) return;
                                return {
                                    id: t.getCameFrom(),
                                    text: t.getCameFromText(),
                                    counter: 1
                                }
                            }(t),
                            d = s && s.getInputSettings(),
                            p = s && s.getAllowReply(!1),
                            f = s && s.getAllowUrlParsing(!1),
                            v = d && d.getInputFeatures(),
                            y = d && d.toJSON().input_items || [],
                            A = t.getMaxUnansweredMessages(i.maxUnansweredMessages);
                        Object.assign(i, {
                            isReplyFeatureAllowed: p,
                            isAllowUrlParsing: f,
                            chatInstanceId: a ? a.getUid() : n,
                            chatUser: c,
                            counter: a ? a.getCounter(0) : i.counter,
                            deletedMember: a ? a.getOtherAccountDeleted() : i.deletedMember,
                            allowDisablingPrivateDetector: s && s.getAllowDisablingPrivateDetector(),
                            dummy: !1,
                            gender: c.getGender(),
                            initialScreen: u,
                            sourceOfMessage: l,
                            initialScreenType: null == u ? void 0 : u.type,
                            inputFeatures: v ? v.map((function(e) {
                                return e.toJSON()
                            })) : i.inputFeatures,
                            inputSettingsItems: y,
                            isMatch: c.getIsMatch(),
                            largePhoto: (0, r.Yz)(c),
                            maxUnansweredMessages: A,
                            messages: m({
                                clientOpenChat: t,
                                userId: n
                            }),
                            multimediaVisibility: g(s),
                            promoBanners: t.getPromoBanners([]),
                            readMessagesTimestamp: t.getReadMessagesTimestamp(i.readMessagesTimestamp),
                            userId: n,
                            isShowingCrushAnimation: s && s.getShowCrushAnimation(),
                            isNotInterested: t.getIsNotInterested(),
                            isShowingOffensiveMessagesPrompt: s && s.getShowOffensiveMessagesPrompt()
                        })
                    }({
                        clientOpenChat: a,
                        userId: u
                    }), void 0 !== t && function(e) {
                        var t = e.userId,
                            n = e.chatMessage,
                            r = e.blockingFeature,
                            i = p({
                                userId: t,
                                chatMessage: n
                            });
                        i.initialScreen && (i.initialScreen.blockingFeature = r)
                    }({
                        userId: u,
                        chatMessage: n,
                        blockingFeature: t
                    }), void 0 !== s && function(e) {
                        var t = e.userId,
                            n = e.chatSettings,
                            r = p({
                                userId: t
                            }),
                            i = n && n.getInputSettings(),
                            a = i && i.getInputFeatures(),
                            o = i && i.toJSON().input_items;
                        r.inputSettingsItems = o, r.inputFeatures = a ? a.map((function(e) {
                            return e.toJSON()
                        })) : r.inputFeatures, r.allowDisablingPrivateDetector = n && n.getAllowDisablingPrivateDetector()
                    }({
                        userId: u,
                        chatSettings: s
                    }), void 0 !== c && v({
                        userId: u,
                        chatMessage: n,
                        initialScreen: c
                    }), void 0 === i && void 0 === n || function(e) {
                        var t = e.clientOpenChat,
                            n = e.userId,
                            r = e.clientChatMessages,
                            i = e.chatMessage,
                            a = p({
                                clientOpenChat: t,
                                userId: n,
                                clientChatMessages: r,
                                chatMessage: i
                            }),
                            o = a.messages.length;
                        if (m({
                                clientOpenChat: t,
                                userId: n,
                                clientChatMessages: r,
                                chatMessage: i
                            }), r) {
                            var s = r.getChatInstance();
                            a.counter = s.getCounter(a.counter)
                        } else i && o < a.messages.length && (v({
                            userId: n,
                            chatMessage: i,
                            initialScreen: void 0
                        }), a.counter++, i.isYours() ? 10 !== i.messageType && a.maxUnansweredMessages-- : a.maxUnansweredMessages = 1 / 0)
                    }({
                        clientOpenChat: a,
                        userId: u,
                        clientChatMessages: i,
                        chatMessage: n
                    }), l
                }

                function h(e) {
                    var t = e.chatMessage,
                        n = e.clientChatMessages,
                        r = e.clientOpenChat,
                        o = e.userId,
                        s = function(e) {
                            var t = e.clientOpenChat,
                                n = e.userId,
                                r = e.clientChatMessages,
                                a = e.chatMessage,
                                o = t && t.getChatInstance(),
                                s = r ? r.getMessages([]) : [],
                                c = s.length ? new i.Ay(s[0]) : a;
                            if (o) {
                                var u = t.getChatUser();
                                return o.getUid() || (u ? u.getUserId() : n)
                            }
                            if (c) return (c.isYours() ? c.toPersonId : c.fromPersonId) || n;
                            return n
                        }({
                            chatMessage: t,
                            clientChatMessages: n,
                            clientOpenChat: r,
                            userId: o
                        });
                    o = o || s;
                    var c = l[s] = l[o] = l[s] || function(e) {
                        return {
                            chatInstanceId: e,
                            chatUser: new a.KJW({
                                user_id: e,
                                name: ""
                            }),
                            counter: 0,
                            deletedMember: !1,
                            dummy: !0,
                            gender: void 0,
                            inputFeatures: [{
                                feature: 18,
                                enabled: !0
                            }, {
                                feature: 70,
                                enabled: !1
                            }, {
                                feature: 111,
                                enabled: !1
                            }, {
                                feature: 113,
                                enabled: !1
                            }, {
                                feature: 155,
                                enabled: !1
                            }],
                            initialScreen: void 0,
                            initialScreenType: void 0,
                            sourceOfMessage: void 0,
                            isMatch: void 0,
                            largePhoto: void 0,
                            maxUnansweredMessages: 1 / 0,
                            messages: [],
                            multimediaVisibility: g(),
                            promoBanners: [],
                            dismissedPromoBanners: [],
                            readMessagesTimestamp: void 0,
                            userId: e
                        }
                    }(o);
                    return c
                }

                function g(e) {
                    if (!d) {
                        var t = e && e.getMultimediaSettings().getMultimediaConfig().getVisibility();
                        t && (d = t.map((function(e) {
                            return {
                                seconds: e.getSeconds(),
                                title: e.getDisplayValue(),
                                visibilityType: e.getVisibilityType()
                            }
                        })))
                    }
                    return d || []
                }

                function v(e) {
                    var t = e.userId,
                        n = e.chatMessage,
                        r = e.initialScreen,
                        i = p({
                            userId: t,
                            chatMessage: n
                        });
                    return i.initialScreen = r, i.initialScreenType = null == r ? void 0 : r.type, i
                }

                function m(e) {
                    var t = e.clientOpenChat,
                        n = e.userId,
                        r = e.clientChatMessages,
                        a = e.chatMessage,
                        o = t && t.getInitialChatScreen(),
                        s = function(e) {
                            var t = e.clientOpenChat,
                                n = e.userId,
                                r = e.clientChatMessages,
                                a = e.chatMessage;
                            if (t) {
                                var o = t.getChatUser(),
                                    s = t.getChatSettings(),
                                    c = s && s.getAllowReply(!1);
                                return t.getChatMessages([]).map((function(e) {
                                    return new i.Ay(e, o, {
                                        isReplyFeatureAllowed: c,
                                        readMessagesTimestamp: t.getReadMessagesTimestamp()
                                    })
                                }))
                            }
                            if (r) {
                                var u = p({
                                    userId: n
                                }).chatUser;
                                return r.getMessages([]).map((function(e) {
                                    return new i.Ay(e, u)
                                }))
                            }
                            return a ? [a] : []
                        }({
                            clientOpenChat: t,
                            userId: n,
                            clientChatMessages: r,
                            chatMessage: a
                        }),
                        c = p({
                            clientOpenChat: t,
                            userId: n,
                            clientChatMessages: r,
                            chatMessage: a
                        }),
                        u = c.messages;
                    return o && 7 === o.getType() && (u.length = 0), s.forEach((function(e) {
                            var t = e.id,
                                n = u.findIndex((function(e) {
                                    return e.id === t
                                })),
                                r = 20 === e.messageType; - 1 !== n ? (r && (e.messageType = u[n].messageType), u[n].update(e, c.chatUser)) : r || u.push(e)
                        })),
                        function(e) {
                            return (e || []).sort((function(e, t) {
                                return e.dateCreated - t.dateCreated || e.id - t.id
                            }))
                        }(u)
                }

                function y(e) {
                    var t = l[e],
                        n = t.initialScreen || {},
                        r = n.blockingFeature,
                        i = n.promo;
                    return c(c({}, t), {}, {
                        chatUser: t.chatUser.toJSON(),
                        messages: t.messages.slice(-5),
                        promoBanners: t.promoBanners.map((function(e) {
                            return e.toJSON()
                        })),
                        initialScreen: t.initialScreen ? c(c({}, t.initialScreen), {}, {
                            blockingFeature: r && r.toJSON(),
                            promo: i && i.toJSON()
                        }) : void 0
                    })
                }
                t.A = {
                    create: function(e) {
                        var t = e.chatMessage,
                            n = e.clientChatMessages,
                            r = e.clientOpenChat,
                            i = e.userId;
                        return f({
                            chatMessage: t,
                            clientChatMessages: n,
                            clientOpenChat: r,
                            userId: i
                        })
                    },
                    read: p,
                    update: f,
                    delete: function e(t) {
                        if (t) l.hasOwnProperty(t) && delete l[t];
                        else
                            for (var n in l) e(n)
                    },
                    increaseMaxAnswers: function(e) {
                        var t = e.clientOpenChat,
                            n = e.userId,
                            r = e.clientChatMessages,
                            i = e.chatMessage;
                        p({
                            clientOpenChat: t,
                            userId: n,
                            clientChatMessages: r,
                            chatMessage: i
                        }).maxUnansweredMessages++
                    },
                    markChatPromoHandled: function(e, t, n) {
                        var r = e.clientOpenChat,
                            i = e.userId,
                            a = e.clientChatMessages,
                            o = e.chatMessage,
                            s = p({
                                clientOpenChat: r,
                                userId: i,
                                clientChatMessages: a,
                                chatMessage: o
                            });
                        if (n) {
                            var c = s.dismissedPromoBanners.indexOf(t);
                            c > -1 && s.dismissedPromoBanners.splice(c, 1)
                        } else s.dismissedPromoBanners.push(t)
                    },
                    load: function() {},
                    save: function(e) {
                        if (e) return y(e);
                        var t = {};
                        for (var n in l) t[n] = y(n);
                        return t
                    }
                }
            },
            20140: function(e, t, n) {
                n.d(t, {
                    U: function() {
                        return r
                    }
                });
                n(50113), n(26099);

                function r(e, t) {
                    return e.find((function(e) {
                        return e.provider_id === t
                    }))
                }
            },
            26019: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return tn
                    }
                });
                n(28706), n(26099), n(3362), n(79432), n(25276), n(48598), n(33110), n(27495), n(74423), n(72712), n(51629), n(23500), n(21699), n(10287), n(2892), n(90906), n(45700), n(89572), n(52675), n(89463), n(84185), n(2008), n(83851), n(81278), n(67945), n(2259), n(23792), n(47764), n(62953), n(66412), n(78125), n(4731), n(60479), n(40875), n(94490);
                var r, i = n(64741),
                    a = n(42302),
                    o = n(89610),
                    s = n(99417),
                    c = n(40075),
                    u = n(36521),
                    l = n(73090),
                    d = n(13264),
                    p = n(36721),
                    f = n(58385),
                    h = n(74389),
                    g = n(18025),
                    v = n(49683),
                    m = n(31087),
                    y = n(20387),
                    A = n(83771),
                    P = n(41298),
                    E = n(76201),
                    _ = n(25093),
                    b = n(30397),
                    T = n(23715),
                    S = n(19276),
                    I = n(78195),
                    C = n(14566),
                    O = n(68906),
                    R = n(30922),
                    w = n(93529),
                    D = n(7815);
                ! function(e) {
                    e.TRANSACTION = "transaction", e.GOOGLE_RECEIPT = "googleReceipt", e.SERVER_RECEIPT = "serverReceipt"
                }(r || (r = {}));
                var L = "bd-google-play-transactions";

                function U(e) {
                    s.A.localStorage.setItem(L, JSON.stringify(e))
                }

                function N() {
                    var e = s.A.localStorage.getItem(L);
                    return e ? JSON.parse(e) : {}
                }

                function j(e, t) {
                    var n = t || N();
                    return Object.prototype.hasOwnProperty.call(n, e) ? n[e][r.TRANSACTION] : null
                }
                var M = {
                        createTransaction: function(e) {
                            var t, n = N();
                            j(e.transaction_id, n) || (n[e.transaction_id] = ((t = {})[r.TRANSACTION] = e, t[r.GOOGLE_RECEIPT] = null, t[r.SERVER_RECEIPT] = null, t), U(n))
                        },
                        removeTransaction: function(e) {
                            var t = N();
                            return !!Object.prototype.hasOwnProperty.call(t, e) && (delete t[e], U(t), !0)
                        },
                        _load: N,
                        getTransaction: j,
                        addGoogleReceipt: function(e, t) {
                            var n = N();
                            Object.prototype.hasOwnProperty.call(n, t) && (n[t][r.GOOGLE_RECEIPT] = e), U(n)
                        },
                        getGoogleReceipt: function(e) {
                            var t = N();
                            return Object.prototype.hasOwnProperty.call(t, e) ? t[e][r.GOOGLE_RECEIPT] : null
                        },
                        addServerReceipt: function(e, t) {
                            var n = N();
                            Object.prototype.hasOwnProperty.call(n, t) && (n[t][r.SERVER_RECEIPT] = e), U(n)
                        },
                        getServerReceipt: function(e) {
                            var t = N();
                            return Object.prototype.hasOwnProperty.call(t, e) ? t[e][r.SERVER_RECEIPT] : null
                        }
                    },
                    x = n(70271),
                    k = [113, 117];

                function F(e, t) {
                    var n, r = (null == (n = e.data) ? void 0 : n.type) === D.jq;
                    return t ? r && e.source === t : r
                }
                var B = n(67556),
                    H = n(11927),
                    G = n(18084),
                    V = G.A.getLogger("getGooglePurchaseToken");
                var W = n(10031),
                    Y = n(17412),
                    q = (n(48408), n(96540)),
                    Q = n(65297),
                    K = n(1977),
                    X = n(59028),
                    z = n(32485),
                    Z = n.n(z),
                    J = n(47901),
                    $ = n(87184),
                    ee = n(15376),
                    te = n(11734),
                    ne = n(99795),
                    re = n(94318),
                    ie = n(28733),
                    ae = n(89769),
                    oe = n(12501),
                    se = n(20017),
                    ce = n(47632),
                    ue = n(55105),
                    le = n(74848),
                    de = function(e) {
                        var t = e.children,
                            n = e.isLoading,
                            r = e.isFullScreen,
                            i = Z()({
                                "order-recap__payment-details": !0,
                                "is-loading": n,
                                "is-fullscreen": r
                            });
                        return (0, le.jsxs)("div", {
                            className: i,
                            children: [n && r ? (0, le.jsx)(ue.A, {}) : null, t]
                        })
                    },
                    pe = n(93827),
                    fe = function(e) {
                        var t = e.providerInfo,
                            n = e.textCta,
                            r = e.onClickCta;
                        return (0, le.jsxs)("div", {
                            className: "payment-details__content",
                            children: [(0, le.jsxs)("div", {
                                className: "payment-details__content-start",
                                children: [(0, le.jsxs)("div", {
                                    className: "payment-details__provider-info",
                                    children: [(0, le.jsx)("img", {
                                        src: t.imageSrc,
                                        className: "payment-details__provider-image",
                                        alt: ""
                                    }), (0, le.jsx)(pe.P1, {
                                        children: t.name
                                    })]
                                }), t.payerInfo ? (0, le.jsx)("div", {
                                    className: "payment-details__payer-info",
                                    children: (0, le.jsx)(pe.P3, {
                                        color: "gray-80",
                                        dangerous: !0,
                                        children: t.payerInfo
                                    })
                                }) : null]
                            }), n && r ? (0, le.jsx)("div", {
                                className: "payment-details__content-end",
                                children: (0, le.jsx)("button", {
                                    className: "payment-details__cta",
                                    onClick: r,
                                    children: (0, le.jsx)(pe.P3, {
                                        color: "primary",
                                        children: n
                                    })
                                })
                            }) : null]
                        })
                    },
                    he = n(13315),
                    ge = function(e) {
                        (0, q.useEffect)((function() {
                            return he.A.getInstance().setTrustedOrigins([e], !0),
                                function() {
                                    he.A.getInstance().setTrustedOrigins([])
                                }
                        }), [e])
                    },
                    ve = ge,
                    me = function(e) {
                        ge(e.url);
                        var t = e.iframeRef,
                            n = e.isScrollable,
                            r = void 0 !== n && n,
                            i = e.url,
                            a = r ? "yes" : "no";
                        return (0, le.jsx)("iframe", {
                            ref: t,
                            src: i,
                            className: "embedded-iframe",
                            scrolling: a,
                            title: c.Ay.get(320)
                        })
                    },
                    ye = n(33815),
                    Ae = function(e) {
                        return he.A.getInstance().getTrustedOrigins().includes(e)
                    },
                    Pe = Ae;

                function Ee(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function _e(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? Ee(Object(n), !0).forEach((function(t) {
                            be(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Ee(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function be(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var Te = 22;
                var Se = function(e) {
                        var t = e.paymentOptions,
                            n = e.mop,
                            r = e.textCta,
                            i = e.onClickCta,
                            a = e.onClientPurchaseReceipt,
                            o = e.onErrorLoadingPaymentDetails,
                            c = e.onIframeRef,
                            u = e.onPurchaseTransaction,
                            l = (0, q.useState)(!0),
                            d = l[0],
                            p = l[1],
                            f = (0, q.useState)(!1),
                            h = f[0],
                            g = f[1],
                            m = (0, q.useState)(!1),
                            y = m[0],
                            A = m[1],
                            P = (0, q.useState)(),
                            E = P[0],
                            _ = P[1],
                            b = (0, q.useState)(""),
                            T = b[0],
                            S = b[1],
                            I = (0, q.useState)(null),
                            C = I[0],
                            O = I[1],
                            R = (0, q.useRef)(null),
                            w = (0, q.useRef)(!1),
                            D = (0, q.useMemo)((function() {
                                return function(e, t) {
                                    var n = {
                                        imageSrc: "",
                                        name: ""
                                    };
                                    if (t) {
                                        var r, i = null == (r = (t.pictures || [])[0]) ? void 0 : r.display_images;
                                        n.imageSrc = ce.A.getImageUrlForSize(i, Te, Te), n.name = t.header, n.payerInfo = t.mssg
                                    } else n.imageSrc = ce.A.getImageUrlForSize(e.image, Te, Te), n.name = e.providerName;
                                    return n
                                }(n, E)
                            }), [n, E]);
                        (0, q.useEffect)((function() {
                            var e = t.providerId,
                                n = t.recurringPromo;
                            if (n) _(n), p(!1);
                            else if ((0, x.n)(e)) {
                                var r;
                                p(!0), null == u || u(), null == (r = R.current) || r.cancel(), R.current = v.A.getInstance().startTransactionAsPromise(_e(_e({}, t), {}, {
                                    ignoreStoredDetails: !0
                                })), R.current.then((function(e) {
                                    var t = e.error,
                                        n = e.purchaseTransaction,
                                        r = e.clientPurchaseReceipt;
                                    if (n) {
                                        var i = n.redirect_url || "";
                                        null == u || u(n), S(i), p(!1)
                                    } else r ? a(r) : o(t || new Error("Error loading the payment details"), e)
                                })).catch(o)
                            } else p(!1);
                            return function() {
                                var e;
                                null == (e = R.current) || e.cancel()
                            }
                        }), [a, o, u, t]), (0, q.useEffect)((function() {
                            if (null == c || c(C), C) return s.A.addEventListener("message", e),
                                function() {
                                    return s.A.removeEventListener("message", e)
                                };

                            function e(e) {
                                if (Ae(e.origin) && e.data) {
                                    Object.prototype.hasOwnProperty.call(e.data, "isKeyboardVisible") && (w.current = Boolean(e.data.isKeyboardVisible)), F(e) && p(!0);
                                    var t = e.data,
                                        n = t.event,
                                        r = t.type;
                                    n === Y.An.SECURITY_CHECK && (g(!0), r === Y.vD.REDIRECT && A(!0))
                                }
                            }
                        }), [C, c]);
                        var L = null;
                        return L = d && h ? null : d ? (0, le.jsx)(ye.A, {}) : T ? (0, le.jsx)(me, {
                            iframeRef: function(e) {
                                O(e)
                            },
                            url: T,
                            isScrollable: y
                        }) : (0, le.jsx)(fe, {
                            providerInfo: D,
                            textCta: r,
                            onClickCta: i
                        }), (0, le.jsx)(de, {
                            isLoading: d,
                            isFullScreen: h,
                            children: L
                        })
                    },
                    Ie = n(73616),
                    Ce = n(84932),
                    Oe = function(e) {
                        var t = e.email,
                            n = e.emailLabel,
                            r = e.emailErrorLabel,
                            i = e.onSubmit,
                            a = e.onChange;
                        return (0, le.jsx)("div", {
                            className: "order-recap__email",
                            children: (0, le.jsx)(Ie.A, {
                                onSubmit: i,
                                children: (0, le.jsx)(Ce.A, {
                                    errorMessage: r,
                                    fieldId: "order-recap-email",
                                    type: "email",
                                    value: t,
                                    onChange: a,
                                    label: n
                                })
                            })
                        })
                    },
                    Re = function(e) {
                        var t = e.title,
                            n = e.price,
                            r = e.displayPrice,
                            i = e.textCta,
                            a = e.onClickCta,
                            o = n ? "gray-80" : "black";
                        return (0, le.jsx)("div", {
                            className: "service-summary",
                            children: (0, le.jsxs)("div", {
                                className: "service-summary__content",
                                children: [(0, le.jsxs)("div", {
                                    className: "service-summary__content-start",
                                    children: [t ? (0, le.jsx)(pe.P1, {
                                        children: t
                                    }) : null, r ? (0, le.jsx)("div", {
                                        className: "service-summary__display-price",
                                        children: (0, le.jsx)(pe.P3, {
                                            color: o,
                                            children: r
                                        })
                                    }) : null]
                                }), (0, le.jsxs)("div", {
                                    className: "service-summary__content-end",
                                    children: [n ? (0, le.jsx)(pe.P1, {
                                        children: n
                                    }) : null, i ? (0, le.jsx)("button", {
                                        className: "service-summary__cta",
                                        onClick: a,
                                        children: (0, le.jsx)(pe.P3, {
                                            color: "primary",
                                            children: i
                                        })
                                    }) : null]
                                })]
                            })
                        })
                    },
                    we = function(e) {
                        var t = e.tnc;
                        return (0, le.jsx)("div", {
                            className: "recurring-billing",
                            children: (0, le.jsx)(pe.P2, {
                                dangerous: !0,
                                children: t
                            })
                        })
                    },
                    De = n(17380),
                    Le = function(e) {
                        var t = e.label,
                            n = e.value,
                            r = e.onChange;
                        return (0, le.jsxs)("div", {
                            className: "order-recap-autotopup",
                            children: [(0, le.jsx)("div", {
                                className: "order-recap-autotopup__checkbox",
                                children: (0, le.jsx)(De.A, {
                                    id: "order-recap-autotopup",
                                    isChecked: n,
                                    onChange: r,
                                    type: "checkbox"
                                })
                            }), (0, le.jsx)("label", {
                                className: "order-recap-autotopup__label",
                                htmlFor: "order-recap-autotopup",
                                children: (0, le.jsx)(pe.P3, {
                                    color: "gray-80",
                                    inline: !0,
                                    children: t
                                })
                            })]
                        })
                    },
                    Ue = function(e) {
                        var t, n = e.autoTopUpText,
                            r = e.autoTopUpValue,
                            i = e.closeIconLabel,
                            a = e.email,
                            o = e.emailErrorLabel,
                            s = e.emailLabel,
                            c = e.isAutoTopUpAvailable,
                            u = void 0 !== c && c,
                            l = e.isBillingEmailRequired,
                            d = void 0 !== l && l,
                            p = e.isLoading,
                            f = e.isScreenFixed,
                            h = e.paymentDetails,
                            g = e.submitCta,
                            v = e.summary,
                            m = e.title,
                            y = e.tnc,
                            A = e.onClickClose,
                            P = e.onSubmitEmail,
                            E = e.onChangeEmail,
                            _ = e.onChangeAutoTopUp,
                            b = e.onClickSubmitPayment;
                        f && (t = "fixed");
                        var T = Z()({
                            "order-recap": !0,
                            "is-fixed": f
                        });
                        return (0, le.jsxs)("div", {
                            className: T,
                            children: [(0, le.jsxs)(J.A, {
                                children: [(0, le.jsx)(ee.A, {
                                    children: (0, le.jsxs)(ne.A, {
                                        position: t,
                                        children: [(0, le.jsx)(ie.A, {
                                            children: (0, le.jsx)(re.A, {
                                                name: "navigation-bar-close",
                                                onClick: A,
                                                a11y: {
                                                    iconLabel: i
                                                }
                                            })
                                        }), (0, le.jsx)(oe.A, {
                                            text: m
                                        }), (0, le.jsx)(ae.A, {})]
                                    })
                                }), (0, le.jsx)($.A, {
                                    hpadded: !0,
                                    vpadded: !0,
                                    children: (0, le.jsx)(Re, {
                                        title: v.title,
                                        price: v.price,
                                        displayPrice: v.displayPrice,
                                        textCta: v.textCta,
                                        onClickCta: v.onClickCta
                                    })
                                }), (0, le.jsx)($.A, {
                                    hpadded: !0,
                                    vpadded: !0,
                                    children: (0, le.jsx)(Se, {
                                        paymentOptions: h.paymentOptions,
                                        mop: h.mop,
                                        textCta: h.textCta,
                                        onClickCta: h.onClickCta,
                                        onClientPurchaseReceipt: h.onClientPurchaseReceipt,
                                        onErrorLoadingPaymentDetails: h.onErrorLoadingPaymentDetails,
                                        onIframeRef: h.onIframeRef,
                                        onPurchaseTransaction: h.onPurchaseTransaction
                                    })
                                }), d ? (0, le.jsx)($.A, {
                                    hpadded: !0,
                                    vpadded: !0,
                                    children: (0, le.jsx)(Oe, {
                                        email: a,
                                        emailLabel: s,
                                        emailErrorLabel: o,
                                        onSubmit: P,
                                        onChange: E
                                    })
                                }) : null, u && n ? (0, le.jsx)($.A, {
                                    hpadded: !0,
                                    vpadded: !0,
                                    children: (0, le.jsx)(Le, {
                                        label: n,
                                        value: r,
                                        onChange: _
                                    })
                                }) : null, y ? (0, le.jsx)($.A, {
                                    hpadded: !0,
                                    vpadded: !0,
                                    children: (0, le.jsx)(we, {
                                        tnc: y
                                    })
                                }) : null, (0, le.jsx)(te.A, {
                                    hpadded: !0,
                                    vpadded: !0,
                                    children: (0, le.jsx)("div", {
                                        className: "order-recap__footer",
                                        children: (0, le.jsx)(se.A, {
                                            icon: "generic-lock",
                                            text: g,
                                            isLoading: p,
                                            onClick: b
                                        })
                                    })
                                })]
                            }), p ? (0, le.jsx)(ue.A, {}) : null]
                        })
                    },
                    Ne = [Y.An.INPUT_ERRORS, Y.An.SECURITY_CHECK];

                function je(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function Me(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? je(Object(n), !0).forEach((function(t) {
                            xe(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : je(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function xe(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function ke(e, t) {
                    return ke = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, ke(e, t)
                }
                var Fe = function(e) {
                        var t, n;

                        function r(t) {
                            var n;
                            (n = e.call(this, t) || this).iframeElement = void 0, n.ccFormUrl = void 0, n.transaction = void 0, n.log = G.A.getLogger("OrderRecapContainer"), n.settingsPromise = void 0, n.handlePaymentSettings = function(e) {
                                e && (e.auto_topup || n.showChangeCtas())
                            }, n.handleErrorPaymentSettings = function(e) {
                                (0, _.A)(e) && n.log.error("Error loading the payment settings", {
                                    error: e
                                })
                            }, n.handlePurchaseTransaction = function(e) {
                                n.isCcPayment() && n.setState({
                                    isLoading: !e
                                }), n.transaction = e, n.ccFormUrl = null == e ? void 0 : e.redirect_url
                            }, n.handleIframeRef = function(e) {
                                n.iframeElement = e
                            }, n.handleMessageFromIframe = function(e) {
                                if (Ae(e.origin) && e.data) {
                                    var t = e.data,
                                        r = t.event,
                                        i = t.data;
                                    if (r && Ne.includes(r) && n.setState({
                                            isLoading: !1
                                        }), r === Y.An.SECURITY_CHECK && (n.setState({
                                            hasSecurityCheckRequested: !0
                                        }), n.iframeElement && (n.iframeElement.height = "", n.iframeElement.style.height = "")), r === Y.An.UPDATE_HEIGHT) {
                                        var a = (i || {}).height,
                                            o = Number(a);
                                        n.iframeElement && (isNaN(o) ? (n.iframeElement.height = "", n.iframeElement.style.height = "") : (n.iframeElement.height = o + "px", n.iframeElement.style.height = o + "px"))
                                    }
                                }
                            }, n.handleErrorLoadingPaymentDetails = function(e, t) {
                                var r = t || {},
                                    i = r.error,
                                    a = r.purchaseTransactionFailed;
                                if (!a && (0, _.A)(i || e) && n.log.error("Error loading the payment details", {
                                        error: e,
                                        transactionResult: t
                                    }), !(e instanceof P.k)) {
                                    var o, s = null == a || null == (o = a.notification) ? void 0 : o.message;
                                    w.A.showNotification({
                                        type: w.A.TYPES.ERROR,
                                        text: s
                                    }), n.props.onClose()
                                }
                            }, n.handleSubmitEmail = function(e) {
                                e.preventDefault(), n.handleClickSubmitPayment()
                            }, n.handleChangeEmail = function(e) {
                                n.setState({
                                    email: e.currentTarget.value,
                                    emailErrorLabel: ""
                                })
                            }, n.handleClickClose = function() {
                                var e = n.state.hasSecurityCheckRequested;
                                n.props.onClose(n.transaction, e)
                            }, n.handleChangePackage = function() {
                                null == n.props.onChangePackage || n.props.onChangePackage(), n.handleClickClose()
                            }, n.handleChangePaymentMethod = function() {
                                null == n.props.onChangePaymentMethod || n.props.onChangePaymentMethod()
                            }, n.handleChangeAutoTopUp = function() {
                                n.isCcPayment() && n.postMessageCcForm(Y.An.STORE_DETAILS), s.A.setTimeout((function() {
                                    n.setState((function(e) {
                                        return {
                                            autoTopUpValue: !e.autoTopUpValue,
                                            paymentDetails: Me(Me({}, e.paymentDetails), {}, {
                                                paymentOptions: Me(Me({}, e.paymentDetails.paymentOptions), {}, {
                                                    autoTopup: !e.autoTopUpValue
                                                })
                                            })
                                        }
                                    }))
                                }))
                            }, n.handleClickSubmitPayment = function() {
                                var e = n.props.paymentOptions,
                                    t = n.isCcPayment();
                                (!t || n.iframeElement && n.ccFormUrl) && (n.setState({
                                    isLoading: !0
                                }), !n.props.orderRecap.is_billing_email_required || (0, K.m)(n.state.email) ? t ? (n.setTransactionExtraData(), n.postMessageCcForm(Y.An.SUBMIT_FORM)) : (n.state.email && (e.billingEmail = n.state.email), e.autoTopup = n.state.autoTopUpValue, e.ignoreStoredDetails = n.props.ignoreStoredDetails, n.props.onSubmitPayment(e)) : n.setState({
                                    emailErrorLabel: c.Ay.get(683),
                                    isLoading: !1
                                }))
                            };
                            var r = n.props,
                                i = r.mop,
                                a = r.orderRecap,
                                o = r.paymentOptions,
                                u = Boolean(a.is_auto_topup_available && a.auto_top_up_default_state);
                            return n.state = {
                                email: "",
                                emailErrorLabel: "",
                                autoTopUpValue: u,
                                isLoading: n.isCcPayment(),
                                hasSecurityCheckRequested: !1,
                                summary: {
                                    title: a.title || "",
                                    price: a.price || "",
                                    displayPrice: a.display_price || ""
                                },
                                paymentDetails: {
                                    mop: i,
                                    paymentOptions: Me(Me({}, o), {}, {
                                        autoTopup: u
                                    }),
                                    onClientPurchaseReceipt: t.onClientPurchaseReceipt,
                                    onIframeRef: n.handleIframeRef,
                                    onErrorLoadingPaymentDetails: n.handleErrorLoadingPaymentDetails,
                                    onPurchaseTransaction: n.handlePurchaseTransaction
                                }
                            }, n.iframeElement = null, n
                        }
                        n = e, (t = r).prototype = Object.create(n.prototype), t.prototype.constructor = t, ke(t, n);
                        var i = r.prototype;
                        return i.componentDidMount = function() {
                            this.isCreditsProduct() ? (this.settingsPromise = X.A.getInstance().get(), this.settingsPromise.then(this.handlePaymentSettings).catch(this.handleErrorPaymentSettings)) : this.showChangeCtas(), s.A.addEventListener("message", this.handleMessageFromIframe), Q.A.trigger(Q.A.BEFORE_SHOW_MODAL)
                        }, i.componentWillUnmount = function() {
                            var e;
                            null == (e = this.settingsPromise) || e.cancel(), s.A.removeEventListener("message", this.handleMessageFromIframe), Q.A.trigger(Q.A.HIDE_MODAL)
                        }, i.isCreditsProduct = function() {
                            return 13 === this.props.paymentOptions.productType
                        }, i.showChangeCtas = function() {
                            var e = this,
                                t = this.props,
                                n = t.allowChangePackage,
                                r = t.onChangePaymentMethod;
                            n && this.setState((function(t) {
                                return {
                                    summary: Me(Me({}, t.summary), {}, {
                                        textCta: c.Ay.get(682),
                                        onClickCta: e.handleChangePackage
                                    })
                                }
                            })), r && this.setState((function(t) {
                                return {
                                    paymentDetails: Me(Me({}, t.paymentDetails), {}, {
                                        textCta: c.Ay.get(682),
                                        onClickCta: e.handleChangePaymentMethod
                                    })
                                }
                            }))
                        }, i.isCcPayment = function() {
                            var e = this.props.paymentOptions;
                            return !this.isStoredPayment() && (0, x.n)(e.providerId)
                        }, i.isStoredPayment = function() {
                            var e = this.props,
                                t = e.storedDetails,
                                n = e.paymentOptions.provider;
                            return t || 100001 === n
                        }, i.setTransactionExtraData = function() {
                            var e, t = null == (e = this.transaction) ? void 0 : e.transaction_id;
                            t && B.K.set(t, {
                                billingEmail: this.state.email
                            })
                        }, i.postMessageCcForm = function(e) {
                            var t, n = new s.A.URL(this.ccFormUrl);
                            null == (t = this.iframeElement.contentWindow) || t.postMessage({
                                event: e
                            }, n.origin)
                        }, i.render = function() {
                            var e = this.props,
                                t = e.title,
                                n = e.orderRecap,
                                r = this.state,
                                i = r.autoTopUpValue,
                                a = r.email,
                                o = r.emailErrorLabel,
                                s = r.isLoading,
                                u = r.hasSecurityCheckRequested,
                                l = r.paymentDetails,
                                d = r.summary;
                            return (0, le.jsx)(Ue, {
                                closeIconLabel: c.Ay.get(268),
                                title: t,
                                summary: d,
                                paymentDetails: l,
                                isBillingEmailRequired: Boolean(n.is_billing_email_required),
                                email: a,
                                emailLabel: c.Ay.get(684),
                                emailErrorLabel: o,
                                tnc: n.tnc,
                                isAutoTopUpAvailable: n.is_auto_topup_available,
                                autoTopUpValue: i,
                                autoTopUpText: n.auto_top_up_text,
                                onClickClose: this.handleClickClose,
                                submitCta: n.service_action,
                                isLoading: s,
                                isScreenFixed: u,
                                onSubmitEmail: this.handleSubmitEmail,
                                onChangeEmail: this.handleChangeEmail,
                                onChangeAutoTopUp: this.handleChangeAutoTopUp,
                                onClickSubmitPayment: this.handleClickSubmitPayment
                            })
                        }, r
                    }(q.PureComponent),
                    Be = n(12702),
                    He = n(8483),
                    Ge = function(e) {
                        var t = e.title,
                            n = e.subTitle,
                            r = e.price;
                        return (0, le.jsxs)("div", {
                            className: "ucb-selected-product",
                            children: [(0, le.jsx)("div", {
                                className: "ucb-selected-product__logo",
                                children: (0, le.jsx)(He.A, {
                                    name: "logo-square"
                                })
                            }), (0, le.jsxs)("div", {
                                className: "ucb-selected-product__titles",
                                children: [(0, le.jsx)(pe.P1, {
                                    children: t
                                }), (0, le.jsx)(pe.P3, {
                                    color: "gray-50",
                                    children: n
                                })]
                            }), (0, le.jsx)("div", {
                                className: "ucb-selected-product__price",
                                children: (0, le.jsx)(pe.ZS, {
                                    children: r
                                })
                            })]
                        })
                    },
                    Ve = function(e) {
                        var t = e.children,
                            n = e.onClickBack,
                            r = e.title,
                            i = e.description,
                            a = e.isLoading,
                            o = e.isClosable ? "navigation-bar-close" : "navigation-bar-back";
                        return (0, le.jsx)("div", {
                            className: "ucb-screen-wrapper",
                            children: (0, le.jsxs)(J.A, {
                                dataQA: {
                                    "data-qa": "paywall-screen"
                                },
                                children: [(0, le.jsx)(ee.A, {
                                    children: (0, le.jsxs)(ne.A, {
                                        transparent: !0,
                                        children: [(0, le.jsx)(ie.A, {
                                            isWide: !0,
                                            children: (0, le.jsx)(re.A, {
                                                name: o,
                                                onClick: n
                                            })
                                        }), (0, le.jsx)("div", {
                                            "data-qa": "paywall-title",
                                            children: (0, le.jsx)(oe.A, {
                                                text: r,
                                                tag: "h1"
                                            })
                                        }), (0, le.jsx)(ie.A, {
                                            isWide: !0,
                                            children: " "
                                        })]
                                    })
                                }), (0, le.jsx)($.A, {
                                    align: "top",
                                    children: (0, le.jsxs)("div", {
                                        className: "ucb-screen-wrapper__content",
                                        children: [i ? (0, le.jsx)("div", {
                                            className: "ucb-screen-wrapper__description",
                                            "data-qa": "paywall-description",
                                            children: (0, le.jsx)(pe.P1, {
                                                children: i
                                            })
                                        }) : null, t]
                                    })
                                }), a ? (0, le.jsx)(ue.A, {}) : null]
                            })
                        })
                    },
                    We = (n(62062), function(e) {
                        var t = e.children,
                            n = e.onSelect,
                            r = e.isSelected,
                            i = e.isStored,
                            a = e.iconName,
                            o = e.iconImage,
                            s = e.label,
                            c = e.value,
                            u = function() {
                                null == n || n(c || "")
                            },
                            l = function() {
                                null == n || n(c || "")
                            },
                            d = function() {
                                return a ? (0, le.jsx)(He.A, {
                                    name: a
                                }) : (0, le.jsx)("img", {
                                    src: o,
                                    alt: "",
                                    style: {
                                        width: "100%",
                                        height: "100%"
                                    }
                                })
                            },
                            p = "ucb-payment-provider-" + c,
                            f = Z()({
                                "ucb-provider-item": !0,
                                "is-selected": r
                            });
                        return (0, le.jsxs)("div", {
                            className: f,
                            children: [i ? (0, le.jsxs)("button", {
                                className: "ucb-provider-item__heading",
                                onClick: l,
                                children: [(0, le.jsx)("span", {
                                    className: "ucb-provider-item__image",
                                    children: d()
                                }), (0, le.jsx)(pe.P2, {
                                    inline: !0,
                                    children: s
                                }), (0, le.jsx)("span", {
                                    className: "ucb-provider-item__button-icon",
                                    children: (0, le.jsx)(He.A, {
                                        name: "generic-chevron-right",
                                        size: "xsm"
                                    })
                                })]
                            }) : (0, le.jsxs)("label", {
                                className: "ucb-provider-item__heading",
                                htmlFor: p,
                                "data-qa": "payment-provider-" + c,
                                children: [(0, le.jsx)("span", {
                                    className: "ucb-provider-item__checkbox",
                                    children: (0, le.jsx)(De.A, {
                                        type: "radio",
                                        onChange: u,
                                        name: "provider",
                                        isChecked: r,
                                        value: c,
                                        id: p
                                    })
                                }), (0, le.jsx)("span", {
                                    className: "ucb-provider-item__image",
                                    children: d()
                                }), (0, le.jsx)(pe.P2, {
                                    inline: !0,
                                    children: s
                                })]
                            }), (0, le.jsx)("div", {
                                className: "ucb-provider-item__content",
                                children: t
                            })]
                        })
                    }),
                    Ye = n(78979),
                    qe = function(e) {
                        var t = e.billingEmail,
                            n = e.autoTopUp,
                            r = e.tnc,
                            i = e.onSubmit,
                            a = e.ctaText,
                            o = e.isLoading,
                            s = t || {},
                            c = s.isRequired,
                            u = s.email,
                            l = void 0 === u ? "" : u,
                            d = s.emailLabel,
                            p = s.emailErrorLabel,
                            f = s.onSubmitEmail,
                            h = s.onChangeEmail,
                            g = n || {},
                            v = g.isRequired,
                            m = g.autoTopUpText,
                            y = g.autoTopUpValue,
                            A = g.onChangeAutoTopUp;
                        return (0, le.jsxs)("div", {
                            className: "ucb-generic-data-for-provider",
                            children: [c ? (0, le.jsx)("div", {
                                className: "ucb-billing-email",
                                children: (0, le.jsx)(Oe, {
                                    email: l,
                                    emailLabel: d,
                                    emailErrorLabel: p,
                                    onSubmit: f,
                                    onChange: h
                                })
                            }) : null, (0, le.jsxs)(Ye.A, {
                                spacing: "loose",
                                children: [v && m ? (0, le.jsx)("div", {
                                    "data-qa": "product-top-up",
                                    children: (0, le.jsx)(Le, {
                                        label: m,
                                        value: y,
                                        onChange: A
                                    })
                                }) : null, (0, le.jsx)("div", {
                                    className: "ucb-recap__footer",
                                    children: (0, le.jsx)(se.A, {
                                        icon: "generic-lock",
                                        text: a,
                                        isLoading: o,
                                        onClick: i,
                                        dataQA: {
                                            "data-qa-action": "continue-payment"
                                        }
                                    })
                                }), r ? (0, le.jsx)(we, {
                                    tnc: r
                                }) : null]
                            })]
                        })
                    },
                    Qe = function(e) {
                        var t = e.url,
                            n = e.isFullscreen,
                            r = e.hasDescription,
                            i = e.onRef;
                        ve(t);
                        var a = Z()({
                            "ucb-iframe": !0,
                            "is-fullscreen": n,
                            "has-description": r
                        });
                        return (0, le.jsx)("iframe", {
                            ref: i,
                            src: t,
                            title: c.Ay.get(320),
                            className: a
                        })
                    };

                function Ke(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function Xe(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? Ke(Object(n), !0).forEach((function(t) {
                            ze(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Ke(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function ze(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var Ze = G.A.getLogger("UcbRecap"),
                    Je = function(e) {
                        var t = (0, Be.jh)().state.ccFormState;
                        return {
                            title: (0, q.useMemo)((function() {
                                return t === Be.Kl.SECURITY_STEP ? c.Ay.get(901) : e
                            }), [e, t]),
                            description: (0, q.useMemo)((function() {
                                return t === Be.Kl.SECURITY_STEP ? c.Ay.get(900) : ""
                            }), [t])
                        }
                    },
                    $e = (n(48980), n(79860)),
                    et = function(e) {
                        return e ? 2186 : 2185
                    },
                    tt = function(e) {
                        var t = e.isActive,
                            n = e.iframeRef,
                            r = e.onClientPurchaseReceipt,
                            i = e.onSubmit,
                            a = (0, Be.jh)(),
                            o = a.state,
                            s = a.dispatch,
                            u = o.ccFormUrl,
                            l = o.isCcPayment,
                            d = o.isCcFormFullscreen,
                            p = o.isLoading,
                            f = o.billingEmail,
                            h = o.emailErrorLabel,
                            g = o.autoTopUpValue,
                            m = o.currentUcbRecap,
                            y = o.storedProvider,
                            A = Je("").description,
                            E = Boolean(A);
                        ! function(e) {
                            var t = e.isActive,
                                n = e.onClientPurchaseReceipt,
                                r = (0, q.useRef)(null),
                                i = (0, Be.jh)(),
                                a = i.state,
                                o = i.dispatch,
                                s = a.isCcPayment,
                                c = a.paymentOptions,
                                u = (0, q.useCallback)((function(e) {
                                    s && o({
                                        type: Be.BX.UPDATE_IS_LOADING,
                                        value: !e
                                    }), o({
                                        type: Be.BX.UPDATE_CURRENT_TRANSACTION,
                                        value: e
                                    })
                                }), [o, s]),
                                l = (0, q.useCallback)((function(e, t) {
                                    var n = t || {},
                                        r = n.error,
                                        i = n.purchaseTransactionFailed;
                                    if (!i && (0, _.A)(r || e) && Ze.error("Error loading the payment details", {
                                            error: e,
                                            transactionResult: t
                                        }), o({
                                            type: Be.BX.UPDATE_IS_LOADING,
                                            value: !1
                                        }), o({
                                            type: Be.BX.FIRE_SIGNAL_CLOSE,
                                            value: !0
                                        }), !(e instanceof P.k)) {
                                        var a, s = null == i || null == (a = i.notification) ? void 0 : a.message;
                                        w.A.showNotification({
                                            type: w.A.TYPES.ERROR,
                                            text: s
                                        })
                                    }
                                }), [o]);
                            (0, q.useEffect)((function() {
                                var e;
                                s && t ? (null == u || u(), null == (e = r.current) || e.cancel(), r.current = v.A.getInstance().startTransactionAsPromise(Xe(Xe({}, c), {}, {
                                    ignoreStoredDetails: !0
                                })), r.current.then((function(e) {
                                    var t = e.error,
                                        r = e.purchaseTransaction,
                                        i = e.clientPurchaseReceipt;
                                    r ? null == u || u(r) : i ? null == n || n(i) : null == l || l(t || new Error("Error loading the payment details"), e)
                                }))) : o({
                                    type: Be.BX.UPDATE_CURRENT_TRANSACTION,
                                    value: void 0
                                })
                            }), [t, s, n, l, u, c, r, o])
                        }({
                            isActive: t,
                            onClientPurchaseReceipt: r
                        });
                        var b = function(e) {
                                s({
                                    type: Be.BX.UPDATE_BILLING_EMAIL,
                                    value: e.currentTarget.value
                                }), s({
                                    type: Be.BX.UPDATE_EMAIL_ERROR_LABEL,
                                    value: ""
                                })
                            },
                            T = function(e) {
                                e.preventDefault(), i()
                            },
                            S = function() {
                                var e, t, n = !g;
                                s({
                                    type: Be.BX.UPDATE_AUTO_TOP_UP_VALUE,
                                    value: n
                                }), e = n, t = void 0 !== y, (0, $e.sx)(332, {
                                    element: 709,
                                    parent_element: et(t),
                                    position: e ? 1 : 0
                                })
                            };
                        return t ? (0, le.jsxs)("div", {
                            className: "ucb-provider-item-content",
                            children: [l && (0, le.jsx)(Qe, {
                                url: u || "",
                                onRef: n,
                                isFullscreen: d,
                                hasDescription: E
                            }), (0, le.jsx)(qe, {
                                billingEmail: {
                                    isRequired: Boolean(null == m ? void 0 : m.is_billing_email_required),
                                    email: f,
                                    emailLabel: c.Ay.get(684),
                                    emailErrorLabel: h,
                                    onChangeEmail: b,
                                    onSubmitEmail: T
                                },
                                autoTopUp: {
                                    isRequired: null == m ? void 0 : m.is_auto_topup_available,
                                    autoTopUpText: null == m ? void 0 : m.auto_top_up_text,
                                    autoTopUpValue: g,
                                    onChangeAutoTopUp: S
                                },
                                tnc: null == m ? void 0 : m.tnc,
                                onSubmit: i,
                                ctaText: null == m ? void 0 : m.service_action,
                                isLoading: p
                            })]
                        }) : null
                    },
                    nt = function(e) {
                        var t = e.iframeRef,
                            n = e.providers,
                            r = e.isStoredProviderPressed,
                            i = e.onSubmit,
                            a = e.onProviderSelected,
                            o = e.onClientPurchaseReceipt,
                            s = (0, Be.jh)().state,
                            u = s.selectedProvider,
                            l = s.userPickedPaymentMethod;
                        return (0, le.jsxs)("div", {
                            children: [(0, le.jsx)("div", {
                                className: "ucb-screen-title",
                                children: (0, le.jsx)(pe.ZS, {
                                    children: r ? c.Ay.get(1046) : c.Ay.get(1045)
                                })
                            }), (0, le.jsx)("div", {
                                "data-qa": "payment-providers-wrapper",
                                className: "ucb-provider-items-list",
                                children: null == n ? void 0 : n.map((function(e) {
                                    var n = (null == u ? void 0 : u.provider) === e.provider && (null == u ? void 0 : u.provider_id) === e.provider_id && l;
                                    return (0, le.jsx)(We, {
                                        label: e.provider_name,
                                        value: String(e.provider_id),
                                        iconImage: e.image,
                                        isSelected: n,
                                        onSelect: function() {
                                            return a(e)
                                        },
                                        children: (0, le.jsx)(tt, {
                                            iframeRef: t,
                                            isActive: n,
                                            onSubmit: i,
                                            onClientPurchaseReceipt: o
                                        })
                                    }, e.provider + "_" + e.provider_id)
                                }))
                            })]
                        })
                    },
                    rt = function(e) {
                        var t = e.onSubmit,
                            n = e.onClick,
                            r = (0, Be.jh)().state.storedProvider;
                        return (0, le.jsxs)("div", {
                            children: [(0, le.jsx)("div", {
                                className: "ucb-screen-title",
                                children: (0, le.jsx)(pe.ZS, {
                                    children: c.Ay.get(1047)
                                })
                            }), (0, le.jsxs)("div", {
                                "data-qa": "payment-providers-wrapper",
                                className: "ucb-provider-items-list",
                                children: [(0, le.jsx)(We, {
                                    label: null == r ? void 0 : r.provider_name,
                                    value: String(null == r ? void 0 : r.provider),
                                    iconImage: null == r ? void 0 : r.image,
                                    isStored: !0,
                                    onSelect: function() {
                                        return n(r)
                                    }
                                }, null == r ? void 0 : r.provider), (0, le.jsx)(tt, {
                                    isActive: !0,
                                    onSubmit: t
                                })]
                            })]
                        })
                    },
                    it = function(e) {
                        var t = e.onSubmit,
                            n = e.onProviderSelected,
                            r = (0, Be.jh)().state,
                            i = r.selectedProvider,
                            a = r.storedProvider,
                            o = r.userPickedPaymentMethod,
                            s = (null == i ? void 0 : i.provider) === (null == a ? void 0 : a.provider) && (null == i ? void 0 : i.provider_id) === (null == a ? void 0 : a.provider_id) && o;
                        return (0, le.jsxs)("div", {
                            children: [(0, le.jsx)("div", {
                                className: "ucb-screen-title",
                                children: (0, le.jsx)(pe.ZS, {
                                    children: c.Ay.get(1047)
                                })
                            }), (0, le.jsx)("div", {
                                "data-qa": "payment-providers-wrapper",
                                className: "ucb-provider-items-list",
                                children: (0, le.jsx)(We, {
                                    label: null == a ? void 0 : a.provider_name,
                                    value: String(null == a ? void 0 : a.provider),
                                    isSelected: s,
                                    iconImage: null == a ? void 0 : a.image,
                                    onSelect: function() {
                                        return n(a)
                                    },
                                    children: (0, le.jsx)(tt, {
                                        isActive: s,
                                        onSubmit: t
                                    })
                                }, null == a ? void 0 : a.provider)
                            })]
                        })
                    },
                    at = n(64872),
                    ot = n(55272),
                    st = n(54129),
                    ct = n(7802),
                    ut = n(34256),
                    lt = n(58478);

                function dt(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function pt(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? dt(Object(n), !0).forEach((function(t) {
                            ft(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : dt(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function ft(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var ht = function(e) {
                        var t = e.title,
                            n = e.defaultUcbRecap,
                            r = e.transactionController,
                            i = e.onClose,
                            a = e.onSubmitPayment,
                            o = e.onClientPurchaseReceipt,
                            u = (0, Be.jh)(),
                            l = u.state,
                            d = u.dispatch,
                            p = l.isLoading,
                            f = l.billingEmail,
                            h = l.isStoredProviderPressed,
                            g = l.currentTransaction,
                            m = l.autoTopUpValue,
                            y = l.ignoreStoredDetails,
                            A = l.ccFormUrl,
                            P = l.ccFormState,
                            E = l.isCcPayment,
                            _ = l.selectedProvider,
                            b = l.storedProvider,
                            T = l.nonStoredProviders,
                            S = l.toBeClosed,
                            I = l.selectedProduct,
                            C = l.deviceProfilingId,
                            O = l.paymentOptions,
                            R = (0, ut.d)(),
                            w = Je(t),
                            D = w.title,
                            L = w.description,
                            U = (0, q.useRef)(null),
                            N = (0, q.useMemo)((function() {
                                return !b || h
                            }), [b, h]),
                            j = (0, q.useMemo)((function() {
                                return b && h
                            }), [h, b]),
                            M = (0, q.useMemo)((function() {
                                return b && !h
                            }), [h, b]),
                            x = M || j,
                            k = function(e) {
                                var t;
                                if (null != (t = U.current) && t.src) {
                                    var n, r, i = new s.A.URL((null == (n = U.current) ? void 0 : n.src) || "");
                                    null == (r = U.current) || null == (r = r.contentWindow) || r.postMessage({
                                        event: e
                                    }, i.origin)
                                }
                            },
                            F = (0, q.useCallback)((function(e) {
                                d({
                                    type: Be.BX.UPDATE_SELECTED_PROVIDER,
                                    value: e
                                }), h && d({
                                    type: Be.BX.UPDATE_IGNORE_STORED_DETAILS,
                                    value: !0
                                })
                            }), [d, h]),
                            H = (0, q.useCallback)((function(e) {
                                F(e), d({
                                        type: Be.BX.UPDATE_USER_PICKED_PAYMENT_METHOD,
                                        value: !0
                                    }),
                                    function(e, t, n) {
                                        var r = (null == t ? void 0 : t.findIndex((function(t) {
                                            return t.provider === (null == e ? void 0 : e.provider)
                                        }))) || 0;
                                        (0, $e.sx)(332, {
                                            element: 2188,
                                            parent_element: et(n),
                                            position: Math.max(r, 0)
                                        })
                                    }(e, T, x)
                            }), [d, F, x, T]),
                            G = function(e) {
                                F(e), (0, $e.sx)(332, {
                                    element: 2187,
                                    parent_element: et(!0),
                                    position: 0
                                }), d({
                                    type: Be.BX.UPDATE_STORED_PROVIDER,
                                    value: e
                                }), d({
                                    type: Be.BX.UPDATE_STORE_PROVIDER_PRESSED,
                                    value: !0
                                })
                            },
                            V = function() {
                                if (function(e) {
                                        (0, $e.sx)(332, {
                                            element: 235,
                                            parent_element: et(e)
                                        })
                                    }(x), (0, lt.D)(_))(0, lt.V)(_, O, C);
                                else if (!E || U.current && A) {
                                    if (d({
                                            type: Be.BX.UPDATE_IS_LOADING,
                                            value: !0
                                        }), ct.q.setValue(!0), null != n && n.is_billing_email_required && !(0, K.m)(f || "")) return d({
                                        type: Be.BX.UPDATE_EMAIL_ERROR_LABEL,
                                        value: c.Ay.get(683)
                                    }), void d({
                                        type: Be.BX.UPDATE_IS_LOADING,
                                        value: !1
                                    });
                                    if (E)(t = null == g ? void 0 : g.transaction_id) && B.K.set(t, {
                                        billingEmail: f
                                    }), k(Y.An.SUBMIT_FORM);
                                    else {
                                        if ((0, ot.K)(_) || (0, st.R)(_)) {
                                            var e = pt(pt({}, O), {}, {
                                                useSync: !0
                                            });
                                            v.A.getInstance().startTransaction(e, (function(e) {
                                                O.purchaseTransaction = e.purchaseTransaction, O.handleOnStartTransaction = !0
                                            }))
                                        } else O.purchaseTransaction = void 0, O.handleOnStartTransaction = void 0;
                                        f && (O.billingEmail = f), O.autoTopup = m, O.ignoreStoredDetails = y, a(O)
                                    }
                                    var t
                                }
                            };
                        (0, q.useEffect)((function() {
                            (M || j) && F(b)
                        }), [F, M, j, b]), (0, q.useEffect)((function() {
                            S && i()
                        }), [i, S]), (0, q.useEffect)((function() {
                            var e;
                            N && 1 === (null == T ? void 0 : T.length) && d({
                                type: Be.BX.UPDATE_CURRENT_UCB_RECAP,
                                value: null == I || null == (e = I.providers) ? void 0 : e[0].ucb_recap
                            })
                        }), [d, N, T, I]), (0, at.L)({
                            selectedProvider: _,
                            transactionController: r,
                            isUcbFlow: !0
                        }),
                        function(e) {
                            var t = e.iframeRef,
                                n = e.isCcPayment,
                                r = (0, Be.jh)().dispatch;
                            (0, q.useEffect)((function() {
                                if (n) return s.A.addEventListener("message", i),
                                    function() {
                                        return s.A.removeEventListener("message", i)
                                    };

                                function e(e) {
                                    var n = Number(e);
                                    null != t && t.current && (isNaN(n) ? (t.current.height = "", t.current.style.height = "") : (t.current.height = n + "px", t.current.style.height = n + "px"))
                                }

                                function i(t) {
                                    if (Pe(t.origin) && t.data) {
                                        var n = t.data,
                                            i = n.event,
                                            a = n.data;
                                        i && Ne.includes(i) && r({
                                            type: Be.BX.UPDATE_IS_LOADING,
                                            value: !1
                                        }), i === Y.An.SECURITY_CHECK && (r({
                                            type: Be.BX.UPDATE_IS_CC_FORM_FULLSCREEN,
                                            value: !0
                                        }), r({
                                            type: Be.BX.UPDATE_CC_FORM_STATE,
                                            value: Be.Kl.SECURITY_STEP
                                        }), e("NaN")), i === Y.An.UPDATE_HEIGHT && e((a || {}).height)
                                    }
                                }
                            }), [r, t, n])
                        }({
                            iframeRef: U,
                            isCcPayment: E
                        }), (0, q.useEffect)((function() {
                            k(Y.An.STORE_DETAILS)
                        }), [m]), (0, q.useEffect)((function() {
                            d({
                                type: Be.BX.UPDATE_IS_LOADING,
                                value: R
                            })
                        }), [d, R]), (0, q.useEffect)((function() {
                            var e = (null == T ? void 0 : T.length) || 1;
                            (0, $e.sx)(258, {
                                element: et(void 0 !== b),
                                count: x ? 1 : e
                            })
                        }), [T, x, b]);
                        return (0, le.jsxs)(Ve, {
                            title: D,
                            description: L,
                            onClickBack: function() {
                                h ? d({
                                    type: Be.BX.UPDATE_STORE_PROVIDER_PRESSED,
                                    value: !1
                                }) : i(g, P === Be.Kl.SECURITY_STEP)
                            },
                            isClosable: !h,
                            isLoading: p,
                            children: [(0, le.jsx)(Ge, {
                                title: null == n ? void 0 : n.title,
                                subTitle: null == n ? void 0 : n.display_price,
                                price: null == n ? void 0 : n.price
                            }), (0, le.jsxs)("div", {
                                className: "ucb-screen-wrapper__content_scrollable",
                                children: [M ? (0, le.jsx)(rt, {
                                    onSubmit: V,
                                    onClick: G
                                }) : null, j ? (0, le.jsx)(it, {
                                    onSubmit: V,
                                    onProviderSelected: H
                                }) : null, N ? (0, le.jsx)(nt, {
                                    iframeRef: U,
                                    providers: T,
                                    isStoredProviderPressed: h,
                                    onSubmit: V,
                                    onProviderSelected: H,
                                    onClientPurchaseReceipt: o
                                }) : null]
                            })]
                        })
                    },
                    gt = ["children"];

                function vt(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function mt(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? vt(Object(n), !0).forEach((function(t) {
                            yt(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : vt(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function yt(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var At = function(e) {
                        e.children;
                        var t = function(e, t) {
                            if (null == e) return {};
                            var n, r, i = {},
                                a = Object.keys(e);
                            for (r = 0; r < a.length; r++) n = a[r], t.indexOf(n) >= 0 || (i[n] = e[n]);
                            return i
                        }(e, gt);
                        return (0, le.jsx)(Be.FW, mt(mt({}, t), {}, {
                            children: (0, le.jsx)(ht, {
                                title: t.title,
                                defaultUcbRecap: t.defaultUcbRecap,
                                onClose: t.onClose,
                                onSubmitPayment: t.onSubmitPayment,
                                onClientPurchaseReceipt: t.onClientPurchaseReceipt,
                                transactionController: t.transactionController
                            })
                        }))
                    },
                    Pt = n(91258),
                    Et = function(e) {
                        var t = e.closeIconLabel,
                            n = e.psd2HeaderRef,
                            r = e.psd2Heading,
                            i = e.psd2Body,
                            a = e.onClose;
                        return Boolean(r || i) ? (0, le.jsxs)("div", {
                            ref: n,
                            children: [(0, le.jsxs)(ne.A, {
                                position: "fixed",
                                shadow: !1,
                                children: [(0, le.jsx)(ie.A, {
                                    children: (0, le.jsx)(re.A, {
                                        name: "navigation-bar-close",
                                        onClick: a,
                                        a11y: {
                                            iconLabel: t
                                        }
                                    })
                                }), (0, le.jsx)(oe.A, {
                                    text: r
                                }), (0, le.jsx)(ae.A, {})]
                            }), (0, le.jsx)(ne.A, {}), (0, le.jsx)("div", {
                                className: "payment-process-window__sub-header",
                                children: (0, le.jsx)("div", {
                                    className: "payment-process-window__sub-header_content",
                                    children: (0, le.jsx)(pe.P2, {
                                        children: i
                                    })
                                })
                            })]
                        }) : (0, le.jsx)(ne.A, {
                            position: "fixed",
                            transparent: !0,
                            children: (0, le.jsx)(ie.A, {
                                children: (0, le.jsx)(re.A, {
                                    name: "generic-close-circle-semitransparent",
                                    a11y: {
                                        iconLabel: t
                                    },
                                    dataQA: {
                                        "data-qa": "navbar-close"
                                    },
                                    onClick: a
                                })
                            })
                        })
                    },
                    _t = function(e) {
                        var t, n, r = e.children,
                            i = e.childrenContainerRef,
                            a = e.closeIconLabel,
                            o = e.isLoading,
                            s = void 0 !== o && o,
                            c = e.psd2Body,
                            u = e.psd2HeaderRef,
                            l = e.psd2Heading,
                            d = e.processWindowHeight,
                            p = e.onClose,
                            f = Boolean(l || c),
                            h = Z()({
                                "payment-process-window__content": !0,
                                "payment-process-window__content--fit": Boolean(f)
                            });
                        return f ? d && (n = {
                            height: d + "px"
                        }) : t = "stretch", (0, le.jsx)("div", {
                            className: "payment-process-window",
                            children: (0, le.jsxs)(J.A, {
                                children: [(0, le.jsx)(ee.A, {
                                    children: (0, le.jsx)(Et, {
                                        closeIconLabel: a,
                                        psd2Body: c,
                                        psd2HeaderRef: u,
                                        psd2Heading: l,
                                        onClose: p
                                    })
                                }), (0, le.jsx)($.A, {
                                    align: t,
                                    children: (0, le.jsx)("div", {
                                        className: h,
                                        style: n,
                                        children: (0, le.jsxs)("div", {
                                            className: "payment-process-window__fake",
                                            ref: i,
                                            children: [r, s ? (0, le.jsx)(ue.A, {}) : null]
                                        })
                                    })
                                })]
                            })
                        })
                    },
                    bt = function(e) {
                        var t = e.threeDSecureRedirect,
                            n = e.onClose,
                            r = e.onError,
                            i = e.onSuccess,
                            a = (0, q.useState)(!0),
                            o = a[0],
                            u = a[1],
                            l = (0, q.useState)(0),
                            d = l[0],
                            p = l[1],
                            f = (0, q.useRef)(null),
                            h = (0, q.useRef)(null);
                        (0, q.useEffect)((function() {
                            return Q.A.trigger(Q.A.BEFORE_SHOW_MODAL),
                                function() {
                                    var e;
                                    Q.A.trigger(Q.A.HIDE_MODAL), null == (e = h.current) || e.destroy()
                                }
                        }), []);
                        var g = (0, q.useCallback)((function() {
                            if (f.current) {
                                var e = s.A.document.body.clientHeight - f.current.clientHeight;
                                p(e)
                            }
                        }), []);
                        return (0, q.useEffect)((function() {
                            return s.A.addEventListener("resize", g),
                                function() {
                                    s.A.removeEventListener("resize", g)
                                }
                        }), [g]), (0, le.jsx)(_t, {
                            childrenContainerRef: function(e) {
                                if (e) {
                                    var n = t.params || [];
                                    h.current = new O.RQ({
                                        rootElement: e,
                                        data: {
                                            form_action_url: t.url,
                                            fields: n.reduce((function(e, t) {
                                                return e[t.key] = t.value, e
                                            }), {})
                                        },
                                        onSuccess: i,
                                        onError: r
                                    }), s.A.setTimeout((function() {
                                        u(!1)
                                    }), 1e3)
                                }
                            },
                            closeIconLabel: c.Ay.get(268),
                            isLoading: o,
                            processWindowHeight: d,
                            psd2Body: c.Ay.get(900),
                            psd2HeaderRef: function(e) {
                                f.current = e, g()
                            },
                            psd2Heading: c.Ay.get(901),
                            onClose: n
                        })
                    },
                    Tt = n(27384),
                    St = function(e) {
                        var t = e.closeIconLabel,
                            n = e.iframeRef,
                            r = e.iframeTitle,
                            i = e.iframeUrl,
                            a = e.isIframeHidden,
                            o = e.isLoading,
                            s = void 0 !== o && o,
                            c = e.isScrollableIframe,
                            u = void 0 !== c && c,
                            l = e.processWindowHeight,
                            d = e.psd2HeaderRef,
                            p = e.psd2Heading,
                            f = e.psd2Body,
                            h = e.onClose;
                        ge(i);
                        var g = Z()({
                                "payment-process-window__iframe": !0,
                                "is-hidden": a
                            }),
                            v = u ? "yes" : "no";
                        return (0, le.jsx)(_t, {
                            closeIconLabel: t,
                            isLoading: s,
                            processWindowHeight: l,
                            psd2Body: f,
                            psd2HeaderRef: d,
                            psd2Heading: p,
                            onClose: h,
                            children: (0, le.jsx)("iframe", {
                                title: r,
                                ref: n,
                                src: i,
                                className: g,
                                style: {
                                    width: "100%",
                                    height: "100%",
                                    border: "none"
                                },
                                scrolling: v,
                                "data-qa": "payment-process-window"
                            })
                        })
                    };
                var It, Ct, Ot, Rt, wt = {
                        CC_FORM: "cc_form",
                        EMBEDDED_SECURITY_CHECK: Y.vD.EMBEDDED,
                        REDIRECT_SECURITY_CHECK: Y.vD.REDIRECT
                    },
                    Dt = function(e) {
                        var t = e.isFinishingPayment,
                            n = void 0 !== t && t,
                            r = e.isIframeHidden,
                            i = e.isOneOffSecurityStep,
                            a = e.url,
                            o = e.onClose,
                            l = e.onIframeMounted,
                            d = (0, q.useState)(0),
                            p = d[0],
                            f = d[1],
                            h = (0, q.useState)(i ? wt.EMBEDDED_SECURITY_CHECK : wt.CC_FORM),
                            g = h[0],
                            v = h[1],
                            m = (0, q.useRef)(null),
                            y = (0, q.useRef)(!1),
                            A = (i || g !== wt.CC_FORM) && !r,
                            P = (0, q.useCallback)((function() {
                                null == o || o(g === wt.EMBEDDED_SECURITY_CHECK)
                            }), [o, g]);
                        (0, q.useEffect)((function() {
                            function e(e) {
                                Pe(e.origin) && e.data && (Object.prototype.hasOwnProperty.call(e.data, "isKeyboardVisible") && (y.current = Boolean(e.data.isKeyboardVisible)), function(e) {
                                    var t;
                                    return (null == (t = e.data) ? void 0 : t.event) === Y.An.SECURITY_CHECK
                                }(e) && v(e.data.type))
                            }
                            return Q.A.trigger(Q.A.BEFORE_SHOW_MODAL), s.A.addEventListener("message", e),
                                function() {
                                    var t;
                                    Q.A.trigger(Q.A.HIDE_MODAL), s.A.removeEventListener("message", e), u.A.ios && y.current && (y.current = !1, (t = s.A.document.createElement("input")).type = "text", s.A.document.body.appendChild(t), t.addEventListener("focus", (function() {
                                        s.A.setTimeout((function() {
                                            t.blur(), t.remove()
                                        }), 300)
                                    })), t.focus())
                                }
                        }), []);
                        var E = (0, q.useCallback)((function() {
                            if (A && m.current) {
                                var e = s.A.document.body.clientHeight - m.current.clientHeight;
                                f(e)
                            }
                        }), [A]);
                        return (0, q.useEffect)((function() {
                            return s.A.addEventListener("resize", E),
                                function() {
                                    s.A.removeEventListener("resize", E)
                                }
                        }), [E]), (0, le.jsx)(St, {
                            closeIconLabel: c.Ay.get(268),
                            iframeRef: function(e) {
                                e && (null == l || l(e))
                            },
                            iframeTitle: A ? c.Ay.get(321) : c.Ay.get(320),
                            iframeUrl: a,
                            isIframeHidden: r,
                            isLoading: n,
                            isScrollableIframe: g !== wt.EMBEDDED_SECURITY_CHECK,
                            processWindowHeight: p,
                            psd2HeaderRef: function(e) {
                                m.current = e, E()
                            },
                            psd2Heading: A ? c.Ay.get(901) : void 0,
                            psd2Body: A ? c.Ay.get(900) : void 0,
                            onClose: P
                        })
                    },
                    Lt = n(86812),
                    Ut = (n(50113), n(26910), n(69079));

                function Nt() {
                    "use strict";
                    Nt = function() {
                        return t
                    };
                    var e, t = {},
                        n = Object.prototype,
                        r = n.hasOwnProperty,
                        i = Object.defineProperty || function(e, t, n) {
                            e[t] = n.value
                        },
                        a = "function" == typeof Symbol ? Symbol : {},
                        o = a.iterator || "@@iterator",
                        s = a.asyncIterator || "@@asyncIterator",
                        c = a.toStringTag || "@@toStringTag";

                    function u(e, t, n) {
                        return Object.defineProperty(e, t, {
                            value: n,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }), e[t]
                    }
                    try {
                        u({}, "")
                    } catch (e) {
                        u = function(e, t, n) {
                            return e[t] = n
                        }
                    }

                    function l(e, t, n, r) {
                        var a = t && t.prototype instanceof m ? t : m,
                            o = Object.create(a.prototype),
                            s = new w(r || []);
                        return i(o, "_invoke", {
                            value: I(e, n, s)
                        }), o
                    }

                    function d(e, t, n) {
                        try {
                            return {
                                type: "normal",
                                arg: e.call(t, n)
                            }
                        } catch (e) {
                            return {
                                type: "throw",
                                arg: e
                            }
                        }
                    }
                    t.wrap = l;
                    var p = "suspendedStart",
                        f = "suspendedYield",
                        h = "executing",
                        g = "completed",
                        v = {};

                    function m() {}

                    function y() {}

                    function A() {}
                    var P = {};
                    u(P, o, (function() {
                        return this
                    }));
                    var E = Object.getPrototypeOf,
                        _ = E && E(E(D([])));
                    _ && _ !== n && r.call(_, o) && (P = _);
                    var b = A.prototype = m.prototype = Object.create(P);

                    function T(e) {
                        ["next", "throw", "return"].forEach((function(t) {
                            u(e, t, (function(e) {
                                return this._invoke(t, e)
                            }))
                        }))
                    }

                    function S(e, t) {
                        function n(i, a, o, s) {
                            var c = d(e[i], e, a);
                            if ("throw" !== c.type) {
                                var u = c.arg,
                                    l = u.value;
                                return l && "object" == typeof l && r.call(l, "__await") ? t.resolve(l.__await).then((function(e) {
                                    n("next", e, o, s)
                                }), (function(e) {
                                    n("throw", e, o, s)
                                })) : t.resolve(l).then((function(e) {
                                    u.value = e, o(u)
                                }), (function(e) {
                                    return n("throw", e, o, s)
                                }))
                            }
                            s(c.arg)
                        }
                        var a;
                        i(this, "_invoke", {
                            value: function(e, r) {
                                function i() {
                                    return new t((function(t, i) {
                                        n(e, r, t, i)
                                    }))
                                }
                                return a = a ? a.then(i, i) : i()
                            }
                        })
                    }

                    function I(t, n, r) {
                        var i = p;
                        return function(a, o) {
                            if (i === h) throw new Error("Generator is already running");
                            if (i === g) {
                                if ("throw" === a) throw o;
                                return {
                                    value: e,
                                    done: !0
                                }
                            }
                            for (r.method = a, r.arg = o;;) {
                                var s = r.delegate;
                                if (s) {
                                    var c = C(s, r);
                                    if (c) {
                                        if (c === v) continue;
                                        return c
                                    }
                                }
                                if ("next" === r.method) r.sent = r._sent = r.arg;
                                else if ("throw" === r.method) {
                                    if (i === p) throw i = g, r.arg;
                                    r.dispatchException(r.arg)
                                } else "return" === r.method && r.abrupt("return", r.arg);
                                i = h;
                                var u = d(t, n, r);
                                if ("normal" === u.type) {
                                    if (i = r.done ? g : f, u.arg === v) continue;
                                    return {
                                        value: u.arg,
                                        done: r.done
                                    }
                                }
                                "throw" === u.type && (i = g, r.method = "throw", r.arg = u.arg)
                            }
                        }
                    }

                    function C(t, n) {
                        var r = n.method,
                            i = t.iterator[r];
                        if (i === e) return n.delegate = null, "throw" === r && t.iterator.return && (n.method = "return", n.arg = e, C(t, n), "throw" === n.method) || "return" !== r && (n.method = "throw", n.arg = new TypeError("The iterator does not provide a '" + r + "' method")), v;
                        var a = d(i, t.iterator, n.arg);
                        if ("throw" === a.type) return n.method = "throw", n.arg = a.arg, n.delegate = null, v;
                        var o = a.arg;
                        return o ? o.done ? (n[t.resultName] = o.value, n.next = t.nextLoc, "return" !== n.method && (n.method = "next", n.arg = e), n.delegate = null, v) : o : (n.method = "throw", n.arg = new TypeError("iterator result is not an object"), n.delegate = null, v)
                    }

                    function O(e) {
                        var t = {
                            tryLoc: e[0]
                        };
                        1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                    }

                    function R(e) {
                        var t = e.completion || {};
                        t.type = "normal", delete t.arg, e.completion = t
                    }

                    function w(e) {
                        this.tryEntries = [{
                            tryLoc: "root"
                        }], e.forEach(O, this), this.reset(!0)
                    }

                    function D(t) {
                        if (t || "" === t) {
                            var n = t[o];
                            if (n) return n.call(t);
                            if ("function" == typeof t.next) return t;
                            if (!isNaN(t.length)) {
                                var i = -1,
                                    a = function n() {
                                        for (; ++i < t.length;)
                                            if (r.call(t, i)) return n.value = t[i], n.done = !1, n;
                                        return n.value = e, n.done = !0, n
                                    };
                                return a.next = a
                            }
                        }
                        throw new TypeError(typeof t + " is not iterable")
                    }
                    return y.prototype = A, i(b, "constructor", {
                        value: A,
                        configurable: !0
                    }), i(A, "constructor", {
                        value: y,
                        configurable: !0
                    }), y.displayName = u(A, c, "GeneratorFunction"), t.isGeneratorFunction = function(e) {
                        var t = "function" == typeof e && e.constructor;
                        return !!t && (t === y || "GeneratorFunction" === (t.displayName || t.name))
                    }, t.mark = function(e) {
                        return Object.setPrototypeOf ? Object.setPrototypeOf(e, A) : (e.__proto__ = A, u(e, c, "GeneratorFunction")), e.prototype = Object.create(b), e
                    }, t.awrap = function(e) {
                        return {
                            __await: e
                        }
                    }, T(S.prototype), u(S.prototype, s, (function() {
                        return this
                    })), t.AsyncIterator = S, t.async = function(e, n, r, i, a) {
                        void 0 === a && (a = Promise);
                        var o = new S(l(e, n, r, i), a);
                        return t.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                            return e.done ? e.value : o.next()
                        }))
                    }, T(b), u(b, c, "Generator"), u(b, o, (function() {
                        return this
                    })), u(b, "toString", (function() {
                        return "[object Generator]"
                    })), t.keys = function(e) {
                        var t = Object(e),
                            n = [];
                        for (var r in t) n.push(r);
                        return n.reverse(),
                            function e() {
                                for (; n.length;) {
                                    var r = n.pop();
                                    if (r in t) return e.value = r, e.done = !1, e
                                }
                                return e.done = !0, e
                            }
                    }, t.values = D, w.prototype = {
                        constructor: w,
                        reset: function(t) {
                            if (this.prev = 0, this.next = 0, this.sent = this._sent = e, this.done = !1, this.delegate = null, this.method = "next", this.arg = e, this.tryEntries.forEach(R), !t)
                                for (var n in this) "t" === n.charAt(0) && r.call(this, n) && !isNaN(+n.slice(1)) && (this[n] = e)
                        },
                        stop: function() {
                            this.done = !0;
                            var e = this.tryEntries[0].completion;
                            if ("throw" === e.type) throw e.arg;
                            return this.rval
                        },
                        dispatchException: function(t) {
                            if (this.done) throw t;
                            var n = this;

                            function i(r, i) {
                                return s.type = "throw", s.arg = t, n.next = r, i && (n.method = "next", n.arg = e), !!i
                            }
                            for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                                var o = this.tryEntries[a],
                                    s = o.completion;
                                if ("root" === o.tryLoc) return i("end");
                                if (o.tryLoc <= this.prev) {
                                    var c = r.call(o, "catchLoc"),
                                        u = r.call(o, "finallyLoc");
                                    if (c && u) {
                                        if (this.prev < o.catchLoc) return i(o.catchLoc, !0);
                                        if (this.prev < o.finallyLoc) return i(o.finallyLoc)
                                    } else if (c) {
                                        if (this.prev < o.catchLoc) return i(o.catchLoc, !0)
                                    } else {
                                        if (!u) throw new Error("try statement without catch or finally");
                                        if (this.prev < o.finallyLoc) return i(o.finallyLoc)
                                    }
                                }
                            }
                        },
                        abrupt: function(e, t) {
                            for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                                var i = this.tryEntries[n];
                                if (i.tryLoc <= this.prev && r.call(i, "finallyLoc") && this.prev < i.finallyLoc) {
                                    var a = i;
                                    break
                                }
                            }
                            a && ("break" === e || "continue" === e) && a.tryLoc <= t && t <= a.finallyLoc && (a = null);
                            var o = a ? a.completion : {};
                            return o.type = e, o.arg = t, a ? (this.method = "next", this.next = a.finallyLoc, v) : this.complete(o)
                        },
                        complete: function(e, t) {
                            if ("throw" === e.type) throw e.arg;
                            return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), v
                        },
                        finish: function(e) {
                            for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                                var n = this.tryEntries[t];
                                if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), R(n), v
                            }
                        },
                        catch: function(e) {
                            for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                                var n = this.tryEntries[t];
                                if (n.tryLoc === e) {
                                    var r = n.completion;
                                    if ("throw" === r.type) {
                                        var i = r.arg;
                                        R(n)
                                    }
                                    return i
                                }
                            }
                            throw new Error("illegal catch attempt")
                        },
                        delegateYield: function(t, n, r) {
                            return this.delegate = {
                                iterator: D(t),
                                resultName: n,
                                nextLoc: r
                            }, "next" === this.method && (this.arg = e), v
                        }
                    }, t
                }

                function jt(e, t, n, r, i, a, o) {
                    try {
                        var s = e[a](o),
                            c = s.value
                    } catch (e) {
                        return void n(e)
                    }
                    s.done ? t(c) : Promise.resolve(c).then(r, i)
                }

                function Mt(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function xt(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? Mt(Object(n), !0).forEach((function(t) {
                            kt(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Mt(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function kt(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function Ft(e, t) {
                    return Ft = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, Ft(e, t)
                }! function(e) {
                    e.CANCEL = "CANCEL", e.COMPLETE = "COMPLETE", e.FAILED = "FAILED", e.PROCESSING = "PROCESSING", e.SUCCESS = "SUCCESS"
                }(It || (It = {})),
                function(e) {
                    e.BACK = "BACK"
                }(Ct || (Ct = {})),
                function(e) {
                    e.SUCCESS = "SUCCESS", e.FAILED = "FAILED", e.CANCELLED = "CANCELLED"
                }(Ot || (Ot = {})),
                function(e) {
                    e.DETECT_SLEEP = "DETECT_SLEEP", e.MANUAL = "MANUAL", e.MANUAL_INTERRUPTED = "MANUAL_INTERRUPTED", e.STORED = "STORED", e.LOCAL_STORAGE = "LOCAL_STORAGE", e.BILLING = "BILLING"
                }(Rt || (Rt = {}));
                var Bt = g.A.getInstance(),
                    Ht = "bd-payment-redirect",
                    Gt = "/payment-container.html",
                    Vt = u.A.ios7 || u.A.samsungBrowser,
                    Wt = [],
                    Yt = [113, 117, 180, 192],
                    qt = function(e) {
                        var t, n;

                        function r() {
                            for (var t, n = arguments.length, r = new Array(n), a = 0; a < n; a++) r[a] = arguments[a];
                            return (t = e.call.apply(e, [this].concat(r)) || this).applePay = null, t.ccOverlayData = {
                                containerId: "",
                                hideIframe: !1,
                                iframe: null,
                                isFinishingPayment: !1,
                                isOneOffSecurityStep: !1,
                                url: ""
                            }, t.googlePay = null, t.orderRecapContainerId = "", t.ucbRecapContainerId = "", t.extraDataModalContainerId = "", t.paymentPopupWindow = null, t.paymentResultReceived = !1, t.paymentResultWait = null, t.threatmetrixHandler = null, t.threeDSData = {
                                containerId: "",
                                iframe: null
                            }, t.threeDS2Handler = null, t.transactionStarted = !1, t.transactionFinished = !1, t.currentTransaction = null, t.merchantValidationHandler = function(e) {
                                return new Promise((function(n, r) {
                                    var i, a = (null == (i = t.applePay) ? void 0 : i.getTransactionId()) || "";
                                    v.A.getInstance().validateMerchant({
                                        validationURL: e,
                                        transactionId: a
                                    }).then((function(e) {
                                        if (!e.success) return r(new Error("Failed to validate the merchant"));
                                        try {
                                            var t = e.validation_data;
                                            if ("string" == typeof t) {
                                                var i = JSON.parse(t);
                                                n(i)
                                            } else r(new Error("Merchant session is not present"))
                                        } catch (e) {
                                            r(new Error("Merchant session is invalid"))
                                        }
                                    })).catch(r)
                                }))
                            }, t.handleStartTransaction = function(e, n) {
                                if (!t.checkIfTransactionHasRequirements(e)) {
                                    var r = e.error,
                                        i = e.purchaseTransaction;
                                    if (!r && i) {
                                        var a = i.provider,
                                            o = function(e) {
                                                return e && k.includes(e)
                                            }(a),
                                            s = 192 === a,
                                            c = 180 === a;
                                        return o ? void t.startGoogleWalletPayment(i) : s ? void t.startGooglePayPayment(i) : c ? void t.startApplePayPayment(i) : void t.handlePurchaseTransaction(i, n)
                                    }
                                    var u = e.clientPurchaseReceipt;
                                    t.removePaymentWindow().then((function() {
                                        if (!r && u) {
                                            var n = u.purchase_success ? Ot.SUCCESS : Ot.FAILED;
                                            t.handleTransactionFinished(n, Rt.STORED, e)
                                        } else t.handleTransactionFinished(Ot.FAILED, Rt.BILLING, e)
                                    }))
                                }
                            }, t.handleErrorThreeDSecureRedirect = function() {
                                t.handleTransactionFinished(Ot.FAILED, Rt.BILLING)
                            }, t.handleError3DS2 = function() {
                                t.handleTransactionFinished(Ot.FAILED, Rt.BILLING)
                            }, t.handleIframeMounted = function(e) {
                                t.ccOverlayData.iframe = e, t.paymentPopupWindow = null == e ? void 0 : e.contentWindow
                            }, t.handleDeviceWakeUp = (0, i.A)((function() {
                                b.A.off(b.A.ACTIONS.WAKE_UP, t.handleDeviceWakeUp);
                                var e = D.VB.getPaymentResult();
                                e ? t.handleTransactionResultReceived({
                                    result: e
                                }) : (t.log.error("Empty payment result after a device has woken up"), t.handleTransactionFinished(Ot.CANCELLED, Rt.DETECT_SLEEP))
                            }), 1e3), t.handleMessageReceived = function(e) {
                                var n;
                                Pe(e.origin) && (F(e, t.paymentPopupWindow) && (null != (n = e.data) && n.data ? (t.mustHandleDeviceWakeUp() && b.A.off(b.A.ACTIONS.WAKE_UP, t.handleDeviceWakeUp), t.handleTransactionResultReceived({
                                    result: e.data.data
                                })) : (t.log.error("Payment failed, invalid message", {
                                    data: e.data
                                }), t.handleTransactionFinished(Ot.CANCELLED, Rt.LOCAL_STORAGE))))
                            }, t.handlePaymentReceipt = function(e, n) {
                                var r = !e && null != n && n.purchase_success ? Ot.SUCCESS : Ot.FAILED;
                                if (n && "purchase_success" in n) {
                                    var i = Wt.indexOf((null == n ? void 0 : n.transaction_identifier) || "");
                                    i > -1 && Wt.splice(i, 1)
                                }
                                t.handleTransactionFinished(r, Rt.LOCAL_STORAGE, {
                                    clientPurchaseReceipt: n
                                })
                            }, t.handleIframeClosed = function(e) {
                                t.removeCcOverlay(), t.handleTransactionFinished(Ot.CANCELLED, e ? Rt.MANUAL_INTERRUPTED : Rt.MANUAL)
                            }, t.handleClickCloseThreeDSecureRedirectIframe = function() {
                                Zt(t.getParameters(), t.threeDSData.purchaseTransaction, {
                                    cancellation_reason: 1
                                }), t.removeThreeDSecureRedirectOverlay(), t.handleTransactionFinished(Ot.CANCELLED, Rt.MANUAL), t.trigger(It.CANCEL)
                            }, t.handleReceiptAnyRecapPayment = function(e) {
                                t.handleStartTransaction({
                                    clientPurchaseReceipt: e
                                })
                            }, t.handleSubmitAnyRecapPayment = function(e) {
                                t.updateParameters(e)
                            }, t.handleChangePaymentMethod = function() {
                                var e = t.getParameter("orderRecapFlow");
                                null == e || null == e.onChangePaymentMethod || e.onChangePaymentMethod(), t.removeOrderRecap()
                            }, t.handleCloseOrderRecap = function(e, n) {
                                if (e) {
                                    var r = {
                                        cancellation_reason: n ? 3 : 1
                                    };
                                    Zt(t.getParameters(), e, r)
                                }
                                var i = t.getParameter("orderRecapFlow");
                                null == i || null == i.onClose || i.onClose(), t.removeOrderRecap()
                            }, t.handleCloseUcbRecap = function(e, n) {
                                if (e) {
                                    var r = {
                                        cancellation_reason: n ? 3 : 1
                                    };
                                    Zt(t.getParameters(), e, r)
                                }
                                t.removeUcbRecap()
                            }, t.removeExtraDataModal = function() {
                                t.extraDataModalContainerId && (t.removeReactView((0, Tt.j)()), t.extraDataModalContainerId = "")
                            }, t
                        }
                        n = e, (t = r).prototype = Object.create(n.prototype), t.prototype.constructor = t, Ft(t, n);
                        var u = r.prototype;
                        return u.getParameters = function() {
                            return e.prototype.getParameters.call(this)
                        }, u.onParametersUpdate = function() {
                            var e = this.getParameters();
                            return r.hasRequiredParamsMissed(e) ? (this.log.error("Haven't got all the parameters we need"), f.A.back(), void this.trigger(Ct.BACK)) : (this.transactionFinished = !1, this.transactionStarted = !0, this.paymentResultReceived = !1, this.isOrderRecapFlow() ? this.renderOrderRecap() : this.isUcbRecapFlow() ? this.renderUcbRecap() : this.isExtraModalFlow() ? this.renderExtraDataModal(e) : void this.startTransaction(e))
                        }, r.getExtraDataModalFlow = function(e) {
                            return e.extraDataModalFlow
                        }, r.hasRequiredParamsMissed = function(e) {
                            return !("number" == typeof e.provider && "string" == typeof e.providerName && "string" == typeof e.uid) && !Boolean(e.ucbRecapFlow)
                        }, u.getTransactionFromParams = function(e) {
                            var t = e || xt({}, this.getParameters());
                            return xt(xt({}, t), {}, {
                                useSync: Vt
                            })
                        }, u.startTransaction = function(e) {
                            var t = this;
                            if (!e.purchaseTransaction || e.orderRecapFlow) {
                                Kt(e.provider) && Qt() && !Vt && this.openPaymentWindow(Gt);
                                var n = this.getTransactionFromParams(e);
                                v.A.getInstance().startTransaction(n, this.handleStartTransaction)
                            } else e.handleOnStartTransaction ? (Kt(e.provider) && this.openPaymentWindow(Gt), this.handleStartTransaction({
                                purchaseTransaction: e.purchaseTransaction
                            })) : zt(e).then((function(e) {
                                t.handleStartTransaction({
                                    clientPurchaseReceipt: e
                                })
                            })).catch((function(e) {
                                t.handleStartTransaction({
                                    error: e
                                })
                            }))
                        }, u.checkPendingPayment = function() {
                            var e = D.VB.getPaymentResult();
                            return !!e && (this.handleTransactionResultReceived({
                                result: e,
                                sameWindow: !0
                            }), !0)
                        }, u.onStart = function() {
                            f.A.navigationEvent.subscribe(this.handleNavigation, this), this.resetCcOverlayData()
                        }, u.onStop = function() {
                            return this.paymentResultWait && (this.paymentResultWait.stop(), this.paymentResultWait = null), this.resetCcOverlayData(), f.A.navigationEvent.unsubscribe(this.handleNavigation, this), s.A.removeEventListener("message", this.handleMessageReceived), this.mustHandleDeviceWakeUp() && b.A.off(b.A.ACTIONS.WAKE_UP, this.handleDeviceWakeUp), this.removePaymentWindow().then((function() {
                                D.VB.removePaymentResult()
                            }))
                        }, u.initApplePay = function(e) {
                            var t = this,
                                n = xt(xt({}, e), {}, {
                                    onReady: function(n, r) {
                                        t.handleApplePayReady(n), "function" == typeof e.onReady && e.onReady(n, r)
                                    },
                                    merchantValidationHandler: this.merchantValidationHandler
                                });
                            return this.applePay = new S.A(n), this.applePay
                        }, u.handleApplePayReady = function(e) {
                            e && !(0, Lt.y)(e) && (w.A.showNotification({
                                type: w.A.TYPES.ERROR
                            }), this.log.error("Apple Pay initialized with an error", {
                                error: e
                            }))
                        }, u.initGooglePay = function(e) {
                            var t = this,
                                n = xt(xt({}, e), {}, {
                                    onReady: function(n, r) {
                                        n ? t.handleGooglePayError(n) : "function" == typeof e.onReady && e.onReady(null, r)
                                    }
                                });
                            return this.googlePay = new I.A(n), this.googlePay
                        }, u.handleGooglePayError = function(e) {
                            w.A.showNotification({
                                type: w.A.TYPES.ERROR
                            }), this.log.error("Google pay initialized with an error", {
                                error: e
                            })
                        }, u.checkIfTransactionHasRequirements = function(e) {
                            return !!(0, W.Q)(e.purchaseTransactionFailed) && (this.removePaymentWindow().then((function() {
                                Jt(e.purchaseTransactionFailed), f.A.navigate(h.x.ADD_PHOTOS, {
                                    backHistoryEntry: f.A.getHistoryEntryId(),
                                    destination: f.A.getUrl()
                                })
                            })), !0)
                        }, u.handlePurchaseTransaction = function(e, t) {
                            if (!e) return this.log.error("Missing transactionResult handling the startTransaction", {
                                transactionParams: t || this.getTransactionFromParams()
                            }), void this.handleTransactionFinished(Ot.FAILED, Rt.BILLING);
                            (this.currentTransaction = e, "is_hidden_view" in e) ? this.startOneOff3DS2Handler({
                                redirect_url: e.redirect_url,
                                is_hidden_view: e.is_hidden_view,
                                hidden_view_timeout_sec: e.hidden_view_timeout_sec
                            }, e): (0, C.k)(e) ? this.startThreatmetrixProfiling(e, t) : Qt() && this.startWindowPayment(e) || function(e) {
                                var t = e.redirect_url;
                                t && (n = n || f.A.getUrl(), f.A.saveHistory(), E.A.set(Ht, "/" + n), s.A.location = t);
                                var n
                            }(e)
                        }, u.startThreatmetrixProfiling = function(e, t) {
                            var n = this;
                            this.removeThreatmetrixHandler(), this.threatmetrixHandler = new C._(e), this.threatmetrixHandler.startProfiling().then((function(r) {
                                var i = t ? xt({}, t) : n.getTransactionFromParams();
                                i.threatmetrixSessionId = e.threatmetrix_session_id, i.threatmetrixProfilingStatus = r.status, 2 !== r.status && n.log.error(r.error, {
                                    profilingStatus: r.status,
                                    profilingType: e.threatmetrix_profiling_type
                                }), v.A.getInstance().startTransaction(i, n.handleStartTransaction)
                            }))
                        }, u.startThreeDSecureRedirectHandler = function(e) {
                            Bt.pauseHistory(), this.threeDSData.redirect = e.three_d_secure_redirect, this.threeDSData.purchaseTransaction = e, this.renderThreeDSecureRedirectOverlay()
                        }, u.handleSuccessThreeDSecureRedirect = function(e) {
                            var t = this,
                                n = this.threeDSData,
                                r = n.purchaseTransaction;
                            if (n.containerId)
                                if (e.receipt_data) {
                                    var i = this.getParameters(),
                                        a = i.priceToken,
                                        o = i.productType,
                                        s = i.providerName;
                                    zt({
                                        priceToken: a,
                                        productType: o,
                                        provider: (null == r ? void 0 : r.provider) || this.getParameter("provider"),
                                        providerId: (null == r ? void 0 : r.provider_id) || this.getParameter("providerId"),
                                        providerName: s,
                                        purchaseTransaction: r,
                                        receiptData: e.receipt_data,
                                        uid: (null == r ? void 0 : r.uid) || this.getParameter("uid")
                                    }).then((function(e) {
                                        t.handleStartTransaction({
                                            clientPurchaseReceipt: e
                                        })
                                    })).catch((function(e) {
                                        t.handleStartTransaction({
                                            error: e
                                        })
                                    }))
                                } else this.handleErrorThreeDSecureRedirect()
                        }, u.startOneOff3DS2Handler = function(e, t) {
                            var n, r, i = this;
                            Bt.pauseHistory(), this.ccOverlayData.containerId && (n = (0, Tt.j)(), r = this.ccOverlayData.iframe || void 0, this.ccOverlayData.hideIframe = Boolean(null == e ? void 0 : e.is_hidden_view), this.ccOverlayData.isOneOffSecurityStep = !0, this.renderCcOverlay()), this.threeDS2Handler ? this.threeDS2Handler.updateOptions({
                                data: e,
                                onSuccess: function(e) {
                                    return i.handleSuccess3DS2(t, e)
                                }
                            }) : this.threeDS2Handler = new O.Us({
                                rootElement: n,
                                iframe: r,
                                data: e,
                                onSuccess: function(e) {
                                    return i.handleSuccess3DS2(t, e)
                                },
                                onError: this.handleError3DS2
                            }), this.threeDS2Handler.start()
                        }, u.handleSuccess3DS2 = function(e, t) {
                            var n = this;
                            this.threeDS2Handler && (t.redirect_url ? this.startOneOff3DS2Handler(t, e) : t.receipt_data ? zt({
                                purchaseTransaction: e,
                                productType: this.getParameter("productType"),
                                providerName: this.getParameter("providerName"),
                                priceToken: "",
                                providerId: e.provider_id,
                                provider: e.provider,
                                uid: e.uid,
                                receiptData: t.receipt_data
                            }).then((function(e) {
                                n.handleStartTransaction({
                                    clientPurchaseReceipt: e
                                })
                            })).catch((function(e) {
                                n.handleStartTransaction({
                                    error: e
                                })
                            })) : this.handleError3DS2())
                        }, u.startGoogleWalletPayment = function(e) {
                            var t = e.transaction_id,
                                n = e.unique_flow_id,
                                r = e.provider_product_uid,
                                i = 117 === e.provider,
                                a = this.getParameter("productType"),
                                o = s.A.location.pathname;
                            if (5 === a) {
                                for (var c = s.A.location.pathname.split("/"), u = 0; u < c.length; u += 1)
                                    if (c[u] === n) {
                                        c[u + 2] = String(13);
                                        break
                                    }
                                o = c.join("/")
                            }
                            var l = "" + s.A.location.origin + o + "?__twa=1";
                            if (s.A.localStorage) {
                                M.createTransaction(e), f.A.saveHistory();
                                var d = (0, H.F)({
                                    transactionId: t,
                                    sku: r,
                                    isSubscription: Boolean(i),
                                    resultUrl: l
                                });
                                s.A.location = d
                            }
                        }, u.startGooglePayPayment = function(e) {
                            var t, n = this;
                            null != (t = this.googlePay) && t.isReadyToPay() ? this.googlePay.submitPaymentDataRequest(e, (function(e) {
                                var t = function(e) {
                                        e && (e instanceof P.k || w.A.showNotification({
                                            type: w.A.TYPES.ERROR
                                        }), (0, _.A)(e) && n.log.error("Start transaction as promise failed", {
                                            error: e
                                        })), n.trigger(It.CANCEL)
                                    },
                                    r = n.getParameters();
                                v.A.getInstance().startTransactionAsPromise(xt(xt({}, r), {}, {
                                    googlePayToken: e
                                })).then((function(e) {
                                    var r, i, a, o = e.clientPurchaseReceipt,
                                        s = e.error,
                                        c = e.purchaseTransaction,
                                        u = e.purchaseTransactionFailed;
                                    o ? (r = null, a = null == (i = o) ? void 0 : i.purchase_success, !r && a || (n.trigger(It.CANCEL), n.log.error("Google Pay failed on the provider side", {
                                        error: r
                                    })), n.handlePaymentReceipt(r, i)) : u ? (Jt(u), n.trigger(It.CANCEL)) : null != c && c.three_d_secure_redirect ? n.startThreeDSecureRedirectHandler(c) : s ? t(s) : (n.log.error("Unexpected server purchase transaction response after google pay payment", {
                                        response: e
                                    }), n.trigger(It.CANCEL))
                                })).catch(t)
                            }), (function(t) {
                                if (t.statusCode && "CANCELED" === t.statusCode) {
                                    Zt(n.getParameters(), e, {
                                        cancellation_reason: 2
                                    })
                                } else w.A.showNotification({
                                    type: w.A.TYPES.ERROR
                                }), n.log.error("Google Pay failed", {
                                    error: t,
                                    transactionResult: e
                                });
                                n.trigger(It.CANCEL)
                            })) : (this.log.error("User has seen Google Pay section, but device does not support Google Pay"), w.A.showNotification({
                                type: w.A.TYPES.ERROR
                            }), this.trigger(It.CANCEL), this.removeOrderRecap(), this.removeUcbRecap())
                        }, u.startApplePayPayment = function(e) {
                            var t, n, r = this,
                                i = null == (t = this.applePay) ? void 0 : t.getIsPaymentsPossible(),
                                a = null == (n = this.applePay) ? void 0 : n.getIsPaymentsAvailable();
                            if (i)
                                if (a) {
                                    var o, s, u = c.Ay.get(1039);
                                    null == (o = this.applePay) || o.updateCurrentSession(e, u);
                                    var l = this.getApplePaySessionHandlers();
                                    null == (s = this.applePay) || s.startSession(l)
                                } else {
                                    var d, p;
                                    null == (d = this.applePay) || d.updatePurchaseTransactionData(e), null == (p = this.applePay) || p.setupApplePay().catch((function(t) {
                                        w.A.showNotification({
                                            type: w.A.TYPES.ERROR
                                        }), r.log.error("ApplePay is not available on this device", {
                                            error: t,
                                            purchaseTransaction: e
                                        }), r.trigger(It.CANCEL), r.removeOrderRecap(), r.removeUcbRecap()
                                    }))
                                }
                            else this.log.error("User have seen the Apple Pay section, but his devices does not support Apple Pay"), w.A.showNotification({
                                type: w.A.TYPES.ERROR
                            }), this.removeOrderRecap(), this.removeUcbRecap()
                        }, u.reCheckApplePaymentAvailability = function(e, t) {
                            if (e = "function" == typeof e ? e : a.A, t = "function" == typeof t ? t : a.A, this.transactionStarted) {
                                if (this.applePay) return e(), this.applePay.checkForApplePayAvailability(t);
                                this.log.error("ApplePay has not been initialized in the TransactionsController")
                            }
                        }, u.getApplePaySessionHandlers = function() {
                            var e = this;
                            return {
                                onValidateMerchant: function(t, n) {
                                    t && (w.A.showNotification({
                                        type: w.A.TYPES.ERROR
                                    }), e.log.error("Merchant validation failed", {
                                        error: t,
                                        merchantSession: n
                                    }), e.trigger(It.CANCEL))
                                },
                                onPaymentAuthorized: function(t, n) {
                                    return e.handleApplePayPaymentResult(t, n)
                                },
                                onCancel: function(t, n) {
                                    e.trigger(It.CANCEL)
                                }
                            }
                        }, u.handleApplePayPaymentResult = function(e, t) {
                            var n = this;
                            return new Promise((function(r, i) {
                                var a;
                                if (e) return w.A.showNotification({
                                    type: w.A.TYPES.ERROR
                                }), n.trigger(It.CANCEL), i(new Error("Apple Pay failed for unknown reason"));
                                var o = t || {},
                                    s = o.transactionId,
                                    c = void 0 === s ? "" : s,
                                    u = o.providerId,
                                    l = void 0 === u ? "" : u,
                                    d = o.uid,
                                    p = void 0 === d ? "" : d,
                                    f = o.event,
                                    h = (null == f || null == (a = f.payment) || null == (a = a.token) ? void 0 : a.paymentData) || {},
                                    g = JSON.stringify(h),
                                    m = {
                                        uid: p,
                                        success: !0,
                                        _id: String(c),
                                        _pid: String(l),
                                        _p: String(180),
                                        _receipt_data: g
                                    };
                                v.A.getInstance().getPaymentReceipt(m).then((function(e) {
                                    e.purchase_success ? r(e) : (n.trigger(It.CANCEL), i(new Error("Apple Pay failed on the provider side"))), n.handlePaymentReceipt(null, e)
                                })).catch((function(e) {
                                    n.trigger(It.CANCEL), i(e), n.handlePaymentReceipt(e)
                                }))
                            }))
                        }, u.startWindowPayment = function(e) {
                            var t = e.redirect_url || "";
                            return this.listenForPaymentResult(), this.mustHandleDeviceWakeUp() && b.A.on(b.A.ACTIONS.WAKE_UP, this.handleDeviceWakeUp), this.setPaymentWindowUrl(t)
                        }, u.listenForPaymentResult = function() {
                            var e = this;
                            s.A.addEventListener("message", this.handleMessageReceived), this.paymentResultWait || (this.paymentResultWait = D.VB.waitForPaymentResult((function(t) {
                                e.handleTransactionResultReceived({
                                    result: t
                                })
                            })))
                        }, u.setPaymentWindowUrl = function(e) {
                            if (this.paymentPopupWindow || this.ccOverlayData.containerId) {
                                var t;
                                if (this.isIframeFlow()) this.ccOverlayData.url = en(e), this.renderCcOverlay();
                                else null == (t = this.paymentPopupWindow) || t.location.replace(e);
                                return !0
                            }
                            return this.openPaymentWindow(e)
                        }, u.openPaymentWindow = function(e) {
                            if (this.isIframeFlow()) return this.trigger(It.PROCESSING), f.A.saveHistory(), Bt.pauseHistory(), this.ccOverlayData.url = en(e), this.renderCcOverlay(), !0;
                            var t = s.A.open(e);
                            return ! function(e) {
                                return !e || s.A.closed
                            }(t) && (this.paymentPopupWindow = t, !0)
                        }, u.renderCcOverlay = function() {
                            this.ccOverlayData.containerId = this.renderReactView((0, le.jsx)(Dt, {
                                url: this.ccOverlayData.url,
                                isOneOffSecurityStep: this.ccOverlayData.isOneOffSecurityStep,
                                isIframeHidden: this.ccOverlayData.hideIframe,
                                isFinishingPayment: this.ccOverlayData.isFinishingPayment,
                                onIframeMounted: this.handleIframeMounted,
                                onClose: this.handleIframeClosed
                            }), (0, Tt.j)())
                        }, u.renderThreeDSecureRedirectOverlay = function() {
                            var e;
                            this.threeDSData.containerId = this.renderReactView((0, le.jsx)(bt, {
                                threeDSecureRedirect: null == (e = this.threeDSData.purchaseTransaction) ? void 0 : e.three_d_secure_redirect,
                                onSuccess: this.handleSuccessThreeDSecureRedirect,
                                onError: this.handleErrorThreeDSecureRedirect,
                                onClose: this.handleClickCloseThreeDSecureRedirectIframe
                            }), (0, Tt.j)())
                        }, u.handleTransactionResultReceived = function(e) {
                            var t = this,
                                n = e.result,
                                r = e.sameWindow,
                                i = void 0 !== r && r,
                                a = n._id;
                            this.paymentResultReceived || Wt.includes(a) || (this.paymentResultReceived = !0, Wt.push(a), Xt(i ? "same_window" : "new_window"), this.ccOverlayData.isFinishingPayment = !0, this.hideIframe(), v.A.getInstance().getPaymentReceipt(n).then((function(e) {
                                t.handlePaymentReceipt(null, e)
                            })).catch((function(e) {
                                t.handlePaymentReceipt(e)
                            })))
                        }, u.onGooglePlayPaymentsToConsume = function(e, t) {
                            var n = this,
                                r = e.reduce((function(e, r) {
                                    var i = r.transaction_id;
                                    if (Wt.includes(i)) return e;
                                    M.getTransaction(i) || n.log.warn("Unable to find transaction in localStorage, continuing to send transaction anyway", {
                                        transactionId: i
                                    });
                                    var a = JSON.parse(r.google_response_json).productId,
                                        o = null;
                                    if (t.forEach((function(e) {
                                            var t = e.uid,
                                                n = e.providers;
                                            null == n || n.forEach((function(e) {
                                                e.external_id === a && (o = s.A.btoa(t))
                                            }))
                                        })), !o) return n.log.warn("Unable to find any product with external_id " + a + "."), e;
                                    var c = {
                                        _id: i,
                                        _p: "113",
                                        _pid: "30",
                                        uid: o,
                                        _receipt_data: r.google_response_json,
                                        _receipt_signature: r.google_signature
                                    };
                                    return M.addGoogleReceipt(r, i), e.push(c), e
                                }), []);
                            if (0 !== r.length) {
                                var i = [],
                                    a = [],
                                    o = [],
                                    c = this;
                                this.trigger(It.PROCESSING), r.forEach((function(e) {
                                    v.A.getInstance().getPaymentReceipt(e).then((function(t) {
                                        u(e._id, 0, t)
                                    })).catch((function(t) {
                                        u(e._id)
                                    }))
                                }))
                            }

                            function u(e, t, n) {
                                if (null != n && n.purchase_success ? (M.addServerReceipt(n, e), Wt.push(e), a.push(n), o.push(e)) : M.removeTransaction(e), i.push(e), i.length === r.length)
                                    if (o.length) {
                                        var u = (0, H.F)({
                                            transactionId: o,
                                            consumeTransaction: !0
                                        });
                                        s.A.setTimeout((function() {
                                            c.trigger(It.CANCEL), f.A.navigate(h.x.GOOGLE_PLAY_PURCHASE_SUCCESS, !0, {
                                                clientPurchaseReceipts: a,
                                                purchaseConsumeUrl: u,
                                                onPurchaseConsumed: function() {
                                                    T.A.isOnline() && o.forEach((function(e) {
                                                        return M.removeTransaction(e)
                                                    })), c.navigateAway(Ot.SUCCESS, {
                                                        clientPurchaseReceipt: a[a.length - 1]
                                                    })
                                                }
                                            })
                                        }), 1e3)
                                    } else c.navigateAway(Ot.FAILED, {
                                        clientPurchaseReceipt: n
                                    })
                            }
                        }, u.onGooglePlayPaymentResult = function(e) {
                            var t = this,
                                n = e.result,
                                r = e.isCancelled,
                                i = e.isFailed;
                            if (!Wt.includes(n.transaction_id)) {
                                var a = M.getTransaction(n.transaction_id);
                                if (a) {
                                    this.trigger(It.PROCESSING);
                                    var o = {
                                        _id: a.transaction_id,
                                        _p: "113",
                                        _pid: "" + a.provider_id,
                                        uid: s.A.btoa(a.uid)
                                    };
                                    r || i ? r ? (o.success = "nope", o.cancellation_reason = 1, M.removeTransaction(n.transaction_id)) : i && (o.success = "nope", o.cancellation_reason = 2, M.removeTransaction(n.transaction_id)) : (o._receipt_data = s.A.atob(n.google_response_json), o._receipt_signature = n.google_signature, M.addGoogleReceipt(n, n.transaction_id), Xt("new_window")), v.A.getInstance().getPaymentReceipt(o).then((function(e) {
                                        t.handleGooglePlayPaymentReceipt(a, null, e)
                                    })).catch((function(e) {
                                        t.handleGooglePlayPaymentReceipt(a, e)
                                    }))
                                } else this.log.error("Unable to find google play transaction in localStorage", {
                                    result: n,
                                    isCancelled: r,
                                    isFailed: i
                                })
                            }
                        }, u.handleGooglePlayPaymentReceipt = function(e, t, n) {
                            var r = this,
                                i = e.transaction_id;
                            if (null != n && n.purchase_success) {
                                M.addServerReceipt(n, i);
                                var a = function(e) {
                                        var t, n = M.getGoogleReceipt(e);
                                        if (n) try {
                                            t = JSON.parse(s.A.atob(n.google_response_json)).purchaseToken
                                        } catch (e) {
                                            V.error("Error parsing Google receipt to get the purchaseToken", {
                                                error: e,
                                                googleReceiptData: n
                                            })
                                        }
                                        return t
                                    }(i),
                                    o = (0, H.F)({
                                        consumeTransaction: !0,
                                        purchaseToken: a,
                                        transactionId: i
                                    });
                                117 === e.provider ? (M.removeTransaction(i), this.handlePaymentReceipt(t, n)) : (this.transactionFinished = !0, this.transactionStarted = !1, this.currentTransaction = null, Wt.push(i), s.A.setTimeout((function() {
                                    f.A.navigate(h.x.GOOGLE_PLAY_PURCHASE_SUCCESS, !0, {
                                        clientPurchaseReceipts: [n],
                                        purchaseConsumeUrl: o,
                                        onPurchaseConsumed: function() {
                                            T.A.isOnline() && M.removeTransaction(i), r.navigateAway(Ot.SUCCESS, {
                                                clientPurchaseReceipt: n
                                            })
                                        },
                                        backHistoryEntry: f.A.getHistoryEntryId(),
                                        destination: f.A.getUrl()
                                    })
                                }), 1e3))
                            } else M.removeTransaction(i), this.handlePaymentReceipt(t, n)
                        }, u.handleTransactionFinished = function() {
                            var e, t = (e = Nt().mark((function e(t, n, r) {
                                var i;
                                return Nt().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            if (!this.transactionFinished) {
                                                e.next = 3;
                                                break
                                            }
                                            return this.log.warn("Transaction has finished already", t, n), e.abrupt("return");
                                        case 3:
                                            return e.next = 5, Bt.restartHistory();
                                        case 5:
                                            this.transactionFinished = !0, this.transactionStarted = !1, i = this.currentTransaction, this.currentTransaction = null, D.VB.removePaymentResult(), this.displayResultMessage({
                                                result: t,
                                                type: n,
                                                transactionResult: r,
                                                purchaseTransaction: i
                                            });
                                        case 11:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })), function() {
                                var t = this,
                                    n = arguments;
                                return new Promise((function(r, i) {
                                    var a = e.apply(t, n);

                                    function o(e) {
                                        jt(a, r, i, o, s, "next", e)
                                    }

                                    function s(e) {
                                        jt(a, r, i, o, s, "throw", e)
                                    }
                                    o(void 0)
                                }))
                            });
                            return function(e, n, r) {
                                return t.apply(this, arguments)
                            }
                        }(), u.displayResultMessage = function(e) {
                            var t = e.result,
                                n = e.type,
                                r = e.transactionResult,
                                i = e.purchaseTransaction,
                                a = r || {},
                                o = a.clientPurchaseReceipt,
                                s = a.purchaseTransactionFailed;
                            if (t === Ot.SUCCESS) R.A.processClientPurchaseReceipt(o);
                            else if (t === Ot.CANCELLED && i)
                                if (11 === i.provider_id && i.processing_message) w.A.showNotification({
                                    type: w.A.TYPES.INFO,
                                    text: i.processing_message
                                });
                                else {
                                    var c = {
                                        cancellation_reason: function() {
                                            switch (n) {
                                                case Rt.MANUAL:
                                                    return 1;
                                                case Rt.MANUAL_INTERRUPTED:
                                                    return 3;
                                                default:
                                                    return 0
                                            }
                                        }()
                                    };
                                    Zt(this.getParameters(), i, c)
                                }
                            else if (t !== Ot.CANCELLED || ![Rt.MANUAL, Rt.MANUAL_INTERRUPTED].includes(n)) {
                                var u, l = (null == s ? void 0 : s.notification) || (null == o ? void 0 : o.notification);
                                l && (u = l.message), w.A.showNotification({
                                    type: w.A.TYPES.ERROR,
                                    text: u
                                })
                            }
                            this.navigateAway(t, r)
                        }, u.navigateAway = function(e, t) {
                            var n = this;
                            this.removePaymentWindow().then((function() {
                                if (e === Ot.CANCELLED) return n.trigger(Ct.BACK), void n.trigger(It.CANCEL);
                                var r = t || {},
                                    i = r.clientPurchaseReceipt,
                                    a = r.purchaseTransactionFailed;
                                e === Ot.SUCCESS ? (m.A.getInstance().invalidate(l.A.getUserId()), y.A.getInstance().invalidatePaymentFolders(), A.A.getInstance().invalidate(), n.trigger(It.SUCCESS, i)) : n.trigger(It.FAILED, a || i), n.trigger(It.COMPLETE)
                            }))
                        }, u.removePaymentWindow = function() {
                            var e = this;
                            if (!(this.paymentPopupWindow || this.ccOverlayData.containerId || this.threeDSData.containerId || this.orderRecapContainerId || this.ucbRecapContainerId || this.extraDataModalContainerId)) return Promise.resolve();
                            if (this.isOrderRecapFlow() || this.isUcbRecapFlow()) Bt.restartHistory().then((function() {
                                e.removePaymentFlows()
                            }));
                            else {
                                if (this.isIframeFlow()) return this.paymentPopupWindow = null, Bt.restartHistory().then((function() {
                                    e.removePaymentFlows()
                                }));
                                if (this.threeDSData.containerId) return Bt.restartHistory().then((function() {
                                    e.removePaymentFlows()
                                }))
                            }
                            return function(e) {
                                var t = e.log,
                                    n = e.remoteWindow,
                                    r = function e() {
                                        try {
                                            if (!n) return;
                                            if (n.closed) return;
                                            if (!(0, o.A)(n.close)) return;
                                            if (!(0, o.A)(n.setTimeout)) return;
                                            n.setTimeout(e, 0), n.close()
                                        } catch (e) {
                                            t.error("Error closing window!", {
                                                error: e
                                            })
                                        }
                                    };
                                r()
                            }({
                                remoteWindow: this.paymentPopupWindow,
                                log: this.log
                            }), this.paymentPopupWindow = null, Promise.resolve()
                        }, u.mustHandleDeviceWakeUp = function() {
                            return !(this.isIframeFlow() || this.isOrderRecapFlow() && (0, x.n)(this.getParameter("providerId")))
                        }, u.isExtraModalFlow = function(e) {
                            var t = e || this.getParameters();
                            return void 0 !== r.getExtraDataModalFlow(t)
                        }, u.isOrderRecapFlow = function() {
                            return Boolean(this.getParameter("orderRecapFlow"))
                        }, u.isUcbRecapFlow = function() {
                            return Boolean(this.getParameter("ucbRecapFlow"))
                        }, u.isIframeFlow = function() {
                            var e = this.getParameters(),
                                t = e.forceIframeFlow,
                                n = e.providerId,
                                r = (0, x.n)(n);
                            if (this.isOrderRecapFlow()) {
                                var i = this.getParameter("orderRecapFlow");
                                return !!r && Boolean(i.storedDetails)
                            }
                            return t || r
                        }, u.removeCcOverlay = function() {
                            this.ccOverlayData.containerId && (this.removeReactView((0, Tt.j)()), this.resetCcOverlayData())
                        }, u.resetCcOverlayData = function() {
                            this.ccOverlayData = {
                                containerId: "",
                                hideIframe: !1,
                                iframe: null,
                                isFinishingPayment: !1,
                                isOneOffSecurityStep: !1,
                                url: ""
                            }
                        }, u.removeThreeDSecureRedirectOverlay = function() {
                            this.threeDSData.containerId && (this.removeReactView((0, Tt.j)()), this.threeDSData = {
                                containerId: "",
                                iframe: null
                            })
                        }, u.handleNavigation = function() {
                            this.removePaymentFlows()
                        }, u.removePaymentFlows = function() {
                            this.removeCcOverlay(), this.removeThreeDSecureRedirectOverlay(), this.remove3DS2Handler(), this.removeThreatmetrixHandler(), this.removeOrderRecap(), this.removeUcbRecap()
                        }, u.remove3DS2Handler = function() {
                            this.threeDS2Handler && (this.threeDS2Handler.stop(), this.threeDS2Handler = null)
                        }, u.removeThreatmetrixHandler = function() {
                            this.threatmetrixHandler && (this.threatmetrixHandler.destroy(), this.threatmetrixHandler = null)
                        }, u.hideIframe = function() {
                            (this.ccOverlayData.containerId || this.isUcbRecapFlow() || this.isOrderRecapFlow()) && (this.ccOverlayData.hideIframe = !0, this.renderCcOverlay()), this.threeDS2Handler && this.threeDS2Handler.hideIframe()
                        }, u.renderOrderRecap = function() {
                            Bt.pauseHistory(), this.listenForPaymentResult();
                            var e = this.getParameter("orderRecapFlow");
                            this.orderRecapContainerId = this.renderReactView((0, le.jsx)(Fe, {
                                paymentOptions: e.paymentOptions,
                                orderRecap: e.orderRecap,
                                mop: e.mop,
                                storedDetails: e.storedDetails,
                                ignoreStoredDetails: e.ignoreStoredDetails,
                                title: e.title,
                                allowChangePackage: e.allowChangePackage,
                                onClientPurchaseReceipt: this.handleReceiptAnyRecapPayment,
                                onClose: this.handleCloseOrderRecap,
                                onChangePackage: e.onChangePackage,
                                onChangePaymentMethod: this.handleChangePaymentMethod,
                                onSubmitPayment: this.handleSubmitAnyRecapPayment
                            }), (0, Tt.j)())
                        }, u.renderUcbRecap = function() {
                            Bt.pauseHistory(), this.listenForPaymentResult();
                            var e = function(e) {
                                var t, n, r = e.productsList,
                                    i = e.providersList,
                                    a = e.paymentOptions,
                                    o = e.title,
                                    s = null == r ? void 0 : r.find((function(e) {
                                        return e.uid === a.uid
                                    })),
                                    c = null == s || null == (t = s.providers) ? void 0 : t.map((function(e) {
                                        return e.provider_id
                                    })),
                                    u = null == i ? void 0 : i.filter((function(e) {
                                        return null == c ? void 0 : c.includes(e.provider_id)
                                    })),
                                    l = null == i ? void 0 : i.find((function(e) {
                                        return e.provider === a.provider
                                    })),
                                    d = null == u ? void 0 : u.find((function(e) {
                                        return 100001 === e.provider
                                    })),
                                    p = null == u ? void 0 : u.filter((function(e) {
                                        return 100001 !== e.provider
                                    })).sort(Ut.e);
                                return {
                                    title: o,
                                    defaultUcbRecap: null == s || null == (n = s.providers) || null == (n = n[0]) ? void 0 : n.ucb_recap,
                                    paymentOptions: a,
                                    selectedProduct: s,
                                    selectedProvider: l,
                                    storedProvider: d,
                                    nonStoredProviders: p
                                }
                            }(this.getParameter("ucbRecapFlow"));
                            s.A.document.body.classList.add("fullscreen"), this.ucbRecapContainerId = this.renderReactView((0, le.jsx)(At, {
                                title: e.title,
                                defaultUcbRecap: e.defaultUcbRecap,
                                paymentOptions: e.paymentOptions,
                                selectedProduct: e.selectedProduct,
                                selectedProvider: e.selectedProvider,
                                storedProvider: e.storedProvider,
                                nonStoredProviders: e.nonStoredProviders,
                                onClose: this.handleCloseUcbRecap,
                                onClientPurchaseReceipt: this.handleReceiptAnyRecapPayment,
                                onSubmitPayment: this.handleSubmitAnyRecapPayment,
                                transactionController: this
                            }), (0, Tt.j)())
                        }, u.renderExtraDataModal = function(e) {
                            if (r.getExtraDataModalFlow(e) === Y.qR.PROVIDER_PLAID) this.renderExtraDataModalProviderPlaid(e)
                        }, u.renderExtraDataModalProviderPlaid = function(e) {
                            this.extraDataModalContainerId = this.renderReactView((0, le.jsx)(Pt.A, {
                                paymentOptions: e,
                                onReturn: this.removeExtraDataModal
                            }), (0, Tt.j)())
                        }, u.removeOrderRecap = function() {
                            this.orderRecapContainerId && (this.removeReactView((0, Tt.j)()), this.orderRecapContainerId = "")
                        }, u.removeUcbRecap = function() {
                            if (this.ucbRecapContainerId) {
                                this.removeReactView((0, Tt.j)()), this.ucbRecapContainerId = "";
                                var e = this.getParameter("ucbRecapFlow");
                                null == e || null == e.onClose || e.onClose(), s.A.document.body.classList.remove("fullscreen")
                            }
                        }, r
                    }(d.A);

                function Qt() {
                    return !p.A.isWindowsDevice && !p.A.isHuaweiQuickApp()
                }

                function Kt(e) {
                    return e && !Yt.includes(e)
                }

                function Xt(e) {
                    (0, $e.sx)(51, {
                        event_name: "redirect_payment",
                        p1: e
                    })
                }

                function zt(e) {
                    var t, n = (null == (t = e.purchaseTransaction) ? void 0 : t.transaction_id) || "",
                        r = B.K.remove(n),
                        i = {
                            payment_success: !0,
                            transaction_identifier: n,
                            provider_id: Number(e.providerId),
                            provider: e.provider,
                            product_uid: e.uid
                        };
                    return null != r && r.billingEmail && (i.billing_email = r.billingEmail), e.receiptData && (i.receipt_data = e.receiptData), v.A.getInstance().sendReceipt(i)
                }

                function Zt(e, t, n) {
                    var r = xt({
                        payment_success: !1,
                        transaction_identifier: t.transaction_id,
                        provider_id: e.providerId,
                        provider: e.provider,
                        product_uid: e.uid
                    }, n);
                    v.A.getInstance().sendReceipt(r).then((function(e) {
                        var t = null == e ? void 0 : e.notification,
                            n = null == t ? void 0 : t.message;
                        n && w.A.showNotification({
                            text: n,
                            type: w.A.TYPES.INFO
                        })
                    })).catch(a.A)
                }

                function Jt(e) {
                    var t = e.form_error,
                        n = null == t ? void 0 : t.failure,
                        r = null == n ? void 0 : n.error_message,
                        i = e.notification,
                        a = null == i ? void 0 : i.message;
                    w.A.showNotification({
                        text: r || a,
                        type: w.A.TYPES.ERROR
                    })
                }
                qt.EVENTS = It, qt.ACTIONS = Ct;
                var $t = /^https?:/;

                function en(e) {
                    return e ? $t.test(e) ? e : ("/" !== e.charAt(0) && (e = "/" + e), s.A.location.protocol + "//" + s.A.location.hostname + e) : e
                }
                var tn = qt
            },
            26935: function(e, t, n) {
                n(2892), n(69085), n(45700), n(89572), n(52675), n(89463), n(26099), n(84185), n(79432), n(2008), n(83851), n(51629), n(23500), n(81278), n(67945);
                var r = n(42302),
                    i = n(74389),
                    a = n(58385),
                    o = n(18084),
                    s = n(13315),
                    c = n(41025),
                    u = n(59179),
                    l = n(62608),
                    d = n(20387),
                    p = n(76854),
                    f = n(49683),
                    h = n(10031),
                    g = n(30922),
                    v = n(51438),
                    m = n(26019);

                function y(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function A(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? y(Object(n), !0).forEach((function(t) {
                            P(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : y(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function P(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function E(e) {
                    var t = e.purchaseParameters,
                        n = e.transactionResult,
                        r = t.chatMessage,
                        o = t.cost,
                        s = t.onComplete,
                        u = t.onError,
                        l = t.onSuccess,
                        p = t.productType,
                        f = n.error,
                        y = n.clientPurchaseReceipt,
                        P = n.featureProductList,
                        E = n.purchaseTransaction,
                        _ = n.purchaseTransactionFailed,
                        b = t.hotPanelData,
                        T = void 0 === b ? {
                            activationPlace: 1
                        } : b,
                        S = 1 !== T.eventVersion,
                        I = void 0;
                    if (!p) return u("Trying to make a one-click payment without productType"), void s(!1);
                    if (S && (I = (0, v.Im)(t.hotPanelPaymentFlowId || null, p, T.activationPlace, {
                            activation_place_option: T.activationPlaceOption,
                            banner_id: T.bannerId,
                            credits_cost: Number(o),
                            is_one_click_payment: Boolean(y),
                            object_id: T.objectId
                        })), f)
                        if (_) {
                            if (S && (0, v.Np)(I, v.QO.FAILURE), (0, h.Q)(_)) return a.A.navigate(i.x.ADD_PHOTOS, {
                                backHistoryEntry: a.A.getHistoryEntryId(),
                                destination: a.A.getUrl()
                            }), void s(!1);
                            var C = _.notification,
                                O = null == C ? void 0 : C.message;
                            u(O), s(!1)
                        } else {
                            if (E) {
                                var R = new m.A;
                                return R.on(m.A.EVENTS.SUCCESS, (function() {
                                    l(), s(!0), R.stop()
                                })).on(m.A.EVENTS.FAILED, (function() {
                                    u(), s(!1), R.stop()
                                })).on(m.A.ACTIONS.BACK, (function() {
                                    u(), s(!1, !0), R.stop()
                                })), R.start(), void R.updateParameters(function(e, t) {
                                    var n = t.uid,
                                        r = A(A({
                                            purchaseTransaction: t,
                                            handleOnStartTransaction: !0
                                        }, e), {}, {
                                            provider: t.provider,
                                            providerName: "Credit Card",
                                            forceIframeFlow: !0
                                        });
                                    n && (r.uid = n);
                                    return r
                                }(t, E))
                            }
                            var w, D = null == r || null == (w = r.gift) ? void 0 : w.getGift();
                            c.A.navigateToPayment({
                                back: t.back,
                                chatMessage: r,
                                cost: o,
                                giftProductId: null == D ? void 0 : D.getProductId(),
                                hotPanelData: T,
                                newNavigation: t.newNavigation,
                                productType: p,
                                promoBlockType: t.promoBlockType,
                                stickerPackId: t.stickerPackId,
                                transactionResult: P,
                                userId: t.userId,
                                callback: function(e) {
                                    var t = e.cancelled,
                                        n = e.purchaseReceipt;
                                    e.success && n ? g.A.subscribeToNotificationShow(n, (function(e) {
                                        var t = e.receipt;
                                        l(t), d.A.getInstance().invalidateCreditFolders(), s(!0)
                                    })) : (!0 !== t && u(), s(!1, t))
                                }
                            }, {
                                replace: t.popState,
                                existingPaymentFlowId: I,
                                paymentTransitionInFlow: t.paymentTransitionInFlow
                            })
                        }
                    else y ? (g.A.processClientPurchaseReceipt(y), g.A.subscribeToNotificationShow(y, (function() {
                        S && (0, v.Np)(I, v.QO.SUCCESS, T.eventVersion), l(y), d.A.getInstance().invalidateCreditFolders(), s(!0, !1, {
                            isOneClickPayment: !0
                        })
                    }))) : (S && (0, v.Np)(I, v.QO.FAILURE), u(), s(!1))
                }
                var _ = function() {
                    function e() {}
                    return e.purchase = function(t) {
                        null != t && t.productType ? l.A.getInstance().getCredits().then((function(e) {
                            var n, r = t.ignoreCost || p.A.getInstance().hasConsumableForProductType(t.productType),
                                i = t.cost,
                                a = !r && "number" == typeof i,
                                o = "number" == typeof i && e >= i,
                                s = u.A.getInstance().canUseInstantPaywall(t.productType),
                                c = Boolean(null == (n = t.purchaseTransactionSetup) ? void 0 : n.crossSellOrderId);
                            if (!s || !a || o || c) {
                                var l = function(e) {
                                    var t, n = Object.assign({
                                        chatMessage: e.chatMessage,
                                        featureType: e.featureType,
                                        productType: e.productType,
                                        userId: e.userId
                                    }, e.purchaseTransactionSetup);
                                    null != (t = e.hotPanelData) && t.activationPlace && (n.hpActivationPlaceId = e.hotPanelData.activationPlace);
                                    return n
                                }(t);
                                f.A.getInstance().tryCreditsPurchase(l, (function(e) {
                                    E({
                                        purchaseParameters: b(t),
                                        transactionResult: e
                                    })
                                }))
                            } else E({
                                purchaseParameters: b(t),
                                transactionResult: {
                                    error: new Error("Not able to purchase credits in OneClickPurchase")
                                }
                            })
                        })) : e.log.error("Trying to pay without productType")
                    }, e
                }();

                function b(e) {
                    var t = e.hotPanelData;
                    return Object.assign({
                        back: s.A.getInstance().getBackRoute() || e.back,
                        chatMessage: e.chatMessage,
                        cost: e.cost || t.cost,
                        hotPanelData: e.hotPanelData,
                        hotPanelPaymentFlowId: t.existingPaymentFlowId,
                        newNavigation: e.newNavigation,
                        paymentTransitionInFlow: Boolean(e.paymentTransitionInFlow),
                        popState: e.popState,
                        productType: e.productType,
                        promoBlockType: e.promoBlockType,
                        userId: e.userId,
                        onComplete: e.complete || r.A,
                        onError: e.error || r.A,
                        onSuccess: e.success || r.A
                    }, e.purchaseTransactionSetup)
                }
                _.log = o.A.getLogger("oneClickPaymentFeature"), t.A = _
            },
            28244: function(e, t, n) {
                n(79432), n(25276), n(45700), n(89572), n(52675), n(89463), n(26099), n(2892), n(84185), n(2008), n(83851), n(51629), n(23500), n(81278), n(67945);
                var r = n(58385),
                    i = n(12632),
                    a = n(18084),
                    o = n(99417),
                    s = n(33926),
                    c = n(74848),
                    u = ["routeName", "routeParams", "href", "onClick", "dataQA", "children", "target", "preventNavigation"];

                function l(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function d(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? l(Object(n), !0).forEach((function(t) {
                            p(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : l(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function p(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var f = a.A.getLogger("RoutingAnchor");
                t.A = function(e) {
                    var t, n = e.routeName,
                        a = e.routeParams,
                        l = e.href,
                        p = e.onClick,
                        h = e.dataQA,
                        g = e.children,
                        v = e.target,
                        m = e.preventNavigation,
                        y = function(e, t) {
                            if (null == e) return {};
                            var n, r, i = {},
                                a = Object.keys(e);
                            for (r = 0; r < a.length; r++) n = a[r], t.indexOf(n) >= 0 || (i[n] = e[n]);
                            return i
                        }(e, u);
                    n && (t = r.A.getAccessibleUrl({
                        routeName: n,
                        parameters: a
                    })), t || l || p || f.error("RoutingAnchor is meaningless because neither accessible URL nor onClick exist", {
                        children: g,
                        routeName: n
                    });
                    var A = t || l ? "a" : "button",
                        P = d({
                            "data-qa": "routing-anchor"
                        }, h);
                    return (0, c.jsxs)(A, d(d(d({
                        href: t || l,
                        onClick: function(e) {
                            var t = (0, i.s)(e);
                            null == p || p(), !m && t && (n ? r.A.navigate(n, a) : l && o.A.open(l, v || "_self"))
                        },
                        type: "button" === A ? "button" : void 0,
                        target: "a" === A ? v : void 0
                    }, P), y), {}, {
                        children: [g, "a" === A && "_blank" === v ? (0, c.jsx)(s.A, {}) : null]
                    }))
                }
            },
            30245: function(e, t, n) {
                n.d(t, {
                    J: function() {
                        return r
                    }
                });
                n(50113), n(26099);

                function r(e, t) {
                    return e.find((function(e) {
                        return e.uid === t
                    }))
                }
            },
            30711: function(e, t, n) {
                var r;
                n.d(t, {
                        f: function() {
                            return r
                        }
                    }),
                    function(e) {
                        e.EXTRA = "EXTRA", e.SPP = "SPP", e.PREMIUM_PLUS = "PREMIUM_PLUS"
                    }(r || (r = {}))
            },
            30922: function(e, t, n) {
                n(51629), n(26099), n(23500);
                var r = n(99417),
                    i = n(58385),
                    a = n(74389),
                    o = n(93529),
                    s = {},
                    c = function() {
                        function e() {
                            this.clientNotification = void 0, this.clientPurchaseReceipt = void 0, this.notificationShown = void 0, this.notificationShownCallbacks = void 0, this.waitTime = void 0, this.waitTimeIsOver = void 0, this.notificationShownCallbacks = [], this.notificationShown = !1, this.waitTimeIsOver = !1
                        }
                        var t = e.prototype;
                        return t.addNotificationShownCallback = function(e) {
                            this.notificationShown ? e({
                                receipt: this.clientPurchaseReceipt
                            }) : this.notificationShownCallbacks.push(e)
                        }, t.setClientPurchaseReceipt = function(e) {
                            var t = this;
                            this.clientPurchaseReceipt = e, this.waitTime = this.clientPurchaseReceipt.payment_timeout, this.checkState(), this.waitTime && r.A.setTimeout((function() {
                                t.waitTimeIsOver = !0, t.checkState()
                            }), 1e3 * this.waitTime)
                        }, t.setClientNotification = function(e) {
                            this.clientNotification = e, this.checkState()
                        }, t.checkState = function() {
                            var e = this;
                            if (!this.notificationShown && this.clientPurchaseReceipt) return this.clientPurchaseReceipt.cross_sell ? (this.setNotificationShown(), void r.A.setTimeout((function() {
                                return e.navigateToCrossSell()
                            }), 400)) : void(!this.clientNotification && this.clientPurchaseReceipt.purchase_success && this.waitTime && !this.waitTimeIsOver || (this.showNotification(), this.setNotificationShown()))
                        }, t.setNotificationShown = function() {
                            var e = this;
                            this.notificationShown = !0, this.notificationShownCallbacks.forEach((function(t) {
                                return t({
                                    receipt: e.clientPurchaseReceipt
                                })
                            }))
                        }, t.navigateToCrossSell = function() {
                            i.A.navigate(a.x.CROSS_SELL, {
                                clientPurchaseReceipt: this.clientPurchaseReceipt
                            })
                        }, t.showNotification = function() {
                            var e, t, n = this.clientNotification || (null == (e = this.clientPurchaseReceipt) ? void 0 : e.notification);
                            if (n) {
                                var r = n.message,
                                    i = n.title;
                                i && i !== r && (r = i + " " + r);
                                var a = {
                                        type: o.A.TYPES.INFO,
                                        text: r
                                    },
                                    s = n.promo_block;
                                18 === (null == s ? void 0 : s.promo_block_position) && (a.promoBlock = s), null != (t = this.clientPurchaseReceipt) && t.productType && (a.type = o.A.TYPES.PAYMENT, a.productType = this.clientPurchaseReceipt.productType), o.A.showNotification(a)
                            }
                        }, e
                    }();

                function u(e) {
                    return s[e] || (s[e] = new c), s[e]
                }
                t.A = {
                    processClientNotification: function(e) {
                        e.transaction_identifier && u(e.transaction_identifier).setClientNotification(e)
                    },
                    processClientPurchaseReceipt: function(e) {
                        e && u(e.transaction_identifier).setClientPurchaseReceipt(e)
                    },
                    subscribeToNotificationShow: function(e, t) {
                        var n = u(e.transaction_identifier);
                        t && n.addNotificationShownCallback(t)
                    },
                    reset: function() {
                        for (var e in s) delete s[e]
                    }
                }
            },
            32411: function(e, t, n) {
                n(26099), n(3362), n(10287);
                var r = n(6696),
                    i = n(32308),
                    a = n(41298);

                function o(e, t) {
                    return o = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, o(e, t)
                }
                var s = function(e) {
                    var t, n;

                    function r() {
                        return e.call(this, {
                            get: {
                                message: 493,
                                response: 494
                            }
                        }, {
                            name: "ProductExplanationModel",
                            useCache: !1
                        }) || this
                    }
                    return n = e, (t = r).prototype = Object.create(n.prototype), t.prototype.constructor = t, o(t, n), r.getInstance = function() {
                        return r.instance || (r.instance = new r), r.instance
                    }, r.prototype.getProductExplanation = function(t) {
                        var n = t.productType,
                            r = t.userId,
                            o = t.explanationType,
                            s = t.clientSource,
                            c = t.promoBlockType;
                        if (!(0, i.Rg)(n)) return (0, a.A)(Promise.reject(new Error("Invalid moumi.bma.PaymentProductType provided: " + n)));
                        var u = {
                            product_type: n
                        };
                        return o && (u.type = o), r && (u.user_id = r), s && (u.context = s), c && (u.promo_block_type = c), e.prototype.get.call(this, u)
                    }, r
                }(r.A);
                s.instance = null, t.A = s
            },
            33926: function(e, t, n) {
                n.d(t, {
                    P: function() {
                        return o
                    }
                });
                var r = n(84362),
                    i = n(40075),
                    a = n(74848);

                function o(e) {
                    return e + '<span class="csms-a11y-visually-hidden"> ' + i.Ay.get(618) + "</span>"
                }
                t.A = function(e) {
                    var t = e.children,
                        n = i.Ay.get(618);
                    return (0, a.jsxs)(a.Fragment, {
                        children: [t, (0, a.jsx)(r.A, {
                            children: n
                        })]
                    })
                }
            },
            34256: function(e, t, n) {
                n.d(t, {
                    d: function() {
                        return a
                    }
                });
                var r = n(96540),
                    i = n(7802),
                    a = function() {
                        var e = (0, r.useState)(!1),
                            t = e[0],
                            n = e[1];
                        return (0, r.useEffect)((function() {
                            function e(e) {
                                n(e)
                            }
                            return i.q.changeEvent.subscribe(e),
                                function() {
                                    i.q.changeEvent.unsubscribe(e)
                                }
                        }), []), t
                    }
            },
            39403: function(e, t, n) {
                n.d(t, {
                    F: function() {
                        return c
                    },
                    l: function() {
                        return s
                    }
                });
                n(2892), n(42762);
                var r = n(63334),
                    i = n(3208),
                    a = n(57998),
                    o = n(32308);

                function s(e, t) {
                    var n = c(t),
                        o = function(e, t) {
                            var n, o = {
                                auto_top_up: Boolean(t.autoTopup),
                                result_url: (0, r.B)(),
                                browser_info: a.T.getInfo()
                            };
                            t.plaidInstitutionId && (o.plaid_institution_id = t.plaidInstitutionId);
                            t.uid && (o.uid = t.uid, o.initiated_from_instant_paywall = Boolean(t.isInstantPayWall));
                            e && (o.product_type = Number(e));
                            t.promoBlockVariantId && (o.promo_block_variant_id = String(t.promoBlockVariantId));
                            t.provider && (o.provider = t.provider);
                            t.promoBlockType && (o.promo_block_type = t.promoBlockType);
                            t.providerId && (o.provider_id = t.providerId);
                            t.sharingProviderType && (o.sharing_provider_type = t.sharingProviderType);
                            12 === t.productType && (o.chat_initial_screen_type = 19);
                            t.context ? o.context = t.context : null != (n = t.chatMessage) && n.context && (o.context = t.chatMessage.context);
                            t.priceToken && (o.price_token = t.priceToken);
                            t.threatmetrixSessionId && (o.threatmetrix_session_id = t.threatmetrixSessionId);
                            t.threatmetrixProfilingStatus && (o.threatmetrix_profiling_status = t.threatmetrixProfilingStatus);
                            t.billingEmail && (o.billing_email = t.billingEmail);
                            t.ignoreStoredDetails && (o.ignore_stored_details = t.ignoreStoredDetails);
                            t.hpActivationPlaceId && (o.hp_activation_place_id = t.hpActivationPlaceId);
                            t.googlePayToken && (o.google_pay_token = t.googlePayToken);
                            o.unique_flow_id = i.A.get(), t.deviceProfilingId && (o.device_profiling_id = t.deviceProfilingId);
                            return o
                        }(e, t);
                    return o.purchase_params = n, o
                }

                function c(e) {
                    var t = {
                        msisdn: e.msisdn
                    };
                    if (e.userId && (t.user_id = String(e.userId)), e.chatMessage) {
                        var n = function(e, t) {
                                var n = {},
                                    r = e.messageType;
                                if ((0, o.Rg)(r) || (r = 1), n.type = r, t && (n.to_user_id = String(t)), e.gift) {
                                    var i = e.gift;
                                    n.gift_is_private = Boolean(i.getIsPrivate()), n.gift_product_id = Number(i.getGift().getProductId()), n.message_text = String(i.getText())
                                }
                                if (e.message && (n.message_text = String(e.message)), e.id && (n.client_message_id = String(e.id)), 23 === e.messageType && (n.sticker_id = String(e.image.id)), e.gif) {
                                    var a = {
                                        type: e.gif.provider
                                    };
                                    e.gif.image && (a.aspect_ratio = e.gif.image.ratio), n.gif_info = a
                                }
                                return n
                            }(e.chatMessage, e.userId),
                            r = function(e) {
                                var t = e.gift_product_id;
                                if (t) return {
                                    gift_product_id: t,
                                    text: e.message_text || "",
                                    is_private: e.gift_is_private || !1
                                }
                            }(n);
                        r && (t.gift_params = r), t.chat_message_params = n
                    }
                    if (e.stickerPackId && (t.sticker_pack_id = String(e.stickerPackId)), e.crossSellOrderId && (t.cross_sell_order_id = String(e.crossSellOrderId)), e.photoId && (t.photo_id = e.photoId), e.productToActivate && (t.product_to_activate = e.productToActivate), e.billingInfo) {
                        var i = 195 === e.provider,
                            a = e.billingInfo,
                            s = {},
                            c = {},
                            u = {
                                id: Number(a.city.id),
                                name: a.city.name
                            };
                        i && (u.name = a.city.name.split(",")[0].trim(), c = {
                            value: String(a.document),
                            type: 1
                        }), a.region && (s = {
                            id: Number(a.region.id),
                            name: a.region.name,
                            abbreviation: a.region.abbreviation
                        }), t.billing_info = {
                            full_name: a.fullName,
                            tax_id: String(a.taxId),
                            postcode: a.postcode,
                            street_address: a.streetAddress,
                            phone: a.phone,
                            email: a.email,
                            address_number: a.addressNumber,
                            document: c,
                            city: u,
                            region: s
                        }
                    }
                    return t
                }
            },
            41025: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return y
                    }
                });
                n(27495), n(45700), n(89572), n(52675), n(89463), n(26099), n(2892), n(84185), n(79432), n(2008), n(83851), n(51629), n(23500), n(81278), n(67945), n(99417);
                var r, i, a = n(74389),
                    o = n(58385),
                    s = n(18084),
                    c = n(3208),
                    u = n(30711),
                    l = n(93529),
                    d = n(79860);

                function p(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function f(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? p(Object(n), !0).forEach((function(t) {
                            h(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : p(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function h(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var g = s.A.getLogger("RouteHelper"),
                    v = ((r = {})[u.f.EXTRA] = 818, r[u.f.SPP] = 8, r[u.f.PREMIUM_PLUS] = 557, r),
                    m = ((i = {})[u.f.EXTRA] = 66, i[u.f.SPP] = 1, i[u.f.PREMIUM_PLUS] = 47, i),
                    y = function() {
                        function e() {}
                        return e.navigateToPayment = function(e, t) {
                            if (e.productType) {
                                var n = t || {},
                                    r = n.existingPaymentFlowId,
                                    i = n.paymentTransitionInFlow,
                                    s = void 0 !== i && i,
                                    u = n.replace,
                                    l = void 0 !== u && u,
                                    d = f(f({}, e), {}, {
                                        paymentFlowId: r || c.A.get()
                                    }),
                                    p = s ? a.x.PAY : a.x.PAY_OVERLAY;
                                0, o.A.navigate(p, l, d)
                            } else g.error("Trying to navigate to payment without productType")
                        }, e.navigateToTierPaywall = function(t, n) {
                            if (n) l.A.showNotification({
                                type: l.A.TYPES.ERROR,
                                text: n.error_message
                            });
                            else {
                                var r = v[t],
                                    i = m[t];
                                (0, d.sx)(139, {
                                    banner_id: r,
                                    position_id: 29,
                                    context: 8,
                                    call_to_action_type: 1
                                }), e.navigateToPayment({
                                    hotPanelData: {
                                        activationPlace: 364
                                    },
                                    productType: i,
                                    back: o.A.getUrl()
                                })
                            }
                        }, e
                    }()
            },
            47632: function(e, t, n) {
                n(11745), n(38309), n(26099), n(3362), n(74423);
                var r, i, a = n(99417),
                    o = n(18084),
                    s = n(79880),
                    c = {
                        SYMBOL: "symbol",
                        URL: "url"
                    },
                    u = o.A.getLogger("ImageHelper"),
                    l = ((r = {})[56] = "badge-feature-attention-boost", r[96] = "badge-feature-crush", r[59] = "badge-feature-chat-quota", r[58] = "badge-feature-chat-quota", r[5] = "badge-feature-chat-with-tired", r[4] = "badge-feature-chat-with-newbies", r[8] = "badge-feature-premium", r[10] = "badge-feature-extra-shows", r[11] = "badge-feature-extra-shows", r[48] = "badge-feature-extra-shows", r[6] = "badge-feature-favourites", r[7] = "badge-feature-liked-you", r[38] = "badge-feature-liked-you", r[1] = "badge-feature-riseup", r[24] = "badge-gift", r[3] = "badge-feature-special-delivery", r[16] = "badge-feature-special-delivery", r[40] = "badge-feature-special-delivery", r[12] = "badge-add-photos", r[37] = "badge-feature-invisible-mode", r[43] = "badge-feature-undo", r[35] = "badge-feature-undo", r[57] = "badge-feature-bundle-sale", r[165] = "badge-chat", r[160] = "badge-chat", r[41] = null, r[388] = "badge-feature-read-receipt", r[119] = "badge-no-advert", r),
                    d = ((i = {})[3] = f(6), i[4] = f(7), i[5] = f(1), i[7] = f(10), i[8] = f(8), i[9] = "badge-coin", i[18] = f(4), i[22] = f(43), i[25] = "badge-provider-instagram", i[26] = f(56), i[27] = f(57), i[28] = f(48), i[29] = f(59), i[54] = f(160), i[30] = f(58), i[32] = "badge-provider-facebook", i[33] = "badge-provider-vkontakte", i[34] = "badge-plus", i[37] = f(7), i[40] = f(96), i[19] = "badge-feature-special-delivery", i[1] = null, i),
                    p = {
                        getImageUrlForSize: s.A,
                        getPlaceholderForGender: function(e) {
                            var t;
                            switch (e) {
                                case "male":
                                case 1:
                                    t = "avatar-placeholder-male";
                                    break;
                                case "female":
                                case 2:
                                    t = "avatar-placeholder-female";
                                    break;
                                default:
                                    t = "avatar-placeholder-unknown"
                            }
                            return {
                                type: c.SYMBOL,
                                value: t
                            }
                        },
                        getBadgeName: function(e) {
                            var t = d[e] || null;
                            return void 0 === t && u.error("Badge name not supported for NotificationBadgeType " + e), t
                        },
                        getBadgeTypeFromFeature: function(e) {
                            switch (e) {
                                case 127:
                                    return f(56);
                                case 18:
                                    return "badge-feature-chat-quota";
                                case 32:
                                    return f(10);
                                case 15:
                                    return "badge-feature-extra-votes";
                                case 50:
                                case 8:
                                    return f(6);
                                case 42:
                                    return f(7);
                                case 28:
                                    return f(1)
                            }
                            u.warn("FeatureType to an icon not mapped: " + e + ".")
                        },
                        getOrientation: function(e) {
                            var t = a.A.FileReader,
                                n = a.A.DataView;
                            return null != t && t.prototype.readAsArrayBuffer && n ? new Promise((function(r) {
                                var i = a.A.document.createElement("img");
                                i.onload = function() {
                                    if (1 === i.width && 2 === i.height) return r(0);
                                    var a = new t;
                                    a.onload = function(e) {
                                        var t, i = new n(null == (t = e.target) ? void 0 : t.result);
                                        if (65496 !== i.getUint16(0, !1)) return r(-2);
                                        for (var a = i.byteLength, o = 2; o < a;) {
                                            var s = i.getUint16(o, !1);
                                            if (o += 2, 65505 === s) {
                                                if (1165519206 !== i.getUint32(o += 2, !1)) return r(-1);
                                                var c = 18761 === i.getUint16(o += 6, !1);
                                                o += i.getUint32(o + 4, c);
                                                var u = i.getUint16(o, c);
                                                o += 2;
                                                for (var l = 0; l < u; l++)
                                                    if (274 === i.getUint16(o + 12 * l, c)) return r(i.getUint16(o + 12 * l + 8, c))
                                            } else {
                                                if (65280 & ~s) break;
                                                o += i.getUint16(o, !1)
                                            }
                                        }
                                        return r(-1)
                                    }, a.readAsArrayBuffer(function(e) {
                                        var t = 65536;
                                        return e.slice ? e.slice(0, t) : e.webkitSlice ? e.webkitSlice(0, t) : e
                                    }(e))
                                }, i.src = "data:image/jpeg;base64,/9j/4QAiRXhpZgAATU0AKgAAAAgAAQESAAMAAAABAAYAAAAAAAD/2wCEAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/AABEIAAEAAgMBEQACEQEDEQH/xABKAAEAAAAAAAAAAAAAAAAAAAALEAEAAAAAAAAAAAAAAAAAAAAAAQEAAAAAAAAAAAAAAAAAAAAAEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwA/8H//2Q=="
                            })) : Promise.resolve(-1)
                        },
                        getOrientationFromExifValue: function(e) {
                            switch (e) {
                                case 3:
                                case 4:
                                    return 180;
                                case 5:
                                case 6:
                                    return 90;
                                case 7:
                                case 8:
                                    return -90;
                                default:
                                    return 0
                            }
                        },
                        rotateBase64: function(e, t, n) {
                            return new Promise((function(r, i) {
                                var o = a.A.document.createElement("canvas"),
                                    s = o.getContext("2d"),
                                    c = new a.A.Image,
                                    u = [5, 6, 7, 8, 90].includes(Math.abs(t));
                                c.src = e, c.onerror = i, c.onload = function() {
                                    var e = u ? c.width : c.height,
                                        i = u ? c.height : c.width,
                                        l = u ? a.A.innerHeight : a.A.innerWidth,
                                        d = n ? l / i : 1,
                                        p = c.height * d,
                                        f = c.width * d;
                                    if (o.height = e * d, o.width = i * d, s) {
                                        switch (t) {
                                            case 5:
                                            case 6:
                                            case 90:
                                                s.translate(p, 0), s.rotate(Math.PI / 2);
                                                break;
                                            case 3:
                                            case 4:
                                            case 180:
                                                s.translate(f, p), s.rotate(Math.PI);
                                                break;
                                            case 7:
                                            case 8:
                                            case -90:
                                                s.translate(0, f), s.rotate(-Math.PI / 2)
                                        }
                                        s.drawImage(c, 0, 0, f, p), r(o.toDataURL("image/jpeg"))
                                    }
                                }
                            }))
                        },
                        getBadgeTypeFromPromoBlock: f,
                        IMAGE_TYPE: c
                    };

                function f(e) {
                    var t = l[e] || null;
                    return t || u.warn("Badge type not supported for PromoBlockType " + e), t
                }
                t.A = p
            },
            49683: function(e, t, n) {
                n.d(t, {
                    i: function() {
                        return I
                    }
                });
                n(26099), n(3362), n(58940), n(10287), n(38781), n(27495), n(71761), n(25276);
                var r = n(99562),
                    i = n(6696),
                    a = n(32308),
                    o = n(31709),
                    s = n(47344),
                    c = n(23149),
                    u = n(93529),
                    l = n(59179),
                    d = n(32411),
                    p = n(39403),
                    f = n(63334),
                    h = n(10031),
                    g = n(30922),
                    v = n(13315),
                    m = n(67556),
                    y = n(75248),
                    A = n(25093),
                    P = n(41298);

                function E(e, t) {
                    return E = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, E(e, t)
                }
                var _ = {},
                    b = function(e) {
                        var t, n;

                        function i() {
                            var t;
                            return (t = e.call(this, {}, {
                                name: "PaymentsModel",
                                useCache: !1
                            }) || this).fetchProductExplanation = function(e, t, n, r) {
                                return d.A.getInstance().getProductExplanation({
                                    productType: e,
                                    userId: t,
                                    explanationType: n,
                                    clientSource: r
                                })
                            }, t
                        }
                        n = e, (t = i).prototype = Object.create(n.prototype), t.prototype.constructor = t, E(t, n);
                        var h = i.prototype;
                        return h.init = function() {
                            y.A.getInstance().on(y.A.Type.NOTIFICATION, T, this)
                        }, h.getPaymentReceipt = function(e) {
                            if ("string" != typeof e._id || "string" != typeof e._pid) return (0, P.A)(Promise.reject(new Error("Missing _id or _pid when trying to get receipt")));
                            var t = e._id,
                                n = function(e) {
                                    return !e.success || "true" === e.success.toString()
                                }(e),
                                r = {
                                    transaction_identifier: t,
                                    payment_success: n
                                },
                                i = parseInt(e._p, 10);
                            (0, a.Rg)(i) && (r.provider = i);
                            var o = parseInt(e._pid, 10);
                            isNaN(o) || (r.provider_id = o), "string" == typeof e.uid && (r.product_uid = e.uid), e.cancellation_reason && (0, a.Rg)(e.cancellation_reason) && (r.cancellation_reason = e.cancellation_reason), "cancellation_reason" in r || (r.cancellation_reason = "error_type" in e ? 2 : 0);
                            var s = m.K.remove(t);
                            if (null != s && s.billingEmail && (r.billing_email = s.billingEmail), 113 === i || 117 === i || 180 === i) n && (e._receipt_data && (r.receipt_data = e._receipt_data), e._receipt_signature && (r.receipt_signature = e._receipt_signature));
                            else {
                                var u = function(e) {
                                    (0, c.A)(e) || (e = {});
                                    return function(e) {
                                        var t = e.url.match(/\?/) ? e.url : e.url + "/?";
                                        for (var n in e.params) {
                                            t += n + "=" + (e.nonEncodedKeys && e.nonEncodedKeys.indexOf(n) > -1 ? e.params[n] : encodeURIComponent(e.params[n])) + "&"
                                        }
                                        return t.substring(0, t.length - 1)
                                    }({
                                        url: (0, f.B)(),
                                        params: e
                                    })
                                }(e);
                                u && (r.receipt_data = u)
                            }
                            return this.sendReceipt(r)
                        }, h.sendReceipt = function(e) {
                            return (0, r.Y)({
                                requestType: 154,
                                responseType: 173,
                                message: e
                            })
                        }, h.startTransaction = function(e, t) {
                            e.isInstantPayWall = l.A.getInstance().canUseInstantPaywall(e.productType);
                            var n = (0, p.l)(e.productType, e);
                            this.sendPurchaseTransaction(n, e, t)
                        }, h.startTransactionAsPromise = function(e) {
                            var t = this;
                            return (0, P.A)(new Promise((function(n, r) {
                                t.startTransaction(e, (function(e) {
                                    var t = e.error;
                                    t ? r(t) : n(e)
                                }))
                            })))
                        }, h.sendPurchaseTransaction = function(e, t, n) {
                            var r = this,
                                a = (0, s.A)(n),
                                c = {};
                            new o.Ay(166, e).onResponse(167, (function(e) {
                                r.trigger(i.EVENTS.SUCCESS, null, e, t), c.purchaseTransaction = e, c.data = t
                            })).onResponse(168, (function(n) {
                                r.trigger(i.EVENTS.FAILURE, null, n, t), n ? S(n.transaction_id, v.A.RESULTS.FAILURE) : r.log.error("Missing purchaseTransactionFailed info from failed transaction.", {
                                    data: t,
                                    purchaseTransactionFailed: n,
                                    purchaseTransactionSetup: e
                                }), c.purchaseTransactionFailed = n
                            })).onResponse(173, (function(e) {
                                r.trigger(i.EVENTS.RECEIPT, null, e, t), e && S(e.transaction_identifier, v.A.RESULTS.PENDING), c.clientPurchaseReceipt = e
                            })).onResponse(153, (function(e) {
                                c.featureProductList = e
                            })).onResponse(1, (function(e) {
                                c.error = e
                            })).onError((function(n) {
                                n && n.type !== o.a5.HANDLER_UNSATISFIED && ((0, A.A)(n) && r.log.error("Error sending a PurchaseTransaction.", {
                                    data: t,
                                    error: n,
                                    purchaseTransactionSetup: e
                                }), c.error || (c.error = n))
                            })).onSpecialEvent(o.SE.REQ_FINISHED, (function() {
                                a(c)
                            })).setIsSynchronous(Boolean(t.useSync)).request()
                        }, h.tryCreditsPurchase = function(e, t) {
                            this.startTransaction(e, (function(e) {
                                var n = e.error,
                                    r = e.clientPurchaseReceipt,
                                    i = e.purchaseTransactionFailed;
                                if (n || !r) {
                                    var a, o;
                                    if (i && I(e)) a = null == (o = i.form_error) || null == (o = o.failure) ? void 0 : o.error_message;
                                    else null != i && i.notification && (a = i.notification.message);
                                    a && u.A.showNotification({
                                        type: u.A.TYPES.ERROR,
                                        text: a
                                    }), e.error = e.error || new Error("Not able to purchase credits in tryCreditsPurchase")
                                }
                                t(e)
                            }))
                        }, h.validateMerchant = function(e) {
                            var t = {
                                validation_url: e.validationURL,
                                transaction_id: e.transactionId
                            };
                            return (0, r.Y)({
                                requestType: 738,
                                responseType: 739,
                                message: t
                            })
                        }, i
                    }(i.A);

                function T(e) {
                    e && (46 === e.type ? (g.A.processClientNotification(e), S(e.transaction_identifier, v.A.RESULTS.SUCCESS)) : 49 === e.type && (g.A.processClientNotification(e), S(e.transaction_identifier, v.A.RESULTS.FAILURE)))
                }

                function S(e, t) {
                    e || v.A.getInstance().setResult(t);
                    var n = _[e];
                    (!n || n.state !== t && t !== v.A.RESULTS.PENDING) && (n = {
                        state: t,
                        paymentStateUpdated: !1
                    }, _[e] = n), n.paymentStateUpdated && t !== v.A.RESULTS.PENDING || (v.A.getInstance().setResult(n.state), n.paymentStateUpdated = !0)
                }

                function I(e) {
                    return (0, h.Q)(null == e ? void 0 : e.purchaseTransactionFailed)
                }
                b.EVENTS = {
                    SUCCESS: "payment-success",
                    FAILURE: "payment-failure",
                    RECEIPT: "payment-receipt"
                }, b.instance = null, b.getInstance = function() {
                    return b.instance || (b.instance = new b), b.instance
                }, t.A = b
            },
            49711: function(e, t, n) {
                var r;
                n.d(t, {
                        P: function() {
                            return r
                        }
                    }),
                    function(e) {
                        e.DEFAULT = "DEFAULT", e.EXTRA = "EXTRA", e.SPP = "SPP", e.PREMIUM_PLUS = "PREMIUM_PLUS"
                    }(r || (r = {}))
            },
            51438: function(e, t, n) {
                n.d(t, {
                    D$: function() {
                        return S
                    },
                    D4: function() {
                        return I
                    },
                    Im: function() {
                        return E
                    },
                    Np: function() {
                        return O
                    },
                    QO: function() {
                        return y
                    },
                    UM: function() {
                        return b
                    },
                    a_: function() {
                        return _
                    },
                    eV: function() {
                        return T
                    },
                    s$: function() {
                        return C
                    }
                });
                n(2008), n(26099), n(50113), n(25276), n(45700), n(89572), n(52675), n(89463), n(2892), n(84185), n(79432), n(83851), n(51629), n(23500), n(81278), n(67945);
                var r = n(32308),
                    i = n(79860),
                    a = n(18084),
                    o = n(71672),
                    s = n(69978),
                    c = n(3208);

                function u(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function l(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? u(Object(n), !0).forEach((function(t) {
                            d(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function d(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var p, f, h, g = "trackedPaymentFlowIds",
                    v = [],
                    m = a.A.getLogger("PaymentTracker"),
                    y = {
                        CANCELLED: 1,
                        SUCCESS: 3,
                        FAILURE: 2
                    };

                function A(e) {
                    var t = 1;
                    return void 0 === e ? t = 3 : e && (t = 2), t
                }

                function P() {
                    return o.A.getArray(g) || []
                }

                function E(e, t, n, a) {
                    if (void 0 === a && (a = {}), function(e) {
                            return Boolean(P().find((function(t) {
                                return t.id === e
                            })))
                        }(e = e || c.A.get())) return e;
                    var u;
                    (0, r.Rg)(n) || (n = 1);
                    var d = function(e) {
                        var t = (0, s.z)(e);
                        return t || m.error("No product enum for specified productType", {
                            productType: e
                        }), t
                    }(t);
                    return d && (u = d), u ? ((0, i.sx)(54, l({
                        uid: e,
                        activation_place: n,
                        product: u
                    }, a)), function(e) {
                        var t = P();
                        t.push({
                            id: e,
                            date: (new Date).getTime()
                        }), o.A.saveArray(g, t)
                    }(e), e) : (m.error("Missing required product type. ", {
                        inputFeature: t
                    }), "")
                }

                function _(e, t, n) {
                    "string" == typeof e && (0, i.sx)(46, {
                        uid: e,
                        provider_id: t,
                        product_id: n
                    })
                }

                function b(e, t, n) {
                    var r;
                    "string" == typeof e && ("boolean" == typeof t && (r = A(t)), (0, i.sx)(109, l({
                        uid: e,
                        auto_topup: r
                    }, n)))
                }

                function T(e, t, n) {
                    if ("string" == typeof e) {
                        var r = A(t);
                        (0, i.sx)(112, l({
                            uid: e,
                            auto_topup: r
                        }, n))
                    }
                }

                function S(e, t, n) {
                    var r;
                    "string" == typeof e && ("boolean" == typeof t && (r = A(t)), (0, i.sx)(111, l({
                        uid: e,
                        auto_topup: r
                    }, n)))
                }

                function I(e, t) {
                    if ("string" == typeof e) {
                        var n = A(t);
                        (0, i.sx)(113, {
                            uid: e,
                            auto_topup: n
                        })
                    }
                }

                function C(e, t, n) {
                    if ("string" == typeof e) {
                        var r = A(t);
                        (0, i.sx)(114, l({
                            uid: e,
                            auto_topup: r
                        }, n))
                    }
                }

                function O(e, t, n) {
                    if ("string" == typeof e) {
                        var r = t + ":" + e; - 1 === v.indexOf(r) ? (v.push(r), (0, i.sx)(115, {
                            uid: e,
                            result: t,
                            event_version: n
                        })) : m.warn("Payment tracker tried to track multiple times the payment with result state as " + t + ".", e)
                    }
                }
                p = 1728e5, f = (new Date).getTime(), h = P().filter((function(e) {
                    return f - e.date < p
                })), o.A.saveArray(g, h)
            },
            54129: function(e, t, n) {
                function r(e) {
                    return 192 === (null == e ? void 0 : e.provider)
                }
                n.d(t, {
                    R: function() {
                        return r
                    }
                })
            },
            55272: function(e, t, n) {
                function r(e) {
                    return 180 === (null == e ? void 0 : e.provider)
                }
                n.d(t, {
                    K: function() {
                        return r
                    }
                })
            },
            56217: function(e, t, n) {
                n.d(t, {
                    H: function() {
                        return r
                    }
                });
                n(50113), n(26099);

                function r(e, t) {
                    var n = e.find((function(e) {
                        return e.provider_id === t
                    }));
                    return null == n ? void 0 : n.default_product_uid
                }
            },
            58478: function(e, t, n) {
                n.d(t, {
                    D: function() {
                        return a
                    },
                    V: function() {
                        return o
                    }
                });
                var r = n(58385),
                    i = n(74389),
                    a = function(e) {
                        var t = null == e ? void 0 : e.start_transaction_to_display_wizard,
                            n = null == e ? void 0 : e.prefilled_billing_info;
                        return !1 === t && n
                    },
                    o = function(e, t, n, a) {
                        r.A.navigate(i.x.ADD_BILLING_INFO, !0, {
                            purchase: t,
                            selectedProvider: e,
                            deviceProfilingId: n,
                            tnc: a
                        })
                    }
            },
            59028: function(e, t, n) {
                n(26099), n(3362), n(10287);
                var r = n(6696),
                    i = n(99562),
                    a = n(32308),
                    o = n(31709),
                    s = n(41298);

                function c(e, t) {
                    return c = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, c(e, t)
                }
                var u = function(e) {
                    var t, n;

                    function r() {
                        var t;
                        return (t = e.call(this, {
                            get: {
                                message: 182,
                                response: 183
                            },
                            set: {
                                message: 195,
                                response: 196
                            }
                        }, {
                            name: "PaymentSettings",
                            useCache: !1
                        }) || this).removeStoredPayment = function(e) {
                            if (!e) return (0, s.A)(Promise.reject(new Error("Missing payment id when trying to remove stored payment")));
                            var t = {
                                value: e
                            };
                            return (0, i.e)({
                                requestType: 197,
                                responseType: 198,
                                message: t
                            })
                        }, t.unsubscribe = function(e, t) {
                            if (!(0, a.Rg)(e)) return (0, s.A)(Promise.reject(new Error("Invalid SubscriptionType provided: " + e)));
                            var n = {
                                type: e,
                                client_unsubscribe_alternative_supported: Boolean(t)
                            };
                            return (0, s.A)(new Promise((function(e, t) {
                                var r = {},
                                    i = !1,
                                    a = function(e) {
                                        e && e.type !== o.a5.HANDLER_UNSATISFIED && (i = !0, t(e))
                                    };
                                new o.Ay(464, n).onResponse(483, (function(e) {
                                    r.unsubscribeAlternative = e
                                })).onResponse(1, a).onError(a).onSpecialEvent(o.SE.REQ_FINISHED, (function() {
                                    i || e(r)
                                })).request()
                            })))
                        }, t
                    }
                    return n = e, (t = r).prototype = Object.create(n.prototype), t.prototype.constructor = t, c(t, n), r.getInstance = function() {
                        return r.instance || (r.instance = new r), r.instance
                    }, r.prototype.removeAutoTopup = function() {
                        return this.set()
                    }, r
                }(r.A);
                u.instance = void 0, t.A = u
            },
            59179: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return H
                    }
                });
                n(10287), n(45700), n(89572), n(52675), n(89463), n(2892), n(84185), n(79432), n(83851), n(81278), n(67945), n(74423), n(21699), n(51629), n(26099), n(23500), n(3362), n(23792), n(62953), n(72712), n(2008);
                var r = n(31709),
                    i = n(72537),
                    a = n(6696),
                    o = n(73090),
                    s = n(41298),
                    c = n(8054),
                    u = n(14153),
                    l = n(83183),
                    d = n(75248),
                    p = (n(23418), n(47764), n(31415), n(50113), n(99417)),
                    f = n(41051),
                    h = n(25093);

                function g(e, t) {
                    return g = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, g(e, t)
                }
                var v = function(e) {
                    var t, n;

                    function r() {
                        var t;
                        return (t = e.call(this, {
                            get: {
                                message: 749,
                                response: 750
                            }
                        }, {
                            name: "ServerSyncInstantPaywallsModel",
                            useCache: !1
                        }) || this).origin = 0, t.retryLaterTimeout = -1, t.cacheActionTypeReplaceWithResponse = function(e, n) {
                            var i = A(n, e.product_type);
                            t.sendStats(i, e), t.trigger(r.EVENTS.CACHE, e)
                        }, t.cacheActionTypeUseExisting = function(e, n) {
                            var r = A(n, e.product_type);
                            t.setAvailableProducts(r)
                        }, t.cacheActionTypeDropAndRetryLater = function(e, n) {
                            var r = e.product_type,
                                i = e.retry_in_sec,
                                a = A(n, r);
                            t.sendStats(a, e), t.dropFeatureProductListCache(r), p.A.clearTimeout(t.retryLaterTimeout), t.retryLaterTimeout = p.A.setTimeout(t.handleEmptyCacheCase, 1e3 * i)
                        }, t.cacheActionTypeDropAndFallback = function(e) {
                            var n = e.product_type;
                            t.dropFeatureProductListCache(n), 13 !== n && 1 !== n || t.trigger(r.EVENTS.PRELOAD_PAYWALLS, n)
                        }, t.cacheActionTypeUndefined = function(e) {
                            t.dropFeatureProductListCache(void 0), t.handleEmptyCacheCase()
                        }, t.handleSyncedPaywallsResponse = function(e, n) {
                            var r = (null == e ? void 0 : e.paywalls) || [];
                            0 === r.length && t.handleEmptyCacheCase(), r.forEach((function(e) {
                                t.setAvailableProducts(e);
                                var r = e.cache_action;
                                t.getPaywallHandler(r)(e, n), 0 === n.length && [2, 3].includes(r)
                            }))
                        }, t.handleEmptyCacheCase = function() {
                            t.trigger(r.EVENTS.PRELOAD_PAYWALLS)
                        }, t
                    }
                    n = e, (t = r).prototype = Object.create(n.prototype), t.prototype.constructor = t, g(t, n), r.getInstance = function() {
                        return r.instance || (r.instance = new r), r.instance
                    };
                    var i = r.prototype;
                    return i.getSyncedPaywalls = function(e) {
                        var t = {
                            cached_paywalls: this.getCachedPaywallProductRequest(e)
                        };
                        return this.get(t)
                    }, i.setOrigin = function(e) {
                        this.origin = e
                    }, i.syncInstantPaywalls = function(e, t) {
                        var n = this;
                        t && this.setOrigin(t), this.getSyncedPaywalls(e).then((function(t) {
                            n.handleSyncedPaywallsResponse(t, e)
                        })).catch((function(e) {
                            (0, h.A)(e) && n.log.error("Failed to sync Instant Paywalls", {
                                error: e
                            })
                        }))
                    }, i.getPaywallHandler = function(e) {
                        switch (e) {
                            case 1:
                                return this.cacheActionTypeReplaceWithResponse;
                            case 2:
                                return this.cacheActionTypeUseExisting;
                            case 3:
                                return this.cacheActionTypeDropAndRetryLater;
                            case 4:
                                return this.cacheActionTypeDropAndFallback;
                            default:
                                return this.cacheActionTypeUndefined
                        }
                    }, i.dropFeatureProductListCache = function(e) {
                        e ? this.trigger(r.EVENTS.INVALIDATE, e) : this.trigger(r.EVENTS.INVALIDATE_ALL, !0)
                    }, i.setAvailableProducts = function(e) {
                        var t = e.paywall_data;
                        Boolean(null == t ? void 0 : t.available_products) && this.trigger(r.EVENTS.UPDATE_PRODUCTS, t)
                    }, i.sendStats = function(e, t) {
                        var n = {
                            cachedPaywallId: m(e),
                            freshPaywallId: m(t),
                            cachedPaywallPriceTokens: y(e),
                            freshPaywallPriceTokens: y(t),
                            refreshOrigin: this.origin
                        };
                        f.A.sendCachedPaywallsUpdatedStats(n)
                    }, i.getCachedPaywallProductRequest = function(e) {
                        var t = this;
                        return void 0 === e && (e = []), e.reduce((function(e, n) {
                            var r = n.paywall_data,
                                i = null == r ? void 0 : r.product_type;
                            if (i) {
                                var a = {
                                    product_type: i
                                };
                                n.request_mode && (a.request_mode = n.request_mode);
                                var o = null == r ? void 0 : r.identifier;
                                o && (a.cached_instant_paywall_identifier = o), e.push(a)
                            } else t.log.error("ProductRequest: cached paywall has not productType", {
                                paywall: n
                            });
                            return e
                        }), [])
                    }, r
                }(a.A);

                function m(e) {
                    var t = null == e ? void 0 : e.paywall_data;
                    return (null == t ? void 0 : t.identifier) || ""
                }

                function y(e) {
                    var t = [],
                        n = null == e ? void 0 : e.paywall_data;
                    return ((null == n ? void 0 : n.products) || []).forEach((function(e) {
                        (e.providers || []).forEach((function(e) {
                            var n = (null == e ? void 0 : e.price_token) || "";
                            t.push(n)
                        }))
                    })), Array.from(new Set(t))
                }

                function A(e, t) {
                    return t && e.find((function(e) {
                        return e.product_type === t
                    })) || {}
                }
                v.EVENTS = {
                    CACHE: "cache",
                    INVALIDATE: "invalidate",
                    INVALIDATE_ALL: "invalidate_all",
                    INVALIDATED: "invalidated",
                    PRELOAD_PAYWALLS: "preload_paywalls",
                    UPDATE_PRODUCTS: "update_products"
                }, v.instance = null;
                var P = v,
                    E = n(3508),
                    _ = n(65869),
                    b = n(36721),
                    T = n(32308),
                    S = n(3208);

                function I(e, t) {
                    var n = {
                        experimental_is_for_instant_wizard: Boolean(null == t ? void 0 : t.isInstantPayWall),
                        product_type: e,
                        providers: (0, _.A)({
                            paymentProviderConfig: E.A.get("payment.providers"),
                            supportsApplePay: b.A.supportsApplePay(),
                            isTWA: b.A.isTWA()
                        }),
                        request_mode: 1
                    };
                    return t && (Array.isArray(t.providers) && (n.providers = t.providers), t.userId && (n.user_id = String(t.userId)), (0, T.Rg)(t.requestMode) && (n.request_mode = t.requestMode), (0, T.Rg)(t.promoBlockType) && (n.promo_block_type = t.promoBlockType), (0, T.Rg)(t.context) && (n.context = t.context), t.creditsForProduct && (n.credits_for_product = Number(t.creditsForProduct)), 12 === e && (n.chat_initial_screen_type = 19), t.promoCampaignId && (n.promo_campaign_id = t.promoCampaignId), t.ignoreStoredDetails && (n.ignore_stored_details = t.ignoreStoredDetails), n.unique_flow_id = S.A.get()), n
                }
                var C = function() {};
                C.getPaywallData = function(e, t) {
                    var n = I(e, t);
                    return (0, s.A)(new Promise((function(e, t) {
                        new r.Ay(630, n).onResponse(153, (function(t) {
                            e(t)
                        })).onResponse(1, (function(e) {
                            t(e)
                        })).onError((function(e) {
                            e && e.type !== r.a5.HANDLER_UNSATISFIED && t(e)
                        })).request()
                    })))
                };
                var O = C,
                    R = n(39403);
                var w = function() {
                    function e() {}
                    return e.getPaywallData = function(e, t) {
                        var n = function(e, t) {
                            return (0, R.l)(e, t)
                        }(e, t);
                        return (0, s.A)(new Promise((function(e, t) {
                            new r.Ay(644, n).onResponse(153, (function(t) {
                                e(t)
                            })).onResponse(1, (function(e) {
                                t(e)
                            })).onError((function(e) {
                                e && e.type !== r.a5.HANDLER_UNSATISFIED && t(e)
                            })).request()
                        })))
                    }, e
                }();
                var D = n(63826);
                var L, U, N = n(107);

                function j(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function M(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function x(e, t) {
                    return x = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, x(e, t)
                }! function(e) {
                    e.EXTRA = "EXTRA", e.SPP = "SPP", e.PREMIUM_PLUS = "PREMIUM_PLUS", e.CREDITS = "CREDITS"
                }(U || (U = {}));
                var k = ((L = {})[U.EXTRA] = U.EXTRA, L[U.SPP] = U.SPP, L[U.PREMIUM_PLUS] = U.PREMIUM_PLUS, L[U.CREDITS] = U.CREDITS, L),
                    F = 0,
                    B = function(e) {
                        var t, n;

                        function a() {
                            var t;
                            return (t = e.call(this, {
                                get: {
                                    message: 627,
                                    response: 666
                                }
                            }, {
                                name: "FeatureProductListModel" + (b.A.isTWA() ? "_TWA" : b.A.isHuaweiQuickApp() ? "_HUAWEI" : "_MW"),
                                preventMultiple: !0
                            }) || this).instantProductTypes = [66, 1, 47, 13], t.serverSyncInstantPaywallsModel = void 0, t.serverSyncInstantPaywallsModel = P.getInstance(), t
                        }
                        n = e, (t = a).prototype = Object.create(n.prototype), t.prototype.constructor = t, x(t, n), a.getInstance = function() {
                            return a.instance || (a.instance = new a), a.instance
                        };
                        var c = a.prototype;
                        return c.init = function() {
                            var e = this;
                            this.serverSyncInstantPaywallsModel = P.getInstance(), d.A.getInstance().on(d.A.Type.SYSTEM_NOTIFICATION, (function(t) {
                                23 === t.id && (e.invalidateAll(!0), e.preloadInstantPaywalls(2))
                            }));
                            var t = i.A.getObservable(204);
                            i.A.observe(t, this.preloadInstantPaywall.bind(this), {
                                leading: !1
                            }), this.serverSyncInstantPaywallsModel.on(P.EVENTS.CACHE, this.cachePaywallData, this).on(P.EVENTS.INVALIDATE, this.invalidateByProductType, this).on(P.EVENTS.INVALIDATE_ALL, this.invalidateAll, this).on(P.EVENTS.PRELOAD_PAYWALLS, this.preloadPaywalls, this).on(P.EVENTS.UPDATE_PRODUCTS, this.setAvailableProducts, this), this.updateInstantProductTypesFromCache()
                        }, c.canUseInstantPaywall = function(e) {
                            var t, n = i.A.getSync(204).enabled,
                                r = Boolean(e && (null == (t = this.cache) ? void 0 : t.get(G(e)))),
                                a = !e || this.instantProductTypes.includes(e);
                            return n && a && !r
                        }, c.setInstantProductTypes = function(e) {
                            Array.isArray(e) && (this.instantProductTypes = e)
                        }, c.updateInstantProductTypesFromCache = function() {
                            var e = this;
                            this.getCachedInstantPayWalls().forEach((function(t) {
                                var n = t.paywall_data;
                                (null == n ? void 0 : n.available_products) && e.setAvailableProducts(n)
                            }))
                        }, c.getInstantPaywall = function(e) {
                            var t, n = this.getCacheKey(627, e),
                                i = null == (t = this.cache) ? void 0 : t.get(n);
                            if (!e.ignore_stored_details && null != i && i.length) {
                                i.fromCache = !0;
                                var a = i[0];
                                return Promise.resolve({
                                    productList: null == a ? void 0 : a.paywall_data
                                })
                            }
                            return new Promise((function(t, n) {
                                var i = {};
                                new r.Ay(627, e).onResponse(666, (function(e) {
                                    i.productList = e.paywall_data
                                })).onResponse(629, (function(e) {
                                    i.productListFailure = e
                                })).onResponse(1, (function(e) {
                                    i.serverErrorMessage = e
                                })).onError((function(e) {
                                    e && e.type !== r.a5.HANDLER_UNSATISFIED && n(e)
                                })).onSpecialEvent(r.SE.REQ_END, (function() {
                                    t(i)
                                })).request()
                            }))
                        }, c.getByProduct = function(e, t) {
                            var n = this,
                                i = this.canUseInstantPaywall(e),
                                a = Boolean(this.getCachedInstantPayWalls(e).length),
                                o = W(e),
                                c = I(e, t),
                                u = i && (a || !o) ? this.getInstantPaywall(c) : function(e) {
                                    return new Promise((function(t, n) {
                                        var i = {};
                                        new r.Ay(165, e).onResponse(153, (function(e) {
                                            i.productList = e
                                        })).onResponse(1, (function(e) {
                                            i.serverErrorMessage = e
                                        })).onError((function(e) {
                                            e && e.type !== r.a5.HANDLER_UNSATISFIED && n(e)
                                        })).onSpecialEvent(r.SE.REQ_END, (function() {
                                            t(i)
                                        })).request()
                                    }))
                                }(c);
                            return (0, s.A)(u.then((function(r) {
                                var i = r.productList,
                                    a = r.productListFailure,
                                    o = r.serverErrorMessage;
                                if (o) throw o;
                                if (a) {
                                    if (n.handleProductListFailure(e, a), null != t && t.background) return {};
                                    n.getByProduct(e, t)
                                }
                                if (i) return c.ignore_stored_details || n.cachePaywallData(i), n.setAvailableProducts(i),
                                    function(e, t) {
                                        if (e && t) {
                                            var n, r = function(e) {
                                                    for (var t = 1; t < arguments.length; t++) {
                                                        var n = null != arguments[t] ? arguments[t] : {};
                                                        t % 2 ? j(Object(n), !0).forEach((function(t) {
                                                            M(e, t, n[t])
                                                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : j(Object(n)).forEach((function(t) {
                                                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                                                        }))
                                                    }
                                                    return e
                                                }({}, e),
                                                i = null == (n = r.products) ? void 0 : n.filter((function(e) {
                                                    return !e.value || e.value >= t
                                                }));
                                            return r.products = i, r
                                        }
                                        return e
                                    }(i, null == t ? void 0 : t.cost);
                                throw new Error("Retrieving featureProductList when the session has expired on SRV")
                            })).catch((function(t) {
                                throw n.disablePayWall(e), t
                            })))
                        }, c.getMultiplePaywalls = function() {
                            var e = this,
                                t = [13, 1];
                            (0, D.X)() && t.push(47), (0, N.M)() && t.push(66);
                            var n = [];
                            t.forEach((function(e) {
                                n.push({
                                    message_type: 627,
                                    body: I(e, {
                                        productType: e,
                                        background: !0
                                    })
                                })
                            }));
                            var i = t.length,
                                a = [];
                            return new Promise((function(t, o) {
                                var s = function(n) {
                                        if (e.cachePaywallData(n), a.push(n), a.length === i) return t(a)
                                    },
                                    c = function(e) {
                                        if (e) {
                                            if ((0, u.i)(e) && e.type === r.a5.HANDLER_UNSATISFIED) return;
                                            var t = "";
                                            (0, l.P)(e) && (t = e.error_message), o(new Error(t))
                                        }
                                    };
                                new r.Ay(628, n).onResponse(153, s).onResponse(666, s).onResponse(1, c).onError(c).request()
                            }))
                        }, c.getCacheTime = function() {
                            return 31536e6
                        }, c.cachePaywallData = function(e) {
                            F = Date.now();
                            var t = this.getCacheKey(627, e),
                                n = this.getCacheTime(),
                                r = function(e) {
                                    return "paywall_data" in e
                                }(e) ? e : function(e) {
                                    var t = e.product_type;
                                    if (!t) return {};
                                    return {
                                        product_type: t,
                                        request_mode: 1,
                                        paywall_data: e
                                    }
                                }(e);
                            this.cacheResponse(t, n, r)
                        }, c.invalidateByProductType = function(e) {
                            var t = V(e);
                            this.invalidate(t, !1, !0)
                        }, c.handleProductListFailure = function(e, t) {
                            var n = t.retry_in_sec,
                                r = n ? 1e3 * n : n;
                            this.disablePayWall(e, r)
                        }, c.disablePayWall = function(e, t) {
                            var n;
                            t || (t = 9e5), null == (n = this.cache) || n.invalidate(G(e), !1, !0)
                        }, c.getContextPayWall = function(e, t) {
                            var n = this,
                                r = e || t.productType;
                            t.isInstantPayWall = this.canUseInstantPaywall(r);
                            var i = W(r) ? O.getPaywallData(r, t) : w.getPaywallData(r, t);
                            return i.catch((function(e) {
                                if (n.disablePayWall(r), !t.background) throw e;
                                n.log.warn(e)
                            })), i
                        }, c.getCacheKey = function(e, t) {
                            return V(t.product_type)
                        }, c.shouldCache = function(e) {
                            return 627 === e
                        }, c.handleCacheInvalidated = function(t) {
                            var n = this,
                                r = t.all,
                                i = t.keys,
                                a = t.fromWatchdog;
                            e.prototype.handleCacheInvalidated.call(this, t), this.canUseInstantPaywall() && !a && (r ? this.preloadInstantPaywall() : null == i || i.forEach((function(e) {
                                e === k.CREDITS ? n.preloadCreditsPaywall() : e === k.EXTRA ? n.preloadExtraPaywall() : e === k.SPP ? n.preloadSppPaywall() : e === k.PREMIUM_PLUS && n.preloadPremiumPlusPaywall()
                            })))
                        }, c.cacheResponse = function(t, n, r) {
                            var i = null == r ? void 0 : r.paywall_data;
                            if (i) {
                                var a, o = i.product_type;
                                if (o) null == (a = this.cache) || a.invalidate(G(o), !0);
                                return e.prototype.cacheResponse.call(this, t, n, r)
                            }
                            return r
                        }, c.getCachedInstantPayWalls = function(e) {
                            var t, n = this;
                            return ((null == (t = this.cache) ? void 0 : t.getKeys()) || []).reduce((function(t, r) {
                                if (k[r]) {
                                    var i, a = null == (i = n.cache) ? void 0 : i.get(r);
                                    if (a) {
                                        var o = Array.isArray(a) ? a[0] : a,
                                            s = o.product_type;
                                        (!e || e === s) && t.push(o)
                                    }
                                }
                                return t
                            }), [])
                        }, c.preloadPaywalls = function(e) {
                            13 === e ? this.preloadCreditsPaywall() : 1 === e ? this.preloadSppPaywall() : 66 === e ? this.preloadExtraPaywall() : 47 === e ? this.preloadPremiumPlusPaywall() : this.getMultiplePaywalls().catch(Y)
                        }, c.preloadInstantPaywall = function() {
                            S.A.generate(), this.preloadCreditsPaywall(), this.preloadExtraPaywall(), this.preloadSppPaywall(), this.preloadPremiumPlusPaywall()
                        }, c.preloadInstantPaywalls = function(e) {
                            S.A.generate();
                            var t = this.getCachedInstantPayWalls();
                            this.serverSyncInstantPaywallsModel.syncInstantPaywalls(t, e)
                        }, c.preloadCreditsPaywall = function() {
                            var e = this;
                            if (i.A.getSync(204).enabled && o.A.isLoggedIn()) return this.getByProduct(13, {
                                background: !0,
                                productType: 13
                            }).then((function(t) {
                                t && e.setAvailableProducts(t)
                            })).catch(Y)
                        }, c.preloadExtraPaywall = function() {
                            if (i.A.getSync(204).enabled && o.A.isLoggedIn() && !i.A.getSync(19).enabled) return this.getByProduct(66, {
                                background: !0,
                                productType: 66
                            }).catch(Y)
                        }, c.preloadSppPaywall = function() {
                            if (i.A.getSync(204).enabled && o.A.isLoggedIn() && !i.A.getSync(19).enabled) return this.getByProduct(1, {
                                background: !0,
                                productType: 1
                            }).catch(Y)
                        }, c.preloadPremiumPlusPaywall = function() {
                            if (i.A.getSync(204).enabled && o.A.isLoggedIn() && (0, D.X)() && !i.A.getSync(19).enabled) return this.getByProduct(47, {
                                background: !0,
                                productType: 47
                            }).catch(Y)
                        }, c.setAvailableProducts = function(e) {
                            var t = e.available_products;
                            Boolean(t) && this.setInstantProductTypes(t)
                        }, a
                    }(a.A);
                B.instance = null;
                var H = B;

                function G(e) {
                    return "DID_PAYWALL_FAIL:" + e
                }

                function V(e) {
                    switch (e) {
                        case 66:
                            return k.EXTRA;
                        case 1:
                            return k.SPP;
                        case 47:
                            return k.PREMIUM_PLUS;
                        default:
                            return k.CREDITS
                    }
                }

                function W(e) {
                    return 66 === e || 1 === e || 47 === e || 13 === e
                }

                function Y() {
                    return !0
                }(0, c.A)({
                    getLastInstantPaywallUpdate: function() {
                        return F
                    }
                })
            },
            59244: function(e, t, n) {
                var r, i;
                n.d(t, {
                    y: function() {
                        return s
                    }
                });
                var a = ((r = {})[26] = "badge-feature-boost", r[75] = "badge-feature-premium-plus", r[27] = "badge-feature-bundle-sale", r[30] = "badge-chat", r[40] = "badge-feature-crush", r[7] = "badge-feature-extra-shows", r[3] = "badge-feature-favourites", r[17] = "badge-feature-chat-with-tired", r[31] = "badge-feature-invisible-mode", r[37] = "badge-feature-liked-you", r[4] = "badge-feature-match", r[18] = "badge-feature-chat-with-newbies", r[19] = "badge-feature-special-delivery", r[74] = "badge-feature-read-receipt", r[44] = "badge-no-advert", r[5] = "badge-feature-riseup", r[8] = "badge-feature-premium", r[22] = "badge-feature-undo", r[28] = "badge-feature-encounters", r[70] = "badge-feature-filter", r[91] = "badge-feature-credit", r),
                    o = ((i = {})[26] = "badge-feature-boost-premium-plus", i[30] = "badge-chat-premium-plus", i[40] = "badge-feature-crush-premium-plus", i[7] = "badge-feature-boost-premium-plus", i[74] = "badge-feature-read-receipt-premium-plus", i);

                function s(e, t) {
                    if (e) {
                        var n = 47 === t ? o[e] : void 0;
                        return n || (n = a[e]), n
                    }
                }
            },
            62608: function(e, t, n) {
                n(26099), n(3362), n(10287), n(50113);
                var r, i = n(65297),
                    a = n(6696),
                    o = n(73090),
                    s = n(31709);

                function c(e, t) {
                    return c = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, c(e, t)
                }! function(e) {
                    e.CHANGE = "CHANGE"
                }(r || (r = {}));
                var u = function(e) {
                    var t, n;

                    function a() {
                        var t;
                        return (t = e.call(this, {
                            get: {
                                message: 573,
                                response: 574
                            }
                        }, {
                            commitCache: !1,
                            name: "CreditsModel",
                            useCache: !1
                        }) || this).creditsBalance = void 0, t
                    }
                    n = e, (t = a).prototype = Object.create(n.prototype), t.prototype.constructor = t, c(t, n), a.getInstance = function() {
                        return a.instance || (a.instance = new a), a.instance
                    };
                    var u = a.prototype;
                    return u.init = function() {
                        var e = this;
                        return s.aV.onResponse(574, (function(t) {
                            e.saveAndTriggerBalanceChange(t)
                        })), i.A.on(i.A.Session.SESSION_CHANGED, (function(t) {
                            t.isLoggedIn || e.setCreditsBalance(void 0)
                        })), this
                    }, u.saveAndTriggerBalanceChange = function(e) {
                        var t = function(e) {
                            if (!e) return;
                            return (e.balances || []).find((function(e) {
                                return 1 === e.type
                            }))
                        }(e);
                        if (t)
                            if (this.creditsBalance) {
                                var n = this.creditsBalance.balance_ts || 0,
                                    r = t.balance_ts || 0;
                                if (r > n) this.setCreditsBalance(t);
                                else if (r === n) {
                                    var i = this.creditsBalance.value < t.value ? this.creditsBalance : t;
                                    this.setCreditsBalance(i)
                                }
                            } else this.setCreditsBalance(t)
                    }, u.setCreditsBalance = function(e) {
                        var t = this.getCurrentCredits();
                        this.creditsBalance = e;
                        var n = this.getCurrentCredits();
                        n !== t && this.trigger(r.CHANGE, n)
                    }, u.getCredits = function() {
                        var t = this;
                        if (!o.A.isLoggedIn()) return Promise.resolve(0);
                        if (this.creditsBalance) return Promise.resolve(this.getCurrentCredits());
                        return e.prototype.get.call(this, {
                            types: [1]
                        }).then((function(e) {
                            if (t.saveAndTriggerBalanceChange(e), !t.creditsBalance) throw new Error("Credits balance not found");
                            return t.getCurrentCredits()
                        }))
                    }, u.getCurrentCredits = function() {
                        var e;
                        return (null == (e = this.creditsBalance) ? void 0 : e.value) || 0
                    }, a
                }(a.A);
                u.EVENTS = r, u.instance = null, u.getInstance(), t.A = u
            },
            63334: function(e, t, n) {
                n.d(t, {
                    B: function() {
                        return i
                    }
                });
                var r = n(99417);

                function i() {
                    return r.A.location.protocol + "//" + r.A.location.hostname + "/payment-result.html"
                }
            },
            64872: function(e, t, n) {
                n.d(t, {
                    L: function() {
                        return _
                    }
                });
                n(26099), n(3362), n(9391);
                var r = n(96540),
                    i = n(55272),
                    a = n(54129);
                var o, s = n(65153),
                    c = n(99417),
                    u = n(89104),
                    l = n(8054),
                    d = (0, n(40504).A)(c.A.location.hostname).env === u.A.DEV_REMOTE;
                ! function(e) {
                    e.INITIALIZED = "INITIALIZED", e.INITIALIZING = "INITIALIZING", e.NONE = "NONE"
                }(o || (o = {})), (0, l.A)({
                    enableGooglePayTestEnv: function(e) {
                        return void 0 === e && (e = !0), d = e, e
                    }
                });
                var p, f, h = n(26359);
                ! function(e) {
                    e.INITIALIZED = "INITIALIZED", e.INITIALIZING = "INITIALIZING", e.NONE = "NONE"
                }(p || (p = {})),
                function(e) {
                    e.SANDBOX = "https://static-sandbox.dlocal.com/js/collector/direct.js", e.PRODUCTION = "https://static.dlocal.com/js/collector/direct.js"
                }(f || (f = {}));
                var g = n(86812),
                    v = n(18084),
                    m = n(93529),
                    y = n(12702),
                    A = n(7802),
                    P = n(87574),
                    E = v.A.getLogger("useExternalProviderInitialiser"),
                    _ = function(e) {
                        var t, n, u, l = e.selectedProvider,
                            v = e.transactionController,
                            _ = e.isUcbFlow,
                            b = (0, s.Q)(),
                            T = b.initApplePay,
                            S = b.isInitialized,
                            I = b.needsInitialization,
                            C = (t = (0, r.useState)(o.NONE), n = t[0], u = t[1], {
                                initGooglePay: function(e, t) {
                                    return new Promise((function(n, r) {
                                        var i = null == t ? void 0 : t.integration,
                                            a = null == i ? void 0 : i.app_key;
                                        if (a) {
                                            u(o.INITIALIZING);
                                            var s = e.initGooglePay({
                                                gatewayMerchantId: a,
                                                isTestEnvironment: d,
                                                nonce: c.A._nonce,
                                                onReady: function(e) {
                                                    e ? r(e) : n(s), s.isReadyToPay() ? u(o.INITIALIZED) : u(o.NONE)
                                                }
                                            })
                                        } else r(new Error("Cannot get gatewayMerchantId for GooglePay"))
                                    }))
                                },
                                needsInitialization: n === o.NONE
                            }),
                            O = C.initGooglePay,
                            R = C.needsInitialization,
                            w = function() {
                                var e = (0, r.useState)(p.NONE),
                                    t = e[0],
                                    n = e[1];
                                return {
                                    initUpi: function(e) {
                                        return new Promise((function(t, r) {
                                            var i = null == e ? void 0 : e.integration,
                                                a = null == i ? void 0 : i.app_key;
                                            if (a) {
                                                var o = null == i ? void 0 : i.is_sandbox,
                                                    s = o ? f.SANDBOX : f.PRODUCTION;
                                                n(p.INITIALIZING), (0, h.k)(s, {
                                                    nonce: c.A._nonce
                                                }).then((function() {
                                                    c.A.window.dlocalCollector.create({
                                                        ENV: o ? "sandbox" : "production",
                                                        apiKey: a
                                                    }).then((function(e) {
                                                        n(p.INITIALIZED), t(e)
                                                    }))
                                                }))
                                            } else r(new Error("Cannot get merchantIdentifier for Upi"))
                                        }))
                                    },
                                    needsInitialization: t === p.NONE
                                }
                            }(),
                            D = w.initUpi,
                            L = w.needsInitialization,
                            U = (0, y.jh)().dispatch,
                            N = (0, P.LZ)().dispatch;
                        (0, r.useEffect)((function() {
                            var e, t = (0, i.K)(l),
                                n = (0, a.R)(l),
                                r = 195 === (null == (e = l) ? void 0 : e.provider),
                                o = function(e) {
                                    _ ? U({
                                        type: y.BX.UPDATE_IS_LOADING,
                                        value: e
                                    }) : A.q.setValue(e)
                                };
                            t && I ? (o(!0), T(v, l).catch((function(e) {
                                (0, g.y)(e) || E.error("Cannot get merchantIdentifier for ApplePay", {
                                    error: e,
                                    mop: l
                                }), m.A.showNotification({
                                    type: m.A.TYPES.ERROR
                                })
                            })).finally((function() {
                                o(!1)
                            }))) : n && R ? (o(!0), O(v, l).catch((function() {
                                E.error("Cannot get gatewayMerchantId for GooglePay", {
                                    mop: l
                                }), m.A.showNotification({
                                    type: m.A.TYPES.ERROR
                                })
                            })).finally((function() {
                                o(!1)
                            }))) : r && L && (o(!0), D(l).then((function(e) {
                                _ ? U({
                                    type: y.BX.UPDATE_DEVICE_PROFILING_ID,
                                    value: e
                                }) : N({
                                    type: P.YM.UPDATE_DEVICE_PROFILING_ID,
                                    value: e
                                })
                            })).finally((function() {
                                o(!1)
                            })))
                        }), [l, v, _, T, O, D, S, R, I, L, U, N])
                    }
            },
            65153: function(e, t, n) {
                n.d(t, {
                    Q: function() {
                        return a
                    }
                });
                n(26099), n(3362);
                var r, i = n(96540);

                function a() {
                    var e = (0, i.useState)(r.NONE),
                        t = e[0],
                        n = e[1];
                    return {
                        initApplePay: function(e, t) {
                            return new Promise((function(i, a) {
                                var o = null == t ? void 0 : t.integration,
                                    s = null == o ? void 0 : o.app_key;
                                if (s) {
                                    n(r.INITIALIZING);
                                    var c = null == t ? void 0 : t.provider_id,
                                        u = e.initApplePay({
                                            providerId: String(c),
                                            merchantIdentifier: s,
                                            onReady: function(e) {
                                                e ? a(e) : i(u), null != u && null != u.getIsPaymentsAvailable && u.getIsPaymentsAvailable() ? n(r.INITIALIZED) : n(r.NONE)
                                            }
                                        })
                                } else a(new Error("Cannot get merchantIdentifier for ApplePay"))
                            }))
                        },
                        isInitialized: t === r.INITIALIZED,
                        needsInitialization: t === r.NONE
                    }
                }! function(e) {
                    e.INITIALIZED = "INITIALIZED", e.INITIALIZING = "INITIALIZING", e.NONE = "NONE"
                }(r || (r = {}))
            },
            67556: function(e, t, n) {
                n.d(t, {
                    K: function() {
                        return r
                    }
                });
                var r = function() {
                    function e() {}
                    return e.get = function(t) {
                        return e.transactionsExtraData[t]
                    }, e.set = function(t, n) {
                        e.transactionsExtraData[t] = n
                    }, e.remove = function(t) {
                        var n = e.transactionsExtraData[t];
                        return delete e.transactionsExtraData[t], n
                    }, e
                }();
                r.transactionsExtraData = {}
            },
            68251: function(e, t, n) {
                var r;
                n.d(t, {
                        G: function() {
                            return r
                        }
                    }),
                    function(e) {
                        e.SPP = "SPP", e.SPP_CONTEXTUAL = "SPP_CONTEXTUAL", e.PREMIUM_PLUS = "PREMIUM_PLUS", e.PREMIUM_PLUS_CONTEXTUAL = "PREMIUM_PLUS_CONTEXTUAL", e.CREDITS = "CREDITS", e.CREDITS_CONTEXTUAL = "CREDITS_CONTEXTUAL"
                    }(r || (r = {}))
            },
            69079: function(e, t, n) {
                function r(e, t) {
                    return t.priority || 0 - e.priority || 0
                }
                n.d(t, {
                    e: function() {
                        return r
                    }
                })
            },
            69978: function(e, t, n) {
                var r;
                n.d(t, {
                    z: function() {
                        return a
                    }
                });
                var i = ((r = {})[1] = 6, r[23] = 22, r[3] = 1, r[4] = 7, r[5] = 9, r[6] = 3, r[7] = 8, r[12] = 13, r[13] = 2, r[14] = 11, r[21] = 15, r[22] = 21, r[25] = 23, r[45] = 47, r[47] = 48, r[66] = 57, r);

                function a(e) {
                    if (e) return i[e]
                }
            },
            70182: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return a
                    }
                });
                n(74423), n(21699);
                var r = n(74389),
                    i = [r.x.PAYMENT_TERMS, r.x.PLAN_COMPARISON],
                    a = function() {
                        function e() {}
                        return e.set = function(t) {
                            e.initialProductType = t.initialProductType, e.methodOfPayment = t.methodOfPayment, e.product = t.product
                        }, e.get = function() {
                            return {
                                initialProductType: e.initialProductType,
                                methodOfPayment: e.methodOfPayment,
                                product: e.product
                            }
                        }, e.clear = function() {
                            e.initialProductType = void 0, e.methodOfPayment = void 0, e.product = void 0
                        }, e.hasToStoreSelection = function(e) {
                            return i.includes(e)
                        }, e
                    }();
                a.initialProductType = void 0, a.methodOfPayment = void 0, a.product = void 0
            },
            70271: function(e, t, n) {
                n.d(t, {
                    n: function() {
                        return i
                    }
                });
                var r = 2;

                function i(e) {
                    return e === r
                }
            },
            73160: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return v
                    }
                });
                n(84864), n(57465), n(27495), n(87745), n(38781), n(62062), n(51629), n(26099), n(45700), n(89572), n(52675), n(89463), n(2892), n(84185), n(79432), n(2008), n(83851), n(23500), n(81278), n(67945);
                var r = n(96540),
                    i = n(18084),
                    a = n(28244),
                    o = n(74848);

                function s(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function c(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? s(Object(n), !0).forEach((function(t) {
                            u(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function u(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var l = /\[link(?:=["']?([^'"\]]+)["']?)?\]([^\[]+)\[\/link\]/,
                    d = /<a(?:[^>]+href="([^"]*)"([^>]*))?>([^<]+)<\/a>/,
                    p = /(<a(?:[^>]+href[^>]+)?>[^<]+<\/a>)/,
                    f = ["rel", "target"],
                    h = i.A.getLogger("RoutingText");

                function g(e) {
                    var t, n = e.text,
                        i = e.routingMapping,
                        s = e.ignoreMissingRoutingInfo,
                        u = void 0 !== s && s,
                        g = new RegExp(l, "gi"),
                        v = new RegExp(d, "gi"),
                        m = new RegExp(p, "gi"),
                        y = n.replace(g, '<a href="$1">$2</a>').split(m).map((function(e) {
                            var t, r = v.exec(e);
                            if (r) {
                                var s, l = r[1];
                                if (!l && null != i && i.default && (l = "default"), i && (s = i[l]), s) {
                                    if ("href" in (t = s) || "routeName" in t) {
                                        var d = function(e) {
                                            var t = {},
                                                n = document.createElement("div");
                                            n.innerHTML = e;
                                            var r = n.getElementsByTagName("a")[0];
                                            r && f.forEach((function(e) {
                                                t[e] = r.getAttribute(e) || void 0
                                            }));
                                            return t
                                        }(e);
                                        return (0, o.jsx)(a.A, c(c(c({}, d), s), {}, {
                                            children: r[3]
                                        }))
                                    }
                                    return (0, o.jsx)("button", c(c({
                                        onClick: s.onClick
                                    }, s.dataQA), {}, {
                                        type: "button",
                                        children: r[3]
                                    }))
                                }
                                u || h.error("RoutingText string contains anchor markup, but no routing information is passed", {
                                    textPiece: e,
                                    text: n,
                                    routingMapping: i
                                })
                            }
                            return e
                        }));
                    return t = y, (0, o.jsx)(r.Fragment, {
                        children: t.map((function(e, t) {
                            return "string" == typeof e ? (0, o.jsx)("span", {
                                dangerouslySetInnerHTML: {
                                    __html: e
                                }
                            }, "fragment-" + t) : (0, o.jsx)(r.Fragment, {
                                children: e
                            }, "fragment-" + t)
                        }))
                    })
                }
                var v = function(e) {
                    var t = e.text,
                        n = e.routingMapping,
                        r = e.className,
                        i = g({
                            text: t,
                            routingMapping: n,
                            ignoreMissingRoutingInfo: e.ignoreMissingRoutingInfo
                        });
                    return (0, o.jsx)("span", {
                        className: r,
                        children: i
                    })
                }
            },
            73616: function(e, t, n) {
                var r = n(31189);
                t.A = r.A
            },
            76854: function(e, t, n) {
                n(10287), n(26099), n(3362), n(51629), n(23500), n(2008), n(74423), n(72712);
                var r, i, a = n(65297),
                    o = n(6696),
                    s = n(73090),
                    c = n(31709),
                    u = n(41298),
                    l = n(25093);

                function d(e, t) {
                    return d = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, d(e, t)
                }! function(e) {
                    e.CHANGE_CHAT_UNBLOCKERS = "CHANGE_CHAT_UNBLOCKERS", e.CHANGE_CRUSHES = "CHANGE_CRUSHES", e.CHANGE_EXTRA_SHOWS = "CHANGE_EXTRA_SHOWS"
                }(i || (i = {}));
                var p = [12, 2, 13],
                    f = ((r = {})[12] = i.CHANGE_CHAT_UNBLOCKERS, r[2] = i.CHANGE_CRUSHES, r[13] = i.CHANGE_EXTRA_SHOWS, r),
                    h = function(e) {
                        var t, n;

                        function r() {
                            var t;
                            return (t = e.call(this, {
                                get: {
                                    message: 573,
                                    response: 574
                                }
                            }, {
                                commitCache: !1,
                                name: "ConsumablesModel",
                                useCache: !1
                            }) || this).consumablesBalance = g(), t.loadBalancePromise = (0, u.A)(Promise.resolve({})), t
                        }
                        n = e, (t = r).prototype = Object.create(n.prototype), t.prototype.constructor = t, d(t, n), r.getInstance = function() {
                            return r.instance || (r.instance = new r), r.instance
                        };
                        var i = r.prototype;
                        return i.init = function() {
                            var t = this;
                            return e.prototype.init.call(this), c.aV.onResponse(574, (function(e) {
                                t.updateBalances(e)
                            })), a.A.on(a.A.Session.SESSION_CHANGED, (function(e) {
                                e.isLoggedIn ? t.preloadConsumables() : t.resetBalances()
                            })), this.preloadConsumables(), this
                        }, i.resetBalances = function() {
                            this.consumablesBalance = g()
                        }, i.preloadConsumables = function() {
                            var t = this;
                            if (s.A.isLoggedIn()) {
                                var n = {
                                    types: p
                                };
                                this.loadBalancePromise = e.prototype.get.call(this, n), this.loadBalancePromise.then((function(e) {
                                    t.updateBalances(e)
                                })).catch((function(e) {
                                    (0, l.A)(e) && t.log.error("Error preloading the consumables balances", {
                                        error: e
                                    })
                                }))
                            }
                        }, i.updateBalances = function(e) {
                            var t = this,
                                n = function(e) {
                                    if (!e) return [];
                                    return (e.balances || []).filter((function(e) {
                                        return Boolean(e.type && p.includes(e.type))
                                    }))
                                }(e);
                            0 !== n.length && n.forEach((function(e) {
                                t.updateBalanceByType(e, e.type)
                            }))
                        }, i.updateBalanceByType = function(e, t) {
                            var n, r, i, a, o = this.consumablesBalance[t],
                                s = null != (n = null == o ? void 0 : o.balance_ts) ? n : 0,
                                c = null != (r = null == e ? void 0 : e.balance_ts) ? r : 0,
                                u = null != (i = null == o ? void 0 : o.value) ? i : 0,
                                l = null != (a = null == e ? void 0 : e.value) ? a : 0;
                            c > s && (this.consumablesBalance[t] = e, u !== l && this.trigger(f[t], e))
                        }, i.getBalanceValue = function(e) {
                            return this.consumablesBalance[e].value || 0
                        }, i.getCurrentChatBlockers = function() {
                            return this.getBalanceValue(12)
                        }, i.getCurrentCrushes = function() {
                            return this.getBalanceValue(2)
                        }, i.getCurrentExtraShows = function() {
                            return this.getBalanceValue(13)
                        }, i.hasConsumableForProductType = function(e) {
                            switch (e) {
                                case 44:
                                case 46:
                                    return this.getCurrentChatBlockers() > 0;
                                case 50:
                                case 6:
                                    return this.getCurrentExtraShows() > 0;
                                case 49:
                                case 25:
                                    return this.getCurrentCrushes() > 0;
                                default:
                                    return !1
                            }
                        }, r
                    }(o.A);

                function g() {
                    return p.reduce((function(e, t) {
                        return e[t] = {
                            balance_ts: 0,
                            type: t,
                            value: 0
                        }, e
                    }), {})
                }
                h.EVENTS = i, h.instance = null, h.getInstance(), t.A = h
            },
            83771: function(e, t, n) {
                n(10287);
                var r, i = n(6696);

                function a(e, t) {
                    return a = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, a(e, t)
                }! function(e) {
                    e.INVALIDATED = "invalidated"
                }(r || (r = {}));
                var o = function(e) {
                    var t, n;

                    function i() {
                        return e.call(this, {
                            get: {
                                message: 418,
                                response: 419
                            }
                        }, {
                            name: "PopularityModel",
                            useCache: !1
                        }) || this
                    }
                    return n = e, (t = i).prototype = Object.create(n.prototype), t.prototype.constructor = t, a(t, n), i.prototype.invalidate = function() {
                        this.trigger(r.INVALIDATED)
                    }, i
                }(i.A);
                o.EVENTS = r, o.instance = null, o.getInstance = function() {
                    return o.instance || (o.instance = new o), o.instance
                }, t.A = o
            },
            84932: function(e, t, n) {
                n(45700), n(89572), n(52675), n(89463), n(26099), n(2892), n(84185), n(79432), n(2008), n(83851), n(51629), n(23500), n(81278), n(67945);
                var r = n(51709),
                    i = n(33702),
                    a = n(14680),
                    o = n(74848);

                function s(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function c(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? s(Object(n), !0).forEach((function(t) {
                            u(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function u(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                t.A = function(e) {
                    var t = (0, r.iD)(e),
                        n = t.a11y,
                        s = t.ids,
                        u = t.labelProps;
                    return (0, o.jsxs)(a.A, c(c(c({}, e), s), {}, {
                        label: u.label,
                        children: [(0, o.jsx)(i.A, c(c(c(c({}, e), s), (0, r.$E)(e.preset, e)), {}, {
                            status: Boolean(e.errorMessage) || e.isInvalid ? "error" : void 0,
                            a11y: c(c({}, n), {}, {
                                ariaRequired: u.ariaRequired
                            })
                        })), e.extraContent]
                    }))
                }
            },
            86812: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return s
                    },
                    y: function() {
                        return o
                    }
                });
                var r = n(19276),
                    i = n(17412),
                    a = n(4803),
                    o = function(e) {
                        return (null == e ? void 0 : e.errorCode) === r.A.ERROR_CODES.PAYMENTS_WITH_CURRENT_CARD_CHECK_FAILED
                    },
                    s = function(e) {
                        return (0, a.W)(e) ? i.qR.PROVIDER_PLAID : void 0
                    }
            },
            87574: function(e, t, n) {
                n.d(t, {
                    YM: function() {
                        return T
                    },
                    vh: function() {
                        return x
                    },
                    LZ: function() {
                        return k
                    }
                });
                n(62062), n(45700), n(89572), n(52675), n(89463), n(26099), n(2892), n(84185), n(79432), n(2008), n(83851), n(51629), n(23500), n(81278), n(67945);
                var r = n(96540),
                    i = n(56217),
                    a = (n(50113), n(72537)),
                    o = function(e) {
                        var t = a.A.getSync(415);
                        return Boolean(e.isDoubleCredits) || t.enabled ? e.previous_display_name : void 0
                    };

                function s(e) {
                    var t, n, r, i;
                    return {
                        badge: e.badge,
                        displayName: e.display_name || "",
                        displayPrice: e.display_price || "",
                        isDoubleCredits: Boolean(e.isDoubleCredits),
                        isTopUpAvailable: e.is_top_up_possible || !1,
                        isTopUpEnabled: e.top_up_default_state || !1,
                        previousDisplayName: o(e),
                        previousDisplayPrice: e.previous_display_price,
                        pricePerUnit: e.price_per_unit,
                        savedPaymentText: e.saved_payment_text,
                        shortTnc: e.short_tnc,
                        paywallUiFooterText: (null == (n = e, i = (n.ui || []).find((function(e) {
                            return "paywall_ui_footer" === e.ref
                        })), t = null == i || null == (r = i.children) ? void 0 : r.find((function(e) {
                            return "paywall_ui_footer_content" === e.ref
                        }))) ? void 0 : t.text) || "",
                        uid: e.uid,
                        unitName: e.unit_name || ""
                    }
                }
                var c = n(68251);

                function u(e, t) {
                    var n = t && 8 !== t;
                    return 1 === e ? n ? c.G.SPP_CONTEXTUAL : c.G.SPP : 47 === e ? n || t && 557 !== t ? c.G.PREMIUM_PLUS_CONTEXTUAL : c.G.PREMIUM_PLUS : e && 13 !== e || 12 === e ? c.G.CREDITS_CONTEXTUAL : 13 === e ? c.G.CREDITS : c.G.CREDITS_CONTEXTUAL
                }
                var l = n(49711);

                function d(e) {
                    switch (e) {
                        case 66:
                            return l.P.EXTRA;
                        case 1:
                        case 23:
                            return l.P.SPP;
                        case 47:
                            return l.P.PREMIUM_PLUS;
                        default:
                            return l.P.DEFAULT
                    }
                }
                var p = n(30245),
                    f = (n(26910), n(69079));

                function h(e, t) {
                    var n = [];
                    return e ? (e.forEach((function(e) {
                        var r, i = (e.providers || []).find((function(e) {
                            return e.provider_id === t
                        }));
                        i && (i.uid = e.uid, i.isDoubleCredits = !!(r = e.options) && Boolean(r.find((function(e) {
                            return 3 === e
                        }))), n.push(i))
                    })), n.sort(f.e)) : n
                }
                var g = n(20140),
                    v = n(3208);
                var m = n(79880),
                    y = (n(72712), n(59244));

                function A(e, t) {
                    var n;
                    return 562 === t.promo_block_type ? ["badge-feature-special-delivery-premium-plus"] : (null == (n = t.pictures) ? void 0 : n.reduce((function(t, n) {
                        var r = (0, y.y)(n.badge_type, e);
                        return void 0 !== r && t.push(r), t
                    }), [])) || []
                }

                function P(e) {
                    var t, n = null == (t = e.pictures) ? void 0 : t.find((function(e) {
                        return 2 === e.badge_type
                    }));
                    return null == n ? void 0 : n.badge_text
                }

                function E(e, t) {
                    if (47 === e) return (t.buttons || []).find((function(e) {
                        return 3 === e.type
                    }))
                }
                n(27495);
                var _ = n(82531);

                function b(e) {
                    var t = d(e) === l.P.DEFAULT ? _.TOKEN_ICON_JUMBO_SIZE_SM : _.TOKEN_ICON_JUMBO_SIZE_MD;
                    return Number(t.replace("px", ""))
                }
                var T, S = n(78944),
                    I = n(70182),
                    C = n(31709),
                    O = n(74848);

                function R(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function w(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function D(e, t) {
                    var n = t || (null == e ? void 0 : e.default_provider_id),
                        r = h(null == e ? void 0 : e.products, n).map(s);
                    return r.length > 0 ? r : void 0
                }

                function L(e, t) {
                    var n;
                    return null == (n = function(e) {
                        if (e) return e.filter((function(e) {
                            return 10 === e.promo_block_position
                        }))
                    }(null == t ? void 0 : t.product_promos)) ? void 0 : n.map((function(t) {
                        return function(e, t) {
                            var n, r = e.promo_block_type;
                            return {
                                badges: A(t, e),
                                badgeText: P(e),
                                image: (0, m.A)(null == (n = e.pictures) ? void 0 : n[0].display_images, b(t)),
                                isDoubleCredits: 41 === r,
                                linkCta: E(t, e),
                                message: e.mssg || "",
                                pictures: e.pictures,
                                timer: e.timer,
                                title: e.header || "",
                                type: r
                            }
                        }(t, e)
                    }))
                }

                function U(e) {
                    var t;
                    e.selectedProduct || (e.selectedProduct = null == (t = e.paywallData) || null == (t = t.products) ? void 0 : t[0])
                }

                function N(e) {
                    var t = e || {},
                        n = t.paywallData,
                        r = t.promoBlocksData,
                        a = t.productType,
                        o = t.promoBlockType,
                        s = I.A.get(),
                        c = s.initialProductType,
                        l = s.methodOfPayment,
                        f = s.product,
                        h = void 0,
                        m = void 0;
                    if (l && f) h = f, m = l;
                    else if (n) {
                        var y = n.default_provider_id;
                        m = (0, g.U)(n.provider_name, y);
                        var A = (0, i.H)(n.provider_name, y);
                        h = (0, p.J)(n.products, A)
                    }
                    var P = {
                        initialProductType: c || a || 13,
                        isTopUpEnabled: !1,
                        paywallData: n,
                        paywallInteraction: new S.V({
                            Rpc: C.Ay
                        }),
                        paywallType: d(a),
                        products: D(n),
                        productType: a || 13,
                        promoBlocks: L(a || 13, r),
                        promoBlocksData: r,
                        selectedProduct: h,
                        selectedProvider: m,
                        screenMode: u(a, o),
                        uniqueFlowId: v.A.get(),
                        deviceProfilingId: void 0
                    };
                    return U(P), P
                }! function(e) {
                    e.UPDATE_AUTO_TOP_UP = "UPDATE_AUTO_TOP_UP", e.UPDATE_PAYWALL_DATA = "UPDATE_PAYWALL_DATA", e.UPDATE_PRODUCT_TYPE = "UPDATE_PRODUCT_TYPE", e.UPDATE_PROMO_BLOCKS_DATA = "UPDATE_PROMO_BLOCKS_DATA", e.UPDATE_SELECTED_PRODUCT = "UPDATE_SELECTED_PRODUCT", e.UPDATE_SELECTED_PROVIDER = "UPDATE_SELECTED_PROVIDER", e.UPDATE_UNIQUE_FLOW_ID = "UPDATE_UNIQUE_FLOW_ID", e.UPDATE_DEVICE_PROFILING_ID = "UPDATE_DEVICE_PROFILING_ID"
                }(T || (T = {}));
                var j = (0, r.createContext)({
                    state: N(),
                    dispatch: function() {}
                });

                function M(e, t) {
                    var n = function(e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var n = null != arguments[t] ? arguments[t] : {};
                            t % 2 ? R(Object(n), !0).forEach((function(t) {
                                w(e, t, n[t])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : R(Object(n)).forEach((function(t) {
                                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                            }))
                        }
                        return e
                    }({}, e);
                    switch (t.type) {
                        case T.UPDATE_AUTO_TOP_UP:
                            n.isTopUpEnabled = t.value;
                            break;
                        case T.UPDATE_PAYWALL_DATA:
                            var r = t.value;
                            if (n.paywallInteraction.setIdentifier(null == r ? void 0 : r.identifier).setProductType(null == r ? void 0 : r.product_type).setViewMode(null == r ? void 0 : r.view_mode), n.paywallData = r, r) {
                                var a = (0, g.U)(r.provider_name, r.default_provider_id);
                                n = M(n, {
                                    type: T.UPDATE_SELECTED_PROVIDER,
                                    value: a
                                })
                            }
                            break;
                        case T.UPDATE_PRODUCT_TYPE:
                            n.paywallType = d(t.value), n.productType = t.value;
                            break;
                        case T.UPDATE_PROMO_BLOCKS_DATA:
                            n.promoBlocksData = t.value, n.promoBlocks = L(n.productType, t.value);
                            break;
                        case T.UPDATE_SELECTED_PRODUCT:
                            n.selectedProduct = t.value, U(n);
                            break;
                        case T.UPDATE_SELECTED_PROVIDER:
                            var o, s, c;
                            n.selectedProvider = t.value;
                            var u = null == (o = t.value) ? void 0 : o.provider_id;
                            n.products = D(n.paywallData, u);
                            var l = (0, i.H)(null == (s = n.paywallData) ? void 0 : s.provider_name, u);
                            n = M(n, {
                                type: T.UPDATE_SELECTED_PRODUCT,
                                value: (0, p.J)(null == (c = n.paywallData) ? void 0 : c.products, l)
                            });
                            break;
                        case T.UPDATE_UNIQUE_FLOW_ID:
                            n.uniqueFlowId = t.value;
                            break;
                        case T.UPDATE_DEVICE_PROFILING_ID:
                            n.deviceProfilingId = t.value;
                            break;
                        default:
                            throw new Error("PaywallContext: Unhandled action type")
                    }
                    return n
                }
                var x = function(e) {
                    var t = (0, r.useReducer)(M, N(e)),
                        n = {
                            state: t[0],
                            dispatch: t[1]
                        };
                    return (0, O.jsx)(j.Provider, {
                        value: n,
                        children: e.children
                    })
                };

                function k() {
                    var e = (0, r.useContext)(j);
                    if (void 0 === e) throw new Error("usePaywallContext must be used within a PaywallContextProvider");
                    return e
                }
            },
            91258: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return J
                    }
                });
                var r = n(40075),
                    i = n(47901),
                    a = n(15376),
                    o = n(99795),
                    s = n(28733),
                    c = n(89769),
                    u = n(94318),
                    l = n(12501),
                    d = n(74848),
                    p = function(e) {
                        var t = e.title,
                            n = e.onNavigateBack,
                            p = e.children;
                        return (0, d.jsx)("div", {
                            className: "open-banking__screen",
                            children: (0, d.jsxs)(i.A, {
                                children: [(0, d.jsx)(a.A, {
                                    children: (0, d.jsxs)(o.A, {
                                        children: [(0, d.jsx)(s.A, {
                                            isWide: !0,
                                            children: (0, d.jsx)(u.A, {
                                                name: "navigation-bar-back",
                                                onClick: n,
                                                a11y: {
                                                    iconLabel: r.Ay.get(268)
                                                }
                                            })
                                        }), (0, d.jsx)(l.A, {
                                            text: t
                                        }), (0, d.jsx)(c.A, {
                                            isWide: !0
                                        })]
                                    })
                                }), p]
                            })
                        })
                    },
                    f = function(e) {
                        var t = e.height,
                            n = e.width;
                        return (0, d.jsxs)("svg", {
                            width: n || 43,
                            height: t || 16,
                            viewBox: "0 0 43 16",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: [(0, d.jsx)("path", {
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M22.4332 5.48287C22.0753 5.18324 21.4644 5.0336 20.6002 5.0336H18.6511V11.0288H20.1086V9.1498H20.7614C21.5538 9.1498 22.1349 8.97622 22.5047 8.62874C22.9212 8.23947 23.1308 7.72111 23.1308 7.074C23.1308 6.40297 22.8981 5.87248 22.4332 5.48287ZM20.7252 7.79323H20.1086V6.39016H20.6626C21.3364 6.39016 21.6733 6.62541 21.6733 7.09591C21.6733 7.56034 21.3571 7.7929 20.7252 7.7929V7.79323ZM25.6248 5.03326H24.105V11.0284H27.3863V9.67152H25.6248V5.03326ZM30.3638 5.03326L27.9765 11.0284H29.6127L29.9256 10.1569H32L32.2862 11.0284H33.9407L31.5703 5.03326H30.3638ZM30.3459 8.94319L30.972 6.89403L31.5883 8.94319H30.3455H30.3459Z",
                                fill: "#767676"
                            }), (0, d.jsx)("mask", {
                                id: "mask0_3379_504",
                                style: {
                                    maskType: "alpha"
                                },
                                maskUnits: "userSpaceOnUse",
                                x: "0",
                                y: "0",
                                width: n || 43,
                                height: t || 16,
                                children: (0, d.jsx)("path", {
                                    d: "M0 16H42.6667V0H0V16Z",
                                    fill: "white"
                                })
                            }), (0, d.jsx)("g", {
                                mask: "url(#mask0_3379_504)",
                                children: (0, d.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M34.6999 11.0284H36.2199V5.03326H34.6999V11.0284ZM42.1215 6.15693C41.9295 5.87984 41.6829 5.64444 41.3968 5.465C40.938 5.17717 40.3119 5.0336 39.5192 5.0336H37.5165V11.0284H39.8591C40.7057 11.0284 41.385 10.7531 41.8976 10.2017C42.4103 9.65062 42.6663 8.91926 42.6663 8.00826C42.6663 7.28364 42.4845 6.66653 42.1211 6.15693H42.1215ZM39.6891 9.67118H39.0366V6.3905H39.6983C40.1632 6.3905 40.5205 6.53542 40.771 6.82426C41.0216 7.1131 41.1469 7.52293 41.1469 8.05342C41.1469 9.13193 40.661 9.67118 39.6891 9.67118ZM6.31094 0L1.38497 1.2841L0.0274286 6.21456L1.72529 7.94961L0 9.65602L1.27763 14.6081L6.18226 15.972L7.90789 14.2653L9.60576 16L14.5317 14.7159L15.8889 9.7851L14.1914 8.05072L15.9167 6.34432L14.6391 1.39195L9.73376 0.0279738L8.0088 1.73438L6.31094 0ZM3.28804 2.23251L5.88292 1.55575L7.01765 2.71514L5.36279 4.35178L3.28804 2.23251ZM8.98438 2.73065L10.1374 1.59046L12.7211 2.30902L10.6125 4.39425L8.98438 2.73065ZM1.58205 5.80979L2.29689 3.21294L4.37096 5.33221L2.71644 6.96885L1.58205 5.80945V5.80979ZM11.5874 5.39085L13.696 3.30495L14.3685 5.91359L13.2158 7.05412L11.5874 5.39085ZM6.33803 5.34805L7.99289 3.71142L9.62066 5.37501L7.96614 7.01165L6.33803 5.34805ZM3.69202 7.96512L5.34654 6.32848L6.97532 7.99208L5.32013 9.62872L3.69202 7.96512ZM8.94171 8.00792L10.5962 6.37128L12.2243 8.03488L10.5695 9.67152L8.94171 8.00792ZM1.54751 10.0864L2.70087 8.94555L4.32863 10.6095L2.2207 12.6944L1.54751 10.0864ZM6.29536 10.625L7.95022 8.98835L9.57833 10.6519L7.92381 12.2886L6.29536 10.625ZM11.5447 10.6681L13.1996 9.03149L14.3343 10.1906L13.6198 12.7874L11.5447 10.6681ZM3.1956 13.6913L5.30387 11.6054L6.93266 13.269L5.7793 14.4099L3.1956 13.691V13.6913ZM8.89905 13.2849L10.5536 11.6482L12.628 13.7678L10.0334 14.4443L8.89905 13.2849Z",
                                    fill: "#767676"
                                })
                            })]
                        })
                    },
                    h = (n(62062), n(96540)),
                    g = n(20017),
                    v = n(87908),
                    m = n(87184),
                    y = n(11611),
                    A = n(47667),
                    P = n(93827),
                    E = n(30559),
                    _ = n(26914),
                    b = n(55105),
                    T = n(51709),
                    S = function(e) {
                        var t = (0, h.useMemo)((function() {
                                return r.Ay.get(464)
                            }), []),
                            n = (0, h.useMemo)((function() {
                                return r.Ay.get(472)
                            }), []),
                            i = (0, h.useState)(""),
                            a = i[0],
                            o = i[1],
                            s = (0, h.useState)(!0),
                            c = s[0],
                            u = s[1],
                            l = e.institutions,
                            p = e.onSelectInstitution,
                            f = e.onSearchInstitution;
                        (0, h.useEffect)((function() {
                            f(a), u("" === a)
                        }), [f, a]);
                        var S = l;
                        return l && c && (S = null == l ? void 0 : l.slice(0, 8)), (0, d.jsxs)(m.A, {
                            children: [(0, d.jsx)(v.A, {
                                hpadded: !0,
                                isSticky: !0,
                                children: (0, d.jsx)("div", {
                                    className: "open-banking-institutions__search",
                                    children: (0, d.jsx)(y.A, {
                                        a11y: {
                                            clearLabel: n,
                                            inputId: "open-banking-search-input",
                                            inputLabel: t
                                        },
                                        onChange: function(e) {
                                            o(e.target.value)
                                        },
                                        value: a,
                                        showClear: a.length > 0,
                                        onClear: function() {
                                            return o("")
                                        },
                                        onSubmit: function(e) {
                                            return (0, T.Y4)(e, (function() {
                                                return o(a)
                                            }))
                                        }
                                    })
                                })
                            }), S ? (0, d.jsxs)(d.Fragment, {
                                children: [S.map((function(e) {
                                    return (0, d.jsx)(A.A, {
                                        onClick: function() {
                                            return p(e)
                                        },
                                        color: "white",
                                        content: (0, d.jsxs)(d.Fragment, {
                                            children: [(0, d.jsx)(P.P1, {
                                                weight: "bolder",
                                                children: e.name
                                            }), (0, d.jsx)(P.P3, {
                                                color: "gray-80",
                                                children: e.url
                                            })]
                                        }),
                                        media: (0, d.jsx)(E.A, {
                                            children: (0, d.jsx)("div", {
                                                className: "open-banking-logo",
                                                children: (0, d.jsx)(_.A, {
                                                    size: "xxsm",
                                                    image: {
                                                        src: "data:image/png;base64, " + e.logo
                                                    }
                                                })
                                            })
                                        }),
                                        mediaAlign: "center"
                                    }, e.id)
                                })), c ? (0, d.jsx)(v.A, {
                                    hpadded: !0,
                                    isSticky: !0,
                                    align: "bottom",
                                    children: (0, d.jsx)("div", {
                                        className: "open-banking-institutions__show-all",
                                        children: (0, d.jsx)(g.A, {
                                            text: r.Ay.get(681),
                                            size: "small",
                                            narrow: !0,
                                            onClick: function() {
                                                u(!1)
                                            }
                                        })
                                    })
                                }) : null]
                            }) : (0, d.jsx)(b.A, {})]
                        })
                    },
                    I = n(11734),
                    C = n(3508),
                    O = n(4571),
                    R = n(51634),
                    w = n(27895),
                    D = n(40578),
                    L = function(e) {
                        var t = e.label,
                            n = e.value;
                        return n ? (0, d.jsxs)("div", {
                            className: "open-banking-order-label",
                            children: [(0, d.jsx)("div", {
                                className: "open-banking-order-label__key",
                                children: (0, d.jsx)(P.P2, {
                                    inline: !0,
                                    align: "left",
                                    color: "gray-80",
                                    children: t
                                })
                            }), (0, d.jsx)(P.P1, {
                                align: "right",
                                children: n
                            })]
                        }) : null
                    },
                    U = n(32483),
                    N = n(73160),
                    j = n(74389),
                    M = "https://" + C.A.get("partner_url"),
                    x = M + "/" + j.x.PRIVACY,
                    k = M + "/" + j.x.TERMS,
                    F = function(e) {
                        var t = e.orderParams,
                            n = t.accountProviderName,
                            i = t.amount,
                            a = t.bacsAccount,
                            o = t.bacsSortCode,
                            s = t.payeeName,
                            c = e.confirmationStatus,
                            u = e.providerLogo;
                        return (0, d.jsxs)(O.A, {
                            align: "center",
                            isCompact: !0,
                            children: [c ? (0, d.jsxs)(d.Fragment, {
                                children: [(0, d.jsx)(w.A, {
                                    children: (0, d.jsx)(_.A, {
                                        size: "sm",
                                        icon: {
                                            name: "success" === c ? "badge-check" : "badge-cross"
                                        }
                                    })
                                }), (0, d.jsx)(D.A, {
                                    isCompact: !0,
                                    text: "success" === c ? r.Ay.get(678) : r.Ay.get(677)
                                })]
                            }) : null, (0, d.jsxs)(R.A, {
                                width: "stretch",
                                children: [c ? (0, d.jsx)("hr", {
                                    className: "open-banking-order-details__seperator"
                                }) : null, (0, d.jsx)(L, {
                                    label: r.Ay.get(671),
                                    value: i
                                }), (0, d.jsx)(L, {
                                    label: r.Ay.get(674),
                                    value: s
                                }), (0, d.jsx)(L, {
                                    label: r.Ay.get(675),
                                    value: a
                                }), (0, d.jsx)(L, {
                                    label: r.Ay.get(676),
                                    value: o
                                }), (0, d.jsx)(L, {
                                    label: r.Ay.get(670),
                                    value: n
                                }), c ? null : (0, d.jsxs)(h.Fragment, {
                                    children: [(0, d.jsx)("hr", {
                                        className: "open-banking-order-details__seperator"
                                    }), (0, d.jsx)("div", {
                                        className: "open-banking-order-details__legal-text",
                                        children: (0, d.jsx)(U.A, {
                                            children: (0, d.jsx)(N.A, {
                                                routingMapping: {
                                                    "#privacy": {
                                                        href: x,
                                                        target: "_blank"
                                                    },
                                                    "#terms": {
                                                        href: k,
                                                        target: "_blank"
                                                    },
                                                    "#plaid_terms": {
                                                        href: "https://plaid.com/legal/#end-user-privacy-policy",
                                                        target: "_blank"
                                                    }
                                                },
                                                text: r.Ay.get(673)
                                            })
                                        })
                                    }), (0, d.jsxs)("div", {
                                        className: "open-banking-order-details__provider",
                                        children: [(0, d.jsx)(U.A, {
                                            children: r.Ay.get(679)
                                        }), u]
                                    })]
                                })]
                            })]
                        })
                    },
                    B = function(e) {
                        var t = e.orderParams,
                            n = e.onClick,
                            i = e.confirmationStatus,
                            a = e.isReadyForConnection,
                            o = e.returnToDestination,
                            s = e.providerLogo;
                        return (0, d.jsxs)(h.Fragment, {
                            children: [(0, d.jsx)(m.A, {
                                hpadded: !0,
                                vpadded: !0,
                                align: "stretch",
                                children: (0, d.jsx)(F, {
                                    orderParams: t,
                                    confirmationStatus: i,
                                    providerLogo: s
                                })
                            }), (0, d.jsx)(I.A, {
                                hpadded: !0,
                                vpadded: !0,
                                children: i ? "success" === i ? (0, d.jsx)(g.A, {
                                    onClick: o,
                                    text: r.Ay.get(672)
                                }) : null : (0, d.jsx)(g.A, {
                                    onClick: n,
                                    text: r.Ay.get(457),
                                    isLoading: !a
                                })
                            })]
                        })
                    },
                    H = (n(2008), n(26099), n(74423), n(21699), n(45700), n(89572), n(52675), n(89463), n(2892), n(84185), n(79432), n(83851), n(51629), n(23500), n(81278), n(67945), n(24947)),
                    G = n(58385),
                    V = n(93529),
                    W = n(99562),
                    Y = n(49683),
                    q = n(18084);

                function Q(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function K(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? Q(Object(n), !0).forEach((function(t) {
                            X(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Q(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function X(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function z(e) {
                    var t, n = e.paymentOptions,
                        r = e.onReturn,
                        i = (0, h.useState)(!1),
                        a = i[0],
                        o = i[1],
                        s = (0, h.useState)(),
                        c = s[0],
                        u = s[1],
                        l = (0, h.useState)(),
                        d = l[0],
                        p = l[1],
                        f = (0, h.useState)(),
                        g = f[0],
                        v = f[1],
                        m = (0, h.useState)(""),
                        y = m[0],
                        A = m[1],
                        P = (0, h.useRef)(q.A.getLogger("usePlaidInstitutions")),
                        E = (0, H.usePlaidLink)({
                            token: null == g || null == (t = g.plaid_params) ? void 0 : t.link_token,
                            onSuccess: function() {
                                Y.A.getInstance().sendReceipt({
                                    payment_success: !0,
                                    transaction_identifier: null == g ? void 0 : g.transaction_id
                                }), u("success")
                            },
                            onExit: function() {
                                Y.A.getInstance().sendReceipt({
                                    payment_success: !1,
                                    transaction_identifier: null == g ? void 0 : g.transaction_id
                                }), u("fail")
                            }
                        }),
                        _ = E.open,
                        b = E.ready,
                        T = (0, h.useMemo)((function() {
                            var e;
                            return y ? null == d || null == (e = d.plaid_institutions) ? void 0 : e.filter((function(e) {
                                var t;
                                return null == (t = e.name) ? void 0 : t.toLocaleLowerCase().includes(y.toLocaleLowerCase())
                            })) : null == d ? void 0 : d.plaid_institutions
                        }), [d, y]);
                    (0, h.useEffect)((function() {
                        (0, W.Y)({
                            requestType: 889,
                            responseType: 890
                        }).then((function(e) {
                            p(e)
                        })).catch((function(e) {
                            P.current.error(e)
                        }))
                    }), []);
                    return {
                        isLoading: a,
                        isReadyForConnection: b,
                        confirmationStatus: c,
                        institutions: T,
                        purchaseTransaction: g,
                        searchTerm: y,
                        handleBankSelected: function(e) {
                            o(!0), Y.A.getInstance().startTransaction(K(K({}, n), {}, {
                                plaidInstitutionId: e.id
                            }), (function(e) {
                                var t = e.error,
                                    n = e.purchaseTransactionFailed;
                                if (t || !e.purchaseTransaction) {
                                    var i, a, s;
                                    if (n && (0, Y.i)(e)) i = null == (s = n.form_error) || null == (s = s.failure) ? void 0 : s.error_message, a = function() {
                                        return G.A.navigate(j.x.ADD_PHOTOS, {
                                            backHistoryEntry: G.A.getHistoryEntryId(),
                                            destination: G.A.getUrl()
                                        })
                                    };
                                    else null != n && n.notification && (i = n.notification.message);
                                    i && V.A.showNotification({
                                            type: V.A.TYPES.ERROR,
                                            text: i
                                        }), e.error = e.error || new Error("Not able to purchase using Plaid"),
                                        function(e) {
                                            r(), e && e()
                                        }(a)
                                }
                                v(e.purchaseTransaction), o(!1)
                            }))
                        },
                        handleSearchTermChanged: A,
                        handleStartFlow: function() {
                            b && _()
                        }
                    }
                }
                var Z = function(e) {
                        return {
                            accountProviderName: e.plaid_params.account_provider_name,
                            amount: e.plaid_params.amount,
                            bacsAccount: e.plaid_params.bacs_account,
                            bacsSortCode: e.plaid_params.bacs_sort_code,
                            linkToken: e.plaid_params.link_token,
                            payeeName: e.plaid_params.payee_name,
                            reference: e.plaid_params.reference
                        }
                    },
                    J = function(e) {
                        var t = e.paymentOptions,
                            n = e.onReturn,
                            i = z({
                                paymentOptions: t,
                                onReturn: n
                            }),
                            a = i.isLoading,
                            o = i.isReadyForConnection,
                            s = i.confirmationStatus,
                            c = i.institutions,
                            u = i.purchaseTransaction,
                            l = i.handleBankSelected,
                            h = i.handleSearchTermChanged,
                            g = i.handleStartFlow,
                            v = function() {
                                n()
                            };
                        return (0, d.jsx)(p, {
                            title: u ? r.Ay.get(82) : r.Ay.get(680),
                            onNavigateBack: v,
                            children: a ? (0, d.jsx)(b.A, {}) : u ? (0, d.jsx)(B, {
                                onClick: g,
                                returnToDestination: v,
                                orderParams: Z(u),
                                confirmationStatus: s,
                                isReadyForConnection: o,
                                providerLogo: (0, d.jsx)(f, {})
                            }) : (0, d.jsx)(S, {
                                onSelectInstitution: l,
                                institutions: c,
                                onSearchInstitution: h
                            })
                        })
                    }
            },
            98819: function(e, t, n) {
                n(23792), n(26099), n(3362), n(47764), n(62953), n(51629), n(23500), n(79432), n(2892), n(50113), n(25276), n(48980), n(11392), n(42762), n(27495);
                var r = n(23735),
                    i = n(35837),
                    a = n(74022),
                    o = n(38795),
                    s = n(1978),
                    c = n(47344),
                    u = n(57917),
                    l = n(73090),
                    d = n(23715),
                    p = n(58336),
                    f = n(26935),
                    h = n(75248),
                    g = n(41298),
                    v = n(25093),
                    m = n(65297),
                    y = n(254),
                    A = n(18826),
                    P = n(15566),
                    E = (0, p.A)("FLUSH", "HISTORY_UPDATED", "IS_WRITING", "MESSAGE_DELETED", "MESSAGE_FROM_ME", "MESSAGE_FROM_USER", "MESSAGES_READ", "NEW_MESSAGE_READ", "NEW_OFFLINE_MESSAGE", "CHAT_PROMO_HANDLED", "INPUT_FOCUSED", "SETTINGS_UPDATED"),
                    _ = {},
                    b = u.A.extend({
                        name: "Chat",
                        EVENTS: E,
                        commitCache: !1,
                        pendingPaidMessages_: [],
                        offlinePendingMessages: [],
                        getRequestMessageType: 102,
                        getResponseMessageType: [103],
                        setRequestMessageType: 104,
                        setResponseMessageType: (0, r.jU)(151, 1),
                        preventMultiple: !0,
                        watch_: {},
                        messagesToDelete: {},
                        init_: function() {
                            var e = this;
                            this.throttledSendReadTimestamp = (0, a.A)(this.sendReadTimestamp.bind(this), 500), d.A.on(d.A.EVENTS.ONLINE, this.sync_, this), m.A.on("push-sync", this.sync_, this), m.A.on(m.A.Session.LOGOUT, this.invalidateAll, this), h.A.getInstance().on(h.A.Type.CHAT_MESSAGE_RECEIVED, (function(t) {
                                e.checkPendingPaidMessages_((0, i.A)(t, P.bF6))
                            })).on(h.A.Type.CHAT_MESSAGE, (function(t) {
                                e.onChatMessageReceived_((0, i.A)(t, P.cMz))
                            })).on(h.A.Type.CHAT_MESSAGE_READ, this.onChatMessageRead_, this).on(h.A.Type.CHAT_IS_WRITING, this.onChatIsWriting_, this).on(h.A.Type.SYSTEM_NOTIFICATION, this.onSystemNotification_, this).on(h.A.Type.CHAT_SETTINGS, (function(t) {
                                return e.trigger(E.SETTINGS_UPDATED, t)
                            }), this)
                        },
                        sync_: function() {
                            for (var e = this, t = []; this.offlinePendingMessages.length;) {
                                var n = this.offlinePendingMessages.shift();
                                t.push(this.send(n.toPersonId, n))
                            }
                            Promise.all(t).then((function() {
                                Object.keys(e.watch_).forEach((function(t) {
                                    A.A.read({
                                        userId: t
                                    }).dummy ? e.trigger(E.FLUSH) : e.loadNewChatMessages_(t)
                                }))
                            }))
                        },
                        ignoreUser: function(e) {
                            delete this.watch_[e]
                        },
                        loadNewChatMessages_: function(e) {
                            var t = this,
                                n = A.A.read({
                                    userId: e
                                });
                            if (n) {
                                var r = n.messages.length,
                                    i = (0, o.A)(n.messages, (function(e) {
                                        return !e.isTemporary()
                                    })),
                                    a = i && Number(i.id),
                                    s = {
                                        messageId: a
                                    };
                                a && this.getMessages(e, s).then((function(e) {
                                    r < e.length && t.trigger(E.MESSAGE_FROM_USER, e[0])
                                })).catch((function(n) {
                                    (0, v.A)(n) && t.log.error("loadNewChatMessages_::SERVER_GET_CHAT_MESSAGES", n, {
                                        userId: e
                                    }, s)
                                }))
                            }
                        },
                        watchUser: function(e) {
                            this.watch_[e] = !0
                        },
                        updatePrivateDetectorStatus: function(e, t) {
                            var n = (new P.eZb).setChatInstanceId(e).setEnable(t);
                            return this.fetch_(737, 360, n).then((function(t) {
                                var n = t[0];
                                A.A.update({
                                    userId: e,
                                    chatSettings: n
                                })
                            }))
                        },
                        markChatPromoHandled: function(e, t, n) {
                            A.A.markChatPromoHandled({
                                userId: e
                            }, t, n), this.trigger(E.CHAT_PROMO_HANDLED, t, n)
                        },
                        accessRequest: function(e, t, n) {
                            var r = this,
                                i = (new P.tUm).setAccessObject(t).setUserId(String(e));
                            return n && i.setVerificationAccessObject(n), this.fetch_(509, 105, i).then((function(e) {
                                var t = e[0];
                                if (t instanceof P.cMz) return r.onChatMessageReceived_(t)
                            }))
                        },
                        accessResponse: function(e) {
                            var t = this,
                                n = e.userId,
                                r = e.accessObject,
                                i = e.grant,
                                a = e.uid,
                                o = e.verificationAccessObject,
                                s = (new P.hBT).setAccessObject(r).setChatMessageUid(String(a)).setResponse(i ? 1 : 2).setUserId(String(n));
                            return o && s.setVerificationAccessObject(o), this.fetch_(510, 105, s).then((function(e) {
                                var n = e[0];
                                if (n instanceof P.cMz) return t.onChatMessageReceived_(n)
                            }))
                        },
                        add: function(e) {
                            if (A.A.update({
                                    chatMessage: e
                                }), C(e) ? this.trigger(E.MESSAGE_FROM_ME, e) : this.trigger(E.MESSAGE_FROM_USER, e), !d.A.isOnline()) {
                                var t = O(e),
                                    n = e instanceof y.Ay ? e.message : e.getMessage();
                                this.trigger(E.NEW_OFFLINE_MESSAGE, n, t.chatUser)
                            }
                            return this.triggerStreamDirectMessage_(e), e
                        },
                        checkPendingPaidMessages_: function(e) {
                            if (e instanceof P.bF6 && e.hasUid()) {
                                var t = this.pendingPaidMessages_.find((function(t) {
                                        return t.id === e.getUid()
                                    })),
                                    n = this.pendingPaidMessages_.indexOf(t);
                                if (t) return this.pendingPaidMessages_.splice(n, 1), e.getSuccess() ? t.resolve([e, null]) : t.reject(new Error("Failed to send paid chat message")), !0
                            }
                        },
                        revertAddMessage_: function(e, t) {
                            var n = A.A.read({
                                    chatMessage: e
                                }),
                                r = null == n ? void 0 : n.messages;
                            if (this.pendingPaidMessages_.length) {
                                var i = this.pendingPaidMessages_.findIndex((function(t) {
                                    return t.id === e.id
                                })); - 1 !== i && this.pendingPaidMessages_.splice(i, 1)
                            }
                            if (r) {
                                var a = r.findIndex((function(t) {
                                    return t.id === e.id
                                }));
                                if (-1 === a) return;
                                null != t && t.increaseMaxAnswers && A.A.increaseMaxAnswers({
                                    chatMessage: e
                                }), r.splice(a, 1)
                            }
                            this.trigger(E.MESSAGE_DELETED, e)
                        },
                        deleteChatMessage: function(e, t, n) {
                            var r = Promise.resolve();
                            t.startsWith(y.py) ? this.messagesToDelete[t] = {
                                reason: n
                            } : r = this.deleteChatMessageInServer(t, n);
                            var i = this.removeChatMessageFromStore(e, t),
                                a = i.messages,
                                o = i.index,
                                s = i.deletedMessage;
                            return r.catch((function(e) {
                                return a.splice(o, 0, s), e
                            }))
                        },
                        deleteChatMessageInServer: function(e, t) {
                            var n = (new P.Tcu).setUid(e).setDeleteReason(t);
                            return this.fetch_(373, 374, n).then((function(e) {
                                var t = e[0];
                                if (!t.getSuccess()) throw new Error("Not possible to delete chat message");
                                return t
                            }))
                        },
                        removeChatMessageFromStore: function(e, t) {
                            var n = A.A.read({
                                    userId: e
                                }).messages,
                                r = n.find((function(e) {
                                    return e.id === t
                                })),
                                i = n.indexOf(r);
                            return r && (n.splice(i, 1), this.trigger(E.MESSAGE_DELETED, r)), {
                                index: i,
                                messages: n,
                                deletedMessage: r
                            }
                        },
                        deleteInitialChatScreen: function(e) {
                            A.A.update({
                                userId: e,
                                initialScreen: null
                            })
                        },
                        reportUser: function(e) {
                            _[e] = !0
                        },
                        isUserReported: function(e) {
                            return _[e]
                        },
                        hasInitialChatScreen: function(e) {
                            return Boolean(this.getInitialChatScreen(e))
                        },
                        getInitialChatScreen: function(e) {
                            return A.A.read({
                                userId: e
                            }).initialScreen
                        },
                        cacheResponse_: function(e, t, n) {
                            var r = null == n ? void 0 : n[0];
                            return r instanceof P.eI_ ? A.A.update({
                                userId: e,
                                clientOpenChat: r
                            }) : n
                        },
                        getFromCache_: function() {
                            return null
                        },
                        getCachedClientOpenChat: O,
                        getSenderName: function(e) {
                            var t = e.fromPersonId;
                            if (l.A.getUserId() === t) return l.A.getUser().name;
                            return O(t).chatUser.getName()
                        },
                        isReplyFeatureAllowed: R,
                        getBlockingFeature: function(e) {
                            var t = this.getInitialChatScreen(e);
                            return null == t ? void 0 : t.blockingFeature
                        },
                        getPromoBlock: function(e, t) {
                            return A.A.read({
                                userId: e
                            }).promoBanners.find((function(e) {
                                return e.getPromoBlockType() === t
                            }))
                        },
                        getClientOpenChat: function(e, t) {
                            return !Number(e) && e.length < 20 && this.log.error("WRONG CHAT USER ID: " + e), d.A.isOnline() ? this.fetch(function(e, t) {
                                var n = (new P.Ad3).setChatInstanceId(e).setUserFieldFilter(T());
                                t && (t.allowConsumeChatUnblocker && n.setAllowConsumeChatUnblocker(t.allowConsumeChatUnblocker), "number" == typeof t.context && n.setContext(t.context), t.folderId && n.setFolderId(t.folderId), t.userType && n.setUserType(t.userType));
                                return n.setInitialScreenUserFieldFilter(S()), n
                            }(e, t)) : Promise.resolve(A.A.read({
                                userId: e
                            }))
                        },
                        getCacheKey_: function(e, t) {
                            return t instanceof P.Ad3 ? t.getChatInstanceId() : null
                        },
                        getMaxUnansweredMessages: function(e) {
                            return A.A.read({
                                userId: e
                            }).maxUnansweredMessages
                        },
                        getMessages: function(e, t) {
                            var n = this,
                                r = A.A.read({
                                    userId: e
                                }).chatInstanceId;
                            return this.fetch_(279, 280, function(e, t) {
                                return t = t || {}, new P.wTs({
                                    chat_instance_id: e,
                                    count: t.count,
                                    direction: t.direction,
                                    inclusive: t.inclusive || !1,
                                    message_id: t.messageId
                                })
                            }(r, t)).then((function(e) {
                                var t = e[0];
                                return n.updateChatMessages(t)
                            }))
                        },
                        getLastReadableMessage_: function(e, t) {
                            var n = A.A.read({
                                userId: e
                            }).messages;
                            return (0, o.A)(n, (function(e) {
                                return e.fromPersonId === t && 19 !== e.messageType
                            }))
                        },
                        send: function(e, t, n, r) {
                            if (this.messagesToDelete[t.id]) {
                                var i = (0, g.A)(Promise.resolve());
                                return i.cancel(), i
                            }
                            if (t.setStatus(t.STATUS.SENDING), !d.A.isOnline()) return -1 !== this.offlinePendingMessages.indexOf(t) || (this.offlinePendingMessages.push(t), this.add(t)), Promise.resolve(t);
                            var a = this.needToPayToSendMessage_(e, t) ? this.payToSend({
                                userId: e,
                                chatMessage: t,
                                backUrl: n,
                                redirectUrl: r
                            }) : this.set(t.toGPB());
                            return this.add(t), a.then(this.onSend_(e, t), this.onError_(t))
                        },
                        shouldCache_: function(e) {
                            return 555 !== e && this.useCache_
                        },
                        markMessageRead: function(e) {
                            this.updateTheirReadMessages_(e), e.setStatus(e.STATUS.READ)
                        },
                        likeMessage: function(e) {
                            var t = this,
                                n = e.isLiked,
                                r = e.messageType;
                            "EMOJI" === r && (r = 1);
                            var i = e.toGPB().setContext(e.context).setIsLiked(!n).setUid(e.id).setMessageType(r).setFromPersonId(e.fromPersonId).setToPersonId(e.toPersonId);
                            return this.fetch_(705, 151, i).then((function(n) {
                                var r = n[0];
                                if (!r || !r.getSuccess) throw new Error(new Error("No response received on message sent!"));
                                r.getSuccess() || t.onUpdateChatMessageError_(e), t.updateChatMessage_(e, r.getChatMessage().setRead(!0))
                            }))
                        },
                        sendQuestionsGameAnswer: function(e, t, n) {
                            var r = this,
                                i = (new P.vNH).setId(e.question.id).setText(e.question.text).setOwnAnswer(n ? t : e.question.own_answer).setOtherAnswer(n ? e.question.other_answer : t),
                                a = e.toGPB().setContext(e.context).setUid(e.id).setMessageType(50).setFromPersonId(e.fromPersonId).setToPersonId(e.toPersonId).setQuestion(i);
                            return this.fetch_(705, 151, a).then((function(t) {
                                var n = t[0];
                                if (!n) throw new Error(new Error("No response received on message sent!"));
                                n.getSuccess() || r.onUpdateChatMessageError_(e), r.updateChatMessage_(e, n.getChatMessage().setQuestion(i))
                            }), (function() {
                                r.onUpdateChatMessageError_(e)
                            }))
                        },
                        sendReadTimestamp: function(e) {
                            var t = A.A.read({
                                userId: e
                            });
                            this.fetch_(555, 387, (new P.eN$).setUserId(e).setReadTimestamp(t.readMessagesTimestamp))
                        },
                        markMultimediaView: function(e) {
                            var t = e.image,
                                n = null == t ? void 0 : t.viewDate,
                                r = 19 === e.messageType;
                            if (!e.isYours() && t && !n && r) {
                                var i = e.toGPB().setContext(e.context).setFromPersonId(e.toPersonId).setMessageType(20).setToPersonId(e.fromPersonId);
                                this.trigger(E.MESSAGES_READ, e.fromPersonId, e.dateCreated), this.set(i)
                            }
                        },
                        needToPayToSendMessage_: function(e, t) {
                            return I(this.getBlockingFeature(e)) || this.getPromoBlock(e, 472) || 10 === t.messageType
                        },
                        onChatMessageRead_: function(e) {
                            if (e) {
                                var t = e.user_id,
                                    n = e.read_timestamp;
                                this.updateMyReadMessages_(t, n)
                            }
                        },
                        updateMyReadMessages_: function(e, t) {
                            var n = A.A.read({
                                    userId: e
                                }),
                                r = null;
                            n.messages.forEach((function(e) {
                                !e.isRead && e.isYours() && e.dateCreated <= t && (r = e, e.setReadMessagesTimestamp(t), e.setStatus(e.STATUS.READ, void 0))
                            })), r && this.trigger(E.MESSAGES_READ, e, t)
                        },
                        updateTheirReadMessages_: function(e) {
                            var t = null,
                                n = e.fromPersonId,
                                r = A.A.read({
                                    userId: n
                                }),
                                i = Math.max(e.dateCreated, r.readMessagesTimestamp);
                            r.messages.forEach((function(e) {
                                !e.isYours() && e.dateCreated <= i && !e.isRead && (t = e, e.isRead = !0)
                            })), t && !r.dummy && (r.readMessagesTimestamp = i, this.throttledSendReadTimestamp(n, i), this.trigger(E.NEW_MESSAGE_READ, n, t))
                        },
                        onChatIsWriting_: function(e) {
                            var t = e.who_is_writing;
                            this.trigger(E.IS_WRITING, t)
                        },
                        onChatMessageReceived_: function(e) {
                            if (!(e instanceof P.cMz)) {
                                if (e instanceof Error) this.log.error(e);
                                else {
                                    var t = e && (e.$gpb || e.constructor.name) || "UNKNOWN";
                                    this.log.error("Expected instance of ChatMessage and got " + t, e)
                                }
                                return e
                            }
                            if (10 !== e.getMessageType() || !this.pendingPaidMessages_.length) {
                                var n = O(e),
                                    r = n.chatUser && n.chatUser.getUserId();
                                return this.add(new y.Ay(e, n.chatUser, {
                                    isReplyFeatureAllowed: R(r)
                                }))
                            }
                            this.checkPendingPaidMessages_((new P.bF6).setChatMessage(e).setSuccess(!0).setUid(this.pendingPaidMessages_[0].id))
                        },
                        onSend_: function(e, t) {
                            var n = this;
                            return function(e) {
                                var r = e[0],
                                    i = e[1];
                                if (!r && !i) throw new Error(new Error("No response received on message sent!"));
                                if (i || !r.getSuccess()) {
                                    var a = "Unknown error when sending message",
                                        o = i ? function(e, t) {
                                            var n = e.getFeature(),
                                                r = new Error(n && n.getDisplayMessage() || e.getErrorMessage(t));
                                            return r.serverErrorMessage = e, r
                                        }(i, a) : new Error(a);
                                    return n.onError_(t)(o)
                                }
                                return n.updateChatMessage_(t, r.getChatMessage()), t
                            }
                        },
                        onError_: function(e) {
                            return function(t) {
                                throw t.serverErrorMessage && 91 === t.serverErrorMessage.getType() && 3 === t.serverErrorMessage.getBehaviour() ? e.setStatus(e.STATUS.INAPPROPRIATE, "") : e.setStatus(e.STATUS.FAILED, t.message && t.message.replace(/\(.*\)/g, "").trim()), t
                            }
                        },
                        onUpdateChatMessageError_: function(e) {
                            var t = new Error("Unknown error when sending message");
                            return this.onError_(e)(t)
                        },
                        onSystemNotification_: function(e) {
                            switch (e.id) {
                                case 5:
                                case 2:
                                case 6:
                                    this.invalidateAll(), this.trigger(E.FLUSH)
                            }
                        },
                        onStreamMessage: function(e, t) {
                            e && this.on(w(e), t)
                        },
                        offStreamMessage: function(e, t) {
                            var n = w(e);
                            this.hasListeners(n) && this.off(n, t)
                        },
                        triggerStreamDirectMessage_: function(e) {
                            var t = w(e.streamId);
                            this.hasListeners(t) && this.trigger(t, e)
                        },
                        invalidate: function(e) {
                            this.trigger(E.FLUSH), A.A.delete(e)
                        },
                        invalidateAll: function() {
                            A.A.delete()
                        },
                        payToSend: function(e) {
                            var t = this,
                                n = e.userId,
                                r = e.chatMessage,
                                i = e.backUrl,
                                a = e.redirectUrl,
                                o = e.blockingFeature;
                            return new Promise((function(e, s) {
                                var c = t.getPromoBlock(n, 472),
                                    u = function(e, t, n) {
                                        if (e.gift) {
                                            var r = e.gift.getGift();
                                            return {
                                                activationPlace: 122,
                                                cost: r.getCost(),
                                                objectId: String(r.getProductId()),
                                                product: 5
                                            }
                                        }
                                        if (t) return {
                                            activationPlace: I(t) ? 80 : null,
                                            cost: t.getPaymentAmount(),
                                            product: t.getProductType()
                                        };
                                        if (n) return {
                                            activationPlace: 472 === n.getPromoBlockType() ? 80 : null,
                                            cost: n.getPaymentAmount(),
                                            product: n.getOkPaymentProductType()
                                        }
                                    }(r, o || t.getBlockingFeature(n), c);
                                c && t.markChatPromoHandled(n, c.getPromoBlockType()), t.pendingPaidMessages_.push({
                                    id: r.id,
                                    resolve: e,
                                    reject: s
                                }), f.A.purchase({
                                    back: i,
                                    cost: null == u ? void 0 : u.cost,
                                    newNavigation: a,
                                    chatMessage: r,
                                    hotPanelData: u,
                                    productType: u.product,
                                    userId: n,
                                    complete: function(e) {
                                        e || (t.revertAddMessage_(r), c && t.markChatPromoHandled(n, c.getPromoBlockType(), !0))
                                    },
                                    error: function(e) {
                                        r.setStatus(r.STATUS.FAILED, null == e ? void 0 : e.message), s(e || new Error("Unknown error when try to send a payed message"))
                                    },
                                    success: function() {
                                        A.A.update({
                                            userId: n,
                                            blockingFeature: null
                                        })
                                    }
                                })
                            }))
                        },
                        updateChatMessages: function(e) {
                            var t = e.getChatInstance().getUid(),
                                n = A.A.update({
                                    userId: t,
                                    clientChatMessages: e
                                });
                            return this.trigger(E.HISTORY_UPDATED, t, n.counter, n.messages.length), n.messages
                        },
                        updateChatMessage_: function(e, t) {
                            var n = t.getUid(),
                                r = this.messagesToDelete[e.id];
                            if (r) return this.revertAddMessage_(e, {
                                increaseMaxAnswers: !0
                            }), void this.deleteChatMessageInServer(n, r.reason);
                            var i = A.A.read({
                                    chatMessage: e
                                }),
                                a = i.messages.find((function(e) {
                                    return e.id === n
                                }));
                            a && e.id !== n ? (this.revertAddMessage_(e, {
                                increaseMaxAnswers: !0
                            }), a.update(t, i.chatUser), this.add(a)) : (e.update(t, i.chatUser), this.add(e))
                        },
                        getMaskedMessage: function(e, t) {
                            var n = this;
                            return this.fetch_(606, (0, r.jU)(280, 360), (new P.tm1).setUserId(e).setAction(1).setMessageIds(t).setContext(10)).then((function(t) {
                                var r = t[0],
                                    i = t[1],
                                    a = n.updateChatMessages(r);
                                return i && (0, s.A)((function() {
                                    A.A.update({
                                        userId: e,
                                        chatSettings: i
                                    })
                                })), a
                            }))
                        },
                        focusInput: function() {
                            this.trigger(E.INPUT_FOCUSED)
                        },
                        setShowLikelyOffensivePrompt: function(e, t) {
                            O(e).isShowingOffensiveMessagesPrompt = t
                        },
                        createMultimedia: function(e) {
                            var t = (new P.$_D).setId(e.multimediaId),
                                n = (new P.anE).setVisibilityType(e.visibility);
                            return (new P.U0R).setFormat(e.format || 1).setPhoto(t).setVisibility(n)
                        },
                        isContactsForCreditsFeature: I,
                        isYours: C
                    }, "ChatModel");
                var T = (0, c.A)((function() {
                        var e = new P.KkJ,
                            t = [210, 230, 610, 580, 290, 583, 250, 100, 570, 200, 331, 330, 340, 560, 650, 930, 1436, 760, 761];
                        return e.setRequestAlbums([(new P.Nij).setAlbumType(2).setCount(20)]).setProfileOptionTypes([10, 1, 12]), t.push.apply(t, [370, 431, 700, 410, 310, 490, 311]), e.setProjection(t)
                    })),
                    S = function() {
                        return (new P.KkJ).setProjection([760, 761])
                    };

                function I(e) {
                    var t = e;
                    if (!t) return !1;
                    var n = t.getCreditsForProduct(t.getProductType());
                    return 18 === n || 12 === n
                }

                function C(e) {
                    return e instanceof P.cMz ? e.getFromPersonId() === l.A.getUserId() : e.fromPersonId === l.A.getUserId()
                }

                function O(e) {
                    return e instanceof P.cMz ? e = C(e) ? e.getToPersonId() : e.getFromPersonId() : e instanceof y.Ay && (e = C(e) ? e.toPersonId : e.fromPersonId), A.A.read({
                        userId: e
                    })
                }

                function R(e) {
                    var t = O(e);
                    return Boolean(t.isReplyFeatureAllowed)
                }

                function w(e) {
                    return "STREAM::" + e
                }
                var D = new b;
                D.getInstance = function() {
                    return D
                }, t.A = D
            }
        }
    ]);
//# sourceMappingURL=8819.44794e59ca17963a952e.js.map
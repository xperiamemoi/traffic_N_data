var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "e04d3766-0840-4559-84a3-3e91563986af", e._sentryDebugIdIdentifier = "sentry-dbid-e04d3766-0840-4559-84a3-3e91563986af")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "e04d3766-0840-4559-84a3-3e91563986af", e._sentryDebugIdIdentifier = "sentry-dbid-e04d3766-0840-4559-84a3-3e91563986af")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [387], {
            20387: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return H
                    }
                });
                n(69085), n(58940), n(2892), n(27495), n(5746), n(62062), n(2008), n(26099), n(28706), n(25276), n(51629), n(23500), n(48980), n(3362), n(23792), n(47764), n(62953), n(60739), n(27208), n(50113), n(46449), n(93514);
                var s = n(89610),
                    r = n(85208),
                    i = n(46996),
                    o = n(47360),
                    a = n(32308),
                    l = n(23735),
                    c = n(57917),
                    d = n(79860),
                    u = n(65297),
                    f = n(54864),
                    h = n(23149),
                    g = n(3508),
                    I = n(13614),
                    _ = n(40075),
                    p = n(15566),
                    m = {
                        NEARBY: "nearby",
                        FAN: "fan",
                        FAVOURITE: "favourite",
                        CREDIT_INTRO: "credit-intro",
                        PROFILE_INFO: "profile-info",
                        MATCHES: "matches",
                        MENU: "menu"
                    },
                    v = {
                        MEDIUM: "medium",
                        LARGE: "large",
                        SMALL: "small",
                        TINY: "tiny"
                    },
                    y = "icon-right",
                    S = {
                        size: v.MEDIUM,
                        allowNewIcon: !0,
                        allowBumpedIcon: !0,
                        allowMatchIcon: !0,
                        allowNoVoteIcon: !0,
                        allowFavouriteIcon: !0,
                        iconPosition: "icon-centre",
                        displayName: !0,
                        displayMessage: !0,
                        defaultMessage: null
                    },
                    A = {
                        NEARBY: (0, r.A)({}, S, {
                            allowNewIcon: !1,
                            allowNoVoteIcon: !1,
                            displayMessage: !1
                        }),
                        FAN: (0, r.A)({}, S, {
                            allowBumpedIcon: !1,
                            allowFavouriteIcon: !1
                        }),
                        VISITORS: (0, r.A)({}, S, {
                            allowBumpedIcon: !1,
                            allowFavouriteIcon: !1
                        }),
                        FAVOURITE: (0, r.A)({}, S, {
                            allowBumpedIcon: !1,
                            allowFavouriteIcon: !1
                        }),
                        CREDIT_INTRO: (0, r.A)({}, S, {
                            size: v.LARGE,
                            allowNewIcon: !1,
                            allowNoVoteIcon: !1,
                            displayMessage: !1
                        }),
                        PROFILE_INFO: (0, r.A)({}, S, {
                            allowNewIcon: !1,
                            allowBumpedIcon: !1,
                            allowMatchIcon: !1,
                            allowNoVoteIcon: !1,
                            allowFavouriteIcon: !1,
                            iconPosition: y
                        }),
                        MATCHES: (0, r.A)({}, S, {
                            size: v.SMALL
                        }),
                        MENU: (0, r.A)({}, S, {
                            size: v.TINY,
                            allowNewIcon: !1,
                            allowBumpedIcon: !1,
                            allowMatchIcon: !1,
                            allowNoVoteIcon: !1,
                            allowFavouriteIcon: !1,
                            displayMessage: !1
                        })
                    },
                    T = {
                        EXTRA_SHOWS: "extra-shows",
                        QUOTA: "quota",
                        RISE_UP: "rise-up"
                    },
                    E = {
                        tiny: g.A.get("image.avatar.size.small", 45),
                        small: g.A.get("image.avatar.size.small", 65),
                        medium: g.A.get("image.avatar.size.medium", 90),
                        large: g.A.get("image.avatar.size.medium", 140),
                        huge: g.A.get("image.avatar.size.medium", 175)
                    };

                function w(e, t) {
                    t = (0, h.A)(t) ? t : {}, this.context_ = "string" == typeof t.context ? t.context : null, this.config_ = function(e) {
                        for (var t in m)
                            if (m[t] === e) return A[t];
                        return A.FAN
                    }(this.context_), this.size = "string" == typeof t.size ? t.size : this.config_.size, this.iconPosition = this.config_.iconPosition, e instanceof p.KJW ? this.populateFromUser_(e) : e instanceof p.y9T ? this.populateFromPhonebookContact_(e, t) : this.populateFromOptions_(t)
                }(0, r.A)(w.prototype, {
                    populateFromUser_: function(e) {
                        var t = e.getProfilePhoto(null);
                        if (t && (this.image = t.getLargeUrl(null)), this.gender = e.getGender(null), 2 === this.gender ? this.female = !0 : 1 === this.gender && (this.male = !0), this.setIconFromUser_(e), this.config_.displayMessage ? this.info = e.getDisplayMessage() || this.config_.defaultMessage || !1 : this.info = !1, 30 !== e.getAccessLevel()) {
                            this.name = this.config_.displayName && e.getName(), !this.invisible && this.name && (this.name = (0, I.KS)(e.getName())), 4 === e.getVerificationStatus() && (this.isFullyVerified = !0);
                            var n = e.getOnlineStatus();
                            1 === n ? this.online = !0 : 2 === n ? this.idle = !0 : 4 === n && (this.offline = !0), this.deleted = this.disabled = e.getIsDeleted(), this.invisible = e.getIsInvisible(), this.id = e.getUserId(null)
                        } else this.locked = !0
                    },
                    setIconFromUser_: function(e) {
                        if (!e.getIsCrush()) return this.config_.allowNewIcon && e.getIsUnread() ? (this.showNewIcon = !0, void(this.newIconText = function(e) {
                            switch (e) {
                                case 2:
                                    return _.Ay.get(518);
                                case 1:
                                    return _.Ay.get(520);
                                default:
                                    return _.Ay.get(519)
                            }
                        }(this.gender))) : void(this.config_.allowMatchIcon && e.getIsMatch() ? this.showMatchedIcon = !0 : this.config_.allowNoVoteIcon && 3 === e.getMyVote() && (this.showNoVoteIcon = !0));
                        this.showCrushIcon = !0
                    },
                    populateFromPhonebookContact_: function(e, t) {
                        this.name = e.hasName() ? (0, I.KS)(e.getName()) : null, this.image = e.getPhotoUrl(null), this.gender = e.getGender(null), this.id = e.getUserId(null), this.info = e.getDescription(null), this.id ? this.showPlatformIcon = !0 : this.setIconFromOptions_(t)
                    },
                    populateFromOptions_: function(e) {
                        this.image = e.image, this.darkBorder = !0, this.setIconFromOptions_(e), this.gender = e.gender || 1
                    },
                    setIconFromOptions_: function(e) {
                        switch (e.icon) {
                            case T.EXTRA_SHOWS:
                                this.showExtraShowsIcon = !0;
                                break;
                            case T.QUOTA:
                            case T.RISE_UP:
                                this.showRiseUpIcon = !0;
                                break;
                            default:
                                this.customIcon = e.icon
                        }
                    }
                }), w.CONTEXT = m, w.SIZES = v, w.HEIGHT = {
                    MEDIUM: 150
                }, w.PAYMENT_ICONS = T, w.THUMBNAIL_SIZE = E;
                var F, U = w,
                    C = n(26666),
                    R = {
                        getOffset: function(e) {
                            for (var t = 0, n = e.getSection(), s = 0; s < n.length; s += 1) t += n[s].getUsers().length;
                            return t
                        },
                        hasMoreData: function(e, t) {
                            if (!(e instanceof p.fRy)) return !1;
                            var n = null;
                            return (n = t ? e.getSection([]).find((function(e) {
                                return e.getSectionId() === t
                            })) : (0, C.A)(e.getSection())) && !n.getLastBlock()
                        },
                        getPlaceholderUserList: function(e) {
                            var t = (new p.fRy).setTotalSections(1).setTotalCount(e),
                                n = (new p.iSN).setSectionId("placeholder").setName("").setTotalCount(e).setLastBlock(!0);
                            n.isPlaceholder = !0;
                            for (var s = (new p.KJW).setUserId("placeholder").setName(""), r = [], i = 0; i < e; i++) r[i] = s;
                            return n.setUsers(r), t.setSection([n]), t
                        }
                    },
                    N = n(92105),
                    P = n(58336),
                    b = n(8054),
                    k = {
                        BLOCKED: 9,
                        WANT_TO_MEET_YOU: 6,
                        PEOPLE_NEARBY: 10,
                        FAVOURITES: 4,
                        VISITORS: 8,
                        MESSAGES: 0,
                        COMBINED_CONNECTIONS_ALL: 31,
                        MESSAGES_AND_ACTIVITY: 56
                    },
                    M = [k.WANT_TO_MEET_YOU, k.FAVOURITES],
                    O = [],
                    L = {
                        ALL: "ALL",
                        ONLINE: 0,
                        UNREAD: 2,
                        FAVOURITES: 6,
                        SEARCH: "SEARCH",
                        UNREPLIED: 9,
                        CONVERSATIONS: 3
                    },
                    B = Object.assign({}, c.A.EVENTS, (0, P.A)("USER_ADDED", "USER_REMOVED")),
                    D = ((F = {})[9] = "1", F),
                    x = {};
                u.A.on(u.A.Session.USER_CHANGED, (function() {
                    x = {}
                }));
                var V, q = c.A.extend({
                    name: "Folders",
                    getRequestMessageType: 245,
                    getResponseMessageType: 246,
                    folderId_: null,
                    preferredCount_: 20,
                    photo_: U.THUMBNAIL_SIZE.MEDIUM,
                    search_: null,
                    filter_: L.ALL,
                    isInstance_: !1,
                    init_: function(e) {
                        (0, N.A)(this), e && ((0, a.Rg)(e.folderId) && this.setFolderId(e.folderId), e.preferredCount && this.setPreferredCount(e.preferredCount), e.instance && (this.isInstance_ = !0))
                    },
                    setFolderId: function(e) {
                        return this.isInstance_ || (0, a.Rg)(e) && (this.folderId_ = e), this
                    },
                    setPreferredCount: function(e) {
                        return this.isInstance_ || "number" == typeof e && (this.preferredCount_ = e), this
                    },
                    setSearch: function(e) {
                        return this.isInstance_ || (this.search_ = "string" == typeof e ? e : null), this
                    },
                    setFilter: function(e) {
                        if (null == e || isNaN(e)) null === e && (this.filter_ = null);
                        else {
                            if (this.isInstance_) return this;
                            if (e !== L.SEARCH && e !== L.ALL && (e = parseInt(e, 10), !(0, a.Rg)(e))) return void this.log.error("Wrong filter set", {
                                filter: e
                            });
                            this.filter_ = e
                        }
                    },
                    setClientSource: function(e) {
                        (0, a.Rg)(e) && (this.clientSource_ = e)
                    },
                    getClientSource: function(e) {
                        return (0, a.Rg)(e) ? e : this.clientSource_ || 0
                    },
                    get: function(e) {
                        return q._super.get.call(this, this.getMessageBody_(e))
                    },
                    fetch: function(e, t, n) {
                        var r = this;
                        e = this.getMessageBody_(e), ((0, s.A)(e) || (0, s.A)(t) || (0, s.A)(n)) && this.log.error("FUNCTION...");
                        var i = q._super.fetch.call(this, e),
                            o = i;
                        return !0 !== t && (o = i.then((function(t) {
                            var n = r.getRequestMessageType,
                                s = r.getCacheKey_(n, e),
                                i = r.getFromCache_(n, e);
                            return i && i && i.length && (t = r.merge_(t, i)), r.cacheResponse_(s, r.getCacheTime_(n, e), t)
                        }))), !0 === n || !0 === t ? i : o
                    },
                    expand: function() {
                        var e = this.getMessageBody_(),
                            t = this.getFromCache_(this.getRequestMessageType, e) || [];
                        return e.setOffset(null != t && t.length ? R.getOffset(t[0]) : 0), this.fetch(e)
                    },
                    getMessageBody_: function(e) {
                        var t, n;
                        e = e || {};
                        var s = this.getClientSource(e.clientSource);
                        this.setFilter(e.activityFilter);
                        var i = (e = (0, r.A)({
                                offset: null,
                                filter: this.filter_,
                                folderId: e.folderId || this.folderId_,
                                sectionId: null,
                                preferredCount: this.preferredCount_,
                                search: this.search_,
                                clientSource: s
                            }, e)).userFieldFilter || f.h.getFolderFilter(s),
                            o = (new p.XPS).setFolderId(e.folderId).setUserFieldFilter(i).setSource(e.clientSource);
                        if ("number" == typeof e.preferredCount && o.setPreferredCount(e.preferredCount), (0, a.Rg)(e.activityFilter) && o.addFilter(Number(e.activityFilter)), "string" == typeof e.search && e.search.length > 0 && o.setSearchString(e.search), "string" == typeof e.sectionId && e.sectionId.length > 0 && o.setSectionId(e.sectionId), "number" == typeof e.offset && o.setOffset(e.offset), "string" == typeof e.pageToken && o.setPageToken(e.pageToken), "string" == typeof e.syncToken && o.setSyncToken(e.syncToken), null != (t = e.sectionRequests) && t.length && o.setSectionRequests(e.sectionRequests.map((function(e) {
                                var t = new p.Jql;
                                return e.id && t.setSectionId(e.id), e.type && t.setSectionType(e.type), e.offset && t.setOffset(e.offset), e.preferredCount && t.setPreferredCount(e.preferredCount), e.pageToken && t.setPageToken(e.pageToken), e.syncToken && t.setSyncToken(e.syncToken), t
                            }))), this.setFolderSyncItems_(o, e), null != (n = e.promoBlockRequestParams) && n.length) {
                            var l = function(e) {
                                var t = [];
                                return e.forEach((function(e) {
                                    var n = new p.agq,
                                        s = e.shownPromoBlocks,
                                        r = e.position,
                                        i = e.count;
                                    s && Array.isArray(s) && s.length > 0 && n.setShownPromoBlocks(s), "number" == typeof r && n.setPosition(r), "number" == typeof i && n.setCount(i), t.push(n)
                                })), t
                            }(e.promoBlockRequestParams);
                            o.setPromoBlockRequestParams(l)
                        }
                        return e.streamId && o.setStreamId(e.streamId), o
                    },
                    setFolderSyncItems_: function(e, t) {
                        "number" == typeof t.updateTimestamp && e.setUpdateTimestamp(t.updateTimestamp), "number" == typeof t.sortTimestamp && e.setSortTimestamp(t.sortTimestamp), t.direction && e.setDirection(t.direction), t.lastUserId && e.setLastUserId(t.lastUserId), t.includeTransient && e.setIncludeTransient(t.includeTransient)
                    },
                    merge_: function(e, t) {
                        if (!t) return e;
                        var n = t[0].getSection(),
                            s = e[0].getSection();
                        if (!s) return t;
                        for (var r = [], i = n.map((function(e) {
                                r.push(e.getSectionId());
                                var t = this.getSectionById_(s, e.getSectionId());
                                if (!t) return e;
                                e.setLastBlock(t.getLastBlock());
                                var n = [],
                                    i = e.getUsers([]),
                                    o = t.getUsers([]);
                                e.setUsers(i.concat(o).filter((function(e) {
                                    return -1 === n.indexOf(e.getUserId()) && (n.push(e.getUserId()), !0)
                                }), this));
                                var a = t.getSectionFeature();
                                return a ? e.setSectionFeature(a) : (delete e._data.section_feature, delete e._deferred.section_feature), e
                            }), this), o = 0; o < s.length; o += 1) - 1 === r.indexOf(s[o].getSectionId()) && i.push(s[o]);
                        t[0].setSection(i);
                        var a = t[0].getPromoBanners([]),
                            l = e[0].getPromoBanners([]);
                        return t[0].setPromoBanners(a.concat(l)), t
                    },
                    getSectionById_: function(e, t) {
                        for (var n in e)
                            if (e[n].getSectionId() === t) return e[n];
                        return null
                    },
                    getCacheKey_: function(e, t) {
                        var n = this.folderId_,
                            r = "",
                            i = "";
                        t && (0, s.A)(t.getFolderId) && (n = t.getFolderId()), this.search_ && this.search_.length > 0 && (r = this.search_), (0, a.Rg)(this.filter_) && (i = this.filter_);
                        var o = n + "-" + r + "-" + i,
                            l = t && t.getUserId();
                        return l && (o += "-" + l), o
                    },
                    moveToTop: function(e) {
                        var t = this.getMessageBody_(),
                            n = this.getRequestMessageType,
                            s = this.getFromCache_(n, t) || [];
                        if (Array.isArray(s) && s[0] instanceof p.fRy) {
                            if (!this.moveToTop_(s[0], e)) return;
                            var r = this.getCacheTime_(n, t),
                                i = this.getCacheKey_(n, t);
                            this.cacheResponse_(i, r, s)
                        }
                    },
                    moveToTop_: function(e, t) {
                        var n = !1;
                        return e.getSection([]).forEach((function(e) {
                            for (var s = e.getUsers([]), r = -1, i = 0, o = s.length; i < o; i++)
                                if (s[i].getUserId() === t) {
                                    r = i;
                                    break
                                }
                            if (-1 !== r) {
                                var a = s.splice(r, 1)[0];
                                s.unshift(a), n = !0
                            }
                        }), this), n
                    },
                    markPeopleViewed: function(e, t) {
                        var n = this,
                            s = (new p.lCE).setPersonId(e.peopleIds);
                        e.sectionId && s.setSectionId(e.sectionId);
                        var r = (new p.WSr).setFolderId("folderId" in e ? e.folderId : this.folderId_).setAction(2).addUserList(s);
                        e.context && r.setContext(e.context);
                        var i = this.fetch_(259, 387, r);
                        if (!t) {
                            var o = e.peopleIds,
                                a = this.updateUsersInCache_.bind(this, (function(e) {
                                    return o.indexOf(e.getUserId()) > -1 && (e.setIsUnread(!1), !0)
                                }));
                            return i.then(a).then((function(t) {
                                t && n.trigger(B.INVALIDATED, {
                                    keys: [n.folderId_],
                                    peopleIds: e.peopleIds,
                                    metaDataOnly: !0
                                })
                            }))
                        }
                    },
                    containsTruthy_: function(e) {
                        return Array.isArray(e) ? -1 !== e.findIndex((function(e) {
                            return e
                        })) : e
                    },
                    updateUsersInCache_: function(e) {
                        var t = this;
                        return this.updateSectionsInCache_((function(n) {
                            var s = n.getUsers([]);
                            return !!s.length && t.containsTruthy_(s.map(e))
                        }))
                    },
                    updateSectionsInCache_: function(e) {
                        var t = this;
                        return this.updateListInCache_((function(n) {
                            return !(!n || !n.getSection([]).length) && t.containsTruthy_(n.getSection([]).map(e))
                        }))
                    },
                    updateListInCache_: function(e) {
                        var t = this,
                            n = this.getMessageBody_(),
                            s = this.getCacheKey_(this.getRequestMessageType, n),
                            r = this.getCacheTime_(this.getRequestMessageType, n),
                            i = this.getFromCache_(this.getRequestMessageType, n) || [];
                        return i.length ? Promise.all(i).then((function(n) {
                            var i = n[0],
                                o = t.containsTruthy_(e(i));
                            return o && t.cacheResponse_(s, r, [i]), o
                        })) : Promise.resolve(!1)
                    },
                    trackUserRemove_: function(e, t, n) {
                        if (!t) switch (e) {
                            case 0:
                                t = 27;
                                break;
                            case 4:
                                t = 24;
                                break;
                            case 6:
                                t = 4;
                                break;
                            case 8:
                                t = 23;
                                break;
                            case 9:
                                t = 25;
                                break;
                            case 20:
                                t = 37;
                                break;
                            default:
                                t = 1
                        }(0, d.sx)(93, {
                            encrypted_user_id: n,
                            activation_place: t
                        })
                    },
                    addUserToFolder: function(e) {
                        this.trigger(B.USER_ADDED, e);
                        var t = (new p.eUi).setPersonId(e.uid).setFolderId(e.folder);
                        return e.customFolderId && t.setCustomFolderId(e.customFolderId), e.context && t.setContext(e.context), 9 === e.folder && (x[e.uid] = !0), this.fetch_(63, 387, t).then(this.invalidateAndResolvePromise_.bind(this, e.folder))
                    },
                    removeUserFromFolder: function(e) {
                        return this.removeUsers({
                            folderId: e.folder,
                            ids: [e.uid]
                        })
                    },
                    invalidateAndResolvePromise_: function(e, t) {
                        var n = this;
                        return new Promise((function(s, r) {
                            n.invalidateFolder(e), t && Array.isArray(t) && (t = !!t.length && (t = t[0])), t && t.getType() !== l.a5.HANDLER_UNSATISFIED ? r(t) : s()
                        }))
                    },
                    removeUsers: function(e) {
                        var t = this,
                            n = e.activationPlace,
                            s = e.folderId,
                            r = e.ids,
                            i = e.listSectionType,
                            o = e.avoidHotpanelTracking,
                            a = e.context;
                        s = "number" == typeof s ? s : this.folderId_;
                        var l = D[s],
                            c = (new p.lCE).setPersonId(r);
                        l && c.setSectionId(l), i && c.setSectionType(i), 9 === s && r.forEach((function(e) {
                            x[e] = !1
                        }));
                        var d = (new p.WSr).setFolderId(s).setAction(1).addUserList(c);
                        return a && d.setContext(a), o || r.forEach(this.trackUserRemove_.bind(this, s, n)), r.forEach((function(e) {
                            return t.trigger(B.USER_REMOVED, {
                                folder: s,
                                uid: e
                            })
                        })), this.fetch_(259, 387, d).then(this.invalidateAndResolvePromise_.bind(this, s))
                    },
                    revealUser: function(e) {
                        var t = e.personId,
                            n = e.folderId,
                            s = (new p.lCE).addPersonId(t),
                            r = (new p.WSr).setAction(3).setFolderId(n).addUserList(s);
                        return this.fetch_(259, 246, r)
                    },
                    unmatchUser: function(e) {
                        var t = e.personId,
                            n = e.folderId,
                            s = (new p.lCE).addPersonId(t),
                            r = (new p.WSr).setAction(10).setFolderId(n).addUserList(s);
                        return this.fetch_(259, 387, r)
                    },
                    shouldCache_: function(e, t) {
                        return !(t instanceof p.XPS && (t.hasSearchString() || t.hasOffset())) && e === this.getRequestMessageType
                    },
                    invalidateFolder: function(e) {
                        if ((0, a.Rg)(e)) {
                            var t = this.cache_.getKeys(),
                                n = e + "-";
                            t && t.length > 0 && (t = t.filter((function(e) {
                                return e.substr(0, n.length) === n
                            })), this.invalidate(t))
                        } else this.log.error("Invalidating wrong folder", e)
                    },
                    markAsGentleLetdownBlocked: function(e) {
                        var t = (new p.lCE).addPersonId(e),
                            n = (new p.WSr).setAction(5).setFolderId(9).setContext(209).addUserList(t);
                        return this.fetch_(259, 387, n)
                    },
                    invalidateSppFolders: function() {
                        for (var e = 0; e < M.length; e++) this.invalidateFolder(M[e])
                    },
                    invalidateCreditFolders: function() {
                        for (var e = 0; e < O.length; e++) this.invalidateFolder(O[e])
                    },
                    invalidatePaymentFolders: function() {
                        this.invalidateSppFolders(), this.invalidateCreditFolders()
                    },
                    isEqual: function(e, t) {
                        if (!e || !t || e.length !== t.length) return !1;
                        for (var n = e.length, s = 0; s < n; s++)
                            if (!(0, i.A)(e[s].toJSON(), t[s].toJSON())) return !1;
                        return !0
                    },
                    isSameUsers: function(e, t) {
                        if (!e && !t) return !0;
                        if (!e || !t) return !1;
                        var n = e.length;
                        if (n !== t.length) return !1;
                        for (var s = 0; s < n; s += 1)
                            if (e[s].getUserId() !== t[s].getUserId()) return !1;
                        return !0
                    },
                    getProfileFromLocation_: function(e, t, n) {
                        var s;
                        for (t += n; t > -1 && t < e.length;) {
                            if (!(s = e[t]).getIsInvisible() && !s.getIsDeleted() && !this.isBlockedInSession_(s.getUserId())) return s;
                            t += n
                        }
                        return null
                    },
                    isBlockedInSession_: function(e) {
                        return Boolean(x[e])
                    },
                    extractProfilesIndex_: function(e, t) {
                        var n;
                        if (e && Array.isArray(e) && e.length) {
                            var s = e[0].getSection([]);
                            if (s.length) {
                                var r = {
                                        users: []
                                    },
                                    i = null;
                                return t && (i = s.find((function(e) {
                                    return e.getSectionId() === t
                                }))), null != (n = i) && n.getUser ? r.users = i.getUsers([]) : r.users = s.map((function(e) {
                                    return e.getUsers([])
                                })).flat(), r.ids = r.users.map((function(e) {
                                    return e.getUserId()
                                })), r
                            }
                        }
                    },
                    getAdjacentProfiles: function(e, t, n) {
                        var s = this;
                        return this.get({
                            sectionId: t,
                            activityFilter: n
                        }).then((function(n) {
                            var r = s.extractProfilesIndex_(n, t),
                                i = r && r.ids.indexOf(e);
                            if (!r || -1 === i) return null;
                            var a = r.ids[r.ids.length - 1];
                            if (e !== a) return {
                                next: s.getProfileFromLocation_(r.users, i, 1),
                                prev: s.getProfileFromLocation_(r.users, i, -1)
                            };
                            var l = {
                                offset: r.users.length,
                                preferredCount: 20,
                                sectionId: t
                            };
                            return s.fetch(l, !1, !0).then((function(n) {
                                var a = (0, o.A)(n[0].getSection());
                                return (a ? a.getUsers([]).filter((function(e) {
                                    return -1 === r.ids.indexOf(e.getUserId())
                                })) : []).length ? s.getAdjacentProfiles(e, t) : {
                                    next: null,
                                    prev: s.getProfileFromLocation_(r.users, i, -1)
                                }
                            }))
                        }))
                    },
                    onCacheInvalidated_: function(e) {
                        var t, n, s = {
                            all: e.all,
                            keys: []
                        };
                        if (e.keys && Array.isArray(e.keys))
                            for (n = e.keys.length, t = 0; t < n; t += 1) s.keys.push(parseInt(e.keys[t].split("-")[0], 10));
                        q._super.onCacheInvalidated_.call(this, s)
                    },
                    setPromoCounter: function(e, t) {
                        var n = this;
                        return this.updateListInCache_((function(s) {
                            var r = s.getPromoBanners([]).map((function(n) {
                                var s = n.getPromoBlockType() === e;
                                return s && n.setCounter(t), s
                            }));
                            return n.containsTruthy_(r)
                        }))
                    },
                    getVersion_: function() {
                        return 3
                    }
                }, "Folders");
                q.TYPES = k, q.FILTERS = L, q.EVENTS = B, q.getInstance = function() {
                    return V || (V = new q({
                        instance: !0
                    }))
                };
                var H = q;
                (0, b.A)({
                    clearFoldersCache: function() {
                        q.getInstance().invalidateAll()
                    }
                })
            }
        }
    ]);
//# sourceMappingURL=387.05a95349952e06c00ff8.js.map
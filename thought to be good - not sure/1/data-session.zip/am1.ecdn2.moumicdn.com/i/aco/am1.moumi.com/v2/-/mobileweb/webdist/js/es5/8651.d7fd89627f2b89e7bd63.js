var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "69981fe1-2ae9-4454-a3aa-078346aa2aa4", e._sentryDebugIdIdentifier = "sentry-dbid-69981fe1-2ae9-4454-a3aa-078346aa2aa4")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "69981fe1-2ae9-4454-a3aa-078346aa2aa4", e._sentryDebugIdIdentifier = "sentry-dbid-69981fe1-2ae9-4454-a3aa-078346aa2aa4")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [8651], {
            61155: function(e, t, n) {
                var s = n(58544),
                    i = n(84230),
                    r = n(15566),
                    o = (0, s.lh)(),
                    a = i.A.getInstance("EncountersProgressBar"),
                    u = "GoalProgress",
                    c = {
                        get: function() {
                            return a.get(u)
                        },
                        update: function(e) {
                            var t = function(e) {
                                if (e instanceof r.rxp) return {
                                    goal: e.getGoal(),
                                    progress: e.getProgress()
                                };
                                return null
                            }(e);
                            t && t.goal === t.progress ? this.setAsReached() : (o.trigger(t), a.put(u, t, {
                                ttl: 6048e5
                            }))
                        },
                        setAsReached: function() {
                            o.trigger(null), a.invalidate(u)
                        },
                        subscribeOnChange: o.subscribe,
                        unsubscribeFromChange: o.unsubscribe
                    };
                t.A = c
            },
            88651: function(e, t, n) {
                n(62062), n(25276), n(74423), n(21699), n(26099), n(3362), n(2008), n(72712), n(51629), n(23500), n(60739), n(27208), n(48598), n(50113);
                var s, i = n(23735),
                    r = n(23149),
                    o = n(64741),
                    a = n(1978),
                    u = n(57917),
                    c = (n(72537), n(7714), n(31087)),
                    d = n(54864),
                    h = n(92105),
                    l = n(61155),
                    g = n(32308),
                    f = n(15566),
                    _ = n(8054),
                    p = null,
                    v = null,
                    y = "84::fab",
                    I = "",
                    b = u.A.extend({
                        name: "Encounters",
                        votedOn_: null,
                        getRequestMessageType: 81,
                        getResponseMessageType: [84, 83],
                        setRequestMessageType: 80,
                        setResponseMessageType: 132,
                        preventMultiple: !0,
                        hasInitialEncounters: !1,
                        previousSessionCached_: [],
                        init_: function() {
                            (0, h.A)(this), this.votedOn_ = this.cache_.get("votedOn") || {}, I = this.cache_.get("lastSeenId") || ""
                        },
                        getMessageBody_: function(e, t, n, s) {
                            var i = new f.KMf;
                            i.setLastPersonId(I);
                            var r = (this.hasInitialEncounters, 20);
                            return n = "number" == typeof n ? n : r, "number" == typeof t && i.setContext(t), e && Array.isArray(e) && e.length && (i.setRequestedPersonIds(e), this.cache_.invalidateAll(!0), I = "", p = null, v = null), i.setNumber(r), s && Array.isArray(s) && i.setEncountersQueueState(s), i
                        },
                        get: function(e) {
                            var t = this.getMessageBody_(e.ids, e.context, e.initialFetchCount, e.queueState).setUserFieldFilter(d.h.getEncountersFilter());
                            return this.hasInitialEncounters || (this.hasInitialEncounters = !0), this.get_(this.getRequestMessageType, this.getResponseMessageType, t).then(this.handleGetResponse_.bind(this, t, e.ids))
                        },
                        getFromCache_: function() {
                            return p || b._super.getFromCache_.apply(this, arguments)
                        },
                        handleGetResponse_: function(e, t, n) {
                            var s, i = this,
                                r = n.fromCache,
                                o = n[0] instanceof f.nsU,
                                a = this.getFromCache_(this.getRequestMessageType, e);
                            if (o && (!a || 0 === a.length)) return n[0];
                            if (o && (null == a ? void 0 : a.length) > 0 && (s = a), r && !o && (s = n), !r && !o) {
                                var u = n[0];
                                v = u;
                                var c = function(e) {
                                    var t = e.getUserSubstitutes([]),
                                        n = e.getQuota();
                                    if (n && 0 === n.getYesVotesQuota()) return t.find((function(e) {
                                        return 2 === e.getType() && 2 === e.getDisplayStrategy()
                                    }));
                                    return !1
                                }(u);
                                if (c) return c;
                                l.A.update(u.getGoalProgress()), s = this.processNewEncountersResponse(u, a)
                            }
                            var d = this.filterValidEncounters_(s, t);
                            return r && d.length < 12 ? i.fetch_(i.getRequestMessageType, i.getResponseMessageType, e).then(i.handleGetResponse_.bind(i, e, t)) : 0 === d.length && o ? n[0] : (this.cacheLastSeenId(d), r && d.length > 0 && function(e) {
                                i.previousSessionCached_ = e.map((function(e) {
                                    return i.getUserId_(e)
                                }))
                            }(d), r || function(t) {
                                i.cacheResponse_(i.getCacheKey_(81, e), i.getCacheTime_(), t, !0)
                            }(d), {
                                encounters: d,
                                isCached: r,
                                hasLikedYouEntry: this.cache_.get(y)
                            })
                        },
                        processNewEncountersResponse: function(e, t) {
                            var n = this.substituteUsers_(e.getResults(), e.getUserSubstitutes([]));
                            return (null == t ? void 0 : t.length) > 0 ? this.getUnion_(t, n) : n
                        },
                        cacheLastSeenId: function(e) {
                            I !== (I = (e.length, this.getUserId_(e[e.length - 1]))) && this.cache_.put("lastSeenId", I, {
                                ttl: this.getCacheTime_()
                            })
                        },
                        forceUserVoteYes: function(e) {
                            for (var t = 0, n = e.length; t < n; t += 1) e[t].setHasUserVoted(!0);
                            return e
                        },
                        getUnion_: function(e, t) {
                            for (var n = this, s = e.map((function(e) {
                                    return n.getUserId_(e)
                                })), i = 0; i < t.length; i += 1) - 1 === s.indexOf(this.getUserId_(t[i])) && e.push(t[i]);
                            return e
                        },
                        _constructVoteEntity: function(e) {
                            var t = (new f.s5f).setPersonId(e.id).setVote(e.voteType).setVoteSource(e.source).setIsForCachedEncounters(e.cached || !1).setClientSideMatch(e.canClientMatch || !1);
                            if (t.setFirstPhotoId(e.firstPhotoId || "").setHiddenPhotoIds(e.hiddenPhotoIds || []).setIsEngagedVote(e.isEngagedVote || !1), this.previousSessionCached_.includes(e.id)) {
                                var n = this.previousSessionCached_.indexOf(e.id);
                                n > -1 && (t.setIsForCachedEncounters(!0), this.previousSessionCached_.splice(n, 1))
                            }
                            return "string" == typeof e.photoId && t.setPhotoId(e.photoId), t
                        },
                        _isSetRequestValid: function(e) {
                            return (0, r.A)(e) && e.id && (0, g.Rg)(e.voteType) && (0, g.Rg)(e.source)
                        },
                        set: function(e) {
                            if (!this._isSetRequestValid(e)) return this.log.error("Invalid set request"), Promise.reject(new Error("Invalid set request"));
                            this.votedOn_[e.id] = !0, this.saveVotedOn_();
                            var t = this._constructVoteEntity(e);
                            return b._super.set.call(this, t).then(this.handleSetResponse_.bind(this, t))
                        },
                        undoVote: function(e) {
                            this.votedOn_[e] = !1, this.saveVotedOn_()
                        },
                        handleSetResponse_: function(e, t) {
                            switch ((t = t && Array.isArray(t) && t.length ? t[0] : null).getVoteResponseType()) {
                                case 5:
                                case 6:
                                    return Promise.reject(t)
                            }
                            return c.A.getInstance().informVote(e, t), Promise.resolve(t)
                        },
                        saveVotedOn_: (0, o.A)((function() {
                            this.cache_.put("votedOn", this.votedOn_, {
                                ttl: this.getCacheTime_()
                            })
                        }), 500),
                        filterValidEncounters_: function(e, t) {
                            var n = this;
                            return (e || []).filter((function(e) {
                                if (e instanceof f.mBm) return !n.votedOn_[e.getId()];
                                var s = n.getUserId_(e);
                                return t && -1 !== t.indexOf(s) ? (e.setMyVote(1), !0) : (!s || !0 !== n.votedOn_[s]) && (void 0 === e.getMyVote() || 1 === e.getMyVote())
                            }))
                        },
                        getUserId_: function(e) {
                            return e instanceof f.q05 ? e.getUser().getUserId() : null
                        },
                        substituteUsers_: function(e, t) {
                            var n = this;
                            if (!t || 0 === t.length) return e;
                            var s = t.reduce((function(e, t) {
                                    var n = t.getType(),
                                        s = t.getDisplayStrategy(),
                                        i = t.getId();
                                    return (4 === n || 5 === n) && 4 === s && (e[i] = t), e
                                }), {}),
                                i = [];
                            return e.forEach((function(e) {
                                if (e instanceof f.q05)
                                    if (3 !== e.getUser().getType()) i.push(e);
                                    else {
                                        var t = s[n.getUserId_(e)];
                                        t && i.push(t)
                                    }
                            })), i
                        },
                        markUserAsVoted: function(e) {
                            this.votedOn_[e] = !0, this.saveVotedOn_()
                        },
                        cacheResponse_: function(e, t, n, s) {
                            var i = this;
                            if (!s) return n;
                            p = n;
                            var r = n.map((function(e) {
                                return (e = e.toJSON()).has_user_voted = !1, e
                            }));
                            return (0, a.A)((function() {
                                i.cache_.put(e, r, {
                                    ttl: t,
                                    noCommit: !i.commitCache
                                })
                            })), r
                        },
                        onCacheInvalidated_: function(e) {
                            I = "", this.votedOn_ = {}, p = null, v = null, this.trigger(b.EVENTS.INVALIDATED, e)
                        },
                        getRequest_: function(e, t, n, s) {
                            var r = this,
                                o = new i.Ay(e, n);
                            return o.on(486, this.handleFloatingButtonConfig_, this), t.forEach((function(e) {
                                o.on(e, s, r)
                            })), o.request(), o
                        },
                        handleFloatingButtonConfig_: function(e, t) {
                            var n = !e && 3 === t.getType();
                            this.cache_.put(y, n, {
                                ttl: this.getCacheTime_()
                            })
                        },
                        getCacheKey_: function(e, t) {
                            return "" + (e + (t.getRequestedPersonIds() || []).join(","))
                        },
                        getVersion_: function() {
                            return 7
                        },
                        reset: function() {
                            p = null, I = ""
                        },
                        decreaseYesVoteQuota: function() {
                            var e = v && v.getQuota();
                            if (e) {
                                var t = e.getYesVotesQuota();
                                t > 0 && (e.setYesVotesQuota(Math.max(t - 1, 0)), 0 === e.getYesVotesQuota() && this.invalidateAll())
                            }
                        }
                    }, "Encounters");
                b.getInstance = function() {
                    return s || (s = new b)
                }, t.A = b, (0, _.A)({
                    clearEncountersCache: function() {
                        b.getInstance().invalidateAll()
                    }
                })
            }
        }
    ]);
//# sourceMappingURL=8651.d7fd89627f2b89e7bd63.js.map
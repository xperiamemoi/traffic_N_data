/*! For license information please see 6416.ef8c3dcd2c161b4f5b9a.js.LICENSE.txt */
var _global;
! function() {
    try {
        var a = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            s = (new Error).stack;
        s && (a._sentryDebugIds = a._sentryDebugIds || {}, a._sentryDebugIds[s] = "0ab500b7-5d11-4ac1-9557-5eb2e39b3973", a._sentryDebugIdIdentifier = "sentry-dbid-0ab500b7-5d11-4ac1-9557-5eb2e39b3973")
    } catch (a) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var a = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                s = (new Error).stack;
            s && (a._sentryDebugIds = a._sentryDebugIds || {}, a._sentryDebugIds[s] = "0ab500b7-5d11-4ac1-9557-5eb2e39b3973", a._sentryDebugIdIdentifier = "sentry-dbid-0ab500b7-5d11-4ac1-9557-5eb2e39b3973")
        } catch (a) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [6416], {
            4571: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(96540),
                    n = e(32485),
                    o = e.n(n);
                s.A = ({
                    children: a,
                    isCompact: s,
                    tag: e = "div",
                    align: n = "center",
                    color: r = "default",
                    dataQA: c
                }) => {
                    const l = o()({
                            "csms-cta-box": !0,
                            "csms-cta-box--is-compact": s,
                            [`csms-cta-box--align-${n}`]: n,
                            [`csms-cta-box--${r}`]: r
                        }),
                        d = t.Children.toArray(a).filter(Boolean).map((a => (0, t.cloneElement)(a, {
                            isCompact: s
                        }))),
                        u = e,
                        p = {
                            "data-qa": "cta-box",
                            ...c
                        };
                    return (0, i.jsx)(u, {
                        className: l,
                        ...p,
                        children: d
                    })
                }
            },
            8323: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(78979);
                s.A = ({
                    children: a,
                    spacing: s = "loose"
                }) => (0, i.jsx)(t.A, {
                    spacing: s,
                    children: a
                })
            },
            8483: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(32485),
                    n = e.n(t),
                    o = e(84362),
                    r = e(62721);
                s.A = ({
                    name: a,
                    size: s = "stretch",
                    preserveAspectRatio: e,
                    color: t,
                    background: c,
                    shadow: l,
                    a11y: d,
                    supportsRtl: u,
                    customAsset: p
                }) => {
                    const h = n()({
                            "csms-icon": !0,
                            [`csms-icon--size-${s}`]: !0,
                            [`csms-icon--color-${t}`]: t,
                            [`csms-icon--background-${c}`]: c,
                            "csms-icon--shadow": l,
                            "csms-icon--is-flipped": u
                        }),
                        b = d ? .label && d.label.toUpperCase().indexOf("FIXME_") < 0 ? d.label : void 0,
                        f = Boolean(b);
                    let m = "image" === d ? .role ? "img" : void 0;
                    f || (m = void 0);
                    const x = t ? {
                        "--csms-icon-color": `var(--token-cosmos-semantic-color-icon-${t})`
                    } : void 0;
                    return (0, i.jsxs)("span", {
                        className: h,
                        "data-qa": "icon",
                        "data-qa-icon-name": a,
                        role: m,
                        "aria-label": m ? b : void 0,
                        "aria-hidden": !f || void 0,
                        style: x,
                        children: [!m && b ? (0, i.jsx)(o.A, {
                            children: b
                        }) : void 0, c ? (0, i.jsx)("span", {
                            className: "csms-icon__background"
                        }) : null, p || (0, i.jsx)(r.A, {
                            name: a,
                            preserveAspectRatio: e
                        })]
                    })
                }
            },
            12501: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(96540),
                    n = e(32485),
                    o = e.n(n),
                    r = e(84362),
                    c = e(40223);
                s.A = ({
                    text: a,
                    tag: s = "h1",
                    variant: e = "secondary",
                    fontSize: n,
                    a11y: l
                }) => {
                    const {
                        tokens: d
                    } = (0, t.useContext)(c.Ay), u = (0, t.useMemo)((() => function(a, s, e) {
                        if (s && "primary" === e) {
                            const e = parseInt(a.TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_FONT_SIZE.replace(/px$/, ""), 10),
                                i = parseInt(a.TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_FONT_SIZE.replace(/px$/, ""), 10),
                                t = parseInt(a.TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_FONT_SIZE.replace(/px$/, ""), 10),
                                n = parseInt(a.TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H1_LINE_HEIGHT.replace(/px$/, ""), 10),
                                o = parseInt(a.TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H2_LINE_HEIGHT.replace(/px$/, ""), 10),
                                r = parseInt(a.TOKEN_COSMOS_SEMANTIC_TYPOGRAPHY_H3_LINE_HEIGHT.replace(/px$/, ""), 10),
                                c = Math.round(n / e * 100) / 100,
                                l = Math.round(o / i * 100) / 100,
                                d = Math.round(r / t * 100) / 100;
                            let u = s || e;
                            u >= e ? u = e : u <= t && (u = t);
                            let p = c;
                            return u <= i && (p = l), u <= t && (p = d), {
                                "--csms-navigation-bar-title-font-size": `${u}px`,
                                "--csms-navigation-bar-title-line-height": p
                            }
                        }
                    }(d, n, e)), [d, n, e]), p = o()({
                        "csms-navigation-bar__title": !0,
                        [`csms-navigation-bar__title--${e}`]: e
                    }), h = s, b = Boolean(l ? .label) || void 0;
                    return (0, i.jsxs)(h, {
                        className: p,
                        "data-qa": "navbar-title",
                        "aria-hidden": Boolean(l ? .ariaHidden) || void 0,
                        children: [(0, i.jsx)(r.A, {
                            children: l ? .label
                        }), (0, i.jsx)("span", {
                            className: "csms-navigation-bar__title-text",
                            "aria-hidden": b,
                            style: u,
                            "data-qa": "csms-navbar-title-text",
                            children: a
                        })]
                    })
                }
            },
            15376: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(87908);
                s.A = ({
                    children: a,
                    hpadded: s,
                    vpadded: e,
                    tag: n,
                    isSticky: o
                }) => (0, i.jsx)(t.A, {
                    align: "top",
                    hpadded: s,
                    vpadded: e,
                    tag: n,
                    isSticky: o,
                    dataQA: {
                        "data-qa": "screen-header"
                    },
                    children: a
                })
            },
            20017: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(96540),
                    n = e(32485),
                    o = e.n(n),
                    r = e(84362),
                    c = e(8483),
                    l = e(33815),
                    d = e(93827);
                const u = ["facebook", "google", "apple"];
                s.A = ({
                    semantic: a = "primary",
                    styling: s = "default",
                    size: e = "medium",
                    narrow: n,
                    icon: p,
                    iconPosition: h = "start",
                    text: b,
                    tag: f = "button",
                    isDisabled: m,
                    isPressed: x,
                    isLoading: g,
                    onClick: v,
                    linkAttrs: j,
                    buttonAttrs: _,
                    innerRef: A,
                    dataQA: y,
                    a11y: F,
                    extraClass: k,
                    extraAttrs: M
                }) => {
                    const C = f,
                        z = o()({
                            "csms-button": !0,
                            [`csms-button--semantic-${a}`]: a,
                            [`csms-button--styling-${s}`]: s,
                            [`csms-button--${e}`]: !0,
                            "csms-button--narrow": n,
                            "is-pressed": (x || g) && !m,
                            "is-loading": g,
                            "js-touchable": !0,
                            "qa-button": !0,
                            [k]: k
                        });
                    let E = u.indexOf(s) >= 0;
                    const N = ["brand", "vkontakte", "odnoklassniki"].indexOf(s) >= 0 ? "default" : s;
                    "default" === N && (E = !1);
                    const $ = {
                            className: z,
                            style: E ? {
                                "--csms-button-background-color": `var(--token-cosmos-socialmediabutton-color-background-${N}, var(--token-cosmos-button-color-background-primary-${N}))`,
                                "--csms-button-content-color": `var(--token-cosmos-socialmediabutton-color-content, var(--token-cosmos-button-color-content-primary-${N}))`,
                                "--csms-button-icon-color": `var(--token-cosmos-socialmediabutton-color-icon, var(--token-cosmos-button-color-icon-primary-${N}))`,
                                "--csms-button-border-color": `var(--token-cosmos-socialmediabutton-color-background-${N}, var(--token-cosmos-button-color-border-primary-${N}))`
                            } : {
                                "--csms-button-background-color": `var(--token-cosmos-button-color-background-${a}-${N})`,
                                "--csms-button-content-color": `var(--token-cosmos-button-color-content-${a}-${N})`,
                                "--csms-button-icon-color": `var(--token-cosmos-button-color-icon-${a}-${N})`,
                                "--csms-button-border-color": `var(--token-cosmos-button-color-border-${a}-${N})`,
                                "--csms-button-border-width": `var(--token-cosmos-button-border-width-${a}-${N})`,
                                "--csms-button-border-style": `var(--token-cosmos-button-border-style-${a}-${N})`
                            },
                            onClick: m ? void 0 : v,
                            disabled: m,
                            "aria-live": "polite",
                            "aria-busy": g,
                            ref: A,
                            "data-qa": "button",
                            ...y,
                            ...M
                        },
                        S = Boolean(F ? .label),
                        B = a => (0, i.jsx)("span", {
                            className: `csms-button__icon csms-button__icon--${a}`,
                            "aria-hidden": !0,
                            children: p && (0, i.jsx)(c.A, {
                                name: p
                            })
                        }),
                        w = (0, i.jsxs)(t.Fragment, {
                            children: [(0, i.jsxs)("span", {
                                className: "csms-button__content",
                                children: [p && "start" === h && B("start"), b ? (0, i.jsx)(d.Qi, {
                                    breakWords: !0,
                                    className: "csms-button__text",
                                    a11y: {
                                        ariaHidden: g || S
                                    },
                                    children: b
                                }) : null, (0, i.jsx)(r.A, {
                                    children: F ? .label
                                }), p && "end" === h && B("end")]
                            }), g ? (0, i.jsx)("span", {
                                className: "csms-button__loader",
                                children: (0, i.jsx)(l.A, {
                                    a11y: {
                                        label: F ? .loaderLabel
                                    }
                                })
                            }) : null]
                        });
                    if ("a" === f) return (0, i.jsx)(C, { ...$,
                        "aria-disabled": m || !j ? .href && !v || void 0,
                        role: m || !j ? .href ? "link" : void 0,
                        tabIndex: j ? .href || !v || m ? void 0 : 0,
                        ...j,
                        href: m ? void 0 : j ? .href,
                        children: w
                    }); {
                        const a = {
                            type: "button",
                            ..._
                        };
                        return (0, i.jsx)(C, { ...$,
                            ...a,
                            children: w
                        })
                    }
                }
            },
            27895: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(32485),
                    n = e.n(t);
                s.A = ({
                    children: a,
                    size: s,
                    align: e = "start",
                    isCompact: t
                }) => {
                    const o = n()({
                            "csms-cta-box__media": !0,
                            "csms-cta-box__media--is-compact": t
                        }),
                        r = n()({
                            "csms-cta-box__media-content": !0,
                            [`csms-cta-box__media-content--align-${e}`]: e,
                            [`csms-cta-box__media-content--size-${s}`]: s
                        });
                    return (0, i.jsx)("div", {
                        className: o,
                        "data-qa": "cta-box-media",
                        children: (0, i.jsx)("div", {
                            className: r,
                            children: a
                        })
                    })
                }
            },
            28733: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(33943);
                s.A = ({
                    children: a,
                    isWide: s
                }) => (0, i.jsx)(t.A, {
                    slot: "primary",
                    isWide: s,
                    children: a
                })
            },
            32485: function(a, s) {
                var e;
                ! function() {
                    "use strict";
                    var i = {}.hasOwnProperty;

                    function t() {
                        for (var a = [], s = 0; s < arguments.length; s++) {
                            var e = arguments[s];
                            if (e) {
                                var n = typeof e;
                                if ("string" === n || "number" === n) a.push(e);
                                else if (Array.isArray(e)) {
                                    if (e.length) {
                                        var o = t.apply(null, e);
                                        o && a.push(o)
                                    }
                                } else if ("object" === n)
                                    if (e.toString === Object.prototype.toString)
                                        for (var r in e) i.call(e, r) && e[r] && a.push(r);
                                    else a.push(e.toString())
                            }
                        }
                        return a.join(" ")
                    }
                    a.exports ? (t.default = t, a.exports = t) : void 0 === (e = function() {
                        return t
                    }.apply(s, [])) || (a.exports = e)
                }()
            },
            33815: function(a, s, e) {
                "use strict";
                var i = e(74848);
                s.A = ({
                    a11y: a
                }) => (0, i.jsx)("span", {
                    className: "csms-loader",
                    "data-qa": "loader",
                    role: a ? .label ? "status" : void 0,
                    "aria-label": a ? .label,
                    children: (0, i.jsxs)("svg", {
                        viewBox: "0 0 64 64",
                        width: "0",
                        height: "0",
                        "aria-hidden": !0,
                        children: [(0, i.jsx)("circle", {
                            cx: "12",
                            cy: "32",
                            r: "8",
                            className: "csms-loader__dot"
                        }), (0, i.jsx)("circle", {
                            cx: "32",
                            cy: "32",
                            r: "8",
                            className: "csms-loader__dot"
                        }), (0, i.jsx)("circle", {
                            cx: "52",
                            cy: "32",
                            r: "8",
                            className: "csms-loader__dot"
                        })]
                    })
                })
            },
            33943: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(32485),
                    n = e.n(t);
                s.A = ({
                    children: a,
                    slot: s,
                    isWide: e
                }) => {
                    const t = n()({
                        "csms-navigation-bar__slot": !0,
                        [`csms-navigation-bar__slot--${s}`]: s,
                        "csms-navigation-bar__slot--is-wide": e
                    });
                    return (0, i.jsx)("div", {
                        className: t,
                        "data-qa": `navbar-slot-${s}`,
                        children: a
                    })
                }
            },
            40223: function(a, s, e) {
                "use strict";
                e.d(s, {
                    Kq: function() {
                        return o
                    },
                    ZC: function() {
                        return n
                    },
                    dw: function() {
                        return r
                    }
                });
                var i = e(96540);
                const t = (0, i.createContext)({
                    brand: "moumi",
                    assetStore: {},
                    tokens: {}
                });
                s.Ay = t;
                const n = t.Consumer,
                    o = t.Provider,
                    r = () => {
                        const {
                            tokens: a
                        } = (0, i.useContext)(t);
                        return a
                    }
            },
            40578: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(32485),
                    n = e.n(t),
                    o = e(93827);
                s.A = ({
                    text: a,
                    color: s = "default",
                    tag: e = "div",
                    dangerous: t,
                    isCompact: r
                }) => {
                    const c = n()({
                        "csms-cta-box__header": !0,
                        [`csms-cta-box__header--${s}`]: s,
                        "csms-cta-box__header--is-compact": r
                    });
                    return (0, i.jsx)(o.Qi, {
                        className: c,
                        breakWords: !0,
                        tag: e,
                        dangerous: t,
                        dataQA: {
                            "data-qa": "cta-box-header"
                        },
                        children: a
                    })
                }
            },
            45869: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(32485),
                    n = e.n(t),
                    o = e(84362);
                s.A = ({
                    status: a,
                    borderColor: s = "white",
                    counterText: e,
                    counterStatus: t,
                    a11y: r
                }) => {
                    const c = n()({
                            "csms-dot-counter-notification": !0,
                            [`csms-dot-counter-notification--is-${a}`]: a
                        }),
                        l = n()({
                            "csms-dot-counter-notification__dot": !0,
                            [`csms-dot-counter-notification__dot--border-color-${s}`]: s
                        }),
                        d = n()({
                            "csms-dot-counter-notification__counter": !0,
                            [`csms-dot-counter-notification__counter--is-${t}`]: t,
                            [`csms-dot-counter-notification__counter--border-color-${s}`]: s
                        }),
                        u = Boolean(r ? .label);
                    return (0, i.jsxs)("div", {
                        className: c,
                        "aria-live": "polite",
                        "aria-hidden": "hidden" === a,
                        "data-qa": "dot-counter-notification",
                        children: [(0, i.jsx)("div", {
                            className: l
                        }), e ? (0, i.jsx)("div", {
                            className: d,
                            "aria-hidden": u,
                            "data-qa": "dot-counter-notification-text",
                            children: e
                        }) : null, (0, i.jsx)(o.A, {
                            children: r ? .label
                        })]
                    })
                }
            },
            46770: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(32485),
                    n = e.n(t),
                    o = e(8323);
                s.A = ({
                    children: a,
                    isCompact: s
                }) => {
                    const e = n()({
                        "csms-cta-box__buttons": !0,
                        "csms-cta-box__buttons--is-compact": s
                    });
                    return (0, i.jsx)("div", {
                        className: e,
                        "data-qa": "cta-box-buttons",
                        children: (0, i.jsx)(o.A, {
                            children: a
                        })
                    })
                }
            },
            47901: function(a, s, e) {
                "use strict";
                var i = e(74848);
                s.A = ({
                    children: a,
                    dataQA: s,
                    innerRef: e
                }) => {
                    const t = {
                        "data-qa": "screen",
                        ...s
                    };
                    return (0, i.jsx)("div", {
                        className: "csms-screen",
                        ref: e,
                        ...t,
                        children: a
                    })
                }
            },
            62721: function(a, s, e) {
                "use strict";
                e.d(s, {
                    A: function() {
                        return c
                    }
                });
                var i = e(74848),
                    t = e(40223);
                var n = {
                    "badge-counter-1": function({
                        preserveAspectRatio: a
                    }) {
                        return (0, i.jsx)("svg", {
                            "aria-hidden": !0,
                            "data-origin": "pipeline",
                            preserveAspectRatio: a,
                            viewBox: "0 0 44 44",
                            children: (0, i.jsxs)("g", {
                                fill: "none",
                                fillRule: "evenodd",
                                children: [(0, i.jsx)("rect", {
                                    fill: "var(--token-cosmos-semantic-color-supportive-feedback-notification)",
                                    width: 44,
                                    height: 44,
                                    rx: 22
                                }), (0, i.jsx)("path", {
                                    fill: "#FFF",
                                    d: "M22 31V15.45l-5 4.073V17l4.9-4H24l-.006 18.058z"
                                })]
                            })
                        })
                    },
                    "loading-dots": function({
                        preserveAspectRatio: a
                    }) {
                        return (0, i.jsxs)("svg", {
                            "aria-hidden": !0,
                            viewBox: "0 0 64 64",
                            "data-origin": "cosmos-local",
                            preserveAspectRatio: a,
                            children: [(0, i.jsx)("circle", {
                                cx: "12",
                                cy: "32",
                                r: "8",
                                children: (0, i.jsx)("animate", {
                                    attributeName: "r",
                                    from: "8",
                                    to: "8",
                                    dur: "1.3s",
                                    values: "8; 4; 4; 8",
                                    keyTimes: "0; 0.25; 0.75; 1",
                                    begin: "0s",
                                    repeatCount: "indefinite"
                                })
                            }), (0, i.jsx)("circle", {
                                cx: "32",
                                cy: "32",
                                r: "8",
                                children: (0, i.jsx)("animate", {
                                    attributeName: "r",
                                    from: "8",
                                    to: "8",
                                    dur: "1.3s",
                                    values: "8; 4; 4; 8",
                                    keyTimes: "0; 0.25; 0.75; 1",
                                    begin: "0.26s",
                                    repeatCount: "indefinite"
                                })
                            }), (0, i.jsx)("circle", {
                                cx: "52",
                                cy: "32",
                                r: "8",
                                children: (0, i.jsx)("animate", {
                                    attributeName: "r",
                                    from: "8",
                                    to: "8",
                                    dur: "1.3s",
                                    values: "8; 4; 4; 8",
                                    keyTimes: "0; 0.25; 0.75; 1",
                                    begin: "0.53s",
                                    repeatCount: "indefinite"
                                })
                            })]
                        })
                    },
                    "premium-potion": function({
                        preserveAspectRatio: a
                    }) {
                        return (0, i.jsxs)("svg", {
                            "aria-hidden": !0,
                            viewBox: "0 0 64 64",
                            "data-origin": "cosmos-local",
                            preserveAspectRatio: a,
                            children: [(0, i.jsx)("path", {
                                d: "M13.93 54.74a22.99 22.99 0 0013.85 6.57 23.02 23.02 0 0024.1-15.1 22.7 22.7 0 00-5.42-23.8 23.1 23.1 0 00-32.53.01 22.75 22.75 0 000 32.32",
                                fill: "#00A2DB"
                            }), (0, i.jsx)("path", {
                                d: "M27.78 61.3c6.66.7 13.47-1.58 18.68-6.56a21.57 21.57 0 006.6-18.56 23.02 23.02 0 00-24.1 15.1 22.7 22.7 0 00-1.18 10.03",
                                fill: "#27D3FC"
                            }), (0, i.jsx)("path", {
                                d: "M17.43 51.26A18.04 18.04 0 0028.3 56.4a18.07 18.07 0 0018.9-11.84 17.82 17.82 0 00-4.25-18.67c-7.04-7-18.47-7-25.52 0a17.85 17.85 0 000 25.36",
                                fill: "#007EC2"
                            }), (0, i.jsx)("path", {
                                d: "M13.36 38.4c1.1 2.32 3.9 3.43 6.53 3.4 3.34-.03 7.05-.76 10.25-1.68a3.13 3.13 0 002.38-3.03h15.72a18 18 0 01-5.29 14.17c-4 3.98-9.42 5.7-14.65 5.15a18.03 18.03 0 01-14.77-10.94 17.81 17.81 0 01-1.38-6.83v-1.55h.12c.23.52.6.98 1.09 1.32",
                                fill: "#7000E3"
                            }), (0, i.jsx)("path", {
                                d: "M12.15 37.09c.27 1.58 1.5 3.08 4.02 4.24 3.3 1.53 8.35 2.5 14.02 2.5s10.72-.97 14.03-2.5c2.51-1.16 4.02-2.64 4.02-4.24 0-3.73-7.72-6.17-24.04.87-9.13 3.95-12.25-2.1-12.05-.87",
                                fill: "#AF61FF"
                            }), (0, i.jsx)("path", {
                                d: "M21.66 55.52A3.61 3.61 0 0027.8 53a3.56 3.56 0 00-3.6-3.58A3.61 3.61 0 0020.61 53a3.56 3.56 0 001.05 2.52zM34.4 28.01A2.12 2.12 0 0038 26.52a2.1 2.1 0 00-2.11-2.1 2.12 2.12 0 00-2.12 2.1 2.1 2.1 0 00.62 1.49",
                                fill: "#fff"
                            }), (0, i.jsx)("path", {
                                d: "M1.88 28.03L21.07 8.97l6.74 6.7c2.97 2.96 1.08 9.62-4.21 14.88-5.3 5.26-12 7.14-14.97 4.19l-6.75-6.7z",
                                fill: "#27D3FC"
                            }), (0, i.jsx)("path", {
                                d: "M6.12 23.83l11.2 11.13c2.1-.95 4.3-2.44 6.28-4.41a21.5 21.5 0 004.43-6.24l-11.2-11.13-10.7 10.65z",
                                fill: "#3DDFF9"
                            }), (0, i.jsx)("path", {
                                d: "M12.37 17.61l12.1 12.02a19.07 19.07 0 004.28-7.33c.07-.26.13-.5.18-.76l-10.26-10.2-6.3 6.27z",
                                fill: "#fff"
                            }), (0, i.jsx)("path", {
                                d: "M1.88 28.03c2.97 2.95 9.68 1.08 14.97-4.18 5.3-5.27 7.19-11.93 4.21-14.88C18.1 6.02 11.4 7.9 6.1 13.16.8 18.42-1.1 25.08 1.88 28.03z",
                                fill: "#D2FFFF"
                            }), (0, i.jsx)("path", {
                                d: "M5.46 23.74c.8.78 2.04.98 3.46.67a11.26 11.26 0 005.24-3.1 11.2 11.2 0 003.11-5.2c.32-1.41.12-2.65-.67-3.44-1.73-1.71-5.61-.62-8.69 2.43-3.08 3.06-4.17 6.92-2.45 8.64",
                                fill: "#3DDFF9"
                            }), (0, i.jsx)("path", {
                                d: "M8.92 24.4a11.28 11.28 0 005.24-3.1 11.2 11.2 0 003.11-5.2 11.27 11.27 0 00-5.23 3.1 11.17 11.17 0 00-3.12 5.2",
                                fill: "#00A2DB"
                            }), (0, i.jsx)("path", {
                                d: "M5.4 18.13a1.87 1.87 0 003.2 1.32 1.87 1.87 0 10-3.05-2.03c-.1.22-.15.46-.15.7",
                                fill: "#7000E3"
                            }), (0, i.jsx)("path", {
                                d: "M11.06 13.9a1.87 1.87 0 003.2 1.32 1.87 1.87 0 00.54-1.32 1.87 1.87 0 00-3.2-1.32c-.34.35-.54.82-.54 1.32",
                                fill: "#AF61FF"
                            }), (0, i.jsx)("path", {
                                d: "M6.22 9.91a1.87 1.87 0 003.2 1.32 1.87 1.87 0 00.55-1.32 1.87 1.87 0 00-3.2-1.32c-.35.35-.55.82-.55 1.32zm7.76 11.52a9.7 9.7 0 01-4.08 2.51 4.28 4.28 0 015.97-5.02c-.5.93-1.14 1.77-1.9 2.5zm-2.8-18.66c0 .44.36.8.81.8a.8.8 0 00.57-1.37.8.8 0 00-.57-.24.8.8 0 00-.8.8zM20.11 41c.2 1.17 5.8 1.23 12.53.13 6.73-1.1 12.02-2.94 11.83-4.1-.2-1.17-5.8-1.23-12.53-.13C25.2 38 19.9 39.84 20.1 41z",
                                fill: "#7000E3"
                            }), (0, i.jsx)("path", {
                                d: "M25.31 40.05c.08.5 3.11.42 6.76-.18s6.54-1.48 6.46-1.98c-.08-.5-3.1-.42-6.76.17-3.65.6-6.54 1.49-6.46 1.99z",
                                fill: "#AF61FF"
                            })]
                        })
                    },
                    "credits-handful": function({
                        preserveAspectRatio: a
                    }) {
                        return (0, i.jsxs)("svg", {
                            "aria-hidden": !0,
                            viewBox: "0 0 64 64",
                            "data-origin": "cosmos-local",
                            preserveAspectRatio: a,
                            fill: "none",
                            children: [(0, i.jsx)("path", {
                                opacity: ".05",
                                d: "M32 51.09c17.1 0 30.98-1.03 30.98-2.3 0-1.28-13.87-2.32-30.98-2.32-17.1 0-30.98 1.04-30.98 2.31 0 1.28 13.87 2.31 30.98 2.31z",
                                fill: "#000"
                            }), (0, i.jsx)("path", {
                                d: "M17.01 51.09c7.54 0 13.66-1.83 13.66-4.09 0-2.25-6.12-4.08-13.66-4.08S3.36 44.75 3.36 47.01c0 2.25 6.11 4.08 13.65 4.08z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M3.36 42.92h27.3v3.9H3.37v-3.9z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M17.01 47.18c7.54 0 13.66-1.83 13.66-4.08C30.67 40.84 24.55 39 17 39S3.36 40.84 3.36 43.1c0 2.25 6.11 4.08 13.65 4.08z",
                                fill: "#FFCE00"
                            }), (0, i.jsx)("path", {
                                d: "M17.34 45.05c4.05 0 7.33-.95 7.33-2.13s-3.28-2.13-7.33-2.13c-4.04 0-7.32.95-7.32 2.13s3.28 2.13 7.32 2.13zM45.99 50.38c7.54 0 13.66-1.83 13.66-4.09 0-2.25-6.12-4.08-13.66-4.08s-13.66 1.83-13.66 4.09c0 2.25 6.12 4.08 13.66 4.08z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M32.33 42.21h27.32v3.9H32.33v-3.9z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M45.99 46.83c7.54 0 13.66-1.83 13.66-4.09 0-2.25-6.12-4.08-13.66-4.08s-13.66 1.83-13.66 4.08c0 2.26 6.12 4.09 13.66 4.09z",
                                fill: "#FFCE00"
                            }), (0, i.jsx)("path", {
                                d: "M45.66 44.34c4.04 0 7.32-.95 7.32-2.13s-3.28-2.13-7.32-2.13c-4.05 0-7.33.95-7.33 2.13s3.28 2.13 7.33 2.13z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M44.99 45.05c7.54 0 13.66-1.83 13.66-4.08 0-2.26-6.12-4.09-13.66-4.09s-13.66 1.83-13.66 4.09c0 2.25 6.12 4.08 13.66 4.08z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M31.33 37.6h27.32v3.9H31.33v-3.9z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M44.99 41.5c7.54 0 13.66-1.83 13.66-4.09 0-2.25-6.12-4.08-13.66-4.08s-13.66 1.83-13.66 4.08c0 2.26 6.12 4.09 13.66 4.09z",
                                fill: "#FFCE00"
                            }), (0, i.jsx)("path", {
                                d: "M45.32 39.01c4.05 0 7.33-.95 7.33-2.13s-3.28-2.13-7.33-2.13c-4.04 0-7.33.95-7.33 2.13s3.29 2.13 7.33 2.13z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M47.66 40.79c7.54 0 13.65-1.83 13.65-4.09 0-2.25-6.11-4.08-13.66-4.08-7.54 0-13.65 1.83-13.65 4.08 0 2.26 6.11 4.09 13.66 4.09z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M34 32.62H61.3v3.9H34v-3.9z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M47.66 37.24c7.54 0 13.65-1.83 13.65-4.09s-6.11-4.08-13.66-4.08c-7.54 0-13.65 1.82-13.65 4.08s6.11 4.09 13.66 4.09z",
                                fill: "#FFCE00"
                            }), (0, i.jsx)("path", {
                                d: "M18.01 46.12c7.54 0 13.66-1.83 13.66-4.09 0-2.25-6.12-4.08-13.66-4.08S4.35 39.78 4.35 42.03c0 2.26 6.12 4.09 13.66 4.09z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M4.36 38.66h27.3v3.9H4.37v-3.9z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M18.01 42.56c7.54 0 13.66-1.82 13.66-4.08S25.55 34.4 18 34.4 4.35 36.22 4.35 38.48s6.12 4.09 13.66 4.09z",
                                fill: "#FFCE00"
                            }), (0, i.jsx)("path", {
                                d: "M18.34 40.08c4.05 0 7.33-.96 7.33-2.13 0-1.18-3.28-2.13-7.33-2.13-4.04 0-7.32.95-7.32 2.13 0 1.17 3.28 2.13 7.32 2.13z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M17.01 41.5c7.54 0 13.66-1.83 13.66-4.09 0-2.25-6.12-4.08-13.66-4.08S3.36 35.16 3.36 37.4c0 2.26 6.11 4.09 13.65 4.09z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M3.36 33.33h27.3v3.9H3.37v-3.9z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M17.01 37.6c7.54 0 13.66-1.84 13.66-4.1 0-2.25-6.12-4.08-13.66-4.08S3.36 31.25 3.36 33.51c0 2.25 6.11 4.08 13.65 4.08z",
                                fill: "#FFCE00"
                            }), (0, i.jsx)("path", {
                                d: "M17.34 35.46c4.05 0 7.33-.95 7.33-2.13s-3.28-2.13-7.33-2.13c-4.04 0-7.32.95-7.32 2.13s3.28 2.13 7.32 2.13z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M17.01 35.46c7.54 0 13.66-1.83 13.66-4.09 0-2.25-6.12-4.08-13.66-4.08S3.36 29.12 3.36 31.38c0 2.25 6.11 4.08 13.65 4.08z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M3.36 28h27.3v3.9H3.37V28z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M17.01 31.9c7.54 0 13.66-1.82 13.66-4.08 0-2.25-6.12-4.08-13.66-4.08S3.36 25.57 3.36 27.82c0 2.26 6.11 4.09 13.65 4.09z",
                                fill: "#FFCE00"
                            }), (0, i.jsx)("path", {
                                d: "M17.34 29.42c4.05 0 7.33-.95 7.33-2.13s-3.28-2.13-7.33-2.13c-4.04 0-7.32.95-7.32 2.13s3.28 2.13 7.32 2.13z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M18.01 30.13c7.54 0 13.66-1.83 13.66-4.08 0-2.26-6.12-4.09-13.66-4.09S4.35 23.8 4.35 26.05c0 2.25 6.12 4.08 13.66 4.08z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M4.36 21.96h27.3v3.9H4.37v-3.9z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M18.01 26.58c7.54 0 13.66-1.83 13.66-4.08 0-2.26-6.12-4.09-13.66-4.09S4.35 20.24 4.35 22.5c0 2.25 6.12 4.08 13.66 4.08z",
                                fill: "#FFCE00"
                            }), (0, i.jsx)("path", {
                                d: "M18.34 24.1c4.05 0 7.33-.96 7.33-2.14 0-1.17-3.28-2.13-7.33-2.13-4.04 0-7.32.96-7.32 2.13 0 1.18 3.28 2.13 7.32 2.13z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M16.68 25.51c7.54 0 13.66-1.82 13.66-4.08s-6.12-4.09-13.66-4.09-13.66 1.83-13.66 4.09 6.12 4.08 13.66 4.08z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M3.02 17.7h27.32v3.9H3.02v-3.9z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M16.68 21.6c7.54 0 13.66-1.82 13.66-4.08 0-2.25-6.12-4.08-13.66-4.08S3.02 15.27 3.02 17.52c0 2.26 6.12 4.09 13.66 4.09z",
                                fill: "#FFCE00"
                            }), (0, i.jsx)("path", {
                                d: "M16.34 19.48c4.05 0 7.33-.96 7.33-2.14 0-1.17-3.28-2.13-7.33-2.13-4.04 0-7.32.96-7.32 2.13 0 1.18 3.28 2.14 7.32 2.14z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M21.68 20.54c7.54 0 13.65-1.83 13.65-4.08 0-2.26-6.11-4.09-13.65-4.09-7.55 0-13.66 1.83-13.66 4.09 0 2.25 6.11 4.08 13.66 4.08z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M8.02 12.37h27.31v3.9H8.02v-3.9z",
                                fill: "#FFBC00"
                            }), (0, i.jsx)("path", {
                                d: "M21.68 16.28c7.54 0 13.65-1.83 13.65-4.09 0-2.25-6.11-4.08-13.65-4.08-7.55 0-13.66 1.83-13.66 4.08 0 2.26 6.11 4.09 13.66 4.09z",
                                fill: "#FFCE00"
                            }), (0, i.jsx)("path", {
                                opacity: ".05",
                                d: "M29.18 57.86c5.94 0 10.76-.58 10.76-1.28 0-.71-4.82-1.28-10.76-1.28-5.93 0-10.75.57-10.75 1.28 0 .7 4.82 1.28 10.75 1.28z",
                                fill: "#000"
                            }), (0, i.jsx)("path", {
                                d: "M29.18 57.86a13.31 13.31 0 100-26.63 13.31 13.31 0 000 26.63z",
                                fill: "#FFDA00"
                            }), (0, i.jsx)("path", {
                                d: "M29.18 57.6a13.06 13.06 0 100-26.12 13.06 13.06 0 000 26.13z",
                                stroke: "#FB0"
                            }), (0, i.jsx)("path", {
                                opacity: ".9",
                                d: "M32.38 39.42c-1.26 0-2.45.58-3.2 1.57a4.05 4.05 0 00-4.43-1.35c-1.63.52-2.73 2-2.73 3.66 0 3.5 4.8 7.9 7.16 7.9 2.37 0 7.17-4.4 7.17-7.9a3.94 3.94 0 00-3.97-3.88z",
                                fill: "#FFB200"
                            }), (0, i.jsx)("path", {
                                d: "M24.88 10.24a7.86 7.86 0 00-3.04.52c-.97-.37-2-.55-3.04-.52-2.09 0-3.79.58-3.79 1.29 0 1.16 4.58 2.62 6.83 2.62s6.83-1.46 6.83-2.63c0-.71-1.7-1.28-3.79-1.28zM50.86 30.5a7.86 7.86 0 00-3.04.52c-.97-.37-2-.55-3.04-.52-2.09 0-3.79.58-3.79 1.28 0 1.17 4.58 2.63 6.83 2.63s6.83-1.46 6.83-2.63c0-.7-1.7-1.28-3.79-1.28z",
                                fill: "#FFBC00"
                            })]
                        })
                    }
                };
                var o = function({
                    name: a,
                    onError: s
                }) {
                    return s ? s() : console.log(`Missing asset ${a}`), (0, i.jsx)("svg", {
                        viewBox: "0 0 64 64",
                        "aria-hidden": !0,
                        children: (0, i.jsx)("title", {
                            children: `Warning: invalid asset name "${a}" supplied to Icon → Asset components (that asset doesn't exist!)`
                        })
                    })
                };

                function r({
                    name: a,
                    preserveAspectRatio: s,
                    assetStore: e
                }) {
                    const t = n[a];
                    if (t) return (0, i.jsx)(t, {
                        preserveAspectRatio: s
                    });
                    const r = e[a];
                    return r ? (0, i.jsx)(r, {
                        preserveAspectRatio: s
                    }) : (0, i.jsx)(o, {
                        name: a
                    })
                }
                var c = ({
                    name: a,
                    preserveAspectRatio: s
                }) => (0, i.jsx)(t.ZC, {
                    children: ({
                        assetStore: e
                    }) => (0, i.jsx)(r, {
                        name: a,
                        preserveAspectRatio: s,
                        assetStore: e
                    })
                })
            },
            74848: function(a, s, e) {
                "use strict";
                a.exports = e(21020)
            },
            77001: function(a, s, e) {
                "use strict";
                e.d(s, {
                    E: function() {
                        return o
                    }
                });
                var i = e(74848),
                    t = e(32485),
                    n = e.n(t);
                const o = ({
                    children: a,
                    size: s,
                    tag: e = "span",
                    align: t,
                    color: o,
                    inline: r,
                    ellipsis: c,
                    breakWords: l,
                    dangerous: d,
                    id: u,
                    a11y: p,
                    className: h,
                    dataQA: b
                }) => {
                    const f = n()(h, {
                            [`csms-${s}`]: s,
                            [`csms-text-align-${t}`]: t,
                            "csms-text-ellipsis": c,
                            "csms-text-break-words": l,
                            [`csms-text-color-${o}`]: o
                        }),
                        m = e;
                    let x = {};
                    return r && "span" !== e && (x = {
                        display: "inline"
                    }), r || "span" !== e || (x = {
                        display: "block"
                    }), d ? (0, i.jsx)(m, {
                        id: u,
                        className: f,
                        dangerouslySetInnerHTML: {
                            __html: a
                        },
                        style: x,
                        "aria-hidden": Boolean(p ? .ariaHidden) || void 0,
                        ...b
                    }) : (0, i.jsx)(m, {
                        id: u,
                        className: f,
                        style: x,
                        "aria-hidden": Boolean(p ? .ariaHidden) || void 0,
                        ...b,
                        children: a
                    })
                };
                s.A = 8792 == e.j ? o : null
            },
            78979: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(96540),
                    n = e(32485),
                    o = e.n(n);
                s.A = ({
                    fullWidth: a = !0,
                    direction: s = "column",
                    align: e = "stretch",
                    spacing: n = "loose",
                    children: r,
                    dataQA: c
                }) => {
                    const l = o()({
                        "csms-stack": !0,
                        "csms-stack--fullwidth": a,
                        [`csms-stack--${s}`]: s,
                        [`csms-stack--align-${e}`]: e,
                        [`csms-stack--spacing-${n}`]: n
                    });
                    return (0, i.jsx)("div", {
                        className: l,
                        "data-qa": "csms-stack",
                        ...c,
                        children: t.Children.toArray(r).filter(Boolean).map(((a, s) => (0, i.jsx)("div", {
                            className: "csms-stack__item",
                            "data-qa": "csms-stack-item",
                            children: a
                        }, s)))
                    })
                }
            },
            84362: function(a, s, e) {
                "use strict";
                var i = e(74848);
                s.A = ({
                    children: a,
                    id: s,
                    tag: e = "span",
                    dangerous: t,
                    a11y: n
                }) => {
                    const o = e;
                    return a ? t ? (0, i.jsx)(o, {
                        className: "csms-a11y-visually-hidden",
                        id: s,
                        dangerouslySetInnerHTML: {
                            __html: a
                        },
                        "aria-hidden": Boolean(n ? .ariaHidden) || void 0,
                        "aria-live": n ? .ariaLive
                    }) : (0, i.jsx)(o, {
                        className: "csms-a11y-visually-hidden",
                        id: s,
                        "aria-hidden": Boolean(n ? .ariaHidden) || void 0,
                        "aria-live": n ? .ariaLive,
                        children: a
                    }) : null
                }
            },
            87184: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(87908);
                s.A = ({
                    children: a,
                    hpadded: s,
                    vpadded: e,
                    align: n,
                    tag: o
                }) => (0, i.jsx)(t.A, {
                    align: n,
                    hpadded: s,
                    vpadded: e,
                    tag: o,
                    children: a
                })
            },
            87908: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(32485),
                    n = e.n(t);
                s.A = ({
                    children: a,
                    hpadded: s,
                    vpadded: e,
                    align: t = "top",
                    tag: o = "div",
                    isSticky: r,
                    dataQA: c
                }) => {
                    const l = o,
                        d = n()({
                            "csms-screen__block": !0,
                            "csms-screen__block--hpadded": s,
                            "csms-screen__block--vpadded": e,
                            [`csms-screen__block--align-${t}`]: t,
                            [`csms-screen__block--sticky-${t}`]: r
                        });
                    return a ? (0, i.jsx)(l, {
                        className: d,
                        ...c,
                        children: a
                    }) : null
                }
            },
            89769: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(33943);
                s.A = ({
                    children: a,
                    isWide: s
                }) => (0, i.jsx)(t.A, {
                    slot: "secondary",
                    isWide: s,
                    children: a
                })
            },
            93827: function(a, s, e) {
                "use strict";
                e.d(s, {
                    Dl: function() {
                        return n
                    },
                    HL: function() {
                        return b
                    },
                    P1: function() {
                        return f
                    },
                    P2: function() {
                        return m
                    },
                    P3: function() {
                        return x
                    },
                    Qi: function() {
                        return g
                    },
                    Sz: function() {
                        return c
                    },
                    ZS: function() {
                        return l
                    },
                    Zb: function() {
                        return r
                    },
                    er: function() {
                        return p
                    },
                    gT: function() {
                        return d
                    },
                    hE: function() {
                        return h
                    },
                    rc: function() {
                        return u
                    },
                    w4: function() {
                        return o
                    }
                });
                var i = e(74848),
                    t = e(77001);
                const n = ({
                        children: a,
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u
                    }) => (0, i.jsx)(t.E, {
                        size: "display-2",
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u,
                        children: a
                    }),
                    o = ({
                        children: a,
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u
                    }) => (0, i.jsx)(t.E, {
                        size: "display-3",
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u,
                        children: a
                    }),
                    r = ({
                        children: a,
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u
                    }) => (0, i.jsx)(t.E, {
                        size: "header-1",
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u,
                        children: a
                    }),
                    c = ({
                        children: a,
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u
                    }) => (0, i.jsx)(t.E, {
                        size: "header-2",
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u,
                        children: a
                    }),
                    l = ({
                        children: a,
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u
                    }) => (0, i.jsx)(t.E, {
                        size: "header-3",
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u,
                        children: a
                    }),
                    d = ({
                        children: a,
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u
                    }) => (0, i.jsx)(t.E, {
                        size: "header-4",
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u,
                        children: a
                    }),
                    u = ({
                        children: a,
                        tag: s,
                        color: e,
                        inline: n,
                        breakWords: o,
                        dangerous: r,
                        a11y: c,
                        dataQA: l
                    }) => (0, i.jsx)(t.E, {
                        size: "action",
                        tag: s,
                        color: e,
                        inline: n,
                        breakWords: o,
                        dangerous: r,
                        a11y: c,
                        dataQA: l,
                        children: a
                    }),
                    p = ({
                        children: a,
                        tag: s,
                        color: e,
                        inline: n,
                        breakWords: o,
                        dangerous: r,
                        a11y: c,
                        dataQA: l
                    }) => (0, i.jsx)(t.E, {
                        size: "action-small",
                        tag: s,
                        color: e,
                        inline: n,
                        breakWords: o,
                        dangerous: r,
                        a11y: c,
                        dataQA: l,
                        children: a
                    }),
                    h = ({
                        children: a,
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u
                    }) => (0, i.jsx)(t.E, {
                        size: "p-title",
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u,
                        children: a
                    }),
                    b = ({
                        children: a,
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u
                    }) => (0, i.jsx)(t.E, {
                        size: "caption",
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        a11y: d,
                        dataQA: u,
                        children: a
                    }),
                    f = ({
                        children: a,
                        tag: s,
                        weight: e,
                        align: n,
                        color: o,
                        inline: r,
                        ellipsis: c,
                        breakWords: l,
                        dangerous: d,
                        a11y: u,
                        dataQA: p
                    }) => (0, i.jsx)(t.E, {
                        size: "bolder" === e ? "p-1-bolder" : "p-1",
                        tag: s,
                        align: n,
                        color: o,
                        inline: r,
                        ellipsis: c,
                        breakWords: l,
                        dangerous: d,
                        a11y: u,
                        dataQA: p,
                        children: a
                    }),
                    m = ({
                        children: a,
                        tag: s,
                        weight: e,
                        align: n,
                        color: o,
                        inline: r,
                        ellipsis: c,
                        breakWords: l,
                        dangerous: d,
                        a11y: u,
                        dataQA: p
                    }) => (0, i.jsx)(t.E, {
                        size: "bolder" === e ? "p-2-bolder" : "p-2",
                        tag: s,
                        align: n,
                        color: o,
                        inline: r,
                        ellipsis: c,
                        breakWords: l,
                        dangerous: d,
                        a11y: u,
                        dataQA: p,
                        children: a
                    }),
                    x = ({
                        children: a,
                        tag: s,
                        weight: e,
                        align: n,
                        color: o,
                        inline: r,
                        ellipsis: c,
                        breakWords: l,
                        dangerous: d,
                        id: u,
                        a11y: p,
                        dataQA: h
                    }) => (0, i.jsx)(t.E, {
                        size: "bolder" === e ? "p-3-bolder" : "p-3",
                        tag: s,
                        align: n,
                        color: o,
                        inline: r,
                        ellipsis: c,
                        breakWords: l,
                        dangerous: d,
                        id: u,
                        a11y: p,
                        dataQA: h,
                        children: a
                    }),
                    g = ({
                        children: a,
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        id: d,
                        a11y: u,
                        dataQA: p,
                        className: h
                    }) => (0, i.jsx)(t.E, {
                        tag: s,
                        align: e,
                        color: n,
                        inline: o,
                        ellipsis: r,
                        breakWords: c,
                        dangerous: l,
                        id: d,
                        a11y: u,
                        dataQA: p,
                        className: h,
                        children: a
                    })
            },
            94318: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(32485),
                    n = e.n(t),
                    o = e(45869),
                    r = e(8483);
                s.A = ({
                    name: a,
                    notification: s,
                    isDisabled: e,
                    onClick: t,
                    innerRef: c,
                    a11y: l,
                    dataQA: d
                }) => {
                    const u = n()({
                        "csms-navigation-bar__icon": !0,
                        "csms-navigation-bar__icon--is-disabled": e
                    });
                    return (0, i.jsxs)("button", {
                        className: u,
                        onClick: e ? void 0 : t,
                        ref: c,
                        "data-qa": "navbar-icon",
                        "data-qa-icon": a,
                        "aria-disabled": e,
                        "aria-describedby": l ? .ariaDescribedby,
                        type: "button",
                        ...d,
                        children: [(0, i.jsx)(r.A, {
                            name: a,
                            supportsRtl: !0,
                            a11y: {
                                label: l ? .iconLabel
                            }
                        }), s ? (0, i.jsx)("div", {
                            className: "csms-navigation-bar__icon-notification",
                            children: (0, i.jsx)(o.A, { ...s,
                                a11y: {
                                    label: l ? .notificationLabel
                                }
                            })
                        }) : null]
                    })
                }
            },
            99795: function(a, s, e) {
                "use strict";
                var i = e(74848),
                    t = e(32485),
                    n = e.n(t);
                s.A = ({
                    children: a,
                    position: s,
                    transparent: e,
                    shadow: t,
                    inverted: o,
                    a11y: r = {
                        tag: "nav"
                    },
                    extra: c,
                    extraClass: l,
                    extraAttrs: d
                }) => {
                    const u = n()(l, {
                            "csms-navigation-bar": !0,
                            [`csms-navigation-bar--${s}`]: s,
                            "csms-navigation-bar--transparent": e,
                            "csms-navigation-bar--shadow": t,
                            "csms-navigation-bar--inverted": o,
                            [l]: l
                        }),
                        p = a ? r ? .tag || "nav" : "div";
                    return (0, i.jsxs)(p, {
                        className: u,
                        "data-qa": "navbar",
                        ...d,
                        "aria-label": r ? .label,
                        children: [(0, i.jsx)("div", {
                            className: "csms-navigation-bar__main",
                            children: a
                        }), c]
                    })
                }
            }
        }
    ]);
//# sourceMappingURL=6416.ef8c3dcd2c161b4f5b9a.js.map
"use strict";
(self.webpackChunk_segment_analytics_next = self.webpackChunk_segment_analytics_next || []).push([
    [104], {
        1419: function(n, e, t) {
            function i(n, e) {
                var t, i;
                return "boolean" == typeof(null == e ? void 0 : e.enabled) ? e.enabled : null === (i = null === (t = null == n ? void 0 : n.__default) || void 0 === t ? void 0 : t.enabled) || void 0 === i || i
            }
            t.d(e, {
                j: function() {
                    return i
                }
            })
        },
        3542: function(n, e, t) {
            t.r(e), t.d(e, {
                schemaFilter: function() {
                    return o
                }
            });
            var i = t(5478),
                r = t(1419);

            function o(n, e) {
                function t(t) {
                    var o = n,
                        u = t.event.event;
                    if (o && u) {
                        var a = o[u];
                        if (!(0, r.j)(o, a)) return t.updateEvent("integrations", (0, i.Cl)((0, i.Cl)({}, t.event.integrations), {
                            All: !1,
                            "Segment.io": !0
                        })), t;
                        var l = function(n, e) {
                            var t, i;
                            if (!n || !Object.keys(n)) return {};
                            var r = n.integrations ? Object.keys(n.integrations).filter((function(e) {
                                    return !1 === n.integrations[e]
                                })) : [],
                                o = [];
                            return (null !== (t = e.remotePlugins) && void 0 !== t ? t : []).forEach((function(n) {
                                r.forEach((function(e) {
                                    n.creationName == e && o.push(n.name)
                                }))
                            })), (null !== (i = e.remotePlugins) && void 0 !== i ? i : []).reduce((function(n, e) {
                                return e.settings.subscriptions && o.includes(e.name) && e.settings.subscriptions.forEach((function(t) {
                                    return n["".concat(e.name, " ").concat(t.partnerAction)] = !1
                                })), n
                            }), {})
                        }(a, e);
                        t.updateEvent("integrations", (0, i.Cl)((0, i.Cl)((0, i.Cl)({}, t.event.integrations), null == a ? void 0 : a.integrations), l))
                    }
                    return t
                }
                return {
                    name: "Schema Filter",
                    version: "0.1.0",
                    isLoaded: function() {
                        return !0
                    },
                    load: function() {
                        return Promise.resolve()
                    },
                    type: "before",
                    page: t,
                    alias: t,
                    track: t,
                    identify: t,
                    group: t
                }
            }
        }
    }
]);
//# sourceMappingURL=schemaFilter.bundle.1b218d13fed021531d4e.js.map
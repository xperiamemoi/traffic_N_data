"use strict";
(self.webpackChunk_segment_analytics_next = self.webpackChunk_segment_analytics_next || []).push([
    [50], {
        1419: function(t, n, i) {
            function e(t, n) {
                var i, e;
                return "boolean" == typeof(null == n ? void 0 : n.enabled) ? n.enabled : null === (e = null === (i = null == t ? void 0 : t.__default) || void 0 === i ? void 0 : i.enabled) || void 0 === e || e
            }
            i.d(n, {
                j: function() {
                    return e
                }
            })
        },
        3771: function(t, n, i) {
            i.r(n), i.d(n, {
                LegacyDestination: function() {
                    return k
                },
                ajsDestinations: function() {
                    return C
                }
            });
            var e = i(5478),
                r = i(4303),
                o = i(6789),
                s = i(8456),
                a = i(9752),
                u = i(4082),
                l = i(2620),
                c = i(1419),
                d = i(5835),
                h = i(7106),
                f = i(2939),
                v = i(9732),
                p = i(1418),
                g = i(2911),
                m = i(6238);

            function y(t) {
                return t.toLowerCase().replace(".", "").replace(/\s+/g, "-")
            }

            function w(t, n) {
                return void 0 === n && (n = !1), n ? btoa(t).replace(/=/g, "") : void 0
            }

            function b(t, n, i, r) {
                return (0, e.sH)(this, void 0, Promise, (function() {
                    var o, s, a, u, l, c;
                    return (0, e.YH)(this, (function(d) {
                        switch (d.label) {
                            case 0:
                                o = y(n), s = w(o, r), a = (0, g.YM)(), u = "".concat(a, "/integrations/").concat(null != s ? s : o, "/").concat(i, "/").concat(null != s ? s : o, ".dynamic.js.gz"), d.label = 1;
                            case 1:
                                return d.trys.push([1, 3, , 4]), [4, (0, m.k)(u)];
                            case 2:
                                return d.sent(),
                                    function(t, n, i) {
                                        var r, o;
                                        try {
                                            var s = (null !== (o = null === (r = null === window || void 0 === window ? void 0 : window.performance) || void 0 === r ? void 0 : r.getEntriesByName(t, "resource")) && void 0 !== o ? o : [])[0];
                                            s && n.stats.gauge("legacy_destination_time", Math.round(s.duration), (0, e.fX)([i], s.duration < 100 ? ["cached"] : [], !0))
                                        } catch (t) {}
                                    }(u, t, n), [3, 4];
                            case 3:
                                throw l = d.sent(), t.stats.gauge("legacy_destination_time", -1, ["plugin:".concat(n), "failed"]), l;
                            case 4:
                                return c = window["".concat(o, "Deps")], [4, Promise.all(c.map((function(t) {
                                    return (0, m.k)(a + t + ".gz")
                                })))];
                            case 5:
                                return d.sent(), window["".concat(o, "Loader")](), [2, window["".concat(o, "Integration")]]
                        }
                    }))
                }))
            }
            var H = i(441),
                _ = i(2822),
                P = i(8115);

            function z(t, n) {
                return (0, e.sH)(this, void 0, Promise, (function() {
                    var i, r = this;
                    return (0, e.YH)(this, (function(a) {
                        switch (a.label) {
                            case 0:
                                return i = [], (0, o.a)() ? [2, n] : [4, (0, h._)((function() {
                                    return n.length > 0 && (0, o.s)()
                                }), (function() {
                                    return (0, e.sH)(r, void 0, void 0, (function() {
                                        var r, o;
                                        return (0, e.YH)(this, (function(e) {
                                            switch (e.label) {
                                                case 0:
                                                    return (r = n.pop()) ? [4, (0, l.C)(r, t)] : [2];
                                                case 1:
                                                    return o = e.sent(), o instanceof s.o || i.push(r), [2]
                                            }
                                        }))
                                    }))
                                }))];
                            case 1:
                                return a.sent(), i.map((function(t) {
                                    return n.pushWithBackoff(t)
                                })), [2, n]
                        }
                    }))
                }))
            }
            var k = function() {
                function t(t, n, i, r, o, s) {
                    void 0 === r && (r = {});
                    var a = this;
                    this.options = {}, this.type = "destination", this.middleware = [], this.initializePromise = (0, P.u)(), this.flushing = !1, this.name = t, this.version = n, this.settings = (0, e.Cl)({}, r), this.disableAutoISOConversion = o.disableAutoISOConversion || !1, this.integrationSource = s, this.settings.type && "browser" === this.settings.type && delete this.settings.type, this.initializePromise.promise.then((function(t) {
                        return a._initialized = t
                    }), (function() {})), this.options = o, this.buffer = o.disableClientPersistence ? new f.M(4, []) : new v.x(4, "".concat(i, ":dest-").concat(t)), this.scheduleFlush()
                }
                return t.prototype.isLoaded = function() {
                    return !!this._ready
                }, t.prototype.ready = function() {
                    var t = this;
                    return this.initializePromise.promise.then((function() {
                        var n;
                        return null !== (n = t.onReady) && void 0 !== n ? n : Promise.resolve()
                    }))
                }, t.prototype.load = function(t, n) {
                    var i;
                    return (0, e.sH)(this, void 0, Promise, (function() {
                        var r, o, s = this;
                        return (0, e.YH)(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return this._ready || void 0 !== this.onReady ? [2] : null === (i = this.integrationSource) || void 0 === i ? [3, 1] : (o = i, [3, 3]);
                                case 1:
                                    return [4, b(t, this.name, this.version, this.options.obfuscate)];
                                case 2:
                                    o = e.sent(), e.label = 3;
                                case 3:
                                    r = o, this.integration = function(t, n, i) {
                                        var e;
                                        "Integration" in t ? (t({
                                            user: function() {
                                                return i.user()
                                            },
                                            addIntegration: function() {}
                                        }), e = t.Integration) : e = t;
                                        var r = new e(n);
                                        return r.analytics = i, r
                                    }(r, this.settings, n), this.onReady = new Promise((function(t) {
                                        s.integration.once("ready", (function() {
                                            s._ready = !0, t(!0)
                                        }))
                                    })), this.integration.on("initialize", (function() {
                                        s.initializePromise.resolve(!0)
                                    }));
                                    try {
                                        (0, _.y)(t, {
                                            integrationName: this.name,
                                            methodName: "initialize",
                                            type: "classic"
                                        }), this.integration.initialize()
                                    } catch (n) {
                                        throw (0, _.y)(t, {
                                            integrationName: this.name,
                                            methodName: "initialize",
                                            type: "classic",
                                            didError: !0
                                        }), this.initializePromise.resolve(!1), n
                                    }
                                    return [2]
                            }
                        }))
                    }))
                }, t.prototype.unload = function(t, n) {
                    return function(t, n, i) {
                        return (0, e.sH)(this, void 0, Promise, (function() {
                            var r, o, s, a;
                            return (0, e.YH)(this, (function(e) {
                                return r = (0, g.YM)(), o = y(t), s = w(t, i), a = "".concat(r, "/integrations/").concat(null != s ? s : o, "/").concat(n, "/").concat(null != s ? s : o, ".dynamic.js.gz"), [2, (0, m.d)(a)]
                            }))
                        }))
                    }(this.name, this.version, this.options.obfuscate)
                }, t.prototype.addMiddleware = function() {
                    for (var t, n = [], i = 0; i < arguments.length; i++) n[i] = arguments[i];
                    this.middleware = (t = this.middleware).concat.apply(t, n)
                }, t.prototype.shouldBuffer = function(t) {
                    return "page" !== t.event.type && ((0, o.a)() || !0 !== this._ready || !0 !== this._initialized)
                }, t.prototype.send = function(t, n, i) {
                    var r, o;
                    return (0, e.sH)(this, void 0, Promise, (function() {
                        var s, u, l, d, h, f;
                        return (0, e.YH)(this, (function(v) {
                            switch (v.label) {
                                case 0:
                                    return this.shouldBuffer(t) ? (this.buffer.push(t), this.scheduleFlush(), [2, t]) : (s = null === (o = null === (r = this.options) || void 0 === r ? void 0 : r.plan) || void 0 === o ? void 0 : o.track, u = t.event.event, s && u && "Segment.io" !== this.name && (l = s[u], (0, c.j)(s, l) ? t.updateEvent("integrations", (0, e.Cl)((0, e.Cl)({}, t.event.integrations), null == l ? void 0 : l.integrations)) : (t.updateEvent("integrations", (0, e.Cl)((0, e.Cl)({}, t.event.integrations), {
                                        All: !1,
                                        "Segment.io": !0
                                    })), t.cancel(new a.d({
                                        retry: !1,
                                        reason: "Event ".concat(u, " disabled for integration ").concat(this.name, " in tracking plan"),
                                        type: "Dropped by plan"
                                    }))), (null == l ? void 0 : l.enabled) && !1 === (null == l ? void 0 : l.integrations[this.name]) && t.cancel(new a.d({
                                        retry: !1,
                                        reason: "Event ".concat(u, " disabled for integration ").concat(this.name, " in tracking plan"),
                                        type: "Dropped by plan"
                                    }))), [4, (0, p.applyDestinationMiddleware)(this.name, t.event, this.middleware)]);
                                case 1:
                                    if (null === (d = v.sent())) return [2, t];
                                    h = new n(d, {
                                        traverse: !this.disableAutoISOConversion
                                    }), (0, _.y)(t, {
                                        integrationName: this.name,
                                        methodName: i,
                                        type: "classic"
                                    }), v.label = 2;
                                case 2:
                                    return v.trys.push([2, 5, , 6]), this.integration ? [4, this.integration.invoke.call(this.integration, i, h)] : [3, 4];
                                case 3:
                                    v.sent(), v.label = 4;
                                case 4:
                                    return [3, 6];
                                case 5:
                                    throw f = v.sent(), (0, _.y)(t, {
                                        integrationName: this.name,
                                        methodName: i,
                                        type: "classic",
                                        didError: !0
                                    }), f;
                                case 6:
                                    return [2, t]
                            }
                        }))
                    }))
                }, t.prototype.track = function(t) {
                    return (0, e.sH)(this, void 0, Promise, (function() {
                        return (0, e.YH)(this, (function(n) {
                            return [2, this.send(t, r.Track, "track")]
                        }))
                    }))
                }, t.prototype.page = function(t) {
                    var n;
                    return (0, e.sH)(this, void 0, Promise, (function() {
                        return (0, e.YH)(this, (function(i) {
                            switch (i.label) {
                                case 0:
                                    return (null === (n = this.integration) || void 0 === n ? void 0 : n._assumesPageview) && !this._initialized && this.integration.initialize(), [4, this.initializePromise.promise];
                                case 1:
                                    return i.sent(), [2, this.send(t, r.Page, "page")]
                            }
                        }))
                    }))
                }, t.prototype.identify = function(t) {
                    return (0, e.sH)(this, void 0, Promise, (function() {
                        return (0, e.YH)(this, (function(n) {
                            return [2, this.send(t, r.Identify, "identify")]
                        }))
                    }))
                }, t.prototype.alias = function(t) {
                    return (0, e.sH)(this, void 0, Promise, (function() {
                        return (0, e.YH)(this, (function(n) {
                            return [2, this.send(t, r.Alias, "alias")]
                        }))
                    }))
                }, t.prototype.group = function(t) {
                    return (0, e.sH)(this, void 0, Promise, (function() {
                        return (0, e.YH)(this, (function(n) {
                            return [2, this.send(t, r.Group, "group")]
                        }))
                    }))
                }, t.prototype.scheduleFlush = function() {
                    var t = this;
                    this.flushing || setTimeout((function() {
                        return (0, e.sH)(t, void 0, void 0, (function() {
                            var t;
                            return (0, e.YH)(this, (function(n) {
                                switch (n.label) {
                                    case 0:
                                        return (0, o.a)() || !0 !== this._ready || !0 !== this._initialized ? (this.scheduleFlush(), [2]) : (this.flushing = !0, t = this, [4, z(this, this.buffer)]);
                                    case 1:
                                        return t.buffer = n.sent(), this.flushing = !1, this.buffer.todo > 0 && this.scheduleFlush(), [2]
                                }
                            }))
                        }))
                    }), 5e3 * Math.random())
                }, t
            }();

            function C(t, n, i, r, o, s) {
                var a, l;
                if (void 0 === i && (i = {}), void 0 === r && (r = {}), (0, u.S)()) return [];
                n.plan && ((r = null != r ? r : {}).plan = n.plan);
                var c = null !== (l = null === (a = n.middlewareSettings) || void 0 === a ? void 0 : a.routingRules) && void 0 !== l ? l : [],
                    h = n.integrations,
                    f = r.integrations,
                    v = (0, d.J)(n, null != r ? r : {}),
                    p = null == s ? void 0 : s.reduce((function(t, n) {
                        var i;
                        return (0, e.Cl)((0, e.Cl)({}, t), ((i = {})[function(t) {
                            return ("Integration" in t ? t.Integration : t).prototype.name
                        }(n)] = n, i))
                    }), {}),
                    g = new Set((0, e.fX)((0, e.fX)([], Object.keys(h).filter((function(t) {
                        return function(t, n) {
                            var i, e = n.type,
                                r = n.bundlingStatus,
                                o = n.versionSettings,
                                s = "unbundled" !== r && ("browser" === e || (null === (i = null == o ? void 0 : o.componentTypes) || void 0 === i ? void 0 : i.includes("browser")));
                            return !t.startsWith("Segment") && "Iterable" !== t && s
                        }(t, h[t])
                    })), !0), Object.keys(p || {}).filter((function(t) {
                        return (0, H.Qd)(h[t]) || (0, H.Qd)(null == f ? void 0 : f[t])
                    })), !0));
                return Array.from(g).filter((function(t) {
                    return ! function(t, n) {
                        var i = !1 === n.All && void 0 === n[t];
                        return !1 === n[t] || i
                    }(t, i)
                })).map((function(n) {
                    var i = function(t) {
                            var n, i, e, r;
                            return null !== (r = null !== (i = null === (n = null == t ? void 0 : t.versionSettings) || void 0 === n ? void 0 : n.override) && void 0 !== i ? i : null === (e = null == t ? void 0 : t.versionSettings) || void 0 === e ? void 0 : e.version) && void 0 !== r ? r : "latest"
                        }(h[n]),
                        e = new k(n, i, t, v[n], r, null == p ? void 0 : p[n]);
                    return c.filter((function(t) {
                        return t.destinationName === n
                    })).length > 0 && o && e.addMiddleware(o), e
                }))
            }
        }
    }
]);
//# sourceMappingURL=ajs-destination.bundle.8e6b895db75187c55313.js.map
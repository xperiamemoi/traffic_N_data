function stopGetNumberRequest() {
    $("#leftMainDivUpper").addClass("hide");
    $("#ot_add_service_tip").hide();
    $("#trying").text(0);
    $('#stopGetNumberRequest').attr("stop", 1);
    $.removeCookie('count');
    buyProgressBar.style.width = 0
    buyProgressBarLabel.style.display = ''
    otherCountriesBlock.style.display = 'None'
}

$("#stopGetNumberRequest").click(function() {
    stopGetNumberRequest();
});

function rentFirstLoad() {
    bus.$emit('check-url-rent-path')

    setPriceChanging()

    writeCookie('rentTab', 'true', isAuth() ? 999 : 1 / 24)
};
const newAsideMainBtn = document.querySelector(".newAside__renting.newAside__main-btn")
if (newAsideMainBtn) {
    newAsideMainBtn.onclick = rentFirstLoad;
}

async function setActivationsStatus2(id) {
    let answerText = {
        success: ('Операция выполнена'),
        error: ('Операция не выполнена')
    }
    let params = {
        action: 'setStatus',
        id: id,
        status: 2,
        csrf: getCsrf()
    }
    let response = await internalApi(params)

    if (!response) {
        globalAlert(answerText.error)
        return false
    }

    let result = await response.text()
    let txt = (result == 'BAD_STATUS' ? answerText.error : answerText.success)
    globalAlert(txt)
    bus.$emit('update-activations-view')
    return true
}

$("#checkSoundNew").change(function() {
    if ($(this).is(":checked")) {
        $.cookie('checkSoundNew', 1);
    } else {
        $.cookie('checkSoundNew', 0);
    }
});

$('ul.tabs__caption').on('click', 'li:not(.active)', function() {
    $(this)
        .addClass('active').siblings().removeClass('active')
        .closest('div.tabs').find('div.tabs__content').removeClass('active').eq($(this).index()).addClass('active');
});

$('.nav-anchors a[href^="#"]').click(function() {
    let target = $(this).attr('href');
    $('html, body').animate({
        scrollTop: $(target).offset().top - 60
    }, 1000);
});

$("#multiServiceModal").one('show.bs.modal', function() {
    $.ajax({
        type: "POST",
        url: "/api/api.php",
        dataType: "json",
        data: {
            act: "getMultiServiceDesk",
            csrf: $("#csrf").val()
        },
        success: function(data) {
            let desc = document.querySelector('#multiServiceDesc')

            function makeMsg(status = 'danger', txt = 'Неизвестная ошибка, попробуйте позже') {
                desc.innerHTML += `<div class='alert alert-${status}'>${_(txt)}</div>`
            }

            if (data.status == "success") {
                data = data.data

                if (!data) return makeMsg()
                if (objEmpty(data)) return makeMsg('info', 'Нет данных')

                let msCountries = ''

                for (let id in data) {
                    msCountries += `<tr><td><span class='country_row'><img src='${iconRepo}/assets/ico/country/${id}.svg' width='24px' alt='' class='country_img'>${data[id].name}</td><td>${data[id].ms}</td></tr>`
                }

                desc.querySelector('tbody').innerHTML = msCountries
            } else return makeMsg()
        }
    })
})

$(document).ready(function() {
    for (let k in $.cookie())
        if (k.startsWith("avitoForward") && k.substring(13) < 127025789) $.removeCookie(k)

    let isMobile = this.body.clientWidth < 1067

    window.startOffset = 0;
    window.addNumber = !isMobile

    function alert(elem, txt, status, timeout = 5000) {
        status = 'alert-' + status
        elem.text(txt).addClass(status).show()
        setTimeout(function() {
            elem.hide().removeClass(status).text('')
        }, timeout)
    }
    const
        proposalAlert = $(".purchaseWindow__alert"),
        proposalResult = $(".purchaseWindow__result"),
        proposalBuyResult = $("#resultBuyGood");

    $("#hstock-user-activate-btn").click(function(e) {
        e.preventDefault()
        $.ajax({
            url: '/stubs/handler_hstock.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'userActivate',
                code: $("#hstock-user-activate-input").val(),
                csrf: $("#csrf").val()
            },
            success(data) {
                let status = 'success'
                if (data.status === 'success') {
                    $("#hstock-user-activate-box").hide();
                } else status = 'danger'
                alert(proposalBuyResult, data.msg, status)
            }
        })
    })
    $("#goodDataStream").click(function(e) {
        e.stopPropagation()
        e.preventDefault()
        const blob = new Blob([$(this).attr('data-content')])
        let a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'download.txt';
        a.click();
    })
    $("#buyGoodModal").on("hide.bs.modal", function() {
        $('#resultGoodsData').hide();
    });
    $("#buyGoodForm").submit(function(e) {
        e.preventDefault()
        $.ajax({
            url: $(this).attr("action"),
            type: 'POST',
            dataType: 'json',
            data: $(this).serialize() + "&csrf=" + $("#csrf").val(),
            success: function(data) {
                if (data.status === 'error') {
                    if (data.msg === 'NO_BALANCE') {
                        bus.$emit('no-funds-modal-show')
                    } else {
                        alert(proposalBuyResult, data.msg, 'danger')
                    }

                } else if (data.status === 'email') {
                    alert(proposalBuyResult, data.msg, 'danger')
                    $("#hstock-user-activate-box").show()
                    $("#hstock-user-activate-input").val("")
                } else {
                    alert(proposalBuyResult, _('Покупка прошла успешно!'), 'success')
                    $("#resultGoodsData div ul").empty()
                    let dataContent = '';
                    $.each(data, function(i, v) {
                        dataContent += i + ': ' + v + '\n\r';
                        $("#resultGoodsData div ul").append('<li>' + i + ': ' + v + '</li>');
                    })
                    $("#resultGoodsData").show();
                    $("#goodDataStream").attr('data-content', dataContent);
                    getBalance(false, true);
                    document.getElementById("submitBuyGood").innerText = _("Купить ещё");
                }
            }
        })
    })
    $(".purchaseWindow__EmailCode").click(function(e) {
        e.preventDefault()
        $.ajax({
            url: '/stubs/handler_hstock.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'userActivate',
                code: $(".purchaseWindow-btns__email input").val(),
                csrf: $("#csrf").val()
            },
            success(data) {
                let status = 'success'
                if (data.status === 'success') $(".purchaseWindow-btns__email").hide();
                else status = 'danger'
                alert(proposalAlert, data.msg, status)
            }
        })
    })
    $('.purchaseWindow__Download').click(function(e) {
        e.stopPropagation()
        e.preventDefault()
        const blob = new Blob([proposalResult.attr('data-content')])
        let a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'download.txt';
        a.click();
    })
    $(".purchaseWindow__buy").click(function(e) {
        e.preventDefault()
        $.ajax({
            url: '/stubs/handler_hstock.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'buyProduct',
                good_id: $("#purchaseWindow").data('id'),
                csrf: $("#csrf").val()
            },
            success: function(data) {
                if (data.status === 'error') {
                    alert(proposalAlert, data.msg, 'danger')
                } else if (data.status === 'email') {
                    alert(proposalAlert, data.msg, 'danger')
                    $(".purchaseWindow-btns__email").show();
                    $(".purchaseWindow-btns__email input").val("");
                } else {
                    alert(proposalBuyResult, _('Покупка прошла успешно!'), 'success')
                    proposalResult.empty().append("<ul></ul>")
                    let dataContent = '';
                    $.each(data, function(i, v) {
                        dataContent += i + ': ' + v + '\n\r';
                        proposalResult.find("ul").append('<li>' + i + ': ' + v + '</li>');
                    })
                    proposalResult.attr('data-content', dataContent).show();
                    $(".purchaseWindow__Download").show();
                }
            }
        })
    })

    let allAccordions = $('.accordion div.data');
    let allAccordionItems = $('.accordion .accordion-item');
    $('.accordion-header').click(function() {
        if ($(this).parents('.accordion-item').hasClass('open')) {
            $(this).parents('.accordion-item').removeClass('open');
            $(this).next().slideUp("fast");
        } else {
            allAccordions.slideUp("fast");
            allAccordionItems.removeClass('open');
            $(this).parents('.accordion-item').addClass('open');
            $(this).next().slideDown("fast");
            return false;
        }
    })
})
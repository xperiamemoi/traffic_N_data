"use strict";
const lazyImage = {
    imgContainer: document.querySelectorAll("[data-lazy-load]"),

    handleIntersect: function(entries, observer) {
        entries.forEach(entry => {
            if (!entry.isIntersecting) {
                return
            }

            let options = {
                container: entry.target,
            }

            if (options.container.tagName === 'IMG') {
                options.img = options.container
            } else {
                options.img = entry.target.querySelector('img')
            }

            options.img.src = options.img.getAttribute('data-src')
            options.img.removeAttribute('data-src')

            lazyImage.checkLoadImg(options)
            observer.unobserve(entry.target)
        })

    },
    createObserve: function() {
        let observer
        const options = {
            rootMargin: '0px 0px 50px 0px',
            threshold: 0,
        }
        observer = new IntersectionObserver(this.handleIntersect, options)
        this.imgContainer.forEach((container) => {
            observer.observe(container);
        });
    },
    checkLoadImg: function(options) {
        options.img.onload = function() {
            options.container.classList.add('image-load')
        }
    },
    init: function() {
        this.createObserve();
    },
};

const lazyVideoLoad = () => {
    const lazyVideosContainers = document.querySelectorAll('[data-lazy-video]');

    if (lazyVideosContainers.length) {
        lazyVideosContainers.forEach(videoContainer => {
            let load = false
            let imgContainer = videoContainer.querySelector('[data-preview]')
            let img = videoContainer.querySelector('img')

            let url = new URL(videoContainer.getAttribute('data-lazy-video'))
            let videoId = url.pathname.split('/').filter((el) => el !== '').pop()

            img.src = `https://rutube.ru/api/video/${videoId}/thumbnail/?redirect=1`
            img.onload = () => {
                imgContainer.style.display = 'block'
            }

            const addVideo = () => {
                let iframe = document.createElement('iframe')
                imgContainer.classList.add('loading')
                iframe.src = `https://rutube.ru/play/embed/${videoId}?autoplay=1&mute=1`
                iframe.setAttribute('allow', 'autoplay')
                iframe.style.display = 'none'

                videoContainer.appendChild(iframe)
                iframe.onload = () => {
                    imgContainer.classList.remove('loading')
                    imgContainer.style.display = 'none'
                    iframe.style.display = ''
                }
                load = true
            }

            videoContainer.addEventListener('mouseenter', () => {
                if (!load) {
                    addVideo()
                }

            }, {
                once: true
            })
            videoContainer.addEventListener('touchstart', () => {
                if (!load) {
                    addVideo()
                }
            }, {
                once: true
            })
        })
    }
}

window.addEventListener('load', () => {
    lazyImage.init();
    lazyVideoLoad()
})
"use strick"
document.addEventListener("DOMContentLoaded", () => {
    const copyTexts = {
        copyBtns: document.querySelectorAll('[data-clipboard]'),
        getAttributeText: function(btn) {
            return btn.getAttribute('data-clipboard-text')
        },
        getAttributeTarget: function(btn) {
            return btn.getAttribute('data-clipboard-target')
        },
        addListeners: function() {
            this.copyBtns.forEach(copyBtn => {
                copyBtn.addEventListener('click', () => {
                    if (this.getAttributeTarget(copyBtn)) {
                        let copyTarget = document.querySelector(copyTexts.getAttributeTarget(copyBtn))
                        let text = copyTarget.tagName.toLowerCase() == 'textarea' || 'input' ? copyTarget.value : copyTarget.textContent
                        copyText(text)
                    } else if (this.getAttributeText(copyBtn)) {
                        copyText(this.getAttributeText(copyBtn))
                    }
                })
            })
        },
        init: function() {
            this.addListeners()
        }
    }
    copyTexts.init()
});
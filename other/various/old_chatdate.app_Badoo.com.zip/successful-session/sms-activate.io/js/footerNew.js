const spollerContainer = document.querySelectorAll("[data-spoller-container]");
const footerBtn = document.querySelector(".footerNew-app .footerNew-app__link");
const footerAbout = document.querySelector("#footerAboutCompany");

if (footerAbout) {
    let year = new Date().getFullYear();
    footerAbout.textContent = `© 2015–${year}. SMS-ACTIVATE`;

}

spollerContainer.forEach((container) => {
    const spollerItem = container.querySelectorAll("[data-spoller-item]");
    spollerItem.forEach((item) => {
        const button = item.querySelector("[data-spoller-button]");
        const body = item.querySelector("[data-spoller-body]");

        button.addEventListener("click", () => {
            button.classList.toggle("_active");
            if (body.classList.contains("_active")) {
                body.classList.remove("_active");
                body.style.height = "";
            } else {
                body.classList.add("_active");
                body.style.height = body.scrollHeight + "px";
            }
        });
    });
});
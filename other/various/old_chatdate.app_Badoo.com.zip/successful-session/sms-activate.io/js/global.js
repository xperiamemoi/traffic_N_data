// $_ аналог jquery. Use: $DQ('el-name').style.display = 'none'
var $DQ = document.querySelector.bind(document)
var $DQQ = document.querySelectorAll.bind(document)

const DOLLAR_CODE = 840
const MAX_USER_VALUE = 999 _999_999

const STEP_MAX_PRICE_DOLLAR = 0.001
const STEP_MAX_PRICE_RUB = 0.1

const MAX_MOBILE_WIDTH = 768

const CURRENCY_SYMBOLS = {
    840: '$',
    978: '€',
    643: '₽',
    156: '¥',
};

const svgIconsRepo = {
        close: '<svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M6.39513 7.50001L0.697632 13.1975L1.80263 14.3025L7.50013 8.60501L13.1976 14.3025L14.3026 13.1975L8.60513 7.50001L14.3026 1.80251L13.1976 0.69751L7.50013 6.39501L1.80263 0.69751L0.697632 1.80251L6.39513 7.50001Z" fill="#3A5072"/></svg>',
        btnRepeat: '<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="0.5" y="0.5" width="21" height="21" rx="4.5" stroke="#EA5400"/><path d="M15.9425 6.05625C14.6729 4.7875 12.9306 4 10.9956 4C7.1257 4 4 7.1325 4 11C4 14.8675 7.1257 18 10.9956 18C14.2614 18 16.9844 15.7688 17.7636 12.75H15.9425C15.2245 14.7887 13.2808 16.25 10.9956 16.25C8.09756 16.25 5.74234 13.8962 5.74234 11C5.74234 8.10375 8.09756 5.75 10.9956 5.75C12.449 5.75 13.7448 6.35375 14.6904 7.3075L11.8712 10.125H18V4L15.9425 6.05625Z" fill="#EA5400"/></svg>',
        btnSuccess: `<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22" fill="none">
    <rect x="0.5" y="0.5" width="21" height="21" rx="4.5" stroke="#EA5400"/>ssssssssssssssssssssssssssssssss
    <path d="M8.00039 15.2001L3.80039 11.0001L2.40039 12.4001L8.00039 18.0001L20.0004 6.0001L18.6004 4.6001L8.00039 15.2001Z" fill="#EA5400"/>
    </svg>`,
        btnReplace: '<svg width="22" height="22" fill="none" xmlns="http://www.w3.org/2000/svg"><rect width="22" height="22" rx="4" fill="url(#paint0_linear_1919_13006)"/><path d="M16.95 6.745a.665.665 0 00-.145-.216l-2-2a.666.666 0 10-.943.942l.862.862h-6.39A3.333 3.333 0 005 9.667V11a.667.667 0 001.333 0V9.667a2 2 0 012-2h6.391l-.862.862a.667.667 0 00.943.942l2-2A.664.664 0 0017 7m-.05-.255c.033.08.05.166.05.253l-.05-.253zm-11.9 8a.665.665 0 00.145.726l2 2a.667.667 0 00.943-.942l-.862-.862h6.39A3.333 3.333 0 0017 12.333V11a.667.667 0 00-1.333 0v1.333a2 2 0 01-2 2H7.276l.862-.862a.667.667 0 10-.943-.942l-2 2m-.144.216a.665.665 0 01.143-.215l-.143.215z" fill="#fff"/><defs><linearGradient id="paint0_linear_1919_13006" x1="22" y1="11" x2="0" y2="11" gradientUnits="userSpaceOnUse"><stop stop-color="#EA5400"/><stop offset="1" stop-color="#F67C00"/></linearGradient></defs></svg>',
        btnCancel: '<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="0.5" y="0.5" width="21" height="21" rx="4.5" stroke="#EA5400"/><path d="M18 5.41L16.59 4L11 9.59L5.41 4L4 5.41L9.59 11L4 16.59L5.41 18L11 12.41L16.59 18L18 16.59L12.41 11L18 5.41Z" fill="#EA5400"/></svg>',
        copy: '<svg width="12" height="12" viewbox0="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.275 5.5125L7.9875 3.225C7.875 3.075 7.6875 3 7.5 3H4.5C4.0875 3 3.75 3.3375 3.75 3.75V10.5C3.75 10.9125 4.0875 11.25 4.5 11.25H9.75C10.1625 11.25 10.5 10.9125 10.5 10.5V6.0375C10.5 5.85 10.425 5.6625 10.275 5.5125ZM7.5 3.75L9.7125 6H7.5V3.75ZM4.5 10.5V3.75H6.75V6C6.75 6.4125 7.0875 6.75 7.5 6.75H9.75V10.5H4.5Z" fill="black"></path><path d="M2.25 6.75H1.5V1.5C1.5 1.0875 1.8375 0.75 2.25 0.75H7.5V1.5H2.25V6.75Z" fill="black"></path></svg>',
        copy2: '<svg width="16" height="17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.4 9.04v2.52c0 2.1-.84 2.94-2.94 2.94H4.94c-2.1 0-2.94-.84-2.94-2.94V9.04c0-2.1.84-2.94 2.94-2.94h2.52m2.94 2.94c0-2.1-.84-2.94-2.94-2.94m2.94 2.94v1.86h.66c2.1 0 2.94-.84 2.94-2.94V5.44c0-2.1-.84-2.94-2.94-2.94H8.54c-2.1 0-2.94.84-2.94 2.94v.66h1.86" stroke="#D1D9F3" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
        edit: '<svg width="12" height="12" viewBox="0 0 10 10" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.10833 1.25C7.00416 1.25 6.89583 1.29167 6.81666 1.37083L6.05416 2.13333L7.61666 3.69583L8.37916 2.93333C8.54166 2.77083 8.54166 2.50833 8.37916 2.34583L7.40416 1.37083C7.32083 1.2875 7.21666 1.25 7.10833 1.25ZM5.60833 3.75861L5.99167 4.14194L2.21667 7.91694H1.83333V7.53361L5.60833 3.75861ZM1 7.18725L5.60833 2.57892L7.17083 4.14142L2.5625 8.74975H1V7.18725Z" fill-opacity="0.54"/></svg>',
        pencil: '<svg width="12" height="12" viewBox="0 0 10 10" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.10833 1.25C7.00416 1.25 6.89583 1.29167 6.81666 1.37083L6.05416 2.13333L7.61666 3.69583L8.37916 2.93333C8.54166 2.77083 8.54166 2.50833 8.37916 2.34583L7.40416 1.37083C7.32083 1.2875 7.21666 1.25 7.10833 1.25ZM5.60833 3.75861L5.99167 4.14194L2.21667 7.91694H1.83333V7.53361L5.60833 3.75861ZM1 7.18725L5.60833 2.57892L7.17083 4.14142L2.5625 8.74975H1V7.18725Z" fill-opacity="0.54"></path></svg>',
        basket: '<svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.9084 8.25C11.4707 8.25 11.9656 7.9425 12.2205 7.4775L14.9045 2.61C15.1819 2.115 14.822 1.5 14.2522 1.5H3.15633L2.45159 0H0V1.5H1.49944L4.19844 7.1925L3.18632 9.0225C2.63902 10.0275 3.35875 11.25 4.49833 11.25H13.495V9.75H4.49833L5.32302 8.25H10.9084ZM3.86856 3H12.9777L10.9084 6.75H5.6454L3.86856 3ZM4.49833 12C3.67364 12 3.00638 12.675 3.00638 13.5C3.00638 14.325 3.67364 15 4.49833 15C5.32302 15 5.99777 14.325 5.99777 13.5C5.99777 12.675 5.32302 12 4.49833 12ZM11.9955 12C11.1709 12 10.5036 12.675 10.5036 13.5C10.5036 14.325 11.1709 15 11.9955 15C12.8202 15 13.495 14.325 13.495 13.5C13.495 12.675 12.8202 12 11.9955 12Z" fill="white"/></svg>',
        heart: '<svg width="20" height="17" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M6.25.5A5.411 5.411 0 0110 2.007a5.417 5.417 0 019.166 3.91c0 2.611-1.53 5-3.313 6.8-1.793 1.81-3.984 3.176-5.59 3.71a.834.834 0 01-.526 0c-1.605-.534-3.797-1.9-5.59-3.71-1.784-1.8-3.314-4.189-3.314-6.8A5.417 5.417 0 016.25.5zm1.73 2.088A3.75 3.75 0 002.5 5.917c0 1.971 1.179 3.959 2.832 5.628C6.87 13.1 8.698 14.252 10 14.751c1.303-.5 3.13-1.652 4.668-3.206 1.654-1.67 2.832-3.657 2.832-5.628a3.75 3.75 0 00-6.818-2.156.833.833 0 01-1.364-.001A3.745 3.745 0 007.98 2.588z" fill="#fff"/><path d="M6.25 2.167A3.744 3.744 0 019.319 3.76a.833.833 0 001.364 0A3.75 3.75 0 0117.5 5.917c0 1.972-1.18 3.96-2.833 5.63-1.538 1.553-3.365 2.706-4.668 3.205-1.302-.5-3.13-1.652-4.668-3.206C3.679 9.875 2.5 7.888 2.5 5.917a3.75 3.75 0 013.75-3.75z"/></svg>',
        arrow: '<svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 2L6 6L10 2" stroke="#4C4C4C" stroke-width="2" stroke-linecap="square"/></svg>',
        arrowNavigation: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16 7H3.83L9.42 1.41L8 0L0 8L8 16L9.41 14.59L3.83 9H16V7Z" fill="black" fill-opacity="0.54"/></svg>',
        hstockLogo: `<svg width="40" height="39" viewBox="0 0 40 39" fill="none" xmlns="http://www.w3.org/2000/svg"> <path fill-rule="evenodd" clip-rule="evenodd" d="M37.3913 0H7.70091C3.46542 0 0 3.44331 0 7.65212V37.1544C0 38.1697 0.8358 39.0002 1.85751 39.0002H31.5479C35.7834 39.0002 39.2488 35.5569 39.2488 31.348V1.84574C39.2488 0.830505 38.413 0 37.3913 0Z" fill="#F9FAFF"/> <path fill-rule="evenodd" clip-rule="evenodd" d="M15.1211 4.07788H33.2322C34.1044 4.07788 34.8185 4.78725 34.8185 5.6543V18.0893L34.8171 18.1605C34.8086 18.5395 34.7881 18.8998 34.7121 19.1403C34.6363 19.3809 34.5049 19.5012 34.3442 19.5557C34.1833 19.6101 33.993 19.5983 33.8295 19.5544C33.6661 19.5106 33.5295 19.4345 33.366 19.3406C33.2026 19.2467 33.0125 19.1349 32.9086 19.0756C32.8665 19.0515 32.8386 19.0363 32.8194 19.026L32.8173 19.0248C32.5608 18.8724 32.2461 18.7157 31.8532 18.5692C31.0028 18.2524 29.7865 17.9845 28.2136 17.8612C27.8636 17.8339 26.9703 17.815 25.7541 17.8006V12.6165C25.7541 12.4182 25.6061 12.2528 25.4145 12.2239L24.0597 12.2194H22.5453C22.3269 12.2194 22.1457 12.3994 22.1457 12.6165V17.7709C20.5327 17.7606 18.7762 17.7513 17.0971 17.7382V12.6163C17.0971 12.3979 16.9152 12.2192 16.6975 12.2192H14.2828L13.8678 12.2198C13.6816 12.2293 13.528 12.3669 13.4952 12.5453L13.495 17.7009C11.4367 17.671 9.88173 17.6274 9.48394 17.5569C8.34064 17.3545 7.34022 16.9712 6.55778 16.2363C5.77534 15.5013 5.21074 14.4151 4.87131 13.4318C4.53189 12.4482 4.4175 11.5678 4.4319 10.6697C4.44614 9.77137 4.58917 8.8555 5.03578 7.93248C5.4824 7.00945 6.23276 6.07927 7.05447 5.4436C7.87619 4.80809 8.76942 4.4674 9.90912 4.28998C11.0488 4.1124 12.4351 4.0981 13.9537 4.08752C14.3393 4.08472 14.7333 4.08223 15.1214 4.07804L15.1211 4.07788ZM24.1276 34.922H6.01649C5.14423 34.922 4.43018 34.2126 4.43018 33.3457V20.9107L4.43158 20.8393C4.44019 20.4603 4.46053 20.1001 4.53643 19.8597C4.61233 19.6191 4.74362 19.4986 4.90449 19.4443C5.06536 19.3899 5.25565 19.4017 5.41902 19.4456C5.58255 19.4894 5.71916 19.5655 5.88269 19.6594C6.04591 19.7533 6.2362 19.8651 6.34011 19.9243C6.3822 19.9483 6.41006 19.9637 6.4293 19.9739L6.43134 19.9752C6.68782 20.1276 7.00236 20.2842 7.3953 20.4308C8.24565 20.7475 9.46219 21.0155 11.035 21.1386C11.5829 21.1817 12.4411 21.2117 13.4946 21.2332L13.4944 26.7189C13.528 26.9039 13.692 27.0456 13.8877 27.0456H16.6971C16.9168 27.0456 17.0966 26.8669 17.0966 26.6485V21.2761C18.7239 21.2868 20.4756 21.291 22.1452 21.2968V26.6485C22.1452 26.866 22.325 27.0456 22.5449 27.0456H23.921L25.4396 27.0364C25.6186 26.9972 25.7536 26.8377 25.7536 26.6485V21.3163C27.8024 21.3348 29.3472 21.3691 29.7647 21.4431C30.908 21.6455 31.9084 22.029 32.6909 22.7637C33.4733 23.4986 34.0379 24.5849 34.3773 25.5682C34.7168 26.5517 34.831 27.432 34.8168 28.3303C34.8025 29.2286 34.6596 30.1445 34.2129 31.0675C33.7663 31.9905 33.0161 32.9207 32.1943 33.5562C31.3726 34.1917 30.4794 34.5324 29.3397 34.71C28.2 34.8876 26.8137 34.9017 25.2953 34.9125C24.9097 34.9153 24.5155 34.9176 24.1274 34.9218L24.1276 34.922Z" fill="#EF233C"/> <path fill-rule="evenodd" clip-rule="evenodd" d="M34.1013 31.098C34.0454 30.6743 33.9813 30.082 33.6403 29.3706C33.2993 28.6592 32.6819 27.8284 31.9314 27.0933C31.1812 26.3583 30.15 25.6533 29.1747 25.2168C28.2742 24.8136 27.0146 24.5866 25.7653 24.3832V21.2212C27.3244 21.2353 28.7724 21.2691 29.7644 21.4446C30.8218 21.632 31.9081 22.0305 32.6904 22.7653C33.4728 23.5001 34.0376 24.5864 34.3769 25.5698C34.7163 26.5533 34.8307 27.4337 34.8163 28.3319C34.802 29.2302 34.659 30.1459 34.2124 31.0691C34.1834 31.1291 34.1529 31.189 34.1215 31.2491C34.1146 31.2011 34.1078 31.151 34.101 31.098H34.1013ZM5.14656 7.9034C5.20227 8.32713 5.26658 8.91941 5.60757 9.63081C5.94855 10.3422 6.5659 11.173 7.31626 11.908C8.06661 12.6429 9.09458 13.3467 10.0731 13.7846C10.9272 14.1669 12.271 14.3932 13.5066 14.5893V17.7783C11.9772 17.7631 10.4338 17.7249 9.48361 17.5566C8.42309 17.3689 7.33973 16.9709 6.55745 16.236C5.77501 15.5011 5.21025 14.4148 4.87098 13.4314C4.53156 12.4479 4.41717 11.5675 4.43157 10.6694C4.44581 9.77107 4.58884 8.85535 5.03545 7.93217C5.0644 7.87215 5.09492 7.81212 5.12637 7.75226C5.13341 7.80015 5.13998 7.85038 5.14687 7.90325L5.14656 7.9034ZM17.1083 15.0335C18.6888 15.1162 20.4515 15.164 22.1571 15.2089V17.7734H22.1492C20.5844 17.7822 18.7837 17.788 17.1083 17.7897V15.0334V15.0335ZM25.7655 15.3498C27.3299 15.4174 29.061 15.4922 30.5111 15.7403C32.0918 16.0104 33.7863 16.6029 34.8181 17.322V18.0895L34.8166 18.1607C34.8081 18.5397 34.7876 18.8999 34.7117 19.1405C34.636 19.381 34.5045 19.5016 34.3438 19.5558C34.183 19.6102 33.9927 19.5984 33.8291 19.5546C33.6658 19.5107 33.5292 19.4347 33.3656 19.3408C33.2024 19.2468 33.0121 19.135 32.9082 19.0758C32.8661 19.0517 32.8383 19.0365 32.819 19.0262L32.817 19.025C32.5605 18.8726 32.2458 18.7158 31.8529 18.5694C31.0025 18.2526 29.3272 17.9488 28.2133 17.8615C27.2869 17.7889 26.473 17.7833 25.7657 17.7766V15.3501L25.7655 15.3498ZM22.1571 23.9688C20.5775 23.8859 18.8148 23.838 17.1083 23.7929V21.2279C18.6765 21.2192 20.4803 21.2134 22.1571 21.2115V23.9686V23.9688ZM13.5063 23.6485C11.9414 23.5818 10.1578 23.5043 8.73669 23.2614C7.1521 22.9906 5.46157 22.3986 4.42969 21.6797V20.9122L4.43125 20.841C4.4397 20.4619 4.4602 20.1018 4.5361 19.8612C4.61184 19.6208 4.74329 19.5003 4.904 19.446C5.06487 19.3916 5.25516 19.4034 5.41869 19.4473C5.58206 19.4911 5.71868 19.5672 5.8822 19.6611C6.04542 19.755 6.23587 19.8668 6.33962 19.9261C6.38171 19.9502 6.40972 19.9656 6.42882 19.9758L6.43085 19.9769C6.68733 20.1293 7.00203 20.286 7.39497 20.4325C8.24532 20.7494 9.9163 21.0528 11.0347 21.1403C11.9236 21.21 12.7833 21.2185 13.5061 21.2249V23.6486L13.5063 23.6485Z" fill="#D80032"/> <path fill-rule="evenodd" clip-rule="evenodd" d="M4.44598 26.1566C4.57461 26.9022 4.71749 28.1944 5.07475 29.2381C5.43201 30.2819 6.00366 31.077 6.94681 31.7304C7.88996 32.3836 9.20492 32.8947 10.7556 33.264C12.306 33.6333 14.0925 33.8605 16.6864 34.0238C19.2804 34.1872 22.6818 34.2864 25.0541 34.3433C27.4265 34.4001 28.7698 34.4144 29.8988 34.2155C31.0277 34.0168 31.9424 33.605 32.6643 33.0086C32.9984 32.7324 33.2913 32.4167 33.5782 32.1163C33.1804 32.6613 32.701 33.1648 32.1945 33.5565C31.3728 34.192 30.4796 34.5327 29.3399 34.7103C28.2002 34.8879 26.8138 34.902 25.2953 34.9128C24.9097 34.9154 24.5157 34.9179 24.1276 34.9221H6.01665C5.14423 34.9221 4.43018 34.2127 4.43018 33.3458V26.0685L4.44598 26.1568V26.1566ZM34.7952 12.8454C34.6665 12.0998 34.5237 10.8076 34.1662 9.76375C33.809 8.72006 33.2375 7.92485 32.2942 7.27161C31.351 6.61837 30.0361 6.1071 28.4854 5.7378C26.935 5.36849 25.1485 5.14147 22.5546 4.97804C19.9606 4.81477 16.5592 4.71541 14.1869 4.6585C11.8145 4.60174 10.4711 4.58743 9.342 4.78631C8.2131 4.98519 7.29844 5.39695 6.57671 5.99343C6.24261 6.26959 5.94967 6.58525 5.66267 6.88582C6.06046 6.34081 6.53994 5.83716 7.04633 5.44546C7.86821 4.80995 8.76128 4.46926 9.90113 4.29168C11.0407 4.1141 12.4272 4.0998 13.9456 4.08922C14.3311 4.08643 14.7252 4.08409 15.1133 4.0799H33.2243C34.0968 4.0799 34.8107 4.78927 34.8107 5.65616V12.9335L34.795 12.8452L34.7952 12.8454Z" fill="#FF2E46"/> </svg>`,
        proxyLogo: `<svg width="38" height="40" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M5.322 4.183c-3.926 3.5-6.09 7.552-4.835 9.05 1.255 1.498 5.455-.125 9.38-3.625 3.926-3.5 6.091-7.552 4.836-9.05-1.255-1.498-5.455.125-9.38 3.625zm.284.321C3.91 5.928 3.184 7.658 3.696 8.308c.513.65 2.07-.028 3.766-1.452 1.695-1.423 2.655-3.104 2.142-3.753-.513-.65-2.303-.022-3.998 1.401z" fill="#0A2051"/><path d="M6.322 36.443c6.785 4.952 29.675-18.23 27.959-29.016-1.727-2.58-2.7-3.821-4.474-4.293 3.415 5.3-6.357 18.982-13.577 24.738-7.086 5.205-11.127 8.034-13.395 3.246.687 2.754 1.258 2.697 3.487 5.325z" fill="#0A2051"/><path d="M15.137 39.033c6.737-2.2 21.224-16.876 21.484-25.193.664.094.96 1.038 1.379 3.997-.286 5.93-11.184 20.471-20.418 22.162-2.86.012-3.31-.217-2.445-.966z" fill="#0A2051"/><path d="M16.438 36.135c-2.122-.193-4.292-.983-5.046-1.341-.886 1.34-1.012 4.081.182 4.32.21.415 4.026.915 5.826.885-1.89-.158-1.898-1.905-.962-3.864zM2.159 32.298c-.104-.795.165-2.533 1.872-5.365 8.116-12.09 27.457-22.974 32.278-16.34 1.32 3.121 1.769 4.561 1.665 7.352-.788-5.164-4.486-5.164-12.25-2.335-8.03 3.308-21.196 14.733-19.508 20.713-1.764-1.447-2.678-2.31-4.057-4.025z" fill="#FF9501"/><path d="M0 19.554c.375-3.52 2.636-8.406 3.72-10.41.173.635.652 2.497.936 2.2C10.472 5.264 22.186-.89 27.466.934c2.164.455 5.495 4.196 6.815 6.493-5.06-5.872-17.908-1.684-27.83 7.78.145.409 1.36 2.21 1.95 3.06-3.246.553-5.068.859-8.401 1.287z" fill="#FF9501"/><path fill-rule="evenodd" clip-rule="evenodd" d="M30.884 34.58c3.806-3.393 5.905-7.321 4.688-8.774-1.217-1.452-5.289.121-9.095 3.515-3.806 3.393-5.905 7.322-4.688 8.774 1.217 1.453 5.289-.12 9.095-3.514zm-.275-.31c1.644-1.381 2.348-3.059 1.851-3.689-.497-.63-2.006.027-3.65 1.407-1.644 1.38-2.574 3.01-2.077 3.64.497.63 2.232.021 3.876-1.359z" fill="#FF9501"/></svg>`,
        smsHubLogo: `<svg width="34" height="40" fill="none" xmlns="http://www.w3.org/2000/svg"><path clip-rule="evenodd" d="M22.97 20.148h-7.056c-1.74 0-3.544-.049-5.277.005l-6.312-5.97-.002-5.315-.001-2.25c.017-1.934-.268-2.709 1.356-2.694 5.193 0 8.698.012 13.748.013.9 0 1.702.001 2.418.675 1.721 1.62 5.547 5.435 6.962 6.971.412.594.491 1.233.5 1.943l.01 9.139c-1.848-2.093-4.862-2.517-6.346-2.517v0zM12.202 31.33a1.675 1.675 0 100-3.35 1.675 1.675 0 000 3.35zm4.719 0a1.675 1.675 0 100-3.35 1.675 1.675 0 000 3.35zm4.717 0a1.675 1.675 0 100-3.351 1.675 1.675 0 000 3.35zm2.138-29.182c3.107 3.262 4.419 4.553 7.525 7.815.627.657 1.066 1.905 1.066 2.814l.03 16.786v.002c0 5.189-4.236 9.434-9.427 9.434H10.932c-5.185 0-9.427-4.242-9.427-9.427.049-4.582 0-9.194 0-13.78V4.54c0-.47-.033-.984.066-1.436.056-.258.164-.6.386-.929.222-.327.56-.641.955-.833.396-.19.85-.258 1.296-.297.447-.038.884-.047 1.268-.045 5.304.021 9.755.026 15.058.026.428 0 1.16.05 1.799.257.616.199 1.14.549 1.444.866v0z" stroke="#54B20A" stroke-width="2"/></svg>`,
        smsActivateBot: `<svg width="40" height="33" fill="none" xmlns="http://www.w3.org/2000/svg"><path clip-rule="evenodd" d="M9.554 20.306L1 17.508l29.224-11.71c1.528-.625 1.914.07 1.683 1.476L26.559 31l-9.062-5.346-3.77 3.871v-6.973l12.578-11.867-16.75 9.621z" stroke="#254D71" stroke-width="1.601" stroke-miterlimit="19.96"/><path clip-rule="evenodd" d="M33.471 22.447a2.286 2.286 0 002.284 2.285 2.286 2.286 0 10-2.284-2.286zM2.376 28.236a2.287 2.287 0 002.285 2.287 2.285 2.285 0 10-2.284-2.286zM7.738 3.575a2.286 2.286 0 002.284 2.286 2.286 2.286 0 000-4.57 2.284 2.284 0 00-2.284 2.284z" stroke="#EA5400" stroke-width="1.983" stroke-miterlimit="19.96"/></svg>`
    },
    iconRepo = 'https://smsactivate.s3.eu-central-1.amazonaws.com',
    iconAssets = iconRepo + '/assets'

JSON.safeParse = function(str, defVal = []) {
    try {
        return this.parse(str)
    } catch (e) {
        return defVal
    }
}

class BroadcastChannelPolyfill {
    constructor(name) {
        this.name = name;
        window.addEventListener('storage', this.handler.bind(this))
    }
    postMessage(data) {
        localStorage.setItem(this.name, JSON.stringify(data))
        setTimeout(() => localStorage.removeItem(this.name), 500)
    }
    onmessage(event) {

    }
    close() {
        window.removeEventListener('storage', this.handler)
    }
    handler(event) {
        if (this.onmessage && event.key == this.name && event.newValue) {
            this.onmessage(event)
        }
    }
}

//TODO: убрать после перехода полностью на доллар
const currencyChangeChannel = new BroadcastChannelPolyfill('currency')

function getCookie(key) {
    var keyValue = document.cookie.match('(^|;) ?' + key + '=([^;]*)(;|$)');
    return keyValue ? keyValue[2] : null;
}

function writeCookie(cname, cvalue, exdays) {
    const d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    let expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function deleteCookie(cname) {
    writeCookie(cname, null, -1)
}

function getNode(html) {
    let a = document.createElement('a');
    a.innerHTML = html;
    return a.firstChild;
}

function objEmpty(obj) {
    for (a in obj) return false
    return true
}

function copyObj(obj) {
    if (typeof obj !== 'object') return obj

    return JSON.parse(JSON.stringify(obj))
}

function copyArr(arr) {
    if (!Array.isArray(arr)) return arr

    return arr.slice()
}

function round10(val, precision) {
    let m = Math.pow(10, precision);
    return Math.round(val * (m)) / m;
}

function safeNum(num) {
    num = +num
    return num ? num : 0
}

function safeStr(str) {
    return str ? str : ''
}

function getRank() {
    return safeNum(document.getElementById("userRank").value);
}

function isSafari() {
    return /^((?!chrome|android|linux).)*safari/i.test(navigator.userAgent)
}

function isApple() {
    return navigator.userAgent.toLowerCase().includes('mac os') || isSafari()
}

function isIOS() {
    return [
            'iPad Simulator',
            'iPhone Simulator',
            'iPod Simulator',
            'iPad',
            'iPhone',
            'iPod'
        ].includes(navigator.platform)
        // iPad on iOS 13 detection
        ||
        (navigator.userAgent.includes("Mac") && "ontouchend" in document)
}

function openAuthModal() {
    document.querySelector('.newHeader__user.user .user__logout').click()
}

function openLoginModal() {
    if (isAuth()) return
    window.authLoginModal.openModal()
}

function openRegisterModal() {
    if (isAuth()) return
    window.authRegisterModal.openModal()
}

function isAuth() {
    return getCookie("userid") > 0;
}

function isRetail() {
    return +getCookie('isRetail')
}

function isBigUser() {
    return getRank() > 5;
}

function isMobile() {
    return isIOS() || document.body.clientWidth < 1067
}

function isMobileResponsive(val) {
    return document.body.clientWidth <= val
}

function delay(fn, ms) {
    let timer = 0;
    return function(...args) {
        clearTimeout(timer);
        timer = setTimeout(fn.bind(this, ...args), ms || 0);
    }
}

window.addEventListener('load', function() {
    writeCookie('mobile', isMobile().toString(), 9999)
})

window.addEventListener("orientationchange", function() {
    const playingVideo = Array.from(document.querySelectorAll('video').values()).some((video) => {
        const playing = !!(video.currentTime > 0 && !video.paused && !video.ended && video.readyState > 2)
        const openedInFullScreen = document.fullscreenElement
        return playing || openedInFullScreen;
    })
    if (isMobile() && !playingVideo) window.location.reload()
})
async function initVueBlock(funcName, elemName, templateName) {
    window[funcName] = () => {}
    const el = document.getElementById(elemName)
    el.ontouchstart = null
    el.onmouseover = null

    const res = await SaApi('/api/api.php', {
            act: 'getVueTemplate',
            template: templateName,
            isMobile: isMobile()
        }),
        result = await res.json()

    if (!result ? .status || result ? .status !== 'success') {
        setTimeout(globalAlert(result.message, _('Ошибка')), 1500)
        return false
    }

    var script = document.createElement('script')
    script.innerHTML = result.data
    script.type = 'module'
    script.onerror = () => {
        console.error(`Error load script: {templateName}`)
    }
    document.body.appendChild(script)
}

function isJivoJiv() {
    return !(typeof jivo_api == 'undefined' || !document.querySelector('#jvlabelWrap') ? .clientWidth && !document.querySelector('#jcont') ? .clientWidth)
}

function hoursToDays(hours) {
    return Math.floor(hours / 24);
}

function hoursToMonths(hours) {
    return Math.floor(hours / 30 / 24)
}

const SaApiErr = (function() {
    const TXT = {
        def: _('Неизвестная ошибка, попробуйте позже'),
        hoursAvailable: _('Доступно часов: '),
        daysAvailable: _('Доступно дней: '),
    }
    const ERRORS = {
        WRONG_OPERATOR: _('Данный оператор не поддерживает продление номеров'),
        RENT_DIE: _('Аренда уже завершена'),
        NO_BALANCE: _('Недостаточно средств!'),
        INVALID_PHONE: _('Продление аренды невозможно'),
        INVALID_TIME: _('Некорректное время'),
        TIMEOUT_EXPIRED: _('Истекло время выполнения запроса'),
        TOO_LATE: _('Максимально допустимый период запроса - 2 недели!'),
    }

    function recognize(errorMsg, defMsg = TXT.def) {
        if (!errorMsg) return defMsg

        let isHumanMsg = !(/^[A-Z_]*$/.test(errorMsg))

        if (isHumanMsg) return errorMsg

        if (ERRORS[errorMsg]) return ERRORS[errorMsg]

        return defMsg
    }

    function parse(reply) {
        if (typeof reply.err === 'undefined') {
            if (reply.error) return recognize(reply.error)
            return recognize(reply)
        }

        if (reply.err === 'MAX_HOURS_EXCEED') {
            let hours = reply.info ? .max

            if (!hours) return reply.msg

            let days = hoursToDays(hours),
                msgMaxAvailable = TXT.hoursAvailable + hours

            if (days > 0) msgMaxAvailable = TXT.daysAvailable + days

            return reply.msg + '\n' + msgMaxAvailable;
        }

        let msg = recognize(reply.msg, null)

        if (msg !== null) return msg

        return recognize(reply.err)
    }

    return function(reply = null) {
        try {
            return parse(reply);
        } catch (e) {
            return TXT.def;
        }
    }
})()


/** @type Record<string, Promise<Response>> */
const saPendingRequests = {}
/** @type Record<string, Response> */
const saNoTtlCache = {}
const noTtlRequests = ["getCountries", "getAllServicesDesktop"];
const noCache = [
    "getNumber"
]
const SaApi = async function(url, params = {}) {
    let cacheable = !noCache.find((action) => action === params['action']);
    const isNoTtlRequest = noTtlRequests.includes(params.act) || noTtlRequests.includes(params.action);
    if (isAuth() && getCsrf()) params['csrf'] = getCsrf();
    const requestId = JSON.stringify({
        url,
        params
    });
    if (isNoTtlRequest && saNoTtlCache[requestId]) {
        return Promise.resolve(saNoTtlCache[requestId].clone());
    }
    if (cacheable && saPendingRequests[requestId]) {
        return new Promise((res) => {
            /** catch отсутсвует потому что SaApi возвращает null при ошибке */
            saPendingRequests[requestId].then((response) => res(response.clone()))
        })
    }

    const data = new URLSearchParams()
    for (var key in params) {
        data.append(key, params[key])
    }

    const request = new Promise((res) => {
        fetch(url, {
                method: 'POST',
                body: data
            })
            .then(reply => {
                if (isNoTtlRequest) saNoTtlCache[requestId] = reply.clone();

                res(reply.ok ? reply : null)
            })
            .catch(() => res(null))
            .finally(() => saPendingRequests[requestId] = null)
    })
    if (cacheable) saPendingRequests[requestId] = request
    return request
}
const rentApi = function(params) {
    return SaApi('/stubs/rent.php', params)
}
const internalApi = function(params) {
    return SaApi('/stubs/handler_api_internal.php', params)
}
const paymentApi = async (action, params, method = 'POST') => {
    if (typeof params.csrf === 'undefined') params.csrf = getCsrf()
    try {
        let reply = null
        if (method !== 'POST') {
            const data = new URLSearchParams()
            for (var key in params) {
                data.append(key, params[key])
            }
            reply = await fetch(`/api/payment/?method=${action}&client=site&` + data, {
                method: 'GET',
                body: null
            })
        } else {
            params = {
                method: action,
                client: 'site',
                ...params
            }
            reply = await fetch('/api/payment/', {
                method: method,
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(params)
            })
        }
        if (!reply.ok) return null
        let result = null
        try {
            const isJSON = reply.headers.get('Content-Type').includes('json')
            result = isJSON ? await reply.json() : await reply.text()
        } catch (err) {
            result = {
                status: 'error',
                msg: result
            }
        }
        return result
    } catch (e) {
        return e
    }
}

function getClosableAlert(status, html) {
    return `<div class="alert alert-${status}" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <div>${html}</div>
  </div>`
}

async function getIncomeForLastPeriod() {
    let reply = await internalApi({
        action: 'getIncomeAmountForLastPeriod',
        csrf: getCsrf()
    })

    if (!reply || !reply.ok) {
        alertUnknownError()
        return false
    }

    reply = await getFetchResponse(reply)
    if (!reply.status || reply.status !== 'success') {
        return false
    }

    return {
        sum: reply.sum,
        currency: reply.currency
    };
}

function callTechSupport(btn) {
    const checkIsJivo = async () => {
        const jivoWidget = document.querySelector('.jivo-widget')
        if (isJivoJiv()) {
            jivoWidget.classList.add('hidden')
            jivo_api.open()
        } else {
            let parentNote = btn.parentNode
            let supportPopper = document.createElement('div')
            supportPopper.id = "supportPopper"
            supportPopper.className = "support-popper"
            supportPopper.innerHTML = `<div class="arrow"></div></h3><div class="support-popper__content p-2">
                ${_('К сожалению, но сейчас нет операторов в сети.')}
                <br><br>
                ${_('Напишите, пожалуйста, Ваш вопрос:')}
                <br>Email: <a href='mailto:info@sms-activate.org' class='orange'>info@sms-activate.org</a>
                <br>Telegram: <a href='https://t.me/SA_Support_mobile_Bot' class='orange'>@SA_Support_mobile_Bot</a>
                <br><br>
                ${_('Как только операторы появятся в сети, мы сразу же с Вами свяжемся.')}</div>`
            btn.parentNode.classList.add('p-relative')


            parentNote.querySelector(".support-popper") ? parentNote.querySelector(".support-popper").remove() : parentNote.appendChild(supportPopper)

        }
    }

    checkIsJivo()
}

const Cache = {
    get: function(key) {
        try {
            return localStorage.getItem(key)
        } catch (e) {
            return null
        }
    },
    set: function(key, value) {
        try {
            localStorage.setItem(key, value)
        } catch (e) {}
    },
    unset: function(key) {
        try {
            localStorage.removeItem(key)
        } catch (e) {}
    },
    clear: function() {
        try {
            localStorage.clear()
        } catch (e) {}
    },
    setElapseFor: function(key) {
        try {
            localStorage.setItem(key + 'ET', Date.now())
        } catch (e) {}
    },
    elapsedFor: function(key, seconds = 3600) {
        try {
            return Date.now() - this.get(key + 'ET') > seconds * 1000
        } catch (e) {
            return true
        }
    },
    isAlive: function() {
        try {
            const key = `test`;
            localStorage.setItem(key, null);
            localStorage.removeItem(key);
            return true;
        } catch (e) {
            return false;
        }
    }
}

function getPriceChanges(rent = false) {
    let cache = Cache.get('priceChanges'),
        isRent = +Boolean(rent)

    if (!cache || cache === '[]') return {}

    try {
        cache = JSON.safeParse(cache)
        cache = cache[isRent]

        if (!cache) return {}

        for (let key in cache) {
            let item = cache[key].split('_')

            item = {
                diff: item[0],
                date: item[1]
            }

            cache[key] = item
        }

        return cache;
    } catch (e) {
        return {}
    }
}

function setPriceChanging() {
    if (!Cache.isAlive()) return;
    sessionStorage.removeItem('priceChange') //del old
    Cache.unset('priceChange')

    const PRICE_CHANGING_INTERVAL = 3600000 //1 hour

    let cache = Cache.get('priceChanges'),
        date = new Date(),
        now = date.getTime()

    if (cache) {
        cache = JSON.safeParse(cache)
        if (cache.date && now - cache.date < PRICE_CHANGING_INTERVAL) return;
    }

    $.ajax({
        type: "POST",
        url: "/api/api.php",
        dataType: "json",
        data: {
            act: "setPriceChanging",
            csrf: $("#csrf").val()
        },
        success: function(reply) {
            if (reply.status != "success") return {}

            let data = reply.data,
                hoursDiffMsc = -1 * (date.getTimezoneOffset() / 60 + 3)

            data.date = Date.now()

            for (let isRent in data) {
                for (let key in data[isRent]) {
                    let item = data[isRent][key],
                        $date = moment(item.date)

                    if (hoursDiffMsc) $date.add(hoursDiffMsc, 'h')

                    item.date = $date.unix()

                    data[isRent][key] = Object.values(item).join('_')
                }
            }

            Cache.set('priceChanges', JSON.stringify(data))
        }
    });
}

function priceChangingContainer(priceChange) {
    if (!priceChange) return '';

    const upArrowElement = '<img class="checkbox-arrow" src="' + iconRepo + '/assets/ico/double-arrow_up.svg" alt="img">',
        downArrowElement = '<img class="checkbox-arrow" src="' + iconRepo + '/assets/ico/double-arrow_down.svg" alt="img">',
        PLANNED_DIFF = 300

    let diff = +priceChange.diff,
        date = new Date(priceChange.date * 1000),
        planned = date - new Date() > PLANNED_DIFF,
        title = '',
        arrow = '',
        userDate = moment(date).format('MM.DD HH:mm:ss')

    if (!diff) return '';

    if (diff > 0) {
        if (planned) title = _("Повышение цены запланировано на ")
        else title = _("Повышение цены состоялось ")

        arrow = upArrowElement
    } else if (diff < 0) {
        if (planned) title = _("Понижение цены запланировано на ")
        else title = _("Понижение цены состоялось ")

        arrow = downArrowElement
    }

    title += userDate + ` (${_("на")} ${Math.abs(diff)} ${CURRENCY_ICO})`

    return `<div class="priceChangeArrow" style="margin: 10px"><span data-toggle="tooltip" data-placement="top" title="${title}">${arrow}</span></div>`
}

const ModalInfo = {
    html(modalId) {
        if (!modalId) return ''

        return `<i data-toggle="modal" data-target="#${modalId}" class="icon-info">?</i>`
    },
    /*checkWa(service, country){
        if('wa' == service && 0 === +country) return this.html('infoWaModal')

        return ''
    },*/
    checkMailgroup(service) {
        if (isMailGroup(service)) return this.html('infoMailGroupModal')

        return ''
    },
    checkOlx(service) {
        if ('sn' == service) return this.html('infoOlxModal')

        return ''
    },

    forActivationService(service) {
        let html = ''

        switch (true) {
            case Boolean(html = this.checkMailgroup(service)):
            case Boolean(html = this.checkOlx(service)):
                break;
        }

        return html
    },
    forActivationCountry(service, country) {
        let html = ''

        /*switch(true){
            case Boolean(html = this.checkWa(service, country)):
                break;
        }*/

        return html
    },
    forMultiservice(service, country) {
        let html = ''

        switch (true) {
            //case Boolean(html = this.checkWa(service, country)):
            case Boolean(html = this.checkMailgroup(service)):
                break;
        }

        return html
    },
    forRent(service, country) {
        let html = ''

        switch (true) {
            //case Boolean(html = this.checkWa(service, country)):
            case Boolean(html = this.checkMailgroup(service)):
                break;
        }

        return html
    },
}

function sanitizeHTML(str) {
    return str.replace(/[^\w. ]/gi, function(c) {
        return '&#' + c.charCodeAt(0) + ';'
    })
}

function escapeHtml(text) {
    let map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };

    return text.replace(/[&<>"']/g, function(m) {
        return map[m];
    });
}

function findRows(tbody, val) {
    tbody.querySelector('.table-msg') ? .parentNode.remove()
    val = val.trim();
    search = val.toLowerCase();
    let finded = 0
    for (let tr of tbody.querySelectorAll('tr')) {
        for (el of tr.querySelectorAll('[data-findable]')) {
            if (el.textContent.toLowerCase().includes(search)) {
                tr.classList.remove('hide')
                finded++
                break
            }
            tr.classList.add('hide')
        }
    }

    if (!finded) tbody.innerHTML += `<td colspan='3' class='table-msg text-center'>${_('Нет совпадений с')} <b>"${sanitizeHTML(val)}"</b></td>`
}

function isEqualObj(object1, object2) {
    const props1 = Object.getOwnPropertyNames(object1);
    const props2 = Object.getOwnPropertyNames(object2);

    if (props1.length !== props2.length) {
        return false;
    }

    for (let i = 0; i < props1.length; i += 1) {
        const prop = props1[i];
        const bothAreObjects = typeof(object1[prop]) === 'object' && typeof(object2[prop]) === 'object';

        if ((!bothAreObjects && (object1[prop] !== object2[prop])) ||
            (bothAreObjects && !isEqualObj(object1[prop], object2[prop]))) {
            return false;
        }
    }

    return true;
}

function phoneFormat(s, plus = true) {
    if (s == null) return ''
    if (s.length < 10) return s

    const cntCountry = s.length - 10
    let phone = new RegExp('(\\d{' + cntCountry + '})(\\d{3})(\\d{3})(\\d{2})(\\d{2})', 'g')
    phone = (plus ? '+' : '') + s.replace(phone, `$1 ($2) $3 $4 $5`)
    return phone
}

function phoneFormatV2(code, number, plus = true) {
    if (code == null) return ''
    if (number == null) return ''

    number = number.slice(code.length);

    codeCity = number.substring(0, 3)
    let abonent = number.slice(3);

    if (abonent.length == 8) {
        abonentArr = abonent.match(/.{1,3}/g)
        abonent = abonentArr.join(" ")
    } else if (abonent.length == 7) {
        abonentArr = [abonent.substring(0, 3)]
        abonent = abonent.slice(3);
        abonent = abonent.match(/.{1,2}/g)
        abonentArr = abonentArr.concat(abonent);
        abonent = abonentArr.join(" ")
    } else if (abonent.length == 6) {
        abonentArr = abonent.match(/.{1,2}/g)
        abonent = abonentArr.join(" ")
    }

    phone = (plus ? '+' : '') +
        code +
        ' (' + codeCity + ') ' +
        abonent
    return phone
}

function numberFormat(val) {
    let value = typeof val == 'string' ? Number(val) : val
    value = new Intl.NumberFormat('ru-RU').format(val)
    return value.replace(',', '.')
}

/** @deprecated */
// for fetch params convert
function ObjToUrlData(params) {
    const data = new URLSearchParams()
    for (var key in params) {
        data.append(key, params[key])
    }
    return data
}

function formattedNumber(val = 0, minimumFractionDigits = 0) {
    return val.toLocaleString('ru-RU', {
        style: 'decimal',
        minimumFractionDigits: minimumFractionDigits
    })
}

function formattedCurrency(val = 0, minimumFractionDigits = 0, currency = 'RUB') {
    return val.toLocaleString('ru-RU', {
        style: 'currency',
        currency: currency,
        minimumFractionDigits: minimumFractionDigits
    })
}

let dtLang = 'https://cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/'
switch (getCookie('lang')) {
    case 'ru':
        dtLang += 'Russian.json';
        break;
    case 'es':
        dtLang += 'Spanish.json';
        break;
    case 'cn':
        dtLang += 'Chinese.json';
        break;
    default:
        dtLang += 'English.json';
}

// alert, icon = 'warning' || ''
const globalAlert = (msg = '', icon = '') => {
    if (msg === 'SERVER_ERROR') msg = _('Внутренняя ошибка сервера')
    let send = {
        msg: msg,
        icon: icon
    }
    vueFooter.bottomDialogMsg = send
}
const alertUnknownError = () => {
    globalAlert(_('Неизвестная ошибка, попробуйте позже'))
}
const frequentMessages = {
    mailRuShortError: _('Покупка Mailgroup недоступна. '),
    mailRuError: _('Покупка Mailgroup недоступна. ') +
        _('Для покупки данного сервиса свяжитесь с технической поддержкой и подайте заявку на приобретение данного сервиса. Также вы можете купить данный сервис через раздел Аренда, без подачи заявки.') + '<br>' +
        '<a class="primary-btn sm mt-8" href="https://t.me/SA_Support_mobile_Bot" target="_blank">' + _('Контакты') + ' @SA_Support_mobile_Bot</a>'
}

// плавная прокрутка top или Y-offset
function scrollIntoY(offsetY = 0) {
    window.scrollTo({
        top: offsetY,
        behavior: 'smooth'
    })
}

// плавная прокрутка к якорю
function scrollIntoElem(elemName) {
    try {
        document.querySelector(elemName).scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        })
    } catch (e) {
        console.log('Element not found')
    }
}

// do first char UPPER
String.prototype.UpperFirstChar = function() {
    return this.charAt(0).toUpperCase() + this.slice(1);
};

/**
 * Для fetch: определяем тип ответа text/json и получаем ответ в едином формате {status: 'error'|'success', data...}
 * @param {response} response - передаем fetch response
 * @retrun object {status: 'success'|'error', data..|msg=error_text}
 */
async function getFetchResponse(response) {
    let result = {}
    const isJSON = response.headers.get('Content-Type').includes('json')
    result = isJSON ? await response.json() : await response.text()
    try {
        if (isJSON) return result
        result = JSON.parse(result)
    } catch (err) {
        result = {
            status: 'error',
            msg: result
        }
    }
    return result
}

function searchInObj(object, pattern) {
    for (const property in object) {
        const value = object[property].toLowerCase()
        if (value.includes(pattern.toLowerCase())) {
            return true
        }
    }
    return false
}

function getCsrf() {
    let el = document.querySelector('#csrf')
    return el !== null ? el.value : ''
}

function isset(val) {
    return typeof val !== 'undefined' ? val : null
}

function copyText(text, alertText) {
    let successText = alertText ? alertText : _('Текст скопирован')
    if (!navigator.clipboard) {
        fallbackCopyTextToClipboard(text, successText);
        return;
    }
    navigator.clipboard.writeText(text).then(function() {
        globalAlert(successText)
    }, function(err) {

    });
};
const fallbackCopyTextToClipboard = function(text, successText = null) {
    let isModal = false
    let textArea = document.createElement("textarea");
    let modalContentShow = document.querySelector('.modal.show .modal-content')

    modalContentShow ? isModal = true : isModal = false

    textArea.value = text;


    // Avoid scrolling to bottom
    textArea.style.top = "0";
    textArea.style.left = "0";
    textArea.style.position = "fixed";
    textArea.style.opacity = "0"

    modalContentShow ? modalContentShow.appendChild(textArea) : document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
        let successful = document.execCommand('copy');
        let msg = successful ? 'successful' : 'unsuccessful';
        globalAlert(successText)
    } catch (err) {
        console.error('Fallback: Oops, unable to copy', err);
    }

    modalContentShow ? modalContentShow.removeChild(textArea) : document.body.removeChild(textArea);
}

const getCountryIcon = (countryOrId) => `${iconAssets}/ico/country/${countryOrId?.id ?? countryOrId}.svg`;
const getServiceIcon = (name) => `${iconAssets}/ico/${name}0.webp`;

function minutesToReadableString(minutesNumber, fullLabel = false) {
    const minutesInDay = 1440;
    const minutesInHour = 60;

    const days = Math.floor(minutesNumber / minutesInDay);
    const hours = Math.floor((minutesNumber % minutesInDay) / minutesInHour);
    const minutes = minutesNumber % minutesInHour;

    const parts = [];
    if (days > 0) {
        parts.push(`${days} ${fullLabel ? _("день") : _("д")}`);
    }
    if (hours > 0) {
        parts.push(`${hours} ${fullLabel ? _("час") : _("ч")}`);
    }
    if (minutes > 0) {
        parts.push(`${minutes} ${_('мин')}`);
    }
    return parts.join(" ");
}

function checkAuth(targetLocation = null) {
    if (!isAuth()) {
        window.authLoginModal.openModal(targetLocation);
    }
    return isAuth();
}

/**
 * @param {string} event
 * @param {object} data
 */
function pushGoogleAnalyicsEvent(event, data = {}) {
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({
        event,
        ...data
    });
}

/**
 * Alias для функции ym с предзаполненым id
 * @param {string[]} messages
 */
function pushYandexMetricEvent(...messages) {
    const inputEl = document.querySelector("#yandexMetricId");
    if (!inputEl ? .value) return console.error("Yandex metrics id not set");
    if (typeof ym === 'undefined') return // METRICS_OFF mode
    ym(+inputEl.value, ...messages);
}

const isDefaultPrice = () => isRetail() == 0 && isAuth();

/**
 * Replaces %s in the template with provided arguments
 * @param {string} template
 * @param {string[]} args
 * @returns {string}
 */
function sprintf(template, ...args) {
    let i = 0;
    return template.replace(/%s/g, () => args[i++] ? ? '');
}

/**
 * @param {string} errorCode
 * @returns {boolean} True if banned
 */
function checkBan(errorCode) {
    if (typeof errorCode !== "string") return false;
    if (!errorCode ? .includes("BANNED")) return false;
    const dateParts = errorCode.split(":");
    const higlightedDate = `<p><strong>${dateParts[1]}:${dateParts[2]}:${dateParts[3]}</strong><p>`;
    const banMessage = _(
        "Вы забанены за отмену большого количества номеров, аккаунт будет разблокирован",
    );
    globalAlert(`${banMessage} ${higlightedDate}`);
    return true;
}

/**
 * @param {object} params
 * @returns {Promise<{ error: boolean, code?: string }>}
 */
async function buyRent(params) {
    const body = {
        action: "getNumber",
        owner: "site",
        service: params.service,
        country: params.country,
        operator: params.operator,
        incomingCall: params.incomingCall,
    };
    if (params.time) body.time = params.time;
    const res = await SaApi("/stubs/rent.php", body);
    const data = await res.text();
    const parsedJson = JSON.safeParse(data);
    const code = parsedJson ? .code ? ? parsedJson ? .message ? ? parsedJson ? .msg ? ? data;
    const hasBan = checkBan(code);
    if (hasBan) return {
        error: true,
        type: "BAN"
    };
    switch (code.toString()) {
        case "2":
        case "NO_BALANCE":
            bus.$emit('no-funds-modal-show');
            globalAlert(_("На вашем счету недостаточно средств"));
            return {
                error: true
            };
        case "BAD_country":
            globalAlert(_("Сервис не выбран. Выберите необходимый сервис в левом меню"));
            return {
                error: true
            };
        case "NO_YULA_MAIL":
            globalAlert(_("Покупка Mailgroup недоступна."));
            return {
                error: true
            };
        case "3":
        case "ERROR_SQL":
            globalAlert(_("Ошибка SQL, обратитесь в поддержку"));
            return {
                error: true
            };
        case "MAX_RENT_DATE_ERROR":
            globalAlert(_("Выбранный Вами номер недоступен к покупке.Попробуйте ещё раз!"));
            return {
                error: true
            };
        case "NOT_AVAILABLE":
            globalAlert(_("Для данной страны недоступна покупка нескольких сервисов на 1 номер"));
            return {
                error: true
            };
        case "1":
        case "NO_NUMBERS":
            return {
                error: true,
                type: "NO_NUMBERS"
            };
        case "SERVER_ERROR":
            globalAlert(_("Неизвестная ошибка, попробуйте позже"));
            return {
                error: true
            };
    }
    if (parsedJson ? .status === "error") {
        globalAlert(parsedJson ? .msg ? ? _("Неизвестная ошибка, попробуйте позже"));
        return {
            error: true
        };
    }
    if (!params.hideAlert) globalAlert(_("Номер приобретен успешно"));

    let buyRentFrom = Cache.get('buyRentFrom')
    if (buyRentFrom) {
        if (!Cache.elapsedFor('buyRentFrom', 5)) {
            pushGoogleAnalyicsEvent(buyRentFrom === 'leftMenuOfferList' ? 'rentalComplete' : 'rentalComplete_UNKNOWN')
        }
        Cache.unset('buyRentFrom')
        Cache.unset('buyRentFromET')
    }
    return {
        error: false
    };
}

/**
 * @param {object} params
 * @returns {Promise<{ error: boolean, type?: string }>}
 */
async function buyActivation(params) {
    const res = await SaApi("/stubs/handler_api_internal.php", {
        action: "getNumber",
        owner: "site",
        ...params,
    });
    const data = await res.text();
    const parsedJson = JSON.safeParse(data);
    let errorCode = parsedJson ? .code ? ? parsedJson ? .err ? ? data;
    const hasBan = checkBan(errorCode);
    if (hasBan) return {
        error: true,
        type: "BAN"
    };
    switch (errorCode) {
        case "SERVICE_NOT_AVAILABLE":
            globalAlert(_("Доступ к выбранному сервису ограничен, обратитесь в поддержку"));
            return {
                error: true
            };
        case "WRONG_MAX_PRICE":
            globalAlert(parsedJson.msg);
            return {
                error: true
            };
        case "NO_NUMBERS":
            return {
                error: true,
                type: errorCode
            };
        case "NO_BALANCE":
            globalAlert(_("На вашем счету недостаточно средств"));
            return {
                error: true,
                type: errorCode
            };
        case "BAD_SERVICE":
            globalAlert(
                _("Сервис не выбран. Выберите необходимый сервис в левом меню"),
            );
            return {
                error: true
            };
        case "NO_YULA_MAIL":
            globalAlert(_("Покупка Mailgroup недоступна."));
            return {
                error: true
            };
        case "ERROR_SQL":
        case "ERROR_SQL25":
            globalAlert(_("Ошибка SQL, обратитесь в поддержку"));
            return {
                error: true
            };
        case "BAD_FORWARD":
            globalAlert(_("Выберите один сервис с переадресацией"));
            return {
                error: true
            };
        case "WHATSAPP_NOT_AVAILABLE":
            globalAlert(_("Покупка WhatsApp недоступна."));
            return {
                error: true
            };
        case "NOT_AVAILABLE":
            globalAlert(
                _(
                    "Для данной страны недоступна покупка нескольких сервисов на 1 номер",
                ),
            );
            return {
                error: true
            };
        case "WRONG_EXCEPTION_PHONE":
            globalAlert(_("Неверно заданы исключающие префиксы для номеров"));
            return {
                error: true
            };
        case "NO_BALANCE_FORWARD":
            globalAlert(_("На вашем балансе недостаточно средств"));
            return {
                error: true
            };
        case "CHANNELS_LIMIT":
            globalAlert(_("Работа аккаунта ограничена, обратитесь в поддержку"));
            return {
                error: true
            };
        case "SERVER_ERROR":
            return {
                error: true
            };
    }
    return {
        error: false
    };
}
/**
 * @param {multiService: String, country: String, operator: String } params
 * @returns {Promise<{ error: boolean, type?: String, data?: Array }>}
 */
async function buyMultiServices(params) {
    const res = await SaApi("/stubs/handler_api_internal.php", {
        action: "getMultiServiceNumber",
        owner: "site",
        ...params,
    });
    const data = await res.text();
    const parsedJson = JSON.safeParse(data);
    let errorCode = parsedJson ? .code ? ? parsedJson ? .err ? ? data;
    const hasBan = checkBan(errorCode);
    if (hasBan) return {
        error: true,
        type: "BAN"
    };
    switch (errorCode) {
        case "SERVICE_NOT_AVAILABLE":
            globalAlert(_("Доступ к выбранному сервису ограничен, обратитесь в поддержку"));
            return {
                error: true
            };
        case "WRONG_MAX_PRICE":
            globalAlert(parsedJson.msg);
            return {
                error: true
            };
        case "NO_NUMBERS":
            return {
                error: true,
                type: errorCode
            };
        case "NO_BALANCE":
            globalAlert(_("На вашем счету недостаточно средств"));
            return {
                error: true,
                type: errorCode
            };
        case "BAD_SERVICE":
            globalAlert(
                _("Сервис не выбран. Выберите необходимый сервис в левом меню"),
            );
            return {
                error: true
            };
        case "NO_YULA_MAIL":
            globalAlert(_("Покупка Mailgroup недоступна."));
            return {
                error: true
            };
        case "ERROR_SQL":
        case "ERROR_SQL25":
            globalAlert(_("Ошибка SQL, обратитесь в поддержку"));
            return {
                error: true
            };
        case "BAD_FORWARD":
            globalAlert(_("Выберите один сервис с переадресацией"));
            return {
                error: true
            };
        case "WHATSAPP_NOT_AVAILABLE":
            globalAlert(_("Покупка WhatsApp недоступна."));
            return {
                error: true
            };
        case "NOT_AVAILABLE":
            globalAlert(
                _(
                    "Для данной страны недоступна покупка нескольких сервисов на 1 номер",
                ),
            );
            return {
                error: true
            };
        case "WRONG_EXCEPTION_PHONE":
            globalAlert(_("Неверно заданы исключающие префиксы для номеров"));
            return {
                error: true
            };
        case "NO_BALANCE_FORWARD":
            globalAlert(_("На вашем балансе недостаточно средств"));
            return {
                error: true
            };
        case "CHANNELS_LIMIT":
            globalAlert(_("Работа аккаунта ограничена, обратитесь в поддержку"));
            return {
                error: true
            };
        case "SERVER_ERROR":
            return {
                error: true
            };
    }
    return {
        error: false,
        data: parsedJson
    };
}

/**
 * @requires Defining fields in ctx:
 * needToStopPolling, pollingActivation
 *
 * @param {object} ctx
 */
function stopPolling(ctx) {
    if (!ctx.pollingActivation) return;
    ctx.needToStopPolling = true;
}

/**
 * @requires Defining fields in ctx:
 * needToStopPolling, pollingActivation, emit
 *
 * @param {object} ctx
 * @param {object} params
 * @param {object} params
 */
async function startActivationPolling(ctx, params, request) {
    if (ctx.pollingActivation) return;
    ctx.pollingActivation = true;
    const delay = (ms) => new Promise((res) => setTimeout(res, ms));
    const MAX_TRY_COUNT = 10;
    ctx.emit("no-numbers", {
        type: "start",
        stop: ctx.stopPolling.bind(this),
    });
    globalAlert(_('По данной стоимости сейчас номеров нет пожалуйста выберите другую'));
    let currentTryCount = 1;
    while (currentTryCount <= MAX_TRY_COUNT) {
        ctx.emit("no-numbers", {
            type: "trying",
            stop: ctx.stopPolling.bind(this),
            tryCount: currentTryCount,
        });
        if (ctx.needToStopPolling) {
            ctx.emit("no-numbers", {
                type: "stop"
            });
            ctx.pollingActivation = false;
            ctx.needToStopPolling = false;
            return {
                type: "stop"
            }
        }
        const {
            error
        } = await request(params);
        if (!error) {
            getBalance(true, true);
            ctx.pollingActivation = false;
            ctx.emit("no-numbers", {
                type: "success"
            });
            return {
                type: "success"
            }
        }
        await delay(1000);
        currentTryCount++;
    }
    ctx.pollingActivation = false;
    ctx.emit("no-numbers", {
        type: "fail"
    })
    return {
        type: "fail"
    }
}

function getLocaleDate(date, params = {}) {
    const lang = getCookie('lang')
    const currentDate = new Date(date)
    const formatter = new Intl.DateTimeFormat(lang, params)
    return formatter.format(currentDate)
}
const voiceLanguages = Object.entries({
    "af-ZA": _("Африкаанс (Южная Африка)"),
    "sq-AL": _("Албанский (Албания)"),
    "am-ET": _("Амхарский (Эфиопия)"),
    "ar-DZ": _("Арабский (Алжир)"),
    "ar-BH": _("Арабский (Бахрейн)"),
    "ar-EG": _("Арабский (Египет)"),
    "ar-IQ": _("Арабский (Ирак)"),
    "ar-IL": _("Арабский (Израиль)"),
    "ar-JO": _("Арабский (Иордания)"),
    "ar-KW": _("Арабский (Кувейт)"),
    "ar-LB": _("Арабский (Ливан)"),
    "ar-MR": _("Арабский (Мавритания)"),
    "ar-MA": _("Арабский (Марокко)"),
    "ar-OM": _("Арабский (Оман)"),
    "ar-QA": _("Арабский (Катар)"),
    "ar-SA": _("Арабский (Саудовская Аравия)"),
    "ar-PS": _("Арабский (Государство Палестина)"),
    "ar-SY": _("Арабский (Сирия)"),
    "ar-TN": _("Арабский (Тунис)"),
    "ar-AE": _("Арабский (Объединенные Арабские Эмираты)"),
    "ar-YE": _("Арабский (Йемен)"),
    "hy-AM": _("Армянский (Армения)"),
    "az-AZ": _("Азербайджанский (Азербайджан)"),
    "eu-ES": _("Баскский (Испания)"),
    "bn-BD": _("Бенгальский (Бангладеш)"),
    "bn-IN": _("Бенгальский (Индия)"),
    "bs-BA": _("Боснийский (Босния и Герцеговина)"),
    "bg-BG": _("Болгарский (Болгария)"),
    "my-MM": _("Бирманский (Мьянма)"),
    "ca-ES": _("Каталонский (Испания)"),
    "cmn-Hans-CN": _("Китайский (упрощенный, Китай)"),
    "cmn-Hans-HK": _("Китайский (упрощенный, Гонконг)"),
    "cmn-Hant-TW": _("Китайский (традиционный, Тайвань)"),
    "yue-Hant-HK": _("Кантонский (традиционный, Гонконг)"),
    "hr-HR": _("Хорватский (Хорватия)"),
    "cs-CZ": _("Чешский (Чехия)"),
    "da-DK": _("Датский (Дания)"),
    "nl-BE": _("Нидерландский (Бельгия)"),
    "nl-NL": _("Нидерландский (Нидерланды)"),
    "en-AU": _("Английский (Австралия)"),
    "en-CA": _("Английский (Канада)"),
    "en-GH": _("Английский (Гана)"),
    "en-HK": _("Английский (Гонконг)"),
    "en-IN": _("Английский (Индия)"),
    "en-IE": _("Английский (Ирландия)"),
    "en-KE": _("Английский (Кения)"),
    "en-NZ": _("Английский (Новая Зеландия)"),
    "en-NG": _("Английский (Нигерия)"),
    "en-PK": _("Английский (Пакистан)"),
    "en-PH": _("Английский (Филиппины)"),
    "en-SG": _("Английский (Сингапур)"),
    "en-ZA": _("Английский (Южная Африка)"),
    "en-TZ": _("Английский (Танзания)"),
    "en-GB": _("Английский (Великобритания)"),
    "en-US": _("Английский (США)"),
    "et-EE": _("Эстонский (Эстония)"),
    "fil-PH": _("Филиппинский (Филиппины)"),
    "fi-FI": _("Финский (Финляндия)"),
    "fr-BE": _("Французский (Бельгия)"),
    "fr-CA": _("Французский (Канада)"),
    "fr-FR": _("Французский (Франция)"),
    "fr-CH": _("Французский (Швейцария)"),
    "gl-ES": _("Галисийский (Испания)"),
    "ka-GE": _("Грузинский (Грузия)"),
    "de-AT": _("Немецкий (Австрия)"),
    "de-DE": _("Немецкий (Германия)"),
    "de-CH": _("Немецкий (Швейцария)"),
    "el-GR": _("Греческий (Греция)"),
    "gu-IN": _("Гуджарати (Индия)"),
    "iw-IL": _("Иврит (Израиль)"),
    "hi-IN": _("Хинди (Индия)"),
    "hu-HU": _("Венгерский (Венгрия)"),
    "is-IS": _("Исландский (Исландия)"),
    "id-ID": _("Индонезийский (Индонезия)"),
    "it-IT": _("Итальянский (Италия)"),
    "it-CH": _("Итальянский (Швейцария)"),
    "ja-JP": _("Японский (Япония)"),
    "jv-ID": _("Яванский (Индонезия)"),
    "kn-IN": _("Каннада (Индия)"),
    "kk-KZ": _("Казахский (Казахстан)"),
    "km-KH": _("Кхмерский (Камбоджа)"),
    "rw-RW": _("Киньяруанда (Руанда)"),
    "ko-KR": _("Корейский (Южная Корея)"),
    "lo-LA": _("Лаосский (Лаос)"),
    "lv-LV": _("Латышский (Латвия)"),
    "lt-LT": _("Литовский (Литва)"),
    "mk-MK": _("Македонский (Северная Македония)"),
    "ms-MY": _("Малайский (Малайзия)"),
    "ml-IN": _("Малаялам (Индия)"),
    "mr-IN": _("Маратхи (Индия)"),
    "mn-MN": _("Монгольский (Монголия)"),
    "ne-NP": _("Непальский (Непал)"),
    "no-NO": _("Норвежский (Норвегия)"),
    "fa-IR": _("Персидский (Иран)"),
    "pl-PL": _("Польский (Польша)"),
    "pt-BR": _("Португальский (Бразилия)"),
    "pt-PT": _("Португальский (Португалия)"),
    "pa-Guru-IN": _("Пенджабский (гурмукхи, Индия)"),
    "ro-RO": _("Румынский (Румыния)"),
    "ru-RU": _("Русский (Россия)"),
    "sr-RS": _("Сербский (Сербия)"),
    "si-LK": _("Сингальский (Шри-Ланка)"),
    "sk-SK": _("Словацкий (Словакия)"),
    "sl-SI": _("Словенский (Словения)"),
    "st-ZA": _("Сесото (Южная Африка)"),
    "es-AR": _("Испанский (Аргентина)"),
    "es-BO": _("Испанский (Боливия)"),
    "es-CL": _("Испанский (Чили)"),
    "es-CO": _("Испанский (Колумбия)"),
    "es-CR": _("Испанский (Коста-Рика)"),
    "es-DO": _("Испанский (Доминиканская Республика)"),
    "es-EC": _("Испанский (Эквадор)"),
    "es-SV": _("Испанский (Сальвадор)"),
    "es-GT": _("Испанский (Гватемала)"),
    "es-HN": _("Испанский (Гондурас)"),
    "es-MX": _("Испанский (Мексика)"),
    "es-NI": _("Испанский (Никарагуа)"),
    "es-PA": _("Испанский (Панама)"),
    "es-PY": _("Испанский (Парагвай)"),
    "es-PE": _("Испанский (Перу)"),
    "es-PR": _("Испанский (Пуэрто-Рико)"),
    "es-ES": _("Испанский (Испания)"),
    "es-US": _("Испанский (США)"),
    "es-UY": _("Испанский (Уругвай)"),
    "es-VE": _("Испанский (Венесуэла)"),
    "su-ID": _("Сунданский (Индонезия)"),
    "sw-KE": _("Суахили (Кения)"),
    "sw-TZ": _("Суахили (Танзания)"),
    "ss-Latn-ZA": _("Сисвати (латиница, Южная Африка)"),
    "sv-SE": _("Шведский (Швеция)"),
    "ta-IN": _("Тамильский (Индия)"),
    "ta-MY": _("Тамильский (Малайзия)"),
    "ta-SG": _("Тамильский (Сингапур)"),
    "ta-LK": _("Тамильский (Шри-Ланка)"),
    "te-IN": _("Телугу (Индия)"),
    "th-TH": _("Тайский (Таиланд)"),
    "ts-ZA": _("Тсонга (Южная Африка)"),
    "tn-Latn-ZA": _("Тсвана (латиница, Южная Африка)"),
    "tr-TR": _("Турецкий (Турция)"),
    "uk-UA": _("Украинский (Украина)"),
    "ur-IN": _("Урду (Индия)"),
    "ur-PK": _("Урду (Пакистан)"),
    "uz-UZ": _("Узбекский (Узбекистан)"),
    "ve-ZA": _("Венда (Южная Африка)"),
    "vi-VN": _("Вьетнамский (Вьетнам)"),
    "xh-ZA": _("Коса (Южная Африка)"),
    "zu-ZA": _("Зулу (Южная Африка)")
}).map(([value, label]) => ({
    label,
    value
}));

/**
 * @param {{label: string}[]} options
 * @param {string} search
 * @param {string} searchField
 */
function searchOption(options, search, searchField) {
    if (!Array.isArray(options)) return options;
    if (!search || typeof search !== "string") return options;
    const candidates = options.filter((el) =>
        el[searchField] ? .toLowerCase() ? .includes(search.toLowerCase()),
    );
    return candidates.sort((a, b) => {
        const valueA = a[searchField].toLowerCase();
        const valueB = b[searchField].toLowerCase();
        return valueA.indexOf(search) - valueB.indexOf(search);
    })
}
/**
 * @param {object} params
 * @returns {Promise<{ error: boolean, cards?: object }>}
 */
async function getCountriesStackRender(params) {
    let url = isAuth() ? '/stubs/handler_api_internal.php' : '/stubs/apiMobile.php'
    const res = await SaApi(url, {
        action: "countriesStackRender",
        change: true,
        render: true,
        ...params,
    });

    let result = await getFetchResponse(res)

    if (result ? .status === 'error') return {
        error: true
    }

    if (typeof result.status !== 'undefined' && result.status === 'error') {
        globalAlert(_('Ошибка') + ': ' + result.msg)
        return {
            error: true
        }
    }

    return {
        error: false,
        result: result
    }
}
// если нужно использовать api из localStorage раскоментить строки ниже

let apiKeyForLaravelApi = window.localStorage.getItem("apiKey")
// const apiLocalStorageUrl = window.localStorage.getItem("apiLaravelUrl")

let stageLaravelUrl;
const isDevelopment = window.appMode === 'development'

if (window.appMode === 'development') {
    apiLaravelUrl = 'https://sa-staging.keepcode.org/api/v2'
} else {
    apiLaravelUrl = '/api/web'
}

// if (apiLocalStorageUrl) {
//   apiLaravelUrl = apiLocalStorageUrl
// }

let headers = isDevelopment ? {
    'X-API-key': apiKeyForLaravelApi
} : {}

const SaLaravelApi = {
    get: async (path, params = {}) => {
        if (!isDevelopment) params.csrf = getCsrf()
        let query = new URLSearchParams(params)
        let url = apiLaravelUrl + path + (Object.keys(params).length > 0 ? '?' + query : '')
        return new Promise(async (resolve, reject) => {
            let res = await fetch(url, {
                method: 'GET',
                headers: {
                    ...headers
                },
            })
            if (res.ok) {
                resolve(res)
            } else {
                reject(res)
            }
        })
    },
    post: async (path, params = {}) => {
        if (!isDevelopment) params.csrf = getCsrf()
        let url = apiLaravelUrl + path
        return new Promise(async (resolve, reject) => {
            let res = await fetch(url, {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json",
                    ...headers
                },
                body: JSON.stringify(params)
            })
            if (res.ok) {
                resolve(res)
            } else {
                reject(res)
            }
        })

    },
    put: async (path, params = {}) => {
        if (!isDevelopment) params.csrf = getCsrf()
        let url = apiLaravelUrl + path
        return new Promise(async (resolve, reject) => {
            let res = await fetch(url, {
                method: 'PUT',
                headers: {
                    "Content-Type": "application/json",
                    ...headers
                },
                body: JSON.stringify(params)
            })
            if (res.ok) {
                resolve(res)
            } else {
                reject(res)
            }
        })
    },
    delete: async (path, params = {}) => {
        if (!isDevelopment) params.csrf = getCsrf()
        let url = apiLaravelUrl + path
        return new Promise(async (resolve, reject) => {
            let res = await fetch(url, {
                method: 'DELETE',
                headers: {
                    "Content-Type": "application/json",
                    ...headers
                },
                body: JSON.stringify(params)
            })
            if (res.ok) {
                resolve(res)
            } else {
                reject(res)
            }
        })
    }
}

function getCurrency(currency) {
    return CURRENCY_SYMBOLS[Number(currency)];
}


function getLangPrefix(lang) {
    return ['es', 'cn'].includes(lang) ? '/' + lang : '';
}
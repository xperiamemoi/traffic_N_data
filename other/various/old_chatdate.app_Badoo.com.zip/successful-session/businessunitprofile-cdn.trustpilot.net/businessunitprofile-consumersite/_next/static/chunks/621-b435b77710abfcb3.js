! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "6a51bac3-bb2e-425e-9264-4b20663fc3a4", e._sentryDebugIdIdentifier = "sentry-dbid-6a51bac3-bb2e-425e-9264-4b20663fc3a4")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [621], {
        20541: function(e, n, t) {
            "use strict";
            t.d(n, {
                Z: function() {
                    return _
                }
            });
            var r = t(85893),
                i = t(67294),
                a = t(11616),
                s = t(11752),
                o = t.n(s),
                l = t(54248),
                c = t(18462),
                u = t(71981),
                d = t(66887),
                p = t(10354),
                v = t.n(p),
                f = t(81332),
                m = e => {
                    let [n, t] = (0, i.useState)(!1);
                    return ((0, i.useEffect)(() => t(!0), []), !n && e.client || n && e.server) ? null : e.children
                };
            let {
                facebookAppId: h,
                googleClientId: w,
                googleRecaptchaScoreSiteKey: g,
                appleClientId: b
            } = o()().publicRuntimeConfig, y = {
                facebookAppId: h,
                googleClientId: w,
                googleRecaptchaScoreSiteKey: g,
                webhost: "",
                appleClientId: b
            }, x = () => {
                let {
                    locale: e
                } = i.useContext(u.Il), {
                    legalUrl: n
                } = d.Pu.getLocale(e);
                return {
                    privacyPolicy: "".concat(n, "/for-reviewers/end-user-privacy-terms"),
                    termsAndConditions: "".concat(n, "/for-reviewers/end-user-terms-and-conditions")
                }
            };
            var _ = e => {
                let {
                    onAuthenticate: n,
                    enableGoogleOneTap: t = !0
                } = e, {
                    track: s,
                    locale: o
                } = i.useContext(u.Il), d = (0, f.hz)("consumer-site-facebook-authentication", !0), p = (0, f.hz)("consumer-site-apple-authentication", !1), h = (0, f.hz)("consumer-site-marketing-opt-in-checkbox", !1), w = i.useMemo(() => new(v())().withOptions({
                    lazyInitialize: !1,
                    onError: () => {
                        s("Simplicity Load Failed", {
                            timeout: !1,
                            error: !0
                        })
                    },
                    onTimeout: e => {
                        s("Simplicity Load Failed", {
                            timeout: !0,
                            elapsedMs: e,
                            error: !1
                        })
                    }
                }).build(), [s]), g = x();
                return (0, r.jsx)(m, {
                    client: !0,
                    children: (0, r.jsx)(a._, {
                        locale: o,
                        translations: c.Z[o],
                        children: (0, r.jsx)(l.Ho, {
                            authContext: y,
                            simplicityProvider: w,
                            legalUrls: g,
                            onAuthenticate: n,
                            initialSubView: "email-hidden",
                            isFacebookAuthenticationEnabled: d,
                            isAppleAuthenticationEnabled: p,
                            enableGoogleOneTap: t,
                            showMarketingOptIn: h
                        })
                    })
                })
            }
        },
        45968: function(e, n, t) {
            "use strict";
            t.d(n, {
                Z: function() {
                    return b
                }
            });
            var r = t(85893),
                i = t(67294),
                a = t(54248),
                s = t(71981),
                o = t(10354),
                l = t.n(o),
                c = t(89217),
                u = t(47193),
                d = t(19912),
                p = t(79008),
                v = t(14209),
                f = t(65541),
                m = t(52362),
                h = t(25810);
            let w = async (e, n) => await (await e("/api/businessunitprofile/service-reviews/".concat(n, "/compliance-data"))).json(),
                g = async (e, n, t, r, i, a) => {
                    let s = (0, h.E)(t),
                        o = {
                            [s.reason]: !0
                        },
                        l = {
                            fabricatedReview: "",
                            marketingOrSpam: "",
                            sensitiveInformation: "",
                            coarseLanguage: ""
                        };
                    s.comment && (l[s.reason] = s.comment);
                    let c = await e("/api/businessunitprofile/service-reviews/".concat(n, "/compliance-data"), {
                        method: "POST",
                        body: JSON.stringify({
                            notificationReasons: o,
                            notificationReasonsComments: l,
                            titleSelections: i,
                            contentSelections: a,
                            simplicity: r
                        })
                    });
                    if (!c.ok) throw new m.o(c);
                    return await c.json()
                };
            var b = e => {
                let {
                    reviewId: n,
                    reviewText: t,
                    reviewTitle: o,
                    highlightingEnabled: m
                } = e, {
                    fetch: h
                } = (0, u.i)(), {
                    isLoggedIn: b
                } = (0, a.xO)(), y = (0, p.Tm)(), x = i.useContext(s.Il), [_, j] = i.useState(!1), [k, I] = i.useState(!1), [C, T] = i.useState(!1), [S, P] = i.useState({}), R = (0, d.r$)(n, y.id), W = async () => {
                    if (I(!0), !b) {
                        (0, d.rf)();
                        return
                    }
                    let e = await w(h, n);
                    if (x.track("Button Clicked", {
                            name: "notify-compliance",
                            action: "notify-compliance",
                            alreadyFlagged: !e.canNotify
                        }), !e.canNotify) return T(!0), I(!1);
                    P(e.disabledReasonsReasons), j(!0), I(!1)
                }, L = async e => {
                    let t;
                    switch (e.violation) {
                        case f.i.AdvertisingOrPromotional:
                            t = e.advertisingOrPromotionalReason;
                            break;
                        case f.i.HarmfulOrIllegal:
                            t = e.harmfulOrIllegalReason;
                            break;
                        case f.i.Fabricated:
                            t = e.fabricatedReason;
                            break;
                        case f.i.SensitiveInformation:
                        default:
                            t = f.i.SensitiveInformation
                    }
                    let r = !0;
                    try {
                        let i = new(l())().withOptions({
                                lazyInitialize: !1,
                                useFingerprint: !0
                            }).build(),
                            a = await i.getSimplicityData();
                        if (!(r = (await g(h, n, t, a, e.reviewTitleSelections, e.reviewTextSelections)).success)) throw Error("Failed to post review report!")
                    } finally {
                        x.track("Notification Submission Attempted", {
                            success: r,
                            reason: (0, c.ns)(e),
                            subreason: (0, c.Fe)(e)
                        })
                    }
                };
                return (0, r.jsx)(v.Z, {
                    businessUnitId: y.id,
                    businessUnitIdentifyingName: y.identifyingName,
                    businessLinkUrl: R,
                    reviewId: n,
                    reviewText: t,
                    reviewTitle: o,
                    highlightingEnabled: m,
                    loading: k,
                    disabled: C,
                    isModalOpen: _,
                    disabledReasonsReasons: S,
                    onOpenHandler: W,
                    onCloseHandler: e => {
                        x.track("Modal Closed", {
                            name: "Notifying Flow",
                            ...e
                        }), j(!1)
                    },
                    onSubmit: L
                })
            }
        },
        63270: function(e, n, t) {
            "use strict";
            var r = t(85893),
                i = t(67294),
                a = t(94343),
                s = t(8075),
                o = t(40136),
                l = t(65487),
                c = t(17510),
                u = t(81344);
            n.Z = () => {
                let [e] = (0, a.T)(), n = i.useId(), t = e["service-review-card/banner/pending/header"], {
                    formatHelpCenterLink: d
                } = (0, u.P)();
                return (0, r.jsx)(o.w, {
                    appearance: "info",
                    name: "pending-banner",
                    header: t,
                    expandable: !0,
                    id: n,
                    children: (0, r.jsx)(l.ZT, {
                        variant: "body-m",
                        children: (0, r.jsx)(s.x, {
                            id: "service-review-card/banner/pending/body",
                            interpolations: {
                                LINK: e => (0, r.jsx)(c.rU, {
                                    color: "inherit",
                                    rel: "nofollow",
                                    target: "_blank",
                                    underline: !0,
                                    href: d("https://help.trustpilot.com/s/article/Why-we-delay-posting-reviews"),
                                    trackingProps: {
                                        name: "pending-review-read-more",
                                        target: "Support 4870054488082"
                                    },
                                    children: e
                                }, "pending-review-support")
                            }
                        })
                    })
                })
            }
        },
        7188: function(e, n, t) {
            "use strict";
            t.d(n, {
                L: function() {
                    return f
                }
            });
            var r = t(85893),
                i = t(67294),
                a = t(8075),
                s = t(94343),
                o = t(65487),
                l = t(17510),
                c = t(71981),
                u = t(40136),
                d = t(66522),
                p = t(52007);
            let v = (e, n, t, s, c, u, d, v) => {
                    var f;
                    let m = {
                            harmfulOrIllegal: {
                                href: (0, p.O)("https://help.trustpilot.com/s/article/What-happens-if-my-review-is-flagged", d),
                                trackingProps: {
                                    name: "review-flagged",
                                    target: "Support 207312237"
                                }
                            },
                            otherReasons: {
                                href: (0, p.O)("https://help.trustpilot.com/s/article/Quick-guide-to-Trustpilots-Guidelines-for-Reviewers", d),
                                trackingProps: {
                                    name: "user-guidelines",
                                    target: "Support 201748526"
                                }
                            }
                        },
                        h = t ? m.harmfulOrIllegal : m.otherReasons,
                        w = "46d6a890000064000500e0c3" === c,
                        g = null !== (f = null == e ? void 0 : e.toLowerCase()) && void 0 !== f ? f : "",
                        b = "",
                        y = "";
                    if (s) b = "service-review-card/banner/report/review-under-moderation/header", y = "service-review-card/banner/report/review-under-moderation/body";
                    else if (t) {
                        let e = "flagged-by-robots";
                        "consumer" === g ? e = "flagged-by-consumer" : "businessuser" === g && (e = w ? "tp-cpp/flagged-by-tp" : "flagged-by-business"), b = "service-review-card/banner/report/harmful-or-illegal/".concat(e, "/header"), y = "service-review-card/banner/report/harmful-or-illegal/".concat(n ? "private-view" : "public-view").concat(w ? "/tp-cpp/flagged-by-tp" : "", "/body")
                    } else b = "service-review-card/banner/report/all-reasons/removed/header", y = -1 !== ["consumer", "businessuser"].indexOf(g) ? "service-review-card/banner/report/all-reasons/removed/body" : "service-review-card/banner/report/all-reasons/removed/flagged-by-robots/body";
                    return {
                        header: v[b].replace("[COMPANY]", u),
                        body: (0, r.jsx)(o.ZT, {
                            variant: "body-m",
                            children: (0, r.jsx)(a.x, {
                                id: y,
                                interpolations: {
                                    LINK: e => (0, r.jsx)(l.rU, {
                                        color: "inherit",
                                        underline: !0,
                                        rel: "nofollow",
                                        target: "_blank",
                                        href: h.href,
                                        trackingProps: h.trackingProps,
                                        children: e
                                    }, "1"),
                                    "LINE-BREAK": (0, r.jsxs)(i.Fragment, {
                                        children: [(0, r.jsx)("br", {}), (0, r.jsx)("br", {})]
                                    }, "br")
                                }
                            })
                        })
                    }
                },
                f = e => {
                    let {
                        isCurrentConsumer: n,
                        report: t,
                        filtered: a,
                        business: o
                    } = e, [l] = (0, s.T)(), p = i.useId(), {
                        locale: f
                    } = i.useContext(c.Il);
                    if (!t) return null;
                    let m = (0, d.c)(t),
                        h = "untrue_course_of_events" === t.reason,
                        w = n && !m && a;
                    if (!m && !w && !h) return null;
                    let g = v(t.source, n, m, h, o.id, o.displayName, f, l);
                    return (0, r.jsx)(u.w, {
                        name: "report-banner",
                        appearance: "flagged",
                        header: g.header,
                        expandable: !0,
                        id: p,
                        children: g.body
                    })
                }
        },
        96946: function(e, n, t) {
            "use strict";
            t.d(n, {
                N: function() {
                    return s
                }
            });
            var r = t(67294),
                i = t(71981),
                a = t(47193);
            let s = function(e) {
                let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : () => null,
                    {
                        track: t
                    } = r.useContext(i.Il),
                    [s, o] = r.useState(!1),
                    {
                        fetch: l
                    } = (0, a.i)();
                return [s, async () => {
                    try {
                        (await l("/api/businessunitprofile/service-reviews/".concat(e), {
                            method: "DELETE"
                        })).ok && (t("Review Deleted", {
                            reviewId: e
                        }), o(!0))
                    } catch (e) {
                        alert("Coudln't delete your review, something unexpected happened")
                    } finally {
                        setTimeout(() => n(), 300)
                    }
                }]
            }
        },
        38433: function(e, n, t) {
            "use strict";
            t.d(n, {
                m: function() {
                    return m
                }
            });
            var r = t(85893),
                i = t(67294),
                a = t(94343),
                s = t(8075),
                o = t(19051),
                l = t(4359),
                c = t(65487),
                u = t(11944),
                d = t.n(u),
                p = t(19912),
                v = t(32173),
                f = t.n(v);
            let m = e => {
                let {
                    onDeleteReview: n
                } = e, [t] = (0, a.T)(), [u, v] = i.useState(!1), m = async () => {
                    if (v(!0), !confirm(t["service-review-card/delete-review/confirmation"])) {
                        v(!1);
                        return
                    }
                    n && await n(), v(!1)
                };
                return (0, r.jsxs)(o.Q, {
                    name: "delete-review",
                    onClick: m,
                    trackingProps: {
                        name: "delete-review",
                        action: "Delete review"
                    },
                    "aria-label": t["service-review-card/actions/delete-review/label"],
                    disabled: u,
                    appearance: "subtle",
                    size: "s",
                    className: (0, p.AK)(f().actionButtons, f().button),
                    children: [(0, r.jsx)(l.J, {
                        content: d(),
                        color: "currentColor",
                        width: 14,
                        height: 14
                    }), (0, r.jsx)(c.ZT, {
                        variant: "body-m",
                        as: "span",
                        appearance: "inherit",
                        children: (0, r.jsx)(s.x, {
                            id: "service-review-card/actions/delete-review/button"
                        })
                    })]
                })
            }
        },
        33128: function(e, n, t) {
            "use strict";
            t.d(n, {
                m: function() {
                    return f
                }
            });
            var r = t(85893);
            t(67294);
            var i = t(94343),
                a = t(8075),
                s = t(17510),
                o = t(4359),
                l = t(65487),
                c = t(67358),
                u = t.n(c),
                d = t(19912),
                p = t(32173),
                v = t.n(p);
            let f = e => {
                let {
                    reviewId: n
                } = e, [t] = (0, i.T)();
                return (0, r.jsxs)(s.rU, {
                    href: (0, d.lI)(n),
                    rel: "nofollow",
                    title: t["service-review-card/actions/edit-review/title"],
                    name: "edit-review",
                    appearance: "subtle",
                    className: (0, d.AK)(v().actionButtons, v().button),
                    trackingProps: {
                        name: "edit-review",
                        target: "Evaluate page",
                        legacyEventName: "EditReviewButtonClicked",
                        reviewId: n
                    },
                    children: [(0, r.jsx)(o.J, {
                        content: u(),
                        color: "currentColor",
                        width: 14,
                        height: 14
                    }), (0, r.jsx)(l.ZT, {
                        variant: "body-m",
                        as: "span",
                        appearance: "inherit",
                        children: (0, r.jsx)(a.x, {
                            id: "service-review-card/actions/edit-review/label"
                        })
                    })]
                })
            }
        },
        58432: function(e, n, t) {
            "use strict";
            t.d(n, {
                m: function() {
                    return O
                }
            });
            var r = t(85893),
                i = t(67294),
                a = t(8075),
                s = t(54248),
                o = t(71981),
                l = t(84676),
                c = t(87442),
                u = t(4359),
                d = t(17510),
                p = t(8706),
                v = t.n(p),
                f = t(20541),
                m = t(30592),
                h = t.n(m),
                w = e => {
                    let {
                        isOpen: n,
                        onClose: t,
                        ...i
                    } = e;
                    return (0, r.jsxs)(c.u_, {
                        name: "authentication",
                        isOpen: n,
                        onClose: t,
                        children: [(0, r.jsx)(c.xB, {
                            leftAction: (0, r.jsx)(r.Fragment, {}),
                            children: (0, r.jsx)(a.x, {
                                id: "authentication-modal/header"
                            })
                        }), (0, r.jsx)(c.hz, {
                            children: (0, r.jsx)("div", {
                                className: h().content,
                                children: (0, r.jsx)(f.Z, { ...i,
                                    enableGoogleOneTap: !1
                                })
                            })
                        })]
                    })
                };
            let g = e => {
                let {
                    condition: n,
                    children: t,
                    wrapper: i
                } = e;
                return n ? i(t) : (0, r.jsx)(r.Fragment, {
                    children: t
                })
            };
            var b = t(42298),
                y = t(47193),
                x = t(19912),
                _ = t(52362);
            let j = async (e, n) => await (await e("/api/businessunitprofile/service-reviews/".concat(n, "/likes"))).json(),
                k = async (e, n, t) => {
                    let r = await e("/api/businessunitprofile/service-reviews/".concat(n, "/likes"), {
                        method: "POST",
                        body: JSON.stringify({
                            reviewId: n,
                            consumerLikesReview: t
                        })
                    });
                    if (!r.ok) throw new _.o(r);
                    return await r.json()
                };
            var I = t(92699),
                C = t(76772),
                T = t.n(C);
            let S = e => {
                let {
                    likes: n,
                    showButton: t,
                    onShowMoreButtonClick: s,
                    onMount: o
                } = e;
                return i.useEffect(() => {
                    o()
                }, [o]), (0, r.jsxs)(r.Fragment, {
                    children: [n.map((e, n, t) => {
                        let {
                            consumerDisplayName: i,
                            consumerId: a
                        } = e;
                        return (0, r.jsx)(d.rU, {
                            variant: "body-m",
                            className: T().userProfileLink,
                            href: (0, x.Xg)(a),
                            children: "".concat(i).concat(n < t.length - 1 ? "," : "")
                        }, a)
                    }), t ? (0, r.jsx)(I.Sn, {
                        name: "show-all-likes",
                        appearance: "secondary",
                        size: "s",
                        className: T().showMoreButton,
                        onClick: s,
                        children: (0, r.jsx)(a.x, {
                            id: "service-review-card/find-useful/show-all"
                        })
                    }) : null]
                })
            };
            var P = t(19051),
                R = t(65487),
                W = t(32173),
                L = t.n(W);
            let N = e => {
                    let {
                        count: n,
                        isLikedByCurrentConsumer: t,
                        ...i
                    } = e, s = t ? "action" : "subtle";
                    return (0, r.jsxs)(P.Q, {
                        name: "find-useful",
                        appearance: s,
                        className: (0, x.AK)(L().actionButtons, L().button),
                        ...i,
                        children: [(0, r.jsx)(u.J, {
                            content: v(),
                            color: "currentColor",
                            width: 14,
                            height: 14
                        }), (0, r.jsxs)(R.ZT, {
                            variant: "body-m",
                            as: "span",
                            appearance: "inherit",
                            className: T().usefulLabel,
                            children: [(0, r.jsx)(a.x, {
                                id: "service-review-card/actions/find-useful/button"
                            }), n > 0 ? (0, r.jsx)(R.ZT, {
                                weight: "heavy",
                                variant: "body-m",
                                as: "span",
                                appearance: s,
                                name: "find-useful-count",
                                children: n
                            }) : null]
                        })]
                    })
                },
                O = e => {
                    let {
                        likes: n,
                        reviewId: t
                    } = e, {
                        track: p
                    } = i.useContext(o.Il), {
                        consumer: f,
                        isLoggedIn: m
                    } = (0, s.xO)(), {
                        fetch: h
                    } = (0, y.i)(), I = (0, b.k)("smaller-than", "tablet-small"), [C, P] = i.useState(!1), [R, W] = i.useState(!1), L = i.useRef(!1), [O, B] = i.useState([]), [M, A] = i.useState(n), [E, F] = i.useState(!1), D = [...O].reverse().slice(0, 5), Z = m && !!O.find(e => {
                        let {
                            consumerId: n
                        } = e;
                        return n === (null == f ? void 0 : f.id)
                    }), [U, z] = i.useState(!1);
                    i.useEffect(() => {
                        async function e() {
                            L.current = !0;
                            try {
                                let e = await j(h, t);
                                F(!0), B(e.likes)
                            } catch (e) {}
                            L.current = !1
                        }
                        n > 0 && !E && (m || R) && e()
                    }, [n, m, R, h, t, E]);
                    let K = () => ({
                        action: Z ? "Removed like" : "Liked",
                        reviewId: t
                    });
                    async function G(e) {
                        if (!0 !== L.current) {
                            if (L.current = !0, !e || !e.hasAcceptedTerms) {
                                z(!0);
                                return
                            }
                            try {
                                let n = !Z;
                                if (!(await k(h, t, n)).success) return;
                                p("Review Liked", K()), n ? (B(n => [...n, {
                                    consumerDisplayName: e.displayName,
                                    consumerId: e.id
                                }]), A(e => ++e)) : (B(n => n.filter(n => {
                                    let {
                                        consumerId: t
                                    } = n;
                                    return t !== e.id
                                })), A(e => --e)), L.current = !1
                            } catch (e) {
                                L.current = !1, e instanceof _.o && (0, x.hK)(null == e ? void 0 : e.response.status)
                            }
                        }
                    }
                    let H = async () => {
                        p("Button Clicked", {
                            name: "find-useful",
                            ...K()
                        }), G(f)
                    };
                    return (0, r.jsxs)(r.Fragment, {
                        children: [(0, r.jsx)(g, {
                            condition: !I && M > 0,
                            wrapper: e => (0, r.jsx)(l.u, {
                                placement: "bottom",
                                tooltipText: (0, r.jsx)(S, {
                                    likes: D,
                                    showButton: M > 5,
                                    onShowMoreButtonClick: () => P(!0),
                                    onMount: () => W(!0)
                                }),
                                children: e
                            }),
                            children: (0, r.jsx)(N, {
                                count: M,
                                onClick: H,
                                isLikedByCurrentConsumer: Z
                            })
                        }), (0, r.jsxs)(c.u_, {
                            name: "likes",
                            isOpen: C,
                            onClose: () => P(!1),
                            children: [(0, r.jsxs)(c.xB, {
                                children: [(0, r.jsx)("span", {
                                    className: T().iconWrapper,
                                    children: (0, r.jsx)(u.J, {
                                        content: v()
                                    })
                                }), (0, r.jsx)(a.x, {
                                    id: "service-review-card/find-useful/modal/title",
                                    interpolations: {
                                        COUNT: O.length
                                    }
                                })]
                            }), (0, r.jsx)(c.hz, {
                                children: (0, r.jsx)("div", {
                                    className: T().userProfileLinksWrapper,
                                    children: O.map(e => {
                                        let {
                                            consumerId: n,
                                            consumerDisplayName: t
                                        } = e;
                                        return (0, r.jsx)(d.rU, {
                                            className: T().userProfileLink,
                                            href: (0, x.Xg)(n),
                                            title: t,
                                            children: t
                                        }, n)
                                    })
                                })
                            })]
                        }), (0, r.jsx)(w, {
                            isOpen: U,
                            onClose: () => {
                                L.current = !1, z(!1)
                            },
                            onAuthenticate: e => {
                                L.current = !1, z(!1), G(e)
                            }
                        })]
                    })
                }
        },
        12131: function(e, n, t) {
            "use strict";
            t.d(n, {
                _: function() {
                    return f
                }
            });
            var r = t(85893);
            t(67294);
            var i = t(94343),
                a = t(8075),
                s = t(75365),
                o = t(4359),
                l = t(65487),
                c = t(73345),
                u = t.n(c),
                d = t(19912),
                p = t(32173),
                v = t.n(p);
            let f = e => {
                let {
                    reviewId: n,
                    businessUnitId: t
                } = e, [c] = (0, i.T)(), p = (0, d.r$)(n, t);
                return (0, r.jsxs)(s.g, {
                    href: p,
                    rel: "nofollow",
                    target: "_blank",
                    title: c["service-review-card/actions/reply-as-business/title"],
                    name: "reply-as-company",
                    className: (0, d.AK)(v().actionButtons, v().button),
                    trackingProps: {
                        name: "reply-as-company",
                        target: "Business App",
                        legacyEventName: "ReplyAsCompany"
                    },
                    children: [(0, r.jsx)(o.J, {
                        content: u(),
                        appearance: "inherit",
                        width: 14,
                        height: 14
                    }), (0, r.jsx)(l.ZT, {
                        variant: "body-m",
                        as: "span",
                        appearance: "inherit",
                        children: (0, r.jsx)(a.x, {
                            id: "service-review-card/actions/reply-as-business/label"
                        })
                    })]
                })
            }
        },
        26596: function(e, n, t) {
            "use strict";
            t.d(n, {
                k: function() {
                    return p
                }
            });
            var r = t(85893),
                i = t(67294),
                a = t(8075),
                s = t(87322),
                o = t(65487),
                l = t(21364),
                c = t.n(l),
                u = t(19912);
            let d = e => {
                    let n = (0, u.WT)(e);
                    return n.startsWith("/") ? "".concat(window.location.origin).concat(n) : n
                },
                p = e => {
                    let {
                        review: n
                    } = e, [t, l] = i.useState(!1), u = i.useRef(0);
                    return i.useEffect(() => () => clearTimeout(u.current), []), (0, r.jsx)(s.h, {
                        name: "copy-url",
                        icon: c(),
                        iconPosition: "left",
                        appearance: "outline",
                        wide: !0,
                        size: "m",
                        onClick: () => {
                            let e = d(n.id);
                            navigator.clipboard.writeText(e).then(() => {
                                l(!0), clearTimeout(u.current), u.current = window.setTimeout(() => {
                                    l(!1)
                                }, 1500)
                            })
                        },
                        trackingProps: {
                            action: "Copy url",
                            name: "copy-url"
                        },
                        children: (0, r.jsx)(o.ZT, {
                            variant: "body-m",
                            weight: "heavy",
                            as: "span",
                            appearance: "inherit",
                            children: t ? (0, r.jsx)(a.x, {
                                id: "service-review-card/actions/share-review/copy-url-success/message"
                            }) : (0, r.jsx)(a.x, {
                                id: "service-review-card/actions/share-review/copy-url/button"
                            })
                        })
                    })
                }
        },
        69101: function(e, n, t) {
            "use strict";

            function r(e, n, t) {
                let r = {
                    copyhistory: !1,
                    directories: !1,
                    location: !1,
                    menubar: !1,
                    resizable: !1,
                    scrollbars: !0,
                    status: !1,
                    toolbar: !1,
                    ...t
                };
                r.left = r.left || screen.width / 2 - r.width / 2, r.top = r.top || screen.height / 2 - r.height / 2;
                let i = Object.keys(r).map(e => "".concat(e, "=").concat(Number(r[e]))).join(",");
                return window.open(e, n, i)
            }
            t.d(n, {
                Q: function() {
                    return r
                }
            })
        },
        67414: function(e, n, t) {
            "use strict";
            t.d(n, {
                S: function() {
                    return p
                }
            });
            var r = t(85893);
            t(67294);
            var i = t(94343),
                a = t(8075),
                s = t(23181),
                o = t(87322),
                l = t(47270),
                c = t.n(l),
                u = t(19912);
            let d = () => (0, s.e)("tp-b2b-selected-business-unit-id"),
                p = e => {
                    let {
                        businessUnitId: n,
                        reviewId: t
                    } = e, [l] = (0, i.T)(), p = (0, u.n5)(t, n), v = d();
                    return (0, r.jsx)(o.h, {
                        name: "style-review",
                        icon: c(),
                        iconPosition: "right",
                        appearance: "outline",
                        wide: !0,
                        size: "m",
                        onClick: () => {
                            v && (0, s.d)(v, n, {
                                domain: location.hostname.split(".").splice(-2).join("."),
                                path: "/",
                                sameSite: "Strict"
                            }), window.open(p, "_blank")
                        },
                        trackingProps: {
                            action: "ShareReviewInBusinessApp",
                            name: "share-in-business-app"
                        },
                        title: l["service-review-card/share/share-in-business-app/long"],
                        children: (0, r.jsx)(a.x, {
                            id: "service-review-card/share/share-in-business-app/short"
                        })
                    })
                }
        },
        65427: function(e, n, t) {
            "use strict";
            t.d(n, {
                T: function() {
                    return o
                }
            });
            var r = t(85893);
            t(67294);
            var i = t(19912),
                a = t(73771),
                s = t.n(a);
            let o = e => {
                let {
                    className: n,
                    children: t
                } = e;
                return (0, r.jsx)("div", {
                    className: (0, i.AK)(s().wrapper, n),
                    children: t
                })
            }
        },
        88157: function(e, n, t) {
            "use strict";
            t.d(n, {
                m: function() {
                    return o
                }
            });
            var r = t(85893);
            t(67294);
            var i = t(8075),
                a = t(65487),
                s = t(99082);
            let o = e => {
                let {
                    filtered: n,
                    dates: t,
                    className: o = ""
                } = e;
                return (0, r.jsxs)(a.ZT, {
                    variant: "body-m",
                    appearance: "subtle",
                    as: "div",
                    className: o,
                    children: [(0, r.jsx)(s.i, { ...t,
                        dataName: "service-review-date"
                    }), n ? (0, r.jsx)(a.ZT, {
                        variant: "body-m",
                        weight: "heavy",
                        children: (0, r.jsx)(i.x, {
                            id: "service-review-card/removed"
                        })
                    }) : null]
                })
            }
        },
        65290: function(e, n, t) {
            "use strict";
            t.d(n, {
                v: function() {
                    return d
                }
            });
            var r = t(85893);
            t(67294);
            var i = t(8075),
                a = t(65487),
                s = t(17510),
                o = t(50141),
                l = t.n(o),
                c = t(81344),
                u = t(59375);
            let d = e => {
                let {
                    businessIdentifyingName: n
                } = e, {
                    formatHelpCenterLink: t
                } = (0, c.P)();
                return (0, r.jsx)(u.o, {
                    icon: l(),
                    label: (0, r.jsx)(i.x, {
                        id: "service-review-card/review-labels/merged/label"
                    }),
                    trackingProps: {
                        name: "Merged"
                    },
                    children: (0, r.jsx)(a.ZT, {
                        variant: "body-m",
                        children: (0, r.jsx)(i.x, {
                            id: "service-review-card/review-labels/merged/tooltip",
                            interpolations: {
                                "COMPANY-URL": n,
                                LINK: e => (0, r.jsx)(s.rU, {
                                    href: t("https://help.trustpilot.com/s/article/Why-are-some-business-profiles-and-reviews-marked-Merged?utm_campaign=merged&utm_content=merged_review_tooltip&utm_medium=referral&utm_source=CPP"),
                                    target: "_blank",
                                    trackingProps: {
                                        name: "support-article-merged-review",
                                        target: "Support 360015370220"
                                    },
                                    children: e
                                }, "1")
                            }
                        })
                    })
                })
            }
        },
        59375: function(e, n, t) {
            "use strict";
            t.d(n, {
                o: function() {
                    return u
                }
            });
            var r = t(85893);
            t(67294);
            var i = t(23201),
                a = t(65487),
                s = t(4359),
                o = t(1649),
                l = t.n(o);
            let c = e => {
                    let {
                        children: n,
                        icon: t
                    } = e;
                    return (0, r.jsxs)(a.ZT, {
                        variant: "body-m",
                        as: "div",
                        className: l().detailsIcon,
                        appearance: "subtle",
                        children: [(0, r.jsx)(s.J, {
                            content: t,
                            color: "currentColor",
                            width: 14,
                            height: 14
                        }), (0, r.jsx)("span", {
                            children: n
                        })]
                    })
                },
                u = e => {
                    let {
                        icon: n,
                        label: t,
                        children: a,
                        trackingProps: s
                    } = e;
                    return (0, r.jsx)("div", {
                        className: l().reviewLabel,
                        children: (0, r.jsx)(i.W, {
                            button: (0, r.jsx)("button", {
                                "data-review-label-tooltip-trigger": !0,
                                className: l().reviewLabelButton,
                                children: (0, r.jsx)(c, {
                                    icon: n,
                                    children: t
                                })
                            }),
                            modalTitle: t,
                            trackingProps: s,
                            tooltipTriggers: ["hover", "focus"],
                            children: a
                        })
                    })
                }
        },
        23330: function(e, n, t) {
            "use strict";
            t.d(n, {
                Cn: function() {
                    return p
                }
            });
            class r {
                toString() {
                    return this.name
                }
                constructor(e, n, t, r, i) {
                    this.id = e, this.name = n, this.isVerified = t, this.sourceGroup = r, this.defaultVerificationLevel = i
                }
            }
            let i = "automatic-invitation",
                a = "generated-link",
                s = "manual-invitation",
                o = "embedded-review-form",
                l = "organic",
                c = "not-verified",
                u = "invited",
                d = "verified",
                p = "BannerRedirect";
            new r(3, "AFS", !0, i, d), new r(1, "Kickstart", !0, s, u), new r(5, "Trustpilot", !1, l, c), new r(2, "LegacyUniqueLink", !0, a, u), new r(10, "AFSv1", !0, i, d), new r(11, "AFSv2", !0, i, d), new r(12, "BasicLink", !1, "basic-invitation", u), new r(13, "BigCommerce", !0, i, d), new r(14, "BusinessGeneratedLink", !0, a, u), new r(15, "CopyPasteInvitation", !0, s, u), new r(16, "EmbeddedUniqueLinkForm", !0, o, u), new r(17, "EmbeddedBusinessGeneratedLinkForm", !0, o, u), new r(18, "FileUploadInvitation", !0, s, u), new r(19, "InvitationApi", !0, i, d), new r(20, "InvitationLinkApi", !0, a, u), new r(21, "UniqueLink", !0, a, u), new r(22, "Magento", !0, i, d), new r(23, "ManualInputInvitation", !0, s, u), new r(24, "Organic", !1, l, c), new r(25, "Shopify", !0, i, d), new r(26, "WooCommerce", !0, i, d), new r(27, "InvitationScript", !0, i, d), new r(28, "PrestaShop", !0, i, d), new r(29, "MagentoV1", !0, i, d), new r(30, "MagentoV2", !0, i, d), new r(31, "OpenCart", !0, i, d), new r(32, "Segment", !0, i, d), new r(33, "Shopware", !0, i, d), new r(34, "DomainLink", !1, l, "redirected"), new r(35, "Wix", !0, i, d), new r(36, "GTM", !0, i, d), new r(37, "Square", !0, i, d), new r(38, "PayPal", !0, i, d), new r(39, "Salesforce", !0, i, d), new r(40, p, !0, a, u)
        },
        97075: function(e, n, t) {
            "use strict";
            t.d(n, {
                G: function() {
                    return s
                }
            });
            var r = t(67294),
                i = t(71981);
            let a = (e, n, t, i) => {
                    let a = r.useRef(null),
                        s = i || a,
                        o = r.useRef(e);
                    r.useEffect(() => {
                        o.current = e
                    }, [e]);
                    let l = r.useRef(t);
                    r.useEffect(() => {
                        l.current = t
                    }, [t]);
                    let [c, u] = r.useState(), d = r.useRef(), p = r.useRef(!1);
                    return r.useEffect(() => {
                        let e = new IntersectionObserver(e => {
                            let [n] = e;
                            return u(n)
                        }, l.current);
                        return s.current && e.observe(s.current), d.current = e, () => e.disconnect()
                    }, [s]), r.useEffect(() => {
                        let e;
                        return (null == c ? void 0 : c.isIntersecting) && (e = setTimeout(() => {
                            if (!p.current) {
                                if (p.current = !0, s.current) {
                                    var e;
                                    null === (e = d.current) || void 0 === e || e.unobserve(s.current)
                                }
                                o.current()
                            }
                        }, n)), () => clearTimeout(e)
                    }, [c, s, n]), s
                },
                s = e => {
                    let {
                        businessUnitId: n,
                        businessUnitIdentifyingName: t,
                        dates: s,
                        id: o,
                        isCurrentConsumer: l,
                        hasUnhandledReports: c,
                        rating: u,
                        report: d,
                        positionInList: p,
                        placement: v
                    } = e, {
                        track: f
                    } = r.useContext(i.Il), m = !l && !(c && null !== d);
                    return a(() => {
                        if (m) {
                            var e;
                            f("ReviewViewed", {
                                businessUnitId: n,
                                domain: t,
                                numberOfDaysLive: (e = new Date(s.publishedDate), Math.floor((new Date().getTime() - e.getTime()) / 864e5)),
                                numberOfStars: u,
                                positionInList: p,
                                reviewId: o,
                                ...v ? {
                                    placement: v
                                } : {}
                            })
                        }
                    }, 2e3, {
                        threshold: .5
                    })
                }
        },
        92465: function(e, n, t) {
            "use strict";
            var r = t(85893),
                i = t(67294),
                a = t(8075),
                s = t(19051),
                o = t(89140),
                l = t(86855),
                c = t.n(l);
            let u = e => e;
            n.Z = e => {
                var n, t;
                let {
                    text: l,
                    truncate: d,
                    trackingProps: p,
                    maxLength: v = 300,
                    textWrapper: f = u,
                    onClick: m,
                    textId: h,
                    className: w
                } = e, g = null !== (n = null == l ? void 0 : l.substring(0, v)) && void 0 !== n ? n : "", b = null !== (t = null == l ? void 0 : l.substring(v)) && void 0 !== t ? t : "", [y, x] = i.useState(b.length > 0);
                return d && y ? (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)("span", {
                        className: c().previewText,
                        children: f(g)
                    }), (0, r.jsx)("span", {
                        className: c().truncatedText,
                        children: f(b)
                    }), (0, r.jsx)(s.Q, {
                        name: "read-more",
                        appearance: w ? "inherit" : "subtle",
                        linkProps: {
                            underline: !1
                        },
                        className: (0, o.cn)(c().readMore, w),
                        onClick: () => m ? m() : x(!1),
                        trackingProps: p,
                        children: (0, r.jsx)(a.x, {
                            id: null != h ? h : "NO_TRANSLATE/service-review-card/actions/read-more/label"
                        })
                    })]
                }) : (0, r.jsx)(r.Fragment, {
                    children: f(l)
                })
            }
        },
        40886: function(e, n, t) {
            "use strict";
            var r, i, a, s, o, l, c, u, d, p;
            t.d(n, {
                $Z: function() {
                    return i
                },
                Bm: function() {
                    return a
                },
                JG: function() {
                    return o
                },
                LN: function() {
                    return s
                },
                R2: function() {
                    return v
                }
            });
            let v = {
                WarningScammerBusiness: "WarningScammerBusiness",
                WarningCustom: "WarningCustom",
                WarningFabricatedReviews: "WarningFabricatedReviews",
                WarningMisuseOfReporting: "WarningMisuseOfReporting",
                WarningIncentivesForReviews: "WarningIncentivesForReviews",
                WarningCherrypicking: "WarningCherrypicking",
                WarningBadFit: "WarningBadFit",
                WarningBiasedInvitation: "WarningBiasedInvitation",
                WarningThreats: "WarningThreats",
                WarningMisuseOfPublicReply: "WarningMisuseOfPublicReply",
                WarningConflictOfInterest: "WarningConflictOfInterest",
                WarningPurchasedReviews: "WarningPurchasedReviews",
                WarningIncorrectDisplayOfTrustpilotContent: "WarningIncorrectDisplayOfTrustpilotContent",
                WarningLegalThreatsTowardReviewer: "WarningLegalThreatsTowardReviewer",
                InfoCustom: "InfoCustom",
                InfoPreInvestigation: "InfoPreInvestigation",
                InfoMediaStorm: "InfoMediaStorm",
                InfoRegulatoryNotification: "InfoRegulatoryNotification",
                InfoIpr: "InfoIpr",
                InfoHighRiskInvestment: "InfoHighRiskInvestment",
                InfoRegulatoryActionFraud: "InfoRegulatoryActionFraud",
                InfoDutchNationalPolice: "InfoDutchNationalPolice"
            };
            (l = r || (r = {})).filtered = "filtered", l.reported = "reported", l.pending = "pending", l.active = "active", (c = i || (i = {})).verified = "verified", c.notverified = "not_verified", c.submitted = "submitted", c.failed = "failed", (u = a || (a = {})).in = "in", u.out = "out", u.undecided = "undecided", u.pending_confirmation = "pending_confirmation", (d = s || (s = {})).confirmed = "confirmed", d.failed = "failed", d.not_checked = "not_checked", (p = o || (o = {})).BroadMarketingPermission = "broad-marketing", p.PersonalizedRecommendationsPermission = "personalized-recommendations", p.LatestInsightsPermission = "latest-insights", p.NewsletterPermission = "newsletter", p.FeatureUpdatesPermission = "feature-updates", p.AboutTrustpilotPermission = "about-trustpilot", p.GeneralPermission = "general", p.ReviewMilestonesPermission = "review-milestones"
        },
        89140: function(e, n, t) {
            "use strict";
            t.d(n, {
                cn: function() {
                    return a
                }
            });
            var r = t(93967),
                i = t.n(r);
            let a = function() {
                for (var e = arguments.length, n = Array(e), t = 0; t < e; t++) n[t] = arguments[t];
                return i()(...n.filter(Boolean))
            }
        },
        30592: function(e) {
            e.exports = {
                content: "styles_content__UrvMY"
            }
        },
        559: function(e) {
            e.exports = {
                consumerInfoWrapper: "styles_consumerInfoWrapper__MOCv1",
                consumerDetailsWrapper: "styles_consumerDetailsWrapper__2XThH",
                consumerDetails: "styles_consumerDetails__DW9Hp",
                consumerExtraDetails: "styles_consumerExtraDetails__NFM0b",
                detailsIcon: "styles_detailsIcon__ch_FY"
            }
        },
        32173: function(e) {
            e.exports = {
                actionButtons: "buttons_actionButtons__SZCAW",
                button: "buttons_button__ECb04"
            }
        },
        76772: function(e) {
            e.exports = {
                userProfileLink: "styles_userProfileLink__KAZan",
                userProfileLinksWrapper: "styles_userProfileLinksWrapper__1PK76",
                showMoreButton: "styles_showMoreButton__okWZ3",
                iconWrapper: "styles_iconWrapper__WUco_",
                usefulLabel: "styles_usefulLabel__VcnL3"
            }
        },
        73771: function(e) {
            e.exports = {
                wrapper: "styles_wrapper___luvQ"
            }
        },
        1649: function(e) {
            e.exports = {
                reviewLabel: "styles_reviewLabel__I43un",
                detailsIcon: "styles_detailsIcon__xmMRm",
                reviewLabelButton: "styles_reviewLabelButton__Drv0Q"
            }
        },
        57122: function(e) {
            e.exports = {
                reviewContentwrapper: "styles_reviewContentwrapper__W9Vqf",
                reviewHeader: "styles_reviewHeader__xV2js",
                datesWrapper: "styles_datesWrapper__2T9ri",
                reviewLabels: "styles_reviewLabels____3__",
                reviewContent: "styles_reviewContent__44s_M",
                hidden: "styles_hidden__GHZ5T"
            }
        },
        7250: function(e) {
            e.exports = {
                alert: "styles_alert__vLH8u",
                reviewCard: "styles_reviewCard__6j0RQ",
                reviewCardInner: "styles_reviewCardInner__UZk1x",
                cardDivider: "styles_cardDivider__2qERY",
                actionsWrapper: "styles_actionsWrapper__jpzvy",
                actionsRightSide: "styles_actionsRightSide__XC7LC"
            }
        },
        86855: function(e) {
            e.exports = {
                previewText: "styles_previewText__afbaG",
                truncatedText: "styles_truncatedText__SYw6V",
                readMore: "styles_readMore__Bevrq"
            }
        }
    }
]);
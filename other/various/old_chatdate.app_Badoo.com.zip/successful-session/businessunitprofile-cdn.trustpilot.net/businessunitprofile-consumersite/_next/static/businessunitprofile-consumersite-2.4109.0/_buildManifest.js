self.__BUILD_MANIFEST = function(s, e, c, t, a, i, n, r, u, b, d, o, f, h, p, k, j, l, g, v, w, m, U, _, I, y, B, x, F) {
    return {
        __rewrites: {
            afterFiles: [{
                has: s,
                source: "/robots.txt",
                destination: "/api/robots"
            }, {
                has: s,
                source: "/sitemaps/recent.xml",
                destination: "/api/sitemaps/recent"
            }, {
                has: s,
                source: "/location",
                destination: "/api/location"
            }, {
                has: s,
                source: "/manifest.json",
                destination: "/api/manifest"
            }, {
                has: s,
                source: "/sessions/init",
                destination: "/api/sessions/init"
            }, {
                has: s,
                source: "/social/urlshortener",
                destination: "/api/businessunitprofile/social/urlshortener"
            }, {
                has: s,
                source: g,
                destination: g
            }, {
                has: s,
                source: v,
                destination: v
            }, {
                has: s,
                source: w,
                destination: w
            }],
            beforeFiles: [],
            fallback: []
        },
        "/_error": ["static/chunks/pages/_error-73a0825159890706.js"],
        "/about": [e, "static/css/ec117d0d2ea13204.css", "static/chunks/pages/about-2ea46bb23adfbbb3.js"],
        "/accept-terms": ["static/css/4cd51901a0542f9c.css", "static/chunks/pages/accept-terms-7e24c749e1f41403.js"],
        "/contact": ["static/css/13b525e68dc5e162.css", "static/chunks/pages/contact-24bd17adb1c4ddbb.js"],
        "/do-not-sell-my-info": ["static/css/61ec2349923b9e86.css", "static/chunks/pages/do-not-sell-my-info-a9e059b467e09c10.js"],
        "/emailsuppressions/invitations": ["static/css/ac7d2e32b79e766a.css", "static/chunks/pages/emailsuppressions/invitations-329b18ef5c2e889b.js"],
        "/end-of-the-line": ["static/chunks/pages/end-of-the-line-12683a9318e089c6.js"],
        "/error/404": ["static/chunks/pages/error/404-dd922b2c4a9e6025.js"],
        "/error/500": ["static/chunks/pages/error/500-d9bf9d41f1dbbeec.js"],
        "/error/upgradebrowser": ["static/css/3d1701904ed78226.css", "static/chunks/pages/error/upgradebrowser-5ee7bd841cc602a3.js"],
        "/facebook/data-deletion-status": ["static/css/c868992573ff763c.css", "static/chunks/pages/facebook/data-deletion-status-fc5e8e108da8e7ec.js"],
        "/impressum": ["static/css/fe0d92d0c7f27794.css", "static/chunks/pages/impressum-eab3d06c7761ca83.js"],
        "/review/[businessUnit]": [c, t, e, a, i, n, u, d, o, m, h, p, "static/chunks/3535-b22505e3769b428c.js", r, b, f, k, U, _, "static/css/0c7dcfe792f48abe.css", "static/chunks/pages/review/[businessUnit]-88d5c632ce8a6ccb.js"],
        "/review/[businessUnit]/location": [c, t, "static/chunks/1198-1eb43676d2578fd3.js", "static/css/53637834e4bfa1aa.css", "static/chunks/pages/review/[businessUnit]/location-645bd2ff2bd4d7a5.js"],
        "/review/[businessUnit]/location/[location]": [c, t, e, a, i, n, u, d, o, m, h, p, I, r, b, f, k, U, _, "static/css/f6a5551121ed8670.css", "static/chunks/pages/review/[businessUnit]/location/[location]-c3287a7b7dc910e5.js"],
        "/review/[businessUnit]/product": [e, a, d, "static/css/6996abcc92a539d7.css", "static/chunks/pages/review/[businessUnit]/product-1ff87d65ecfba8eb.js"],
        "/review/[businessUnit]/product/[productIdentifier]": [c, t, e, a, n, u, d, h, p, y, r, b, k, B, "static/css/f409902dc3369270.css", "static/chunks/pages/review/[businessUnit]/product/[productIdentifier]-0caeb91ceb57edac.js"],
        "/review/[businessUnit]/transparency": [c, t, a, I, "static/chunks/1085-b1c8e78d592c7198.js", "static/css/35eacd42bd9ca6fa.css", "static/chunks/pages/review/[businessUnit]/transparency-dcca2e402d096a2f.js"],
        "/reviews/[review]": [c, t, e, a, i, n, u, o, r, b, f, j, l, "static/css/658a056f71e8140a.css", "static/chunks/pages/reviews/[review]-425a903a520c6266.js"],
        "/submitted/review": [c, t, e, a, i, n, u, o, x, "static/chunks/7148-1fed67aafed979d3.js", r, b, f, j, l, "static/css/57228251020d9652.css", "static/chunks/pages/submitted/review-f676a8d98885fdb3.js"],
        "/unsubscribe/invitation": ["static/css/6f9e24ca979dc835.css", "static/chunks/pages/unsubscribe/invitation-9ddd0d5ebf551dac.js"],
        "/unsubscribe/marketing": ["static/css/96042a830e12f0bc.css", "static/chunks/pages/unsubscribe/marketing-077ed8e281d3f300.js"],
        "/users/connect": [i, "static/css/70005caf3f372d2e.css", "static/chunks/pages/users/connect-15609d82843fec58.js"],
        "/users/data": ["static/css/7e149e60953ef169.css", "static/chunks/pages/users/data-8325f068bc1c832c.js"],
        "/users/magic-link": ["static/css/a6c3b06c9b503353.css", "static/chunks/pages/users/magic-link-b32dd2f1e4c41d88.js"],
        "/users/settings": [c, t, e, a, i, n, F, x, r, "static/css/f4be1547610fa4c9.css", "static/chunks/pages/users/settings-81bc97193c679f1b.js"],
        "/users/[...id]": [c, t, e, a, i, n, u, d, o, F, y, r, b, f, j, l, B, "static/css/d0598c78c93f9db7.css", "static/chunks/pages/users/[...id]-09c555c52db3af39.js"],
        sortedPages: ["/_app", "/_error", "/about", "/accept-terms", "/contact", "/do-not-sell-my-info", "/emailsuppressions/invitations", "/end-of-the-line", "/error/404", "/error/500", "/error/upgradebrowser", "/facebook/data-deletion-status", "/impressum", "/review/[businessUnit]", "/review/[businessUnit]/location", "/review/[businessUnit]/location/[location]", "/review/[businessUnit]/product", "/review/[businessUnit]/product/[productIdentifier]", "/review/[businessUnit]/transparency", "/reviews/[review]", "/submitted/review", "/unsubscribe/invitation", "/unsubscribe/marketing", "/users/connect", "/users/data", "/users/magic-link", "/users/settings", "/users/[...id]"]
    }
}(void 0, "static/chunks/5675-17c437759eb9d2e1.js", "static/css/b52c077b888287ce.css", "static/chunks/5538-c0b3885d6d529056.js", "static/chunks/1664-07edf6198a5cd9ed.js", "static/chunks/1852-2212bddee6374db0.js", "static/chunks/146-1595e6223aff13ed.js", "static/chunks/9419-e66367db19e4b66a.js", "static/chunks/5370-e95573c567f9e180.js", "static/chunks/9496-e72a6e7a758c2c5e.js", "static/chunks/5529-0856d796f682bde7.js", "static/chunks/684-7437874513870434.js", "static/chunks/621-b435b77710abfcb3.js", "static/css/bcef4e4689cfc683.css", "static/chunks/5704-7543508816553eb0.js", "static/chunks/4494-6effa3f78f3aab17.js", "static/css/f977c761e4aca8e9.css", "static/chunks/8989-d61d3fa331f9e663.js", "/ads.txt", "/.well-known/security.txt", "/BingSiteAuth.xml", "static/chunks/9734-1c69d62e6fc2b10d.js", "static/css/5a61a2886b37a54f.css", "static/chunks/8172-4e24c7e7e68eb2ab.js", "static/chunks/7966-900f0966f44fc3dd.js", "static/chunks/8829-754d435fba22c639.js", "static/chunks/2909-591c714a4806b468.js", "static/chunks/3594-0e33dae653325cdc.js", "static/chunks/4027-85860eb7119b9a94.js"), self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();
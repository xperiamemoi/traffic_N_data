! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "c4ace131-573b-4898-8a3e-42545ecf9163", e._sentryDebugIdIdentifier = "sentry-dbid-c4ace131-573b-4898-8a3e-42545ecf9163")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4494], {
        39786: function(e, n, t) {
            "use strict";
            t.d(n, {
                s: function() {
                    return i
                }
            });
            var r = t(750);
            let i = e => {
                let {
                    rating: n,
                    count: t
                } = e;
                return t && n ? {
                    "@type": "AggregateRating",
                    bestRating: "5",
                    worstRating: "1",
                    ratingValue: (0, r.U)(n),
                    reviewCount: (0, r.U)(t)
                } : null
            }
        },
        38221: function(e, n, t) {
            "use strict";
            t.d(n, {
                O: function() {
                    return i
                }
            });
            var r = t(46819);
            let i = (e, n) => {
                let {
                    displayName: t,
                    id: i
                } = e;
                if (!t || !i) return null;
                let a = (0, r.gn)("".concat(n, "users/").concat(i));
                return {
                    "@type": "Person",
                    name: t,
                    url: i ? a : null
                }
            }
        },
        70483: function(e, n, t) {
            "use strict";
            t.d(n, {
                X: function() {
                    return a
                }
            });
            var r = t(46819),
                i = t(64709);
            let a = e => {
                let {
                    id: n,
                    imageUrl: t,
                    width: a,
                    height: s
                } = e, o = !!(0, i.Z)(t);
                return n && o && t ? {
                    "@type": "ImageObject",
                    "@id": "https://www.trustpilot.com/#/schema/ImageObject/".concat(n),
                    url: (0, r.gn)(t, {
                        trailingSlash: !1
                    }),
                    contentUrl: (0, r.gn)(t, {
                        trailingSlash: !1
                    }),
                    width: a ? {
                        "@type": "QuantitativeValue",
                        value: a,
                        unitCode: "E37",
                        unitText: "pixel"
                    } : null,
                    height: s ? {
                        "@type": "QuantitativeValue",
                        value: s,
                        unitCode: "E37",
                        unitText: "pixel"
                    } : null
                } : null
            }
        },
        52450: function(e, n, t) {
            "use strict";
            t.d(n, {
                R: function() {
                    return i
                }
            });
            var r = t(750);
            let i = e => "number" != typeof e ? null : {
                "@type": "Rating",
                bestRating: "5",
                worstRating: "1",
                ratingValue: (0, r.U)(e)
            }
        },
        94542: function(e, n, t) {
            "use strict";
            t.d(n, {
                Mp: function() {
                    return c
                },
                Sy: function() {
                    return l
                },
                sz: function() {
                    return u
                }
            });
            var r = t(11752),
                i = t.n(r),
                a = t(60849),
                s = t(46819);
            let {
                publicRuntimeConfig: o
            } = i()(), l = (e, n) => ({
                name: n,
                item: {
                    "@id": e
                }
            }), u = (e, n) => {
                let t = (0, a.u)(e).map(e => {
                    let {
                        children: t,
                        href: r
                    } = e, i = "development" === o.environment ? r : "".concat(n).concat(r.startsWith("/") ? r.slice(1) : r);
                    return {
                        name: t,
                        item: i,
                        sameAs: i
                    }
                });
                return [{
                    name: "Home",
                    item: n,
                    sameAs: n
                }, ...t]
            }, c = (e, n, t) => ({
                name: (0, s.Aj)(e, n),
                item: t,
                sameAs: t
            })
        },
        46819: function(e, n, t) {
            "use strict";
            t.d(n, {
                Aj: function() {
                    return l
                },
                Ct: function() {
                    return u
                },
                _x: function() {
                    return g
                },
                gT: function() {
                    return c
                },
                gn: function() {
                    return i.gn
                },
                nt: function() {
                    return d
                },
                z4: function() {
                    return p
                }
            });
            var r = t(77503),
                i = t(82610),
                a = t(66522),
                s = t(16133),
                o = t(85124);
            let l = (e, n) => "".concat(e.displayName, " ").concat(n["shared/words/reviews"]),
                u = (e, n, t, r) => {
                    let i = l(e, n),
                        {
                            description: a
                        } = r ? (0, s.WG)(n, t, e, { ...null == r ? void 0 : r.pagination,
                            totalNumberOfFilteredReviews: r.totalNumberOfFilteredReviews
                        }) : {};
                    return {
                        name: i,
                        description: a
                    }
                },
                c = (e, n, t) => {
                    let {
                        withLocalBusiness: r = !1,
                        withImage: i = !1,
                        withDataset: a = !1,
                        isProduct: s = !1
                    } = t;
                    r && (e.about = {
                        "@id": s ? "https://www.trustpilot.com/#/schema/Product/".concat(n) : "https://www.trustpilot.com/#/schema/Organization/".concat(n)
                    }, e.mainEntity = {
                        "@id": s ? "https://www.trustpilot.com/#/schema/Product/".concat(n) : "https://www.trustpilot.com/#/schema/Organization/".concat(n)
                    }), i && (e.primaryImageOfPage = {
                        "@id": "https://www.trustpilot.com/#/schema/ImageObject/".concat(n)
                    }), a && (e.hasPart = {
                        "@id": "https://www.trustpilot.com/#/schema/DataSet/".concat(n, "/1")
                    })
                },
                p = e => {
                    var n;
                    return null !== (n = null == e ? void 0 : e.filter(e => !e.hasUnhandledReports && !e.filtered)) && void 0 !== n ? n : []
                },
                d = e => {
                    var n;
                    return null !== (n = null == e ? void 0 : e.filter(e => !(0, a.c)(e.report))) && void 0 !== n ? n : []
                },
                g = e => "string" == typeof e ? (0, o.bL)(r.load(e, {}, !1).text()) : ""
        },
        64709: function(e, n, t) {
            "use strict";
            t.d(n, {
                Z: function() {
                    return i
                }
            });
            var r = t(19912);
            let i = function(e) {
                let n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                return e && !(0, r.Wn)(e) ? n ? (0, r.RF)(e) : e : null
            }
        },
        61085: function(e, n, t) {
            "use strict";
            t.d(n, {
                S: function() {
                    return a
                }
            });
            var r = t(66887),
                i = t(46819);
            let a = function(e) {
                let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, i.gn)(r.Pu.getLocale(e, n.translationLocale, n.trustpilotHost).consumerWebApp, {
                    trailingSlash: n.trailingSlash
                })
            }
        },
        13477: function(e, n, t) {
            "use strict";
            t.d(n, {
                b: function() {
                    return a
                }
            });
            var r = t(67294),
                i = t(71981);
            let a = () => {
                if (!i.Il) throw Error("useAppContext must be used within an AppContextProvider");
                return r.useContext(i.Il)
            }
        },
        60849: function(e, n, t) {
            "use strict";
            t.d(n, {
                u: function() {
                    return i
                }
            });
            var r = t(19912);
            let i = function(e) {
                let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                return e ? [{
                    id: e.topLevelId,
                    displayName: e.topLevelDisplayName
                }, {
                    id: e.midLevelId,
                    displayName: e.midLevelDisplayName
                }, {
                    id: e.bottomLevelId,
                    displayName: e.bottomLevelDisplayName
                }].filter(e => {
                    let {
                        id: n,
                        displayName: t
                    } = e;
                    return !!n && !!t
                }).map((e, t, i) => {
                    let {
                        id: a,
                        displayName: s
                    } = e;
                    return {
                        href: (0, r.QG)(a),
                        children: s,
                        trackingProps: {
                            name: "breadcrumbs-cpp",
                            target: "Category page",
                            position: i.length - t + n
                        }
                    }
                }) : []
            }
        },
        45978: function(e, n, t) {
            "use strict";
            t.d(n, {
                k: function() {
                    return d
                }
            });
            var r = t(85893),
                i = t(67294),
                a = t(41664),
                s = t.n(a),
                o = t(11163),
                l = t(71981),
                u = t(35529),
                c = t(44347),
                p = t(32377);
            let d = e => {
                let {
                    currentPage: n,
                    totalPages: t,
                    target: a,
                    className: d,
                    scroll: g,
                    range: f,
                    onClick: m
                } = e, b = (0, o.useRouter)(), v = (0, p.Ew)(b.asPath, {
                    excludeQueryString: !0
                }), y = (0, p.iH)(v), {
                    track: w,
                    locale: h
                } = i.useContext(l.Il), k = e => {
                    w("Link Clicked", {
                        name: "navigation",
                        target: a,
                        navigationType: e.rel ? "next" === e.rel ? "next" : "previous" : "number"
                    }), null == m || m()
                };
                return (0, r.jsx)("div", {
                    className: d,
                    children: (0, r.jsx)(u.tl, {
                        url: y,
                        last: t,
                        locale: h,
                        current: n,
                        range: f,
                        lastLinkDisabled: !0,
                        relNoFollowAfter: 10,
                        renderLinks: e => {
                            var n;
                            return (0, r.jsx)(s(), {
                                passHref: !0,
                                href: null !== (n = e.href) && void 0 !== n ? n : "",
                                scroll: g,
                                legacyBehavior: !0,
                                prefetch: !1,
                                children: (0, r.jsx)(c.Z, { ...e,
                                    onClick: () => k(e)
                                })
                            })
                        }
                    })
                })
            }
        },
        52705: function(e, n, t) {
            "use strict";
            t.d(n, {
                q: function() {
                    return m
                }
            });
            var r = t(85893),
                i = t(67294),
                a = t(94343),
                s = t(81686),
                o = t(60928),
                l = t(60131),
                u = t(41447),
                c = t(65487),
                p = t(19912),
                d = t(9975),
                g = t.n(d);
            let f = e => {
                    let {
                        name: n,
                        id: t,
                        title: i,
                        isSelected: a,
                        isDisabled: s,
                        percentage: o,
                        onToggle: d,
                        tooltip: f
                    } = e, m = 1 > o.actual && o.actual > 0, b = "star-filter-".concat(n, "-").concat(t);
                    return (0, r.jsxs)("label", {
                        className: (0, p.AK)(g().row, s && g().disabledRow),
                        title: f,
                        htmlFor: b,
                        "data-selected": a,
                        "data-star-rating": t,
                        children: [(0, r.jsx)("div", {
                            className: (0, p.AK)(g().cell, g().checkboxCell),
                            children: (0, r.jsx)(u.X, {
                                checked: a,
                                id: b,
                                disabled: s,
                                onChange: () => d(t)
                            })
                        }), (0, r.jsx)(c.ZT, {
                            variant: "body-m",
                            className: (0, p.AK)(g().cell, g().labelCell),
                            name: "rating-label",
                            children: i
                        }), (0, r.jsx)("div", {
                            className: (0, p.AK)(g().cell, g().barCell),
                            children: (0, r.jsx)("div", {
                                className: g().bar,
                                children: (0, r.jsx)("span", {
                                    className: g().barValue,
                                    style: {
                                        width: "".concat(o.rounded, "%"),
                                        minWidth: o.actual ? "12px" : "auto"
                                    }
                                })
                            })
                        }), (0, r.jsx)(c.ZT, {
                            variant: "body-m",
                            className: (0, p.AK)(g().cell, g().percentageCell),
                            name: "rating-distribution-row-percentage",
                            children: m ? (0, r.jsxs)("span", {
                                children: ["<", (0, r.jsx)(l.n$, {
                                    number: .01,
                                    percentage: !0
                                })]
                            }) : (0, r.jsx)(l.n$, {
                                number: o.rounded / 100,
                                percentage: !0
                            })
                        })]
                    })
                },
                m = e => {
                    let {
                        name: n,
                        numberOfReviews: t,
                        selectedStars: l,
                        onChange: u
                    } = e, [c, p] = (0, a.T)(), [d, m] = i.useState(function(e) {
                        var n;
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
                            r = arguments.length > 2 ? arguments[2] : void 0,
                            i = arguments.length > 3 ? arguments[3] : void 0,
                            {
                                one: a,
                                two: l,
                                three: u,
                                four: c,
                                five: p,
                                total: d
                            } = e,
                            g = (0, o.r)([a, l, u, c, p], d),
                            f = null === (n = r[(0, s.$)("shared/sentences/reviews-ratio", d)]) || void 0 === n ? void 0 : n.replace("[COUNT]", d.toLocaleString(i)),
                            m = e => null == f ? void 0 : f.replace("[SUB-COUNT]", e.toLocaleString(i));
                        return [{
                            id: "five",
                            number: "5",
                            title: r["shared/rating/v2/star-5"],
                            tooltip: m(p),
                            isSelected: t.includes("5"),
                            isDisabled: 0 === e.five,
                            percentage: g[4]
                        }, {
                            id: "four",
                            number: "4",
                            title: r["shared/rating/v2/star-4"],
                            tooltip: m(c),
                            isSelected: t.includes("4"),
                            isDisabled: 0 === e.four,
                            percentage: g[3]
                        }, {
                            id: "three",
                            number: "3",
                            title: r["shared/rating/v2/star-3"],
                            tooltip: m(u),
                            isSelected: t.includes("3"),
                            isDisabled: 0 === e.three,
                            percentage: g[2]
                        }, {
                            id: "two",
                            number: "2",
                            title: r["shared/rating/v2/star-2"],
                            tooltip: m(l),
                            isSelected: t.includes("2"),
                            isDisabled: 0 === e.two,
                            percentage: g[1]
                        }, {
                            id: "one",
                            number: "1",
                            title: r["shared/rating/v2/star-1"],
                            tooltip: m(a),
                            isSelected: t.includes("1"),
                            isDisabled: 0 === e.one,
                            percentage: g[0]
                        }]
                    }(t, l, c, p)), b = d.some(e => e.isSelected), v = e => {
                        let n = d.map(n => n.id === e && t[e] > 0 ? { ...n,
                            isSelected: !n.isSelected
                        } : n);
                        m(n), u(n.filter(e => e.isSelected).map(e => e.number))
                    };
                    return (0, r.jsx)("div", {
                        className: g().container,
                        "data-some-selected": b,
                        children: d.map(e => (0, i.createElement)(f, { ...e,
                            onToggle: v,
                            key: e.id,
                            name: n
                        }))
                    })
                }
        },
        77121: function(e, n, t) {
            "use strict";
            t.d(n, {
                i: function() {
                    return g
                }
            });
            var r = t(85893),
                i = t(93967),
                a = t.n(i);
            t(67294);
            var s = t(60131),
                o = t(66667),
                l = t(65487),
                u = t(46356),
                c = t(80618),
                p = t(30719),
                d = t.n(p);
            let g = e => {
                let {
                    rating: n,
                    variant: t,
                    className: i,
                    size: p = "small",
                    onClick: g
                } = e, f = "product" === t ? (0, c.f)(n) : (0, c.O)(n);
                return (0, r.jsxs)("div", {
                    role: "link",
                    tabIndex: 0,
                    className: a()(d().rating, g && d().clickable, i),
                    ...(0, u.c)(() => null == g ? void 0 : g()),
                    "data-rating-component": !0,
                    children: [(0, r.jsx)(o.Z, {
                        rating: f,
                        size: p,
                        variant: t
                    }), (0, r.jsx)(l.ZT, {
                        variant: "small" === p ? "body-m" : "body-l",
                        appearance: "subtle",
                        name: "rating",
                        children: (0, r.jsx)(s.n$, {
                            minDecimals: 1,
                            number: n
                        })
                    })]
                })
            }
        },
        37749: function(e, n, t) {
            "use strict";
            t.d(n, {
                p: function() {
                    return c
                }
            });
            var r = t(85893),
                i = t(67294),
                a = t(84676),
                s = t(4359),
                o = t(88826),
                l = t.n(o),
                u = t(13477);
            let c = e => {
                let {
                    className: n,
                    tooltipText: t,
                    placement: o,
                    trackingProps: c,
                    icon: p,
                    trigger: d
                } = e, g = (0, u.b)(), [f, m] = i.useState(!1), b = () => {
                    f || (g.track("Element Viewed", c), m(!0))
                };
                return (0, r.jsx)("span", {
                    className: n,
                    onMouseOver: () => c && b(),
                    onFocus: () => c && b(),
                    children: (0, r.jsx)(a.u, {
                        tooltipText: t,
                        placement: o,
                        trigger: d,
                        children: null != p ? p : (0, r.jsx)("span", {
                            role: "button",
                            tabIndex: 0,
                            "aria-label": "Tooltip",
                            children: (0, r.jsx)(s.J, {
                                content: l(),
                                color: "#6C6C85"
                            })
                        })
                    })
                })
            }
        },
        31691: function(e, n, t) {
            "use strict";
            t.d(n, {
                e: function() {
                    return a
                }
            });
            var r = t(79008),
                i = t(16789);
            let a = e => {
                let n = (0, r.Tm)(),
                    {
                        consumerAlert: t
                    } = null != e ? e : n,
                    a = (0, i.Wb)(null == t ? void 0 : t.predefinedType);
                return {
                    consumerAlert: t,
                    hasWarningAlert: a
                }
            }
        },
        46356: function(e, n, t) {
            "use strict";
            t.d(n, {
                c: function() {
                    return r
                }
            });
            let r = function(e) {
                let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ["Enter"];
                return {
                    onClick: n => e(n),
                    onKeyDown: t => {
                        n.includes(t.key) && (t.preventDefault(), e(t))
                    }
                }
            }
        },
        80618: function(e, n, t) {
            "use strict";
            t.d(n, {
                O: function() {
                    return r
                },
                f: function() {
                    return i
                }
            });
            let r = e => {
                    if (e > 4.7) return 5;
                    if (e > 4.2) return 4.5;
                    if (e > 3.7) return 4;
                    if (e > 3.2) return 3.5;
                    if (e > 2.7) return 3;
                    if (e > 2.2) return 2.5;
                    if (e > 1.7) return 2;
                    else if (e > 1.2) return 1.5;
                    else if (e > 0) return 1;
                    else return 0
                },
                i = e => e > 4.4 ? 5 : e > 3.4 ? 4 : e > 2.4 ? 3 : e > 1.4 ? 2 : e > 0 ? 1 : 0
        },
        16789: function(e, n, t) {
            "use strict";
            t.d(n, {
                M6: function() {
                    return u
                },
                Wb: function() {
                    return s
                },
                jt: function() {
                    return l
                },
                rF: function() {
                    return o
                }
            });
            var r = t(52007);
            let i = (e, n, t) => {
                    var r, i, a, s, o, l, u, c;
                    let {
                        predefinedType: p,
                        content: d,
                        languageVersions: g
                    } = t;
                    switch (p) {
                        case "InfoIpr":
                            return {
                                type: "business-profile-page/consumer-alert/info/ipr/type",
                                description: "business-profile-page/consumer-alert/info/ipr/description",
                                body: n["business-profile-page/consumer-alert/info/ipr/body"]
                            };
                        case "InfoRegulatoryNotification":
                            return {
                                type: "business-profile-page/consumer-alert/info/regulatory-notification/type",
                                description: "business-profile-page/consumer-alert/info/regulatory-notification/description",
                                body: n["business-profile-page/consumer-alert/info/regulatory-notification/body-v2"]
                            };
                        case "InfoDutchNationalPolice":
                            return {
                                type: "business-profile-page/consumer-alert/info/dutch-national-police/type",
                                description: "business-profile-page/consumer-alert/info/dutch-national-police/description",
                                body: n["business-profile-page/consumer-alert/info/dutch-national-police/body"]
                            };
                        case "InfoMediaStorm":
                            return {
                                type: "business-profile-page/consumer-alert/info/media-storm/type",
                                description: "business-profile-page/consumer-alert/info/media-storm/description-v2",
                                body: n["business-profile-page/consumer-alert/info/media-storm/body-v3"]
                            };
                        case "InfoPreInvestigation":
                            return {
                                description: "business-profile-page/consumer-alert/info/pre-investigation/description",
                                type: "business-profile-page/consumer-alert/info/pre-investigation/type",
                                body: n["business-profile-page/consumer-alert/info/pre-investigation/body"]
                            };
                        case "InfoHighRiskInvestment":
                            return {
                                type: "business-profile-page/consumer-alert/info/high-risk-investment/type",
                                description: "business-profile-page/consumer-alert/info/high-risk-investment/description",
                                body: n["business-profile-page/consumer-alert/info/high-risk-investment/body-v2"]
                            };
                        case "InfoRegulatoryActionFraud":
                            return {
                                type: "business-profile-page/consumer-alert/info/regulatory-action-fraud/type",
                                description: "business-profile-page/consumer-alert/info/regulatory-action-fraud/description",
                                body: n["business-profile-page/consumer-alert/info/regulatory-action-fraud/body-v2"]
                            };
                        case "WarningCherrypicking":
                            return {
                                type: "business-profile-page/consumer-alert/warning/cherrypicking/type",
                                description: "business-profile-page/consumer-alert/warning/cherrypicking/description",
                                body: n["business-profile-page/consumer-alert/warning/cherrypicking/body-v2"]
                            };
                        case "WarningFabricatedReviews":
                            return {
                                type: "business-profile-page/consumer-alert/warning/fabricated-reviews/type",
                                description: "business-profile-page/consumer-alert/warning/fabricated-reviews/description",
                                body: n["business-profile-page/consumer-alert/warning/fabricated-reviews/body-v2"]
                            };
                        case "WarningIncentivesForReviews":
                            return {
                                type: "business-profile-page/consumer-alert/warning/incentives-for-reviews/type",
                                description: "business-profile-page/consumer-alert/warning/incentives-for-reviews/description",
                                body: n["business-profile-page/consumer-alert/warning/incentives-for-reviews/body-v2"]
                            };
                        case "WarningMisuseOfReporting":
                            return {
                                type: "business-profile-page/consumer-alert/warning/misuse-of-reporting/type",
                                description: "business-profile-page/consumer-alert/warning/misuse-of-reporting/description",
                                body: n["business-profile-page/consumer-alert/warning/misuse-of-reporting/body-v2"]
                            };
                        case "WarningBiasedInvitation":
                            return {
                                type: "business-profile-page/consumer-alert/warning/biased-invitation/type",
                                description: "business-profile-page/consumer-alert/warning/biased-invitation/description",
                                body: n["business-profile-page/consumer-alert/warning/biased-invitation/body-v2"]
                            };
                        case "WarningThreats":
                            return {
                                type: "business-profile-page/consumer-alert/warning/threats/type",
                                description: "business-profile-page/consumer-alert/warning/threats/description",
                                body: n["business-profile-page/consumer-alert/warning/threats/body-v2"]
                            };
                        case "WarningMisuseOfPublicReply":
                            return {
                                type: "business-profile-page/consumer-alert/warning/misuse-of-reply/type",
                                description: "business-profile-page/consumer-alert/warning/misuse-of-reply/description",
                                body: n["business-profile-page/consumer-alert/warning/misuse-of-reply/body-v2"]
                            };
                        case "WarningConflictOfInterest":
                            return {
                                type: "business-profile-page/consumer-alert/warning/conflict-of-interest/type",
                                description: "business-profile-page/consumer-alert/warning/conflict-of-interest/description",
                                body: n["business-profile-page/consumer-alert/warning/conflict-of-interest/body-v2"]
                            };
                        case "WarningPurchasedReviews":
                            return {
                                type: "business-profile-page/consumer-alert/warning/purchased-reviews/type",
                                description: "business-profile-page/consumer-alert/warning/purchased-reviews/description",
                                body: n["business-profile-page/consumer-alert/warning/purchased-reviews/body-v2"]
                            };
                        case "WarningIncorrectDisplayOfTrustpilotContent":
                            return {
                                type: "business-profile-page/consumer-alert/warning/incorrect-display-of-tp-content/type",
                                description: "business-profile-page/consumer-alert/warning/incorrect-display-of-tp-content/description",
                                body: n["business-profile-page/consumer-alert/warning/incorrect-display-of-tp-content/body"]
                            };
                        case "WarningScammerBusiness":
                            return {
                                type: "business-profile-page/consumer-alert/warning/scammer-business/type",
                                description: "business-profile-page/consumer-alert/warning/scammer-business/description",
                                body: n["business-profile-page/consumer-alert/warning/scammer-business/body-v2"]
                            };
                        case "WarningLegalThreatsTowardReviewer":
                            return {
                                type: "business-profile-page/consumer-alert/warning/legal-threats-toward-reviewer/type",
                                description: "business-profile-page/consumer-alert/warning/legal-threats-toward-reviewer/description",
                                body: n["business-profile-page/consumer-alert/warning/legal-threats-toward-reviewer/body-v2"]
                            };
                        case "InfoCustom":
                            return {
                                body: null !== (i = null !== (r = g && g[e]) && void 0 !== r ? r : d) && void 0 !== i ? i : n["business-profile-page/alerts/default"],
                                description: null !== (s = null !== (a = g && g[e]) && void 0 !== a ? a : d) && void 0 !== s ? s : n["business-profile-page/alerts/default"],
                                type: "business-profile-page/alerts/modal/title"
                            };
                        default:
                            return {
                                description: null !== (l = null !== (o = g && g[e]) && void 0 !== o ? o : d) && void 0 !== l ? l : n["business-profile-page/alerts/default"],
                                body: null !== (c = null !== (u = g && g[e]) && void 0 !== u ? u : d) && void 0 !== c ? c : n["business-profile-page/alerts/default"],
                                type: "business-profile-page/warnings/modal/title"
                            }
                    }
                },
                a = (e, n, t, i) => {
                    if (i) return {
                        linkBegin: '<a href="'.concat(i, '" target="_blank" rel="nofollow noopener">'),
                        linkEnd: "</a>",
                        trackingOptions: {
                            name: "consumer-alert-banner",
                            target: "Regulatory attention"
                        }
                    };
                    switch (n) {
                        case "InfoRegulatoryNotification":
                        case "InfoRegulatoryNotificationBadFit":
                            return {
                                linkBegin: "",
                                linkEnd: ""
                            };
                        case "InfoHighRiskInvestment":
                            return {
                                linkBegin: '<a href="'.concat((0, r.O)("https://help.trustpilot.com/s/article/What-you-should-know-about-high-risk-investments", t), '" target="_blank" rel="nofollow noopener">'),
                                linkEnd: "</a>",
                                trackingOptions: {
                                    name: "consumer-alert-banner",
                                    target: "Support 7550994547218"
                                }
                            };
                        case "InfoRegulatoryActionFraud":
                            return {
                                linkBegin: '<a href="https://www.actionfraud.police.uk/" target="_blank" rel="nofollow noopener">',
                                linkEnd: "</a>",
                                trackingOptions: {
                                    name: "consumer-alert-banner",
                                    target: "Police Action Fraud"
                                }
                            };
                        case "InfoDutchNationalPolice":
                            return {
                                linkBegin: '<a href="https://www.politie.nl/aangifte-of-melding-doen" target="_blank" rel="nofollow noopener">',
                                linkEnd: "</a>",
                                trackingOptions: {
                                    name: "consumer-alert-banner",
                                    target: "Dutch National Police"
                                }
                            };
                        case "WarningIncorrectDisplayOfTrustpilotContent":
                            return {
                                linkBegin: '<a href="https://legal.trustpilot.com/for-businesses/terms-of-use-and-sale-for-businesses" target="_blank" rel="nofollow noopener">',
                                linkEnd: "</a>",
                                trackingOptions: {
                                    name: "consumer-alert-banner",
                                    target: "Terms of Use Page"
                                }
                            };
                        case "WarningFabricatedReviews":
                            return {
                                linkBegin: '<a href="https://legal.trustpilot.com/for-everyone/action-we-take">',
                                linkEnd: "</a>",
                                trackingOptions: {
                                    name: "consumer-alert-banner",
                                    target: "Action We Take Page"
                                }
                            };
                        default:
                            return {
                                linkBegin: '<a href="/review/'.concat(e, '/transparency">'),
                                linkEnd: "</a>",
                                trackingOptions: {
                                    name: "consumer-alert-banner",
                                    target: "Activity Page"
                                }
                            }
                    }
                },
                s = e => {
                    var n;
                    return null !== (n = null == e ? void 0 : e.toLowerCase().startsWith("warning")) && void 0 !== n && n
                },
                o = (e, n, t, r, i) => {
                    let s = a(e, t, r, i);
                    return {
                        alertText: n.replace(/\[LINE-BREAK]/g, "<br><br>").replace("[LINK-BEGIN]", s.linkBegin).replace("[LINK-END]", s.linkEnd).replace("[LINK]", "https://legal.trustpilot.com/for-businesses/guidelines-for-businesses"),
                        trackingOptions: { ...s.trackingOptions
                        }
                    }
                },
                l = (e, n, t) => {
                    let r = e.find(e => e.predefinedType === "".concat(n, "Custom"));
                    return t && r ? [r] : e.filter(e => e.predefinedType.startsWith(n))
                },
                u = (e, n, t) => e.map(e => ({
                    alertContent: i(n, t, e),
                    alert: e
                }))
        },
        70649: function(e, n, t) {
            "use strict";
            t.d(n, {
                K: function() {
                    return r
                }
            });
            let r = e => e.stars.length > 0
        },
        31553: function(e, n, t) {
            "use strict";

            function r(e, n) {
                let t, r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {
                        trailing: !0
                    },
                    i = !1;
                return function() {
                    for (var a = arguments.length, s = Array(a), o = 0; o < a; o++) s[o] = arguments[o];
                    let l = this,
                        u = r.leading && !t;
                    i = !!t, clearTimeout(t), t = window.setTimeout(() => {
                        t = null, (!r.leading || r.leading && r.trailing && i) && e.apply(l, s)
                    }, n), u && e.apply(l, s)
                }
            }

            function i(e, n) {
                let t, r, i, a, s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                    o = 0,
                    l = () => {
                        o = !1 === s.leading ? 0 : Date.now(), t = null, a = e.apply(r, i), t || (r = i = null)
                    },
                    u = function() {
                        for (var u = arguments.length, c = Array(u), p = 0; p < u; p++) c[p] = arguments[p];
                        let d = Date.now();
                        o || !1 !== s.leading || (o = d);
                        let g = n - (d - o);
                        return r = this, i = c, g <= 0 || g > n ? (t && (clearTimeout(t), t = null), o = d, a = e.apply(r, i), t || (r = i = null)) : t || !1 === s.trailing || (t = window.setTimeout(l, g)), a
                    };
                return u.cancel = () => {
                    t && clearTimeout(t), o = 0, t = r = i = null
                }, u
            }
            t.d(n, {
                D: function() {
                    return r
                },
                P: function() {
                    return i
                }
            })
        },
        60928: function(e, n, t) {
            "use strict";
            t.d(n, {
                r: function() {
                    return s
                },
                t: function() {
                    return a
                }
            });
            let r = e => e.reduce((e, n) => e + n, 0),
                i = (e, n) => Math.pow(Math.abs(n - e), 2) / Math.sqrt(e < 1 ? 1 : e),
                a = e => {
                    if (Math.abs(r(e) - 100) > e.length) return e;
                    let n = e.map(e => Math.floor(e)),
                        t = 100 - n.reduce((e, n) => e + n),
                        a = [];
                    for (let t = 0; t < e.length; t++) a[t] = [i(e[t], n[t] + 1) - i(e[t], n[t]), t];
                    let s = [...a].sort((e, n) => e[0] > n[0] ? 1 : n[0] > e[0] ? -1 : 0);
                    for (let e = 0; e < t; e++) n[s[e][1]] += 1;
                    return n
                },
                s = (e, n) => {
                    let t = e.map(e => n > 0 ? e / n * 100 : 0),
                        r = a(t);
                    return t.map((e, n) => ({
                        actual: e,
                        rounded: r[n]
                    }))
                }
        },
        750: function(e, n, t) {
            "use strict";

            function r(e, n, t) {
                let r = new Intl.NumberFormat(n, t);
                return isNaN(e) ? "n/a" : r.format(e)
            }

            function i(e) {
                return isNaN(e) ? "" : new Intl.NumberFormat("en-US", {
                    useGrouping: !1
                }).format(e)
            }
            t.d(n, {
                U: function() {
                    return i
                },
                u: function() {
                    return r
                }
            })
        },
        16133: function(e, n, t) {
            "use strict";
            t.d(n, {
                WG: function() {
                    return c
                },
                X_: function() {
                    return u
                }
            });
            var r = t(70649);
            t(85124);
            var i = t(16789);
            t(18619);
            var a = t(750),
                s = t(83454);
            let o = [],
                l = e => (s.env.NOINDEX_DOMAIN || "tp-staging.com,test-staging.com").split(",").some(n => e.toLocaleLowerCase().endsWith(".".concat(n))),
                u = (e, n) => !(n && (0, r.K)(n) || e && o.includes(e.identifyingName.toLowerCase()) || e && l(e.identifyingName)),
                c = (e, n, t, r) => {
                    var s, o, l, u, c, p, d, g, f, m, b, v, y, w, h, k, N, _, I, C;
                    let x = ((null !== (g = t.numberOfReviews) && void 0 !== g ? g : 0) > 0 ? e["business-profile-page/title"] : e["business-profile-page/title/no-reviews"]).replaceAll("[COMPANY]", null !== (f = t.displayName) && void 0 !== f ? f : "").replaceAll("[DOMAIN]", null !== (m = t.identifyingName) && void 0 !== m ? m : ""),
                        O = (null !== (b = null === (s = t.stars) || void 0 === s ? void 0 : s.toLocaleString("en-US")) && void 0 !== b ? b : "0").charAt(0),
                        A = "business-profile-page/description/".concat(O, "-stars").concat(1 === t.numberOfReviews ? "/one.v2" : ".v2"),
                        R = (0, i.Wb)(null == t ? void 0 : null === (o = t.consumerAlert) || void 0 === o ? void 0 : o.predefinedType) ? null === (l = e["business-profile-page/description/has-alert-generic"]) || void 0 === l ? void 0 : l.replaceAll("[COMPANY]", null !== (v = t.displayName) && void 0 !== v ? v : "") : null === (d = e[A]) || void 0 === d ? void 0 : null === (p = d.replaceAll("[COMPANY]", null !== (y = t.displayName) && void 0 !== y ? y : "")) || void 0 === p ? void 0 : null === (c = p.replaceAll("[REVIEWSCOUNT]", (0, a.u)(null !== (w = t.numberOfReviews) && void 0 !== w ? w : 0, n))) || void 0 === c ? void 0 : null === (u = c.replaceAll("[REVIEWS COUNT]", (0, a.u)(null !== (h = t.numberOfReviews) && void 0 !== h ? h : 0, n))) || void 0 === u ? void 0 : u.replaceAll("[DOMAIN]", null !== (k = t.identifyingName) && void 0 !== k ? k : "");
                    if (r.currentPage > 1) {
                        let t = null === (_ = e["business-profile-page/description/meta/pagenumber"]) || void 0 === _ ? void 0 : null === (N = _.replaceAll("[PageNumber]", r.currentPage.toLocaleString("en-US"))) || void 0 === N ? void 0 : N.replaceAll("[PageNumberMax]", r.totalPages.toLocaleString("en-US")),
                            i = Math.min(r.currentPage * r.perPage, r.totalNumberOfFilteredReviews),
                            s = r.currentPage * r.perPage - r.perPage + 1,
                            o = null === (C = e["business-profile-page/description/meta/reviewnumber"]) || void 0 === C ? void 0 : null === (I = C.replaceAll("[ReviewCount]", "".concat((0, a.u)(s, n), "-").concat((0, a.u)(i, n)))) || void 0 === I ? void 0 : I.replaceAll("[ReviewCountMax]", (0, a.u)(r.totalNumberOfFilteredReviews, n));
                        return {
                            pageTitle: "".concat(x, " | ").concat(t),
                            description: "".concat(R, " | ").concat(o)
                        }
                    }
                    return {
                        pageTitle: x,
                        description: R
                    }
                }
        },
        9975: function(e) {
            e.exports = {
                container: "styles_container__7TW3E",
                row: "styles_row__4BwV6",
                barValue: "styles_barValue__X_IuW",
                disabledRow: "styles_disabledRow__zQ8BQ",
                labelCell: "styles_labelCell__gg5_Q",
                percentageCell: "styles_percentageCell__AKkqm",
                cell: "styles_cell__2f_al",
                checkboxCell: "styles_checkboxCell__N1jGJ",
                barCell: "styles_barCell__0iL4o",
                bar: "styles_bar__sCCoh"
            }
        },
        30719: function(e) {
            e.exports = {
                rating: "styles_rating__kLMDv",
                clickable: "styles_clickable__tOHMN"
            }
        }
    }
]);
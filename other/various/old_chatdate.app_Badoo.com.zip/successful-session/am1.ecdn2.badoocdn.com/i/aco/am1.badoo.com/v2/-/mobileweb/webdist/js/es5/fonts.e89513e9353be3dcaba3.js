var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "afefe239-c4dd-4eb5-918f-78643a22ace4", e._sentryDebugIdIdentifier = "sentry-dbid-afefe239-c4dd-4eb5-918f-78643a22ace4")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "afefe239-c4dd-4eb5-918f-78643a22ace4", e._sentryDebugIdIdentifier = "sentry-dbid-afefe239-c4dd-4eb5-918f-78643a22ace4")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [6699], {
            59906: function(e, t, n) {
                n.r(t);
                n(27495), n(90906);
                var a = n(20679),
                    f = n(99417),
                    o = a.A.getRequest("WebFont Loaded", 32),
                    d = f.A._partner_id,
                    s = f.A.localStorage,
                    i = /^\s*</,
                    c = function() {
                        if ("badoo" === d) return "/css/fonts/beausite-classic.5b846ac1ac3bbf8f1b0f.css";
                        return
                    }();
                if (function() {
                        if (!("FontFace" in f.A)) return !1;
                        var e = new f.A.FontFace("t", 'url( "data:application/font-woff2;base64,d09GMgABAAAAAADcAAoAAAAAAggAAACWAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAABk4ALAoUNAE2AiQDCAsGAAQgBSAHIBtvAcieB3aD8wURQ+TZazbRE9HvF5vde4KCYGhiCgq/NKPF0i6UIsZynbP+Xi9Ng+XLbNlmNz/xIBBqq61FIQRJhC/+QA/08PJQJ3sK5TZFMlWzC/iK5GUN40psgqvxwBjBOg6JUSJ7ewyKE2AAaXZrfUB4v+hze37ugJ9d+DeYqiDwVgCawviwVFGnuttkLqIMGivmDg" ) format( "woff2" )', {});
                        return e.load(), "loading" === e.status || "loaded" === e.status
                    }() && function() {
                        try {
                            return s.setItem("test", "test"), s.removeItem("test"), !0
                        } catch (e) {
                            return !1
                        }
                    }()) {
                    o.setStart(Date.now());
                    var r = function() {
                        var e = s.font_css_cache_file;
                        if (!e) return;
                        if (e !== c) return void A();
                        var t = s.font_css_cache;
                        if (n = t, i.test(n)) return void A();
                        var n;
                        return t
                    }();
                    r ? u(r) : function(e) {
                        if (!c) return;
                        var t = new f.A.XMLHttpRequest;
                        t.open("GET", "" + f.A._badoo_cdnUrl + c, !0), t.onreadystatechange = function() {
                            if (4 === t.readyState)
                                if (200 === t.status) {
                                    var n = t.responseText;
                                    ! function(e) {
                                        s.font_css_cache = e, s.font_css_cache_file = c
                                    }(n), e(n)
                                } else e()
                        }, t.send()
                    }((function(e) {
                        e && u(e)
                    }))
                }

                function A() {
                    s.removeItem("font_css_cache"), s.removeItem("font_css_cache_file")
                }

                function u(e) {
                    var t = f.A.document.createElement("style");
                    t.setAttribute("type", "text/css"), t.styleSheet ? t.styleSheet.cssText = e : t.innerHTML = e, f.A.document.getElementsByTagName("head")[0].appendChild(t), o.end()
                }
            }
        }
    ]);
//# sourceMappingURL=fonts.e89513e9353be3dcaba3.js.map
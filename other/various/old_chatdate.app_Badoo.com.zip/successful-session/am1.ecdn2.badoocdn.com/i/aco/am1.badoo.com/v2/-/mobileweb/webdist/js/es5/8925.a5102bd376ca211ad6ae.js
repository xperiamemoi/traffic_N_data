/*! For license information please see 8925.a5102bd376ca211ad6ae.js.LICENSE.txt */
var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "7e2c150a-54f1-4ae8-b47b-799cc17b2088", e._sentryDebugIdIdentifier = "sentry-dbid-7e2c150a-54f1-4ae8-b47b-799cc17b2088")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "7e2c150a-54f1-4ae8-b47b-799cc17b2088", e._sentryDebugIdIdentifier = "sentry-dbid-7e2c150a-54f1-4ae8-b47b-799cc17b2088")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [8925], {
            11611: function(e, t, n) {
                "use strict";
                var r = n(47639);
                t.A = r.A
            },
            14566: function(e, t, n) {
                "use strict";

                function r(e) {
                    return Boolean(e.threatmetrix_url && e.threatmetrix_profiling_type && e.threatmetrix_timeout_sec && e.threatmetrix_session_id)
                }
                n.d(t, {
                    _: function() {
                        return s
                    },
                    k: function() {
                        return r
                    }
                });
                var i = function(e, t) {
                    return i = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                    }, i(e, t)
                };
                var o = function(e) {
                    function t() {
                        var t = e.call(this) || this;
                        return t.name = "TimeoutError", t.message = "Timeout error loading ThreatMetrix profiling", t
                    }
                    return function(e, t) {
                        if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                        function n() {
                            this.constructor = e
                        }
                        i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                    }(t, e), t
                }(Error);

                function a(e) {
                    return new Promise((function(t, n) {
                        var r = 1e3 * (e.threatmetrix_timeout_sec || 0);
                        setTimeout((function() {
                            n(new o)
                        }), r)
                    }))
                }
                var s = function() {
                    function e(e, t) {
                        this.purchaseTransaction = e, this.wrapper = (null == t ? void 0 : t.iframeWrapper) || document.body
                    }
                    return e.prototype.handleIframeType = function() {
                        var e = this;
                        return new Promise((function(t) {
                            var n = e.purchaseTransaction.threatmetrix_url;
                            e.iframe = document.createElement("iframe"), e.iframe.style.width = "1px", e.iframe.style.height = "1px", e.iframe.onload = function() {
                                t()
                            }, e.iframe.setAttribute("src", n), e.wrapper.appendChild(e.iframe)
                        }))
                    }, e.prototype.handleImageType = function() {
                        var e = this;
                        return new Promise((function(t, n) {
                            var r = e.purchaseTransaction.threatmetrix_url,
                                i = new Image,
                                o = function() {
                                    n(new Error("Error loading ThreatMetrix profiling image"))
                                };
                            i.onerror = o, i.onload = function() {
                                if ("naturalHeight" in i) {
                                    if (i.naturalHeight + i.naturalWidth === 0) return void o()
                                } else {
                                    var e = i;
                                    if (e.width + e.height === 0) return void o()
                                }
                                t()
                            }, i.src = r
                        }))
                    }, e.prototype.startProfiling = function() {
                        var e = this,
                            t = this.purchaseTransaction;
                        return new Promise((function(n) {
                            var r = t.threatmetrix_profiling_type,
                                i = null;
                            2 === r ? i = e.handleIframeType() : 1 === r && (i = e.handleImageType()), i ? Promise.race([i, a(t)]).then((function() {
                                n({
                                    status: 2
                                })
                            })).catch((function(e) {
                                n({
                                    status: e instanceof o ? 1 : 3,
                                    error: e
                                })
                            })).finally((function() {
                                e.destroy()
                            })) : n({
                                status: 3,
                                error: new Error("Unknown ThreatMetrix profiling type")
                            })
                        }))
                    }, e.prototype.destroy = function() {
                        this.iframe && (this.wrapper.removeChild(this.iframe), this.iframe = void 0)
                    }, e
                }()
            },
            15700: function(e, t, n) {
                "use strict";
                var r = n(74848),
                    i = n(32485),
                    o = n.n(i),
                    a = n(8483),
                    s = n(93827);
                t.A = ({
                    icon: e,
                    text: t,
                    extra: n,
                    variant: i = "hint",
                    id: c,
                    dataQA: u
                }) => {
                    const l = o()({
                        "csms-form-control-note": !0,
                        [`csms-form-control-note--variant-${i}`]: i
                    });
                    let d = e;
                    return d || ("success" === i && (d = "generic-verification-hollow"), "error" === i && (d = "generic-error")), (0, r.jsxs)("div", {
                        className: l,
                        role: "error" === i ? "alert" : void 0,
                        children: [d && t ? (0, r.jsx)("div", {
                            className: "csms-form-control-note__icon",
                            children: (0, r.jsx)(a.A, {
                                name: d
                            })
                        }) : null, t ? (0, r.jsx)("div", {
                            className: "csms-form-control-note__text",
                            children: (0, r.jsx)(s.P3, {
                                id: c,
                                dataQA: u,
                                children: t
                            })
                        }) : null, n ? (0, r.jsx)("div", {
                            className: "csms-form-control-note__extra",
                            children: n
                        }) : null]
                    })
                }
            },
            17380: function(e, t, n) {
                "use strict";
                var r = n(74848),
                    i = n(32485),
                    o = n.n(i),
                    a = n(8483);
                t.A = ({
                    type: e,
                    color: t = "default",
                    id: n,
                    name: i,
                    value: s,
                    isChecked: c,
                    isInvalid: u,
                    isDisabled: l,
                    onChange: d,
                    onClick: f,
                    dataQA: h,
                    a11y: m
                }) => {
                    let p = c ? "checked" : "unchecked";
                    u && !c && (p = "error");
                    const v = o()({
                            "csms-choice": !0,
                            "csms-choice--is-checked": c,
                            ["csms-choice--" + ("checkbox" === e ? "checkbox" : "radiobutton")]: !0,
                            "csms-choice--disabled": l,
                            [`csms-choice--${t}-${p}-${"checkbox"===e?"checkbox":"radiobutton"}`]: !0
                        }),
                        y = "checkbox" === e ? "checkbox" : "radio",
                        b = {
                            "data-qa": `csms-${y}`,
                            ...h
                        };
                    return (0, r.jsxs)("span", {
                        className: v,
                        ...b,
                        children: [(0, r.jsx)("input", {
                            className: "csms-choice__input",
                            id: n,
                            name: i,
                            value: s,
                            type: y,
                            checked: c,
                            onChange: d,
                            disabled: l,
                            onClick: f,
                            "aria-label": m ? .label,
                            "aria-invalid": u && !c
                        }), (0, r.jsx)("span", {
                            className: "csms-choice__icon",
                            children: (0, r.jsx)(a.A, {
                                name: "checkbox" === e ? "elements-checkbox-selected-indicator" : "elements-radiobutton-selected-indicator"
                            })
                        }), (0, r.jsx)("span", {
                            className: "csms-choice__border"
                        })]
                    })
                }
            },
            19276: function(e, t, n) {
                "use strict";
                var r;
                n.d(t, {
                    A: function() {
                        return s
                    }
                });
                var i, o = ((r = {})[1] = "supports3DS", r[2] = "supportsEMV", r[3] = "supportsCredit", r[4] = "supportsDebit", r),
                    a = "final";
                ! function(e) {
                    e[e.NOT_AVAILABLE = 1] = "NOT_AVAILABLE", e[e.UNKNOWN = 2] = "UNKNOWN", e[e.SESSION_ABSENT = 3] = "SESSION_ABSENT", e[e.SESSION_SETUP_FAILED = 4] = "SESSION_SETUP_FAILED", e[e.INVALID_CONSTRUCTOR_PARAMS = 5] = "INVALID_CONSTRUCTOR_PARAMS", e[e.APPLE_PAY_SETUP_FAILED = 6] = "APPLE_PAY_SETUP_FAILED", e[e.MERCHANT_VALIDATION_FAILED = 7] = "MERCHANT_VALIDATION_FAILED", e[e.PAYMENTS_WITH_CURRENT_CARD_CHECK_FAILED = 8] = "PAYMENTS_WITH_CURRENT_CARD_CHECK_FAILED"
                }(i || (i = {}));
                var s = function() {
                    function e(e) {
                        var t = e || {},
                            n = t.onReady,
                            r = void 0 === n ? c : n,
                            i = t.providerId,
                            o = void 0 === i ? "" : i,
                            a = t.merchantIdentifier,
                            s = void 0 === a ? "" : a,
                            u = t.merchantValidationHandler,
                            l = void 0 === u ? null : u;
                        this.merchantIdentifier = s, this.providerId = o, this.merchantValidationHandler = l, this.onReady = r, this.isPaymentsPossible = "undefined" != typeof ApplePaySession, this.isPaymentsAvailable = !1, this.session = null, this.transactionId = "", this.total = null, this.uid = "", this.initPromise = null, this.init()
                    }
                    return e.prototype.updatePurchaseTransactionData = function(e) {
                        this.transactionId = e.transaction_id, this.uid = e.uid
                    }, e.prototype.updateCurrentSession = function(t, n) {
                        void 0 === n && (n = "");
                        var r = (t.merchant_capability || []).map((function(e) {
                            return o[e]
                        })).filter(Boolean);
                        this.updatePurchaseTransactionData(t);
                        var i = t.transaction_id,
                            s = {
                                amount: t.price,
                                label: n || "...",
                                type: a
                            },
                            c = {
                                applicationData: i,
                                countryCode: t.country_code || "",
                                currencyCode: t.currency,
                                merchantCapabilities: r,
                                supportedNetworks: t.supported_networks || [],
                                supportedCountries: t.supported_countries,
                                total: s
                            },
                            u = new ApplePaySession(e.CURRENT_APPLE_PAY_JS_API_VERSION, c);
                        return this.session = u, this.total = s, u
                    }, e.prototype.startSession = function(e) {
                        var t = this,
                            n = this.session;
                        if (!n) return {
                            errorCode: i.SESSION_ABSENT,
                            message: "Can not start the session because it does not exist"
                        };
                        var r = e || {
                                onValidateMerchant: c,
                                onShippingContactSelected: c,
                                onShippingMethodSelected: c,
                                onPaymentMethodSelected: c,
                                onPaymentAuthorized: u,
                                onCancel: c
                            },
                            o = r.onValidateMerchant,
                            a = void 0 === o ? c : o,
                            s = r.onShippingContactSelected,
                            l = void 0 === s ? c : s,
                            d = r.onShippingMethodSelected,
                            f = void 0 === d ? c : d,
                            h = r.onPaymentMethodSelected,
                            m = void 0 === h ? c : h,
                            p = r.onPaymentAuthorized,
                            v = void 0 === p ? u : p,
                            y = r.onCancel,
                            b = void 0 === y ? c : y;
                        return n.onvalidatemerchant = function(e) {
                            t.performMerchantValidation(e).then((function(e) {
                                n.completeMerchantValidation(e), a(null, e)
                            })).catch((function(n) {
                                t.abortSession();
                                var r = {
                                    errorCode: i.MERCHANT_VALIDATION_FAILED,
                                    message: "Failed to validate the merchant",
                                    originalError: n
                                };
                                a(r, e)
                            }))
                        }, n.onshippingcontactselected = function(e) {
                            l(null, e)
                        }, n.onshippingmethodselected = function(e) {
                            f(null, e)
                        }, n.onpaymentmethodselected = function(e) {
                            try {
                                var r = t.total;
                                null !== r && (n.completePaymentMethodSelection({
                                    newTotal: r
                                }), m(null, e))
                            } catch (t) {
                                m(t, e)
                            }
                        }, n.onpaymentauthorized = function(e) {
                            v(null, {
                                event: e,
                                transactionId: t.transactionId,
                                providerId: t.providerId,
                                uid: t.uid
                            }).then((function() {
                                n.completePayment(ApplePaySession.STATUS_SUCCESS)
                            })).catch((function() {
                                n.completePayment(ApplePaySession.STATUS_FAILURE)
                            })).finally((function() {
                                t.abortSession()
                            }))
                        }, n.oncancel = function(e) {
                            b(null, e)
                        }, n.begin()
                    }, e.prototype.setupApplePay = function() {
                        var e = this;
                        return new Promise((function(t, n) {
                            ApplePaySession.openPaymentSetup(e.merchantIdentifier).then((function(r) {
                                if (r) t(r);
                                else {
                                    var o = {
                                        message: "Failed to setup Apple Pay because of wrong configuration",
                                        errorCode: i.APPLE_PAY_SETUP_FAILED,
                                        state: {
                                            merchantIdentifier: e.merchantIdentifier
                                        }
                                    };
                                    n(o)
                                }
                            })).catch((function(t) {
                                var r = {
                                    errorCode: i.APPLE_PAY_SETUP_FAILED,
                                    message: "Failed to setup Apple Pay unexpectedly",
                                    originalError: t,
                                    state: {
                                        merchantIdentifier: e.merchantIdentifier
                                    }
                                };
                                n(r)
                            }))
                        }))
                    }, e.prototype.checkForApplePayAvailability = function(e) {
                        var t = this;
                        return this.checkAvailability().then((function(n) {
                            return t.isPaymentsAvailable = n, e(null, t), t.isPaymentsAvailable
                        })).catch((function(n) {
                            return e(n, t), !1
                        }))
                    }, e.prototype.init = function() {
                        return this.initPromise || (this.initPromise = this.checkForApplePayAvailability(this.onReady)), this.initPromise
                    }, e.prototype.checkAvailability = function() {
                        var e = this;
                        if (!this.isPaymentsPossible) {
                            var t = {
                                errorCode: i.NOT_AVAILABLE,
                                message: "Apple Pay is not available on your device"
                            };
                            return Promise.reject(t)
                        }
                        return new Promise((function(t, n) {
                            ApplePaySession.canMakePaymentsWithActiveCard(e.merchantIdentifier).then((function(r) {
                                if (r) return t(r);
                                var o = {
                                    errorCode: i.PAYMENTS_WITH_CURRENT_CARD_CHECK_FAILED,
                                    message: "Apple Pay is unavailable, try to add a new card",
                                    state: {
                                        merchantIdentifier: e.merchantIdentifier
                                    }
                                };
                                return n(o)
                            })).catch((function(e) {
                                var t = {
                                    errorCode: i.UNKNOWN,
                                    message: "Apple Pay is not available for unknown reason",
                                    originalError: e
                                };
                                return n(t)
                            }))
                        }))
                    }, e.prototype.abortSession = function() {
                        if (this.session) try {
                            this.session.abort()
                        } catch (e) {} finally {
                            this.session = null
                        }
                        this.transactionId = "", this.total = null, this.uid = ""
                    }, e.prototype.performMerchantValidation = function(e) {
                        var t = e.validationURL,
                            n = void 0 === t ? "" : t;
                        if ("function" == typeof this.merchantValidationHandler) return this.merchantValidationHandler(n);
                        var r = {
                            errorCode: i.INVALID_CONSTRUCTOR_PARAMS,
                            message: "Provide a valid merchantValidationHandler"
                        };
                        return Promise.reject(r)
                    }, e.prototype.getTransactionId = function() {
                        return this.transactionId
                    }, e.prototype.getIsPaymentsPossible = function() {
                        return this.isPaymentsPossible
                    }, e.prototype.getIsPaymentsAvailable = function() {
                        return this.isPaymentsAvailable
                    }, e.CURRENT_APPLE_PAY_JS_API_VERSION = 1, e.ERROR_CODES = i, e
                }();

                function c() {}

                function u() {
                    return Promise.reject(new Error("Uncaught error"))
                }
            },
            24947: function(e, t, n) {
                ! function(e, t) {
                    "use strict";
                    var r = "default" in t ? t.default : t;

                    function i(e, t) {
                        var n = Object.keys(e);
                        if (Object.getOwnPropertySymbols) {
                            var r = Object.getOwnPropertySymbols(e);
                            t && (r = r.filter((function(t) {
                                return Object.getOwnPropertyDescriptor(e, t).enumerable
                            }))), n.push.apply(n, r)
                        }
                        return n
                    }

                    function o(e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var n = null != arguments[t] ? arguments[t] : {};
                            t % 2 ? i(Object(n), !0).forEach((function(t) {
                                a(e, t, n[t])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach((function(t) {
                                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                            }))
                        }
                        return e
                    }

                    function a(e, t, n) {
                        return t in e ? Object.defineProperty(e, t, {
                            value: n,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : e[t] = n, e
                    }

                    function s(e, t) {
                        if (null == e) return {};
                        var n, r, i = {},
                            o = Object.keys(e);
                        for (r = 0; r < o.length; r++) n = o[r], t.indexOf(n) >= 0 || (i[n] = e[n]);
                        return i
                    }

                    function c(e, t) {
                        if (null == e) return {};
                        var n, r, i = s(e, t);
                        if (Object.getOwnPropertySymbols) {
                            var o = Object.getOwnPropertySymbols(e);
                            for (r = 0; r < o.length; r++) n = o[r], t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (i[n] = e[n])
                        }
                        return i
                    }

                    function u(e, t) {
                        return l(e) || d(e, t) || f(e, t) || m()
                    }

                    function l(e) {
                        if (Array.isArray(e)) return e
                    }

                    function d(e, t) {
                        var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                        if (null != n) {
                            var r, i, o = [],
                                a = !0,
                                s = !1;
                            try {
                                for (n = n.call(e); !(a = (r = n.next()).done) && (o.push(r.value), !t || o.length !== t); a = !0);
                            } catch (e) {
                                s = !0, i = e
                            } finally {
                                try {
                                    a || null == n.return || n.return()
                                } finally {
                                    if (s) throw i
                                }
                            }
                            return o
                        }
                    }

                    function f(e, t) {
                        if (e) {
                            if ("string" == typeof e) return h(e, t);
                            var n = Object.prototype.toString.call(e).slice(8, -1);
                            return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? h(e, t) : void 0
                        }
                    }

                    function h(e, t) {
                        (null == t || t > e.length) && (t = e.length);
                        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                        return r
                    }

                    function m() {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }
                    var p = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : void 0 !== n.g ? n.g : "undefined" != typeof self ? self : {};

                    function v(e) {
                        return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
                    }

                    function y(e, t) {
                        return e(t = {
                            exports: {}
                        }, t.exports), t.exports
                    }
                    var b = y((function(e, t) {
                        var n = p && p.__rest || function(e, t) {
                            var n = {};
                            for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
                            if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                                var i = 0;
                                for (r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]])
                            }
                            return n
                        };
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.scripts = void 0, t.scripts = {};
                        var i = function(e) {
                            var n = document.querySelector('script[src="' + e + '"]');
                            if (n) return t.scripts[e] = {
                                loading: !1,
                                error: null,
                                scriptEl: n
                            }
                        };

                        function o(e) {
                            var o = e.src,
                                s = e.checkForExisting,
                                c = void 0 !== s && s,
                                u = n(e, ["src", "checkForExisting"]),
                                l = o ? t.scripts[o] : void 0;
                            !l && c && o && a && (l = i(o));
                            var d = (0, r.useState)(l ? l.loading : Boolean(o)),
                                f = d[0],
                                h = d[1],
                                m = (0, r.useState)(l ? l.error : null),
                                p = m[0],
                                v = m[1];
                            return (0, r.useEffect)((function() {
                                if (a && o && f && !p) {
                                    var e;
                                    !(l = t.scripts[o]) && c && (l = i(o)), l ? e = l.scriptEl : ((e = document.createElement("script")).src = o, Object.keys(u).forEach((function(t) {
                                        void 0 === e[t] ? e.setAttribute(t, u[t]) : e[t] = u[t]
                                    })), l = t.scripts[o] = {
                                        loading: !0,
                                        error: null,
                                        scriptEl: e
                                    });
                                    var n = function() {
                                            l && (l.loading = !1), h(!1)
                                        },
                                        r = function(e) {
                                            l && (l.error = e), v(e)
                                        };
                                    return e.addEventListener("load", n), e.addEventListener("error", r), document.body.appendChild(e),
                                        function() {
                                            e.removeEventListener("load", n), e.removeEventListener("error", r)
                                        }
                                }
                            }), [o]), [f, p]
                        }
                        t.default = o;
                        var a = "undefined" != typeof window && void 0 !== window.document
                    }));
                    v(b), b.scripts;
                    var g, _ = y((function(e, t) {
                            var n = p && p.__importDefault || function(e) {
                                return e && e.__esModule ? e : {
                                    default: e
                                }
                            };
                            Object.defineProperty(t, "__esModule", {
                                value: !0
                            }), t.scripts = t.default = void 0, Object.defineProperty(t, "default", {
                                enumerable: !0,
                                get: function() {
                                    return n(b).default
                                }
                            }), Object.defineProperty(t, "scripts", {
                                enumerable: !0,
                                get: function() {
                                    return b.scripts
                                }
                            })
                        })),
                        E = v(_),
                        A = (_.scripts, function(e, t, n) {
                            var r = {};
                            return delete Object.assign(r, e, a({}, n, e[t]))[t], r
                        }),
                        C = function(e) {
                            var t = {
                                plaid: null,
                                open: !1,
                                onExitCallback: null
                            };
                            if ("undefined" == typeof window || !window.Plaid) throw new Error("Plaid not loaded");
                            var n = A(e, "publicKey", "key");
                            return t.plaid = window.Plaid.create(o(o({}, n), {}, {
                                onExit: function(e, r) {
                                    t.open = !1, n.onExit && n.onExit(e, r), t.onExitCallback && t.onExitCallback()
                                }
                            })), {
                                open: function() {
                                    t.plaid && (t.open = !0, t.onExitCallback = null, t.plaid.open())
                                },
                                exit: function(e, n) {
                                    t.open && t.plaid ? (t.onExitCallback = n, t.plaid.exit(e), e && e.force && (t.open = !1)) : n && n()
                                },
                                destroy: function() {
                                    t.plaid && (t.plaid.destroy(), t.plaid = null)
                                }
                            }
                        },
                        w = "https://cdn.plaid.com/link/v2/stable/link-initialize.js",
                        I = function() {},
                        P = function(e) {
                            var n = u(E({
                                    src: w,
                                    checkForExisting: !0
                                }), 2),
                                r = n[0],
                                i = n[1],
                                a = u(t.useState(null), 2),
                                s = a[0],
                                c = a[1],
                                l = u(t.useState(!1), 2),
                                d = l[0],
                                f = l[1],
                                h = (e.product || []).slice().sort().join(",");
                            t.useEffect((function() {
                                if (!r && (e.token || e.publicKey)) {
                                    if (!i && window.Plaid) {
                                        null != s && s.exit({
                                            force: !0
                                        }, (function() {
                                            return s.destroy()
                                        }));
                                        var t = C(o(o({}, e), {}, {
                                            onLoad: function() {
                                                f(!0), e.onLoad && e.onLoad()
                                            }
                                        }));
                                        return c(t),
                                            function() {
                                                return t.exit({
                                                    force: !0
                                                }, (function() {
                                                    return t.destroy()
                                                }))
                                            }
                                    }
                                    console.error("Error loading Plaid", i)
                                }
                            }), [r, i, e.publicKey, e.token, h]);
                            var m = function() {
                                e.token || console.warn("react-plaid-link: You cannot call open() without a valid token supplied to usePlaidLink. This is a no-op.")
                            };
                            return {
                                error: i,
                                ready: null != s && (!r || d),
                                exit: s ? s.exit : I,
                                open: s ? s.open : m
                            }
                        },
                        x = ["children", "style", "className"],
                        S = function(e) {
                            var t = e.children,
                                n = e.style,
                                i = e.className,
                                a = c(e, x),
                                s = P(o({}, a)),
                                u = s.error,
                                l = s.open;
                            return r.createElement("button", {
                                disabled: Boolean(u),
                                type: "button",
                                className: i,
                                style: o({
                                    padding: "6px 4px",
                                    outline: "none",
                                    background: "#FFFFFF",
                                    border: "2px solid #F1F1F1",
                                    borderRadius: "4px"
                                }, n),
                                onClick: function() {
                                    return l()
                                }
                            }, t)
                        };
                    S.displayName = "PlaidLink", (g = e.PlaidLinkStableEvent || (e.PlaidLinkStableEvent = {})).OPEN = "OPEN", g.EXIT = "EXIT", g.HANDOFF = "HANDOFF", g.SELECT_INSTITUTION = "SELECT_INSTITUTION", g.ERROR = "ERROR", e.PlaidLink = S, e.usePlaidLink = P, Object.defineProperty(e, "__esModule", {
                        value: !0
                    })
                }(t, n(96540))
            },
            30559: function(e, t, n) {
                "use strict";
                var r = n(74848);
                t.A = ({
                    children: e
                }) => (0, r.jsx)("span", {
                    className: "csms-placard-media",
                    children: e
                })
            },
            31189: function(e, t, n) {
                "use strict";
                var r = n(74848),
                    i = n(32485),
                    o = n.n(i);
                t.A = ({
                    children: e,
                    onSubmit: t,
                    noValidate: n = !0,
                    isFixed: i,
                    extraClass: a
                }) => {
                    const s = o()(a, {
                        "csms-form": !0,
                        "csms-form--fixed": i
                    });
                    return t ? (0, r.jsx)("form", {
                        method: "post",
                        className: s,
                        onSubmit: t,
                        noValidate: n,
                        children: e
                    }) : (0, r.jsx)("div", {
                        className: s,
                        children: e
                    })
                }
            },
            32483: function(e, t, n) {
                "use strict";
                var r = n(74848),
                    i = n(32485),
                    o = n.n(i);
                t.A = ({
                    children: e,
                    color: t = "default",
                    align: n = "center",
                    dataQA: i
                }) => {
                    const a = {
                        className: o()({
                            "csms-hint": !0,
                            [`csms-hint--${t}`]: t,
                            [`csms-hint--${n}`]: !0
                        }),
                        ...{
                            "data-qa": "hint",
                            ...i
                        },
                        ..."string" == typeof e ? {
                            dangerouslySetInnerHTML: {
                                __html: e
                            }
                        } : {
                            children: e
                        }
                    };
                    return (0, r.jsx)("div", { ...a
                    })
                }
            },
            33702: function(e, t, n) {
                "use strict";
                var r = n(74848),
                    i = n(32485),
                    o = n.n(i),
                    a = n(84362),
                    s = n(8483),
                    c = n(33815);
                t.A = ({
                    id: e,
                    type: t = "text",
                    name: n,
                    value: i,
                    docked: u,
                    pattern: l,
                    maxLength: d,
                    min: f,
                    max: h,
                    autoFocus: m,
                    isFocused: p,
                    status: v,
                    onFocus: y,
                    onChange: b,
                    onBlur: g,
                    onClick: _,
                    onKeyUp: E,
                    inputRef: A,
                    actionIcon: C,
                    onActionClick: w,
                    isLoading: I,
                    autoComplete: P,
                    autoCapitalize: x,
                    autoCorrect: S,
                    inputMode: T,
                    dir: O = "auto",
                    spellCheck: N,
                    dataQA: R,
                    dataQAInput: j,
                    a11y: k = {}
                }) => {
                    let L = "auto";
                    "tel" === t && (L = "ltr");
                    const D = o()({
                            "csms-text-field": !0,
                            [`csms-text-field--${t}`]: !0,
                            "csms-text-field--is-focused": p,
                            [`csms-text-field--status-${v}`]: v,
                            [`csms-text-field--docked-${u}`]: u,
                            [`csms-text-field--dir-${O||L}`]: !0,
                            "csms-text-field--has-action": C || I
                        }),
                        M = o()({
                            "csms-text-field__input": !0,
                            [`csms-text-field__input--${t}`]: t
                        }),
                        F = {
                            "data-qa": "text-field",
                            ...R
                        },
                        H = w ? "button" : "div";
                    return (0, r.jsxs)("div", {
                        className: D,
                        ...F,
                        children: [(0, r.jsx)("input", {
                            className: M,
                            type: t,
                            autoComplete: P,
                            id: e,
                            name: n,
                            value: b ? i : void 0,
                            defaultValue: b ? void 0 : i,
                            maxLength: void 0 !== d && d > 0 ? d : void 0,
                            onFocus: y,
                            onChange: b,
                            onKeyUp: E,
                            onBlur: g,
                            onClick: _,
                            ref: A,
                            pattern: l,
                            dir: O || L,
                            "data-qa": j || "text-field-input",
                            autoCapitalize: x,
                            autoCorrect: S,
                            inputMode: T,
                            spellCheck: N,
                            autoFocus: m,
                            min: f,
                            max: h,
                            role: k.role,
                            "aria-label": k.inputLabel,
                            "aria-controls": k.ariaControls,
                            "aria-autocomplete": k.ariaAutocomplete,
                            "aria-expanded": k.ariaExpanded,
                            "aria-haspopup": k.ariaHaspopup,
                            "aria-describedby": k.ariaDescribedby,
                            "aria-required": k.ariaRequired,
                            "aria-invalid": "error" === v || void 0,
                            "aria-activedescendant": k.ariaActivedescendant
                        }), C || I ? (0, r.jsx)(H, {
                            className: "csms-text-field__action",
                            onClick: I ? void 0 : w,
                            "data-qa": "text-field-action",
                            type: w && !I ? "button" : void 0,
                            "aria-pressed": w && !I ? k.actionAriaPressed : void 0,
                            "aria-describedby": `${e}-action-description`,
                            "aria-controls": e,
                            children: I ? (0, r.jsx)(c.A, {}) : (0, r.jsx)(s.A, {
                                name: C,
                                a11y: w ? {
                                    label: k.actionIconLabel
                                } : void 0
                            })
                        }) : null, (0, r.jsx)(a.A, {
                            id: `${e}-action-description`,
                            children: k.actionAriaDescription
                        }), (0, r.jsx)("div", {
                            className: "csms-text-field__focus-ring"
                        })]
                    })
                }
            },
            39759: function(e, t) {
                "use strict";
                t.A = function(e, t) {
                    var n = -1,
                        r = e.length;
                    for (t || (t = Array(r)); ++n < r;) t[n] = e[n];
                    return t
                }
            },
            46449: function(e, t, n) {
                "use strict";
                var r = n(46518),
                    i = n(70259),
                    o = n(48981),
                    a = n(26198),
                    s = n(91291),
                    c = n(1469);
                r({
                    target: "Array",
                    proto: !0
                }, {
                    flat: function() {
                        var e = arguments.length ? arguments[0] : void 0,
                            t = o(this),
                            n = a(t),
                            r = c(t, 0);
                        return r.length = i(r, t, t, n, 0, void 0 === e ? 1 : s(e)), r
                    }
                })
            },
            47360: function(e, t) {
                "use strict";
                t.A = function(e) {
                    return e && e.length ? e[0] : void 0
                }
            },
            47639: function(e, t, n) {
                "use strict";
                var r = n(74848),
                    i = n(32485),
                    o = n.n(i),
                    a = n(8483),
                    s = n(93827);
                t.A = ({
                    variant: e = "gray-10",
                    shape: t = "rounded",
                    value: n,
                    name: i,
                    isDisabled: c,
                    showClear: u,
                    onFocus: l,
                    onChange: d,
                    onSubmit: f,
                    onBlur: h,
                    onClear: m,
                    innerRef: p,
                    dataQA: v,
                    dataQAInput: y,
                    a11y: b
                }) => {
                    const g = o()({
                        "csms-search": !0,
                        [`csms-search--${e}`]: !0,
                        [`csms-search--${t}`]: t,
                        "csms-search--disabled": c
                    });
                    return (0, r.jsxs)("form", {
                        className: g,
                        onSubmit: f,
                        role: "search",
                        "data-qa": "csms-search",
                        ...v,
                        children: [(0, r.jsx)("span", {
                            className: "csms-search__icon",
                            children: (0, r.jsx)(a.A, {
                                name: "generic-search"
                            })
                        }), n ? null : (0, r.jsx)("label", {
                            className: "csms-search__label",
                            "aria-hidden": !0,
                            htmlFor: b.inputId,
                            children: (0, r.jsx)(s.P1, {
                                ellipsis: !0,
                                children: b.inputLabel
                            })
                        }), (0, r.jsx)("input", {
                            className: "csms-search__input",
                            type: "search",
                            name: i,
                            id: b.inputId,
                            value: n,
                            autoComplete: "off",
                            autoCorrect: "off",
                            inputMode: "search",
                            spellCheck: !1,
                            disabled: c,
                            onFocus: l,
                            onChange: d,
                            onBlur: h,
                            ref: p,
                            "aria-label": b.inputLabel,
                            "data-qa": y || "csms-search-input"
                        }), u && !c ? (0, r.jsx)("button", {
                            className: "csms-search__clear",
                            onClick: m,
                            type: "reset",
                            "data-qa": "csms-search-clear",
                            children: (0, r.jsx)(a.A, {
                                name: "generic-close-circle-hollow",
                                a11y: {
                                    label: b.clearLabel
                                }
                            })
                        }) : null, (0, r.jsx)("div", {
                            className: "csms-search__focus-ring"
                        })]
                    })
                }
            },
            47667: function(e, t, n) {
                "use strict";
                var r = n(74848),
                    i = n(32485),
                    o = n.n(i);
                t.A = ({
                    media: e,
                    mediaAlign: t = "center",
                    content: n,
                    extra: i,
                    color: a,
                    onClick: s,
                    hasBorder: c,
                    tag: u,
                    innerRef: l,
                    dataQA: d
                }) => {
                    const f = o()({
                            "csms-placard": !0,
                            [`csms-placard--color-${a}`]: !0,
                            "csms-placard--border": c
                        }),
                        h = o()({
                            "csms-placard__media": !0,
                            [`csms-placard__media--align-${t}`]: t
                        }),
                        m = s ? "button" : u || "span";
                    return (0, r.jsxs)(m, {
                        className: f,
                        onClick: s,
                        ...d,
                        ref: l,
                        type: "button" === m ? "button" : void 0,
                        children: [e ? (0, r.jsx)("span", {
                            className: h,
                            children: e
                        }) : null, (0, r.jsx)("span", {
                            className: "csms-placard__content",
                            children: n
                        }), i ? (0, r.jsx)("span", {
                            className: "csms-placard__extra",
                            children: i
                        }) : null]
                    })
                }
            },
            51168: function(e, t, n) {
                "use strict";
                n.d(t, {
                    A: function() {
                        return d
                    }
                });
                var r = n(39142);
                var i = function(e) {
                        return function(t, n, r) {
                            for (var i = -1, o = Object(t), a = r(t), s = a.length; s--;) {
                                var c = a[e ? s : ++i];
                                if (!1 === n(o[c], c, o)) break
                            }
                            return t
                        }
                    }(),
                    o = n(27422);
                var a = function(e, t) {
                    return e && i(e, t, o.A)
                };
                var s = function(e, t, n, r) {
                    return a(e, (function(e, i, o) {
                        t(r, n(e), i, o)
                    })), r
                };
                var c = function(e, t) {
                        return function(n, r) {
                            return s(n, e, t(r), {})
                        }
                    },
                    u = n(29008),
                    l = Object.prototype.toString,
                    d = c((function(e, t, n) {
                        null != t && "function" != typeof t.toString && (t = l.call(t)), e[t] = n
                    }), (0, r.A)(u.A))
            },
            51634: function(e, t, n) {
                "use strict";
                var r = n(74848),
                    i = n(32485),
                    o = n.n(i);
                t.A = ({
                    children: e,
                    width: t = "content",
                    neutral: n,
                    isCompact: i
                }) => {
                    const a = o()({
                        "csms-cta-box__content": !0,
                        "csms-cta-box__content--is-compact": i,
                        [`csms-cta-box__content--width-${t}`]: t,
                        "csms-cta-box__content--neutral": n
                    });
                    return (0, r.jsx)("div", {
                        className: a,
                        "data-qa": "cta-box-content",
                        children: e
                    })
                }
            },
            57998: function(e, t, n) {
                "use strict";
                n.d(t, {
                    T: function() {
                        return o
                    }
                });
                var r, i = self;
                ! function(e) {
                    e.color_depth = "color_depth", e.java_enabled = "java_enabled", e.screen_height = "screen_height", e.screen_width = "screen_width", e.timezone_offset = "timezone_offset"
                }(r || (r = {}));
                var o = function() {
                    function e() {}
                    return e.getInfo = function() {
                        var e = i.screen,
                            t = i.String;
                        return [{
                            key: r.color_depth,
                            value: t(e.colorDepth)
                        }, {
                            key: r.java_enabled,
                            value: t(i.navigator.javaEnabled())
                        }, {
                            key: r.screen_height,
                            value: t(e.height)
                        }, {
                            key: r.screen_width,
                            value: t(e.width)
                        }, {
                            key: r.timezone_offset,
                            value: t((new i.Date).getTimezoneOffset())
                        }]
                    }, e.getInfoAsGenericParams = function(t) {
                        return e.getInfo().map((function(e) {
                            return (new t).setKey(e.key).setValue(e.value)
                        }))
                    }, e.populateInfo = function(t) {
                        t && e.getInfo().forEach((function(e) {
                            var n = e.key,
                                i = e.value,
                                o = t.querySelector('input[name="'.concat(r[n], '"]'));
                            o && (o.value = i)
                        }))
                    }, e
                }()
            },
            64975: function(e, t, n) {
                "use strict";
                n.d(t, {
                    j0: function() {
                        return u
                    },
                    jq: function() {
                        return i
                    }
                });
                var r, i = "bd-payment-result";
                "undefined" != typeof globalThis ? r = globalThis : void 0 !== n.g ? r = n.g : "undefined" != typeof window ? r = window : "undefined" != typeof self && (r = self);
                var o, a = r;
                ! function(e) {
                    e.PRODUCTION = "production", e.STAGING = "staging", e.SHOT = "shot", e.DEV = "dev", e.DEV_REMOTE = "dev_remote"
                }(o || (o = {}));
                var s = function(e, t, n) {
                        if (void 0 === t && (t = ""), e) {
                            var r = ["".concat(e, "=").concat(t)];
                            if (n && !1 !== n.domain) {
                                var i = function(e) {
                                        var t = [void 0, "eu1", "us1", "am1", "gew3", "fr1"],
                                            n = e.split(".").reverse(),
                                            r = n[0],
                                            i = n[1],
                                            a = n[2],
                                            s = n[3],
                                            c = null;
                                        return ["d3", "d4", "d5"].indexOf(r) > -1 ? c = o.DEV_REMOTE : "localhost" === a && (c = o.DEV), ["s", "seu1", "sus1", "sam1", "sgew3", "sfr1", "localhost"].indexOf(a) > -1 || t.indexOf(a) > -1 && "badoo" === i && ("eu" === r || "us" === r) ? c = o.STAGING : t.indexOf(a) > -1 ? c = o.PRODUCTION : ["vpn-shot", "shot"].indexOf(a) > -1 && (c = o.SHOT), {
                                            env: c,
                                            zone: r,
                                            partner: i,
                                            platform: a,
                                            reference: s
                                        }
                                    }(a.location.hostname),
                                    s = i.zone,
                                    c = i.partner,
                                    u = ".".concat(c, ".").concat(s);
                                u && r.push("domain=".concat(u))
                            }
                            if (r.push("path=/"), n && void 0 !== n.expires) {
                                var l = new Date;
                                void 0 !== n.expires && (l = n.expires), r.push("expires=".concat(l.toUTCString()))
                            }(null == n ? void 0 : n.secure) && r.push("secure"), a.document.cookie = r.join("; ")
                        }
                    },
                    c = function(e) {
                        if ("string" != typeof e) return null;
                        for (var t = a.document.cookie.split(";"), n = 0; n < t.length; n++) {
                            var r = "".concat(t[n]),
                                i = r.indexOf("=");
                            if (r.substr(0, i).trim().toLowerCase().toLowerCase() === e.toLowerCase()) {
                                var o = a.unescape(r.substr(i + 1));
                                return "null" === o || "undefined" === o ? "" : o
                            }
                        }
                        return null
                    };
                var u = function() {
                    function e(e, t, n) {
                        this.log = null, this.log = e || console, this.channel = function() {
                            try {
                                var e = String(Math.random());
                                return localStorage.setItem(e, "1"), localStorage.removeItem(e), !0
                            } catch (e) {
                                return !1
                            }
                        }() ? function(e) {
                            return {
                                getPaymentResult: function() {
                                    return a.localStorage.getItem(e)
                                },
                                removePaymentResult: function() {
                                    try {
                                        a.localStorage.removeItem(e)
                                    } catch (e) {}
                                },
                                listenToChange: function(t) {
                                    function n(n) {
                                        n.key === e && t(n.newValue)
                                    }
                                    return a.addEventListener("storage", n), {
                                        stop: function() {
                                            a.removeEventListener("storage", n)
                                        }
                                    }
                                }
                            }
                        }(t || i) : function(e) {
                            return {
                                getPaymentResult: function() {
                                    return c(e)
                                },
                                removePaymentResult: function() {
                                    s(e, "", {
                                        domain: !1,
                                        expires: new Date((new Date).getDate() - 1)
                                    })
                                },
                                listenToChange: function(t) {
                                    var n = i(),
                                        r = setInterval((function() {
                                            var e = i();
                                            e !== n && t(e)
                                        }), 1e3);

                                    function i() {
                                        return c(e)
                                    }
                                    return {
                                        stop: function() {
                                            clearInterval(r)
                                        }
                                    }
                                }
                            }
                        }(n || "bdlocal_bd-payment-result")
                    }
                    return e.prototype.getPaymentResult = function() {
                        var e, t = this.channel.getPaymentResult();
                        if (!t) return null;
                        try {
                            return JSON.parse(t)
                        } catch (n) {
                            null === (e = this.log) || void 0 === e || e.error("Error parsing payment result", {
                                error: n,
                                result: t
                            })
                        }
                        return null
                    }, e.prototype.removePaymentResult = function() {
                        this.channel.removePaymentResult()
                    }, e.prototype.waitForPaymentResult = function(e) {
                        return this.channel.listenToChange((function(t) {
                            if (t) {
                                var n = JSON.parse(t);
                                e(n)
                            }
                        }))
                    }, e
                }()
            },
            68906: function(e, t, n) {
                "use strict";
                n.d(t, {
                    RQ: function() {
                        return p
                    },
                    Us: function() {
                        return g
                    }
                });
                var r = function(e, t) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                    }, r(e, t)
                };

                function i(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    r(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }
                var o = function() {
                    return o = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                        return e
                    }, o.apply(this, arguments)
                };
                "function" == typeof SuppressedError && SuppressedError;
                var a = self,
                    s = function() {
                        function e(e) {
                            var t = this;
                            this.handleMessage = function(e) {
                                var n, r, i, o, a, s;
                                if (e)
                                    if (e.source === t.iframe.contentWindow)
                                        if (t.isTrustedOrigin(e.origin)) {
                                            var c = e.data;
                                            "Error" === c.event ? t.handleError() : t.handleSuccess(c)
                                        } else null === (s = null === (a = t.logger) || void 0 === a ? void 0 : a.warning) || void 0 === s || s.call(a, "Received a message from untrusted origin", {
                                            hasEvent: Boolean(e),
                                            isTrustedOrigin: t.isTrustedOrigin(e.origin),
                                            differentWindowSource: e.source !== t.iframe.contentWindow,
                                            origin: e.origin
                                        });
                                else null === (o = null === (i = t.logger) || void 0 === i ? void 0 : i.warning) || void 0 === o || o.call(i, "Received a message from untrusted source/window", {
                                    differentWindowSource: e.source !== t.iframe.contentWindow,
                                    hasEvent: Boolean(e),
                                    isTrustedOrigin: t.isTrustedOrigin(e.origin),
                                    origin: e.origin
                                });
                                else null === (r = null === (n = t.logger) || void 0 === n ? void 0 : n.warning) || void 0 === r || r.call(n, "handleMessage was called without an event", {
                                    hasEvent: Boolean(e)
                                })
                            };
                            var n = e.iframe,
                                r = e.logger,
                                i = e.redirectUrl,
                                o = e.url,
                                a = e.onSuccess,
                                s = e.onError;
                            if (!n || !o) throw new TypeError("IframeCommunicationHandler needs an iframe and a URL");
                            this.iframe = n, this.logger = r, this.redirectUrl = i, this.url = o, this.callbacks = {
                                onSuccess: a,
                                onError: s
                            }, this.isCancelled = !1
                        }
                        return e.prototype.start = function() {
                            a.addEventListener("message", this.handleMessage, !1)
                        }, e.prototype.stop = function() {
                            this.isCancelled = !0, this.removeOnMessageListener()
                        }, e.prototype.removeOnMessageListener = function() {
                            a.removeEventListener("message", this.handleMessage)
                        }, e.prototype.handleSuccess = function(e) {
                            this.removeOnMessageListener(), !this.isCancelled && this.callbacks.onSuccess && this.callbacks.onSuccess(e)
                        }, e.prototype.handleError = function(e) {
                            this.removeOnMessageListener(), !this.isCancelled && this.callbacks.onError && this.callbacks.onError(e)
                        }, e.prototype.isTrustedOrigin = function(e) {
                            return e === this.url || e === this.redirectUrl
                        }, e
                    }();

                function c(e) {
                    if (e) {
                        var t = a.document.createElement("a");
                        return t.href = e,
                            function(e) {
                                if (!e) return "";
                                if (!e.origin) {
                                    var t = e.port ? ":".concat(e.port) : "";
                                    return "".concat(e.protocol, "//").concat(e.hostname).concat(t)
                                }
                                return e.origin
                            }(t)
                    }
                }
                var u, l = "psd2-iframe",
                    d = "psd2-iframe--hidden",
                    f = function() {
                        function e(e) {
                            var t = this;
                            this.iframeAttributes = [], this.name = "GenericHandler", this.handleSuccess = function(e) {
                                if (t.stopCommunication(), t.data.on_message_notification_url) {
                                    t.onCancelTimeout(), t.redirected = !0;
                                    var n = t.data.on_message_notification_url;
                                    t.data.on_message_notification_url = "";
                                    var r = {
                                        form_action_url: n,
                                        fields: {
                                            data: e
                                        }
                                    };
                                    t.startCommunication(n), t.createHiddenForm(r)
                                } else t.callbacks.onSuccess && t.callbacks.onSuccess(e)
                            }, this.handleError = function(e) {
                                var n;
                                t.stopCommunication(), e && (null === (n = t.logger) || void 0 === n || n.error(e, {
                                    data: t.data
                                })), t.callbacks.onError && t.callbacks.onError()
                            };
                            var n = e.data,
                                r = e.logger,
                                i = e.rootElement,
                                o = e.onSuccess,
                                s = e.onError;
                            this.rootElement = i || a.document.body, this.data = n, this.logger = r, this.callbacks = {
                                onSuccess: o,
                                onError: s
                            }, this.redirected = !1, this.timeoutRedirectId = 0
                        }
                        return e.prototype.initIframe = function(e) {
                            var t = this,
                                n = this.iframeAttributes;
                            if (!n || !n.length) throw this.handleError("Missing iframe attributes in fingerprint step"), new Error("The iframe requires attributes");
                            e && this.removeIframe();
                            var r = a.document.createElement("iframe");
                            this.iframe = r, n.forEach((function(e) {
                                var n = e.name,
                                    i = e.value;
                                if (n) {
                                    if ("src" === n) throw t.handleError("src is a forbidden attribute"), new Error("src is a forbidden attribute");
                                    r.setAttribute(n, i)
                                }
                            })), r.classList.add(l), this.isHiddenIframe() && r.classList.add(d), this.rootElement.appendChild(r), this.startCommunication(this.data.form_action_url), this.createHiddenForm(this.data)
                        }, e.prototype.createHiddenForm = function(e) {
                            var t, n = this;
                            if (e.form_action_url) {
                                this.form && this.rootElement.contains(this.form) && this.rootElement.removeChild(this.form);
                                var r = (null === (t = this.iframe) || void 0 === t ? void 0 : t.getAttribute("name")) || "";
                                this.form = a.document.createElement("form"), this.form.setAttribute("method", "POST"), this.form.setAttribute("target", r), this.form.setAttribute("action", e.form_action_url);
                                var i, o = e.fields || {};
                                Object.keys(o).forEach((function(e) {
                                    var t;
                                    (i = a.document.createElement("input")).setAttribute("type", "hidden"), i.setAttribute("name", e), i.setAttribute("value", o[e]), null === (t = n.form) || void 0 === t || t.appendChild(i)
                                })), this.rootElement.appendChild(this.form), this.form.submit()
                            } else this.handleError("Missing form_action_url in fingerprint step")
                        }, e.prototype.startCommunication = function(e) {
                            this.stopCommunication(), this.iframeCommunicationHandler = new s({
                                iframe: this.iframe,
                                logger: this.logger,
                                redirectUrl: c(this.data.timeout_redirect_url),
                                url: c(e),
                                onSuccess: this.handleSuccess,
                                onError: this.handleError
                            }), this.iframeCommunicationHandler.start(), this.scheduleTimeoutRedirect()
                        }, e.prototype.stopCommunication = function() {
                            this.onCancelTimeout(), this.iframeCommunicationHandler && (this.iframeCommunicationHandler.stop(), this.iframeCommunicationHandler = void 0)
                        }, e.prototype.destroy = function() {
                            this.stopCommunication(), this.removeIframe(), this.removeForm()
                        }, e.prototype.removeIframe = function() {
                            this.iframe && this.iframe.parentNode && this.iframe.parentNode.removeChild(this.iframe)
                        }, e.prototype.removeForm = function() {
                            this.form && this.form.parentNode && this.form.parentNode.removeChild(this.form)
                        }, e.prototype.isHiddenIframe = function() {
                            return Boolean(this.data && this.data.is_hidden_view)
                        }, e.prototype.scheduleTimeoutRedirect = function() {
                            var e = this;
                            if (!this.timeoutRedirectId && !this.redirected) {
                                var t = this.data,
                                    n = t.timeout,
                                    r = t.timeout_redirect_url;
                                n && r && (this.timeoutRedirectId = a.setTimeout((function() {
                                    var t;
                                    e.redirected = !0, null === (t = e.iframe) || void 0 === t || t.setAttribute("src", r)
                                }), 1e3 * n))
                            }
                        }, e.prototype.onCancelTimeout = function() {
                            a.clearTimeout(this.timeoutRedirectId), this.timeoutRedirectId = 0
                        }, e
                    }(),
                    h = "fingerprint-iframe",
                    m = [{
                        name: "id",
                        value: h
                    }, {
                        name: "name",
                        value: h
                    }],
                    p = function(e) {
                        function t(t) {
                            var n = e.call(this, t) || this;
                            return n.name = "FingerprintHandler", n.iframeAttributes = m, n.initIframe(t.removeIframeOnInit), n
                        }
                        return i(t, e), t
                    }(f),
                    v = "challenge-iframe",
                    y = [{
                        name: "id",
                        value: v
                    }, {
                        name: "name",
                        value: v
                    }],
                    b = (function(e) {
                        function t(t) {
                            var n = e.call(this, t) || this;
                            return n.name = "ChallengeHandler", n.iframeAttributes = y, n.initIframe(t.removeIframeOnInit), n
                        }
                        i(t, e)
                    }(f), {
                        iframeCssClassName: l,
                        iframeHiddenCssClass: d,
                        iframeIncorrectHiddenCssClass: ""
                    }),
                    g = function() {
                        function e(e) {
                            var t = this;
                            this.handleSuccess = function(e) {
                                var n, r;
                                t.stopCommunication(), a.clearTimeout(t.hiddenTimeoutId), null === (r = (n = t.callbacks).onSuccess) || void 0 === r || r.call(n, e)
                            }, this.handleError = function() {
                                var e, n;
                                a.clearTimeout(t.hiddenTimeoutId), t.stopCommunication(), null === (n = (e = t.callbacks).onError) || void 0 === n || n.call(e)
                            };
                            var n = e.rootElement,
                                r = e.classNames,
                                i = void 0 === r ? {} : r;
                            this.rootElement = n || a.document.body, this.callbacks = {}, this.data = {}, this.iframeCommunicationHandler = null, this.classNames = o(o({}, b), i), this.updateOptions(e)
                        }
                        return e.prototype.updateOptions = function(e) {
                            var t = e.iframe,
                                n = e.data,
                                r = e.onSuccess,
                                i = e.onError;
                            t && (this.iframe = t), n && (this.data = n), r && (this.callbacks.onSuccess = r), i && (this.callbacks.onError = i)
                        }, e.prototype.start = function() {
                            var e = this.getRedirectUrl();
                            if (e) {
                                this.iframe || (this.iframe = a.document.createElement("iframe"));
                                var t = this.iframe;
                                if (t.classList.add(this.classNames.iframeCssClassName), this.isHiddenIframe() ? this.hideIframe() : this.showIframe(), this.startCommunication(), t.setAttribute("src", e), this.rootElement.contains(t) || this.rootElement.appendChild(t), this.data.hidden_view_timeout_sec) {
                                    var n = this.data.hidden_view_timeout_sec;
                                    this.hiddenTimeoutId = a.setTimeout(this.handleError, 1e3 * n)
                                }
                            } else this.handleError()
                        }, e.prototype.stop = function() {
                            var e, t = this.iframe;
                            t && (this.stopCommunication(), a.clearTimeout(this.hiddenTimeoutId), null === (e = t.parentNode) || void 0 === e || e.removeChild(t))
                        }, e.prototype.startCommunication = function() {
                            this.stopCommunication(), this.iframeCommunicationHandler = new s({
                                iframe: this.iframe,
                                url: this.getOriginRedirectUrl(),
                                onSuccess: this.handleSuccess,
                                onError: this.handleError
                            }), this.iframeCommunicationHandler.start()
                        }, e.prototype.stopCommunication = function() {
                            this.iframeCommunicationHandler && (this.iframeCommunicationHandler.stop(), this.iframeCommunicationHandler = null)
                        }, e.prototype.isHiddenIframe = function() {
                            return this.data.is_hidden_view
                        }, e.prototype.getRedirectUrl = function() {
                            return this.data.redirect_url || ""
                        }, e.prototype.getOriginRedirectUrl = function() {
                            return c(this.getRedirectUrl())
                        }, e.prototype.hideIframe = function() {
                            var e, t;
                            null === (e = this.iframe) || void 0 === e || e.classList.add(this.classNames.iframeHiddenCssClass), this.classNames.iframeIncorrectHiddenCssClass && (null === (t = this.iframe) || void 0 === t || t.classList.add(this.classNames.iframeIncorrectHiddenCssClass))
                        }, e.prototype.showIframe = function() {
                            var e, t;
                            null === (e = this.iframe) || void 0 === e || e.classList.remove(this.classNames.iframeHiddenCssClass), this.classNames.iframeIncorrectHiddenCssClass && (null === (t = this.iframe) || void 0 === t || t.classList.remove(this.classNames.iframeIncorrectHiddenCssClass))
                        }, e
                    }();
                ! function(e) {
                    e.ERROR = "Error", e.REDIRECTION = "Redirection", e.SUCCESS = "Success"
                }(u || (u = {}))
            },
            70259: function(e, t, n) {
                "use strict";
                var r = n(34376),
                    i = n(26198),
                    o = n(96837),
                    a = n(76080),
                    s = function(e, t, n, c, u, l, d, f) {
                        for (var h, m, p = u, v = 0, y = !!d && a(d, f); v < c;) v in n && (h = y ? y(n[v], v, t) : n[v], l > 0 && r(h) ? (m = i(h), p = s(e, t, h, m, p, l - 1) - 1) : (o(p + 1), e[p] = h), p++), v++;
                        return p
                    };
                e.exports = s
            },
            70898: function(e, t) {
                "use strict";
                var n = RegExp("[\\u200d\\ud800-\\udfff\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff\\ufe0e\\ufe0f]");
                t.A = function(e) {
                    return n.test(e)
                }
            },
            76299: function(e, t, n) {
                "use strict";
                n.d(t, {
                    A: function() {
                        return b
                    }
                });
                var r = function(e) {
                        return e.split("")
                    },
                    i = n(70898),
                    o = "\\ud800-\\udfff",
                    a = "[" + o + "]",
                    s = "[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]",
                    c = "\\ud83c[\\udffb-\\udfff]",
                    u = "[^" + o + "]",
                    l = "(?:\\ud83c[\\udde6-\\uddff]){2}",
                    d = "[\\ud800-\\udbff][\\udc00-\\udfff]",
                    f = "(?:" + s + "|" + c + ")" + "?",
                    h = "[\\ufe0e\\ufe0f]?",
                    m = h + f + ("(?:\\u200d(?:" + [u, l, d].join("|") + ")" + h + f + ")*"),
                    p = "(?:" + [u + s + "?", s, l, d, a].join("|") + ")",
                    v = RegExp(c + "(?=" + c + ")|" + p + m, "g");
                var y = function(e) {
                    return e.match(v) || []
                };
                var b = function(e) {
                    return (0, i.A)(e) ? y(e) : r(e)
                }
            },
            78195: function(e, t, n) {
                "use strict";
                n.d(t, {
                    A: function() {
                        return c
                    }
                });
                var r, i = (r = {}, function(e, t) {
                        var n, i = void 0 === t ? {} : t,
                            o = i.id,
                            a = i.nonce;
                        if (o && r[o]) return r[o];
                        var s = window.document.getElementsByTagName("script")[0],
                            c = window.document.createElement("script");
                        o && (c.id = o), a && c.setAttribute("nonce", a), c.src = e, c.async = !0;
                        var u = !1,
                            l = new Promise((function(t, n) {
                                c.onload = function() {
                                    u || (u = !0, t(e))
                                }, c.onreadystatechange = function() {
                                    u || "complete" !== this.readyState || (u = !0, t(e))
                                }, c.onerror = function() {
                                    u || (u = !0, n(new Error("Failed to load the ".concat(o, " script."))))
                                }, c.onabort = function() {
                                    u || (u = !0, n(new Error("Loading of the ".concat(o, " script has been aborted."))))
                                }
                            }));
                        return o && (r[o] = l), null === (n = null == s ? void 0 : s.parentNode) || void 0 === n || n.insertBefore(c, s), l
                    }),
                    o = function() {
                        return o = Object.assign || function(e) {
                            for (var t, n = 1, r = arguments.length; n < r; n++)
                                for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                            return e
                        }, o.apply(this, arguments)
                    };
                "function" == typeof SuppressedError && SuppressedError;
                var a = {
                        apiVersion: 2,
                        apiVersionMinor: 0
                    },
                    s = {
                        type: "CARD",
                        parameters: {
                            allowedAuthMethods: ["PAN_ONLY", "CRYPTOGRAM_3DS"],
                            allowedCardNetworks: ["AMEX", "DISCOVER", "INTERAC", "JCB", "MASTERCARD", "VISA"]
                        }
                    },
                    c = function() {
                        function e(e) {
                            var t = e.gatewayMerchantId,
                                n = void 0 === t ? "" : t,
                                r = e.isTestEnvironment,
                                i = void 0 !== r && r,
                                o = e.onReady,
                                a = void 0 === o ? u : o,
                                s = e.nonce;
                            this.gatewayMerchantId = n, this.isTestEnvironment = i, this.readyToPay = !1, this.onReady = a, this.nonce = s, this.init()
                        }
                        return e.prototype.init = function() {
                            var e = this;
                            i("https://pay.google.com/gp/p/js/pay.js", {
                                id: "googlepay",
                                nonce: this.nonce
                            }).then((function() {
                                var t = o(o({}, a), {
                                    allowedPaymentMethods: [s]
                                });
                                e.paymentsClient = new google.payments.api.PaymentsClient({
                                    environment: e.isTestEnvironment ? "TEST" : "PRODUCTION"
                                }), e.paymentsClient.isReadyToPay(t).then((function(t) {
                                    t.result && (e.readyToPay = !0, e.onReady(null, e))
                                })).catch((function(t) {
                                    e.onReady(t, e)
                                }))
                            }))
                        }, e.prototype.createButton = function(e) {
                            var t;
                            return null === (t = this.paymentsClient) || void 0 === t ? void 0 : t.createButton({
                                buttonColor: "black",
                                buttonType: "buy",
                                onClick: e
                            })
                        }, e.prototype.submitPaymentDataRequest = function(e, t, n) {
                            if (this.readyToPay && this.paymentsClient) {
                                var r = function(e, t, n) {
                                    void 0 === n && (n = !1);
                                    var r = o({}, a),
                                        i = {
                                            type: "PAYMENT_GATEWAY",
                                            parameters: {
                                                gateway: "adyen",
                                                gatewayMerchantId: t
                                            }
                                        },
                                        s = {
                                            type: "CARD",
                                            parameters: {
                                                allowedAuthMethods: e.supported_auth_methods,
                                                allowedCardNetworks: e.supported_networks
                                            },
                                            tokenizationSpecification: i
                                        };
                                    r.allowedPaymentMethods = [s], r.transactionInfo = function(e) {
                                        return {
                                            countryCode: e.country_code,
                                            currencyCode: e.currency,
                                            totalPriceStatus: "FINAL",
                                            totalPrice: Number.parseFloat(e.price).toFixed(2)
                                        }
                                    }(e), r.shippingAddressRequired = !1, r.merchantInfo = n ? {
                                        merchantName: "Badoo",
                                        merchantId: "12345678901234567890"
                                    } : {
                                        merchantId: e.merchant_uid,
                                        merchantName: e.merchant_name
                                    };
                                    return r
                                }(e, this.gatewayMerchantId, this.isTestEnvironment);
                                this.paymentsClient.loadPaymentData(r).then((function(e) {
                                    t(e.paymentMethodData.tokenizationData.token)
                                })).catch((function(e) {
                                    n && n(e)
                                }))
                            }
                        }, e.prototype.isReadyToPay = function() {
                            return this.readyToPay
                        }, e
                    }();

                function u() {}
            },
            78944: function(e, t, n) {
                "use strict";
                n.d(t, {
                    V: function() {
                        return r
                    }
                });
                var r = function() {
                    function e(e) {
                        this.result = 2, this.startTs = Math.floor(Date.now() / 1e3), this.Rpc = e.Rpc
                    }
                    return e.prototype.setFinishTs = function(e) {
                        return this.finishTs = e, this
                    }, e.prototype.setIdentifier = function(e) {
                        return this.identifier = e, this
                    }, e.prototype.setProductType = function(e) {
                        return this.productType = e, this
                    }, e.prototype.setResult = function(e) {
                        if (4 !== e || 2 === this.result) return this.result = e, this
                    }, e.prototype.setStartTs = function(e) {
                        return this.startTs = e, this
                    }, e.prototype.setViewMode = function(e) {
                        return this.viewMode = e, this
                    }, e.prototype.send = function() {
                        if (this.productType && this.viewMode) {
                            2 === this.result || this.finishTs || (this.finishTs = Math.floor(Date.now() / 1e3));
                            var e = {
                                paywall_interaction_stats: {
                                    finish_ts: this.finishTs,
                                    identifier: this.identifier,
                                    product_type: this.productType,
                                    result: this.result,
                                    start_ts: this.startTs,
                                    view_mode: this.viewMode
                                }
                            };
                            new this.Rpc(278, e).request()
                        }
                    }, e
                }()
            },
            79601: function(e, t, n) {
                "use strict";
                n.d(t, {
                    A: function() {
                        return _
                    }
                });
                var r = n(241),
                    i = n(39759),
                    o = n(9137),
                    a = n(38446),
                    s = n(2383),
                    c = n(92049),
                    u = n(53098);
                var l = function(e) {
                    return "string" == typeof e || !(0, c.A)(e) && (0, u.A)(e) && "[object String]" == (0, s.A)(e)
                };
                var d = function(e) {
                        for (var t, n = []; !(t = e.next()).done;) n.push(t.value);
                        return n
                    },
                    f = n(64877),
                    h = n(29959),
                    m = n(76299),
                    p = n(45572);
                var v = function(e, t) {
                        return (0, p.A)(t, (function(t) {
                            return e[t]
                        }))
                    },
                    y = n(27422);
                var b = function(e) {
                        return null == e ? [] : v(e, (0, y.A)(e))
                    },
                    g = r.A ? r.A.iterator : void 0;
                var _ = function(e) {
                    if (!e) return [];
                    if ((0, a.A)(e)) return l(e) ? (0, m.A)(e) : (0, i.A)(e);
                    if (g && e[g]) return d(e[g]());
                    var t = (0, o.A)(e);
                    return ("[object Map]" == t ? f.A : "[object Set]" == t ? h.A : b)(e)
                }
            },
            79752: function(e, t, n) {
                "use strict";
                n.d(t, {
                    A: function() {
                        return s
                    }
                });
                var r = n(74848),
                    i = n(93827);
                var o = ({
                        text: e,
                        fieldId: t,
                        tag: n
                    }) => {
                        let o = n || "label";
                        "label" !== o || t || (o = "span");
                        const a = {
                            label: {
                                "data-qa": "form-control-label",
                                htmlFor: t,
                                children: e
                            },
                            legend: {
                                "data-qa": "form-control-legend",
                                children: e
                            },
                            span: {
                                "data-qa": "form-control-label",
                                children: e
                            }
                        };
                        return (0, r.jsx)("div", {
                            className: "csms-form-control-label",
                            "data-qa": "csms-form-control-label",
                            children: (0, r.jsx)(i.P2, {
                                weight: "bolder",
                                children: (0, r.jsx)(o, { ...a[o]
                                })
                            })
                        })
                    },
                    a = n(15700);
                var s = ({
                    label: e,
                    children: t,
                    hint: n,
                    status: i,
                    tag: s = "div",
                    dataQA: c,
                    fieldId: u
                }) => {
                    const l = {
                            "data-qa": "form-control",
                            ...c
                        },
                        d = s;
                    return (0, r.jsxs)(d, {
                        className: "csms-form-control",
                        ...l,
                        children: [e ? (0, r.jsx)(o, {
                            text: e,
                            fieldId: u,
                            tag: "fieldset" === s ? "legend" : "label"
                        }) : null, t, i ? (0, r.jsx)(a.A, {
                            text: i.text,
                            extra: i.extra,
                            variant: i.variant || "error",
                            id: i.id,
                            dataQA: {
                                "data-qa": `form-control-${i.variant||"error"}`
                            }
                        }) : null, n ? .text ? (0, r.jsx)(a.A, {
                            icon: n.icon,
                            text: n.text,
                            extra: n.extra,
                            id: n.id,
                            dataQA: {
                                "data-qa": "form-control-hint"
                            }
                        }) : null]
                    })
                }
            },
            93514: function(e, t, n) {
                "use strict";
                n(6469)("flat")
            }
        }
    ]);
//# sourceMappingURL=8925.a5102bd376ca211ad6ae.js.map
var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "f078a333-abde-4292-883b-c4aaeab3d224", e._sentryDebugIdIdentifier = "sentry-dbid-f078a333-abde-4292-883b-c4aaeab3d224")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "f078a333-abde-4292-883b-c4aaeab3d224", e._sentryDebugIdIdentifier = "sentry-dbid-f078a333-abde-4292-883b-c4aaeab3d224")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [3326], {
            90665: function(e, t, n) {
                n.r(t), n.d(t, {
                    BrowserClient: function() {
                        return qe.y
                    },
                    ErrorBoundary: function() {
                        return Pl.tH
                    },
                    Profiler: function() {
                        return Dl
                    },
                    SDK_VERSION: function() {
                        return r.M
                    },
                    SEMANTIC_ATTRIBUTE_SENTRY_OP: function() {
                        return o.uT
                    },
                    SEMANTIC_ATTRIBUTE_SENTRY_ORIGIN: function() {
                        return o.JD
                    },
                    SEMANTIC_ATTRIBUTE_SENTRY_SAMPLE_RATE: function() {
                        return o.sy
                    },
                    SEMANTIC_ATTRIBUTE_SENTRY_SOURCE: function() {
                        return o.i_
                    },
                    Scope: function() {
                        return s.H
                    },
                    WINDOW: function() {
                        return We.jf
                    },
                    addBreadcrumb: function() {
                        return i.Z
                    },
                    addEventProcessor: function() {
                        return a.SA
                    },
                    addIntegration: function() {
                        return c.Q8
                    },
                    addTracingExtensions: function() {
                        return y
                    },
                    breadcrumbsIntegration: function() {
                        return Ge.F
                    },
                    browserApiErrorsIntegration: function() {
                        return tt.G
                    },
                    browserProfilingIntegration: function() {
                        return xl
                    },
                    browserTracingIntegration: function() {
                        return Wu
                    },
                    captureConsoleIntegration: function() {
                        return x
                    },
                    captureEvent: function() {
                        return a.r
                    },
                    captureException: function() {
                        return a.Cp
                    },
                    captureFeedback: function() {
                        return I
                    },
                    captureMessage: function() {
                        return a.wd
                    },
                    captureSession: function() {
                        return a.J5
                    },
                    captureUserFeedback: function() {
                        return Ye.lo
                    },
                    chromeStackLineParser: function() {
                        return Ke.Yj
                    },
                    close: function() {
                        return a.VN
                    },
                    contextLinesIntegration: function() {
                        return kt
                    },
                    continueTrace: function() {
                        return ee
                    },
                    createReduxEnhancer: function() {
                        return zl
                    },
                    createTransport: function() {
                        return ue.o
                    },
                    createUserFeedbackEnvelope: function() {
                        return Xe.L
                    },
                    debugIntegration: function() {
                        return le
                    },
                    dedupeIntegration: function() {
                        return de.s
                    },
                    defaultRequestInstrumentationOptions: function() {
                        return bu
                    },
                    defaultStackLineParsers: function() {
                        return Ke.c9
                    },
                    defaultStackParser: function() {
                        return Ke.lG
                    },
                    endSession: function() {
                        return a.ky
                    },
                    eventFromException: function() {
                        return Ve.u
                    },
                    eventFromMessage: function() {
                        return Ve.qv
                    },
                    exceptionFromError: function() {
                        return Ve.K8
                    },
                    extraErrorDataIntegration: function() {
                        return he
                    },
                    feedbackAsyncIntegration: function() {
                        return Qc
                    },
                    feedbackIntegration: function() {
                        return Zc
                    },
                    feedbackSyncIntegration: function() {
                        return Zc
                    },
                    flush: function() {
                        return a.bX
                    },
                    forceLoad: function() {
                        return Ye.w7
                    },
                    functionToStringIntegration: function() {
                        return fe.Z
                    },
                    geckoStackLineParser: function() {
                        return Ke.dY
                    },
                    getActiveSpan: function() {
                        return h.Bk
                    },
                    getClient: function() {
                        return C.KU
                    },
                    getCurrentHub: function() {
                        return me
                    },
                    getCurrentScope: function() {
                        return C.o5
                    },
                    getDefaultIntegrations: function() {
                        return Ye.nI
                    },
                    getFeedback: function() {
                        return ka
                    },
                    getGlobalScope: function() {
                        return C.m6
                    },
                    getIsolationScope: function() {
                        return C.rm
                    },
                    getReplay: function() {
                        return Di
                    },
                    getRootSpan: function() {
                        return h.zU
                    },
                    getSpanDescendants: function() {
                        return h.xO
                    },
                    getSpanStatusFromHttpCode: function() {
                        return f.AJ
                    },
                    globalHandlersIntegration: function() {
                        return Qe.L
                    },
                    httpClientIntegration: function() {
                        return ft
                    },
                    httpContextIntegration: function() {
                        return Ze.M
                    },
                    inboundFiltersIntegration: function() {
                        return ge.D
                    },
                    init: function() {
                        return El
                    },
                    instrumentOutgoingRequests: function() {
                        return Su
                    },
                    isInitialized: function() {
                        return a.Dp
                    },
                    lastEventId: function() {
                        return a.Q
                    },
                    lazyLoadIntegration: function() {
                        return ot
                    },
                    linkedErrorsIntegration: function() {
                        return et.p
                    },
                    makeBrowserOfflineTransport: function() {
                        return tl
                    },
                    makeFetchTransport: function() {
                        return Je._
                    },
                    makeMultiplexedTransport: function() {
                        return Se
                    },
                    metrics: function() {
                        return mu
                    },
                    moduleMetadataIntegration: function() {
                        return Ie
                    },
                    onLoad: function() {
                        return Ye.kF
                    },
                    opera10StackLineParser: function() {
                        return Ke.Q_
                    },
                    opera11StackLineParser: function() {
                        return Ke.Vv
                    },
                    parameterize: function() {
                        return Ee
                    },
                    reactErrorHandler: function() {
                        return Ml.yL
                    },
                    reactRouterV3BrowserTracingIntegration: function() {
                        return Hl
                    },
                    reactRouterV4BrowserTracingIntegration: function() {
                        return Jl
                    },
                    reactRouterV5BrowserTracingIntegration: function() {
                        return Kl
                    },
                    reactRouterV6BrowserTracingIntegration: function() {
                        return sd
                    },
                    registerSpanErrorInstrumentation: function() {
                        return g
                    },
                    replayCanvasIntegration: function() {
                        return ua
                    },
                    replayIntegration: function() {
                        return Ai
                    },
                    reportingObserverIntegration: function() {
                        return ct
                    },
                    rewriteFramesIntegration: function() {
                        return De
                    },
                    sendFeedback: function() {
                        return fa
                    },
                    sessionTimingIntegration: function() {
                        return Oe
                    },
                    setContext: function() {
                        return a.o
                    },
                    setCurrentClient: function() {
                        return Fe.B
                    },
                    setExtra: function() {
                        return a.l7
                    },
                    setExtras: function() {
                        return a.cx
                    },
                    setHttpStatus: function() {
                        return f.N8
                    },
                    setMeasurement: function() {
                        return H
                    },
                    setTag: function() {
                        return a.NA
                    },
                    setTags: function() {
                        return a.Wt
                    },
                    setUser: function() {
                        return a.gV
                    },
                    showReportDialog: function() {
                        return Ye.mn
                    },
                    spanToBaggageHeader: function() {
                        return F.HW
                    },
                    spanToJSON: function() {
                        return h.et
                    },
                    spanToTraceHeader: function() {
                        return h.Qh
                    },
                    startBrowserTracingNavigationSpan: function() {
                        return Ju
                    },
                    startBrowserTracingPageLoadSpan: function() {
                        return qu
                    },
                    startInactiveSpan: function() {
                        return Z
                    },
                    startNewTrace: function() {
                        return ne
                    },
                    startSession: function() {
                        return a.J0
                    },
                    startSpan: function() {
                        return G
                    },
                    startSpanManual: function() {
                        return Q
                    },
                    tanstackRouterBrowserTracingIntegration: function() {
                        return Wl
                    },
                    thirdPartyErrorFilterIntegration: function() {
                        return Be
                    },
                    useProfiler: function() {
                        return Fl
                    },
                    winjsStackLineParser: function() {
                        return Ke.$2
                    },
                    withActiveSpan: function() {
                        return te
                    },
                    withErrorBoundary: function() {
                        return Pl.Xc
                    },
                    withIsolationScope: function() {
                        return C.rB
                    },
                    withProfiler: function() {
                        return Ol
                    },
                    withScope: function() {
                        return C.v4
                    },
                    withSentryReactRouterV6Routing: function() {
                        return ld
                    },
                    withSentryRouting: function() {
                        return Yl
                    },
                    wrapCreateBrowserRouter: function() {
                        return pd
                    },
                    wrapUseRoutes: function() {
                        return dd
                    },
                    zodErrorsIntegration: function() {
                        return $e
                    }
                });
                var r = n(68074),
                    o = n(74611),
                    s = n(94988),
                    i = n(6810),
                    a = n(64251),
                    c = n(68826),
                    u = n(77397),
                    l = n(62221),
                    d = n(3932),
                    p = n(26674),
                    h = n(5915),
                    f = n(91135);
                let m = !1;

                function g() {
                    m || (m = !0, (0, u.L)(_), (0, l.r)(_))
                }

                function _() {
                    const e = (0, h.Bk)(),
                        t = e && (0, h.zU)(e);
                    if (t) {
                        const e = "internal_error";
                        p.T && d.vF.log(`[Tracing] Root span: ${e} -> Global error occured`), t.setStatus({
                            code: f.TJ,
                            message: e
                        })
                    }
                }

                function y() {
                    g()
                }
                _.tag = "sentry_tracingErrorCallback";
                var v = n(39085),
                    b = n(63827),
                    S = n(92855),
                    w = n(99888),
                    k = n(6013),
                    C = n(57968);
                const x = (0, c._C)(((e = {}) => {
                    const t = e.levels || d.Ow;
                    return {
                        name: "CaptureConsole",
                        setup(e) {
                            "console" in v.O && (0, b.P)((({
                                args: n,
                                level: r
                            }) => {
                                (0, C.KU)() === e && t.includes(r) && function(e, t) {
                                    const n = {
                                        level: (0, S.t)(t),
                                        extra: {
                                            arguments: e
                                        }
                                    };
                                    (0, C.v4)((r => {
                                        if (r.addEventProcessor((e => (e.logger = "console", (0, w.M6)(e, {
                                                handled: !1,
                                                type: "console"
                                            }), e))), "assert" === t) {
                                            if (!e[0]) {
                                                const t = `Assertion failed: ${(0,k.gt)(e.slice(1)," ")||"console.assert"}`;
                                                r.setExtra("arguments", e.slice(1)), (0, a.wd)(t, n)
                                            }
                                            return
                                        }
                                        const o = e.find((e => e instanceof Error));
                                        if (o) return void(0, a.Cp)(o, n);
                                        const s = (0, k.gt)(e, " ");
                                        (0, a.wd)(s, n)
                                    }))
                                }(n, r)
                            }))
                        }
                    }
                }));
                var T = n(40179);

                function I(e, t = {}, n = (0, C.o5)()) {
                    const {
                        message: r,
                        name: o,
                        email: s,
                        url: i,
                        source: a,
                        associatedEventId: c,
                        tags: u
                    } = e, l = {
                        contexts: {
                            feedback: (0, T.Ce)({
                                contact_email: s,
                                name: o,
                                message: r,
                                url: i,
                                source: a,
                                associated_event_id: c
                            })
                        },
                        type: "feedback",
                        level: "info",
                        tags: u
                    }, d = n && n.getClient() || (0, C.KU)();
                    d && d.emit("beforeSendFeedback", l, t);
                    return n.captureEvent(l, t)
                }
                var E = n(69540),
                    M = n(52317),
                    R = n(95200),
                    A = n(92328),
                    N = n(26752);

                function L(e, t, n = () => {}) {
                    let r;
                    try {
                        r = e()
                    } catch (e) {
                        throw t(e), n(), e
                    }
                    return function(e, t, n) {
                        if ((0, N.Qg)(e)) return e.then((e => (n(), e)), (e => {
                            throw t(e), n(), e
                        }));
                        return n(), e
                    }(r, t, n)
                }

                function D(e) {
                    if ("boolean" == typeof __SENTRY_TRACING__ && !__SENTRY_TRACING__) return !1;
                    const t = e || function() {
                        const e = (0, C.KU)();
                        return e && e.getOptions()
                    }();
                    return !!t && (t.enableTracing || "tracesSampleRate" in t || "tracesSampler" in t)
                }
                var O = n(70333),
                    F = n(31158);
                var P = n(91773);
                class B {
                    constructor(e = {}) {
                        this._traceId = e.traceId || (0, w.eJ)(), this._spanId = e.spanId || (0, w.eJ)().substring(16)
                    }
                    spanContext() {
                        return {
                            spanId: this._spanId,
                            traceId: this._traceId,
                            traceFlags: h.CC
                        }
                    }
                    end(e) {}
                    setAttribute(e, t) {
                        return this
                    }
                    setAttributes(e) {
                        return this
                    }
                    setStatus(e) {
                        return this
                    }
                    updateName(e) {
                        return this
                    }
                    isRecording() {
                        return !1
                    }
                    addEvent(e, t, n) {
                        return this
                    }
                    addLink(e) {
                        return this
                    }
                    addLinks(e) {
                        return this
                    }
                    recordException(e, t) {}
                }
                var U = n(91305),
                    j = n(75330),
                    z = n(42409);

                function H(e, t, n) {
                    const r = (0, h.Bk)(),
                        s = r && (0, h.zU)(r);
                    s && s.addEvent(e, {
                        [o.xc]: t,
                        [o.Sn]: n
                    })
                }

                function $(e) {
                    if (!e || 0 === e.length) return;
                    const t = {};
                    return e.forEach((e => {
                        const n = e.attributes || {},
                            r = n[o.Sn],
                            s = n[o.xc];
                        "string" == typeof r && "number" == typeof s && (t[e.name] = {
                            value: s,
                            unit: r
                        })
                    })), t
                }
                const W = "_sentryScope",
                    q = "_sentryIsolationScope";

                function J(e) {
                    return {
                        scope: e[W],
                        isolationScope: e[q]
                    }
                }
                class K {
                    constructor(e = {}) {
                        this._traceId = e.traceId || (0, w.eJ)(), this._spanId = e.spanId || (0, w.eJ)().substring(16), this._startTime = e.startTimestamp || (0, U.zf)(), this._attributes = {}, this.setAttributes({
                            [o.JD]: "manual",
                            [o.uT]: e.op,
                            ...e.attributes
                        }), this._name = e.name, e.parentSpanId && (this._parentSpanId = e.parentSpanId), "sampled" in e && (this._sampled = e.sampled), e.endTimestamp && (this._endTime = e.endTimestamp), this._events = [], this._isStandaloneSpan = e.isStandalone, this._endTime && this._onSpanEnded()
                    }
                    addLink(e) {
                        return this
                    }
                    addLinks(e) {
                        return this
                    }
                    recordException(e, t) {}
                    spanContext() {
                        const {
                            _spanId: e,
                            _traceId: t,
                            _sampled: n
                        } = this;
                        return {
                            spanId: e,
                            traceId: t,
                            traceFlags: n ? h.aO : h.CC
                        }
                    }
                    setAttribute(e, t) {
                        return void 0 === t ? delete this._attributes[e] : this._attributes[e] = t, this
                    }
                    setAttributes(e) {
                        return Object.keys(e).forEach((t => this.setAttribute(t, e[t]))), this
                    }
                    updateStartTime(e) {
                        this._startTime = (0, h.cI)(e)
                    }
                    setStatus(e) {
                        return this._status = e, this
                    }
                    updateName(e) {
                        return this._name = e, this
                    }
                    end(e) {
                        this._endTime || (this._endTime = (0, h.cI)(e), function(e) {
                            if (!p.T) return;
                            const {
                                description: t = "< unknown name >",
                                op: n = "< unknown op >"
                            } = (0, h.et)(e), {
                                spanId: r
                            } = e.spanContext(), o = `[Tracing] Finishing "${n}" ${(0,h.zU)(e)===e?"root ":""}span "${t}" with ID ${r}`;
                            d.vF.log(o)
                        }(this), this._onSpanEnded())
                    }
                    getSpanJSON() {
                        return (0, T.Ce)({
                            data: this._attributes,
                            description: this._name,
                            op: this._attributes[o.uT],
                            parent_span_id: this._parentSpanId,
                            span_id: this._spanId,
                            start_timestamp: this._startTime,
                            status: (0, h.yW)(this._status),
                            timestamp: this._endTime,
                            trace_id: this._traceId,
                            origin: this._attributes[o.JD],
                            _metrics_summary: (0, z.g)(this),
                            profile_id: this._attributes[o.E1],
                            exclusive_time: this._attributes[o.jG],
                            measurements: $(this._events),
                            is_segment: this._isStandaloneSpan && (0, h.zU)(this) === this || void 0,
                            segment_id: this._isStandaloneSpan ? (0, h.zU)(this).spanContext().spanId : void 0
                        })
                    }
                    isRecording() {
                        return !this._endTime && !!this._sampled
                    }
                    addEvent(e, t, n) {
                        p.T && d.vF.log("[Tracing] Adding an event to span:", e);
                        const r = V(t) ? t : n || (0, U.zf)(),
                            o = V(t) ? {} : t || {},
                            s = {
                                name: e,
                                time: (0, h.cI)(r),
                                attributes: o
                            };
                        return this._events.push(s), this
                    }
                    isStandaloneSpan() {
                        return !!this._isStandaloneSpan
                    }
                    _onSpanEnded() {
                        const e = (0, C.KU)();
                        e && e.emit("spanEnd", this);
                        if (!(this._isStandaloneSpan || this === (0, h.zU)(this))) return;
                        if (this._isStandaloneSpan) return void(this._sampled ? function(e) {
                            const t = (0, C.KU)();
                            if (!t) return;
                            const n = e[1];
                            if (!n || 0 === n.length) return void t.recordDroppedEvent("before_send", "span");
                            const r = t.getTransport();
                            r && r.send(e).then(null, (e => {
                                p.T && d.vF.error("Error while sending span:", e)
                            }))
                        }((0, j.lu)([this], e)) : (p.T && d.vF.log("[Tracing] Discarding standalone span because its trace was not chosen to be sampled."), e && e.recordDroppedEvent("sample_rate", "span")));
                        const t = this._convertSpanToTransaction();
                        if (t) {
                            (J(this).scope || (0, C.o5)()).captureEvent(t)
                        }
                    }
                    _convertSpanToTransaction() {
                        if (!X((0, h.et)(this))) return;
                        this._name || (p.T && d.vF.warn("Transaction has no name, falling back to `<unlabeled transaction>`."), this._name = "<unlabeled transaction>");
                        const {
                            scope: e,
                            isolationScope: t
                        } = J(this), n = (e || (0, C.o5)()).getClient() || (0, C.KU)();
                        if (!0 !== this._sampled) return p.T && d.vF.log("[Tracing] Discarding transaction because its trace was not chosen to be sampled."), void(n && n.recordDroppedEvent("sample_rate", "transaction"));
                        const r = (0, h.xO)(this).filter((e => e !== this && ! function(e) {
                                return e instanceof K && e.isStandaloneSpan()
                            }(e))).map((e => (0, h.et)(e))).filter(X),
                            s = this._attributes[o.i_],
                            i = {
                                contexts: {
                                    trace: (0, h.Ck)(this)
                                },
                                spans: r.length > 1e3 ? r.sort(((e, t) => e.start_timestamp - t.start_timestamp)).slice(0, 1e3) : r,
                                start_timestamp: this._startTime,
                                timestamp: this._endTime,
                                transaction: this._name,
                                type: "transaction",
                                sdkProcessingMetadata: {
                                    capturedSpanScope: e,
                                    capturedSpanIsolationScope: t,
                                    ...(0, T.Ce)({
                                        dynamicSamplingContext: (0, F.k1)(this)
                                    })
                                },
                                _metrics_summary: (0, z.g)(this),
                                ...s && {
                                    transaction_info: {
                                        source: s
                                    }
                                }
                            },
                            a = $(this._events);
                        return a && Object.keys(a).length && (p.T && d.vF.log("[Measurements] Adding measurements to transaction event", JSON.stringify(a, void 0, 2)), i.measurements = a), i
                    }
                }

                function V(e) {
                    return e && "number" == typeof e || e instanceof Date || Array.isArray(e)
                }

                function X(e) {
                    return !!(e.start_timestamp && e.timestamp && e.span_id && e.trace_id)
                }
                const Y = "__SENTRY_SUPPRESS_TRACING__";

                function G(e, t) {
                    const n = se();
                    if (n.startSpan) return n.startSpan(e, t);
                    const r = oe(e),
                        {
                            forceTransaction: o,
                            parentSpan: s
                        } = e;
                    return (0, C.v4)(e.scope, (() => ce(s)((() => {
                        const n = (0, C.o5)(),
                            s = ae(n),
                            i = e.onlyIfParent && !s ? new B : re({
                                parentSpan: s,
                                spanArguments: r,
                                forceTransaction: o,
                                scope: n
                            });
                        return (0, O.r)(n, i), L((() => t(i)), (() => {
                            const {
                                status: e
                            } = (0, h.et)(i);
                            !i.isRecording() || e && "ok" !== e || i.setStatus({
                                code: f.TJ,
                                message: "internal_error"
                            })
                        }), (() => i.end()))
                    }))))
                }

                function Q(e, t) {
                    const n = se();
                    if (n.startSpanManual) return n.startSpanManual(e, t);
                    const r = oe(e),
                        {
                            forceTransaction: o,
                            parentSpan: s
                        } = e;
                    return (0, C.v4)(e.scope, (() => ce(s)((() => {
                        const n = (0, C.o5)(),
                            s = ae(n),
                            i = e.onlyIfParent && !s ? new B : re({
                                parentSpan: s,
                                spanArguments: r,
                                forceTransaction: o,
                                scope: n
                            });

                        function a() {
                            i.end()
                        }
                        return (0, O.r)(n, i), L((() => t(i, a)), (() => {
                            const {
                                status: e
                            } = (0, h.et)(i);
                            !i.isRecording() || e && "ok" !== e || i.setStatus({
                                code: f.TJ,
                                message: "internal_error"
                            })
                        }))
                    }))))
                }

                function Z(e) {
                    const t = se();
                    if (t.startInactiveSpan) return t.startInactiveSpan(e);
                    const n = oe(e),
                        {
                            forceTransaction: r,
                            parentSpan: o
                        } = e;
                    return (e.scope ? t => (0, C.v4)(e.scope, t) : void 0 !== o ? e => te(o, e) : e => e())((() => {
                        const t = (0, C.o5)(),
                            o = ae(t);
                        return e.onlyIfParent && !o ? new B : re({
                            parentSpan: o,
                            spanArguments: n,
                            forceTransaction: r,
                            scope: t
                        })
                    }))
                }
                const ee = ({
                    sentryTrace: e,
                    baggage: t
                }, n) => (0, C.v4)((r => {
                    const o = (0, E.kM)(e, t);
                    return r.setPropagationContext(o), n()
                }));

                function te(e, t) {
                    const n = se();
                    return n.withActiveSpan ? n.withActiveSpan(e, t) : (0, C.v4)((n => ((0, O.r)(n, e || void 0), t(n))))
                }

                function ne(e) {
                    return (0, C.v4)((t => (t.setPropagationContext((0, M.J)()), p.T && d.vF.info(`Starting a new trace with id ${t.getPropagationContext().traceId}`), te(null, e))))
                }

                function re({
                    parentSpan: e,
                    spanArguments: t,
                    forceTransaction: n,
                    scope: r
                }) {
                    if (!D()) return new B;
                    const o = (0, C.rm)();
                    let s;
                    if (e && !n) s = function(e, t, n) {
                        const {
                            spanId: r,
                            traceId: o
                        } = e.spanContext(), s = !t.getScopeData().sdkProcessingMetadata[Y] && (0, h.pK)(e), i = s ? new K({ ...n,
                            parentSpanId: r,
                            traceId: o,
                            sampled: s
                        }) : new B({
                            traceId: o
                        });
                        (0, h.Hu)(e, i);
                        const a = (0, C.KU)();
                        a && (a.emit("spanStart", i), n.endTimestamp && a.emit("spanEnd", i));
                        return i
                    }(e, r, t), (0, h.Hu)(e, s);
                    else if (e) {
                        const n = (0, F.k1)(e),
                            {
                                traceId: o,
                                spanId: i
                            } = e.spanContext(),
                            a = (0, h.pK)(e);
                        s = ie({
                            traceId: o,
                            parentSpanId: i,
                            ...t
                        }, r, a), (0, F.LZ)(s, n)
                    } else {
                        const {
                            traceId: e,
                            dsc: n,
                            parentSpanId: i,
                            sampled: a
                        } = { ...o.getPropagationContext(),
                            ...r.getPropagationContext()
                        };
                        s = ie({
                            traceId: e,
                            parentSpanId: i,
                            ...t
                        }, r, a), n && (0, F.LZ)(s, n)
                    }
                    return function(e) {
                            if (!p.T) return;
                            const {
                                description: t = "< unknown name >",
                                op: n = "< unknown op >",
                                parent_span_id: r
                            } = (0, h.et)(e), {
                                spanId: o
                            } = e.spanContext(), s = (0, h.pK)(e), i = (0, h.zU)(e), a = i === e, c = `[Tracing] Starting ${s?"sampled":"unsampled"} ${a?"root ":""}span`, u = [`op: ${n}`, `name: ${t}`, `ID: ${o}`];
                            if (r && u.push(`parent ID: ${r}`), !a) {
                                const {
                                    op: e,
                                    description: t
                                } = (0, h.et)(i);
                                u.push(`root ID: ${i.spanContext().spanId}`), e && u.push(`root op: ${e}`), t && u.push(`root description: ${t}`)
                            }
                            d.vF.log(`${c}\n  ${u.join("\n  ")}`)
                        }(s),
                        function(e, t, n) {
                            e && ((0, T.my)(e, q, n), (0, T.my)(e, W, t))
                        }(s, r, o), s
                }

                function oe(e) {
                    const t = {
                        isStandalone: (e.experimental || {}).standalone,
                        ...e
                    };
                    if (e.startTime) {
                        const n = { ...t
                        };
                        return n.startTimestamp = (0, h.cI)(e.startTime), delete n.startTime, n
                    }
                    return t
                }

                function se() {
                    const e = (0, R.E)();
                    return (0, A.h)(e)
                }

                function ie(e, t, n) {
                    const r = (0, C.KU)(),
                        s = r && r.getOptions() || {},
                        {
                            name: i = "",
                            attributes: a
                        } = e,
                        [c, u] = t.getScopeData().sdkProcessingMetadata[Y] ? [!1] : function(e, t) {
                            if (!D(e)) return [!1];
                            let n;
                            n = "function" == typeof e.tracesSampler ? e.tracesSampler(t) : void 0 !== t.parentSampled ? t.parentSampled : void 0 !== e.tracesSampleRate ? e.tracesSampleRate : 1;
                            const r = (0, P.i)(n);
                            return void 0 === r ? (p.T && d.vF.warn("[Tracing] Discarding transaction because of invalid sample rate."), [!1]) : r ? Math.random() < r ? [!0, r] : (p.T && d.vF.log(`[Tracing] Discarding transaction because it's not included in the random sample (sampling rate = ${Number(n)})`), [!1, r]) : (p.T && d.vF.log("[Tracing] Discarding transaction because " + ("function" == typeof e.tracesSampler ? "tracesSampler returned 0 or false" : "a negative sampling decision was inherited or tracesSampleRate is set to 0")), [!1, r])
                        }(s, {
                            name: i,
                            parentSampled: n,
                            attributes: a,
                            transactionContext: {
                                name: i,
                                parentSampled: n
                            }
                        }),
                        l = new K({ ...e,
                            attributes: {
                                [o.i_]: "custom",
                                ...e.attributes
                            },
                            sampled: c
                        });
                    return void 0 !== u && l.setAttribute(o.sy, u), r && r.emit("spanStart", l), l
                }

                function ae(e) {
                    const t = (0, O.f)(e);
                    if (!t) return;
                    const n = (0, C.KU)();
                    return (n ? n.getOptions() : {}).parentSpanIsAlwaysRootSpan ? (0, h.zU)(t) : t
                }

                function ce(e) {
                    return void 0 !== e ? t => te(e, t) : e => e()
                }
                var ue = n(27403);
                const le = (0, c._C)(((e = {}) => {
                    const t = {
                        debugger: !1,
                        stringify: !1,
                        ...e
                    };
                    return {
                        name: "Debug",
                        setup(e) {
                            e.on("beforeSendEvent", ((e, n) => {
                                t.debugger, (0, d.pq)((() => {
                                    t.stringify ? (console.log(JSON.stringify(e, null, 2)), n && Object.keys(n).length && console.log(JSON.stringify(n, null, 2))) : (console.log(e), n && Object.keys(n).length && console.log(n))
                                }))
                            }))
                        }
                    }
                }));
                var de = n(75083),
                    pe = n(76845);
                const he = (0, c._C)(((e = {}) => {
                    const {
                        depth: t = 3,
                        captureErrorCause: n = !0
                    } = e;
                    return {
                        name: "ExtraErrorData",
                        processEvent(e, r, o) {
                            const {
                                maxValueLength: s = 250
                            } = o.getOptions();
                            return function(e, t = {}, n, r, o) {
                                if (!t.originalException || !(0, N.bJ)(t.originalException)) return e;
                                const s = t.originalException.name || t.originalException.constructor.name,
                                    i = function(e, t, n) {
                                        try {
                                            const r = ["name", "message", "stack", "line", "column", "fileName", "lineNumber", "columnNumber", "toJSON"],
                                                o = {};
                                            for (const t of Object.keys(e)) {
                                                if (-1 !== r.indexOf(t)) continue;
                                                const s = e[t];
                                                o[t] = (0, N.bJ)(s) || "string" == typeof s ? (0, k.xv)(`${s}`, n) : s
                                            }
                                            if (t && void 0 !== e.cause && (o.cause = (0, N.bJ)(e.cause) ? e.cause.toString() : e.cause), "function" == typeof e.toJSON) {
                                                const t = e.toJSON();
                                                for (const e of Object.keys(t)) {
                                                    const n = t[e];
                                                    o[e] = (0, N.bJ)(n) ? n.toString() : n
                                                }
                                            }
                                            return o
                                        } catch (e) {
                                            p.T && d.vF.error("Unable to extract extra data from the Error object:", e)
                                        }
                                        return null
                                    }(t.originalException, r, o);
                                if (i) {
                                    const t = { ...e.contexts
                                        },
                                        r = (0, pe.S8)(i, n);
                                    return (0, N.Qd)(r) && ((0, T.my)(r, "__sentry_skip_normalization__", !0), t[s] = r), { ...e,
                                        contexts: t
                                    }
                                }
                                return e
                            }(e, r, t, n, s)
                        }
                    }
                }));
                var fe = n(32324);
                const me = function() {
                    return {
                        bindClient(e) {
                            (0, C.o5)().setClient(e)
                        },
                        withScope: C.v4,
                        getClient: () => (0, C.KU)(),
                        getScope: C.o5,
                        getIsolationScope: C.rm,
                        captureException: (e, t) => (0, C.o5)().captureException(e, t),
                        captureMessage: (e, t, n) => (0, C.o5)().captureMessage(e, t, n),
                        captureEvent: a.r,
                        addBreadcrumb: i.Z,
                        setUser: a.gV,
                        setTags: a.Wt,
                        setTag: a.NA,
                        setExtra: a.l7,
                        setExtras: a.cx,
                        setContext: a.o,
                        getIntegration(e) {
                            const t = (0, C.KU)();
                            return t && t.getIntegrationByName(e.id) || null
                        },
                        startSession: a.J0,
                        endSession: a.ky,
                        captureSession(e) {
                            if (e) return (0, a.ky)();
                            ! function() {
                                const e = (0, C.o5)(),
                                    t = (0, C.KU)(),
                                    n = e.getSession();
                                t && n && t.captureSession(n)
                            }()
                        }
                    }
                };
                var ge = n(45896),
                    _e = n(44984),
                    ye = n(11447),
                    ve = n(20144);

                function be(e, t) {
                    let n;
                    return (0, _e.yH)(e, ((e, r) => (t.includes(r) && (n = Array.isArray(e) ? e[1] : void 0), !!n))), n
                }

                function Se(e, t) {
                    return n => {
                        const r = e(n),
                            o = new Map;

                        function s(t, r) {
                            const s = r ? `${t}:${r}` : t;
                            let i = o.get(s);
                            if (!i) {
                                const a = (0, ye.hH)(t);
                                if (!a) return;
                                const c = (0, ve.Z)(a, n.tunnel);
                                i = r ? function(e, t) {
                                    return n => {
                                        const r = e(n);
                                        return { ...r,
                                            send: async e => {
                                                const n = be(e, ["event", "transaction", "profile", "replay_event"]);
                                                return n && (n.release = t), r.send(e)
                                            }
                                        }
                                    }
                                }(e, r)({ ...n,
                                    url: c
                                }) : e({ ...n,
                                    url: c
                                }), o.set(s, i)
                            }
                            return [t, i]
                        }
                        return {
                            send: async function(e) {
                                const n = t({
                                        envelope: e,
                                        getEvent: function(t) {
                                            const n = t && t.length ? t : ["event"];
                                            return be(e, n)
                                        }
                                    }).map((e => "string" == typeof e ? s(e, void 0) : s(e.dsn, e.release))).filter((e => !!e)),
                                    o = n.length ? n : [
                                        ["", r]
                                    ],
                                    i = await Promise.all(o.map((([t, n]) => n.send(function(e, t) {
                                        return (0, _e.h4)(t ? { ...e[0],
                                            dsn: t
                                        } : e[0], e[1])
                                    }(e, t)))));
                                return i[0]
                            },
                            flush: async function(e) {
                                const t = [...o.values(), r];
                                return (await Promise.all(t.map((t => t.flush(e))))).every((e => e))
                            }
                        }
                    }
                }
                const we = new Map,
                    ke = new Set;

                function Ce(e, t) {
                    return function(e) {
                        if (v.O._sentryModuleMetadata)
                            for (const t of Object.keys(v.O._sentryModuleMetadata)) {
                                const n = v.O._sentryModuleMetadata[t];
                                if (ke.has(t)) continue;
                                ke.add(t);
                                const r = e(t);
                                for (const e of r.reverse())
                                    if (e.filename) {
                                        we.set(e.filename, n);
                                        break
                                    }
                            }
                    }(e), we.get(t)
                }

                function xe(e, t) {
                    try {
                        t.exception.values.forEach((t => {
                            if (t.stacktrace)
                                for (const n of t.stacktrace.frames || []) {
                                    if (!n.filename || n.module_metadata) continue;
                                    const t = Ce(e, n.filename);
                                    t && (n.module_metadata = t)
                                }
                        }))
                    } catch (e) {}
                }

                function Te(e) {
                    try {
                        e.exception.values.forEach((e => {
                            if (e.stacktrace)
                                for (const t of e.stacktrace.frames || []) delete t.module_metadata
                        }))
                    } catch (e) {}
                }
                const Ie = (0, c._C)((() => ({
                    name: "ModuleMetadata",
                    setup(e) {
                        e.on("beforeEnvelope", (e => {
                            (0, _e.yH)(e, ((e, t) => {
                                if ("event" === t) {
                                    const t = Array.isArray(e) ? e[1] : void 0;
                                    t && (Te(t), e[1] = t)
                                }
                            }))
                        })), e.on("applyFrameMetadata", (t => {
                            if (t.type) return;
                            xe(e.getOptions().stackParser, t)
                        }))
                    }
                })));

                function Ee(e, ...t) {
                    const n = new String(String.raw(e, ...t));
                    return n.__sentry_template_string__ = e.join("\0").replace(/%/g, "%%").replace(/\0/g, "%s"), n.__sentry_template_values__ = t, n
                }

                function Me(e, t) {
                    let n = 0;
                    for (let t = e.length - 1; t >= 0; t--) {
                        const r = e[t];
                        "." === r ? e.splice(t, 1) : ".." === r ? (e.splice(t, 1), n++) : n && (e.splice(t, 1), n--)
                    }
                    if (t)
                        for (; n--; n) e.unshift("..");
                    return e
                }
                const Re = /^(\S+:\\|\/?)([\s\S]*?)((?:\.{1,2}|[^/\\]+?|)(\.[^./\\]*|))(?:[/\\]*)$/;

                function Ae(e) {
                    const t = e.length > 1024 ? `<truncated>${e.slice(-1024)}` : e,
                        n = Re.exec(t);
                    return n ? n.slice(1) : []
                }

                function Ne(...e) {
                    let t = "",
                        n = !1;
                    for (let r = e.length - 1; r >= -1 && !n; r--) {
                        const o = r >= 0 ? e[r] : "/";
                        o && (t = `${o}/${t}`, n = "/" === o.charAt(0))
                    }
                    return t = Me(t.split("/").filter((e => !!e)), !n).join("/"), (n ? "/" : "") + t || "."
                }

                function Le(e) {
                    let t = 0;
                    for (; t < e.length && "" === e[t]; t++);
                    let n = e.length - 1;
                    for (; n >= 0 && "" === e[n]; n--);
                    return t > n ? [] : e.slice(t, n - t + 1)
                }
                const De = (0, c._C)(((e = {}) => {
                    const t = e.root,
                        n = e.prefix || "app:///",
                        r = "window" in v.O && void 0 !== v.O.window,
                        o = e.iteratee || function({
                            isBrowser: e,
                            root: t,
                            prefix: n
                        }) {
                            return r => {
                                if (!r.filename) return r;
                                const o = /^[a-zA-Z]:\\/.test(r.filename) || r.filename.includes("\\") && !r.filename.includes("/"),
                                    s = /^\//.test(r.filename);
                                if (e) {
                                    if (t) {
                                        const e = r.filename;
                                        0 === e.indexOf(t) && (r.filename = e.replace(t, n))
                                    }
                                } else if (o || s) {
                                    const e = o ? r.filename.replace(/^[a-zA-Z]:/, "").replace(/\\/g, "/") : r.filename,
                                        s = t ? function(e, t) {
                                            e = Ne(e).slice(1), t = Ne(t).slice(1);
                                            const n = Le(e.split("/")),
                                                r = Le(t.split("/")),
                                                o = Math.min(n.length, r.length);
                                            let s = o;
                                            for (let e = 0; e < o; e++)
                                                if (n[e] !== r[e]) {
                                                    s = e;
                                                    break
                                                }
                                            let i = [];
                                            for (let e = s; e < n.length; e++) i.push("..");
                                            return i = i.concat(r.slice(s)), i.join("/")
                                        }(t, e) : function(e, t) {
                                            let n = Ae(e)[2] || "";
                                            return t && n.slice(-1 * t.length) === t && (n = n.slice(0, n.length - t.length)), n
                                        }(e);
                                    r.filename = `${n}${s}`
                                }
                                return r
                            }
                        }({
                            isBrowser: r,
                            root: t,
                            prefix: n
                        });

                    function s(e) {
                        return { ...e,
                            frames: e && e.frames && e.frames.map((e => o(e)))
                        }
                    }
                    return {
                        name: "RewriteFrames",
                        processEvent(e) {
                            let t = e;
                            return e.exception && Array.isArray(e.exception.values) && (t = function(e) {
                                try {
                                    return { ...e,
                                        exception: { ...e.exception,
                                            values: e.exception.values.map((e => ({ ...e,
                                                ...e.stacktrace && {
                                                    stacktrace: s(e.stacktrace)
                                                }
                                            })))
                                        }
                                    }
                                } catch (t) {
                                    return e
                                }
                            }(t)), t
                        }
                    }
                }));
                const Oe = (0, c._C)((() => {
                    const e = 1e3 * (0, U.zf)();
                    return {
                        name: "SessionTiming",
                        processEvent(t) {
                            const n = 1e3 * (0, U.zf)();
                            return { ...t,
                                extra: { ...t.extra,
                                    "session:start": e,
                                    "session:duration": n - e,
                                    "session:end": n
                                }
                            }
                        }
                    }
                }));
                var Fe = n(77468),
                    Pe = n(86453);
                const Be = (0, c._C)((e => ({
                    name: "ThirdPartyErrorsFilter",
                    setup(e) {
                        e.on("beforeEnvelope", (e => {
                            (0, _e.yH)(e, ((e, t) => {
                                if ("event" === t) {
                                    const t = Array.isArray(e) ? e[1] : void 0;
                                    t && (Te(t), e[1] = t)
                                }
                            }))
                        })), e.on("applyFrameMetadata", (t => {
                            if (t.type) return;
                            xe(e.getOptions().stackParser, t)
                        }))
                    },
                    processEvent(t) {
                        const n = function(e) {
                            const t = (0, Pe.RV)(e);
                            if (!t) return;
                            return t.filter((e => !!e.filename)).map((e => e.module_metadata ? Object.keys(e.module_metadata).filter((e => e.startsWith(Ue))).map((e => e.slice(Ue.length))) : []))
                        }(t);
                        if (n) {
                            const r = n["drop-error-if-contains-third-party-frames" === e.behaviour || "apply-tag-if-contains-third-party-frames" === e.behaviour ? "some" : "every"]((t => !t.some((t => e.filterKeys.includes(t)))));
                            if (r) {
                                if ("drop-error-if-contains-third-party-frames" === e.behaviour || "drop-error-if-exclusively-contains-third-party-frames" === e.behaviour) return null;
                                t.tags = { ...t.tags,
                                    third_party_code: !0
                                }
                            }
                        }
                        return t
                    }
                })));
                const Ue = "_sentryBundlerPluginAppKey:";

                function je(e) {
                    return { ...e,
                        path: "path" in e && Array.isArray(e.path) ? e.path.join(".") : void 0,
                        keys: "keys" in e ? JSON.stringify(e.keys) : void 0,
                        unionErrors: "unionErrors" in e ? JSON.stringify(e.unionErrors) : void 0
                    }
                }

                function ze(e) {
                    const t = new Set;
                    for (const n of e.issues) n.path && n.path[0] && t.add(n.path[0]);
                    const n = Array.from(t);
                    return `Failed to validate keys: ${(0,k.xv)(n.join(", "),100)}`
                }

                function He(e, t, n) {
                    return t.exception && t.exception.values && n && n.originalException && (r = n.originalException, (0, N.bJ)(r) && "ZodError" === r.name && Array.isArray(r.errors)) && 0 !== n.originalException.issues.length ? { ...t,
                        exception: { ...t.exception,
                            values: [{ ...t.exception.values[0],
                                value: ze(n.originalException)
                            }, ...t.exception.values.slice(1)]
                        },
                        extra: { ...t.extra,
                            "zoderror.issues": n.originalException.errors.slice(0, e).map(je)
                        }
                    } : t;
                    var r
                }
                const $e = (0, c._C)(((e = {}) => {
                    const t = e.limit || 10;
                    return {
                        name: "ZodErrors",
                        processEvent(e, n) {
                            return He(t, e, n)
                        }
                    }
                }));
                var We = n(90452),
                    qe = n(78856),
                    Je = n(17980),
                    Ke = n(34720),
                    Ve = n(11738),
                    Xe = n(97469),
                    Ye = n(2933),
                    Ge = n(79695),
                    Qe = n(4283),
                    Ze = n(79274),
                    et = n(247),
                    tt = n(82522);
                const nt = {
                        replayIntegration: "replay",
                        replayCanvasIntegration: "replay-canvas",
                        feedbackIntegration: "feedback",
                        feedbackModalIntegration: "feedback-modal",
                        feedbackScreenshotIntegration: "feedback-screenshot",
                        captureConsoleIntegration: "captureconsole",
                        contextLinesIntegration: "contextlines",
                        linkedErrorsIntegration: "linkederrors",
                        debugIntegration: "debug",
                        dedupeIntegration: "dedupe",
                        extraErrorDataIntegration: "extraerrordata",
                        httpClientIntegration: "httpclient",
                        reportingObserverIntegration: "reportingobserver",
                        rewriteFramesIntegration: "rewriteframes",
                        sessionTimingIntegration: "sessiontiming",
                        browserProfilingIntegration: "browserprofiling"
                    },
                    rt = We.jf;
                async function ot(e) {
                    const t = nt[e],
                        n = rt.Sentry = rt.Sentry || {};
                    if (!t) throw new Error(`Cannot lazy load integration: ${e}`);
                    const o = n[e];
                    if ("function" == typeof o) return o;
                    const s = function(e) {
                            const t = (0, C.KU)(),
                                n = t && t.getOptions(),
                                o = n && n.cdnBaseUrl || "https://browser.sentry-cdn.com";
                            return new URL(`/${r.M}/${e}.min.js`, o).toString()
                        }(t),
                        i = We.jf.document.createElement("script");
                    i.src = s, i.crossOrigin = "anonymous", i.referrerPolicy = "origin";
                    const a = new Promise(((e, t) => {
                        i.addEventListener("load", (() => e())), i.addEventListener("error", t)
                    }));
                    We.jf.document.body.appendChild(i);
                    try {
                        await a
                    } catch (t) {
                        throw new Error(`Error when loading integration: ${e}`)
                    }
                    const c = n[e];
                    if ("function" != typeof c) throw new Error(`Could not load integration: ${e}`);
                    return c
                }
                var st = n(42544);
                const it = v.O,
                    at = new WeakMap,
                    ct = (0, c._C)(((e = {}) => {
                        const t = e.types || ["crash", "deprecation", "intervention"];

                        function n(e) {
                            if (at.has((0, C.KU)()))
                                for (const t of e)(0, C.v4)((e => {
                                    e.setExtra("url", t.url);
                                    const n = `ReportingObserver [${t.type}]`;
                                    let r = "No details available";
                                    if (t.body) {
                                        const n = {};
                                        for (const e in t.body) n[e] = t.body[e];
                                        if (e.setExtra("body", n), "crash" === t.type) {
                                            const e = t.body;
                                            r = [e.crashId || "", e.reason || ""].join(" ").trim() || r
                                        } else {
                                            r = t.body.message || r
                                        }
                                    }(0, a.wd)(`${n}: ${r}`)
                                }))
                        }
                        return {
                            name: "ReportingObserver",
                            setupOnce() {
                                if (!(0, st.vQ)()) return;
                                new it.ReportingObserver(n, {
                                    buffered: !0,
                                    types: t
                                }).observe()
                            },
                            setup(e) {
                                at.set(e, !0)
                            }
                        }
                    }));
                var ut = n(35947);

                function lt(e, t) {
                    const n = t && t.getDsn(),
                        r = t && t.getOptions().tunnel;
                    return function(e, t) {
                        return !!t && e.includes(t.host)
                    }(e, n) || function(e, t) {
                        if (!t) return !1;
                        return dt(e) === dt(t)
                    }(e, r)
                }

                function dt(e) {
                    return "/" === e[e.length - 1] ? e.slice(0, -1) : e
                }
                var pt = n(71098),
                    ht = n(49431);
                const ft = (0, c._C)(((e = {}) => {
                    const t = {
                        failedRequestStatusCodes: [
                            [500, 599]
                        ],
                        failedRequestTargets: [/.*/],
                        ...e
                    };
                    return {
                        name: "HttpClient",
                        setup(e) {
                            ! function(e, t) {
                                if (!(0, st.m7)()) return;
                                (0, pt.ur)((n => {
                                    if ((0, C.KU)() !== e) return;
                                    const {
                                        response: r,
                                        args: o
                                    } = n, [s, i] = o;
                                    r && function(e, t, n, r) {
                                        if (yt(e, n.status, n.url)) {
                                            const e = function(e, t) {
                                                if (!t && e instanceof Request) return e;
                                                if (e instanceof Request && e.bodyUsed) return e;
                                                return new Request(e, t)
                                            }(t, r);
                                            let o, s, i, c;
                                            bt() && ([o, i] = mt("Cookie", e), [s, c] = mt("Set-Cookie", n));
                                            const u = vt({
                                                url: e.url,
                                                method: e.method,
                                                status: n.status,
                                                requestHeaders: o,
                                                responseHeaders: s,
                                                requestCookies: i,
                                                responseCookies: c
                                            });
                                            (0, a.r)(u)
                                        }
                                    }(t, s, r, i)
                                }))
                            }(e, t),
                            function(e, t) {
                                if (!("XMLHttpRequest" in v.O)) return;
                                (0, ut.Mn)((n => {
                                    if ((0, C.KU)() !== e) return;
                                    const r = n.xhr,
                                        o = r[ut.Er];
                                    if (!o) return;
                                    const {
                                        method: s,
                                        request_headers: i
                                    } = o;
                                    try {
                                        ! function(e, t, n, r) {
                                            if (yt(e, t.status, t.responseURL)) {
                                                let e, o, s;
                                                if (bt()) {
                                                    try {
                                                        const e = t.getResponseHeader("Set-Cookie") || t.getResponseHeader("set-cookie") || void 0;
                                                        e && (o = _t(e))
                                                    } catch (e) {
                                                        ht.T && d.vF.log("Could not extract cookies from response headers")
                                                    }
                                                    try {
                                                        s = function(e) {
                                                            const t = e.getAllResponseHeaders();
                                                            if (!t) return {};
                                                            return t.split("\r\n").reduce(((e, t) => {
                                                                const [n, r] = t.split(": ");
                                                                return n && r && (e[n] = r), e
                                                            }), {})
                                                        }(t)
                                                    } catch (e) {
                                                        ht.T && d.vF.log("Could not extract headers from response")
                                                    }
                                                    e = r
                                                }
                                                const i = vt({
                                                    url: t.responseURL,
                                                    method: n,
                                                    status: t.status,
                                                    requestHeaders: e,
                                                    responseHeaders: s,
                                                    responseCookies: o
                                                });
                                                (0, a.r)(i)
                                            }
                                        }(t, r, s, i)
                                    } catch (e) {
                                        ht.T && d.vF.warn("Error while extracting response event form XHR response", e)
                                    }
                                }))
                            }(e, t)
                        }
                    }
                }));

                function mt(e, t) {
                    const n = function(e) {
                        const t = {};
                        return e.forEach(((e, n) => {
                            t[n] = e
                        })), t
                    }(t.headers);
                    let r;
                    try {
                        const t = n[e] || n[e.toLowerCase()] || void 0;
                        t && (r = _t(t))
                    } catch (t) {
                        ht.T && d.vF.log(`Could not extract cookies from header ${e}`)
                    }
                    return [n, r]
                }

                function gt(e) {
                    if (e) {
                        const t = e["Content-Length"] || e["content-length"];
                        if (t) return parseInt(t, 10)
                    }
                }

                function _t(e) {
                    return e.split("; ").reduce(((e, t) => {
                        const [n, r] = t.split("=");
                        return n && r && (e[n] = r), e
                    }), {})
                }

                function yt(e, t, n) {
                    return function(e, t) {
                        return e.some((e => "number" == typeof e ? e === t : t >= e[0] && t <= e[1]))
                    }(e.failedRequestStatusCodes, t) && (r = e.failedRequestTargets, o = n, r.some((e => "string" == typeof e ? o.includes(e) : e.test(o)))) && !lt(n, (0, C.KU)());
                    var r, o
                }

                function vt(e) {
                    const t = `HTTP Client Error with status code: ${e.status}`,
                        n = {
                            message: t,
                            exception: {
                                values: [{
                                    type: "Error",
                                    value: t
                                }]
                            },
                            request: {
                                url: e.url,
                                method: e.method,
                                headers: e.requestHeaders,
                                cookies: e.requestCookies
                            },
                            contexts: {
                                response: {
                                    status_code: e.status,
                                    headers: e.responseHeaders,
                                    cookies: e.responseCookies,
                                    body_size: gt(e.responseHeaders)
                                }
                            }
                        };
                    return (0, w.M6)(n, {
                        type: "http.client",
                        handled: !1
                    }), n
                }

                function bt() {
                    const e = (0, C.KU)();
                    return !!e && Boolean(e.getOptions().sendDefaultPii)
                }
                var St = n(28039);
                const wt = v.O,
                    kt = (0, c._C)(((e = {}) => {
                        const t = null != e.frameContextLines ? e.frameContextLines : 7;
                        return {
                            name: "ContextLines",
                            processEvent(e) {
                                return function(e, t) {
                                    const n = wt.document,
                                        r = wt.location && (0, St.f)(wt.location.href);
                                    if (!n || !r) return e;
                                    const o = e.exception && e.exception.values;
                                    if (!o || !o.length) return e;
                                    const s = n.documentElement.innerHTML;
                                    if (!s) return e;
                                    const i = ["<!DOCTYPE html>", "<html>", ...s.split("\n"), "</html>"];
                                    return o.forEach((e => {
                                        const n = e.stacktrace;
                                        n && n.frames && (n.frames = n.frames.map((e => function(e, t, n, r) {
                                            if (e.filename !== n || !e.lineno || !t.length) return e;
                                            return (0, w.db)(t, e, r), e
                                        }(e, i, r, t))))
                                    })), e
                                }(e, t)
                            }
                        }
                    }));

                function Ct(e) {
                    let t, n = e[0],
                        r = 1;
                    for (; r < e.length;) {
                        const o = e[r],
                            s = e[r + 1];
                        if (r += 2, ("optionalAccess" === o || "optionalCall" === o) && null == n) return;
                        "access" === o || "optionalAccess" === o ? (t = n, n = s(n)) : "call" !== o && "optionalCall" !== o || (n = s(((...e) => n.call(t, ...e))), t = void 0)
                    }
                    return n
                }
                var xt = n(10204),
                    Tt = n(65166),
                    It = n(11114),
                    Et = n(31859),
                    Mt = n(4285);

                function Rt() {
                    return "undefined" != typeof window && (!(!(0, Mt.Z)() && "[object process]" === Object.prototype.toString.call("undefined" != typeof process ? process : 0)) || void 0 !== v.O.process && "renderer" === v.O.process.type)
                }
                var At = n(3594),
                    Nt = n(4693);
                const Lt = (e, t, n, r) => {
                    let o, s;
                    return i => {
                        t.value >= 0 && (i || r) && (s = t.value - (o || 0), (s || void 0 === o) && (o = t.value, t.delta = s, t.rating = ((e, t) => e > t[1] ? "poor" : e > t[0] ? "needs-improvement" : "good")(t.value, n), e(t)))
                    }
                };
                var Dt = n(14910);
                const Ot = () => Dt.j.performance && performance.getEntriesByType && performance.getEntriesByType("navigation")[0],
                    Ft = () => {
                        const e = Ot();
                        return e && e.activationStart || 0
                    },
                    Pt = (e, t) => {
                        const n = Ot();
                        let r = "navigate";
                        n && (Dt.j.document && Dt.j.document.prerendering || Ft() > 0 ? r = "prerender" : Dt.j.document && Dt.j.document.wasDiscarded ? r = "restore" : n.type && (r = n.type.replace(/_/g, "-")));
                        return {
                            name: e,
                            value: void 0 === t ? -1 : t,
                            rating: "good",
                            delta: 0,
                            entries: [],
                            id: `v3-${Date.now()}-${Math.floor(8999999999999*Math.random())+1e12}`,
                            navigationType: r
                        }
                    },
                    Bt = (e, t, n) => {
                        try {
                            if (PerformanceObserver.supportedEntryTypes.includes(e)) {
                                const r = new PerformanceObserver((e => {
                                    Promise.resolve().then((() => {
                                        t(e.getEntries())
                                    }))
                                }));
                                return r.observe(Object.assign({
                                    type: e,
                                    buffered: !0
                                }, n || {})), r
                            }
                        } catch (e) {}
                    },
                    Ut = e => {
                        const t = t => {
                            ("pagehide" === t.type || Dt.j.document && "hidden" === Dt.j.document.visibilityState) && e(t)
                        };
                        Dt.j.document && (addEventListener("visibilitychange", t, !0), addEventListener("pagehide", t, !0))
                    },
                    jt = e => {
                        let t = !1;
                        return n => {
                            t || (e(n), t = !0)
                        }
                    };
                let zt = -1;
                const Ht = e => {
                        "hidden" === Dt.j.document.visibilityState && zt > -1 && (zt = "visibilitychange" === e.type ? e.timeStamp : 0, removeEventListener("visibilitychange", Ht, !0), removeEventListener("prerenderingchange", Ht, !0))
                    },
                    $t = () => (Dt.j.document && zt < 0 && (zt = "hidden" !== Dt.j.document.visibilityState || Dt.j.document.prerendering ? 1 / 0 : 0, addEventListener("visibilitychange", Ht, !0), addEventListener("prerenderingchange", Ht, !0)), {
                        get firstHiddenTime() {
                            return zt
                        }
                    }),
                    Wt = e => {
                        Dt.j.document && Dt.j.document.prerendering ? addEventListener("prerenderingchange", (() => e()), !0) : e()
                    },
                    qt = [1800, 3e3],
                    Jt = [.1, .25],
                    Kt = (e, t = {}) => {
                        ((e, t = {}) => {
                            Wt((() => {
                                const n = $t(),
                                    r = Pt("FCP");
                                let o;
                                const s = Bt("paint", (e => {
                                    e.forEach((e => {
                                        "first-contentful-paint" === e.name && (s.disconnect(), e.startTime < n.firstHiddenTime && (r.value = Math.max(e.startTime - Ft(), 0), r.entries.push(e), o(!0)))
                                    }))
                                }));
                                s && (o = Lt(e, r, qt, t.reportAllChanges))
                            }))
                        })(jt((() => {
                            const n = Pt("CLS", 0);
                            let r, o = 0,
                                s = [];
                            const i = e => {
                                    e.forEach((e => {
                                        if (!e.hadRecentInput) {
                                            const t = s[0],
                                                n = s[s.length - 1];
                                            o && t && n && e.startTime - n.startTime < 1e3 && e.startTime - t.startTime < 5e3 ? (o += e.value, s.push(e)) : (o = e.value, s = [e])
                                        }
                                    })), o > n.value && (n.value = o, n.entries = s, r())
                                },
                                a = Bt("layout-shift", i);
                            a && (r = Lt(e, n, Jt, t.reportAllChanges), Ut((() => {
                                i(a.takeRecords()), r(!0)
                            })), setTimeout(r, 0))
                        })))
                    },
                    Vt = [100, 300];
                let Xt = 0,
                    Yt = 1 / 0,
                    Gt = 0;
                const Qt = e => {
                    e.forEach((e => {
                        e.interactionId && (Yt = Math.min(Yt, e.interactionId), Gt = Math.max(Gt, e.interactionId), Xt = Gt ? (Gt - Yt) / 7 + 1 : 0)
                    }))
                };
                let Zt;
                const en = () => {
                        "interactionCount" in performance || Zt || (Zt = Bt("event", Qt, {
                            type: "event",
                            buffered: !0,
                            durationThreshold: 0
                        }))
                    },
                    tn = [200, 500],
                    nn = () => (Zt ? Xt : performance.interactionCount || 0) - 0,
                    rn = [],
                    on = {},
                    sn = e => {
                        const t = rn[rn.length - 1],
                            n = on[e.interactionId];
                        if (n || rn.length < 10 || t && e.duration > t.latency) {
                            if (n) n.entries.push(e), n.latency = Math.max(n.latency, e.duration);
                            else {
                                const t = {
                                    id: e.interactionId,
                                    latency: e.duration,
                                    entries: [e]
                                };
                                on[t.id] = t, rn.push(t)
                            }
                            rn.sort(((e, t) => t.latency - e.latency)), rn.splice(10).forEach((e => {
                                delete on[e.id]
                            }))
                        }
                    },
                    an = (e, t = {}) => {
                        Wt((() => {
                            en();
                            const n = Pt("INP");
                            let r;
                            const o = e => {
                                    e.forEach((e => {
                                        if (e.interactionId && sn(e), "first-input" === e.entryType) {
                                            !rn.some((t => t.entries.some((t => e.duration === t.duration && e.startTime === t.startTime)))) && sn(e)
                                        }
                                    }));
                                    const t = (() => {
                                        const e = Math.min(rn.length - 1, Math.floor(nn() / 50));
                                        return rn[e]
                                    })();
                                    t && t.latency !== n.value && (n.value = t.latency, n.entries = t.entries, r())
                                },
                                s = Bt("event", o, {
                                    durationThreshold: null != t.durationThreshold ? t.durationThreshold : 40
                                });
                            r = Lt(e, n, tn, t.reportAllChanges), s && ("PerformanceEventTiming" in Dt.j && "interactionId" in PerformanceEventTiming.prototype && s.observe({
                                type: "first-input",
                                buffered: !0
                            }), Ut((() => {
                                o(s.takeRecords()), n.value < 0 && nn() > 0 && (n.value = 0, n.entries = []), r(!0)
                            })))
                        }))
                    },
                    cn = [2500, 4e3],
                    un = {},
                    ln = [800, 1800],
                    dn = e => {
                        Dt.j.document && Dt.j.document.prerendering ? Wt((() => dn(e))) : Dt.j.document && "complete" !== Dt.j.document.readyState ? addEventListener("load", (() => dn(e)), !0) : setTimeout(e, 0)
                    },
                    pn = {},
                    hn = {};
                let fn, mn, gn, _n, yn;

                function vn(e, t = !1) {
                    return Rn("cls", e, xn, fn, t)
                }

                function bn(e, t = !1) {
                    return Rn("lcp", e, In, gn, t)
                }

                function Sn(e) {
                    return Rn("fid", e, Tn, mn)
                }

                function wn(e) {
                    return Rn("inp", e, Mn, yn)
                }

                function kn(e, t) {
                    return An(e, t), hn[e] || (! function(e) {
                        const t = {};
                        "event" === e && (t.durationThreshold = 0);
                        Bt(e, (t => {
                            Cn(e, {
                                entries: t
                            })
                        }), t)
                    }(e), hn[e] = !0), Nn(e, t)
                }

                function Cn(e, t) {
                    const n = pn[e];
                    if (n && n.length)
                        for (const r of n) try {
                            r(t)
                        } catch (t) {
                            Nt.T && d.vF.error(`Error while triggering instrumentation handler.\nType: ${e}\nName: ${(0,Pe.qQ)(r)}\nError:`, t)
                        }
                }

                function xn() {
                    return Kt((e => {
                        Cn("cls", {
                            metric: e
                        }), fn = e
                    }), {
                        reportAllChanges: !0
                    })
                }

                function Tn() {
                    return ((e, t = {}) => {
                        Wt((() => {
                            const n = $t(),
                                r = Pt("FID");
                            let o;
                            const s = e => {
                                    e.startTime < n.firstHiddenTime && (r.value = e.processingStart - e.startTime, r.entries.push(e), o(!0))
                                },
                                i = e => {
                                    e.forEach(s)
                                },
                                a = Bt("first-input", i);
                            o = Lt(e, r, Vt, t.reportAllChanges), a && Ut(jt((() => {
                                i(a.takeRecords()), a.disconnect()
                            })))
                        }))
                    })((e => {
                        Cn("fid", {
                            metric: e
                        }), mn = e
                    }))
                }

                function In() {
                    return ((e, t = {}) => {
                        Wt((() => {
                            const n = $t(),
                                r = Pt("LCP");
                            let o;
                            const s = e => {
                                    const t = e[e.length - 1];
                                    t && t.startTime < n.firstHiddenTime && (r.value = Math.max(t.startTime - Ft(), 0), r.entries = [t], o())
                                },
                                i = Bt("largest-contentful-paint", s);
                            if (i) {
                                o = Lt(e, r, cn, t.reportAllChanges);
                                const n = jt((() => {
                                    un[r.id] || (s(i.takeRecords()), i.disconnect(), un[r.id] = !0, o(!0))
                                }));
                                ["keydown", "click"].forEach((e => {
                                    Dt.j.document && addEventListener(e, (() => setTimeout(n, 0)), !0)
                                })), Ut(n)
                            }
                        }))
                    })((e => {
                        Cn("lcp", {
                            metric: e
                        }), gn = e
                    }), {
                        reportAllChanges: !0
                    })
                }

                function En() {
                    return ((e, t = {}) => {
                        const n = Pt("TTFB"),
                            r = Lt(e, n, ln, t.reportAllChanges);
                        dn((() => {
                            const e = Ot();
                            if (e) {
                                const t = e.responseStart;
                                if (t <= 0 || t > performance.now()) return;
                                n.value = Math.max(t - Ft(), 0), n.entries = [e], r(!0)
                            }
                        }))
                    })((e => {
                        Cn("ttfb", {
                            metric: e
                        }), _n = e
                    }))
                }

                function Mn() {
                    return an((e => {
                        Cn("inp", {
                            metric: e
                        }), yn = e
                    }))
                }

                function Rn(e, t, n, r, o = !1) {
                    let s;
                    return An(e, t), hn[e] || (s = n(), hn[e] = !0), r && t({
                        metric: r
                    }), Nn(e, t, o ? s : void 0)
                }

                function An(e, t) {
                    pn[e] = pn[e] || [], pn[e].push(t)
                }

                function Nn(e, t, n) {
                    return () => {
                        n && n();
                        const r = pn[e];
                        if (!r) return;
                        const o = r.indexOf(t); - 1 !== o && r.splice(o, 1)
                    }
                }
                var Ln = n(61221),
                    Dn = n(83741);
                const On = v.O,
                    Fn = "sentryReplaySession",
                    Pn = "Unable to send Replay",
                    Bn = 15e4,
                    Un = 5e3,
                    jn = 2e7,
                    zn = 36e5;

                function Hn(e, t) {
                    return null != e ? e : t()
                }

                function $n(e) {
                    let t, n = e[0],
                        r = 1;
                    for (; r < e.length;) {
                        const o = e[r],
                            s = e[r + 1];
                        if (r += 2, ("optionalAccess" === o || "optionalCall" === o) && null == n) return;
                        "access" === o || "optionalAccess" === o ? (t = n, n = s(n)) : "call" !== o && "optionalCall" !== o || (n = s(((...e) => n.call(t, ...e))), t = void 0)
                    }
                    return n
                }
                var Wn;

                function qn(e) {
                    const t = $n([e, "optionalAccess", e => e.host]);
                    return Boolean($n([t, "optionalAccess", e => e.shadowRoot]) === e)
                }

                function Jn(e) {
                    return "[object ShadowRoot]" === Object.prototype.toString.call(e)
                }

                function Kn(e) {
                    try {
                        const n = e.rules || e.cssRules;
                        return n ? ((t = Array.from(n, Vn).join("")).includes(" background-clip: text;") && !t.includes(" -webkit-background-clip: text;") && (t = t.replace(" background-clip: text;", " -webkit-background-clip: text; background-clip: text;")), t) : null
                    } catch (e) {
                        return null
                    }
                    var t
                }

                function Vn(e) {
                    let t;
                    if (function(e) {
                            return "styleSheet" in e
                        }(e)) try {
                        t = Kn(e.styleSheet) || function(e) {
                            const {
                                cssText: t
                            } = e;
                            if (t.split('"').length < 3) return t;
                            const n = ["@import", `url(${JSON.stringify(e.href)})`];
                            return "" === e.layerName ? n.push("layer") : e.layerName && n.push(`layer(${e.layerName})`), e.supportsText && n.push(`supports(${e.supportsText})`), e.media.length && n.push(e.media.mediaText), n.join(" ") + ";"
                        }(e)
                    } catch (e) {} else if (function(e) {
                            return "selectorText" in e
                        }(e) && e.selectorText.includes(":")) return function(e) {
                        const t = /(\[(?:[\w-]+)[^\\])(:(?:[\w-]+)\])/gm;
                        return e.replace(t, "$1\\$2")
                    }(e.cssText);
                    return t || e.cssText
                }! function(e) {
                    e[e.Document = 0] = "Document", e[e.DocumentType = 1] = "DocumentType", e[e.Element = 2] = "Element", e[e.Text = 3] = "Text", e[e.CDATA = 4] = "CDATA", e[e.Comment = 5] = "Comment"
                }(Wn || (Wn = {}));
                class Xn {
                    constructor() {
                        this.idNodeMap = new Map, this.nodeMetaMap = new WeakMap
                    }
                    getId(e) {
                        if (!e) return -1;
                        return Hn($n([this, "access", e => e.getMeta, "call", t => t(e), "optionalAccess", e => e.id]), (() => -1))
                    }
                    getNode(e) {
                        return this.idNodeMap.get(e) || null
                    }
                    getIds() {
                        return Array.from(this.idNodeMap.keys())
                    }
                    getMeta(e) {
                        return this.nodeMetaMap.get(e) || null
                    }
                    removeNodeFromMap(e) {
                        const t = this.getId(e);
                        this.idNodeMap.delete(t), e.childNodes && e.childNodes.forEach((e => this.removeNodeFromMap(e)))
                    }
                    has(e) {
                        return this.idNodeMap.has(e)
                    }
                    hasNode(e) {
                        return this.nodeMetaMap.has(e)
                    }
                    add(e, t) {
                        const n = t.id;
                        this.idNodeMap.set(n, e), this.nodeMetaMap.set(e, t)
                    }
                    replace(e, t) {
                        const n = this.getNode(e);
                        if (n) {
                            const e = this.nodeMetaMap.get(n);
                            e && this.nodeMetaMap.set(t, e)
                        }
                        this.idNodeMap.set(e, t)
                    }
                    reset() {
                        this.idNodeMap = new Map, this.nodeMetaMap = new WeakMap
                    }
                }

                function Yn({
                    maskInputOptions: e,
                    tagName: t,
                    type: n
                }) {
                    return "OPTION" === t && (t = "SELECT"), Boolean(e[t.toLowerCase()] || n && e[n] || "password" === n || "INPUT" === t && !n && e.text)
                }

                function Gn({
                    isMasked: e,
                    element: t,
                    value: n,
                    maskInputFn: r
                }) {
                    let o = n || "";
                    return e ? (r && (o = r(o, t)), "*".repeat(o.length)) : o
                }

                function Qn(e) {
                    return e.toLowerCase()
                }

                function Zn(e) {
                    return e.toUpperCase()
                }
                const er = "__rrweb_original__";

                function tr(e) {
                    const t = e.type;
                    return e.hasAttribute("data-rr-is-password") ? "password" : t ? Qn(t) : null
                }

                function nr(e, t, n) {
                    return "INPUT" !== t || "radio" !== n && "checkbox" !== n ? e.value : e.getAttribute("value") || ""
                }

                function rr(e, t) {
                    let n;
                    try {
                        n = new URL(e, Hn(t, (() => window.location.href)))
                    } catch (e) {
                        return null
                    }
                    return Hn($n([n.pathname.match(/\.([0-9a-z]+)(?:$)/i), "optionalAccess", e => e[1]]), (() => null))
                }
                const or = {};

                function sr(e) {
                    const t = or[e];
                    if (t) return t;
                    const n = window.document;
                    let r = window[e];
                    if (n && "function" == typeof n.createElement) try {
                        const t = n.createElement("iframe");
                        t.hidden = !0, n.head.appendChild(t);
                        const o = t.contentWindow;
                        o && o[e] && (r = o[e]), n.head.removeChild(t)
                    } catch (e) {}
                    return or[e] = r.bind(window)
                }

                function ir(...e) {
                    return sr("setTimeout")(...e)
                }

                function ar(...e) {
                    return sr("clearTimeout")(...e)
                }
                let cr = 1;
                const ur = new RegExp("[^a-z0-9-_:]");

                function lr() {
                    return cr++
                }
                let dr, pr;
                const hr = /url\((?:(')([^']*)'|(")(.*?)"|([^)]*))\)/gm,
                    fr = /^(?:[a-z+]+:)?\/\//i,
                    mr = /^www\..*/i,
                    gr = /^(data:)([^,]*),(.*)/i;

                function _r(e, t) {
                    return (e || "").replace(hr, ((e, n, r, o, s, i) => {
                        const a = r || s || i,
                            c = n || o || "";
                        if (!a) return e;
                        if (fr.test(a) || mr.test(a)) return `url(${c}${a}${c})`;
                        if (gr.test(a)) return `url(${c}${a}${c})`;
                        if ("/" === a[0]) return `url(${c}${function(e){let t="";return t=e.indexOf("//")>-1?e.split("/").slice(0,3).join("/"):e.split("/")[0],t=t.split("?")[0],t}(t)+a}${c})`;
                        const u = t.split("/"),
                            l = a.split("/");
                        u.pop();
                        for (const e of l) "." !== e && (".." === e ? u.pop() : u.push(e));
                        return `url(${c}${u.join("/")}${c})`
                    }))
                }
                const yr = /^[^ \t\n\r\u000c]+/,
                    vr = /^[, \t\n\r\u000c]+/;

                function br(e, t) {
                    if (!t || "" === t.trim()) return t;
                    const n = e.createElement("a");
                    return n.href = t, n.href
                }

                function Sr(e) {
                    return Boolean("svg" === e.tagName || e.ownerSVGElement)
                }

                function wr() {
                    const e = document.createElement("a");
                    return e.href = "", e.href
                }

                function kr(e, t, n, r, o, s) {
                    return r ? "src" === n || "href" === n && ("use" !== t || "#" !== r[0]) || "xlink:href" === n && "#" !== r[0] ? br(e, r) : "background" !== n || "table" !== t && "td" !== t && "th" !== t ? "srcset" === n ? function(e, t) {
                        if ("" === t.trim()) return t;
                        let n = 0;

                        function r(e) {
                            let r;
                            const o = e.exec(t.substring(n));
                            return o ? (r = o[0], n += r.length, r) : ""
                        }
                        const o = [];
                        for (; r(vr), !(n >= t.length);) {
                            let s = r(yr);
                            if ("," === s.slice(-1)) s = br(e, s.substring(0, s.length - 1)), o.push(s);
                            else {
                                let r = "";
                                s = br(e, s);
                                let i = !1;
                                for (;;) {
                                    const e = t.charAt(n);
                                    if ("" === e) {
                                        o.push((s + r).trim());
                                        break
                                    }
                                    if (i) ")" === e && (i = !1);
                                    else {
                                        if ("," === e) {
                                            n += 1, o.push((s + r).trim());
                                            break
                                        }
                                        "(" === e && (i = !0)
                                    }
                                    r += e, n += 1
                                }
                            }
                        }
                        return o.join(", ")
                    }(e, r) : "style" === n ? _r(r, wr()) : "object" === t && "data" === n ? br(e, r) : "function" == typeof s ? s(n, r, o) : r : br(e, r) : r
                }

                function Cr(e, t, n) {
                    return ("video" === e || "audio" === e) && "autoplay" === t
                }

                function xr(e, t, n = 1 / 0, r = 0) {
                    return e ? e.nodeType !== e.ELEMENT_NODE || r > n ? -1 : t(e) ? r : xr(e.parentNode, t, n, r + 1) : -1
                }

                function Tr(e, t) {
                    return n => {
                        const r = n;
                        if (null === r) return !1;
                        try {
                            if (e)
                                if ("string" == typeof e) {
                                    if (r.matches(`.${e}`)) return !0
                                } else if (function(e, t) {
                                    for (let n = e.classList.length; n--;) {
                                        const r = e.classList[n];
                                        if (t.test(r)) return !0
                                    }
                                    return !1
                                }(r, e)) return !0;
                            return !(!t || !r.matches(t))
                        } catch (e) {
                            return !1
                        }
                    }
                }

                function Ir(e, t, n, r, o, s) {
                    try {
                        const i = e.nodeType === e.ELEMENT_NODE ? e : e.parentElement;
                        if (null === i) return !1;
                        if ("INPUT" === i.tagName) {
                            const e = i.getAttribute("autocomplete");
                            if (["current-password", "new-password", "cc-number", "cc-exp", "cc-exp-month", "cc-exp-year", "cc-csc"].includes(e)) return !0
                        }
                        let a = -1,
                            c = -1;
                        if (s) {
                            if (c = xr(i, Tr(r, o)), c < 0) return !0;
                            a = xr(i, Tr(t, n), c >= 0 ? c : 1 / 0)
                        } else {
                            if (a = xr(i, Tr(t, n)), a < 0) return !1;
                            c = xr(i, Tr(r, o), a >= 0 ? a : 1 / 0)
                        }
                        return a >= 0 ? !(c >= 0) || a <= c : !(c >= 0) && !!s
                    } catch (e) {}
                    return !!s
                }

                function Er(e, t) {
                    const {
                        doc: n,
                        mirror: r,
                        blockClass: o,
                        blockSelector: s,
                        unblockSelector: i,
                        maskAllText: a,
                        maskAttributeFn: c,
                        maskTextClass: u,
                        unmaskTextClass: l,
                        maskTextSelector: d,
                        unmaskTextSelector: p,
                        inlineStylesheet: h,
                        maskInputOptions: f = {},
                        maskTextFn: m,
                        maskInputFn: g,
                        dataURLOptions: _ = {},
                        inlineImages: y,
                        recordCanvas: v,
                        keepIframeSrcFn: b,
                        newlyAddedElement: S = !1
                    } = t, w = function(e, t) {
                        if (!t.hasNode(e)) return;
                        const n = t.getId(e);
                        return 1 === n ? void 0 : n
                    }(n, r);
                    switch (e.nodeType) {
                        case e.DOCUMENT_NODE:
                            return "CSS1Compat" !== e.compatMode ? {
                                type: Wn.Document,
                                childNodes: [],
                                compatMode: e.compatMode
                            } : {
                                type: Wn.Document,
                                childNodes: []
                            };
                        case e.DOCUMENT_TYPE_NODE:
                            return {
                                type: Wn.DocumentType,
                                name: e.name,
                                publicId: e.publicId,
                                systemId: e.systemId,
                                rootId: w
                            };
                        case e.ELEMENT_NODE:
                            return function(e, t) {
                                const {
                                    doc: n,
                                    blockClass: r,
                                    blockSelector: o,
                                    unblockSelector: s,
                                    inlineStylesheet: i,
                                    maskInputOptions: a = {},
                                    maskAttributeFn: c,
                                    maskInputFn: u,
                                    dataURLOptions: l = {},
                                    inlineImages: d,
                                    recordCanvas: p,
                                    keepIframeSrcFn: h,
                                    newlyAddedElement: f = !1,
                                    rootId: m,
                                    maskAllText: g,
                                    maskTextClass: _,
                                    unmaskTextClass: y,
                                    maskTextSelector: v,
                                    unmaskTextSelector: b
                                } = t, S = function(e, t, n, r) {
                                    try {
                                        if (r && e.matches(r)) return !1;
                                        if ("string" == typeof t) {
                                            if (e.classList.contains(t)) return !0
                                        } else
                                            for (let n = e.classList.length; n--;) {
                                                const r = e.classList[n];
                                                if (t.test(r)) return !0
                                            }
                                        if (n) return e.matches(n)
                                    } catch (e) {}
                                    return !1
                                }(e, r, o, s), w = function(e) {
                                    if (e instanceof HTMLFormElement) return "form";
                                    const t = Qn(e.tagName);
                                    return ur.test(t) ? "div" : t
                                }(e);
                                let k = {};
                                const C = e.attributes.length;
                                for (let t = 0; t < C; t++) {
                                    const r = e.attributes[t];
                                    r.name && !Cr(w, r.name, r.value) && (k[r.name] = kr(n, w, Qn(r.name), r.value, e, c))
                                }
                                if ("link" === w && i) {
                                    const t = Array.from(n.styleSheets).find((t => t.href === e.href));
                                    let r = null;
                                    t && (r = Kn(t)), r && (delete k.rel, delete k.href, k._cssText = _r(r, t.href))
                                }
                                if ("style" === w && e.sheet && !(e.innerText || e.textContent || "").trim().length) {
                                    const t = Kn(e.sheet);
                                    t && (k._cssText = _r(t, wr()))
                                }
                                if ("input" === w || "textarea" === w || "select" === w || "option" === w) {
                                    const t = e,
                                        n = tr(t),
                                        r = nr(t, Zn(w), n),
                                        o = t.checked;
                                    if ("submit" !== n && "button" !== n && r) {
                                        const e = Ir(t, _, v, y, b, Yn({
                                            type: n,
                                            tagName: Zn(w),
                                            maskInputOptions: a
                                        }));
                                        k.value = Gn({
                                            isMasked: e,
                                            element: t,
                                            value: r,
                                            maskInputFn: u
                                        })
                                    }
                                    o && (k.checked = o)
                                }
                                "option" === w && (e.selected && !a.select ? k.selected = !0 : delete k.selected);
                                if ("canvas" === w && p)
                                    if ("2d" === e.__context)(function(e) {
                                        const t = e.getContext("2d");
                                        if (!t) return !0;
                                        for (let n = 0; n < e.width; n += 50)
                                            for (let r = 0; r < e.height; r += 50) {
                                                const o = t.getImageData,
                                                    s = er in o ? o[er] : o;
                                                if (new Uint32Array(s.call(t, n, r, Math.min(50, e.width - n), Math.min(50, e.height - r)).data.buffer).some((e => 0 !== e))) return !1
                                            }
                                        return !0
                                    })(e) || (k.rr_dataURL = e.toDataURL(l.type, l.quality));
                                    else if (!("__context" in e)) {
                                    const t = e.toDataURL(l.type, l.quality),
                                        n = document.createElement("canvas");
                                    n.width = e.width, n.height = e.height;
                                    t !== n.toDataURL(l.type, l.quality) && (k.rr_dataURL = t)
                                }
                                if ("img" === w && d) {
                                    dr || (dr = n.createElement("canvas"), pr = dr.getContext("2d"));
                                    const t = e,
                                        r = t.crossOrigin;
                                    t.crossOrigin = "anonymous";
                                    const o = () => {
                                        t.removeEventListener("load", o);
                                        try {
                                            dr.width = t.naturalWidth, dr.height = t.naturalHeight, pr.drawImage(t, 0, 0), k.rr_dataURL = dr.toDataURL(l.type, l.quality)
                                        } catch (e) {
                                            console.warn(`Cannot inline img src=${t.currentSrc}! Error: ${e}`)
                                        }
                                        r ? k.crossOrigin = r : t.removeAttribute("crossorigin")
                                    };
                                    t.complete && 0 !== t.naturalWidth ? o() : t.addEventListener("load", o)
                                }
                                "audio" !== w && "video" !== w || (k.rr_mediaState = e.paused ? "paused" : "played", k.rr_mediaCurrentTime = e.currentTime);
                                f || (e.scrollLeft && (k.rr_scrollLeft = e.scrollLeft), e.scrollTop && (k.rr_scrollTop = e.scrollTop));
                                if (S) {
                                    const {
                                        width: t,
                                        height: n
                                    } = e.getBoundingClientRect();
                                    k = {
                                        class: k.class,
                                        rr_width: `${t}px`,
                                        rr_height: `${n}px`
                                    }
                                }
                                "iframe" !== w || h(k.src) || (S || e.contentDocument || (k.rr_src = k.src), delete k.src);
                                let x;
                                try {
                                    customElements.get(w) && (x = !0)
                                } catch (e) {}
                                return {
                                    type: Wn.Element,
                                    tagName: w,
                                    attributes: k,
                                    childNodes: [],
                                    isSVG: Sr(e) || void 0,
                                    needBlock: S,
                                    rootId: m,
                                    isCustom: x
                                }
                            }(e, {
                                doc: n,
                                blockClass: o,
                                blockSelector: s,
                                unblockSelector: i,
                                inlineStylesheet: h,
                                maskAttributeFn: c,
                                maskInputOptions: f,
                                maskInputFn: g,
                                dataURLOptions: _,
                                inlineImages: y,
                                recordCanvas: v,
                                keepIframeSrcFn: b,
                                newlyAddedElement: S,
                                rootId: w,
                                maskAllText: a,
                                maskTextClass: u,
                                unmaskTextClass: l,
                                maskTextSelector: d,
                                unmaskTextSelector: p
                            });
                        case e.TEXT_NODE:
                            return function(e, t) {
                                const {
                                    maskAllText: n,
                                    maskTextClass: r,
                                    unmaskTextClass: o,
                                    maskTextSelector: s,
                                    unmaskTextSelector: i,
                                    maskTextFn: a,
                                    maskInputOptions: c,
                                    maskInputFn: u,
                                    rootId: l
                                } = t, d = e.parentNode && e.parentNode.tagName;
                                let p = e.textContent;
                                const h = "STYLE" === d || void 0,
                                    f = "SCRIPT" === d || void 0,
                                    m = "TEXTAREA" === d || void 0;
                                if (h && p) {
                                    try {
                                        e.nextSibling || e.previousSibling || $n([e, "access", e => e.parentNode, "access", e => e.sheet, "optionalAccess", e => e.cssRules]) && (p = Kn(e.parentNode.sheet))
                                    } catch (t) {
                                        console.warn(`Cannot get CSS styles from text's parentNode. Error: ${t}`, e)
                                    }
                                    p = _r(p, wr())
                                }
                                f && (p = "SCRIPT_PLACEHOLDER");
                                const g = Ir(e, r, s, o, i, n);
                                h || f || m || !p || !g || (p = a ? a(p, e.parentElement) : p.replace(/[\S]/g, "*"));
                                m && p && (c.textarea || g) && (p = u ? u(p, e.parentNode) : p.replace(/[\S]/g, "*"));
                                if ("OPTION" === d && p) {
                                    p = Gn({
                                        isMasked: Ir(e, r, s, o, i, Yn({
                                            type: null,
                                            tagName: d,
                                            maskInputOptions: c
                                        })),
                                        element: e,
                                        value: p,
                                        maskInputFn: u
                                    })
                                }
                                return {
                                    type: Wn.Text,
                                    textContent: p || "",
                                    isStyle: h,
                                    rootId: l
                                }
                            }(e, {
                                maskAllText: a,
                                maskTextClass: u,
                                unmaskTextClass: l,
                                maskTextSelector: d,
                                unmaskTextSelector: p,
                                maskTextFn: m,
                                maskInputOptions: f,
                                maskInputFn: g,
                                rootId: w
                            });
                        case e.CDATA_SECTION_NODE:
                            return {
                                type: Wn.CDATA,
                                textContent: "",
                                rootId: w
                            };
                        case e.COMMENT_NODE:
                            return {
                                type: Wn.Comment,
                                textContent: e.textContent || "",
                                rootId: w
                            };
                        default:
                            return !1
                    }
                }

                function Mr(e) {
                    return null == e ? "" : e.toLowerCase()
                }

                function Rr(e, t) {
                    const {
                        doc: n,
                        mirror: r,
                        blockClass: o,
                        blockSelector: s,
                        unblockSelector: i,
                        maskAllText: a,
                        maskTextClass: c,
                        unmaskTextClass: u,
                        maskTextSelector: l,
                        unmaskTextSelector: d,
                        skipChild: p = !1,
                        inlineStylesheet: h = !0,
                        maskInputOptions: f = {},
                        maskAttributeFn: m,
                        maskTextFn: g,
                        maskInputFn: _,
                        slimDOMOptions: y,
                        dataURLOptions: v = {},
                        inlineImages: b = !1,
                        recordCanvas: S = !1,
                        onSerialize: w,
                        onIframeLoad: k,
                        iframeLoadTimeout: C = 5e3,
                        onStylesheetLoad: x,
                        stylesheetLoadTimeout: T = 5e3,
                        keepIframeSrcFn: I = () => !1,
                        newlyAddedElement: E = !1
                    } = t;
                    let {
                        preserveWhiteSpace: M = !0
                    } = t;
                    const R = Er(e, {
                        doc: n,
                        mirror: r,
                        blockClass: o,
                        blockSelector: s,
                        maskAllText: a,
                        unblockSelector: i,
                        maskTextClass: c,
                        unmaskTextClass: u,
                        maskTextSelector: l,
                        unmaskTextSelector: d,
                        inlineStylesheet: h,
                        maskInputOptions: f,
                        maskAttributeFn: m,
                        maskTextFn: g,
                        maskInputFn: _,
                        dataURLOptions: v,
                        inlineImages: b,
                        recordCanvas: S,
                        keepIframeSrcFn: I,
                        newlyAddedElement: E
                    });
                    if (!R) return console.warn(e, "not serialized"), null;
                    let A;
                    A = r.hasNode(e) ? r.getId(e) : ! function(e, t) {
                        if (t.comment && e.type === Wn.Comment) return !0;
                        if (e.type === Wn.Element) {
                            if (t.script && ("script" === e.tagName || "link" === e.tagName && ("preload" === e.attributes.rel || "modulepreload" === e.attributes.rel) && "script" === e.attributes.as || "link" === e.tagName && "prefetch" === e.attributes.rel && "string" == typeof e.attributes.href && "js" === rr(e.attributes.href))) return !0;
                            if (t.headFavicon && ("link" === e.tagName && "shortcut icon" === e.attributes.rel || "meta" === e.tagName && (Mr(e.attributes.name).match(/^msapplication-tile(image|color)$/) || "application-name" === Mr(e.attributes.name) || "icon" === Mr(e.attributes.rel) || "apple-touch-icon" === Mr(e.attributes.rel) || "shortcut icon" === Mr(e.attributes.rel)))) return !0;
                            if ("meta" === e.tagName) {
                                if (t.headMetaDescKeywords && Mr(e.attributes.name).match(/^description|keywords$/)) return !0;
                                if (t.headMetaSocial && (Mr(e.attributes.property).match(/^(og|twitter|fb):/) || Mr(e.attributes.name).match(/^(og|twitter):/) || "pinterest" === Mr(e.attributes.name))) return !0;
                                if (t.headMetaRobots && ("robots" === Mr(e.attributes.name) || "googlebot" === Mr(e.attributes.name) || "bingbot" === Mr(e.attributes.name))) return !0;
                                if (t.headMetaHttpEquiv && void 0 !== e.attributes["http-equiv"]) return !0;
                                if (t.headMetaAuthorship && ("author" === Mr(e.attributes.name) || "generator" === Mr(e.attributes.name) || "framework" === Mr(e.attributes.name) || "publisher" === Mr(e.attributes.name) || "progid" === Mr(e.attributes.name) || Mr(e.attributes.property).match(/^article:/) || Mr(e.attributes.property).match(/^product:/))) return !0;
                                if (t.headMetaVerification && ("google-site-verification" === Mr(e.attributes.name) || "yandex-verification" === Mr(e.attributes.name) || "csrf-token" === Mr(e.attributes.name) || "p:domain_verify" === Mr(e.attributes.name) || "verify-v1" === Mr(e.attributes.name) || "verification" === Mr(e.attributes.name) || "shopify-checkout-api-token" === Mr(e.attributes.name))) return !0
                            }
                        }
                        return !1
                    }(R, y) && (M || R.type !== Wn.Text || R.isStyle || R.textContent.replace(/^\s+|\s+$/gm, "").length) ? lr() : -2;
                    const N = Object.assign(R, {
                        id: A
                    });
                    if (r.add(e, N), -2 === A) return null;
                    w && w(e);
                    let L = !p;
                    if (N.type === Wn.Element) {
                        L = L && !N.needBlock, delete N.needBlock;
                        const t = e.shadowRoot;
                        t && Jn(t) && (N.isShadowHost = !0)
                    }
                    if ((N.type === Wn.Document || N.type === Wn.Element) && L) {
                        y.headWhitespace && N.type === Wn.Element && "head" === N.tagName && (M = !1);
                        const t = {
                            doc: n,
                            mirror: r,
                            blockClass: o,
                            blockSelector: s,
                            maskAllText: a,
                            unblockSelector: i,
                            maskTextClass: c,
                            unmaskTextClass: u,
                            maskTextSelector: l,
                            unmaskTextSelector: d,
                            skipChild: p,
                            inlineStylesheet: h,
                            maskInputOptions: f,
                            maskAttributeFn: m,
                            maskTextFn: g,
                            maskInputFn: _,
                            slimDOMOptions: y,
                            dataURLOptions: v,
                            inlineImages: b,
                            recordCanvas: S,
                            preserveWhiteSpace: M,
                            onSerialize: w,
                            onIframeLoad: k,
                            iframeLoadTimeout: C,
                            onStylesheetLoad: x,
                            stylesheetLoadTimeout: T,
                            keepIframeSrcFn: I
                        };
                        for (const n of Array.from(e.childNodes)) {
                            const e = Rr(n, t);
                            e && N.childNodes.push(e)
                        }
                        if (function(e) {
                                return e.nodeType === e.ELEMENT_NODE
                            }(e) && e.shadowRoot)
                            for (const n of Array.from(e.shadowRoot.childNodes)) {
                                const r = Rr(n, t);
                                r && (Jn(e.shadowRoot) && (r.isShadow = !0), N.childNodes.push(r))
                            }
                    }
                    return e.parentNode && qn(e.parentNode) && Jn(e.parentNode) && (N.isShadow = !0), N.type === Wn.Element && "iframe" === N.tagName && function(e, t, n) {
                        const r = e.contentWindow;
                        if (!r) return;
                        let o, s = !1;
                        try {
                            o = r.document.readyState
                        } catch (e) {
                            return
                        }
                        if ("complete" !== o) {
                            const r = ir((() => {
                                s || (t(), s = !0)
                            }), n);
                            return void e.addEventListener("load", (() => {
                                ar(r), s = !0, t()
                            }))
                        }
                        const i = "about:blank";
                        if (r.location.href !== i || e.src === i || "" === e.src) return ir(t, 0), e.addEventListener("load", t);
                        e.addEventListener("load", t)
                    }(e, (() => {
                        const t = e.contentDocument;
                        if (t && k) {
                            const n = Rr(t, {
                                doc: t,
                                mirror: r,
                                blockClass: o,
                                blockSelector: s,
                                unblockSelector: i,
                                maskAllText: a,
                                maskTextClass: c,
                                unmaskTextClass: u,
                                maskTextSelector: l,
                                unmaskTextSelector: d,
                                skipChild: !1,
                                inlineStylesheet: h,
                                maskInputOptions: f,
                                maskAttributeFn: m,
                                maskTextFn: g,
                                maskInputFn: _,
                                slimDOMOptions: y,
                                dataURLOptions: v,
                                inlineImages: b,
                                recordCanvas: S,
                                preserveWhiteSpace: M,
                                onSerialize: w,
                                onIframeLoad: k,
                                iframeLoadTimeout: C,
                                onStylesheetLoad: x,
                                stylesheetLoadTimeout: T,
                                keepIframeSrcFn: I
                            });
                            n && k(e, n)
                        }
                    }), C), N.type === Wn.Element && "link" === N.tagName && "string" == typeof N.attributes.rel && ("stylesheet" === N.attributes.rel || "preload" === N.attributes.rel && "string" == typeof N.attributes.href && "css" === rr(N.attributes.href)) && function(e, t, n) {
                        let r, o = !1;
                        try {
                            r = e.sheet
                        } catch (e) {
                            return
                        }
                        if (r) return;
                        const s = ir((() => {
                            o || (t(), o = !0)
                        }), n);
                        e.addEventListener("load", (() => {
                            ar(s), o = !0, t()
                        }))
                    }(e, (() => {
                        if (x) {
                            const t = Rr(e, {
                                doc: n,
                                mirror: r,
                                blockClass: o,
                                blockSelector: s,
                                unblockSelector: i,
                                maskAllText: a,
                                maskTextClass: c,
                                unmaskTextClass: u,
                                maskTextSelector: l,
                                unmaskTextSelector: d,
                                skipChild: !1,
                                inlineStylesheet: h,
                                maskInputOptions: f,
                                maskAttributeFn: m,
                                maskTextFn: g,
                                maskInputFn: _,
                                slimDOMOptions: y,
                                dataURLOptions: v,
                                inlineImages: b,
                                recordCanvas: S,
                                preserveWhiteSpace: M,
                                onSerialize: w,
                                onIframeLoad: k,
                                iframeLoadTimeout: C,
                                onStylesheetLoad: x,
                                stylesheetLoadTimeout: T,
                                keepIframeSrcFn: I
                            });
                            t && x(e, t)
                        }
                    }), T), N
                }

                function Ar(e) {
                    let t, n = e[0],
                        r = 1;
                    for (; r < e.length;) {
                        const o = e[r],
                            s = e[r + 1];
                        if (r += 2, ("optionalAccess" === o || "optionalCall" === o) && null == n) return;
                        "access" === o || "optionalAccess" === o ? (t = n, n = s(n)) : "call" !== o && "optionalCall" !== o || (n = s(((...e) => n.call(t, ...e))), t = void 0)
                    }
                    return n
                }

                function Nr(e, t, n = document) {
                    const r = {
                        capture: !0,
                        passive: !0
                    };
                    return n.addEventListener(e, t, r), () => n.removeEventListener(e, t, r)
                }
                const Lr = "Please stop import mirror directly. Instead of that,\r\nnow you can use replayer.getMirror() to access the mirror instance of a replayer,\r\nor you can use record.mirror to access the mirror instance during recording.";
                let Dr = {
                    map: {},
                    getId() {
                        return console.error(Lr), -1
                    },
                    getNode() {
                        return console.error(Lr), null
                    },
                    removeNodeFromMap() {
                        console.error(Lr)
                    },
                    has() {
                        return console.error(Lr), !1
                    },
                    reset() {
                        console.error(Lr)
                    }
                };

                function Or(e, t, n = {}) {
                    let r = null,
                        o = 0;
                    return function(...s) {
                        const i = Date.now();
                        o || !1 !== n.leading || (o = i);
                        const a = t - (i - o),
                            c = this;
                        a <= 0 || a > t ? (r && (! function(...e) {
                            to("clearTimeout")(...e)
                        }(r), r = null), o = i, e.apply(c, s)) : r || !1 === n.trailing || (r = no((() => {
                            o = !1 === n.leading ? 0 : Date.now(), r = null, e.apply(c, s)
                        }), a))
                    }
                }

                function Fr(e, t, n, r, o = window) {
                    const s = o.Object.getOwnPropertyDescriptor(e, t);
                    return o.Object.defineProperty(e, t, r ? n : {
                        set(e) {
                            no((() => {
                                n.set.call(this, e)
                            }), 0), s && s.set && s.set.call(this, e)
                        }
                    }), () => Fr(e, t, s || {}, !0)
                }

                function Pr(e, t, n) {
                    try {
                        if (!(t in e)) return () => {};
                        const r = e[t],
                            o = n(r);
                        return "function" == typeof o && (o.prototype = o.prototype || {}, Object.defineProperties(o, {
                            __rrweb_original__: {
                                enumerable: !1,
                                value: r
                            }
                        })), e[t] = o, () => {
                            e[t] = r
                        }
                    } catch (e) {
                        return () => {}
                    }
                }
                "undefined" != typeof window && window.Proxy && window.Reflect && (Dr = new Proxy(Dr, {
                    get(e, t, n) {
                        return "map" === t && console.error(Lr), Reflect.get(e, t, n)
                    }
                }));
                let Br = Date.now;

                function Ur(e) {
                    const t = e.document;
                    return {
                        left: t.scrollingElement ? t.scrollingElement.scrollLeft : void 0 !== e.pageXOffset ? e.pageXOffset : Ar([t, "optionalAccess", e => e.documentElement, "access", e => e.scrollLeft]) || Ar([t, "optionalAccess", e => e.body, "optionalAccess", e => e.parentElement, "optionalAccess", e => e.scrollLeft]) || Ar([t, "optionalAccess", e => e.body, "optionalAccess", e => e.scrollLeft]) || 0,
                        top: t.scrollingElement ? t.scrollingElement.scrollTop : void 0 !== e.pageYOffset ? e.pageYOffset : Ar([t, "optionalAccess", e => e.documentElement, "access", e => e.scrollTop]) || Ar([t, "optionalAccess", e => e.body, "optionalAccess", e => e.parentElement, "optionalAccess", e => e.scrollTop]) || Ar([t, "optionalAccess", e => e.body, "optionalAccess", e => e.scrollTop]) || 0
                    }
                }

                function jr() {
                    return window.innerHeight || document.documentElement && document.documentElement.clientHeight || document.body && document.body.clientHeight
                }

                function zr() {
                    return window.innerWidth || document.documentElement && document.documentElement.clientWidth || document.body && document.body.clientWidth
                }

                function Hr(e) {
                    if (!e) return null;
                    return e.nodeType === e.ELEMENT_NODE ? e : e.parentElement
                }

                function $r(e, t, n, r, o) {
                    if (!e) return !1;
                    const s = Hr(e);
                    if (!s) return !1;
                    const i = Tr(t, n);
                    if (!o) {
                        const e = r && s.matches(r);
                        return i(s) && !e
                    }
                    const a = xr(s, i);
                    let c = -1;
                    return !(a < 0) && (r && (c = xr(s, Tr(null, r))), a > -1 && c < 0 || a < c)
                }

                function Wr(e, t) {
                    return -2 === t.getId(e)
                }

                function qr(e, t) {
                    if (qn(e)) return !1;
                    const n = t.getId(e);
                    return !t.has(n) || (!e.parentNode || e.parentNode.nodeType !== e.DOCUMENT_NODE) && (!e.parentNode || qr(e.parentNode, t))
                }

                function Jr(e) {
                    return Boolean(e.changedTouches)
                }

                function Kr(e, t) {
                    return Boolean("IFRAME" === e.nodeName && t.getMeta(e))
                }

                function Vr(e, t) {
                    return Boolean("LINK" === e.nodeName && e.nodeType === e.ELEMENT_NODE && e.getAttribute && "stylesheet" === e.getAttribute("rel") && t.getMeta(e))
                }

                function Xr(e) {
                    return Boolean(Ar([e, "optionalAccess", e => e.shadowRoot]))
                }
                /[1-9][0-9]{12}/.test(Date.now().toString()) || (Br = () => (new Date).getTime());
                class Yr {
                    constructor() {
                        this.id = 1, this.styleIDMap = new WeakMap, this.idStyleMap = new Map
                    }
                    getId(e) {
                        return t = this.styleIDMap.get(e), n = () => -1, null != t ? t : n();
                        var t, n
                    }
                    has(e) {
                        return this.styleIDMap.has(e)
                    }
                    add(e, t) {
                        if (this.has(e)) return this.getId(e);
                        let n;
                        return n = void 0 === t ? this.id++ : t, this.styleIDMap.set(e, n), this.idStyleMap.set(n, e), n
                    }
                    getStyle(e) {
                        return this.idStyleMap.get(e) || null
                    }
                    reset() {
                        this.styleIDMap = new WeakMap, this.idStyleMap = new Map, this.id = 1
                    }
                    generateId() {
                        return this.id++
                    }
                }

                function Gr(e) {
                    let t = null;
                    return Ar([e, "access", e => e.getRootNode, "optionalCall", e => e(), "optionalAccess", e => e.nodeType]) === Node.DOCUMENT_FRAGMENT_NODE && e.getRootNode().host && (t = e.getRootNode().host), t
                }

                function Qr(e) {
                    const t = e.ownerDocument;
                    if (!t) return !1;
                    const n = function(e) {
                        let t, n = e;
                        for (; t = Gr(n);) n = t;
                        return n
                    }(e);
                    return t.contains(n)
                }

                function Zr(e) {
                    const t = e.ownerDocument;
                    return !!t && (t.contains(e) || Qr(e))
                }
                const eo = {};

                function to(e) {
                    const t = eo[e];
                    if (t) return t;
                    const n = window.document;
                    let r = window[e];
                    if (n && "function" == typeof n.createElement) try {
                        const t = n.createElement("iframe");
                        t.hidden = !0, n.head.appendChild(t);
                        const o = t.contentWindow;
                        o && o[e] && (r = o[e]), n.head.removeChild(t)
                    } catch (e) {}
                    return eo[e] = r.bind(window)
                }

                function no(...e) {
                    return to("setTimeout")(...e)
                }
                var ro = (e => (e[e.DomContentLoaded = 0] = "DomContentLoaded", e[e.Load = 1] = "Load", e[e.FullSnapshot = 2] = "FullSnapshot", e[e.IncrementalSnapshot = 3] = "IncrementalSnapshot", e[e.Meta = 4] = "Meta", e[e.Custom = 5] = "Custom", e[e.Plugin = 6] = "Plugin", e))(ro || {}),
                    oo = (e => (e[e.Mutation = 0] = "Mutation", e[e.MouseMove = 1] = "MouseMove", e[e.MouseInteraction = 2] = "MouseInteraction", e[e.Scroll = 3] = "Scroll", e[e.ViewportResize = 4] = "ViewportResize", e[e.Input = 5] = "Input", e[e.TouchMove = 6] = "TouchMove", e[e.MediaInteraction = 7] = "MediaInteraction", e[e.StyleSheetRule = 8] = "StyleSheetRule", e[e.CanvasMutation = 9] = "CanvasMutation", e[e.Font = 10] = "Font", e[e.Log = 11] = "Log", e[e.Drag = 12] = "Drag", e[e.StyleDeclaration = 13] = "StyleDeclaration", e[e.Selection = 14] = "Selection", e[e.AdoptedStyleSheet = 15] = "AdoptedStyleSheet", e[e.CustomElement = 16] = "CustomElement", e))(oo || {}),
                    so = (e => (e[e.MouseUp = 0] = "MouseUp", e[e.MouseDown = 1] = "MouseDown", e[e.Click = 2] = "Click", e[e.ContextMenu = 3] = "ContextMenu", e[e.DblClick = 4] = "DblClick", e[e.Focus = 5] = "Focus", e[e.Blur = 6] = "Blur", e[e.TouchStart = 7] = "TouchStart", e[e.TouchMove_Departed = 8] = "TouchMove_Departed", e[e.TouchEnd = 9] = "TouchEnd", e[e.TouchCancel = 10] = "TouchCancel", e))(so || {}),
                    io = (e => (e[e.Mouse = 0] = "Mouse", e[e.Pen = 1] = "Pen", e[e.Touch = 2] = "Touch", e))(io || {});

                function ao(e) {
                    let t, n = e[0],
                        r = 1;
                    for (; r < e.length;) {
                        const o = e[r],
                            s = e[r + 1];
                        if (r += 2, ("optionalAccess" === o || "optionalCall" === o) && null == n) return;
                        "access" === o || "optionalAccess" === o ? (t = n, n = s(n)) : "call" !== o && "optionalCall" !== o || (n = s(((...e) => n.call(t, ...e))), t = void 0)
                    }
                    return n
                }

                function co(e) {
                    return "__ln" in e
                }
                class uo {
                    constructor() {
                        this.length = 0, this.head = null, this.tail = null
                    }
                    get(e) {
                        if (e >= this.length) throw new Error("Position outside of list range");
                        let t = this.head;
                        for (let n = 0; n < e; n++) t = ao([t, "optionalAccess", e => e.next]) || null;
                        return t
                    }
                    addNode(e) {
                        const t = {
                            value: e,
                            previous: null,
                            next: null
                        };
                        if (e.__ln = t, e.previousSibling && co(e.previousSibling)) {
                            const n = e.previousSibling.__ln.next;
                            t.next = n, t.previous = e.previousSibling.__ln, e.previousSibling.__ln.next = t, n && (n.previous = t)
                        } else if (e.nextSibling && co(e.nextSibling) && e.nextSibling.__ln.previous) {
                            const n = e.nextSibling.__ln.previous;
                            t.previous = n, t.next = e.nextSibling.__ln, e.nextSibling.__ln.previous = t, n && (n.next = t)
                        } else this.head && (this.head.previous = t), t.next = this.head, this.head = t;
                        null === t.next && (this.tail = t), this.length++
                    }
                    removeNode(e) {
                        const t = e.__ln;
                        this.head && (t.previous ? (t.previous.next = t.next, t.next ? t.next.previous = t.previous : this.tail = t.previous) : (this.head = t.next, this.head ? this.head.previous = null : this.tail = null), e.__ln && delete e.__ln, this.length--)
                    }
                }
                const lo = (e, t) => `${e}@${t}`;
                class po {
                    constructor() {
                        this.frozen = !1, this.locked = !1, this.texts = [], this.attributes = [], this.attributeMap = new WeakMap, this.removes = [], this.mapRemoves = [], this.movedMap = {}, this.addedSet = new Set, this.movedSet = new Set, this.droppedSet = new Set, this.processMutations = e => {
                            e.forEach(this.processMutation), this.emit()
                        }, this.emit = () => {
                            if (this.frozen || this.locked) return;
                            const e = [],
                                t = new Set,
                                n = new uo,
                                r = e => {
                                    let t = e,
                                        n = -2;
                                    for (; - 2 === n;) t = t && t.nextSibling, n = t && this.mirror.getId(t);
                                    return n
                                },
                                o = o => {
                                    if (!o.parentNode || !Zr(o)) return;
                                    const s = qn(o.parentNode) ? this.mirror.getId(Gr(o)) : this.mirror.getId(o.parentNode),
                                        i = r(o);
                                    if (-1 === s || -1 === i) return n.addNode(o);
                                    const a = Rr(o, {
                                        doc: this.doc,
                                        mirror: this.mirror,
                                        blockClass: this.blockClass,
                                        blockSelector: this.blockSelector,
                                        maskAllText: this.maskAllText,
                                        unblockSelector: this.unblockSelector,
                                        maskTextClass: this.maskTextClass,
                                        unmaskTextClass: this.unmaskTextClass,
                                        maskTextSelector: this.maskTextSelector,
                                        unmaskTextSelector: this.unmaskTextSelector,
                                        skipChild: !0,
                                        newlyAddedElement: !0,
                                        inlineStylesheet: this.inlineStylesheet,
                                        maskInputOptions: this.maskInputOptions,
                                        maskAttributeFn: this.maskAttributeFn,
                                        maskTextFn: this.maskTextFn,
                                        maskInputFn: this.maskInputFn,
                                        slimDOMOptions: this.slimDOMOptions,
                                        dataURLOptions: this.dataURLOptions,
                                        recordCanvas: this.recordCanvas,
                                        inlineImages: this.inlineImages,
                                        onSerialize: e => {
                                            Kr(e, this.mirror) && this.iframeManager.addIframe(e), Vr(e, this.mirror) && this.stylesheetManager.trackLinkElement(e), Xr(o) && this.shadowDomManager.addShadowRoot(o.shadowRoot, this.doc)
                                        },
                                        onIframeLoad: (e, t) => {
                                            this.iframeManager.attachIframe(e, t), e.contentWindow && this.canvasManager.addWindow(e.contentWindow), this.shadowDomManager.observeAttachShadow(e)
                                        },
                                        onStylesheetLoad: (e, t) => {
                                            this.stylesheetManager.attachLinkElement(e, t)
                                        }
                                    });
                                    a && (e.push({
                                        parentId: s,
                                        nextId: i,
                                        node: a
                                    }), t.add(a.id))
                                };
                            for (; this.mapRemoves.length;) this.mirror.removeNodeFromMap(this.mapRemoves.shift());
                            for (const e of this.movedSet) fo(this.removes, e, this.mirror) && !this.movedSet.has(e.parentNode) || o(e);
                            for (const e of this.addedSet) go(this.droppedSet, e) || fo(this.removes, e, this.mirror) ? go(this.movedSet, e) ? o(e) : this.droppedSet.add(e) : o(e);
                            let s = null;
                            for (; n.length;) {
                                let e = null;
                                if (s) {
                                    const t = this.mirror.getId(s.value.parentNode),
                                        n = r(s.value); - 1 !== t && -1 !== n && (e = s)
                                }
                                if (!e) {
                                    let t = n.tail;
                                    for (; t;) {
                                        const n = t;
                                        if (t = t.previous, n) {
                                            const t = this.mirror.getId(n.value.parentNode);
                                            if (-1 === r(n.value)) continue;
                                            if (-1 !== t) {
                                                e = n;
                                                break
                                            } {
                                                const t = n.value;
                                                if (t.parentNode && t.parentNode.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
                                                    const r = t.parentNode.host;
                                                    if (-1 !== this.mirror.getId(r)) {
                                                        e = n;
                                                        break
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if (!e) {
                                    for (; n.head;) n.removeNode(n.head.value);
                                    break
                                }
                                s = e.previous, n.removeNode(e.value), o(e.value)
                            }
                            const i = {
                                texts: this.texts.map((e => ({
                                    id: this.mirror.getId(e.node),
                                    value: e.value
                                }))).filter((e => !t.has(e.id))).filter((e => this.mirror.has(e.id))),
                                attributes: this.attributes.map((e => {
                                    const {
                                        attributes: t
                                    } = e;
                                    if ("string" == typeof t.style) {
                                        const n = JSON.stringify(e.styleDiff),
                                            r = JSON.stringify(e._unchangedStyles);
                                        n.length < t.style.length && (n + r).split("var(").length === t.style.split("var(").length && (t.style = e.styleDiff)
                                    }
                                    return {
                                        id: this.mirror.getId(e.node),
                                        attributes: t
                                    }
                                })).filter((e => !t.has(e.id))).filter((e => this.mirror.has(e.id))),
                                removes: this.removes,
                                adds: e
                            };
                            (i.texts.length || i.attributes.length || i.removes.length || i.adds.length) && (this.texts = [], this.attributes = [], this.attributeMap = new WeakMap, this.removes = [], this.addedSet = new Set, this.movedSet = new Set, this.droppedSet = new Set, this.movedMap = {}, this.mutationCb(i))
                        }, this.processMutation = e => {
                            if (!Wr(e.target, this.mirror)) switch (e.type) {
                                case "characterData":
                                    {
                                        const t = e.target.textContent;$r(e.target, this.blockClass, this.blockSelector, this.unblockSelector, !1) || t === e.oldValue || this.texts.push({
                                            value: Ir(e.target, this.maskTextClass, this.maskTextSelector, this.unmaskTextClass, this.unmaskTextSelector, this.maskAllText) && t ? this.maskTextFn ? this.maskTextFn(t, Hr(e.target)) : t.replace(/[\S]/g, "*") : t,
                                            node: e.target
                                        });
                                        break
                                    }
                                case "attributes":
                                    {
                                        const t = e.target;
                                        let n = e.attributeName,
                                            r = e.target.getAttribute(n);
                                        if ("value" === n) {
                                            const n = tr(t),
                                                o = t.tagName;
                                            r = nr(t, o, n);
                                            const s = Yn({
                                                maskInputOptions: this.maskInputOptions,
                                                tagName: o,
                                                type: n
                                            });
                                            r = Gn({
                                                isMasked: Ir(e.target, this.maskTextClass, this.maskTextSelector, this.unmaskTextClass, this.unmaskTextSelector, s),
                                                element: t,
                                                value: r,
                                                maskInputFn: this.maskInputFn
                                            })
                                        }
                                        if ($r(e.target, this.blockClass, this.blockSelector, this.unblockSelector, !1) || r === e.oldValue) return;
                                        let o = this.attributeMap.get(e.target);
                                        if ("IFRAME" === t.tagName && "src" === n && !this.keepIframeSrcFn(r)) {
                                            if (t.contentDocument) return;
                                            n = "rr_src"
                                        }
                                        if (o || (o = {
                                                node: e.target,
                                                attributes: {},
                                                styleDiff: {},
                                                _unchangedStyles: {}
                                            }, this.attributes.push(o), this.attributeMap.set(e.target, o)), "type" === n && "INPUT" === t.tagName && "password" === (e.oldValue || "").toLowerCase() && t.setAttribute("data-rr-is-password", "true"), !Cr(t.tagName, n) && (o.attributes[n] = kr(this.doc, Qn(t.tagName), Qn(n), r, t, this.maskAttributeFn), "style" === n)) {
                                            if (!this.unattachedDoc) try {
                                                this.unattachedDoc = document.implementation.createHTMLDocument()
                                            } catch (e) {
                                                this.unattachedDoc = this.doc
                                            }
                                            const n = this.unattachedDoc.createElement("span");
                                            e.oldValue && n.setAttribute("style", e.oldValue);
                                            for (const e of Array.from(t.style)) {
                                                const r = t.style.getPropertyValue(e),
                                                    s = t.style.getPropertyPriority(e);
                                                r !== n.style.getPropertyValue(e) || s !== n.style.getPropertyPriority(e) ? o.styleDiff[e] = "" === s ? r : [r, s] : o._unchangedStyles[e] = [r, s]
                                            }
                                            for (const e of Array.from(n.style)) "" === t.style.getPropertyValue(e) && (o.styleDiff[e] = !1)
                                        }
                                        break
                                    }
                                case "childList":
                                    if ($r(e.target, this.blockClass, this.blockSelector, this.unblockSelector, !0)) return;
                                    e.addedNodes.forEach((t => this.genAdds(t, e.target))), e.removedNodes.forEach((t => {
                                        const n = this.mirror.getId(t),
                                            r = qn(e.target) ? this.mirror.getId(e.target.host) : this.mirror.getId(e.target);
                                        $r(e.target, this.blockClass, this.blockSelector, this.unblockSelector, !1) || Wr(t, this.mirror) || ! function(e, t) {
                                            return -1 !== t.getId(e)
                                        }(t, this.mirror) || (this.addedSet.has(t) ? (ho(this.addedSet, t), this.droppedSet.add(t)) : this.addedSet.has(e.target) && -1 === n || qr(e.target, this.mirror) || (this.movedSet.has(t) && this.movedMap[lo(n, r)] ? ho(this.movedSet, t) : this.removes.push({
                                            parentId: r,
                                            id: n,
                                            isShadow: !(!qn(e.target) || !Jn(e.target)) || void 0
                                        })), this.mapRemoves.push(t))
                                    }))
                            }
                        }, this.genAdds = (e, t) => {
                            if (!this.processedNodeManager.inOtherBuffer(e, this) && !this.addedSet.has(e) && !this.movedSet.has(e)) {
                                if (this.mirror.hasNode(e)) {
                                    if (Wr(e, this.mirror)) return;
                                    this.movedSet.add(e);
                                    let n = null;
                                    t && this.mirror.hasNode(t) && (n = this.mirror.getId(t)), n && -1 !== n && (this.movedMap[lo(this.mirror.getId(e), n)] = !0)
                                } else this.addedSet.add(e), this.droppedSet.delete(e);
                                $r(e, this.blockClass, this.blockSelector, this.unblockSelector, !1) || (e.childNodes.forEach((e => this.genAdds(e))), Xr(e) && e.shadowRoot.childNodes.forEach((t => {
                                    this.processedNodeManager.add(t, this), this.genAdds(t, e)
                                })))
                            }
                        }
                    }
                    init(e) {
                        ["mutationCb", "blockClass", "blockSelector", "unblockSelector", "maskAllText", "maskTextClass", "unmaskTextClass", "maskTextSelector", "unmaskTextSelector", "inlineStylesheet", "maskInputOptions", "maskAttributeFn", "maskTextFn", "maskInputFn", "keepIframeSrcFn", "recordCanvas", "inlineImages", "slimDOMOptions", "dataURLOptions", "doc", "mirror", "iframeManager", "stylesheetManager", "shadowDomManager", "canvasManager", "processedNodeManager"].forEach((t => {
                            this[t] = e[t]
                        }))
                    }
                    freeze() {
                        this.frozen = !0, this.canvasManager.freeze()
                    }
                    unfreeze() {
                        this.frozen = !1, this.canvasManager.unfreeze(), this.emit()
                    }
                    isFrozen() {
                        return this.frozen
                    }
                    lock() {
                        this.locked = !0, this.canvasManager.lock()
                    }
                    unlock() {
                        this.locked = !1, this.canvasManager.unlock(), this.emit()
                    }
                    reset() {
                        this.shadowDomManager.reset(), this.canvasManager.reset()
                    }
                }

                function ho(e, t) {
                    e.delete(t), t.childNodes.forEach((t => ho(e, t)))
                }

                function fo(e, t, n) {
                    return 0 !== e.length && mo(e, t, n)
                }

                function mo(e, t, n) {
                    const {
                        parentNode: r
                    } = t;
                    if (!r) return !1;
                    const o = n.getId(r);
                    return !!e.some((e => e.id === o)) || mo(e, r, n)
                }

                function go(e, t) {
                    return 0 !== e.size && _o(e, t)
                }

                function _o(e, t) {
                    const {
                        parentNode: n
                    } = t;
                    return !!n && (!!e.has(n) || _o(e, n))
                }
                let yo;

                function vo(e) {
                    yo = e
                }

                function bo() {
                    yo = void 0
                }
                const So = e => {
                    if (!yo) return e;
                    return (...t) => {
                        try {
                            return e(...t)
                        } catch (e) {
                            if (yo && !0 === yo(e)) return () => {};
                            throw e
                        }
                    }
                };

                function wo(e) {
                    let t, n = e[0],
                        r = 1;
                    for (; r < e.length;) {
                        const o = e[r],
                            s = e[r + 1];
                        if (r += 2, ("optionalAccess" === o || "optionalCall" === o) && null == n) return;
                        "access" === o || "optionalAccess" === o ? (t = n, n = s(n)) : "call" !== o && "optionalCall" !== o || (n = s(((...e) => n.call(t, ...e))), t = void 0)
                    }
                    return n
                }
                const ko = [];

                function Co(e) {
                    try {
                        if ("composedPath" in e) {
                            const t = e.composedPath();
                            if (t.length) return t[0]
                        } else if ("path" in e && e.path.length) return e.path[0]
                    } catch (e) {}
                    return e && e.target
                }

                function xo(e, t) {
                    const n = new po;
                    ko.push(n), n.init(e);
                    let r = window.MutationObserver || window.__rrMutationObserver;
                    const o = wo([window, "optionalAccess", e => e.Zone, "optionalAccess", e => e.__symbol__, "optionalCall", e => e("MutationObserver")]);
                    o && window[o] && (r = window[o]);
                    const s = new r(So((t => {
                        e.onMutation && !1 === e.onMutation(t) || n.processMutations.bind(n)(t)
                    })));
                    return s.observe(t, {
                        attributes: !0,
                        attributeOldValue: !0,
                        characterData: !0,
                        characterDataOldValue: !0,
                        childList: !0,
                        subtree: !0
                    }), s
                }

                function To({
                    mouseInteractionCb: e,
                    doc: t,
                    mirror: n,
                    blockClass: r,
                    blockSelector: o,
                    unblockSelector: s,
                    sampling: i
                }) {
                    if (!1 === i.mouseInteraction) return () => {};
                    const a = !0 === i.mouseInteraction || void 0 === i.mouseInteraction ? {} : i.mouseInteraction,
                        c = [];
                    let u = null;
                    return Object.keys(so).filter((e => Number.isNaN(Number(e)) && !e.endsWith("_Departed") && !1 !== a[e])).forEach((i => {
                        let a = Qn(i);
                        const l = (t => i => {
                            const a = Co(i);
                            if ($r(a, r, o, s, !0)) return;
                            let c = null,
                                l = t;
                            if ("pointerType" in i) {
                                switch (i.pointerType) {
                                    case "mouse":
                                        c = io.Mouse;
                                        break;
                                    case "touch":
                                        c = io.Touch;
                                        break;
                                    case "pen":
                                        c = io.Pen
                                }
                                c === io.Touch ? so[t] === so.MouseDown ? l = "TouchStart" : so[t] === so.MouseUp && (l = "TouchEnd") : io.Pen
                            } else Jr(i) && (c = io.Touch);
                            null !== c ? (u = c, (l.startsWith("Touch") && c === io.Touch || l.startsWith("Mouse") && c === io.Mouse) && (c = null)) : so[t] === so.Click && (c = u, u = null);
                            const d = Jr(i) ? i.changedTouches[0] : i;
                            if (!d) return;
                            const p = n.getId(a),
                                {
                                    clientX: h,
                                    clientY: f
                                } = d;
                            So(e)({
                                type: so[l],
                                id: p,
                                x: h,
                                y: f,
                                ...null !== c && {
                                    pointerType: c
                                }
                            })
                        })(i);
                        if (window.PointerEvent) switch (so[i]) {
                            case so.MouseDown:
                            case so.MouseUp:
                                a = a.replace("mouse", "pointer");
                                break;
                            case so.TouchStart:
                            case so.TouchEnd:
                                return
                        }
                        c.push(Nr(a, l, t))
                    })), So((() => {
                        c.forEach((e => e()))
                    }))
                }

                function Io({
                    scrollCb: e,
                    doc: t,
                    mirror: n,
                    blockClass: r,
                    blockSelector: o,
                    unblockSelector: s,
                    sampling: i
                }) {
                    return Nr("scroll", So(Or(So((i => {
                        const a = Co(i);
                        if (!a || $r(a, r, o, s, !0)) return;
                        const c = n.getId(a);
                        if (a === t && t.defaultView) {
                            const n = Ur(t.defaultView);
                            e({
                                id: c,
                                x: n.left,
                                y: n.top
                            })
                        } else e({
                            id: c,
                            x: a.scrollLeft,
                            y: a.scrollTop
                        })
                    })), i.scroll || 100)), t)
                }
                const Eo = ["INPUT", "TEXTAREA", "SELECT"],
                    Mo = new WeakMap;

                function Ro({
                    inputCb: e,
                    doc: t,
                    mirror: n,
                    blockClass: r,
                    blockSelector: o,
                    unblockSelector: s,
                    ignoreClass: i,
                    ignoreSelector: a,
                    maskInputOptions: c,
                    maskInputFn: u,
                    sampling: l,
                    userTriggeredOnInput: d,
                    maskTextClass: p,
                    unmaskTextClass: h,
                    maskTextSelector: f,
                    unmaskTextSelector: m
                }) {
                    function g(e) {
                        let n = Co(e);
                        const l = e.isTrusted,
                            g = n && Zn(n.tagName);
                        if ("OPTION" === g && (n = n.parentElement), !n || !g || Eo.indexOf(g) < 0 || $r(n, r, o, s, !0)) return;
                        const y = n;
                        if (y.classList.contains(i) || a && y.matches(a)) return;
                        const v = tr(n);
                        let b = nr(y, g, v),
                            S = !1;
                        const w = Yn({
                                maskInputOptions: c,
                                tagName: g,
                                type: v
                            }),
                            k = Ir(n, p, f, h, m, w);
                        "radio" !== v && "checkbox" !== v || (S = n.checked), b = Gn({
                            isMasked: k,
                            element: n,
                            value: b,
                            maskInputFn: u
                        }), _(n, d ? {
                            text: b,
                            isChecked: S,
                            userTriggered: l
                        } : {
                            text: b,
                            isChecked: S
                        });
                        const C = n.name;
                        "radio" === v && C && S && t.querySelectorAll(`input[type="radio"][name="${C}"]`).forEach((e => {
                            if (e !== n) {
                                const t = Gn({
                                    isMasked: k,
                                    element: e,
                                    value: nr(e, g, v),
                                    maskInputFn: u
                                });
                                _(e, d ? {
                                    text: t,
                                    isChecked: !S,
                                    userTriggered: !1
                                } : {
                                    text: t,
                                    isChecked: !S
                                })
                            }
                        }))
                    }

                    function _(t, r) {
                        const o = Mo.get(t);
                        if (!o || o.text !== r.text || o.isChecked !== r.isChecked) {
                            Mo.set(t, r);
                            const o = n.getId(t);
                            So(e)({ ...r,
                                id: o
                            })
                        }
                    }
                    const y = ("last" === l.input ? ["change"] : ["input", "change"]).map((e => Nr(e, So(g), t))),
                        v = t.defaultView;
                    if (!v) return () => {
                        y.forEach((e => e()))
                    };
                    const b = v.Object.getOwnPropertyDescriptor(v.HTMLInputElement.prototype, "value"),
                        S = [
                            [v.HTMLInputElement.prototype, "value"],
                            [v.HTMLInputElement.prototype, "checked"],
                            [v.HTMLSelectElement.prototype, "value"],
                            [v.HTMLTextAreaElement.prototype, "value"],
                            [v.HTMLSelectElement.prototype, "selectedIndex"],
                            [v.HTMLOptionElement.prototype, "selected"]
                        ];
                    return b && b.set && y.push(...S.map((e => Fr(e[0], e[1], {
                        set() {
                            So(g)({
                                target: this,
                                isTrusted: !1
                            })
                        }
                    }, !1, v)))), So((() => {
                        y.forEach((e => e()))
                    }))
                }

                function Ao(e) {
                    return function(e, t) {
                        if (Oo("CSSGroupingRule") && e.parentRule instanceof CSSGroupingRule || Oo("CSSMediaRule") && e.parentRule instanceof CSSMediaRule || Oo("CSSSupportsRule") && e.parentRule instanceof CSSSupportsRule || Oo("CSSConditionRule") && e.parentRule instanceof CSSConditionRule) {
                            const n = Array.from(e.parentRule.cssRules).indexOf(e);
                            t.unshift(n)
                        } else if (e.parentStyleSheet) {
                            const n = Array.from(e.parentStyleSheet.cssRules).indexOf(e);
                            t.unshift(n)
                        }
                        return t
                    }(e, [])
                }

                function No(e, t, n) {
                    let r, o;
                    return e ? (e.ownerNode ? r = t.getId(e.ownerNode) : o = n.getId(e), {
                        styleId: o,
                        id: r
                    }) : {}
                }

                function Lo({
                    mirror: e,
                    stylesheetManager: t
                }, n) {
                    let r = null;
                    r = "#document" === n.nodeName ? e.getId(n) : e.getId(n.host);
                    const o = "#document" === n.nodeName ? wo([n, "access", e => e.defaultView, "optionalAccess", e => e.Document]) : wo([n, "access", e => e.ownerDocument, "optionalAccess", e => e.defaultView, "optionalAccess", e => e.ShadowRoot]),
                        s = wo([o, "optionalAccess", e => e.prototype]) ? Object.getOwnPropertyDescriptor(wo([o, "optionalAccess", e => e.prototype]), "adoptedStyleSheets") : void 0;
                    return null !== r && -1 !== r && o && s ? (Object.defineProperty(n, "adoptedStyleSheets", {
                        configurable: s.configurable,
                        enumerable: s.enumerable,
                        get() {
                            return wo([s, "access", e => e.get, "optionalAccess", e => e.call, "call", e => e(this)])
                        },
                        set(e) {
                            const n = wo([s, "access", e => e.set, "optionalAccess", e => e.call, "call", t => t(this, e)]);
                            if (null !== r && -1 !== r) try {
                                t.adoptStyleSheets(e, r)
                            } catch (e) {}
                            return n
                        }
                    }), So((() => {
                        Object.defineProperty(n, "adoptedStyleSheets", {
                            configurable: s.configurable,
                            enumerable: s.enumerable,
                            get: s.get,
                            set: s.set
                        })
                    }))) : () => {}
                }

                function Do(e, t = {}) {
                    const n = e.doc.defaultView;
                    if (!n) return () => {};
                    let r;
                    e.recordDOM && (r = xo(e, e.doc));
                    const o = function({
                            mousemoveCb: e,
                            sampling: t,
                            doc: n,
                            mirror: r
                        }) {
                            if (!1 === t.mousemove) return () => {};
                            const o = "number" == typeof t.mousemove ? t.mousemove : 50,
                                s = "number" == typeof t.mousemoveCallback ? t.mousemoveCallback : 500;
                            let i, a = [];
                            const c = Or(So((t => {
                                    const n = Date.now() - i;
                                    e(a.map((e => (e.timeOffset -= n, e))), t), a = [], i = null
                                })), s),
                                u = So(Or(So((e => {
                                    const t = Co(e),
                                        {
                                            clientX: n,
                                            clientY: o
                                        } = Jr(e) ? e.changedTouches[0] : e;
                                    i || (i = Br()), a.push({
                                        x: n,
                                        y: o,
                                        id: r.getId(t),
                                        timeOffset: Br() - i
                                    }), c("undefined" != typeof DragEvent && e instanceof DragEvent ? oo.Drag : e instanceof MouseEvent ? oo.MouseMove : oo.TouchMove)
                                })), o, {
                                    trailing: !1
                                })),
                                l = [Nr("mousemove", u, n), Nr("touchmove", u, n), Nr("drag", u, n)];
                            return So((() => {
                                l.forEach((e => e()))
                            }))
                        }(e),
                        s = To(e),
                        i = Io(e),
                        a = function({
                            viewportResizeCb: e
                        }, {
                            win: t
                        }) {
                            let n = -1,
                                r = -1;
                            return Nr("resize", So(Or(So((() => {
                                const t = jr(),
                                    o = zr();
                                n === t && r === o || (e({
                                    width: Number(o),
                                    height: Number(t)
                                }), n = t, r = o)
                            })), 200)), t)
                        }(e, {
                            win: n
                        }),
                        c = Ro(e),
                        u = function({
                            mediaInteractionCb: e,
                            blockClass: t,
                            blockSelector: n,
                            unblockSelector: r,
                            mirror: o,
                            sampling: s,
                            doc: i
                        }) {
                            const a = So((i => Or(So((s => {
                                    const a = Co(s);
                                    if (!a || $r(a, t, n, r, !0)) return;
                                    const {
                                        currentTime: c,
                                        volume: u,
                                        muted: l,
                                        playbackRate: d
                                    } = a;
                                    e({
                                        type: i,
                                        id: o.getId(a),
                                        currentTime: c,
                                        volume: u,
                                        muted: l,
                                        playbackRate: d
                                    })
                                })), s.media || 500))),
                                c = [Nr("play", a(0), i), Nr("pause", a(1), i), Nr("seeked", a(2), i), Nr("volumechange", a(3), i), Nr("ratechange", a(4), i)];
                            return So((() => {
                                c.forEach((e => e()))
                            }))
                        }(e);
                    let l = () => {},
                        d = () => {},
                        p = () => {},
                        h = () => {};
                    e.recordDOM && (l = function({
                        styleSheetRuleCb: e,
                        mirror: t,
                        stylesheetManager: n
                    }, {
                        win: r
                    }) {
                        if (!r.CSSStyleSheet || !r.CSSStyleSheet.prototype) return () => {};
                        const o = r.CSSStyleSheet.prototype.insertRule;
                        r.CSSStyleSheet.prototype.insertRule = new Proxy(o, {
                            apply: So(((r, o, s) => {
                                const [i, a] = s, {
                                    id: c,
                                    styleId: u
                                } = No(o, t, n.styleMirror);
                                return (c && -1 !== c || u && -1 !== u) && e({
                                    id: c,
                                    styleId: u,
                                    adds: [{
                                        rule: i,
                                        index: a
                                    }]
                                }), r.apply(o, s)
                            }))
                        });
                        const s = r.CSSStyleSheet.prototype.deleteRule;
                        let i, a;
                        r.CSSStyleSheet.prototype.deleteRule = new Proxy(s, {
                            apply: So(((r, o, s) => {
                                const [i] = s, {
                                    id: a,
                                    styleId: c
                                } = No(o, t, n.styleMirror);
                                return (a && -1 !== a || c && -1 !== c) && e({
                                    id: a,
                                    styleId: c,
                                    removes: [{
                                        index: i
                                    }]
                                }), r.apply(o, s)
                            }))
                        }), r.CSSStyleSheet.prototype.replace && (i = r.CSSStyleSheet.prototype.replace, r.CSSStyleSheet.prototype.replace = new Proxy(i, {
                            apply: So(((r, o, s) => {
                                const [i] = s, {
                                    id: a,
                                    styleId: c
                                } = No(o, t, n.styleMirror);
                                return (a && -1 !== a || c && -1 !== c) && e({
                                    id: a,
                                    styleId: c,
                                    replace: i
                                }), r.apply(o, s)
                            }))
                        })), r.CSSStyleSheet.prototype.replaceSync && (a = r.CSSStyleSheet.prototype.replaceSync, r.CSSStyleSheet.prototype.replaceSync = new Proxy(a, {
                            apply: So(((r, o, s) => {
                                const [i] = s, {
                                    id: a,
                                    styleId: c
                                } = No(o, t, n.styleMirror);
                                return (a && -1 !== a || c && -1 !== c) && e({
                                    id: a,
                                    styleId: c,
                                    replaceSync: i
                                }), r.apply(o, s)
                            }))
                        }));
                        const c = {};
                        Fo("CSSGroupingRule") ? c.CSSGroupingRule = r.CSSGroupingRule : (Fo("CSSMediaRule") && (c.CSSMediaRule = r.CSSMediaRule), Fo("CSSConditionRule") && (c.CSSConditionRule = r.CSSConditionRule), Fo("CSSSupportsRule") && (c.CSSSupportsRule = r.CSSSupportsRule));
                        const u = {};
                        return Object.entries(c).forEach((([r, o]) => {
                            u[r] = {
                                insertRule: o.prototype.insertRule,
                                deleteRule: o.prototype.deleteRule
                            }, o.prototype.insertRule = new Proxy(u[r].insertRule, {
                                apply: So(((r, o, s) => {
                                    const [i, a] = s, {
                                        id: c,
                                        styleId: u
                                    } = No(o.parentStyleSheet, t, n.styleMirror);
                                    return (c && -1 !== c || u && -1 !== u) && e({
                                        id: c,
                                        styleId: u,
                                        adds: [{
                                            rule: i,
                                            index: [...Ao(o), a || 0]
                                        }]
                                    }), r.apply(o, s)
                                }))
                            }), o.prototype.deleteRule = new Proxy(u[r].deleteRule, {
                                apply: So(((r, o, s) => {
                                    const [i] = s, {
                                        id: a,
                                        styleId: c
                                    } = No(o.parentStyleSheet, t, n.styleMirror);
                                    return (a && -1 !== a || c && -1 !== c) && e({
                                        id: a,
                                        styleId: c,
                                        removes: [{
                                            index: [...Ao(o), i]
                                        }]
                                    }), r.apply(o, s)
                                }))
                            })
                        })), So((() => {
                            r.CSSStyleSheet.prototype.insertRule = o, r.CSSStyleSheet.prototype.deleteRule = s, i && (r.CSSStyleSheet.prototype.replace = i), a && (r.CSSStyleSheet.prototype.replaceSync = a), Object.entries(c).forEach((([e, t]) => {
                                t.prototype.insertRule = u[e].insertRule, t.prototype.deleteRule = u[e].deleteRule
                            }))
                        }))
                    }(e, {
                        win: n
                    }), d = Lo(e, e.doc), p = function({
                        styleDeclarationCb: e,
                        mirror: t,
                        ignoreCSSAttributes: n,
                        stylesheetManager: r
                    }, {
                        win: o
                    }) {
                        const s = o.CSSStyleDeclaration.prototype.setProperty;
                        o.CSSStyleDeclaration.prototype.setProperty = new Proxy(s, {
                            apply: So(((o, i, a) => {
                                const [c, u, l] = a;
                                if (n.has(c)) return s.apply(i, [c, u, l]);
                                const {
                                    id: d,
                                    styleId: p
                                } = No(wo([i, "access", e => e.parentRule, "optionalAccess", e => e.parentStyleSheet]), t, r.styleMirror);
                                return (d && -1 !== d || p && -1 !== p) && e({
                                    id: d,
                                    styleId: p,
                                    set: {
                                        property: c,
                                        value: u,
                                        priority: l
                                    },
                                    index: Ao(i.parentRule)
                                }), o.apply(i, a)
                            }))
                        });
                        const i = o.CSSStyleDeclaration.prototype.removeProperty;
                        return o.CSSStyleDeclaration.prototype.removeProperty = new Proxy(i, {
                            apply: So(((o, s, a) => {
                                const [c] = a;
                                if (n.has(c)) return i.apply(s, [c]);
                                const {
                                    id: u,
                                    styleId: l
                                } = No(wo([s, "access", e => e.parentRule, "optionalAccess", e => e.parentStyleSheet]), t, r.styleMirror);
                                return (u && -1 !== u || l && -1 !== l) && e({
                                    id: u,
                                    styleId: l,
                                    remove: {
                                        property: c
                                    },
                                    index: Ao(s.parentRule)
                                }), o.apply(s, a)
                            }))
                        }), So((() => {
                            o.CSSStyleDeclaration.prototype.setProperty = s, o.CSSStyleDeclaration.prototype.removeProperty = i
                        }))
                    }(e, {
                        win: n
                    }), e.collectFonts && (h = function({
                        fontCb: e,
                        doc: t
                    }) {
                        const n = t.defaultView;
                        if (!n) return () => {};
                        const r = [],
                            o = new WeakMap,
                            s = n.FontFace;
                        n.FontFace = function(e, t, n) {
                            const r = new s(e, t, n);
                            return o.set(r, {
                                family: e,
                                buffer: "string" != typeof t,
                                descriptors: n,
                                fontSource: "string" == typeof t ? t : JSON.stringify(Array.from(new Uint8Array(t)))
                            }), r
                        };
                        const i = Pr(t.fonts, "add", (function(t) {
                            return function(n) {
                                return no(So((() => {
                                    const t = o.get(n);
                                    t && (e(t), o.delete(n))
                                })), 0), t.apply(this, [n])
                            }
                        }));
                        return r.push((() => {
                            n.FontFace = s
                        })), r.push(i), So((() => {
                            r.forEach((e => e()))
                        }))
                    }(e)));
                    const f = function(e) {
                            const {
                                doc: t,
                                mirror: n,
                                blockClass: r,
                                blockSelector: o,
                                unblockSelector: s,
                                selectionCb: i
                            } = e;
                            let a = !0;
                            const c = So((() => {
                                const e = t.getSelection();
                                if (!e || a && wo([e, "optionalAccess", e => e.isCollapsed])) return;
                                a = e.isCollapsed || !1;
                                const c = [],
                                    u = e.rangeCount || 0;
                                for (let t = 0; t < u; t++) {
                                    const i = e.getRangeAt(t),
                                        {
                                            startContainer: a,
                                            startOffset: u,
                                            endContainer: l,
                                            endOffset: d
                                        } = i;
                                    $r(a, r, o, s, !0) || $r(l, r, o, s, !0) || c.push({
                                        start: n.getId(a),
                                        startOffset: u,
                                        end: n.getId(l),
                                        endOffset: d
                                    })
                                }
                                i({
                                    ranges: c
                                })
                            }));
                            return c(), Nr("selectionchange", c)
                        }(e),
                        m = function({
                            doc: e,
                            customElementCb: t
                        }) {
                            const n = e.defaultView;
                            return n && n.customElements ? Pr(n.customElements, "define", (function(e) {
                                return function(n, r, o) {
                                    try {
                                        t({
                                            define: {
                                                name: n
                                            }
                                        })
                                    } catch (e) {}
                                    return e.apply(this, [n, r, o])
                                }
                            })) : () => {}
                        }(e),
                        g = [];
                    for (const t of e.plugins) g.push(t.observer(t.callback, n, t.options));
                    return So((() => {
                        ko.forEach((e => e.reset())), wo([r, "optionalAccess", e => e.disconnect, "call", e => e()]), o(), s(), i(), a(), c(), u(), l(), d(), p(), h(), f(), m(), g.forEach((e => e()))
                    }))
                }

                function Oo(e) {
                    return void 0 !== window[e]
                }

                function Fo(e) {
                    return Boolean(void 0 !== window[e] && window[e].prototype && "insertRule" in window[e].prototype && "deleteRule" in window[e].prototype)
                }
                class Po {
                    constructor(e) {
                        this.generateIdFn = e, this.iframeIdToRemoteIdMap = new WeakMap, this.iframeRemoteIdToIdMap = new WeakMap
                    }
                    getId(e, t, n, r) {
                        const o = n || this.getIdToRemoteIdMap(e),
                            s = r || this.getRemoteIdToIdMap(e);
                        let i = o.get(t);
                        return i || (i = this.generateIdFn(), o.set(t, i), s.set(i, t)), i
                    }
                    getIds(e, t) {
                        const n = this.getIdToRemoteIdMap(e),
                            r = this.getRemoteIdToIdMap(e);
                        return t.map((t => this.getId(e, t, n, r)))
                    }
                    getRemoteId(e, t, n) {
                        const r = n || this.getRemoteIdToIdMap(e);
                        if ("number" != typeof t) return t;
                        const o = r.get(t);
                        return o || -1
                    }
                    getRemoteIds(e, t) {
                        const n = this.getRemoteIdToIdMap(e);
                        return t.map((t => this.getRemoteId(e, t, n)))
                    }
                    reset(e) {
                        if (!e) return this.iframeIdToRemoteIdMap = new WeakMap, void(this.iframeRemoteIdToIdMap = new WeakMap);
                        this.iframeIdToRemoteIdMap.delete(e), this.iframeRemoteIdToIdMap.delete(e)
                    }
                    getIdToRemoteIdMap(e) {
                        let t = this.iframeIdToRemoteIdMap.get(e);
                        return t || (t = new Map, this.iframeIdToRemoteIdMap.set(e, t)), t
                    }
                    getRemoteIdToIdMap(e) {
                        let t = this.iframeRemoteIdToIdMap.get(e);
                        return t || (t = new Map, this.iframeRemoteIdToIdMap.set(e, t)), t
                    }
                }

                function Bo(e) {
                    let t, n = e[0],
                        r = 1;
                    for (; r < e.length;) {
                        const o = e[r],
                            s = e[r + 1];
                        if (r += 2, ("optionalAccess" === o || "optionalCall" === o) && null == n) return;
                        "access" === o || "optionalAccess" === o ? (t = n, n = s(n)) : "call" !== o && "optionalCall" !== o || (n = s(((...e) => n.call(t, ...e))), t = void 0)
                    }
                    return n
                }
                class Uo {
                    constructor() {
                        this.crossOriginIframeMirror = new Po(lr), this.crossOriginIframeRootIdMap = new WeakMap
                    }
                    addIframe() {}
                    addLoadListener() {}
                    attachIframe() {}
                }
                class jo {
                    constructor(e) {
                        this.iframes = new WeakMap, this.crossOriginIframeMap = new WeakMap, this.crossOriginIframeMirror = new Po(lr), this.crossOriginIframeRootIdMap = new WeakMap, this.mutationCb = e.mutationCb, this.wrappedEmit = e.wrappedEmit, this.stylesheetManager = e.stylesheetManager, this.recordCrossOriginIframes = e.recordCrossOriginIframes, this.crossOriginIframeStyleMirror = new Po(this.stylesheetManager.styleMirror.generateId.bind(this.stylesheetManager.styleMirror)), this.mirror = e.mirror, this.recordCrossOriginIframes && window.addEventListener("message", this.handleMessage.bind(this))
                    }
                    addIframe(e) {
                        this.iframes.set(e, !0), e.contentWindow && this.crossOriginIframeMap.set(e.contentWindow, e)
                    }
                    addLoadListener(e) {
                        this.loadListener = e
                    }
                    attachIframe(e, t) {
                        this.mutationCb({
                            adds: [{
                                parentId: this.mirror.getId(e),
                                nextId: null,
                                node: t
                            }],
                            removes: [],
                            texts: [],
                            attributes: [],
                            isAttachIframe: !0
                        }), Bo([this, "access", e => e.loadListener, "optionalCall", t => t(e)]), e.contentDocument && e.contentDocument.adoptedStyleSheets && e.contentDocument.adoptedStyleSheets.length > 0 && this.stylesheetManager.adoptStyleSheets(e.contentDocument.adoptedStyleSheets, this.mirror.getId(e.contentDocument))
                    }
                    handleMessage(e) {
                        const t = e;
                        if ("rrweb" !== t.data.type || t.origin !== t.data.origin) return;
                        if (!e.source) return;
                        const n = this.crossOriginIframeMap.get(e.source);
                        if (!n) return;
                        const r = this.transformCrossOriginEvent(n, t.data.event);
                        r && this.wrappedEmit(r, t.data.isCheckout)
                    }
                    transformCrossOriginEvent(e, t) {
                        switch (t.type) {
                            case ro.FullSnapshot:
                                {
                                    this.crossOriginIframeMirror.reset(e),
                                    this.crossOriginIframeStyleMirror.reset(e),
                                    this.replaceIdOnNode(t.data.node, e);
                                    const n = t.data.node.id;
                                    return this.crossOriginIframeRootIdMap.set(e, n),
                                    this.patchRootIdOnNode(t.data.node, n),
                                    {
                                        timestamp: t.timestamp,
                                        type: ro.IncrementalSnapshot,
                                        data: {
                                            source: oo.Mutation,
                                            adds: [{
                                                parentId: this.mirror.getId(e),
                                                nextId: null,
                                                node: t.data.node
                                            }],
                                            removes: [],
                                            texts: [],
                                            attributes: [],
                                            isAttachIframe: !0
                                        }
                                    }
                                }
                            case ro.Meta:
                            case ro.Load:
                            case ro.DomContentLoaded:
                                return !1;
                            case ro.Plugin:
                                return t;
                            case ro.Custom:
                                return this.replaceIds(t.data.payload, e, ["id", "parentId", "previousId", "nextId"]), t;
                            case ro.IncrementalSnapshot:
                                switch (t.data.source) {
                                    case oo.Mutation:
                                        return t.data.adds.forEach((t => {
                                            this.replaceIds(t, e, ["parentId", "nextId", "previousId"]), this.replaceIdOnNode(t.node, e);
                                            const n = this.crossOriginIframeRootIdMap.get(e);
                                            n && this.patchRootIdOnNode(t.node, n)
                                        })), t.data.removes.forEach((t => {
                                            this.replaceIds(t, e, ["parentId", "id"])
                                        })), t.data.attributes.forEach((t => {
                                            this.replaceIds(t, e, ["id"])
                                        })), t.data.texts.forEach((t => {
                                            this.replaceIds(t, e, ["id"])
                                        })), t;
                                    case oo.Drag:
                                    case oo.TouchMove:
                                    case oo.MouseMove:
                                        return t.data.positions.forEach((t => {
                                            this.replaceIds(t, e, ["id"])
                                        })), t;
                                    case oo.ViewportResize:
                                        return !1;
                                    case oo.MediaInteraction:
                                    case oo.MouseInteraction:
                                    case oo.Scroll:
                                    case oo.CanvasMutation:
                                    case oo.Input:
                                        return this.replaceIds(t.data, e, ["id"]), t;
                                    case oo.StyleSheetRule:
                                    case oo.StyleDeclaration:
                                        return this.replaceIds(t.data, e, ["id"]), this.replaceStyleIds(t.data, e, ["styleId"]), t;
                                    case oo.Font:
                                        return t;
                                    case oo.Selection:
                                        return t.data.ranges.forEach((t => {
                                            this.replaceIds(t, e, ["start", "end"])
                                        })), t;
                                    case oo.AdoptedStyleSheet:
                                        return this.replaceIds(t.data, e, ["id"]), this.replaceStyleIds(t.data, e, ["styleIds"]), Bo([t, "access", e => e.data, "access", e => e.styles, "optionalAccess", e => e.forEach, "call", t => t((t => {
                                            this.replaceStyleIds(t, e, ["styleId"])
                                        }))]), t
                                }
                        }
                        return !1
                    }
                    replace(e, t, n, r) {
                        for (const o of r)(Array.isArray(t[o]) || "number" == typeof t[o]) && (Array.isArray(t[o]) ? t[o] = e.getIds(n, t[o]) : t[o] = e.getId(n, t[o]));
                        return t
                    }
                    replaceIds(e, t, n) {
                        return this.replace(this.crossOriginIframeMirror, e, t, n)
                    }
                    replaceStyleIds(e, t, n) {
                        return this.replace(this.crossOriginIframeStyleMirror, e, t, n)
                    }
                    replaceIdOnNode(e, t) {
                        this.replaceIds(e, t, ["id", "rootId"]), "childNodes" in e && e.childNodes.forEach((e => {
                            this.replaceIdOnNode(e, t)
                        }))
                    }
                    patchRootIdOnNode(e, t) {
                        e.type === Wn.Document || e.rootId || (e.rootId = t), "childNodes" in e && e.childNodes.forEach((e => {
                            this.patchRootIdOnNode(e, t)
                        }))
                    }
                }
                class zo {
                    init() {}
                    addShadowRoot() {}
                    observeAttachShadow() {}
                    reset() {}
                }
                class Ho {
                    constructor(e) {
                        this.shadowDoms = new WeakSet, this.restoreHandlers = [], this.mutationCb = e.mutationCb, this.scrollCb = e.scrollCb, this.bypassOptions = e.bypassOptions, this.mirror = e.mirror, this.init()
                    }
                    init() {
                        this.reset(), this.patchAttachShadow(Element, document)
                    }
                    addShadowRoot(e, t) {
                        if (!Jn(e)) return;
                        if (this.shadowDoms.has(e)) return;
                        this.shadowDoms.add(e), this.bypassOptions.canvasManager.addShadowRoot(e);
                        const n = xo({ ...this.bypassOptions,
                            doc: t,
                            mutationCb: this.mutationCb,
                            mirror: this.mirror,
                            shadowDomManager: this
                        }, e);
                        this.restoreHandlers.push((() => n.disconnect())), this.restoreHandlers.push(Io({ ...this.bypassOptions,
                            scrollCb: this.scrollCb,
                            doc: e,
                            mirror: this.mirror
                        })), no((() => {
                            e.adoptedStyleSheets && e.adoptedStyleSheets.length > 0 && this.bypassOptions.stylesheetManager.adoptStyleSheets(e.adoptedStyleSheets, this.mirror.getId(e.host)), this.restoreHandlers.push(Lo({
                                mirror: this.mirror,
                                stylesheetManager: this.bypassOptions.stylesheetManager
                            }, e))
                        }), 0)
                    }
                    observeAttachShadow(e) {
                        e.contentWindow && e.contentDocument && this.patchAttachShadow(e.contentWindow.Element, e.contentDocument)
                    }
                    patchAttachShadow(e, t) {
                        const n = this;
                        this.restoreHandlers.push(Pr(e.prototype, "attachShadow", (function(e) {
                            return function(r) {
                                const o = e.call(this, r);
                                return this.shadowRoot && Zr(this) && n.addShadowRoot(this.shadowRoot, t), o
                            }
                        })))
                    }
                    reset() {
                        this.restoreHandlers.forEach((e => {
                            try {
                                e()
                            } catch (e) {}
                        })), this.restoreHandlers = [], this.shadowDoms = new WeakSet, this.bypassOptions.canvasManager.resetShadowRoots()
                    }
                }
                class $o {
                    reset() {}
                    freeze() {}
                    unfreeze() {}
                    lock() {}
                    unlock() {}
                    snapshot() {}
                    addWindow() {}
                    addShadowRoot() {}
                    resetShadowRoots() {}
                }
                class Wo {
                    constructor(e) {
                        this.trackedLinkElements = new WeakSet, this.styleMirror = new Yr, this.mutationCb = e.mutationCb, this.adoptedStyleSheetCb = e.adoptedStyleSheetCb
                    }
                    attachLinkElement(e, t) {
                        "_cssText" in t.attributes && this.mutationCb({
                            adds: [],
                            removes: [],
                            texts: [],
                            attributes: [{
                                id: t.id,
                                attributes: t.attributes
                            }]
                        }), this.trackLinkElement(e)
                    }
                    trackLinkElement(e) {
                        this.trackedLinkElements.has(e) || (this.trackedLinkElements.add(e), this.trackStylesheetInLinkElement(e))
                    }
                    adoptStyleSheets(e, t) {
                        if (0 === e.length) return;
                        const n = {
                                id: t,
                                styleIds: []
                            },
                            r = [];
                        for (const t of e) {
                            let e;
                            this.styleMirror.has(t) ? e = this.styleMirror.getId(t) : (e = this.styleMirror.add(t), r.push({
                                styleId: e,
                                rules: Array.from(t.rules || CSSRule, ((e, t) => ({
                                    rule: Vn(e),
                                    index: t
                                })))
                            })), n.styleIds.push(e)
                        }
                        r.length > 0 && (n.styles = r), this.adoptedStyleSheetCb(n)
                    }
                    reset() {
                        this.styleMirror.reset(), this.trackedLinkElements = new WeakSet
                    }
                    trackStylesheetInLinkElement(e) {}
                }
                class qo {
                    constructor() {
                        this.nodeMap = new WeakMap, this.loop = !0, this.periodicallyClear()
                    }
                    periodicallyClear() {
                        ! function(...e) {
                            to("requestAnimationFrame")(...e)
                        }((() => {
                            this.clear(), this.loop && this.periodicallyClear()
                        }))
                    }
                    inOtherBuffer(e, t) {
                        const n = this.nodeMap.get(e);
                        return n && Array.from(n).some((e => e !== t))
                    }
                    add(e, t) {
                        this.nodeMap.set(e, (this.nodeMap.get(e) || new Set).add(t))
                    }
                    clear() {
                        this.nodeMap = new WeakMap
                    }
                    destroy() {
                        this.loop = !1
                    }
                }
                let Jo, Ko;
                try {
                    if (2 !== Array.from([1], (e => 2 * e))[0]) {
                        const e = document.createElement("iframe");
                        document.body.appendChild(e), Array.from = Ct([e, "access", e => e.contentWindow, "optionalAccess", e => e.Array, "access", e => e.from]) || Array.from, document.body.removeChild(e)
                    }
                } catch (e) {
                    console.debug("Unable to override Array.from", e)
                }
                const Vo = new Xn;

                function Xo(e = {}) {
                    const {
                        emit: t,
                        checkoutEveryNms: n,
                        checkoutEveryNth: r,
                        blockClass: o = "rr-block",
                        blockSelector: s = null,
                        unblockSelector: i = null,
                        ignoreClass: a = "rr-ignore",
                        ignoreSelector: c = null,
                        maskAllText: u = !1,
                        maskTextClass: l = "rr-mask",
                        unmaskTextClass: d = null,
                        maskTextSelector: p = null,
                        unmaskTextSelector: h = null,
                        inlineStylesheet: f = !0,
                        maskAllInputs: m,
                        maskInputOptions: g,
                        slimDOMOptions: _,
                        maskAttributeFn: y,
                        maskInputFn: v,
                        maskTextFn: b,
                        maxCanvasSize: S = null,
                        packFn: w,
                        sampling: k = {},
                        dataURLOptions: C = {},
                        mousemoveWait: x,
                        recordDOM: T = !0,
                        recordCanvas: I = !1,
                        recordCrossOriginIframes: E = !1,
                        recordAfter: M = ("DOMContentLoaded" === e.recordAfter ? e.recordAfter : "load"),
                        userTriggeredOnInput: R = !1,
                        collectFonts: A = !1,
                        inlineImages: N = !1,
                        plugins: L,
                        keepIframeSrcFn: D = () => !1,
                        ignoreCSSAttributes: O = new Set([]),
                        errorHandler: F,
                        onMutation: P,
                        getCanvasManager: B
                    } = e;
                    vo(F);
                    const U = !E || window.parent === window;
                    let j = !1;
                    if (!U) try {
                        window.parent.document && (j = !1)
                    } catch (e) {
                        j = !0
                    }
                    if (U && !t) throw new Error("emit function is required");
                    void 0 !== x && void 0 === k.mousemove && (k.mousemove = x), Vo.reset();
                    const z = !0 === m ? {
                            color: !0,
                            date: !0,
                            "datetime-local": !0,
                            email: !0,
                            month: !0,
                            number: !0,
                            range: !0,
                            search: !0,
                            tel: !0,
                            text: !0,
                            time: !0,
                            url: !0,
                            week: !0,
                            textarea: !0,
                            select: !0,
                            radio: !0,
                            checkbox: !0
                        } : void 0 !== g ? g : {},
                        H = !0 === _ || "all" === _ ? {
                            script: !0,
                            comment: !0,
                            headFavicon: !0,
                            headWhitespace: !0,
                            headMetaSocial: !0,
                            headMetaRobots: !0,
                            headMetaHttpEquiv: !0,
                            headMetaVerification: !0,
                            headMetaAuthorship: "all" === _,
                            headMetaDescKeywords: "all" === _
                        } : _ || {};
                    let $;
                    ! function(e = window) {
                        "NodeList" in e && !e.NodeList.prototype.forEach && (e.NodeList.prototype.forEach = Array.prototype.forEach), "DOMTokenList" in e && !e.DOMTokenList.prototype.forEach && (e.DOMTokenList.prototype.forEach = Array.prototype.forEach), Node.prototype.contains || (Node.prototype.contains = (...e) => {
                            let t = e[0];
                            if (!(0 in e)) throw new TypeError("1 argument is required");
                            do {
                                if (this === t) return !0
                            } while (t = t && t.parentNode);
                            return !1
                        })
                    }();
                    let W = 0;
                    const q = e => {
                        for (const t of L || []) t.eventProcessor && (e = t.eventProcessor(e));
                        return w && !j && (e = w(e)), e
                    };
                    Jo = (e, o) => {
                        const s = e;
                        if (s.timestamp = Br(), !Ct([ko, "access", e => e[0], "optionalAccess", e => e.isFrozen, "call", e => e()]) || s.type === ro.FullSnapshot || s.type === ro.IncrementalSnapshot && s.data.source === oo.Mutation || ko.forEach((e => e.unfreeze())), U) Ct([t, "optionalCall", e => e(q(s), o)]);
                        else if (j) {
                            const e = {
                                type: "rrweb",
                                event: q(s),
                                origin: window.location.origin,
                                isCheckout: o
                            };
                            window.parent.postMessage(e, "*")
                        }
                        if (s.type === ro.FullSnapshot) $ = s, W = 0;
                        else if (s.type === ro.IncrementalSnapshot) {
                            if (s.data.source === oo.Mutation && s.data.isAttachIframe) return;
                            W++;
                            const e = r && W >= r,
                                t = n && $ && s.timestamp - $.timestamp > n;
                            (e || t) && ee(!0)
                        }
                    };
                    const J = e => {
                            Jo({
                                type: ro.IncrementalSnapshot,
                                data: {
                                    source: oo.Mutation,
                                    ...e
                                }
                            })
                        },
                        K = e => Jo({
                            type: ro.IncrementalSnapshot,
                            data: {
                                source: oo.Scroll,
                                ...e
                            }
                        }),
                        V = e => Jo({
                            type: ro.IncrementalSnapshot,
                            data: {
                                source: oo.CanvasMutation,
                                ...e
                            }
                        }),
                        X = new Wo({
                            mutationCb: J,
                            adoptedStyleSheetCb: e => Jo({
                                type: ro.IncrementalSnapshot,
                                data: {
                                    source: oo.AdoptedStyleSheet,
                                    ...e
                                }
                            })
                        }),
                        Y = "boolean" == typeof __RRWEB_EXCLUDE_IFRAME__ && __RRWEB_EXCLUDE_IFRAME__ ? new Uo : new jo({
                            mirror: Vo,
                            mutationCb: J,
                            stylesheetManager: X,
                            recordCrossOriginIframes: E,
                            wrappedEmit: Jo
                        });
                    for (const e of L || []) e.getMirror && e.getMirror({
                        nodeMirror: Vo,
                        crossOriginIframeMirror: Y.crossOriginIframeMirror,
                        crossOriginIframeStyleMirror: Y.crossOriginIframeStyleMirror
                    });
                    const G = new qo,
                        Q = function(e, t) {
                            try {
                                return e ? e(t) : new $o
                            } catch (e) {
                                return console.warn("Unable to initialize CanvasManager"), new $o
                            }
                        }(B, {
                            mirror: Vo,
                            win: window,
                            mutationCb: e => Jo({
                                type: ro.IncrementalSnapshot,
                                data: {
                                    source: oo.CanvasMutation,
                                    ...e
                                }
                            }),
                            recordCanvas: I,
                            blockClass: o,
                            blockSelector: s,
                            unblockSelector: i,
                            maxCanvasSize: S,
                            sampling: k.canvas,
                            dataURLOptions: C,
                            errorHandler: F
                        }),
                        Z = "boolean" == typeof __RRWEB_EXCLUDE_SHADOW_DOM__ && __RRWEB_EXCLUDE_SHADOW_DOM__ ? new zo : new Ho({
                            mutationCb: J,
                            scrollCb: K,
                            bypassOptions: {
                                onMutation: P,
                                blockClass: o,
                                blockSelector: s,
                                unblockSelector: i,
                                maskAllText: u,
                                maskTextClass: l,
                                unmaskTextClass: d,
                                maskTextSelector: p,
                                unmaskTextSelector: h,
                                inlineStylesheet: f,
                                maskInputOptions: z,
                                dataURLOptions: C,
                                maskAttributeFn: y,
                                maskTextFn: b,
                                maskInputFn: v,
                                recordCanvas: I,
                                inlineImages: N,
                                sampling: k,
                                slimDOMOptions: H,
                                iframeManager: Y,
                                stylesheetManager: X,
                                canvasManager: Q,
                                keepIframeSrcFn: D,
                                processedNodeManager: G
                            },
                            mirror: Vo
                        }),
                        ee = (e = !1) => {
                            if (!T) return;
                            Jo({
                                type: ro.Meta,
                                data: {
                                    href: window.location.href,
                                    width: zr(),
                                    height: jr()
                                }
                            }, e), X.reset(), Z.init(), ko.forEach((e => e.lock()));
                            const t = function(e, t) {
                                const {
                                    mirror: n = new Xn,
                                    blockClass: r = "rr-block",
                                    blockSelector: o = null,
                                    unblockSelector: s = null,
                                    maskAllText: i = !1,
                                    maskTextClass: a = "rr-mask",
                                    unmaskTextClass: c = null,
                                    maskTextSelector: u = null,
                                    unmaskTextSelector: l = null,
                                    inlineStylesheet: d = !0,
                                    inlineImages: p = !1,
                                    recordCanvas: h = !1,
                                    maskAllInputs: f = !1,
                                    maskAttributeFn: m,
                                    maskTextFn: g,
                                    maskInputFn: _,
                                    slimDOM: y = !1,
                                    dataURLOptions: v,
                                    preserveWhiteSpace: b,
                                    onSerialize: S,
                                    onIframeLoad: w,
                                    iframeLoadTimeout: k,
                                    onStylesheetLoad: C,
                                    stylesheetLoadTimeout: x,
                                    keepIframeSrcFn: T = () => !1
                                } = t || {};
                                return Rr(e, {
                                    doc: e,
                                    mirror: n,
                                    blockClass: r,
                                    blockSelector: o,
                                    unblockSelector: s,
                                    maskAllText: i,
                                    maskTextClass: a,
                                    unmaskTextClass: c,
                                    maskTextSelector: u,
                                    unmaskTextSelector: l,
                                    skipChild: !1,
                                    inlineStylesheet: d,
                                    maskInputOptions: !0 === f ? {
                                        color: !0,
                                        date: !0,
                                        "datetime-local": !0,
                                        email: !0,
                                        month: !0,
                                        number: !0,
                                        range: !0,
                                        search: !0,
                                        tel: !0,
                                        text: !0,
                                        time: !0,
                                        url: !0,
                                        week: !0,
                                        textarea: !0,
                                        select: !0
                                    } : !1 === f ? {} : f,
                                    maskAttributeFn: m,
                                    maskTextFn: g,
                                    maskInputFn: _,
                                    slimDOMOptions: !0 === y || "all" === y ? {
                                        script: !0,
                                        comment: !0,
                                        headFavicon: !0,
                                        headWhitespace: !0,
                                        headMetaDescKeywords: "all" === y,
                                        headMetaSocial: !0,
                                        headMetaRobots: !0,
                                        headMetaHttpEquiv: !0,
                                        headMetaAuthorship: !0,
                                        headMetaVerification: !0
                                    } : !1 === y ? {} : y,
                                    dataURLOptions: v,
                                    inlineImages: p,
                                    recordCanvas: h,
                                    preserveWhiteSpace: b,
                                    onSerialize: S,
                                    onIframeLoad: w,
                                    iframeLoadTimeout: k,
                                    onStylesheetLoad: C,
                                    stylesheetLoadTimeout: x,
                                    keepIframeSrcFn: T,
                                    newlyAddedElement: !1
                                })
                            }(document, {
                                mirror: Vo,
                                blockClass: o,
                                blockSelector: s,
                                unblockSelector: i,
                                maskAllText: u,
                                maskTextClass: l,
                                unmaskTextClass: d,
                                maskTextSelector: p,
                                unmaskTextSelector: h,
                                inlineStylesheet: f,
                                maskAllInputs: z,
                                maskAttributeFn: y,
                                maskInputFn: v,
                                maskTextFn: b,
                                slimDOM: H,
                                dataURLOptions: C,
                                recordCanvas: I,
                                inlineImages: N,
                                onSerialize: e => {
                                    Kr(e, Vo) && Y.addIframe(e), Vr(e, Vo) && X.trackLinkElement(e), Xr(e) && Z.addShadowRoot(e.shadowRoot, document)
                                },
                                onIframeLoad: (e, t) => {
                                    Y.attachIframe(e, t), e.contentWindow && Q.addWindow(e.contentWindow), Z.observeAttachShadow(e)
                                },
                                onStylesheetLoad: (e, t) => {
                                    X.attachLinkElement(e, t)
                                },
                                keepIframeSrcFn: D
                            });
                            if (!t) return console.warn("Failed to snapshot the document");
                            Jo({
                                type: ro.FullSnapshot,
                                data: {
                                    node: t,
                                    initialOffset: Ur(window)
                                }
                            }), ko.forEach((e => e.unlock())), document.adoptedStyleSheets && document.adoptedStyleSheets.length > 0 && X.adoptStyleSheets(document.adoptedStyleSheets, Vo.getId(document))
                        };
                    Ko = ee;
                    try {
                        const e = [],
                            t = e => So(Do)({
                                onMutation: P,
                                mutationCb: J,
                                mousemoveCb: (e, t) => Jo({
                                    type: ro.IncrementalSnapshot,
                                    data: {
                                        source: t,
                                        positions: e
                                    }
                                }),
                                mouseInteractionCb: e => Jo({
                                    type: ro.IncrementalSnapshot,
                                    data: {
                                        source: oo.MouseInteraction,
                                        ...e
                                    }
                                }),
                                scrollCb: K,
                                viewportResizeCb: e => Jo({
                                    type: ro.IncrementalSnapshot,
                                    data: {
                                        source: oo.ViewportResize,
                                        ...e
                                    }
                                }),
                                inputCb: e => Jo({
                                    type: ro.IncrementalSnapshot,
                                    data: {
                                        source: oo.Input,
                                        ...e
                                    }
                                }),
                                mediaInteractionCb: e => Jo({
                                    type: ro.IncrementalSnapshot,
                                    data: {
                                        source: oo.MediaInteraction,
                                        ...e
                                    }
                                }),
                                styleSheetRuleCb: e => Jo({
                                    type: ro.IncrementalSnapshot,
                                    data: {
                                        source: oo.StyleSheetRule,
                                        ...e
                                    }
                                }),
                                styleDeclarationCb: e => Jo({
                                    type: ro.IncrementalSnapshot,
                                    data: {
                                        source: oo.StyleDeclaration,
                                        ...e
                                    }
                                }),
                                canvasMutationCb: V,
                                fontCb: e => Jo({
                                    type: ro.IncrementalSnapshot,
                                    data: {
                                        source: oo.Font,
                                        ...e
                                    }
                                }),
                                selectionCb: e => {
                                    Jo({
                                        type: ro.IncrementalSnapshot,
                                        data: {
                                            source: oo.Selection,
                                            ...e
                                        }
                                    })
                                },
                                customElementCb: e => {
                                    Jo({
                                        type: ro.IncrementalSnapshot,
                                        data: {
                                            source: oo.CustomElement,
                                            ...e
                                        }
                                    })
                                },
                                blockClass: o,
                                ignoreClass: a,
                                ignoreSelector: c,
                                maskAllText: u,
                                maskTextClass: l,
                                unmaskTextClass: d,
                                maskTextSelector: p,
                                unmaskTextSelector: h,
                                maskInputOptions: z,
                                inlineStylesheet: f,
                                sampling: k,
                                recordDOM: T,
                                recordCanvas: I,
                                inlineImages: N,
                                userTriggeredOnInput: R,
                                collectFonts: A,
                                doc: e,
                                maskAttributeFn: y,
                                maskInputFn: v,
                                maskTextFn: b,
                                keepIframeSrcFn: D,
                                blockSelector: s,
                                unblockSelector: i,
                                slimDOMOptions: H,
                                dataURLOptions: C,
                                mirror: Vo,
                                iframeManager: Y,
                                stylesheetManager: X,
                                shadowDomManager: Z,
                                processedNodeManager: G,
                                canvasManager: Q,
                                ignoreCSSAttributes: O,
                                plugins: Ct([L, "optionalAccess", e => e.filter, "call", e => e((e => e.observer)), "optionalAccess", e => e.map, "call", e => e((e => ({
                                    observer: e.observer,
                                    options: e.options,
                                    callback: t => Jo({
                                        type: ro.Plugin,
                                        data: {
                                            plugin: e.name,
                                            payload: t
                                        }
                                    })
                                })))]) || []
                            }, {});
                        Y.addLoadListener((n => {
                            try {
                                e.push(t(n.contentDocument))
                            } catch (e) {
                                console.warn(e)
                            }
                        }));
                        const n = () => {
                            ee(), e.push(t(document))
                        };
                        return "interactive" === document.readyState || "complete" === document.readyState ? n() : (e.push(Nr("DOMContentLoaded", (() => {
                            Jo({
                                type: ro.DomContentLoaded,
                                data: {}
                            }), "DOMContentLoaded" === M && n()
                        }))), e.push(Nr("load", (() => {
                            Jo({
                                type: ro.Load,
                                data: {}
                            }), "load" === M && n()
                        }), window))), () => {
                            e.forEach((e => e())), G.destroy(), Ko = void 0, bo()
                        }
                    } catch (e) {
                        console.warn(e)
                    }
                }
                Xo.mirror = Vo, Xo.takeFullSnapshot = function(e) {
                    if (!Ko) throw new Error("please take full snapshot after start recording");
                    Ko(e)
                };

                function Yo(e) {
                    return e > 9999999999 ? e : 1e3 * e
                }

                function Go(e) {
                    return e > 9999999999 ? e / 1e3 : e
                }

                function Qo(e, t) {
                    "sentry.transaction" !== t.category && (["ui.click", "ui.input"].includes(t.category) ? e.triggerUserActivity() : e.checkAndHandleExpiredSession(), e.addUpdate((() => (e.throttledAddEvent({
                        type: ro.Custom,
                        timestamp: 1e3 * (t.timestamp || 0),
                        data: {
                            tag: "breadcrumb",
                            payload: (0, pe.S8)(t, 10, 1e3)
                        }
                    }), "console" === t.category))))
                }

                function Zo(e) {
                    return e.closest("button,a") || e
                }

                function es(e) {
                    const t = ts(e);
                    return t && t instanceof Element ? Zo(t) : t
                }

                function ts(e) {
                    return function(e) {
                        return "object" == typeof e && !!e && "target" in e
                    }(e) ? e.target : e
                }
                let ns;

                function rs(e) {
                    return ns || (ns = [], (0, T.GS)(On, "open", (function(e) {
                        return function(...t) {
                            if (ns) try {
                                ns.forEach((e => e()))
                            } catch (e) {}
                            return e.apply(On, t)
                        }
                    }))), ns.push(e), () => {
                        const t = ns ? ns.indexOf(e) : -1;
                        t > -1 && ns.splice(t, 1)
                    }
                }
                class os {
                    constructor(e, t, n = Qo) {
                        this._lastMutation = 0, this._lastScroll = 0, this._clicks = [], this._timeout = t.timeout / 1e3, this._threshold = t.threshold / 1e3, this._scollTimeout = t.scrollTimeout / 1e3, this._replay = e, this._ignoreSelector = t.ignoreSelector, this._addBreadcrumbEvent = n
                    }
                    addListeners() {
                        const e = rs((() => {
                            this._lastMutation = is()
                        }));
                        this._teardown = () => {
                            e(), this._clicks = [], this._lastMutation = 0, this._lastScroll = 0
                        }
                    }
                    removeListeners() {
                        this._teardown && this._teardown(), this._checkClickTimeout && clearTimeout(this._checkClickTimeout)
                    }
                    handleClick(e, t) {
                        if (function(e, t) {
                                if (!ss.includes(e.tagName)) return !0;
                                if ("INPUT" === e.tagName && !["submit", "button"].includes(e.getAttribute("type") || "")) return !0;
                                if ("A" === e.tagName && (e.hasAttribute("download") || e.hasAttribute("target") && "_self" !== e.getAttribute("target"))) return !0;
                                if (t && e.matches(t)) return !0;
                                return !1
                            }(t, this._ignoreSelector) || ! function(e) {
                                return !(!e.data || "number" != typeof e.data.nodeId || !e.timestamp)
                            }(e)) return;
                        const n = {
                            timestamp: Go(e.timestamp),
                            clickBreadcrumb: e,
                            clickCount: 0,
                            node: t
                        };
                        this._clicks.some((e => e.node === n.node && Math.abs(e.timestamp - n.timestamp) < 1)) || (this._clicks.push(n), 1 === this._clicks.length && this._scheduleCheckClicks())
                    }
                    registerMutation(e = Date.now()) {
                        this._lastMutation = Go(e)
                    }
                    registerScroll(e = Date.now()) {
                        this._lastScroll = Go(e)
                    }
                    registerClick(e) {
                        const t = Zo(e);
                        this._handleMultiClick(t)
                    }
                    _handleMultiClick(e) {
                        this._getClicks(e).forEach((e => {
                            e.clickCount++
                        }))
                    }
                    _getClicks(e) {
                        return this._clicks.filter((t => t.node === e))
                    }
                    _checkClicks() {
                        const e = [],
                            t = is();
                        this._clicks.forEach((n => {
                            !n.mutationAfter && this._lastMutation && (n.mutationAfter = n.timestamp <= this._lastMutation ? this._lastMutation - n.timestamp : void 0), !n.scrollAfter && this._lastScroll && (n.scrollAfter = n.timestamp <= this._lastScroll ? this._lastScroll - n.timestamp : void 0), n.timestamp + this._timeout <= t && e.push(n)
                        }));
                        for (const t of e) {
                            const e = this._clicks.indexOf(t);
                            e > -1 && (this._generateBreadcrumbs(t), this._clicks.splice(e, 1))
                        }
                        this._clicks.length && this._scheduleCheckClicks()
                    }
                    _generateBreadcrumbs(e) {
                        const t = this._replay,
                            n = e.scrollAfter && e.scrollAfter <= this._scollTimeout,
                            r = e.mutationAfter && e.mutationAfter <= this._threshold,
                            o = !n && !r,
                            {
                                clickCount: s,
                                clickBreadcrumb: i
                            } = e;
                        if (o) {
                            const n = 1e3 * Math.min(e.mutationAfter || this._timeout, this._timeout),
                                r = n < 1e3 * this._timeout ? "mutation" : "timeout",
                                o = {
                                    type: "default",
                                    message: i.message,
                                    timestamp: i.timestamp,
                                    category: "ui.slowClickDetected",
                                    data: { ...i.data,
                                        url: On.location.href,
                                        route: t.getCurrentRoute(),
                                        timeAfterClickMs: n,
                                        endReason: r,
                                        clickCount: s || 1
                                    }
                                };
                            this._addBreadcrumbEvent(t, o)
                        } else if (s > 1) {
                            const e = {
                                type: "default",
                                message: i.message,
                                timestamp: i.timestamp,
                                category: "ui.multiClick",
                                data: { ...i.data,
                                    url: On.location.href,
                                    route: t.getCurrentRoute(),
                                    clickCount: s,
                                    metric: !0
                                }
                            };
                            this._addBreadcrumbEvent(t, e)
                        }
                    }
                    _scheduleCheckClicks() {
                        this._checkClickTimeout && clearTimeout(this._checkClickTimeout), this._checkClickTimeout = (0, At.wg)((() => this._checkClicks()), 1e3)
                    }
                }
                const ss = ["A", "BUTTON", "INPUT"];

                function is() {
                    return Date.now() / 1e3
                }

                function as(e, t) {
                    try {
                        if (! function(e) {
                                return 3 === e.type
                            }(t)) return;
                        const {
                            source: n
                        } = t.data;
                        if (n === oo.Mutation && e.registerMutation(t.timestamp), n === oo.Scroll && e.registerScroll(t.timestamp), function(e) {
                                return e.data.source === oo.MouseInteraction
                            }(t)) {
                            const {
                                type: n,
                                id: r
                            } = t.data, o = Xo.mirror.getNode(r);
                            o instanceof HTMLElement && n === so.Click && e.registerClick(o)
                        }
                    } catch (e) {}
                }

                function cs(e) {
                    return {
                        timestamp: Date.now() / 1e3,
                        type: "default",
                        ...e
                    }
                }
                var us;
                ! function(e) {
                    e[e.Document = 0] = "Document", e[e.DocumentType = 1] = "DocumentType", e[e.Element = 2] = "Element", e[e.Text = 3] = "Text", e[e.CDATA = 4] = "CDATA", e[e.Comment = 5] = "Comment"
                }(us || (us = {}));
                const ls = new Set(["id", "class", "aria-label", "role", "name", "alt", "title", "data-test-id", "data-testid", "disabled", "aria-disabled", "data-sentry-component"]);

                function ds(e) {
                    const t = {};
                    !e["data-sentry-component"] && e["data-sentry-element"] && (e["data-sentry-component"] = e["data-sentry-element"]);
                    for (const n in e)
                        if (ls.has(n)) {
                            let r = n;
                            "data-testid" !== n && "data-test-id" !== n || (r = "testId"), t[r] = e[n]
                        }
                    return t
                }
                const ps = e => t => {
                    if (!e.isEnabled()) return;
                    const n = function(e) {
                        const {
                            target: t,
                            message: n
                        } = function(e) {
                            const t = "click" === e.name;
                            let n, r = null;
                            try {
                                r = t ? es(e.event) : ts(e.event), n = (0, Tt.Hd)(r, {
                                    maxStringLength: 200
                                }) || "<unknown>"
                            } catch (e) {
                                n = "<unknown>"
                            }
                            return {
                                target: r,
                                message: n
                            }
                        }(e);
                        return cs({
                            category: `ui.${e.name}`,
                            ...hs(t, n)
                        })
                    }(t);
                    if (!n) return;
                    const r = "click" === t.name,
                        o = r ? t.event : void 0;
                    var s, i, a;
                    !(r && e.clickDetector && o && o.target) || o.altKey || o.metaKey || o.ctrlKey || o.shiftKey || (s = e.clickDetector, i = n, a = es(t.event), s.handleClick(i, a)), Qo(e, n)
                };

                function hs(e, t) {
                    const n = Xo.mirror.getId(e),
                        r = n && Xo.mirror.getNode(n),
                        o = r && Xo.mirror.getMeta(r),
                        s = o && function(e) {
                            return e.type === us.Element
                        }(o) ? o : null;
                    return {
                        message: t,
                        data: s ? {
                            nodeId: n,
                            node: {
                                id: n,
                                tagName: s.tagName,
                                textContent: Array.from(s.childNodes).map((e => e.type === us.Text && e.textContent)).filter(Boolean).map((e => e.trim())).join(""),
                                attributes: ds(s.attributes)
                            }
                        } : {}
                    }
                }

                function fs(e, t) {
                    if (!e.isEnabled()) return;
                    e.updateUserActivity();
                    const n = function(e) {
                        const {
                            metaKey: t,
                            shiftKey: n,
                            ctrlKey: r,
                            altKey: o,
                            key: s,
                            target: i
                        } = e;
                        if (!i || function(e) {
                                return "INPUT" === e.tagName || "TEXTAREA" === e.tagName || e.isContentEditable
                            }(i) || !s) return null;
                        const a = t || r || o,
                            c = 1 === s.length;
                        if (!a && c) return null;
                        const u = (0, Tt.Hd)(i, {
                                maxStringLength: 200
                            }) || "<unknown>",
                            l = hs(i, u);
                        return cs({
                            category: "ui.keyDown",
                            message: u,
                            data: { ...l.data,
                                metaKey: t,
                                shiftKey: n,
                                ctrlKey: r,
                                altKey: o,
                                key: s
                            }
                        })
                    }(t);
                    n && Qo(e, n)
                }
                const ms = {
                    resource: function(e) {
                        const {
                            entryType: t,
                            initiatorType: n,
                            name: r,
                            responseEnd: o,
                            startTime: s,
                            decodedBodySize: i,
                            encodedBodySize: a,
                            responseStatus: c,
                            transferSize: u
                        } = e;
                        if (["fetch", "xmlhttprequest"].includes(n)) return null;
                        return {
                            type: `${t}.${n}`,
                            start: ys(s),
                            end: ys(o),
                            name: r,
                            data: {
                                size: u,
                                statusCode: c,
                                decodedBodySize: i,
                                encodedBodySize: a
                            }
                        }
                    },
                    paint: function(e) {
                        const {
                            duration: t,
                            entryType: n,
                            name: r,
                            startTime: o
                        } = e, s = ys(o);
                        return {
                            type: n,
                            name: r,
                            start: s,
                            end: s + t,
                            data: void 0
                        }
                    },
                    navigation: function(e) {
                        const {
                            entryType: t,
                            name: n,
                            decodedBodySize: r,
                            duration: o,
                            domComplete: s,
                            encodedBodySize: i,
                            domContentLoadedEventStart: a,
                            domContentLoadedEventEnd: c,
                            domInteractive: u,
                            loadEventStart: l,
                            loadEventEnd: d,
                            redirectCount: p,
                            startTime: h,
                            transferSize: f,
                            type: m
                        } = e;
                        if (0 === o) return null;
                        return {
                            type: `${t}.${m}`,
                            start: ys(h),
                            end: ys(s),
                            name: n,
                            data: {
                                size: f,
                                decodedBodySize: r,
                                encodedBodySize: i,
                                duration: o,
                                domInteractive: u,
                                domContentLoadedEventStart: a,
                                domContentLoadedEventEnd: c,
                                loadEventStart: l,
                                loadEventEnd: d,
                                domComplete: s,
                                redirectCount: p
                            }
                        }
                    }
                };

                function gs(e, t) {
                    return ({
                        metric: n
                    }) => {
                        t.replayPerformanceEntries.push(e(n))
                    }
                }

                function _s(e) {
                    const t = ms[e.entryType];
                    return t ? t(e) : null
                }

                function ys(e) {
                    return ((U.k3 || On.performance.timeOrigin) + e) / 1e3
                }

                function vs(e) {
                    const t = e.entries[e.entries.length - 1];
                    return ks(e, "largest-contentful-paint", t && t.element ? [t.element] : void 0)
                }

                function bs(e) {
                    const t = e.entries[e.entries.length - 1],
                        n = [];
                    if (t && t.sources)
                        for (const e of t.sources) e.node && n.push(e.node);
                    return ks(e, "cumulative-layout-shift", n)
                }

                function Ss(e) {
                    const t = e.entries[e.entries.length - 1];
                    return ks(e, "first-input-delay", t && t.target ? [t.target] : void 0)
                }

                function ws(e) {
                    const t = e.entries[e.entries.length - 1];
                    return ks(e, "interaction-to-next-paint", t && t.target ? [t.target] : void 0)
                }

                function ks(e, t, n) {
                    const r = e.value,
                        o = e.rating,
                        s = ys(r);
                    return {
                        type: "web-vital",
                        name: t,
                        start: s,
                        end: s,
                        data: {
                            value: r,
                            size: r,
                            rating: o,
                            nodeIds: n ? n.map((e => Xo.mirror.getId(e))) : void 0
                        }
                    }
                }
                const Cs = !1;
                class xs extends Error {
                    constructor() {
                        super("Event buffer exceeded maximum size of 20000000.")
                    }
                }
                class Ts {
                    constructor() {
                        this.events = [], this._totalSize = 0, this.hasCheckout = !1
                    }
                    get hasEvents() {
                        return this.events.length > 0
                    }
                    get type() {
                        return "sync"
                    }
                    destroy() {
                        this.events = []
                    }
                    async addEvent(e) {
                        const t = JSON.stringify(e).length;
                        if (this._totalSize += t, this._totalSize > jn) throw new xs;
                        this.events.push(e)
                    }
                    finish() {
                        return new Promise((e => {
                            const t = this.events;
                            this.clear(), e(JSON.stringify(t))
                        }))
                    }
                    clear() {
                        this.events = [], this._totalSize = 0, this.hasCheckout = !1
                    }
                    getEarliestTimestamp() {
                        const e = this.events.map((e => e.timestamp)).sort()[0];
                        return e ? Yo(e) : null
                    }
                }
                class Is {
                    constructor(e) {
                        this._worker = e, this._id = 0
                    }
                    ensureReady() {
                        return this._ensureReadyPromise || (this._ensureReadyPromise = new Promise(((e, t) => {
                            this._worker.addEventListener("message", (({
                                data: n
                            }) => {
                                n.success ? e() : t()
                            }), {
                                once: !0
                            }), this._worker.addEventListener("error", (e => {
                                t(e)
                            }), {
                                once: !0
                            })
                        }))), this._ensureReadyPromise
                    }
                    destroy() {
                        this._worker.terminate()
                    }
                    postMessage(e, t) {
                        const n = this._getAndIncrementId();
                        return new Promise(((r, o) => {
                            const s = ({
                                data: t
                            }) => {
                                const i = t;
                                i.method === e && i.id === n && (this._worker.removeEventListener("message", s), i.success ? r(i.response) : o(new Error("Error in compression worker")))
                            };
                            this._worker.addEventListener("message", s), this._worker.postMessage({
                                id: n,
                                method: e,
                                arg: t
                            })
                        }))
                    }
                    _getAndIncrementId() {
                        return this._id++
                    }
                }
                class Es {
                    constructor(e) {
                        this._worker = new Is(e), this._earliestTimestamp = null, this._totalSize = 0, this.hasCheckout = !1
                    }
                    get hasEvents() {
                        return !!this._earliestTimestamp
                    }
                    get type() {
                        return "worker"
                    }
                    ensureReady() {
                        return this._worker.ensureReady()
                    }
                    destroy() {
                        this._worker.destroy()
                    }
                    addEvent(e) {
                        const t = Yo(e.timestamp);
                        (!this._earliestTimestamp || t < this._earliestTimestamp) && (this._earliestTimestamp = t);
                        const n = JSON.stringify(e);
                        return this._totalSize += n.length, this._totalSize > jn ? Promise.reject(new xs) : this._sendEventToWorker(n)
                    }
                    finish() {
                        return this._finishRequest()
                    }
                    clear() {
                        this._earliestTimestamp = null, this._totalSize = 0, this.hasCheckout = !1, this._worker.postMessage("clear").then(null, (e => {}))
                    }
                    getEarliestTimestamp() {
                        return this._earliestTimestamp
                    }
                    _sendEventToWorker(e) {
                        return this._worker.postMessage("addEvent", e)
                    }
                    async _finishRequest() {
                        const e = await this._worker.postMessage("finish");
                        return this._earliestTimestamp = null, this._totalSize = 0, e
                    }
                }
                class Ms {
                    constructor(e) {
                        this._fallback = new Ts, this._compression = new Es(e), this._used = this._fallback, this._ensureWorkerIsLoadedPromise = this._ensureWorkerIsLoaded()
                    }
                    get type() {
                        return this._used.type
                    }
                    get hasEvents() {
                        return this._used.hasEvents
                    }
                    get hasCheckout() {
                        return this._used.hasCheckout
                    }
                    set hasCheckout(e) {
                        this._used.hasCheckout = e
                    }
                    destroy() {
                        this._fallback.destroy(), this._compression.destroy()
                    }
                    clear() {
                        return this._used.clear()
                    }
                    getEarliestTimestamp() {
                        return this._used.getEarliestTimestamp()
                    }
                    addEvent(e) {
                        return this._used.addEvent(e)
                    }
                    async finish() {
                        return await this.ensureWorkerIsLoaded(), this._used.finish()
                    }
                    ensureWorkerIsLoaded() {
                        return this._ensureWorkerIsLoadedPromise
                    }
                    async _ensureWorkerIsLoaded() {
                        try {
                            await this._compression.ensureReady()
                        } catch (e) {
                            return
                        }
                        await this._switchToCompressionWorker()
                    }
                    async _switchToCompressionWorker() {
                        const {
                            events: e,
                            hasCheckout: t
                        } = this._fallback, n = [];
                        for (const t of e) n.push(this._compression.addEvent(t));
                        this._compression.hasCheckout = t, this._used = this._compression;
                        try {
                            await Promise.all(n)
                        } catch (e) {}
                    }
                }

                function Rs({
                    useCompression: e,
                    workerUrl: t
                }) {
                    if (e && window.Worker) {
                        const e = function(e) {
                            try {
                                const t = e || function() {
                                    if ("undefined" == typeof __SENTRY_EXCLUDE_REPLAY_WORKER__ || !__SENTRY_EXCLUDE_REPLAY_WORKER__) return function() {
                                        const e = new Blob(['var t=Uint8Array,n=Uint16Array,r=Int32Array,e=new t([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),i=new t([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),a=new t([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),s=function(t,e){for(var i=new n(31),a=0;a<31;++a)i[a]=e+=1<<t[a-1];var s=new r(i[30]);for(a=1;a<30;++a)for(var o=i[a];o<i[a+1];++o)s[o]=o-i[a]<<5|a;return{b:i,r:s}},o=s(e,2),f=o.b,h=o.r;f[28]=258,h[258]=28;for(var l=s(i,0).r,u=new n(32768),c=0;c<32768;++c){var v=(43690&c)>>1|(21845&c)<<1;v=(61680&(v=(52428&v)>>2|(13107&v)<<2))>>4|(3855&v)<<4,u[c]=((65280&v)>>8|(255&v)<<8)>>1}var d=function(t,r,e){for(var i=t.length,a=0,s=new n(r);a<i;++a)t[a]&&++s[t[a]-1];var o,f=new n(r);for(a=1;a<r;++a)f[a]=f[a-1]+s[a-1]<<1;if(e){o=new n(1<<r);var h=15-r;for(a=0;a<i;++a)if(t[a])for(var l=a<<4|t[a],c=r-t[a],v=f[t[a]-1]++<<c,d=v|(1<<c)-1;v<=d;++v)o[u[v]>>h]=l}else for(o=new n(i),a=0;a<i;++a)t[a]&&(o[a]=u[f[t[a]-1]++]>>15-t[a]);return o},g=new t(288);for(c=0;c<144;++c)g[c]=8;for(c=144;c<256;++c)g[c]=9;for(c=256;c<280;++c)g[c]=7;for(c=280;c<288;++c)g[c]=8;var w=new t(32);for(c=0;c<32;++c)w[c]=5;var p=d(g,9,0),y=d(w,5,0),m=function(t){return(t+7)/8|0},b=function(n,r,e){return(null==r||r<0)&&(r=0),(null==e||e>n.length)&&(e=n.length),new t(n.subarray(r,e))},M=["unexpected EOF","invalid block type","invalid length/literal","invalid distance","stream finished","no stream handler",,"no callback","invalid UTF-8 data","extra field too long","date not in range 1980-2099","filename too long","stream finishing","invalid zip data"],E=function(t,n,r){var e=new Error(n||M[t]);if(e.code=t,Error.captureStackTrace&&Error.captureStackTrace(e,E),!r)throw e;return e},z=function(t,n,r){r<<=7&n;var e=n/8|0;t[e]|=r,t[e+1]|=r>>8},A=function(t,n,r){r<<=7&n;var e=n/8|0;t[e]|=r,t[e+1]|=r>>8,t[e+2]|=r>>16},_=function(r,e){for(var i=[],a=0;a<r.length;++a)r[a]&&i.push({s:a,f:r[a]});var s=i.length,o=i.slice();if(!s)return{t:F,l:0};if(1==s){var f=new t(i[0].s+1);return f[i[0].s]=1,{t:f,l:1}}i.sort((function(t,n){return t.f-n.f})),i.push({s:-1,f:25001});var h=i[0],l=i[1],u=0,c=1,v=2;for(i[0]={s:-1,f:h.f+l.f,l:h,r:l};c!=s-1;)h=i[i[u].f<i[v].f?u++:v++],l=i[u!=c&&i[u].f<i[v].f?u++:v++],i[c++]={s:-1,f:h.f+l.f,l:h,r:l};var d=o[0].s;for(a=1;a<s;++a)o[a].s>d&&(d=o[a].s);var g=new n(d+1),w=x(i[c-1],g,0);if(w>e){a=0;var p=0,y=w-e,m=1<<y;for(o.sort((function(t,n){return g[n.s]-g[t.s]||t.f-n.f}));a<s;++a){var b=o[a].s;if(!(g[b]>e))break;p+=m-(1<<w-g[b]),g[b]=e}for(p>>=y;p>0;){var M=o[a].s;g[M]<e?p-=1<<e-g[M]++-1:++a}for(;a>=0&&p;--a){var E=o[a].s;g[E]==e&&(--g[E],++p)}w=e}return{t:new t(g),l:w}},x=function(t,n,r){return-1==t.s?Math.max(x(t.l,n,r+1),x(t.r,n,r+1)):n[t.s]=r},D=function(t){for(var r=t.length;r&&!t[--r];);for(var e=new n(++r),i=0,a=t[0],s=1,o=function(t){e[i++]=t},f=1;f<=r;++f)if(t[f]==a&&f!=r)++s;else{if(!a&&s>2){for(;s>138;s-=138)o(32754);s>2&&(o(s>10?s-11<<5|28690:s-3<<5|12305),s=0)}else if(s>3){for(o(a),--s;s>6;s-=6)o(8304);s>2&&(o(s-3<<5|8208),s=0)}for(;s--;)o(a);s=1,a=t[f]}return{c:e.subarray(0,i),n:r}},T=function(t,n){for(var r=0,e=0;e<n.length;++e)r+=t[e]*n[e];return r},k=function(t,n,r){var e=r.length,i=m(n+2);t[i]=255&e,t[i+1]=e>>8,t[i+2]=255^t[i],t[i+3]=255^t[i+1];for(var a=0;a<e;++a)t[i+a+4]=r[a];return 8*(i+4+e)},C=function(t,r,s,o,f,h,l,u,c,v,m){z(r,m++,s),++f[256];for(var b=_(f,15),M=b.t,E=b.l,x=_(h,15),C=x.t,U=x.l,F=D(M),I=F.c,S=F.n,L=D(C),O=L.c,j=L.n,q=new n(19),B=0;B<I.length;++B)++q[31&I[B]];for(B=0;B<O.length;++B)++q[31&O[B]];for(var G=_(q,7),H=G.t,J=G.l,K=19;K>4&&!H[a[K-1]];--K);var N,P,Q,R,V=v+5<<3,W=T(f,g)+T(h,w)+l,X=T(f,M)+T(h,C)+l+14+3*K+T(q,H)+2*q[16]+3*q[17]+7*q[18];if(c>=0&&V<=W&&V<=X)return k(r,m,t.subarray(c,c+v));if(z(r,m,1+(X<W)),m+=2,X<W){N=d(M,E,0),P=M,Q=d(C,U,0),R=C;var Y=d(H,J,0);z(r,m,S-257),z(r,m+5,j-1),z(r,m+10,K-4),m+=14;for(B=0;B<K;++B)z(r,m+3*B,H[a[B]]);m+=3*K;for(var Z=[I,O],$=0;$<2;++$){var tt=Z[$];for(B=0;B<tt.length;++B){var nt=31&tt[B];z(r,m,Y[nt]),m+=H[nt],nt>15&&(z(r,m,tt[B]>>5&127),m+=tt[B]>>12)}}}else N=p,P=g,Q=y,R=w;for(B=0;B<u;++B){var rt=o[B];if(rt>255){A(r,m,N[(nt=rt>>18&31)+257]),m+=P[nt+257],nt>7&&(z(r,m,rt>>23&31),m+=e[nt]);var et=31&rt;A(r,m,Q[et]),m+=R[et],et>3&&(A(r,m,rt>>5&8191),m+=i[et])}else A(r,m,N[rt]),m+=P[rt]}return A(r,m,N[256]),m+P[256]},U=new r([65540,131080,131088,131104,262176,1048704,1048832,2114560,2117632]),F=new t(0),I=function(){for(var t=new Int32Array(256),n=0;n<256;++n){for(var r=n,e=9;--e;)r=(1&r&&-306674912)^r>>>1;t[n]=r}return t}(),S=function(){var t=-1;return{p:function(n){for(var r=t,e=0;e<n.length;++e)r=I[255&r^n[e]]^r>>>8;t=r},d:function(){return~t}}},L=function(){var t=1,n=0;return{p:function(r){for(var e=t,i=n,a=0|r.length,s=0;s!=a;){for(var o=Math.min(s+2655,a);s<o;++s)i+=e+=r[s];e=(65535&e)+15*(e>>16),i=(65535&i)+15*(i>>16)}t=e,n=i},d:function(){return(255&(t%=65521))<<24|(65280&t)<<8|(255&(n%=65521))<<8|n>>8}}},O=function(a,s,o,f,u){if(!u&&(u={l:1},s.dictionary)){var c=s.dictionary.subarray(-32768),v=new t(c.length+a.length);v.set(c),v.set(a,c.length),a=v,u.w=c.length}return function(a,s,o,f,u,c){var v=c.z||a.length,d=new t(f+v+5*(1+Math.ceil(v/7e3))+u),g=d.subarray(f,d.length-u),w=c.l,p=7&(c.r||0);if(s){p&&(g[0]=c.r>>3);for(var y=U[s-1],M=y>>13,E=8191&y,z=(1<<o)-1,A=c.p||new n(32768),_=c.h||new n(z+1),x=Math.ceil(o/3),D=2*x,T=function(t){return(a[t]^a[t+1]<<x^a[t+2]<<D)&z},F=new r(25e3),I=new n(288),S=new n(32),L=0,O=0,j=c.i||0,q=0,B=c.w||0,G=0;j+2<v;++j){var H=T(j),J=32767&j,K=_[H];if(A[J]=K,_[H]=J,B<=j){var N=v-j;if((L>7e3||q>24576)&&(N>423||!w)){p=C(a,g,0,F,I,S,O,q,G,j-G,p),q=L=O=0,G=j;for(var P=0;P<286;++P)I[P]=0;for(P=0;P<30;++P)S[P]=0}var Q=2,R=0,V=E,W=J-K&32767;if(N>2&&H==T(j-W))for(var X=Math.min(M,N)-1,Y=Math.min(32767,j),Z=Math.min(258,N);W<=Y&&--V&&J!=K;){if(a[j+Q]==a[j+Q-W]){for(var $=0;$<Z&&a[j+$]==a[j+$-W];++$);if($>Q){if(Q=$,R=W,$>X)break;var tt=Math.min(W,$-2),nt=0;for(P=0;P<tt;++P){var rt=j-W+P&32767,et=rt-A[rt]&32767;et>nt&&(nt=et,K=rt)}}}W+=(J=K)-(K=A[J])&32767}if(R){F[q++]=268435456|h[Q]<<18|l[R];var it=31&h[Q],at=31&l[R];O+=e[it]+i[at],++I[257+it],++S[at],B=j+Q,++L}else F[q++]=a[j],++I[a[j]]}}for(j=Math.max(j,B);j<v;++j)F[q++]=a[j],++I[a[j]];p=C(a,g,w,F,I,S,O,q,G,j-G,p),w||(c.r=7&p|g[p/8|0]<<3,p-=7,c.h=_,c.p=A,c.i=j,c.w=B)}else{for(j=c.w||0;j<v+w;j+=65535){var st=j+65535;st>=v&&(g[p/8|0]=w,st=v),p=k(g,p+1,a.subarray(j,st))}c.i=v}return b(d,0,f+m(p)+u)}(a,null==s.level?6:s.level,null==s.mem?Math.ceil(1.5*Math.max(8,Math.min(13,Math.log(a.length)))):12+s.mem,o,f,u)},j=function(t,n,r){for(;r;++n)t[n]=r,r>>>=8},q=function(t,n){var r=n.filename;if(t[0]=31,t[1]=139,t[2]=8,t[8]=n.level<2?4:9==n.level?2:0,t[9]=3,0!=n.mtime&&j(t,4,Math.floor(new Date(n.mtime||Date.now())/1e3)),r){t[3]=8;for(var e=0;e<=r.length;++e)t[e+10]=r.charCodeAt(e)}},B=function(t){return 10+(t.filename?t.filename.length+1:0)},G=function(){function n(n,r){if("function"==typeof n&&(r=n,n={}),this.ondata=r,this.o=n||{},this.s={l:0,i:32768,w:32768,z:32768},this.b=new t(98304),this.o.dictionary){var e=this.o.dictionary.subarray(-32768);this.b.set(e,32768-e.length),this.s.i=32768-e.length}}return n.prototype.p=function(t,n){this.ondata(O(t,this.o,0,0,this.s),n)},n.prototype.push=function(n,r){this.ondata||E(5),this.s.l&&E(4);var e=n.length+this.s.z;if(e>this.b.length){if(e>2*this.b.length-32768){var i=new t(-32768&e);i.set(this.b.subarray(0,this.s.z)),this.b=i}var a=this.b.length-this.s.z;a&&(this.b.set(n.subarray(0,a),this.s.z),this.s.z=this.b.length,this.p(this.b,!1)),this.b.set(this.b.subarray(-32768)),this.b.set(n.subarray(a),32768),this.s.z=n.length-a+32768,this.s.i=32766,this.s.w=32768}else this.b.set(n,this.s.z),this.s.z+=n.length;this.s.l=1&r,(this.s.z>this.s.w+8191||r)&&(this.p(this.b,r||!1),this.s.w=this.s.i,this.s.i-=2)},n}();var H=function(){function t(t,n){this.c=L(),this.v=1,G.call(this,t,n)}return t.prototype.push=function(t,n){this.c.p(t),G.prototype.push.call(this,t,n)},t.prototype.p=function(t,n){var r=O(t,this.o,this.v&&(this.o.dictionary?6:2),n&&4,this.s);this.v&&(function(t,n){var r=n.level,e=0==r?0:r<6?1:9==r?3:2;if(t[0]=120,t[1]=e<<6|(n.dictionary&&32),t[1]|=31-(t[0]<<8|t[1])%31,n.dictionary){var i=L();i.p(n.dictionary),j(t,2,i.d())}}(r,this.o),this.v=0),n&&j(r,r.length-4,this.c.d()),this.ondata(r,n)},t}(),J="undefined"!=typeof TextEncoder&&new TextEncoder,K="undefined"!=typeof TextDecoder&&new TextDecoder;try{K.decode(F,{stream:!0})}catch(t){}var N=function(){function t(t){this.ondata=t}return t.prototype.push=function(t,n){this.ondata||E(5),this.d&&E(4),this.ondata(P(t),this.d=n||!1)},t}();function P(n,r){if(r){for(var e=new t(n.length),i=0;i<n.length;++i)e[i]=n.charCodeAt(i);return e}if(J)return J.encode(n);var a=n.length,s=new t(n.length+(n.length>>1)),o=0,f=function(t){s[o++]=t};for(i=0;i<a;++i){if(o+5>s.length){var h=new t(o+8+(a-i<<1));h.set(s),s=h}var l=n.charCodeAt(i);l<128||r?f(l):l<2048?(f(192|l>>6),f(128|63&l)):l>55295&&l<57344?(f(240|(l=65536+(1047552&l)|1023&n.charCodeAt(++i))>>18),f(128|l>>12&63),f(128|l>>6&63),f(128|63&l)):(f(224|l>>12),f(128|l>>6&63),f(128|63&l))}return b(s,0,o)}function Q(t){return function(t,n){n||(n={});var r=S(),e=t.length;r.p(t);var i=O(t,n,B(n),8),a=i.length;return q(i,n),j(i,a-8,r.d()),j(i,a-4,e),i}(P(t))}const R=new class{constructor(){this._init()}clear(){this._init()}addEvent(t){if(!t)throw new Error("Adding invalid event");const n=this._hasEvents?",":"";this.stream.push(n+t),this._hasEvents=!0}finish(){this.stream.push("]",!0);const t=function(t){let n=0;for(const r of t)n+=r.length;const r=new Uint8Array(n);for(let n=0,e=0,i=t.length;n<i;n++){const i=t[n];r.set(i,e),e+=i.length}return r}(this._deflatedData);return this._init(),t}_init(){this._hasEvents=!1,this._deflatedData=[],this.deflate=new H,this.deflate.ondata=(t,n)=>{this._deflatedData.push(t)},this.stream=new N(((t,n)=>{this.deflate.push(t,n)})),this.stream.push("[")}},V={clear:()=>{R.clear()},addEvent:t=>R.addEvent(t),finish:()=>R.finish(),compress:t=>Q(t)};addEventListener("message",(function(t){const n=t.data.method,r=t.data.id,e=t.data.arg;if(n in V&&"function"==typeof V[n])try{const t=V[n](e);postMessage({id:r,method:n,success:!0,response:t})}catch(t){postMessage({id:r,method:n,success:!1,response:t.message}),console.error(t)}})),postMessage({id:void 0,method:"init",success:!0,response:void 0});']);
                                        return URL.createObjectURL(e)
                                    }();
                                    return ""
                                }();
                                if (!t) return;
                                const n = new Worker(t);
                                return new Ms(n)
                            } catch (e) {}
                        }(t);
                        if (e) return e
                    }
                    return new Ts
                }

                function As() {
                    try {
                        return "sessionStorage" in On && !!On.sessionStorage
                    } catch (e) {
                        return !1
                    }
                }

                function Ns(e) {
                    ! function() {
                        if (!As()) return;
                        try {
                            On.sessionStorage.removeItem(Fn)
                        } catch (e) {}
                    }(), e.session = void 0
                }

                function Ls(e) {
                    return void 0 !== e && Math.random() < e
                }

                function Ds(e) {
                    const t = Date.now();
                    return {
                        id: e.id || (0, w.eJ)(),
                        started: e.started || t,
                        lastActivity: e.lastActivity || t,
                        segmentId: e.segmentId || 0,
                        sampled: e.sampled,
                        previousSessionId: e.previousSessionId
                    }
                }

                function Os(e) {
                    if (As()) try {
                        On.sessionStorage.setItem(Fn, JSON.stringify(e))
                    } catch (e) {}
                }

                function Fs({
                    sessionSampleRate: e,
                    allowBuffering: t,
                    stickySession: n = !1
                }, {
                    previousSessionId: r
                } = {}) {
                    const o = function(e, t) {
                            return Ls(e) ? "session" : !!t && "buffer"
                        }(e, t),
                        s = Ds({
                            sampled: o,
                            previousSessionId: r
                        });
                    return n && Os(s), s
                }

                function Ps(e, t, n = +new Date) {
                    return null === e || void 0 === t || t < 0 || 0 !== t && e + t <= n
                }

                function Bs(e, {
                    maxReplayDuration: t,
                    sessionIdleExpire: n,
                    targetTime: r = Date.now()
                }) {
                    return Ps(e.started, t, r) || Ps(e.lastActivity, n, r)
                }

                function Us(e, {
                    sessionIdleExpire: t,
                    maxReplayDuration: n
                }) {
                    return !!Bs(e, {
                        sessionIdleExpire: t,
                        maxReplayDuration: n
                    }) && ("buffer" !== e.sampled || 0 !== e.segmentId)
                }

                function js({
                    traceInternals: e,
                    sessionIdleExpire: t,
                    maxReplayDuration: n,
                    previousSessionId: r
                }, o) {
                    const s = o.stickySession && function() {
                        if (!As()) return null;
                        try {
                            const e = On.sessionStorage.getItem(Fn);
                            return e ? Ds(JSON.parse(e)) : null
                        } catch (e) {
                            return null
                        }
                    }();
                    return s ? Us(s, {
                        sessionIdleExpire: t,
                        maxReplayDuration: n
                    }) ? Fs(o, {
                        previousSessionId: s.id
                    }) : s : Fs(o, {
                        previousSessionId: r
                    })
                }

                function zs(e, t, n) {
                    return !!$s(e, t) && (Hs(e, t, n), !0)
                }
                async function Hs(e, t, n) {
                    if (!e.eventBuffer) return null;
                    try {
                        n && "buffer" === e.recordingMode && e.eventBuffer.clear(), n && (e.eventBuffer.hasCheckout = !0);
                        const r = function(e, t) {
                            try {
                                if ("function" == typeof t && function(e) {
                                        return e.type === ro.Custom
                                    }(e)) return t(e)
                            } catch (e) {
                                return null
                            }
                            return e
                        }(t, e.getOptions().beforeAddRecordingEvent);
                        if (!r) return;
                        return await e.eventBuffer.addEvent(r)
                    } catch (t) {
                        const n = t && t instanceof xs ? "addEventSizeExceeded" : "addEvent";
                        e.handleException(t), await e.stop({
                            reason: n
                        });
                        const r = (0, C.KU)();
                        r && r.recordDroppedEvent("internal_sdk_error", "replay")
                    }
                }

                function $s(e, t) {
                    if (!e.eventBuffer || e.isPaused() || !e.isEnabled()) return !1;
                    const n = Yo(t.timestamp);
                    return !(n + e.timeouts.sessionIdlePause < Date.now()) && (!(n > e.getContext().initialTimestamp + e.getOptions().maxReplayDuration) || (e.getOptions()._experiments.traceInternals, !1))
                }

                function Ws(e) {
                    return !e.type
                }

                function qs(e) {
                    return "transaction" === e.type
                }

                function Js(e) {
                    return "feedback" === e.type
                }

                function Ks(e) {
                    return (t, n) => {
                        if (!e.isEnabled() || !Ws(t) && !qs(t)) return;
                        const r = n && n.statusCode;
                        !r || r < 200 || r >= 300 || (qs(t) ? function(e, t) {
                            const n = e.getContext();
                            t.contexts && t.contexts.trace && t.contexts.trace.trace_id && n.traceIds.size < 100 && n.traceIds.add(t.contexts.trace.trace_id)
                        }(e, t) : function(e, t) {
                            const n = e.getContext();
                            t.event_id && n.errorIds.size < 100 && n.errorIds.add(t.event_id);
                            if ("buffer" !== e.recordingMode || !t.tags || !t.tags.replayId) return;
                            const {
                                beforeErrorSampling: r
                            } = e.getOptions();
                            if ("function" == typeof r && !r(t)) return;
                            (0, At.wg)((() => {
                                e.sendBufferedReplayOrFlush()
                            }))
                        }(e, t))
                    }
                }

                function Vs(e) {
                    return t => {
                        e.isEnabled() && Ws(t) && function(e, t) {
                            const n = t.exception && t.exception.values && t.exception.values[0] && t.exception.values[0].value;
                            if ("string" != typeof n) return;
                            if (n.match(/(reactjs\.org\/docs\/error-decoder\.html\?invariant=|react\.dev\/errors\/)(418|419|422|423|425)/) || n.match(/(does not match server-rendered HTML|Hydration failed because)/i)) {
                                Qo(e, cs({
                                    category: "replay.hydrate-error",
                                    data: {
                                        url: (0, Tt.$N)()
                                    }
                                }))
                            }
                        }(e, t)
                    }
                }

                function Xs(e) {
                    const t = (0, C.KU)();
                    t && t.on("beforeAddBreadcrumb", (t => function(e, t) {
                        if (!e.isEnabled() || !Ys(t)) return;
                        const n = function(e) {
                            if (!Ys(e) || ["fetch", "xhr", "sentry.event", "sentry.transaction"].includes(e.category) || e.category.startsWith("ui.")) return null;
                            if ("console" === e.category) return function(e) {
                                const t = e.data && e.data.arguments;
                                if (!Array.isArray(t) || 0 === t.length) return cs(e);
                                let n = !1;
                                const r = t.map((e => {
                                    if (!e) return e;
                                    if ("string" == typeof e) return e.length > Un ? (n = !0, `${e.slice(0,Un)}…`) : e;
                                    if ("object" == typeof e) try {
                                        const t = (0, pe.S8)(e, 7);
                                        return JSON.stringify(t).length > Un ? (n = !0, `${JSON.stringify(t,null,2).slice(0,Un)}…`) : t
                                    } catch (e) {}
                                    return e
                                }));
                                return cs({ ...e,
                                    data: { ...e.data,
                                        arguments: r,
                                        ...n ? {
                                            _meta: {
                                                warnings: ["CONSOLE_ARG_TRUNCATED"]
                                            }
                                        } : {}
                                    }
                                })
                            }(e);
                            return cs(e)
                        }(t);
                        n && Qo(e, n)
                    }(e, t)))
                }

                function Ys(e) {
                    return !!e.category
                }

                function Gs(e) {
                    return Object.assign(((t, n) => {
                        if (!e.isEnabled()) return t;
                        if (function(e) {
                                return "replay_event" === e.type
                            }(t)) return delete t.breadcrumbs, t;
                        if (!Ws(t) && !qs(t) && !Js(t)) return t;
                        if (!e.checkAndHandleExpiredSession()) return t;
                        if (Js(t)) return e.flush(), t.contexts.feedback.replay_id = e.getSessionId(),
                            function(e, t) {
                                e.triggerUserActivity(), e.addUpdate((() => !t.timestamp || (e.throttledAddEvent({
                                    type: ro.Custom,
                                    timestamp: 1e3 * t.timestamp,
                                    data: {
                                        tag: "breadcrumb",
                                        payload: {
                                            timestamp: t.timestamp,
                                            type: "default",
                                            category: "sentry.feedback",
                                            data: {
                                                feedbackId: t.event_id
                                            }
                                        }
                                    }
                                }), !1)))
                            }(e, t), t;
                        if (function(e, t) {
                                return !(e.type || !e.exception || !e.exception.values || !e.exception.values.length || !t.originalException || !t.originalException.__rrweb__)
                            }(t, n) && !e.getOptions()._experiments.captureExceptions) return null;
                        const r = function(e, t) {
                            return "buffer" === e.recordingMode && t.message !== Pn && !(!t.exception || t.type) && Ls(e.getOptions().errorSampleRate)
                        }(e, t);
                        return (r || "session" === e.recordingMode) && (t.tags = { ...t.tags,
                            replayId: e.getSessionId()
                        }), t
                    }), {
                        id: "Replay"
                    })
                }

                function Qs(e, t) {
                    return t.map((({
                        type: t,
                        start: n,
                        end: r,
                        name: o,
                        data: s
                    }) => {
                        const i = e.throttledAddEvent({
                            type: ro.Custom,
                            timestamp: n,
                            data: {
                                tag: "performanceSpan",
                                payload: {
                                    op: t,
                                    description: o,
                                    startTimestamp: n,
                                    endTimestamp: r,
                                    data: s
                                }
                            }
                        });
                        return "string" == typeof i ? Promise.resolve(null) : i
                    }))
                }

                function Zs(e) {
                    return t => {
                        if (!e.isEnabled()) return;
                        const n = function(e) {
                            const {
                                from: t,
                                to: n
                            } = e, r = Date.now() / 1e3;
                            return {
                                type: "navigation.push",
                                start: r,
                                end: r,
                                name: n,
                                data: {
                                    previous: t
                                }
                            }
                        }(t);
                        null !== n && (e.getContext().urls.push(n.name), e.triggerUserActivity(), e.addUpdate((() => (Qs(e, [n]), !1))))
                    }
                }

                function ei(e, t) {
                    e.isEnabled() && (null !== t && (lt(t.name, (0, C.KU)()) || e.addUpdate((() => (Qs(e, [t]), !0)))))
                }

                function ti(e) {
                    if (!e) return;
                    const t = new TextEncoder;
                    try {
                        if ("string" == typeof e) return t.encode(e).length;
                        if (e instanceof URLSearchParams) return t.encode(e.toString()).length;
                        if (e instanceof FormData) {
                            const n = ui(e);
                            return t.encode(n).length
                        }
                        if (e instanceof Blob) return e.size;
                        if (e instanceof ArrayBuffer) return e.byteLength
                    } catch (e) {}
                }

                function ni(e) {
                    if (!e) return;
                    const t = parseInt(e, 10);
                    return isNaN(t) ? void 0 : t
                }

                function ri(e) {
                    try {
                        if ("string" == typeof e) return [e];
                        if (e instanceof URLSearchParams) return [e.toString()];
                        if (e instanceof FormData) return [ui(e)];
                        if (!e) return [void 0]
                    } catch (e) {
                        return [void 0, "BODY_PARSE_ERROR"]
                    }
                    return [void 0, "UNPARSEABLE_BODY_TYPE"]
                }

                function oi(e, t) {
                    if (!e) return {
                        headers: {},
                        size: void 0,
                        _meta: {
                            warnings: [t]
                        }
                    };
                    const n = { ...e._meta
                        },
                        r = n.warnings || [];
                    return n.warnings = [...r, t], e._meta = n, e
                }

                function si(e, t) {
                    if (!t) return null;
                    const {
                        startTimestamp: n,
                        endTimestamp: r,
                        url: o,
                        method: s,
                        statusCode: i,
                        request: a,
                        response: c
                    } = t;
                    return {
                        type: e,
                        start: n / 1e3,
                        end: r / 1e3,
                        name: o,
                        data: (0, T.Ce)({
                            method: s,
                            statusCode: i,
                            request: a,
                            response: c
                        })
                    }
                }

                function ii(e) {
                    return {
                        headers: {},
                        size: e,
                        _meta: {
                            warnings: ["URL_SKIPPED"]
                        }
                    }
                }

                function ai(e, t, n) {
                    if (!t && 0 === Object.keys(e).length) return;
                    if (!t) return {
                        headers: e
                    };
                    if (!n) return {
                        headers: e,
                        size: t
                    };
                    const r = {
                            headers: e,
                            size: t
                        },
                        {
                            body: o,
                            warnings: s
                        } = function(e) {
                            if (!e || "string" != typeof e) return {
                                body: e
                            };
                            const t = e.length > Bn,
                                n = function(e) {
                                    const t = e[0],
                                        n = e[e.length - 1];
                                    return "[" === t && "]" === n || "{" === t && "}" === n
                                }(e);
                            if (t) {
                                const t = e.slice(0, Bn);
                                return n ? {
                                    body: t,
                                    warnings: ["MAYBE_JSON_TRUNCATED"]
                                } : {
                                    body: `${t}…`,
                                    warnings: ["TEXT_TRUNCATED"]
                                }
                            }
                            if (n) try {
                                return {
                                    body: JSON.parse(e)
                                }
                            } catch (e) {}
                            return {
                                body: e
                            }
                        }(n);
                    return r.body = o, s && s.length > 0 && (r._meta = {
                        warnings: s
                    }), r
                }

                function ci(e, t) {
                    return Object.entries(e).reduce(((n, [r, o]) => {
                        const s = r.toLowerCase();
                        return t.includes(s) && e[r] && (n[s] = o), n
                    }), {})
                }

                function ui(e) {
                    return new URLSearchParams(e).toString()
                }

                function li(e, t) {
                    const n = function(e, t = On.document.baseURI) {
                        if (e.startsWith("http://") || e.startsWith("https://") || e.startsWith(On.location.origin)) return e;
                        const n = new URL(e, t);
                        if (n.origin !== new URL(t).origin) return e;
                        const r = n.href;
                        if (!e.endsWith("/") && r.endsWith("/")) return r.slice(0, -1);
                        return r
                    }(e);
                    return (0, k.Xr)(n, t)
                }
                async function di(e, t, n) {
                    try {
                        const r = await async function(e, t, n) {
                                const r = Date.now(),
                                    {
                                        startTimestamp: o = r,
                                        endTimestamp: s = r
                                    } = t,
                                    {
                                        url: i,
                                        method: a,
                                        status_code: c = 0,
                                        request_body_size: u,
                                        response_body_size: l
                                    } = e.data,
                                    d = li(i, n.networkDetailAllowUrls) && !li(i, n.networkDetailDenyUrls),
                                    p = d ? function({
                                        networkCaptureBodies: e,
                                        networkRequestHeaders: t
                                    }, n, r) {
                                        const o = n ? function(e, t) {
                                            if (1 === e.length && "string" != typeof e[0]) return fi(e[0], t);
                                            if (2 === e.length) return fi(e[1], t);
                                            return {}
                                        }(n, t) : {};
                                        if (!e) return ai(o, r, void 0);
                                        const s = pi(n),
                                            [i, a] = ri(s),
                                            c = ai(o, r, i);
                                        if (a) return oi(c, a);
                                        return c
                                    }(n, t.input, u) : ii(u),
                                    h = await async function(e, {
                                        networkCaptureBodies: t,
                                        networkResponseHeaders: n
                                    }, r, o) {
                                        if (!e && void 0 !== o) return ii(o);
                                        const s = r ? hi(r.headers, n) : {};
                                        if (!r || !t && void 0 !== o) return ai(s, o, void 0);
                                        const [i, a] = await async function(e) {
                                            const t = function(e) {
                                                try {
                                                    return e.clone()
                                                } catch (e) {}
                                            }(e);
                                            if (!t) return [void 0, "BODY_PARSE_ERROR"];
                                            try {
                                                const e = await
                                                function(e) {
                                                    return new Promise(((t, n) => {
                                                        const r = (0, At.wg)((() => n(new Error("Timeout while trying to read response body"))), 500);
                                                        (async function(e) {
                                                            return await e.text()
                                                        })(e).then((e => t(e)), (e => n(e))).finally((() => clearTimeout(r)))
                                                    }))
                                                }(t);
                                                return [e]
                                            } catch (e) {
                                                return [void 0, "BODY_PARSE_ERROR"]
                                            }
                                        }(r), c = function(e, {
                                            networkCaptureBodies: t,
                                            responseBodySize: n,
                                            captureDetails: r,
                                            headers: o
                                        }) {
                                            try {
                                                const s = e && e.length && void 0 === n ? ti(e) : n;
                                                return r ? ai(o, s, t ? e : void 0) : ii(s)
                                            } catch (e) {
                                                return ai(o, n, void 0)
                                            }
                                        }(i, {
                                            networkCaptureBodies: t,
                                            responseBodySize: o,
                                            captureDetails: e,
                                            headers: s
                                        });
                                        if (a) return oi(c, a);
                                        return c
                                    }(d, n, t.response, l);
                                return {
                                    startTimestamp: o,
                                    endTimestamp: s,
                                    url: i,
                                    method: a,
                                    statusCode: c,
                                    request: p,
                                    response: h
                                }
                            }(e, t, n),
                            o = si("resource.fetch", r);
                        ei(n.replay, o)
                    } catch (e) {}
                }

                function pi(e = []) {
                    if (2 === e.length && "object" == typeof e[1]) return e[1].body
                }

                function hi(e, t) {
                    const n = {};
                    return t.forEach((t => {
                        e.get(t) && (n[t] = e.get(t))
                    })), n
                }

                function fi(e, t) {
                    if (!e) return {};
                    const n = e.headers;
                    return n ? n instanceof Headers ? hi(n, t) : Array.isArray(n) ? {} : ci(n, t) : {}
                }
                async function mi(e, t, n) {
                    try {
                        const r = function(e, t, n) {
                                const r = Date.now(),
                                    {
                                        startTimestamp: o = r,
                                        endTimestamp: s = r,
                                        input: i,
                                        xhr: a
                                    } = t,
                                    {
                                        url: c,
                                        method: u,
                                        status_code: l = 0,
                                        request_body_size: d,
                                        response_body_size: p
                                    } = e.data;
                                if (!c) return null;
                                if (!a || !li(c, n.networkDetailAllowUrls) || li(c, n.networkDetailDenyUrls)) {
                                    return {
                                        startTimestamp: o,
                                        endTimestamp: s,
                                        url: c,
                                        method: u,
                                        statusCode: l,
                                        request: ii(d),
                                        response: ii(p)
                                    }
                                }
                                const h = a[ut.Er],
                                    f = h ? ci(h.request_headers, n.networkRequestHeaders) : {},
                                    m = ci(function(e) {
                                        const t = e.getAllResponseHeaders();
                                        if (!t) return {};
                                        return t.split("\r\n").reduce(((e, t) => {
                                            const [n, r] = t.split(": ");
                                            return r && (e[n.toLowerCase()] = r), e
                                        }), {})
                                    }(a), n.networkResponseHeaders),
                                    [g, _] = n.networkCaptureBodies ? ri(i) : [void 0],
                                    [y, v] = n.networkCaptureBodies ? function(e) {
                                        const t = [];
                                        try {
                                            return [e.responseText]
                                        } catch (e) {
                                            t.push(e)
                                        }
                                        try {
                                            return function(e, t) {
                                                try {
                                                    if ("string" == typeof e) return [e];
                                                    if (e instanceof Document) return [e.body.outerHTML];
                                                    if ("json" === t && e && "object" == typeof e) return [JSON.stringify(e)];
                                                    if (!e) return [void 0]
                                                } catch (e) {
                                                    return [void 0, "BODY_PARSE_ERROR"]
                                                }
                                                return [void 0, "UNPARSEABLE_BODY_TYPE"]
                                            }(e.response, e.responseType)
                                        } catch (e) {
                                            t.push(e)
                                        }
                                        return [void 0]
                                    }(a) : [void 0],
                                    b = ai(f, d, g),
                                    S = ai(m, p, y);
                                return {
                                    startTimestamp: o,
                                    endTimestamp: s,
                                    url: c,
                                    method: u,
                                    statusCode: l,
                                    request: _ ? oi(b, _) : b,
                                    response: v ? oi(S, v) : S
                                }
                            }(e, t, n),
                            o = si("resource.xhr", r);
                        ei(n.replay, o)
                    } catch (e) {}
                }

                function gi(e, t) {
                    const {
                        xhr: n,
                        input: r
                    } = t;
                    if (!n) return;
                    const o = ti(r),
                        s = n.getResponseHeader("content-length") ? ni(n.getResponseHeader("content-length")) : function(e, t) {
                            try {
                                return ti("json" === t && e && "object" == typeof e ? JSON.stringify(e) : e)
                            } catch (e) {
                                return
                            }
                        }(n.response, n.responseType);
                    void 0 !== o && (e.data.request_body_size = o), void 0 !== s && (e.data.response_body_size = s)
                }

                function _i(e) {
                    const t = (0, C.KU)();
                    try {
                        const {
                            networkDetailAllowUrls: n,
                            networkDetailDenyUrls: r,
                            networkCaptureBodies: o,
                            networkRequestHeaders: s,
                            networkResponseHeaders: i
                        } = e.getOptions(), a = {
                            replay: e,
                            networkDetailAllowUrls: n,
                            networkDetailDenyUrls: r,
                            networkCaptureBodies: o,
                            networkRequestHeaders: s,
                            networkResponseHeaders: i
                        };
                        t && t.on("beforeAddBreadcrumb", ((e, t) => function(e, t, n) {
                            if (!t.data) return;
                            try {
                                (function(e) {
                                    return "xhr" === e.category
                                })(t) && function(e) {
                                    return e && e.xhr
                                }(n) && (gi(t, n), mi(t, n, e)),
                                function(e) {
                                    return "fetch" === e.category
                                }(t) && function(e) {
                                    return e && e.response
                                }(n) && (! function(e, t) {
                                    const {
                                        input: n,
                                        response: r
                                    } = t, o = ti(n ? pi(n) : void 0), s = r ? ni(r.headers.get("content-length")) : void 0;
                                    void 0 !== o && (e.data.request_body_size = o), void 0 !== s && (e.data.response_body_size = s)
                                }(t, n), di(t, n, e))
                            } catch (e) {}
                        }(a, e, t)))
                    } catch (e) {}
                }

                function yi(e) {
                    const {
                        jsHeapSizeLimit: t,
                        totalJSHeapSize: n,
                        usedJSHeapSize: r
                    } = e, o = Date.now() / 1e3;
                    return {
                        type: "memory",
                        name: "memory",
                        start: o,
                        end: o,
                        data: {
                            memory: {
                                jsHeapSizeLimit: t,
                                totalJSHeapSize: n,
                                usedJSHeapSize: r
                            }
                        }
                    }
                }

                function vi(e) {
                    let t = !1;
                    return (n, r) => {
                        if (!e.checkAndHandleExpiredSession()) return;
                        const o = r || !t;
                        t = !0, e.clickDetector && as(e.clickDetector, n), e.addUpdate((() => {
                            if ("buffer" === e.recordingMode && o && e.setInitialState(), !zs(e, n, o)) return !0;
                            if (!o) return !1;
                            if (function(e, t) {
                                    if (!t || !e.session || 0 !== e.session.segmentId) return;
                                    zs(e, function(e) {
                                        const t = e.getOptions();
                                        return {
                                            type: ro.Custom,
                                            timestamp: Date.now(),
                                            data: {
                                                tag: "options",
                                                payload: {
                                                    shouldRecordCanvas: e.isRecordingCanvas(),
                                                    sessionSampleRate: t.sessionSampleRate,
                                                    errorSampleRate: t.errorSampleRate,
                                                    useCompressionOption: t.useCompression,
                                                    blockAllMedia: t.blockAllMedia,
                                                    maskAllText: t.maskAllText,
                                                    maskAllInputs: t.maskAllInputs,
                                                    useCompression: !!e.eventBuffer && "worker" === e.eventBuffer.type,
                                                    networkDetailHasUrls: t.networkDetailAllowUrls.length > 0,
                                                    networkCaptureBodies: t.networkCaptureBodies,
                                                    networkRequestHasHeaders: t.networkRequestHeaders.length > 0,
                                                    networkResponseHasHeaders: t.networkResponseHeaders.length > 0
                                                }
                                            }
                                        }
                                    }(e), !1)
                                }(e, o), e.session && e.session.previousSessionId) return !0;
                            if ("buffer" === e.recordingMode && e.session && e.eventBuffer) {
                                const t = e.eventBuffer.getEarliestTimestamp();
                                t && (new Date(t), e.getOptions()._experiments.traceInternals, e.session.started = t, e.getOptions().stickySession && Os(e.session))
                            }
                            return "session" === e.recordingMode && e.flush(), !0
                        }))
                    }
                }
                async function bi({
                    recordingData: e,
                    replayId: t,
                    segmentId: n,
                    eventContext: r,
                    timestamp: o,
                    session: s
                }) {
                    const i = function({
                            recordingData: e,
                            headers: t
                        }) {
                            let n;
                            const r = `${JSON.stringify(t)}\n`;
                            if ("string" == typeof e) n = `${r}${e}`;
                            else {
                                const t = (new TextEncoder).encode(r);
                                n = new Uint8Array(t.length + e.length), n.set(t), n.set(e, t.length)
                            }
                            return n
                        }({
                            recordingData: e,
                            headers: {
                                segment_id: n
                            }
                        }),
                        {
                            urls: a,
                            errorIds: c,
                            traceIds: u,
                            initialTimestamp: l
                        } = r,
                        d = (0, C.KU)(),
                        p = (0, C.o5)(),
                        h = d && d.getTransport(),
                        f = d && d.getDsn();
                    if (!(d && h && f && s.sampled)) return (0, It.XW)({});
                    const m = {
                            type: "replay_event",
                            replay_start_timestamp: l / 1e3,
                            timestamp: o / 1e3,
                            error_ids: c,
                            trace_ids: u,
                            urls: a,
                            replay_id: t,
                            segment_id: n,
                            replay_type: s.sampled
                        },
                        g = await async function({
                            client: e,
                            scope: t,
                            replayId: n,
                            event: r
                        }) {
                            const o = {
                                event_id: n,
                                integrations: "object" != typeof e._integrations || null === e._integrations || Array.isArray(e._integrations) ? void 0 : Object.keys(e._integrations)
                            };
                            e.emit("preprocessEvent", r, o);
                            const s = await (0, xt.mG)(e.getOptions(), r, o, t, e, (0, C.rm)());
                            if (!s) return null;
                            s.platform = s.platform || "javascript";
                            const i = e.getSdkMetadata(),
                                {
                                    name: a,
                                    version: c
                                } = i && i.sdk || {};
                            return s.sdk = { ...s.sdk,
                                name: a || "sentry.javascript.unknown",
                                version: c || "0.0.0"
                            }, s
                        }({
                            scope: p,
                            client: d,
                            replayId: t,
                            event: m
                        });
                    if (!g) return d.recordDroppedEvent("event_processor", "replay", m), (0, It.XW)({});
                    delete g.sdkProcessingMetadata;
                    const _ = function(e, t, n, r) {
                        return (0, _e.h4)((0, _e.n2)(e, (0, _e.Cj)(e), r, n), [
                            [{
                                type: "replay_event"
                            }, e],
                            [{
                                type: "replay_recording",
                                length: "string" == typeof t ? (new TextEncoder).encode(t).length : t.length
                            }, t]
                        ])
                    }(g, i, f, d.getOptions().tunnel);
                    let y;
                    try {
                        y = await h.send(_)
                    } catch (e) {
                        const t = new Error(Pn);
                        try {
                            t.cause = e
                        } catch (e) {}
                        throw t
                    }
                    if ("number" == typeof y.statusCode && (y.statusCode < 200 || y.statusCode >= 300)) throw new Si(y.statusCode);
                    const v = (0, Et.wq)({}, y);
                    if ((0, Et.Jz)(v, "replay")) throw new wi(v);
                    return y
                }
                class Si extends Error {
                    constructor(e) {
                        super(`Transport returned status code ${e}`)
                    }
                }
                class wi extends Error {
                    constructor(e) {
                        super("Rate limit hit"), this.rateLimits = e
                    }
                }
                async function ki(e, t = {
                    count: 0,
                    interval: 5e3
                }) {
                    const {
                        recordingData: n,
                        options: r
                    } = e;
                    if (n.length) try {
                        return await bi(e), !0
                    } catch (n) {
                        if (n instanceof Si || n instanceof wi) throw n;
                        if ((0, a.o)("Replays", {
                                _retryCount: t.count
                            }), t.count >= 3) {
                            const e = new Error(`${Pn} - max retries exceeded`);
                            try {
                                e.cause = n
                            } catch (e) {}
                            throw e
                        }
                        return t.interval *= ++t.count, new Promise(((n, r) => {
                            (0, At.wg)((async () => {
                                try {
                                    await ki(e, t), n(!0)
                                } catch (e) {
                                    r(e)
                                }
                            }), t.interval)
                        }))
                    }
                }
                const Ci = "__THROTTLED";

                function xi(e, t, n) {
                    const r = new Map;
                    let o = !1;
                    return (...s) => {
                        const i = Math.floor(Date.now() / 1e3);
                        if ((e => {
                                const t = e - n;
                                r.forEach(((e, n) => {
                                    n < t && r.delete(n)
                                }))
                            })(i), [...r.values()].reduce(((e, t) => e + t), 0) >= t) {
                            const e = o;
                            return o = !0, e ? "__SKIPPED" : Ci
                        }
                        o = !1;
                        const a = r.get(i) || 0;
                        return r.set(i, a + 1), e(...s)
                    }
                }
                class Ti {
                    constructor({
                        options: e,
                        recordingOptions: t
                    }) {
                        Ti.prototype.__init.call(this), Ti.prototype.__init2.call(this), Ti.prototype.__init3.call(this), Ti.prototype.__init4.call(this), Ti.prototype.__init5.call(this), Ti.prototype.__init6.call(this), this.eventBuffer = null, this.performanceEntries = [], this.replayPerformanceEntries = [], this.recordingMode = "session", this.timeouts = {
                            sessionIdlePause: 3e5,
                            sessionIdleExpire: 9e5
                        }, this._lastActivity = Date.now(), this._isEnabled = !1, this._isPaused = !1, this._requiresManualStart = !1, this._hasInitializedCoreListeners = !1, this._context = {
                            errorIds: new Set,
                            traceIds: new Set,
                            urls: [],
                            initialTimestamp: Date.now(),
                            initialUrl: ""
                        }, this._recordingOptions = t, this._options = e, this._debouncedFlush = function(e, t, n) {
                            let r, o, s;
                            const i = n && n.maxWait ? Math.max(n.maxWait, t) : 0;

                            function a() {
                                return c(), r = e(), r
                            }

                            function c() {
                                void 0 !== o && clearTimeout(o), void 0 !== s && clearTimeout(s), o = s = void 0
                            }

                            function u() {
                                return o && clearTimeout(o), o = (0, At.wg)(a, t), i && void 0 === s && (s = (0, At.wg)(a, i)), r
                            }
                            return u.cancel = c, u.flush = function() {
                                return void 0 !== o || void 0 !== s ? a() : r
                            }, u
                        }((() => this._flush()), this._options.flushMinDelay, {
                            maxWait: this._options.flushMaxDelay
                        }), this._throttledAddEvent = xi(((e, t) => function(e, t, n) {
                            return $s(e, t) ? Hs(e, t, n) : Promise.resolve(null)
                        }(this, e, t)), 300, 5);
                        const {
                            slowClickTimeout: n,
                            slowClickIgnoreSelectors: r
                        } = this.getOptions(), o = n ? {
                            threshold: Math.min(3e3, n),
                            timeout: n,
                            scrollTimeout: 300,
                            ignoreSelector: r ? r.join(",") : ""
                        } : void 0;
                        o && (this.clickDetector = new os(this, o))
                    }
                    getContext() {
                        return this._context
                    }
                    isEnabled() {
                        return this._isEnabled
                    }
                    isPaused() {
                        return this._isPaused
                    }
                    isRecordingCanvas() {
                        return Boolean(this._canvas)
                    }
                    getOptions() {
                        return this._options
                    }
                    handleException(e) {
                        Cs
                    }
                    initializeSampling(e) {
                        const {
                            errorSampleRate: t,
                            sessionSampleRate: n
                        } = this._options, r = t <= 0 && n <= 0;
                        this._requiresManualStart = r, r || (this._initializeSessionForSampling(e), this.session ? !1 !== this.session.sampled && (this.recordingMode = "buffer" === this.session.sampled && 0 === this.session.segmentId ? "buffer" : "session", this.recordingMode, this._options._experiments.traceInternals, this._initializeRecording()) : this.handleException(new Error("Unable to initialize and create session")))
                    }
                    start() {
                        if (this._isEnabled && "session" === this.recordingMode) return;
                        if (this._isEnabled && "buffer" === this.recordingMode) return;
                        this._options._experiments.traceInternals, this._updateUserActivity();
                        const e = js({
                            maxReplayDuration: this._options.maxReplayDuration,
                            sessionIdleExpire: this.timeouts.sessionIdleExpire,
                            traceInternals: this._options._experiments.traceInternals
                        }, {
                            stickySession: this._options.stickySession,
                            sessionSampleRate: 1,
                            allowBuffering: !1
                        });
                        this.session = e, this._initializeRecording()
                    }
                    startBuffering() {
                        if (this._isEnabled) return;
                        this._options._experiments.traceInternals;
                        const e = js({
                            sessionIdleExpire: this.timeouts.sessionIdleExpire,
                            maxReplayDuration: this._options.maxReplayDuration,
                            traceInternals: this._options._experiments.traceInternals
                        }, {
                            stickySession: this._options.stickySession,
                            sessionSampleRate: 0,
                            allowBuffering: !0
                        });
                        this.session = e, this.recordingMode = "buffer", this._initializeRecording()
                    }
                    startRecording() {
                        try {
                            const e = this._canvas;
                            this._stopRecording = Xo({ ...this._recordingOptions,
                                ..."buffer" === this.recordingMode && {
                                    checkoutEveryNms: 6e4
                                },
                                emit: vi(this),
                                onMutation: this._onMutationHandler,
                                ...e ? {
                                    recordCanvas: e.recordCanvas,
                                    getCanvasManager: e.getCanvasManager,
                                    sampling: e.sampling,
                                    dataURLOptions: e.dataURLOptions
                                } : {}
                            })
                        } catch (e) {
                            this.handleException(e)
                        }
                    }
                    stopRecording() {
                        try {
                            return this._stopRecording && (this._stopRecording(), this._stopRecording = void 0), !0
                        } catch (e) {
                            return this.handleException(e), !1
                        }
                    }
                    async stop({
                        forceFlush: e = !1,
                        reason: t
                    } = {}) {
                        if (this._isEnabled) {
                            this._isEnabled = !1;
                            try {
                                this._options._experiments.traceInternals, this._removeListeners(), this.stopRecording(), this._debouncedFlush.cancel(), e && await this._flush({
                                    force: !0
                                }), this.eventBuffer && this.eventBuffer.destroy(), this.eventBuffer = null, Ns(this)
                            } catch (e) {
                                this.handleException(e)
                            }
                        }
                    }
                    pause() {
                        this._isPaused || (this._isPaused = !0, this.stopRecording(), this._options._experiments.traceInternals)
                    }
                    resume() {
                        this._isPaused && this._checkSession() && (this._isPaused = !1, this.startRecording(), this._options._experiments.traceInternals)
                    }
                    async sendBufferedReplayOrFlush({
                        continueRecording: e = !0
                    } = {}) {
                        if ("session" === this.recordingMode) return this.flushImmediate();
                        const t = Date.now();
                        this._options._experiments.traceInternals, await this.flushImmediate();
                        const n = this.stopRecording();
                        e && n && "session" !== this.recordingMode && (this.recordingMode = "session", this.session && (this._updateUserActivity(t), this._updateSessionActivity(t), this._maybeSaveSession()), this.startRecording())
                    }
                    addUpdate(e) {
                        const t = e();
                        "buffer" !== this.recordingMode && !0 !== t && this._debouncedFlush()
                    }
                    triggerUserActivity() {
                        if (this._updateUserActivity(), this._stopRecording) this.checkAndHandleExpiredSession(), this._updateSessionActivity();
                        else {
                            if (!this._checkSession()) return;
                            this.resume()
                        }
                    }
                    updateUserActivity() {
                        this._updateUserActivity(), this._updateSessionActivity()
                    }
                    conditionalFlush() {
                        return "buffer" === this.recordingMode ? Promise.resolve() : this.flushImmediate()
                    }
                    flush() {
                        return this._debouncedFlush()
                    }
                    flushImmediate() {
                        return this._debouncedFlush(), this._debouncedFlush.flush()
                    }
                    cancelFlush() {
                        this._debouncedFlush.cancel()
                    }
                    getSessionId() {
                        return this.session && this.session.id
                    }
                    checkAndHandleExpiredSession() {
                        if (!(this._lastActivity && Ps(this._lastActivity, this.timeouts.sessionIdlePause) && this.session && "session" === this.session.sampled)) return !!this._checkSession();
                        this.pause()
                    }
                    setInitialState() {
                        const e = `${On.location.pathname}${On.location.hash}${On.location.search}`,
                            t = `${On.location.origin}${e}`;
                        this.performanceEntries = [], this.replayPerformanceEntries = [], this._clearContext(), this._context.initialUrl = t, this._context.initialTimestamp = Date.now(), this._context.urls.push(t)
                    }
                    throttledAddEvent(e, t) {
                        const n = this._throttledAddEvent(e, t);
                        if (n === Ci) {
                            const e = cs({
                                category: "replay.throttled"
                            });
                            this.addUpdate((() => !zs(this, {
                                type: 5,
                                timestamp: e.timestamp || 0,
                                data: {
                                    tag: "breadcrumb",
                                    payload: e,
                                    metric: !0
                                }
                            })))
                        }
                        return n
                    }
                    getCurrentRoute() {
                        const e = this.lastActiveSpan || (0, h.Bk)(),
                            t = e && (0, h.zU)(e),
                            n = (t && (0, h.et)(t).data || {})[o.i_];
                        if (t && n && ["route", "custom"].includes(n)) return (0, h.et)(t).description
                    }
                    _initializeRecording() {
                        this.setInitialState(), this._updateSessionActivity(), this.eventBuffer = Rs({
                            useCompression: this._options.useCompression,
                            workerUrl: this._options.workerUrl
                        }), this._removeListeners(), this._addListeners(), this._isEnabled = !0, this._isPaused = !1, this.startRecording()
                    }
                    _initializeSessionForSampling(e) {
                        const t = this._options.errorSampleRate > 0,
                            n = js({
                                sessionIdleExpire: this.timeouts.sessionIdleExpire,
                                maxReplayDuration: this._options.maxReplayDuration,
                                traceInternals: this._options._experiments.traceInternals,
                                previousSessionId: e
                            }, {
                                stickySession: this._options.stickySession,
                                sessionSampleRate: this._options.sessionSampleRate,
                                allowBuffering: t
                            });
                        this.session = n
                    }
                    _checkSession() {
                        if (!this.session) return !1;
                        const e = this.session;
                        return !Us(e, {
                            sessionIdleExpire: this.timeouts.sessionIdleExpire,
                            maxReplayDuration: this._options.maxReplayDuration
                        }) || (this._refreshSession(e), !1)
                    }
                    async _refreshSession(e) {
                        this._isEnabled && (await this.stop({
                            reason: "refresh session"
                        }), this.initializeSampling(e.id))
                    }
                    _addListeners() {
                        try {
                            On.document.addEventListener("visibilitychange", this._handleVisibilityChange), On.addEventListener("blur", this._handleWindowBlur), On.addEventListener("focus", this._handleWindowFocus), On.addEventListener("keydown", this._handleKeyboardEvent), this.clickDetector && this.clickDetector.addListeners(), this._hasInitializedCoreListeners || (! function(e) {
                                const t = (0, C.KU)();
                                (0, Ln.i)(ps(e)), (0, Dn._)(Zs(e)), Xs(e), _i(e);
                                const n = Gs(e);
                                (0, a.SA)(n), t && (t.on("beforeSendEvent", Vs(e)), t.on("afterSendEvent", Ks(e)), t.on("createDsc", (t => {
                                    const n = e.getSessionId();
                                    n && e.isEnabled() && "session" === e.recordingMode && e.checkAndHandleExpiredSession() && (t.replay_id = n)
                                })), t.on("spanStart", (t => {
                                    e.lastActiveSpan = t
                                })), t.on("spanEnd", (t => {
                                    e.lastActiveSpan = t
                                })), t.on("beforeSendFeedback", ((t, n) => {
                                    const r = e.getSessionId();
                                    n && n.includeReplay && e.isEnabled() && r && t.contexts && t.contexts.feedback && (t.contexts.feedback.replay_id = r)
                                })))
                            }(this), this._hasInitializedCoreListeners = !0)
                        } catch (e) {
                            this.handleException(e)
                        }
                        this._performanceCleanupCallback = function(e) {
                            function t(t) {
                                e.performanceEntries.includes(t) || e.performanceEntries.push(t)
                            }

                            function n({
                                entries: e
                            }) {
                                e.forEach(t)
                            }
                            const r = [];
                            return ["navigation", "paint", "resource"].forEach((e => {
                                r.push(kn(e, n))
                            })), r.push(bn(gs(vs, e)), vn(gs(bs, e)), Sn(gs(Ss, e)), wn(gs(ws, e))), () => {
                                r.forEach((e => e()))
                            }
                        }(this)
                    }
                    _removeListeners() {
                        try {
                            On.document.removeEventListener("visibilitychange", this._handleVisibilityChange), On.removeEventListener("blur", this._handleWindowBlur), On.removeEventListener("focus", this._handleWindowFocus), On.removeEventListener("keydown", this._handleKeyboardEvent), this.clickDetector && this.clickDetector.removeListeners(), this._performanceCleanupCallback && this._performanceCleanupCallback()
                        } catch (e) {
                            this.handleException(e)
                        }
                    }
                    __init() {
                        this._handleVisibilityChange = () => {
                            "visible" === On.document.visibilityState ? this._doChangeToForegroundTasks() : this._doChangeToBackgroundTasks()
                        }
                    }
                    __init2() {
                        this._handleWindowBlur = () => {
                            const e = cs({
                                category: "ui.blur"
                            });
                            this._doChangeToBackgroundTasks(e)
                        }
                    }
                    __init3() {
                        this._handleWindowFocus = () => {
                            const e = cs({
                                category: "ui.focus"
                            });
                            this._doChangeToForegroundTasks(e)
                        }
                    }
                    __init4() {
                        this._handleKeyboardEvent = e => {
                            fs(this, e)
                        }
                    }
                    _doChangeToBackgroundTasks(e) {
                        if (!this.session) return;
                        Bs(this.session, {
                            maxReplayDuration: this._options.maxReplayDuration,
                            sessionIdleExpire: this.timeouts.sessionIdleExpire
                        }) || (e && this._createCustomBreadcrumb(e), this.conditionalFlush())
                    }
                    _doChangeToForegroundTasks(e) {
                        if (!this.session) return;
                        this.checkAndHandleExpiredSession() && e && this._createCustomBreadcrumb(e)
                    }
                    _updateUserActivity(e = Date.now()) {
                        this._lastActivity = e
                    }
                    _updateSessionActivity(e = Date.now()) {
                        this.session && (this.session.lastActivity = e, this._maybeSaveSession())
                    }
                    _createCustomBreadcrumb(e) {
                        this.addUpdate((() => {
                            this.throttledAddEvent({
                                type: ro.Custom,
                                timestamp: e.timestamp || 0,
                                data: {
                                    tag: "breadcrumb",
                                    payload: e
                                }
                            })
                        }))
                    }
                    _addPerformanceEntries() {
                        const e = (t = this.performanceEntries, t.map(_s).filter(Boolean)).concat(this.replayPerformanceEntries);
                        var t;
                        return this.performanceEntries = [], this.replayPerformanceEntries = [], Promise.all(Qs(this, e))
                    }
                    _clearContext() {
                        this._context.errorIds.clear(), this._context.traceIds.clear(), this._context.urls = []
                    }
                    _updateInitialTimestampFromEventBuffer() {
                        const {
                            session: e,
                            eventBuffer: t
                        } = this;
                        if (!e || !t || this._requiresManualStart) return;
                        if (e.segmentId) return;
                        const n = t.getEarliestTimestamp();
                        n && n < this._context.initialTimestamp && (this._context.initialTimestamp = n)
                    }
                    _popEventContext() {
                        const e = {
                            initialTimestamp: this._context.initialTimestamp,
                            initialUrl: this._context.initialUrl,
                            errorIds: Array.from(this._context.errorIds),
                            traceIds: Array.from(this._context.traceIds),
                            urls: this._context.urls
                        };
                        return this._clearContext(), e
                    }
                    async _runFlush() {
                        const e = this.getSessionId();
                        if (this.session && this.eventBuffer && e && (await this._addPerformanceEntries(), this.eventBuffer && this.eventBuffer.hasEvents && (await async function(e) {
                                try {
                                    return Promise.all(Qs(e, [yi(On.performance.memory)]))
                                } catch (e) {
                                    return []
                                }
                            }(this), this.eventBuffer && e === this.getSessionId()))) try {
                            this._updateInitialTimestampFromEventBuffer();
                            const t = Date.now();
                            if (t - this._context.initialTimestamp > this._options.maxReplayDuration + 3e4) throw new Error("Session is too long, not sending replay");
                            const n = this._popEventContext(),
                                r = this.session.segmentId++;
                            this._maybeSaveSession();
                            const o = await this.eventBuffer.finish();
                            await ki({
                                replayId: e,
                                recordingData: o,
                                segmentId: r,
                                eventContext: n,
                                session: this.session,
                                options: this.getOptions(),
                                timestamp: t
                            })
                        } catch (e) {
                            this.handleException(e), this.stop({
                                reason: "sendReplay"
                            });
                            const t = (0, C.KU)();
                            t && t.recordDroppedEvent("send_error", "replay")
                        }
                    }
                    __init5() {
                        this._flush = async ({
                            force: e = !1
                        } = {}) => {
                            if (!this._isEnabled && !e) return;
                            if (!this.checkAndHandleExpiredSession()) return;
                            if (!this.session) return;
                            const t = this.session.started,
                                n = Date.now() - t;
                            this._debouncedFlush.cancel();
                            const r = n < this._options.minReplayDuration,
                                o = n > this._options.maxReplayDuration + 5e3;
                            if (r || o) return Math.floor(n / 1e3), this._options._experiments.traceInternals, void(r && this._debouncedFlush());
                            const s = this.eventBuffer;
                            if (s && 0 === this.session.segmentId && !s.hasCheckout && this._options._experiments.traceInternals, !this._flushLock) return this._flushLock = this._runFlush(), await this._flushLock, void(this._flushLock = void 0);
                            try {
                                await this._flushLock
                            } catch (e) {} finally {
                                this._debouncedFlush()
                            }
                        }
                    }
                    _maybeSaveSession() {
                        this.session && this._options.stickySession && Os(this.session)
                    }
                    __init6() {
                        this._onMutationHandler = e => {
                            const t = e.length,
                                n = this._options.mutationLimit,
                                r = n && t > n;
                            if (t > this._options.mutationBreadcrumbLimit || r) {
                                const e = cs({
                                    category: "replay.mutations",
                                    data: {
                                        count: t,
                                        limit: r
                                    }
                                });
                                this._createCustomBreadcrumb(e)
                            }
                            return !r || (this.stop({
                                reason: "mutationLimit",
                                forceFlush: "session" === this.recordingMode
                            }), !1)
                        }
                    }
                }

                function Ii(e, t) {
                    return [...e, ...t].join(",")
                }
                const Ei = 'img,image,svg,video,object,picture,embed,map,audio,link[rel="icon"],link[rel="apple-touch-icon"]',
                    Mi = ["content-length", "content-type", "accept"];
                let Ri = !1;
                const Ai = e => new Ni(e);
                class Ni {
                    static __initStatic() {
                        this.id = "Replay"
                    }
                    constructor({
                        flushMinDelay: e = 5e3,
                        flushMaxDelay: t = 5500,
                        minReplayDuration: n = 4999,
                        maxReplayDuration: r = 36e5,
                        stickySession: o = !0,
                        useCompression: s = !0,
                        workerUrl: i,
                        _experiments: a = {},
                        maskAllText: c = !0,
                        maskAllInputs: u = !0,
                        blockAllMedia: l = !0,
                        mutationBreadcrumbLimit: d = 750,
                        mutationLimit: p = 1e4,
                        slowClickTimeout: h = 7e3,
                        slowClickIgnoreSelectors: f = [],
                        networkDetailAllowUrls: m = [],
                        networkDetailDenyUrls: g = [],
                        networkCaptureBodies: _ = !0,
                        networkRequestHeaders: y = [],
                        networkResponseHeaders: v = [],
                        mask: b = [],
                        maskAttributes: S = ["title", "placeholder"],
                        unmask: w = [],
                        block: k = [],
                        unblock: C = [],
                        ignore: x = [],
                        maskFn: T,
                        beforeAddRecordingEvent: I,
                        beforeErrorSampling: E
                    } = {}) {
                        this.name = Ni.id;
                        const M = function({
                            mask: e,
                            unmask: t,
                            block: n,
                            unblock: r,
                            ignore: o
                        }) {
                            return {
                                maskTextSelector: Ii(e, [".sentry-mask", "[data-sentry-mask]"]),
                                unmaskTextSelector: Ii(t, []),
                                blockSelector: Ii(n, [".sentry-block", "[data-sentry-block]", 'base[href="/"]']),
                                unblockSelector: Ii(r, []),
                                ignoreSelector: Ii(o, [".sentry-ignore", "[data-sentry-ignore]", 'input[type="file"]'])
                            }
                        }({
                            mask: b,
                            unmask: w,
                            block: k,
                            unblock: C,
                            ignore: x
                        });
                        if (this._recordingOptions = {
                                maskAllInputs: u,
                                maskAllText: c,
                                maskInputOptions: {
                                    password: !0
                                },
                                maskTextFn: T,
                                maskInputFn: T,
                                maskAttributeFn: (e, t, n) => function({
                                    el: e,
                                    key: t,
                                    maskAttributes: n,
                                    maskAllText: r,
                                    privacyOptions: o,
                                    value: s
                                }) {
                                    return r ? o.unmaskTextSelector && e.matches(o.unmaskTextSelector) ? s : n.includes(t) || "value" === t && "INPUT" === e.tagName && ["submit", "button"].includes(e.getAttribute("type") || "") ? s.replace(/[\S]/g, "*") : s : s
                                }({
                                    maskAttributes: S,
                                    maskAllText: c,
                                    privacyOptions: M,
                                    key: e,
                                    value: t,
                                    el: n
                                }),
                                ...M,
                                slimDOMOptions: "all",
                                inlineStylesheet: !0,
                                inlineImages: !1,
                                collectFonts: !0,
                                errorHandler: e => {
                                    try {
                                        e.__rrweb__ = !0
                                    } catch (e) {}
                                }
                            }, this._initialOptions = {
                                flushMinDelay: e,
                                flushMaxDelay: t,
                                minReplayDuration: Math.min(n, 15e3),
                                maxReplayDuration: Math.min(r, zn),
                                stickySession: o,
                                useCompression: s,
                                workerUrl: i,
                                blockAllMedia: l,
                                maskAllInputs: u,
                                maskAllText: c,
                                mutationBreadcrumbLimit: d,
                                mutationLimit: p,
                                slowClickTimeout: h,
                                slowClickIgnoreSelectors: f,
                                networkDetailAllowUrls: m,
                                networkDetailDenyUrls: g,
                                networkCaptureBodies: _,
                                networkRequestHeaders: Li(y),
                                networkResponseHeaders: Li(v),
                                beforeAddRecordingEvent: I,
                                beforeErrorSampling: E,
                                _experiments: a
                            }, this._initialOptions.blockAllMedia && (this._recordingOptions.blockSelector = this._recordingOptions.blockSelector ? `${this._recordingOptions.blockSelector},${Ei}` : Ei), this._isInitialized && Rt()) throw new Error("Multiple Sentry Session Replay instances are not supported");
                        this._isInitialized = !0
                    }
                    get _isInitialized() {
                        return Ri
                    }
                    set _isInitialized(e) {
                        Ri = e
                    }
                    afterAllSetup(e) {
                        Rt() && !this._replay && (this._setup(e), this._initialize(e))
                    }
                    start() {
                        this._replay && this._replay.start()
                    }
                    startBuffering() {
                        this._replay && this._replay.startBuffering()
                    }
                    stop() {
                        return this._replay ? this._replay.stop({
                            forceFlush: "session" === this._replay.recordingMode
                        }) : Promise.resolve()
                    }
                    flush(e) {
                        return this._replay ? this._replay.isEnabled() ? this._replay.sendBufferedReplayOrFlush(e) : (this._replay.start(), Promise.resolve()) : Promise.resolve()
                    }
                    getReplayId() {
                        if (this._replay && this._replay.isEnabled()) return this._replay.getSessionId()
                    }
                    _initialize(e) {
                        this._replay && (this._maybeLoadFromReplayCanvasIntegration(e), this._replay.initializeSampling())
                    }
                    _setup(e) {
                        const t = function(e, t) {
                            const n = t.getOptions(),
                                r = {
                                    sessionSampleRate: 0,
                                    errorSampleRate: 0,
                                    ...(0, T.Ce)(e)
                                },
                                o = (0, P.i)(n.replaysSessionSampleRate),
                                s = (0, P.i)(n.replaysOnErrorSampleRate);
                            null == o && null == s && (0, d.pq)((() => {
                                console.warn("Replay is disabled because neither `replaysSessionSampleRate` nor `replaysOnErrorSampleRate` are set.")
                            }));
                            null != o && (r.sessionSampleRate = o);
                            null != s && (r.errorSampleRate = s);
                            return r
                        }(this._initialOptions, e);
                        this._replay = new Ti({
                            options: t,
                            recordingOptions: this._recordingOptions
                        })
                    }
                    _maybeLoadFromReplayCanvasIntegration(e) {
                        try {
                            const t = e.getIntegrationByName("ReplayCanvas");
                            if (!t) return;
                            this._replay._canvas = t.getOptions()
                        } catch (e) {}
                    }
                }

                function Li(e) {
                    return [...Mi, ...e.map((e => e.toLowerCase()))]
                }

                function Di() {
                    const e = (0, C.KU)();
                    return e && e.getIntegrationByName("Replay")
                }
                var Oi;

                function Fi(e, t, n = 1 / 0, r = 0) {
                    return e ? e.nodeType !== e.ELEMENT_NODE || r > n ? -1 : t(e) ? r : Fi(e.parentNode, t, n, r + 1) : -1
                }

                function Pi(e, t) {
                    return n => {
                        const r = n;
                        if (null === r) return !1;
                        try {
                            if (e)
                                if ("string" == typeof e) {
                                    if (r.matches(`.${e}`)) return !0
                                } else if (function(e, t) {
                                    for (let n = e.classList.length; n--;) {
                                        const r = e.classList[n];
                                        if (t.test(r)) return !0
                                    }
                                    return !1
                                }(r, e)) return !0;
                            return !(!t || !r.matches(t))
                        } catch (e) {
                            return !1
                        }
                    }
                }
                Ni.__initStatic(),
                    function(e) {
                        e[e.Document = 0] = "Document", e[e.DocumentType = 1] = "DocumentType", e[e.Element = 2] = "Element", e[e.Text = 3] = "Text", e[e.CDATA = 4] = "CDATA", e[e.Comment = 5] = "Comment"
                    }(Oi || (Oi = {}));
                const Bi = "Please stop import mirror directly. Instead of that,\r\nnow you can use replayer.getMirror() to access the mirror instance of a replayer,\r\nor you can use record.mirror to access the mirror instance during recording.";
                let Ui = {
                    map: {},
                    getId() {
                        return console.error(Bi), -1
                    },
                    getNode() {
                        return console.error(Bi), null
                    },
                    removeNodeFromMap() {
                        console.error(Bi)
                    },
                    has() {
                        return console.error(Bi), !1
                    },
                    reset() {
                        console.error(Bi)
                    }
                };

                function ji(e, t, n, r, o = window) {
                    const s = o.Object.getOwnPropertyDescriptor(e, t);
                    return o.Object.defineProperty(e, t, r ? n : {
                        set(e) {
                            Ji((() => {
                                n.set.call(this, e)
                            }), 0), s && s.set && s.set.call(this, e)
                        }
                    }), () => ji(e, t, s || {}, !0)
                }

                function zi(e, t, n) {
                    try {
                        if (!(t in e)) return () => {};
                        const r = e[t],
                            o = n(r);
                        return "function" == typeof o && (o.prototype = o.prototype || {}, Object.defineProperties(o, {
                            __rrweb_original__: {
                                enumerable: !1,
                                value: r
                            }
                        })), e[t] = o, () => {
                            e[t] = r
                        }
                    } catch (e) {
                        return () => {}
                    }
                }

                function Hi(e, t, n, r, o) {
                    if (!e) return !1;
                    const s = function(e) {
                        return e ? e.nodeType === e.ELEMENT_NODE ? e : e.parentElement : null
                    }(e);
                    if (!s) return !1;
                    const i = Pi(t, n);
                    if (!o) {
                        const e = r && s.matches(r);
                        return i(s) && !e
                    }
                    const a = Fi(s, i);
                    let c = -1;
                    return !(a < 0) && (r && (c = Fi(s, Pi(null, r))), a > -1 && c < 0 || a < c)
                }
                "undefined" != typeof window && window.Proxy && window.Reflect && (Ui = new Proxy(Ui, {
                    get(e, t, n) {
                        return "map" === t && console.error(Bi), Reflect.get(e, t, n)
                    }
                })), /[1-9][0-9]{12}/.test(Date.now().toString());
                const $i = {};

                function Wi(e) {
                    const t = $i[e];
                    if (t) return t;
                    const n = window.document;
                    let r = window[e];
                    if (n && "function" == typeof n.createElement) try {
                        const t = n.createElement("iframe");
                        t.hidden = !0, n.head.appendChild(t);
                        const o = t.contentWindow;
                        o && o[e] && (r = o[e]), n.head.removeChild(t)
                    } catch (e) {}
                    return $i[e] = r.bind(window)
                }

                function qi(...e) {
                    return Wi("requestAnimationFrame")(...e)
                }

                function Ji(...e) {
                    return Wi("setTimeout")(...e)
                }
                var Ki = (e => (e[e["2D"] = 0] = "2D", e[e.WebGL = 1] = "WebGL", e[e.WebGL2 = 2] = "WebGL2", e))(Ki || {});
                let Vi;
                const Xi = e => {
                    if (!Vi) return e;
                    return (...t) => {
                        try {
                            return e(...t)
                        } catch (e) {
                            if (Vi && !0 === Vi(e)) return () => {};
                            throw e
                        }
                    }
                };
                for (var Yi = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", Gi = "undefined" == typeof Uint8Array ? [] : new Uint8Array(256), Qi = 0; Qi < 64; Qi++) Gi[Yi.charCodeAt(Qi)] = Qi;
                const Zi = new Map;
                const ea = (e, t, n) => {
                    if (!e || !ra(e, t) && "object" != typeof e) return;
                    const r = function(e, t) {
                        let n = Zi.get(e);
                        return n || (n = new Map, Zi.set(e, n)), n.has(t) || n.set(t, []), n.get(t)
                    }(n, e.constructor.name);
                    let o = r.indexOf(e);
                    return -1 === o && (o = r.length, r.push(e)), o
                };

                function ta(e, t, n) {
                    if (e instanceof Array) return e.map((e => ta(e, t, n)));
                    if (null === e) return e;
                    if (e instanceof Float32Array || e instanceof Float64Array || e instanceof Int32Array || e instanceof Uint32Array || e instanceof Uint8Array || e instanceof Uint16Array || e instanceof Int16Array || e instanceof Int8Array || e instanceof Uint8ClampedArray) {
                        return {
                            rr_type: e.constructor.name,
                            args: [Object.values(e)]
                        }
                    }
                    if (e instanceof ArrayBuffer) {
                        const t = e.constructor.name,
                            n = function(e) {
                                var t, n = new Uint8Array(e),
                                    r = n.length,
                                    o = "";
                                for (t = 0; t < r; t += 3) o += Yi[n[t] >> 2], o += Yi[(3 & n[t]) << 4 | n[t + 1] >> 4], o += Yi[(15 & n[t + 1]) << 2 | n[t + 2] >> 6], o += Yi[63 & n[t + 2]];
                                return r % 3 == 2 ? o = o.substring(0, o.length - 1) + "=" : r % 3 == 1 && (o = o.substring(0, o.length - 2) + "=="), o
                            }(e);
                        return {
                            rr_type: t,
                            base64: n
                        }
                    }
                    if (e instanceof DataView) {
                        return {
                            rr_type: e.constructor.name,
                            args: [ta(e.buffer, t, n), e.byteOffset, e.byteLength]
                        }
                    }
                    if (e instanceof HTMLImageElement) {
                        const t = e.constructor.name,
                            {
                                src: n
                            } = e;
                        return {
                            rr_type: t,
                            src: n
                        }
                    }
                    if (e instanceof HTMLCanvasElement) {
                        return {
                            rr_type: "HTMLImageElement",
                            src: e.toDataURL()
                        }
                    }
                    if (e instanceof ImageData) {
                        return {
                            rr_type: e.constructor.name,
                            args: [ta(e.data, t, n), e.width, e.height]
                        }
                    }
                    if (ra(e, t) || "object" == typeof e) {
                        return {
                            rr_type: e.constructor.name,
                            index: ea(e, t, n)
                        }
                    }
                    return e
                }
                const na = (e, t, n) => e.map((e => ta(e, t, n))),
                    ra = (e, t) => {
                        const n = ["WebGLActiveInfo", "WebGLBuffer", "WebGLFramebuffer", "WebGLProgram", "WebGLRenderbuffer", "WebGLShader", "WebGLShaderPrecisionFormat", "WebGLTexture", "WebGLUniformLocation", "WebGLVertexArrayObject", "WebGLVertexArrayObjectOES"].filter((e => "function" == typeof t[e]));
                        return Boolean(n.find((n => e instanceof t[n])))
                    };

                function oa(e, t, n, r, o) {
                    const s = [];
                    try {
                        const i = zi(e.HTMLCanvasElement.prototype, "getContext", (function(e) {
                            return function(s, ...i) {
                                if (!Hi(this, t, n, r, !0)) {
                                    const e = function(e) {
                                        return "experimental-webgl" === e ? "webgl" : e
                                    }(s);
                                    if ("__context" in this || (this.__context = e), o && ["webgl", "webgl2"].includes(e))
                                        if (i[0] && "object" == typeof i[0]) {
                                            const e = i[0];
                                            e.preserveDrawingBuffer || (e.preserveDrawingBuffer = !0)
                                        } else i.splice(0, 1, {
                                            preserveDrawingBuffer: !0
                                        })
                                }
                                return e.apply(this, [s, ...i])
                            }
                        }));
                        s.push(i)
                    } catch (e) {
                        console.error("failed to patch HTMLCanvasElement.prototype.getContext")
                    }
                    return () => {
                        s.forEach((e => e()))
                    }
                }

                function sa(e, t, n, r, o, s, i, a) {
                    const c = [],
                        u = Object.getOwnPropertyNames(e);
                    for (const i of u)
                        if (!["isContextLost", "canvas", "drawingBufferWidth", "drawingBufferHeight"].includes(i)) try {
                            if ("function" != typeof e[i]) continue;
                            const u = zi(e, i, (function(e) {
                                return function(...c) {
                                    const u = e.apply(this, c);
                                    if (ea(u, a, this), "tagName" in this.canvas && !Hi(this.canvas, r, o, s, !0)) {
                                        const e = na(c, a, this),
                                            r = {
                                                type: t,
                                                property: i,
                                                args: e
                                            };
                                        n(this.canvas, r)
                                    }
                                    return u
                                }
                            }));
                            c.push(u)
                        } catch (r) {
                            const o = ji(e, i, {
                                set(e) {
                                    n(this.canvas, {
                                        type: t,
                                        property: i,
                                        args: [e],
                                        setter: !0
                                    })
                                }
                            });
                            c.push(o)
                        }
                    return c
                }
                class ia {
                    reset() {
                        this.pendingCanvasMutations.clear(), this.restoreHandlers.forEach((e => {
                            try {
                                e()
                            } catch (e) {}
                        })), this.restoreHandlers = [], this.windowsSet = new WeakSet, this.windows = [], this.shadowDoms = new Set, Ct([this, "access", e => e.worker, "optionalAccess", e => e.terminate, "call", e => e()]), this.worker = null, this.snapshotInProgressMap = new Map, (this.options.recordCanvas && "number" == typeof this.options.sampling || this.options.enableManualSnapshot) && (this.worker = this.initFPSWorker())
                    }
                    freeze() {
                        this.frozen = !0
                    }
                    unfreeze() {
                        this.frozen = !1
                    }
                    lock() {
                        this.locked = !0
                    }
                    unlock() {
                        this.locked = !1
                    }
                    constructor(e) {
                        this.pendingCanvasMutations = new Map, this.rafStamps = {
                            latestId: 0,
                            invokeId: null
                        }, this.shadowDoms = new Set, this.windowsSet = new WeakSet, this.windows = [], this.restoreHandlers = [], this.frozen = !1, this.locked = !1, this.snapshotInProgressMap = new Map, this.worker = null, this.processMutation = (e, t) => {
                            !(this.rafStamps.invokeId && this.rafStamps.latestId !== this.rafStamps.invokeId) && this.rafStamps.invokeId || (this.rafStamps.invokeId = this.rafStamps.latestId), this.pendingCanvasMutations.has(e) || this.pendingCanvasMutations.set(e, []), this.pendingCanvasMutations.get(e).push(t)
                        };
                        const {
                            sampling: t = "all",
                            win: n,
                            blockClass: r,
                            blockSelector: o,
                            unblockSelector: s,
                            maxCanvasSize: i,
                            recordCanvas: a,
                            dataURLOptions: c,
                            errorHandler: u
                        } = e;
                        this.mutationCb = e.mutationCb, this.mirror = e.mirror, this.options = e, u && (Vi = u), (a && "number" == typeof t || e.enableManualSnapshot) && (this.worker = this.initFPSWorker()), this.addWindow(n), e.enableManualSnapshot || Xi((() => {
                            a && "all" === t && (this.startRAFTimestamping(), this.startPendingCanvasMutationFlusher()), a && "number" == typeof t && this.initCanvasFPSObserver(t, r, o, s, i, {
                                dataURLOptions: c
                            })
                        }))()
                    }
                    addWindow(e) {
                        const {
                            sampling: t = "all",
                            blockClass: n,
                            blockSelector: r,
                            unblockSelector: o,
                            recordCanvas: s,
                            enableManualSnapshot: i
                        } = this.options;
                        if (!this.windowsSet.has(e)) {
                            if (i) return this.windowsSet.add(e), void this.windows.push(new WeakRef(e));
                            Xi((() => {
                                if (s && "all" === t && this.initCanvasMutationObserver(e, n, r, o), s && "number" == typeof t) {
                                    const t = oa(e, n, r, o, !0);
                                    this.restoreHandlers.push((() => {
                                        t()
                                    }))
                                }
                            }))(), this.windowsSet.add(e), this.windows.push(new WeakRef(e))
                        }
                    }
                    addShadowRoot(e) {
                        this.shadowDoms.add(new WeakRef(e))
                    }
                    resetShadowRoots() {
                        this.shadowDoms = new Set
                    }
                    initFPSWorker() {
                        const e = new Worker(function() {
                            const e = new Blob(['for(var e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",t="undefined"==typeof Uint8Array?[]:new Uint8Array(256),a=0;a<64;a++)t[e.charCodeAt(a)]=a;var n=function(t){var a,n=new Uint8Array(t),r=n.length,s="";for(a=0;a<r;a+=3)s+=e[n[a]>>2],s+=e[(3&n[a])<<4|n[a+1]>>4],s+=e[(15&n[a+1])<<2|n[a+2]>>6],s+=e[63&n[a+2]];return r%3==2?s=s.substring(0,s.length-1)+"=":r%3==1&&(s=s.substring(0,s.length-2)+"=="),s};const r=new Map,s=new Map;const i=self;i.onmessage=async function(e){if(!("OffscreenCanvas"in globalThis))return i.postMessage({id:e.data.id});{const{id:t,bitmap:a,width:o,height:f,maxCanvasSize:c,dataURLOptions:g}=e.data,u=async function(e,t,a){const r=e+"-"+t;if("OffscreenCanvas"in globalThis){if(s.has(r))return s.get(r);const i=new OffscreenCanvas(e,t);i.getContext("2d");const o=await i.convertToBlob(a),f=await o.arrayBuffer(),c=n(f);return s.set(r,c),c}return""}(o,f,g),[h,d]=function(e,t,a){if(!a)return[e,t];const[n,r]=a;if(e<=n&&t<=r)return[e,t];let s=e,i=t;return s>n&&(i=Math.floor(n*t/e),s=n),i>r&&(s=Math.floor(r*e/t),i=r),[s,i]}(o,f,c),l=new OffscreenCanvas(h,d),w=l.getContext("bitmaprenderer"),p=h===o&&d===f?a:await createImageBitmap(a,{resizeWidth:h,resizeHeight:d,resizeQuality:"low"});w.transferFromImageBitmap(p),a.close();const y=await l.convertToBlob(g),v=y.type,b=await y.arrayBuffer(),m=n(b);if(p.close(),!r.has(t)&&await u===m)return r.set(t,m),i.postMessage({id:t});if(r.get(t)===m)return i.postMessage({id:t});i.postMessage({id:t,type:v,base64:m,width:o,height:f}),r.set(t,m)}};']);
                            return URL.createObjectURL(e)
                        }());
                        return e.onmessage = e => {
                            const t = e.data,
                                {
                                    id: n
                                } = t;
                            if (this.snapshotInProgressMap.set(n, !1), !("base64" in t)) return;
                            const {
                                base64: r,
                                type: o,
                                width: s,
                                height: i
                            } = t;
                            this.mutationCb({
                                id: n,
                                type: Ki["2D"],
                                commands: [{
                                    property: "clearRect",
                                    args: [0, 0, s, i]
                                }, {
                                    property: "drawImage",
                                    args: [{
                                        rr_type: "ImageBitmap",
                                        args: [{
                                            rr_type: "Blob",
                                            data: [{
                                                rr_type: "ArrayBuffer",
                                                base64: r
                                            }],
                                            type: o
                                        }]
                                    }, 0, 0, s, i]
                                }]
                            })
                        }, e
                    }
                    initCanvasFPSObserver(e, t, n, r, o, s) {
                        const i = this.takeSnapshot(!1, e, t, n, r, o, s.dataURLOptions);
                        this.restoreHandlers.push((() => {
                            cancelAnimationFrame(i)
                        }))
                    }
                    initCanvasMutationObserver(e, t, n, r) {
                        const o = oa(e, t, n, r, !1),
                            s = function(e, t, n, r, o) {
                                const s = [],
                                    i = Object.getOwnPropertyNames(t.CanvasRenderingContext2D.prototype);
                                for (const a of i) try {
                                    if ("function" != typeof t.CanvasRenderingContext2D.prototype[a]) continue;
                                    const i = zi(t.CanvasRenderingContext2D.prototype, a, (function(s) {
                                        return function(...i) {
                                            return Hi(this.canvas, n, r, o, !0) || Ji((() => {
                                                const n = na(i, t, this);
                                                e(this.canvas, {
                                                    type: Ki["2D"],
                                                    property: a,
                                                    args: n
                                                })
                                            }), 0), s.apply(this, i)
                                        }
                                    }));
                                    s.push(i)
                                } catch (n) {
                                    const r = ji(t.CanvasRenderingContext2D.prototype, a, {
                                        set(t) {
                                            e(this.canvas, {
                                                type: Ki["2D"],
                                                property: a,
                                                args: [t],
                                                setter: !0
                                            })
                                        }
                                    });
                                    s.push(r)
                                }
                                return () => {
                                    s.forEach((e => e()))
                                }
                            }(this.processMutation.bind(this), e, t, n, r),
                            i = function(e, t, n, r, o) {
                                const s = [];
                                return s.push(...sa(t.WebGLRenderingContext.prototype, Ki.WebGL, e, n, r, o, 0, t)), void 0 !== t.WebGL2RenderingContext && s.push(...sa(t.WebGL2RenderingContext.prototype, Ki.WebGL2, e, n, r, o, 0, t)), () => {
                                    s.forEach((e => e()))
                                }
                            }(this.processMutation.bind(this), e, t, n, r, this.mirror);
                        this.restoreHandlers.push((() => {
                            o(), s(), i()
                        }))
                    }
                    snapshot(e) {
                        const {
                            options: t
                        } = this, n = this.takeSnapshot(!0, "all" === t.sampling ? 2 : t.sampling || 2, t.blockClass, t.blockSelector, t.unblockSelector, t.maxCanvasSize, t.dataURLOptions, e);
                        this.restoreHandlers.push((() => {
                            cancelAnimationFrame(n)
                        }))
                    }
                    takeSnapshot(e, t, n, r, o, s, i, a) {
                        const c = 1e3 / t;
                        let u, l = 0;
                        const d = e => {
                                if (e) return [e];
                                const t = [],
                                    s = e => {
                                        e.querySelectorAll("canvas").forEach((e => {
                                            Hi(e, n, r, o, !0) || t.push(e)
                                        }))
                                    };
                                for (const e of this.windows) {
                                    const t = e.deref();
                                    t && s(t.document)
                                }
                                for (const e of this.shadowDoms) {
                                    const t = e.deref();
                                    t && s(t)
                                }
                                return t
                            },
                            p = t => {
                                this.windows.length && (l && t - l < c || (l = t, d(a).forEach((t => {
                                    if (!this.mirror.hasNode(t)) return;
                                    const n = this.mirror.getId(t);
                                    if (!this.snapshotInProgressMap.get(n) && t.width && t.height) {
                                        if (this.snapshotInProgressMap.set(n, !0), !e && ["webgl", "webgl2"].includes(t.__context)) {
                                            const e = t.getContext(t.__context);
                                            !1 === Ct([e, "optionalAccess", e => e.getContextAttributes, "call", e => e(), "optionalAccess", e => e.preserveDrawingBuffer]) && e.clear(e.COLOR_BUFFER_BIT)
                                        }
                                        createImageBitmap(t).then((e => {
                                            Ct([this, "access", e => e.worker, "optionalAccess", e => e.postMessage, "call", r => r({
                                                id: n,
                                                bitmap: e,
                                                width: t.width,
                                                height: t.height,
                                                dataURLOptions: i,
                                                maxCanvasSize: s
                                            }, [e])])
                                        })).catch((e => {
                                            Xi((() => {
                                                throw e
                                            }))()
                                        }))
                                    }
                                }))), u = qi(p))
                            };
                        return u = qi(p), u
                    }
                    startPendingCanvasMutationFlusher() {
                        qi((() => this.flushPendingCanvasMutations()))
                    }
                    startRAFTimestamping() {
                        const e = t => {
                            this.rafStamps.latestId = t, qi(e)
                        };
                        qi(e)
                    }
                    flushPendingCanvasMutations() {
                        this.pendingCanvasMutations.forEach(((e, t) => {
                            const n = this.mirror.getId(t);
                            this.flushPendingCanvasMutationFor(t, n)
                        })), qi((() => this.flushPendingCanvasMutations()))
                    }
                    flushPendingCanvasMutationFor(e, t) {
                        if (this.frozen || this.locked) return;
                        const n = this.pendingCanvasMutations.get(e);
                        if (!n || -1 === t) return;
                        const r = n.map((e => {
                                const {
                                    type: t,
                                    ...n
                                } = e;
                                return n
                            })),
                            {
                                type: o
                            } = n[0];
                        this.mutationCb({
                            id: t,
                            type: o,
                            commands: r
                        }), this.pendingCanvasMutations.delete(e)
                    }
                }
                const aa = {
                        low: {
                            sampling: {
                                canvas: 1
                            },
                            dataURLOptions: {
                                type: "image/webp",
                                quality: .25
                            }
                        },
                        medium: {
                            sampling: {
                                canvas: 2
                            },
                            dataURLOptions: {
                                type: "image/webp",
                                quality: .4
                            }
                        },
                        high: {
                            sampling: {
                                canvas: 4
                            },
                            dataURLOptions: {
                                type: "image/webp",
                                quality: .5
                            }
                        }
                    },
                    ca = 1280,
                    ua = (0, c._C)(((e = {}) => {
                        const [t, n] = e.maxCanvasSize || [], r = {
                            quality: e.quality || "medium",
                            enableManualSnapshot: e.enableManualSnapshot,
                            maxCanvasSize: [t ? Math.min(t, ca) : ca, n ? Math.min(n, ca) : ca]
                        };
                        let o;
                        const s = new Promise((e => o = e));
                        return {
                            name: "ReplayCanvas",
                            getOptions() {
                                const {
                                    quality: e,
                                    enableManualSnapshot: t,
                                    maxCanvasSize: n
                                } = r;
                                return {
                                    enableManualSnapshot: t,
                                    recordCanvas: !0,
                                    getCanvasManager: e => {
                                        const r = new ia({ ...e,
                                            enableManualSnapshot: t,
                                            maxCanvasSize: n,
                                            errorHandler: e => {
                                                try {
                                                    "object" == typeof e && (e.__rrweb__ = !0)
                                                } catch (e) {}
                                            }
                                        });
                                        return o(r), r
                                    },
                                    ...aa[e || "medium"] || aa.medium
                                }
                            },
                            async snapshot(e) {
                                (await s).snapshot(e)
                            }
                        }
                    })),
                    la = v.O,
                    da = la.document,
                    pa = la.navigator,
                    ha = "Report a Bug",
                    fa = (e, t = {
                        includeReplay: !0
                    }) => {
                        if (!e.message) throw new Error("Unable to submit feedback with empty message");
                        const n = (0, C.KU)();
                        if (!n) throw new Error("No client setup, cannot send feedback.");
                        e.tags && Object.keys(e.tags).length && (0, C.o5)().setTags(e.tags);
                        const r = I({
                            source: "api",
                            url: (0, Tt.$N)(),
                            ...e
                        }, t);
                        return new Promise(((e, t) => {
                            const o = setTimeout((() => t("Unable to determine if Feedback was correctly sent.")), 5e3),
                                s = n.on("afterSendEvent", ((n, i) => {
                                    if (n.event_id === r) return clearTimeout(o), s(), i && "number" == typeof i.statusCode && i.statusCode >= 200 && i.statusCode < 300 && e(r), i && "number" == typeof i.statusCode && 0 === i.statusCode ? t("Unable to send Feedback. This is because of network issues, or because you are using an ad-blocker.") : t("Unable to send Feedback. This could be because of network issues, or because you are using an ad-blocker")
                                }))
                        }))
                    };

                function ma(e, t) {
                    return { ...e,
                        ...t,
                        tags: { ...e.tags,
                            ...t.tags
                        },
                        onFormOpen: () => {
                            t.onFormOpen && t.onFormOpen(), e.onFormOpen && e.onFormOpen()
                        },
                        onFormClose: () => {
                            t.onFormClose && t.onFormClose(), e.onFormClose && e.onFormClose()
                        },
                        onSubmitSuccess: n => {
                            t.onSubmitSuccess && t.onSubmitSuccess(n), e.onSubmitSuccess && e.onSubmitSuccess(n)
                        },
                        onSubmitError: n => {
                            t.onSubmitError && t.onSubmitError(n), e.onSubmitError && e.onSubmitError(n)
                        },
                        onFormSubmitted: () => {
                            t.onFormSubmitted && t.onFormSubmitted(), e.onFormSubmitted && e.onFormSubmitted()
                        },
                        themeDark: { ...e.themeDark,
                            ...t.themeDark
                        },
                        themeLight: { ...e.themeLight,
                            ...t.themeLight
                        }
                    }
                }

                function ga(e, t) {
                    return Object.entries(t).forEach((([t, n]) => {
                        e.setAttributeNS(null, t, n)
                    })), e
                }

                function _a({
                    triggerLabel: e,
                    triggerAriaLabel: t,
                    shadow: n
                }) {
                    const r = da.createElement("button");
                    if (r.type = "button", r.className = "widget__actor", r.ariaHidden = "false", r.ariaLabel = t || e || ha, r.appendChild(function() {
                            const e = e => la.document.createElementNS("http://www.w3.org/2000/svg", e),
                                t = ga(e("svg"), {
                                    width: "20",
                                    height: "20",
                                    viewBox: "0 0 20 20",
                                    fill: "var(--foreground)"
                                }),
                                n = ga(e("g"), {
                                    clipPath: "url(#clip0_57_80)"
                                }),
                                r = ga(e("path"), {
                                    "fill-rule": "evenodd",
                                    "clip-rule": "evenodd",
                                    d: "M15.6622 15H12.3997C12.2129 14.9959 12.031 14.9396 11.8747 14.8375L8.04965 12.2H7.49956V19.1C7.4875 19.3348 7.3888 19.5568 7.22256 19.723C7.05632 19.8892 6.83435 19.9879 6.59956 20H2.04956C1.80193 19.9968 1.56535 19.8969 1.39023 19.7218C1.21511 19.5467 1.1153 19.3101 1.11206 19.0625V12.2H0.949652C0.824431 12.2017 0.700142 12.1783 0.584123 12.1311C0.468104 12.084 0.362708 12.014 0.274155 11.9255C0.185602 11.8369 0.115689 11.7315 0.0685419 11.6155C0.0213952 11.4995 -0.00202913 11.3752 -0.00034808 11.25V3.75C-0.00900498 3.62067 0.0092504 3.49095 0.0532651 3.36904C0.0972798 3.24712 0.166097 3.13566 0.255372 3.04168C0.344646 2.94771 0.452437 2.87327 0.571937 2.82307C0.691437 2.77286 0.82005 2.74798 0.949652 2.75H8.04965L11.8747 0.1625C12.031 0.0603649 12.2129 0.00407221 12.3997 0H15.6622C15.9098 0.00323746 16.1464 0.103049 16.3215 0.278167C16.4966 0.453286 16.5964 0.689866 16.5997 0.9375V3.25269C17.3969 3.42959 18.1345 3.83026 18.7211 4.41679C19.5322 5.22788 19.9878 6.32796 19.9878 7.47502C19.9878 8.62209 19.5322 9.72217 18.7211 10.5333C18.1345 11.1198 17.3969 11.5205 16.5997 11.6974V14.0125C16.6047 14.1393 16.5842 14.2659 16.5395 14.3847C16.4948 14.5035 16.4268 14.6121 16.3394 14.7042C16.252 14.7962 16.147 14.8698 16.0307 14.9206C15.9144 14.9714 15.7891 14.9984 15.6622 15ZM1.89695 10.325H1.88715V4.625H8.33715C8.52423 4.62301 8.70666 4.56654 8.86215 4.4625L12.6872 1.875H14.7247V13.125H12.6872L8.86215 10.4875C8.70666 10.3835 8.52423 10.327 8.33715 10.325H2.20217C2.15205 10.3167 2.10102 10.3125 2.04956 10.3125C1.9981 10.3125 1.94708 10.3167 1.89695 10.325ZM2.98706 12.2V18.1625H5.66206V12.2H2.98706ZM16.5997 9.93612V5.01393C16.6536 5.02355 16.7072 5.03495 16.7605 5.04814C17.1202 5.13709 17.4556 5.30487 17.7425 5.53934C18.0293 5.77381 18.2605 6.06912 18.4192 6.40389C18.578 6.73866 18.6603 7.10452 18.6603 7.47502C18.6603 7.84552 18.578 8.21139 18.4192 8.54616C18.2605 8.88093 18.0293 9.17624 17.7425 9.41071C17.4556 9.64518 17.1202 9.81296 16.7605 9.90191C16.7072 9.91509 16.6536 9.9265 16.5997 9.93612Z"
                                });
                            t.appendChild(n).appendChild(r);
                            const o = e("defs"),
                                s = ga(e("clipPath"), {
                                    id: "clip0_57_80"
                                }),
                                i = ga(e("rect"), {
                                    width: "20",
                                    height: "20",
                                    fill: "white"
                                });
                            return s.appendChild(i), o.appendChild(s), t.appendChild(o).appendChild(s).appendChild(i), t
                        }()), e) {
                        const t = da.createElement("span");
                        t.appendChild(da.createTextNode(e)), r.appendChild(t)
                    }
                    const o = function() {
                        const e = da.createElement("style");
                        return e.textContent = '\n.widget__actor {\n  position: fixed;\n  z-index: var(--z-index);\n  margin: var(--page-margin);\n  inset: var(--actor-inset);\n\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  padding: 16px;\n\n  font-family: inherit;\n  font-size: var(--font-size);\n  font-weight: 600;\n  line-height: 1.14em;\n  text-decoration: none;\n\n  background: var(--actor-background, var(--background));\n  border-radius: var(--actor-border-radius, 1.7em/50%);\n  border: var(--actor-border, var(--border));\n  box-shadow: var(--actor-box-shadow, var(--box-shadow));\n  color: var(--actor-color, var(--foreground));\n  fill: var(--actor-color, var(--foreground));\n  cursor: pointer;\n  opacity: 1;\n  transition: transform 0.2s ease-in-out;\n  transform: translate(0, 0) scale(1);\n}\n.widget__actor[aria-hidden="true"] {\n  opacity: 0;\n  pointer-events: none;\n  visibility: hidden;\n  transform: translate(0, 16px) scale(0.98);\n}\n\n.widget__actor:hover {\n  background: var(--actor-hover-background, var(--background));\n  filter: var(--interactive-filter);\n}\n\n.widget__actor svg {\n  width: 1.14em;\n  height: 1.14em;\n}\n\n@media (max-width: 600px) {\n  .widget__actor span {\n    display: none;\n  }\n}\n', e
                    }();
                    return {
                        el: r,
                        appendToDom() {
                            n.appendChild(o), n.appendChild(r)
                        },
                        removeFromDom() {
                            n.removeChild(r), n.removeChild(o)
                        },
                        show() {
                            r.ariaHidden = "false"
                        },
                        hide() {
                            r.ariaHidden = "true"
                        }
                    }
                }
                const ya = "rgba(88, 74, 192, 1)",
                    va = {
                        foreground: "#2b2233",
                        background: "#ffffff",
                        accentForeground: "white",
                        accentBackground: ya,
                        successColor: "#268d75",
                        errorColor: "#df3338",
                        border: "1.5px solid rgba(41, 35, 47, 0.13)",
                        boxShadow: "0px 4px 24px 0px rgba(43, 34, 51, 0.12)",
                        outline: "1px auto var(--accent-background)",
                        interactiveFilter: "brightness(95%)"
                    },
                    ba = {
                        foreground: "#ebe6ef",
                        background: "#29232f",
                        accentForeground: "white",
                        accentBackground: ya,
                        successColor: "#2da98c",
                        errorColor: "#f55459",
                        border: "1.5px solid rgba(235, 230, 239, 0.15)",
                        boxShadow: "0px 4px 24px 0px rgba(43, 34, 51, 0.12)",
                        outline: "1px auto var(--accent-background)",
                        interactiveFilter: "brightness(150%)"
                    };

                function Sa(e) {
                    return `\n  --foreground: ${e.foreground};\n  --background: ${e.background};\n  --accent-foreground: ${e.accentForeground};\n  --accent-background: ${e.accentBackground};\n  --success-color: ${e.successColor};\n  --error-color: ${e.errorColor};\n  --border: ${e.border};\n  --box-shadow: ${e.boxShadow};\n  --outline: ${e.outline};\n  --interactive-filter: ${e.interactiveFilter};\n  `
                }
                const wa = ({
                    lazyLoadIntegration: e,
                    getModalIntegration: t,
                    getScreenshotIntegration: n
                }) => ({
                    id: r = "sentry-feedback",
                    autoInject: o = !0,
                    showBranding: s = !0,
                    isEmailRequired: i = !1,
                    isNameRequired: a = !1,
                    showEmail: c = !0,
                    showName: u = !0,
                    enableScreenshot: l = !0,
                    useSentryUser: d = {
                        email: "email",
                        name: "username"
                    },
                    tags: p,
                    colorScheme: h = "system",
                    themeLight: f = {},
                    themeDark: m = {},
                    addScreenshotButtonLabel: g = "Add a screenshot",
                    cancelButtonLabel: _ = "Cancel",
                    confirmButtonLabel: y = "Confirm",
                    emailLabel: v = "Email",
                    emailPlaceholder: b = "your.email@example.org",
                    formTitle: S = "Report a Bug",
                    isRequiredLabel: w = "(required)",
                    messageLabel: k = "Description",
                    messagePlaceholder: x = "What's the bug? What did you expect?",
                    nameLabel: T = "Name",
                    namePlaceholder: I = "Your Name",
                    removeScreenshotButtonLabel: E = "Remove screenshot",
                    submitButtonLabel: M = "Send Bug Report",
                    successMessageText: R = "Thank you for your report!",
                    triggerLabel: A = ha,
                    triggerAriaLabel: N = "",
                    onFormOpen: L,
                    onFormClose: D,
                    onSubmitSuccess: O,
                    onSubmitError: F,
                    onFormSubmitted: P
                } = {}) => {
                    const B = {
                        id: r,
                        autoInject: o,
                        showBranding: s,
                        isEmailRequired: i,
                        isNameRequired: a,
                        showEmail: c,
                        showName: u,
                        enableScreenshot: l,
                        useSentryUser: d,
                        tags: p,
                        colorScheme: h,
                        themeDark: m,
                        themeLight: f,
                        triggerLabel: A,
                        triggerAriaLabel: N,
                        cancelButtonLabel: _,
                        submitButtonLabel: M,
                        confirmButtonLabel: y,
                        formTitle: S,
                        emailLabel: v,
                        emailPlaceholder: b,
                        messageLabel: k,
                        messagePlaceholder: x,
                        nameLabel: T,
                        namePlaceholder: I,
                        successMessageText: R,
                        isRequiredLabel: w,
                        addScreenshotButtonLabel: g,
                        removeScreenshotButtonLabel: E,
                        onFormClose: D,
                        onFormOpen: L,
                        onSubmitError: F,
                        onSubmitSuccess: O,
                        onFormSubmitted: P
                    };
                    let U = null,
                        j = [];
                    const z = e => {
                            if (!U) {
                                const t = da.createElement("div");
                                t.id = String(e.id), da.body.appendChild(t), U = t.attachShadow({
                                    mode: "open"
                                }), U.appendChild(function({
                                    colorScheme: e,
                                    themeDark: t,
                                    themeLight: n
                                }) {
                                    const r = da.createElement("style");
                                    return r.textContent = `\n:host {\n  --font-family: system-ui, 'Helvetica Neue', Arial, sans-serif;\n  --font-size: 14px;\n  --z-index: 100000;\n\n  --page-margin: 16px;\n  --inset: auto 0 0 auto;\n  --actor-inset: var(--inset);\n\n  font-family: var(--font-family);\n  font-size: var(--font-size);\n\n  ${"system"!==e?"color-scheme: only light;":""}\n\n  ${Sa("dark"===e?{...ba,...t}:{...va,...n})}\n}\n\n${"system"===e?`\n@media (prefers-color-scheme: dark) {\n  :host {\n    ${Sa({...ba,...t})}\n  }\n}`:""}\n}\n`, r
                                }(e))
                            }
                            return U
                        },
                        H = async (t, n, r) => {
                            const o = (0, C.KU)(),
                                s = o && o.getIntegrationByName(t);
                            if (s) return s;
                            const i = (n && n() || await e(r))();
                            return o && o.addIntegration(i), i
                        },
                        $ = async e => {
                            const r = e.enableScreenshot && !(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(pa.userAgent) || /Macintosh/i.test(pa.userAgent) && pa.maxTouchPoints && pa.maxTouchPoints > 1 || !isSecureContext),
                                [o, s] = await Promise.all([H("FeedbackModal", t, "feedbackModalIntegration"), r ? H("FeedbackScreenshot", n, "feedbackScreenshotIntegration") : void 0]);
                            if (!o) throw new Error("[Feedback] Missing feedback modal integration!");
                            return o.createDialog({
                                options: e,
                                screenshotIntegration: r ? s : void 0,
                                sendFeedback: fa,
                                shadow: z(e)
                            })
                        },
                        W = (e, t = {}) => {
                            const n = ma(B, t),
                                r = "string" == typeof e ? da.querySelector(e) : "function" == typeof e.addEventListener ? e : null;
                            if (!r) throw new Error("Unable to attach to target element");
                            let o = null;
                            const s = async () => {
                                o || (o = await $({ ...n,
                                    onFormClose: () => {
                                        o && o.close(), n.onFormClose && n.onFormClose()
                                    },
                                    onFormSubmitted: () => {
                                        o && o.removeFromDom(), n.onFormSubmitted && n.onFormSubmitted()
                                    }
                                })), o.appendToDom(), o.open()
                            };
                            r.addEventListener("click", s);
                            const i = () => {
                                j = j.filter((e => e !== i)), o && o.removeFromDom(), o = null, r.removeEventListener("click", s)
                            };
                            return j.push(i), i
                        },
                        q = (e = {}) => {
                            const t = ma(B, e),
                                n = z(t),
                                r = _a({
                                    triggerLabel: t.triggerLabel,
                                    triggerAriaLabel: t.triggerAriaLabel,
                                    shadow: n
                                });
                            return W(r.el, { ...t,
                                onFormOpen() {
                                    r.hide()
                                },
                                onFormClose() {
                                    r.show()
                                },
                                onFormSubmitted() {
                                    r.show()
                                }
                            }), r
                        };
                    return {
                        name: "Feedback",
                        setupOnce() {
                            Rt() && B.autoInject && ("loading" === da.readyState ? da.addEventListener("DOMContentLoaded", (() => q().appendToDom())) : q().appendToDom())
                        },
                        attachTo: W,
                        createWidget(e = {}) {
                            const t = q(ma(B, e));
                            return t.appendToDom(), t
                        },
                        async createForm(e = {}) {
                            return $(ma(B, e))
                        },
                        remove() {
                            U && (U.parentElement && U.parentElement.remove(), U = null), j.forEach((e => e())), j = []
                        }
                    }
                };

                function ka() {
                    const e = (0, C.KU)();
                    return e && e.getIntegrationByName("Feedback")
                }
                var Ca, xa, Ta, Ia, Ea, Ma, Ra, Aa = {},
                    Na = [],
                    La = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
                    Da = Array.isArray;

                function Oa(e, t) {
                    for (var n in t) e[n] = t[n];
                    return e
                }

                function Fa(e) {
                    var t = e.parentNode;
                    t && t.removeChild(e)
                }

                function Pa(e, t, n) {
                    var r, o, s, i = {};
                    for (s in t) "key" == s ? r = t[s] : "ref" == s ? o = t[s] : i[s] = t[s];
                    if (arguments.length > 2 && (i.children = arguments.length > 3 ? Ca.call(arguments, 2) : n), "function" == typeof e && null != e.defaultProps)
                        for (s in e.defaultProps) void 0 === i[s] && (i[s] = e.defaultProps[s]);
                    return Ba(e, i, r, o, null)
                }

                function Ba(e, t, n, r, o) {
                    var s = {
                        type: e,
                        props: t,
                        key: n,
                        ref: r,
                        __k: null,
                        __: null,
                        __b: 0,
                        __e: null,
                        __d: void 0,
                        __c: null,
                        constructor: void 0,
                        __v: null == o ? ++Ta : o,
                        __i: -1,
                        __u: 0
                    };
                    return null == o && null != xa.vnode && xa.vnode(s), s
                }

                function Ua(e) {
                    return e.children
                }

                function ja(e, t) {
                    this.props = e, this.context = t
                }

                function za(e, t) {
                    if (null == t) return e.__ ? za(e.__, e.__i + 1) : null;
                    for (var n; t < e.__k.length; t++)
                        if (null != (n = e.__k[t]) && null != n.__e) return n.__e;
                    return "function" == typeof e.type ? za(e) : null
                }

                function Ha(e, t, n) {
                    var r, o = e.__v,
                        s = o.__e,
                        i = e.__P;
                    if (i) return (r = Oa({}, o)).__v = o.__v + 1, xa.vnode && xa.vnode(r), Za(i, r, o, e.__n, void 0 !== i.ownerSVGElement, 32 & o.__u ? [s] : null, t, null == s ? za(o) : s, !!(32 & o.__u), n), r.__.__k[r.__i] = r, r.__d = void 0, r.__e != s && $a(r), r
                }

                function $a(e) {
                    var t, n;
                    if (null != (e = e.__) && null != e.__c) {
                        for (e.__e = e.__c.base = null, t = 0; t < e.__k.length; t++)
                            if (null != (n = e.__k[t]) && null != n.__e) {
                                e.__e = e.__c.base = n.__e;
                                break
                            }
                        return $a(e)
                    }
                }

                function Wa(e) {
                    (!e.__d && (e.__d = !0) && Ia.push(e) && !qa.__r++ || Ea !== xa.debounceRendering) && ((Ea = xa.debounceRendering) || Ma)(qa)
                }

                function qa() {
                    var e, t, n, r = [],
                        o = [];
                    for (Ia.sort(Ra); e = Ia.shift();) e.__d && (n = Ia.length, t = Ha(e, r, o) || t, 0 === n || Ia.length > n ? (ec(r, t, o), o.length = r.length = 0, t = void 0, Ia.sort(Ra)) : t && xa.__c && xa.__c(t, Na));
                    t && ec(r, t, o), qa.__r = 0
                }

                function Ja(e, t, n, r, o, s, i, a, c, u, l) {
                    var d, p, h, f, m, g = r && r.__k || Na,
                        _ = t.length;
                    for (n.__d = c, function(e, t, n) {
                            var r, o, s, i, a, c = t.length,
                                u = n.length,
                                l = u,
                                d = 0;
                            for (e.__k = [], r = 0; r < c; r++) null != (o = e.__k[r] = null == (o = t[r]) || "boolean" == typeof o || "function" == typeof o ? null : "string" == typeof o || "number" == typeof o || "bigint" == typeof o || o.constructor == String ? Ba(null, o, null, null, o) : Da(o) ? Ba(Ua, {
                                children: o
                            }, null, null, null) : void 0 === o.constructor && o.__b > 0 ? Ba(o.type, o.props, o.key, o.ref ? o.ref : null, o.__v) : o) ? (o.__ = e, o.__b = e.__b + 1, a = Va(o, n, i = r + d, l), o.__i = a, s = null, -1 !== a && (l--, (s = n[a]) && (s.__u |= 131072)), null == s || null === s.__v ? (-1 == a && d--, "function" != typeof o.type && (o.__u |= 65536)) : a !== i && (a === i + 1 ? d++ : a > i ? l > c - i ? d += a - i : d-- : d = a < i && a == i - 1 ? a - i : 0, a !== r + d && (o.__u |= 65536))) : (s = n[r]) && null == s.key && s.__e && (s.__e == e.__d && (e.__d = za(s)), rc(s, s, !1), n[r] = null, l--);
                            if (l)
                                for (r = 0; r < u; r++) null != (s = n[r]) && !(131072 & s.__u) && (s.__e == e.__d && (e.__d = za(s)), rc(s, s))
                        }(n, t, g), c = n.__d, d = 0; d < _; d++) null != (h = n.__k[d]) && "boolean" != typeof h && "function" != typeof h && (p = -1 === h.__i ? Aa : g[h.__i] || Aa, h.__i = d, Za(e, h, p, o, s, i, a, c, u, l), f = h.__e, h.ref && p.ref != h.ref && (p.ref && nc(p.ref, null, h), l.push(h.ref, h.__c || f, h)), null == m && null != f && (m = f), 65536 & h.__u || p.__k === h.__k ? c = Ka(h, c, e) : "function" == typeof h.type && void 0 !== h.__d ? c = h.__d : f && (c = f.nextSibling), h.__d = void 0, h.__u &= -196609);
                    n.__d = c, n.__e = m
                }

                function Ka(e, t, n) {
                    var r, o;
                    if ("function" == typeof e.type) {
                        for (r = e.__k, o = 0; r && o < r.length; o++) r[o] && (r[o].__ = e, t = Ka(r[o], t, n));
                        return t
                    }
                    e.__e != t && (n.insertBefore(e.__e, t || null), t = e.__e);
                    do {
                        t = t && t.nextSibling
                    } while (null != t && 8 === t.nodeType);
                    return t
                }

                function Va(e, t, n, r) {
                    var o = e.key,
                        s = e.type,
                        i = n - 1,
                        a = n + 1,
                        c = t[n];
                    if (null === c || c && o == c.key && s === c.type) return n;
                    if (r > (null == c || 131072 & c.__u ? 0 : 1))
                        for (; i >= 0 || a < t.length;) {
                            if (i >= 0) {
                                if ((c = t[i]) && !(131072 & c.__u) && o == c.key && s === c.type) return i;
                                i--
                            }
                            if (a < t.length) {
                                if ((c = t[a]) && !(131072 & c.__u) && o == c.key && s === c.type) return a;
                                a++
                            }
                        }
                    return -1
                }

                function Xa(e, t, n) {
                    "-" === t[0] ? e.setProperty(t, null == n ? "" : n) : e[t] = null == n ? "" : "number" != typeof n || La.test(t) ? n : n + "px"
                }

                function Ya(e, t, n, r, o) {
                    var s;
                    e: if ("style" === t)
                        if ("string" == typeof n) e.style.cssText = n;
                        else {
                            if ("string" == typeof r && (e.style.cssText = r = ""), r)
                                for (t in r) n && t in n || Xa(e.style, t, "");
                            if (n)
                                for (t in n) r && n[t] === r[t] || Xa(e.style, t, n[t])
                        }
                    else if ("o" === t[0] && "n" === t[1]) s = t !== (t = t.replace(/(PointerCapture)$|Capture$/i, "$1")), t = t.toLowerCase() in e ? t.toLowerCase().slice(2) : t.slice(2), e.l || (e.l = {}), e.l[t + s] = n, n ? r ? n.u = r.u : (n.u = Date.now(), e.addEventListener(t, s ? Qa : Ga, s)) : e.removeEventListener(t, s ? Qa : Ga, s);
                    else {
                        if (o) t = t.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
                        else if ("width" !== t && "height" !== t && "href" !== t && "list" !== t && "form" !== t && "tabIndex" !== t && "download" !== t && "rowSpan" !== t && "colSpan" !== t && "role" !== t && t in e) try {
                            e[t] = null == n ? "" : n;
                            break e
                        } catch (e) {}
                        "function" == typeof n || (null == n || !1 === n && "-" !== t[4] ? e.removeAttribute(t) : e.setAttribute(t, n))
                    }
                }

                function Ga(e) {
                    if (this.l) {
                        var t = this.l[e.type + !1];
                        if (e.t) {
                            if (e.t <= t.u) return
                        } else e.t = Date.now();
                        return t(xa.event ? xa.event(e) : e)
                    }
                }

                function Qa(e) {
                    if (this.l) return this.l[e.type + !0](xa.event ? xa.event(e) : e)
                }

                function Za(e, t, n, r, o, s, i, a, c, u) {
                    var l, d, p, h, f, m, g, _, y, v, b, S, w, k, C, x = t.type;
                    if (void 0 !== t.constructor) return null;
                    128 & n.__u && (c = !!(32 & n.__u), s = [a = t.__e = n.__e]), (l = xa.__b) && l(t);
                    e: if ("function" == typeof x) try {
                        if (_ = t.props, y = (l = x.contextType) && r[l.__c], v = l ? y ? y.props.value : l.__ : r, n.__c ? g = (d = t.__c = n.__c).__ = d.__E : ("prototype" in x && x.prototype.render ? t.__c = d = new x(_, v) : (t.__c = d = new ja(_, v), d.constructor = x, d.render = oc), y && y.sub(d), d.props = _, d.state || (d.state = {}), d.context = v, d.__n = r, p = d.__d = !0, d.__h = [], d._sb = []), null == d.__s && (d.__s = d.state), null != x.getDerivedStateFromProps && (d.__s == d.state && (d.__s = Oa({}, d.__s)), Oa(d.__s, x.getDerivedStateFromProps(_, d.__s))), h = d.props, f = d.state, d.__v = t, p) null == x.getDerivedStateFromProps && null != d.componentWillMount && d.componentWillMount(), null != d.componentDidMount && d.__h.push(d.componentDidMount);
                        else {
                            if (null == x.getDerivedStateFromProps && _ !== h && null != d.componentWillReceiveProps && d.componentWillReceiveProps(_, v), !d.__e && (null != d.shouldComponentUpdate && !1 === d.shouldComponentUpdate(_, d.__s, v) || t.__v === n.__v)) {
                                for (t.__v !== n.__v && (d.props = _, d.state = d.__s, d.__d = !1), t.__e = n.__e, t.__k = n.__k, t.__k.forEach((function(e) {
                                        e && (e.__ = t)
                                    })), b = 0; b < d._sb.length; b++) d.__h.push(d._sb[b]);
                                d._sb = [], d.__h.length && i.push(d);
                                break e
                            }
                            null != d.componentWillUpdate && d.componentWillUpdate(_, d.__s, v), null != d.componentDidUpdate && d.__h.push((function() {
                                d.componentDidUpdate(h, f, m)
                            }))
                        }
                        if (d.context = v, d.props = _, d.__P = e, d.__e = !1, S = xa.__r, w = 0, "prototype" in x && x.prototype.render) {
                            for (d.state = d.__s, d.__d = !1, S && S(t), l = d.render(d.props, d.state, d.context), k = 0; k < d._sb.length; k++) d.__h.push(d._sb[k]);
                            d._sb = []
                        } else
                            do {
                                d.__d = !1, S && S(t), l = d.render(d.props, d.state, d.context), d.state = d.__s
                            } while (d.__d && ++w < 25);
                        d.state = d.__s, null != d.getChildContext && (r = Oa(Oa({}, r), d.getChildContext())), p || null == d.getSnapshotBeforeUpdate || (m = d.getSnapshotBeforeUpdate(h, f)), Ja(e, Da(C = null != l && l.type === Ua && null == l.key ? l.props.children : l) ? C : [C], t, n, r, o, s, i, a, c, u), d.base = t.__e, t.__u &= -161, d.__h.length && i.push(d), g && (d.__E = d.__ = null)
                    } catch (e) {
                        t.__v = null, c || null != s ? (t.__e = a, t.__u |= c ? 160 : 32, s[s.indexOf(a)] = null) : (t.__e = n.__e, t.__k = n.__k), xa.__e(e, t, n)
                    } else null == s && t.__v === n.__v ? (t.__k = n.__k, t.__e = n.__e) : t.__e = tc(n.__e, t, n, r, o, s, i, c, u);
                    (l = xa.diffed) && l(t)
                }

                function ec(e, t, n) {
                    for (var r = 0; r < n.length; r++) nc(n[r], n[++r], n[++r]);
                    xa.__c && xa.__c(t, e), e.some((function(t) {
                        try {
                            e = t.__h, t.__h = [], e.some((function(e) {
                                e.call(t)
                            }))
                        } catch (e) {
                            xa.__e(e, t.__v)
                        }
                    }))
                }

                function tc(e, t, n, r, o, s, i, a, c) {
                    var u, l, d, p, h, f, m, g = n.props,
                        _ = t.props,
                        y = t.type;
                    if ("svg" === y && (o = !0), null != s)
                        for (u = 0; u < s.length; u++)
                            if ((h = s[u]) && "setAttribute" in h == !!y && (y ? h.localName === y : 3 === h.nodeType)) {
                                e = h, s[u] = null;
                                break
                            }
                    if (null == e) {
                        if (null === y) return document.createTextNode(_);
                        e = o ? document.createElementNS("http://www.w3.org/2000/svg", y) : document.createElement(y, _.is && _), s = null, a = !1
                    }
                    if (null === y) g === _ || a && e.data === _ || (e.data = _);
                    else {
                        if (s = s && Ca.call(e.childNodes), g = n.props || Aa, !a && null != s)
                            for (g = {}, u = 0; u < e.attributes.length; u++) g[(h = e.attributes[u]).name] = h.value;
                        for (u in g) h = g[u], "children" == u || ("dangerouslySetInnerHTML" == u ? d = h : "key" === u || u in _ || Ya(e, u, null, h, o));
                        for (u in _) h = _[u], "children" == u ? p = h : "dangerouslySetInnerHTML" == u ? l = h : "value" == u ? f = h : "checked" == u ? m = h : "key" === u || a && "function" != typeof h || g[u] === h || Ya(e, u, h, g[u], o);
                        if (l) a || d && (l.__html === d.__html || l.__html === e.innerHTML) || (e.innerHTML = l.__html), t.__k = [];
                        else if (d && (e.innerHTML = ""), Ja(e, Da(p) ? p : [p], t, n, r, o && "foreignObject" !== y, s, i, s ? s[0] : n.__k && za(n, 0), a, c), null != s)
                            for (u = s.length; u--;) null != s[u] && Fa(s[u]);
                        a || (u = "value", void 0 !== f && (f !== e[u] || "progress" === y && !f || "option" === y && f !== g[u]) && Ya(e, u, f, g[u], !1), u = "checked", void 0 !== m && m !== e[u] && Ya(e, u, m, g[u], !1))
                    }
                    return e
                }

                function nc(e, t, n) {
                    try {
                        "function" == typeof e ? e(t) : e.current = t
                    } catch (e) {
                        xa.__e(e, n)
                    }
                }

                function rc(e, t, n) {
                    var r, o;
                    if (xa.unmount && xa.unmount(e), (r = e.ref) && (r.current && r.current !== e.__e || nc(r, null, t)), null != (r = e.__c)) {
                        if (r.componentWillUnmount) try {
                            r.componentWillUnmount()
                        } catch (e) {
                            xa.__e(e, t)
                        }
                        r.base = r.__P = null, e.__c = void 0
                    }
                    if (r = e.__k)
                        for (o = 0; o < r.length; o++) r[o] && rc(r[o], t, n || "function" != typeof e.type);
                    n || null == e.__e || Fa(e.__e), e.__ = e.__e = e.__d = void 0
                }

                function oc(e, t, n) {
                    return this.constructor(e, n)
                }
                Ca = Na.slice, xa = {
                    __e: function(e, t, n, r) {
                        for (var o, s, i; t = t.__;)
                            if ((o = t.__c) && !o.__) try {
                                if ((s = o.constructor) && null != s.getDerivedStateFromError && (o.setState(s.getDerivedStateFromError(e)), i = o.__d), null != o.componentDidCatch && (o.componentDidCatch(e, r || {}), i = o.__d), i) return o.__E = o
                            } catch (t) {
                                e = t
                            }
                        throw e
                    }
                }, Ta = 0, ja.prototype.setState = function(e, t) {
                    var n;
                    n = null != this.__s && this.__s !== this.state ? this.__s : this.__s = Oa({}, this.state), "function" == typeof e && (e = e(Oa({}, n), this.props)), e && Oa(n, e), null != e && this.__v && (t && this._sb.push(t), Wa(this))
                }, ja.prototype.forceUpdate = function(e) {
                    this.__v && (this.__e = !0, e && this.__h.push(e), Wa(this))
                }, ja.prototype.render = Ua, Ia = [], Ma = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, Ra = function(e, t) {
                    return e.__v.__b - t.__v.__b
                }, qa.__r = 0;
                var sc, ic, ac, cc, uc = 0,
                    lc = [],
                    dc = [],
                    pc = xa,
                    hc = pc.__b,
                    fc = pc.__r,
                    mc = pc.diffed,
                    gc = pc.__c,
                    _c = pc.unmount,
                    yc = pc.__;

                function vc(e, t) {
                    pc.__h && pc.__h(ic, e, uc || t), uc = 0;
                    var n = ic.__H || (ic.__H = {
                        __: [],
                        __h: []
                    });
                    return e >= n.__.length && n.__.push({
                        __V: dc
                    }), n.__[e]
                }

                function bc(e) {
                    return uc = 1, Sc(Ac, e)
                }

                function Sc(e, t, n) {
                    var r = vc(sc++, 2);
                    if (r.t = e, !r.__c && (r.__ = [n ? n(t) : Ac(void 0, t), function(e) {
                            var t = r.__N ? r.__N[0] : r.__[0],
                                n = r.t(t, e);
                            t !== n && (r.__N = [n, r.__[1]], r.__c.setState({}))
                        }], r.__c = ic, !ic.u)) {
                        var o = function(e, t, n) {
                            if (!r.__c.__H) return !0;
                            var o = r.__c.__H.__.filter((function(e) {
                                return !!e.__c
                            }));
                            if (o.every((function(e) {
                                    return !e.__N
                                }))) return !s || s.call(this, e, t, n);
                            var i = !1;
                            return o.forEach((function(e) {
                                if (e.__N) {
                                    var t = e.__[0];
                                    e.__ = e.__N, e.__N = void 0, t !== e.__[0] && (i = !0)
                                }
                            })), !(!i && r.__c.props === e) && (!s || s.call(this, e, t, n))
                        };
                        ic.u = !0;
                        var s = ic.shouldComponentUpdate,
                            i = ic.componentWillUpdate;
                        ic.componentWillUpdate = function(e, t, n) {
                            if (this.__e) {
                                var r = s;
                                s = void 0, o(e, t, n), s = r
                            }
                            i && i.call(this, e, t, n)
                        }, ic.shouldComponentUpdate = o
                    }
                    return r.__N || r.__
                }

                function wc(e, t) {
                    var n = vc(sc++, 4);
                    !pc.__s && Rc(n.__H, t) && (n.__ = e, n.i = t, ic.__h.push(n))
                }

                function kc(e, t) {
                    var n = vc(sc++, 7);
                    return Rc(n.__H, t) ? (n.__V = e(), n.i = t, n.__h = e, n.__V) : n.__
                }

                function Cc(e, t) {
                    return uc = 8, kc((function() {
                        return e
                    }), t)
                }

                function xc() {
                    for (var e; e = lc.shift();)
                        if (e.__P && e.__H) try {
                            e.__H.__h.forEach(Ec), e.__H.__h.forEach(Mc), e.__H.__h = []
                        } catch (t) {
                            e.__H.__h = [], pc.__e(t, e.__v)
                        }
                }
                pc.__b = function(e) {
                    ic = null, hc && hc(e)
                }, pc.__ = function(e, t) {
                    t.__k && t.__k.__m && (e.__m = t.__k.__m), yc && yc(e, t)
                }, pc.__r = function(e) {
                    fc && fc(e), sc = 0;
                    var t = (ic = e.__c).__H;
                    t && (ac === ic ? (t.__h = [], ic.__h = [], t.__.forEach((function(e) {
                        e.__N && (e.__ = e.__N), e.__V = dc, e.__N = e.i = void 0
                    }))) : (t.__h.forEach(Ec), t.__h.forEach(Mc), t.__h = [], sc = 0)), ac = ic
                }, pc.diffed = function(e) {
                    mc && mc(e);
                    var t = e.__c;
                    t && t.__H && (t.__H.__h.length && (1 !== lc.push(t) && cc === pc.requestAnimationFrame || ((cc = pc.requestAnimationFrame) || Ic)(xc)), t.__H.__.forEach((function(e) {
                        e.i && (e.__H = e.i), e.__V !== dc && (e.__ = e.__V), e.i = void 0, e.__V = dc
                    }))), ac = ic = null
                }, pc.__c = function(e, t) {
                    t.some((function(e) {
                        try {
                            e.__h.forEach(Ec), e.__h = e.__h.filter((function(e) {
                                return !e.__ || Mc(e)
                            }))
                        } catch (n) {
                            t.some((function(e) {
                                e.__h && (e.__h = [])
                            })), t = [], pc.__e(n, e.__v)
                        }
                    })), gc && gc(e, t)
                }, pc.unmount = function(e) {
                    _c && _c(e);
                    var t, n = e.__c;
                    n && n.__H && (n.__H.__.forEach((function(e) {
                        try {
                            Ec(e)
                        } catch (e) {
                            t = e
                        }
                    })), n.__H = void 0, t && pc.__e(t, n.__v))
                };
                var Tc = "function" == typeof requestAnimationFrame;

                function Ic(e) {
                    var t, n = function() {
                            clearTimeout(r), Tc && cancelAnimationFrame(t), setTimeout(e)
                        },
                        r = setTimeout(n, 100);
                    Tc && (t = requestAnimationFrame(n))
                }

                function Ec(e) {
                    var t = ic,
                        n = e.__c;
                    "function" == typeof n && (e.__c = void 0, n()), ic = t
                }

                function Mc(e) {
                    var t = ic;
                    e.__c = e.__(), ic = t
                }

                function Rc(e, t) {
                    return !e || e.length !== t.length || t.some((function(t, n) {
                        return t !== e[n]
                    }))
                }

                function Ac(e, t) {
                    return "function" == typeof t ? t(e) : t
                }
                const Nc = {
                    __proto__: null,
                    useCallback: Cc,
                    useContext: function(e) {
                        var t = ic.context[e.__c],
                            n = vc(sc++, 9);
                        return n.c = e, t ? (null == n.__ && (n.__ = !0, t.sub(ic)), t.props.value) : e.__
                    },
                    useDebugValue: function(e, t) {
                        pc.useDebugValue && pc.useDebugValue(t ? t(e) : e)
                    },
                    useEffect: function(e, t) {
                        var n = vc(sc++, 3);
                        !pc.__s && Rc(n.__H, t) && (n.__ = e, n.i = t, ic.__H.__h.push(n))
                    },
                    useErrorBoundary: function(e) {
                        var t = vc(sc++, 10),
                            n = bc();
                        return t.__ = e, ic.componentDidCatch || (ic.componentDidCatch = function(e, r) {
                            t.__ && t.__(e, r), n[1](e)
                        }), [n[0], function() {
                            n[1](void 0)
                        }]
                    },
                    useId: function() {
                        var e = vc(sc++, 11);
                        if (!e.__) {
                            for (var t = ic.__v; null !== t && !t.__m && null !== t.__;) t = t.__;
                            var n = t.__m || (t.__m = [0, 0]);
                            e.__ = "P" + n[0] + "-" + n[1]++
                        }
                        return e.__
                    },
                    useImperativeHandle: function(e, t, n) {
                        uc = 6, wc((function() {
                            return "function" == typeof e ? (e(t()), function() {
                                return e(null)
                            }) : e ? (e.current = t(), function() {
                                return e.current = null
                            }) : void 0
                        }), null == n ? n : n.concat(e))
                    },
                    useLayoutEffect: wc,
                    useMemo: kc,
                    useReducer: Sc,
                    useRef: function(e) {
                        return uc = 5, kc((function() {
                            return {
                                current: e
                            }
                        }), [])
                    },
                    useState: bc
                };

                function Lc() {
                    const e = e => da.createElementNS("http://www.w3.org/2000/svg", e),
                        t = ga(e("svg"), {
                            width: "32",
                            height: "30",
                            viewBox: "0 0 72 66",
                            fill: "inherit"
                        }),
                        n = ga(e("path"), {
                            transform: "translate(11, 11)",
                            d: "M29,2.26a4.67,4.67,0,0,0-8,0L14.42,13.53A32.21,32.21,0,0,1,32.17,40.19H27.55A27.68,27.68,0,0,0,12.09,17.47L6,28a15.92,15.92,0,0,1,9.23,12.17H4.62A.76.76,0,0,1,4,39.06l2.94-5a10.74,10.74,0,0,0-3.36-1.9l-2.91,5a4.54,4.54,0,0,0,1.69,6.24A4.66,4.66,0,0,0,4.62,44H19.15a19.4,19.4,0,0,0-8-17.31l2.31-4A23.87,23.87,0,0,1,23.76,44H36.07a35.88,35.88,0,0,0-16.41-31.8l4.67-8a.77.77,0,0,1,1.05-.27c.53.29,20.29,34.77,20.66,35.17a.76.76,0,0,1-.68,1.13H40.6q.09,1.91,0,3.81h4.78A4.59,4.59,0,0,0,50,39.43a4.49,4.49,0,0,0-.62-2.28Z"
                        });
                    return t.appendChild(n), t
                }
                const Dc = "/home/runner/work/sentry-javascript/sentry-javascript/packages/feedback/src/modal/components/DialogHeader.tsx";

                function Oc({
                    options: e
                }) {
                    const t = kc((() => ({
                        __html: Lc().outerHTML
                    })), []);
                    return Pa("h2", {
                        class: "dialog__header",
                        __self: this,
                        __source: {
                            fileName: Dc,
                            lineNumber: 16
                        }
                    }, e.formTitle, e.showBranding ? Pa("a", {
                        class: "brand-link",
                        target: "_blank",
                        href: "https://sentry.io/welcome/",
                        title: "Powered by Sentry",
                        rel: "noopener noreferrer",
                        dangerouslySetInnerHTML: t,
                        __self: this,
                        __source: {
                            fileName: Dc,
                            lineNumber: 19
                        }
                    }) : null)
                }
                const Fc = "/home/runner/work/sentry-javascript/sentry-javascript/packages/feedback/src/modal/components/Form.tsx";

                function Pc(e, t) {
                    const n = e.get(t);
                    return "string" == typeof n ? n.trim() : ""
                }

                function Bc({
                    options: e,
                    defaultEmail: t,
                    defaultName: n,
                    onFormClose: r,
                    onSubmit: o,
                    onSubmitSuccess: s,
                    onSubmitError: i,
                    showEmail: a,
                    showName: c,
                    screenshotInput: u
                }) {
                    const {
                        tags: l,
                        addScreenshotButtonLabel: d,
                        removeScreenshotButtonLabel: p,
                        cancelButtonLabel: h,
                        emailLabel: f,
                        emailPlaceholder: m,
                        isEmailRequired: g,
                        isNameRequired: _,
                        messageLabel: y,
                        messagePlaceholder: v,
                        nameLabel: b,
                        namePlaceholder: S,
                        submitButtonLabel: w,
                        isRequiredLabel: k
                    } = e, [C, x] = bc(null), [T, I] = bc(!1), E = u && u.input, [M, R] = bc(null), A = Cc((e => {
                        R(e), I(!1)
                    }), []), N = Cc((e => {
                        const t = function(e, t) {
                            const n = [];
                            return t.isNameRequired && !e.name && n.push(t.nameLabel), t.isEmailRequired && !e.email && n.push(t.emailLabel), e.message || n.push(t.messageLabel), n
                        }(e, {
                            emailLabel: f,
                            isEmailRequired: g,
                            isNameRequired: _,
                            messageLabel: y,
                            nameLabel: b
                        });
                        return t.length > 0 ? x(`Please enter in the following required fields: ${t.join(", ")}`) : x(null), 0 === t.length
                    }), [f, g, _, y, b]), L = Cc((async e => {
                        try {
                            if (e.preventDefault(), !(e.target instanceof HTMLFormElement)) return;
                            const t = new FormData(e.target),
                                n = await (u && T ? u.value() : void 0),
                                r = {
                                    name: Pc(t, "name"),
                                    email: Pc(t, "email"),
                                    message: Pc(t, "message"),
                                    attachments: n ? [n] : void 0
                                };
                            if (!N(r)) return;
                            try {
                                await o({
                                    name: r.name,
                                    email: r.email,
                                    message: r.message,
                                    source: "widget",
                                    tags: l
                                }, {
                                    attachments: r.attachments
                                }), s(r)
                            } catch (e) {
                                x(e), i(e)
                            }
                        } catch (e) {}
                    }), [u && T, s, i]);
                    return Pa("form", {
                        class: "form",
                        onSubmit: L,
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 144
                        }
                    }, E && T ? Pa(E, {
                        onError: A,
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 146
                        }
                    }) : null, Pa("div", {
                        class: "form__right",
                        "data-sentry-feedback": !0,
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 149
                        }
                    }, Pa("div", {
                        class: "form__top",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 150
                        }
                    }, C ? Pa("div", {
                        class: "form__error-container",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 151
                        }
                    }, C) : null, c ? Pa("label", {
                        for: "name",
                        class: "form__label",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 154
                        }
                    }, Pa(Uc, {
                        label: b,
                        isRequiredLabel: k,
                        isRequired: _,
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 155
                        }
                    }), Pa("input", {
                        class: "form__input",
                        defaultValue: n,
                        id: "name",
                        name: "name",
                        placeholder: S,
                        required: _,
                        type: "text",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 156
                        }
                    })) : Pa("input", {
                        "aria-hidden": !0,
                        value: n,
                        name: "name",
                        type: "hidden",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 167
                        }
                    }), a ? Pa("label", {
                        for: "email",
                        class: "form__label",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 171
                        }
                    }, Pa(Uc, {
                        label: f,
                        isRequiredLabel: k,
                        isRequired: g,
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 172
                        }
                    }), Pa("input", {
                        class: "form__input",
                        defaultValue: t,
                        id: "email",
                        name: "email",
                        placeholder: m,
                        required: g,
                        type: "email",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 173
                        }
                    })) : Pa("input", {
                        "aria-hidden": !0,
                        value: t,
                        name: "email",
                        type: "hidden",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 184
                        }
                    }), Pa("label", {
                        for: "message",
                        class: "form__label",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 187
                        }
                    }, Pa(Uc, {
                        label: y,
                        isRequiredLabel: k,
                        isRequired: !0,
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 188
                        }
                    }), Pa("textarea", {
                        autoFocus: !0,
                        class: "form__input form__input--textarea",
                        id: "message",
                        name: "message",
                        placeholder: v,
                        required: !0,
                        rows: 5,
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 189
                        }
                    })), E ? Pa("label", {
                        for: "screenshot",
                        class: "form__label",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 201
                        }
                    }, Pa("button", {
                        class: "btn btn--default",
                        type: "button",
                        onClick: () => {
                            R(null), I((e => !e))
                        },
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 202
                        }
                    }, T ? p : d), M ? Pa("div", {
                        class: "form__error-container",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 212
                        }
                    }, M.message) : null) : null), Pa("div", {
                        class: "btn-group",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 216
                        }
                    }, Pa("button", {
                        class: "btn btn--primary",
                        type: "submit",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 217
                        }
                    }, w), Pa("button", {
                        class: "btn btn--default",
                        type: "button",
                        onClick: r,
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 220
                        }
                    }, h))))
                }

                function Uc({
                    label: e,
                    isRequired: t,
                    isRequiredLabel: n
                }) {
                    return Pa("span", {
                        class: "form__label__text",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 239
                        }
                    }, e, t && Pa("span", {
                        class: "form__label__text--required",
                        __self: this,
                        __source: {
                            fileName: Fc,
                            lineNumber: 241
                        }
                    }, n))
                }

                function jc() {
                    const e = e => la.document.createElementNS("http://www.w3.org/2000/svg", e),
                        t = ga(e("svg"), {
                            width: "16",
                            height: "17",
                            viewBox: "0 0 16 17",
                            fill: "inherit"
                        }),
                        n = ga(e("g"), {
                            clipPath: "url(#clip0_57_156)"
                        }),
                        r = ga(e("path"), {
                            "fill-rule": "evenodd",
                            "clip-rule": "evenodd",
                            d: "M3.55544 15.1518C4.87103 16.0308 6.41775 16.5 8 16.5C10.1217 16.5 12.1566 15.6571 13.6569 14.1569C15.1571 12.6566 16 10.6217 16 8.5C16 6.91775 15.5308 5.37103 14.6518 4.05544C13.7727 2.73985 12.5233 1.71447 11.0615 1.10897C9.59966 0.503466 7.99113 0.34504 6.43928 0.653721C4.88743 0.962403 3.46197 1.72433 2.34315 2.84315C1.22433 3.96197 0.462403 5.38743 0.153721 6.93928C-0.15496 8.49113 0.00346625 10.0997 0.608967 11.5615C1.21447 13.0233 2.23985 14.2727 3.55544 15.1518ZM4.40546 3.1204C5.46945 2.40946 6.72036 2.03 8 2.03C9.71595 2.03 11.3616 2.71166 12.575 3.92502C13.7883 5.13838 14.47 6.78405 14.47 8.5C14.47 9.77965 14.0905 11.0306 13.3796 12.0945C12.6687 13.1585 11.6582 13.9878 10.476 14.4775C9.29373 14.9672 7.99283 15.0953 6.73777 14.8457C5.48271 14.596 4.32987 13.9798 3.42502 13.075C2.52018 12.1701 1.90397 11.0173 1.65432 9.76224C1.40468 8.50718 1.5328 7.20628 2.0225 6.02404C2.5122 4.8418 3.34148 3.83133 4.40546 3.1204Z"
                        }),
                        o = ga(e("path"), {
                            d: "M6.68775 12.4297C6.78586 12.4745 6.89218 12.4984 7 12.5C7.11275 12.4955 7.22315 12.4664 7.32337 12.4145C7.4236 12.3627 7.51121 12.2894 7.58 12.2L12 5.63999C12.0848 5.47724 12.1071 5.28902 12.0625 5.11098C12.0178 4.93294 11.9095 4.77744 11.7579 4.67392C11.6064 4.57041 11.4221 4.52608 11.24 4.54931C11.0579 4.57254 10.8907 4.66173 10.77 4.79999L6.88 10.57L5.13 8.56999C5.06508 8.49566 4.98613 8.43488 4.89768 8.39111C4.80922 8.34735 4.713 8.32148 4.61453 8.31498C4.51605 8.30847 4.41727 8.32147 4.32382 8.35322C4.23038 8.38497 4.14413 8.43484 4.07 8.49999C3.92511 8.63217 3.83692 8.81523 3.82387 9.01092C3.81083 9.2066 3.87393 9.39976 4 9.54999L6.43 12.24C6.50187 12.3204 6.58964 12.385 6.68775 12.4297Z"
                        });
                    t.appendChild(n).append(o, r);
                    const s = e("defs"),
                        i = ga(e("clipPath"), {
                            id: "clip0_57_156"
                        }),
                        a = ga(e("rect"), {
                            width: "16",
                            height: "16",
                            fill: "white",
                            transform: "translate(0 0.5)"
                        });
                    return i.appendChild(a), s.appendChild(i), t.appendChild(s).appendChild(i).appendChild(a), t
                }
                const zc = "/home/runner/work/sentry-javascript/sentry-javascript/packages/feedback/src/modal/components/Dialog.tsx";

                function Hc({
                    open: e,
                    onFormSubmitted: t,
                    ...n
                }) {
                    const r = n.options,
                        o = kc((() => ({
                            __html: jc().outerHTML
                        })), []),
                        [s, i] = bc(null),
                        a = Cc((() => {
                            s && (clearTimeout(s), i(null)), t()
                        }), [s]),
                        c = Cc((e => {
                            n.onSubmitSuccess(e), i(setTimeout((() => {
                                t(), i(null)
                            }), 5e3))
                        }), [t]);
                    return Pa(Ua, {
                        __self: this,
                        __source: {
                            fileName: zc,
                            lineNumber: 48
                        }
                    }, s ? Pa("div", {
                        class: "success__position",
                        onClick: a,
                        __self: this,
                        __source: {
                            fileName: zc,
                            lineNumber: 50
                        }
                    }, Pa("div", {
                        class: "success__content",
                        __self: this,
                        __source: {
                            fileName: zc,
                            lineNumber: 51
                        }
                    }, r.successMessageText, Pa("span", {
                        class: "success__icon",
                        dangerouslySetInnerHTML: o,
                        __self: this,
                        __source: {
                            fileName: zc,
                            lineNumber: 53
                        }
                    }))) : Pa("dialog", {
                        class: "dialog",
                        onClick: r.onFormClose,
                        open: e,
                        __self: this,
                        __source: {
                            fileName: zc,
                            lineNumber: 57
                        }
                    }, Pa("div", {
                        class: "dialog__position",
                        __self: this,
                        __source: {
                            fileName: zc,
                            lineNumber: 58
                        }
                    }, Pa("div", {
                        class: "dialog__content",
                        onClick: e => {
                            e.stopPropagation()
                        },
                        __self: this,
                        __source: {
                            fileName: zc,
                            lineNumber: 59
                        }
                    }, Pa(Oc, {
                        options: r,
                        __self: this,
                        __source: {
                            fileName: zc,
                            lineNumber: 66
                        }
                    }), Pa(Bc, { ...n,
                        onSubmitSuccess: c,
                        __self: this,
                        __source: {
                            fileName: zc,
                            lineNumber: 67
                        }
                    })))))
                }
                const $c = () => ({
                    name: "FeedbackModal",
                    setupOnce() {},
                    createDialog: ({
                        options: e,
                        screenshotIntegration: t,
                        sendFeedback: n,
                        shadow: r
                    }) => {
                        const o = r,
                            s = e.useSentryUser,
                            i = function() {
                                const e = (0, C.o5)().getUser(),
                                    t = (0, C.rm)().getUser(),
                                    n = (0, C.m6)().getUser();
                                return e && Object.keys(e).length ? e : t && Object.keys(t).length ? t : n
                            }(),
                            a = da.createElement("div"),
                            c = function() {
                                const e = da.createElement("style");
                                return e.textContent = "\n:host {\n  --dialog-inset: var(--inset);\n}\n\n\n.dialog {\n  position: fixed;\n  z-index: var(--z-index);\n  margin: 0;\n  inset: 0;\n\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 0;\n  height: 100vh;\n  width: 100vw;\n\n  color: var(--dialog-color, var(--foreground));\n  fill: var(--dialog-color, var(--foreground));\n  line-height: 1.75em;\n\n  background-color: rgba(0, 0, 0, 0.05);\n  border: none;\n  inset: 0;\n  opacity: 1;\n  transition: opacity 0.2s ease-in-out;\n}\n\n.dialog__position {\n  position: fixed;\n  z-index: var(--z-index);\n  inset: var(--dialog-inset);\n  padding: var(--page-margin);\n  display: flex;\n  max-height: calc(100vh - (2 * var(--page-margin)));\n}\n@media (max-width: 600px) {\n  .dialog__position {\n    inset: var(--page-margin);\n    padding: 0;\n  }\n}\n\n.dialog__position:has(.editor) {\n  inset: var(--page-margin);\n  padding: 0;\n}\n\n.dialog:not([open]) {\n  opacity: 0;\n  pointer-events: none;\n  visibility: hidden;\n}\n.dialog:not([open]) .dialog__content {\n  transform: translate(0, -16px) scale(0.98);\n}\n\n.dialog__content {\n  display: flex;\n  flex-direction: column;\n  gap: 16px;\n  padding: var(--dialog-padding, 24px);\n  max-width: 100%;\n  width: 100%;\n  max-height: 100%;\n  overflow: auto;\n\n  background: var(--dialog-background, var(--background));\n  border-radius: var(--dialog-border-radius, 20px);\n  border: var(--dialog-border, var(--border));\n  box-shadow: var(--dialog-box-shadow, var(--box-shadow));\n  transform: translate(0, 0) scale(1);\n  transition: transform 0.2s ease-in-out;\n}\n\n\n.dialog__header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  font-weight: var(--dialog-header-weight, 600);\n  margin: 0;\n}\n\n.brand-link {\n  display: inline-flex;\n}\n.brand-link:focus-visible {\n  outline: var(--outline);\n}\n\n\n.form {\n  display: flex;\n  overflow: auto;\n  flex-direction: row;\n  gap: 16px;\n  flex: 1 0;\n}\n\n.form__right {\n  flex: 0 0 var(--form-width, 272px);\n  width: var(--form-width, 272px);\n  display: flex;\n  overflow: auto;\n  flex-direction: column;\n  justify-content: space-between;\n  gap: 20px;\n}\n\n@media (max-width: 600px) {\n  .form__right {\n    width: auto;\n  }\n}\n\n.form__top {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n\n.form__error-container {\n  color: var(--error-color);\n  fill: var(--error-color);\n}\n\n.form__label {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  margin: 0px;\n}\n\n.form__label__text {\n  display: flex;\n  gap: 4px;\n  align-items: center;\n}\n\n.form__label__text--required {\n  font-size: 0.85em;\n}\n\n.form__input {\n  font-family: inherit;\n  line-height: inherit;\n  background: transparent;\n  box-sizing: border-box;\n  border: var(--input-border, var(--border));\n  border-radius: var(--input-border-radius, 6px);\n  color: var(--input-color, inherit);\n  fill: var(--input-color, inherit);\n  font-size: var(--input-font-size, inherit);\n  font-weight: var(--input-font-weight, 500);\n  padding: 6px 12px;\n}\n\n.form__input::placeholder {\n  opacity: 0.65;\n  color: var(--input-placeholder-color, inherit);\n  filter: var(--interactive-filter);\n}\n\n.form__input:focus-visible {\n  outline: var(--input-focus-outline, var(--outline));\n}\n\n.form__input--textarea {\n  font-family: inherit;\n  resize: vertical;\n}\n\n.error {\n  color: var(--error-color);\n  fill: var(--error-color);\n}\n\n\n.btn-group {\n  display: grid;\n  gap: 8px;\n}\n\n.btn {\n  line-height: inherit;\n  border: var(--button-border, var(--border));\n  border-radius: var(--button-border-radius, 6px);\n  cursor: pointer;\n  font-family: inherit;\n  font-size: var(--button-font-size, inherit);\n  font-weight: var(--button-font-weight, 600);\n  padding: var(--button-padding, 6px 16px);\n}\n.btn[disabled] {\n  opacity: 0.6;\n  pointer-events: none;\n}\n\n.btn--primary {\n  color: var(--button-primary-color, var(--accent-foreground));\n  fill: var(--button-primary-color, var(--accent-foreground));\n  background: var(--button-primary-background, var(--accent-background));\n  border: var(--button-primary-border, var(--border));\n  border-radius: var(--button-primary-border-radius, 6px);\n  font-weight: var(--button-primary-font-weight, 500);\n}\n.btn--primary:hover {\n  color: var(--button-primary-hover-color, var(--accent-foreground));\n  fill: var(--button-primary-hover-color, var(--accent-foreground));\n  background: var(--button-primary-hover-background, var(--accent-background));\n  filter: var(--interactive-filter);\n}\n.btn--primary:focus-visible {\n  background: var(--button-primary-hover-background, var(--accent-background));\n  filter: var(--interactive-filter);\n  outline: var(--button-primary-focus-outline, var(--outline));\n}\n\n.btn--default {\n  color: var(--button-color, var(--foreground));\n  fill: var(--button-color, var(--foreground));\n  background: var(--button-background, var(--background));\n  border: var(--button-border, var(--border));\n  border-radius: var(--button-border-radius, 6px);\n  font-weight: var(--button-font-weight, 500);\n}\n.btn--default:hover {\n  color: var(--button-color, var(--foreground));\n  fill: var(--button-color, var(--foreground));\n  background: var(--button-hover-background, var(--background));\n  filter: var(--interactive-filter);\n}\n.btn--default:focus-visible {\n  background: var(--button-hover-background, var(--background));\n  filter: var(--interactive-filter);\n  outline: var(--button-focus-outline, var(--outline));\n}\n\n\n.success__position {\n  position: fixed;\n  inset: var(--dialog-inset);\n  padding: var(--page-margin);\n  z-index: var(--z-index);\n}\n.success__content {\n  background: var(--success-background, var(--background));\n  border: var(--success-border, var(--border));\n  border-radius: var(--success-border-radius, 1.7em/50%);\n  box-shadow: var(--success-box-shadow, var(--box-shadow));\n  font-weight: var(--success-font-weight, 600);\n  color: var(--success-color);\n  fill: var(--success-color);\n  padding: 12px 24px;\n  line-height: 1.75em;\n\n  display: grid;\n  align-items: center;\n  grid-auto-flow: column;\n  gap: 6px;\n  cursor: default;\n}\n\n.success__icon {\n  display: flex;\n}\n\n", e
                            }();
                        let u = "";
                        const l = {
                                get el() {
                                    return a
                                },
                                appendToDom() {
                                    o.contains(c) || o.contains(a) || (o.appendChild(c), o.appendChild(a))
                                },
                                removeFromDom() {
                                    o.removeChild(a), o.removeChild(c), da.body.style.overflow = u
                                },
                                open() {
                                    p(!0), e.onFormOpen && e.onFormOpen(), u = da.body.style.overflow, da.body.style.overflow = "hidden"
                                },
                                close() {
                                    p(!1), da.body.style.overflow = u
                                }
                            },
                            d = t && t.createInput({
                                h: Pa,
                                hooks: Nc,
                                dialog: l,
                                options: e
                            }),
                            p = t => {
                                ! function(e, t, n) {
                                    var r, o, s, i;
                                    xa.__ && xa.__(e, t), o = (r = "function" == typeof n) ? null : n && n.__k || t.__k, s = [], i = [], Za(t, e = (!r && n || t).__k = Pa(Ua, null, [e]), o || Aa, Aa, void 0 !== t.ownerSVGElement, !r && n ? [n] : o ? null : t.firstChild ? Ca.call(t.childNodes) : null, s, !r && n ? n : o ? o.__e : t.firstChild, r, i), e.__d = void 0, ec(s, e, i)
                                }(Pa(Hc, {
                                    options: e,
                                    screenshotInput: d,
                                    showName: e.showName || e.isNameRequired,
                                    showEmail: e.showEmail || e.isEmailRequired,
                                    defaultName: s && i && i[s.name] || "",
                                    defaultEmail: s && i && i[s.email] || "",
                                    onFormClose: () => {
                                        p(!1), e.onFormClose && e.onFormClose()
                                    },
                                    onSubmit: n,
                                    onSubmitSuccess: t => {
                                        p(!1), e.onSubmitSuccess && e.onSubmitSuccess(t)
                                    },
                                    onSubmitError: t => {
                                        e.onSubmitError && e.onSubmitError(t)
                                    },
                                    onFormSubmitted: () => {
                                        e.onFormSubmitted && e.onFormSubmitted()
                                    },
                                    open: t,
                                    __self: void 0,
                                    __source: {
                                        fileName: "/home/runner/work/sentry-javascript/sentry-javascript/packages/feedback/src/modal/integration.tsx",
                                        lineNumber: 67
                                    }
                                }), a)
                            };
                        return l
                    }
                });

                function Wc() {
                    const e = da.createElement("style"),
                        t = "#1A141F",
                        n = "#302735";
                    return e.textContent = `\n.editor {\n  padding: 10px;\n  padding-top: 65px;\n  padding-bottom: 65px;\n  flex-grow: 1;\n\n  background-color: ${t};\n  background-image: repeating-linear-gradient(\n      -145deg,\n      transparent,\n      transparent 8px,\n      ${t} 8px,\n      ${t} 11px\n    ),\n    repeating-linear-gradient(\n      -45deg,\n      transparent,\n      transparent 15px,\n      ${n} 15px,\n      ${n} 16px\n    );\n}\n\n.editor__canvas-container {\n  width: 100%;\n  height: 100%;\n  position: relative;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.editor__canvas-container canvas {\n  object-fit: contain;\n  position: relative;\n}\n\n.editor__crop-btn-group {\n  padding: 8px;\n  gap: 8px;\n  border-radius: var(--menu-border-radius, 6px);\n  background: var(--button-primary-background, var(--background));\n  width: 175px;\n  position: absolute;\n}\n\n.editor__crop-corner {\n  width: 30px;\n  height: 30px;\n  position: absolute;\n  background: none;\n  border: 3px solid #ffffff;\n}\n\n.editor__crop-corner--top-left {\n  cursor: nwse-resize;\n  border-right: none;\n  border-bottom: none;\n}\n.editor__crop-corner--top-right {\n  cursor: nesw-resize;\n  border-left: none;\n  border-bottom: none;\n}\n.editor__crop-corner--bottom-left {\n  cursor: nesw-resize;\n  border-right: none;\n  border-top: none;\n}\n.editor__crop-corner--bottom-right {\n  cursor: nwse-resize;\n  border-left: none;\n  border-top: none;\n}\n`, e
                }
                const qc = "/home/runner/work/sentry-javascript/sentry-javascript/packages/feedback/src/screenshot/components/ScreenshotEditor.tsx",
                    Jc = 33,
                    Kc = la.devicePixelRatio,
                    Vc = e => ({
                        x: Math.min(e.startX, e.endX),
                        y: Math.min(e.startY, e.endY),
                        width: Math.abs(e.startX - e.endX),
                        height: Math.abs(e.startY - e.endY)
                    }),
                    Xc = e => {
                        const t = e.clientHeight,
                            n = e.clientWidth,
                            r = e.width / e.height;
                        let o = t * r,
                            s = t;
                        o > n && (o = n, s = n / r);
                        const i = (n - o) / 2,
                            a = (t - s) / 2;
                        return {
                            startX: i,
                            startY: a,
                            endX: o + i,
                            endY: s + a
                        }
                    };

                function Yc({
                    h: e,
                    hooks: t,
                    imageBuffer: n,
                    dialog: r,
                    options: o
                }) {
                    const s = function({
                        hooks: e
                    }) {
                        return function({
                            onBeforeScreenshot: t,
                            onScreenshot: n,
                            onAfterScreenshot: r,
                            onError: o
                        }) {
                            e.useEffect((() => {
                                (async () => {
                                    t();
                                    const e = await pa.mediaDevices.getDisplayMedia({
                                            video: {
                                                width: la.innerWidth * la.devicePixelRatio,
                                                height: la.innerHeight * la.devicePixelRatio
                                            },
                                            audio: !1,
                                            monitorTypeSurfaces: "exclude",
                                            preferCurrentTab: !0,
                                            selfBrowserSurface: "include",
                                            surfaceSwitching: "exclude"
                                        }),
                                        o = da.createElement("video");
                                    await new Promise(((t, r) => {
                                        o.srcObject = e, o.onloadedmetadata = () => {
                                            n(o), e.getTracks().forEach((e => e.stop())), t()
                                        }, o.play().catch(r)
                                    })), r()
                                })().catch(o)
                            }), [])
                        }
                    }({
                        hooks: t
                    });
                    return function({
                        onError: i
                    }) {
                        const a = t.useMemo((() => ({
                                __html: Wc().innerText
                            })), []),
                            c = function({
                                h: e
                            }) {
                                return function({
                                    top: t,
                                    left: n,
                                    corner: r,
                                    onGrabButton: o
                                }) {
                                    return e("button", {
                                        class: `editor__crop-corner editor__crop-corner--${r} `,
                                        style: {
                                            top: t,
                                            left: n
                                        },
                                        onMouseDown: e => {
                                            e.preventDefault(), o(e, r)
                                        },
                                        onClick: e => {
                                            e.preventDefault()
                                        },
                                        __self: this,
                                        __source: {
                                            fileName: "/home/runner/work/sentry-javascript/sentry-javascript/packages/feedback/src/screenshot/components/CropCorner.tsx",
                                            lineNumber: 22
                                        }
                                    })
                                }
                            }({
                                h: e
                            }),
                            u = t.useRef(null),
                            l = t.useRef(null),
                            d = t.useRef(null),
                            [p, h] = t.useState({
                                startX: 0,
                                startY: 0,
                                endX: 0,
                                endY: 0
                            }),
                            [f, m] = t.useState(!1),
                            [g, _] = t.useState(!1);

                        function y() {
                            const e = d.current,
                                t = Vc(Xc(n));
                            if (e) {
                                e.width = t.width * Kc, e.height = t.height * Kc, e.style.width = `${t.width}px`, e.style.height = `${t.height}px`;
                                const n = e.getContext("2d");
                                n && n.scale(Kc, Kc)
                            }
                            const r = l.current;
                            r && (r.style.width = `${t.width}px`, r.style.height = `${t.height}px`), h({
                                startX: 0,
                                startY: 0,
                                endX: t.width,
                                endY: t.height
                            })
                        }

                        function v(e, t) {
                            m(!1), _(!0);
                            const n = b(t),
                                r = () => {
                                    da.removeEventListener("mousemove", n), da.removeEventListener("mouseup", r), m(!0), _(!1)
                                };
                            da.addEventListener("mouseup", r), da.addEventListener("mousemove", n)
                        }
                        t.useEffect((() => {
                            la.addEventListener("resize", y, !1)
                        }), []), t.useEffect((() => {
                            const e = d.current;
                            if (!e) return;
                            const t = e.getContext("2d");
                            if (!t) return;
                            const r = Vc(Xc(n)),
                                o = Vc(p);
                            t.clearRect(0, 0, r.width, r.height), t.fillStyle = "rgba(0, 0, 0, 0.5)", t.fillRect(0, 0, r.width, r.height), t.clearRect(o.x, o.y, o.width, o.height), t.strokeStyle = "#ffffff", t.lineWidth = 3, t.strokeRect(o.x + 1, o.y + 1, o.width - 2, o.height - 2), t.strokeStyle = "#000000", t.lineWidth = 1, t.strokeRect(o.x + 3, o.y + 3, o.width - 6, o.height - 6)
                        }), [p]);
                        const b = t.useCallback((e => function(t) {
                                if (!d.current) return;
                                const n = d.current,
                                    r = n.getBoundingClientRect(),
                                    o = t.clientX - r.x,
                                    s = t.clientY - r.y;
                                switch (e) {
                                    case "top-left":
                                        h((e => ({ ...e,
                                            startX: Math.min(Math.max(0, o), e.endX - Jc),
                                            startY: Math.min(Math.max(0, s), e.endY - Jc)
                                        })));
                                        break;
                                    case "top-right":
                                        h((e => ({ ...e,
                                            endX: Math.max(Math.min(o, n.width / Kc), e.startX + Jc),
                                            startY: Math.min(Math.max(0, s), e.endY - Jc)
                                        })));
                                        break;
                                    case "bottom-left":
                                        h((e => ({ ...e,
                                            startX: Math.min(Math.max(0, o), e.endX - Jc),
                                            endY: Math.max(Math.min(s, n.height / Kc), e.startY + Jc)
                                        })));
                                        break;
                                    case "bottom-right":
                                        h((e => ({ ...e,
                                            endX: Math.max(Math.min(o, n.width / Kc), e.startX + Jc),
                                            endY: Math.max(Math.min(s, n.height / Kc), e.startY + Jc)
                                        })))
                                }
                            }), []),
                            S = t.useRef({
                                initialX: 0,
                                initialY: 0
                            });
                        return s({
                            onBeforeScreenshot: t.useCallback((() => {
                                r.el.style.display = "none"
                            }), []),
                            onScreenshot: t.useCallback((e => {
                                const t = n.getContext("2d");
                                if (!t) throw new Error("Could not get canvas context");
                                n.width = e.videoWidth, n.height = e.videoHeight, n.style.width = "100%", n.style.height = "100%", t.drawImage(e, 0, 0)
                            }), [n]),
                            onAfterScreenshot: t.useCallback((() => {
                                r.el.style.display = "block";
                                const e = u.current;
                                e && e.appendChild(n), y()
                            }), []),
                            onError: t.useCallback((e => {
                                r.el.style.display = "block", i(e)
                            }), [])
                        }), e("div", {
                            class: "editor",
                            __self: this,
                            __source: {
                                fileName: qc,
                                lineNumber: 315
                            }
                        }, e("style", {
                            dangerouslySetInnerHTML: a,
                            __self: this,
                            __source: {
                                fileName: qc,
                                lineNumber: 316
                            }
                        }), e("div", {
                            class: "editor__canvas-container",
                            ref: u,
                            __self: this,
                            __source: {
                                fileName: qc,
                                lineNumber: 317
                            }
                        }, e("div", {
                            class: "editor__crop-container",
                            style: {
                                position: "absolute",
                                zIndex: 1
                            },
                            ref: l,
                            __self: this,
                            __source: {
                                fileName: qc,
                                lineNumber: 318
                            }
                        }, e("canvas", {
                            onMouseDown: function(e) {
                                if (g) return;
                                S.current = {
                                    initialX: e.clientX,
                                    initialY: e.clientY
                                };
                                const t = e => {
                                        const t = d.current;
                                        if (!t) return;
                                        const n = e.clientX - S.current.initialX,
                                            r = e.clientY - S.current.initialY;
                                        h((o => {
                                            const s = Math.max(0, Math.min(o.startX + n, t.width / Kc - (o.endX - o.startX))),
                                                i = Math.max(0, Math.min(o.startY + r, t.height / Kc - (o.endY - o.startY))),
                                                a = s + (o.endX - o.startX),
                                                c = i + (o.endY - o.startY);
                                            return S.current.initialX = e.clientX, S.current.initialY = e.clientY, {
                                                startX: s,
                                                startY: i,
                                                endX: a,
                                                endY: c
                                            }
                                        }))
                                    },
                                    n = () => {
                                        da.removeEventListener("mousemove", t), da.removeEventListener("mouseup", n)
                                    };
                                da.addEventListener("mousemove", t), da.addEventListener("mouseup", n)
                            },
                            style: {
                                position: "absolute",
                                cursor: f ? "move" : "auto"
                            },
                            ref: d,
                            __self: this,
                            __source: {
                                fileName: qc,
                                lineNumber: 319
                            }
                        }), e(c, {
                            left: p.startX - 3,
                            top: p.startY - 3,
                            onGrabButton: v,
                            corner: "top-left",
                            __self: this,
                            __source: {
                                fileName: qc,
                                lineNumber: 324
                            }
                        }), e(c, {
                            left: p.endX - 30 + 3,
                            top: p.startY - 3,
                            onGrabButton: v,
                            corner: "top-right",
                            __self: this,
                            __source: {
                                fileName: qc,
                                lineNumber: 330
                            }
                        }), e(c, {
                            left: p.startX - 3,
                            top: p.endY - 30 + 3,
                            onGrabButton: v,
                            corner: "bottom-left",
                            __self: this,
                            __source: {
                                fileName: qc,
                                lineNumber: 336
                            }
                        }), e(c, {
                            left: p.endX - 30 + 3,
                            top: p.endY - 30 + 3,
                            onGrabButton: v,
                            corner: "bottom-right",
                            __self: this,
                            __source: {
                                fileName: qc,
                                lineNumber: 342
                            }
                        }), e("div", {
                            style: {
                                left: Math.max(0, p.endX - 191),
                                top: Math.max(0, p.endY + 8),
                                display: f ? "flex" : "none"
                            },
                            class: "editor__crop-btn-group",
                            __self: this,
                            __source: {
                                fileName: qc,
                                lineNumber: 348
                            }
                        }, e("button", {
                            onClick: e => {
                                e.preventDefault(), d.current && h({
                                    startX: 0,
                                    startY: 0,
                                    endX: d.current.width / Kc,
                                    endY: d.current.height / Kc
                                }), m(!1)
                            },
                            class: "btn btn--default",
                            __self: this,
                            __source: {
                                fileName: qc,
                                lineNumber: 356
                            }
                        }, o.cancelButtonLabel), e("button", {
                            onClick: e => {
                                e.preventDefault(),
                                    function() {
                                        const e = da.createElement("canvas"),
                                            t = Vc(Xc(n)),
                                            r = Vc(p);
                                        e.width = r.width * Kc, e.height = r.height * Kc;
                                        const o = e.getContext("2d");
                                        o && n && o.drawImage(n, r.x / t.width * n.width, r.y / t.height * n.height, r.width / t.width * n.width, r.height / t.height * n.height, 0, 0, e.width, e.height);
                                        const s = n.getContext("2d");
                                        s && (s.clearRect(0, 0, n.width, n.height), n.width = e.width, n.height = e.height, n.style.width = `${r.width}px`, n.style.height = `${r.height}px`, s.drawImage(e, 0, 0), y())
                                    }(), m(!1)
                            },
                            class: "btn btn--primary",
                            __self: this,
                            __source: {
                                fileName: qc,
                                lineNumber: 373
                            }
                        }, o.confirmButtonLabel)))))
                    }
                }
                const Gc = () => ({
                        name: "FeedbackScreenshot",
                        setupOnce() {},
                        createInput: ({
                            h: e,
                            hooks: t,
                            dialog: n,
                            options: r
                        }) => {
                            const o = da.createElement("canvas");
                            return {
                                input: Yc({
                                    h: e,
                                    hooks: t,
                                    imageBuffer: o,
                                    dialog: n,
                                    options: r
                                }),
                                value: async () => {
                                    const e = await new Promise((e => {
                                        o.toBlob(e, "image/png")
                                    }));
                                    if (e) {
                                        return {
                                            data: new Uint8Array(await e.arrayBuffer()),
                                            filename: "screenshot.png",
                                            contentType: "application/png"
                                        }
                                    }
                                }
                            }
                        }
                    }),
                    Qc = wa({
                        lazyLoadIntegration: ot
                    }),
                    Zc = wa({
                        lazyLoadIntegration: ot,
                        getModalIntegration: () => $c,
                        getScreenshotIntegration: () => Gc
                    }),
                    eu = "c",
                    tu = "g",
                    nu = "s",
                    ru = "d";

                function ou(e, t) {
                    const n = (0, v.B)("globalMetricsAggregators", (() => new WeakMap)),
                        r = n.get(e);
                    if (r) return r;
                    const o = new t(e);
                    return e.on("flush", (() => o.flush())), e.on("close", (() => o.close())), n.set(e, o), o
                }

                function su(e, t, n, r, o = {}) {
                    const s = o.client || (0, C.KU)();
                    if (!s) return;
                    const i = (0, h.Bk)(),
                        a = i ? (0, h.zU)(i) : void 0,
                        c = a && (0, h.et)(a).description,
                        {
                            unit: u,
                            tags: l,
                            timestamp: f
                        } = o,
                        {
                            release: m,
                            environment: g
                        } = s.getOptions(),
                        _ = {};
                    m && (_.release = m), g && (_.environment = g), c && (_.transaction = c), p.T && d.vF.log(`Adding value of ${r} to ${t} metric ${n}`);
                    ou(s, e).add(t, n, r, u, { ..._,
                        ...l
                    }, f)
                }

                function iu(e, t, n, r) {
                    su(e, "d", t, cu(n), r)
                }
                const au = {
                    increment: function(e, t, n = 1, r) {
                        su(e, "c", t, cu(n), r)
                    },
                    distribution: iu,
                    set: function(e, t, n, r) {
                        su(e, "s", t, n, r)
                    },
                    gauge: function(e, t, n, r) {
                        su(e, "g", t, cu(n), r)
                    },
                    timing: function(e, t, n, r = "second", o) {
                        if ("function" == typeof n) {
                            const r = (0, U.zf)();
                            return Q({
                                op: "metrics.timing",
                                name: t,
                                startTime: r,
                                onlyIfParent: !0
                            }, (s => L((() => n()), (() => {}), (() => {
                                const n = (0, U.zf)();
                                iu(e, t, n - r, { ...o,
                                    unit: "second"
                                }), s.end(n)
                            }))))
                        }
                        iu(e, t, n, { ...o,
                            unit: r
                        })
                    },
                    getMetricsAggregatorForClient: ou
                };

                function cu(e) {
                    return "string" == typeof e ? parseInt(e) : e
                }

                function uu(e) {
                    return e.replace(/[^\w\-./]+/gi, "")
                }
                const lu = [
                    ["\n", "\\n"],
                    ["\r", "\\r"],
                    ["\t", "\\t"],
                    ["\\", "\\\\"],
                    ["|", "\\u{7c}"],
                    [",", "\\u{2c}"]
                ];

                function du(e) {
                    return [...e].reduce(((e, t) => e + function(e) {
                        for (const [t, n] of lu)
                            if (e === t) return n;
                        return e
                    }(t)), "")
                }

                function pu(e, t) {
                    d.vF.log(`Flushing aggregated metrics, number of metrics: ${t.length}`);
                    const n = function(e, t, n, r) {
                        const o = {
                            sent_at: (new Date).toISOString()
                        };
                        n && n.sdk && (o.sdk = {
                            name: n.sdk.name,
                            version: n.sdk.version
                        });
                        r && t && (o.dsn = (0, ye.SB)(t));
                        const s = function(e) {
                            const t = function(e) {
                                let t = "";
                                for (const n of e) {
                                    const e = Object.entries(n.tags),
                                        r = e.length > 0 ? `|#${e.map((([e,t])=>`${e}:${t}`)).join(",")}` : "";
                                    t += `${n.name}@${n.unit}:${n.metric}|${n.metricType}${r}|T${n.timestamp}\n`
                                }
                                return t
                            }(e);
                            return [{
                                type: "statsd",
                                length: t.length
                            }, t]
                        }(e);
                        return (0, _e.h4)(o, [s])
                    }(t, e.getDsn(), e.getSdkMetadata(), e.getOptions().tunnel);
                    e.sendEnvelope(n)
                }
                const hu = {
                    [eu]: class {
                        constructor(e) {
                            this._value = e
                        }
                        get weight() {
                            return 1
                        }
                        add(e) {
                            this._value += e
                        }
                        toString() {
                            return `${this._value}`
                        }
                    },
                    [tu]: class {
                        constructor(e) {
                            this._last = e, this._min = e, this._max = e, this._sum = e, this._count = 1
                        }
                        get weight() {
                            return 5
                        }
                        add(e) {
                            this._last = e, e < this._min && (this._min = e), e > this._max && (this._max = e), this._sum += e, this._count++
                        }
                        toString() {
                            return `${this._last}:${this._min}:${this._max}:${this._sum}:${this._count}`
                        }
                    },
                    [ru]: class {
                        constructor(e) {
                            this._value = [e]
                        }
                        get weight() {
                            return this._value.length
                        }
                        add(e) {
                            this._value.push(e)
                        }
                        toString() {
                            return this._value.join(":")
                        }
                    },
                    [nu]: class {
                        constructor(e) {
                            this.first = e, this._value = new Set([e])
                        }
                        get weight() {
                            return this._value.size
                        }
                        add(e) {
                            this._value.add(e)
                        }
                        toString() {
                            return Array.from(this._value).map((e => "string" == typeof e ? function(e) {
                                let t = 0;
                                for (let n = 0; n < e.length; n++) t = (t << 5) - t + e.charCodeAt(n), t &= t;
                                return t >>> 0
                            }(e) : e)).join(":")
                        }
                    }
                };
                class fu {
                    constructor(e) {
                        this._client = e, this._buckets = new Map, this._interval = setInterval((() => this.flush()), 5e3)
                    }
                    add(e, t, n, r = "none", o = {}, s = (0, U.zf)()) {
                        const i = Math.floor(s),
                            a = t.replace(/[^\w\-.]+/gi, "_");
                        const c = function(e) {
                                const t = {};
                                for (const n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[uu(n)] = du(String(e[n])));
                                return t
                            }(o),
                            u = function(e) {
                                return e.replace(/[^\w]+/gi, "_")
                            }(r),
                            l = function(e, t, n, r) {
                                const o = Object.entries((0, T.Ce)(r)).sort(((e, t) => e[0].localeCompare(t[0])));
                                return `${e}${t}${n}${o}`
                            }(e, a, u, c);
                        let d = this._buckets.get(l);
                        const p = d && "s" === e ? d.metric.weight : 0;
                        d ? (d.metric.add(n), d.timestamp < i && (d.timestamp = i)) : (d = {
                            metric: new hu[e](n),
                            timestamp: i,
                            metricType: e,
                            name: a,
                            unit: u,
                            tags: c
                        }, this._buckets.set(l, d));
                        const f = "string" == typeof n ? d.metric.weight - p : n;
                        (0, h.r2)(e, a, f, u, o, l)
                    }
                    flush() {
                        if (0 === this._buckets.size) return;
                        const e = Array.from(this._buckets.values());
                        pu(this._client, e), this._buckets.clear()
                    }
                    close() {
                        clearInterval(this._interval), this.flush()
                    }
                }
                const mu = {
                    increment: function(e, t = 1, n) {
                        au.increment(fu, e, t, n)
                    },
                    distribution: function(e, t, n) {
                        au.distribution(fu, e, t, n)
                    },
                    set: function(e, t, n) {
                        au.set(fu, e, t, n)
                    },
                    gauge: function(e, t, n) {
                        au.gauge(fu, e, t, n)
                    },
                    timing: function(e, t, n = "second", r) {
                        return au.timing(fu, e, t, n, r)
                    }
                };
                var gu = n(26904);

                function _u(e, t, n, r, s = "auto.http.browser") {
                    if (!e.fetchData) return;
                    const i = D() && t(e.fetchData.url);
                    if (e.endTimestamp && i) {
                        const t = e.fetchData.__span;
                        if (!t) return;
                        const n = r[t];
                        return void(n && (! function(e, t) {
                            if (t.response) {
                                (0, f.N8)(e, t.response.status);
                                const n = t.response && t.response.headers && t.response.headers.get("content-length");
                                if (n) {
                                    const t = parseInt(n);
                                    t > 0 && e.setAttribute("http.response_content_length", t)
                                }
                            } else t.error && e.setStatus({
                                code: f.TJ,
                                message: "internal_error"
                            });
                            e.end()
                        }(n, e), delete r[t]))
                    }
                    const a = (0, C.o5)(),
                        c = (0, C.KU)(),
                        {
                            method: u,
                            url: l
                        } = e.fetchData,
                        d = function(e) {
                            try {
                                return new URL(e).href
                            } catch (e) {
                                return
                            }
                        }(l),
                        p = d ? (0, St.Dl)(d).host : void 0,
                        m = !!(0, h.Bk)(),
                        g = i && m ? Z({
                            name: `${u} ${l}`,
                            attributes: {
                                url: l,
                                type: "fetch",
                                "http.method": u,
                                "http.url": d,
                                "server.address": p,
                                [o.JD]: s,
                                [o.uT]: "http.client"
                            }
                        }) : new B;
                    if (e.fetchData.__span = g.spanContext().spanId, r[g.spanContext().spanId] = g, n(e.fetchData.url) && c) {
                        const t = e.args[0];
                        e.args[1] = e.args[1] || {};
                        const n = e.args[1];
                        n.headers = function(e, t, n, r, o) {
                            const s = (0, C.rm)(),
                                {
                                    traceId: i,
                                    spanId: a,
                                    sampled: c,
                                    dsc: u
                                } = { ...s.getPropagationContext(),
                                    ...n.getPropagationContext()
                                },
                                l = o ? (0, h.Qh)(o) : (0, E.TC)(i, a, c),
                                d = (0, gu.De)(u || (o ? (0, F.k1)(o) : (0, F.lF)(i, t))),
                                p = r.headers || ("undefined" != typeof Request && (0, N.tH)(e, Request) ? e.headers : void 0);
                            if (p) {
                                if ("undefined" != typeof Headers && (0, N.tH)(p, Headers)) {
                                    const e = new Headers(p);
                                    return e.append("sentry-trace", l), d && e.append(gu.hF, d), e
                                }
                                if (Array.isArray(p)) {
                                    const e = [...p, ["sentry-trace", l]];
                                    return d && e.push([gu.hF, d]), e
                                } {
                                    const e = "baggage" in p ? p.baggage : void 0,
                                        t = [];
                                    return Array.isArray(e) ? t.push(...e) : e && t.push(e), d && t.push(d), { ...p,
                                        "sentry-trace": l,
                                        baggage: t.length > 0 ? t.join(",") : void 0
                                    }
                                }
                            }
                            return {
                                "sentry-trace": l,
                                baggage: d
                            }
                        }(t, c, a, n, D() && m ? g : void 0)
                    }
                    return g
                }
                const yu = new WeakMap,
                    vu = new Map,
                    bu = {
                        traceFetch: !0,
                        traceXHR: !0,
                        enableHTTPTimings: !0
                    };

                function Su(e, t) {
                    const {
                        traceFetch: n,
                        traceXHR: r,
                        shouldCreateSpanForRequest: s,
                        enableHTTPTimings: i,
                        tracePropagationTargets: a
                    } = {
                        traceFetch: bu.traceFetch,
                        traceXHR: bu.traceXHR,
                        ...t
                    }, c = "function" == typeof s ? s : e => !0, u = e => function(e, t) {
                        const n = We.jf.location && We.jf.location.href;
                        if (n) {
                            let r, o;
                            try {
                                r = new URL(e, n), o = new URL(n).origin
                            } catch (e) {
                                return !1
                            }
                            const s = r.origin === o;
                            return t ? (0, k.Xr)(r.toString(), t) || s && (0, k.Xr)(r.pathname, t) : s
                        } {
                            const n = !!e.match(/^\/(?!\/)/);
                            return t ? (0, k.Xr)(e, t) : n
                        }
                    }(e, a), l = {};
                    n && (e.addEventProcessor((e => ("transaction" === e.type && e.spans && e.spans.forEach((e => {
                        if ("http.client" === e.op) {
                            const t = vu.get(e.span_id);
                            t && (e.timestamp = t / 1e3, vu.delete(e.span_id))
                        }
                    })), e))), (0, pt.B$)((e => {
                        if (e.response) {
                            const t = yu.get(e.response);
                            t && e.endTimestamp && vu.set(t, e.endTimestamp)
                        }
                    })), (0, pt.ur)((e => {
                        const t = _u(e, c, u, l);
                        if (e.response && e.fetchData.__span && yu.set(e.response, e.fetchData.__span), t) {
                            const n = Cu(e.fetchData.url),
                                r = n ? (0, St.Dl)(n).host : void 0;
                            t.setAttributes({
                                "http.url": n,
                                "server.address": r
                            })
                        }
                        i && t && wu(t)
                    }))), r && (0, ut.Mn)((e => {
                        const t = function(e, t, n, r) {
                            const s = e.xhr,
                                i = s && s[ut.Er];
                            if (!s || s.__sentry_own_request__ || !i) return;
                            const a = D() && t(i.url);
                            if (e.endTimestamp && a) {
                                const e = s.__sentry_xhr_span_id__;
                                if (!e) return;
                                const t = r[e];
                                return void(t && void 0 !== i.status_code && ((0, f.N8)(t, i.status_code), t.end(), delete r[e]))
                            }
                            const c = Cu(i.url),
                                u = c ? (0, St.Dl)(c).host : void 0,
                                l = !!(0, h.Bk)(),
                                d = a && l ? Z({
                                    name: `${i.method} ${i.url}`,
                                    attributes: {
                                        type: "xhr",
                                        "http.method": i.method,
                                        "http.url": c,
                                        url: i.url,
                                        "server.address": u,
                                        [o.JD]: "auto.http.browser",
                                        [o.uT]: "http.client"
                                    }
                                }) : new B;
                            s.__sentry_xhr_span_id__ = d.spanContext().spanId, r[s.__sentry_xhr_span_id__] = d;
                            const p = (0, C.KU)();
                            s.setRequestHeader && n(i.url) && p && function(e, t, n) {
                                const r = (0, C.o5)(),
                                    o = (0, C.rm)(),
                                    {
                                        traceId: s,
                                        spanId: i,
                                        sampled: a,
                                        dsc: c
                                    } = { ...o.getPropagationContext(),
                                        ...r.getPropagationContext()
                                    },
                                    u = n && D() ? (0, h.Qh)(n) : (0, E.TC)(s, i, a),
                                    l = (0, gu.De)(c || (n ? (0, F.k1)(n) : (0, F.lF)(s, t)));
                                ! function(e, t, n) {
                                    try {
                                        e.setRequestHeader("sentry-trace", t), n && e.setRequestHeader(gu.hF, n)
                                    } catch (e) {}
                                }(e, u, l)
                            }(s, p, D() && l ? d : void 0);
                            return d
                        }(e, c, u, l);
                        i && t && wu(t)
                    }))
                }

                function wu(e) {
                    const {
                        url: t
                    } = (0, h.et)(e).data || {};
                    if (!t || "string" != typeof t) return;
                    const n = kn("resource", (({
                        entries: r
                    }) => {
                        r.forEach((r => {
                            if (function(e) {
                                    return "resource" === e.entryType && "initiatorType" in e && "string" == typeof e.nextHopProtocol && ("fetch" === e.initiatorType || "xmlhttprequest" === e.initiatorType)
                                }(r) && r.name.endsWith(t)) {
                                const t = function(e) {
                                    const {
                                        name: t,
                                        version: n
                                    } = function(e) {
                                        let t = "unknown",
                                            n = "unknown",
                                            r = "";
                                        for (const o of e) {
                                            if ("/" === o) {
                                                [t, n] = e.split("/");
                                                break
                                            }
                                            if (!isNaN(Number(o))) {
                                                t = "h" === r ? "http" : r, n = e.split(r)[1];
                                                break
                                            }
                                            r += o
                                        }
                                        r === e && (t = r);
                                        return {
                                            name: t,
                                            version: n
                                        }
                                    }(e.nextHopProtocol), r = [];
                                    if (r.push(["network.protocol.version", n], ["network.protocol.name", t]), !U.k3) return r;
                                    return [...r, ["http.request.redirect_start", ku(e.redirectStart)],
                                        ["http.request.fetch_start", ku(e.fetchStart)],
                                        ["http.request.domain_lookup_start", ku(e.domainLookupStart)],
                                        ["http.request.domain_lookup_end", ku(e.domainLookupEnd)],
                                        ["http.request.connect_start", ku(e.connectStart)],
                                        ["http.request.secure_connection_start", ku(e.secureConnectionStart)],
                                        ["http.request.connection_end", ku(e.connectEnd)],
                                        ["http.request.request_start", ku(e.requestStart)],
                                        ["http.request.response_start", ku(e.responseStart)],
                                        ["http.request.response_end", ku(e.responseEnd)]
                                    ]
                                }(r);
                                t.forEach((t => e.setAttribute(...t))), setTimeout(n)
                            }
                        }))
                    }))
                }

                function ku(e = 0) {
                    return ((U.k3 || performance.timeOrigin) + e) / 1e3
                }

                function Cu(e) {
                    try {
                        return new URL(e, We.jf.location.origin).href
                    } catch (e) {
                        return
                    }
                }

                function xu(e) {
                    return "number" == typeof e && isFinite(e)
                }

                function Tu(e, t, n, { ...r
                }) {
                    const o = (0, h.et)(e).start_timestamp;
                    return o && o > t && "function" == typeof e.updateStartTime && e.updateStartTime(t), te(e, (() => {
                        const e = Z({
                            startTime: t,
                            ...r
                        });
                        return e && e.end(n), e
                    }))
                }

                function Iu() {
                    return Dt.j && Dt.j.addEventListener && Dt.j.performance
                }

                function Eu(e) {
                    return e / 1e3
                }
                let Mu, Ru, Au = 0,
                    Nu = {};

                function Lu() {
                    const e = Iu();
                    if (e && U.k3) {
                        e.mark && Dt.j.performance.mark("sentry-tracing-init");
                        const t = Sn((({
                                metric: e
                            }) => {
                                const t = e.entries[e.entries.length - 1];
                                if (!t) return;
                                const n = Eu(U.k3),
                                    r = Eu(t.startTime);
                                Nt.T && d.vF.log("[Measurements] Adding FID"), Nu.fid = {
                                    value: e.value,
                                    unit: "millisecond"
                                }, Nu["mark.fid"] = {
                                    value: n + r,
                                    unit: "second"
                                }
                            })),
                            n = vn((({
                                metric: e
                            }) => {
                                const t = e.entries[e.entries.length - 1];
                                t && (Nt.T && d.vF.log("[Measurements] Adding CLS"), Nu.cls = {
                                    value: e.value,
                                    unit: ""
                                }, Ru = t)
                            }), !0),
                            r = bn((({
                                metric: e
                            }) => {
                                const t = e.entries[e.entries.length - 1];
                                t && (Nt.T && d.vF.log("[Measurements] Adding LCP"), Nu.lcp = {
                                    value: e.value,
                                    unit: "millisecond"
                                }, Mu = t)
                            }), !0),
                            o = Rn("ttfb", (({
                                metric: e
                            }) => {
                                e.entries[e.entries.length - 1] && (Nt.T && d.vF.log("[Measurements] Adding TTFB"), Nu.ttfb = {
                                    value: e.value,
                                    unit: "millisecond"
                                })
                            }), En, _n);
                        return () => {
                            t(), n(), r(), o()
                        }
                    }
                    return () => {}
                }

                function Du(e) {
                    const t = Iu();
                    if (!t || !Dt.j.performance.getEntries || !U.k3) return;
                    Nt.T && d.vF.log("[Tracing] Adding & adjusting spans using Performance API");
                    const n = Eu(U.k3),
                        r = t.getEntries(),
                        {
                            op: s,
                            start_timestamp: i
                        } = (0, h.et)(e);
                    if (r.slice(Au).forEach((t => {
                            const r = Eu(t.startTime),
                                a = Eu(Math.max(0, t.duration));
                            if (!("navigation" === s && i && n + r < i)) switch (t.entryType) {
                                case "navigation":
                                    ! function(e, t, n) {
                                        ["unloadEvent", "redirect", "domContentLoadedEvent", "loadEvent", "connect"].forEach((r => {
                                                Ou(e, t, r, n)
                                            })), Ou(e, t, "secureConnection", n, "TLS/SSL", "connectEnd"), Ou(e, t, "fetch", n, "cache", "domainLookupStart"), Ou(e, t, "domainLookup", n, "DNS"),
                                            function(e, t, n) {
                                                const r = n + Eu(t.requestStart),
                                                    s = n + Eu(t.responseEnd),
                                                    i = n + Eu(t.responseStart);
                                                t.responseEnd && (Tu(e, r, s, {
                                                    op: "browser",
                                                    name: "request",
                                                    attributes: {
                                                        [o.JD]: "auto.ui.browser.metrics"
                                                    }
                                                }), Tu(e, i, s, {
                                                    op: "browser",
                                                    name: "response",
                                                    attributes: {
                                                        [o.JD]: "auto.ui.browser.metrics"
                                                    }
                                                }))
                                            }(e, t, n)
                                    }(e, t, n);
                                    break;
                                case "mark":
                                case "paint":
                                case "measure":
                                    {! function(e, t, n, r, s) {
                                            const i = Ot(),
                                                a = Eu(i ? i.requestStart : 0),
                                                c = s + Math.max(n, a),
                                                u = s + n,
                                                l = u + r,
                                                d = {
                                                    [o.JD]: "auto.resource.browser.metrics"
                                                };
                                            c !== u && (d["sentry.browser.measure_happened_before_request"] = !0, d["sentry.browser.measure_start_time"] = c);
                                            Tu(e, c, l, {
                                                name: t.name,
                                                op: t.entryType,
                                                attributes: d
                                            })
                                        }(e, t, r, a, n);
                                        const s = $t(),
                                            i = t.startTime < s.firstHiddenTime;
                                        "first-paint" === t.name && i && (Nt.T && d.vF.log("[Measurements] Adding FP"), Nu.fp = {
                                            value: t.startTime,
                                            unit: "millisecond"
                                        }),
                                        "first-contentful-paint" === t.name && i && (Nt.T && d.vF.log("[Measurements] Adding FCP"), Nu.fcp = {
                                            value: t.startTime,
                                            unit: "millisecond"
                                        });
                                        break
                                    }
                                case "resource":
                                    ! function(e, t, n, r, s, i) {
                                        if ("xmlhttprequest" === t.initiatorType || "fetch" === t.initiatorType) return;
                                        const a = (0, St.Dl)(n),
                                            c = {
                                                [o.JD]: "auto.resource.browser.metrics"
                                            };
                                        Fu(c, t, "transferSize", "http.response_transfer_size"), Fu(c, t, "encodedBodySize", "http.response_content_length"), Fu(c, t, "decodedBodySize", "http.decoded_response_content_length"), "renderBlockingStatus" in t && (c["resource.render_blocking_status"] = t.renderBlockingStatus);
                                        a.protocol && (c["url.scheme"] = a.protocol.split(":").pop());
                                        a.host && (c["server.address"] = a.host);
                                        c["url.same_origin"] = n.includes(Dt.j.location.origin);
                                        const u = i + r,
                                            l = u + s;
                                        Tu(e, u, l, {
                                            name: n.replace(Dt.j.location.origin, ""),
                                            op: t.initiatorType ? `resource.${t.initiatorType}` : "resource.other",
                                            attributes: c
                                        })
                                    }(e, t, t.name, r, a, n)
                            }
                        })), Au = Math.max(r.length - 1, 0), function(e) {
                            const t = Dt.j.navigator;
                            if (!t) return;
                            const n = t.connection;
                            n && (n.effectiveType && e.setAttribute("effectiveConnectionType", n.effectiveType), n.type && e.setAttribute("connectionType", n.type), xu(n.rtt) && (Nu["connection.rtt"] = {
                                value: n.rtt,
                                unit: "millisecond"
                            }));
                            xu(t.deviceMemory) && e.setAttribute("deviceMemory", `${t.deviceMemory} GB`);
                            xu(t.hardwareConcurrency) && e.setAttribute("hardwareConcurrency", String(t.hardwareConcurrency))
                        }(e), "pageload" === s) {
                        ! function(e) {
                            const t = Ot();
                            if (!t) return;
                            const {
                                responseStart: n,
                                requestStart: r
                            } = t;
                            r <= n && (Nt.T && d.vF.log("[Measurements] Adding TTFB Request Time"), e["ttfb.requestTime"] = {
                                value: n - r,
                                unit: "millisecond"
                            })
                        }(Nu), ["fcp", "fp", "lcp"].forEach((e => {
                            const t = Nu[e];
                            if (!t || !i || n >= i) return;
                            const r = t.value,
                                o = n + Eu(r),
                                s = Math.abs(1e3 * (o - i)),
                                a = s - r;
                            Nt.T && d.vF.log(`[Measurements] Normalized ${e} from ${r} to ${s} (${a})`), t.value = s
                        }));
                        const t = Nu["mark.fid"];
                        t && Nu.fid && (Tu(e, t.value, t.value + Eu(Nu.fid.value), {
                                name: "first input delay",
                                op: "ui.action",
                                attributes: {
                                    [o.JD]: "auto.ui.browser.metrics"
                                }
                            }), delete Nu["mark.fid"]), "fcp" in Nu || delete Nu.cls, Object.entries(Nu).forEach((([e, t]) => {
                                H(e, t.value, t.unit)
                            })),
                            function(e) {
                                Mu && (Nt.T && d.vF.log("[Measurements] Adding LCP Data"), Mu.element && e.setAttribute("lcp.element", (0, Tt.Hd)(Mu.element)), Mu.id && e.setAttribute("lcp.id", Mu.id), Mu.url && e.setAttribute("lcp.url", Mu.url.trim().slice(0, 200)), e.setAttribute("lcp.size", Mu.size));
                                Ru && Ru.sources && (Nt.T && d.vF.log("[Measurements] Adding CLS Data"), Ru.sources.forEach(((t, n) => e.setAttribute(`cls.source.${n+1}`, (0, Tt.Hd)(t.node)))))
                            }(e)
                    }
                    Mu = void 0, Ru = void 0, Nu = {}
                }

                function Ou(e, t, n, r, s, i) {
                    const a = i ? t[i] : t[`${n}End`],
                        c = t[`${n}Start`];
                    c && a && Tu(e, r + Eu(c), r + Eu(a), {
                        op: "browser",
                        name: s || n,
                        attributes: {
                            [o.JD]: "auto.ui.browser.metrics"
                        }
                    })
                }

                function Fu(e, t, n, r) {
                    const o = t[n];
                    null != o && o < 2147483647 && (e[r] = o)
                }
                const Pu = [],
                    Bu = new Map;

                function Uu() {
                    if (Iu() && U.k3) {
                        const e = wn((({
                            metric: e
                        }) => {
                            const t = (0, C.KU)();
                            if (!t || null == e.value) return;
                            const n = e.entries.find((t => t.duration === e.value && ju[t.name]));
                            if (!n) return;
                            const {
                                interactionId: r
                            } = n, s = ju[n.name], i = t.getOptions(), a = Eu(U.k3 + n.startTime), c = Eu(e.value), u = (0, C.o5)(), l = (0, h.Bk)(), d = l ? (0, h.zU)(l) : void 0, p = (null != r ? Bu.get(r) : void 0) || d, f = p ? (0, h.et)(p).description : u.getScopeData().transactionName, m = u.getUser(), g = t.getIntegrationByName("Replay"), _ = g && g.getReplayId(), y = void 0 !== m ? m.email || m.id || m.ip_address : void 0;
                            let v;
                            try {
                                v = u.getScopeData().contexts.profile.profile_id
                            } catch (e) {}
                            const b = Z({
                                name: (0, Tt.Hd)(n.target),
                                op: `ui.interaction.${s}`,
                                attributes: (0, T.Ce)({
                                    release: i.release,
                                    environment: i.environment,
                                    transaction: f,
                                    [o.jG]: e.value,
                                    [o.JD]: "auto.http.browser.inp",
                                    user: y || void 0,
                                    profile_id: v || void 0,
                                    replay_id: _ || void 0,
                                    "user_agent.original": Dt.j.navigator && Dt.j.navigator.userAgent
                                }),
                                startTime: a,
                                experimental: {
                                    standalone: !0
                                }
                            });
                            b.addEvent("inp", {
                                [o.Sn]: "millisecond",
                                [o.xc]: e.value
                            }), b.end(a + c)
                        }));
                        return () => {
                            e()
                        }
                    }
                    return () => {}
                }
                const ju = {
                    click: "click",
                    pointerdown: "click",
                    pointerup: "click",
                    mousedown: "click",
                    mouseup: "click",
                    touchstart: "click",
                    touchend: "click",
                    mouseover: "hover",
                    mouseout: "hover",
                    mouseenter: "hover",
                    mouseleave: "hover",
                    pointerover: "hover",
                    pointerout: "hover",
                    pointerenter: "hover",
                    pointerleave: "hover",
                    dragstart: "drag",
                    dragend: "drag",
                    drag: "drag",
                    dragenter: "drag",
                    dragleave: "drag",
                    dragover: "drag",
                    drop: "drag",
                    keydown: "press",
                    keyup: "press",
                    keypress: "press",
                    input: "press"
                };
                const zu = {
                    idleTimeout: 1e3,
                    finalTimeout: 3e4,
                    childSpanTimeout: 15e3
                };

                function Hu(e, t = {}) {
                    const n = new Map;
                    let r, s = !1,
                        i = "externalFinish",
                        a = !t.disableAutoFinish;
                    const c = [],
                        {
                            idleTimeout: u = zu.idleTimeout,
                            finalTimeout: l = zu.finalTimeout,
                            childSpanTimeout: m = zu.childSpanTimeout,
                            beforeSpanEnd: g
                        } = t,
                        _ = (0, C.KU)();
                    if (!_ || !D()) return new B;
                    const y = (0, C.o5)(),
                        v = (0, h.Bk)(),
                        b = function(e) {
                            const t = Z(e);
                            return (0, O.r)((0, C.o5)(), t), p.T && d.vF.log("[Tracing] Started span is an idle span"), t
                        }(e);

                    function S() {
                        r && (clearTimeout(r), r = void 0)
                    }

                    function w(e) {
                        S(), r = setTimeout((() => {
                            !s && 0 === n.size && a && (i = "idleTimeout", b.end(e))
                        }), u)
                    }

                    function k(e) {
                        r = setTimeout((() => {
                            !s && a && (i = "heartbeatFailed", b.end(e))
                        }), m)
                    }

                    function x(e) {
                        s = !0, n.clear(), c.forEach((e => e())), (0, O.r)(y, v);
                        const t = (0, h.et)(b),
                            {
                                start_timestamp: r
                            } = t;
                        if (!r) return;
                        (t.data || {})[o.fs] || b.setAttribute(o.fs, i), d.vF.log(`[Tracing] Idle span "${t.op}" finished`);
                        const a = (0, h.xO)(b).filter((e => e !== b));
                        let m = 0;
                        a.forEach((t => {
                            t.isRecording() && (t.setStatus({
                                code: f.TJ,
                                message: "cancelled"
                            }), t.end(e), p.T && d.vF.log("[Tracing] Cancelling span since span ended early", JSON.stringify(t, void 0, 2)));
                            const n = (0, h.et)(t),
                                {
                                    timestamp: r = 0,
                                    start_timestamp: o = 0
                                } = n,
                                s = o <= e,
                                i = r - o <= (l + u) / 1e3;
                            if (p.T) {
                                const e = JSON.stringify(t, void 0, 2);
                                s ? i || d.vF.log("[Tracing] Discarding span since it finished after idle span final timeout", e) : d.vF.log("[Tracing] Discarding span since it happened after idle span was finished", e)
                            }
                            i && s || ((0, h.VS)(b, t), m++)
                        })), m > 0 && b.setAttribute("sentry.idle_span_discarded_spans", m)
                    }
                    return b.end = new Proxy(b.end, {
                        apply(e, t, n) {
                            g && g(b);
                            const [r, ...o] = n, s = r || (0, U.zf)(), i = (0, h.cI)(s), a = (0, h.xO)(b).filter((e => e !== b));
                            if (!a.length) return x(i), Reflect.apply(e, t, [i, ...o]);
                            const c = a.map((e => (0, h.et)(e).timestamp)).filter((e => !!e)),
                                u = c.length ? Math.max(...c) : void 0,
                                d = (0, h.et)(b).start_timestamp,
                                p = Math.min(d ? d + l / 1e3 : 1 / 0, Math.max(d || -1 / 0, Math.min(i, u || 1 / 0)));
                            return x(p), Reflect.apply(e, t, [p, ...o])
                        }
                    }), c.push(_.on("spanStart", (e => {
                        if (s || e === b || (0, h.et)(e).timestamp) return;
                        var t;
                        (0, h.xO)(b).includes(e) && (t = e.spanContext().spanId, S(), n.set(t, !0), k((0, U.zf)() + m / 1e3))
                    }))), c.push(_.on("spanEnd", (e => {
                        var t;
                        s || (t = e.spanContext().spanId, n.has(t) && n.delete(t), 0 === n.size && w((0, U.zf)() + u / 1e3))
                    }))), c.push(_.on("idleSpanEnableAutoFinish", (e => {
                        e === b && (a = !0, w(), n.size && k())
                    }))), t.disableAutoFinish || w(), setTimeout((() => {
                        s || (b.setStatus({
                            code: f.TJ,
                            message: "deadline_exceeded"
                        }), i = "finalTimeout", b.end())
                    }), l), b
                }
                const $u = { ...zu,
                        instrumentNavigation: !0,
                        instrumentPageLoad: !0,
                        markBackgroundSpan: !0,
                        enableLongTask: !0,
                        enableLongAnimationFrame: !1,
                        enableInp: !0,
                        _experiments: {},
                        ...bu
                    },
                    Wu = (e = {}) => {
                        g();
                        const {
                            enableInp: t,
                            enableLongTask: n,
                            enableLongAnimationFrame: r,
                            _experiments: {
                                enableInteractions: s
                            },
                            beforeStartSpan: i,
                            idleTimeout: a,
                            finalTimeout: c,
                            childSpanTimeout: u,
                            markBackgroundSpan: l,
                            traceFetch: p,
                            traceXHR: m,
                            shouldCreateSpanForRequest: _,
                            enableHTTPTimings: y,
                            instrumentPageLoad: v,
                            instrumentNavigation: b
                        } = { ...$u,
                            ...e
                        }, S = Lu();
                        t && Uu(), r && PerformanceObserver.supportedEntryTypes.includes("long-animation-frame") ? new PerformanceObserver((e => {
                            for (const t of e.getEntries()) {
                                if (!(0, h.Bk)()) return;
                                if (!t.scripts[0]) return;
                                const e = Eu(U.k3 + t.startTime),
                                    n = Eu(t.duration),
                                    r = {
                                        [o.JD]: "auto.ui.browser.metrics"
                                    },
                                    s = t.scripts[0];
                                if (s) {
                                    const {
                                        invoker: e,
                                        invokerType: t,
                                        sourceURL: n,
                                        sourceFunctionName: o,
                                        sourceCharPosition: i
                                    } = s;
                                    r["browser.script.invoker"] = e, r["browser.script.invoker_type"] = t, n && (r["code.filepath"] = n), o && (r["code.function"] = o), -1 !== i && (r["browser.script.source_char_position"] = i)
                                }
                                const i = Z({
                                    name: "Main UI thread blocked",
                                    op: "ui.long-animation-frame",
                                    startTime: e,
                                    attributes: r
                                });
                                i && i.end(e + n)
                            }
                        })).observe({
                            type: "long-animation-frame",
                            buffered: !0
                        }) : n && kn("longtask", (({
                            entries: e
                        }) => {
                            for (const t of e) {
                                if (!(0, h.Bk)()) return;
                                const e = Eu(U.k3 + t.startTime),
                                    n = Eu(t.duration),
                                    r = Z({
                                        name: "Main UI thread blocked",
                                        op: "ui.long-task",
                                        startTime: e,
                                        attributes: {
                                            [o.JD]: "auto.ui.browser.metrics"
                                        }
                                    });
                                r && r.end(e + n)
                            }
                        })), s && kn("event", (({
                            entries: e
                        }) => {
                            for (const t of e) {
                                if (!(0, h.Bk)()) return;
                                if ("click" === t.name) {
                                    const e = Eu(U.k3 + t.startTime),
                                        n = Eu(t.duration),
                                        r = {
                                            name: (0, Tt.Hd)(t.target),
                                            op: `ui.interaction.${t.name}`,
                                            startTime: e,
                                            attributes: {
                                                [o.JD]: "auto.ui.browser.metrics"
                                            }
                                        },
                                        s = (0, Tt.xE)(t.target);
                                    s && (r.attributes["ui.component_name"] = s);
                                    const i = Z(r);
                                    i && i.end(e + n)
                                }
                            }
                        }));
                        const w = {
                            name: void 0,
                            source: void 0
                        };

                        function k(e, t) {
                            const n = "pageload" === t.op,
                                r = i ? i(t) : t,
                                s = r.attributes || {};
                            t.name !== r.name && (s[o.i_] = "custom", r.attributes = s), w.name = r.name, w.source = s[o.i_];
                            const l = Hu(r, {
                                idleTimeout: a,
                                finalTimeout: c,
                                childSpanTimeout: u,
                                disableAutoFinish: n,
                                beforeSpanEnd: e => {
                                    S(), Du(e)
                                }
                            });

                            function d() {
                                ["interactive", "complete"].includes(We.jf.document.readyState) && e.emit("idleSpanEnableAutoFinish", l)
                            }
                            return n && We.jf.document && (We.jf.document.addEventListener("readystatechange", (() => {
                                d()
                            })), d()), l
                        }
                        return {
                            name: "BrowserTracing",
                            afterAllSetup(e) {
                                let n, r = We.jf.location && We.jf.location.href;
                                e.on("startNavigationSpan", (t => {
                                    (0, C.KU)() === e && (n && !(0, h.et)(n).timestamp && (ht.T && d.vF.log(`[Tracing] Finishing current root span with op: ${(0,h.et)(n).op}`), n.end()), n = k(e, {
                                        op: "navigation",
                                        ...t
                                    }))
                                })), e.on("startPageLoadSpan", ((t, r = {}) => {
                                    if ((0, C.KU)() !== e) return;
                                    n && !(0, h.et)(n).timestamp && (ht.T && d.vF.log(`[Tracing] Finishing current root span with op: ${(0,h.et)(n).op}`), n.end());
                                    const o = r.sentryTrace || Ku("sentry-trace"),
                                        s = r.baggage || Ku("baggage"),
                                        i = (0, E.kM)(o, s);
                                    (0, C.o5)().setPropagationContext(i), n = k(e, {
                                        op: "pageload",
                                        ...t
                                    })
                                })), e.on("spanEnd", (e => {
                                    const t = (0, h.et)(e).op;
                                    if (e !== (0, h.zU)(e) || "navigation" !== t && "pageload" !== t) return;
                                    const n = (0, C.o5)(),
                                        r = n.getPropagationContext();
                                    n.setPropagationContext({ ...r,
                                        sampled: void 0 !== r.sampled ? r.sampled : (0, h.pK)(e),
                                        dsc: r.dsc || (0, F.k1)(e)
                                    })
                                })), We.jf.location && (v && qu(e, {
                                    name: We.jf.location.pathname,
                                    startTime: U.k3 ? U.k3 / 1e3 : void 0,
                                    attributes: {
                                        [o.i_]: "url",
                                        [o.JD]: "auto.pageload.browser"
                                    }
                                }), b && (0, Dn._)((({
                                    to: t,
                                    from: n
                                }) => {
                                    void 0 === n && r && -1 !== r.indexOf(t) ? r = void 0 : n !== t && (r = void 0, Ju(e, {
                                        name: We.jf.location.pathname,
                                        attributes: {
                                            [o.i_]: "url",
                                            [o.JD]: "auto.navigation.browser"
                                        }
                                    }))
                                }))), l && (We.jf && We.jf.document ? We.jf.document.addEventListener("visibilitychange", (() => {
                                    const e = (0, h.Bk)();
                                    if (!e) return;
                                    const t = (0, h.zU)(e);
                                    if (We.jf.document.hidden && t) {
                                        const e = "cancelled",
                                            {
                                                op: n,
                                                status: r
                                            } = (0, h.et)(t);
                                        ht.T && d.vF.log(`[Tracing] Transaction: ${e} -> since tab moved to the background, op: ${n}`), r || t.setStatus({
                                            code: f.TJ,
                                            message: e
                                        }), t.setAttribute("sentry.cancellation_reason", "document.hidden"), t.end()
                                    }
                                })) : ht.T && d.vF.warn("[Tracing] Could not set up background tab detection due to lack of global document")), s && function(e, t, n, r) {
                                    let s;
                                    const i = () => {
                                        const i = "ui.action.click",
                                            a = (0, h.Bk)(),
                                            c = a && (0, h.zU)(a);
                                        if (c) {
                                            const e = (0, h.et)(c).op;
                                            if (["navigation", "pageload"].includes(e)) return void(ht.T && d.vF.warn(`[Tracing] Did not create ${i} span because a pageload or navigation span is in progress.`))
                                        }
                                        s && (s.setAttribute(o.fs, "interactionInterrupted"), s.end(), s = void 0), r.name ? s = Hu({
                                            name: r.name,
                                            op: i,
                                            attributes: {
                                                [o.i_]: r.source || "url"
                                            }
                                        }, {
                                            idleTimeout: e,
                                            finalTimeout: t,
                                            childSpanTimeout: n
                                        }) : ht.T && d.vF.warn(`[Tracing] Did not create ${i} transaction because _latestRouteName is missing.`)
                                    };
                                    We.jf.document && addEventListener("click", i, {
                                        once: !1,
                                        capture: !0
                                    })
                                }(a, c, u, w), t && function() {
                                    const e = ({
                                        entries: e
                                    }) => {
                                        const t = (0, h.Bk)(),
                                            n = t && (0, h.zU)(t);
                                        e.forEach((e => {
                                            if (! function(e) {
                                                    return "duration" in e
                                                }(e) || !n) return;
                                            const t = e.interactionId;
                                            if (null != t && !Bu.has(t)) {
                                                if (Pu.length > 10) {
                                                    const e = Pu.shift();
                                                    Bu.delete(e)
                                                }
                                                Pu.push(t), Bu.set(t, n)
                                            }
                                        }))
                                    };
                                    kn("event", e), kn("first-input", e)
                                }(), Su(e, {
                                    traceFetch: p,
                                    traceXHR: m,
                                    tracePropagationTargets: e.getOptions().tracePropagationTargets,
                                    shouldCreateSpanForRequest: _,
                                    enableHTTPTimings: y
                                })
                            }
                        }
                    };

                function qu(e, t, n) {
                    e.emit("startPageLoadSpan", t, n), (0, C.o5)().setTransactionName(t.name);
                    const r = (0, h.Bk)();
                    return "pageload" === (r && (0, h.et)(r).op) ? r : void 0
                }

                function Ju(e, t) {
                    (0, C.rm)().setPropagationContext((0, M.J)()), (0, C.o5)().setPropagationContext((0, M.J)()), e.emit("startNavigationSpan", t), (0, C.o5)().setTransactionName(t.name);
                    const n = (0, h.Bk)();
                    return "navigation" === (n && (0, h.et)(n).op) ? n : void 0
                }

                function Ku(e) {
                    const t = (0, Tt.NX)(`meta[name=${e}]`);
                    return t ? t.getAttribute("content") : void 0
                }
                const Vu = 100,
                    Xu = 5e3,
                    Yu = 36e5;

                function Gu(e) {
                    function t(...e) {
                        p.T && d.vF.info("[Offline]:", ...e)
                    }
                    return n => {
                        const r = e(n);
                        if (!n.createStore) throw new Error("No `createStore` function was provided");
                        const o = n.createStore(n);
                        let s, i = Xu;

                        function a(e) {
                            s && clearTimeout(s), s = setTimeout((async () => {
                                s = void 0;
                                const e = await o.shift();
                                e && (t("Attempting to send previously queued event"), e[0].sent_at = (new Date).toISOString(), u(e, !0).catch((e => {
                                    t("Failed to retry sending", e)
                                })))
                            }), e), "number" != typeof s && s.unref && s.unref()
                        }

                        function c() {
                            s || (a(i), i = Math.min(2 * i, Yu))
                        }
                        async function u(e, s = !1) {
                            if (!s && (0, _e.hP)(e, ["replay_event", "replay_recording"])) return await o.push(e), a(Vu), {};
                            try {
                                const t = await r.send(e);
                                let n = Vu;
                                if (t)
                                    if (t.headers && t.headers["retry-after"]) n = (0, Et.FA)(t.headers["retry-after"]);
                                    else if (t.headers && t.headers["x-sentry-rate-limits"]) n = 6e4;
                                else if ((t.statusCode || 0) >= 400) return t;
                                return a(n), i = Xu, t
                            } catch (r) {
                                if (await
                                    function(e, t, r) {
                                        return !(0, _e.hP)(e, ["client_report"]) && (!n.shouldStore || n.shouldStore(e, t, r))
                                    }(e, r, i)) return s ? await o.unshift(e) : await o.push(e), c(), t("Error sending. Event queued.", r), {};
                                throw r
                            }
                        }
                        return n.flushAtStartup && c(), {
                            send: u,
                            flush: e => r.flush(e)
                        }
                    }
                }

                function Qu(e) {
                    return new Promise(((t, n) => {
                        e.oncomplete = e.onsuccess = () => t(e.result), e.onabort = e.onerror = () => n(e.error)
                    }))
                }

                function Zu(e) {
                    return Qu(e.getAllKeys())
                }

                function el(e) {
                    let t;

                    function n() {
                        return null == t && (t = function(e, t) {
                            const n = indexedDB.open(e);
                            n.onupgradeneeded = () => n.result.createObjectStore(t);
                            const r = Qu(n);
                            return e => r.then((n => e(n.transaction(t, "readwrite").objectStore(t))))
                        }(e.dbName || "sentry-offline", e.storeName || "queue")), t
                    }
                    return {
                        push: async t => {
                            try {
                                const r = await (0, _e.bN)(t);
                                await
                                function(e, t, n) {
                                    return e((e => Zu(e).then((r => {
                                        if (!(r.length >= n)) return e.put(t, Math.max(...r, 0) + 1), Qu(e.transaction)
                                    }))))
                                }(n(), r, e.maxQueueSize || 30)
                            } catch (e) {}
                        },
                        unshift: async t => {
                            try {
                                const r = await (0, _e.bN)(t);
                                await
                                function(e, t, n) {
                                    return e((e => Zu(e).then((r => {
                                        if (!(r.length >= n)) return e.put(t, Math.min(...r, 0) - 1), Qu(e.transaction)
                                    }))))
                                }(n(), r, e.maxQueueSize || 30)
                            } catch (e) {}
                        },
                        shift: async () => {
                            try {
                                const e = await
                                function(e) {
                                    return e((e => Zu(e).then((t => {
                                        const n = t[0];
                                        if (null != n) return Qu(e.get(n)).then((t => (e.delete(n), Qu(e.transaction).then((() => t)))))
                                    }))))
                                }(n());
                                if (e) return (0, _e.mE)(e)
                            } catch (e) {}
                        }
                    }
                }

                function tl(e = Je._) {
                    return function(e) {
                        return t => e({ ...t,
                            createStore: el
                        })
                    }(Gu(e))
                }
                var nl = n(7313);
                const rl = 1e6,
                    ol = String(0),
                    sl = "main";
                let il = "",
                    al = "",
                    cl = "",
                    ul = We.jf.navigator && We.jf.navigator.userAgent || "",
                    ll = "";
                const dl = We.jf.navigator && We.jf.navigator.language || We.jf.navigator && We.jf.navigator.languages && We.jf.navigator.languages[0] || "";
                const pl = We.jf.navigator && We.jf.navigator.userAgentData;
                var hl;

                function fl(e) {
                    return function(e) {
                        return !("thread_metadata" in e)
                    }(e) ? function(e) {
                        let t, n = 0;
                        const r = {
                                samples: [],
                                stacks: [],
                                frames: [],
                                thread_metadata: {
                                    [ol]: {
                                        name: sl
                                    }
                                }
                            },
                            o = e.samples[0];
                        if (!o) return r;
                        const s = o.timestamp,
                            i = "number" == typeof performance.timeOrigin ? performance.timeOrigin : U.k3 || 0,
                            a = i - (U.k3 || i);
                        return e.samples.forEach(((o, i) => {
                            if (void 0 === o.stackId) return void 0 === t && (t = n, r.stacks[t] = [], n++), void(r.samples[i] = {
                                elapsed_since_start_ns: ((o.timestamp + a - s) * rl).toFixed(0),
                                stack_id: t,
                                thread_id: ol
                            });
                            let c = e.stacks[o.stackId];
                            const u = [];
                            for (; c;) {
                                u.push(c.frameId);
                                const t = e.frames[c.frameId];
                                t && void 0 === r.frames[c.frameId] && (r.frames[c.frameId] = {
                                    function: t.name,
                                    abs_path: "number" == typeof t.resourceId ? e.resources[t.resourceId] : void 0,
                                    lineno: t.line,
                                    colno: t.column
                                }), c = void 0 === c.parentId ? void 0 : e.stacks[c.parentId]
                            }
                            const l = {
                                elapsed_since_start_ns: ((o.timestamp + a - s) * rl).toFixed(0),
                                stack_id: n,
                                thread_id: ol
                            };
                            r.stacks[n] = u, r.samples[i] = l, n++
                        })), r
                    }(e) : e
                }

                function ml(e, t, n, r) {
                    if ("transaction" !== r.type) throw new TypeError("Profiling events may only be attached to transactions, this should never occur.");
                    if (null == n) throw new TypeError(`Cannot construct profiling event envelope without a valid profile. Got ${n} instead.`);
                    const o = function(e) {
                            const t = e && e.contexts && e.contexts.trace && e.contexts.trace.trace_id;
                            return "string" == typeof t && 32 !== t.length && ht.T && d.vF.log(`[Profiling] Invalid traceId: ${t} on profiled event`), "string" != typeof t ? "" : t
                        }(r),
                        s = fl(n),
                        i = t || ("number" == typeof r.start_timestamp ? 1e3 * r.start_timestamp : 1e3 * (0, U.zf)()),
                        a = "number" == typeof r.timestamp ? 1e3 * r.timestamp : 1e3 * (0, U.zf)();
                    return {
                        event_id: e,
                        timestamp: new Date(i).toISOString(),
                        platform: "javascript",
                        version: "1",
                        release: r.release || "",
                        environment: r.environment || nl.U,
                        runtime: {
                            name: "javascript",
                            version: We.jf.navigator.userAgent
                        },
                        os: {
                            name: il,
                            version: al,
                            build_number: ul
                        },
                        device: {
                            locale: dl,
                            model: ll,
                            manufacturer: ul,
                            architecture: cl,
                            is_emulator: !1
                        },
                        debug_meta: {
                            images: yl(n.resources)
                        },
                        profile: s,
                        transactions: [{
                            name: r.transaction || "",
                            id: r.event_id || (0, w.eJ)(),
                            trace_id: o,
                            active_thread_id: ol,
                            relative_start_ns: "0",
                            relative_end_ns: (1e6 * (a - i)).toFixed(0)
                        }]
                    }
                }

                function gl(e) {
                    return "pageload" === (0, h.et)(e).op
                }
                "object" == typeof(hl = pl) && null !== hl && "getHighEntropyValues" in hl && pl.getHighEntropyValues(["architecture", "model", "platform", "platformVersion", "fullVersionList"]).then((e => {
                    if (il = e.platform || "", cl = e.architecture || "", ll = e.model || "", al = e.platformVersion || "", e.fullVersionList && e.fullVersionList.length > 0) {
                        const t = e.fullVersionList[e.fullVersionList.length - 1];
                        ul = `${t.brand} ${t.version}`
                    }
                })).catch((e => {}));
                const _l = new WeakMap;

                function yl(e) {
                    const t = v.O._sentryDebugIds;
                    if (!t) return [];
                    const n = (0, C.KU)(),
                        r = n && n.getOptions(),
                        o = r && r.stackParser;
                    if (!o) return [];
                    let s;
                    const i = _l.get(o);
                    i ? s = i : (s = new Map, _l.set(o, s));
                    const a = Object.keys(t).reduce(((e, n) => {
                            let r;
                            const i = s.get(n);
                            i ? r = i : (r = o(n), s.set(n, r));
                            for (let o = r.length - 1; o >= 0; o--) {
                                const s = r[o],
                                    i = s && s.filename;
                                if (s && i) {
                                    e[i] = t[n];
                                    break
                                }
                            }
                            return e
                        }), {}),
                        c = [];
                    for (const t of e) t && a[t] && c.push({
                        type: "sourcemap",
                        code_file: t,
                        debug_id: a[t]
                    });
                    return c
                }
                let vl = !1;

                function bl(e) {
                    if (vl) return ht.T && d.vF.log("[Profiling] Profiling has been disabled for the duration of the current user session."), !1;
                    if (!e.isRecording()) return ht.T && d.vF.log("[Profiling] Discarding profile because transaction was not sampled."), !1;
                    const t = (0, C.KU)(),
                        n = t && t.getOptions();
                    if (!n) return ht.T && d.vF.log("[Profiling] Profiling disabled, no options found."), !1;
                    const r = n.profilesSampleRate;
                    if (!("number" != typeof(o = r) && "boolean" != typeof o || "number" == typeof o && isNaN(o) ? (ht.T && d.vF.warn(`[Profiling] Invalid sample rate. Sample rate must be a boolean or a number between 0 and 1. Got ${JSON.stringify(o)} of type ${JSON.stringify(typeof o)}.`), 0) : !0 === o || !1 === o || !(o < 0 || o > 1) || (ht.T && d.vF.warn(`[Profiling] Invalid sample rate. Sample rate must be between 0 and 1. Got ${o}.`), 0))) return ht.T && d.vF.warn("[Profiling] Discarding profile because of invalid sample rate."), !1;
                    var o;
                    if (!r) return ht.T && d.vF.log("[Profiling] Discarding profile because a negative sampling decision was inherited or profileSampleRate is set to 0"), !1;
                    return !!(!0 === r || Math.random() < r) || (ht.T && d.vF.log(`[Profiling] Discarding profile because it's not included in the random sample (sampling rate = ${Number(r)})`), !1)
                }

                function Sl(e, t, n, r) {
                    return function(e) {
                        return e.samples.length < 2 ? (ht.T && d.vF.log("[Profiling] Discarding profile because it contains less than 2 samples"), !1) : !!e.frames.length || (ht.T && d.vF.log("[Profiling] Discarding profile because it contains no frames"), !1)
                    }(n) ? ml(e, t, n, r) : null
                }
                const wl = new Map;

                function kl(e) {
                    const t = wl.get(e);
                    return t && wl.delete(e), t
                }

                function Cl(e) {
                    let t;
                    gl(e) && (t = 1e3 * (0, U.zf)());
                    const n = function() {
                        const e = We.jf.Profiler;
                        if ("function" != typeof e) return void(ht.T && d.vF.log("[Profiling] Profiling is not supported by this browser, Profiler interface missing on window object."));
                        const t = Math.floor(3e3);
                        try {
                            return new e({
                                sampleInterval: 10,
                                maxBufferSize: t
                            })
                        } catch (e) {
                            ht.T && (d.vF.log("[Profiling] Failed to initialize the Profiling constructor, this is likely due to a missing 'Document-Policy': 'js-profiling' header."), d.vF.log("[Profiling] Disabling profiling for current user session.")), vl = !0
                        }
                    }();
                    if (!n) return;
                    ht.T && d.vF.log(`[Profiling] started profiling span: ${(0,h.et)(e).description}`);
                    const r = (0, w.eJ)();
                    async function o() {
                        if (e && n) return n.stop().then((t => {
                            s && (We.jf.clearTimeout(s), s = void 0), ht.T && d.vF.log(`[Profiling] stopped profiling of span: ${(0,h.et)(e).description}`), t ? function(e, t) {
                                if (wl.set(e, t), wl.size > 30) {
                                    const e = wl.keys().next().value;
                                    wl.delete(e)
                                }
                            }(r, t) : ht.T && d.vF.log(`[Profiling] profiler returned null profile for: ${(0,h.et)(e).description}`, "this may indicate an overlapping span or a call to stopProfiling with a profile title that was never started")
                        })).catch((e => {
                            ht.T && d.vF.log("[Profiling] error while stopping profiler:", e)
                        }))
                    }(0, C.o5)().setContext("profile", {
                        profile_id: r,
                        start_timestamp: t
                    });
                    let s = We.jf.setTimeout((() => {
                        ht.T && d.vF.log("[Profiling] max profile duration elapsed, stopping profiling for:", (0, h.et)(e).description), o()
                    }), 3e4);
                    const i = e.end.bind(e);
                    e.end = function() {
                        return e ? (o().then((() => {
                            i()
                        }), (() => {
                            i()
                        })), e) : i()
                    }
                }
                const xl = (0, c._C)((() => ({
                    name: "BrowserProfiling",
                    setup(e) {
                        const t = (0, h.Bk)(),
                            n = t && (0, h.zU)(t);
                        n && gl(n) && bl(n) && Cl(n), e.on("spanStart", (e => {
                            e === (0, h.zU)(e) && bl(e) && Cl(e)
                        })), e.on("beforeEnvelope", (e => {
                            if (!wl.size) return;
                            const t = function(e) {
                                const t = [];
                                return (0, _e.yH)(e, ((e, n) => {
                                    if ("transaction" === n)
                                        for (let n = 1; n < e.length; n++) {
                                            const r = e[n];
                                            r && r.contexts && r.contexts.profile && r.contexts.profile.profile_id && t.push(e[n])
                                        }
                                })), t
                            }(e);
                            if (!t.length) return;
                            const n = [];
                            for (const e of t) {
                                const t = e && e.contexts,
                                    r = t && t.profile && t.profile.profile_id,
                                    o = t && t.profile && t.profile.start_timestamp;
                                if ("string" != typeof r) {
                                    ht.T && d.vF.log("[Profiling] cannot find profile for a span without a profile context");
                                    continue
                                }
                                if (!r) {
                                    ht.T && d.vF.log("[Profiling] cannot find profile for a span without a profile context");
                                    continue
                                }
                                t && t.profile && delete t.profile;
                                const s = kl(r);
                                if (!s) {
                                    ht.T && d.vF.log(`[Profiling] Could not retrieve profile for span: ${r}`);
                                    continue
                                }
                                const i = Sl(r, o, s, e);
                                i && n.push(i)
                            }! function(e, t) {
                                if (!t.length) return e;
                                for (const n of t) e[1].push([{
                                    type: "profile"
                                }, n])
                            }(e, n)
                        }))
                    }
                })));
                var Tl = n(8251),
                    Il = n(96540);

                function El(e) {
                    const t = { ...e
                    };
                    return (0, Tl.K)(t, "react"), (0, a.o)("react", {
                        version: Il.version
                    }), (0, Ye.Ts)(t)
                }
                var Ml = n(84446),
                    Rl = n(4146);
                const Al = "ui.react.render",
                    Nl = "ui.react.mount",
                    Ll = "unknown";
                class Dl extends Il.Component {
                    static __initStatic() {
                        this.defaultProps = {
                            disabled: !1,
                            includeRender: !0,
                            includeUpdates: !0
                        }
                    }
                    constructor(e) {
                        super(e);
                        const {
                            name: t,
                            disabled: n = !1
                        } = this.props;
                        n || (this._mountSpan = Z({
                            name: `<${t}>`,
                            onlyIfParent: !0,
                            op: Nl,
                            attributes: {
                                [o.JD]: "auto.ui.react.profiler",
                                "ui.component_name": t
                            }
                        }))
                    }
                    componentDidMount() {
                        this._mountSpan && this._mountSpan.end()
                    }
                    shouldComponentUpdate({
                        updateProps: e,
                        includeUpdates: t = !0
                    }) {
                        if (t && this._mountSpan && e !== this.props.updateProps) {
                            const t = Object.keys(e).filter((t => e[t] !== this.props.updateProps[t]));
                            if (t.length > 0) {
                                const e = (0, U.zf)();
                                this._updateSpan = te(this._mountSpan, (() => Z({
                                    name: `<${this.props.name}>`,
                                    onlyIfParent: !0,
                                    op: "ui.react.update",
                                    startTime: e,
                                    attributes: {
                                        [o.JD]: "auto.ui.react.profiler",
                                        "ui.component_name": this.props.name,
                                        "ui.react.changed_props": t
                                    }
                                })))
                            }
                        }
                        return !0
                    }
                    componentDidUpdate() {
                        this._updateSpan && (this._updateSpan.end(), this._updateSpan = void 0)
                    }
                    componentWillUnmount() {
                        const e = (0, U.zf)(),
                            {
                                name: t,
                                includeRender: n = !0
                            } = this.props;
                        if (this._mountSpan && n) {
                            const n = (0, h.et)(this._mountSpan).timestamp;
                            te(this._mountSpan, (() => {
                                const r = Z({
                                    onlyIfParent: !0,
                                    name: `<${t}>`,
                                    op: Al,
                                    startTime: n,
                                    attributes: {
                                        [o.JD]: "auto.ui.react.profiler",
                                        "ui.component_name": t
                                    }
                                });
                                r && r.end(e)
                            }))
                        }
                    }
                    render() {
                        return this.props.children
                    }
                }

                function Ol(e, t) {
                    const n = t && t.name || e.displayName || e.name || Ll,
                        r = r => Il.createElement(Dl, { ...t,
                            name: n,
                            updateProps: r
                        }, Il.createElement(e, { ...r
                        }));
                    return r.displayName = `profiler(${n})`, Rl(r, e), r
                }

                function Fl(e, t = {
                    disabled: !1,
                    hasRenderSpan: !0
                }) {
                    const [n] = Il.useState((() => {
                        if (!t || !t.disabled) return Z({
                            name: `<${e}>`,
                            onlyIfParent: !0,
                            op: Nl,
                            attributes: {
                                [o.JD]: "auto.ui.react.profiler",
                                "ui.component_name": e
                            }
                        })
                    }));
                    Il.useEffect((() => (n && n.end(), () => {
                        if (n && t.hasRenderSpan) {
                            const t = (0, h.et)(n).timestamp,
                                r = (0, U.zf)(),
                                s = Z({
                                    name: `<${e}>`,
                                    onlyIfParent: !0,
                                    op: Al,
                                    startTime: t,
                                    attributes: {
                                        [o.JD]: "auto.ui.react.profiler",
                                        "ui.component_name": e
                                    }
                                });
                            s && s.end(r)
                        }
                    })), [])
                }
                Dl.__initStatic();
                var Pl = n(92732);
                const Bl = "redux.action",
                    Ul = "info",
                    jl = {
                        attachReduxState: !0,
                        actionTransformer: e => e,
                        stateTransformer: e => e || null
                    };

                function zl(e) {
                    const t = { ...jl,
                        ...e
                    };
                    return e => (n, r) => {
                        t.attachReduxState && (0, C.m6)().addEventProcessor(((e, t) => {
                            try {
                                void 0 === e.type && "redux" === e.contexts.state.state.type && (t.attachments = [...t.attachments || [], {
                                    filename: "redux_state.json",
                                    data: JSON.stringify(e.contexts.state.state.value)
                                }])
                            } catch (e) {}
                            return e
                        }));
                        return e(((e, r) => {
                            const o = n(e, r),
                                s = (0, C.o5)(),
                                a = t.actionTransformer(r);
                            null != a && (0, i.Z)({
                                category: Bl,
                                data: a,
                                type: Ul
                            });
                            const c = t.stateTransformer(o);
                            if (null != c) {
                                const e = (0, C.KU)(),
                                    t = e && e.getOptions(),
                                    n = t && t.normalizeDepth || 3,
                                    r = {
                                        state: {
                                            type: "redux",
                                            value: c
                                        }
                                    };
                                (0, T.my)(r, "__sentry_override_normalization_depth__", 3 + n), s.setContext("state", r)
                            } else s.setContext("state", null);
                            const {
                                configureScopeWithState: u
                            } = t;
                            return "function" == typeof u && u(s, o), o
                        }), r)
                    }
                }

                function Hl(e) {
                    const t = Wu({ ...e,
                            instrumentPageLoad: !1,
                            instrumentNavigation: !1
                        }),
                        {
                            history: n,
                            routes: r,
                            match: s,
                            instrumentPageLoad: i = !0,
                            instrumentNavigation: a = !0
                        } = e;
                    return { ...t,
                        afterAllSetup(e) {
                            t.afterAllSetup(e), i && We.jf && We.jf.location && $l(r, We.jf.location, s, ((t, n = "url") => {
                                qu(e, {
                                    name: t,
                                    attributes: {
                                        [o.uT]: "pageload",
                                        [o.JD]: "auto.pageload.react.reactrouter_v3",
                                        [o.i_]: n
                                    }
                                })
                            })), a && n.listen && n.listen((t => {
                                "PUSH" !== t.action && "POP" !== t.action || $l(r, t, s, ((t, n = "url") => {
                                    Ju(e, {
                                        name: t,
                                        attributes: {
                                            [o.uT]: "navigation",
                                            [o.JD]: "auto.navigation.react.reactrouter_v3",
                                            [o.i_]: n
                                        }
                                    })
                                }))
                            }))
                        }
                    }
                }

                function $l(e, t, n, r) {
                    let o = t.pathname;
                    n({
                        location: t,
                        routes: e
                    }, ((e, t, n) => {
                        if (e || !n) return r(o);
                        const s = function(e) {
                            if (!Array.isArray(e) || 0 === e.length) return "";
                            const t = e.filter((e => !!e.path));
                            let n = -1;
                            for (let e = t.length - 1; e >= 0; e--) {
                                const r = t[e];
                                if (r.path && r.path.startsWith("/")) {
                                    n = e;
                                    break
                                }
                            }
                            return t.slice(n).filter((({
                                path: e
                            }) => !!e)).map((({
                                path: e
                            }) => e)).join("")
                        }(n.routes || []);
                        return 0 === s.length || "/*" === s ? r(o) : (o = s, r(o, "route"))
                    }))
                }

                function Wl(e, t = {}) {
                    const n = e,
                        r = Wu({ ...t,
                            instrumentNavigation: !1,
                            instrumentPageLoad: !1
                        }),
                        {
                            instrumentPageLoad: s = !0,
                            instrumentNavigation: i = !0
                        } = t;
                    return { ...r,
                        afterAllSetup(e) {
                            r.afterAllSetup(e);
                            const t = We.jf.location;
                            if (s && t) {
                                const r = n.matchRoutes(t.pathname, t.search, {
                                        preload: !1,
                                        throwOnError: !1
                                    }),
                                    s = r[r.length - 1];
                                qu(e, {
                                    name: s ? s.routeId : t.pathname,
                                    attributes: {
                                        [o.uT]: "pageload",
                                        [o.JD]: "auto.pageload.react.tanstack_router",
                                        [o.i_]: s ? "route" : "url",
                                        ...ql(s)
                                    }
                                })
                            }
                            i && n.subscribe("onBeforeNavigate", (t => {
                                if (t.toLocation.state === t.fromLocation.state) return;
                                const r = n.matchRoutes(t.toLocation.pathname, t.toLocation.search, {
                                        preload: !1,
                                        throwOnError: !1
                                    }),
                                    s = r[r.length - 1],
                                    i = We.jf.location,
                                    a = Ju(e, {
                                        name: s ? s.routeId : i.pathname,
                                        attributes: {
                                            [o.uT]: "navigation",
                                            [o.JD]: "auto.navigation.react.tanstack_router",
                                            [o.i_]: s ? "route" : "url"
                                        }
                                    }),
                                    c = n.subscribe("onResolved", (e => {
                                        if (c(), a) {
                                            const t = n.matchRoutes(e.toLocation.pathname, e.toLocation.search, {
                                                    preload: !1,
                                                    throwOnError: !1
                                                }),
                                                r = t[t.length - 1];
                                            r && (a.updateName(r.routeId), a.setAttribute(o.i_, "route"), a.setAttributes(ql(r)))
                                        }
                                    }))
                            }))
                        }
                    }
                }

                function ql(e) {
                    if (!e) return {};
                    const t = {};
                    return Object.entries(e.params).forEach((([e, n]) => {
                        t[`url.path.params.${e}`] = n
                    })), t
                }

                function Jl(e) {
                    const t = Wu({ ...e,
                            instrumentPageLoad: !1,
                            instrumentNavigation: !1
                        }),
                        {
                            history: n,
                            routes: r,
                            matchPath: o,
                            instrumentPageLoad: s = !0,
                            instrumentNavigation: i = !0
                        } = e;
                    return { ...t,
                        afterAllSetup(e) {
                            t.afterAllSetup(e), Vl(e, s, i, n, "reactrouter_v4", r, o)
                        }
                    }
                }

                function Kl(e) {
                    const t = Wu({ ...e,
                            instrumentPageLoad: !1,
                            instrumentNavigation: !1
                        }),
                        {
                            history: n,
                            routes: r,
                            matchPath: o,
                            instrumentPageLoad: s = !0,
                            instrumentNavigation: i = !0
                        } = e;
                    return { ...t,
                        afterAllSetup(e) {
                            t.afterAllSetup(e), Vl(e, s, i, n, "reactrouter_v5", r, o)
                        }
                    }
                }

                function Vl(e, t, n, r, s, i = [], a) {
                    function c(e) {
                        if (0 === i.length || !a) return [e, "url"];
                        const t = Xl(i, e, a);
                        for (const e of t)
                            if (e.match.isExact) return [e.match.path, "route"];
                        return [e, "url"]
                    }
                    if (t) {
                        const t = r && r.location ? r.location.pathname : We.jf && We.jf.location ? We.jf.location.pathname : void 0;
                        if (t) {
                            const [n, r] = c(t);
                            qu(e, {
                                name: n,
                                attributes: {
                                    [o.uT]: "pageload",
                                    [o.JD]: `auto.pageload.react.${s}`,
                                    [o.i_]: r
                                }
                            })
                        }
                    }
                    n && r.listen && r.listen(((t, n) => {
                        if (n && ("PUSH" === n || "POP" === n)) {
                            const [n, r] = c(t.pathname);
                            Ju(e, {
                                name: n,
                                attributes: {
                                    [o.uT]: "navigation",
                                    [o.JD]: `auto.navigation.react.${s}`,
                                    [o.i_]: r
                                }
                            })
                        }
                    }))
                }

                function Xl(e, t, n, r = []) {
                    return e.some((e => {
                        const o = e.path ? n(t, e) : r.length ? r[r.length - 1].match : function(e) {
                            return {
                                path: "/",
                                url: "/",
                                params: {},
                                isExact: "/" === e
                            }
                        }(t);
                        return o && (r.push({
                            route: e,
                            match: o
                        }), e.routes && Xl(e.routes, t, n, r)), !!o
                    })), r
                }

                function Yl(e) {
                    const t = e.displayName || e.name,
                        n = t => {
                            if (t && t.computedMatch && t.computedMatch.isExact) {
                                const e = t.computedMatch.path,
                                    n = function() {
                                        const e = (0, h.Bk)(),
                                            t = e && (0, h.zU)(e);
                                        if (!t) return;
                                        const n = (0, h.et)(t).op;
                                        return "navigation" === n || "pageload" === n ? t : void 0
                                    }();
                                (0, C.o5)().setTransactionName(e), n && (n.updateName(e), n.setAttribute(o.i_, "route"))
                            }
                            return Il.createElement(e, { ...t
                            })
                        };
                    return n.displayName = `sentryRoute(${t})`, Rl(n, e), n
                }
                var Gl = n(29882);
                let Ql, Zl, ed, td, nd, rd = !1;
                const od = new WeakSet;

                function sd(e) {
                    const t = Wu({ ...e,
                            instrumentPageLoad: !1,
                            instrumentNavigation: !1
                        }),
                        {
                            useEffect: n,
                            useLocation: r,
                            useNavigationType: s,
                            createRoutesFromChildren: i,
                            matchRoutes: a,
                            stripBasename: c,
                            instrumentPageLoad: u = !0,
                            instrumentNavigation: l = !0
                        } = e;
                    return { ...t,
                        setup() {
                            Ql = n, Zl = r, ed = s, nd = a, td = i, rd = c || !1
                        },
                        afterAllSetup(e) {
                            t.afterAllSetup(e);
                            const n = We.jf && We.jf.location && We.jf.location.pathname;
                            u && n && qu(e, {
                                name: n,
                                attributes: {
                                    [o.i_]: "url",
                                    [o.uT]: "pageload",
                                    [o.JD]: "auto.pageload.react.reactrouter_v6"
                                }
                            }), l && od.add(e)
                        }
                    }
                }

                function id(e, t) {
                    if (!t || "/" === t) return e;
                    if (!e.toLowerCase().startsWith(t.toLowerCase())) return e;
                    const n = t.endsWith("/") ? t.length - 1 : t.length,
                        r = e.charAt(n);
                    return r && "/" !== r ? e : e.slice(n) || "/"
                }

                function ad(e, t, n, r = "") {
                    if (!e || 0 === e.length) return [rd ? id(t.pathname, r) : t.pathname, "url"];
                    let o = "";
                    if (n)
                        for (const e of n) {
                            const n = e.route;
                            if (n) {
                                if (n.index) return [rd ? id(e.pathname, r) : e.pathname, "route"];
                                const s = n.path;
                                if (s) {
                                    const n = "/" === s[0] || "/" === o[o.length - 1] ? s : `/${s}`;
                                    if (o += n, r + e.pathname === t.pathname) return (0, St.c4)(o) !== (0, St.c4)(e.pathname) && "/*" !== o.slice(-2) ? [(rd ? "" : r) + n, "route"] : [(rd ? "" : r) + o, "route"]
                                }
                            }
                        }
                    return [rd ? id(t.pathname, r) : t.pathname, "url"]
                }

                function cd(e, t, n, r, s) {
                    const i = Array.isArray(r) ? r : nd(n, t, s);
                    if (i) {
                        const [r, a] = ad(n, t, i, s);
                        (0, C.o5)().setTransactionName(r), e && (e.updateName(r), e.setAttribute(o.i_, a))
                    }
                }

                function ud(e, t, n, r, s) {
                    const i = Array.isArray(r) ? r : nd(t, e, s),
                        a = (0, C.KU)();
                    if (a && od.has(a) && ("PUSH" === n || "POP" === n) && i) {
                        const [n, r] = ad(t, e, i, s);
                        Ju(a, {
                            name: n,
                            attributes: {
                                [o.i_]: r,
                                [o.uT]: "navigation",
                                [o.JD]: "auto.navigation.react.reactrouter_v6"
                            }
                        })
                    }
                }

                function ld(e) {
                    if (!(Ql && Zl && ed && td && nd)) return Gl.T && d.vF.warn(`reactRouterV6Instrumentation was unable to wrap Routes because of one or more missing parameters.\n      useEffect: ${Ql}. useLocation: ${Zl}. useNavigationType: ${ed}.\n      createRoutesFromChildren: ${td}. matchRoutes: ${nd}.`), e;
                    let t = !0;
                    const n = n => {
                        const r = Zl(),
                            o = ed();
                        return Ql((() => {
                            const e = td(n.children);
                            t ? (cd(hd(), r, e), t = !1) : ud(r, e, o)
                        }), [r, o]), Il.createElement(e, { ...n
                        })
                    };
                    return Rl(n, e), n
                }

                function dd(e) {
                    if (!(Ql && Zl && ed && nd)) return Gl.T && d.vF.warn("reactRouterV6Instrumentation was unable to wrap `useRoutes` because of one or more missing parameters."), e;
                    let t = !0;
                    const n = n => {
                        const {
                            routes: r,
                            locationArg: o
                        } = n, s = e(r, o), i = Zl(), a = ed(), c = "string" == typeof o || o && o.pathname ? o : i;
                        return Ql((() => {
                            const e = "string" == typeof c ? {
                                pathname: c
                            } : c;
                            t ? (cd(hd(), e, r), t = !1) : ud(e, r, a)
                        }), [a, c]), s
                    };
                    return (e, t) => Il.createElement(n, {
                        routes: e,
                        locationArg: t
                    })
                }

                function pd(e) {
                    return Ql && Zl && ed && nd ? function(t, n) {
                        const r = e(t, n),
                            o = n && n.basename,
                            s = hd();
                        return "POP" === r.state.historyAction && s && cd(s, r.state.location, t, void 0, o), r.subscribe((e => {
                            const n = e.location;
                            "PUSH" !== e.historyAction && "POP" !== e.historyAction || ud(n, t, e.historyAction, void 0, o)
                        })), r
                    } : (Gl.T && d.vF.warn("reactRouterV6Instrumentation was unable to wrap the `createRouter` function because of one or more missing parameters."), e)
                }

                function hd() {
                    const e = (0, h.Bk)(),
                        t = e ? (0, h.zU)(e) : void 0;
                    if (!t) return;
                    const n = (0, h.et)(t).op;
                    return "navigation" === n || "pageload" === n ? t : void 0
                }
            }
        }
    ]);
//# sourceMappingURL=sentry.c31b8d99e1a7d25fddad.js.map
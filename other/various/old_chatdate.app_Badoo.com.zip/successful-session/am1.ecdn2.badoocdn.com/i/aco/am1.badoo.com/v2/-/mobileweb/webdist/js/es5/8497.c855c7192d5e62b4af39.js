var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "20ec0656-6adc-47ab-bfc5-f3e804438c8c", e._sentryDebugIdIdentifier = "sentry-dbid-20ec0656-6adc-47ab-bfc5-f3e804438c8c")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "20ec0656-6adc-47ab-bfc5-f3e804438c8c", e._sentryDebugIdIdentifier = "sentry-dbid-20ec0656-6adc-47ab-bfc5-f3e804438c8c")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [8497], {
            26172: function(e, t, n) {
                n(62062), n(28706), n(72712), n(26099), n(25276), n(2008), n(26910);
                var o = n(85608),
                    r = n(47632),
                    a = n(18084),
                    i = a.A.getLogger("PromotionPageHelper"),
                    c = [50],
                    s = function() {
                        function e() {}
                        return e.getTitle = function(e) {
                            return e
                        }, e.getDataFromNotification = function(e) {
                            var t, n = null == e ? void 0 : e.image_urls,
                                o = null == n ? void 0 : n[0],
                                r = null == e ? void 0 : e.import_providers,
                                a = null == r || null == (t = r.providers) ? void 0 : t[0];
                            return {
                                avatars: [{
                                    significance: 1,
                                    src: o
                                }],
                                imageUrl: o,
                                providerType: null == a ? void 0 : a.type,
                                buttons: [{
                                    actionText: (null == e ? void 0 : e.action_text) || "",
                                    actionType: null == e ? void 0 : e.action,
                                    type: 1
                                }],
                                notificationId: null == e ? void 0 : e.id,
                                titleText: (null == e ? void 0 : e.title) || "",
                                messageText: (null == e ? void 0 : e.message) || "",
                                actionType: null == e ? void 0 : e.action,
                                cancelActionText: null == e ? void 0 : e.cancel_action_text,
                                actionText: null == e ? void 0 : e.action_text,
                                empathizedText: null == e ? void 0 : e.display_comment
                            }
                        }, e.getDataFromPrePurchaseInfo = function(e) {
                            if (e) {
                                var t = e.application_feature || {},
                                    n = null == t ? void 0 : t.feature,
                                    a = e.album,
                                    i = (null == a ? void 0 : a.photos) || [],
                                    c = Boolean(a) ? i.map((function(e) {
                                        var t = u(e);
                                        return {
                                            src: e.large_url,
                                            badgeType: t,
                                            badgeName: r.A.getBadgeName(t),
                                            significance: 2
                                        }
                                    })) : [],
                                    s = (t.display_images || []).map((function(e) {
                                        var t = u(e);
                                        return {
                                            src: e.display_images,
                                            badgeType: t,
                                            badgeName: r.A.getBadgeName(t),
                                            significance: 2
                                        }
                                    })),
                                    l = t.product_type,
                                    d = c.concat(s),
                                    p = o.A.getPromoBlockForProduct(l),
                                    f = d.slice(0, 3),
                                    m = null;
                                return 3 === f.length && ((m = f[1]).badgeName = r.A.getBadgeTypeFromPromoBlock(p), m.significance = 1), {
                                    avatars: f,
                                    buttons: [{
                                        actionText: t.display_action || "",
                                        actionType: t.required_action,
                                        type: 1
                                    }],
                                    featureName: o.A.getFeatureName(p),
                                    costOfService: e.cost,
                                    cost: t.payment_amount,
                                    featureType: n,
                                    messageText: t.display_message || "",
                                    pageTitle: e.header,
                                    productType: l,
                                    sharingPicture: m ? m.src : void 0,
                                    titleText: t.display_title || ""
                                }
                            }
                        }, e.getDataFromPromoBlock = function(e, t) {
                            var n;
                            void 0 === t && (t = !1);
                            var a = function(e) {
                                    var t = (e.pictures || []).sort(l).map((function(e) {
                                        var t = e.badge_type || 1;
                                        return {
                                            badgeName: r.A.getBadgeName(t),
                                            badgeType: t,
                                            significance: e.significance || -1,
                                            src: e.display_images
                                        }
                                    }));
                                    3 === t.length && (t = [t[2], t[0], t[1]]);
                                    return t
                                }(e),
                                i = e.promo_block_type,
                                c = e.ok_payment_product_type,
                                s = function(e) {
                                    var t = e.buttons || [];
                                    if (t.length) return t.filter((function(e) {
                                        return 4 !== e.type
                                    })).map((function(t) {
                                        var n = t.product_type || e.ok_payment_product_type,
                                            o = t.redirect_page;
                                        return {
                                            actionText: t.text || "",
                                            actionType: t.action,
                                            type: t.type,
                                            productType: n,
                                            redirectPage: null == o ? void 0 : o.redirect_page,
                                            isPremiumPlus: 47 === n
                                        }
                                    }));
                                    var n = [];
                                    n.push({
                                        actionText: e.action || "",
                                        actionType: e.ok_action
                                    }), e.other_text && e.other_action && n.push({
                                        actionText: e.other_text,
                                        actionType: e.other_action
                                    });
                                    return n
                                }(e),
                                u = (e.extra_texts || []).reduce((function(e, t) {
                                    switch (t.type) {
                                        case 11:
                                            e.inBetweenText = t.text;
                                            break;
                                        case 28:
                                            e.offerText = t.text;
                                            break;
                                        case 31:
                                            e.disclaimerText = t.text
                                    }
                                    return e
                                }), {});
                            return {
                                avatars: a,
                                buttonName: o.A.getButtonName(i),
                                buttons: s,
                                cost: e.payment_amount,
                                costOfService: e.credits_cost,
                                extraTexts: u,
                                featureName: o.A.getFeatureName(i, t),
                                featureType: c && o.A.getFeatureFromPaymentProductType(c),
                                messageText: e.mssg || "",
                                pageTitle: e.screen_header || e.header,
                                productType: c,
                                sharingPicture: a.length ? (a[1] || a[0]).src : void 0,
                                titleText: e.header || "",
                                promoBlockType: i,
                                redirectPage: null == (n = e.redirect_page) ? void 0 : n.redirect_page
                            }
                        }, e.getDataFromCorrectSource = function(t) {
                            var n = t.clientNotification,
                                o = t.prePurchaseInfo,
                                r = t.promoBlock,
                                a = t.twoTiersIsAvailable;
                            if (n || o || r) {
                                if (n) {
                                    var s = n.type;
                                    return 81 === s || 89 === s ? e.getDataFromPromoBlock(n.promo_block) : s && -1 === c.indexOf(s) ? e.getDataFromPrePurchaseInfo(n.purchase_info) : e.getDataFromNotification(n)
                                }
                                return o ? e.getDataFromPrePurchaseInfo(o) : r ? e.getDataFromPromoBlock(r, a) : void 0
                            }
                            i.error("Invalid arguments, expected Notification, PrePurchaseInfo or PromoBlock object")
                        }, e
                    }();

                function l(e, t) {
                    return (e.significance || -1) < (t.significance || -1) ? -1 : (e.significance || -1) > (t.significance || -1) ? 1 : 0
                }

                function u(e) {
                    return (null == e ? void 0 : e.badge_type) || 1
                }
                t.A = s
            },
            51265: function(e, t, n) {
                n(28706), n(10287);
                var o = n(35837),
                    r = n(85558),
                    a = n(31190),
                    i = n(15566);

                function c(e, t) {
                    return c = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, c(e, t)
                }
                var s = function(e) {
                    var t, n;

                    function r() {
                        for (var t, n = arguments.length, o = new Array(n), r = 0; r < n; r++) o[r] = arguments[r];
                        return (t = e.call.apply(e, [this].concat(o)) || this).notification = void 0, t
                    }
                    n = e, (t = r).prototype = Object.create(n.prototype), t.prototype.constructor = t, c(t, n);
                    var s = r.prototype;
                    return s.componentDidMount = function() {
                        if (e.prototype.componentDidMount.call(this), "string" != typeof this.getParameter("notification")) {
                            var t = this.getParameter("notification");
                            t && (this.notification = (0, o.A)(t))
                        }
                    }, s.notifyHandler = function() {
                        var e;
                        this.notification instanceof i.z5N && "string" == typeof(null == (e = this.notification) ? void 0 : e.getId()) && a.A.getInstance().notificationHandled(this.notification.getId())
                    }, r
                }(r.A);
                t.A = s
            },
            73648: function(e, t, n) {
                n(45700), n(89572), n(52675), n(89463), n(26099), n(2892), n(84185), n(79432), n(2008), n(83851), n(51629), n(23500), n(81278), n(67945);
                var o = n(32485),
                    r = n.n(o),
                    a = n(28244),
                    i = n(74848);

                function c(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var o = Object.getOwnPropertySymbols(e);
                        t && (o = o.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, o)
                    }
                    return n
                }

                function s(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? c(Object(n), !0).forEach((function(t) {
                            l(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function l(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var o = n.call(e, t || "default");
                                if ("object" != typeof o) return o;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                t.A = function(e) {
                    var t = e.linkAppstore,
                        n = e.imageSrc,
                        o = e.jsClass,
                        c = e.a11y,
                        l = r()({
                            "badge-appstore": !0
                        }, o);
                    return (0, i.jsx)(a.A, s(s({}, t), {}, {
                        className: l,
                        children: (0, i.jsx)("img", {
                            className: "badge-appstore__image",
                            src: n,
                            alt: c.label
                        })
                    }))
                }
            },
            80878: function(e, t, n) {
                n.r(t), n.d(t, {
                    default: function() {
                        return ye
                    }
                });
                n(28706), n(10287);
                var o, r = n(58385),
                    a = n(56368),
                    i = n(51265),
                    c = n(96540),
                    s = n(31709),
                    l = n(74389),
                    u = n(93529),
                    d = n(79860),
                    p = (n(62062), n(40075)),
                    f = (n(45700), n(89572), n(52675), n(89463), n(26099), n(2892), n(84185), n(79432), n(2008), n(83851), n(51629), n(23500), n(81278), n(67945), n(69020)),
                    m = n(47901),
                    g = n(87184),
                    v = n(11734),
                    x = n(4571),
                    b = n(46770),
                    _ = n(40578),
                    T = n(27895),
                    y = n(30784),
                    A = n(20017),
                    h = n(32483),
                    E = n(26914),
                    O = n(31023),
                    k = n(8483),
                    P = n(85608),
                    j = n(93827),
                    I = n(36693),
                    N = n(74026),
                    S = n(74848);

                function w(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var o = Object.getOwnPropertySymbols(e);
                        t && (o = o.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, o)
                    }
                    return n
                }

                function C(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? w(Object(n), !0).forEach((function(t) {
                            B(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : w(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function B(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var o = n.call(e, t || "default");
                                if ("object" != typeof o) return o;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var R = ((o = {})[P.T.ATTENTION_BOOST] = "default", o[P.T.BUNDLE_SALE] = "default", o[P.T.CHAT_WITH_NEWBIES] = "default", o[P.T.CHAT_WITH_TIRED] = "default", o[P.T.CRUSH] = "revenue", o[P.T.EXTRA_SHOWS] = "default", o[P.T.GET_VERIFIED] = "default", o[P.T.LIKED_YOU] = "default", o[P.T.QUESTIONS_IN_PROFILE] = "default", o[P.T.RISEUP] = "default", o[P.T.SPECIAL_DELIVERY] = "revenue", o[P.T.SPP] = "revenue", o[P.T.UNDO_VOTE] = "revenue", o[P.T.LIKED_YOU_PREMIUM_PLUS] = "default", o),
                    D = function(e) {
                        var t, n, o = e.avatars,
                            r = e.hasSameSignificance,
                            a = e.zeroEncounters,
                            i = e.gender;
                        return t = 1 === o.length ? "single" : "triple", n = r ? "m-m-m" : "s-m-s", o.length ? (0, S.jsx)(T.A, {
                            children: (0, S.jsx)("div", {
                                style: {
                                    position: "relative"
                                },
                                children: (0, S.jsx)(O.A, {
                                    layout: t,
                                    variant: n,
                                    children: o.map((function(e, n) {
                                        var o = "single" === t ? "md" : void 0,
                                            r = {};
                                        e.src && (r.photo = {
                                            src: e.src
                                        }), i && (r.gender = i);
                                        var a = e.badgeName ? {
                                            position: "bc",
                                            icon: {
                                                name: e.badgeName,
                                                size: "lg"
                                            }
                                        } : void 0;
                                        return (0, S.jsx)(E.A, {
                                            size: o,
                                            user: r,
                                            badge: a
                                        }, n)
                                    }))
                                })
                            })
                        }) : a ? (0, S.jsx)(T.A, {
                            size: "icon",
                            children: (0, S.jsx)(k.A, {
                                name: "badge-encounters"
                            })
                        }) : null
                    },
                    L = function(e, t) {
                        return {
                            "data-action-type": (t = C(C({}, e), t)).actionType,
                            "data-activation-place": t.activationPlace,
                            "data-button-name": t.buttonName,
                            "data-cost": t.cost,
                            "data-feature-type": t.featureType,
                            "data-from": t.from,
                            "data-notification-id": t.notificationId,
                            "data-product-type": t.productType,
                            "data-promo-block-type": t.promoBlockType,
                            "data-provider-type": t.providerType,
                            "data-has-extra-shows": t.hasExtraShows,
                            "data-redirect-page": t.redirectPage,
                            "data-sharing-picture": t.sharingPicture,
                            "data-user-id": t.userId
                        }
                    },
                    U = function(e, t, n) {
                        void 0 === n && (n = !1);
                        var o, r = C(C({}, e), t);
                        return o = r.isPremiumPlus ? "continue-premium-button" : n ? "close-button" : "continue-button", {
                            "data-qa-button": n && !r.isPremiumPlus ? "secondary" : r.featureName,
                            "data-qa": o
                        }
                    },
                    M = function(e) {
                        var t, n = e.featureName,
                            o = e.buttons,
                            r = e.hideCloseButton,
                            a = e.extrasText,
                            i = e.hasExtraShows,
                            s = e.isTwoTiersAvailable,
                            l = e.onBackClick,
                            u = e.onClick,
                            d = null == (t = o[1]) ? void 0 : t.isPremiumPlus,
                            m = {
                                0: s && null != a && a.inBetweenText || d ? "secondary" : "primary",
                                1: s && null != a && a.inBetweenText || d ? "primary" : "secondary",
                                2: "tertiary"
                            };
                        return o.length <= 2 && r && (m[1] = "tertiary"), (0, S.jsxs)(b.A, {
                            children: [o.map((function(t, o) {
                                if (0 === o) {
                                    var l = void 0 !== n ? function(e, t) {
                                        if (t || P.T.LIKED_YOU_PREMIUM_PLUS !== e) return R[e]
                                    }(n, i) : void 0;
                                    return (0, S.jsxs)(c.Fragment, {
                                        children: [(0, S.jsx)(A.A, {
                                            semantic: m[o],
                                            styling: l,
                                            text: t.actionText,
                                            extraAttrs: L(e, t),
                                            dataQA: U(e, t),
                                            extraClass: "js-action",
                                            onClick: function() {
                                                return u(t)
                                            }
                                        }, "button-" + o), s && null != a && a.inBetweenText ? (0, S.jsx)(I.A, {
                                            top: "sm",
                                            children: (0, S.jsx)(N.A, {
                                                text: null == a ? void 0 : a.inBetweenText
                                            })
                                        }) : null]
                                    }, o)
                                }
                                return (0, S.jsxs)(c.Fragment, {
                                    children: [null != a && a.offerText ? (0, S.jsx)(I.A, {
                                        top: "sm",
                                        bottom: "sm",
                                        children: (0, S.jsx)(j.P2, {
                                            children: null == a ? void 0 : a.offerText
                                        })
                                    }) : null, r ? (0, S.jsx)(A.A, {
                                        semantic: m[o],
                                        text: t.actionText,
                                        extraAttrs: L(e, t),
                                        dataQA: U(e, t, !0),
                                        extraClass: "js-navigation js-action",
                                        onClick: function() {
                                            return u(t)
                                        }
                                    }, "button-" + o) : (0, S.jsx)(A.A, {
                                        semantic: m[o],
                                        text: t.actionText,
                                        extraAttrs: L(e, t),
                                        dataQA: U(e, t, !0),
                                        extraClass: "js-action",
                                        onClick: function() {
                                            return u(t)
                                        }
                                    }, "button-" + o)]
                                }, o)
                            })), r ? null : (0, S.jsx)(A.A, {
                                semantic: "tertiary",
                                text: p.Ay.get(650),
                                extraAttrs: {
                                    "data-action": f.A.CLOSE
                                },
                                dataQA: U(e, {}, !0),
                                extraClass: "js-navigation",
                                onClick: function() {
                                    return l()
                                }
                            })]
                        })
                    },
                    F = function(e) {
                        var t = e.titleText,
                            n = e.messageText,
                            o = e.costOfService;
                        return (0, S.jsxs)(m.A, {
                            children: [(0, S.jsx)(g.A, {
                                hpadded: !0,
                                vpadded: !0,
                                align: "center",
                                children: (0, S.jsxs)(x.A, {
                                    children: [(0, S.jsx)(D, {
                                        avatars: e.hasOneAvatar ? e.avatars.slice(0, 1) : e.avatars,
                                        hasSameSignificance: e.hasSameSignificance,
                                        zeroEncounters: e.zeroEncounters,
                                        gender: e.gender
                                    }), (0, S.jsx)(_.A, {
                                        text: t,
                                        tag: "h1"
                                    }), (0, S.jsx)(y.A, {
                                        text: n
                                    }), (0, S.jsx)(M, C(C({}, e), {}, {
                                        featureName: e.featureName,
                                        buttons: e.buttons,
                                        hideCloseButton: e.hideCloseButton
                                    }))]
                                })
                            }), o ? (0, S.jsx)(v.A, {
                                hpadded: !0,
                                vpadded: !0,
                                children: (0, S.jsx)(h.A, {
                                    children: o
                                })
                            }) : null]
                        })
                    },
                    K = function(e) {
                        var t, n = e.titleText,
                            o = e.messageText,
                            r = e.costOfService,
                            a = e.buttons;
                        return (0, S.jsxs)(m.A, {
                            children: [(0, S.jsx)(g.A, {
                                hpadded: !0,
                                vpadded: !0,
                                align: "center",
                                children: (0, S.jsxs)(x.A, {
                                    children: [(0, S.jsx)(T.A, {
                                        size: "icon",
                                        children: (0, S.jsx)(k.A, {
                                            name: "badge-feature-invisible-mode"
                                        })
                                    }), (0, S.jsx)(_.A, {
                                        text: (0, S.jsx)("span", {
                                            className: "qa-title",
                                            children: n
                                        }),
                                        tag: "h1"
                                    }), (0, S.jsx)(y.A, {
                                        text: (0, S.jsx)("span", {
                                            className: "qa-message",
                                            children: o
                                        })
                                    }), (0, S.jsxs)(b.A, {
                                        children: [a.map((function(t, n) {
                                            return (0, S.jsx)(A.A, {
                                                styling: "revenue",
                                                text: t.actionText,
                                                extraAttrs: L(e, t),
                                                dataQA: U(e, t, !1),
                                                extraClass: "js-action"
                                            }, "button-" + n)
                                        })), (0, S.jsx)(A.A, {
                                            semantic: "tertiary",
                                            text: p.Ay.get(650),
                                            extraAttrs: {
                                                "data-action": null == (t = e.NAVIGATION_BUTTONS) ? void 0 : t.CLOSE
                                            },
                                            extraClass: "js-navigation"
                                        })]
                                    })]
                                })
                            }), r ? (0, S.jsx)(v.A, {
                                hpadded: !0,
                                vpadded: !0,
                                children: (0, S.jsx)(h.A, {
                                    children: r
                                })
                            }) : null]
                        })
                    },
                    G = n(47632),
                    H = n(51634),
                    z = function(e) {
                        var t, n, o = e.imageUrl,
                            r = e.providerType,
                            a = e.titleText,
                            i = e.messageText,
                            c = e.empathizedText,
                            s = e.cancelActionText,
                            l = e.buttons,
                            u = e.PROVIDER_TYPES,
                            d = e.onBackClick,
                            p = e.onClick;
                        switch (o && (t = {
                            photo: {
                                src: G.A.getImageUrlForSize(o, 100)
                            }
                        }), r) {
                            case u.FACEBOOK:
                                n = {
                                    icon: "badge-provider-facebook"
                                };
                                break;
                            case u.VKONTAKTE:
                                n = {
                                    icon: "badge-provider-vkontakte"
                                };
                                break;
                            case u.ODNOKLASSNIKI:
                                n = {
                                    icon: "badge-provider-odnoklassniki"
                                };
                                break;
                            case u.GOOGLE:
                                n = {
                                    icon: "badge-provider-google"
                                };
                                break;
                            case u.TWITTER:
                                n = {
                                    icon: "badge-provider-twitter"
                                };
                                break;
                            case u.INSTAGRAM:
                                n = {
                                    icon: "badge-provider-instagram"
                                };
                                break;
                            case u.LINKEDIN:
                                n = {
                                    icon: "badge-provider-linkedin"
                                };
                                break;
                            default:
                                n = {}
                        }
                        return (0, S.jsx)(m.A, {
                            children: (0, S.jsx)(g.A, {
                                hpadded: !0,
                                vpadded: !0,
                                align: "center",
                                children: (0, S.jsxs)(x.A, {
                                    children: [(0, S.jsx)(T.A, {
                                        children: (0, S.jsx)(E.A, {
                                            size: "md",
                                            user: t,
                                            badge: n.icon ? {
                                                icon: {
                                                    name: n.icon
                                                }
                                            } : void 0
                                        })
                                    }), (0, S.jsx)(_.A, {
                                        text: a,
                                        tag: "h1"
                                    }), (0, S.jsx)(y.A, {
                                        text: i
                                    }), (0, S.jsx)(H.A, {
                                        children: (0, S.jsx)(j.P1, {
                                            weight: "bolder",
                                            color: "gray-80",
                                            breakWords: !0,
                                            children: c
                                        })
                                    }), (0, S.jsxs)(b.A, {
                                        children: [l.map((function(t, n) {
                                            return (0, S.jsx)(A.A, {
                                                styling: "revenue",
                                                text: t.actionText,
                                                extraAttrs: L(e, t),
                                                dataQA: U(e, t, !1),
                                                extraClass: "js-action",
                                                onClick: function() {
                                                    return p(t)
                                                }
                                            }, "button-" + n)
                                        })), (0, S.jsx)(A.A, {
                                            semantic: "tertiary",
                                            text: s,
                                            extraClass: "js-navigation",
                                            onClick: d,
                                            extraAttrs: {
                                                "data-action": "CLOSE"
                                            }
                                        })]
                                    })]
                                })
                            })
                        })
                    },
                    V = n(73648),
                    X = function(e) {
                        var t = e.src,
                            n = e.titleText,
                            o = e.messageText,
                            r = e.linkAppstore,
                            a = e.appstoreImage,
                            i = e.onBackClick;
                        return (0, S.jsx)(m.A, {
                            children: (0, S.jsx)(g.A, {
                                hpadded: !0,
                                vpadded: !0,
                                align: "center",
                                children: (0, S.jsxs)(x.A, {
                                    children: [(0, S.jsx)(T.A, {
                                        children: (0, S.jsx)(E.A, {
                                            size: "md",
                                            image: {
                                                src: G.A.getImageUrlForSize(t, 100)
                                            },
                                            badge: {
                                                icon: {
                                                    name: "badge-video"
                                                }
                                            }
                                        })
                                    }), (0, S.jsx)(_.A, {
                                        text: n,
                                        tag: "h1"
                                    }), (0, S.jsx)(y.A, {
                                        text: o
                                    }), (0, S.jsxs)(b.A, {
                                        children: [(0, S.jsx)(V.A, {
                                            jsClass: "js-app-store",
                                            imageSrc: a.src,
                                            linkAppstore: r,
                                            a11y: {
                                                label: a.label
                                            }
                                        }), (0, S.jsx)(A.A, {
                                            semantic: "tertiary",
                                            text: p.Ay.get(451),
                                            extraAttrs: {
                                                "data-action": f.A.CLOSE
                                            },
                                            dataQA: {
                                                "data-qa": "dismiss"
                                            },
                                            extraClass: "js-navigation",
                                            onClick: i
                                        })]
                                    })]
                                })
                            })
                        })
                    },
                    W = function(e) {
                        var t = e.title,
                            n = e.buttons,
                            o = e.onBackClick,
                            r = e.onClick;
                        return (0, S.jsx)("div", {
                            className: "promo-card promo-card--survey",
                            children: (0, S.jsxs)("div", {
                                className: "promo-card__inner",
                                children: [(0, S.jsx)("button", {
                                    className: "promo-card__close js-action",
                                    "data-promo-block-type": e.promoBlockType,
                                    "data-dismiss": !0,
                                    onClick: o,
                                    children: (0, S.jsx)(k.A, {
                                        name: "generic-close",
                                        size: "md",
                                        a11y: {
                                            label: p.Ay.get(268)
                                        }
                                    })
                                }), (0, S.jsxs)("div", {
                                    className: "promo-card__content",
                                    children: [(0, S.jsx)("div", {
                                        className: "promo-card__title",
                                        children: (0, S.jsx)(j.Zb, {
                                            align: "center",
                                            tag: "h1",
                                            children: t
                                        })
                                    }), n.map((function(t) {
                                        return (0, S.jsx)("div", {
                                            className: "promo-card__action",
                                            children: (0, S.jsx)("button", {
                                                className: "promo-card__button js-action",
                                                "data-answer-id": t.id,
                                                "data-promo-block-type": e.promoBlockType,
                                                onClick: function() {
                                                    return r(t)
                                                },
                                                children: (0, S.jsx)(j.P1, {
                                                    children: t.text
                                                })
                                            }, t.id)
                                        })
                                    }))]
                                })]
                            })
                        })
                    },
                    Y = n(19049),
                    q = n(13614),
                    J = {
                        FACEBOOK: 1,
                        VKONTAKTE: 2,
                        ODNOKLASSNIKI: 3,
                        GOOGLE: 4,
                        TWITTER: 15,
                        INSTAGRAM: 12,
                        LINKEDIN: 14
                    },
                    Q = function(e) {
                        var t = e.data,
                            n = e.externalUrl,
                            o = e.hasExtraShows,
                            r = e.productMode,
                            a = e.src,
                            i = e.isTwoTiersAvailable,
                            c = e.onBackClick,
                            s = e.onClick,
                            l = t.avatars,
                            u = t.buttons,
                            d = t.cancelActionText,
                            p = t.costOfService,
                            f = t.empathizedText,
                            m = t.hideCloseButton,
                            g = t.imageUrl,
                            v = t.messageText,
                            x = t.mode,
                            b = t.promoBlockType,
                            _ = t.providerType,
                            T = t.titleText,
                            y = (0, q.Je)();
                        switch (r || x) {
                            case Y.J.INVISIBLE_MODE:
                                return (0, S.jsx)(K, {
                                    buttons: u,
                                    messageText: v,
                                    titleText: T
                                });
                            case Y.J.NICE_NAME:
                                return (0, S.jsx)(z, {
                                    buttons: u,
                                    cancelActionText: d,
                                    empathizedText: f,
                                    imageUrl: g,
                                    messageText: v,
                                    providerType: _,
                                    titleText: T,
                                    onBackClick: c,
                                    onClick: s,
                                    PROVIDER_TYPES: J
                                });
                            case Y.J.VIDEO_CHAT_EXPLANATION:
                                return (0, S.jsx)(X, {
                                    appstoreImage: y,
                                    linkAppstore: {
                                        href: n,
                                        target: "_blank",
                                        onClick: c
                                    },
                                    messageText: v,
                                    titleText: T,
                                    src: a,
                                    onBackClick: c
                                });
                            case Y.J.USER_SURVEY:
                                return (0, S.jsx)(W, {
                                    buttons: u,
                                    title: T,
                                    onClick: s,
                                    onBackClick: c
                                });
                            default:
                                return (0, S.jsx)(F, {
                                    avatars: l,
                                    buttons: u,
                                    costOfService: p,
                                    hideCloseButton: m,
                                    messageText: v,
                                    promoBlockType: b,
                                    titleText: T,
                                    hasExtraShows: o,
                                    isTwoTiersAvailable: i,
                                    onBackClick: c,
                                    onClick: s
                                })
                        }
                    },
                    Z = n(18084),
                    $ = n(51438),
                    ee = n(15566);

                function te(e, t, n, o) {
                    (0, d.sx)(138, {
                        banner_id: e,
                        position_id: t,
                        context: n,
                        variation_id: o
                    })
                }

                function ne(e, t, n, o) {
                    (0, d.sx)(139, {
                        banner_id: e,
                        position_id: t,
                        context: n,
                        variation_id: o,
                        call_to_action_type: 1
                    })
                }

                function oe(e, t) {
                    var n = e.promo_block;
                    new s.Ay(278, {
                        promo_banner_stats: {
                            event: t,
                            promo_block_type: null == n ? void 0 : n.promo_block_type,
                            promo_block_position: null == n ? void 0 : n.promo_block_position,
                            variant_id: null == n ? void 0 : n.variant_id
                        }
                    }).request()
                }
                n(15086), n(88431);
                var re = n(72537),
                    ae = n(73090),
                    ie = n(26172);

                function ce(e) {
                    var t, n, o, a = re.A.getSync(19),
                        i = e.clientNotification,
                        c = e.prePurchaseInfo,
                        s = e.promoBlock,
                        l = e.isTwoTiersAvailable,
                        u = e.productMode,
                        d = ie.A.getDataFromCorrectSource({
                            clientNotification: i,
                            prePurchaseInfo: c,
                            promoBlock: s,
                            isTwoTiersAvailable: l
                        }),
                        p = d.avatars;
                    if (d.hasBadges = p.some((function(e) {
                            return !!e.badgeName
                        })), d.hasSameSignificance = p.every((function(e) {
                            return e.significance === p[0].significance
                        })), d.hasOneAvatar = 1 === p.length, d.gender = (0, q.v4)(null == (t = ae.A.getUser()) ? void 0 : t.gender), d.from = r.A.getUrl(), d.sppEnabled = a.enabled, s && d.featureType && (d.hotPanelPaymentFlowId = (o = (n = s).ok_payment_product_type, (0, $.Im)(null, o, 77, {
                            credits_cost: n.payment_amount || 0,
                            promo_option: !0
                        }))), 326 === d.promoBlockType && (d.avatars[1].badgeName = "badge-feature-liked-you", d.hideCloseButton = !0), 48 === d.promoBlockType && (d.zeroEncounters = !0), 107 === d.promoBlockType) {
                        var f, m, g = null == i || null == (f = i.promo_block) || null == (f = f.survey) || null == (f = f.questions) ? void 0 : f[0];
                        d.mode = Y.J.USER_SURVEY, d.titleText = (null == g ? void 0 : g.question_text) || "", d.buttons = (null == g || null == (m = g.answers) ? void 0 : m.map((function(e) {
                            return {
                                id: e.answer_id,
                                text: e.answer_text
                            }
                        }))) || []
                    }
                    return u === Y.J.MMG_PROMO && (d.buttons = d.buttons.filter((function(e) {
                        return 1 === e.type
                    }))), d
                }
                var se, le, ue = n(25093),
                    de = n(41298),
                    pe = n(26935),
                    fe = n(3208),
                    me = n(64058),
                    ge = Z.A.getLogger("PromotionPage"),
                    ve = function(e) {
                        var t = e.activationPlace,
                            n = e.externalUrl,
                            o = e.notification,
                            i = e.productMode,
                            p = e.prePurchaseInfo,
                            f = e.promoBlock,
                            m = e.src,
                            g = e.userId,
                            v = e.hasExtraShows,
                            x = e.isTwoTiersAvailable,
                            b = (0, c.useMemo)((function() {
                                return ce({
                                    clientNotification: o,
                                    prePurchaseInfo: p,
                                    promoBlock: f,
                                    isTwoTiersAvailable: x,
                                    productMode: i
                                })
                            }), [o, f, p, x, i]);
                        (0, c.useEffect)((function() {
                            i === Y.J.MMG_PROMO && ((0, d.sx)(258, {
                                element: 14
                            }), (0, d.sx)(150, {
                                promo_screen: 84
                            }), oe(o, 2))
                        }), [o, i]), (0, c.useEffect)((function() {
                            switch (b.promoBlockType) {
                                case 326:
                                    te(null == f ? void 0 : f.promo_block_type, null == f ? void 0 : f.promo_block_position, 3);
                                    break;
                                case 48:
                                    te(null == f ? void 0 : f.promo_block_type, null == f ? void 0 : f.promo_block_position, null == f ? void 0 : f.context, 1);
                                    break;
                                case 107:
                                case 195:
                                    te(null == f ? void 0 : f.promo_block_type, null == f ? void 0 : f.promo_block_position, null == f ? void 0 : f.context, null == f ? void 0 : f.stats_variation_id);
                                    break;
                                case 165:
                                    (0, d.sx)(332, {
                                        element: 288,
                                        parent_element: 14
                                    }), (0, d.sx)(244, {
                                        promo_screen: 84
                                    })
                            }
                        }), [b, f]);
                        var _ = function() {
                                i === Y.J.MMG_PROMO && ((0, d.sx)(332, {
                                    element: 65,
                                    parent_element: 14
                                }), oe(o, 4)), r.A.back(), a.A.getInstance().enableTooltips(a.A.BLOCKER_TYPES.PROMO)
                            },
                            T = function() {
                                var e = b.featureType,
                                    n = b.cost,
                                    o = b.from,
                                    r = b.productType;
                                if (e) {
                                    var a = {
                                        activationPlace: t,
                                        cost: n,
                                        existingPaymentFlowId: b.hotPanelPaymentFlowId,
                                        feature: e,
                                        promoBlockType: null == f ? void 0 : f.promo_block_type
                                    };
                                    pe.A.purchase({
                                        back: o,
                                        cost: n,
                                        featureType: e,
                                        hotPanelData: a,
                                        popState: !0,
                                        productType: r,
                                        userId: g,
                                        paymentTransitionInFlow: !0,
                                        complete: function(e, t, n) {
                                            e && null != n && n.isOneClickPayment ? _() : t || function(e) {
                                                e && (0, ue.A)(e) && ge.error(e);
                                                e instanceof de.k || (u.A.showNotification({
                                                    type: u.A.TYPES.ERROR
                                                }), _())
                                            }()
                                        }
                                    })
                                } else ge.error("Invalid feature type")
                            },
                            y = function(e) {
                                var n = e.actionType,
                                    o = e.redirectPage,
                                    r = e.productType,
                                    a = b.cost,
                                    i = b.from,
                                    c = {
                                        action: n,
                                        activationPlace: t,
                                        banner: null == f ? void 0 : f.promo_block_type,
                                        cost: a,
                                        popState: !0,
                                        productType: r,
                                        paymentTransitionInFlow: !0
                                    };
                                o && (c.redirectPage = function(e) {
                                    return (new ee.gGJ).setRedirectPage(e)
                                }(o)), P.A.handlePromoSelected(c, {
                                    from: i
                                })
                            };
                        return b ? (0, S.jsx)("div", {
                            className: i,
                            children: (0, S.jsx)(Q, {
                                data: b,
                                externalUrl: n,
                                hasExtraShows: v,
                                productMode: i,
                                src: m,
                                isTwoTiersAvailable: x,
                                onBackClick: function() {
                                    107 === b.promoBlockType && oe(o, 4), b.hotPanelPaymentFlowId && (0, $.Np)(b.hotPanelPaymentFlowId, $.QO.CANCELLED), _()
                                },
                                onClick: function(e) {
                                    var t, n, a, i, c, p, m, g = e.actionType;
                                    if (fe.A.generate(), b.buttonName && (0, d.sx)(38, {
                                            button_name: b.buttonName
                                        }), 326 === b.promoBlockType && ne(null == f ? void 0 : f.promo_block_type, null == f ? void 0 : f.promo_block_position, 3), 195 === b.promoBlockType) {
                                        var v = o.promo_block;
                                        return ne(null == v ? void 0 : v.promo_block_type, null == v ? void 0 : v.promo_block_position, null == v ? void 0 : v.context), void r.A.navigate(l.x.SECURITY_WALKTHROUGH_REDIRECT, {
                                            securityWalkthroughSource: l.x.ENCOUNTERS
                                        })
                                    }
                                    if (107 === b.promoBlockType) return c = e.id, new s.Ay(450, {
                                        context: 45,
                                        answers: [{
                                            question_id: 0,
                                            answer_id: c || 0
                                        }]
                                    }).request(), ne(null == o || null == (t = o.promo_block) ? void 0 : t.promo_block_type, null == o || null == (n = o.promo_block) ? void 0 : n.promo_block_position, null == o || null == (a = o.promo_block) ? void 0 : a.context, null == o || null == (i = o.promo_block) ? void 0 : i.stats_variation_id), _();
                                    switch (g) {
                                        case 60:
                                            p = b.notificationId, m = b.providerType, new s.Ay(402, {
                                                value: p
                                            }).onResponse(387, (function(e) {
                                                e && u.A.showNotification({
                                                    type: u.A.TYPES.ERROR
                                                })
                                            })).request(), m && (0, d.sx)(153, {
                                                social_media: me.A[m]
                                            }), _();
                                            break;
                                        case 9:
                                            T();
                                            break;
                                        case 77:
                                        case 20:
                                            _();
                                            break;
                                        default:
                                            y(e)
                                    }
                                }
                            })
                        }) : null
                    },
                    xe = n(63826),
                    be = ((se = {})[l.x.ATTENTION_BOOST_REMINDER] = 209, se[l.x.EXTRA_SHOWS_REMINDER] = 69, se[l.x.RISE_UP_REMINDER] = 70, se[l.x.NICE_NAME] = 118, se[l.x.EXTRA_SHOWS_EXPLANATION] = 208, se[l.x.CRUSH_EXPLANATION] = 181, se[l.x.RISEUP_EXPLANATION] = 70, se[l.x.INVISIBLE_EXPLANATION] = 117, se[l.x.MESSENGER_MINI_GAME_PROMO] = 496, se[l.x.ENCOUNTERS_EXTRA_SHOWS] = 143, se[l.x.EXTRA_SHOWS_EXPLANATION_VISITING_SOURCE] = 205, se[l.x.RISE_UP_EXPLANATION_VISITING_SOURCE] = 205, se[l.x.ATTENTION_BOOST_EXPLANATION_VISITING_SOURCE] = 205, se[l.x.ATTENTION_BOOST_EXPLANATION] = 204, se[l.x.VIDEO_CHAT_EXPLANATION] = 541, se[l.x.BUNDLE_SALE_EXPLANATION] = 204, se[l.x.NEW_USER_SUBSTITUTE] = 11, se[l.x.GET_MORE_LIKES] = 143, se[l.x.VOTE_QUOTA_REACHED] = 125, se);
                (le = {})[69] = 76, le[70] = 133, le[209] = 723;

                function _e(e, t) {
                    return _e = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, _e(e, t)
                }
                var Te = function(e) {
                        var t, n;

                        function o() {
                            for (var t, n = arguments.length, o = new Array(n), a = 0; a < n; a++) o[a] = arguments[a];
                            return (t = e.call.apply(e, [this].concat(o)) || this).getScreenName = function() {
                                var e = r.A.getLocation().routeName;
                                return be[e] || 204
                            }, t.notificationScreenAccess = 3, t
                        }
                        n = e, (t = o).prototype = Object.create(n.prototype), t.prototype.constructor = t, _e(t, n);
                        var i = o.prototype;
                        return i.componentDidMount = function() {
                            a.A.getInstance().disableTooltips(a.A.BLOCKER_TYPES.PROMO)
                        }, i.componentWillUnmount = function() {
                            a.A.getInstance().enableTooltips(a.A.BLOCKER_TYPES.PROMO)
                        }, i.render = function() {
                            var e = this.getParameters(),
                                t = e.activationPlace,
                                n = e.externalUrl,
                                o = e.hasExtraShows,
                                r = e.notification,
                                a = e.promoBlock,
                                i = e.prePurchaseInfo,
                                c = e.src,
                                s = e.userId,
                                l = this.props.config,
                                u = l.productMode,
                                d = l.qaAttribute,
                                p = (0, xe.X)();
                            return this.addPageWrapper((0, S.jsx)(ve, {
                                activationPlace: t,
                                externalUrl: n,
                                notification: r,
                                productMode: u,
                                prePurchaseInfo: i,
                                promoBlock: a,
                                src: c,
                                userId: s,
                                hasExtraShows: o,
                                isTwoTiersAvailable: p
                            }), "overlay-page", {
                                "data-qa-page": d
                            })
                        }, o
                    }(i.A),
                    ye = Te
            }
        }
    ]);
//# sourceMappingURL=8497.c855c7192d5e62b4af39.js.map
var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "b3994f9d-7dc0-492b-a72b-3724d6520c49", e._sentryDebugIdIdentifier = "sentry-dbid-b3994f9d-7dc0-492b-a72b-3724d6520c49")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "b3994f9d-7dc0-492b-a72b-3724d6520c49", e._sentryDebugIdIdentifier = "sentry-dbid-b3994f9d-7dc0-492b-a72b-3724d6520c49")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [9226], {
            13736: function(e, t, n) {
                n(52675), n(89463), n(62062);
                var r = n(8323),
                    o = n(20017),
                    i = n(8483),
                    c = n(93827),
                    a = n(74848);
                t.A = function(e) {
                    var t = e.title,
                        n = e.description,
                        l = e.costOfService,
                        s = e.timeLimit,
                        u = e.icon,
                        f = e.actions;
                    return (0, a.jsxs)("div", {
                        className: "nudge-banner",
                        children: [(0, a.jsxs)("div", {
                            className: "nudge-banner__title",
                            children: [(0, a.jsx)("div", {
                                className: "nudge-banner__title-icon",
                                children: (0, a.jsx)(i.A, {
                                    name: u,
                                    size: "stretch"
                                })
                            }), (0, a.jsx)(c.Sz, {
                                children: t
                            })]
                        }), (0, a.jsx)("div", {
                            className: "nudge-banner__description",
                            children: (0, a.jsx)(c.P2, {
                                color: "black",
                                children: n
                            })
                        }), l && (0, a.jsx)("div", {
                            className: "nudge-banner__cost-of-service",
                            children: (0, a.jsxs)(c.P3, {
                                children: [l, " ", (0, a.jsx)("span", {
                                    className: "nudge-banner__cost-of-service-icon",
                                    children: (0, a.jsx)(i.A, {
                                        name: "generic-coin",
                                        size: "sm"
                                    })
                                })]
                            })
                        }), s && (0, a.jsx)("div", {
                            className: "nudge-banner__time-limit",
                            children: (0, a.jsxs)(c.P3, {
                                children: [s, " ", (0, a.jsx)("span", {
                                    className: "nudge-banner__time-limit-icon",
                                    children: (0, a.jsx)(i.A, {
                                        name: "generic-timer",
                                        size: "sm"
                                    })
                                })]
                            })
                        }), (0, a.jsx)("div", {
                            className: "nudge-banner__actions",
                            children: (0, a.jsx)(r.A, {
                                children: f.map((function(e, t) {
                                    return (0, a.jsx)(o.A, {
                                        semantic: e.semantic,
                                        text: e.text,
                                        onClick: e.onClick,
                                        size: "small"
                                    }, "nudge-banner-button-" + t)
                                }))
                            })
                        })]
                    })
                }
            },
            18823: function(e, t, n) {
                n.d(t, {
                    h: function() {
                        return o
                    }
                });
                var r = n(81712);

                function o(e, t) {
                    return (0, r.x)(e, 1, t)
                }
            },
            23336: function(e, t, n) {
                n.d(t, {
                    F: function() {
                        return o
                    }
                });
                var r, o, i = n(32485),
                    c = n.n(i),
                    a = n(74848);
                ! function(e) {
                    e.DEFAULT = "DEFAULT", e.SQUARE = "SQUARE"
                }(o || (o = {}));
                var l = ((r = {})[o.DEFAULT] = "", r[o.SQUARE] = "external-ads-banner--square", r);
                t.A = function(e) {
                    var t, n = e.adSlot,
                        r = e.dataQa,
                        i = e.type,
                        s = void 0 === i ? o.DEFAULT : i,
                        u = e.innerRef,
                        f = e.disabled,
                        d = c()(((t = {
                            "external-ads-banner": !0
                        })[l[s]] = !0, t["external-ads-banner--no-events"] = f, t));
                    return (0, a.jsx)("div", {
                        className: d,
                        children: (0, a.jsx)("div", {
                            id: n,
                            "data-qa-ads": r,
                            ref: u
                        })
                    })
                }
            },
            25675: function(e, t, n) {
                var r;
                n.d(t, {
                        u: function() {
                            return r
                        }
                    }),
                    function(e) {
                        e.ATTENTION_BOOST = "ATTENTION_BOOST", e.BADOO_BOOST = "BADOO_BOOST", e.EXTRA_SHOWS = "EXTRA_SHOWS", e.RISE_UP = "RISE_UP"
                    }(r || (r = {}))
            },
            31247: function(e, t, n) {
                n.d(t, {
                    b: function() {
                        return r
                    }
                });
                n(48598), n(2008), n(26099);

                function r(e, t) {
                    return e.filter((function(e) {
                        return void 0 !== e && "" !== e
                    })).join(t || ", ")
                }
            },
            37018: function(e, t, n) {
                n(74423), n(21699);
                var r = n(31709);

                function o(e, t, n) {
                    var o;
                    null != n && null != (o = n.stats_required) && o.includes(e) && new r.Ay(278, {
                        promo_banner_stats: {
                            event: e,
                            context: t,
                            promo_block_type: n.promo_block_type,
                            promo_block_position: n.promo_block_position,
                            variant_id: n.variant_id
                        }
                    }).request()
                }
                t.A = {
                    reportShow: o.bind(null, 2),
                    reportClick: o.bind(null, 1),
                    reportDismiss: o.bind(null, 4)
                }
            },
            37445: function(e, t, n) {
                var r = n(32675),
                    o = n(74848);
                t.A = function(e) {
                    var t = e.text,
                        n = e.size,
                        i = e.onClick,
                        c = e.icon;
                    return (0, o.jsx)(r.A, {
                        onClick: i,
                        text: t,
                        size: n,
                        icon: c
                    })
                }
            },
            37688: function(e, t) {
                t.A = function(e, t, n) {
                    var r = -1,
                        o = e.length;
                    t < 0 && (t = -t > o ? 0 : o + t), (n = n > o ? o : n) < 0 && (n += o), o = t > n ? 0 : n - t >>> 0, t >>>= 0;
                    for (var i = Array(o); ++r < o;) i[r] = e[r + t];
                    return i
                }
            },
            42616: function(e, t, n) {
                n.d(t, {
                    h: function() {
                        return i
                    }
                });
                var r = n(40075),
                    o = n(31247);

                function i(e) {
                    var t, n = e.userName,
                        i = e.isProfilePhoto,
                        c = e.type,
                        a = void 0 === c ? "photo" : c,
                        l = e.provider,
                        s = e.position,
                        u = e.total,
                        f = e.extraAction,
                        d = e.hasOpenFullScreenAction ? r.Ay.get(548) : void 0,
                        p = s && u ? r.Ay.get(547, {
                            position: s,
                            total: u
                        }) : void 0;
                    return n ? (t = r.Ay.get(692, {
                        name: n
                    }), i && (t = r.Ay.get(686, {
                        name: n
                    })), "video" === a && (t = r.Ay.get(693, {
                        name: n
                    })), 12 === l && (t = r.Ay.get(690, {
                        name: n
                    }), "video" === a && (t = r.Ay.get(691, {
                        name: n
                    }))), s && u && (t = r.Ay.get(687, {
                        name: n,
                        num: s,
                        total: u
                    }), "video" === a && (t = r.Ay.get(688, {
                        name: n,
                        num: s,
                        total: u
                    })), 12 === l && (t = r.Ay.get(689, {
                        name: n,
                        n: s,
                        total: u
                    }), "video" === a && (t = r.Ay.get(691, {
                        name: n
                    }), t = (0, o.b)([t, p])))), (0, o.b)([t, f || d])) : (t = "video" === a ? r.Ay.get(564) : r.Ay.get(549), (0, o.b)([t, p, f || d]))
                }
            },
            44523: function(e, t, n) {
                n(52675), n(89463), n(45700), n(89572), n(26099), n(2892), n(84185), n(79432), n(2008), n(83851), n(51629), n(23500), n(81278), n(67945);
                var r = n(96540),
                    o = n(93827),
                    i = n(47667),
                    c = n(17380),
                    a = n(36693),
                    l = n(8483),
                    s = n(74848);

                function u(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function f(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? u(Object(n), !0).forEach((function(t) {
                            d(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function d(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                t.A = function(e) {
                    var t = e.header,
                        n = e.description,
                        u = e.icon,
                        d = e.type,
                        p = e.isStandalone,
                        g = e.isSelected,
                        b = e.onOptionClick,
                        v = {
                            align: "left",
                            color: "black",
                            dataQA: {
                                "data-qa-tiw-option-header": d || ""
                            }
                        },
                        m = p ? (0, s.jsx)(o.Zb, f(f({}, v), {}, {
                            children: t
                        })) : (0, s.jsxs)(r.Fragment, {
                            children: [(0, s.jsx)(o.ZS, f(f({}, v), {}, {
                                children: t
                            })), n ? (0, s.jsx)(a.A, {
                                top: "xsm",
                                children: (0, s.jsx)(o.P2, {
                                    align: "left",
                                    color: "gray-80",
                                    children: n
                                })
                            }) : null]
                        });
                    return (0, s.jsx)(i.A, {
                        media: null != u && u.name ? (0, s.jsx)(l.A, {
                            name: u.name,
                            size: "xlg",
                            color: u.color
                        }) : null,
                        mediaAlign: "center",
                        content: m,
                        extra: p ? null : (0, s.jsx)(c.A, {
                            isChecked: g,
                            type: "radio"
                        }),
                        color: g ? "selected" : "gray-10",
                        onClick: b,
                        dataQA: d ? {
                            "data-qa-tiw-option-type": d
                        } : void 0
                    })
                }
            },
            48461: function(e, t, n) {
                n.d(t, {
                    V: function() {
                        return o
                    }
                });
                var r = n(81712);

                function o(e, t) {
                    return (0, r.x)(e, 4, t)
                }
            },
            54433: function(e, t, n) {
                var r, o = n(57917),
                    i = n(15566),
                    c = o.A.extend({
                        useCache_: !1,
                        getRequestMessageType: 460,
                        getResponseMessageType: 461,
                        get: function(e) {
                            var t = (new i.agq).setPosition(e.position).setCount(e.count);
                            e.shownPromoBlocks && t.setShownPromoBlocks(e.shownPromoBlocks), e.excludePromoBlocks && t.setExcludePromoBlocks(e.excludePromoBlocks);
                            var n = (new i.qu1).setContext(e.context).setPromoBlockRequestParams([t]);
                            return c._super.get.call(this, n)
                        }
                    }, "NextPromoBlocksModel");
                c.getInstance = function() {
                    return r || (r = new c)
                }, t.A = c
            },
            59818: function(e, t, n) {
                n(51629), n(26099), n(23500), n(23418), n(47764);
                var r = n(96540),
                    o = n(99417);
                t.A = function(e) {
                    var t = e.list,
                        n = e.onFetchMore,
                        i = void 0 === n ? function() {} : n,
                        c = e.hasMore,
                        a = (0, r.useState)(),
                        l = a[0],
                        s = a[1],
                        u = (0, r.useRef)(),
                        f = (0, r.useCallback)((function(e) {
                            e && s(e)
                        }), []);
                    return (0, r.useEffect)((function() {
                        var e = o.A.document.body.clientHeight;
                        u.current = new o.A.IntersectionObserver((function(e) {
                            e.forEach((function(e) {
                                var t = e.target;
                                e.isIntersecting ? (t.style.visibility = "visible", c && !e.target.nextSibling && i()) : t.style.visibility = "hidden"
                            }))
                        }), {
                            rootMargin: e + "px 0px"
                        })
                    }), [l, c, i]), (0, r.useEffect)((function() {
                        var e;
                        l && (null == (e = u.current) || e.disconnect(), Array.from(l.children).forEach((function(e) {
                            var t;
                            null == (t = u.current) || t.observe(e)
                        })));
                        return function() {
                            var e;
                            null == (e = u.current) || e.disconnect()
                        }
                    }), [u, l, t]), [f]
                }
            },
            63620: function(e, t, n) {
                var r;
                n.d(t, {
                        l: function() {
                            return r
                        }
                    }),
                    function(e) {
                        e.ADD_INTERESTS = "add-interests", e.OWN_INTERESTS = "own-interests", e.ADD_PHOTOS = "add-photos", e.PREVIEW_PROFILE = "preview-profile", e.VERIFICATION = "verification", e.ANCHOR_MOOD_STATUS = "mood-status", e.PLANS_TAB = "plans", e.SAFETY_TAB = "safety"
                    }(r || (r = {}))
            },
            65762: function(e, t, n) {
                n.r(t), n.d(t, {
                    default: function() {
                        return Vt
                    }
                });
                n(10287);
                var r = n(96540),
                    o = n(85558),
                    i = n(58385),
                    c = n(74389),
                    a = (n(26099), n(3362), n(51629), n(23500), n(74423), n(21699), n(62062), n(50113), n(28706), n(23792), n(47764), n(62953), n(45700), n(89572), n(52675), n(89463), n(2892), n(84185), n(79432), n(2008), n(83851), n(81278), n(67945), n(99417)),
                    l = n(37688),
                    s = n(6832),
                    u = n(77127),
                    f = Math.ceil,
                    d = Math.max;
                var p = function(e, t, n) {
                        t = (n ? (0, s.A)(e, t, n) : void 0 === t) ? 1 : d((0, u.A)(t), 0);
                        var r = null == e ? 0 : e.length;
                        if (!r || t < 1) return [];
                        for (var o = 0, i = 0, c = Array(f(r / t)); o < r;) c[i++] = (0, l.A)(e, o, o += t);
                        return c
                    },
                    g = n(79860),
                    b = n(53010),
                    v = n(73090),
                    m = n(65297),
                    y = n(72537),
                    h = n(31709),
                    A = n(28431),
                    P = n(37905),
                    O = n(25093),
                    S = n(47901),
                    j = n(87184),
                    x = n(11734),
                    _ = n(15376),
                    E = n(33815),
                    w = n(40075),
                    T = n(4571),
                    I = n(27895),
                    k = n(46770),
                    N = n(40578),
                    B = n(20017),
                    U = n(8483),
                    C = n(74848),
                    D = function(e) {
                        var t = e.onPrimaryActionClick;
                        return (0, C.jsxs)(T.A, {
                            children: [(0, C.jsx)(I.A, {
                                size: "icon",
                                children: (0, C.jsx)(U.A, {
                                    name: "badge-filter",
                                    color: "black"
                                })
                            }), (0, C.jsx)(N.A, {
                                text: (0, C.jsx)("span", {
                                    dangerouslySetInnerHTML: {
                                        __html: w.Ay.get(744)
                                    }
                                })
                            }), (0, C.jsx)(k.A, {
                                children: (0, C.jsx)(B.A, {
                                    text: w.Ay.get(587),
                                    onClick: t
                                })
                            })]
                        })
                    },
                    R = n(41296),
                    L = function(e) {
                        var t = e.scrollableElement,
                            n = e.header,
                            r = e.chunks,
                            o = e.isEmpty,
                            i = e.isLoading,
                            c = e.onClickEmptyAction,
                            a = e.isFetching;
                        return o ? (0, C.jsxs)(S.A, {
                            children: [(0, C.jsx)(_.A, {
                                children: n
                            }), (0, C.jsx)(j.A, {
                                align: "center",
                                hpadded: !0,
                                children: (0, C.jsx)(D, {
                                    onPrimaryActionClick: c
                                })
                            }), (0, C.jsx)(x.A, {
                                children: (0, C.jsx)("div", {
                                    className: "h-tabbar-affected"
                                })
                            })]
                        }) : (0, C.jsxs)(S.A, {
                            innerRef: t,
                            children: [(0, C.jsx)(_.A, {
                                isSticky: !0,
                                children: n
                            }), (0, C.jsx)(R.A, {
                                type: 3
                            }), i ? (0, C.jsx)(j.A, {
                                align: "center",
                                children: (0, C.jsx)("div", {
                                    className: "people-nearby__loader",
                                    children: (0, C.jsx)(E.A, {})
                                })
                            }) : null, !i && r ? (0, C.jsxs)(j.A, {
                                children: [r, (0, C.jsx)("div", {
                                    className: "people-nearby__loader",
                                    children: a && (0, C.jsx)(E.A, {})
                                })]
                            }) : null, (0, C.jsx)(x.A, {
                                children: (0, C.jsx)("div", {
                                    className: "h-tabbar-affected"
                                })
                            })]
                        })
                    },
                    F = n(68451),
                    M = n(39904),
                    H = function(e) {
                        var t = e.header,
                            n = e.subHeader,
                            o = e.chatUnblockers,
                            i = e.extraShowsHeaderTitle,
                            c = e.extraShowsCta,
                            a = e.popularity,
                            l = e.onClickFilter,
                            s = [o ? {
                                type: M.TN.CHAT_UNBLOCKERS,
                                numChatUnblockers: o.numChatUnblockers,
                                isPremiumPlus: o.isPremiumPlus,
                                ref: o.ref,
                                onClick: o.onClick,
                                a11y: {
                                    ariaDescribedby: "tooltip-chat-unblockers"
                                }
                            } : {
                                type: M.TN.POPULARITY,
                                level: a.popularityLevel,
                                onClick: a.onClick
                            }, {
                                type: M.X2.FILTER,
                                onClick: l,
                                a11y: {
                                    iconLabel: w.Ay.get(463)
                                }
                            }];
                        return c && (null == s || s.unshift({
                            type: M.TN.CUSTOM_COMPONENT,
                            component: c
                        })), i && (null == s || s.unshift({
                            type: M.TN.CUSTOM_COMPONENT,
                            component: i
                        })), (0, C.jsxs)(r.Fragment, {
                            children: [(0, C.jsx)(M.Ay, {
                                actions: s,
                                title: {
                                    text: t,
                                    variant: "primary"
                                },
                                subTitle: n,
                                isBalanced: !1,
                                hasShadow: !0
                            }), null != o && o.tooltip ? (0, C.jsx)("div", {
                                className: "people-nearby__chat-unblockers-tooltip",
                                style: o.tooltip.offset,
                                "aria-hidden": !0,
                                children: (0, C.jsx)(F.A, {
                                    placement: "bottom-start",
                                    text: o.tooltip.text,
                                    id: "tooltip-chat-unblockers"
                                })
                            }) : null]
                        })
                    },
                    V = n(63553),
                    q = n(53416),
                    Q = n(12187),
                    z = n(31087),
                    W = n(73260),
                    Y = n(88029);

                function K(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function G(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? K(Object(n), !0).forEach((function(t) {
                            X(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : K(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function X(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var Z = function(e) {
                        var t, n = e.clientSource,
                            o = e.chatUnblockers,
                            i = e.onClickFilter,
                            c = e.onClickPopularity,
                            a = (0, r.useState)(W.s7.VERY_LOW),
                            l = a[0],
                            s = a[1],
                            u = (0, r.useRef)(null),
                            f = (0, Q.H)(),
                            d = f.headerTitle,
                            p = f.isPnbEntryPointVisible,
                            b = function() {
                                z.A.getInstance().get({
                                    id: v.A.getUserId()
                                }).then((function(e) {
                                    e && s(function(e) {
                                        switch (e) {
                                            case 10:
                                            default:
                                                return W.s7.VERY_LOW;
                                            case 20:
                                                return W.s7.LOW;
                                            case 30:
                                                return W.s7.AVERAGE;
                                            case 40:
                                                return W.s7.HIGH;
                                            case 50:
                                                return W.s7.VERY_HIGH
                                        }
                                    }(e.getPopularityLevel()))
                                }))
                            };
                        if ((0, r.useEffect)((function() {
                                o || b(), (0, g.sx)(258, {
                                    element: 488
                                })
                            }), [o]), u.current && null != o && o.tooltip) {
                            var m = u.current.getBoundingClientRect();
                            t = {
                                text: null == o ? void 0 : o.tooltip,
                                offset: {
                                    left: m.left + m.width / 2,
                                    top: m.bottom
                                }
                            }
                        }
                        var y = (0, Y.A)(n),
                            h = y.header_text,
                            A = y.subheader_text;
                        return (0, C.jsx)(H, {
                            header: h,
                            subHeader: A,
                            chatUnblockers: o ? G(G({}, o), {}, {
                                tooltip: t,
                                ref: u
                            }) : void 0,
                            extraShowsHeaderTitle: p && d ? (0, C.jsx)(V.A, {
                                context: 2
                            }) : null,
                            extraShowsCta: p ? (0, C.jsx)(q.A, {
                                context: 2
                            }) : null,
                            popularity: {
                                onClick: c,
                                popularityLevel: l
                            },
                            onClickFilter: i
                        })
                    },
                    $ = (n(25276), n(74689)),
                    J = n(95836),
                    ee = n(32675),
                    te = n(31751),
                    ne = function(e) {
                        var t = e.distanceBadge,
                            n = e.tiwBadge,
                            r = null;
                        return n && (r = (0, C.jsx)("span", {
                            className: "people-nearby__intention-badge-icon",
                            children: (0, C.jsx)(te.A, {
                                imageSrc: n.src,
                                size: "20px"
                            })
                        })), !r && t && (r = (0, C.jsx)("div", {
                            className: "people-nearby-user-overlay__distance-badge",
                            "data-qa": "people-nearby-distance-badge",
                            children: (0, C.jsx)(ee.A, {
                                size: "small",
                                text: t,
                                styling: "black"
                            })
                        })), (0, C.jsx)("div", {
                            className: "people-nearby-user-overlay",
                            children: r
                        })
                    };

                function re() {
                    i.A.navigate(c.x.POPULARITY), (0, g.sx)(332, {
                        element: 63,
                        screen_name: 2
                    })
                }

                function oe(e, t, n) {
                    var r, o, i = null,
                        c = e.length,
                        a = n ? e[c - 1] : e[0];
                    if ((null == a || null == a.getUserId ? void 0 : a.getUserId()) === t) return null;
                    for (var l = 0; l < c; l++) {
                        if (e[l].getUserId() === t) {
                            i = n ? l === c - 1 ? e[0] : e[l + 1] : 0 === l ? e[c - 1] : e[l - 1];
                            break
                        }
                    }
                    return null != (r = i) && null != r.getIsBlocked && r.getIsBlocked() ? oe(e, null == (o = i) ? void 0 : o.getUserId(), n) : i
                }
                var ie = n(31247),
                    ce = ["id", "distanceBadge", "tiwBadge"];

                function ae(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function le(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? ae(Object(n), !0).forEach((function(t) {
                            se(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : ae(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function se(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var ue = function(e) {
                        var t = e.users,
                            n = e.sectionIndex;
                        return (0, C.jsx)("div", {
                            className: "people-nearby__section",
                            "data-qa": "people-nearby-content",
                            children: t ? (0, C.jsx)($.A, {
                                layout: "grid",
                                cols: 3,
                                children: t.map((function(e, t) {
                                    e.id;
                                    var o, a = e.distanceBadge,
                                        l = e.tiwBadge,
                                        s = function(e, t) {
                                            if (null == e) return {};
                                            var n, r, o = {},
                                                i = Object.keys(e);
                                            for (r = 0; r < i.length; r++) n = i[r], t.indexOf(n) >= 0 || (o[n] = e[n]);
                                            return o
                                        }(e, ce),
                                        u = a || l,
                                        f = [e.user.age ? w.Ay.get(811, {
                                            name: e.user.name,
                                            age: e.user.age
                                        }) : e.user.name, "online" === (null == (o = e.user.status) ? void 0 : o.online) ? w.Ay.get(848) : void 0],
                                        d = (0, r.createElement)(J.A, le(le({}, s), {}, {
                                            overlay: u ? {
                                                children: (0, C.jsx)(ne, {
                                                    distanceBadge: a,
                                                    tiwBadge: l
                                                })
                                            } : void 0,
                                            key: "pnb-section-item-" + e.id,
                                            a11y: {
                                                label: (0, ie.b)(f)
                                            }
                                        }));
                                    return 0 === t && 0 === n ? (0, C.jsx)(R.A, {
                                        onClick: s.onClick,
                                        onSecondaryClick: function() {
                                            return function(e) {
                                                i.A.navigate(c.x.MESSAGES, {
                                                    id: e
                                                })
                                            }(String(e.id))
                                        },
                                        type: 12,
                                        children: d
                                    }, "pnb-section-item-" + e.id) : d
                                }))
                            }) : null
                        })
                    },
                    fe = n(84935),
                    de = n(79069),
                    pe = (n(60739), n(27208), n(37018)),
                    ge = n(47632),
                    be = n(84654),
                    ve = n(30784),
                    me = n(96506),
                    ye = n(32483),
                    he = n(26914),
                    Ae = n(31023),
                    Pe = n(23336),
                    Oe = n(69110),
                    Se = function(e) {
                        var t = e.centerImage,
                            n = e.leftImage,
                            r = e.rightImage;
                        return t.badge && (t.badge.position = "bc"), (0, C.jsxs)(Ae.A, {
                            layout: "triple",
                            variant: "s-m-s",
                            children: [(0, C.jsx)(he.A, {
                                image: n.image
                            }), (0, C.jsx)(he.A, {
                                image: t.image,
                                icon: t.icon,
                                user: t.user,
                                badge: t.badge
                            }), (0, C.jsx)(he.A, {
                                image: r.image
                            })]
                        })
                    },
                    je = function(e) {
                        var t = e.centerImage;
                        return t.badge && (t.badge.position = "br"), (0, C.jsx)(he.A, {
                            size: "md",
                            image: t.image,
                            icon: t.icon,
                            user: t.user,
                            badge: t.badge,
                            halo: t.halo
                        })
                    };

                function xe(e, t) {
                    return e ? {
                        image: {
                            src: ge.A.getImageUrlForSize(e, t)
                        }
                    } : void 0
                }
                var _e = function(e) {
                        var t = e.id,
                            n = e.featureName,
                            r = e.pictures,
                            o = e.title,
                            i = e.message,
                            c = e.action,
                            a = e.costOfService,
                            l = e.isExternalAd,
                            s = e.onView;
                        if (t && l) {
                            var u = (0, C.jsx)("div", {
                                className: "people-nearby-banner people-nearby-banner-ad",
                                children: (0, C.jsx)(Oe.A, {
                                    adSlot: t,
                                    dataQa: "pnb",
                                    type: Pe.F.SQUARE
                                })
                            });
                            return (0, C.jsx)("div", {
                                className: "people-nearby__section",
                                children: s ? (0, C.jsx)(be.A, {
                                    onIntersect: s,
                                    children: u
                                }) : u
                            })
                        }
                        var f, d = xe(null == r ? void 0 : r.pictures.middleImage, 100) || {},
                            p = xe(null == r ? void 0 : r.pictures.leftImage, 70),
                            g = xe(null == r ? void 0 : r.pictures.rightImage, 70);
                        switch (d && null != r && r.icon && (d.badge = {
                            icon: {
                                name: r.icon
                            }
                        }), "add-photo" === n && (d = {
                            icon: {
                                name: "badge-add-photos"
                            }
                        }), "spp-delayed" === n && (d = {
                            icon: {
                                name: "badge-feature-premium"
                            }
                        }), "spp-delayed" === n ? "single" : "triple") {
                            case "single":
                                f = d ? (0, C.jsx)(je, {
                                    centerImage: d
                                }) : null;
                                break;
                            case "triple":
                                f = d && p && g ? (0, C.jsx)(Se, {
                                    centerImage: d,
                                    leftImage: p,
                                    rightImage: g
                                }) : null
                        }
                        var b, v = (0, C.jsx)("div", {
                            className: "people-nearby-banner",
                            children: (0, C.jsxs)(T.A, {
                                isCompact: !0,
                                children: [f ? (0, C.jsx)(I.A, {
                                    children: f
                                }) : null, o ? (0, C.jsx)(N.A, {
                                    text: o
                                }) : null, (0, C.jsx)(ve.A, {
                                    text: i
                                }), (0, C.jsx)(k.A, {
                                    children: (0, C.jsx)(B.A, {
                                        styling: (b = n, {
                                            "attention-boost": "default",
                                            "bundle-sale": "default",
                                            "chat-with-newbies": "default",
                                            "chat-with-tired": "default",
                                            "extra-shows": "default",
                                            "feature-extra-shows": "default",
                                            "invisible-mode": "revenue",
                                            "liked-you": "default",
                                            riseup: "default",
                                            "special-delivery": "revenue",
                                            premium: "revenue",
                                            undo: "revenue"
                                        }[b]),
                                        text: c.text,
                                        isLoading: c.isLoading,
                                        onClick: c.onClick
                                    })
                                }), a ? (0, C.jsx)(me.A, {
                                    children: (0, C.jsx)(ye.A, {
                                        children: a
                                    })
                                }) : null]
                            })
                        });
                        return (0, C.jsx)("div", {
                            className: "people-nearby__section",
                            children: s ? (0, C.jsx)(be.A, {
                                onIntersect: s,
                                children: v
                            }) : v
                        })
                    },
                    Ee = n(13736),
                    we = function(e) {
                        var t = e.id,
                            n = e.title,
                            r = e.message,
                            o = e.action,
                            i = e.costOfService,
                            c = e.timeLimit,
                            a = e.icon,
                            l = e.isExternalAd,
                            s = e.onView;
                        if (t && l) {
                            var u = (0, C.jsx)("div", {
                                className: "people-nearby-banner people-nearby-banner-ad",
                                children: (0, C.jsx)(Oe.A, {
                                    adSlot: t,
                                    dataQa: "pnb",
                                    type: Pe.F.SQUARE
                                })
                            });
                            return (0, C.jsx)("div", {
                                className: "people-nearby__section",
                                children: s ? (0, C.jsx)(be.A, {
                                    onIntersect: s,
                                    children: u
                                }) : u
                            })
                        }
                        return (0, C.jsx)("div", {
                            className: "people-nearby-banner",
                            children: (0, C.jsx)(Ee.A, {
                                title: n,
                                description: r,
                                costOfService: i,
                                timeLimit: c,
                                icon: a,
                                actions: [{
                                    text: o.text,
                                    semantic: "primary",
                                    onClick: o.onClick
                                }]
                            })
                        })
                    },
                    Te = n(41051),
                    Ie = n(85608);

                function ke(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function Ne(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? ke(Object(n), !0).forEach((function(t) {
                            Be(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : ke(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function Be(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var Ue = "pnb_banners_design_revamp_2024";

                function Ce(e) {
                    return function() {
                        if (e && !e.isExternalAd) {
                            var t, n;
                            if ([65, 346].includes(e.type)) {
                                var r, o = Ie.A.getTrackingData(e.promoBlock, 138);
                                return (0, g.sx)(138, Ne(Ne({}, o), {}, {
                                    banner_id: e.type
                                })), void pe.A.reportShow(2, null == (r = e.promoBlock) ? void 0 : r.toJSON())
                            }
                            if (165 === e.type) return (0, g.sx)(138, {
                                banner_id: null == (t = e.promoBlock) ? void 0 : t.getPromoBlockType(),
                                position_id: null == (n = e.promoBlock) ? void 0 : n.getPromoBlockPosition()
                            }), void(0, g.sx)(258, {
                                element: 14
                            });
                            (0, g.sx)(63, {
                                activation_place: 3,
                                banner_id: e.type,
                                notification_action_type: 1,
                                notification_type: 2
                            })
                        }
                    }
                }
                var De = function(e) {
                        var t, n, o = e.banner,
                            a = e.onPromoSelected,
                            l = e.onBannerAction,
                            s = (0, r.useState)(!1),
                            u = s[0],
                            f = s[1],
                            d = function() {
                                var e, t;
                                if (a(), 65 === o.type && (0, g.sx)(332, {
                                        element: 547
                                    }), 165 === o.type && (0, g.sx)(332, {
                                        element: 288,
                                        parent_element: 14
                                    }), 346 === o.type) {
                                    var n = {
                                        variantId: o.variantId,
                                        event: 2,
                                        context: 127,
                                        promoBlockPosition: 1
                                    };
                                    Te.A.sendProfileQuestionsBannerStats(n)
                                }
                                22 === o.product && (0, g.sx)(63, {
                                        notification_type: 2,
                                        notification_action_type: 2,
                                        banner_id: o.type
                                    }),
                                    function() {
                                        var e = {
                                                banner_id: o.type,
                                                call_to_action_type: 1
                                            },
                                            t = o.promoBlock;
                                        if (null != t && t.getPromoBlockPosition && (e.position_id = t.getPromoBlockPosition()), null != t && t.getContext && (e.context = t.getContext()), null != t && t.getButtons) {
                                            var n = t.getButtons([])[0] || {},
                                                r = null == n.getType ? void 0 : n.getType();
                                            "number" == typeof r && (e.call_to_action_type = r)
                                        }(0, g.sx)(139, e)
                                    }();
                                var r, s = o.promoBlock,
                                    u = {};
                                if (63 === (null == (e = o.action) ? void 0 : e.type) && s) {
                                    r = s.getRedirectPage();
                                    var f = [304, 346].includes(o.type);
                                    !r && f && (r = Ie.A.getRedirectPageFromPromoBlock(s))
                                }
                                r && 346 === o.type && (u = {
                                    redirectTo: c.x.OWN_PROFILE_EDIT,
                                    preloadQuestions: !0
                                }), Ie.A.handlePromoSelected({
                                    action: null == (t = o.action) ? void 0 : t.type,
                                    banner: o.type,
                                    cost: o.cost,
                                    productType: o.product,
                                    activationPlace: 3,
                                    destination: i.A.getUrl(),
                                    redirectPage: r,
                                    redirectPageParams: u,
                                    isSkipExplanationScreen: o.variantId === Ue
                                }, {
                                    from: i.A.getUrl(),
                                    context: 2
                                }, {
                                    onAction: l
                                })
                            },
                            p = {
                                text: (null == (t = o.action) ? void 0 : t.label) || "",
                                isLoading: u,
                                onClick: function() {
                                    var e;
                                    u || (f(!0), pe.A.reportClick(2, null == (e = o.promoBlock) ? void 0 : e.toJSON()), d())
                                }
                            };
                        return o.variantId === Ue ? (0, C.jsx)(we, {
                            id: o.id,
                            icon: null == (n = o.pictures) ? void 0 : n.icon,
                            title: o.title,
                            message: o.message,
                            action: p,
                            costOfService: o.costOfService,
                            isExternalAd: o.isExternalAd,
                            onView: Ce(o)
                        }) : (0, C.jsx)(_e, {
                            id: o.id,
                            featureName: o.featureName,
                            pictures: o.pictures,
                            title: o.title,
                            message: o.message,
                            action: p,
                            costOfService: o.costOfService,
                            isExternalAd: o.isExternalAd,
                            onView: Ce(o)
                        })
                    },
                    Re = n(56368),
                    Le = n(20387),
                    Fe = n(64928),
                    Me = n(88651),
                    He = n(16720),
                    Ve = n(93529),
                    qe = n(41298),
                    Qe = n(97547),
                    ze = n(13614),
                    We = n(95773),
                    Ye = n(5664),
                    Ke = n(15566),
                    Ge = n(54433);

                function Xe(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function Ze(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? Xe(Object(n), !0).forEach((function(t) {
                            $e(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Xe(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function $e(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function Je(e) {
                    return 1 === e.getPromoBlockPosition()
                }

                function et(e) {
                    return [4, 16].includes(e.getPromoBlockPosition())
                }

                function tt(e) {
                    var t = e.getPromoBlockType();
                    if ([10, 165].includes(t) || [1, 56, 57, 7, 119].includes(t) && "pnb_banners_design_revamp_2024" === e.getVariantId() || 23 === e.getOkPaymentProductType()) return e.getHeader()
                }

                function nt(e) {
                    var t = e.getPromoBlockType(),
                        n = e.getPaymentAmount(100),
                        r = e.getUniqueId() || (0, Ye.A)("clientId-"),
                        o = e.getCreditsCost() === String(n) ? e.getOtherText() : e.getCreditsCost(),
                        i = function(e) {
                            var t = {
                                    action: e.getAction(),
                                    actionType: e.getOkAction()
                                },
                                n = e.getPromoBlockType(),
                                r = e.getButtons([])[0];
                            if (r) switch (n) {
                                case 165:
                                case 10:
                                    t.action = r.getText();
                                    break;
                                case 346:
                                    t.action = r.getText(), t.actionType = r.getAction()
                            }
                            return t
                        }(e),
                        c = function(e) {
                            var t = e.getPromoBlockType(),
                                n = function(e) {
                                    var t = e.getPictures();
                                    return t ? 3 === t.length ? {
                                        leftImage: t[1].getDisplayImages(),
                                        middleImage: t[0].getDisplayImages(),
                                        rightImage: t[2].getDisplayImages()
                                    } : 2 === t.length ? {
                                        leftImage: t[0].getDisplayImages(),
                                        middleImage: "",
                                        rightImage: t[1].getDisplayImages()
                                    } : 1 === t.length ? {
                                        leftImage: "",
                                        middleImage: t[0].getDisplayImages(),
                                        rightImage: ""
                                    } : null : null
                                }(e);
                            if (n && 65 !== t) return {
                                icon: Ie.A.getBadgeTypeForPromoBlock(t),
                                pictures: n
                            }
                        }(e);
                    return {
                        promoBlock: e,
                        cost: n,
                        costOfService: o,
                        featureName: Ie.A.getFeatureName(t),
                        title: tt(e),
                        message: e.getMssg(e),
                        product: e.getOkPaymentProductType(),
                        type: t,
                        id: r,
                        action: {
                            label: i.action,
                            type: i.actionType
                        },
                        pictures: c,
                        isExternalAd: !1,
                        variantId: null == e.getVariantId ? void 0 : e.getVariantId()
                    }
                }

                function rt(e, t) {
                    var n;
                    if (0 === e.length) return Promise.resolve({
                        bannerIdsToReplace: [],
                        newBanners: []
                    });
                    var r = {
                        position: 1,
                        context: 2,
                        count: e.length
                    };
                    return null != t && null != (n = t.promoBlock) && n.getPromoBlockType() && (r.excludePromoBlocks = [t.promoBlock.getPromoBlockType()]), Ge.A.getInstance().get(r).then((function(n) {
                        var r = n[0],
                            o = null == r ? void 0 : r.getPromoBlocks();
                        return o && 0 !== o.lenght ? {
                            newPromoBlocks: o,
                            bannerIdsToReplace: e,
                            actionBanner: t
                        } : {
                            bannerIdsToReplace: [],
                            newBanners: []
                        }
                    }))
                }

                function ot(e) {
                    return Ze(Ze({}, e || {}), {}, {
                        isExternalAd: !0,
                        id: b.A.create(b.A.placements.PNB)
                    })
                }

                function it(e, t) {
                    if (e || b.A.isEnabled()) {
                        var n = nt(e);
                        return b.A.isEnabled() && (n = ot(n)), t(e, n), n
                    }
                }
                var ct = n(10357),
                    at = n(51064),
                    lt = n(46428);

                function st(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function ut(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? st(Object(n), !0).forEach((function(t) {
                            ft(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : st(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function ft(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                n(46449), n(93514);
                var dt = n(26666);

                function pt(e, t) {
                    return e.map((function(e) {
                        var n = e.getUserId(),
                            r = e.getDistanceBadge(),
                            o = function(e) {
                                return null != e && e.hasIconUrl() ? {
                                    src: e.getIconUrl()
                                } : void 0
                            }(e.getTiwIdea()),
                            i = t(n, Boolean(r)),
                            c = {
                                id: n,
                                user: {
                                    gender: (0, ze.v4)(e.getGender()),
                                    name: e.getName(),
                                    age: e.getAge(),
                                    status: {
                                        online: 1 === e.getOnlineStatus() ? "online" : void 0
                                    }
                                },
                                distanceBadge: r,
                                tiwBadge: o,
                                onClick: i,
                                dataQA: {
                                    "data-qa-user-id": n
                                }
                            },
                            a = e.getProfilePhoto();
                        if (a) {
                            var l = ge.A.getImageUrlForSize(a.getLargeUrl(), 150);
                            c.user.photo = {
                                src: l
                            }
                        }
                        return c
                    }))
                }

                function gt() {
                    return a.A.document.body.clientWidth > 559 ? 30 : 18
                }
                var bt = function() {
                        var e = (0, r.useState)(gt()),
                            t = e[0],
                            n = e[1];
                        return (0, r.useEffect)((function() {
                            var e = function() {
                                n(gt())
                            };
                            return m.A.on(m.A.RESIZE, e),
                                function() {
                                    m.A.off(m.A.RESIZE, e)
                                }
                        }), []), [t]
                    },
                    vt = n(9796),
                    mt = n(64266),
                    yt = n(26035),
                    ht = n(18084),
                    At = n(59818),
                    Pt = n(76854),
                    Ot = n(41025),
                    St = n(63826),
                    jt = n(5974),
                    xt = n(54462),
                    _t = n(61804),
                    Et = n(7572);

                function wt(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function Tt(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? wt(Object(n), !0).forEach((function(t) {
                            It(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : wt(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function It(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var kt = ht.A.getLogger("PeopleNearby"),
                    Nt = (0, xt.A)(3);

                function Bt(e) {
                    var t = e.chunks,
                        n = e.onPromoSelected,
                        r = e.onBannerAction,
                        o = e.listContainerRef;
                    return (0, C.jsx)("div", {
                        className: "people-nearby__content",
                        ref: o,
                        children: t.map((function(e, t) {
                            return e.users ? (0, C.jsx)(ue, {
                                users: e.users,
                                sectionIndex: t
                            }, "section-" + t) : e.banner ? (0, C.jsx)(De, {
                                banner: e.banner,
                                onPromoSelected: n,
                                onBannerAction: r
                            }, e.banner.id) : null
                        }))
                    })
                }

                function Ut(e) {
                    e instanceof qe.k || (e instanceof Error && kt.error(e), A.A.handleError({
                        error: e,
                        screenName: 2,
                        navigationBar: {
                            logo: !0,
                            actions: {}
                        },
                        onHide: Ct
                    }, void 0))
                }

                function Ct(e) {
                    return e === _t.X.BACK_ONLINE && (A.A.hideErrorScreen(), !0)
                }

                function Dt(e) {
                    (0, O.A)(e) && kt.error("Failed to get user by id", e), e instanceof qe.k || Ve.A.showNotification({
                        type: Ve.A.TYPES.ERROR
                    })
                }

                function Rt() {
                    Le.A.getInstance().invalidateFolder(10)
                }
                var Lt = function(e) {
                        var t = e.scrollableElement,
                            n = e.saveScrollPosition,
                            o = e.scrollPosition,
                            l = e.navigatedBack,
                            s = e.onPreventNotifications,
                            u = e.onAllowNotifications,
                            f = e.jinba,
                            d = e.onboardingTipsController,
                            A = e.clientSource,
                            O = e.scrollableProfileUserId,
                            S = e.scrollableProfileDistanceInfo,
                            j = bt()[0],
                            x = (0, r.useState)(!1),
                            _ = x[0],
                            E = x[1],
                            w = (0, r.useState)(!1),
                            T = w[0],
                            I = w[1],
                            k = (0, r.useState)(),
                            N = k[0],
                            B = k[1],
                            U = (0, r.useState)(),
                            D = U[0],
                            R = U[1],
                            F = (0, r.useState)([]),
                            M = F[0],
                            H = F[1],
                            V = (0, r.useState)(!1),
                            q = V[0],
                            Q = V[1],
                            W = (0, r.useState)(!1),
                            Y = W[0],
                            K = W[1],
                            G = (0, r.useState)(!1),
                            X = G[0],
                            $ = G[1],
                            J = (0, r.useState)(),
                            ee = J[0],
                            te = J[1],
                            ne = (0, r.useState)([]),
                            ie = ne[0],
                            ce = ne[1],
                            ae = (0, r.useState)(""),
                            le = ae[0],
                            se = ae[1],
                            ue = (0, r.useState)(!1),
                            pe = ue[0],
                            be = ue[1],
                            ve = (0, r.useState)(!1),
                            me = ve[0],
                            ye = ve[1],
                            he = (0, r.useRef)(!1),
                            Ae = (0, r.useRef)(!1),
                            Pe = (0, r.useRef)({}),
                            Oe = (0, r.useRef)(!1),
                            Se = (0, r.useRef)(!0),
                            je = (0, r.useRef)(j),
                            xe = (0, r.useRef)(!1),
                            _e = {
                                folder: (0, r.useRef)((0, qe.A)(Promise.resolve([]))),
                                settings: (0, r.useRef)((0, qe.A)(Promise.resolve())),
                                getScrollableProfileUser: (0, r.useRef)((0, qe.A)(Promise.resolve()))
                            },
                            Ee = function(e, t) {
                                var n = e.getActionsChangingVisibility([]);
                                n && n.forEach((function(e) {
                                    Pe.current[e] = Pe.current[e] || [], Pe.current[e].push(t.id)
                                }))
                            },
                            we = function(e) {
                                var t, n = e.newPromoBlocks,
                                    r = e.bannerIdsToReplace,
                                    o = e.actionBanner,
                                    i = 0;
                                o && r.includes(o.id) && (t = n[i++]), H((function(e) {
                                    return e.map((function(e) {
                                        if (e.banner) {
                                            var c = e.banner;
                                            if (!r.includes(c.id)) return e;
                                            var a = it(c.id === (null == o ? void 0 : o.id) && t ? t : n[i++], Ee);
                                            return a ? {
                                                banner: a
                                            } : e
                                        }
                                        return e
                                    }))
                                }))
                            },
                            Te = (0, r.useCallback)((function(e, t) {
                                var n = t.onUserClick;
                                e.forEach((function(e) {
                                    d.registerPromoBlock(e, n)
                                }))
                            }), [d]),
                            ke = function() {
                                be(!0)
                            },
                            Ne = function(e) {
                                var t = e.user,
                                    n = e.userDistanceInfo,
                                    r = e.onlyUpdateState,
                                    o = (null == t || null == t.getUserId ? void 0 : t.getUserId()) || "";
                                r ? (se(o), te(t), be(!1)) : i.A.navigate(c.x.PEOPLE_NEARBY, !1, {
                                    id: o,
                                    userDistanceInfo: n
                                })
                            },
                            Be = (0, r.useCallback)((function(e) {
                                _e.getScrollableProfileUser.current = z.A.getUserById({
                                    id: e,
                                    clientSource: 2,
                                    folderType: 10
                                }), _e.getScrollableProfileUser.current.then((function(e) {
                                    var t, n, r = null == (t = e.getProfilePhoto()) ? void 0 : t.getId(),
                                        o = null == (n = e.getAlbums([])[0]) ? void 0 : n.getPhotos([]).find((function(e) {
                                            return e.getId() === r
                                        }));
                                    if (o) {
                                        var i = ge.A.getImageUrlForSize(o.getLargeUrl(), (0, ze.qT)().widthPixelRatio);
                                        (0, We.NN)(i).catch((function(e) {
                                            return (0, We.gf)(e, "Peaople nearby container next profile")
                                        }))
                                    }
                                })).catch((function() {}))
                            }), [_e.getScrollableProfileUser]),
                            Ue = (0, r.useCallback)((function(e, t) {
                                if (null == e || !e.getSection()) return xe.current = !0, [];
                                var r = e.getSection([]),
                                    o = function(e) {
                                        return e.map((function(e) {
                                            return e.getUsers()
                                        })).flat()
                                    }(r);
                                ce((function(e) {
                                    return [].concat(e, o)
                                }));
                                var i = function(e, t) {
                                        return function() {
                                            n(), (0, g.sx)(332, {
                                                element: 21
                                            }), se(e), ke(), _e.getScrollableProfileUser.current = z.A.getUserById({
                                                id: e,
                                                clientSource: 2,
                                                folderType: 10
                                            }), _e.getScrollableProfileUser.current.then((function(n) {
                                                Ne({
                                                    user: n,
                                                    userDistanceInfo: {
                                                        hasDistanceBadge: t
                                                    }
                                                });
                                                var r = oe(o, e, !0);
                                                r && Be(r.getUserId())
                                            })).catch(Dt)
                                        }
                                    },
                                    c = pt(o, i),
                                    a = [],
                                    l = p(c, je.current),
                                    s = function(e, t, n) {
                                        var r = [];
                                        if (null == e || !e.getPromoBanners()) {
                                            if (b.A.isEnabled())
                                                for (var o = t; o > 0; o--) r.push(ot());
                                            return r
                                        }
                                        var i = {},
                                            c = e.getPromoBanners([]).filter(Je),
                                            a = e.getPromoFeatures(),
                                            l = a ? a[0] : null;
                                        if (c.forEach((function(e) {
                                                i[e.getOkAction() + "_" + (e.getOkPaymentProductType() || 0)] = !0;
                                                var t = it(e, n);
                                                void 0 !== t && r.push(t)
                                            })), l && 28 === l.getFeature()) {
                                            var s = l.getRequiredAction() + "_" + (l.getProductType() || 0);
                                            if (!i[s]) {
                                                var u = new Ke.d4N;
                                                u.setAction(l.getDisplayAction()).setHeader(l.getDisplayMessage()).setMssg(l.getDisplayMessage()).setOkAction(l.getRequiredAction()).setOtherText("").setPictures(l.getDisplayImages()).setPromoBlockPosition(1).setPromoBlockType(1), l.getProductType() && u.setOkPaymentProductType(l.getProductType());
                                                var f = it(u, n);
                                                void 0 !== f && r.unshift(f)
                                            }
                                        }
                                        return r
                                    }(e, l.length, Ee);
                                return function(e) {
                                    var t = (0, dt.A)(e);
                                    return null == t ? void 0 : t.getLastBlock()
                                }(r) && (xe.current = !0), l.forEach((function(e, n) {
                                    t && 0 === n || a.push({
                                        banner: s[n]
                                    }), a.push({
                                        users: e
                                    })
                                })), Te(e.getPromoBanners([]).filter(et), {
                                    onUserClick: i
                                }), a
                            }), [n, _e.getScrollableProfileUser, Te, Be]),
                            Ce = (0, r.useCallback)((function(e) {
                                if (void 0 === e && (e = !1), xe.current) return Promise.resolve({});
                                he.current = !0, $(!0);
                                var t, n, r, o = 0 === M.length || e,
                                    i = new Le.A({
                                        folderId: 10
                                    }),
                                    c = !0 === l && o,
                                    a = Tt(Tt({
                                        folderId: 10,
                                        clientSource: 117
                                    }, (t = {}, n = Ae.current, (r = n ? ct.F4.getActivityFilter() : lt.g_.ALL) && void 0 !== at.C9[r] ? ut(ut({}, t), {}, {
                                        activityFilter: at.C9[r]
                                    }) : t)), function(e, t) {
                                        var n = [],
                                            r = 0,
                                            o = 0;
                                        return e.forEach((function(e) {
                                            e.banner ? (e.banner.type && n.push(e.banner.type), r++) : o++
                                        })), {
                                            preferredCount: 3 * t,
                                            promoBlockRequestParams: [{
                                                position: 1,
                                                shownPromoBlocks: n,
                                                count: o - r + 3
                                            }]
                                        }
                                    }(M, je.current));
                                return c || e || (a.offset = function(e, t) {
                                    var n = e.filter((function(e) {
                                        return Boolean(e.users)
                                    }));
                                    return n.length * t
                                }(M, je.current)), _e.folder.current = (0, qe.A)(c ? i.get(a) : i.fetch(a, !1, !0)), _e.folder.current.then((function(e) {
                                    var t = e[0],
                                        n = Ue(t, o);
                                    return H((function(e) {
                                        return e.concat(n)
                                    })), $(!1), Q(o && 0 === n.length), b.A.render(), he.current = !1, t
                                }))
                            }), [he, l, _e.folder, M, Ue]),
                            De = (0, r.useCallback)((function() {
                                xe.current = !1, H([]), Le.A.getInstance().invalidateFolder(10), Ce(!0).then((function() {
                                    K(!1)
                                })).catch(Ut)
                            }), [Ce]),
                            Ye = function() {
                                ye(!0), (0, g.sx)(332, {
                                    element: 488,
                                    parent_element: 94
                                })
                            },
                            Ge = function() {
                                te(void 0), be(!1), i.A.navigate(c.x.PEOPLE_NEARBY), _e.getScrollableProfileUser.current.cancel()
                            },
                            Xe = (0, r.useCallback)((function() {
                                he.current || xe.current || Ce().catch(Ut)
                            }), [he, xe, Ce]),
                            Ze = (0, At.A)({
                                list: M,
                                hasMore: !xe.current,
                                onFetchMore: Xe
                            })[0];
                        (0, r.useEffect)((function() {
                            if (O) {
                                ke();
                                var e = function() {
                                    _e.getScrollableProfileUser.current = z.A.getUserById({
                                        id: O,
                                        clientSource: 2,
                                        folderType: 10
                                    }), _e.getScrollableProfileUser.current.then((function(e) {
                                        Ne({
                                            user: e,
                                            onlyUpdateState: !0
                                        })
                                    })).catch(Dt)
                                };
                                P.A.controllerSetPromise().then(e).catch(e)
                            } else Ne({
                                onlyUpdateState: !0
                            })
                        }), [_e.getScrollableProfileUser, O]), (0, r.useEffect)((function() {
                            ct.F4.getIsActive() && Ye(), vt.A.init(3)
                        }), []), (0, r.useEffect)((function() {
                            je.current = j, Se.current || De()
                        }), [Se, j]), (0, r.useEffect)((function() {
                            l || Le.A.getInstance().invalidateFolder(10), K(!0), Promise.all([vt.A.start(3), (_e.settings.current = (0, qe.A)(Fe.A.getInstance().get()), _e.settings.current.then((function(e) {
                                Ae.current = Boolean(null == e ? void 0 : e.privacy_show_online_status)
                            }), (function(e) {
                                if (!(0, mt.A)(e)) throw e
                            })))]).then((function() {
                                Ce().then((function() {
                                    K(!1), l && o && (0, Qe.V)(a.A, o), null == f || f.stop(), (0, yt.A)("People nearby interactive", 22), d.on(Re.A.ACTIONS.TOOLTIP_SHOWN, s).on(Re.A.ACTIONS.TOOLTIP_DISMISSED, u), Oe.current = !0
                                })).catch(Ut)
                            })).catch(Ut), (0, g.sx)(258, {
                                element: 56
                            });
                            var e = function() {
                                    I((0, St.X)())
                                },
                                t = function() {
                                    var t = y.A.getSync(302);
                                    if (E(t.enabled), N && 125 === t.required_action && t.display_message !== N && B(t.display_message), e(), y.A.getSync(19).enabled) {
                                        var n = function(e, t, n) {
                                            var r = [],
                                                o = [];
                                            return t[e] ? (t[e].forEach((function(e) {
                                                r.push(e);
                                                var t = n.find((function(t) {
                                                    var n;
                                                    return (null == (n = t.banner) ? void 0 : n.id) === e
                                                }));
                                                null != t && t.banner && o.push(t.banner.type)
                                            })), r) : r
                                        }(6, Pe.current, M);
                                        rt(n).then(we)
                                    }
                                };
                            y.A.on(y.A.EVENTS.UPDATE, t);
                            var n = function(e) {
                                e.error && Ve.A.showNotification({
                                    type: Ve.A.TYPES.ERROR
                                })
                            };
                            Ie.A.on(Ie.A.EVENTS.END_PAYMENT, n);
                            var r = function(e) {
                                var t;
                                3 === e.type && rt((t = [], M.forEach((function(e) {
                                    e.banner && t.push(e.banner.id)
                                })), t)).then(we)
                            };
                            h.aV.onResponse(158, r), Se.current = !1;
                            var i = y.A.getSync(302);
                            return E(i.enabled), e(),
                                function() {
                                    _e.folder.current.cancel(), _e.settings.current.cancel(), y.A.off(y.A.EVENTS.UPDATE, t), h.aV.offResponse(158, r), Ie.A.off(Ie.A.EVENTS.END_PAYMENT, n), Oe.current && d.off(Re.A.ACTIONS.TOOLTIP_SHOWN, s).off(Re.A.ACTIONS.TOOLTIP_DISMISSED, u), b.A.destroy(b.A.placements.PNB)
                                }
                        }), []), (0, r.useEffect)((function() {
                            q && (0, g.sx)(258, {
                                element: 70,
                                screen_name: 2
                            })
                        }), [q]), (0, r.useEffect)((function() {
                            _ && R(Pt.A.getInstance().getCurrentChatBlockers())
                        }), [_]), (0, r.useEffect)((function() {
                            function e() {
                                B(void 0), document.body.removeEventListener("click", e)
                            }
                            return N && document.body.addEventListener("click", e),
                                function() {
                                    document.body.removeEventListener("click", e)
                                }
                        }), [N]);
                        var $e = function(e) {
                                var t;
                                e ? Ne({
                                    user: e,
                                    onlyUpdateState: !0
                                }) : null == a.A || null == (t = a.A.location) || null == t.reload || t.reload()
                            },
                            tt = function(e) {
                                var t = oe(ie, le, e);
                                if (t) return function() {
                                    var n = t.getUserId();
                                    ke(), _e.getScrollableProfileUser.current = z.A.getUserById({
                                        id: n,
                                        clientSource: 2,
                                        folderType: 10
                                    }), _e.getScrollableProfileUser.current.then((function(t) {
                                        Ne({
                                            user: t
                                        });
                                        var r = oe(ie, n, e);
                                        r && Be(r.getUserId())
                                    })).catch(Dt)
                                }
                            },
                            nt = function() {
                                return tt(!0)
                            },
                            st = function() {
                                var e = {
                                    user: ee,
                                    voteType: 2,
                                    clientSource: 2
                                };
                                Nt.handleVote(e).then((function() {
                                    return _e.getScrollableProfileUser.current = z.A.getUserById({
                                        id: le,
                                        clientSource: 2,
                                        folderType: 10
                                    }), _e.getScrollableProfileUser.current.then((function(e) {
                                        var t = i.A.getLocation() || {},
                                            n = t.routeName === c.x.PEOPLE_NEARBY || t.routeName === c.x.MUTUAL_ATTRACTION;
                                        Ne({
                                            user: e,
                                            onlyUpdateState: n
                                        })
                                    }))
                                })).catch((function(e) {
                                    e instanceof He.Ay || Dt(e)
                                }))
                            },
                            ft = function(e) {
                                var t = nt();
                                (e ? Promise.resolve(e) : z.A.getUserById({
                                    id: le,
                                    forced: !0
                                })).then((function(e) {
                                    var n = ie.find((function(e) {
                                        return (null == e || null == e.getUserId ? void 0 : e.getUserId()) === le
                                    }));
                                    null == n || null == n.setIsBlocked || n.setIsBlocked(!0), jt.A.isActive() && De(), t ? t() : $e(e)
                                }))
                            },
                            gt = function(e) {
                                $e(e)
                            },
                            ht = function(e) {
                                $e(e)
                            },
                            xt = function(e) {
                                $e(e)
                            };
                        (0, r.useEffect)((function() {
                            return m.A.on(m.A.USER_BLOCKED, ft), m.A.on(m.A.USER_UNBLOCKED, gt), m.A.on(m.A.USER_REPORTED, ft), m.A.on(m.A.USER_FAVOURITED, ht), m.A.on(m.A.USER_REACTION_SENT, xt), m.A.on(m.A.USER_QUICK_MESSAGE_SENT, xt), m.A.on(m.A.USER_QUICK_HELLO_OR_SMILE_SENT, xt),
                                function() {
                                    m.A.off(m.A.USER_BLOCKED, ft), m.A.off(m.A.USER_UNBLOCKED, gt), m.A.off(m.A.USER_REPORTED, ft), m.A.off(m.A.USER_FAVOURITED, ht), m.A.off(m.A.USER_REACTION_SENT, xt), m.A.off(m.A.USER_QUICK_MESSAGE_SENT, xt), m.A.off(m.A.USER_QUICK_HELLO_OR_SMILE_SENT, xt)
                                }
                        }));
                        var _t = function() {
                                var e, t, n, r, o;
                                (e = Nt.handleSmileSendChatMessage(ee, (n = null == (t = v.A.getUser()) ? void 0 : t.gender, r = Boolean(null == ee || null == ee.getAllowSmile ? void 0 : ee.getAllowSmile()), o = Boolean(null == ee || null == ee.getAllowReaction ? void 0 : ee.getAllowReaction()), Boolean((r || o) && 1 === n)))) && (_e.getScrollableProfileUser.current = e, _e.getScrollableProfileUser.current.then((function(e) {
                                    return Ne({
                                        user: e,
                                        onlyUpdateState: !0
                                    })
                                })).catch(Dt))
                            },
                            wt = (0, r.useCallback)((function(e) {
                                ke(), _e.getScrollableProfileUser.current = z.A.getUserById({
                                    id: e,
                                    clientSource: 2,
                                    folderType: 10
                                }), _e.getScrollableProfileUser.current.then((function(e) {
                                    return Ne({
                                        user: e,
                                        onlyUpdateState: !0
                                    })
                                })).catch(Dt)
                            }), [_e.getScrollableProfileUser]);
                        (0, r.useEffect)((function() {
                            return m.A.on(m.A.PNB_USER_UPDATED, wt),
                                function() {
                                    m.A.off(m.A.PNB_USER_UPDATED, wt)
                                }
                        }), [wt]);
                        var It, kt, Ct, Lt, Ft;
                        return (0, C.jsxs)(r.Fragment, {
                            children: [(0, C.jsx)(L, {
                                scrollableElement: t,
                                header: (0, C.jsx)(Z, {
                                    clientSource: A,
                                    chatUnblockers: _ ? {
                                        numChatUnblockers: D,
                                        isPremiumPlus: T,
                                        tooltip: N,
                                        onClick: function() {
                                            var e = y.A.getSync(302);
                                            4 === e.required_action ? Ot.A.navigateToPayment({
                                                back: i.A.getUrl(),
                                                productType: e.product_type,
                                                hotPanelData: {
                                                    activationPlace: 3
                                                }
                                            }) : 125 === e.required_action && B(e.display_message)
                                        }
                                    } : void 0,
                                    onClickPopularity: re,
                                    onClickFilter: Ye
                                }),
                                chunks: Bt({
                                    chunks: M,
                                    onPromoSelected: n,
                                    onBannerAction: Rt,
                                    listContainerRef: Ze
                                }),
                                isEmpty: q,
                                onClickEmptyAction: function() {
                                    (0, g.sx)(332, {
                                        element: 62,
                                        parent_element: 70
                                    }), ye(!0)
                                },
                                isLoading: Y,
                                isFetching: X
                            }), (kt = null == ee ? void 0 : ee.getUserId(), Ct = null == ee || null == ee.getAllowSmile ? void 0 : ee.getAllowSmile(), Lt = null == ee || null == ee.getAllowChat ? void 0 : ee.getAllowChat(), Ft = !Ct && Lt && Nt.handleChat(kt), (0, C.jsx)(fe.A, {
                                user: ee,
                                userDistanceInfo: S,
                                mode: de._.PNB,
                                onClose: Ge,
                                onPrev: tt(!1),
                                onNext: nt(),
                                nextUserId: (It = oe(ie, le, !0), It ? It.getUserId() : ""),
                                onVoteYes: st,
                                onSmile: _t,
                                onChat: Ft,
                                isLoading: pe
                            })), me ? (0, C.jsx)(Et.A, {
                                searchType: 2,
                                onSave: function() {
                                    b.A.destroy(b.A.placements.PNB), K(!0), Me.A.getInstance().invalidate()
                                },
                                onSaveSuccess: function() {
                                    return De()
                                },
                                onClose: function() {
                                    return ye(!1)
                                }
                            }) : null]
                        })
                    },
                    Ft = n(27378);

                function Mt(e, t) {
                    return Mt = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, Mt(e, t)
                }
                var Ht = function(e) {
                    var t, n;

                    function o(t) {
                        var n;
                        return (n = e.call(this, t) || this).activationPlace = 3, n.clientSource = 2, n.screenName = 2, n.onboardingTipsController = Re.A.getInstance(), n.scrollableElement = void 0, n.preventNotifications = function() {
                            n.notificationScreenAccess = 3
                        }, n.allowNotifications = function() {
                            n.notificationScreenAccess = 1
                        }, n.jinba = new Ft.A("PeopleNearby", 21), n.jinba.start(Date.now()), n.scrollableElement = (0, r.createRef)(), n
                    }
                    n = e, (t = o).prototype = Object.create(n.prototype), t.prototype.constructor = t, Mt(t, n);
                    var a = o.prototype;
                    return a.componentDidMount = function() {
                        e.prototype.componentDidMount.call(this), this.onboardingTipsController.setContext(this.clientSource)
                    }, a.updateUrlPath = function() {
                        "people-nearby" === this.getParameters().page || i.A.navigate(c.x.PEOPLE_NEARBY, !0)
                    }, a.getScrollableElement = function() {
                        return this.scrollableElement.current ? this.scrollableElement.current : null
                    }, a.render = function() {
                        var e = this.props,
                            t = e.saveScrollPosition,
                            n = e.scrollPosition,
                            r = e.navigatedBack;
                        return this.addPageWrapper((0, C.jsx)(Lt, {
                            scrollableElement: this.scrollableElement,
                            saveScrollPosition: t,
                            scrollPosition: n,
                            navigatedBack: r,
                            onPreventNotifications: this.preventNotifications,
                            onAllowNotifications: this.allowNotifications,
                            jinba: this.jinba,
                            clientSource: this.clientSource,
                            onboardingTipsController: this.onboardingTipsController,
                            scrollableProfileUserId: this.getParameter("id"),
                            scrollableProfileDistanceInfo: this.getParameter("userDistanceInfo")
                        }), "people-nearby")
                    }, o
                }(o.A);
                Ht.transition = !1, Ht.hasTabBar = !0;
                var Vt = Ht
            },
            69110: function(e, t, n) {
                n(45700), n(89572), n(52675), n(89463), n(26099), n(2892), n(84185), n(79432), n(2008), n(83851), n(51629), n(23500), n(81278), n(67945);
                var r = n(96540),
                    o = n(65297),
                    i = n(23336),
                    c = n(74848);

                function a(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function l(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? a(Object(n), !0).forEach((function(t) {
                            s(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function s(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                t.A = function(e) {
                    var t = (0, r.useState)(!1),
                        n = t[0],
                        a = t[1];

                    function s() {
                        a(!0)
                    }

                    function u() {
                        a(!1)
                    }
                    return (0, r.useEffect)((function() {
                        return o.A.on(o.A.SHOW_MODAL, s), o.A.on(o.A.HIDE_MODAL, u),
                            function() {
                                o.A.off(o.A.SHOW_MODAL, s), o.A.off(o.A.HIDE_MODAL, u)
                            }
                    }), []), (0, c.jsx)(i.A, l(l({}, e), {}, {
                        disabled: n
                    }))
                }
            },
            74689: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return s
                    }
                });
                var r = n(74848),
                    o = n(96540),
                    i = n(32485),
                    c = n.n(i);
                var a = ({
                    children: e,
                    cols: t = 3
                }) => {
                    const n = c()({
                        "csms-user-list": !0,
                        "csms-user-list--chess": !0,
                        [`csms-user-list--chess-cols-${t}`]: {
                            cols: t
                        }
                    });
                    return (0, r.jsx)("ul", {
                        className: n,
                        children: e
                    })
                };
                var l = ({
                    children: e,
                    cols: t = 3
                }) => {
                    const n = c()({
                        "csms-user-list": !0,
                        "csms-user-list--grid": !0,
                        [`csms-user-list--grid-cols-${t}`]: {
                            cols: t
                        }
                    });
                    return (0, r.jsx)("ul", {
                        className: n,
                        children: e
                    })
                };
                var s = ({
                    children: e,
                    layout: t,
                    cols: n
                }) => {
                    const i = o.Children.map(e, (e => (0, r.jsx)("li", {
                        className: "csms-user-list__item",
                        children: e
                    })));
                    switch (t) {
                        case "grid":
                            return (0, r.jsx)(l, {
                                cols: n,
                                children: i
                            });
                        case "chess":
                            return (0, r.jsx)(a, {
                                cols: n,
                                children: i
                            })
                    }
                }
            },
            78938: function(e, t, n) {
                n.d(t, {
                    DD: function() {
                        return c
                    },
                    Eu: function() {
                        return a
                    },
                    GT: function() {
                        return i
                    },
                    PK: function() {
                        return l
                    },
                    mg: function() {
                        return s
                    },
                    nW: function() {
                        return o
                    }
                });
                var r = n(79860);

                function o(e) {
                    (0, r.sx)(138, {
                        banner_id: e.promo_block_type,
                        context: e.context,
                        position_id: e.promo_block_position,
                        variation_id: e.stats_variation_id
                    })
                }

                function i(e, t) {
                    void 0 === t && (t = 1);
                    var n = e.context,
                        o = e.promo_block_position,
                        i = e.promo_block_type;
                    (0, r.sx)(139, {
                        banner_id: i,
                        call_to_action_type: t,
                        context: n,
                        position_id: o,
                        variation_id: e.stats_variation_id
                    })
                }

                function c() {
                    (0, r.sx)(258, {
                        element: 191
                    })
                }

                function a() {
                    (0, r.sx)(332, {
                        element: 191
                    })
                }

                function l() {
                    (0, r.sx)(258, {
                        element: 1558
                    })
                }

                function s() {
                    (0, r.sx)(332, {
                        element: 1558
                    })
                }
            },
            81712: function(e, t, n) {
                n.d(t, {
                    x: function() {
                        return r
                    }
                });
                n(50113), n(26099);

                function r(e, t, n) {
                    var r;
                    return null == (r = e.buttons) ? void 0 : r.find((function(e) {
                        var r = !0;
                        return n && (r = e.action === n), r && e.type === t
                    }))
                }
            },
            90797: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return d
                    }
                });
                var r, o = n(26914),
                    i = n(27895),
                    c = n(8483),
                    a = n(25675),
                    l = n(93827),
                    s = n(74848),
                    u = function(e) {
                        var t = e.text;
                        return (0, s.jsx)("div", {
                            className: "credits-feature-finished-text-media",
                            children: (0, s.jsx)(l.w4, {
                                children: t
                            })
                        })
                    },
                    f = ((r = {})[a.u.ATTENTION_BOOST] = "badge-feature-attention-boost", r[a.u.BADOO_BOOST] = "badge-feature-boost", r[a.u.EXTRA_SHOWS] = "badge-feature-extra-shows", r[a.u.RISE_UP] = "badge-feature-riseup", r),
                    d = function(e) {
                        var t = e.text,
                            n = e.url,
                            r = e.type,
                            a = Boolean(t || n);
                        return a ? (0, s.jsx)(i.A, {
                            children: (0, s.jsx)(o.A, {
                                badge: a ? {
                                    icon: {
                                        name: f[r]
                                    }
                                } : void 0,
                                content: !n && t ? (0, s.jsx)(u, {
                                    text: t
                                }) : void 0,
                                image: n ? {
                                    src: n
                                } : void 0,
                                shape: "circle",
                                size: "md"
                            })
                        }) : (0, s.jsx)(i.A, {
                            size: "icon",
                            children: (0, s.jsx)(c.A, {
                                name: f[r],
                                color: "feature-revenue"
                            })
                        })
                    }
            },
            93019: function(e, t, n) {
                n.d(t, {
                    I: function() {
                        return i
                    },
                    p: function() {
                        return c
                    }
                });
                n(62062);
                var r, o = ((r = {})[0] = "unknown", r[1] = "friends", r[2] = "chat", r[3] = "date", r[4] = "casual", r[5] = "serious", r[6] = "dont_mind", r[7] = "business", r[8] = "long_commitment", r),
                    i = function(e) {
                        switch (e) {
                            case 2:
                                return {
                                    name: "generic-bubble",
                                    color: "default"
                                };
                            case 3:
                                return {
                                    name: "generic-cup",
                                    color: "default"
                                };
                            case 5:
                                return {
                                    name: "generic-heart",
                                    color: "default"
                                };
                            default:
                                return
                        }
                    },
                    c = function(e, t, n) {
                        return e.map((function(e) {
                            var r = i(e.type);
                            return {
                                id: e.tiw_phrase_id,
                                header: e.tiw_phrase,
                                description: e.tiw_description,
                                isSelected: e.tiw_phrase_id === t,
                                onOptionClick: function() {
                                    return n(e.tiw_phrase_id)
                                },
                                type: o[e.type || 0],
                                icon: r
                            }
                        }))
                    }
            },
            95297: function(e, t, n) {
                n.d(t, {
                    y: function() {
                        return a
                    }
                });
                var r = n(25675);

                function o(e) {
                    switch (e) {
                        case 349:
                            return r.u.ATTENTION_BOOST;
                        case 352:
                        default:
                            return r.u.BADOO_BOOST;
                        case 341:
                            return r.u.EXTRA_SHOWS;
                        case 350:
                            return r.u.RISE_UP
                    }
                }
                var i = n(79880),
                    c = 100;

                function a(e) {
                    var t, n = null == (t = e.pictures) ? void 0 : t[0],
                        r = null == n ? void 0 : n.display_images;
                    return {
                        text: null == n ? void 0 : n.badge_text,
                        type: o(e.promo_block_type),
                        url: r ? (0, i.A)(r, c, c) : void 0
                    }
                }
            },
            95836: function(e, t, n) {
                var r = n(74848),
                    o = n(32485),
                    i = n.n(o),
                    c = n(84362),
                    a = n(26914),
                    l = n(8483),
                    s = n(53787),
                    u = n(93827);
                t.A = ({
                    shape: e = "rectangle",
                    user: t,
                    badge: n,
                    overlay: o,
                    halo: f,
                    isBumped: d,
                    onClick: p,
                    innerRef: g,
                    dataQA: b,
                    a11y: v
                }) => {
                    const m = Boolean(v ? .label),
                        y = i()({
                            "csms-user-list-cell": !0,
                            [`csms-user-list-cell--${e}`]: e
                        });
                    return (0, r.jsxs)("button", {
                        className: y,
                        onClick: p,
                        ref: g,
                        type: "button",
                        ...b,
                        children: [(0, r.jsxs)("span", {
                            className: "csms-user-list-cell__content",
                            "aria-hidden": m,
                            children: [(0, r.jsx)("span", {
                                className: "csms-user-list-cell__media",
                                children: (0, r.jsx)("span", {
                                    className: "csms-user-list-cell__media-brick-wrapper",
                                    children: (0, r.jsx)(a.A, {
                                        user: t,
                                        badge: n,
                                        halo: f,
                                        overlay: o,
                                        shape: "circle" === e ? "circle" : "squared-fixed"
                                    })
                                })
                            }), t.name ? (0, r.jsxs)("span", {
                                className: "csms-user-list-cell__text",
                                children: [d ? (0, r.jsx)("span", {
                                    className: "csms-user-list-cell__bump",
                                    children: (0, r.jsx)(l.A, {
                                        name: "badge-feature-bump"
                                    })
                                }) : null, (0, r.jsx)(u.P3, {
                                    color: "black",
                                    ellipsis: !0,
                                    a11y: {
                                        ariaHidden: m
                                    },
                                    children: (0, r.jsx)(s.A, {
                                        name: t.name,
                                        status: t.status,
                                        age: t.age
                                    })
                                })]
                            }) : null]
                        }), (0, r.jsx)(c.A, {
                            children: v ? .label
                        })]
                    })
                }
            },
            97547: function(e, t, n) {
                n.d(t, {
                    V: function() {
                        return i
                    }
                });
                var r = n(99417);

                function o(e) {
                    this.wrapper = e, this.reset()
                }

                function i(e, t, n) {
                    try {
                        e.scrollTo({
                            behavior: n ? "smooth" : "instant",
                            top: t
                        })
                    } catch (n) {
                        if (!(n instanceof TypeError)) throw n;
                        e && "function" == typeof e.scrollTo && e.scrollTo(0, t)
                    }
                }

                function c(e) {
                    return e.wrapper.scrollHeight - e.scrollBottom - r.A.innerHeight
                }
                o.prototype = {
                    restore: function(e) {
                        this.scrollTop = e ? this.scrollTop : c(this), i(this.wrapper, this.scrollTop, !1)
                    },
                    prepare: function() {
                        this.scrollBottom = this.wrapper.scrollHeight - this.wrapper.scrollTop - r.A.innerHeight, this.scrollTop = c(this)
                    },
                    reset: function() {
                        this.scrollBottom = 0, this.scrollTop = c(this)
                    },
                    scrollIntoView: function(e, t, n) {
                        e && i(this.wrapper, e.offsetTop - (t || 0), n)
                    },
                    scrollToBottom: function(e) {
                        i(this.wrapper, this.wrapper.scrollHeight + this.wrapper.clientHeight, e)
                    },
                    scrollBy: function(e, t) {
                        i(this.wrapper, this.wrapper.scrollTop + e, t)
                    },
                    scrollTo: function(e, t) {
                        i(this.wrapper, e, t)
                    }
                }, t.A = o
            }
        }
    ]);
//# sourceMappingURL=people-nearby.f67fa44dca40a201288d.js.map
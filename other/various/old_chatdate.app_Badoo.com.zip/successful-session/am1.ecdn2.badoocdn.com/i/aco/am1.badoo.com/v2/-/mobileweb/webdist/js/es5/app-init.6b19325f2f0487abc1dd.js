var _global;
! function() {
    try {
        var t = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            e = (new Error).stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "d4f6d343-d0e4-4c53-b8cb-505e0407ef52", t._sentryDebugIdIdentifier = "sentry-dbid-d4f6d343-d0e4-4c53-b8cb-505e0407ef52")
    } catch (t) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var t = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                e = (new Error).stack;
            e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "d4f6d343-d0e4-4c53-b8cb-505e0407ef52", t._sentryDebugIdIdentifier = "sentry-dbid-d4f6d343-d0e4-4c53-b8cb-505e0407ef52")
        } catch (t) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [7799], {
            1116: function(t, e, n) {
                n(33110), n(60739), n(27208), n(50113), n(26099), n(16034);
                var i, o, r = n(23735),
                    a = n(99417),
                    s = n(58385),
                    c = n(18084),
                    u = n(74389),
                    l = c.A.getLogger("SecurityCheck"),
                    f = ((i = {})[1] = u.x.SECURITY_SOCIAL_NETWORK, i[2] = u.x.SECURITY_EMAIL, i[4] = u.x.SECURITY_PHONE_CALL, i[5] = u.x.SECURITY_SMS, i[6] = u.x.SECURITY_COMPLETE_PHONE, i[7] = u.x.SECURITY_COMPLETE_EMAIL, i),
                    d = !1;

                function p(t, e) {
                    t || (e instanceof Error ? l.error(e.message) : e && 51 === e.getType() && function() {
                        if (d) return;
                        d = !0, new r.Ay(523, null).on(r.Dl.ON_REQ_END, (function() {
                            d = !1
                        })).request()
                    }())
                }

                function h(t, e) {
                    if (t) l.error("Security check response error", JSON.stringify(t));
                    else {
                        var n = e.toJSON ? e.toJSON() : e;
                        0 !== n.type ? o && Date.now() < o + 3e4 ? a.A.location.reload() : function(t) {
                            var e = f[t.type],
                                n = (i = s.A.getLocation(), Boolean(Object.values(f).find((function(t) {
                                    return t === i.routeName
                                }))));
                            var i;
                            s.A.navigate(e, n, {
                                clientSecurityPage: t
                            })
                        }(n) : a.A.location.reload()
                    }
                }
                e.A = {
                    init: function() {
                        r.Kj.on(1, p), r.Kj.on(524, h)
                    },
                    notifySecurityCheckPassed: function() {
                        o = Date.now()
                    },
                    getRouteNameFromSecurityPage: function(t) {
                        return !!t && f[t.type]
                    }
                }
            },
            11680: function(t, e, n) {
                n.d(e, {
                    s: function() {
                        return i
                    }
                });
                var i = {
                        ERROR: "ERROR",
                        INFO: "INFO",
                        PAYMENT: "PAYMENT",
                        MESSAGE: "MESSAGE",
                        PHOTO_UPLOAD: "PHOTO_UPLOAD"
                    },
                    o = function() {};
                o.showNotification = void 0, o.updateNotification = void 0, o.TYPES = void 0
            },
            12321: function(t, e, n) {
                n.d(e, {
                    N: function() {
                        return a
                    }
                });
                var i, o = n(63620),
                    r = ((i = {})[254] = o.l.ANCHOR_MOOD_STATUS, i);

                function a(t) {
                    return t && r[t]
                }
            },
            13463: function(t, e, n) {
                n.d(e, {
                    Z: function() {
                        return o
                    }
                });
                var i = n(81712);

                function o(t, e) {
                    return (0, i.x)(t, 3, e)
                }
            },
            14680: function(t, e, n) {
                var i = n(51709),
                    o = n(79752),
                    r = n(74848);
                e.A = function(t) {
                    var e = t.label,
                        n = t.children,
                        a = t.errorMessage,
                        s = t.errorId,
                        c = t.hintMessage,
                        u = t.hintId,
                        l = t.hintIcon,
                        f = t.noteExtra,
                        d = t.dataQa,
                        p = t.fieldId,
                        h = t.tag,
                        g = a || f && !c ? {
                            text: a,
                            variant: "error",
                            extra: f,
                            id: s
                        } : void 0,
                        _ = c || f && !a ? {
                            text: c,
                            extra: g ? void 0 : f,
                            id: u,
                            icon: l
                        } : void 0;
                    return (0, r.jsx)(o.A, {
                        label: (0, i.Fi)(e),
                        status: g,
                        hint: _,
                        fieldId: p,
                        tag: h,
                        dataQA: d,
                        children: n
                    })
                }
            },
            15680: function(t, e, n) {
                var i = n(75248),
                    o = (0, n(58544).lh)(),
                    r = {
                        onChange: o.subscribe,
                        start: function() {
                            i.A.getInstance().on(i.A.Type.COMET_CONFIG, (function(t) {
                                r.cometConfiguration = t, o.trigger()
                            }))
                        }
                    };
                e.A = r
            },
            16427: function(t, e, n) {
                n(58940);
                var i = n(85208),
                    o = n(42302),
                    r = n(99417),
                    a = n(80294),
                    s = n(23735),
                    c = n(73090),
                    u = n(58544),
                    l = n(65297),
                    f = n(23318),
                    d = n(18084),
                    p = n(30397),
                    h = n(23715),
                    g = n(15680),
                    _ = n(28030),
                    A = n(92105),
                    m = n(15566),
                    v = {
                        WRITING: 2
                    };

                function y() {
                    (0, A.A)(this), this.log = d.A.getLogger("Comet"), this.comet_ = new a.A
                }

                function T(t) {
                    return (0, f.A)(t, 19)
                }(0, i.A)(y.prototype, u.zb, {
                    comet_: null,
                    pingTimeoutId_: null,
                    lastPingTime_: 0,
                    lastActiveTime_: 0,
                    isActive_: !1,
                    userId_: null,
                    connectionLost_: !1,
                    init: function() {
                        var t = this;
                        return l.A.on(l.A.Session.LOGOUT, this.disconnect_).on(l.A.Session.SESSION_CHANGED, this.onSessionChange_), h.A.on(h.A.EVENTS.ONLINE, this.softReconnect, this), g.A.onChange((function() {
                            return t.configure_()
                        })), _.A.onChange((function(e) {
                            var n = T(e);
                            n && (t.userId_ = n, t.comet_.session_change(n), t.softReconnect())
                        })), this.comet_.on("im:new_msg", this.onNewMsg_, this).on("im:writing", this.onMessageWriting_, this).on("gpb:push", this.onPush_, this).on("unauth", this.onUnauth_, this).on("start", this.onStart_, this).on("stop", this.onStop_, this).on("open", this.onOpen_, this).on("close", this.onClose_, this), p.A.on(p.A.ACTIONS.WAKE_UP, this.onShown_, this).on(p.A.ACTIONS.SLEEP, this.onHidden_, this), this
                    },
                    configureComet_: function(t) {
                        if (!t) return !1;
                        var e = this.comet_;
                        if (e.url === t.path && e.seq === t.sequence) return !1;
                        e.mode = "master";
                        var n = T(_.A.getSettings());
                        return !!n && (this.userId_ = n, e.configure(t.path, t.sequence, n), e.channel("im", {
                            mid: 0
                        }), !0)
                    },
                    softReconnect: function() {
                        c.A.isLoggedIn() ? this.userId_ ? this.comet_.user_id && (this.userId_ === this.comet_.user_id ? (this.isActive_ = !0, this.comet_.soft_reconnect()) : this.log.error("softReconnect UserId is unequal " + this.userId_ + "!=" + this.comet_.user_id)) : this.log.error("softReconnect without UserId") : this.disconnect_()
                    },
                    hasUserId: function() {
                        return Boolean(this.userId_)
                    },
                    onHidden_: function() {
                        this.comet_.stop(), this.isActive_ = !1
                    },
                    onShown_: function() {
                        c.A.isLoggedIn() && this.softReconnect()
                    },
                    updatePing_: function() {
                        if (this.pingTimeoutId_ && (r.A.clearTimeout(this.pingTimeoutId_), this.pingTimeoutId_ = null), this.comet_.run) {
                            var t = this.lastPingTime_ + 6e5,
                                e = +new Date;
                            if (t < e) this.onPing_();
                            else {
                                var n = t - e + 1;
                                this.pingTimeoutId_ = setTimeout(this.onPing_, n)
                            }
                        }
                    },
                    onPing_: function() {
                        this.lastPingTime_ = +new Date, new s.Ay(0, null).on(0, o.A).request(), this.updatePing_()
                    },
                    disconnect_: function() {
                        this.comet_.unauth(), this.isActive_ = !1
                    },
                    configure_: function() {
                        this.configureComet_(g.A.cometConfiguration) && this.softReconnect()
                    },
                    onNewMsg_: function(t, e) {
                        s.Kj.send(e)
                    },
                    onMessageWriting_: function(t) {
                        this.trigger(v.WRITING, t)
                    },
                    onPush_: function(t) {
                        s.Kj.send(t)
                    },
                    onSessionChange_: function() {
                        if (this.isActive_ && c.A.isLoggedIn()) {
                            var t = T(_.A.getSettings());
                            t && (this.userId_ = t), this.comet_.session_change(t), this.softReconnect()
                        }
                    },
                    onStart_: function() {
                        var t;
                        this.lastPingTime_ = +new Date, this.updatePing_(), this.connectionLost_ && (this.connectionLost_ = !1, (t = new m.z5o).setBackgroundSession(!1), new s.Ay(199, t).on(387, o.A).request())
                    },
                    onOpen_: function() {
                        h.A.isOnline() && this.lastActiveTime_ && this.lastActiveTime_ + 3e4 <= +new Date && l.A.trigger("push-sync")
                    },
                    onStop_: function() {
                        this.updatePing_(), this.connectionLost_ = !0
                    },
                    onClose_: function(t, e) {
                        this.lastActiveTime_ = e
                    },
                    onUnauth_: function() {
                        this.disconnect_()
                    },
                    notifyWriting: function(t) {}
                });
                var I = null;
                y.getInstance = function() {
                    return I || (I = new y), I
                }, y.EVENTS = v, e.A = y
            },
            17315: function(t, e, n) {
                n(27495), n(71761), n(48598);
                var i = n(23735),
                    o = n(99417),
                    r = /'errno' => '([^']+)'/,
                    a = /'errmsg' => '(.*?)($|##uncutable##)/m;

                function s(t) {
                    if (o.A.console) {
                        var e = t.match(r),
                            n = t.match(a);
                        console.groupCollapsed ? e && n ? (console.groupCollapsed("%c%s", "color: red; font-weight: bold", "[SRV-ERROR " + e[1] + "] " + n[1]), console.error(t), console.groupEnd()) : (console.groupCollapsed("%c%s", "color: red; font-weight: bold", t.split("\n").slice(0, 3).join("\n")), console.error(t.split("\n").slice(3).join("\n")), console.groupEnd()) : console.error && console.error(t)
                    }
                }
                var c = {
                    init: function() {
                        i.Kj.on(6001, this.onTestError_)
                    },
                    onTestError_: function(t, e) {
                        if (!t)
                            for (var n = e.getErrors(), i = 0; i < n.length; i++) s(n[i])
                    }
                };
                e.A = c
            },
            17412: function(t, e, n) {
                var i, o, r;
                n.d(e, {
                        An: function() {
                            return o
                        },
                        qR: function() {
                            return i
                        },
                        vD: function() {
                            return r
                        }
                    }),
                    function(t) {
                        t[t.PROVIDER_PLAID = 0] = "PROVIDER_PLAID"
                    }(i || (i = {})),
                    function(t) {
                        t.INITIATE_FULLSCREEN_FLOW = "InitiateFullscreenFlow", t.INPUT_ERRORS = "InputErrors", t.SECURITY_CHECK = "SecurityCheck", t.STORE_DETAILS = "StoreDetails", t.SUBMIT_FORM = "SubmitForm", t.UPDATE_HEIGHT = "UpdateHeight"
                    }(o || (o = {})),
                    function(t) {
                        t.EMBEDDED = "embedded", t.REDIRECT = "redirect"
                    }(r || (r = {}))
            },
            21554: function(t, e, n) {
                n.r(e), n.d(e, {
                    default: function() {
                        return qn
                    }
                });
                var i = n(96540),
                    o = n(80224),
                    r = n(93184),
                    a = n(33527),
                    s = n(76854),
                    c = n(62608),
                    u = n(13315);
                var l, f = n(77409),
                    d = (n(72712), n(26099), n(3508)),
                    p = n(23735),
                    h = n(89730),
                    g = n(89104),
                    _ = n(93529);
                p.Kj.on(1, (function(t, e) {
                    if (e instanceof Error) throw e.message;
                    58 === (null == e ? void 0 : e.getType()) && d.A.get("env") !== g.A.PRODUCTION && (l = e)
                }));
                var A = n(5586),
                    m = n(88651),
                    v = n(59179),
                    y = n(58385),
                    T = n(3571),
                    I = n(79860),
                    N = n(49952),
                    b = n(99417),
                    O = n(28030),
                    S = n(74389);
                var E = n(1168),
                    C = n(17369),
                    P = n(18084),
                    w = n(75248),
                    x = n(88626),
                    D = n(15193),
                    k = n(20816),
                    R = P.A.getLogger("AuthManager"),
                    j = function(t) {
                        var e = t.inAppNotificationsDebounceOnLogin,
                            n = t.inAppNotificationsReset,
                            o = t.controllerInstance,
                            r = (0, i.useContext)(f.Ay),
                            a = r.Session,
                            s = r.config,
                            c = (0, i.useState)(!1),
                            u = c[0],
                            d = c[1],
                            p = (0, D.A)(u);
                        return (0, i.useEffect)((function() {
                            u ? T.A.destroy() : T.A.init()
                        }), [u]), (0, i.useEffect)((function() {
                            var t = a.getLoginObserver((function(t) {
                                var n = Boolean(null == t ? void 0 : t.isAuthenticated),
                                    i = t.clientLoginSuccess;
                                n && i ? function(t, e, n) {
                                    var i = t.onboarding_config,
                                        o = null == i ? void 0 : i.pages,
                                        r = null == i ? void 0 : i.registration_pages,
                                        a = e.get("default.authenticated.page"),
                                        s = e.get("forward.page");
                                    s && e.set("forward.page", null);
                                    var c = s || function(t, e) {
                                        if (!t) return e;
                                        var n = A.A.getRouteFromRedirectPage(t);
                                        if (!n) return R.error("No matching route found for client source " + t.redirect_page), e;
                                        return n
                                    }(t.redirect_page, a);
                                    o ? (E.A.handleOnboardingPages(o, r), u()) : L() ? ((0, N.cj)((function() {
                                        u()
                                    })), y.A.navigate(c, !0)) : (u(), c !== a && y.A.navigate(c, !0));
                                    o || t.is_first_login || b.A._badoo_noWhatsNew || O.A.getSettings().show_server_whats_new && y.A.navigate(S.x.WHATS_NEW, {
                                        backHistoryEntry: y.A.getHistoryEntryId()
                                    });

                                    function u() {
                                        n(), w.A.getInstance().enable(), l && (_.A.showNotification({
                                            type: _.A.TYPES.ERROR,
                                            text: l.getErrorMessage()
                                        }), (0, h.A)({
                                            error: l
                                        })), v.A.getInstance().preloadInstantPaywalls(), k.A.fetch()
                                    }
                                }(i, s, e) : function(t) {
                                    if (! function(t) {
                                            return Boolean(null == t ? void 0 : t.failure)
                                        }(t)) return;
                                    var e = t.str_form_data || [],
                                        n = t.failure;
                                    if (x.A.shouldRedirectToBlocked(n)) x.A.redirectToBlocked(n);
                                    else if (e.length > 0) {
                                        var i = e.reduce((function(t, e) {
                                            return t[e.key] = e.value, t
                                        }), {});
                                        y.A.navigate(S.x.SIGNUP, i)
                                    }
                                }(t.formFailure), d(n)
                            }));
                            return function() {
                                t.stop()
                            }
                        }), [a, s, e]), (0, i.useEffect)((function() {
                            "boolean" == typeof p && !1 !== p && (w.A.getInstance().disable(), n(), E.A.reset(), m.A.getInstance().reset(), L() || y.A.navigate(S.x.LANDING), null != o && o.activationPlace && (0, I.sx)(48, {
                                activation_place: o.activationPlace
                            }), C.Ay.checkAllowed() && a.sessionStartup())
                        }), [p]), null
                    };

                function L() {
                    var t = A.A.getRoute(y.A.getLocation().routeName);
                    return null == t ? void 0 : t.requiresAnonymous
                }
                var M = n(1270),
                    F = n(65297),
                    B = (n(28706), n(10287), n(60739), n(27208), n(74423), n(15086), n(50113), n(13264)),
                    V = n(58336),
                    U = n(89610),
                    Y = n(36521),
                    H = n(38337),
                    q = n(13614),
                    W = (n(3362), n(51629), n(23500), n(2892), n(27495), n(47632)),
                    G = "is-loading";
                var z = n(44762),
                    K = n(79087),
                    $ = n(8483),
                    Q = n(74848),
                    X = {
                        attention_boost: "badge-feature-attention-boost",
                        credits: "badge-coin",
                        crush: "badge-feature-crush",
                        extra_shows: "badge-feature-extra-shows",
                        favourites: "badge-feature-favourites",
                        mutual: "badge-feature-liked-you",
                        rise_up: "badge-feature-riseup",
                        spp: "badge-feature-premium",
                        photo_camera: "badge-add-photos",
                        message: "badge-chat"
                    },
                    J = {
                        cross: (0, Q.jsx)($.A, {
                            name: "badge-cross-hollow",
                            color: "gray-80"
                        }),
                        tick: (0, Q.jsx)($.A, {
                            name: "badge-check"
                        }),
                        photo_upload: (0, Q.jsx)($.A, {
                            name: "badge-camera"
                        })
                    },
                    Z = function(t) {
                        var e = t.image,
                            n = t.iconType,
                            o = t.counter,
                            r = t.badgeType,
                            a = t.text,
                            s = t.hasProgress,
                            c = t.hasAction,
                            u = c ? "button" : "div",
                            l = r ? X[r] : void 0,
                            f = e ? W.A.getImageUrlForSize(e, 48) : void 0,
                            d = !e && n ? J[n] : void 0;
                        return (0, Q.jsx)(u, {
                            className: "inapp-notification js-inapp-notification-touchable",
                            "data-qa": "inapp-container",
                            children: (0, Q.jsx)(K.A, {
                                media: d,
                                image: f,
                                badge: o || l ? {
                                    mark: o,
                                    icon: l
                                } : void 0,
                                text: (0, Q.jsxs)(i.Fragment, {
                                    children: [a, (0, Q.jsx)("span", {
                                        className: "inapp-notification__progress-value js-progress"
                                    })]
                                }),
                                extraContent: s ? (0, Q.jsx)("div", {
                                    className: "inapp-notification__progress-bar",
                                    children: (0, Q.jsx)("div", {
                                        className: "csms-progress-bar csms-progress-bar--default",
                                        children: (0, Q.jsx)("div", {
                                            className: "csms-progress-bar__indicator js-progress-bar",
                                            style: {
                                                minWidth: "5%"
                                            }
                                        })
                                    })
                                }) : void 0,
                                hasAction: c
                            })
                        })
                    },
                    tt = (n(62062), n(26914)),
                    et = n(20017),
                    nt = n(93827),
                    it = n(94767),
                    ot = n(87019),
                    rt = n(45998),
                    at = n(4571),
                    st = n(40578),
                    ct = n(30784),
                    ut = n(27895),
                    lt = n(51634),
                    ft = n(65736),
                    dt = function(t) {
                        var e = t.closeCta,
                            n = t.features,
                            i = t.isVisible,
                            o = t.message,
                            r = t.title,
                            a = t.userIcon,
                            s = t.userImage,
                            c = t.onAnimationInComplete,
                            u = t.onAnimationOutComplete,
                            l = t.onClickDismiss,
                            f = Boolean(e);
                        return (0, Q.jsx)(ft.A, {
                            isDismissible: !f,
                            isVisible: i,
                            outerContent: f ? (0, Q.jsx)("div", {
                                className: "payments-notification-success__cta",
                                children: (0, Q.jsx)(et.A, {
                                    text: e,
                                    onClick: l,
                                    dataQA: {
                                        "data-qa": "payments-notification-success-cta"
                                    }
                                })
                            }) : void 0,
                            onAnimationInComplete: c,
                            onAnimationOutComplete: u,
                            isPadded: !0,
                            hasDefaultDismissButton: !1,
                            children: (0, Q.jsxs)(at.A, {
                                isCompact: !0,
                                align: "start",
                                dataQA: {
                                    "data-qa": "payments-notification-success"
                                },
                                children: [(0, Q.jsx)(ut.A, {
                                    children: (0, Q.jsx)(tt.A, {
                                        badge: a ? {
                                            icon: {
                                                name: a
                                            }
                                        } : void 0,
                                        image: {
                                            src: s
                                        },
                                        shape: "circle",
                                        size: "md"
                                    })
                                }), (0, Q.jsx)(st.A, {
                                    text: r
                                }), (0, Q.jsx)(ct.A, {
                                    text: o
                                }), n ? (0, Q.jsx)(lt.A, {
                                    children: (0, Q.jsx)("ul", {
                                        className: "payments-notification-success__features",
                                        children: n.map((function(t) {
                                            return (0, Q.jsx)("li", {
                                                className: "payments-notification-success__feature",
                                                children: (0, Q.jsxs)(it.A, {
                                                    children: [t.icon ? (0, Q.jsx)(ot.A, {
                                                        children: (0, Q.jsx)(tt.A, {
                                                            size: "xxsm",
                                                            icon: {
                                                                name: t.icon
                                                            }
                                                        })
                                                    }) : null, (0, Q.jsx)(rt.A, {
                                                        children: (0, Q.jsx)(nt.P2, {
                                                            children: t.text
                                                        })
                                                    })]
                                                })
                                            }, t.text)
                                        }))
                                    })
                                }) : null]
                            })
                        })
                    },
                    pt = [818, 8, 557];

                function ht(t) {
                    if (t.type !== _.s.PAYMENT) return !1;
                    var e = t.promoBlock;
                    return !!e && (pt.includes(e.promo_block_type) && 18 === e.promo_block_position)
                }
                var gt = n(59244),
                    _t = n(18823),
                    At = n(41927),
                    mt = n(32614);

                function vt(t) {
                    var e, n = t.promoBlock,
                        i = (0, _t.h)(n, 77) || {},
                        o = (0, At.V)(n),
                        r = (0, mt.w)(n),
                        a = function(t) {
                            return 557 === t.promo_block_type ? 47 : 1
                        }(n);
                    return {
                        closeCta: i.text,
                        isPremiumPlus: 47 === a,
                        message: n.mssg,
                        title: n.header,
                        userPicture: (e = o, e ? {
                            image: e.display_images,
                            icon: (0, gt.y)(e.badge_type)
                        } : null),
                        features: r.map((function(t) {
                            return function(t, e) {
                                return {
                                    text: t.header,
                                    icon: (0, gt.y)(t.badge_type, e)
                                }
                            }(t, a)
                        }))
                    }
                }
                var yt, Tt = function(t) {
                        var e, n, o = t.notification,
                            r = t.onClose,
                            a = (0, i.useState)(!0),
                            s = a[0],
                            c = a[1],
                            u = (0, i.useState)(!1),
                            l = u[0],
                            f = u[1],
                            d = (0, i.useRef)(P.A.getLogger("PaymentsNotificationSuccessContainer"));
                        if (!ht(o)) return d.current.error("Trying to show an unsupported payment notification", {
                            notification: o
                        }), r(), null;
                        var p = vt(o);
                        return (0, Q.jsx)(dt, {
                            closeCta: l ? p.closeCta : void 0,
                            features: p.features,
                            isVisible: s,
                            message: p.message,
                            title: p.title,
                            userIcon: null == (e = p.userPicture) ? void 0 : e.icon,
                            userImage: null == (n = p.userPicture) ? void 0 : n.image,
                            onAnimationInComplete: function() {
                                f(!0)
                            },
                            onAnimationOutComplete: function() {
                                r()
                            },
                            onClickDismiss: function() {
                                f(!1), c(!1)
                            }
                        })
                    },
                    It = n(99562),
                    Nt = n(43410),
                    bt = (n(45700), n(89572), n(52675), n(89463), n(84185), n(79432), n(2008), n(83851), n(81278), n(67945), n(46770)),
                    Ot = n(96506),
                    St = n(32483),
                    Et = n(24867);

                function Ct(t, e) {
                    var n = Object.keys(t);
                    if (Object.getOwnPropertySymbols) {
                        var i = Object.getOwnPropertySymbols(t);
                        e && (i = i.filter((function(e) {
                            return Object.getOwnPropertyDescriptor(t, e).enumerable
                        }))), n.push.apply(n, i)
                    }
                    return n
                }

                function Pt(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = null != arguments[e] ? arguments[e] : {};
                        e % 2 ? Ct(Object(n), !0).forEach((function(e) {
                            wt(t, e, n[e])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : Ct(Object(n)).forEach((function(e) {
                            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                        }))
                    }
                    return t
                }

                function wt(t, e, n) {
                    return (e = function(t) {
                        var e = function(t, e) {
                            if ("object" != typeof t || null === t) return t;
                            var n = t[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var i = n.call(t, e || "default");
                                if ("object" != typeof i) return i;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === e ? String : Number)(t)
                        }(t, "string");
                        return "symbol" == typeof e ? e : String(e)
                    }(e)) in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }! function(t) {
                    t.SPP = "SPP", t.PREMIUM_PLUS = "PREMIUM_PLUS"
                }(yt || (yt = {}));
                var xt = function(t) {
                        var e, n = t.continueCtaText,
                            o = t.footerText,
                            r = t.isModal,
                            a = void 0 !== r && r,
                            s = t.isVisible,
                            c = void 0 === s || s,
                            u = t.linkCtaText,
                            l = t.subtitle,
                            f = t.title,
                            d = t.type,
                            p = t.url,
                            h = t.variant,
                            g = t.onAnimationOutComplete,
                            _ = t.onClickContinue,
                            A = t.onClickLink;
                        switch (d) {
                            case yt.SPP:
                                e = "badge-feature-premium";
                                break;
                            case yt.PREMIUM_PLUS:
                                e = "badge-feature-premium-plus"
                        }
                        var m = (0, i.useMemo)((function() {
                            if ("fullscreen" === h) {
                                return {
                                    type: "fullscreen",
                                    isDismissible: !0,
                                    hasDefaultDismissButton: !1
                                }
                            }
                            if (a) {
                                return {
                                    type: "popup",
                                    isDismissible: !1,
                                    hasDefaultDismissButton: !1
                                }
                            }
                            return {
                                type: "bottom-drawer",
                                isDismissible: !0,
                                hasDefaultDismissButton: !0
                            }
                        }), [h, a]);
                        return (0, Q.jsx)(ft.A, Pt(Pt({}, m), {}, {
                            isPadded: !0,
                            isVisible: c,
                            onAnimationOutComplete: g,
                            wrapperType: Et.T.MODAL,
                            children: (0, Q.jsxs)(at.A, {
                                isCompact: !0,
                                align: "start",
                                children: [e ? (0, Q.jsx)(ut.A, {
                                    size: "icon",
                                    children: (0, Q.jsx)($.A, {
                                        name: e
                                    })
                                }) : null, (0, Q.jsx)(st.A, {
                                    text: f,
                                    dangerous: !0,
                                    tag: "h2"
                                }), l ? (0, Q.jsx)(ct.A, {
                                    text: l
                                }) : null, (0, Q.jsxs)(bt.A, {
                                    children: [(0, Q.jsx)(et.A, {
                                        styling: "revenue",
                                        text: n,
                                        onClick: function() {
                                            p ? A(p) : _()
                                        },
                                        dataQA: {
                                            "data-qa": "partnership-result-continue-cta"
                                        }
                                    }), u && A ? (0, Q.jsx)(et.A, {
                                        semantic: "tertiary",
                                        text: u,
                                        onClick: function() {
                                            return A()
                                        },
                                        dataQA: {
                                            "data-qa": "partnership-result-link-cta"
                                        }
                                    }) : null]
                                }), o ? (0, Q.jsx)(Ot.A, {
                                    children: (0, Q.jsx)(St.A, {
                                        children: o
                                    })
                                }) : null]
                            })
                        }))
                    },
                    Dt = n(37692),
                    kt = n(30942);

                function Rt(t) {
                    return (0, kt.c)(t, 3)
                }
                var jt = n(52508),
                    Lt = n(13463);
                var Mt, Ft, Bt = function(t) {
                        var e, o = t.notification,
                            r = t.onClose,
                            a = (0, i.useState)(!0),
                            s = a[0],
                            c = a[1],
                            u = o.promo_block,
                            l = function(t) {
                                var e, n, i, o = t.promo_block || {},
                                    r = 46 === t.type,
                                    a = 135 === t.type,
                                    s = o.mssg,
                                    c = o.header || "";
                                if (r) switch (s = null == (i = (0, jt.z)(o)) ? void 0 : i[0], c = o.mssg || o.header || "", o.ok_payment_product_type) {
                                    case 1:
                                        n = yt.SPP;
                                        break;
                                    case 47:
                                        n = yt.PREMIUM_PLUS
                                } else a && !c && (c = o.mssg || o.header || "", s = "");
                                return {
                                    continueCta: (0, _t.h)(o),
                                    footerText: null == (e = Rt(o)) ? void 0 : e[0],
                                    isSuccess: r,
                                    linkCta: (0, Lt.Z)(o),
                                    subtitle: s,
                                    title: c,
                                    type: n
                                }
                            }(o),
                            f = l.continueCta,
                            d = l.footerText,
                            p = l.isSuccess,
                            h = l.linkCta,
                            g = l.subtitle,
                            _ = l.title,
                            A = l.type;
                        return (0, i.useEffect)((function() {
                            (0, Dt.nW)(u)
                        }), []), (0, Q.jsx)(xt, {
                            continueCtaText: null == f ? void 0 : f.text,
                            footerText: d,
                            isModal: !p,
                            isVisible: s,
                            linkCtaText: null == h ? void 0 : h.text,
                            subtitle: g,
                            title: _,
                            type: A,
                            url: null == f || null == (e = f.redirect_page) ? void 0 : e.url,
                            variant: u.variant_id,
                            onAnimationOutComplete: function() {
                                r()
                            },
                            onClickContinue: function() {
                                c(!1), (0, Dt.GT)(u, null == f ? void 0 : f.type), p && (0, It.Y)({
                                    requestType: 278,
                                    responseType: 387,
                                    message: {
                                        common_stats: {
                                            event: 1,
                                            context: 273,
                                            source: 20
                                        }
                                    }
                                })
                            },
                            onClickLink: function(t) {
                                var e = t ? f : h;
                                (0, Dt.GT)(u, null == e ? void 0 : e.type), Nt.A.handleAction({
                                    cta: e,
                                    clientSource: 273,
                                    hotPanelData: {
                                        activationPlace: 256
                                    }
                                }), t ? n.g.open(t, "_blank", "noopener") : c(!1)
                            }
                        })
                    },
                    Vt = "is-visible",
                    Ut = .2 * b.A.innerWidth,
                    Yt = {
                        CLICK: "CLICK",
                        DISMISS: "DISMISS"
                    },
                    Ht = "RIGHT",
                    qt = "LEFT",
                    Wt = "UP",
                    Gt = "DOWN",
                    zt = ((Mt = {})[Ht] = "is-sliding-right", Mt[qt] = "is-sliding-left", Mt),
                    Kt = ".js-inapp-notification-touchable",
                    $t = H.A.extend({
                        className: "inapp-notification-wrapper",
                        events: (Ft = {}, Ft["click " + Kt] = "onClick_", Ft["touchstart " + Kt] = "onTouchStart_", Ft["touchmove " + Kt] = "onTouchMove_", Ft["touchend " + Kt] = "onTouchEnd_", Ft["mousedown " + Kt] = "onTouchStart_", Ft["mousemove " + Kt] = "onTouchMove_", Ft["mouseup " + Kt] = "onTouchEnd_", Ft),
                        show: function(t) {
                            var e, n, i, o = this.$el;

                            function r() {
                                o.addClass(Vt)
                            }
                            this.render(t), o.show(), null != (e = t.images) && e.length ? (n = o.find(".js-preload"), i = i || n.length - 1, new Promise((function(t) {
                                function e(e, n, o) {
                                    i === n && t(e), (0, M.A)(e).closest("." + G).removeClass(G), o && function(t, e) {
                                        "IMG" === t.tagName.toUpperCase() ? t.src = e : t.style.backgroundImage = "url('" + e + "')"
                                    }(e, o)
                                }
                                n.forEach((function(t, n) {
                                    var i = Number(t.getAttribute("data-width")),
                                        o = Number(t.getAttribute("data-height")),
                                        r = t.getAttribute("data-crop"),
                                        a = W.A.getImageUrlForSize(function(t) {
                                            return t.getAttribute("data-src") || t.src || t.style.backgroundImage.slice(4, -1).replace(/"/g, "")
                                        }(t), i, o, r);
                                    (0, q.NN)(a).then((function(i) {
                                        var o = i[0];
                                        return e(t, n, o)
                                    })).catch((function() {
                                        return e(t, n)
                                    }))
                                }))
                            }))).then(r).catch(r) : r()
                        },
                        showOverlay: function(t) {
                            var e = this,
                                n = this.renderReactView((0, Q.jsx)(Tt, {
                                    notification: t,
                                    onClose: function() {
                                        e.removeReactView(n), e.trigger(Yt.DISMISS, Gt)
                                    }
                                }), this.$el.get(0))
                        },
                        showModal: function(t) {
                            var e = this,
                                n = this.renderReactView((0, Q.jsx)(Bt, {
                                    notification: t.notification,
                                    onClose: function() {
                                        e.removeReactView(n), e.trigger(Yt.DISMISS, Gt)
                                    }
                                }), this.$el.get(0))
                        },
                        onClick_: function() {
                            this.trigger(Yt.CLICK), this.hide()
                        },
                        hDismiss_: function(t) {
                            var e = this,
                                n = zt[t];
                            this.$el.addClass(n), (0, q.Yn)(this.$el, (function() {
                                e.$el.hide(), e.$el.removeClass(n), (0, q.Yn)(e.$el, (function() {
                                    e.$el.removeClass(Vt)
                                }))
                            }))
                        },
                        hide: function(t) {
                            var e = this;
                            this.$el.removeClass(Vt), (0, U.A)(t) && (0, q.Yn)(this.$el, (function() {
                                e.$el.hide(), b.A.requestAnimationFrame(t)
                            }))
                        },
                        render: function(t) {
                            this.$el.html((0, z.A)("InAppNotification", Z).render(t)), this.update(t)
                        },
                        update: function(t) {
                            var e = t.progress,
                                n = e ? Math.max(e.count, 1) + "/" + e.total : "";
                            this.$el.find(".js-progress").html(n);
                            var i = e && e.total > 0 ? Math.round(100 * e.count / e.total) : 0;
                            this.$el.find(".js-progress-bar").width(i + "%")
                        },
                        dismiss: function(t) {
                            t !== Gt && (t === Ht || t === qt ? this.hDismiss_(t) : this.hide())
                        },
                        onTouchStart_: function(t) {
                            var e = Y.A.supportsTouch ? t.touches[0] : t;
                            this.startX = e.clientX, this.startY = e.clientY
                        },
                        onTouchMove_: function(t) {
                            var e = Y.A.supportsTouch ? t.touches[0] : t;
                            if (!(Y.A.supportsTouch && t.touches.length > 1)) {
                                var n = e.clientX - this.startX,
                                    i = e.clientY - this.startY,
                                    o = Math.max(Math.abs(n), Math.abs(i)) > 10;
                                this.isDragHorizontal || this.isDragVertical || !o || (Math.abs(n) < Math.abs(i) && i < 0 ? this.isDragVertical = !0 : this.isDragHorizontal = !0), this.offsetX = n, this.offsetY = i, this.isDragVertical && i < 0 ? (this.$(Kt).css("top", i), this.$(Kt).css("opacity", "" + (1 + i / 60))) : this.isDragHorizontal && (this.$(Kt).css("left", n), this.$(Kt).css("opacity", "" + (1 - Math.abs(n) / b.A.innerWidth))), t.preventDefault(), t.stopPropagation()
                            }
                        },
                        onTouchEnd_: function(t) {
                            if (!(Y.A.supportsTouch && t.touches.length > 1)) {
                                var e = !1;
                                Math.abs(this.offsetX) > Math.abs(this.offsetY) || this.isDragHorizontal ? Math.abs(this.offsetX) > Ut ? (e = !0, this.offsetX < 0 ? this.trigger(Yt.DISMISS, qt) : this.trigger(Yt.DISMISS, Ht)) : (this.$(Kt).css("left", 0), this.$(Kt).css("opacity", "1")) : Math.abs(this.offsetY) > 20 ? this.offsetY < 0 && (e = !0, this.trigger(Yt.DISMISS, Wt)) : (this.$(Kt).css("top", 0), this.$(Kt).css("opacity", "1")), this.startX = this.startY = this.offsetX = this.offsetY = 0, this.isDragVertical = this.isDragHorizontal = !1, e && (t.preventDefault(), t.stopPropagation())
                            }
                        }
                    }, "InAppNotificationItemView");
                $t.EVENTS = Yt;
                var Qt = $t,
                    Xt = n(30397),
                    Jt = n(41025),
                    Zt = (n(48980), n(85208)),
                    te = n(58544),
                    ee = n(15566),
                    ne = {
                        NOTIFICATION_DISPLAY: "notification-display",
                        NOTIFICATION_REMOVE: "notification-remove",
                        NOTIFICATION_DISCARD: "notification-discard",
                        NOTIFICATION_SKIP: "notification-skip",
                        NOTIFICATION_INTERRUPT: "notification-interrupt",
                        NOTIFICATION_REPLACE: "notification-replace",
                        NOTIFICATION_IGNORE: "notification-ignore"
                    },
                    ie = [0, 4, 6, 8],
                    oe = 1e3;

                function re(t, e) {
                    var n = t.slice(0, e),
                        i = t.slice(e + 1, t.length);
                    return n.concat(i)
                }

                function ae() {
                    this._displayedNotification = null, this._queue = [], this._waitTimer = null, this._removeTimer = null, this._displayTimer = null, this._notificationWaitingScreenChange = !1, this._tagShowTimes = {}, this._screenOptions = {
                        screenAccess: 1
                    }, this.blockNextNotifications()
                }
                var se = {
                        addNotification: function(t) {
                            ! function(t) {
                                var e = t instanceof ee.eDv;
                                return !e || e && 2 === t.getDisplayStrategy()
                            }(t) ? (this._addToQueue(t), this._isReadyForDisplayNewOne() && this._displayNextNotification()) : this._displayInterruptNotification(t)
                        },
                        getDisplayedNotification: function() {
                            return this._displayedNotification
                        },
                        clickNotification: function() {
                            this._removeCurrentNotification()
                        },
                        dismissNotification: function() {
                            this._removeCurrentNotification()
                        },
                        setScreenAccess: function(t) {
                            this._screenOptions.screenAccess = t, this._notificationWaitingScreenChange && this._displayNextNotification()
                        },
                        screenChange: function(t) {
                            this._screenOptions = t, this._skipQueuedChatNotifications(this._screenOptions.folderType), this.setScreenAccess(t.screenAccess)
                        },
                        emptyQueue: function() {
                            this._queue = []
                        },
                        blockNextNotifications: function() {
                            this.blockNextNotifications_ = !0
                        },
                        unblockNextNotifications: function() {
                            this.blockNextNotifications_ = !1, this._displayNextNotification()
                        }
                    },
                    ce = {
                        _addToQueue: function(t) {
                            var e = this._queue.findIndex((function(e) {
                                var n = t.getTag();
                                return n && n === e.getTag()
                            }));
                            if (t._added_ts = Date.now(), -1 === e) this._queue.push(t);
                            else {
                                var n = this._queue[e];
                                this.trigger(ne.NOTIFICATION_REPLACE, n), this._queue[e] = t
                            }
                        },
                        _isReadyForDisplayNewOne: function() {
                            return !this._displayedNotification && !this._waitTimer
                        },
                        _onWaitTimeout: function() {
                            clearTimeout(this._waitTimer), this._waitTimer = null, this._isReadyForDisplayNewOne() && this._queue[0] && this._displayNextNotification()
                        },
                        _removeCurrentNotification: function() {
                            this._displayedNotification && (clearTimeout(this._removeTimer), this._storeLastDisplayedTimePerTag(this._displayedNotification), this._removeTimer = null, this._displayedNotification = null, this.trigger(ne.NOTIFICATION_REMOVE), clearTimeout(this._waitTimer), this._waitTimer = setTimeout(this._onWaitTimeout.bind(this), 5e3))
                        },
                        debounceOnLogin: function() {
                            clearTimeout(this._waitTimer), this._waitTimer = setTimeout(this._onWaitTimeout.bind(this), 1e3)
                        },
                        _storeLastDisplayedTimePerTag: function(t) {
                            var e = (0, U.A)(t.getTag) && t.getTag();
                            e && (this._tagShowTimes[e] = Date.now())
                        },
                        _hasScreenAccess: function(t) {
                            return t.getScreenAccess() >= this._screenOptions.screenAccess
                        },
                        _waitTimeToShow: function(t) {
                            var e = t.getTag();
                            if (!(e in this._tagShowTimes)) return 0;
                            var n = t.getFrequency(),
                                i = this._tagShowTimes[e] + n * oe - Date.now();
                            return i > 0 ? i + 300 : 0
                        },
                        _canBeDisplayed: function(t) {
                            return this._hasScreenAccess(t) && !this._waitTimeToShow(t)
                        },
                        _shouldSkipNotification: function(t) {
                            var e = t.getRelevantFolder();
                            return 31 === this._screenOptions.folderType ? this._isCombinedConnectionNotification(t) : e && 0 !== e && this._screenOptions.folderType === e || this._isSkipableChatNotification(t)
                        },
                        _getNotification: function(t) {
                            var e = this._queue[t];
                            if (!e) return null;
                            if ((o = (i = e).getDiscardTimeout()) && o * oe < Date.now() - i._added_ts) return this.trigger(ne.NOTIFICATION_DISCARD, e), this._queue = re(this._queue, t), null;
                            if (this._shouldSkipNotification(e)) return this.trigger(ne.NOTIFICATION_SKIP, e), this._queue = re(this._queue, t), null;
                            if (this._canBeDisplayed(e)) return this._queue = re(this._queue, t), e;
                            if (this._hasScreenAccess(e)) {
                                var n = this._waitTimeToShow(e);
                                this._setDisplayTimeout(n)
                            } else this._notificationWaitingScreenChange = !0;
                            var i, o, r = e._added_ts + e.getDiscardTimeout() * oe - Date.now();
                            return this._setDisplayTimeout(r), null
                        },
                        _getNextNotification: function() {
                            for (var t = 0, e = this._queue.length, n = this._getNotification(t); !n && t < e;) e === this._queue.length ? t++ : e = this._queue.length, n = this._getNotification(t);
                            return n && (clearTimeout(this._displayTimer), this._displayTimer = null, this._notificationWaitingScreenChange = !1), n
                        },
                        _isCombinedConnectionNotification: function(t) {
                            var e = t.getRelevantFolder();
                            return ie.includes(e)
                        },
                        _isSkipableChatNotification: function(t) {
                            var e = t.getRelevantFolder(),
                                n = this._screenOptions,
                                i = t.getRedirectPage(),
                                o = i && (0, U.A)(i.getUserId) && i.getUserId();
                            return 0 === e && n.folderType === e && (!n.params.id || n.params.id === o)
                        },
                        _skipQueuedChatNotifications: function(t) {
                            var e = this;
                            0 === t && (this._queue = this._queue.filter((function(t) {
                                var n = e._isSkipableChatNotification(t);
                                return n && e.trigger(ne.NOTIFICATION_SKIP, t), !n
                            })))
                        },
                        _displayInterruptNotification: function(t) {
                            if (this._isReadyForDisplayNewOne()) return this._displayNotification(t);
                            this._waitTimer || this.trigger(ne.NOTIFICATION_INTERRUPT, this._displayedNotification), this._removeCurrentNotification(), clearTimeout(this._waitTimer), this._waitTimer = null, this._displayNotification(t)
                        },
                        _displayNextNotification: function() {
                            if (this._isReadyForDisplayNewOne() && !this.blockNextNotifications_) {
                                clearTimeout(this._displayTimer), this._displayTimer = null, this._notificationWaitingScreenChange = !1;
                                var t = this._getNextNotification();
                                t && this._displayNotification(t)
                            }
                        },
                        _displayNotification: function(t) {
                            this.trigger(ne.NOTIFICATION_DISPLAY, t);
                            var e = 5e3;
                            (0, U.A)(t.getDisplayTimeout) && (e = t.getDisplayTimeout() * oe), t.displayTime && (e = t.displayTime), clearTimeout(this._removeTimer), this._removeTimer = setTimeout(this._ignoreCurrentNotification.bind(this), e), this._displayedNotification = t
                        },
                        _ignoreCurrentNotification: function() {
                            this.trigger(ne.NOTIFICATION_IGNORE, this._displayedNotification), this._removeCurrentNotification()
                        },
                        _setDisplayTimeout: function(t) {
                            var e = this,
                                n = t + Date.now();
                            this._displayTimer && this._timeToNextDisplay && n >= this._timeToNextDisplay || (this._timeToNextDisplay = n, clearTimeout(this._displayTimer), this._displayTimer = setTimeout((function() {
                                e._timeToNextDisplay = null, e._displayNextNotification()
                            }), t))
                        }
                    };
                (0, Zt.A)(ae.prototype, te.zb, se, ce), ae.EVENTS = ne;
                var ue, le = ae,
                    fe = n(41051),
                    de = ((ue = {})[1] = 2, ue[2] = 1, ue[3] = 4, ue[4] = 3, ue[5] = 5, ue[6] = 6, ue[7] = 7, ue[8] = 8, ue),
                    pe = {
                        track: function(t) {
                            var e = t.event,
                                n = t.notification,
                                i = t.clientSource,
                                o = t.activationPlace || 1;
                            (function(t, e, n) {
                                if (!(e instanceof ee.eDv)) return;
                                fe.A.sendInAppNotificationEvent(t, {
                                    notificationId: e.getNotificationId(),
                                    clientSource: n
                                })
                            })(e, n, i),
                            function(t, e, n) {
                                var i = {
                                    notification_type: 3,
                                    notification_action_type: de[t],
                                    activation_place: e
                                };
                                n instanceof ee.eDv && (i.notification_id = n.getNotificationId(), i.inapp_id = n.getTag());
                                (0, I.sx)(63, i)
                            }(e, o, n)
                        }
                    };
                var he, ge, _e = n(73090),
                    Ae = "system",
                    me = "billing",
                    ve = ((he = {})[26] = "attention_boost", he[9] = "credits", he[40] = "crush", he[7] = "extra_shows", he[3] = "favourites", he[4] = "mutual", he[5] = "rise_up", he[8] = "spp", he[42] = "photo_camera", he),
                    ye = ((ge = {})[21] = "attention_boost", ge[25] = "crush", ge[13] = "credits", ge[6] = "extra_shows", ge[7] = "rise_up", ge[1] = "spp", ge),
                    Te = ["12"];

                function Ie(t) {
                    var e = {};
                    if (e.text = t.text, e.hasAction = !!t.redirectPage, t.type === _.A.TYPES.PAYMENT) {
                        e[me] = !0;
                        var n = function() {
                            var t = _e.A.getUser();
                            return null == t ? void 0 : t.profile_photo.large_url
                        }();
                        n && (e.image = n);
                        var i = t.productType;
                        i in ye ? e.badgeType = ye[i] : 45 === i && (e.image = void 0, e.iconType = "tick")
                    } else t.type === _.A.TYPES.MESSAGE ? (e.image = t.picture, e.badgeType = "message") : t.type === _.A.TYPES.PHOTO_UPLOAD ? (e.iconType = "photo_upload", e.hasProgress = t.progress) : (e[Ae] = !0, t.type === _.A.TYPES.ERROR ? e.iconType = "cross" : e.iconType = "tick");
                    return e
                }
                var Ne = {
                    getData: function(t) {
                        return t instanceof ee.eDv ? function(t) {
                            var e = t.getBadgeType(),
                                n = t.getPhotoUrls(),
                                i = Boolean(null == n ? void 0 : n.length),
                                o = i ? ve[e] : void 0,
                                r = 2 === e && t.getBadgeText(""),
                                a = i && n.slice(0, 1),
                                s = t.getTag();
                            return {
                                hasAction: !!t.getRedirectPage() && !Te.includes(s),
                                badgeType: o,
                                counter: r,
                                image: a[0],
                                text: t.getText()
                            }
                        }(t) : t instanceof _.A ? Ie(t) : t instanceof ee.z5N ? function(t) {
                            var e, n = t.toJSON();
                            return (e = {})[46 === n.type ? me : Ae] = !0, e.notification = n, e.promoBlock = n.promo_block, e.text = n.message, e.iconType = "tick", e
                        }(t) : null
                    }
                };

                function be(t) {
                    var e;
                    if (!t) return !1;
                    if (135 === (null == t ? void 0 : t.type)) return !0;
                    var n = null == t || null == (e = t.promo_block) ? void 0 : e.promo_block_type;
                    return 547 === n || 548 === n
                }
                var Oe = n(3208),
                    Se = n(35837);

                function Ee(t, e) {
                    return Ee = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                        return t.__proto__ = e, t
                    }, Ee(t, e)
                }
                var Ce = [5],
                    Pe = [119],
                    we = "notification-view",
                    xe = P.A.getLogger("InAppNotifications"),
                    De = [ee.eDv, _.A, ee.z5N],
                    ke = (0, V.A)("NOTIFICATION_DISPLAY", "NOTIFICATION_REMOVE"),
                    Re = function(t) {
                        var e, n;

                        function i() {
                            for (var e, n = arguments.length, i = new Array(n), o = 0; o < n; o++) i[o] = arguments[o];
                            return (e = t.call.apply(t, [this].concat(i)) || this).isShowingModal_ = !1, e.screenAccess_ = null, e.isDisplayingNotification_ = !1, e.pendingNotification_ = null, e.userId_ = null, e.clientSource_ = 0, e.activationPlace_ = 1, e
                        }
                        n = t, (e = i).prototype = Object.create(n.prototype), e.prototype.constructor = e, Ee(e, n);
                        var o = i.prototype;
                        return o.construct = function(e) {
                            t.prototype.construct.call(this), this.parent = e
                        }, o.init = function() {
                            this.registerView(we, new Qt).on(Qt.EVENTS.CLICK, this.onNotificationClick_.bind(this)).on(Qt.EVENTS.DISMISS, this.onNotificationDismiss_.bind(this)), this.stateManager_ = (new le).on(le.EVENTS.NOTIFICATION_DISPLAY, this.displayNotification_.bind(this)).on(le.EVENTS.NOTIFICATION_REMOVE, this.onNotificationRemove_.bind(this)).on(le.EVENTS.NOTIFICATION_DISCARD, this.onNotificationDiscard_.bind(this)).on(le.EVENTS.NOTIFICATION_SKIP, this.onNotificationSkip_.bind(this)).on(le.EVENTS.NOTIFICATION_IGNORE, this.onNotificationIgnore_.bind(this)).on(le.EVENTS.NOTIFICATION_INTERRUPT, this.onNotificationInterrupt_.bind(this)).on(le.EVENTS.NOTIFICATION_REPLACE, this.onNotificationReplace_.bind(this)), N.nJ.subscribe(this.screenChange.bind(this))
                        }, o.onStart = function() {
                            w.A.getInstance().on(w.A.Type.INAPP_NOTIFICATION, this.onNotificationReceived_, this), Xt.A.on(Xt.A.ACTIONS.WAKE_UP, this.onDeviceWakeUp_, this), Xt.A.on(Xt.A.ACTIONS.SLEEP, this.onDeviceSleep_, this), this.parent.append(this.getView(we).getElement())
                        }, o.updateParent = function(t) {
                            this.parent = (0, M.A)(t), this.parent.append(this.getView(we).getElement())
                        }, o.onStop = function() {
                            w.A.getInstance().off(w.A.Type.INAPP_NOTIFICATION, this.onNotificationReceived_, this), Xt.A.off(Xt.A.ACTIONS.WAKE_UP, this.onDeviceWakeUp_, this), Xt.A.off(Xt.A.ACTIONS.SLEEP, this.onDeviceSleep_, this)
                        }, o.showNotification = function(t) {
                            this.stateManager_ && Le(t) && (! function(t) {
                                return Boolean(De.find((function(e) {
                                    return t instanceof e
                                })))
                            }(t) ? xe.error("invalid notification type", t) : this.stateManager_.addNotification(t))
                        }, o.updateNotification = function(t) {
                            var e = this.stateManager_.getDisplayedNotification();
                            (null == e ? void 0 : e.type) === t.type && this.getView(we).update(t)
                        }, o.onDeviceWakeUp_ = function() {
                            var t = this.isShowingModal_ ? 3 : this.screenAccess_;
                            this.stateManager_.setScreenAccess(t)
                        }, o.onDeviceSleep_ = function() {
                            this.stateManager_.setScreenAccess(3)
                        }, o.setShowingModal = function(t) {
                            if (this.stateManager_ && t !== this.isShowingModal_) {
                                var e = t ? 3 : this.screenAccess_;
                                this.stateManager_.setScreenAccess(e), this.isShowingModal_ = t
                            }
                        }, o.blockNotifications = function() {
                            this.stateManager_.blockNextNotifications()
                        }, o.resetBlockNotifications = function() {
                            this.stateManager_.unblockNextNotifications()
                        }, o.screenChange = function(t, e) {
                            if (this.stateManager_) {
                                var n = {
                                    screenAccess: t.notificationScreenAccess,
                                    clientSource: t.clientSource,
                                    activationPlace: t.activationPlace,
                                    folderType: t.folderId_,
                                    params: e
                                };
                                this.screenAccess_ = n.screenAccess, this.clientSource_ = n.clientSource, this.activationPlace_ = n.activationPlace, this.stateManager_.screenChange(n)
                            }
                        }, o.reset = function() {
                            return this.stateManager_.emptyQueue(), this.isShowingModal_ = !1, this.screenAccess_ = null, this.isDisplayingNotification_ = !1, this.pendingNotification_ = null, this
                        }, o.onNotificationReceived_ = function(t) {
                            this.stateManager_ && this.stateManager_.addNotification((0, Se.A)(t, ee.eDv))
                        }, o.displayNotification_ = function(t) {
                            if (t && Le(t))
                                if (b.A._badoo_noInAppNotifications) xe.warn("Ignored notification due enabled testParams noInAppNotifications flag");
                                else if (this.isDisplayingNotification_) this.pendingNotification_ = t;
                            else {
                                var e = Ne.getData(t);
                                e ? e.text || ht(t) || be(e.notification) ? (this.isDisplayingNotification_ = !0, this.track_(2, t), ht(t) ? this.getView(we).showOverlay(t) : be(e.notification) ? this.getView(we).showModal(e) : this.getView(we).show(e), this.trigger(ke.NOTIFICATION_DISPLAY)) : xe.error("Empty notification text ", t) : xe.error("invalid notification type", t)
                            }
                        }, o.debounceOnLogin = function() {
                            this.stateManager_.debounceOnLogin()
                        }, o.onNotificationRemove_ = function() {
                            this.getView(we).hide(this.onViewHide_.bind(this)), this.trigger(ke.NOTIFICATION_REMOVE)
                        }, o.onViewHide_ = function() {
                            this.isDisplayingNotification_ = !1, this.pendingNotification_ && (this.displayNotification_(this.pendingNotification_), this.pendingNotification_ = null)
                        }, o.track_ = function(t, e) {
                            this.activationPlace_ || xe.warn("Activation place is undefined"), pe.track({
                                event: t,
                                notification: e,
                                clientSource: this.clientSource_,
                                activationPlace: this.activationPlace_
                            })
                        }, o.onNotificationClick_ = function() {
                            if (this.stateManager_) {
                                var t = this.stateManager_.getDisplayedNotification();
                                if (t) {
                                    if (Oe.A.generate(), this.track_(1, t), this.stateManager_.clickNotification(), t instanceof ee.eDv) {
                                        var e = t.getRedirectPage();
                                        if (e && 43 === e.getRedirectPage()) return n = {
                                            activationPlace: 19
                                        }, i = {
                                            back: y.A.getUrl(),
                                            hotPanelData: n,
                                            productType: 13
                                        }, void Jt.A.navigateToPayment(i)
                                    }
                                    var n, i, o = function(t) {
                                        if (t instanceof ee.eDv) {
                                            var e = t.getRedirectPage();
                                            if (e) return A.A.getRouteFromRedirectPage(e.toJSON())
                                        }
                                        return null
                                    }(t);
                                    if ("string" == typeof o && o.length) {
                                        var r = {
                                            hotPanelData: {
                                                inappId: t.getTag()
                                            },
                                            clientSource: this.clientSource_,
                                            inAppData: {
                                                folderType: t.getRelevantFolder(),
                                                clientSource: 94,
                                                notificationType: t.getTag()
                                            }
                                        };
                                        y.A.navigate(o, r)
                                    } else t instanceof _.A && function(t) {
                                        if (t.redirectPage) {
                                            var e = A.A.getRouteFromRedirectPage(t.redirectPage);
                                            y.A.navigate(e, {
                                                context: 94
                                            })
                                        }
                                    }(t)
                                }
                            }
                        }, o.onNotificationDismiss_ = function(t) {
                            if (this.stateManager_) {
                                var e = this.stateManager_.getDisplayedNotification();
                                this.getView(we).dismiss(t), this.track_(4, e), this.stateManager_.dismissNotification()
                            }
                        }, o.onNotificationDiscard_ = function(t) {
                            this.track_(3, t)
                        }, o.onNotificationSkip_ = function(t) {
                            this.track_(8, t)
                        }, o.onNotificationIgnore_ = function(t) {
                            this.track_(6, t)
                        }, o.onNotificationInterrupt_ = function(t) {
                            this.track_(7, t)
                        }, o.onNotificationReplace_ = function(t) {
                            this.track_(5, t)
                        }, i
                    }(B.A);
                Re.EVENTS = ke;
                var je = Re;

                function Le(t) {
                    var e = !Ce.includes(t.productType),
                        n = !Pe.some((function(e) {
                            return e === (null == t || null == t.getType ? void 0 : t.getType())
                        }));
                    return t && e && n
                }
                var Me = n(56368);
                var Fe = n(30866),
                    Be = (n(9868), n(86529)),
                    Ve = n(47625),
                    Ue = n(53010),
                    Ye = n(534),
                    He = n(41421),
                    qe = n(76201),
                    We = n(69705);

                function Ge(t, e) {
                    var n = (0, i.useState)(!1),
                        o = n[0],
                        r = n[1],
                        a = (0, i.useState)(!1),
                        s = a[0],
                        c = a[1];
                    return (0, i.useEffect)((function() {
                        t && !s && (He.A.send(), O.A.get().then((function(t) {
                            We.A.init({
                                webPushInitParams: t.web_push_init_params
                            })
                        })), Ue.A.init(), c(!0))
                    }), [t, s]), (0, i.useEffect)((function() {
                        !o && t && t.controllerType === Be.A.NORMAL && (Promise.resolve().then((function() {
                            var t = qe.A.get("return_user"),
                                e = (0, q.vc)() === q.t4.PORTRAIT ? 2 : 1,
                                n = {
                                    http_referrer: b.A.document.referrer,
                                    return_user: Boolean(t),
                                    device_position: e
                                };
                            isNaN(b.A.devicePixelRatio) || (n.screen_dpi = b.A.devicePixelRatio), b.A.screen && (isNaN(b.A.screen.width) || (n.horizontal_resolution = b.A.screen.width), isNaN(b.A.screen.height) || (n.vertical_resolution = b.A.screen.height)), isNaN(Number(b.A.navigator.deviceMemory)) || (n.device_ram = b.A.navigator.deviceMemory), Boolean(b.A.navigator.standalone) ? n.home_screen = 2 : null != b.A.matchMedia && b.A.matchMedia("(display-mode: standalone)").matches && Y.A.chrome && !Y.A.samsungBrowser ? n.home_screen = 1 : b.A.matchMedia && (b.A.matchMedia("(display-mode: standalone)").matches || b.A.matchMedia("(display-mode: fullscreen)").matches) && Y.A.samsungBrowser && (n.home_screen = 3);
                            var i = ze();
                            i && (n.network_interface = i), (0, I.sx)(30, n), t || qe.A.set("return_user", "1")
                        })), function() {
                            var t, e;
                            (0, I.sx)(692, {
                                time_ms: 1,
                                name: 18,
                                measurement: 1,
                                datacenter: Ve.A.id,
                                network_interface: 8,
                                ip_v_6: Ye.backend.ipv6
                            });
                            var n = Date.now(),
                                i = (null == (t = b.A.performance) || null == t.now ? void 0 : t.now()) || n - (null == (e = b.A.performance) || null == (e = e.timing) ? void 0 : e.navigationStart);
                            i && (0, I.sx)(692, {
                                time_ms: Number(i.toFixed(0)),
                                name: 18,
                                measurement: 2,
                                datacenter: Ve.A.id,
                                network_interface: 8,
                                ip_v_6: Ye.backend.ipv6
                            })
                        }(), (0, I.sx)(692, {
                            time_ms: 1,
                            name: 1,
                            measurement: b.A._modern_browser ? 5 : 4,
                            datacenter: Ve.A.id,
                            network_interface: 8,
                            ip_v_6: Ye.backend.ipv6
                        }), r(!0))
                    }), [o, t]), (0, i.useEffect)((function() {
                        t && t.controllerType === Be.A.NORMAL && !t.screenOnboardingTips && e.resetBlockNotifications()
                    }), [t, e]), null
                }
                var ze = function() {
                    if ("connection" in window.navigator) {
                        var t = b.A.navigator.connection.effectiveType;
                        if ("slow-2g" === t || "2g" === t) return 2;
                        if ("3g" === t) return 3;
                        if ("4g" === t) return 4
                    }
                    return null
                };
                var Ke = n(84230),
                    $e = n(80725);
                P.A.getLogger("useNewVersionChecker");
                var Qe = n(31087);
                var Xe = n(25093),
                    Je = n(39953);
                var Ze = n(31023);

                function tn(t, e) {
                    var n = Object.keys(t);
                    if (Object.getOwnPropertySymbols) {
                        var i = Object.getOwnPropertySymbols(t);
                        e && (i = i.filter((function(e) {
                            return Object.getOwnPropertyDescriptor(t, e).enumerable
                        }))), n.push.apply(n, i)
                    }
                    return n
                }

                function en(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = null != arguments[e] ? arguments[e] : {};
                        e % 2 ? tn(Object(n), !0).forEach((function(e) {
                            nn(t, e, n[e])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : tn(Object(n)).forEach((function(e) {
                            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                        }))
                    }
                    return t
                }

                function nn(t, e, n) {
                    return (e = function(t) {
                        var e = function(t, e) {
                            if ("object" != typeof t || null === t) return t;
                            var n = t[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var i = n.call(t, e || "default");
                                if ("object" != typeof i) return i;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === e ? String : Number)(t)
                        }(t, "string");
                        return "symbol" == typeof e ? e : String(e)
                    }(e)) in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }
                var on = function(t) {
                        var e = t.imgSrc;
                        return e ? (0, Q.jsx)("img", {
                            className: "generic-overlay__media",
                            src: e,
                            alt: ""
                        }) : null
                    },
                    rn = {
                        icon: on,
                        user: on,
                        header: on,
                        bricks: function(t) {
                            var e = t.imgSources;
                            return e ? (0, Q.jsx)(Ze.A, {
                                layout: 3 === (null == e ? void 0 : e.length) ? "triple" : "double",
                                variant: 3 === (null == e ? void 0 : e.length) ? "s-m-s" : "m-m",
                                children: null == e ? void 0 : e.map((function(t, e) {
                                    return (0, Q.jsx)(tt.A, {
                                        image: {
                                            src: t
                                        }
                                    }, e)
                                }))
                            }) : null
                        }
                    };

                function an(t) {
                    if (!t) return null;
                    var e = rn[t.type];
                    return t ? (0, Q.jsx)(ut.A, {
                        size: "icon" === (null == t ? void 0 : t.type) ? "icon" : "default",
                        children: (0, Q.jsx)(e, en({}, t))
                    }) : null
                }
                var sn = function(t) {
                        var e = t.image,
                            n = t.title,
                            i = t.text,
                            o = t.link,
                            r = t.bullets,
                            a = t.primaryCta,
                            s = t.secondaryCta,
                            c = t.onDismiss,
                            u = t.isVisible,
                            l = t.onAnimationOutComplete;
                        return (0, Q.jsx)(ft.A, {
                            isVisible: u,
                            isPadded: !0,
                            onDismiss: c,
                            onAnimationOutComplete: l,
                            children: (0, Q.jsxs)(at.A, {
                                children: [an(e), (0, Q.jsx)(st.A, {
                                    text: n
                                }), i && (0, Q.jsx)(ct.A, {
                                    text: i
                                }), r && (0, Q.jsx)(ct.A, {
                                    text: (0, Q.jsx)("table", {
                                        className: "generic-overlay__bullets",
                                        children: (0, Q.jsx)("tbody", {
                                            children: r.map((function(t, e) {
                                                return (0, Q.jsxs)("tr", {
                                                    children: [(0, Q.jsx)("td", {
                                                        children: (0, Q.jsx)("span", {
                                                            className: "generic-overlay__bullet-icon",
                                                            children: (0, Q.jsx)($.A, {
                                                                name: "generic-check",
                                                                size: "md"
                                                            })
                                                        })
                                                    }), (0, Q.jsx)("td", {
                                                        children: t
                                                    })]
                                                }, e)
                                            }))
                                        })
                                    })
                                }), o && (0, Q.jsx)(ct.A, {
                                    text: (0, Q.jsx)(nt.P1, {
                                        children: (0, Q.jsx)("a", {
                                            href: o.url,
                                            className: "generic-overlay__link",
                                            target: "_blank",
                                            rel: "noreferrer",
                                            children: o.text
                                        })
                                    })
                                }), (0, Q.jsxs)(bt.A, {
                                    children: [(0, Q.jsx)(et.A, {
                                        text: a.text,
                                        semantic: "primary",
                                        onClick: a.onClick
                                    }), s && (0, Q.jsx)(et.A, {
                                        text: s.text,
                                        semantic: "secondary",
                                        onClick: s.onClick
                                    })]
                                })]
                            })
                        })
                    },
                    cn = n(91133);

                function un(t, e) {
                    var n;
                    return null == e || null == (n = e.ui) ? void 0 : n.find((function(e) {
                        return e.ref === t
                    }))
                }
                var ln = function() {
                        var t, e, n, o, r, a, s, c, u = (0, i.useState)(!1),
                            l = u[0],
                            f = u[1],
                            d = (0, i.useState)(!0),
                            p = d[0],
                            h = d[1],
                            g = (0, i.useState)(),
                            _ = g[0],
                            A = g[1],
                            m = (0, cn.G)(490);
                        (0, i.useEffect)((function() {
                            var t = function(t) {
                                A(t), f(!0)
                            };
                            return F.A.on(F.A.SCREEN_STORY_GENERIC_OVERLAY, t),
                                function() {
                                    F.A.off(F.A.SCREEN_STORY_GENERIC_OVERLAY, t)
                                }
                        }), []), (0, i.useEffect)((function() {
                            _ && l && m(2)
                        }), [_, l, m]);
                        if (!_) return null;
                        var v = un("primary_button", _),
                            T = un("secondary_button", _),
                            I = null == (t = un("image", _)) || null == (t = t.image) ? void 0 : t.display_images,
                            N = null == (e = un("header_image", _)) || null == (e = e.image) ? void 0 : e.display_images,
                            b = null == (n = un("header_photo", _)) || null == (n = n.image) ? void 0 : n.display_images,
                            O = null == (o = un("header_photos", _)) || null == (o = o.children) ? void 0 : o.map((function(t) {
                                var e;
                                return null == (e = t.image) ? void 0 : e.display_images
                            })),
                            E = null == (r = un("header_text", _)) ? void 0 : r.text,
                            C = null == (a = un("description_text", _)) ? void 0 : a.text,
                            P = null == v || null == (s = v.call_to_action) ? void 0 : s.text,
                            w = null == T || null == (c = T.call_to_action) ? void 0 : c.text,
                            x = {
                                type: "header"
                            };
                        return I ? x.imgSrc = I : N ? x.imgSrc = N : b ? (x.imgSrc = b, x.type = "user") : O && (x.imgSources = O, x.type = "bricks"), (0, Q.jsx)("div", {
                            className: "generic-overlay-container",
                            children: l && _ && (0, Q.jsx)(sn, {
                                title: E,
                                text: C,
                                primaryCta: {
                                    text: P,
                                    onClick: function() {
                                        var t, e;
                                        63 === (null == v || null == (t = v.call_to_action) ? void 0 : t.action) && (61 === (null == v || null == (e = v.call_to_action.redirect_page) ? void 0 : e.redirect_page) && (m(1), h(!1), y.A.navigate(S.x.ADD_INTERESTS)))
                                    }
                                },
                                secondaryCta: {
                                    text: w,
                                    onClick: function() {
                                        var t;
                                        77 === (null == T || null == (t = T.call_to_action) ? void 0 : t.action) && (m(9), h(!1))
                                    }
                                },
                                onDismiss: function() {
                                    m(4)
                                },
                                image: x,
                                isVisible: p,
                                onAnimationOutComplete: function() {
                                    f(!1)
                                }
                            })
                        })
                    },
                    fn = n(72537),
                    dn = n(7714),
                    pn = n(71672),
                    hn = (n(58940), n(21699), n(40075)),
                    gn = n(37905),
                    _n = n(39984),
                    An = n(48788),
                    mn = n(33736),
                    vn = n(8562),
                    yn = n(5587);
                var Tn, In, Nn = function(t) {
                        var e = t.sharingProviders,
                            n = t.rating,
                            o = t.showLowScore,
                            r = t.showLowLowScore,
                            a = t.showShareOptions,
                            s = t.onCancel,
                            c = t.onMakeSuggestion,
                            u = t.onShare,
                            l = !o && !r && !a,
                            f = hn.Ay.get(902);
                        return r && (f = hn.Ay.get(905)), o && (f = hn.Ay.get(904)), a && (f = hn.Ay.get(903)), a ? (0, Q.jsxs)(i.Fragment, {
                            children: [(0, Q.jsx)(vn.A, {
                                media: n,
                                text: f
                            }), (0, Q.jsxs)(yn.A, {
                                dataQA: {
                                    "data-qa": "rate-app-share"
                                },
                                children: [e.map((function(t, e) {
                                    var n = function(t) {
                                        switch (t) {
                                            case "facebook":
                                                return {
                                                    icon: "badge-provider-facebook",
                                                    title: hn.Ay.get(517),
                                                    network: "Facebook"
                                                };
                                            case "trustpilot":
                                                return {
                                                    icon: "badge-provider-trustpilot",
                                                    title: hn.Ay.get(915),
                                                    network: "Trustpilot"
                                                };
                                            case "instagram":
                                                return {
                                                    icon: "badge-provider-instagram",
                                                    title: hn.Ay.get(914),
                                                    network: "Instagram"
                                                };
                                            case "twitter":
                                                return {
                                                    icon: "badge-provider-twitter",
                                                    title: hn.Ay.get(914),
                                                    network: "Twitter"
                                                }
                                        }
                                    }(t);
                                    return (0, Q.jsx)(mn.A, {
                                        text: n.title,
                                        icon: (0, Q.jsx)($.A, {
                                            name: n.icon
                                        }),
                                        onClick: function() {
                                            return u(t)
                                        },
                                        a11y: {
                                            contentLabel: n.title + ", " + n.network
                                        }
                                    }, "rate-app-sharing-provider-" + e)
                                })), (0, Q.jsx)(mn.A, {
                                    text: hn.Ay.get(460),
                                    onClick: s,
                                    dataQA: {
                                        "data-qa": "modal-action-cancel"
                                    }
                                })]
                            })]
                        }) : (0, Q.jsxs)(at.A, {
                            isCompact: !0,
                            dataQA: {
                                "data-qa": "rate-app"
                            },
                            children: [l ? (0, Q.jsx)(st.A, {
                                text: hn.Ay.get(909),
                                tag: "h2"
                            }) : null, (0, Q.jsx)(lt.A, {
                                children: n
                            }), (0, Q.jsx)(lt.A, {
                                children: (0, Q.jsx)(nt.P2, {
                                    color: "gray-80",
                                    children: f
                                })
                            }), o || r ? (0, Q.jsxs)(bt.A, {
                                children: [(0, Q.jsx)(et.A, {
                                    text: hn.Ay.get(906),
                                    onClick: c,
                                    dataQA: {
                                        "data-qa": "modal-action-primary"
                                    }
                                }), (0, Q.jsx)(et.A, {
                                    semantic: "tertiary",
                                    text: hn.Ay.get(460),
                                    onClick: s,
                                    dataQA: {
                                        "data-qa": "modal-action-cancel"
                                    }
                                })]
                            }) : (0, Q.jsx)(bt.A, {
                                children: (0, Q.jsx)(et.A, {
                                    semantic: "tertiary",
                                    text: hn.Ay.get(451),
                                    onClick: s,
                                    dataQA: {
                                        "data-qa": "modal-action-cancel"
                                    }
                                })
                            })]
                        })
                    },
                    bn = (n(23792), n(62953), n(32485)),
                    On = n.n(bn),
                    Sn = function(t) {
                        var e = t.checkedValue,
                            n = void 0 === e ? 0 : e,
                            i = t.values,
                            o = t.onClickRating,
                            r = t.qaRole;
                        return (0, Q.jsx)("div", {
                            className: "star-rating",
                            "data-qa": r || "star-rating",
                            children: i.map((function(t, e) {
                                var r = On()({
                                    "star-rating__item": !0,
                                    "is-selected": n >= t,
                                    "is-animated": n === t
                                });
                                return (0, Q.jsxs)("button", {
                                    className: r,
                                    onClick: function() {
                                        return o(t)
                                    },
                                    "aria-pressed": Boolean(n === t),
                                    "aria-label": e + 1 + " / " + i.length,
                                    children: [(0, Q.jsx)("span", {
                                        className: "star-rating__icon star-rating__icon--inactive",
                                        children: (0, Q.jsx)($.A, {
                                            name: "generic-star-outlined"
                                        })
                                    }), (0, Q.jsx)("span", {
                                        className: "star-rating__icon star-rating__icon--active",
                                        children: (0, Q.jsx)($.A, {
                                            name: "generic-star"
                                        })
                                    })]
                                }, "star-rating-item-" + e)
                            }))
                        })
                    },
                    En = function(t) {
                        var e = t.rating,
                            n = t.showLowScore,
                            i = t.showLowLowScore,
                            o = t.showShareOptions,
                            r = t.onDismiss,
                            a = t.onClickRating,
                            s = t.onCancel,
                            c = t.onMakeSuggestion,
                            u = t.onShare;
                        return (0, Q.jsx)(ft.A, {
                            isPadded: !o,
                            onAnimationOutComplete: r,
                            focusTarget: "content",
                            children: (0, Q.jsx)(Nn, {
                                sharingProviders: ["facebook", "trustpilot", "instagram", "twitter"],
                                rating: (0, Q.jsx)(Sn, {
                                    values: [1, 2, 3, 4, 5],
                                    checkedValue: e,
                                    onClickRating: a
                                }),
                                showLowScore: n,
                                showLowLowScore: i,
                                showShareOptions: o,
                                onCancel: s,
                                onMakeSuggestion: c,
                                onShare: u
                            })
                        })
                    },
                    Cn = fn.A.getClientFeatureSync(dn.y.FAST_RATE_US),
                    Pn = Cn ? 5e3 : 3e4,
                    wn = Cn ? 1e4 : 432e6,
                    xn = "Persist::RateUs",
                    Dn = [S.x.INVITATION_CONTACTS, S.x.WHATS_NEW, S.x.MODERATED_PHOTOS, S.x.FORCED_PHOTO_VERIFICATION, S.x.PHOTO_VERIFICATION, S.x.PHONE_VERIFICATION],
                    kn = [423],
                    Rn = [S.x.OWN_PROFILE, S.x.ENCOUNTERS],
                    jn = "facebook",
                    Ln = "trustpilot",
                    Mn = "instagram",
                    Fn = "twitter",
                    Bn = ((Tn = {})[jn] = "https://www.facebook.com/badoo", Tn[Ln] = "https://uk.trustpilot.com/review/www.badoo.com", Tn[Mn] = "https://www.instagram.com/badoo", Tn[Fn] = "https://twitter.com/Badoo", Tn),
                    Vn = ((In = {})[jn] = 120, In[Ln] = 433, In[Fn] = 201, In[Mn] = 44, In);

                function Un(t) {
                    (0, I.sx)(332, {
                        element: 113,
                        parent_element: t
                    })
                }
                var Yn = function() {
                    var t = (0, i.useState)(!1),
                        e = t[0],
                        n = t[1],
                        o = (0, i.useState)(0),
                        r = o[0],
                        a = o[1],
                        s = (0, i.useRef)(),
                        c = (0, i.useRef)(!1),
                        u = (0, i.useRef)(!1),
                        l = (0, i.useRef)(0),
                        f = (0, i.useRef)(0),
                        d = (0, i.useRef)(0),
                        p = (0, i.useCallback)((function() {
                            var t = pn.A.getObject(xn);
                            if (t) {
                                var e = parseInt(t.dismissCount, 10);
                                l.current = "number" != typeof e || isNaN(e) ? 0 : e;
                                var n = parseInt(t.dismissedDate, 10);
                                f.current = "number" != typeof n || isNaN(n) ? 0 : n;
                                var i = parseInt(t.handledDate, 10);
                                d.current = "number" != typeof i || isNaN(i) ? 0 : i, d.current && (14194728e5 < d.current ? u.current = !0 : (u.current = !1, d.current = 0, l.current = 0, A()))
                            }
                        }), [u, d]),
                        h = (0, i.useCallback)((function() {
                            if (c.current) return !1;
                            if (u.current) return !1;
                            if (f.current > (new Date).getTime() - wn) return !1;
                            var t = y.A.getLocation().routeName;
                            return !Dn.includes(t)
                        }), [c, u, f]),
                        g = (0, i.useCallback)((function() {
                            b.A.clearTimeout(s.current), s.current = void 0;
                            var t = y.A.getLocation().routeName,
                                e = gn.A.getScreenName();
                            !Rn.includes(t) || kn.includes(e) || An.A.get() ? (0, N.cj)((function() {
                                s.current = b.A.setTimeout(g, 5e3)
                            })) : (c.current = !0, s.current = void 0, An.A.set(!0), n(!0))
                        }), [c, s]);

                    function A() {
                        pn.A.saveObject(xn, {
                            dismissCount: l.current,
                            handledDate: d.current,
                            dismissedDate: f.current
                        })
                    }

                    function m() {
                        var t;
                        r > 0 && (_n.A.getInstance().sendFeedback({
                            category: _n.E.STAR_RATING,
                            rating: r
                        }).then((function() {
                            _.A.showNotification({
                                type: _.A.TYPES.INFO,
                                text: r < 4 ? hn.Ay.get(907) : hn.Ay.get(908)
                            })
                        })).catch((function() {
                            _.A.showNotification({
                                type: _.A.TYPES.ERROR
                            })
                        })), t = r, (0, I.sx)(132, {
                            stars: t
                        }))
                    }

                    function v() {
                        n(!1), An.A.set(!1), r > 0 ? d.current = (new Date).getTime() : f.current = (new Date).getTime(), l.current += 1, A(), m()
                    }
                    return (0, i.useEffect)((function() {
                        if (!s.current) {
                            if (p(), h()) return s.current = b.A.setTimeout(g, Pn),
                                function() {
                                    b.A.clearTimeout(s.current)
                                };
                            b.A.clearTimeout(s.current)
                        }
                    }), [p, h, g]), e ? (0, Q.jsx)(En, {
                        rating: r,
                        showLowScore: 3 === r,
                        showLowLowScore: r > 0 && r < 3,
                        showShareOptions: r >= 4,
                        onDismiss: v,
                        onClickRating: function(t) {
                            var e;
                            a(t), e = 431, (0, I.sx)(332, {
                                element: e,
                                parent_element: 434
                            }), t >= 4 && function(t) {
                                (0, I.sx)(258, {
                                    element: t
                                })
                            }(50)
                        },
                        onCancel: function() {
                            v(), Un(r > 0 && r < 4 ? 434 : 50)
                        },
                        onMakeSuggestion: function() {
                            n(!1), An.A.set(!1), y.A.navigate(S.x.RATE_APP_FEEDBACK, !0, {
                                rating: r,
                                fromModal: !0
                            })
                        },
                        onShare: function(t) {
                            var e;
                            Bn[t] && b.A.open(Bn[t], "_blank"), Vn[t] && (e = Vn[t], (0, I.sx)(332, {
                                element: e,
                                parent_element: 50
                            }))
                        }
                    }) : null
                };
                var Hn = function() {
                        var t = !1,
                            e = O.A.getSettings();
                        return e && (t = t || Boolean(e.allow_review)), t ? (0, Q.jsx)(Yn, {}) : null
                    },
                    qn = function(t) {
                        var e, n = t.startupResult,
                            l = t.inAppNotificationsContainerRef,
                            d = t.controllerInstance,
                            p = t.navigator,
                            h = (0, i.useContext)(f.Ay).Session,
                            g = function(t, e) {
                                var n = (0, i.useMemo)((function() {
                                        var e = new je((0, M.A)(t.current));
                                        return e.start({}), e.blockNotifications(), e
                                    }), [t]),
                                    o = (0, i.useCallback)((function() {
                                        n.debounceOnLogin()
                                    }), [n]),
                                    r = (0, i.useCallback)((function() {
                                        n.reset()
                                    }), [n]);
                                return (0, i.useEffect)((function() {
                                    var t = function(t) {
                                            n.showNotification(t)
                                        },
                                        i = function(t) {
                                            n.updateNotification(t)
                                        },
                                        o = function() {
                                            n.setShowingModal(!0)
                                        },
                                        r = function() {
                                            n.setShowingModal(!1)
                                        },
                                        a = function() {
                                            e.disableTooltips(Me.A.BLOCKER_TYPES.IN_APP)
                                        },
                                        s = function() {
                                            e.enableTooltips(Me.A.BLOCKER_TYPES.IN_APP)
                                        },
                                        c = function() {
                                            n.blockNotifications()
                                        },
                                        u = function() {
                                            n.resetBlockNotifications()
                                        };
                                    return F.A.on(F.A.SHOW_NOTIFICATION, t), F.A.on(F.A.UPDATE_NOTIFICATION, i), F.A.on(F.A.FB_MODAL_OPEN, o), F.A.on(F.A.FB_MODAL_CLOSE, r), F.A.on(F.A.SHOW_MODAL, o), F.A.on(F.A.HIDE_MODAL, r), n.on(je.EVENTS.NOTIFICATION_DISPLAY, a), n.on(je.EVENTS.NOTIFICATION_REMOVE, s), e.on(Me.A.ACTIONS.TOOLTIP_SHOWN, c).on(Me.A.ACTIONS.TOOLTIP_DISMISSED, u), n.isStarted() || n.start({}),
                                        function() {
                                            F.A.off(F.A.SHOW_NOTIFICATION, t), F.A.off(F.A.UPDATE_NOTIFICATION, i), F.A.off(F.A.FB_MODAL_OPEN, o), F.A.off(F.A.FB_MODAL_CLOSE, r), F.A.off(F.A.SHOW_MODAL, o), F.A.off(F.A.HIDE_MODAL, r), n.off(je.EVENTS.NOTIFICATION_DISPLAY, a), n.off(je.EVENTS.NOTIFICATION_REMOVE, s), n.stop(), e.off(Me.A.ACTIONS.TOOLTIP_SHOWN, c).off(Me.A.ACTIONS.TOOLTIP_DISMISSED, u)
                                        }
                                }), [n, e]), {
                                    debounceOnLogin: o,
                                    reset: r,
                                    inAppNotificationsController: n
                                }
                            }(l, function() {
                                var t = Me.A.getInstance();
                                return (0, i.useEffect)((function() {
                                    var e = function() {
                                            t.disableTooltips(Me.A.BLOCKER_TYPES.MODAL)
                                        },
                                        n = function() {
                                            t.enableTooltips(Me.A.BLOCKER_TYPES.MODAL)
                                        };
                                    return F.A.on(F.A.FB_MODAL_OPEN, e), F.A.on(F.A.FB_MODAL_CLOSE, n), F.A.on(F.A.SHOW_MODAL, e), F.A.on(F.A.HIDE_MODAL, n),
                                        function() {
                                            F.A.off(F.A.FB_MODAL_OPEN, e), F.A.off(F.A.FB_MODAL_CLOSE, n), F.A.off(F.A.SHOW_MODAL, e), F.A.off(F.A.HIDE_MODAL, n)
                                        }
                                }), [t]), t
                            }()),
                            _ = g.debounceOnLogin,
                            A = g.reset,
                            m = g.inAppNotificationsController;
                        return function() {
                                var t = (0, i.useContext)(f.Ay).Session;
                                (0, i.useEffect)((function() {
                                    var e = function(e) {
                                        var n = e.message_type,
                                            i = 10 === n,
                                            o = 27 === n || !0 === e.first_response || 4 === n || 5 === n;
                                        i && Qe.A.getInstance().invalidate(t.getUserId()), o && Qe.A.getInstance().invalidate(e.from_person_id)
                                    };
                                    return w.A.getInstance().on(w.A.Type.CHAT_MESSAGE, e),
                                        function() {
                                            w.A.getInstance().off(w.A.Type.CHAT_MESSAGE, e)
                                        }
                                }), [t])
                            }(), Ge(d, m),
                            function(t, e) {
                                var n = (0, i.useState)(void 0),
                                    o = n[0],
                                    r = n[1],
                                    a = (0, i.useState)(!1),
                                    s = a[0],
                                    c = a[1];
                                (0, i.useEffect)((function() {
                                    var t = function(t) {
                                        c(!1), r(t)
                                    };
                                    return F.A.on(F.A.Session.NEW_VERSION_AVAILABLE, t),
                                        function() {
                                            F.A.off(F.A.Session.NEW_VERSION_AVAILABLE, t)
                                        }
                                }), []), (0, i.useEffect)((function() {
                                    var e = function() {
                                        c(!0)
                                    };
                                    return t.navigationEvent.subscribe(e),
                                        function() {
                                            t.navigationEvent.unsubscribe(e)
                                        }
                                }), [t]), (0, i.useEffect)((function() {
                                    e && s && o && (Ke.A.destroy(!0), b.A.sessionStorage.setItem($e.Z.STORED_USER_STATIC_VERSION, o), b.A.location.reload())
                                }), [o, s, e])
                            }(p, d), j({
                                inAppNotificationsDebounceOnLogin: _,
                                inAppNotificationsReset: A,
                                controllerInstance: d
                            }), (0, i.useEffect)((function() {
                                return a.A.start(),
                                    function() {
                                        a.A.stop()
                                    }
                            }), [h]), (0, i.useEffect)((function() {
                                o.A.init(), r.A.init(), u.A.getInstance().retrieveState(), s.A.getInstance(), c.A.getInstance()
                            }), []), (0, Fe.w)(d, n), e = (0, i.useRef)(P.A.getLogger("usePrefetchingPaidSubscriptionFeatures")), (0, i.useEffect)((function() {
                                function t() {
                                    _e.A.isLoggedIn() && Je.A.getInstance().getPaidSubscriptionFeatures().catch((function(t) {
                                        (0, Xe.A)(t) && e.current.error("Error prefetching PaidSubscriptionFeatures", {
                                            error: t
                                        })
                                    }))
                                }

                                function n(e) {
                                    30 === e.id && (e.updated_resources || []).find((function(t) {
                                        return 25 === t.resource_type
                                    })) && (Je.A.getInstance().invalidateAll(), t())
                                }
                                return t(), F.A.on(F.A.Session.SESSION_CHANGED, t), w.A.getInstance().on(w.A.Type.SYSTEM_NOTIFICATION, n),
                                    function() {
                                        F.A.off(F.A.Session.SESSION_CHANGED, t), w.A.getInstance().off(w.A.Type.SYSTEM_NOTIFICATION, n)
                                    }
                            }), []), (0, Q.jsxs)(i.Fragment, {
                                children: [(0, Q.jsx)(Hn, {}), (0, Q.jsx)(ln, {})]
                            })
                    }
            },
            30942: function(t, e, n) {
                n.d(e, {
                    c: function() {
                        return i
                    }
                });
                n(72712), n(26099);

                function i(t, e) {
                    var n;
                    return null == (n = t.extra_texts) ? void 0 : n.reduce((function(t, n) {
                        return n.type === e && t.push(n.text || ""), t
                    }), [])
                }
            },
            32614: function(t, e, n) {
                n.d(e, {
                    w: function() {
                        return i
                    }
                });
                n(2008), n(26099);

                function i(t) {
                    return (t.pictures || []).filter((function(t) {
                        return 2 === t.significance
                    }))
                }
            },
            33527: function(t, e, n) {
                var i = n(20387),
                    o = n(58544),
                    r = n(31087),
                    a = (0, o.lh)(),
                    s = i.A.EVENTS,
                    c = s.USER_ADDED,
                    u = s.USER_REMOVED,
                    l = i.A.TYPES.FAVOURITES,
                    f = i.A.getInstance();

                function d(t, e) {
                    r.A.getInstance().updateCache(t, "isFavourite", e), a.trigger(t, e)
                }

                function p(t) {
                    var e = t.uid;
                    t.folder === l && d(e, !0)
                }

                function h(t) {
                    var e = t.uid;
                    t.folder === l && d(e, !1)
                }
                e.A = {
                    start: function() {
                        f.on(c, p), f.on(u, h)
                    },
                    stop: function() {
                        f.off(c, p), f.off(u, h)
                    },
                    onFavoriteStateChange: a.subscribe
                }
            },
            37692: function(t, e, n) {
                n.d(e, {
                    GT: function() {
                        return c
                    },
                    H8: function() {
                        return u
                    },
                    dA: function() {
                        return l
                    },
                    nW: function() {
                        return s
                    },
                    wo: function() {
                        return f
                    }
                });
                var i, o = n(79860),
                    r = n(89503),
                    a = ((i = {})[r.y.COOKIES_POLICY] = 473, i[r.y.HELP] = 110, i[r.y.LANGUAGE_INTERFACE] = 28, i[r.y.PRIVACY_POLICY] = 202, i[r.y.TERMS_CONDITIONS] = 161, i);

                function s(t) {
                    (0, o.sx)(138, {
                        banner_id: t.promo_block_type,
                        position_id: t.promo_block_position,
                        context: t.context
                    })
                }

                function c(t, e) {
                    void 0 === e && (e = 1);
                    var n = t.context,
                        i = t.promo_block_position,
                        r = t.promo_block_type;
                    (0, o.sx)(139, {
                        banner_id: r,
                        position_id: i,
                        context: n,
                        call_to_action_type: e
                    })
                }

                function u(t) {
                    (0, o.sx)(332, {
                        element: a[t]
                    })
                }

                function l(t) {
                    (0, o.sx)(332, {
                        element: 0 === t ? 1417 : 1418
                    })
                }

                function f() {
                    (0, o.sx)(258, {
                        element: 1491
                    })
                }
            },
            39953: function(t, e, n) {
                n(50113), n(26099), n(10287);
                var i = n(6696),
                    o = n(41298);

                function r(t, e) {
                    return r = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                        return t.__proto__ = e, t
                    }, r(t, e)
                }
                var a = function(t) {
                    var e, n;

                    function i() {
                        return t.call(this, {
                            get: {
                                message: 667,
                                response: 668
                            }
                        }, {
                            name: "TwoTiersCompareModel",
                            preventMultiple: !0
                        }) || this
                    }
                    return n = t, (e = i).prototype = Object.create(n.prototype), e.prototype.constructor = e, r(e, n), i.getInstance = function() {
                        return i.instance || (i.instance = new i), i.instance
                    }, i.prototype.getPaidSubscriptionFeatures = function() {
                        return (0, o.A)(this.get({
                            requests: [{
                                resource_type: 25
                            }]
                        }).then((function(t) {
                            var e, n = (t.resources || []).find((function(t) {
                                return 25 === t.resource_type
                            }));
                            return (null == n || null == (e = n.payload) ? void 0 : e.paid_subscription_features) || []
                        })).catch((function(t) {
                            throw t
                        })))
                    }, i
                }(i.A);
                a.instance = null, e.A = a
            },
            39984: function(t, e, n) {
                n.d(e, {
                    E: function() {
                        return i
                    }
                });
                n(62062), n(26099), n(3362), n(10287);
                var i, o = n(6696);

                function r(t, e) {
                    return r = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                        return t.__proto__ = e, t
                    }, r(t, e)
                }! function(t) {
                    t.STAR_RATING = "star_rating"
                }(i || (i = {}));
                var a = function(t) {
                    var e, n;

                    function o() {
                        return t.call(this, {
                            get: {
                                message: 71,
                                response: 72
                            },
                            set: {
                                message: 73,
                                response: 387
                            }
                        }, {
                            name: "Feedback"
                        }) || this
                    }
                    n = t, (e = o).prototype = Object.create(n.prototype), e.prototype.constructor = e, r(e, n), o.getInstance = function() {
                        return o.instance || (o.instance = new o), o.instance
                    };
                    var a = o.prototype;
                    return a.getFeedbackList = function(e) {
                        return t.prototype.get.call(this, e || {}).then((function(t) {
                            var e = t.feedback_key;
                            return (t.items || []).map((function(t, n) {
                                return {
                                    key: (null == e ? void 0 : e[n]) || n,
                                    type: t.type,
                                    name: t.name,
                                    requireEmail: t.require_email,
                                    url: t.url
                                }
                            }))
                        })).catch((function() {
                            throw new Error("Error loading categories")
                        }))
                    }, a.sendFeedback = function(e) {
                        var n = {
                            feedback_type: e.category,
                            feedback: e.message || ""
                        };
                        if (e.name && (n.name = e.name), e.email && (n.email = e.email), e.category === i.STAR_RATING) {
                            if ("number" != typeof e.rating) return Promise.reject(new Error("Star rating is not specified"));
                            n.star_rating = e.rating
                        }
                        return e.screenshot && (n.screenshot = e.screenshot), t.prototype.set.call(this, n)
                    }, o
                }(o.A);
                a.instance = void 0, e.A = a
            },
            41421: function(t, e, n) {
                n(69085);
                var i, o = n(31709);
                e.A = Object.assign((function(t) {
                    i = t
                }), {
                    send: function() {
                        i && new o.Ay(278, {
                            start_source: i
                        }).request()
                    }
                })
            },
            41927: function(t, e, n) {
                n.d(e, {
                    V: function() {
                        return i
                    }
                });
                n(50113), n(26099);

                function i(t) {
                    var e;
                    return null == (e = t.pictures) ? void 0 : e.find((function(t) {
                        return 1 === t.significance
                    }))
                }
            },
            43410: function(t, e, n) {
                n(26099), n(3362);
                var i, o, r = n(3508),
                    a = n(71363),
                    s = n(5586),
                    c = n(78029),
                    u = n(72537),
                    l = n(58385),
                    f = n(49683),
                    d = n(26935),
                    p = n(41025),
                    h = n(74389),
                    g = n(18084),
                    _ = n(62610),
                    A = n(97758),
                    m = g.A.getLogger("ServerActionHelper"),
                    v = ((i = {})[10] = h.x.ENCOUNTERS, i[11] = h.x.PEOPLE_NEARBY, i[5] = h.x.LANDING, i),
                    y = ((o = {})[273] = !0, o),
                    T = function() {
                        function t() {}
                        return t.handleAction = function(t) {
                            var e = t.action,
                                n = t.clientSource,
                                i = t.cta,
                                o = t.productType,
                                g = (null == i ? void 0 : i.action) || e || 0;
                            if (g in v) return l.A.navigate(v[g], Boolean(n && y[n])), Promise.resolve();
                            switch (4 !== g || (0, _.A)(o) || (g = 9, 1 === o && (g = 6)), g) {
                                case 0:
                                    return Promise.resolve();
                                case 2:
                                case 69:
                                    return I(t);
                                case 4:
                                    return function(t) {
                                        var e = t.popState,
                                            n = t.productType,
                                            i = t.userId;
                                        if (!n) return m.error("No product type but want to handle PAYMENT_REQUIRED"), Promise.reject(new Error("No product type but want to handle PAYMENT_REQUIRED"));
                                        return new Promise((function(o, s) {
                                            f.A.getInstance().fetchProductExplanation(n).then((function(t) {
                                                return t.promo
                                            })).then((function(c) {
                                                if (!c) {
                                                    var u = "No PromoBlock in response of ClientProductExplanation";
                                                    return m.error(u), void s(new Error(u))
                                                }
                                                if (2 === (null == c ? void 0 : c.ok_action)) return I(t);
                                                var f = (0, _.A)(n) || r.A.get(a.O.DEFAULT_PAGE),
                                                    d = {
                                                        promoBlock: c,
                                                        reject: s,
                                                        resolve: o,
                                                        userId: i
                                                    };
                                                l.A.navigate(f, e, d)
                                            })).catch(s)
                                        }))
                                    }(t);
                                case 6:
                                    return function(t) {
                                        return new Promise((function(e, n) {
                                            var i = t.back,
                                                o = t.hotPanelData,
                                                r = t.paymentFlowId,
                                                a = t.paymentTransitionInFlow,
                                                s = t.popState,
                                                l = {
                                                    back: i,
                                                    productType: 1,
                                                    promoBlockType: t.promoBlockType,
                                                    hotPanelData: o,
                                                    callback: function(t) {
                                                        var i = t.success,
                                                            o = t.cancelled,
                                                            r = t.purchaseFailed;
                                                        if (o) e(!1);
                                                        else if (!i) {
                                                            var a, s = (null == r || null == (a = r.notification) ? void 0 : a.message) || "Unknown error purchasing SuperPowers";
                                                            n(new Error("SPP Error: " + s))
                                                        }
                                                    }
                                                },
                                                f = {
                                                    existingPaymentFlowId: r,
                                                    paymentTransitionInFlow: a,
                                                    replace: s
                                                };
                                            p.A.navigateToPayment(l, f), c.Ay.observe(u.A.getObservable(19), (function(t) {
                                                t.getEnabled() && e(!0)
                                            }), {
                                                leading: !1,
                                                once: !0
                                            })
                                        }))
                                    }(t);
                                case 9:
                                    return function(t) {
                                        var e = t.back,
                                            n = t.cost,
                                            i = t.hotPanelData,
                                            o = t.popState,
                                            r = t.productType,
                                            a = t.promoBlockType,
                                            s = t.purchaseTransactionSetup;
                                        return new Promise((function(t, c) {
                                            var u = {
                                                productType: r,
                                                back: e,
                                                cost: n,
                                                hotPanelData: i,
                                                popState: o,
                                                promoBlockType: a,
                                                purchaseTransactionSetup: s,
                                                complete: t,
                                                success: t,
                                                error: c
                                            };
                                            d.A.purchase(u)
                                        }))
                                    }(t);
                                case 16:
                                    return Promise.resolve(l.A.navigate(h.x.SETTINGS_PRIVACY));
                                case 77:
                                    return function(t) {
                                        var e = t.back,
                                            n = t.popState;
                                        e ? l.A.navigate(e, n) : l.A.back();
                                        return Promise.resolve()
                                    }(t);
                                case 165:
                                    return function(t) {
                                        return new Promise((function(e, n) {
                                            var i = t.back,
                                                o = t.hotPanelData,
                                                r = t.paymentFlowId,
                                                a = t.paymentTransitionInFlow,
                                                s = t.popState,
                                                c = t.promoBlockType,
                                                u = {
                                                    back: i,
                                                    productType: t.productType,
                                                    promoBlockType: c,
                                                    hotPanelData: o,
                                                    callback: function(t) {
                                                        var i = t.success,
                                                            o = t.cancelled,
                                                            r = t.purchaseFailed;
                                                        if (o) e(!1);
                                                        else if (i) e(i);
                                                        else {
                                                            var a, s = (null == r || null == (a = r.notification) ? void 0 : a.message) || "Unknown error purchasing SuperPowers";
                                                            n(new Error("SPP Error: " + s))
                                                        }
                                                    }
                                                },
                                                l = {
                                                    existingPaymentFlowId: r,
                                                    paymentTransitionInFlow: a,
                                                    replace: s
                                                };
                                            p.A.navigateToPayment(u, l)
                                        }))
                                    }(t);
                                case 63:
                                    return function(t) {
                                        var e = t.cta,
                                            n = t.popState,
                                            i = (null == e ? void 0 : e.redirect_page) || t.redirectPage,
                                            o = s.A.getRouteFromRedirectPage(i) || r.A.get(a.O.DEFAULT_PAGE);
                                        return l.A.navigate(o, Boolean(n), (0, A.A)(t)), Promise.resolve()
                                    }(t);
                                case 50:
                                    return function(t) {
                                        var e = t.promoBlock || {},
                                            n = e.id || "",
                                            i = {
                                                timer: e.timer || 0,
                                                videoId: n
                                            };
                                        return l.A.navigate(h.x.EXTERNAL_PROMO_VIDEO, !1, i), Promise.resolve()
                                    }(t);
                                default:
                                    var T = "Action Type not handled by ServerActionHelper";
                                    return m.error(T, {
                                        actionType: g
                                    }), Promise.reject(new Error(T + ": " + g))
                            }
                        }, t
                    }();

                function I(t) {
                    var e = t.albumType,
                        n = t.callback,
                        i = t.back,
                        o = t.feature;
                    return l.A.navigate(h.x.ADD_PHOTOS, {
                        feature: o,
                        albumType: e,
                        destination: i,
                        callback: n
                    }), Promise.resolve()
                }
                e.A = T
            },
            51709: function(t, e, n) {
                n.d(e, {
                    $E: function() {
                        return u
                    },
                    Fi: function() {
                        return s
                    },
                    JU: function() {
                        return d
                    },
                    Y4: function() {
                        return f
                    },
                    iD: function() {
                        return l
                    }
                });
                n(26099), n(38781), n(27495), n(25276), n(48598), n(72712), n(62062), n(45700), n(89572), n(52675), n(89463), n(2892), n(84185), n(79432), n(2008), n(83851), n(51629), n(23500), n(81278), n(67945);
                var i = n(40075);

                function o(t, e) {
                    var n = Object.keys(t);
                    if (Object.getOwnPropertySymbols) {
                        var i = Object.getOwnPropertySymbols(t);
                        e && (i = i.filter((function(e) {
                            return Object.getOwnPropertyDescriptor(t, e).enumerable
                        }))), n.push.apply(n, i)
                    }
                    return n
                }

                function r(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = null != arguments[e] ? arguments[e] : {};
                        e % 2 ? o(Object(n), !0).forEach((function(e) {
                            a(t, e, n[e])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach((function(e) {
                            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                        }))
                    }
                    return t
                }

                function a(t, e, n) {
                    return (e = function(t) {
                        var e = function(t, e) {
                            if ("object" != typeof t || null === t) return t;
                            var n = t[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var i = n.call(t, e || "default");
                                if ("object" != typeof i) return i;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === e ? String : Number)(t)
                        }(t, "string");
                        return "symbol" == typeof e ? e : String(e)
                    }(e)) in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }

                function s(t) {
                    return t && t.toUpperCase().indexOf("FIXME_LABEL") < 0 ? t : void 0
                }
                var c = {
                    email: {
                        type: "email",
                        inputMode: "email",
                        spellCheck: !1,
                        autoCapitalize: "none",
                        autoCorrect: "off",
                        autoComplete: "username"
                    },
                    tel: {
                        type: "tel",
                        inputMode: "tel",
                        spellCheck: !1,
                        autoCapitalize: "none",
                        autoCorrect: "off",
                        autoComplete: "tel-national"
                    },
                    numeric: {
                        type: "text",
                        inputMode: "numeric",
                        spellCheck: !1,
                        autoCapitalize: "none",
                        autoCorrect: "off"
                    },
                    sms: {
                        type: "text",
                        inputMode: "numeric",
                        spellCheck: !1,
                        autoCapitalize: "none",
                        autoCorrect: "off",
                        autoComplete: "one-time-code"
                    },
                    "text-code": {
                        type: "text",
                        spellCheck: !1,
                        autoCapitalize: "none",
                        autoCorrect: "off",
                        autoComplete: "off"
                    },
                    password: {
                        type: "password",
                        spellCheck: !1,
                        autoCapitalize: "none",
                        autoCorrect: "off"
                    },
                    date: {
                        type: "date",
                        autoComplete: "bday",
                        autoCorrect: "off"
                    },
                    location: {
                        type: "text",
                        spellCheck: !0,
                        autoCapitalize: "none",
                        autoCorrect: "off",
                        autoComplete: "location"
                    },
                    "given-name": {
                        type: "text",
                        spellCheck: !1,
                        autoCapitalize: "words",
                        autoCorrect: "off",
                        autoComplete: "given-name"
                    }
                };

                function u(t, e) {
                    var n = e.type,
                        i = e.inputMode,
                        o = e.spellCheck,
                        a = e.autoCapitalize,
                        s = e.autoCorrect,
                        u = e.autoComplete;
                    return r(r(r(r(r(r(r({}, t && c[t]), n && {
                        type: n
                    }), i && {
                        inputMode: i
                    }), o && {
                        spellCheck: o
                    }), a && {
                        autoCapitalize: a
                    }), s && {
                        autoCorrect: s
                    }), u && {
                        autoComplete: u
                    })
                }

                function l(t) {
                    var e, n, o, a, s, c, u, l, f = t.a11y || {},
                        d = (e = t.fieldId, n = t.errorId, o = t.hintId, {
                            fieldId: e,
                            id: e,
                            errorId: n || e + "_error",
                            hintId: o || e + "_hint",
                            counterId: e + "_counter"
                        }),
                        p = (a = t.label, s = t.labelStatus, c = f.ariaRequired, l = c, (u = a) && "required" === s && (u = a + " " + i.Ay.get(209), l = !1), u && "optional" === s && (u = a + " " + i.Ay.get(208), l = !1), {
                            label: u,
                            ariaRequired: l
                        }),
                        h = [];
                    return t.errorMessage && h.push(d.errorId), t.hintMessage && h.push(d.hintId), t.maxLengthCounter && h.push(d.counterId), {
                        a11y: r({
                            ariaDescribedby: h.join(" ") || void 0
                        }, f),
                        ids: d,
                        labelProps: p
                    }
                }

                function f(t, e) {
                    t.preventDefault(), e()
                }

                function d(t) {
                    return void 0 === t && (t = ""), t.split("").map((function(t) {
                        return t.charCodeAt(0)
                    })).reduce((function(t, e) {
                        return t + ((t << 7) + (t << 3)) ^ e
                    })).toString(16)
                }
            },
            52508: function(t, e, n) {
                n.d(e, {
                    z: function() {
                        return o
                    }
                });
                var i = n(30942);

                function o(t) {
                    return (0, i.c)(t, 9)
                }
            },
            55105: function(t, e, n) {
                var i = n(40075),
                    o = n(84362),
                    r = n(23350),
                    a = n(74848);
                e.A = function(t) {
                    var e = t.size,
                        n = void 0 === e ? r.On.LARGE : e,
                        s = t.color,
                        c = void 0 === s ? r.Ac.DARK : s;
                    return (0, a.jsxs)("div", {
                        className: "view-loading-mask",
                        "data-qa": "loader-screen",
                        children: [(0, a.jsx)("div", {
                            className: "view-loading-centre",
                            children: (0, a.jsx)("div", {
                                className: "view-loading-container",
                                children: (0, a.jsx)(r.Ay, {
                                    color: c,
                                    size: n
                                })
                            })
                        }), (0, a.jsx)(o.A, {
                            children: (0, a.jsx)("span", {
                                role: "status",
                                "aria-live": "polite",
                                children: i.Ay.get(992)
                            })
                        })]
                    })
                }
            },
            62610: function(t, e, n) {
                n.d(e, {
                    A: function() {
                        return a
                    }
                });
                var i, o = n(74389),
                    r = ((i = {})[21] = o.x.ATTENTION_BOOST_EXPLANATION, i[22] = o.x.BUNDLE_SALE_EXPLANATION, i[25] = o.x.CRUSH_EXPLANATION, i[6] = o.x.EXTRA_SHOWS_EXPLANATION, i[7] = o.x.RISEUP_EXPLANATION, i);

                function a(t) {
                    return t && r[t]
                }
            },
            64266: function(t, e, n) {
                n.d(e, {
                    A: function() {
                        return p
                    }
                });
                var i, o = n(15566),
                    r = n(73090),
                    a = n(93529),
                    s = n(40075),
                    c = n(18084),
                    u = n(25093),
                    l = 124,
                    f = 25,
                    d = c.A.getLogger("session");

                function p(t, e) {
                    return !! function(t, e) {
                        if (e === l) return !0;
                        return t instanceof o.beZ && ("1" === t.getErrorCode() || t.getType() === f)
                    }(t, e) && (function(t) {
                        var e, n = (0, u.A)(t);
                        n && d.error("Attempt to use failed session", {
                            error: t,
                            url: null == (e = window) ? void 0 : e.location.href
                        });
                        if (t instanceof o.beZ && "1002" === t.getErrorCode()) return;
                        if (i && Date.now() < i + 3e4) return void(u.A && d.error("Additional attempt to use failed session, could lead to infinite loader", {
                            error: t
                        }));
                        i = Date.now(), r.A.logout(!0), a.A.showNotification({
                            type: a.A.TYPES.INFO,
                            text: s.Ay.get(521)
                        })
                    }(t), !0)
                }
            },
            64928: function(t, e, n) {
                n(10287);
                var i = n(72537),
                    o = n(78029),
                    r = n(31709);

                function a(t, e) {
                    return a = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                        return t.__proto__ = e, t
                    }, a(t, e)
                }
                var s = function(t) {
                    var e, n;

                    function s() {
                        return t.call(this, {
                            get: {
                                message: 34,
                                response: 35
                            },
                            set: {
                                message: 36,
                                response: 35
                            }
                        }, {
                            commitCache: !1,
                            name: "AppSettings"
                        }) || this
                    }
                    n = t, (e = s).prototype = Object.create(n.prototype), e.prototype.constructor = e, a(e, n), s.getInstance = function() {
                        return s.instance || (s.instance = new s), s.instance
                    };
                    var c = s.prototype;
                    return c.init = function() {
                        var t = this;
                        o.Ay.observe(i.A.getObservable(19), (function() {
                            return t.invalidate()
                        }), {
                            leading: !1
                        }), r.aV.onResponse(35, (function(e) {
                            t.inform(e)
                        }))
                    }, c.updateLanguage = function(t) {
                        var e = {
                            interface_language: t
                        };
                        return this.set(e)
                    }, c.set = function(e) {
                        var n = this,
                            i = t.prototype.set.call(this, e);
                        return i.then((function(t) {
                            return n.inform(t), t
                        })), i
                    }, c.getRequestTypeByObject = function() {
                        var t;
                        return (null == (t = this.messages.get) ? void 0 : t.message) || null
                    }, c.getCacheByObject = function(t) {
                        return t
                    }, s
                }(n(6696).A);
                s.instance = void 0, e.A = s
            },
            88626: function(t, e, n) {
                n(74423), n(21699);
                var i = n(58385),
                    o = n(74389);
                e.A = {
                    shouldRedirectToBlocked: function(t) {
                        var e = t.type,
                            n = 25 === e,
                            i = 72 === e,
                            o = 5 === t.behaviour;
                        return n || i && !o
                    },
                    redirectToBlocked: function(t) {
                        var e = i.A.getLocation().routeName;
                        [o.x.ACCOUNT_BLOCKED, o.x.TERMS, o.x.FEEDBACK, o.x.DEBUG, o.x.HELP].includes(e) || (25 === t.type ? i.A.navigate(o.x.ACCOUNT_BLOCKED, {
                            title: t.explanation.header,
                            message: t.explanation.mssg,
                            type: t.type,
                            secondaryMessage: t.explanation.extra_texts[0].text,
                            explanation: t.explanation
                        }) : i.A.navigate(o.x.ACCOUNT_BLOCKED, {
                            title: t.error_title,
                            message: t.error_message,
                            type: t.type
                        }))
                    }
                }
            },
            89503: function(t, e, n) {
                var i;
                n.d(e, {
                        y: function() {
                            return i
                        }
                    }),
                    function(t) {
                        t.TERMS_CONDITIONS = "TERMS_CONDITIONS", t.PRIVACY_POLICY = "PRIVACY_POLICY", t.COOKIES_POLICY = "COOKIES_POLICY", t.HELP = "HELP", t.LANGUAGE_INTERFACE = "LANGUAGE_INTERFACE"
                    }(i || (i = {}))
            },
            93184: function(t, e, n) {
                n(26099), n(3362), n(23792), n(47764), n(62953), n(10287), n(74423), n(21699);
                var i = n(99417),
                    o = n(3508),
                    r = n(58544),
                    a = n(65297),
                    s = n(56220),
                    c = n(26359),
                    u = n(18084),
                    l = n(19232),
                    f = n(79860);

                function d(t, e) {
                    return d = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                        return t.__proto__ = e, t
                    }, d(t, e)
                }
                var p = u.A.getLogger("FacebookWrapper"),
                    h = function(t) {
                        var e, n;

                        function r() {
                            var e;
                            return (e = t.call(this) || this).appId_ = null, e.providerId_ = null, e.readyPromise_ = null, e.readyResolve_ = null, a.A.on(a.A.Session.LOGOUT, e.logout, function(t) {
                                if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return t
                            }(e)), e.readyPromise_ = new Promise((function(t, n) {
                                e.readyResolve_ = function(n) {
                                    e.initialized_ = !0, t(n)
                                }, e.readyReject_ = n
                            })), e
                        }
                        n = t, (e = r).prototype = Object.create(n.prototype), e.prototype.constructor = e, d(e, n);
                        var u = r.prototype;
                        return u.get = function() {
                            return this.readyPromise_
                        }, u.getLoginStatus = function(t) {
                            var e, n = this,
                                o = (null == (e = t = t || {}) ? void 0 : e.timeout) || 6e4;
                            return new Promise((function(e, r) {
                                var a = !1,
                                    s = setTimeout((function() {
                                        a = !0, r(new Error("Facebook hasn't replied in the allowed timeout."))
                                    }), o);
                                n.afterInitialization_((function() {
                                    if (!a) {
                                        clearTimeout(s);
                                        var n = !1;
                                        i.A.FB.getLoginStatus((function(t) {
                                            n = !0, e(t)
                                        }), !Boolean(t.sync)), setTimeout((function() {
                                            n || r(new Error("Facebook hasn't replied in the allowed timeout."))
                                        }), o)
                                    }
                                }), (function(t) {
                                    a || (clearTimeout(s), r(t))
                                }))
                            }))
                        }, u.login = function() {
                            return new Promise((function(t) {
                                i.A.FB.login((function(e) {
                                    t(e)
                                }), {
                                    scope: "publish_actions"
                                })
                            }))
                        }, u.logout = function() {
                            return new Promise((function(t) {
                                var e;
                                null != (e = i.A.FB) && e.getAccessToken() ? i.A.FB.logout(t) : t()
                            }))
                        }, u.tryToLogin = function() {
                            return this.getLoginStatus({
                                sync: !0
                            }).then((function(t) {
                                return "connected" === t.status ? t : new Promise((function(t) {
                                    i.A.FB.login(t)
                                }))
                            }))
                        }, u.init = function() {
                            var t, e = this,
                                n = new Promise((function(t) {
                                    i.A.fbAsyncInit = function() {
                                        t(e), i.A.fbAsyncInit = null
                                    }
                                }));
                            return Promise.all([(t = s.A.getFullJSPath("sdk"), (0, c.k)(t, {
                                id: "facebook-jssdk",
                                nonce: i.A._nonce,
                                timeout: 3e4
                            }).then((function() {
                                g("loaded")
                            })).catch((function(t) {
                                if (g("failed"), !String(t).includes("Failed to load") || !String(t).includes("facebook-jssdk")) throw t;
                                p.warn("Load of facebook-jssdk script is blocked by client")
                            }))), n]).then(this.getAppId_.bind(this)).then(_).then((function(t) {
                                return e.readyResolve_(t)
                            })).catch((function(t) {
                                e.initialized_ = !1, e.reason_ = t || new Error("Facebook SDK could not be initialized"), e.readyReject_(e.reason_)
                            }))
                        }, u.getAppId_ = function() {
                            var t = this;
                            return this.appId_ = this.appId_ || o.A.get("fb.appId"), this.appId_ ? Promise.resolve(this.appId_) : l.A.getProvider({
                                providerType: 1,
                                providerContext: 3
                            }).then((function(e) {
                                var n = e.auth_data;
                                return n && (t.appId_ = n.app_id), t.providerId_ = e.id, o.A.set("fb.appId", t.appId_), t.appId_ || p.error("Empty appId in Facebook external provider."), t.appId_
                            }), (function() {
                                return t.appId_
                            }))
                        }, u.getProviderId = function() {
                            var t = this;
                            return this.providerId_ ? Promise.resolve(this.providerId_) : this.getAppId_().then((function() {
                                return t.providerId_ || "1"
                            }))
                        }, u.afterInitialization_ = function(t, e) {
                            !0 !== this.initialized_ ? !1 !== this.initialized_ ? this.get().then(t, e) : e(this.reason_) : t()
                        }, r
                    }(r.sV);

                function g(t) {
                    (0, f.sx)(51, {
                        event_name: "FacebookSDK",
                        p1: t
                    })
                }

                function _(t) {
                    return i.A.FB.init({
                        appId: t,
                        channelUrl: "//" + i.A.location.hostname + "/channel.html",
                        status: !0,
                        cookie: !1,
                        xfbml: !1,
                        version: "v3.2"
                    }), Promise.resolve(i.A.FB)
                }
                e.A = new h
            },
            93529: function(t, e, n) {
                n.d(e, {
                    s: function() {
                        return c.s
                    },
                    A: function() {
                        return u
                    }
                });
                var i = n(23149),
                    o = n(40075),
                    r = n(65297),
                    a = n(18084),
                    s = n(89730),
                    c = n(11680);
                a.A.getLogger("ClientGeneratedNotification");
                var u = function() {
                    function t(t) {
                        this.type = void 0, this.text = void 0, this.redirectPage = void 0, this.productType = void 0, this.picture = void 0, this.progress = void 0, this.promoBlock = void 0, t = (0, i.A)(t) ? t : {}, this.type = function(t) {
                            return t.type in c.s ? t.type : null
                        }(t), this.text = function(t) {
                            return "string" == typeof t.text ? t.text : t.type === c.s.ERROR ? o.Ay.get(1083) : ""
                        }(t), this.redirectPage = function(t) {
                            if ((0, i.A)(t.redirectPage)) {
                                var e = t.redirectPage,
                                    n = {};
                                return e.redirectPage && (n.redirect_page = e.redirectPage), e.userId && (n.user_id = e.userId), e.token && (n.token = e.token), e.commonPlaceId && (n.common_place_id = e.commonPlaceId), e.sectionId && (n.section_id = e.sectionId), n
                            }
                        }(t), this.productType = t.productType, this.promoBlock = t.promoBlock, this.picture = t.picture, this.progress = t.progress
                    }
                    return t.showNotification = function(e) {
                        var n = new t(e);
                        e.type !== c.s.ERROR || e.text && e.text !== o.Ay.get(1083) || (0, s.A)({
                            isOther: !0
                        }), r.A.trigger(r.A.SHOW_NOTIFICATION, n)
                    }, t.updateNotification = function(t) {
                        r.A.trigger(r.A.UPDATE_NOTIFICATION, t)
                    }, t
                }();
                u.TYPES = c.s
            },
            97758: function(t, e, n) {
                n.d(e, {
                    A: function() {
                        return o
                    }
                });
                var i = n(12321);

                function o(t) {
                    var e, n = t.activationPlace,
                        o = t.cta,
                        r = t.redirectPage,
                        a = {},
                        s = (null == o ? void 0 : o.redirect_page) || r;
                    128 === (null == s ? void 0 : s.redirect_page) && (a.category = null == (e = s.feedback_item) ? void 0 : e.type);
                    return n && (a.activationPlace = n), a.anchor = (0, i.N)(null == s ? void 0 : s.redirect_page), a
                }
            }
        }
    ]);
//# sourceMappingURL=app-init.6b19325f2f0487abc1dd.js.map
var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "4b9357fa-ce5e-4aa0-af89-3d4552f89e83", e._sentryDebugIdIdentifier = "sentry-dbid-4b9357fa-ce5e-4aa0-af89-3d4552f89e83")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "4b9357fa-ce5e-4aa0-af89-3d4552f89e83", e._sentryDebugIdIdentifier = "sentry-dbid-4b9357fa-ce5e-4aa0-af89-3d4552f89e83")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [8213], {
            3508: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return g
                    }
                });
                n(69085);
                var r = n(99417);
                n(10287);

                function i(e, t) {
                    return i = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                        return e.__proto__ = t, e
                    }, i(e, t)
                }
                var o = "unset",
                    a = function(e) {
                        var t, n;

                        function r(t) {
                            var n;
                            return (n = e.call(this) || this).data_ = void 0, n.data_ = Object.assign({}, t), n
                        }
                        n = e, (t = r).prototype = Object.create(n.prototype), t.prototype.constructor = t, i(t, n);
                        var o = r.prototype;
                        return o.get = function(e, t) {
                            return Object.prototype.hasOwnProperty.call(this.data_, e) ? "function" == typeof this.data_[e] ? this.data_[e].call(this) : this.data_[e] : 2 === arguments.length ? t : null
                        }, o.set = function(e, t) {
                            this.data_[e] = t
                        }, r
                    }(n(58544).sV);
                a.UNSET = o;
                var c, _ = a,
                    s = n(74389),
                    l = n(71363),
                    u = ((c = {
                        debug: !1,
                        env: null,
                        "api.retries": 1,
                        "webcluster.http.port": "80",
                        "webcluster.https.port": "443"
                    })[l.O.CDN_URL] = "", c[l.O.DEFAULT_PAGE] = s.x.LANDING, c[l.O.DEFAULT_AUTHENTICATED_PAGE] = s.x.ENCOUNTERS, c[l.O.DEFAULT_ANONYMOUS_PAGE] = s.x.LANDING, c.platform = 4, c["image.avatar.size.small"] = 65, c["image.avatar.size.medium"] = 90, c["verification.providers"] = [1, 4, 3, 2, 15, 12, 14], c["api.defaultHostname"] = null, c["webcluster.hostname"] = null, c["analytics.google.tracker"] = null, c["analytics.google.prod"] = null, c["analytics.google.test"] = null, c["cookie.domain"] = null, c.company = o, c["app.name"] = o, c["hotpanel.brand"] = o, c["payment.providers"] = o, c["webcluster.staging"] = o, c["fb.appId"] = o, c[l.O.NATIVE_PROTOCOL] = o, c["user.age.min"] = o, c["persistence.auth.key"] = "external-auth-data", c);
                var d = function(e, t) {
                        var n = t.cdnUrl;
                        e.set(l.O.CDN_URL, n)
                    },
                    p = (n(48598), n(2008), n(26099), n(40504)),
                    f = n(89104);
                var m = function(e, t) {
                        var n = (0, p.A)(t),
                            r = n.env,
                            i = n.zone,
                            o = n.partner,
                            a = n.platform;
                        r && r !== e.get("env") && (e.set("env", r), e.set("cookie.domain", "." + o + "." + i), r === f.A.PRODUCTION ? (e.set("webcluster.hostname", [a, o, i].filter((function(e) {
                            return e
                        })).join(".")), e.set("api.defaultHostname", o + "." + i), e.set("analytics.google.tracker", e.get("analytics.google.prod"))) : (e.set("webcluster.hostname", e.get("webcluster.staging")), e.set("api.defaultHostname", t), e.set("analytics.google.tracker", e.get("analytics.google.test"))))
                    },
                    v = new _(Object.assign({}, u, r.A._config));
                d(v, {
                    cdnUrl: r.A._badoo_cdnUrl
                }), m(v, r.A.location.hostname);
                var g = v
            },
            20679: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return g
                    }
                });
                n(26910), n(2008), n(26099), n(62062), n(79432), n(69085), n(2892), n(9868), n(23792), n(3362), n(47764), n(62953), n(51629), n(23500), n(50113), n(27495), n(90906), n(71761), n(60739), n(27208), n(45700), n(89572), n(52675), n(89463), n(84185), n(83851), n(81278), n(67945);
                var r = n(534),
                    i = n(99417),
                    o = n(3508),
                    a = n(47625),
                    c = n(79860);

                function _(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function s(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? _(Object(n), !0).forEach((function(t) {
                            l(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : _(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function l(e, t, n) {
                    return (t = function(e) {
                        var t = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(e, "string");
                        return "symbol" == typeof t ? t : String(t)
                    }(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                var u, d = n(18084).A.getLogger("Jinba"),
                    p = "hotpanelTimer",
                    f = "hotpanelMeasurement",
                    m = {
                        CLS: 38,
                        FID: 37,
                        FCP: 20,
                        LCP: 39,
                        TTFB: 23
                    },
                    v = function() {
                        var e = i.A.navigator,
                            t = null == e ? void 0 : e.userAgent,
                            n = null == e ? void 0 : e.platform,
                            r = "",
                            o = "",
                            a = "";
                        if ("android" === (n = (n || "").toLowerCase()) || /android/i.test(t)) {
                            r = "android";
                            var c = t.match(/Android (\d+(?:\.\d+)+);/);
                            o = null !== c ? c[1] : "", a = /firefox/i.test(t) ? "firefox" : /chrome/i.test(t) ? "chrome" : "other"
                        } else {
                            if ("iphone" !== n && "ipad" !== n && !/iphone|ipad/gi.test(t)) return "other";
                            var _ = t.match(/iphone|ipad/gi);
                            r = null !== _ ? _[0] : "";
                            var s = t.match(/Android (\d+(?:\.\d+)+);/);
                            o = null !== s ? s[1] : "", a = /CriOS/.test(t) ? "chrome" : "safari"
                        }
                        return r + (o ? "-" + o : "") + (a ? "-" + a : "")
                    }(),
                    g = function() {
                        function e() {
                            this._enabled = !0, this._currentAction = null, this._didMarkStartup = !1, this.trackMeaningfulPaint = h, this.trackLargestContentfulPaint = b, this.trackWebVitals = y, this.reportPerformance = w
                        }
                        var t = e.prototype;
                        return t.actionStart = function(e) {
                            var t = e.name,
                                n = e.startTime,
                                r = e.hotpanelTimer;
                            return this._enabled && t ? (this._currentAction && this._currentAction.name === t || (this._currentAction = {
                                name: t,
                                hotpanelTimer: r,
                                timers: {},
                                startTime: "number" == typeof n ? n : (new Date).getTime(),
                                duration: 0
                            }), this) : this
                        }, t.actionEnd = function(t, n) {
                            if (!this._enabled || !this._currentAction || this._currentAction.name !== t) return this;
                            var r = this._currentAction;
                            r.duration = (new Date).getTime() - r.startTime, "string" == typeof n.nameOverride && (r.name = n.nameOverride), "number" == typeof n.hotpanelTimerOverride && (r.hotpanelTimer = n.hotpanelTimerOverride);
                            var i = e.getRequest(r.name, r.hotpanelTimer, n);
                            for (var o in this._didMarkStartup || (i.tags.startup = "true", this._didMarkStartup = !0), i.setStart(r.startTime), r.timers) {
                                var a = r.timers[o];
                                0 !== a.duration && i.timerAdd(a.tags, a.duration)
                            }
                            var c, _ = this._getTotalTimeForGroup("api-call", r.timers);
                            _ > 0 && i.timerAdd(((c = {
                                group: "api-call-total"
                            })[f] = 8, c), _);
                            var s, l = this._getTotalTimeForGroup("image-load", r.timers);
                            l > 0 && i.timerAdd(((s = {
                                group: "image-load-total"
                            })[f] = 11, s), l);
                            return i.end(), this._currentAction = null, this
                        }, t.actionAbort = function(e) {
                            return this._enabled && this._currentAction && this._currentAction.name === e ? (this._currentAction = null, this) : this
                        }, t._getTotalTimeForGroup = function(e, t) {
                            var n, r, i, o, a = Object.keys(t).map((function(e) {
                                return t[e]
                            })).filter((function(t) {
                                return t.ended && t.tags.group === e
                            })).sort((function(e, t) {
                                return e.startTime - t.startTime
                            }));
                            if (0 === a.length) return 0;
                            for (var c = 0, _ = a[0].startTime, s = _ + a[0].duration, l = 1; l < a.length; l++) i = (n = a[l]).startTime, o = n.duration, i <= s ? (r = i + o) > s && (s = r) : (c += s - _, s = (_ = i) + o);
                            return c += s - _
                        }, t.eventStart = function(e, t, n) {
                            var r;
                            return this._currentAction && this._enabled ? (this._currentAction.timers[e] = {
                                name: e,
                                startTime: (new Date).getTime(),
                                tags: s(s({
                                    group: e
                                }, n), {}, (r = {}, r[f] = t, r)),
                                ended: !1,
                                duration: 0
                            }, this) : this
                        }, t.eventEnd = function(e, t) {
                            if (!this._currentAction || !this._enabled) return this;
                            var n = this._currentAction.timers[e];
                            return n && (Object.assign(n.tags, t), n.ended = !0, n.duration = (new Date).getTime() - n.startTime), this
                        }, e
                    }();

                function h() {
                    var e, t;
                    if (i.A.$timeMarks.firstPaint && null != (e = i.A.performance) && e.timing) {
                        var n = i.A.performance.timing,
                            r = g.getRequest("First meaningful paint", 12);
                        r.setStart(n.navigationStart), r.timerAdd(((t = {
                            group: "first contenful paint"
                        })[f] = 20, t), i.A.$timeMarks.firstPaint - n.navigationStart), setTimeout((function() {
                            r.end()
                        }), 0)
                    }
                }

                function b() {
                    try {
                        var e;
                        new PerformanceObserver((function(t) {
                            var n = t.getEntries(),
                                r = n[n.length - 1];
                            e = Number(r.startTime.toFixed(0))
                        })).observe({
                            type: "largest-contentful-paint",
                            buffered: !0
                        }), i.A.addEventListener("beforeunload", (function() {
                            if (e) {
                                var t = g.getRequest("Largest Contentful Paint", 15);
                                t.setStart(0), t.setEnd(e), t.end(), (0, c.bX)()
                            }
                        }))
                    } catch (e) {}
                }

                function y() {
                    function e(e) {
                        var t = m[e.name];
                        t && (0, c.sx)(692, {
                            name: 34,
                            network_interface: 8,
                            datacenter: a.A.id,
                            ip_v_6: r.backend.ipv6,
                            measurement: t,
                            time_ms: Math.round(e.value)
                        })
                    }
                    n.e(364).then(n.bind(n, 364)).then((function(t) {
                        var n = t.getCLS,
                            r = t.getFID,
                            i = t.getFCP,
                            o = t.getLCP,
                            a = t.getTTFB;
                        n(e), r(e), i(e), o(e), a(e)
                    }))
                }

                function w() {
                    var e;
                    null != (e = i.A.performance) && e.timing && function() {
                        var e, t, n, r, o = i.A.performance.timing,
                            a = o.domainLookupStart - o.navigationStart,
                            c = o.domainLookupEnd - o.domainLookupStart,
                            _ = o.connectEnd - o.connectStart,
                            s = o.responseStart - o.connectEnd,
                            l = o.responseEnd - o.responseStart,
                            u = o.domContentLoadedEventEnd - o.domLoading,
                            d = o.loadEventEnd - o.domInteractive,
                            f = (null == (e = i.A.performance) || null == e.getEntriesByType ? void 0 : e.getEntriesByType("paint")) || [],
                            m = f.find((function(e) {
                                return "first-paint" === e.name
                            })),
                            v = f.find((function(e) {
                                return "first-contentful-paint" === e.name
                            })),
                            g = [(t = {
                                name: "Critical path"
                            }, t[p] = 6, t.start = o.navigationStart, t.end = o.loadEventEnd, t.timers = [
                                ["navigation", 22, a],
                                ["dnsLookup", 36, c],
                                ["initialConnection", 13, _],
                                ["timeToFirstByte", 23, s],
                                ["contentDownload", 14, l],
                                ["domContentLoaded", 15, u],
                                ["domReady", 19, d],
                                ["firstPaint", 21, null != m && m.startTime ? Number(m.startTime.toFixed(0)) : 0],
                                ["fcp", 20, null != v && v.startTime ? Number(v.startTime.toFixed(0)) : 0]
                            ], t), (n = {
                                name: "DOM content loaded"
                            }, n[p] = 7, n.start = o.navigationStart, n.end = o.domContentLoadedEventEnd, n)];
                        o.secureConnectionStart && g.push(((r = {
                            name: "SSL handshake"
                        })[p] = 31, r.start = o.secureConnectionStart, r.end = o.requestStart, r));
                        return g
                    }().forEach((function(e) {
                        var t = g.getRequest(e.name, e[p]);
                        t.setStart(e.start);
                        var n = e.timers;
                        n && n.forEach((function(e) {
                            var n, r = e[0],
                                i = e[1],
                                o = e[2];
                            t.timerAdd(((n = {
                                group: r
                            })[f] = i, n), o)
                        })), t.setEnd(e.end), t.end()
                    }))
                }

                function k(e) {
                    var t = e.tags[p];
                    if (t) {
                        var n = {
                            name: t,
                            measurement: 1,
                            network_interface: 8,
                            time_ms: e.value,
                            datacenter: a.A.id,
                            ip_v_6: e.ipv6
                        };
                        (0, c.sx)(692, n), e.timers.forEach((function(e) {
                            var t, r = null == (t = e.tags) ? void 0 : t[f];
                            r && (0, c.sx)(692, s(s({}, n), {}, {
                                measurement: r,
                                time_ms: e.value
                            }))
                        }))
                    } else d.error("Hotpanel timer name is undefined", e.toJSON())
                }
                g.getInstance = function() {
                    return u || (u = new g)
                }, g.getRequest = function(e, t, n) {
                    var a, c, _ = ((c = {
                        app_version: null == (a = i.A._badoo_webapp_version) ? void 0 : a.replace("-SNAPSHOT", ""),
                        ua: v,
                        mode: ""
                    })[p] = t, c);
                    n && Object.assign(_, n);
                    var s = o.A.get("partner_id");
                    _.mode = s + (_.mode ? "-" + _.mode : "");
                    var l = new r.Request(e, _, d);
                    return l.setHostName(o.A.get("api.defaultHostname")), l.addEndListener(k), l
                }
            },
            37905: function(e, t, n) {
                n(79432), n(33110), n(26099), n(38781), n(3362);
                var r = n(76201),
                    i = n(91929),
                    o = n(64698),
                    a = "Persist::HpTrackingInfos";

                function c() {
                    var e = (0, i.A)(o.A),
                        t = function() {
                            try {
                                return JSON.parse(r.A.get(a))
                            } catch (e) {
                                return
                            }
                        }() || {};
                    return t.uuid !== e && (t.uuid = e, t.id = 0), t
                }

                function _() {
                    var e, t = function(e) {
                        return e.id++, e.id.toString().length > 9 && (e.id = 0), e
                    }(c());
                    return e = t, r.A.set(a, JSON.stringify(e)), t.id.toString()
                }
                var s = {
                    id: _(),
                    controller: void 0,
                    regenerateId: function() {
                        this.id = _()
                    },
                    getScreenName: function() {
                        var e;
                        return (null == (e = this.controller) ? void 0 : e.getScreenName()) || 204
                    },
                    getSrvScreenName: function() {
                        var e;
                        return null == (e = this.controller) ? void 0 : e.getSrvScreenName()
                    },
                    setController: function(e) {
                        e !== this.controller && this.regenerateId(), this.controller = e
                    },
                    controllerSetPromise: function() {
                        var e = this;
                        return new Promise((function(t, n) {
                            var r = setInterval((function() {
                                    e.controller && (o(), t(e.controller))
                                }), 16),
                                i = setTimeout((function() {
                                    e.controller || (o(), n(new Error("Current page has not controller set in 3000 ms")))
                                }), 3e3);

                            function o() {
                                r && clearInterval(r), i && clearTimeout(i)
                            }
                        }))
                    }
                };
                t.A = s
            },
            42239: function(e, t, n) {
                var r;
                n.d(t, {
                    z: function() {
                        return i
                    }
                });
                var i = ((r = {})[1] = "loading", r[2] = "finish_payment", r[3] = "end_of_game", r[4] = "view_landing_video", r[5] = "select_payment_option", r[7] = "missing_info_prompt", r[8] = "send_message", r[9] = "refresh_info", r[10] = "unable_extend", r[11] = "no_location_services", r[12] = "view_my_info", r[13] = "match", r[14] = "view_profile_info", r[15] = "close_explanation", r[16] = "delete_account", r[17] = "change_push_setting", r[18] = "unmatch", r[19] = "import_photo", r[20] = "alert", r[21] = "sign_in", r[22] = "submit_profile_changes", r[23] = "zoom_photo", r[24] = "launch_menu", r[25] = "report", r[26] = "make_payment", r[27] = "view_profile_photo", r[28] = "edit_profile", r[29] = "view_connections", r[30] = "app_start", r[31] = "launch_photo", r[32] = "select_menu_item", r[33] = "update_profile_details", r[34] = "change_payment_option", r[35] = "provide_missing_info", r[36] = "delete_photo", r[37] = "sign_in_failed", r[38] = "click_button", r[39] = "vote_profile", r[40] = "change_host", r[41] = "submit_filter_changes", r[42] = "invite", r[43] = "app_close", r[44] = "continue_voting", r[45] = "view_my_profile", r[46] = "view_payment_terms", r[47] = "request_permission", r[48] = "sign_out", r[49] = "view_screen", r[50] = "extend_match", r[51] = "generic_event", r[52] = "update_filter_details", r[53] = "chat_screen", r[54] = "start_payment", r[55] = "launch_explanation", r[56] = "view_profile", r[61] = "view_splash", r[62] = "import_contacts", r[63] = "notification", r[66] = "shared_friends", r[67] = "found_friends", r[68] = "share_profile", r[69] = "payment_intro_confirmation", r[70] = "click_camera", r[71] = "close_camera", r[72] = "take_picture", r[73] = "send_photo_in_chat", r[74] = "download_photo", r[75] = "sending_failed", r[76] = "view_photo_in_chat", r[77] = "hide_account", r[79] = "select_delete_account_option", r[80] = "accept_free_spp_delete_flow", r[82] = "delete_account_event", r[83] = "unsubscribe_from_delete_flow", r[84] = "get_password", r[87] = "submit_notification_changes", r[88] = "update_privacy_settings", r[89] = "delete_private_photo_access", r[90] = "profile_info_bottom_reached", r[91] = "filter_list", r[92] = "search", r[93] = "delete_user_from_folder", r[94] = "reach_bottom", r[95] = "rewind", r[96] = "post", r[97] = "submit_referral_code", r[98] = "rotate_device", r[99] = "send_gift", r[100] = "click_gift", r[101] = "choose_gift", r[102] = "view_common_places", r[103] = "hide_common_places", r[104] = "add_common_places", r[105] = "sticker_sent", r[106] = "click_stickers", r[107] = "view_cross_sell_screen", r[108] = "exit_cross_sell", r[109] = "view_payment_wizard", r[110] = "change_carousel_message", r[111] = "change_payment_method", r[112] = "change_payment_package", r[113] = "change_auto_topup", r[114] = "click_buy", r[115] = "payment_result", r[116] = "change_gift", r[117] = "view_stickers_screen", r[118] = "gift_sent", r[119] = "view_popularity_screen", r[120] = "click_popularity_day", r[121] = "view_payment_settings", r[122] = "change_auto_topup_from_settings", r[123] = "favorite", r[124] = "whats_new", r[125] = "error", r[126] = "add_videos", r[127] = "play_video", r[128] = "click_partner_link", r[129] = "add_place", r[130] = "view_places", r[131] = "hide_place", r[132] = "rate_app", r[133] = "like", r[134] = "scroll", r[135] = "view_facebook_ads", r[136] = "click_facebook_ads", r[137] = "change_vi_bee_setting", r[138] = "view_banner", r[139] = "click_banner", r[140] = "fill_form", r[141] = "change_place", r[142] = "view_map", r[143] = "delete_place", r[144] = "click_floating_button", r[145] = "skip_screen", r[146] = "click_you_liked_profile", r[147] = "verify_phone_number", r[148] = "verify_account", r[149] = "swtich_verification_method", r[150] = "view_promo", r[151] = "update_invisible_settings", r[152] = "request_pin_code", r[153] = "change_user_name", r[154] = "change_connectivity_status", r[155] = "error_notification", r[156] = "view_shared_friends", r[157] = "send_inmoji", r[158] = "change_notification_settings", r[159] = "bma_connection_error", r[160] = "change_text_input", r[161] = "delete_video", r[164] = "start_verify_account", r[166] = "in_chat_notification", r[167] = "change_verification_settings", r[168] = "change_verification_access_list", r[169] = "view_social_verified_profile", r[170] = "choose_invite_channel", r[172] = "replace_photo", r[173] = "undo_vote", r[174] = "external_registration", r[175] = "apply_photo_filter", r[176] = "remove_photo_filter", r[177] = "swipe_photo_filter", r[178] = "enter_captcha", r[179] = "finish_registration", r[180] = "view_my_circle", r[184] = "teleport", r[185] = "live_search", r[186] = "play_music_track", r[187] = "link_external_music_provider", r[188] = "unlink_external_music_provider", r[190] = "view_tooltip", r[191] = "pass_security_check", r[192] = "view_folder", r[195] = "scroll_element", r[196] = "click_news_digest", r[197] = "click_connection", r[198] = "rematch", r[199] = "profile_quality_walkthrough", r[200] = "profile_completeness_score", r[202] = "answer_question_old", r[203] = "click_whats_new", r[204] = "promo_queue", r[208] = "hide_music_provider_artist", r[209] = "click_buy_by_phone", r[210] = "exit_phone_payment", r[211] = "unlink_phone_number", r[212] = "switch_auto_topup", r[213] = "view_payment_screen", r[214] = "send_support_contacts", r[215] = "photo_set_private", r[216] = "view_error_screen", r[218] = "view_intercept_emoji_popup", r[219] = "click_intercept_emoji_item", r[220] = "leave_peer_to_peer_mode", r[221] = "app_crashed", r[222] = "take_photo", r[223] = "select_place", r[224] = "deselect_place", r[225] = "finish_manual_place_selection", r[227] = "cancel_video_upload", r[228] = "toggle_sharing_method", r[229] = "open_messenger", r[230] = "view_news_digest", r[232] = "enter_peer_to_peer_mode", r[233] = "revoke_permission", r[234] = "view_captcha", r[235] = "validate_captcha", r[237] = "start_invite_flow", r[240] = "send_feedback", r[241] = "video_call", r[242] = "finish_invite_flow", r[243] = "dismiss_promo", r[244] = "click_promo", r[245] = "open_gift", r[246] = "start_feedback_flow", r[247] = "click_inmoji", r[249] = "view_inmoji", r[251] = "search_ad_attribution", r[252] = "bma_connection_success", r[253] = "detach_account", r[254] = "send_gif", r[255] = "click_gif", r[256] = "cancel_photo_upload", r[257] = "click_element", r[258] = "view_element", r[259] = "apply_advanced_search_filter", r[260] = "click_interest", r[266] = "initial_chat", r[279] = "view_question", r[280] = "answer_question", r[281] = "view_questions_profile", r[287] = "view_questions_other_profile", r[306] = "send_bumble_buzz_gif", r[316] = "scroll_screen", r[318] = "reach_element_end", r[327] = "view_profile_video", r[328] = "end_video", r[332] = "click", r[333] = "element_status", r[341] = "reorder_photo", r[342] = "rate_video_call", r[345] = "recommended_profile", r[346] = "make_comment", r[348] = "secret_comment_subscription", r[420] = "chat_blocker", r[421] = "startup_time", r[422] = "cache_size", r[424] = "contacts_for_credits", r[425] = "block_profile", r[426] = "request_access", r[427] = "respond_access", r[430] = "enter_text", r[431] = "like_message", r[432] = "unlike_message", r[433] = "change_sound_setting", r[435] = "start_rewarded_video", r[436] = "rewarded_video_confirmation", r[437] = "receive_payment_external_id", r[439] = "friends_of_friends", r[440] = "start_spending", r[441] = "spending_result", r[444] = "view_filter_list", r[446] = "gesture", r[447] = "send_location", r[449] = "lookalike", r[453] = "request_photo_verification", r[454] = "payment_phone_verification", r[455] = "payment_pin_confirmation", r[456] = "link_request", r[457] = "link_response", r[458] = "auto_sync", r[459] = "disconnect", r[463] = "a_btest_log", r[464] = "screenshot", r[467] = "quick_chat", r[468] = "mini_game", r[469] = "view_education_search", r[471] = "view_returning_user_landing", r[472] = "use_hotkey", r[473] = "jinba_timer", r[475] = "view_ads", r[478] = "click_ads", r[484] = "assertion", r[485] = "report_content", r[486] = "native_sharing_dialogue", r[487] = "timeline", r[488] = "timeline_place", r[494] = "change_online_status", r[495] = "change_distance_status", r[500] = "update_game_mode", r[504] = "uninstall", r[507] = "view_lexeme", r[508] = "security_walkthrough", r[510] = "partner_promo_card", r[511] = "partner_promo_full_content", r[516] = "partner_promo_in_connections", r[549] = "stream_launch_blocker", r[551] = "mute", r[552] = "kick", r[553] = "join_stream", r[555] = "leave_stream", r[557] = "view_live_streams_list", r[565] = "connection_request", r[566] = "connection_response", r[567] = "view_requests", r[568] = "rate_stream", r[573] = "launch_wizard", r[574] = "close_wizard", r[580] = "delete_chat_contact", r[582] = "view_enlarged_photo", r[589] = "delete_question", r[590] = "view_circle_list", r[600] = "external_ad_stats", r[601] = "livestream_connection_timer", r[604] = "remove_payment_method", r[623] = "view_connection", r[643] = "mopub_impression_revenue", r[649] = "load_url_preview", r[655] = "mobile_accessibility", r[664] = "view_video", r[665] = "start_card_scan", r[666] = "card_scanned", r[667] = "luhn_check", r[692] = "web_jinba_timer", r[695] = "i_os_jinba_timer", r[703] = "android_jinba", r[789] = "match_queue_connection", r[812] = "error_ads", r[837] = "view_post", r[839] = "view_collective", r[852] = "click_post", r[854] = "click_collective", r[859] = "ad_loaded", r[864] = "vote_profile_info", r[870] = "appsflyer_sdk_state", r[873] = "notification_type_silent_dismiss", r[875] = "notification_type_aggregate", r[877] = "image_load_metric_histogram", r[878] = "image_loader_timer", r[879] = "image_load_timer", r[883] = "android_anr", r[886] = "send_poll", r[888] = "connection_establishment", r[891] = "dismiss_screen", r[893] = "view_hive_post_feed", r[894] = "click_hive", r[895] = "view_interest", r[896] = "click_hive_dialog", r[900] = "ad_requested", r[901] = "click_hive_category", r[903] = "show_location_on_profile", r[904] = "view_meetup", r[911] = "click_meetup", r[913] = "wipe_on_card", r[916] = "click_hive_notification", r[920] = "update_source_point_privacy_settings", r[930] = "quiz_match_questions_flow_answer", r[932] = "fyp_suggested", r[938] = "google_play_price_stats", r[941] = "browser_extension_check", r[943] = "view_sponsored_interest_badge", r[944] = "click_sponsored_interest_badge", r[945] = "remove_sponsored_interest_badge", r[946] = "add_sponsored_interest_badge", r[947] = "view_sponsored_interest_badge_profile", r[948] = "replace_sponsored_interest_badge", r[950] = "click_buzzing_activity", r[951] = "view_buzzing_activity", r[957] = "device_class_check", r[959] = "send_ice_breaker_ai", r[961] = "source_point_init_start", r[962] = "source_point_error", r[963] = "source_point_show_attempt", r[964] = "source_point_skip", r[965] = "source_point_init_finish", r[966] = "send_reshow_request", r[967] = "reshow_notification_received", r[973] = "view_perspective_other_profile", r[976] = "click_bff_people_discovery_element", r[977] = "view_bff_people_discovery_element", r[981] = "share_profile_toggle", r[982] = "bff_discovery_content_returned", r[986] = "click_prompt", r[988] = "client_behaviour_data", r[989] = "amazon_ad_params_requested", r[990] = "amazon_ad_params_loaded", r[991] = "amazon_ad_params_error", r[993] = "sierra_action", r[994] = "system_gallery", r[995] = "sierra_action_transfer", r[996] = "custom_opening_move_moderation", r[998] = "arkose_request", r[999] = "arkose_session", r[1e3] = "ai_photo_processing", r[1002] = "safe_date", r[1003] = "encounters_scroll_tracking", r[1004] = "click_encounters_card", r[1006] = "reach_encounters_feed_top", r[1007] = "review_before_send_moderation", r[1008] = "user_list_scroll_tracking", r[1009] = "google_play_update_stats", r[1010] = "view_user_list_card", r[1011] = "view_user_list", r[1014] = "ai_photo_model_processing", r[1015] = "photo_selection", r[1016] = "create_pass_key", r[1017] = "did_you_meet", r[1019] = "profile_carousel", r[1020] = "tip_completion_tracking", r[1021] = "collection_click", r[1022] = "scroll_article_tracking", r[1023] = "scroll_collection_tracking", r[1024] = "video_playback_tracking", r[1025] = "snippet_completion_tracking", r[1026] = "article_vote", r[1027] = "click_coaching_card", r[1034] = "article_view", r)
            },
            47625: function(e, t, n) {
                n(45700), n(89572), n(52675), n(89463), n(26099), n(2892), n(84185);

                function r(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, (i = r.key, o = void 0, "symbol" == typeof(o = function(e, t) {
                            if ("object" != typeof e || null === e) return e;
                            var n = e[Symbol.toPrimitive];
                            if (void 0 !== n) {
                                var r = n.call(e, t || "default");
                                if ("object" != typeof r) return r;
                                throw new TypeError("@@toPrimitive must return a primitive value.")
                            }
                            return ("string" === t ? String : Number)(e)
                        }(i, "string")) ? o : String(o)), r)
                    }
                    var i, o
                }
                var i = new(function() {
                    function e() {
                        this._platformId = void 0
                    }
                    var t, n, i;
                    return t = e, (n = [{
                        key: "id",
                        get: function() {
                            return this._platformId
                        },
                        set: function(e) {
                            this._platformId = e
                        }
                    }]) && r(t.prototype, n), i && r(t, i), Object.defineProperty(t, "prototype", {
                        writable: !1
                    }), e
                }());
                t.A = i
            },
            71363: function(e, t, n) {
                var r;
                n.d(t, {
                        O: function() {
                            return r
                        }
                    }),
                    function(e) {
                        e.APP_PRODUCT_TYPE = "app_product_type", e.CDN_URL = "cdn.url", e.DEFAULT_PAGE = "default.page", e.DEFAULT_AUTHENTICATED_PAGE = "default.authenticated.page", e.DEFAULT_ANONYMOUS_PAGE = "default.anonymous.page", e.HOTPANEL_BRAND = "hotpanel.brand", e.NATIVE_PROTOCOL = "native.protocol", e.PARTNER_URL = "partner_url", e.PARTNER_ID = "partner_id"
                    }(r || (r = {}))
            },
            71672: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return u
                    },
                    P: function() {
                        return c
                    }
                });
                n(79432), n(33110), n(51629), n(26099), n(23500);
                var r = n(99417),
                    i = n(18084),
                    o = n(23149),
                    a = n(89610),
                    c = (0, n(47344).A)((function() {
                        try {
                            var e = String(Math.random());
                            return localStorage.setItem(e, "1"), localStorage.removeItem(e), !0
                        } catch (e) {
                            return !1
                        }
                    })),
                    _ = (i.A.getLogger("Persistence"), {}),
                    s = !1;

                function l() {
                    s || (r.A.addEventListener("storage", (function(e) {
                        _[e.key] = null === e.newValue ? void 0 : e.newValue
                    })), s = !0)
                }
                var u = new(function() {
                    function e() {}
                    var t = e.prototype;
                    return t.getString = function(e) {
                        if (c()) return localStorage.getItem(e);
                        var t = _[e];
                        return void 0 === t ? null : t
                    }, t.saveString = function(e, t) {
                        if (c()) try {
                            localStorage.setItem(e, t)
                        } catch (e) {} else l(), _[e] = t
                    }, t.remove = function(e) {
                        c() ? localStorage.removeItem(e) : _[e] = void 0
                    }, t.getObject = function(e) {
                        try {
                            var t = this.getString(e);
                            return null === t ? null : JSON.parse(t)
                        } catch (e) {
                            return null
                        }
                    }, t.saveObject = function(e, t) {
                        try {
                            if (!(0, o.A)(t)) return;
                            var n = JSON.stringify(t);
                            c() ? localStorage.setItem(e, n) : (l(), _[e] = n)
                        } catch (e) {}
                    }, t.saveObjects = function(e) {
                        var t = 0;
                        try {
                            for (; t < e.length; t += 1) {
                                var n = e[t],
                                    r = n.key,
                                    i = n.data,
                                    o = JSON.stringify(i);
                                c() ? localStorage.setItem(r, o) : (l(), _[r] = o)
                            }
                        } catch (e) {}
                    }, t.getArray = function(e) {
                        try {
                            var t = this.getObject(e);
                            return t ? t.data : null
                        } catch (e) {
                            return null
                        }
                    }, t.hasKey = function(e) {
                        return null !== this.getString(e)
                    }, t.saveArray = function(e, t) {
                        try {
                            if (!(0, o.A)(t)) return;
                            var n = JSON.stringify({
                                data: t
                            });
                            c() ? localStorage.setItem(e, n) : (l(), _[e] = n)
                        } catch (e) {}
                    }, t.forEach = function(e) {
                        var t = this;
                        if ((0, a.A)(e)) {
                            var n;
                            if (c()) {
                                n = [];
                                for (var r = localStorage.length, i = 0; i < r; i++) {
                                    var o = localStorage.key(i);
                                    null !== o && n.push(o)
                                }
                            } else n = Object.keys(_);
                            n.forEach((function(n) {
                                return e.call(t, n)
                            }))
                        }
                    }, e
                }())
            },
            76201: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return a
                    }
                });
                var r = n(17369),
                    i = n(71672),
                    o = "bdlocal_",
                    a = new(function() {
                        function e() {}
                        var t = e.prototype;
                        return t.get = function(e) {
                            return (0, i.P)() ? localStorage.getItem(e) : r.Ay.get(o + e)
                        }, t.set = function(e, t) {
                            if ((0, i.P)()) try {
                                localStorage.setItem(e, t)
                            } catch (e) {} else r.Ay.set(o + e, t, {
                                domain: !1,
                                expiryDays: 365
                            })
                        }, t.remove = function(e) {
                            (0, i.P)() ? localStorage.removeItem(e): r.Ay.set(o + e, "", {
                                domain: !1,
                                expiryDays: -1
                            })
                        }, e
                    }())
            },
            79860: function(e, t, n) {
                n.d(t, {
                    bX: function() {
                        return O
                    },
                    U0: function() {
                        return N
                    },
                    F8: function() {
                        return I
                    },
                    sx: function() {
                        return P
                    }
                });
                n(25276), n(2892);
                var r = n(23149),
                    i = n(85208),
                    o = n(99417),
                    a = n(3508),
                    c = n(71363),
                    _ = n(37905),
                    s = n(36094),
                    l = n(55933),
                    u = n(8054),
                    d = n(99423),
                    p = n(91929),
                    f = n(64698),
                    m = n(18483),
                    v = n(18084),
                    g = (n(33110), n(79432), "TEST_COLLECT_HP_EVENTS"),
                    h = o.A.sessionStorage,
                    b = {
                        addEvent: function(e) {
                            void 0 === e && (e = {});
                            var t = this.getEvents() || [];
                            t.push(e), h.setItem(g, JSON.stringify(t))
                        },
                        getEvents: function() {
                            var e;
                            try {
                                e = JSON.parse(h.getItem(g) || "[]")
                            } catch (t) {
                                console.error("[CollectEventsStorage]::Error while retrieving sessionStorage.getItem(" + g + ")"), e = []
                            }
                            return e
                        },
                        removeEvents: function() {
                            h.removeItem(g)
                        }
                    },
                    y = n(54061),
                    w = n(36521);

                function k(e) {
                    return 7 === e ? 12 : 8 === e ? 13 : 2
                }
                var A = (0, d.A)(),
                    S = {
                        url: void 0,
                        age: void 0,
                        gender: void 0,
                        udid: void 0,
                        countryId: 0,
                        userId: void 0,
                        maximumPoolSize: 20,
                        maximumTimeout: "string" == typeof o.A._badoo_hpid ? 0 : 3e3
                    },
                    E = Boolean(o.A._badoo_collectHpEvents),
                    T = new s.oU({
                        getHotPanelConfig: function() {
                            var e = S.url;
                            if ("string" == typeof o.A._badoo_hpurl && (e = o.A._badoo_hpurl), e && "string" == typeof o.A._badoo_hpid) {
                                var t = -1 !== e.indexOf("?") ? "&" : "?";
                                e = "" + e + t + "debug=1&test_run_id=" + encodeURIComponent(o.A._badoo_hpid)
                            }
                            return {
                                url: e,
                                maximumPoolSize: S.maximumPoolSize,
                                maximumTimeout: S.maximumTimeout
                            }
                        },
                        getRequestBody: function() {
                            return function(e) {
                                var t = e.platformType,
                                    n = e.brand,
                                    r = e.userId,
                                    i = void 0 === r ? "0" : r,
                                    o = e.countryId,
                                    a = void 0 === o ? 0 : o,
                                    c = e.gender,
                                    _ = e.age,
                                    s = e.appVersion,
                                    l = e.deviceId,
                                    u = void 0 === l ? "missing-UDID" : l,
                                    d = e.userAgent,
                                    p = e.hotpanelSession,
                                    f = e.systemLocale,
                                    m = {
                                        country_id: a
                                    };
                                "string" == typeof i && (m.encrypted_user_id = i), "string" == typeof c && (m.gender = 1 === c ? 1 : 2), "number" == typeof _ && (m.age = _);
                                var v = 1;
                                return w.A.isDesktop && (v = 3, w.A.supportsTouch && (v = 2)), {
                                    application: {
                                        brand: n,
                                        layout: v,
                                        platform: k(t),
                                        app_version: s,
                                        is_premium: !1
                                    },
                                    device: {
                                        locale: f,
                                        device_id: u,
                                        user_agent: {
                                            ua: d
                                        }
                                    },
                                    user: m,
                                    session_id: p
                                }
                            }({
                                platformType: (0, y.u)(),
                                brand: a.A.get(c.O.HOTPANEL_BRAND),
                                userId: S.userId,
                                countryId: S.countryId,
                                gender: S.gender,
                                age: S.age,
                                appVersion: o.A._badoo_webapp_version,
                                deviceId: S.udid || A,
                                userAgent: o.A.navigator.userAgent,
                                hotpanelSession: (0, p.A)(f.A),
                                systemLocale: m.A.getCurrentLanguageCode()
                            })
                        },
                        getEventTrackingInfo: function() {
                            if (_.A.controller) {
                                var e, t = _.A.getScreenName();
                                if (204 === t) v.A.getLogger("Hotpanel").info("Screen name for hotpanel event tracking is set to unspecified", {
                                    url: o.A.location.href,
                                    controller: null == (e = _.A.controller.constructor) ? void 0 : e.name
                                });
                                return {
                                    screen_name: Number(t),
                                    screen_id: String(_.A.id),
                                    srv_screen_name: Number(_.A.getSrvScreenName())
                                }
                            }
                            return {
                                screen_name: 204,
                                screen_id: "0",
                                srv_screen_name: void 0
                            }
                        },
                        onBeforeTrackEvent: function(e) {
                            E && b.addEvent(e), e.tracking && !e.tracking.screen_name && v.A.getLogger("Hotpanel").error("Screen name not found for hotpanel event tracking info", {
                                eventJSON: e
                            })
                        },
                        getTrackingLogger: function() {
                            return v.A.getLogger("HotPanelLegacyTrackEvent")
                        },
                        sendRequest: l.A
                    });
                o.A.addEventListener("beforeunload", (function() {
                    T.flush()
                }));
                var O = T.flush.bind(T),
                    P = T.trackEvent.bind(T);

                function I(e) {
                    (0, r.A)(e) && (0, i.A)(S, e)
                }

                function N(e) {
                    e.url && (S.url = (0, s.sC)(e.url)), e.maximumPoolSize && (S.maximumPoolSize = e.maximumPoolSize), e.maximumTimeout && (S.maximumTimeout = 1e3 * e.maximumTimeout)
                }(0, u.A)({
                    sendHotPanelTestEndMarkerEvent: function(e) {
                        P(51, {
                            event_name: "HotPanelTestEndMarker",
                            p1: e
                        }), T.flush()
                    }
                }), E && (0, u.A)({
                    cleanHpEvents: function() {
                        b.removeEvents()
                    },
                    getHpEvents: function(e) {
                        var t = b.getEvents();
                        return e && this.cleanHpEvents(), t
                    }
                })
            }
        }
    ]);
//# sourceMappingURL=8213.625d812ba18bfef2e0ae.js.map
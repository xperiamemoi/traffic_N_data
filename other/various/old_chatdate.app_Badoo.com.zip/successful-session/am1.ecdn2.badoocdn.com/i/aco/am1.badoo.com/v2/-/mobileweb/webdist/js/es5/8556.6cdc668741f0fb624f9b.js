var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "d95f960b-60a4-41e4-8777-5866dd1dc385", e._sentryDebugIdIdentifier = "sentry-dbid-d95f960b-60a4-41e4-8777-5866dd1dc385")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                t = (new Error).stack;
            t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "d95f960b-60a4-41e4-8777-5866dd1dc385", e._sentryDebugIdIdentifier = "sentry-dbid-d95f960b-60a4-41e4-8777-5866dd1dc385")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [8556], {
            54864: function(e, t, n) {
                n.d(t, {
                    A: function() {
                        return r
                    }
                });
                n(28706);
                var s = n(15566),
                    i = [210, 370, 660, 732, 670, 431, 93, 541, 220, 230, 420, 410, 250, 610, 580, 290, 304, 550, 200, 330, 331, 310, 50, 490, 470, 750, 460, 560, 291, 100, 360, 492, 1110, 494, 1424, 662, 730, 1457],
                    r = [].concat(i, [650, 770, 670, 600, 320, 340, 480, 311, 1200, 663, 1434]),
                    a = [210, 370, 230, 420, 290, 200, 330, 310, 490, 492, 1110, 340, 480, 291, 100, 494, 360],
                    u = [40, 210, 370, 60, 70, 80, 93, 91, 492, 220, 10, 230, 420, 270, 290, 200, 330, 320, 20, 310, 690, 50, 490, 340, 470, 750, 1110, 460, 480, 291, 100, 311, 494, 360, 71, 231, 1436],
                    o = [700, 210, 230, 432, 545, 250, 790, 270, 580, 280, 290, 600, 200, 330, 340, 291, 494, 360],
                    c = [230, 432, 200, 330, 340, 291, 494],
                    h = [].concat(o, [583]),
                    l = [210, 650, 700, 541, 230, 630, 250, 610, 580, 280, 200, 330, 331, 340, 640, 291, 705],
                    d = [200, 210, 340, 871, 560, 370, 730, 662, 330, 290],
                    f = {
                        getEncountersFilter: function() {
                            var e = new s.KkJ;
                            return e.setProjection(i), e.setRequestInterests((new s.ZzE).setLimit(500)), e.setRequestAlbums([(new s.Nij).setAlbumType(7), (new s.Nij).setAlbumType(2), (new s.Nij).setAlbumType(12).setExternalProvider(12).setOffset(0).setCount(24)]), e.setQuickChatRequest((new s.dRV).setMessageCount(0)), e
                        },
                        getProfileFilter: function(e, t) {
                            var n = new s.KkJ,
                                i = [].concat(r);
                            return 2 === t && i.push(1436), n.setProjection(i), n.setRequestAlbums([(new s.Nij).setAlbumType(2), (new s.Nij).setAlbumType(7), (new s.Nij).setAlbumType(12).setExternalProvider(12).setOffset(0).setCount(24)]), "string" == typeof e && (n.setRequestInterests((new s.ZzE).setUserId(e).setLimit(500)), n.setQuickChatRequest((new s.dRV).setMessageCount(0))), n
                        },
                        getUnauthenticatedProfileFilter: function(e) {
                            var t = new s.KkJ;
                            return t.setProjection(a), t.setRequestAlbums([(new s.Nij).setAlbumType(2), (new s.Nij).setAlbumType(7)]), "string" == typeof e && t.setRequestInterests((new s.ZzE).setUserId(e).setLimit(500)), t
                        },
                        getOwnProfileFilter: function() {
                            var e = this.getProfileFilter();
                            return e.setProjection(u), e.setRequestInterests((new s.ZzE).setLimit(500)), e.delQuickChatRequest(), e
                        },
                        getLikedYouProfileFilter: function(e) {
                            return (new s.KkJ).setProfilePhotoRequest(e).setProjection(d).setSystemBadges([6]).setRequestAlbums([(new s.Nij).setAlbumType(2)])
                        },
                        getFolderFilter: function(e) {
                            var t, n = (new s.qUb).setReturnLargeUrl(!0);
                            switch (e) {
                                case 2:
                                    t = c;
                                    break;
                                case 23:
                                case 22:
                                default:
                                    t = o;
                                    break;
                                case 6:
                                    t = h;
                                    break;
                                case 26:
                                    t = l;
                                    break;
                                case 3:
                                    return this.getLikedYouProfileFilter(n)
                            }
                            return (new s.KkJ).setProfilePhotoRequest(n).setProjection(t)
                        }
                    };
                f.ENCOUNTERS_PROJECTION = i, t.h = f
            },
            57917: function(e, t, n) {
                n(27495), n(58940), n(26099), n(3362), n(62062), n(60739), n(27208), n(48598), n(5506);
                var s = n(85208),
                    i = n(42302),
                    r = n(5664),
                    a = n(1978),
                    u = n(99417),
                    o = n(3508),
                    c = n(58544),
                    h = n(84230),
                    l = n(15129),
                    d = n(18084),
                    f = n(20679),
                    g = n(35837),
                    _ = n(23735),
                    p = {
                        INVALIDATED: "invalidated"
                    };

                function y(e) {
                    if (null != e && e.name && (this.name = e.name), this.log = d.A.getLogger(this.name.replace(/Model$/, "") + "Model"), this.useCache_) {
                        this.cache_ = h.A.getInstance("GPB" + this.name);
                        var t = parseInt(this.cache_.get("version"), 10);
                        (isNaN(t) || t !== this.getVersion_()) && this.invalidateAll(), this.cache_.on(h.A.EVENTS.INVALIDATED, this.onCacheInvalidated_, this)
                    }
                    this.init_(e)
                }(0, s.A)(y.prototype, c.zb, {
                    name: "",
                    cache_: null,
                    useCache_: !0,
                    commitCache: !0,
                    init_: i.A,
                    getRequestMessageType: null,
                    getResponseMessageType: null,
                    preventMultiple: !1,
                    pendingRequests_: {},
                    trackNext_: !1,
                    maxRetries_: o.A.get("api.retries"),
                    getRequest_: function(e, t, n, s) {
                        var i = new _.Ay(e, n).setRetryCount(this.maxRetries_).on(t, s, this);
                        return i.request(), i
                    },
                    setRequestMessageType: null,
                    setResponseMessageType: null,
                    setRequest_: function(e, t) {
                        return new _.Ay(this.setRequestMessageType, e).setRetryCount(this.maxRetries_).on(this.setResponseMessageType, t, this).request()
                    },
                    get: function(e) {
                        return this.get_(this.getRequestMessageType, this.getResponseMessageType, e)
                    },
                    validateCache_: function(e, t) {
                        return !!e
                    },
                    startJinbaEvent_: function(e, t) {
                        f.A.getInstance().eventStart(e + "-api-call", 7, {
                            group: "api-call",
                            message_type: t
                        })
                    },
                    endJinbaEvent_: function(e, t) {
                        this.trackNext_ = !1, f.A.getInstance().eventEnd(e + "-api-call", {
                            is_cached: t
                        })
                    },
                    trackNext: function() {
                        return this.trackNext_ = !0, this
                    },
                    get_: function(e, t, n, s) {
                        var i, a = null,
                            u = !1;
                        if (this.trackNext_ && (i = (0, r.A)(), this.startJinbaEvent_(i, e)), this.shouldCache_(e, n)) {
                            var o = this.getFromCache_(e, n, s);
                            null != o && o.length && (o.fromCache = !0, a = Promise.resolve(o))
                        }
                        return null === a ? this.fetch_(e, t, n, i) : (this.trackNext_ && (u = !0), this.resolvePromise_(a, i, u))
                    },
                    getFromCache_: function(e, t, n) {
                        var s = this.getCacheKey_(e, t),
                            i = this.cache_.get(s);
                        return this.validateCache_(i, n) ? i.map((function(e) {
                            if (!e) return e;
                            var t = (0, g.A)(e);
                            return t.fromCache = !0, t
                        })) : null
                    },
                    fetch: function(e) {
                        return this.fetch_(this.getRequestMessageType, this.getResponseMessageType, e)
                    },
                    fetch_: function(e, t, n, s) {
                        var i = this;
                        !s && this.trackNext_ && (s = (0, r.A)(), this.startJinbaEvent_(s, e));
                        var a, u = this.shouldCache_(e, n);
                        u && (a = this.getCacheKey_(e, n));
                        var o = this.preventMultiple && u,
                            c = o && this.getMatchingPendingRequest(e, n);
                        if (c) return this.resolvePromise_(c, s, !1);
                        var h = new Promise((function(s, r) {
                            i.getRequest_(e, t, n, (function(t) {
                                if (o && i.removePendingRequest(e, n, h), !t || t instanceof _.Qc && t._type === _.a5.HANDLER_UNSATISFIED) {
                                    for (var a = arguments.length, u = new Array(a > 1 ? a - 1 : 0), c = 1; c < a; c++) u[c - 1] = arguments[c];
                                    s(u)
                                } else r(t)
                            }))
                        }));
                        return u && (h = h.then(this.cacheResponse_.bind(this, a, this.getCacheTime_(e, n)))), o && this.addPendingRequest(e, n, h), this.resolvePromise_(h, s, !1)
                    },
                    getMatchingPendingRequest: function(e, t) {
                        var n = this.getCacheKey_(e, t);
                        return this.pendingRequests_[n]
                    },
                    addPendingRequest: function(e, t, n) {
                        var s = this.getCacheKey_(e, t);
                        this.pendingRequests_[s] = n
                    },
                    removePendingRequest: function(e, t) {
                        var n = this.getCacheKey_(e, t);
                        delete this.pendingRequests_[n]
                    },
                    set: function(e) {
                        var t, n = this;
                        this.trackNext_ && (t = (0, r.A)(), this.startJinbaEvent_(t, this.setRequestMessageType));
                        var s = new Promise((function(t, s) {
                            n.setRequest_(e, (function(e) {
                                if (e) s(e);
                                else {
                                    for (var n = arguments.length, i = new Array(n > 1 ? n - 1 : 0), r = 1; r < n; r++) i[r - 1] = arguments[r];
                                    t(i)
                                }
                            }))
                        }));
                        return this.resolvePromise_(s, t, !1)
                    },
                    shouldCache_: function(e, t) {
                        return this.useCache_
                    },
                    shouldCommitCache_: function(e) {
                        return this.commitCache
                    },
                    cacheResponse_: function(e, t, n) {
                        var s = (n || []).map((function(e) {
                            return e ? e.toJSON() : null
                        }));
                        return this.cache_.put(e, s, {
                            ttl: t,
                            noCommit: !this.shouldCommitCache_(n)
                        }), n
                    },
                    resolvePromise_: function(e, t, n) {
                        if ("string" == typeof t && this.trackNext_) {
                            var s = this.endJinbaEvent_.bind(this, t, n);
                            (0, a.A)((function() {
                                e.then(s, s)
                            }))
                        }
                        return e
                    },
                    getCacheTime_: function(e, t) {
                        return 6e4 * (u.A._badoo_cacheTime || 15)
                    },
                    getCacheKey_: function(e, t) {
                        return e + ":" + ("string" == typeof t ? t : Object.entries((null == t ? void 0 : t._data) || t || {}).map((function(e) {
                            return e[0] + "=" + e[1]
                        })).join("&"))
                    },
                    invalidate: function(e, t, n) {
                        this.useCache_ && (e ? this.cache_.invalidate(e, t, n) : this.invalidateAll())
                    },
                    invalidateAll: function(e) {
                        this.useCache_ && (this.cache_.invalidateAll(!0 === e), this.cache_.put("version", this.getVersion_(), {
                            ttl: 2592e6
                        }))
                    },
                    onCacheInvalidated_: function(e) {
                        this.trigger(p.INVALIDATED, e)
                    },
                    getRequestTypeByObject_: function() {},
                    getRequestByObject_: function() {},
                    getCacheByObject_: function() {},
                    inform: function(e) {
                        var t = this.getRequestTypeByObject_(e),
                            n = this.getRequestByObject_(e),
                            s = this.getCacheByObject_(e);
                        return !(!t || void 0 === n || !s) && (!!this.shouldCache_(t, n) && (this.cacheResponse_(this.getCacheKey_(t, n), this.getCacheTime_(t, n), s), !0))
                    },
                    getVersion_: function() {
                        return 1
                    }
                }), y.extend = l.A, y.EVENTS = p, t.A = y
            }
        }
    ]);
//# sourceMappingURL=8556.6cdc668741f0fb624f9b.js.map
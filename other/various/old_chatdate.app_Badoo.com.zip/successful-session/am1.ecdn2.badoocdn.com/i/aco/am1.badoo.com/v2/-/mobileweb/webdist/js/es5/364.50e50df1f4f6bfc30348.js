var _global;
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            n = (new Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "7ed008ad-3a32-48eb-8922-4adc4f053c6f", e._sentryDebugIdIdentifier = "sentry-dbid-7ed008ad-3a32-48eb-8922-4adc4f053c6f")
    } catch (e) {}
}(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    },
    function() {
        try {
            var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
                n = (new Error).stack;
            n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "7ed008ad-3a32-48eb-8922-4adc4f053c6f", e._sentryDebugIdIdentifier = "sentry-dbid-7ed008ad-3a32-48eb-8922-4adc4f053c6f")
        } catch (e) {}
    }(), (_global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
        id: "4a5741025167946eb1a50c7b69f7912ccaaf1d53"
    }, (self.webpackChunkmobileweb = self.webpackChunkmobileweb || []).push([
        [364], {
            364: function(e, n, t) {
                t.r(n), t.d(n, {
                    getCLS: function() {
                        return w
                    },
                    getFCP: function() {
                        return y
                    },
                    getFID: function() {
                        return I
                    },
                    getLCP: function() {
                        return k
                    },
                    getTTFB: function() {
                        return F
                    }
                });
                var i, r, a, o, u = function(e, n) {
                        return {
                            name: e,
                            value: void 0 === n ? -1 : n,
                            delta: 0,
                            entries: [],
                            id: "v2-".concat(Date.now(), "-").concat(Math.floor(8999999999999 * Math.random()) + 1e12)
                        }
                    },
                    f = function(e, n) {
                        try {
                            if (PerformanceObserver.supportedEntryTypes.includes(e)) {
                                if ("first-input" === e && !("PerformanceEventTiming" in self)) return;
                                var t = new PerformanceObserver((function(e) {
                                    return e.getEntries().map(n)
                                }));
                                return t.observe({
                                    type: e,
                                    buffered: !0
                                }), t
                            }
                        } catch (e) {}
                    },
                    c = function(e, n) {
                        var t = function t(i) {
                            "pagehide" !== i.type && "hidden" !== document.visibilityState || (e(i), n && (removeEventListener("visibilitychange", t, !0), removeEventListener("pagehide", t, !0)))
                        };
                        addEventListener("visibilitychange", t, !0), addEventListener("pagehide", t, !0)
                    },
                    d = function(e) {
                        addEventListener("pageshow", (function(n) {
                            n.persisted && e(n)
                        }), !0)
                    },
                    s = function(e, n, t) {
                        var i;
                        return function(r) {
                            n.value >= 0 && (r || t) && (n.delta = n.value - (i || 0), (n.delta || void 0 === i) && (i = n.value, e(n)))
                        }
                    },
                    l = -1,
                    p = function() {
                        return "hidden" === document.visibilityState ? 0 : 1 / 0
                    },
                    m = function() {
                        c((function(e) {
                            var n = e.timeStamp;
                            l = n
                        }), !0)
                    },
                    v = function() {
                        return l < 0 && (l = p(), m(), d((function() {
                            setTimeout((function() {
                                l = p(), m()
                            }), 0)
                        }))), {
                            get firstHiddenTime() {
                                return l
                            }
                        }
                    },
                    y = function(e, n) {
                        var t, i = v(),
                            r = u("FCP"),
                            a = function(e) {
                                "first-contentful-paint" === e.name && (c && c.disconnect(), e.startTime < i.firstHiddenTime && (r.value = e.startTime, r.entries.push(e), t(!0)))
                            },
                            o = window.performance && performance.getEntriesByName && performance.getEntriesByName("first-contentful-paint")[0],
                            c = o ? null : f("paint", a);
                        (o || c) && (t = s(e, r, n), o && a(o), d((function(i) {
                            r = u("FCP"), t = s(e, r, n), requestAnimationFrame((function() {
                                requestAnimationFrame((function() {
                                    r.value = performance.now() - i.timeStamp, t(!0)
                                }))
                            }))
                        })))
                    },
                    g = !1,
                    b = -1,
                    w = function(e, n) {
                        g || (y((function(e) {
                            b = e.value
                        })), g = !0);
                        var t, i = function(n) {
                                b > -1 && e(n)
                            },
                            r = u("CLS", 0),
                            a = 0,
                            o = [],
                            l = function(e) {
                                if (!e.hadRecentInput) {
                                    var n = o[0],
                                        i = o[o.length - 1];
                                    a && e.startTime - i.startTime < 1e3 && e.startTime - n.startTime < 5e3 ? (a += e.value, o.push(e)) : (a = e.value, o = [e]), a > r.value && (r.value = a, r.entries = o, t())
                                }
                            },
                            p = f("layout-shift", l);
                        p && (t = s(i, r, n), c((function() {
                            p.takeRecords().map(l), t(!0)
                        })), d((function() {
                            a = 0, b = -1, r = u("CLS", 0), t = s(i, r, n)
                        })))
                    },
                    E = {
                        passive: !0,
                        capture: !0
                    },
                    h = new Date,
                    T = function(e, n) {
                        i || (i = n, r = e, a = new Date, D(removeEventListener), S())
                    },
                    S = function() {
                        if (r >= 0 && r < a - h) {
                            var e = {
                                entryType: "first-input",
                                name: i.type,
                                target: i.target,
                                cancelable: i.cancelable,
                                startTime: i.timeStamp,
                                processingStart: i.timeStamp + r
                            };
                            o.forEach((function(n) {
                                n(e)
                            })), o = []
                        }
                    },
                    L = function(e) {
                        if (e.cancelable) {
                            var n = (e.timeStamp > 1e12 ? new Date : performance.now()) - e.timeStamp;
                            "pointerdown" == e.type ? function(e, n) {
                                var t = function() {
                                        T(e, n), r()
                                    },
                                    i = function() {
                                        r()
                                    },
                                    r = function() {
                                        removeEventListener("pointerup", t, E), removeEventListener("pointercancel", i, E)
                                    };
                                addEventListener("pointerup", t, E), addEventListener("pointercancel", i, E)
                            }(n, e) : T(n, e)
                        }
                    },
                    D = function(e) {
                        ["mousedown", "keydown", "touchstart", "pointerdown"].forEach((function(n) {
                            return e(n, L, E)
                        }))
                    },
                    I = function(e, n) {
                        var t, a = v(),
                            l = u("FID"),
                            p = function(e) {
                                e.startTime < a.firstHiddenTime && (l.value = e.processingStart - e.startTime, l.entries.push(e), t(!0))
                            },
                            m = f("first-input", p);
                        t = s(e, l, n), m && c((function() {
                            m.takeRecords().map(p), m.disconnect()
                        }), !0), m && d((function() {
                            var a;
                            l = u("FID"), t = s(e, l, n), o = [], r = -1, i = null, D(addEventListener), a = p, o.push(a), S()
                        }))
                    },
                    _ = {},
                    k = function(e, n) {
                        var t, i = v(),
                            r = u("LCP"),
                            a = function(e) {
                                var n = e.startTime;
                                n < i.firstHiddenTime && (r.value = n, r.entries.push(e), t())
                            },
                            o = f("largest-contentful-paint", a);
                        if (o) {
                            t = s(e, r, n);
                            var l = function() {
                                _[r.id] || (o.takeRecords().map(a), o.disconnect(), _[r.id] = !0, t(!0))
                            };
                            ["keydown", "click"].forEach((function(e) {
                                addEventListener(e, l, {
                                    once: !0,
                                    capture: !0
                                })
                            })), c(l, !0), d((function(i) {
                                r = u("LCP"), t = s(e, r, n), requestAnimationFrame((function() {
                                    requestAnimationFrame((function() {
                                        r.value = performance.now() - i.timeStamp, _[r.id] = !0, t(!0)
                                    }))
                                }))
                            }))
                        }
                    },
                    F = function(e) {
                        var n, t = u("TTFB");
                        n = function() {
                            try {
                                var n = performance.getEntriesByType("navigation")[0] || function() {
                                    var e = performance.timing,
                                        n = {
                                            entryType: "navigation",
                                            startTime: 0
                                        };
                                    for (var t in e) "navigationStart" !== t && "toJSON" !== t && (n[t] = Math.max(e[t] - e.navigationStart, 0));
                                    return n
                                }();
                                if (t.value = t.delta = n.responseStart, t.value < 0 || t.value > performance.now()) return;
                                t.entries = [n], e(t)
                            } catch (e) {}
                        }, "complete" === document.readyState ? setTimeout(n, 0) : addEventListener("load", (function() {
                            return setTimeout(n, 0)
                        }))
                    }
            }
        }
    ]);
//# sourceMappingURL=364.50e50df1f4f6bfc30348.js.map
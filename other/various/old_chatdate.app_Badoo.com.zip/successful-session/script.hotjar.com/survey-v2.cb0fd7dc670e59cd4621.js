/*! For license information please see survey-v2.cb0fd7dc670e59cd4621.js.LICENSE.txt */

! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            n = (new Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "5d9fd107-4acd-5949-be82-9e5959c104a4")
    } catch (e) {}
}();
! function() {
    var e = {
            62: function(e, n, t) {
                t.p = hj.scriptDomain
            },
            5340: function(e, n, t) {
                "use strict";
                t.r(n);
                var r = t(5933),
                    o = t.n(r),
                    i = t(2384),
                    a = t.n(i),
                    l = t(1482),
                    s = t.n(l),
                    c = t(2437),
                    u = t.n(c),
                    d = t(7334),
                    p = t.n(d),
                    f = t(6922),
                    h = t.n(f),
                    m = t(6385),
                    _ = t.n(m),
                    v = t(3012),
                    y = t.n(v),
                    b = t(2825),
                    g = t.n(b),
                    w = o()((function(e) {
                        return e[1]
                    })),
                    x = a()(s()),
                    k = a()(s(), {
                        hash: "#iefix"
                    }),
                    j = a()(u()),
                    S = a()(p()),
                    C = a()(h()),
                    M = a()(_(), {
                        hash: "#hotjar"
                    }),
                    P = a()(y()),
                    O = a()(g());
                w.push([e.id, "._hj-Pbej5__styles__resetStyles *{line-height:normal;font-family:Arial, sans-serif, Tahoma !important;text-transform:initial !important;letter-spacing:normal !important}._hj-Pbej5__styles__resetStyles *::before,._hj-Pbej5__styles__resetStyles *::after{box-sizing:initial}._hj-Pbej5__styles__resetStyles div{height:auto}._hj-Pbej5__styles__resetStyles button{display:inline-block;height:auto;font-size:1rem}._hj-Pbej5__styles__resetStyles div,._hj-Pbej5__styles__resetStyles span,._hj-Pbej5__styles__resetStyles p,._hj-Pbej5__styles__resetStyles a,._hj-Pbej5__styles__resetStyles button{font-weight:normal !important}._hj-Pbej5__styles__resetStyles div,._hj-Pbej5__styles__resetStyles span,._hj-Pbej5__styles__resetStyles p,._hj-Pbej5__styles__resetStyles a,._hj-Pbej5__styles__resetStyles img,._hj-Pbej5__styles__resetStyles strong,._hj-Pbej5__styles__resetStyles form,._hj-Pbej5__styles__resetStyles label{border:0;font-size:100%;vertical-align:baseline;background:transparent;margin:0;padding:0;float:none !important}._hj-Pbej5__styles__resetStyles span{color:inherit}._hj-Pbej5__styles__resetStyles ol,._hj-Pbej5__styles__resetStyles ul,._hj-Pbej5__styles__resetStyles li{list-style:none !important;margin:0 !important;padding:0 !important}._hj-Pbej5__styles__resetStyles li:before,._hj-Pbej5__styles__resetStyles li:after{content:none !important}._hj-Pbej5__styles__resetStyles hr{display:block;height:1px;border:0;border-top:1px solid #ccc;margin:1em 0;padding:0}._hj-Pbej5__styles__resetStyles input[type='submit'],._hj-Pbej5__styles__resetStyles input[type='button'],._hj-Pbej5__styles__resetStyles button{margin:0;padding:0;float:none !important}._hj-Pbej5__styles__resetStyles input,._hj-Pbej5__styles__resetStyles select,._hj-Pbej5__styles__resetStyles a img{vertical-align:middle}._hj-s3UIi__styles__globalStyles *,._hj-s3UIi__styles__globalStyles *::before,._hj-s3UIi__styles__globalStyles *::after{box-sizing:border-box}@font-face{font-family:'hotjar';src:url(" + x + ");src:url(" + k + ') format("embedded-opentype"),url(' + j + ') format("woff2"),url(' + S + ') format("truetype"),url(' + C + ') format("woff"),url(' + M + ") format(\"svg\");font-weight:normal;font-style:normal}@keyframes _hj-eYRYp__styles__spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}@keyframes _hj-5\\+Z5O__styles__colors{0%{border-color:#f4364c;border-top-color:transparent}25%{border-color:#00a2f2;border-top-color:transparent}50%{border-color:#efb60c;border-top-color:transparent}75%{border-color:#42ca49;border-top-color:transparent}100%{border-color:#f4364c;border-top-color:transparent}}._hj-s3UIi__styles__globalStyles p{color:inherit !important}._hj-s3UIi__styles__globalStyles a,._hj-s3UIi__styles__globalStyles a:link,._hj-s3UIi__styles__globalStyles a:hover,._hj-s3UIi__styles__globalStyles a:active{color:inherit !important;text-decoration:underline}._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon{speak:none !important;font-style:normal !important;font-weight:normal !important;font-variant:normal !important;text-transform:none !important;overflow-wrap:normal !important;word-break:normal !important;word-wrap:normal !important;white-space:nowrap !important;line-height:normal !important;-webkit-font-smoothing:antialiased !important;-moz-osx-font-smoothing:grayscale !important;vertical-align:middle !important}._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon,._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon:before,._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon:after,._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon *,._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon *:before,._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon *:after{font-family:'hotjar' !important;display:inline-block !important;direction:ltr !important}._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon:before{color:inherit !important}._hj-s3UIi__styles__globalStyles ._hj-dk3Fb__styles__iconX:before{content:'\\e803'}._hj-s3UIi__styles__globalStyles ._hj-9iDZB__styles__iconOk:before{content:'\\e804'}._hj-s3UIi__styles__globalStyles ._hj-t13KX__styles__iconError:before{content:'\\e90c'}._hj-s3UIi__styles__globalStyles ._hj-D\\+oDX__styles__iconLogo:before{content:'\\e806'}._hj-s3UIi__styles__globalStyles ._hj-Nbq9C__styles__iconSelectElement:before{content:'\\e91a'}._hj-s3UIi__styles__globalStyles ._hj-mtJG6__styles__surveyIcons{background-repeat:no-repeat;width:16px;height:16px;display:inline-block !important;zoom:1;vertical-align:middle}._hj-widget-theme-light ._hj-s3UIi__styles__globalStyles ._hj-mtJG6__styles__surveyIcons{background-image:url(" + P + ")}._hj-widget-theme-dark ._hj-s3UIi__styles__globalStyles ._hj-mtJG6__styles__surveyIcons{background-image:url(" + O + ")}._hj-s3UIi__styles__globalStyles ._hj-EZqbk__styles__inputField{font-family:Arial, sans-serif, Tahoma;font-size:14px;color:#333 !important;padding:6px !important;text-indent:0 !important;height:30px;width:100%;min-width:100%;background:white;border:1px solid !important;outline:none !important;max-width:none !important;float:none;border-radius:3px}._hj-s3UIi__styles__globalStyles ._hj-AwaE7__styles__textarea{resize:none;height:100px}._hj-s3UIi__styles__globalStyles ._hj-EIBGi__styles__basicButton,._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton{cursor:pointer;text-decoration:none;text-transform:capitalize;font-size:14px;font-weight:bold;padding:6px 16px !important;border:0;outline:0;display:inline-block;vertical-align:top;width:auto;zoom:1;transition:all 0.2s ease-in-out;box-shadow:0 2px 3px 0 rgba(0,0,0,0.15);border-radius:4px;color:white}._hj-s3UIi__styles__globalStyles ._hj-EIBGi__styles__basicButton:hover,._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:hover,._hj-s3UIi__styles__globalStyles ._hj-EIBGi__styles__basicButton:focus,._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:focus,._hj-s3UIi__styles__globalStyles ._hj-EIBGi__styles__basicButton:active,._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:active{background:#00a251}._hj-s3UIi__styles__globalStyles ._hj-EIBGi__styles__basicButton[disabled],._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton[disabled]{cursor:default}._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton{font-size:14px !important;font-weight:500 !important;padding:6px 16px !important;border:0 !important;outline:0 !important;min-height:initial !important;width:auto !important;min-width:initial !important;background:var(--hjFeedbackAccentColor) !important;color:var(--hjFeedbackAccentTextColor) !important;box-shadow:none !important}._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:hover,._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:focus,._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:active{background:var(--hjFeedbackAccentActiveColor) !important}._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:focus{background:var(--hjFeedbackAccentColor) !important;box-shadow:0 0 0 1px var(--hjFeedbackPrimaryColor),0 0 0 3px var(--hjFeedbackAccentColor) !important}._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:hover{background:var(--hjFeedbackAccentHoverColor) !important}._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton[disabled]{cursor:default;background:var(--hjFeedbackDisabledAccentColor) !important;color:var(--hjFeedbackDisabledAccentTextColor) !important}._hj-s3UIi__styles__globalStyles ._hj-F457\\+__styles__clearButton{cursor:pointer;text-decoration:underline;font-size:13px !important;padding:0 10px !important;border:0 !important}._hj-s3UIi__styles__globalStyles ._hj-F457\\+__styles__clearButton,._hj-s3UIi__styles__globalStyles ._hj-F457\\+__styles__clearButton:hover,._hj-s3UIi__styles__globalStyles ._hj-F457\\+__styles__clearButton:focus,._hj-s3UIi__styles__globalStyles ._hj-F457\\+__styles__clearButton:active{background:transparent !important}._hj-s3UIi__styles__globalStyles ._hj-hTm4\\+__styles__answersContentWrapper{padding:4px 12px 16px 12px}._hj-s3UIi__styles__globalStyles ._hj-ag9y\\+__styles__spinner{border:1px solid rgba(0,0,0,0.6);border-top-color:transparent !important;border-radius:50%;transform:rotate(0deg);animation:_hj-eYRYp__styles__spin 0.4s linear infinite, _hj-5\\+Z5O__styles__colors 5.6s ease-in-out infinite}._hj-s3UIi__styles__globalStyles ._hj-H1LCt__styles__widget{font-size:13px !important;position:fixed;z-index:2147483640;bottom:-400px;right:100px;width:300px;-webkit-border-radius:5px 5px 0 0;-moz-border-radius:5px 5px 0 0;border-radius:5px 5px 0 0;-webkit-transform:translateZ(0) !important;transform:translateZ(0) !important}._hj-AwaE7__styles__textarea{}._hj-dk3Fb__styles__iconX,._hj-9iDZB__styles__iconOk,._hj-t13KX__styles__iconError,._hj-D\\+oDX__styles__iconLogo,._hj-Nbq9C__styles__iconSelectElement{}._hj-eJm8p__styles__rtl,._hj-eJm8p__styles__rtl *{direction:rtl !important}._hj-hc6BA__styles__roundedCorners{border-radius:3px}@media screen and (max-width: 480px){._hj-A4W17__styles__inlineSurvey{max-width:100%;overflow-x:auto}}\n", ""]), w.locals = {
                    resetStyles: "_hj-Pbej5__styles__resetStyles",
                    globalStyles: "_hj-s3UIi__styles__globalStyles",
                    icon: "_hj-L5SMl__styles__icon",
                    iconX: "_hj-dk3Fb__styles__iconX _hj-L5SMl__styles__icon",
                    iconOk: "_hj-9iDZB__styles__iconOk _hj-L5SMl__styles__icon",
                    iconError: "_hj-t13KX__styles__iconError _hj-L5SMl__styles__icon",
                    iconLogo: "_hj-D+oDX__styles__iconLogo _hj-L5SMl__styles__icon",
                    iconSelectElement: "_hj-Nbq9C__styles__iconSelectElement _hj-L5SMl__styles__icon",
                    surveyIcons: "_hj-mtJG6__styles__surveyIcons",
                    inputField: "_hj-EZqbk__styles__inputField",
                    textarea: "_hj-AwaE7__styles__textarea _hj-EZqbk__styles__inputField",
                    basicButton: "_hj-EIBGi__styles__basicButton",
                    primaryButton: "_hj-SU8LU__styles__primaryButton",
                    clearButton: "_hj-F457+__styles__clearButton",
                    answersContentWrapper: "_hj-hTm4+__styles__answersContentWrapper",
                    spinner: "_hj-ag9y+__styles__spinner",
                    spin: "_hj-eYRYp__styles__spin",
                    colors: "_hj-5+Z5O__styles__colors",
                    widget: "_hj-H1LCt__styles__widget",
                    rtl: "_hj-eJm8p__styles__rtl",
                    roundedCorners: "_hj-hc6BA__styles__roundedCorners",
                    inlineSurvey: "_hj-A4W17__styles__inlineSurvey"
                }, n.default = w
            },
            5933: function(e) {
                "use strict";
                e.exports = function(e) {
                    var n = [];
                    return n.toString = function() {
                        return this.map((function(n) {
                            var t = e(n);
                            return n[2] ? "@media ".concat(n[2], " {").concat(t, "}") : t
                        })).join("")
                    }, n.i = function(e, t, r) {
                        "string" == typeof e && (e = [
                            [null, e, ""]
                        ]);
                        var o = {};
                        if (r)
                            for (var i = 0; i < this.length; i++) {
                                var a = this[i][0];
                                null != a && (o[a] = !0)
                            }
                        for (var l = 0; l < e.length; l++) {
                            var s = [].concat(e[l]);
                            r && o[s[0]] || (t && (s[2] ? s[2] = "".concat(t, " and ").concat(s[2]) : s[2] = t), n.push(s))
                        }
                    }, n
                }
            },
            2384: function(e) {
                "use strict";
                e.exports = function(e, n) {
                    return n || (n = {}), "string" != typeof(e = e && e.__esModule ? e.default : e) ? e : (/^['"].*['"]$/.test(e) && (e = e.slice(1, -1)), n.hash && (e += n.hash), /["'() \t\n]/.test(e) || n.needQuotes ? '"'.concat(e.replace(/"/g, '\\"').replace(/\n/g, "\\n"), '"') : e)
                }
            },
            2825: function(e, n, t) {
                e.exports = t.p + "widget_icons_dark.ad934a.png"
            },
            3012: function(e, n, t) {
                e.exports = t.p + "widget_icons_light.766225.png"
            },
            3399: function(e, n, t) {
                e.exports = t.p + "Roboto-Medium.52cb73.woff"
            },
            8585: function(e, n, t) {
                e.exports = t.p + "Roboto-Medium.ef8bb0.woff2"
            },
            5104: function(e, n, t) {
                e.exports = t.p + "Roboto-Regular.376ea5.woff"
            },
            6228: function(e, n, t) {
                e.exports = t.p + "Roboto-Regular.422781.woff2"
            },
            1482: function(e, n, t) {
                e.exports = t.p + "font-hotjar_5.f4b154.eot"
            },
            6385: function(e, n, t) {
                e.exports = t.p + "font-hotjar_5.2c7ab2.svg"
            },
            7334: function(e, n, t) {
                e.exports = t.p + "font-hotjar_5.0ddfe2.ttf"
            },
            6922: function(e, n, t) {
                e.exports = t.p + "font-hotjar_5.17b429.woff"
            },
            2437: function(e, n, t) {
                e.exports = t.p + "font-hotjar_5.65042d.woff2"
            },
            63: function(e, n, t) {
                "use strict";
                var r = t(9415),
                    o = {
                        childContextTypes: !0,
                        contextType: !0,
                        contextTypes: !0,
                        defaultProps: !0,
                        displayName: !0,
                        getDefaultProps: !0,
                        getDerivedStateFromError: !0,
                        getDerivedStateFromProps: !0,
                        mixins: !0,
                        propTypes: !0,
                        type: !0
                    },
                    i = {
                        name: !0,
                        length: !0,
                        prototype: !0,
                        caller: !0,
                        callee: !0,
                        arguments: !0,
                        arity: !0
                    },
                    a = {
                        $$typeof: !0,
                        compare: !0,
                        defaultProps: !0,
                        displayName: !0,
                        propTypes: !0,
                        type: !0
                    },
                    l = {};

                function s(e) {
                    return r.isMemo(e) ? a : l[e.$$typeof] || o
                }
                l[r.ForwardRef] = {
                    $$typeof: !0,
                    render: !0,
                    defaultProps: !0,
                    displayName: !0,
                    propTypes: !0
                }, l[r.Memo] = a;
                var c = Object.defineProperty,
                    u = Object.getOwnPropertyNames,
                    d = Object.getOwnPropertySymbols,
                    p = Object.getOwnPropertyDescriptor,
                    f = Object.getPrototypeOf,
                    h = Object.prototype;
                e.exports = function e(n, t, r) {
                    if ("string" != typeof t) {
                        if (h) {
                            var o = f(t);
                            o && o !== h && e(n, o, r)
                        }
                        var a = u(t);
                        d && (a = a.concat(d(t)));
                        for (var l = s(n), m = s(t), _ = 0; _ < a.length; ++_) {
                            var v = a[_];
                            if (!(i[v] || r && r[v] || m && m[v] || l && l[v])) {
                                var y = p(t, v);
                                try {
                                    c(n, v, y)
                                } catch (e) {}
                            }
                        }
                    }
                    return n
                }
            },
            4507: function(e, n) {
                "use strict";
                var t = "function" == typeof Symbol && Symbol.for,
                    r = t ? Symbol.for("react.element") : 60103,
                    o = t ? Symbol.for("react.portal") : 60106,
                    i = t ? Symbol.for("react.fragment") : 60107,
                    a = t ? Symbol.for("react.strict_mode") : 60108,
                    l = t ? Symbol.for("react.profiler") : 60114,
                    s = t ? Symbol.for("react.provider") : 60109,
                    c = t ? Symbol.for("react.context") : 60110,
                    u = t ? Symbol.for("react.async_mode") : 60111,
                    d = t ? Symbol.for("react.concurrent_mode") : 60111,
                    p = t ? Symbol.for("react.forward_ref") : 60112,
                    f = t ? Symbol.for("react.suspense") : 60113,
                    h = t ? Symbol.for("react.suspense_list") : 60120,
                    m = t ? Symbol.for("react.memo") : 60115,
                    _ = t ? Symbol.for("react.lazy") : 60116,
                    v = t ? Symbol.for("react.block") : 60121,
                    y = t ? Symbol.for("react.fundamental") : 60117,
                    b = t ? Symbol.for("react.responder") : 60118,
                    g = t ? Symbol.for("react.scope") : 60119;

                function w(e) {
                    if ("object" == typeof e && null !== e) {
                        var n = e.$$typeof;
                        switch (n) {
                            case r:
                                switch (e = e.type) {
                                    case u:
                                    case d:
                                    case i:
                                    case l:
                                    case a:
                                    case f:
                                        return e;
                                    default:
                                        switch (e = e && e.$$typeof) {
                                            case c:
                                            case p:
                                            case _:
                                            case m:
                                            case s:
                                                return e;
                                            default:
                                                return n
                                        }
                                }
                            case o:
                                return n
                        }
                    }
                }

                function x(e) {
                    return w(e) === d
                }
                n.AsyncMode = u, n.ConcurrentMode = d, n.ContextConsumer = c, n.ContextProvider = s, n.Element = r, n.ForwardRef = p, n.Fragment = i, n.Lazy = _, n.Memo = m, n.Portal = o, n.Profiler = l, n.StrictMode = a, n.Suspense = f, n.isAsyncMode = function(e) {
                    return x(e) || w(e) === u
                }, n.isConcurrentMode = x, n.isContextConsumer = function(e) {
                    return w(e) === c
                }, n.isContextProvider = function(e) {
                    return w(e) === s
                }, n.isElement = function(e) {
                    return "object" == typeof e && null !== e && e.$$typeof === r
                }, n.isForwardRef = function(e) {
                    return w(e) === p
                }, n.isFragment = function(e) {
                    return w(e) === i
                }, n.isLazy = function(e) {
                    return w(e) === _
                }, n.isMemo = function(e) {
                    return w(e) === m
                }, n.isPortal = function(e) {
                    return w(e) === o
                }, n.isProfiler = function(e) {
                    return w(e) === l
                }, n.isStrictMode = function(e) {
                    return w(e) === a
                }, n.isSuspense = function(e) {
                    return w(e) === f
                }, n.isValidElementType = function(e) {
                    return "string" == typeof e || "function" == typeof e || e === i || e === d || e === l || e === a || e === f || e === h || "object" == typeof e && null !== e && (e.$$typeof === _ || e.$$typeof === m || e.$$typeof === s || e.$$typeof === c || e.$$typeof === p || e.$$typeof === y || e.$$typeof === b || e.$$typeof === g || e.$$typeof === v)
                }, n.typeOf = w
            },
            9415: function(e, n, t) {
                "use strict";
                e.exports = t(4507)
            },
            5090: function(e, n, t) {
                var r = t(1157),
                    o = t(5340);
                "string" == typeof(o = o.__esModule ? o.default : o) && (o = [
                    [e.id, o, ""]
                ]);
                r(o, {
                    insert: "head",
                    singleton: !1
                }), e.exports = o.locals || {}
            },
            1157: function(e, n, t) {
                "use strict";
                var r, o = function() {
                        var e = {};
                        return function(n) {
                            if (void 0 === e[n]) {
                                var t = document.querySelector(n);
                                if (window.HTMLIFrameElement && t instanceof window.HTMLIFrameElement) try {
                                    t = t.contentDocument.head
                                } catch (e) {
                                    t = null
                                }
                                e[n] = t
                            }
                            return e[n]
                        }
                    }(),
                    i = [];

                function a(e) {
                    for (var n = -1, t = 0; t < i.length; t++)
                        if (i[t].identifier === e) {
                            n = t;
                            break
                        }
                    return n
                }

                function l(e, n) {
                    for (var t = {}, r = [], o = 0; o < e.length; o++) {
                        var l = e[o],
                            s = n.base ? l[0] + n.base : l[0],
                            c = t[s] || 0,
                            u = "".concat(s, " ").concat(c);
                        t[s] = c + 1;
                        var d = a(u),
                            p = {
                                css: l[1],
                                media: l[2],
                                sourceMap: l[3]
                            }; - 1 !== d ? (i[d].references++, i[d].updater(p)) : i.push({
                            identifier: u,
                            updater: m(p, n),
                            references: 1
                        }), r.push(u)
                    }
                    return r
                }

                function s(e) {
                    var n = document.createElement("style"),
                        r = e.attributes || {};
                    if (void 0 === r.nonce) {
                        var i = t.nc;
                        i && (r.nonce = i)
                    }
                    if (Object.keys(r).forEach((function(e) {
                            n.setAttribute(e, r[e])
                        })), "function" == typeof e.insert) e.insert(n);
                    else {
                        var a = o(e.insert || "head");
                        if (!a) throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
                        a.appendChild(n)
                    }
                    return n
                }
                var c, u = (c = [], function(e, n) {
                    return c[e] = n, c.filter(Boolean).join("\n")
                });

                function d(e, n, t, r) {
                    var o = t ? "" : r.media ? "@media ".concat(r.media, " {").concat(r.css, "}") : r.css;
                    if (e.styleSheet) e.styleSheet.cssText = u(n, o);
                    else {
                        var i = document.createTextNode(o),
                            a = e.childNodes;
                        a[n] && e.removeChild(a[n]), a.length ? e.insertBefore(i, a[n]) : e.appendChild(i)
                    }
                }

                function p(e, n, t) {
                    var r = t.css,
                        o = t.media,
                        i = t.sourceMap;
                    if (o ? e.setAttribute("media", o) : e.removeAttribute("media"), i && btoa && (r += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(i)))), " */")), e.styleSheet) e.styleSheet.cssText = r;
                    else {
                        for (; e.firstChild;) e.removeChild(e.firstChild);
                        e.appendChild(document.createTextNode(r))
                    }
                }
                var f = null,
                    h = 0;

                function m(e, n) {
                    var t, r, o;
                    if (n.singleton) {
                        var i = h++;
                        t = f || (f = s(n)), r = d.bind(null, t, i, !1), o = d.bind(null, t, i, !0)
                    } else t = s(n), r = p.bind(null, t, n), o = function() {
                        ! function(e) {
                            if (null === e.parentNode) return !1;
                            e.parentNode.removeChild(e)
                        }(t)
                    };
                    return r(e),
                        function(n) {
                            if (n) {
                                if (n.css === e.css && n.media === e.media && n.sourceMap === e.sourceMap) return;
                                r(e = n)
                            } else o()
                        }
                }
                e.exports = function(e, n) {
                    (n = n || {}).singleton || "boolean" == typeof n.singleton || (n.singleton = (void 0 === r && (r = Boolean(window && document && document.all && !window.atob)), r));
                    var t = l(e = e || [], n);
                    return function(e) {
                        if (e = e || [], "[object Array]" === Object.prototype.toString.call(e)) {
                            for (var r = 0; r < t.length; r++) {
                                var o = a(t[r]);
                                i[o].references--
                            }
                            for (var s = l(e, n), c = 0; c < t.length; c++) {
                                var u = a(t[c]);
                                0 === i[u].references && (i[u].updater(), i.splice(u, 1))
                            }
                            t = s
                        }
                    }
                }
            },
            9425: function(e) {
                e.exports = function() {
                    "use strict";
                    var e = {
                            aliceblue: [240, 248, 255],
                            antiquewhite: [250, 235, 215],
                            aqua: [0, 255, 255],
                            aquamarine: [127, 255, 212],
                            azure: [240, 255, 255],
                            beige: [245, 245, 220],
                            bisque: [255, 228, 196],
                            black: [0, 0, 0],
                            blanchedalmond: [255, 235, 205],
                            blue: [0, 0, 255],
                            blueviolet: [138, 43, 226],
                            brown: [165, 42, 42],
                            burlywood: [222, 184, 135],
                            cadetblue: [95, 158, 160],
                            chartreuse: [127, 255, 0],
                            chocolate: [210, 105, 30],
                            coral: [255, 127, 80],
                            cornflowerblue: [100, 149, 237],
                            cornsilk: [255, 248, 220],
                            crimson: [220, 20, 60],
                            cyan: [0, 255, 255],
                            darkblue: [0, 0, 139],
                            darkcyan: [0, 139, 139],
                            darkgoldenrod: [184, 134, 11],
                            darkgray: [169, 169, 169],
                            darkgreen: [0, 100, 0],
                            darkgrey: [169, 169, 169],
                            darkkhaki: [189, 183, 107],
                            darkmagenta: [139, 0, 139],
                            darkolivegreen: [85, 107, 47],
                            darkorange: [255, 140, 0],
                            darkorchid: [153, 50, 204],
                            darkred: [139, 0, 0],
                            darksalmon: [233, 150, 122],
                            darkseagreen: [143, 188, 143],
                            darkslateblue: [72, 61, 139],
                            darkslategray: [47, 79, 79],
                            darkslategrey: [47, 79, 79],
                            darkturquoise: [0, 206, 209],
                            darkviolet: [148, 0, 211],
                            deeppink: [255, 20, 147],
                            deepskyblue: [0, 191, 255],
                            dimgray: [105, 105, 105],
                            dimgrey: [105, 105, 105],
                            dodgerblue: [30, 144, 255],
                            firebrick: [178, 34, 34],
                            floralwhite: [255, 250, 240],
                            forestgreen: [34, 139, 34],
                            fuchsia: [255, 0, 255],
                            gainsboro: [220, 220, 220],
                            ghostwhite: [248, 248, 255],
                            gold: [255, 215, 0],
                            goldenrod: [218, 165, 32],
                            gray: [128, 128, 128],
                            green: [0, 128, 0],
                            greenyellow: [173, 255, 47],
                            grey: [128, 128, 128],
                            honeydew: [240, 255, 240],
                            hotpink: [255, 105, 180],
                            indianred: [205, 92, 92],
                            indigo: [75, 0, 130],
                            ivory: [255, 255, 240],
                            khaki: [240, 230, 140],
                            lavender: [230, 230, 250],
                            lavenderblush: [255, 240, 245],
                            lawngreen: [124, 252, 0],
                            lemonchiffon: [255, 250, 205],
                            lightblue: [173, 216, 230],
                            lightcoral: [240, 128, 128],
                            lightcyan: [224, 255, 255],
                            lightgoldenrodyellow: [250, 250, 210],
                            lightgray: [211, 211, 211],
                            lightgreen: [144, 238, 144],
                            lightgrey: [211, 211, 211],
                            lightpink: [255, 182, 193],
                            lightsalmon: [255, 160, 122],
                            lightseagreen: [32, 178, 170],
                            lightskyblue: [135, 206, 250],
                            lightslategray: [119, 136, 153],
                            lightslategrey: [119, 136, 153],
                            lightsteelblue: [176, 196, 222],
                            lightyellow: [255, 255, 224],
                            lime: [0, 255, 0],
                            limegreen: [50, 205, 50],
                            linen: [250, 240, 230],
                            magenta: [255, 0, 255],
                            maroon: [128, 0, 0],
                            mediumaquamarine: [102, 205, 170],
                            mediumblue: [0, 0, 205],
                            mediumorchid: [186, 85, 211],
                            mediumpurple: [147, 112, 219],
                            mediumseagreen: [60, 179, 113],
                            mediumslateblue: [123, 104, 238],
                            mediumspringgreen: [0, 250, 154],
                            mediumturquoise: [72, 209, 204],
                            mediumvioletred: [199, 21, 133],
                            midnightblue: [25, 25, 112],
                            mintcream: [245, 255, 250],
                            mistyrose: [255, 228, 225],
                            moccasin: [255, 228, 181],
                            navajowhite: [255, 222, 173],
                            navy: [0, 0, 128],
                            oldlace: [253, 245, 230],
                            olive: [128, 128, 0],
                            olivedrab: [107, 142, 35],
                            orange: [255, 165, 0],
                            orangered: [255, 69, 0],
                            orchid: [218, 112, 214],
                            palegoldenrod: [238, 232, 170],
                            palegreen: [152, 251, 152],
                            paleturquoise: [175, 238, 238],
                            palevioletred: [219, 112, 147],
                            papayawhip: [255, 239, 213],
                            peachpuff: [255, 218, 185],
                            peru: [205, 133, 63],
                            pink: [255, 192, 203],
                            plum: [221, 160, 221],
                            powderblue: [176, 224, 230],
                            purple: [128, 0, 128],
                            rebeccapurple: [102, 51, 153],
                            red: [255, 0, 0],
                            rosybrown: [188, 143, 143],
                            royalblue: [65, 105, 225],
                            saddlebrown: [139, 69, 19],
                            salmon: [250, 128, 114],
                            sandybrown: [244, 164, 96],
                            seagreen: [46, 139, 87],
                            seashell: [255, 245, 238],
                            sienna: [160, 82, 45],
                            silver: [192, 192, 192],
                            skyblue: [135, 206, 235],
                            slateblue: [106, 90, 205],
                            slategray: [112, 128, 144],
                            slategrey: [112, 128, 144],
                            snow: [255, 250, 250],
                            springgreen: [0, 255, 127],
                            steelblue: [70, 130, 180],
                            tan: [210, 180, 140],
                            teal: [0, 128, 128],
                            thistle: [216, 191, 216],
                            tomato: [255, 99, 71],
                            turquoise: [64, 224, 208],
                            violet: [238, 130, 238],
                            wheat: [245, 222, 179],
                            white: [255, 255, 255],
                            whitesmoke: [245, 245, 245],
                            yellow: [255, 255, 0],
                            yellowgreen: [154, 205, 50]
                        },
                        n = new RegExp("[^#a-f\\d]", "gi"),
                        t = new RegExp("^#?[a-f\\d]{3}[a-f\\d]?$|^#?[a-f\\d]{6}([a-f\\d]{2})?$", "i"),
                        r = new RegExp(/^#([a-f0-9]{3,4}|[a-f0-9]{4}(?:[a-f0-9]{2}){1,2})\b$/, "i"),
                        o = "-?\\d*(?:\\.\\d+)",
                        i = "(" + o + "?)",
                        a = "(" + o + "?%)",
                        l = ("^\n  hsla?\\(\n    \\s*(-?\\d*(?:\\.\\d+)?(?:deg|rad|turn)?)\\s*,\n    \\s*" + a + "\\s*,\n    \\s*" + a + "\\s*\n    (?:,\\s*(-?\\d*(?:\\.\\d+)?%?)\\s*)?\n  \\)\n  $\n").replace(/\n|\s/g, ""),
                        s = new RegExp(l),
                        c = ("^\n  hsla?\\(\n    \\s*(-?\\d*(?:\\.\\d+)?(?:deg|rad|turn)?)\\s*\n    \\s+" + a + "\n    \\s+" + a + "\n    \\s*(?:\\s*\\/\\s*(-?\\d*(?:\\.\\d+)?%?)\\s*)?\n  \\)\n  $\n").replace(/\n|\s/g, ""),
                        u = new RegExp(c),
                        d = ("^\n  rgba?\\(\n    \\s*" + i + "\\s*,\n    \\s*" + i + "\\s*,\n    \\s*" + i + "\\s*\n    (?:,\\s*(-?\\d*(?:\\.\\d+)?%?)\\s*)?\n  \\)\n  $\n").replace(/\n|\s/g, ""),
                        p = new RegExp(d),
                        f = ("^\n  rgba?\\(\n    \\s*" + a + "\\s*,\n    \\s*" + a + "\\s*,\n    \\s*" + a + "\\s*\n    (?:,\\s*(-?\\d*(?:\\.\\d+)?%?)\\s*)?\n  \\)\n  $\n").replace(/\n|\s/g, ""),
                        h = new RegExp(f),
                        m = ("^\n  rgba?\\(\n    \\s*" + i + "\n    \\s+" + i + "\n    \\s+" + i + "\n    \\s*(?:\\s*\\/\\s*(-?\\d*(?:\\.\\d+)?%?)\\s*)?\n  \\)\n$\n").replace(/\n|\s/g, ""),
                        _ = new RegExp(m),
                        v = ("^\n  rgba?\\(\n    \\s*" + a + "\n    \\s+" + a + "\n    \\s+" + a + "\n    \\s*(?:\\s*\\/\\s*(-?\\d*(?:\\.\\d+)?%?)\\s*)?\n  \\)\n$\n").replace(/\n|\s/g, ""),
                        y = new RegExp(v),
                        b = new RegExp(/^transparent$/, "i"),
                        g = function(e, n, t) {
                            return Math.min(Math.max(n, e), t)
                        },
                        w = function(e) {
                            var n = e;
                            return "number" != typeof n && (n = n.endsWith("%") ? 255 * parseFloat(n) / 100 : parseFloat(n)), g(Math.round(n), 0, 255)
                        },
                        x = function(e) {
                            return g(parseFloat(e), 0, 100)
                        };

                    function k(e) {
                        var n = e;
                        return "number" != typeof n && (n = n.endsWith("%") ? parseFloat(n) / 100 : parseFloat(n)), g(n, 0, 1)
                    }

                    function j(e) {
                        var r = function(e, r) {
                            if (void 0 === r && (r = {}), "string" != typeof e || n.test(e) || !t.test(e)) throw new TypeError("Expected a valid hex string");
                            var o = 1;
                            8 === (e = e.replace(/^#/, "")).length && (o = Number.parseInt(e.slice(6, 8), 16) / 255, e = e.slice(0, 6)), 4 === e.length && (o = Number.parseInt(e.slice(3, 4).repeat(2), 16) / 255, e = e.slice(0, 3)), 3 === e.length && (e = e[0] + e[0] + e[1] + e[1] + e[2] + e[2]);
                            var i = Number.parseInt(e, 16),
                                a = i >> 16,
                                l = i >> 8 & 255,
                                s = 255 & i,
                                c = "number" == typeof r.alpha ? r.alpha : o;
                            return "array" === r.format ? [a, l, s, c] : "css" === r.format ? "rgb(" + a + " " + l + " " + s + (1 === c ? "" : " / " + Number((100 * c).toFixed(2)) + "%") + ")" : {
                                red: a,
                                green: l,
                                blue: s,
                                alpha: c
                            }
                        }(e, {
                            format: "array"
                        });
                        return S([null, r[0], r[1], r[2], r[3]])
                    }

                    function S(e) {
                        var n = e[1],
                            t = e[2],
                            r = e[3],
                            o = e[4];
                        return void 0 === o && (o = 1), {
                            type: "rgb",
                            values: [n, t, r].map(w),
                            alpha: k(null === o ? 1 : o)
                        }
                    }
                    var C = function(n) {
                            if ("string" != typeof n) return null;
                            var t = r.exec(n);
                            if (t) return j(t[0]);
                            var o = u.exec(n) || s.exec(n);
                            if (o) return function(e) {
                                var n = e[1],
                                    t = e[2],
                                    r = e[3],
                                    o = e[4];
                                void 0 === o && (o = 1);
                                var i = n;
                                return {
                                    type: "hsl",
                                    values: [i = i.endsWith("turn") ? 360 * parseFloat(i) / 1 : i.endsWith("rad") ? Math.round(180 * parseFloat(i) / Math.PI) : parseFloat(i), x(t), x(r)],
                                    alpha: k(null === o ? 1 : o)
                                }
                            }(o);
                            var i = _.exec(n) || y.exec(n) || p.exec(n) || h.exec(n);
                            if (i) return S(i);
                            if (b.exec(n)) return S([null, 0, 0, 0, 0]);
                            var a = e[n.toLowerCase()];
                            return a ? S([null, a[0], a[1], a[2], 1]) : null
                        },
                        M = function(e) {
                            var n, t, r, o, i, a = e[0] / 360,
                                l = e[1] / 100,
                                s = e[2] / 100;
                            if (0 == l) return [i = 255 * s, i, i];
                            n = 2 * s - (t = s < .5 ? s * (1 + l) : s + l - s * l), o = [0, 0, 0];
                            for (var c = 0; c < 3; c++)(r = a + 1 / 3 * -(c - 1)) < 0 && r++, r > 1 && r--, i = 6 * r < 1 ? n + 6 * (t - n) * r : 2 * r < 1 ? t : 3 * r < 2 ? n + (t - n) * (2 / 3 - r) * 6 : n, o[c] = 255 * i;
                            return o
                        };

                    function P(e) {
                        var n = Math.round(function(e, n, t) {
                            return Math.min(Math.max(e, n), t)
                        }(e, 0, 255)).toString(16);
                        return 1 == n.length ? "0" + n : n
                    }
                    var O = function(e) {
                            var n = 4 === e.length ? P(255 * e[3]) : "";
                            return "#" + P(e[0]) + P(e[1]) + P(e[2]) + n
                        },
                        A = function(e) {
                            var n, t, r = e[0] / 255,
                                o = e[1] / 255,
                                i = e[2] / 255,
                                a = Math.min(r, o, i),
                                l = Math.max(r, o, i),
                                s = l - a;
                            return l == a ? n = 0 : r == l ? n = (o - i) / s : o == l ? n = 2 + (i - r) / s : i == l && (n = 4 + (r - o) / s), (n = Math.min(60 * n, 360)) < 0 && (n += 360), t = (a + l) / 2, [n, 100 * (l == a ? 0 : t <= .5 ? s / (l + a) : s / (2 - l - a)), 100 * t]
                        };

                    function I(e) {
                        var n = C(e);
                        return null === n ? null : ("hsl" === n.type && (n.values = M(n.values)), n)
                    }

                    function z(e, n, t) {
                        void 0 === t && (t = 50);
                        var r = I(e),
                            o = I(n);
                        if (!r || !o) return null;
                        var i = Math.min(Math.max(0, t), 100) / 100,
                            a = 2 * i - 1,
                            l = r.alpha - o.alpha,
                            s = ((a * l == -1 ? a : (a + l) / (1 + a * l)) + 1) / 2,
                            c = 1 - s,
                            u = r.values.map((function(e, n) {
                                return Math.round(r.values[n] * s + o.values[n] * c)
                            })),
                            d = u[0],
                            p = u[1],
                            f = u[2],
                            h = parseFloat((r.alpha * i + o.alpha * (1 - i)).toFixed(8));
                        return {
                            hex: O([d, p, f]),
                            hexa: O([d, p, f, h]),
                            rgba: [d, p, f, h],
                            hsla: A([d, p, f]).map(Math.round).concat([h])
                        }
                    }
                    var E = function(e, n) {
                            return null === e || isNaN(e) || "string" == typeof e ? n : e
                        },
                        T = function(e, n, t) {
                            var r;
                            void 0 === e && (e = "#000"), void 0 === n && (n = "base"), void 0 === t && (t = 0), r = [
                                [0, 0, 0], 1, n, t
                            ], this.rgb = r[0], this.alpha = r[1], this.type = r[2], this.weight = r[3];
                            var o = null === e ? "#000" : e;
                            if ("string" != typeof o) throw new TypeError("Input should be a string: " + o);
                            var i = C(o);
                            if (!i) throw new Error("Unable to parse color from string: " + o);
                            return this["_setFrom" + i.type.toUpperCase()](i.values.concat([i.alpha]))
                        },
                        N = {
                            hex: {
                                configurable: !0
                            }
                        };
                    return N.hex.get = function() {
                        return this.hexString().replace(/^#/, "")
                    }, T.prototype.setColor = function(e) {
                        var n = C(e);
                        return n ? this["_setFrom" + n.type.toUpperCase()](n.values.concat([n.alpha])) : null
                    }, T.prototype.tint = function(e, n) {
                        return void 0 === n && (n = E(e, 50)), new T("rgb(" + z("#fff", this.rgbString(), n).rgba + ")", "tint", n)
                    }, T.prototype.shade = function(e, n) {
                        return void 0 === n && (n = E(e, 50)), new T("rgb(" + z("#000", this.rgbString(), n).rgba + ")", "shade", n)
                    }, T.prototype.tints = function(e, n) {
                        var t = this;
                        return void 0 === n && (n = E(e, 10)), Array.from({
                            length: 100 / n
                        }, (function(e, r) {
                            return t.tint((r + 1) * n)
                        }))
                    }, T.prototype.shades = function(e, n) {
                        var t = this;
                        return void 0 === n && (n = E(e, 10)), Array.from({
                            length: 100 / n
                        }, (function(e, r) {
                            return t.shade((r + 1) * n)
                        }))
                    }, T.prototype.all = function(e) {
                        return void 0 === e && (e = 10), this.tints(e).reverse().concat([Object.assign(this)], this.shades(e))
                    }, T.prototype.hexString = function() {
                        return O(this.alpha >= 1 ? this.rgb : this.rgb.concat([this.alpha]))
                    }, T.prototype.rgbString = function() {
                        var e = (this.alpha >= 1 ? this.rgb : this.rgb.concat([this.alpha])).join(", ");
                        return (this.alpha >= 1 ? "rgb" : "rgba") + "(" + e + ")"
                    }, T.prototype.getBrightness = function() {
                        return Math.round(this.rgb.reduce((function(e, n) {
                            return e + n
                        })) / 765 * 100)
                    }, T.prototype._setFromRGB = function(e) {
                        var n;
                        return n = [
                            [e[0], e[1], e[2]], e[3]
                        ], this.rgb = n[0], this.alpha = n[1], this
                    }, T.prototype._setFromHSL = function(e) {
                        var n, t = e[0],
                            r = e[1],
                            o = e[2],
                            i = e[3];
                        return n = [M([t, r, o]).map(Math.round), i], this.rgb = n[0], this.alpha = n[1], this
                    }, Object.defineProperties(T.prototype, N), T.VERSION = "v2.1.1", T
                }()
            }
        },
        n = {};

    function t(r) {
        var o = n[r];
        if (void 0 !== o) return o.exports;
        var i = n[r] = {
            id: r,
            exports: {}
        };
        return e[r].call(i.exports, i, i.exports, t), i.exports
    }
    t.n = function(e) {
            var n = e && e.__esModule ? function() {
                return e.default
            } : function() {
                return e
            };
            return t.d(n, {
                a: n
            }), n
        }, t.d = function(e, n) {
            for (var r in n) t.o(n, r) && !t.o(e, r) && Object.defineProperty(e, r, {
                enumerable: !0,
                get: n[r]
            })
        }, t.g = function() {
            if ("object" == typeof globalThis) return globalThis;
            try {
                return this || new Function("return this")()
            } catch (e) {
                if ("object" == typeof window) return window
            }
        }(), t.o = function(e, n) {
            return Object.prototype.hasOwnProperty.call(e, n)
        }, t.r = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            })
        },
        function() {
            var e;
            t.g.importScripts && (e = t.g.location + "");
            var n = t.g.document;
            if (!e && n && (n.currentScript && (e = n.currentScript.src), !e)) {
                var r = n.getElementsByTagName("script");
                if (r.length)
                    for (var o = r.length - 1; o > -1 && !e;) e = r[o--].src
            }
            if (!e) throw new Error("Automatic publicPath is not supported in this browser");
            e = e.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/"), t.p = e
        }(), t.nc = void 0,
        function() {
            "use strict";
            var e, n, r, o, i, a, l = {},
                s = [],
                c = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;

            function u(e, n) {
                for (var t in n) e[t] = n[t];
                return e
            }

            function d(e) {
                var n = e.parentNode;
                n && n.removeChild(e)
            }

            function p(e, n, t) {
                var r, o, i, a = arguments,
                    l = {};
                for (i in n) "key" == i ? r = n[i] : "ref" == i ? o = n[i] : l[i] = n[i];
                if (arguments.length > 3)
                    for (t = [t], i = 3; i < arguments.length; i++) t.push(a[i]);
                if (null != t && (l.children = t), "function" == typeof e && null != e.defaultProps)
                    for (i in e.defaultProps) void 0 === l[i] && (l[i] = e.defaultProps[i]);
                return f(e, l, r, o, null)
            }

            function f(n, t, r, o, i) {
                var a = {
                    type: n,
                    props: t,
                    key: r,
                    ref: o,
                    __k: null,
                    __: null,
                    __b: 0,
                    __e: null,
                    __d: void 0,
                    __c: null,
                    __h: null,
                    constructor: void 0,
                    __v: null == i ? ++e.__v : i
                };
                return null != e.vnode && e.vnode(a), a
            }

            function h(e) {
                return e.children
            }

            function m(e, n) {
                this.props = e, this.context = n
            }

            function _(e, n) {
                if (null == n) return e.__ ? _(e.__, e.__.__k.indexOf(e) + 1) : null;
                for (var t; n < e.__k.length; n++)
                    if (null != (t = e.__k[n]) && null != t.__e) return t.__e;
                return "function" == typeof e.type ? _(e) : null
            }

            function v(e) {
                var n, t;
                if (null != (e = e.__) && null != e.__c) {
                    for (e.__e = e.__c.base = null, n = 0; n < e.__k.length; n++)
                        if (null != (t = e.__k[n]) && null != t.__e) {
                            e.__e = e.__c.base = t.__e;
                            break
                        }
                    return v(e)
                }
            }

            function y(t) {
                (!t.__d && (t.__d = !0) && n.push(t) && !b.__r++ || o !== e.debounceRendering) && ((o = e.debounceRendering) || r)(b)
            }

            function b() {
                for (var e; b.__r = n.length;) e = n.sort((function(e, n) {
                    return e.__v.__b - n.__v.__b
                })), n = [], e.some((function(e) {
                    var n, t, r, o, i, a, l;
                    e.__d && (a = (i = (n = e).__v).__e, (l = n.__P) && (t = [], (r = u({}, i)).__v = i.__v + 1, o = P(l, i, r, n.__n, void 0 !== l.ownerSVGElement, null != i.__h ? [a] : null, t, null == a ? _(i) : a, i.__h), O(t, i), o != a && v(i)))
                }))
            }

            function g(e, n, t, r, o, i, a, c, u, p) {
                var m, v, y, b, g, w, k, j = r && r.__k || s,
                    S = j.length;
                for (u == l && (u = null != a ? a[0] : S ? _(r, 0) : null), t.__k = [], m = 0; m < n.length; m++)
                    if (null != (b = t.__k[m] = null == (b = n[m]) || "boolean" == typeof b ? null : "string" == typeof b || "number" == typeof b ? f(null, b, null, null, b) : Array.isArray(b) ? f(h, {
                            children: b
                        }, null, null, null) : null != b.__e || null != b.__c ? f(b.type, b.props, b.key, null, b.__v) : b)) {
                        if (b.__ = t, b.__b = t.__b + 1, null === (y = j[m]) || y && b.key == y.key && b.type === y.type) j[m] = void 0;
                        else
                            for (v = 0; v < S; v++) {
                                if ((y = j[v]) && b.key == y.key && b.type === y.type) {
                                    j[v] = void 0;
                                    break
                                }
                                y = null
                            }
                        g = P(e, b, y = y || l, o, i, a, c, u, p), (v = b.ref) && y.ref != v && (k || (k = []), y.ref && k.push(y.ref, null, b), k.push(v, b.__c || g, b)), null != g ? (null == w && (w = g), u = x(e, b, y, j, a, g, u), p || "option" != t.type ? "function" == typeof t.type && (t.__d = u) : e.value = "") : u && y.__e == u && u.parentNode != e && (u = _(y))
                    }
                if (t.__e = w, null != a && "function" != typeof t.type)
                    for (m = a.length; m--;) null != a[m] && d(a[m]);
                for (m = S; m--;) null != j[m] && z(j[m], j[m]);
                if (k)
                    for (m = 0; m < k.length; m++) I(k[m], k[++m], k[++m])
            }

            function w(e, n) {
                return n = n || [], null == e || "boolean" == typeof e || (Array.isArray(e) ? e.some((function(e) {
                    w(e, n)
                })) : n.push(e)), n
            }

            function x(e, n, t, r, o, i, a) {
                var l, s, c;
                if (void 0 !== n.__d) l = n.__d, n.__d = void 0;
                else if (o == t || i != a || null == i.parentNode) e: if (null == a || a.parentNode !== e) e.appendChild(i), l = null;
                    else {
                        for (s = a, c = 0;
                            (s = s.nextSibling) && c < r.length; c += 2)
                            if (s == i) break e;
                        e.insertBefore(i, a), l = a
                    }
                return void 0 !== l ? l : i.nextSibling
            }

            function k(e, n, t) {
                "-" === n[0] ? e.setProperty(n, t) : e[n] = null == t ? "" : "number" != typeof t || c.test(n) ? t : t + "px"
            }

            function j(e, n, t, r, o) {
                var i, a, l;
                if (o && "className" == n && (n = "class"), "style" === n)
                    if ("string" == typeof t) e.style.cssText = t;
                    else {
                        if ("string" == typeof r && (e.style.cssText = r = ""), r)
                            for (n in r) t && n in t || k(e.style, n, "");
                        if (t)
                            for (n in t) r && t[n] === r[n] || k(e.style, n, t[n])
                    }
                else "o" === n[0] && "n" === n[1] ? (i = n !== (n = n.replace(/Capture$/, "")), (a = n.toLowerCase()) in e && (n = a), n = n.slice(2), e.l || (e.l = {}), e.l[n + i] = t, l = i ? C : S, t ? r || e.addEventListener(n, l, i) : e.removeEventListener(n, l, i)) : "list" !== n && "tagName" !== n && "form" !== n && "type" !== n && "size" !== n && "download" !== n && "href" !== n && !o && n in e ? e[n] = null == t ? "" : t : "function" != typeof t && "dangerouslySetInnerHTML" !== n && (n !== (n = n.replace(/xlink:?/, "")) ? null == t || !1 === t ? e.removeAttributeNS("http://www.w3.org/1999/xlink", n.toLowerCase()) : e.setAttributeNS("http://www.w3.org/1999/xlink", n.toLowerCase(), t) : null == t || !1 === t && !/^ar/.test(n) ? e.removeAttribute(n) : e.setAttribute(n, t))
            }

            function S(n) {
                this.l[n.type + !1](e.event ? e.event(n) : n)
            }

            function C(n) {
                this.l[n.type + !0](e.event ? e.event(n) : n)
            }

            function M(e, n, t) {
                var r, o;
                for (r = 0; r < e.__k.length; r++)(o = e.__k[r]) && (o.__ = e, o.__e && ("function" == typeof o.type && o.__k.length > 1 && M(o, n, t), n = x(t, o, o, e.__k, null, o.__e, n), "function" == typeof e.type && (e.__d = n)))
            }

            function P(n, t, r, o, i, a, l, s, c) {
                var d, p, f, _, v, y, b, w, x, k, j, S = t.type;
                if (void 0 !== t.constructor) return null;
                null != r.__h && (c = r.__h, s = t.__e = r.__e, t.__h = null, a = [s]), (d = e.__b) && d(t);
                try {
                    e: if ("function" == typeof S) {
                        if (w = t.props, x = (d = S.contextType) && o[d.__c], k = d ? x ? x.props.value : d.__ : o, r.__c ? b = (p = t.__c = r.__c).__ = p.__E : ("prototype" in S && S.prototype.render ? t.__c = p = new S(w, k) : (t.__c = p = new m(w, k), p.constructor = S, p.render = E), x && x.sub(p), p.props = w, p.state || (p.state = {}), p.context = k, p.__n = o, f = p.__d = !0, p.__h = []), null == p.__s && (p.__s = p.state), null != S.getDerivedStateFromProps && (p.__s == p.state && (p.__s = u({}, p.__s)), u(p.__s, S.getDerivedStateFromProps(w, p.__s))), _ = p.props, v = p.state, f) null == S.getDerivedStateFromProps && null != p.componentWillMount && p.componentWillMount(), null != p.componentDidMount && p.__h.push(p.componentDidMount);
                        else {
                            if (null == S.getDerivedStateFromProps && w !== _ && null != p.componentWillReceiveProps && p.componentWillReceiveProps(w, k), !p.__e && null != p.shouldComponentUpdate && !1 === p.shouldComponentUpdate(w, p.__s, k) || t.__v === r.__v) {
                                p.props = w, p.state = p.__s, t.__v !== r.__v && (p.__d = !1), p.__v = t, t.__e = r.__e, t.__k = r.__k, p.__h.length && l.push(p), M(t, s, n);
                                break e
                            }
                            null != p.componentWillUpdate && p.componentWillUpdate(w, p.__s, k), null != p.componentDidUpdate && p.__h.push((function() {
                                p.componentDidUpdate(_, v, y)
                            }))
                        }
                        p.context = k, p.props = w, p.state = p.__s, (d = e.__r) && d(t), p.__d = !1, p.__v = t, p.__P = n, d = p.render(p.props, p.state, p.context), p.state = p.__s, null != p.getChildContext && (o = u(u({}, o), p.getChildContext())), f || null == p.getSnapshotBeforeUpdate || (y = p.getSnapshotBeforeUpdate(_, v)), j = null != d && d.type == h && null == d.key ? d.props.children : d, g(n, Array.isArray(j) ? j : [j], t, r, o, i, a, l, s, c), p.base = t.__e, t.__h = null, p.__h.length && l.push(p), b && (p.__E = p.__ = null), p.__e = !1
                    } else null == a && t.__v === r.__v ? (t.__k = r.__k, t.__e = r.__e) : t.__e = A(r.__e, t, r, o, i, a, l, c);
                    (d = e.diffed) && d(t)
                }
                catch (n) {
                    t.__v = null, (c || null != a) && (t.__e = s, t.__h = !!c, a[a.indexOf(s)] = null), e.__e(n, t, r)
                }
                return t.__e
            }

            function O(n, t) {
                e.__c && e.__c(t, n), n.some((function(t) {
                    try {
                        n = t.__h, t.__h = [], n.some((function(e) {
                            e.call(t)
                        }))
                    } catch (n) {
                        e.__e(n, t.__v)
                    }
                }))
            }

            function A(e, n, t, r, o, i, a, c) {
                var u, d, p, f, h, m = t.props,
                    _ = n.props;
                if (o = "svg" === n.type || o, null != i)
                    for (u = 0; u < i.length; u++)
                        if (null != (d = i[u]) && ((null === n.type ? 3 === d.nodeType : d.localName === n.type) || e == d)) {
                            e = d, i[u] = null;
                            break
                        }
                if (null == e) {
                    if (null === n.type) return document.createTextNode(_);
                    e = o ? document.createElementNS("http://www.w3.org/2000/svg", n.type) : document.createElement(n.type, _.is && {
                        is: _.is
                    }), i = null, c = !1
                }
                if (null === n.type) m === _ || c && e.data === _ || (e.data = _);
                else {
                    if (null != i && (i = s.slice.call(e.childNodes)), p = (m = t.props || l).dangerouslySetInnerHTML, f = _.dangerouslySetInnerHTML, !c) {
                        if (null != i)
                            for (m = {}, h = 0; h < e.attributes.length; h++) m[e.attributes[h].name] = e.attributes[h].value;
                        (f || p) && (f && (p && f.__html == p.__html || f.__html === e.innerHTML) || (e.innerHTML = f && f.__html || ""))
                    }(function(e, n, t, r, o) {
                        var i;
                        for (i in t) "children" === i || "key" === i || i in n || j(e, i, null, t[i], r);
                        for (i in n) o && "function" != typeof n[i] || "children" === i || "key" === i || "value" === i || "checked" === i || t[i] === n[i] || j(e, i, n[i], t[i], r)
                    })(e, _, m, o, c), f ? n.__k = [] : (u = n.props.children, g(e, Array.isArray(u) ? u : [u], n, t, r, "foreignObject" !== n.type && o, i, a, l, c)), c || ("value" in _ && void 0 !== (u = _.value) && (u !== e.value || "progress" === n.type && !u) && j(e, "value", u, m.value, !1), "checked" in _ && void 0 !== (u = _.checked) && u !== e.checked && j(e, "checked", u, m.checked, !1))
                }
                return e
            }

            function I(n, t, r) {
                try {
                    "function" == typeof n ? n(t) : n.current = t
                } catch (n) {
                    e.__e(n, r)
                }
            }

            function z(n, t, r) {
                var o, i, a;
                if (e.unmount && e.unmount(n), (o = n.ref) && (o.current && o.current !== n.__e || I(o, null, t)), r || "function" == typeof n.type || (r = null != (i = n.__e)), n.__e = n.__d = void 0, null != (o = n.__c)) {
                    if (o.componentWillUnmount) try {
                        o.componentWillUnmount()
                    } catch (n) {
                        e.__e(n, t)
                    }
                    o.base = o.__P = null
                }
                if (o = n.__k)
                    for (a = 0; a < o.length; a++) o[a] && z(o[a], t, r);
                null != i && d(i)
            }

            function E(e, n, t) {
                return this.constructor(e, t)
            }

            function T(e, n) {
                var t = {
                    __c: n = "__cC" + a++,
                    __: e,
                    Consumer: function(e, n) {
                        return e.children(n)
                    },
                    Provider: function(e, t, r) {
                        return this.getChildContext || (t = [], (r = {})[n] = this, this.getChildContext = function() {
                            return r
                        }, this.shouldComponentUpdate = function(e) {
                            this.props.value !== e.value && t.some(y)
                        }, this.sub = function(e) {
                            t.push(e);
                            var n = e.componentWillUnmount;
                            e.componentWillUnmount = function() {
                                t.splice(t.indexOf(e), 1), n && n.call(e)
                            }
                        }), e.children
                    }
                };
                return t.Provider.__ = t.Consumer.contextType = t
            }
            e = {
                __e: function(e, n) {
                    for (var t, r, o, i = n.__h; n = n.__;)
                        if ((t = n.__c) && !t.__) try {
                            if ((r = t.constructor) && null != r.getDerivedStateFromError && (t.setState(r.getDerivedStateFromError(e)), o = t.__d), null != t.componentDidCatch && (t.componentDidCatch(e), o = t.__d), o) return n.__h = i, t.__E = t
                        } catch (n) {
                            e = n
                        }
                    throw e
                },
                __v: 0
            }, m.prototype.setState = function(e, n) {
                var t;
                t = null != this.__s && this.__s !== this.state ? this.__s : this.__s = u({}, this.state), "function" == typeof e && (e = e(u({}, t), this.props)), e && u(t, e), null != e && this.__v && (n && this.__h.push(n), y(this))
            }, m.prototype.forceUpdate = function(e) {
                this.__v && (this.__e = !0, e && this.__h.push(e), y(this))
            }, m.prototype.render = h, n = [], r = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, b.__r = 0, i = l, a = 0, t(62);
            var N, L, F, D = 0,
                U = [],
                B = e.__b,
                R = e.__r,
                H = e.diffed,
                q = e.__c,
                $ = e.unmount;

            function Z(n, t) {
                e.__h && e.__h(L, n, D || t), D = 0;
                var r = L.__H || (L.__H = {
                    __: [],
                    __h: []
                });
                return n >= r.__.length && r.__.push({}), r.__[n]
            }

            function W(e) {
                return D = 1,
                    function(e, n, t) {
                        var r = Z(N++, 2);
                        return r.t = e, r.__c || (r.__ = [t ? t(n) : oe(void 0, n), function(e) {
                            var n = r.t(r.__[0], e);
                            r.__[0] !== n && (r.__ = [n, r.__[1]], r.__c.setState({}))
                        }], r.__c = L), r.__
                    }(oe, e)
            }

            function G(n, t) {
                var r = Z(N++, 3);
                !e.__s && re(r.__H, t) && (r.__ = n, r.__H = t, L.__H.__h.push(r))
            }

            function V(n, t) {
                var r = Z(N++, 4);
                !e.__s && re(r.__H, t) && (r.__ = n, r.__H = t, L.__h.push(r))
            }

            function X(e) {
                return D = 5, J((function() {
                    return {
                        current: e
                    }
                }), [])
            }

            function J(e, n) {
                var t = Z(N++, 7);
                return re(t.__H, n) && (t.__ = e(), t.__H = n, t.__h = e), t.__
            }

            function K(e, n) {
                return D = 8, J((function() {
                    return e
                }), n)
            }

            function Y(e) {
                var n = L.context[e.__c],
                    t = Z(N++, 9);
                return t.__c = e, n ? (null == t.__ && (t.__ = !0, n.sub(L)), n.props.value) : e.__
            }

            function Q() {
                U.forEach((function(n) {
                    if (n.__P) try {
                        n.__H.__h.forEach(ne), n.__H.__h.forEach(te), n.__H.__h = []
                    } catch (t) {
                        n.__H.__h = [], e.__e(t, n.__v)
                    }
                })), U = []
            }
            e.__b = function(e) {
                L = null, B && B(e)
            }, e.__r = function(e) {
                R && R(e), N = 0;
                var n = (L = e.__c).__H;
                n && (n.__h.forEach(ne), n.__h.forEach(te), n.__h = [])
            }, e.diffed = function(n) {
                H && H(n);
                var t = n.__c;
                t && t.__H && t.__H.__h.length && (1 !== U.push(t) && F === e.requestAnimationFrame || ((F = e.requestAnimationFrame) || function(e) {
                    var n, t = function() {
                            clearTimeout(r), ee && cancelAnimationFrame(n), setTimeout(e)
                        },
                        r = setTimeout(t, 100);
                    ee && (n = requestAnimationFrame(t))
                })(Q)), L = void 0
            }, e.__c = function(n, t) {
                t.some((function(n) {
                    try {
                        n.__h.forEach(ne), n.__h = n.__h.filter((function(e) {
                            return !e.__ || te(e)
                        }))
                    } catch (r) {
                        t.some((function(e) {
                            e.__h && (e.__h = [])
                        })), t = [], e.__e(r, n.__v)
                    }
                })), q && q(n, t)
            }, e.unmount = function(n) {
                $ && $(n);
                var t = n.__c;
                if (t && t.__H) try {
                    t.__H.__.forEach(ne)
                } catch (n) {
                    e.__e(n, t.__v)
                }
            };
            var ee = "function" == typeof requestAnimationFrame;

            function ne(e) {
                var n = L;
                "function" == typeof e.__c && e.__c(), L = n
            }

            function te(e) {
                var n = L;
                e.__c = e.__(), L = n
            }

            function re(e, n) {
                return !e || e.length !== n.length || n.some((function(n, t) {
                    return n !== e[t]
                }))
            }

            function oe(e, n) {
                return "function" == typeof n ? n(e) : n
            }

            function ie(e, n) {
                for (var t in n) e[t] = n[t];
                return e
            }

            function ae(e, n) {
                for (var t in e)
                    if ("__source" !== t && !(t in n)) return !0;
                for (var r in n)
                    if ("__source" !== r && e[r] !== n[r]) return !0;
                return !1
            }

            function le(e) {
                this.props = e
            }(le.prototype = new m).isPureReactComponent = !0, le.prototype.shouldComponentUpdate = function(e, n) {
                return ae(this.props, e) || ae(this.state, n)
            };
            var se = e.__b;
            e.__b = function(e) {
                e.type && e.type.__f && e.ref && (e.props.ref = e.ref, e.ref = null), se && se(e)
            };
            var ce = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;

            function ue(e) {
                function n(n, t) {
                    var r = ie({}, n);
                    return delete r.ref, e(r, (t = n.ref || t) && ("object" != typeof t || "current" in t) ? t : null)
                }
                return n.$$typeof = ce, n.render = n, n.prototype.isReactComponent = n.__f = !0, n.displayName = "ForwardRef(" + (e.displayName || e.name) + ")", n
            }
            var de = e.__e;

            function pe(e) {
                return e && (e.__c && e.__c.__H && (e.__c.__H.__.forEach((function(e) {
                    "function" == typeof e.__c && e.__c()
                })), e.__c.__H = null), (e = ie({}, e)).__c = null, e.__k = e.__k && e.__k.map(pe)), e
            }

            function fe(e) {
                return e && (e.__v = null, e.__k = e.__k && e.__k.map(fe)), e
            }

            function he() {
                this.__u = 0, this.t = null, this.__b = null
            }

            function me(e) {
                var n = e.__.__c;
                return n && n.__e && n.__e(e)
            }

            function _e() {
                this.u = null, this.o = null
            }
            e.__e = function(e, n, t) {
                if (e.then)
                    for (var r, o = n; o = o.__;)
                        if ((r = o.__c) && r.__c) return null == n.__e && (n.__e = t.__e, n.__k = t.__k), r.__c(e, n);
                de(e, n, t)
            }, (he.prototype = new m).__c = function(e, n) {
                var t = n.__c,
                    r = this;
                null == r.t && (r.t = []), r.t.push(t);
                var o = me(r.__v),
                    i = !1,
                    a = function() {
                        i || (i = !0, t.componentWillUnmount = t.__c, o ? o(l) : l())
                    };
                t.__c = t.componentWillUnmount, t.componentWillUnmount = function() {
                    a(), t.__c && t.__c()
                };
                var l = function() {
                    var e;
                    if (!--r.__u)
                        for (r.__v.__k[0] = fe(r.state.__e), r.setState({
                                __e: r.__b = null
                            }); e = r.t.pop();) e.forceUpdate()
                };
                !0 === n.__h || r.__u++ || r.setState({
                    __e: r.__b = r.__v.__k[0]
                }), e.then(a, a)
            }, he.prototype.componentWillUnmount = function() {
                this.t = []
            }, he.prototype.render = function(e, n) {
                this.__b && (this.__v.__k && (this.__v.__k[0] = pe(this.__b)), this.__b = null);
                var t = n.__e && p(h, null, e.fallback);
                return t && (t.__h = null), [p(h, null, n.__e ? null : e.children), t]
            };
            var ve = function(e, n, t) {
                if (++t[1] === t[0] && e.o.delete(n), e.props.revealOrder && ("t" !== e.props.revealOrder[0] || !e.o.size))
                    for (t = e.u; t;) {
                        for (; t.length > 3;) t.pop()();
                        if (t[1] < t[0]) break;
                        e.u = t = t[2]
                    }
            };
            (_e.prototype = new m).__e = function(e) {
                var n = this,
                    t = me(n.__v),
                    r = n.o.get(e);
                return r[0]++,
                    function(o) {
                        var i = function() {
                            n.props.revealOrder ? (r.push(o), ve(n, e, r)) : o()
                        };
                        t ? t(i) : i()
                    }
            }, _e.prototype.render = function(e) {
                this.u = null, this.o = new Map;
                var n = w(e.children);
                e.revealOrder && "b" === e.revealOrder[0] && n.reverse();
                for (var t = n.length; t--;) this.o.set(n[t], this.u = [1, 0, this.u]);
                return e.children
            }, _e.prototype.componentDidUpdate = _e.prototype.componentDidMount = function() {
                var e = this;
                this.o.forEach((function(n, t) {
                    ve(e, t, n)
                }))
            };
            var ye = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103,
                be = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|fill|flood|font|glyph(?!R)|horiz|marker(?!H|W|U)|overline|paint|stop|strikethrough|stroke|text(?!L)|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/,
                ge = "undefined" != typeof Symbol ? /fil|che|rad/i : /fil|che|ra/i;
            m.prototype.isReactComponent = {}, ["componentWillMount", "componentWillReceiveProps", "componentWillUpdate"].forEach((function(e) {
                Object.defineProperty(m.prototype, e, {
                    configurable: !0,
                    get: function() {
                        return this["UNSAFE_" + e]
                    },
                    set: function(n) {
                        Object.defineProperty(this, e, {
                            configurable: !0,
                            writable: !0,
                            value: n
                        })
                    }
                })
            }));
            var we = e.event;

            function xe() {}

            function ke() {
                return this.cancelBubble
            }

            function je() {
                return this.defaultPrevented
            }
            e.event = function(e) {
                return we && (e = we(e)), e.persist = xe, e.isPropagationStopped = ke, e.isDefaultPrevented = je, e.nativeEvent = e
            };
            var Se = {
                    configurable: !0,
                    get: function() {
                        return this.class
                    }
                },
                Ce = e.vnode;
            e.vnode = function(e) {
                var n = e.type,
                    t = e.props,
                    r = t;
                if ("string" == typeof n) {
                    for (var o in r = {}, t) {
                        var i = t[o];
                        "defaultValue" === o && "value" in t && null == t.value ? o = "value" : "download" === o && !0 === i ? i = "" : /ondoubleclick/i.test(o) ? o = "ondblclick" : /^onchange(textarea|input)/i.test(o + n) && !ge.test(t.type) ? o = "oninput" : /^on(Ani|Tra|Tou|BeforeInp)/.test(o) ? o = o.toLowerCase() : be.test(o) ? o = o.replace(/[A-Z0-9]/, "-$&").toLowerCase() : null === i && (i = void 0), r[o] = i
                    }
                    "select" == n && r.multiple && Array.isArray(r.value) && (r.value = w(t.children).forEach((function(e) {
                        e.props.selected = -1 != r.value.indexOf(e.props.value)
                    }))), e.props = r
                }
                n && t.class != t.className && (Se.enumerable = "className" in t, null != t.className && (r.class = t.className), Object.defineProperty(r, "className", Se)), e.$$typeof = ye, Ce && Ce(e)
            };
            var Me = e.__r;

            function Pe() {
                return Pe = Object.assign ? Object.assign.bind() : function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var t = arguments[n];
                        for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r])
                    }
                    return e
                }, Pe.apply(this, arguments)
            }

            function Oe(e) {
                var n = Object.create(null);
                return function(t) {
                    return void 0 === n[t] && (n[t] = e(t)), n[t]
                }
            }
            e.__r = function(e) {
                Me && Me(e), e.__c
            };
            var Ae = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|download|draggable|encType|enterKeyHint|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/,
                Ie = Oe((function(e) {
                    return Ae.test(e) || 111 === e.charCodeAt(0) && 110 === e.charCodeAt(1) && e.charCodeAt(2) < 91
                })),
                ze = function() {
                    function e(e) {
                        var n = this;
                        this._insertTag = function(e) {
                            var t;
                            t = 0 === n.tags.length ? n.insertionPoint ? n.insertionPoint.nextSibling : n.prepend ? n.container.firstChild : n.before : n.tags[n.tags.length - 1].nextSibling, n.container.insertBefore(e, t), n.tags.push(e)
                        }, this.isSpeedy = void 0 === e.speedy || e.speedy, this.tags = [], this.ctr = 0, this.nonce = e.nonce, this.key = e.key, this.container = e.container, this.prepend = e.prepend, this.insertionPoint = e.insertionPoint, this.before = null
                    }
                    var n = e.prototype;
                    return n.hydrate = function(e) {
                        e.forEach(this._insertTag)
                    }, n.insert = function(e) {
                        this.ctr % (this.isSpeedy ? 65e3 : 1) == 0 && this._insertTag(function(e) {
                            var n = document.createElement("style");
                            return n.setAttribute("data-emotion", e.key), void 0 !== e.nonce && n.setAttribute("nonce", e.nonce), n.appendChild(document.createTextNode("")), n.setAttribute("data-s", ""), n
                        }(this));
                        var n = this.tags[this.tags.length - 1];
                        if (this.isSpeedy) {
                            var t = function(e) {
                                if (e.sheet) return e.sheet;
                                for (var n = 0; n < document.styleSheets.length; n++)
                                    if (document.styleSheets[n].ownerNode === e) return document.styleSheets[n]
                            }(n);
                            try {
                                t.insertRule(e, t.cssRules.length)
                            } catch (e) {}
                        } else n.appendChild(document.createTextNode(e));
                        this.ctr++
                    }, n.flush = function() {
                        this.tags.forEach((function(e) {
                            return e.parentNode && e.parentNode.removeChild(e)
                        })), this.tags = [], this.ctr = 0
                    }, e
                }(),
                Ee = Math.abs,
                Te = String.fromCharCode,
                Ne = Object.assign;

            function Le(e) {
                return e.trim()
            }

            function Fe(e, n, t) {
                return e.replace(n, t)
            }

            function De(e, n) {
                return e.indexOf(n)
            }

            function Ue(e, n) {
                return 0 | e.charCodeAt(n)
            }

            function Be(e, n, t) {
                return e.slice(n, t)
            }

            function Re(e) {
                return e.length
            }

            function He(e) {
                return e.length
            }

            function qe(e, n) {
                return n.push(e), e
            }
            var $e = 1,
                Ze = 1,
                We = 0,
                Ge = 0,
                Ve = 0,
                Xe = "";

            function Je(e, n, t, r, o, i, a) {
                return {
                    value: e,
                    root: n,
                    parent: t,
                    type: r,
                    props: o,
                    children: i,
                    line: $e,
                    column: Ze,
                    length: a,
                    return: ""
                }
            }

            function Ke(e, n) {
                return Ne(Je("", null, null, "", null, null, 0), e, {
                    length: -e.length
                }, n)
            }

            function Ye() {
                return Ve = Ge > 0 ? Ue(Xe, --Ge) : 0, Ze--, 10 === Ve && (Ze = 1, $e--), Ve
            }

            function Qe() {
                return Ve = Ge < We ? Ue(Xe, Ge++) : 0, Ze++, 10 === Ve && (Ze = 1, $e++), Ve
            }

            function en() {
                return Ue(Xe, Ge)
            }

            function nn() {
                return Ge
            }

            function tn(e, n) {
                return Be(Xe, e, n)
            }

            function rn(e) {
                switch (e) {
                    case 0:
                    case 9:
                    case 10:
                    case 13:
                    case 32:
                        return 5;
                    case 33:
                    case 43:
                    case 44:
                    case 47:
                    case 62:
                    case 64:
                    case 126:
                    case 59:
                    case 123:
                    case 125:
                        return 4;
                    case 58:
                        return 3;
                    case 34:
                    case 39:
                    case 40:
                    case 91:
                        return 2;
                    case 41:
                    case 93:
                        return 1
                }
                return 0
            }

            function on(e) {
                return $e = Ze = 1, We = Re(Xe = e), Ge = 0, []
            }

            function an(e) {
                return Xe = "", e
            }

            function ln(e) {
                return Le(tn(Ge - 1, un(91 === e ? e + 2 : 40 === e ? e + 1 : e)))
            }

            function sn(e) {
                for (;
                    (Ve = en()) && Ve < 33;) Qe();
                return rn(e) > 2 || rn(Ve) > 3 ? "" : " "
            }

            function cn(e, n) {
                for (; --n && Qe() && !(Ve < 48 || Ve > 102 || Ve > 57 && Ve < 65 || Ve > 70 && Ve < 97););
                return tn(e, nn() + (n < 6 && 32 == en() && 32 == Qe()))
            }

            function un(e) {
                for (; Qe();) switch (Ve) {
                    case e:
                        return Ge;
                    case 34:
                    case 39:
                        34 !== e && 39 !== e && un(Ve);
                        break;
                    case 40:
                        41 === e && un(e);
                        break;
                    case 92:
                        Qe()
                }
                return Ge
            }

            function dn(e, n) {
                for (; Qe() && e + Ve !== 57 && (e + Ve !== 84 || 47 !== en()););
                return "/*" + tn(n, Ge - 1) + "*" + Te(47 === e ? e : Qe())
            }

            function pn(e) {
                for (; !rn(en());) Qe();
                return tn(e, Ge)
            }
            var fn = "-ms-",
                hn = "-moz-",
                mn = "-webkit-",
                _n = "comm",
                vn = "rule",
                yn = "decl",
                bn = "@keyframes";

            function gn(e, n) {
                for (var t = "", r = He(e), o = 0; o < r; o++) t += n(e[o], o, e, n) || "";
                return t
            }

            function wn(e, n, t, r) {
                switch (e.type) {
                    case "@layer":
                        if (e.children.length) break;
                    case "@import":
                    case yn:
                        return e.return = e.return || e.value;
                    case _n:
                        return "";
                    case bn:
                        return e.return = e.value + "{" + gn(e.children, r) + "}";
                    case vn:
                        e.value = e.props.join(",")
                }
                return Re(t = gn(e.children, r)) ? e.return = e.value + "{" + t + "}" : ""
            }

            function xn(e) {
                return an(kn("", null, null, null, [""], e = on(e), 0, [0], e))
            }

            function kn(e, n, t, r, o, i, a, l, s) {
                for (var c = 0, u = 0, d = a, p = 0, f = 0, h = 0, m = 1, _ = 1, v = 1, y = 0, b = "", g = o, w = i, x = r, k = b; _;) switch (h = y, y = Qe()) {
                    case 40:
                        if (108 != h && 58 == Ue(k, d - 1)) {
                            -1 != De(k += Fe(ln(y), "&", "&\f"), "&\f") && (v = -1);
                            break
                        }
                    case 34:
                    case 39:
                    case 91:
                        k += ln(y);
                        break;
                    case 9:
                    case 10:
                    case 13:
                    case 32:
                        k += sn(h);
                        break;
                    case 92:
                        k += cn(nn() - 1, 7);
                        continue;
                    case 47:
                        switch (en()) {
                            case 42:
                            case 47:
                                qe(Sn(dn(Qe(), nn()), n, t), s);
                                break;
                            default:
                                k += "/"
                        }
                        break;
                    case 123 * m:
                        l[c++] = Re(k) * v;
                    case 125 * m:
                    case 59:
                    case 0:
                        switch (y) {
                            case 0:
                            case 125:
                                _ = 0;
                            case 59 + u:
                                -1 == v && (k = Fe(k, /\f/g, "")), f > 0 && Re(k) - d && qe(f > 32 ? Cn(k + ";", r, t, d - 1) : Cn(Fe(k, " ", "") + ";", r, t, d - 2), s);
                                break;
                            case 59:
                                k += ";";
                            default:
                                if (qe(x = jn(k, n, t, c, u, o, l, b, g = [], w = [], d), i), 123 === y)
                                    if (0 === u) kn(k, n, x, x, g, i, d, l, w);
                                    else switch (99 === p && 110 === Ue(k, 3) ? 100 : p) {
                                        case 100:
                                        case 108:
                                        case 109:
                                        case 115:
                                            kn(e, x, x, r && qe(jn(e, x, x, 0, 0, o, l, b, o, g = [], d), w), o, w, d, l, r ? g : w);
                                            break;
                                        default:
                                            kn(k, x, x, x, [""], w, 0, l, w)
                                    }
                        }
                        c = u = f = 0, m = v = 1, b = k = "", d = a;
                        break;
                    case 58:
                        d = 1 + Re(k), f = h;
                    default:
                        if (m < 1)
                            if (123 == y) --m;
                            else if (125 == y && 0 == m++ && 125 == Ye()) continue;
                        switch (k += Te(y), y * m) {
                            case 38:
                                v = u > 0 ? 1 : (k += "\f", -1);
                                break;
                            case 44:
                                l[c++] = (Re(k) - 1) * v, v = 1;
                                break;
                            case 64:
                                45 === en() && (k += ln(Qe())), p = en(), u = d = Re(b = k += pn(nn())), y++;
                                break;
                            case 45:
                                45 === h && 2 == Re(k) && (m = 0)
                        }
                }
                return i
            }

            function jn(e, n, t, r, o, i, a, l, s, c, u) {
                for (var d = o - 1, p = 0 === o ? i : [""], f = He(p), h = 0, m = 0, _ = 0; h < r; ++h)
                    for (var v = 0, y = Be(e, d + 1, d = Ee(m = a[h])), b = e; v < f; ++v)(b = Le(m > 0 ? p[v] + " " + y : Fe(y, /&\f/g, p[v]))) && (s[_++] = b);
                return Je(e, n, t, 0 === o ? vn : l, s, c, u)
            }

            function Sn(e, n, t) {
                return Je(e, n, t, _n, Te(Ve), Be(e, 2, -2), 0)
            }

            function Cn(e, n, t, r) {
                return Je(e, n, t, yn, Be(e, 0, r), Be(e, r + 1, -1), r)
            }
            var Mn = function(e, n, t) {
                    for (var r = 0, o = 0; r = o, o = en(), 38 === r && 12 === o && (n[t] = 1), !rn(o);) Qe();
                    return tn(e, Ge)
                },
                Pn = new WeakMap,
                On = function(e) {
                    if ("rule" === e.type && e.parent && !(e.length < 1)) {
                        for (var n = e.value, t = e.parent, r = e.column === t.column && e.line === t.line;
                            "rule" !== t.type;)
                            if (!(t = t.parent)) return;
                        if ((1 !== e.props.length || 58 === n.charCodeAt(0) || Pn.get(t)) && !r) {
                            Pn.set(e, !0);
                            for (var o = [], i = function(e, n) {
                                    return an(function(e, n) {
                                        var t = -1,
                                            r = 44;
                                        do {
                                            switch (rn(r)) {
                                                case 0:
                                                    38 === r && 12 === en() && (n[t] = 1), e[t] += Mn(Ge - 1, n, t);
                                                    break;
                                                case 2:
                                                    e[t] += ln(r);
                                                    break;
                                                case 4:
                                                    if (44 === r) {
                                                        e[++t] = 58 === en() ? "&\f" : "", n[t] = e[t].length;
                                                        break
                                                    }
                                                default:
                                                    e[t] += Te(r)
                                            }
                                        } while (r = Qe());
                                        return e
                                    }(on(e), n))
                                }(n, o), a = t.props, l = 0, s = 0; l < i.length; l++)
                                for (var c = 0; c < a.length; c++, s++) e.props[s] = o[l] ? i[l].replace(/&\f/g, a[c]) : a[c] + " " + i[l]
                        }
                    }
                },
                An = function(e) {
                    if ("decl" === e.type) {
                        var n = e.value;
                        108 === n.charCodeAt(0) && 98 === n.charCodeAt(2) && (e.return = "", e.value = "")
                    }
                };

            function In(e, n) {
                switch (function(e, n) {
                    return 45 ^ Ue(e, 0) ? (((n << 2 ^ Ue(e, 0)) << 2 ^ Ue(e, 1)) << 2 ^ Ue(e, 2)) << 2 ^ Ue(e, 3) : 0
                }(e, n)) {
                    case 5103:
                        return mn + "print-" + e + e;
                    case 5737:
                    case 4201:
                    case 3177:
                    case 3433:
                    case 1641:
                    case 4457:
                    case 2921:
                    case 5572:
                    case 6356:
                    case 5844:
                    case 3191:
                    case 6645:
                    case 3005:
                    case 6391:
                    case 5879:
                    case 5623:
                    case 6135:
                    case 4599:
                    case 4855:
                    case 4215:
                    case 6389:
                    case 5109:
                    case 5365:
                    case 5621:
                    case 3829:
                        return mn + e + e;
                    case 5349:
                    case 4246:
                    case 4810:
                    case 6968:
                    case 2756:
                        return mn + e + hn + e + fn + e + e;
                    case 6828:
                    case 4268:
                        return mn + e + fn + e + e;
                    case 6165:
                        return mn + e + fn + "flex-" + e + e;
                    case 5187:
                        return mn + e + Fe(e, /(\w+).+(:[^]+)/, mn + "box-$1$2" + fn + "flex-$1$2") + e;
                    case 5443:
                        return mn + e + fn + "flex-item-" + Fe(e, /flex-|-self/, "") + e;
                    case 4675:
                        return mn + e + fn + "flex-line-pack" + Fe(e, /align-content|flex-|-self/, "") + e;
                    case 5548:
                        return mn + e + fn + Fe(e, "shrink", "negative") + e;
                    case 5292:
                        return mn + e + fn + Fe(e, "basis", "preferred-size") + e;
                    case 6060:
                        return mn + "box-" + Fe(e, "-grow", "") + mn + e + fn + Fe(e, "grow", "positive") + e;
                    case 4554:
                        return mn + Fe(e, /([^-])(transform)/g, "$1" + mn + "$2") + e;
                    case 6187:
                        return Fe(Fe(Fe(e, /(zoom-|grab)/, mn + "$1"), /(image-set)/, mn + "$1"), e, "") + e;
                    case 5495:
                    case 3959:
                        return Fe(e, /(image-set\([^]*)/, mn + "$1$`$1");
                    case 4968:
                        return Fe(Fe(e, /(.+:)(flex-)?(.*)/, mn + "box-pack:$3" + fn + "flex-pack:$3"), /s.+-b[^;]+/, "justify") + mn + e + e;
                    case 4095:
                    case 3583:
                    case 4068:
                    case 2532:
                        return Fe(e, /(.+)-inline(.+)/, mn + "$1$2") + e;
                    case 8116:
                    case 7059:
                    case 5753:
                    case 5535:
                    case 5445:
                    case 5701:
                    case 4933:
                    case 4677:
                    case 5533:
                    case 5789:
                    case 5021:
                    case 4765:
                        if (Re(e) - 1 - n > 6) switch (Ue(e, n + 1)) {
                            case 109:
                                if (45 !== Ue(e, n + 4)) break;
                            case 102:
                                return Fe(e, /(.+:)(.+)-([^]+)/, "$1" + mn + "$2-$3$1" + hn + (108 == Ue(e, n + 3) ? "$3" : "$2-$3")) + e;
                            case 115:
                                return ~De(e, "stretch") ? In(Fe(e, "stretch", "fill-available"), n) + e : e
                        }
                        break;
                    case 4949:
                        if (115 !== Ue(e, n + 1)) break;
                    case 6444:
                        switch (Ue(e, Re(e) - 3 - (~De(e, "!important") && 10))) {
                            case 107:
                                return Fe(e, ":", ":" + mn) + e;
                            case 101:
                                return Fe(e, /(.+:)([^;!]+)(;|!.+)?/, "$1" + mn + (45 === Ue(e, 14) ? "inline-" : "") + "box$3$1" + mn + "$2$3$1" + fn + "$2box$3") + e
                        }
                        break;
                    case 5936:
                        switch (Ue(e, n + 11)) {
                            case 114:
                                return mn + e + fn + Fe(e, /[svh]\w+-[tblr]{2}/, "tb") + e;
                            case 108:
                                return mn + e + fn + Fe(e, /[svh]\w+-[tblr]{2}/, "tb-rl") + e;
                            case 45:
                                return mn + e + fn + Fe(e, /[svh]\w+-[tblr]{2}/, "lr") + e
                        }
                        return mn + e + fn + e + e
                }
                return e
            }
            var zn = [function(e, n, t, r) {
                    if (e.length > -1 && !e.return) switch (e.type) {
                        case yn:
                            e.return = In(e.value, e.length);
                            break;
                        case bn:
                            return gn([Ke(e, {
                                value: Fe(e.value, "@", "@" + mn)
                            })], r);
                        case vn:
                            if (e.length) return function(e, n) {
                                return e.map(n).join("")
                            }(e.props, (function(n) {
                                switch (function(e, n) {
                                    return (e = /(::plac\w+|:read-\w+)/.exec(e)) ? e[0] : e
                                }(n)) {
                                    case ":read-only":
                                    case ":read-write":
                                        return gn([Ke(e, {
                                            props: [Fe(n, /:(read-\w+)/, ":-moz-$1")]
                                        })], r);
                                    case "::placeholder":
                                        return gn([Ke(e, {
                                            props: [Fe(n, /:(plac\w+)/, ":" + mn + "input-$1")]
                                        }), Ke(e, {
                                            props: [Fe(n, /:(plac\w+)/, ":-moz-$1")]
                                        }), Ke(e, {
                                            props: [Fe(n, /:(plac\w+)/, fn + "input-$1")]
                                        })], r)
                                }
                                return ""
                            }))
                    }
                }],
                En = function(e) {
                    var n = e.key;
                    if ("css" === n) {
                        var t = document.querySelectorAll("style[data-emotion]:not([data-s])");
                        Array.prototype.forEach.call(t, (function(e) {
                            -1 !== e.getAttribute("data-emotion").indexOf(" ") && (document.head.appendChild(e), e.setAttribute("data-s", ""))
                        }))
                    }
                    var r, o, i = e.stylisPlugins || zn,
                        a = {},
                        l = [];
                    r = e.container || document.head, Array.prototype.forEach.call(document.querySelectorAll('style[data-emotion^="' + n + ' "]'), (function(e) {
                        for (var n = e.getAttribute("data-emotion").split(" "), t = 1; t < n.length; t++) a[n[t]] = !0;
                        l.push(e)
                    }));
                    var s, c, u, d, p = [wn, (d = function(e) {
                            s.insert(e)
                        }, function(e) {
                            e.root || (e = e.return) && d(e)
                        })],
                        f = (c = [On, An].concat(i, p), u = He(c), function(e, n, t, r) {
                            for (var o = "", i = 0; i < u; i++) o += c[i](e, n, t, r) || "";
                            return o
                        });
                    o = function(e, n, t, r) {
                        s = t,
                            function(e) {
                                gn(xn(e), f)
                            }(e ? e + "{" + n.styles + "}" : n.styles), r && (h.inserted[n.name] = !0)
                    };
                    var h = {
                        key: n,
                        sheet: new ze({
                            key: n,
                            container: r,
                            nonce: e.nonce,
                            speedy: e.speedy,
                            prepend: e.prepend,
                            insertionPoint: e.insertionPoint
                        }),
                        nonce: e.nonce,
                        inserted: a,
                        registered: {},
                        insert: o
                    };
                    return h.sheet.hydrate(l), h
                },
                Tn = {
                    animationIterationCount: 1,
                    aspectRatio: 1,
                    borderImageOutset: 1,
                    borderImageSlice: 1,
                    borderImageWidth: 1,
                    boxFlex: 1,
                    boxFlexGroup: 1,
                    boxOrdinalGroup: 1,
                    columnCount: 1,
                    columns: 1,
                    flex: 1,
                    flexGrow: 1,
                    flexPositive: 1,
                    flexShrink: 1,
                    flexNegative: 1,
                    flexOrder: 1,
                    gridRow: 1,
                    gridRowEnd: 1,
                    gridRowSpan: 1,
                    gridRowStart: 1,
                    gridColumn: 1,
                    gridColumnEnd: 1,
                    gridColumnSpan: 1,
                    gridColumnStart: 1,
                    msGridRow: 1,
                    msGridRowSpan: 1,
                    msGridColumn: 1,
                    msGridColumnSpan: 1,
                    fontWeight: 1,
                    lineHeight: 1,
                    opacity: 1,
                    order: 1,
                    orphans: 1,
                    tabSize: 1,
                    widows: 1,
                    zIndex: 1,
                    zoom: 1,
                    WebkitLineClamp: 1,
                    fillOpacity: 1,
                    floodOpacity: 1,
                    stopOpacity: 1,
                    strokeDasharray: 1,
                    strokeDashoffset: 1,
                    strokeMiterlimit: 1,
                    strokeOpacity: 1,
                    strokeWidth: 1
                },
                Nn = /[A-Z]|^ms/g,
                Ln = /_EMO_([^_]+?)_([^]*?)_EMO_/g,
                Fn = function(e) {
                    return 45 === e.charCodeAt(1)
                },
                Dn = function(e) {
                    return null != e && "boolean" != typeof e
                },
                Un = Oe((function(e) {
                    return Fn(e) ? e : e.replace(Nn, "-$&").toLowerCase()
                })),
                Bn = function(e, n) {
                    switch (e) {
                        case "animation":
                        case "animationName":
                            if ("string" == typeof n) return n.replace(Ln, (function(e, n, t) {
                                return Hn = {
                                    name: n,
                                    styles: t,
                                    next: Hn
                                }, n
                            }))
                    }
                    return 1 === Tn[e] || Fn(e) || "number" != typeof n || 0 === n ? n : n + "px"
                };

            function Rn(e, n, t) {
                if (null == t) return "";
                if (void 0 !== t.__emotion_styles) return t;
                switch (typeof t) {
                    case "boolean":
                        return "";
                    case "object":
                        if (1 === t.anim) return Hn = {
                            name: t.name,
                            styles: t.styles,
                            next: Hn
                        }, t.name;
                        if (void 0 !== t.styles) {
                            var r = t.next;
                            if (void 0 !== r)
                                for (; void 0 !== r;) Hn = {
                                    name: r.name,
                                    styles: r.styles,
                                    next: Hn
                                }, r = r.next;
                            return t.styles + ";"
                        }
                        return function(e, n, t) {
                            var r = "";
                            if (Array.isArray(t))
                                for (var o = 0; o < t.length; o++) r += Rn(e, n, t[o]) + ";";
                            else
                                for (var i in t) {
                                    var a = t[i];
                                    if ("object" != typeof a) null != n && void 0 !== n[a] ? r += i + "{" + n[a] + "}" : Dn(a) && (r += Un(i) + ":" + Bn(i, a) + ";");
                                    else if (!Array.isArray(a) || "string" != typeof a[0] || null != n && void 0 !== n[a[0]]) {
                                        var l = Rn(e, n, a);
                                        switch (i) {
                                            case "animation":
                                            case "animationName":
                                                r += Un(i) + ":" + l + ";";
                                                break;
                                            default:
                                                r += i + "{" + l + "}"
                                        }
                                    } else
                                        for (var s = 0; s < a.length; s++) Dn(a[s]) && (r += Un(i) + ":" + Bn(i, a[s]) + ";")
                                }
                            return r
                        }(e, n, t);
                    case "function":
                        if (void 0 !== e) {
                            var o = Hn,
                                i = t(e);
                            return Hn = o, Rn(e, n, i)
                        }
                }
                if (null == n) return t;
                var a = n[t];
                return void 0 !== a ? a : t
            }
            var Hn, qn = /label:\s*([^\s;\n{]+)\s*(;|$)/g,
                $n = function(e, n, t) {
                    if (1 === e.length && "object" == typeof e[0] && null !== e[0] && void 0 !== e[0].styles) return e[0];
                    var r = !0,
                        o = "";
                    Hn = void 0;
                    var i = e[0];
                    null == i || void 0 === i.raw ? (r = !1, o += Rn(t, n, i)) : o += i[0];
                    for (var a = 1; a < e.length; a++) o += Rn(t, n, e[a]), r && (o += i[a]);
                    qn.lastIndex = 0;
                    for (var l, s = ""; null !== (l = qn.exec(o));) s += "-" + l[1];
                    var c = function(e) {
                        for (var n, t = 0, r = 0, o = e.length; o >= 4; ++r, o -= 4) n = 1540483477 * (65535 & (n = 255 & e.charCodeAt(r) | (255 & e.charCodeAt(++r)) << 8 | (255 & e.charCodeAt(++r)) << 16 | (255 & e.charCodeAt(++r)) << 24)) + (59797 * (n >>> 16) << 16), t = 1540483477 * (65535 & (n ^= n >>> 24)) + (59797 * (n >>> 16) << 16) ^ 1540483477 * (65535 & t) + (59797 * (t >>> 16) << 16);
                        switch (o) {
                            case 3:
                                t ^= (255 & e.charCodeAt(r + 2)) << 16;
                            case 2:
                                t ^= (255 & e.charCodeAt(r + 1)) << 8;
                            case 1:
                                t = 1540483477 * (65535 & (t ^= 255 & e.charCodeAt(r))) + (59797 * (t >>> 16) << 16)
                        }
                        return (((t = 1540483477 * (65535 & (t ^= t >>> 13)) + (59797 * (t >>> 16) << 16)) ^ t >>> 15) >>> 0).toString(36)
                    }(o) + s;
                    return {
                        name: c,
                        styles: o,
                        next: Hn
                    }
                },
                Zn = (Object.prototype.hasOwnProperty, T("undefined" != typeof HTMLElement ? En({
                    key: "css"
                }) : null));
            Zn.Provider;
            var Wn = function(e) {
                    return ue((function(n, t) {
                        var r = Y(Zn);
                        return e(n, r, t)
                    }))
                },
                Gn = T({}),
                Vn = function(e, n, t) {
                    ! function(e, n, t) {
                        var r = e.key + "-" + n.name;
                        !1 === t && void 0 === e.registered[r] && (e.registered[r] = n.styles)
                    }(e, n, t);
                    var r = e.key + "-" + n.name;
                    if (void 0 === e.inserted[n.name]) {
                        var o = n;
                        do {
                            e.insert(n === o ? "." + r : "", o, e.sheet, !0), o = o.next
                        } while (void 0 !== o)
                    }
                },
                Xn = Ie,
                Jn = function(e) {
                    return "theme" !== e
                },
                Kn = function(e) {
                    return "string" == typeof e && e.charCodeAt(0) > 96 ? Xn : Jn
                },
                Yn = function(e, n, t) {
                    var r;
                    if (n) {
                        var o = n.shouldForwardProp;
                        r = e.__emotion_forwardProp && o ? function(n) {
                            return e.__emotion_forwardProp(n) && o(n)
                        } : o
                    }
                    return "function" != typeof r && t && (r = e.__emotion_forwardProp), r
                },
                Qn = function e(n, t) {
                    var r, o, i = n.__emotion_real === n,
                        a = i && n.__emotion_base || n;
                    void 0 !== t && (r = t.label, o = t.target);
                    var l = Yn(n, t, i),
                        s = l || Kn(a),
                        c = !s("as");
                    return function() {
                        var u = arguments,
                            d = i && void 0 !== n.__emotion_styles ? n.__emotion_styles.slice(0) : [];
                        if (void 0 !== r && d.push("label:" + r + ";"), null == u[0] || void 0 === u[0].raw) d.push.apply(d, u);
                        else {
                            d.push(u[0][0]);
                            for (var f = u.length, h = 1; h < f; h++) d.push(u[h], u[0][h])
                        }
                        var m = Wn((function(e, n, t) {
                            var r, i, u, f, h = c && e.as || a,
                                m = "",
                                _ = [],
                                v = e;
                            if (null == e.theme) {
                                for (var y in v = {}, e) v[y] = e[y];
                                v.theme = Y(Gn)
                            }
                            "string" == typeof e.className ? (r = n.registered, i = _, u = e.className, f = "", u.split(" ").forEach((function(e) {
                                void 0 !== r[e] ? i.push(r[e] + ";") : f += e + " "
                            })), m = f) : null != e.className && (m = e.className + " ");
                            var b = $n(d.concat(_), n.registered, v);
                            Vn(n, b, "string" == typeof h), m += n.key + "-" + b.name, void 0 !== o && (m += " " + o);
                            var g = c && void 0 === l ? Kn(h) : s,
                                w = {};
                            for (var x in e) c && "as" === x || g(x) && (w[x] = e[x]);
                            return w.className = m, w.ref = t, p(h, w)
                        }));
                        return m.displayName = void 0 !== r ? r : "Styled(" + ("string" == typeof a ? a : a.displayName || a.name || "Component") + ")", m.defaultProps = n.defaultProps, m.__emotion_real = m, m.__emotion_base = a, m.__emotion_styles = d, m.__emotion_forwardProp = l, Object.defineProperty(m, "toString", {
                            value: function() {
                                return "." + o
                            }
                        }), m.withComponent = function(n, r) {
                            return e(n, Pe({}, t, r, {
                                shouldForwardProp: Yn(m, r, !0)
                            })).apply(void 0, d)
                        }, m
                    }
                }.bind();
            ["a", "abbr", "address", "area", "article", "aside", "audio", "b", "base", "bdi", "bdo", "big", "blockquote", "body", "br", "button", "canvas", "caption", "cite", "code", "col", "colgroup", "data", "datalist", "dd", "del", "details", "dfn", "dialog", "div", "dl", "dt", "em", "embed", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "iframe", "img", "input", "ins", "kbd", "keygen", "label", "legend", "li", "link", "main", "map", "mark", "marquee", "menu", "menuitem", "meta", "meter", "nav", "noscript", "object", "ol", "optgroup", "option", "output", "p", "param", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "script", "section", "select", "small", "source", "span", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "textarea", "tfoot", "th", "thead", "time", "title", "tr", "track", "u", "ul", "var", "video", "wbr", "circle", "clipPath", "defs", "ellipse", "foreignObject", "g", "image", "line", "linearGradient", "mask", "path", "pattern", "polygon", "polyline", "radialGradient", "rect", "stop", "svg", "text", "tspan"].forEach((function(e) {
                Qn[e] = Qn(e)
            }));
            var et = Qn;

            function nt(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return tt(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? tt(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function tt(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }
            var rt = "Roboto",
                ot = {
                    s: "".concat(4, "px"),
                    m: "".concat(8, "px"),
                    l: "".concat(12, "px")
                },
                it = {
                    x0: "".concat(4, "px"),
                    x0pt5: "".concat(4, "px"),
                    x1: "".concat(8, "px"),
                    x1pt5: "".concat(12, "px"),
                    x2: "".concat(16, "px"),
                    x2pt5: "".concat(20, "px"),
                    x3: "".concat(24, "px"),
                    x3pt5: "".concat(28, "px"),
                    x4: "".concat(32, "px"),
                    x4pt5: "".concat(36, "px"),
                    x5: "".concat(40, "px"),
                    x5pt5: "".concat(44, "px"),
                    x6: "".concat(48, "px"),
                    x6pt5: "".concat(52, "px"),
                    x7: "".concat(56, "px"),
                    x7pt5: "".concat(60, "px"),
                    x8: "".concat(64, "px"),
                    x8pt5: "".concat(68, "px")
                },
                at = function() {
                    return "".concat(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : rt, ", Arial, sans-serif")
                },
                lt = function(e) {
                    var n = function(e, n, t) {
                            if (n && !Array.isArray(n) && "number" == typeof n.length) {
                                var r = n.length;
                                return tt(n, 4 < r ? 4 : r)
                            }
                            return e(n, 4)
                        }(nt, e),
                        t = n[0],
                        r = n[1],
                        o = n[2],
                        i = n[3];
                    return "\n        font-family: ".concat(at(void 0 === i ? rt : i), " !important;\n        font-size: ").concat(t, "px !important;\n        font-weight: ").concat(r, " !important;\n        line-height: ").concat(o, "px;\n    ")
                },
                st = {
                    animation: {
                        default: "all 0.3s ease-in-out",
                        property: function(e) {
                            return "".concat(e, " 0.3s ease-in-out")
                        }
                    },
                    maxIndex: 2147483647,
                    radius: ot,
                    shadow: {
                        mobile: "0px 1px 3px 0px rgba(0, 0, 0, 0.10);",
                        desktop: "0px -5px 40px 0px rgba(0, 0, 0, 0.05)",
                        modal: "0px -5px 40px 0px rgba(0, 0, 0, 0.10)"
                    },
                    spacer: it,
                    colors: {
                        ui_background: "#FFFFFF",
                        option_border: "rgba(50, 79, 190, 0.15)",
                        focus_outline: "rgba(89, 117, 203)",
                        overlay: "rgba(26, 25, 25, 0.7)",
                        neutral_300: "#E0E2E8",
                        neutral_600: "#838696",
                        neutral_700: "#696464",
                        primary_cta: "#324FBE",
                        primary_cta_alt: "#1C3286",
                        bg_active: "#EBEEF9",
                        ui_disabled: "#F1F2F6",
                        focus_border: "#5b72cb",
                        focus: "#5069C8",
                        error: "#a72a2a",
                        modal_overlay: "rgba(7, 12, 28, 0.9)"
                    },
                    text: {
                        body2: lt([14, 400, 20, rt]),
                        subtitle1: lt([16, 500, 24, rt]),
                        subtitle2: lt([14, 500, 20, rt]),
                        link: lt([14, 400, 16, rt]),
                        fontFamily: function(e) {
                            return "font-family: ".concat(at(e), " !important;")
                        }
                    },
                    breakpoint: {
                        desktop: "@media screen and (min-width: 650px)",
                        mobile: "@media screen and (max-width: 649px)",
                        previewMobile: "@media screen and (max-width: 320px)"
                    },
                    getFontFamily: at,
                    printNoDisplay: "@media print {\n    display: none !important;\n}"
                },
                ct = T(null),
                ut = function(e) {
                    var n = e.theme,
                        t = e.children;
                    return p(ct.Provider, {
                        value: n
                    }, t)
                },
                dt = function() {
                    var e = Y(ct);
                    if (null === e) throw new Error("theme: useTheme used outside of the ThemeContext or context not set");
                    return e
                },
                pt = 650;

            function ft() {
                return arguments.length > 0 && void 0 !== arguments[0] && arguments[0] ? hj.hq(window).width() < 319 : hj.hq(window).width() <= 650
            }
            var ht = function(e, n) {
                    var t = hj.isPreview && "desktop" === e;
                    return function(e) {
                        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : pt;
                        return function(e) {
                            return hj.features.hasFeature("survey.iframe.full_screen") && "full_screen" === e || hj.features.hasFeature("survey.iframe.popover") && "popover" === e ? window.parent : window
                        }(e).document.documentElement.clientWidth < n
                    }(n) && !t
                },
                mt = {},
                _t = {
                    remove: hj.tryCatch((function(e) {
                        var n = "survey_".concat(e);
                        "function" == typeof mt[n] && window.removeEventListener("resize", mt[n])
                    }), "hj.resizeHandlers.setHandler"),
                    add: hj.tryCatch((function(e, n) {
                        var t = "survey_".concat(n);
                        _t.remove(n), mt[t] = e, window.addEventListener("resize", e)
                    }), "hj.resizeHandlers.setHandler")
                };

            function vt(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return yt(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? yt(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function yt(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }
            var bt = function() {
                    return {
                        width: window.innerWidth,
                        height: window.innerHeight
                    }
                },
                gt = function(e) {
                    return e.SINGLE_OPEN_ENDED_MULTI_LINE = "single-open-ended-multiple-line", e.SINGLE_OPEN_ENDED_SINGLE_LINE = "single-open-ended-single-line", e.EMAIL = "email", e.SINGLE_CLOSE_ENDED = "single-close-ended", e.MULTIPLE_CLOSE_ENDED = "multiple-close-ended", e.YES_NO = "yes-no", e.RATING_5 = "rating-scale-5", e.RATING_7 = "rating-scale-7", e.NPS = "net-promoter-score", e.TITLE_AND_DESCRIPTION = "title-and-description", e.REACTION = "reaction", e
                }({}),
                wt = Object.freeze({
                    POPOVER: "popover",
                    FULL_SCREEN: "full_screen",
                    EXTERNAL: "external_link",
                    BUTTON: "button",
                    INLINE_EMBEDDED: "inline",
                    BUBBLE: "bubble",
                    MOBILE_POPOVER: "mobile_popover"
                }),
                xt = function(e) {
                    var n = e.displayType === wt.EXTERNAL,
                        t = e.displayType === wt.FULL_SCREEN,
                        r = e.displayType === wt.POPOVER,
                        o = e.displayType === wt.BUTTON,
                        i = e.displayType === wt.FULL_SCREEN,
                        a = e.displayType === wt.INLINE_EMBEDDED,
                        l = r || o;
                    return {
                        isExternal: n,
                        isFullScreen: i,
                        isModal: t,
                        isPopover: r,
                        isButton: o,
                        isPopoverOrButton: l,
                        isEmbedded: !l && !a,
                        isInline: a,
                        isBubble: e.displayType === wt.BUBBLE,
                        isMobilePopover: e.displayType === wt.MOBILE_POPOVER
                    }
                };
            const kt = (e, n = 127.5) => {
                const [t, r, o] = (e => e.match(/^rgb/) ? function(e) {
                    const n = e.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d+(?:\.\d+)?))?\)$/),
                        [, t, r, o] = n;
                    return [Number(t), Number(r), Number(o)]
                }(e) : function(e) {
                    const n = +`0x${e.slice(1).replace(e.length<5&&/./g,"$&$&")}`;
                    return [n >> 16 & 255, n >> 8 & 255, 255 & n]
                }(e))(e);
                return Math.sqrt(t * t * .299 + r * r * .587 + o * o * .114) > n
            };
            var jt, St, Ct, Mt;

            function Pt() {
                return Pt = Object.assign ? Object.assign.bind() : function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var t = arguments[n];
                        for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r])
                    }
                    return e
                }, Pt.apply(this, arguments)
            }

            function Ot(e, n, t) {
                if (n && !Array.isArray(n) && "number" == typeof n.length) {
                    var r = n.length;
                    return It(n, void 0 !== t && t < r ? t : r)
                }
                return e(n, t)
            }

            function At(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return It(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? It(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function It(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }
            var zt = "#FFFFFF",
                Et = "#202641";

            function Tt(e, n, t) {
                t /= 100;
                var r = n * Math.min(t, 1 - t) / 100,
                    o = function(n) {
                        var o = (n + e / 30) % 12,
                            i = t - r * Math.max(Math.min(o - 3, 9 - o, 1), -1),
                            a = Math.round(255 * i).toString(16);
                        return 1 === a.length ? "0" + a : a
                    };
                return "#".concat(o(0)).concat(o(8)).concat(o(4))
            }

            function Nt(e) {
                var n = 0,
                    t = 0,
                    r = 0;
                4 === e.length ? (n = Number("0x" + e[1] + e[1]), t = Number("0x" + e[2] + e[2]), r = Number("0x" + e[3] + e[3])) : 7 === e.length && (n = Number("0x" + e[1] + e[2]), t = Number("0x" + e[3] + e[4]), r = Number("0x" + e[5] + e[6])), n /= 255, t /= 255, r /= 255;
                var o = Math.min(n, t, r),
                    i = Math.max(n, t, r),
                    a = i - o,
                    l = 0,
                    s = 0;
                return l = 0 === a ? 0 : i === n ? (t - r) / a % 6 : i === t ? (r - n) / a + 2 : (n - t) / a + 4, (l = Math.round(60 * l)) < 0 && (l += 360), s = (i + o) / 2, [l, +(100 * (0 === a ? 0 : a / (1 - Math.abs(2 * s - 1)))).toFixed(1), s = +(100 * s).toFixed(1)]
            }

            function Lt(e) {
                var n = Ot(At, Nt(e), 3),
                    t = n[0],
                    r = n[1],
                    o = n[2],
                    i = o <= 15 ? 10 : -10;
                return Tt(t, r, Math.max(0, o + i))
            }

            function Ft(e) {
                var n = Ot(At, Nt(e), 3),
                    t = n[0],
                    r = n[1],
                    o = n[2],
                    i = o <= 15 ? 15 : -15;
                return Tt(t, r, Math.max(0, o + i))
            }
            var Dt = ((jt = {})["#324FBE"] = {
                    color: "#324FBE",
                    hoverColor: "#1C3286",
                    textColor: "rgba(255,255,255,0.94)"
                }, jt["#C3F0F7"] = {
                    color: "#C3F0F7",
                    hoverColor: "#90D0DA",
                    textColor: "#202641"
                }, jt),
                Ut = ((St = {})[zt] = {
                    disabledColor: "#F1F2F6",
                    disabledTextColor: "rgba(0, 0, 0, 0.43)"
                }, St[Et] = {
                    disabledColor: "#0A1238",
                    disabledTextColor: "rgba(255, 255, 255, 0.38)"
                }, St),
                Bt = ((Ct = {})[Et] = "#54586B", Ct[zt] = "#E4E6EB", Ct),
                Rt = ((Mt = {})[Et] = "#0A0F26", Mt[zt] = "#E0E2E8", Mt),
                Ht = t(9425),
                qt = t.n(Ht);

            function $t() {
                return $t = Object.assign ? Object.assign.bind() : function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var t = arguments[n];
                        for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r])
                    }
                    return e
                }, $t.apply(this, arguments)
            }

            function Zt(e, n, t) {
                if (n && !Array.isArray(n) && "number" == typeof n.length) {
                    var r = n.length;
                    return Gt(n, void 0 !== t && t < r ? t : r)
                }
                return e(n, t)
            }

            function Wt(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return Gt(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? Gt(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Gt(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }
            var Vt = .25,
                Xt = {},
                Jt = {
                    0: -99,
                    50: -95,
                    100: -90,
                    200: -75,
                    300: -60,
                    400: -30,
                    500: 0,
                    600: 10,
                    700: 40,
                    800: 55,
                    900: 70,
                    950: 80,
                    990: 90,
                    999: 99
                },
                Kt = function(e) {
                    return Object.entries(Jt).reduce((function(n, t) {
                        var r, o = Zt(Wt, t, 2),
                            i = o[0],
                            a = o[1],
                            l = a < 0 ? e.tint(-1 * a).hexString() : e.shade(a).hexString();
                        return $t($t({}, n), {}, ((r = {})[i] = l, r))
                    }), {})
                },
                Yt = function(e) {
                    var n = e.replace("#", "");
                    return 3 == n.length && (n = n[0] + n[0] + n[1] + n[1] + n[2] + n[2]), "#" + n.padEnd(6, "0")
                };

            function Qt(e) {
                var n = e;
                6 !== n.replace("#", "").length && (n = Yt(e));
                var t = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(n);
                return t ? [parseInt(t[1], 16), parseInt(t[2], 16), parseInt(t[3], 16)] : null
            }

            function er(e) {
                var n = e / 255;
                return n <= .03928 ? n / 12.92 : Math.pow((n + .055) / 1.055, 2.4)
            }

            function nr(e) {
                var n = Zt(Wt, e, 3),
                    t = n[0],
                    r = n[1],
                    o = n[2];
                return .2126 * er(t) + .7152 * er(r) + .072 * er(o)
            }

            function tr(e, n) {
                return e > n ? (e + .05) / (n + .05) : (n + .05) / (e + .05)
            }

            function rr(e) {
                var n = Qt(e),
                    t = n ? function(e) {
                        var n = Zt(Wt, e, 3),
                            t = n[0],
                            r = n[1],
                            o = n[2];
                        t /= 255, r /= 255, o /= 255;
                        var i = Math.max(t, r, o),
                            a = i - Math.min(t, r, o),
                            l = a ? i === t ? (r - o) / a : i === r ? 2 + (o - t) / a : 4 + (t - r) / a : 0;
                        return [60 * l < 0 ? 60 * l + 360 : 60 * l, 100 * (a ? i <= .5 ? a / (2 * i - a) : a / (2 - (2 * i - a)) : 0), 100 * (2 * i - a) / 2]
                    }(n) : [0, 0, 0];
                t[1] = t[1] ? Vt * t[1] : 0;
                var r = new(qt())(e),
                    o = new(qt())(function(e) {
                        var n = Zt(Wt, e, 3);
                        return "#" + ((n[0] << 16) + (n[1] << 8) + n[2]).toString(16).padStart(6, "0")
                    }(function(e) {
                        var n = Zt(Wt, e, 3),
                            t = n[0],
                            r = n[1],
                            o = n[2];
                        o /= 100;
                        var i = function(e) {
                                return (e + t / 30) % 12
                            },
                            a = (r /= 100) * Math.min(o, 1 - o),
                            l = function(e) {
                                return o - a * Math.max(-1, Math.min(i(e) - 3, Math.min(9 - i(e), 1)))
                            };
                        return [Math.round(255 * l(0)), Math.round(255 * l(8)), Math.round(255 * l(4))]
                    }(t)));
                return Xt["colors-".concat(e)] = Xt["colors-".concat(e)] || Kt(r), Xt["greys-".concat(e)] = Xt["greys-".concat(e)] || Kt(o), {
                    colors: Xt["colors-".concat(e)],
                    greys: Xt["greys-".concat(e)]
                }
            }
            var or, ir = {};

            function ar(e, n, t) {
                var r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 3,
                    o = function(e, n, t, r) {
                        return "".concat(e).concat(n[t]).concat(r.toString())
                    }(e, n, t, r);
                if (ir[o]) return ir[o];
                var i = nr(Qt(e)),
                    a = n[t],
                    l = nr(Qt(a)),
                    s = tr(i, l),
                    c = i > l;
                if (s >= r) return a;
                for (var u = a, d = Jt[t]; d < 100 & d > -100; c ? d += 5 : d -= 5) {
                    var p = new(qt())(n[500]);
                    if ((s = tr(i, nr((u = d < 0 ? p.tint(-1 * d) : p.shade(d)).rgb))) >= r) break
                }
                return ir[o] = u.hexString(), u.hexString()
            }

            function lr(e) {
                var n = X(null);
                return V((function() {
                    if (n.current) {
                        var t, r, o, i, a, l, s, c, u, d, p, f = e.buttonColor || e.accentColor || e.button,
                            h = rr(f),
                            m = e.secondaryTextColor || e.footerTextColor,
                            _ = e.backgroundColor || e.background || e.primaryColor,
                            v = function(e) {
                                var n = e.toUpperCase();
                                return Bt[n] || Lt(n)
                            }(_),
                            y = function(e) {
                                return Rt[e] || Lt(e)
                            }(_),
                            b = function(e, n) {
                                var t = kt(e),
                                    r = function(e) {
                                        var n = Ot(At, Nt(e), 3),
                                            t = n[0],
                                            r = n[1],
                                            o = n[2],
                                            i = o > 15 ? -5 : 5;
                                        return Tt(t, Math.max(.75 * r, 0), Math.max(0, o + i))
                                    }(n),
                                    o = Pt(Pt({
                                        color: e,
                                        textColor: t ? "#000" : "#FFF",
                                        hoverColor: Lt(e),
                                        disabledColor: r,
                                        disabledTextColor: kt(r) ? "rgba(0,0,0,0.43)" : "rgba(255, 255, 255, 0.38)",
                                        activeColor: Ft(e)
                                    }, Dt[e.toUpperCase()]), Ut[n.toUpperCase()]);
                                return Pt({}, o)
                            }(f, _);
                        n.current.style.setProperty("--hjFeedbackAccentColor", null !== (t = b.color) && void 0 !== t ? t : ""), n.current.style.setProperty("--hjFeedbackAccentHoverColor", null !== (r = b.hoverColor) && void 0 !== r ? r : ""), n.current.style.setProperty("--hjFeedbackAccentActiveColor", null !== (o = b.activeColor) && void 0 !== o ? o : ""), n.current.style.setProperty("--hjFeedbackAccentTextColor", e.accentTextColor || b.textColor), n.current.style.setProperty("--hjFeedbackDisabledAccentColor", b.disabledColor), n.current.style.setProperty("--hjFeedbackDisabledAccentTextColor", b.disabledTextColor), n.current.style.setProperty("--hjFeedbackSecondaryTextColor", null != m ? m : ""), n.current.style.setProperty("--hjFeedbackPrimaryColor", null != _ ? _ : ""), n.current.style.setProperty("--hjFeedbackBackgroundColor", null !== (i = e.backgroundColor) && void 0 !== i ? i : ""), n.current.style.setProperty("--hjFeedbackDarkGray", null !== (a = e.darkGrey) && void 0 !== a ? a : ""), n.current.style.setProperty("--hjFeedbackSelectionColor", null !== (l = e.selectionColor) && void 0 !== l ? l : ""), n.current.style.setProperty("--hjFeedbackSelectionTextColor", null !== (s = e.selectionTextColor) && void 0 !== s ? s : ""), n.current.style.setProperty("--hjFeedbackPrimaryColor", null !== (c = e.primaryColor) && void 0 !== c ? c : ""), n.current.style.setProperty("--hjFeedbackSecondaryColor", null !== (u = e.secondaryColor) && void 0 !== u ? u : ""), n.current.style.setProperty("--hjFeedbackBorderColor", null != v ? v : ""), n.current.style.setProperty("--hjFeedbackOptionButtonBackgroundColor", null != y ? y : ""), n.current.style.setProperty("--hjFeedbackInputPlaceholderColor", "light" === e.skin ? ar(_, h.greys, 500, 4.5) : ar(_, h.greys, 300, 4.5)), n.current.style.setProperty("--hjFeedbackFontColor", null !== (d = e.fontColor) && void 0 !== d ? d : ""), n.current.style.setProperty("font-size", "clamp(16px, 1rem, 32px)", "important"), n.current.style.setProperty("--hjFeedbackPageTextColor", null !== (p = e.pageTextColor) && void 0 !== p ? p : "")
                    }
                }), [e]), {
                    ref: n
                }
            }

            function sr() {
                return hj.isPreview
            }
            var cr = function(e, n, t) {
                    return {
                        negative: e,
                        neutral: n,
                        positive: t
                    }
                },
                ur = ((or = {})[gt.NPS] = cr(6, 8, 10), or[gt.RATING_7] = cr(3, 4, 7), or[gt.RATING_5] = cr(2, 3, 5), or[gt.REACTION] = cr(2, 3, 5), or),
                dr = function(e, n) {
                    var t = function(e) {
                        if (!ur[e]) throw new Error("Got unexpected question type ".concat(e));
                        return ur[e]
                    }(e);
                    if (n <= t.negative) return 0;
                    if (n <= t.neutral) return 1;
                    if (n <= t.positive) return 2;
                    throw new Error("Got unexpected scale answer: " + n)
                },
                pr = hj.tryCatch((function() {
                    var e = function() {
                            try {
                                return window.self !== window.top
                            } catch (e) {
                                return !0
                            }
                        }(),
                        n = {
                            width: !e && window.screen ? window.screen.width : document.body.clientWidth,
                            height: !e && window.screen ? window.screen.height : document.body.clientHeight
                        };
                    return {
                        width: window.innerWidth || document.documentElement.clientWidth || n.width,
                        height: window.innerHeight || document.documentElement.clientHeight || n.height
                    }
                }), "common"),
                fr = hj.tryCatch((function() {
                    var e, n;
                    if (document && document.documentElement && document.documentElement.clientWidth) e = document.documentElement.clientWidth, n = document.documentElement.clientHeight;
                    else {
                        var t = pr();
                        e = t.width, n = t.height
                    }
                    return {
                        width: e,
                        height: n
                    }
                }), "common"),
                hr = hj.tryCatch((function(e) {
                    return e = e || window, {
                        left: hj.hq(e).scrollLeft(),
                        top: hj.hq(e).scrollTop()
                    }
                }), "common"),
                mr = (hj.tryCatch((function() {
                    var e = parseInt(1e3 * (hj.hq(window).scrollTop() + hj.ui.getWindowSize().height) / hj.hq(document).height(), 10);
                    return Math.min(1e3, e)
                }), "common"), hj.tryCatch((function(e) {
                    var n = hj.ui.getScrollPosition();
                    hj.hq(document).on("scroll.hotjarDisable resize.hotjarDisable mousewheel.hotjarDisable DOMMouseScroll.hotjarDisable touchmove.hotjarDisable", hj.tryCatch((function(t) {
                        t.preventDefault(), window.scrollTo(n.left, n.top), e && e()
                    }), "common"))
                }), "common"), hj.tryCatch((function() {
                    hj.hq(document).off("scroll.hotjarDisable"), hj.hq(document).off("resize.hotjarDisable"), hj.hq(document).off("mousewheel.hotjarDisable"), hj.hq(document).off("DOMMouseScroll.hotjarDisable"), hj.hq(document).off("touchmove.hotjarDisable")
                }), "common"), "_hj-widget-container");

            function _r(e, n) {
                for (var t = e.querySelectorAll(n), r = 0; r < t.length; r++) {
                    var o = t[r];
                    o && o.parentElement && o.parentElement.removeChild(o)
                }
            }

            function vr() {
                return vr = Object.assign ? Object.assign.bind() : function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var t = arguments[n];
                        for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r])
                    }
                    return e
                }, vr.apply(this, arguments)
            }
            var yr = function(e) {
                    return (e || "").substr(0, 8)
                },
                br = function(e, n) {
                    var t = {
                        questionUuid: yr(e.uuid),
                        answer: n.answerText
                    };
                    return n.comment && (t.comment = n.comment), t
                },
                gr = [gt.NPS, gt.RATING_7, gt.RATING_5, gt.REACTION],
                wr = function(e) {
                    hj.request.grantConsent({
                        response_type: "poll_response",
                        response_uuid: hj.widget.pollsResponsesUUID[e],
                        message: hj.polls.translate("consent")
                    })
                },
                xr = {
                    popover: {
                        isExternal: !1,
                        allowsScreenshots: !0
                    },
                    full_screen: {
                        isExternal: !1,
                        allowsScreenshots: !0
                    },
                    inline: {
                        isExternal: !1,
                        allowsScreenshots: !0
                    },
                    button: {
                        isExternal: !1,
                        allowsScreenshots: !0
                    },
                    bubble: {
                        isExternal: !1,
                        allowsScreenshots: !0
                    },
                    external_link: {
                        isExternal: !0,
                        allowsScreenshots: !1
                    },
                    mobile_popover: {
                        isExternal: !0,
                        allowsScreenshots: !1
                    }
                };

            function kr(e) {
                return function(e) {
                    if (Array.isArray(e)) return jr(e)
                }(e) || function(e) {
                    if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
                }(e) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return jr(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? jr(e, n) : void 0
                    }
                }(e) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function jr(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }
            var Sr, Cr = "🐛",
                Mr = function(e) {
                    return function(e) {
                        for (var n, t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), o = 1; o < t; o++) r[o - 1] = arguments[o];
                        return (n = console).debug.apply(n, [Cr, e].concat(function(e, n, t) {
                            return n && !Array.isArray(n) && "number" == typeof n.length ? jr(n, n.length) : e(n, t)
                        }(kr, r || [])))
                    }("[safeNative] ".concat(e))
                },
                Pr = function(e, n) {
                    try {
                        if (!Sr) {
                            var t = function() {
                                if (document.body) {
                                    var e = document.createElement("iframe");
                                    return e.id = "_hjSafeContext_".concat(Math.floor(1e8 * Math.random())), e.title = "_hjSafeContext", e.tabIndex = -1, e.setAttribute("aria-hidden", "true"), e.src = "about:blank", e.style.setProperty("display", "none", "important"), e.style.setProperty("width", "1px", "important"), e.style.setProperty("height", "1px", "important"), e.style.setProperty("opacity", "0", "important"), e.style.setProperty("pointer-events", "none", "important"), document.body.appendChild(e), e
                                }
                            }();
                            if (!t) return Mr("Unable to access an IFrame context, using default property."), e;
                            Sr = t
                        }
                        var r = ("function" == typeof e ? e.name : n) || n;
                        return r ? Sr.contentWindow ? Sr.contentWindow[r] || (Mr("Unable to access property with name [".concat(r, "] from an IFrame context")), e) : (Mr("Unable to access contentWindow property"), e) : (Mr("Unable to name property or missing fallbackName"), e)
                    } catch (n) {
                        return Mr("An unexpected error occurred".concat(n instanceof Error ? ": ".concat(n.message) : "", ". Using default constructor")), e
                    }
                },
                Or = Pr(Date, "Date");

            function Ar(e, n, t) {
                if (n && !Array.isArray(n) && "number" == typeof n.length) {
                    var r = n.length;
                    return zr(n, void 0 !== t && t < r ? t : r)
                }
                return e(n, t)
            }

            function Ir(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return zr(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? zr(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function zr(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }
            Pr(encodeURIComponent, "encodeURIComponent"), Pr(decodeURIComponent, "decodeURLComponent"), Pr(btoa, "btoa"), Pr(atob, "atob");
            var Er = function(e) {
                    return e.ETR_OFF = "0", e.ETR_ON = "1", e
                }({}),
                Tr = function(e) {
                    return e.ETR_DISABLED = "0", e.ETR_PENDING = "1", e.ETR_SAVED_PAGE = "2", e.ETR_SAVED_SESSION = "3", e
                }({}),
                Nr = function(e) {
                    return "https://".concat(hj.insightsHost, "/sites/").concat(hjSiteSettings.site_id, "/surveys/responses/").concat(e)
                },
                Lr = function(e, n) {
                    return "".concat(Nr(e), "?prid=").concat(n)
                },
                Fr = {
                    "single-open-ended-multiple-line": !0,
                    "single-open-ended-single-line": !0,
                    email: !0,
                    "single-close-ended": !1,
                    "multiple-close-ended": !1,
                    "rating-scale-5": !1,
                    "rating-scale-7": !1,
                    "net-promoter-score": !1,
                    "title-and-description": !1,
                    reaction: !1,
                    "yes-no": !1
                },
                Dr = function(e, n) {
                    var t = n.filter((function(n) {
                        var t = e.find((function(e) {
                            return e.uuid.startsWith(n.questionUuid)
                        }));
                        return void 0 === t ? (hj.log.debug("Response discarded: Question with id starting with '".concat(n.questionUuid, "' could not be found."), "anonymizing response", n), !1) : !Fr[t.type] || (hj.log.debug("Response discarded: Question with id '".concat(t.uuid, "' has question type ").concat(t.type, " which may contain Personally Identifiable Information"), "anonymizing response", n), !1)
                    }));
                    return JSON.parse(JSON.stringify(t))
                },
                Ur = function(e) {
                    var n = new window.CustomEvent("hotjar-survey-event", {
                        detail: e
                    });
                    window.dispatchEvent(n)
                };

            function Br(e, n, t) {
                if (n && !Array.isArray(n) && "number" == typeof n.length) {
                    var r = n.length;
                    return Hr(n, void 0 !== t && t < r ? t : r)
                }
                return e(n, t)
            }

            function Rr(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return Hr(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? Hr(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Hr(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }

            function qr(e, n) {
                var t, r, o = !!e.is_submitted,
                    i = W(function(e) {
                        return null != e ? e : 0
                    }(null === (t = e.preview) || void 0 === t ? void 0 : t.questionIndex)),
                    a = Br(Rr, i, 2),
                    l = a[0],
                    s = a[1],
                    c = Br(Rr, W({}), 2),
                    u = c[0],
                    d = c[1],
                    p = Br(Rr, W(!1), 2),
                    f = p[0],
                    h = p[1],
                    m = Br(Rr, W(!1), 2),
                    _ = m[0],
                    v = m[1],
                    y = Br(Rr, W(!1), 2),
                    b = y[0],
                    g = y[1],
                    w = Br(Rr, W(!1), 2),
                    x = w[0],
                    k = w[1],
                    j = W([])[1],
                    S = function(e) {
                        var n = Ar(Ir, W(0), 2),
                            t = n[0],
                            r = n[1],
                            o = Ar(Ir, W(0), 2),
                            i = o[0],
                            a = o[1];
                        return G((function() {
                            return r(Or.now())
                        }), []), G((function() {
                            e && 0 === i && a(Or.now())
                        }), [e, i]), K((function() {
                            var e = Or.now();
                            return {
                                fromEngagement: 0 === i ? void 0 : e - i,
                                fromRender: e - t
                            }
                        }), [i, t])
                    }(_),
                    C = function(e) {
                        var n = e.isEtrEnabled;
                        window._uxa = window._uxa || [];
                        var t = X(!1),
                            r = function(e) {
                                hj.log.debug("-- RECORDING CONTEXT CHANGED --", "poll", e), t.current || (e.etrState === Er.ETR_ON || e.etrStatus === Tr.ETR_SAVED_SESSION || e.isRecording) && (t.current = !0)
                            };
                        return G((function() {
                            if (window._uxa && n) {
                                var e = window._uxa.push(["onRecordingContextChange", r]);
                                return function() {
                                    e && "function" == typeof e && e()
                                }
                            }
                        }), [n]), {
                            getIsRecorded: function() {
                                return t.current
                            },
                            triggerEtr: K((function() {
                                if (n && window._uxa && !t.current) try {
                                    t.current = !0, window._uxa.push(["trackEventTriggerRecording", "@ETS@FB_HJ_SurveyInteraction"]), hj.log.debug("-- ETR TRIGGERED --", "poll")
                                } catch (e) {
                                    hj.log.error("Surveys: Error in ETR trigger")
                                }
                            }), [n])
                        }
                    }({
                        isEtrEnabled: e.etr_enabled
                    }).triggerEtr,
                    M = function(e) {
                        e && !sr() && C(), v(e)
                    },
                    P = e.content.questions[l],
                    O = l + 1 > e.content.questions.length || o,
                    A = Br(Rr, W([]), 2),
                    I = A[0],
                    z = A[1],
                    E = n && "ask" === e.connect_visit_data || "always" === e.connect_visit_data;
                G((function() {
                    e.preview && h(e.preview.forceAnswerValid)
                }), [null === (r = e.preview) || void 0 === r ? void 0 : r.forceAnswerValid]), G((function() {
                    var n;
                    sr() || (n = e.id, Ur({
                        event: "surveyDisplayed",
                        surveyId: n,
                        insightsUrl: Nr(n)
                    }))
                }), [e.id]);
                var T = function(n) {
                    M(!0);
                    var t = u[P.uuid],
                        r = n ? P.nextIfSkipped : P.next,
                        o = function(e, n, t, r, o) {
                            var i = o;
                            if ("byAnswer" === o) {
                                var a = Array.isArray(r) ? r[0].answerIndex : r.answerIndex;
                                i = n.nextByAnswer[a]
                            }
                            if ("byOrder" === i || !i) return t + 1;
                            if (0 === i.indexOf("question:")) return function(e, n) {
                                for (var t = n.split(":")[1], r = 0; r < e.length; r++)
                                    if (t === e[r].uuid) return r
                            }(e, i);
                            if ("thankYou" === i) return e.length;
                            throw new Error("Unknown question logic value: " + i)
                        }(e.content.questions, P, l, t, r);
                    if (!sr()) {
                        ! function(e, n, t) {
                            if (!xr[n].isExternal) {
                                var r = (null == t ? void 0 : t.filter((function(e) {
                                    return "url" === e.component
                                }))) || [];
                                (null == t ? void 0 : t.some((function(e) {
                                    return "trigger" === e.component
                                }))) || !0 === hj.targeting.matchUrl(r, location.href) || hj.exceptions.log(new Error("Submitted a response out of URL targeting for survey ID: ".concat(e)), "response-out-of-targeting")
                            }
                        }(e.id, e.display_type, e.targeting);
                        var i = [].concat(I);
                        0 === i.length && i.push(P.uuid);
                        var a = e.content.questions[o];
                        a && i.push(a.uuid), z(i), j((function(t) {
                                var r = u[P.uuid],
                                    a = [].concat(t),
                                    s = !n && r ? function(e, n) {
                                        return Array.isArray(n) ? n.map((function(n) {
                                            return br(e, n)
                                        })) : [br(e, n)]
                                    }(P, r) : [];
                                !n && r && (a = a.concat(s), function(e, n, t) {
                                    var r = {
                                        id: e,
                                        questionUuid: yr(n.uuid),
                                        type: n.type.replace("_", "")
                                    };
                                    t && gr.indexOf(n.type) > -1 && (r.answer = t), hj.event.signal("poll.question", r)
                                }(e.id, P, r.answerText));
                                var c, d = hj.features.hasFeature("survey.screenshots") && e.auto_screenshot && (c = e.display_type, xr[c].allowsScreenshots) && !b,
                                    p = S();
                                return function(e, n, t, r, o, i, a) {
                                    var l = hj.settings.integrations.hubspot,
                                        s = {
                                            utk: l && l.enabled && l.send_surveys ? hj.bridge.storage.items.HUBSPOT_UTK.get() : null,
                                            response_content: hj.hq.stringify({
                                                version: 4,
                                                answers: t
                                            }),
                                            questions_seen: r,
                                            first_seen: hj.bridge.getSessionFirstSeen()
                                        };
                                    o ? function(e, n) {
                                        function t() {
                                            var e = hr(),
                                                n = e.top,
                                                t = e.left,
                                                r = fr(),
                                                o = r.width,
                                                i = r.height;
                                            return {
                                                width: o,
                                                height: i,
                                                viewport: [n, t, n + i, t + o]
                                            }
                                        }
                                        e ? hj.bridge.getPageContent((function(e, r) {
                                            n(vr(vr({}, t()), {}, {
                                                pageContent: e,
                                                projectId: r
                                            }))
                                        }), [".".concat(mr)]) : n(vr(vr({}, t()), {}, {
                                            pageContent: null
                                        }))
                                    }(o, (function(t) {
                                        var r = t.width,
                                            l = t.height,
                                            c = t.pageContent,
                                            u = t.viewport,
                                            d = t.projectId;
                                        o && (d ? (s.cs_page_content = c, s.cs_project_id = d) : s.page_content = c, s.selectors = ["html"], s.window_width = r, s.window_height = l, s.viewport = u), hj.request.savePollResponse(e, n, s, i, a)
                                    })) : hj.request.savePollResponse(e, n, s, i, a)
                                }(e.id, E, a, i, d, (function(n) {
                                    var t = n.poll_response_id;
                                    g(!0), sr() || (function(e, n, t, r, o) {
                                        var i = Dr([t], o);
                                        Ur({
                                            event: "surveySubmitted",
                                            surveyId: e,
                                            question: t,
                                            questionIndex: r,
                                            response: i,
                                            insightsUrl: Lr(e, n)
                                        })
                                    }(e.id, t, P, l, s), "always" === e.connect_visit_data && n.is_new_response && wr(e.id), o === e.content.questions.length && (function(e, n) {
                                        hj.request.completePollResponse(e, n)
                                    }(e.id, p), function(e, n, t, r) {
                                        var o = Dr(t, r);
                                        Ur({
                                            event: "surveyCompleted",
                                            surveyId: e,
                                            questions: t,
                                            responses: o,
                                            insightsUrl: void 0 === n ? void 0 : Lr(e, n)
                                        })
                                    }(e.id, t, e.content.questions, a)))
                                }), (function() {
                                    var n, t, r;
                                    n = e.id, t = e.content.questions, r = Dr(t, a), Ur({
                                        event: "surveyCompletedError",
                                        surveyId: n,
                                        questions: t,
                                        responses: r
                                    })
                                })), a
                            })),
                            function(e) {
                                "always" !== e.persist_condition && hj.bridge.storage.items.POLL_DONE.add(e.id)
                            }(e)
                    }
                    s(o), h(!1)
                };
                return {
                    state: {
                        questionIndex: l,
                        hasInteracted: _,
                        question: P,
                        answerValid: f,
                        isSubmitted: o,
                        isFinalStep: O,
                        isClosed: x
                    },
                    actions: {
                        onQuestionSkipped: function() {
                            return T(!0)
                        },
                        onQuestionSubmitted: function() {
                            return T(!1)
                        },
                        onAnswerChange: function(e, n) {
                            "__proto__" !== P.uuid && "constructor" !== P.uuid && (M(!0), h(e), d((function(e) {
                                var t, r = (t = e, Object.keys(t).reduce((function(e, n) {
                                    return e[n] = t[n], e
                                }), {}));
                                return r[P.uuid] = n, r
                            })))
                        },
                        onClose: function() {
                            var n;
                            k(!0), n = e.id, Ur({
                                event: "surveyClosed",
                                surveyId: n,
                                insightsUrl: Nr(n)
                            })
                        },
                        setInteracted: M,
                        setQuestionIndex: s
                    }
                }
            }

            function $r(e, n) {
                var t, r, o = parseInt(null !== (t = e.getAttribute("tabindex")) && void 0 !== t ? t : "0"),
                    i = parseInt(null !== (r = n.getAttribute("tabindex")) && void 0 !== r ? r : "0");
                return o === i ? 0 : -1 === o ? -1 : -1 === i ? 1 : 0 === o ? -1 : 0 === i ? 1 : o - i
            }
            var Zr = ["a[href]", "area[href]", "button:not(:disabled)", "iframe", 'input:not(:disabled):not([type="hidden"])', "select:not(:disabled)", "textarea:not(:disabled)", "[tabindex]"].map((function(e) {
                    return e.concat(':not([tabindex="-1"]):not([data-skip-autofocus="true"])')
                })).join(", "),
                Wr = (t(63), Wn((function(e, n) {
                    var t = e.styles,
                        r = $n([t], void 0, Y(Gn)),
                        o = X();
                    return V((function() {
                        var e = n.key + "-global",
                            t = new ze({
                                key: e,
                                nonce: n.sheet.nonce,
                                container: n.sheet.container,
                                speedy: n.sheet.isSpeedy
                            }),
                            i = !1,
                            a = document.querySelector('style[data-emotion="' + e + " " + r.name + '"]');
                        return n.sheet.tags.length && (t.before = n.sheet.tags[0]), null !== a && (i = !0, a.setAttribute("data-emotion", e), t.hydrate([a])), o.current = [t, i],
                            function() {
                                t.flush()
                            }
                    }), [n]), V((function() {
                        var e = o.current,
                            t = e[0];
                        if (e[1]) e[1] = !1;
                        else {
                            if (void 0 !== r.next && Vn(n, r.next, !0), t.tags.length) {
                                var i = t.tags[t.tags.length - 1].nextElementSibling;
                                t.before = i, t.flush()
                            }
                            n.insert("", r, t, !1)
                        }
                    }), [n, r.name]), null
                })));

            function Gr() {
                for (var e = arguments.length, n = new Array(e), t = 0; t < e; t++) n[t] = arguments[t];
                return $n(n)
            }
            var Vr = function() {
                    var e = Gr.apply(void 0, arguments),
                        n = "animation-" + e.name;
                    return {
                        name: n,
                        styles: "@keyframes " + n + "{" + e.styles + "}",
                        anim: 1,
                        toString: function() {
                            return "_EMO_" + this.name + "_" + this.styles + "_EMO_"
                        }
                    }
                },
                Xr = function(e) {
                    var n = e.color;
                    return p("svg", {
                        "aria-hidden": !0,
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        "data-testid": "icon-close"
                    }, p("rect", {
                        width: "24",
                        height: "24",
                        fill: "#C4C4C4",
                        fillOpacity: "0.01"
                    }), p("path", {
                        d: "M16.781 7.21875C16.4893 6.92708 16.0164 6.92708 15.7248 7.21875L11.9998 10.9438L8.2748 7.21881C7.98313 6.92714 7.51024 6.92714 7.21857 7.21881C6.9269 7.51048 6.9269 7.98337 7.21857 8.27504L10.9435 12L7.21857 15.725C6.9269 16.0166 6.9269 16.4895 7.21857 16.7812C7.51024 17.0729 7.98313 17.0729 8.2748 16.7812L11.9998 13.0562L15.7248 16.7812C16.0164 17.0729 16.4893 17.0729 16.781 16.7812C17.0727 16.4896 17.0727 16.0167 16.781 15.725L13.056 12L16.781 8.27499C17.0727 7.98332 17.0727 7.51042 16.781 7.21875Z",
                        fill: n
                    }))
                },
                Jr = function(e) {
                    return p("svg", {
                        "aria-hidden": !0,
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        "data-testid": "icon-collapse"
                    }, p("path", {
                        d: "M17.8059 9.87186L13.2207 16.2912C12.6225 17.1287 11.3778 17.1287 10.7795 16.2912L6.19431 9.87186C5.48516 8.87905 6.19485 7.5 7.41491 7.5L16.5853 7.5C17.8054 7.5 18.5151 8.87906 17.8059 9.87186Z",
                        fill: e.color
                    }))
                };

            function Kr(e, n, t) {
                if (n && !Array.isArray(n) && "number" == typeof n.length) {
                    var r = n.length;
                    return Qr(n, void 0 !== t && t < r ? t : r)
                }
                return e(n, t)
            }

            function Yr(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return Qr(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? Qr(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Qr(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }
            var eo, no, to, ro, oo, io = hj.tryCatch((function(e) {
                    var n = {};
                    return Object.entries(e).forEach((function(e) {
                        var t = Kr(Yr, e, 2),
                            r = t[0],
                            o = t[1];
                        if (!o) throw new Error("Cannot convert undefined or null to object");
                        var i = {};
                        Object.entries(o).forEach((function(e) {
                            var n = Kr(Yr, e, 2),
                                t = n[0],
                                r = n[1];
                            if (null == r) throw new Error("Cannot read properties of undefined (reading 'trim')");
                            var o = t.split("-").map((function(e, n) {
                                    return 0 === n ? e : e.charAt(0).toUpperCase() + e.slice(1)
                                })).join(""),
                                a = r.toString().trim().replace(/\s*!?important\s*$/i, "");
                            "fontFamily" === o && (a = "".concat(a, ", ").concat(st.getFontFamily())), a = a.replace(/\s*!important\s*$/i, "");
                            var l = "".concat(a, " !important");
                            i[o] = l
                        })), n[r] = i
                    })), n
                }), "surveys.customCSS"),
                ao = function(e) {
                    return e ? e.replace(/\s*!important\w*\s*$/i, "").trim() : null
                };

            function lo(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var so, co, uo, po, fo, ho, mo, _o, vo, yo, bo = et.div(eo || (eo = lo(["\n    &&& {\n        display: flex;\n        justify-content: end;\n        cursor: pointer;\n    }\n"]))),
                go = et.button(no || (no = lo(["\n    && {\n        border: none;\n        background-color: transparent;\n        line-height: 0;\n\n        :hover {\n            cursor: pointer;\n\n            & path {\n                transition: fill 0.2s ease-in-out;\n                fill: ", ";\n            }\n        }\n\n        ", "\n    }\n"])), (function(e) {
                    return e.theme.iconHover
                }), (function(e) {
                    return e.isMinimized ? "width: 100%; svg { transform: rotate(180deg); };" : ""
                })),
                wo = et.div(to || (to = lo(["\n    display: flex;\n    ", "\n"])), (function(e) {
                    return e.isMinimized ? Gr(ro || (ro = lo(["\n                  display: flex;\n                  flex-direction: row;\n                  align-items: center;\n                  justify-content: space-between;\n              "]))) : ""
                })),
                xo = et.span(oo || (oo = lo(["\n    &&& {\n        font-size: 1em; // 16px\n        font-style: normal;\n        font-weight: 500 !important;\n        color: ", ";\n        text-align: left;\n        flex: 1;\n        padding-right: ", ";\n        white-space: nowrap;\n        overflow: hidden;\n        text-overflow: ellipsis;\n    }\n\n    &&&& {\n        ", ";\n    }\n"])), (function(e) {
                    return e.color
                }), st.spacer.x0pt5, (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.questionTitle
                })),
                ko = function(e) {
                    var n, t, r, o, i = e.questionText,
                        a = e.isMinimized,
                        l = e.showCloseButton,
                        s = e.toggleId,
                        c = e.onClick,
                        u = dt(),
                        d = ao(null === (n = u.customCSS) || void 0 === n || null === (t = n.dropdownArrow) || void 0 === t ? void 0 : t.color) || u.icon,
                        f = ao(null === (r = u.customCSS) || void 0 === r || null === (o = r.closeButton) || void 0 === o ? void 0 : o.color) || u.icon;
                    return p(bo, {
                        onClick: c
                    }, p(go, {
                        id: s,
                        "aria-label": a ? "".concat(hj.polls.translate("show_survey"), " - ").concat(i) : hj.polls.translate("hide_survey"),
                        isMinimized: a,
                        theme: u
                    }, p(wo, {
                        isMinimized: a
                    }, a && p(xo, {
                        color: u.title,
                        theme: u
                    }, i), l ? p(Xr, {
                        color: f
                    }) : p(Jr, {
                        color: d
                    }))))
                },
                jo = et.div(so || (co = ["\n    &&& {\n        z-index: calc(", ");\n        width: 100vw;\n        height: 100vh;\n        position: fixed;\n        bottom: 0;\n        left: 0;\n\n        background: ", ";\n        pointer-events: none;\n        opacity: 0;\n        transition: ", ";\n\n        ", "\n    }\n"], uo || (uo = co.slice(0)), so = Object.freeze(Object.defineProperties(co, {
                    raw: {
                        value: Object.freeze(uo)
                    }
                }))), st.maxIndex - 100, (function(e) {
                    return e.theme.overlay
                }), st.animation.property("opacity"), (function(e) {
                    var n = e.isVisible;
                    return e.isPreview ? "".concat(st.breakpoint.previewMobile, " {\n                ").concat(n && "pointer-events: auto; opacity: 1;", "\n            }") : "".concat(st.breakpoint.mobile, " {\n                ").concat(n && "pointer-events: auto; opacity: 1;", "\n            }")
                })),
                So = function(e) {
                    var n = e.isVisible,
                        t = e.isPreview,
                        r = e.onClick,
                        o = dt();
                    return p(jo, {
                        "aria-hidden": n ? "false" : "true",
                        onClick: r,
                        isVisible: n,
                        isPreview: t,
                        theme: o
                    })
                };

            function Co(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var Mo, Po, Oo, Ao = et.div(po || (po = Co(["\n    &&& {\n        z-index: ", ";\n        position: fixed;\n        bottom: 0;\n        ", ";\n    }\n"])), st.maxIndex, st.printNoDisplay),
                Io = et.div(fo || (fo = Co(["\n    display: flex;\n    opacity: ", ";\n    transition: opacity 0.2s;\n    flex-direction: column;\n    gap: ", ";\n"])), (function(e) {
                    return e.isMinimized ? "0" : "1"
                }), st.spacer.x2),
                zo = et.div(vo || (vo = Co(["\n    && {\n        display: flex;\n        flex-direction: column;\n        z-index: ", ";\n        background: ", ";\n        border-radius: ", " ", " 0 0;\n        padding: ", " ", ";\n        position: fixed;\n        bottom: 0;\n        max-height: 100vh !important;\n        overflow: auto;\n        transition: ", ", ", ";\n\n        ", "\n        ", "\n        ", "\n        * {\n            ", "\n            ", "\n        }\n\n        ", "\n\n        ", "\n        ", "\n    }\n"])), st.maxIndex, (function(e) {
                    return e.backgroundColor
                }), st.spacer.x1, st.spacer.x1, st.spacer.x2, st.spacer.x2pt5, st.animation.property("transform"), st.animation.property("width"), (function(e) {
                    var n = e.isMobile,
                        t = e.showBorder;
                    return n && t && Gr(yo || (yo = Co(["\n                border: 1px solid ", ";\n            "])), st.colors.ui_disabled)
                }), (function(e) {
                    var n = e.isMobile;
                    return e.showBorder && function(e) {
                        return Gr(mo || (mo = Co(["\n        box-shadow: ", ";\n    "])), e ? st.shadow.mobile : st.shadow.desktop)
                    }(n)
                }), (function(e) {
                    return n = e.isMinimized, t = e.isMobile, r = n ? "300px" : "344px", Gr(ho || (ho = Co(["\n        width: ", ";\n    "])), t ? "100vw" : r);
                    var n, t, r
                }), st.text.fontFamily(), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.survey
                }), (function(e) {
                    return function(e, n) {
                        var t = {
                            left: "left: ".concat(st.spacer.x3, "; right: auto;"),
                            right: "right: ".concat(st.spacer.x3, "; left: auto;")
                        };
                        return Gr(_o || (_o = Co(["\n        ", ";\n    "])), e ? "left: 0; right: 0;" : t[n])
                    }(e.isMobile, e.position)
                }), (function(e) {
                    return e.isClosed ? "display: none;" : ""
                }), (function(e) {
                    return e.isMinimized ? "transform: translateY(calc(100% - 44px))".concat("; padding-top: 10px;") : ""
                })),
                Eo = function(e) {
                    var n = e.children,
                        t = e.isClosed,
                        r = e.isFinalStep,
                        o = e.isMinimized,
                        i = e.showCloseButton,
                        a = e.question,
                        l = e.updateMinimizedState,
                        s = e.isMobile,
                        c = e.showBackdrop,
                        u = e.showBorder,
                        d = e.labelId,
                        f = void 0 === d ? "" : d,
                        h = e.toggleId,
                        m = void 0 === h ? "" : h,
                        _ = dt(),
                        v = r ? null : p(ko, {
                            questionText: a.text,
                            isMinimized: o,
                            showCloseButton: i,
                            toggleId: m,
                            onClick: l
                        });
                    return p(Ao, null, c && p(So, {
                        isVisible: !o && !t,
                        isPreview: sr(),
                        onClick: function() {
                            r || o || l()
                        }
                    }), p(zo, {
                        backgroundColor: _.background,
                        isMinimized: o,
                        isClosed: t,
                        position: _.position,
                        isMobile: s,
                        theme: _,
                        showBorder: u
                    }, o && v, p(Io, {
                        role: "dialog",
                        "aria-labelledby": f,
                        "aria-hidden": o,
                        isMinimized: o
                    }, !o && v, n)))
                },
                To = function(e) {
                    return p("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "24",
                        height: "22",
                        fill: "none",
                        viewBox: "0 0 24 22",
                        "data-testid": "icon-buddy"
                    }, p("path", {
                        fill: e.color,
                        fillRule: "evenodd",
                        d: "M22.362.827C21.72.5 20.88.5 19.2.5H3.3C1.755.5.983.5.575.819A1.5 1.5 0 000 1.969c-.01.517.453 1.135 1.38 2.371l1.14 1.52c.178.237.267.356.33.487a1.5 1.5 0 01.122.365C3 6.855 3 7.003 3 7.3v9.4c0 1.68 0 2.52.327 3.162a3 3 0 001.311 1.311c.642.327 1.482.327 3.162.327h11.4c1.68 0 2.52 0 3.162-.327a3 3 0 001.311-1.311C24 19.22 24 18.38 24 16.7V5.3c0-1.68 0-2.52-.327-3.162a3 3 0 00-1.31-1.311zM9.277 11.937a1.125 1.125 0 00-1.948 1.126 7.123 7.123 0 006.171 3.562 7.123 7.123 0 006.171-3.562 1.125 1.125 0 10-1.947-1.126 4.872 4.872 0 01-4.224 2.438 4.873 4.873 0 01-4.223-2.438zM10.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM18 9.5a1.5 1.5 0 100-3 1.5 1.5 0 000 3z",
                        clipRule: "evenodd"
                    }))
                },
                No = et.button(Mo || (Mo = function(e, n) {
                    return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(n)
                        }
                    }))
                }(["\n    && {\n        position: fixed;\n        width: ", ";\n        height: ", ";\n\n        border-radius: 50%;\n        background-color: ", ";\n        border: none;\n        box-shadow: 0 2px 32px 0 rgba(0, 0, 0, 0.15), 0 1px 6px 0 rgba(0, 0, 0, 0.06);\n\n        bottom: ", ";\n        ", "\n        ", "\n\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        transition: ", ", ", ";\n\n        cursor: pointer;\n\n        &:hover {\n            width: ", ";\n            height: ", ";\n        }\n\n        svg {\n            transition: ", ";\n            height: auto;\n            width: auto;\n        }\n\n        &:hover svg {\n            transform: scale(1.33); // from design: 32px / 24px = 1.33\n        }\n    }\n"])), st.spacer.x7pt5, st.spacer.x7pt5, (function(e) {
                    return e.theme.button
                }), st.spacer.x3, (function(e) {
                    return "bottom_left" === e.theme.position ? "left: ".concat(st.spacer.x3, ";") : ""
                }), (function(e) {
                    return "bottom_right" === e.theme.position ? "right: ".concat(st.spacer.x3, ";") : ""
                }), st.animation.property("height"), st.animation.property("width"), st.spacer.x8, st.spacer.x8, st.animation.property("transform")),
                Lo = function(e) {
                    var n, t, r, o, i = e.isMinimized,
                        a = e.isShowingOnce,
                        l = e.toggleId,
                        s = e.onClick,
                        c = dt(),
                        u = ao(null === (n = c.customCSS) || void 0 === n || null === (t = n.dropdownArrow) || void 0 === t ? void 0 : t.color) || c.buttonText,
                        d = ao(null === (r = c.customCSS) || void 0 === r || null === (o = r.closeButton) || void 0 === o ? void 0 : o.color) || c.buttonText;
                    return p(No, {
                        id: l,
                        "aria-label": i ? hj.polls.translate("show_survey") : hj.polls.translate("hide_survey"),
                        isMinimized: i,
                        theme: c,
                        onClick: s
                    }, i ? p(To, {
                        color: c.buttonText
                    }) : a ? p(Xr, {
                        color: d
                    }) : p(Jr, {
                        color: u
                    }))
                };

            function Fo(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var Do, Uo, Bo, Ro, Ho, qo, $o, Zo, Wo = et.div(Oo || (Oo = Fo(["\n    && {\n        cursor: pointer;\n        text-align: right;\n\n        ", "\n    }\n"])), (function(e) {
                    return n = e.isPreviewMode, t = e.forceMobilePreview, r = "none", o = "block", i = function(e) {
                        return t ? o : n ? r : e
                    }, Gr(Po || (Po = Fo(["\n        display: ", ";\n\n        ", " {\n            display: ", ";\n        }\n    "])), i(o), st.breakpoint.desktop, i(r));
                    var n, t, r, o, i
                })),
                Go = function(e) {
                    var n, t, r, o, i = e.isShowingOnce,
                        a = e.isPreviewMode,
                        l = e.forceMobilePreview,
                        s = e.onClick,
                        c = dt(),
                        u = ao(null === (n = c.customCSS) || void 0 === n || null === (t = n.dropdownArrow) || void 0 === t ? void 0 : t.color) || c.buttonText,
                        d = ao(null === (r = c.customCSS) || void 0 === r || null === (o = r.closeButton) || void 0 === o ? void 0 : o.color) || c.buttonText;
                    return p(Wo, {
                        onClick: s,
                        role: "button",
                        isPreviewMode: a,
                        forceMobilePreview: l
                    }, i ? p(Xr, {
                        color: d
                    }) : p(Jr, {
                        color: u
                    }))
                };

            function Vo(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var Xo, Jo, Ko, Yo = et.div(Do || (Do = Vo(["\n    &&& {\n        z-index: ", ";\n        position: fixed;\n        bottom: 0;\n        ", ";\n    }\n"])), st.maxIndex, st.printNoDisplay),
                Qo = et.div(Zo || (Zo = Vo(["\n    && {\n        display: ", ";\n        flex-direction: column;\n        z-index: ", ";\n        background: ", ";\n        padding: ", " ", " ", ";\n        position: fixed;\n        bottom: 100px;\n        transition: ", ";\n        opacity: ", ";\n\n        * {\n            ", "\n            ", "\n        }\n\n        pointer-events: ", ";\n\n        ", "\n        ", "\n    }\n"])), (function(e) {
                    return e.isClosed ? "none" : "flex"
                }), st.maxIndex, (function(e) {
                    return e.backgroundColor
                }), st.spacer.x2, st.spacer.x2pt5, st.spacer.x1pt5, st.animation.property("opacity"), (function(e) {
                    return e.isMinimized ? 0 : 1
                }), st.text.fontFamily(), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.survey
                }), (function(e) {
                    return e.isMinimized ? "none" : "auto"
                }), (function(e) {
                    return function(e, n) {
                        var t = "344px",
                            r = "100vw",
                            o = "100px",
                            i = "".concat(st.spacer.x1),
                            a = "".concat(st.spacer.x1, " ").concat(st.spacer.x1, " 0 0"),
                            l = "calc(100vh - ".concat(o, ")"),
                            s = "100vh",
                            c = function(t, r, o) {
                                return n ? r : e ? o : t
                            };
                        return Gr(Uo || (Uo = Vo(["\n        width: ", ";\n        bottom: ", ";\n        box-shadow: ", ";\n        border-radius: ", ";\n        max-height: ", " !important;\n\n        ", " {\n            width: ", ";\n            bottom: ", ";\n            box-shadow: ", ";\n            border-radius: ", ";\n            max-height: ", " !important;\n        }\n    "])), c(r, r, t), c("0", "0", o), c(st.shadow.mobile, st.shadow.mobile, st.shadow.desktop), c(a, a, i), c(s, s, l), st.breakpoint.desktop, c(t, r, t), c(o, "0", o), c(st.shadow.desktop, st.shadow.mobile, st.shadow.desktop), c(i, a, i), c(l, s, l))
                    }(e.isPreviewMode, e.forceMobilePreview)
                }), (function(e) {
                    return n = e.isPreviewMode, t = e.forceMobilePreview, r = e.positionLeft, o = e.positionRight, t ? Gr(Bo || (Bo = Vo(["\n            left: 0;\n            right: 0;\n        "]))) : n ? r ? Gr(Ro || (Ro = Vo(["\n                left: ", ";\n                right: auto;\n            "])), st.spacer.x3) : o ? Gr(Ho || (Ho = Vo(["\n                right: ", ";\n                left: auto;\n            "])), st.spacer.x3) : Gr(qo || (qo = Vo(["\n            ", "\n            ", "\n        "])), r ? "left: 0;" : "", o ? "right: 0;" : "") : Gr($o || ($o = Vo(["\n        left: 0;\n        right: 0;\n\n        ", " {\n            left: ", ";\n            right: ", ";\n        }\n    "])), st.breakpoint.desktop, r ? st.spacer.x3 : "auto", o ? st.spacer.x3 : "auto");
                    var n, t, r, o
                })),
                ei = function(e) {
                    var n = e.isClosed,
                        t = e.isFinalStep,
                        r = e.isMinimized,
                        o = e.isShowingOnce,
                        i = e.updateMinimizedState,
                        a = e.isMobilePreview,
                        l = e.children,
                        s = e.uniqueId,
                        c = e.labelId,
                        u = void 0 === c ? "" : c,
                        d = e.toggleId,
                        f = void 0 === d ? "" : d,
                        h = dt(),
                        m = !t && !n;
                    return p(Yo, null, p(So, {
                        isVisible: !r && !n,
                        isPreview: sr(),
                        onClick: function() {
                            t || r || i()
                        }
                    }), m && r && p(Lo, {
                        isMinimized: !0,
                        isShowingOnce: o,
                        onClick: i,
                        toggleId: f
                    }), p("div", {
                        role: "dialog",
                        "aria-labelledby": u,
                        "aria-hidden": r
                    }, m && !r && p(Lo, {
                        isMinimized: !1,
                        isShowingOnce: o,
                        onClick: i,
                        toggleId: f
                    }), p(Qo, {
                        backgroundColor: h.background,
                        isMinimized: r,
                        isClosed: n,
                        positionLeft: "bottom_left" === h.position,
                        positionRight: "bottom_right" === h.position,
                        isPreviewMode: sr(),
                        forceMobilePreview: a,
                        theme: h
                    }, p(Go, {
                        isShowingOnce: o,
                        onClick: i,
                        isPreviewMode: sr(),
                        forceMobilePreview: a,
                        uniqueId: s
                    }), l)))
                },
                ni = function(e) {
                    var n = e.color;
                    return p("svg", {
                        width: "13",
                        height: "12",
                        viewBox: "0 0 13 12",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }, p("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M11.634 3.30574C11.7889 3.46361 11.7892 3.71984 11.6346 3.87804L7.0458 8.57419C6.97628 8.64852 6.89287 8.70794 6.80045 8.74888C6.70575 8.79084 6.60362 8.8125 6.50037 8.8125C6.39712 8.8125 6.29499 8.79084 6.20029 8.74888C6.10786 8.70794 6.02445 8.64852 5.95493 8.57419L1.36613 3.87804C1.21156 3.71984 1.21181 3.46361 1.3667 3.30574C1.52159 3.14786 1.77247 3.14812 1.92705 3.30632L6.50037 7.98662L11.0737 3.30632C11.2283 3.14812 11.4791 3.14786 11.634 3.30574Z",
                        fill: n,
                        stroke: n,
                        strokeWidth: "0.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }))
                },
                ti = function(e) {
                    var n = e.color;
                    return p("svg", {
                        "aria-hidden": !0,
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "24",
                        height: "24",
                        viewBox: "4 4 16 16",
                        fill: "none",
                        "data-testid": "icon-close"
                    }, p("rect", {
                        width: "24",
                        height: "24",
                        fill: "#C4C4C4",
                        fillOpacity: "0.01"
                    }), p("path", {
                        d: "M16.781 7.21875C16.4893 6.92708 16.0164 6.92708 15.7248 7.21875L11.9998 10.9438L8.2748 7.21881C7.98313 6.92714 7.51024 6.92714 7.21857 7.21881C6.9269 7.51048 6.9269 7.98337 7.21857 8.27504L10.9435 12L7.21857 15.725C6.9269 16.0166 6.9269 16.4895 7.21857 16.7812C7.51024 17.0729 7.98313 17.0729 8.2748 16.7812L11.9998 13.0562L15.7248 16.7812C16.0164 17.0729 16.4893 17.0729 16.781 16.7812C17.0727 16.4896 17.0727 16.0167 16.781 15.725L13.056 12L16.781 8.27499C17.0727 7.98332 17.0727 7.51042 16.781 7.21875Z",
                        fill: n
                    }))
                };

            function ri(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var oi, ii, ai, li = et.button(Xo || (Xo = ri(["\n    && {\n        display: flex;\n        position: absolute;\n        width: fit-content;\n        height: ", "px;\n        padding: 0 ", ";\n        white-space: nowrap;\n        justify-content: center;\n        align-items: center;\n        border-radius: ", ";\n        border: 0;\n        cursor: pointer;\n        background: ", " !important;\n        color: ", " !important;\n        fill: ", " !important;\n        font-size: 1em;\n        bottom: ", ";\n        gap: 10px;\n        transform-origin: bottom center;\n        pointer-events: all;\n\n        &:focus-visible {\n            ", "\n            outline: none !important;\n        }\n\n        ", "\n\n        ", "\n    }\n"])), 38, st.spacer.x2pt5, (function(e) {
                    return "middle_left" === e.position ? "0 0 6px 6px" : "6px 6px 0 0"
                }), (function(e) {
                    return e.theme.button
                }), (function(e) {
                    return e.theme.buttonText
                }), (function(e) {
                    return e.theme.buttonText
                }), (function(e) {
                    return e.position.includes("middle_") ? "50%" : "".concat(0, "px")
                }), (function(e) {
                    var n = e.theme;
                    return "box-shadow: 0 0 0 1px ".concat(n.buttonText, ", 0 0 0 3px ").concat(n.button, " !important;")
                }), (function(e) {
                    return function(e, n, t, r) {
                        var o = "fixed",
                            i = "absolute",
                            a = function(e, n) {
                                switch (e) {
                                    case "middle_left":
                                        return "\n                left: 0px;\n                right: auto;\n                transform: translate(calc(-50% + ".concat(38, "px), 0) rotate(-90deg);");
                                    case "middle_right":
                                        return "\n                left: auto;\n                right: 0px;\n                transform: translate(50%, 0) rotate(-90deg);";
                                    default:
                                        return "\n                top: ".concat(n ? "auto" : "-".concat(38, "px"), ";\n                bottom: ").concat(n ? "0px" : "auto", ";\n                right: ").concat(e.includes("_right") ? st.spacer.x3 : "auto", ";\n                left: ").concat(e.includes("_left") ? st.spacer.x3 : "auto", ";")
                                }
                            }(t, r),
                            l = function(e) {
                                switch (e) {
                                    case "middle_left":
                                        return "\n                left: auto;\n                right: 0px;\n                transform: translate(calc(50% + ".concat(38, "px), 0) rotate(-90deg);");
                                    case "middle_right":
                                        return "\n                right: auto;\n                left: 0px;\n                transform: translate(-50%, 0) rotate(-90deg);\n            ";
                                    default:
                                        return "\n                top: -".concat(38, "px;\n                ").concat(e.includes("_right") ? "margin-right: ".concat(st.spacer.x2) : "margin-left: ".concat(st.spacer.x2), "\n            ")
                                }
                            }(t),
                            s = function(t, r, o) {
                                return n ? r : e ? o : t
                            };
                        return "\n        position: ".concat(s(o, o, i), ";\n        ").concat(s(a, a, l), ";\n\n        ").concat(st.breakpoint.desktop, " {\n            position: ").concat(s(i, o, i), ";\n            ").concat(s(l, a, l), ";\n        }\n    ")
                    }(e.isPreviewMode, e.forceMobilePreview, e.position, e.isMinimized)
                }), (function(e) {
                    var n = e.isMinimized,
                        t = e.isPreviewMode,
                        r = e.forceMobilePreview;
                    return n ? "" : function(e, n) {
                        var t = "flex",
                            r = "none",
                            o = function(o) {
                                return n ? r : e ? t : o
                            };
                        return "\n        display: ".concat(o(r), ";\n\n        ").concat(st.breakpoint.desktop, " {\n            display: ").concat(o(t), ";\n        }\n    ")
                    }(t, r)
                })),
                si = et.div(Jo || (Jo = ri(["\n    && {\n        display: flex;\n        width: 1em;\n        height: 1em;\n        align-items: center;\n        justify-content: center;\n\n        ", "\n    }\n"])), (function(e) {
                    return function(e, n) {
                        var t = e.includes("bottom_"),
                            r = e.includes("_left");
                        return t ? "" : "transform: rotate(".concat(n ? "90deg" : r ? "180deg" : "0", ");")
                    }(e.position, e.isMinimized)
                })),
                ci = et.span(Ko || (Ko = ri(["\n    && {\n        color: ", ";\n        ", ";\n        font-size: 1em;\n    }\n\n    &&& {\n        ", ";\n        ", ";\n    }\n"])), (function(e) {
                    return e.theme.buttonText
                }), st.text.fontFamily("Ambit"), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.survey
                }), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.surveyButton
                })),
                ui = function(e) {
                    var n, t = e.buttonLabel || hj.polls.translate("feedback"),
                        r = e.isMinimized ? hj.polls.translate("show_survey") : e.isShowingOnce ? hj.polls.translate("close_survey") : hj.polls.translate("hide_survey"),
                        o = dt();
                    return p(li, {
                        position: e.position,
                        theme: o,
                        "aria-label": "".concat(t, " - ").concat(r),
                        onClick: e.updateMinimizedState,
                        ref: e.buttonRef,
                        id: null !== (n = e.toggleId) && void 0 !== n ? n : "",
                        isMinimized: e.isMinimized,
                        isPreviewMode: e.isPreviewMode,
                        forceMobilePreview: e.forceMobilePreview
                    }, p(si, {
                        position: e.position,
                        isMinimized: e.isMinimized
                    }, e.isMinimized ? p(To, {
                        color: o.buttonText
                    }) : e.isShowingOnce ? p(ti, {
                        color: o.buttonText
                    }) : p(ni, {
                        color: o.buttonText
                    })), p(ci, {
                        theme: o
                    }, t || hj.polls.translate("feedback")))
                };

            function di(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var pi, fi, hi, mi, _i, vi, yi, bi, gi, wi, xi, ki, ji, Si, Ci, Mi, Pi, Oi, Ai, Ii, zi, Ei = et.div(ii || (ii = di(["\n    && {\n        justify-content: flex-end;\n        margin: ", " 0 -", " 0;\n        ", "\n    }\n"])), st.spacer.x2, st.spacer.x1, (function(e) {
                    return n = e.isPreviewMode, t = e.forceMobilePreview, r = "none", o = "flex", i = function(e) {
                        return t ? o : n ? r : e
                    }, Gr(oi || (oi = di(["\n        display: ", ";\n\n        ", " {\n            display: ", ";\n        }\n    "])), i(o), st.breakpoint.desktop, i(r));
                    var n, t, r, o, i
                })),
                Ti = et.button(ai || (ai = di(["\n    && {\n        display: flex;\n        background-color: transparent;\n        border: 0;\n        cursor: pointer;\n    }\n"]))),
                Ni = function(e) {
                    var n, t, r, o, i = e.isPreviewMode,
                        a = e.forceMobilePreview,
                        l = e.isShowingOnce,
                        s = e.onClick,
                        c = dt(),
                        u = ao(null === (n = c.customCSS) || void 0 === n || null === (t = n.dropdownArrow) || void 0 === t ? void 0 : t.color) || c.icon,
                        d = ao(null === (r = c.customCSS) || void 0 === r || null === (o = r.closeButton) || void 0 === o ? void 0 : o.color) || c.icon;
                    return p(Ei, {
                        isPreviewMode: i,
                        forceMobilePreview: a
                    }, p(Ti, {
                        onClick: s
                    }, l ? p(Xr, {
                        color: d
                    }) : p(Jr, {
                        color: u
                    })))
                };

            function Li(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return Fi(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? Fi(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Fi(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }

            function Di(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var Ui, Bi, Ri, Hi = Vr(pi || (pi = Di(["\n    from { opacity: 0; }\n    to { opacity: 1; }\n"]))),
                qi = Vr(fi || (fi = Di(["\n    from { opacity: 1 }\n    to { opacity: 0 }\n"]))),
                $i = et.div(yi || (yi = Di(["\n    &&& {\n        z-index: ", ";\n        position: fixed;\n        left: 0;\n        right: 0;\n        ", ";\n    }\n"])), st.maxIndex, st.printNoDisplay),
                Zi = Vr(bi || (bi = Di(["\n    from { transform: translate(-100%, -50%); }\n    to { transform: translate(0, -50%); }\n"]))),
                Wi = Vr(gi || (gi = Di(["\n    from { transform: translate(100%, -50%); }\n    to { transform: translate(0, -50%); }\n"]))),
                Gi = Vr(Si || (Si = Di(["\n    from { transform: translateY(100%) }\n    to { transform: translateY(0) }\n"]))),
                Vi = et.div(Ai || (Ai = Di(["\n    && {\n        ", "\n    }\n"])), (function(e) {
                    return function(e, n, t, r, o) {
                        var i = r.includes("_left"),
                            a = r.includes("bottom_"),
                            l = "\n        bottom: 0;\n        animation: none;\n    ",
                            s = Gr(Ci || (Ci = Di(["\n        display: flex;\n        ", "\n        ", "\n    "])), a ? Gr(Mi || (Mi = Di(["\n                  padding: 0 ", ";\n                  transform: translateY(", ");\n                  animation: ", ";\n                  ", "\n              "])), st.spacer.x3, t ? "100%" : "0", o ? Gr(Pi || (Pi = Di(["\n                            ", " 0.3s ease-in-out ", "\n                        "])), Gi, t ? "reverse" : "") : "none", i ? "left: 0;" : "right: 0;") : "", function(e, n, t) {
                                switch (e) {
                                    case "middle_right":
                                        return Gr(wi || (wi = Di(["\n                bottom: auto;\n                top: 50%;\n                right: 0px;\n                transform: translate(", ", -50%);\n                animation: ", ";\n            "])), n ? "100%" : "0", t ? Gr(xi || (xi = Di(["\n                          ", " 0.3s ease-in-out ", "\n                      "])), Wi, n ? "reverse" : "") : "none");
                                    case "middle_left":
                                        return Gr(ki || (ki = Di(["\n                bottom: auto;\n                top: 50%;\n                left: 0px;\n                transform: translate(", ", -50%);\n                animation: ", ";\n            "])), n ? "-100%" : "0", t ? Gr(ji || (ji = Di(["\n                          ", " 0.3s ease-in-out ", "\n                      "])), Zi, n ? "reverse" : "") : "none");
                                    default:
                                        return ""
                                }
                            }(r, t, o)),
                            c = function(t, r, o) {
                                return n ? r : e ? o : t
                            };
                        return Gr(Oi || (Oi = Di(["\n        position: fixed;\n        width: fit-content;\n        pointer-events: ", ";\n        z-index: ", ";\n        max-width: 100%;\n\n        ", "\n\n        ", " {\n            ", "\n        }\n    "])), t ? "none" : "initial", st.maxIndex, c(l, l, s), st.breakpoint.desktop, c(s, l, s))
                    }(e.isPreviewMode, e.forceMobilePreview, e.isMinimized, e.position, e.shouldAnimate)
                })),
                Xi = et.div(zi || (zi = Di(["\n    && {\n        display: ", ";\n        flex-direction: column;\n        background: ", ";\n        padding: ", " ", ";\n\n        * {\n            ", "\n            ", "\n        }\n\n        ", "\n        ", "\n        ", "\n        ", "\n    }\n"])), (function(e) {
                    return e.isClosed ? "none" : "flex"
                }), (function(e) {
                    return e.backgroundColor
                }), st.spacer.x2, st.spacer.x2pt5, st.text.fontFamily(), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.survey
                }), (function(e) {
                    var n = e.position;
                    return n.includes("_left") ? "left: ".concat(n.includes("middle_") ? 0 : st.spacer.x3, ";") : ""
                }), (function(e) {
                    var n = e.position;
                    return n.includes("_right") ? "right: ".concat(n.includes("middle_") ? 0 : st.spacer.x3, ";") : ""
                }), (function(e) {
                    return function(e, n, t, r, o) {
                        var i, a, l = null !== (i = null == o || null === (a = o.current) || void 0 === a ? void 0 : a.getBoundingClientRect()) && void 0 !== i ? i : {
                                width: 0,
                                height: 0
                            },
                            s = t.includes("middle_"),
                            c = t.includes("_left"),
                            u = l.width + 16 > 344 && !s ? "".concat(l.width + 32, "px") : "".concat(344, "px"),
                            d = "100vw",
                            p = "".concat(st.spacer.x1, " ").concat(st.spacer.x1, " 0 0"),
                            f = "".concat(function(e, n) {
                                return e ? n ? "0 ".concat(st.spacer.x1, " ").concat(st.spacer.x1, " 0") : "".concat(st.spacer.x1, " 0 0 ").concat(st.spacer.x1) : "".concat(st.spacer.x1, " ").concat(st.spacer.x1, " 0 0")
                            }(s, c), ";"),
                            h = function(t, r, o) {
                                return n ? r : e ? o : t
                            };
                        return Gr(Ii || (Ii = Di(["\n        width: ", ";\n        box-shadow: ", ";\n        border-radius: ", ";\n        min-height: ", ";\n        max-height: 100vh !important;\n        max-width: 100%;\n\n        ", " {\n            width: ", ";\n            box-shadow: ", ";\n            border-radius: ", ";\n            min-height: ", ";\n        }\n    "])), h(d, d, u), r ? "" : h(st.shadow.mobile, st.shadow.mobile, st.shadow.desktop), h(p, p, f), h("".concat(l.height + 32, "px"), "auto", "".concat(l.height + 32, "px")), st.breakpoint.desktop, h(u, d, u), r ? "" : h(st.shadow.desktop, st.shadow.mobile, st.shadow.desktop), h(f, p, f), h("".concat(l.height + 32, "px"), "auto", "".concat(l.height + 32, "px")))
                    }(e.isPreviewMode, e.forceMobilePreview, e.position, e.isMinimized, e.buttonRef)
                }), (function(e) {
                    return function(e, n, t, r) {
                        var o = Gr(hi || (hi = Di(["\n        opacity: ", ";\n        ", "\n    "])), t ? 0 : 1, r ? t ? Gr(mi || (mi = Di(["\n                      animation: ", " 0.3s ease-in-out;\n                  "])), qi) : Gr(_i || (_i = Di(["\n                      animation: ", " 0.3s ease-in-out;\n                  "])), Hi) : ""),
                            i = "\n        animation: none;\n        opacity: 1;\n    ",
                            a = function(t, r, o) {
                                return n ? r : e ? o : t
                            };
                        return Gr(vi || (vi = Di(["\n        ", "\n\n        ", " {\n            ", "\n        }\n    "])), a(o, o, i), st.breakpoint.desktop, a(i, o, i))
                    }(e.isPreviewMode, e.forceMobilePreview, e.isMinimized, e.shouldAnimate)
                })),
                Ji = function(e) {
                    var n = e.isClosed,
                        t = e.isFinalStep,
                        r = e.isMinimized,
                        o = e.isShowingOnce,
                        i = e.toggleId,
                        a = e.updateMinimizedState,
                        l = e.isMobilePreview,
                        s = e.children,
                        c = e.labelId,
                        u = void 0 === c ? "" : c,
                        d = e.surveyBodyRef,
                        f = e.buttonLabel,
                        h = e.buttonRef,
                        m = dt(),
                        _ = function(e, n, t) {
                            if (n && !Array.isArray(n) && "number" == typeof n.length) {
                                var r = n.length;
                                return Fi(n, 2 < r ? 2 : r)
                            }
                            return e(n, 2)
                        }(Li, W(!1)),
                        v = _[0],
                        y = _[1],
                        b = function() {
                            y(!0), a(), setTimeout((function() {
                                return y(!1)
                            }), 300)
                        };
                    return p($i, null, p(So, {
                        isVisible: !r && !n,
                        isPreview: sr(),
                        onClick: function() {
                            t || r || b()
                        }
                    }), p(Vi, {
                        isMinimized: r,
                        position: m.position,
                        isPreviewMode: sr(),
                        forceMobilePreview: l,
                        shouldAnimate: v
                    }, r ? p(ui, {
                        buttonLabel: f,
                        updateMinimizedState: b,
                        position: m.position,
                        buttonRef: h,
                        isMinimized: r,
                        isShowingOnce: o,
                        toggleId: i,
                        isPreviewMode: sr(),
                        forceMobilePreview: l
                    }) : null, p("div", {
                        role: "dialog",
                        "aria-labelledby": u,
                        "aria-hidden": r,
                        ref: d
                    }, p("div", {
                        id: "innerLayer"
                    }, r || t || n ? null : p(ui, {
                        position: m.position,
                        buttonLabel: f,
                        toggleId: i,
                        isMinimized: r,
                        isShowingOnce: o,
                        buttonRef: h,
                        updateMinimizedState: b,
                        isPreviewMode: sr(),
                        forceMobilePreview: l
                    }), p(Xi, {
                        backgroundColor: m.background,
                        isMinimized: r,
                        isClosed: n,
                        position: m.position,
                        isPreviewMode: sr(),
                        forceMobilePreview: l,
                        buttonRef: h,
                        shouldAnimate: v,
                        theme: m
                    }, p(Ni, {
                        isPreviewMode: sr(),
                        forceMobilePreview: l,
                        onClick: b,
                        isShowingOnce: o
                    }), s)))))
                },
                Ki = function(e) {
                    if (e) {
                        if (e.startsWith("data:image") || e.startsWith("blob:") || e.startsWith("http")) return e;
                        var n = "live" === hj.environment ? hj.surveyImagesHost : "d23waydkwbngmu.cloudfront.net";
                        return "https://".concat(n, "/").concat(e)
                    }
                },
                Yi = et.div(Ui || (Ui = function(e, n) {
                    return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(n)
                        }
                    }))
                }(["\n    && {\n        display: flex;\n        justify-content: space-between;\n        align-items: flex-start;\n        margin-bottom: ", ";\n\n        p {\n            text-align: left;\n            color: ", " !important;\n            ", ";\n            font-size: 0.875em !important; // 14x;\n        }\n        a {\n            margin-left: 8px;\n            white-space: nowrap;\n            color: ", " !important;\n            ", ";\n            font-size: 0.875em !important; // 14x;\n        }\n    }\n"])), st.spacer.x2, (function(e) {
                    return e.theme.textLight
                }), st.text.body2, (function(e) {
                    return e.theme.textLight
                }), st.text.body2),
                Qi = function(e) {
                    var n = e.showLegal,
                        t = dt();
                    if (!n) return null;
                    var r = hj.settings,
                        o = r.legal_name,
                        i = r.privacy_policy_url;
                    return p(Yi, {
                        theme: t
                    }, p("p", null, o), null !== i && p("a", {
                        href: i,
                        target: "_blank",
                        rel: "noopener noreferrer"
                    }, hj.polls.translate("privacy_policy")))
                };

            function ea(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var na, ta, ra, oa = function(e) {
                    return "\n    &&& {\n        border-radius: ".concat(st.spacer.x0pt5, ";\n        border: none;\n        padding: 10px ").concat(st.spacer.x2, ";\n        transition: all 0.2s ease-in-out;\n        cursor: pointer;\n        ").concat(st.text.subtitle2, ";\n        text-align: center;\n        font-size: 0.875em !important;\n\n        &:focus-visible {\n            box-shadow: 0px 0px 0px 1px ").concat(e.background, ", 0px 0px 0px 3px ").concat(e.buttonOutline, ";\n            outline: none;\n        }\n\n        &:active {\n            box-shadow: inset 0px 2px 4px rgba(45, 54, 66, 0.07), inset 0px 1px 2px rgba(45, 54, 66, 0.07);\n        }\n\n        &:disabled {\n            color: ").concat(e.disabledText, " !important;\n            cursor: not-allowed;\n        }\n")
                },
                ia = {
                    primary: function(e) {
                        return function(e) {
                            return "\n    background-color: ".concat(e.button, " !important;\n    color: ").concat(e.buttonText, " !important;\n\n    &:hover,&:hover:enabled {\n        background-color: ").concat(e.buttonHover, " !important;\n        color: ").concat(e.buttonTextHover, " !important;\n    };\n    &:focus-visible {\n        background-color: ").concat(e.button, ";\n    };\n    &:disabled {\n        background-color: ").concat(e.disabled, " !important;\n        color: ").concat(e.disabledText, " !important;\n    };\n")
                        }(e)
                    },
                    secondary: function(e) {
                        return function(e) {
                            return "\n    &&& {\n        background-color: ".concat(e.background, ";\n        box-shadow: ").concat(e.button, " 0px 0px 0px 1px inset;\n        color: ").concat(e.buttonSecondaryText, " !important;\n\n    &:hover:enabled {\n        box-shadow: ").concat(e.buttonHover, " 0px 0px 0px 2px inset;\n        color: ").concat(e.buttonSecondaryText, " !important;\n    };\n    &:focus-visible {\n        color: ").concat(e.buttonSecondaryText, " !important;\n        box-shadow: 0 0 0 1px ").concat(e.background, ", 0 0 0 3px ").concat(e.buttonOutline, ", inset 0 0 0 2px ").concat(e.buttonHover, ";\n    }\n\n    &:disabled {\n        box-shadow: none;\n        background-color: ").concat(e.disabled, " !important;\n        color: ").concat(e.disabledText, ";\n    };\n\n")
                        }(e)
                    },
                    ghost: function(e) {
                        return function(e) {
                            return "\n    background-color: transparent;\n    color: ".concat(e.ghostButtonText, " !important;\n\n    &:hover:enabled {\n        background-color: ").concat(e.ghostButtonHover, ";\n    };\n\n    &:focus-visible {\n        box-shadow: 0px 0px 0px 1px ").concat(e.background, ", 0px 0px 0px 3px ").concat(e.buttonOutline, ";\n\n    }\n")
                        }(e)
                    }
                },
                aa = "padding: 10px ".concat(st.spacer.x2, ";"),
                la = "padding: 6px ".concat(st.spacer.x2, ";"),
                sa = "white-space: nowrap",
                ca = {
                    m: aa,
                    s: la
                },
                ua = et.button(Bi || (Bi = ea(["\n    &&& {\n        ", ";\n        ", ";\n        ", ";\n        ", ";\n        ", ";\n        ", ";\n    }\n"])), (function(e) {
                    var n = e.theme;
                    return oa(n)
                }), (function(e) {
                    var n = e.size;
                    return ca[n]
                }), (function(e) {
                    var n = e.kind,
                        t = e.theme;
                    return ia[n](t)
                }), (function(e) {
                    return e.noWrap && sa
                }), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.survey
                }), (function(e) {
                    var n = e.withCustomCSS;
                    return n && n
                })),
                da = et.a(Ri || (Ri = ea(["\n    &&& {\n        ", ";\n        ", ";\n\n        text-decoration: none !important;\n\n        &:hover,\n        &:focus,\n        &:active {\n            text-decoration: none;\n        }\n\n        ", ";\n\n        color: ", " !important;\n\n        ", ";\n        ", ";\n        ", ";\n    }\n"])), (function(e) {
                    var n = e.theme;
                    return oa(n)
                }), (function(e) {
                    var n = e.size;
                    return ca[n]
                }), (function(e) {
                    return e.noWrap && sa
                }), (function(e) {
                    return e.theme.defaultText
                }), (function(e) {
                    var n = e.kind,
                        t = e.theme;
                    return ia[n](t)
                }), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.survey
                }), (function(e) {
                    var n = e.withCustomCSS;
                    return n && n
                })),
                pa = function(e) {
                    var n = e.children,
                        t = e.kind,
                        r = void 0 === t ? "primary" : t,
                        o = e.isDisabled,
                        i = e.onClick,
                        a = e.as,
                        l = e.href,
                        s = e.isExternal,
                        c = void 0 !== s && s,
                        u = e.size,
                        d = void 0 === u ? "m" : u,
                        f = e.ariaLabel,
                        h = e.withCustomCSS,
                        m = e.noWrap,
                        _ = void 0 !== m && m,
                        v = dt();
                    return "a" === a ? p(da, {
                        withCustomCSS: h,
                        kind: r,
                        target: c ? "_blank" : "_self",
                        rel: "noopener noreferrer",
                        "aria-disabled": o,
                        href: l,
                        theme: v,
                        size: d,
                        noWrap: _
                    }, n) : p(ua, {
                        withCustomCSS: h,
                        type: "button",
                        kind: r,
                        disabled: o,
                        onClick: i,
                        "aria-label": f,
                        theme: v,
                        size: d,
                        noWrap: _
                    }, n)
                },
                fa = et.div(na || (na = function(e, n) {
                    return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(n)
                        }
                    }))
                }(["\n    &&& {\n        display: flex;\n        flex-direction: row-reverse;\n        flex-wrap: wrap;\n        justify-content: center;\n        align-items: center;\n        gap: ", ";\n\n        button {\n            flex: 1;\n            white-space: nowrap;\n        }\n    }\n"])), st.spacer.x2),
                ha = function(e) {
                    var n, t = e.onClose,
                        r = dt();
                    return p(fa, null, p(pa, {
                        withCustomCSS: null === (n = r.customCSS) || void 0 === n ? void 0 : n.button,
                        kind: "primary",
                        onClick: t
                    }, hj.polls.translate("close")))
                },
                ma = /(\b(https?):\/\/[-A-Z0-9+&amp;@#/%?=~_|!:,.;]*[-A-Z0-9+&amp;@#/%=~_|])/gim,
                _a = /(^|[^/])(www\.[\S]+(\b|$))/gim,
                va = "",
                ya = function(e) {
                    return e && e.match(_a)
                };

            function ba(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var ga, wa, xa, ka, ja = {
                    inline: function() {
                        return "\n    &&& {\n        color: inherit;\n        font-size: inherit;\n        line-height: inherit;\n        outline: none;\n        text-decoration-line: underline;\n\n        &:hover {\n            text-decoration-thickness: 2px;\n        }\n    }\n"
                    },
                    standalone: function(e) {
                        return "\n    &&& {\n        ".concat(st.text.link, "\n        color: ").concat(e.button, " !important;\n        outline: none;\n        text-decoration-line: underline;\n\n        &:hover {\n            text-decoration-thickness: 2px;\n        }\n    }\n")
                    }
                },
                Sa = function(e, n) {
                    return "\n    &&& {\n        border: none;\n        background-color: transparent;\n        color: ".concat(n ? "inherit" : e.defaultText, ";\n        cursor: pointer;\n        font-size: ").concat(n ? "inherit" : "0.875em !important", ";\n\n        &:hover {\n            text-decoration-thickness: 2px;\n        }\n\n        &:focus-visible {\n            box-shadow: 0 0 0 1px ").concat(e.background, ", 0 0 0 3px ").concat(e.buttonOutline, ";\n            outline: none;\n        }\n    }\n")
                },
                Ca = et.a(ta || (ta = ba(["\n    ", "\n    ", ";\n\n    color: ", " !important;\n\n    &&&& {\n        ", ";\n    }\n"])), (function(e) {
                    var n = e.theme,
                        t = e.isInline;
                    return Sa(n, t)
                }), (function(e) {
                    var n = e.kind,
                        t = e.theme;
                    return ja[n](t)
                }), (function(e) {
                    return e.theme.defaultText
                }), (function(e) {
                    var n = e.withCustomCSS;
                    return n && n
                })),
                Ma = et.button(ra || (ra = ba(["\n    ", "\n    ", ";\n\n    color: ", " !important;\n\n    &&&& {\n        ", ";\n    }\n"])), (function(e) {
                    var n = e.theme;
                    return Sa(n)
                }), (function(e) {
                    var n = e.kind,
                        t = e.theme;
                    return ja[n](t)
                }), (function(e) {
                    return e.theme.defaultText
                }), (function(e) {
                    var n = e.withCustomCSS;
                    return n && n
                })),
                Pa = function(e) {
                    var n = e.children,
                        t = e.onClick,
                        r = e.as,
                        o = e.href,
                        i = e.isExternal,
                        a = e.kind,
                        l = e.ariaLabel,
                        s = e.isInline,
                        c = e.withCustomCSS,
                        u = dt();
                    return "button" === r ? p(Ma, {
                        withCustomCSS: c,
                        onClick: t,
                        kind: a,
                        "aria-label": l,
                        theme: u
                    }, n) : p(Ca, {
                        withCustomCSS: c,
                        href: o,
                        target: !0 === i ? "_blank" : "_self",
                        rel: "noopener noreferrer",
                        kind: a,
                        isInline: s,
                        "aria-label": l,
                        theme: u
                    }, n)
                },
                Oa = function(e) {
                    var n, t = e.text,
                        r = e.isInline,
                        o = void 0 !== r && r;
                    return (n = t, n ? (n = (n = n.replace(ma, "".concat(va, "$1").concat(va))).replace(_a, "$1".concat(va, "$2").concat(va))).split(va) : []).map((function(e, n) {
                        return function(e) {
                            return !(! function(e) {
                                return e && e.match(ma)
                            }(e) && !ya(e))
                        }(e) ? p(Pa, {
                            key: n,
                            href: (t = e, ya(t) ? "http://".concat(t) : t),
                            isExternal: !0,
                            kind: "inline",
                            isInline: o
                        }, e) : p(h, {
                            key: n
                        }, e);
                        var t
                    }))
                },
                Aa = et.h2(ga || (ga = function(e, n) {
                    return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(n)
                        }
                    }))
                }(["\n    && {\n        color: ", " !important;\n        display: block;\n        white-space: pre-wrap;\n        overflow-wrap: break-word;\n        text-align: center;\n\n        padding-top: ", ";\n        margin: 0;\n        ", "\n        ", ";\n        font-size: 1em !important; // 16px;\n        line-height: 1.5em;\n\n        a {\n            color: ", " !important;\n        }\n    }\n\n    &&& {\n        ", ";\n        ", ";\n    }\n"])), (function(e) {
                    return e.fontColor
                }), st.spacer.x0pt5, (function(e) {
                    return e.extraPaddingBottom ? "padding-bottom: ".concat(st.spacer.x1, ";") : ""
                }), st.text.subtitle1, (function(e) {
                    return e.fontColor
                }), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.survey
                }), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.questionTitle
                })),
                Ia = function(e) {
                    var n = e.fontColor,
                        t = e.message,
                        r = e.extraPaddingBottom,
                        o = dt();
                    return p(Aa, {
                        theme: o,
                        tabIndex: 0,
                        fontColor: n,
                        extraPaddingBottom: r
                    }, p(Oa, {
                        text: t
                    }))
                };

            function za(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var Ea, Ta = et.div(wa || (wa = za(["\n    &&& {\n        display: flex;\n        flex-direction: column;\n        gap: ", ";\n    }\n"])), st.spacer.x2),
                Na = et.div(xa || (xa = za(["\n    &&& {\n        color: ", " !important;\n        ", ";\n        text-align: initial;\n        line-height: 1em;\n        font-size: 0.875em !important; // 14x;\n    }\n"])), (function(e) {
                    return e.theme.defaultText
                }), st.text.body2),
                La = et.div(ka || (ka = za(["\n    &&& {\n        display: flex;\n        flex-direction: row;\n        justify-content: space-between;\n        align-items: center;\n        gap: ", ";\n\n        button {\n            flex: 1;\n        }\n    }\n"])), st.spacer.x2),
                Fa = function(e) {
                    var n, t, r, o, i, a = e.onConsent,
                        l = e.onDecline,
                        s = dt();
                    return p(Ta, null, p(Na, {
                        theme: s
                    }, p("p", {
                        tabIndex: 0
                    }, null === (n = hj.polls) || void 0 === n ? void 0 : n.translate("consent")), " ", p(Pa, {
                        href: null === (t = hj.polls) || void 0 === t ? void 0 : t.translate("consent_more_information_url"),
                        isExternal: !0,
                        kind: "standalone"
                    }, null === (r = hj.polls) || void 0 === r ? void 0 : r.translate("consent_more_information"))), p(La, null, p(pa, {
                        kind: "secondary",
                        onClick: l
                    }, null === (o = hj.polls) || void 0 === o ? void 0 : o.translate("decline_consent")), p(pa, {
                        onClick: a
                    }, null === (i = hj.polls) || void 0 === i ? void 0 : i.translate("give_consent"))))
                },
                Da = (hj.tryCatch((function(e) {
                    var n = e || navigator.userAgent;
                    return n.indexOf("MSIE ") > 0 ? document.all && !document.compatMode ? 5 : document.all && !window.XMLHttpRequest ? 6 : document.all && !document.querySelector ? 7 : document.all && !document.addEventListener ? 8 : document.all && !window.atob ? 9 : 10 : -1 !== n.indexOf("Trident/") ? 11 : -1 !== n.indexOf("Edge/") ? 12 : "notIE"
                }), "utils"), hj.tryCatch((function(e) {
                    return (e = e || navigator.userAgent).indexOf("Firefox") > -1
                }), "utils"), hj.tryCatch((function(e) {
                    return (e = e || navigator.userAgent).indexOf("Safari") > -1 && -1 === e.indexOf("Chrome")
                }), "utils"), hj.tryCatch((function(e) {
                    return e = e || navigator.userAgent, /\b(Safari|iPad|iPhone|iPod)\b/.test(e) && /WebKit/.test(e) && !/Edge/.test(e) && void 0 === window.MSStream
                }), "utils"), hj.tryCatch((function() {
                    return _hjSettings.wsHost || (_hjSettings.wsHost = "ws.hotjar.com"), _hjSettings.wsHost
                }), "utils.get-ws-server"), function() {});

            function Ua(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return Ba(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? Ba(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Ba(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }
            var Ra, Ha, qa = et.div(Ea || (Ea = function(e, n) {
                    return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(n)
                        }
                    }))
                }(["\n    display: flex;\n    flex-direction: column;\n    gap: ", ";\n"])), st.spacer.x2),
                $a = function(e) {
                    var n = e.theme,
                        t = e.askForConsent,
                        r = e.showLegal,
                        o = e.thankYouMessage,
                        i = e.onClose,
                        a = void 0 === i ? Da : i,
                        l = e.isSubmitted,
                        s = e.surveyId,
                        c = e.showCloseButton,
                        u = void 0 === c || c,
                        d = function(e, n, t) {
                            if (n && !Array.isArray(n) && "number" == typeof n.length) {
                                var r = n.length;
                                return Ba(n, 2 < r ? 2 : r)
                            }
                            return e(n, 2)
                        }(Ua, W(t && !l)),
                        f = d[0],
                        h = d[1];
                    return p(qa, null, p(Ia, {
                        fontColor: n.defaultText,
                        message: o,
                        extraPaddingBottom: !u
                    }), f ? p(Fa, {
                        onConsent: function() {
                            wr(s), h(!1), a()
                        },
                        onDecline: function() {
                            h(!1), a()
                        }
                    }) : u && p(ha, {
                        onClose: a
                    }), p(Qi, {
                        showLegal: r
                    }))
                },
                Za = ((Ha = function() {
                    return Ra()
                }).test = Ra = function() {
                    var e;
                    if (!navigator) return "No User-Agent Provided";
                    if (null !== (e = navigator.userAgentData) && void 0 !== e && e.mobile) return "mobile";
                    var n = function(e) {
                        return navigator.userAgent.match(e)
                    };
                    return n(/GoogleTV|SmartTV|Internet.TV|NetCast|NETTV|AppleTV|boxee|Kylo|Roku|DLNADOC|CE\-HTML/i) || n(/Xbox|PLAYSTATION.3|Wii/i) ? "tv" : n(/iPad/i) || n(/tablet/i) && !n(/RX-34/i) || n(/FOLIO/i) || n(/Linux/i) && n(/Android/i) && !n(/Fennec|mobi|HTC.Magic|HTCX06HT|Nexus.One|SC-02B|fone.945|Chromebook/i) || n(/Kindle/i) || n(/Mac.OS/i) && n(/Silk/i) || n(/GT-P10|SC-01C|SHW-M180S|SGH-T849|SCH-I800|SHW-M180L|SPH-P100|SGH-I987|zt180|HTC(.Flyer|\_Flyer)|Sprint.ATP51|ViewPad7|pandigital(sprnova|nova)|Ideos.S7|Dell.Streak.7|Advent.Vega|A101IT|A70BHT|MID7015|Next2|nook/i) || n(/MB511/i) && n(/RUTEM/i) ? "tablet" : n(/BOLT|Fennec|Iris|Maemo|Minimo|Mobi|mowser|NetFront|Novarra|Prism|RX-34|Skyfire|Tear|XV6875|XV6975|Google.Wireless.Transcoder/i) || n(/Opera/i) && n(/Windows.NT.5/i) && n(/HTC|Xda|Mini|Vario|SAMSUNG\-GT\-i8000|SAMSUNG\-SGH\-i9/i) ? "mobile" : n(/Windows.(NT|XP|ME|9)/) && !n(/Phone/i) || n(/Win(9|.9|NT)/i) || n(/Macintosh|PowerPC/i) && !n(/Silk/i) || n(/Linux/i) && n(/X11/i) || n(/Solaris|SunOS|BSD/i) || n(/Bot|Crawler|Spider|Yahoo|ia_archiver|Covario-IDS|findlinks|DataparkSearch|larbin|Mediapartners-Google|NG-Search|Snappy|Teoma|Jeeves|TinEye/i) && !n(/Mobile/i) || n(/\b(CrOS|Chromebook)\b/i) ? "desktop" : "mobile"
                }, Ha);
            hj.tryCatch((function(e) {
                var n, t, r;
                for (n = e.length - 1; n > 0; n -= 1) t = Math.floor(Math.random() * (n + 1)), r = e[n], e[n] = e[t], e[t] = r;
                return e
            }), "utils.shuffle");
            var Wa, Ga, Va, Xa = hj.tryCatch((function(e) {
                    return /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(e)
                }), "utils.validateEmail"),
                Ja = hj.tryCatch((function() {
                    return hj.userDeviceType || (hj.userDeviceType = Za(), "mobile" === hj.userDeviceType && (hj.userDeviceType = "phone")), hj.userDeviceType
                }), "utils.deviceType");

            function Ka(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return Ya(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? Ya(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Ya(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }

            function Qa(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            hj.tryCatch((function() {
                var e = function() {
                        try {
                            return window.self !== window.top
                        } catch (e) {
                            return !0
                        }
                    }(),
                    n = {
                        width: !e && window.screen ? window.screen.width : document.body.clientWidth,
                        height: !e && window.screen ? window.screen.height : document.body.clientHeight
                    };
                return {
                    width: window.innerWidth || document.documentElement.clientWidth || n.width,
                    height: window.innerHeight || document.documentElement.clientHeight || n.height
                }
            }), "utils.getWindowSize");
            var el = function(e) {
                    return "\n    width: 100%;\n    border-radius: ".concat(st.radius.s, ";\n    color: ").concat(e.inputText, ";\n    border: 1px solid ").concat(e.inputBorder, ";\n    background-color: ").concat(e.background, ";\n    transition: ").concat(st.animation.default, ";\n    font-size: 1em;\n\n    min-width: auto;\n\n    ").concat(st.breakpoint.desktop, " {\n        font-size: 0.875em;\n    }\n\n    &::placeholder {\n        color: ").concat(e.inputPlaceholder, ";\n    }\n\n    &:focus {\n        outline: none;\n        border-color: ").concat(e.inputBorderActive, ";\n        box-shadow: 0px 0px 0px 1px ").concat(e.background, ", 0px 0px 0px 3px ").concat(e.inputOutline, ";\n    }\n")
                },
                nl = et.input(Wa || (Wa = Qa(["\n    && {\n        ", ";\n        height: 40px;\n        padding: 0 ", ";\n    }\n"])), (function(e) {
                    var n = e.theme;
                    return el(n)
                }), st.spacer.x2),
                tl = et.textarea(Ga || (Ga = Qa(["\n    && {\n        ", ";\n        height: 98px;\n        padding: ", " ", ";\n        resize: none;\n    }\n"])), (function(e) {
                    var n = e.theme;
                    return el(n)
                }), st.spacer.x1pt5, st.spacer.x2),
                rl = et.span(Va || (Va = Qa(["\n    && {\n        text-align: left;\n        margin-top: ", ";\n        font-size: 0.875em !important; // 14x;\n        color: ", ";\n    }\n"])), st.spacer.x1, st.colors.error),
                ol = function(e) {
                    var n = e.kind,
                        t = void 0 === n ? "input" : n,
                        r = e.type,
                        o = void 0 === r ? "text" : r,
                        i = e.labelId,
                        a = e.ariaLabel,
                        l = e.value,
                        s = e.required,
                        c = void 0 !== s && s,
                        u = e.theme,
                        d = e.onInput,
                        f = e.onKeyDown,
                        m = e.onClick,
                        _ = e.id,
                        v = function(e, n, t) {
                            if (n && !Array.isArray(n) && "number" == typeof n.length) {
                                var r = n.length;
                                return Ya(n, 2 < r ? 2 : r)
                            }
                            return e(n, 2)
                        }(Ka, W(!0)),
                        y = v[0],
                        b = v[1];
                    return p(h, null, p("textarea" === t ? tl : nl, {
                        autoComplete: "email" === o ? "email" : void 0,
                        type: o,
                        "aria-labelledby": i,
                        "aria-label": a,
                        value: l,
                        required: c,
                        placeholder: hj.polls.translate("please_type_here"),
                        theme: u,
                        onInput: d,
                        onKeyDown: f,
                        onClick: m,
                        onBlur: function(e) {
                            var n, t, r;
                            b(0 === (null === (n = e.target) || void 0 === n || null === (t = n.value) || void 0 === t ? void 0 : t.length) || Xa(null === (r = e.target) || void 0 === r ? void 0 : r.value))
                        },
                        id: _
                    }), !y && "email" === o && p(rl, {
                        role: "alert",
                        "aria-live": "polite"
                    }, hj.polls.translate("enter_a_valid_email")))
                };

            function il(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return al(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? al(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function al(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }
            var ll, sl, cl, ul, dl, pl = function(e) {
                    var n = e.labelId,
                        t = e.question,
                        r = e.onChange,
                        o = e.onSubmit,
                        i = function(e, n, t) {
                            if (n && !Array.isArray(n) && "number" == typeof n.length) {
                                var r = n.length;
                                return al(n, 2 < r ? 2 : r)
                            }
                            return e(n, 2)
                        }(il, W("")),
                        a = i[0],
                        l = i[1],
                        s = dt();
                    G((function() {
                        l("")
                    }), [t.uuid]);
                    var c = t.type === gt.EMAIL,
                        u = function(e) {
                            return c ? Xa(e.value) : e.validity.valid
                        };
                    return p(ol, {
                        kind: t.type === gt.SINGLE_OPEN_ENDED_MULTI_LINE ? "textarea" : "input",
                        labelId: n,
                        type: c ? "email" : "text",
                        value: a,
                        required: t.required,
                        onInput: function(e) {
                            var n = e.currentTarget.value;
                            l(n), r(u(e.currentTarget), {
                                answerText: n,
                                answerIndex: null
                            })
                        },
                        onKeyDown: function(e) {
                            "Enter" === e.key && (e.metaKey || e.ctrlKey) && u(e.currentTarget) && o()
                        },
                        theme: s
                    })
                },
                fl = et.svg(ll || (ll = function(e, n) {
                    return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(n)
                        }
                    }))
                }(["\n    width: 16px;\n    height: 16px;\n    margin: 3px;\n    fill: white;\n    fill: ", ";\n"])), (function(e) {
                    return e.color
                })),
                hl = function(e) {
                    var n = e.color;
                    return p(fl, {
                        color: n,
                        viewBox: "-2 -3 14 14",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }, p("path", {
                        d: "m4.1 7.3 6-6a.7.7 0 1 0-1-1L3.6 5.6 1.3 3.4a.8.8 0 0 0-1 1l2.7 3c.3.3.8.3 1.1 0Z"
                    }))
                };

            function ml(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var _l, vl, yl, bl, gl = "18px",
                wl = et.div(sl || (sl = ml(["\n    && {\n        flex: 0 0 24px;\n        height: 1.25em;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        margin-top: 1px;\n    }\n"]))),
                xl = et.span(cl || (cl = ml(["\n    && {\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        width: ", ";\n        height: ", ";\n        border-radius: 2px;\n        box-shadow: 0 0 0 1px ", " inset;\n        background-color: ", ";\n        transition: ", ";\n\n        & svg {\n            fill: ", " !important;\n        }\n    }\n"])), gl, gl, (function(e) {
                    return e.theme.button
                }), (function(e) {
                    var n = e.isSelected,
                        t = e.theme;
                    return n ? t.option : t.background
                }), st.animation.default, (function(e) {
                    return e.theme.buttonText
                })),
                kl = et.span(ul || (ul = ml(["\n    && {\n        width: ", ";\n        height: ", ";\n        border-radius: ", ";\n        box-shadow: 0 0 0 ", "px ", " inset;\n        background-color: ", ";\n        transition: ", ";\n    }\n"])), gl, gl, gl, (function(e) {
                    return e.isSelected ? 6 : 1
                }), (function(e) {
                    return e.theme.option
                }), (function(e) {
                    return e.theme.background
                }), st.animation.default),
                jl = et.input(dl || (dl = ml(["\n    opacity: 0;\n    position: absolute;\n\n    &:focus-visible + span {\n        box-shadow: ", ";\n    }\n"])), (function(e) {
                    var n = e.type,
                        t = e.checked,
                        r = e.theme;
                    return "checkbox" === n ? "0px 0px 0px 1px ".concat(r.button, ", 0px 0px 0px 2px ").concat(r.background, ",\n            0px 0px 0px 3px ").concat(r.buttonOutline, ", 0px 0px 0px 4px ").concat(r.buttonOutline) : "0px 0px 0px ".concat(t ? 6 : 1, "px ").concat(r.button, " inset, 0px 0px 0px 1px ").concat(r.background, ",\n            0px 0px 0px 2px ").concat(r.buttonOutline, ", 0px 0px 0px 3px ").concat(r.buttonOutline)
                })),
                Sl = function(e) {
                    var n = e.type,
                        t = e.isSelected,
                        r = e.onClick,
                        o = e.theme;
                    return p(wl, null, p(jl, {
                        type: n,
                        checked: t,
                        onClick: r,
                        theme: o
                    }), "checkbox" === n ? p(xl, {
                        "aria-hidden": "true",
                        isSelected: t,
                        theme: o
                    }, t && p(hl, {
                        color: o.background
                    })) : p(kl, {
                        "aria-hidden": "true",
                        isSelected: t,
                        theme: o
                    }))
                };

            function Cl(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return Ml(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? Ml(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Ml(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }

            function Pl(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var Ol, Al = et.label(_l || (_l = Pl(["\n    && {\n        display: flex;\n        align-items: flex-start;\n        text-align: left;\n        gap: ", ";\n        padding: ", " ", ";\n        border-radius: 20px;\n        box-shadow: 0px 0px 0px 1px ", ",\n            0px 0px 0px 2px ", ";\n        background-color: ", ";\n        transition: ", ";\n\n        color: ", " !important;\n\n        &:hover {\n            box-shadow: 0px 0px 0px 1px ", ",\n                0px 0px 0px 2px ", ";\n            background-color: ", ";\n            color: ", " !important;\n            cursor: pointer;\n        }\n\n        ", "\n    }\n\n    &&& {\n        ", ";\n    }\n"])), st.spacer.x1, st.spacer.x1, st.spacer.x2, (function(e) {
                    return e.theme.optionBorder
                }), (function(e) {
                    return e.theme.background
                }), (function(e) {
                    var n = e.isSelected,
                        t = e.theme;
                    return n ? t.optionBackgroundSelected : t.background
                }), st.animation.default, (function(e) {
                    return e.theme.optionText
                }), (function(e) {
                    return e.theme.optionBorder
                }), (function(e) {
                    return e.theme.background
                }), (function(e) {
                    return e.theme.optionBackgroundSelected
                }), (function(e) {
                    return e.theme.optionTextSelected
                }), (function(e) {
                    var n = e.isSelected,
                        t = e.theme;
                    return n ? "\n                    box-shadow: 0px 0px 0px 2px ".concat(t.option, ";\n                    color: ").concat(t.optionTextSelected, " !important;\n                    font-weight: 500;\n                    &:hover {\n                        box-shadow: 0px 0px 0px 2px ").concat(t.optionBorderActive, ";\n                    }") : ""
                }), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.answerBody
                })),
                Il = et.div(vl || (vl = Pl(["\n    && {\n        margin-left: ", ";\n        margin-right: ", ";\n        margin-top: 10px;\n    }\n"])), st.spacer.x6, st.spacer.x2),
                zl = et.span(yl || (yl = Pl(["\n    && {\n        line-height: 1.45em; // 20px\n        font-size: 0.875em; // 14px\n        margin: 2px 0;\n        overflow: hidden;\n        display: inline-block;\n        word-break: break-word;\n    }\n\n    &&& {\n        ", ";\n    }\n"])), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.answerBody
                })),
                El = et.label(bl || (bl = Pl(["\n    && {\n        color: ", ";\n        font-size: 0.875rem;\n        height: ", ";\n        margin-bottom: ", ";\n    }\n\n    &&& {\n        ", ";\n    }\n"])), (function(e) {
                    return e.theme.optionText
                }), st.spacer.x2pt5, st.spacer.x0pt5, (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.answerBody
                })),
                Tl = function(e) {
                    var n = e.answerType,
                        t = e.answer,
                        r = e.isSelected,
                        o = e.onSelect,
                        i = e.onCommentUpdate,
                        a = function(e, n, t) {
                            if (n && !Array.isArray(n) && "number" == typeof n.length) {
                                var r = n.length;
                                return Ml(n, 2 < r ? 2 : r)
                            }
                            return e(n, 2)
                        }(Cl, W("")),
                        l = a[0],
                        s = a[1],
                        c = dt(),
                        u = J((function() {
                            return hj.widget.isActiveLanguageDirectionRtl ? "'".concat(t.text, "' ").concat(hj.polls.translate("comment_for_option")) : "".concat(hj.polls.translate("comment_for_option"), " '").concat(t.text, "'")
                        }), [t.text]);
                    return p("div", null, p(Al, {
                        isSelected: r,
                        theme: c
                    }, p(Sl, {
                        type: n,
                        isSelected: r,
                        onClick: function() {
                            return e = l, void o({
                                answerText: t.text,
                                answerIndex: t.index,
                                comment: e,
                                isValid: !t.comments || e.length > 0
                            });
                            var e
                        },
                        theme: c
                    }), p(zl, {
                        theme: c
                    }, t.text)), r && t.comments && p(Il, null, p(El, {
                        theme: c,
                        htmlFor: "answer-".concat(t.index, "-comment")
                    }, hj.polls.translate("comment_label")), p(ol, {
                        id: "answer-".concat(t.index, "-comment"),
                        ariaLabel: u,
                        kind: "textarea",
                        value: l,
                        required: !0,
                        onInput: function(e) {
                            var n = e.currentTarget.value;
                            s(n), i(t.text, n)
                        },
                        onClick: function(e) {
                            e.nativeEvent.stopImmediatePropagation(), e.preventDefault()
                        },
                        theme: c
                    })))
                };

            function Nl(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return Ll(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? Ll(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Ll(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }
            var Fl, Dl, Ul, Bl = et.div(Ol || (Ol = function(e, n) {
                    return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(n)
                        }
                    }))
                }(["\n    && {\n        display: flex;\n        flex-direction: column;\n        gap: ", ";\n    }\n"])), st.spacer.x1),
                Rl = function(e, n) {
                    return e.map((function(e) {
                        return e.answerText
                    })).indexOf(n)
                },
                Hl = function(e) {
                    var n = e.labelId,
                        t = e.question,
                        r = e.onChange,
                        o = function(e, n, t) {
                            if (n && !Array.isArray(n) && "number" == typeof n.length) {
                                var r = n.length;
                                return Ll(n, 2 < r ? 2 : r)
                            }
                            return e(n, 2)
                        }(Nl, W([])),
                        i = o[0],
                        a = o[1],
                        l = "radio";
                    t.type === gt.SINGLE_CLOSE_ENDED || t.type === gt.YES_NO ? l = "radio" : t.type === gt.MULTIPLE_CLOSE_ENDED && (l = "checkbox");
                    var s = function(e) {
                            var n = e.length > 0 && e.every((function(e) {
                                return e.isValid
                            }));
                            r(n, e)
                        },
                        c = function(e) {
                            a((function(n) {
                                var t = [].concat(n);
                                if ("radio" === l) t = [e];
                                else {
                                    var r = Rl(t, e.answerText); - 1 === r ? t.push(e) : t.splice(r, 1)
                                }
                                return s(t), t
                            }))
                        },
                        u = function(e, n) {
                            a((function(t) {
                                var r = [].concat(t),
                                    o = r[Rl(r, e)];
                                return o && (o.comment = n, o.isValid = n.length > 0), s(r), r
                            }))
                        };
                    return p(Bl, {
                        "aria-labelledby": n,
                        role: "radio" === l ? "radiogroup" : "group"
                    }, t.answers.map((function(e) {
                        return p(Tl, {
                            key: e.index,
                            answerType: l,
                            answer: e,
                            isSelected: Rl(i, e.text) > -1,
                            onSelect: c,
                            onCommentUpdate: u
                        })
                    })))
                },
                ql = function(e, n) {
                    return e ? "#324FBE" : n ? "#1C3286" : "#838696"
                },
                $l = function(e) {
                    var n = e.isHighlighted,
                        t = e.isSelected,
                        r = e.stroke;
                    return p("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "40",
                        height: "40",
                        fill: "none",
                        style: {
                            overflow: "visible"
                        }
                    }, p("path", {
                        fill: ql(n, t),
                        style: t ? {
                            stroke: r,
                            strokeWidth: "3px",
                            paintOrder: "stroke"
                        } : {},
                        d: "M17.72 2a2.5 2.5 0 014.56 0l3.87 8.66a2.5 2.5 0 002.02 1.47l9.43 1a2.5 2.5 0 011.42 4.34l-7.05 6.35a2.5 2.5 0 00-.78 2.38l1.97 9.28a2.5 2.5 0 01-3.7 2.69l-8.21-4.74a2.5 2.5 0 00-2.5 0l-8.22 4.74a2.5 2.5 0 01-3.7-2.69l1.98-9.28a2.5 2.5 0 00-.78-2.38L.98 17.47a2.5 2.5 0 011.42-4.34l9.43-1a2.5 2.5 0 002.02-1.47L17.72 2z"
                    }))
                },
                Zl = "#C2C5CD",
                Wl = "#FFC107",
                Gl = {
                    hate: function(e) {
                        return p(h, null, p("path", {
                            fill: e.greyOut ? Zl : Wl,
                            d: "M22 42.6a20.6 20.6 0 100-41.2 20.6 20.6 0 000 41.2z"
                        }), p("path", {
                            fill: "#111",
                            d: "M27 12.5a9.7 9.7 0 008.1 2.1c.4 0 .8 1.4.3 1.6-3.3.6-6.7-.4-9.3-2.5-.3-.4.7-1.4 1-1.2zm-18 2a10 10 0 008-2c.3-.3 1.4.8 1 1.1a11 11 0 01-9.3 2.5c-.5-.2-.1-1.6.3-1.5zM24.6 17c1.4 6.1 7 7.6 11.2 3 .2-.1-.1-.3-.5-.8a8.8 8.8 0 01-9.8-2.6c-.5.1-1 .1-.9.4zM8.1 20c4.2 4.6 9.8 3.1 11.2-3 0-.2-.3-.3-.8-.4-2.2 3-6.8 4-10 2.6-.2.4-.6.6-.4.9zm24.7 10.3c-1.2-2.5-4-4.2-10.8-4.2-6.7 0-9.6 1.7-10.8 4.1-.6 1.4.3 3.5.3 3.5 1 2.7 1 3.4 10.5 3.4 9.6 0 9.4-.7 10.5-3.4 0 0 1-2.1.3-3.5z"
                        }), p("path", {
                            fill: "#fff",
                            d: "M29.8 29.6c.1-.2 0-.5-.1-.6 0 0-1.7-1.5-7.6-1.5-6 0-7.7 1.5-7.7 1.5-.1.1-.2.4-.1.6l.1.4c.1.2.3.3.5.3h14.5c.2 0 .4-.1.4-.3v-.4z"
                        }))
                    },
                    dislike: function(e) {
                        return p(h, null, p("path", {
                            d: "M22 42.6a20.6 20.6 0 1 0 0-41.2 20.6 20.6 0 0 0 0 41.2Z",
                            fill: e.greyOut ? Zl : Wl
                        }), p("path", {
                            d: "M14 23.8a3.4 3.4 0 1 0 0-6.9 3.4 3.4 0 0 0 0 6.9ZM30 23.8a3.4 3.4 0 1 0 0-6.9 3.4 3.4 0 0 0 0 6.9ZM35.2 12.9a9.7 9.7 0 0 0-8-2.2c-.5 0-.8-1.3-.3-1.5 3.3-.6 6.7.4 9.3 2.5.4.3-.7 1.4-1 1.2Zm-18.4-2.3a10 10 0 0 0-8 2.1c-.3.3-1.4-.8-1-1.1 2.6-2.2 6-3.1 9.3-2.5.5.1.2 1.6-.3 1.5ZM28 30.5a14.2 14.2 0 0 0-12 0c-.8.4.3 3 1.3 2.4 2.4-1.1 6-1.5 9.5 0 1 .4 2-1.9 1.1-2.4Z",
                            fill: "#111"
                        }))
                    },
                    neutral: function(e) {
                        return p(h, null, p("path", {
                            d: "M42.6 22a20.6 20.6 0 1 1-41.2 0 20.6 20.6 0 0 1 41.2 0Z",
                            fill: e.greyOut ? Zl : Wl
                        }), p("path", {
                            d: "M37 20c-2.3-2.6-9.6-1.6-11.8 2-.1.3.3.7.8 1 1.4-1 3.1-1.6 5-1.8 0 2 1.4 3.6 3.4 3.6 2.7 0 4-3.1 2.7-4.7Zm-18.8 0c-2.3-2.6-9.6-1.6-11.8 2-.1.3.3.7.7 1 1.5-1 3.2-1.6 5-1.8 0 2 1.5 3.6 3.4 3.6 2.8 0 4-3.1 2.7-4.7Zm9.5 10.7c-4-1-8.2-.2-11.6 2-.8.7.7 2.8 1.6 2.3 2.2-1.6 5.7-2.6 9.4-1.7.9.3 1.6-2.3.6-2.6Z",
                            fill: "#111"
                        }))
                    },
                    like: function(e) {
                        return p(h, null, p("path", {
                            d: "M22 42.6a20.6 20.6 0 1 0 0-41.2 20.6 20.6 0 0 0 0 41.2Z",
                            fill: e.greyOut ? Zl : Wl
                        }), p("path", {
                            d: "M14 21.7a3.4 3.4 0 1 0 0-6.8 3.4 3.4 0 0 0 0 6.8ZM30 21.7a3.4 3.4 0 1 0 0-6.9 3.4 3.4 0 0 0 0 7ZM30.7 27.7c-5.6 4-11.8 3.9-17.4 0-.6-.5-1.2.4-.8 1.1a11.1 11.1 0 0 0 19 0c.4-.8-.1-1.6-.8-1Z",
                            fill: "#111"
                        }))
                    },
                    love: function(e) {
                        var n = e.greyOut;
                        return p(h, null, p("path", {
                            d: "M42.6 22a20.6 20.6 0 1 1-41.2 0 20.6 20.6 0 0 1 41.2 0Z",
                            fill: n ? Zl : Wl
                        }), p("path", {
                            d: "M42.5 9C42 7.3 41 5.8 39.4 5.3c-1.9-.5-3.5.2-5 1.9-1-2.5-2.4-4.4-4.6-5.3-2.2-1-4.4-.3-5.7 1.4-1.5 1.8-2 4.6-.5 8.3a57.7 57.7 0 0 0 8 10.5c.3-.1 7.4-4.6 9.2-6.8 1.7-2.1 2-4.3 1.7-6.1ZM19.9 3.3a4.7 4.7 0 0 0-5.7-1.4C12 2.8 10.6 4.6 9.7 7 8 5.5 6.4 4.7 4.5 5.3c-1.6.5-2.7 2-3 3.8-.4 1.8 0 4 1.7 6.2 1.7 2 8.9 6.6 9.2 6.7.2-.2 6.6-7 8-10.5 1.5-3.7 1-6.4-.5-8.3Z",
                            fill: n ? "#111" : "#F46767"
                        }), p("path", {
                            d: "M33.7 26.2c0-.6-.4-1.2-1.3-1.4a54.4 54.4 0 0 0-20.8 0c-1 .2-1.3.8-1.3 1.4 0 5 3.9 10 11.7 10 7.8 0 11.7-5 11.7-10Z",
                            fill: "#111"
                        }), p("path", {
                            d: "M30.7 26.3a51.6 51.6 0 0 0-17.4 0c-1 .2-1 .5-1 1l.3 1.2c0 .4.2.6.9.5h17c.8 0 .8-.1 1-.5l.2-1.1c0-.6 0-1-1-1Z",
                            fill: "#fff"
                        }))
                    }
                },
                Vl = function(e) {
                    var n = e.emotion,
                        t = e.greyOut;
                    return p("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "44",
                        height: "44",
                        fill: "none"
                    }, p(Gl[n], {
                        greyOut: t
                    }))
                },
                Xl = {
                    hate: function(e) {
                        return p(h, null, p("circle", {
                            cx: "22",
                            cy: "22",
                            r: "22",
                            fill: "#FF3C00",
                            style: {
                                opacity: e.greyOut ? .3 : 1
                            }
                        }), p("path", {
                            d: "M22.1 28.7c3 0 5.7 2 6.3 5 .1 1 1 1.4 1.8 1.3 1-.2 1.5-1 1.3-2a9.5 9.5 0 0 0-9.4-7.4 9.5 9.5 0 0 0-9.3 7.5c-.2 1 .3 1.7 1.2 1.9 1 .1 1.7-.4 1.9-1.3.6-3 3.3-5 6.2-5ZM14.3 23.3a2.3 2.3 0 1 0 0-4.7 2.3 2.3 0 0 0 0 4.7ZM30 23.3a2.3 2.3 0 1 0 0-4.7 2.3 2.3 0 0 0 0 4.7ZM26.8 16.2c.5 0 .8-.1 1.1-.4l3.1-3.1c.7-.7.7-1.6 0-2.2-.6-.7-1.5-.7-2.2 0l-3 3c-.7.7-.7 1.6 0 2.3.2.3.5.4 1 .4ZM16.4 15.8c.6.6 1.5.6 2.2 0 .6-.7.6-1.6 0-2.2l-3.2-3.1c-.6-.7-1.5-.7-2.2 0-.6.6-.6 1.5 0 2.2l3.2 3Z",
                            fill: "#202641"
                        }))
                    },
                    dislike: function(e) {
                        return p(h, null, p("circle", {
                            cx: "22",
                            cy: "22",
                            r: "22",
                            fill: "#FF855F",
                            style: {
                                opacity: e.greyOut ? .3 : 1
                            }
                        }), p("path", {
                            d: "M14.8 16.7a2.3 2.3 0 1 0 0-4.7 2.3 2.3 0 0 0 0 4.7ZM30.4 16.7a2.3 2.3 0 1 0 0-4.7 2.3 2.3 0 0 0 0 4.7ZM22.6 25.3c3 0 5.7 2 6.3 5 .1.9 1 1.4 1.8 1.2 1-.2 1.5-1 1.3-1.9a9.5 9.5 0 0 0-9.4-7.5 9.5 9.5 0 0 0-9.3 7.5c-.2 1 .3 1.7 1.2 1.9 1 .2 1.7-.3 1.9-1.3.6-3 3.3-5 6.2-5Z",
                            fill: "#202641"
                        }))
                    },
                    neutral: function(e) {
                        return p(h, null, p("circle", {
                            cx: "22",
                            cy: "22",
                            r: "22",
                            fill: "#AFB2BD",
                            style: {
                                opacity: e.greyOut ? .3 : 1
                            }
                        }), p("path", {
                            d: "M14.3 18.7a2.3 2.3 0 1 0 0-4.7 2.3 2.3 0 0 0 0 4.7ZM30 18.7a2.3 2.3 0 1 0 0-4.7 2.3 2.3 0 0 0 0 4.7ZM27 26h-9c-.3 0-.6.2-.7.4a2 2 0 0 0-.3 1.1c0 .4.1.8.3 1 .1.3.4.5.6.5h9.2c.2 0 .5-.2.6-.4.2-.3.3-.7.3-1.1a2 2 0 0 0-.3-1c-.1-.3-.4-.5-.6-.5Z",
                            fill: "#202641"
                        }))
                    },
                    like: function(e) {
                        return p(h, null, p("circle", {
                            cx: "22",
                            cy: "22",
                            r: "22",
                            fill: "#6ABDA9",
                            style: {
                                opacity: e.greyOut ? .3 : 1
                            }
                        }), p("path", {
                            d: "M30.3 22.1a1.6 1.6 0 0 0-2 1.2 6.3 6.3 0 0 1-6.2 5 6.4 6.4 0 0 1-6.2-5 1.6 1.6 0 0 0-3.1.7 9.6 9.6 0 0 0 18.7 0 1.6 1.6 0 0 0-1.2-1.9ZM14.3 16.7a2.3 2.3 0 1 0 0-4.7 2.3 2.3 0 0 0 0 4.7ZM30 16.7a2.3 2.3 0 1 0 0-4.7 2.3 2.3 0 0 0 0 4.7Z",
                            fill: "#202641"
                        }))
                    },
                    love: function(e) {
                        return p(h, null, p("circle", {
                            cx: "22",
                            cy: "22",
                            r: "22",
                            fill: "#23A68E",
                            style: {
                                opacity: e.greyOut ? .3 : 1
                            }
                        }), p("path", {
                            d: "M27.7 25.7H16.3a1.1 1.1 0 0 0-1 .9v.5a7 7 0 0 0 2.4 4 7 7 0 0 0 11.2-4 1.2 1.2 0 0 0-.3-1 1.1 1.1 0 0 0-.9-.4ZM19 16a2.7 2.7 0 0 0 .7-2 2.8 2.8 0 0 0-.7-1.9 2.7 2.7 0 0 0-2-.8 2.6 2.6 0 0 0-1.8.8l-.8.8-.8-.8a2.7 2.7 0 0 0-3.8 0 2.8 2.8 0 0 0 0 3.9l4.6 4.7L19 16ZM34.2 12.1a2.7 2.7 0 0 0-1.9-.8 2.6 2.6 0 0 0-1.9.8l-.8.8-.8-.8a2.7 2.7 0 0 0-3.8 0 2.8 2.8 0 0 0 0 3.9l4.6 4.7 4.6-4.7a2.7 2.7 0 0 0 .8-2 2.8 2.8 0 0 0-.8-1.9Z",
                            fill: "#202641"
                        }))
                    }
                },
                Jl = function(e) {
                    var n = e.emotion,
                        t = e.greyOut;
                    return p("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "44",
                        height: "44",
                        fill: "none"
                    }, p(Xl[n], {
                        greyOut: t
                    }))
                },
                Kl = {
                    hate: function(e) {
                        return p(h, null, p("path", {
                            d: "M36.3 2.5h-35a1.2 1.2 0 0 0-1 2.1L5 9.3v22A3.8 3.8 0 0 0 8.8 35h27.5a3.7 3.7 0 0 0 3.7-3.7v-25a3.8 3.8 0 0 0-3.7-3.8Z",
                            fill: e.greyOut ? "#C2C5CD" : "#FFC107"
                        }), p("path", {
                            d: "M22.5 22.5a5 5 0 0 1 5 4A1.3 1.3 0 1 0 30 26a7.7 7.7 0 0 0-15 0 1.3 1.3 0 1 0 2.5.5c0-.2.9-4 5-4ZM16.3 18.1a1.9 1.9 0 1 0 0-3.7 1.9 1.9 0 0 0 0 3.7ZM28.7 18.1a1.9 1.9 0 1 0 0-3.7 1.9 1.9 0 0 0 0 3.7ZM32.4 8.2a1.3 1.3 0 0 0-1.7-.6l-5 2.5a1.3 1.3 0 1 0 1.1 2.3l5-2.5a1.3 1.3 0 0 0 .6-1.7ZM18.8 12.5a1.3 1.3 0 0 0 .5-2.4l-5-2.5a1.3 1.3 0 1 0-1.1 2.3l5 2.5.6.1Z",
                            fill: "#000"
                        }), p("defs", null, p("clipPath", {
                            id: "a"
                        }, p("path", {
                            fill: "#fff",
                            d: "M0 0h40v40H0z"
                        }))))
                    },
                    dislike: function(e) {
                        return p(h, null, p("path", {
                            d: "M36.2 2.5h-35a1.3 1.3 0 0 0-.8 2.1L5 9.3v22A3.7 3.7 0 0 0 8.7 35h27.5a3.8 3.8 0 0 0 3.8-3.8v-25a3.8 3.8 0 0 0-3.8-3.7Z",
                            fill: e.greyOut ? "#C2C5CD" : "#FFC107"
                        }), p("path", {
                            d: "M22.5 22.5a5 5 0 0 0-5 4A1.3 1.3 0 1 1 15 26a7.6 7.6 0 0 1 7.5-6 7.6 7.6 0 0 1 7.5 6 1.3 1.3 0 1 1-2.5.5c0-.2-.8-4-5-4ZM16.3 15.6a1.9 1.9 0 1 0 0-3.7 1.9 1.9 0 0 0 0 3.7ZM28.8 15.6a1.9 1.9 0 1 0 0-3.7 1.9 1.9 0 0 0 0 3.7Z",
                            fill: "#000"
                        }), p("defs", null, p("clipPath", {
                            id: "a"
                        }, p("path", {
                            fill: "#fff",
                            d: "M0 0h40v40H0z"
                        }))))
                    },
                    neutral: function(e) {
                        return p(h, null, p("path", {
                            d: "M36.3 2.5h-35A1.3 1.3 0 0 0 0 4c0 .2.2.5.4.6L5 9.3v22A3.8 3.8 0 0 0 8.8 35h27.5a3.7 3.7 0 0 0 3.7-3.7v-25a3.7 3.7 0 0 0-3.7-3.8Zm-20 20h12.5a1.2 1.2 0 1 1 0 2.5H16.3a1.2 1.2 0 1 1 0-2.5Zm-2-8.7a1.9 1.9 0 1 1 3.8 0 1.9 1.9 0 0 1-3.7 0Zm14.5 1.8a1.9 1.9 0 1 1 0-3.7 1.9 1.9 0 0 1 0 3.7Z",
                            fill: e.greyOut ? "#C2C5CD" : "#FFC107"
                        }), p("path", {
                            d: "M16.3 15.6a1.9 1.9 0 1 0 0-3.7 1.9 1.9 0 0 0 0 3.7ZM28.7 15.6a1.9 1.9 0 1 0 0-3.7 1.9 1.9 0 0 0 0 3.7ZM16.2 25h12.5a1.3 1.3 0 0 0 0-2.5H16.2a1.3 1.3 0 0 0 0 2.5Z",
                            fill: "#000"
                        }), p("defs", null, p("clipPath", {
                            id: "a"
                        }, p("path", {
                            fill: "#fff",
                            d: "M0 0h40v40H0z"
                        }))))
                    },
                    like: function(e) {
                        return p(h, null, p("path", {
                            d: "M36.2 2.5h-35c-.5 0-1 .3-1 .8-.3.5-.2 1 .2 1.3L5 9.3v22c0 2 1.6 3.7 3.7 3.7h27.5c2.2 0 3.8-1.6 3.8-3.7v-25c0-2.2-1.6-3.8-3.8-3.8Z",
                            fill: e.greyOut ? "#C2C5CD" : "#FFC107"
                        }), p("path", {
                            d: "M16 20c.6-.1 1.4.3 1.5 1a5 5 0 0 0 5 4 5 5 0 0 0 5-4c.1-.7.8-1.1 1.5-1 .8.1 1.1.8 1 1.5a7.6 7.6 0 0 1-9.1 5.9c-3-.6-5.3-3-5.9-5.9-.1-.6.3-1.4 1-1.5ZM16.3 15.6a1.9 1.9 0 1 0 0-3.7 1.9 1.9 0 0 0 0 3.7ZM28.7 15.6a1.9 1.9 0 1 0 0-3.7 1.9 1.9 0 0 0 0 3.7Z",
                            fill: "#000"
                        }), p("defs", null, p("clipPath", {
                            id: "a"
                        }, p("path", {
                            fill: "#fff",
                            d: "M0 0h40v40H0z"
                        }))))
                    },
                    love: function(e) {
                        return p(h, null, p("path", {
                            d: "M36.2 2.5h-35c-.5 0-1 .3-1 .8-.3.5-.2 1 .2 1.3L5 9.3v22c0 2 1.6 3.7 3.7 3.7h27.5c2.2 0 3.8-1.6 3.8-3.7v-25c0-2.2-1.6-3.8-3.8-3.8Z",
                            fill: e.greyOut ? "#C2C5CD" : "#FFC107"
                        }), p("path", {
                            d: "M18.8 10.6c-1-.8-2.3-.8-3.2 0l-.6.7-.6-.7c-.9-.8-2.3-.8-3.1 0-1 .9-1 2.3 0 3.2l3.7 3.7 3.8-3.8c.8-.8.8-2.2 0-3ZM30.6 10.6l-.6.7-.6-.7c-.9-.8-2.3-.8-3.2 0-.8.9-.8 2.3 0 3.2l3.8 3.7 3.7-3.8c1-.8 1-2.2 0-3-.8-1-2.2-1-3 0ZM22.4 27.5c5 0 7.5-4.4 7.5-6 0-.4 0-.6-.3-1-.2-.4-.6-.5-1-.5H16.2c-.3 0-.7.1-1 .5-.2.4-.2.6-.2 1 0 1.6 2.5 6 7.4 6Z",
                            fill: "#000"
                        }), p("defs", null, p("clipPath", {
                            id: "a"
                        }, p("path", {
                            fill: "#fff",
                            d: "M0 0h40v40H0z"
                        }))))
                    }
                },
                Yl = function(e) {
                    var n = e.emotion,
                        t = e.greyOut;
                    return p("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "40",
                        height: "35",
                        fill: "none"
                    }, p(Kl[n], {
                        greyOut: t
                    }))
                };

            function Ql(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var es, ns, ts, rs, os = {
                    1: "hate",
                    2: "dislike",
                    3: "neutral",
                    4: "like",
                    5: "love"
                },
                is = {
                    emoji: "#111111",
                    smiley: "#202641",
                    default: "#000000",
                    star: "#0A112E"
                },
                as = et.input(Fl || (Fl = Ql(["\n    &&& {\n        position: absolute;\n        opacity: 0;\n        width: 0;\n        height: 0;\n\n        ", "\n        &:checked + div {\n            svg {\n                overflow: visible;\n\n                path:first-child,\n                circle:first-child {\n                    paint-order: stroke;\n                    stroke: ", ";\n                    stroke-width: 3px;\n                }\n            }\n        }\n\n        &:not(:focus-visible):not(:checked):not(:hover) + div {\n            transform: scale(1);\n        }\n    }\n"])), (function(e) {
                    return e.hideFocus ? "" : "&:focus-visible + div,"
                }), (function(e) {
                    var n = e.reactionStyle;
                    return is[n]
                })),
                ls = et.label(Dl || (Dl = Ql(["\n    &&& {\n        background: none !important;\n        border: none;\n        cursor: pointer;\n        outline: none;\n        box-shadow: none;\n        display: flex;\n        justify-content: center;\n        width: ", ";\n        height: ", ";\n    }\n"])), st.spacer.x7, st.spacer.x7),
                ss = et.div(Ul || (Ul = Ql(["\n    &&& {\n        display: flex;\n        align-items: center;\n        pointer-events: none; /* ensures that the animation of the icon does not affect the hover state of the button */\n        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.35);\n        ", "\n        svg > * {\n            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.35);\n        }\n    }\n"])), (function(e) {
                    var n = e.highlightScale,
                        t = e.isHighlighted,
                        r = e.isScaled;
                    return t || r ? "\n                    transform: scale(".concat(n, ");\n                    ") : "\n                    transform: scale(1.0);\n                  "
                })),
                cs = function(e) {
                    var n = e.score,
                        t = e.greyOut,
                        r = e.groupName,
                        o = e.isHighlighted,
                        i = e.isSelected,
                        a = e.onPreselection,
                        l = e.onResetPreselection,
                        s = e.onSelection,
                        c = e.reactionStyle,
                        u = e.label,
                        d = e.hideFocus,
                        f = "star" === c ? 1.1 : 1.3,
                        h = os[n];
                    return p(ls, {
                        onMouseOver: a,
                        onMouseOut: l,
                        onBlur: l
                    }, p(as, {
                        type: "radio",
                        name: r,
                        onBlur: l,
                        checked: i,
                        "aria-label": n.toString(),
                        onClick: s,
                        "aria-describedby": u,
                        reactionStyle: c,
                        hideFocus: d
                    }), p(ss, {
                        highlightScale: f,
                        isHighlighted: o,
                        isScaled: i
                    }, "star" === c && p($l, {
                        isHighlighted: o,
                        isSelected: i,
                        stroke: is.star
                    }), "emoji" === c && h && p(Vl, {
                        emotion: h,
                        greyOut: t
                    }), "smiley" === c && h && p(Jl, {
                        emotion: h,
                        greyOut: t
                    }), "default" === c && h && p(Yl, {
                        emotion: h,
                        greyOut: t
                    })))
                };

            function us(e, n, t) {
                if (n && !Array.isArray(n) && "number" == typeof n.length) {
                    var r = n.length;
                    return ps(n, void 0 !== t && t < r ? t : r)
                }
                return e(n, t)
            }

            function ds(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return ps(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? ps(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function ps(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }

            function fs(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var hs, ms, _s = -1,
                vs = et.div(es || (es = fs(["\n    && {\n        display: flex;\n        flex-direction: column;\n        gap: ", ";\n        width: 100%;\n        max-width: 304px;\n        margin: 0 auto;\n    }\n"])), st.spacer.x1),
                ys = et.div(ns || (ns = fs(["\n    display: flex;\n    justify-content: space-between;\n    padding: ", " 0;\n"])), st.spacer.x1),
                bs = et.span(ts || (ts = fs(["\n    &&& {\n        font-size: 0.875em;\n        line-height: 1.25em;\n        color: ", ";\n        max-width: 45%;\n        text-align: ", ";\n    }\n\n    &&&& {\n        ", "\n    }\n"])), (function(e) {
                    return e.theme.textLight
                }), (function(e) {
                    return e.alignment
                }), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.scoreLabel
                })),
                gs = et.div(rs || (rs = fs(["\n    &&& {\n        display: flex;\n        justify-content: space-between;\n    }\n"]))),
                ws = ["M11.4 5.5c0-.4-.3-.8-.7-.8h-4a.7.7 0 1 0 0 1.5h2.2L5.2 10a.7.7 0 1 0 1 1L10 7.3v2.2a.8.8 0 0 0 1.5 0v-4Z", "M1.2 4.2c0-1.1 0-1.7.2-2.1.2-.4.5-.7.9-.9.4-.2 1-.2 2.1-.2H12c1.1 0 1.7 0 2.1.2.4.2.7.5.9.9.2.4.2 1 .2 2.1v7.6c0 1.1 0 1.7-.2 2.1a2 2 0 0 1-.9.9c-.4.2-1 .2-2.1.2H4.4c-1.1 0-1.7 0-2.1-.2a2 2 0 0 1-.9-.9c-.2-.4-.2-1-.2-2.1V4.2Zm3.2-1.7H12a16.7 16.7 0 0 1 1.4 0l.2.3V3l.1 1.2v7.6a16.7 16.7 0 0 1 0 1.4l-.3.2h-.2l-1.2.1H4.4a16.7 16.7 0 0 1-1.4 0l-.2-.3V13l-.1-1.2V4.2a16.7 16.7 0 0 1 0-1.4l.3-.2h.2l1.2-.1Zm9 0Zm.2.3Zm0 10.4Zm-.2.2ZM3 13.4Zm-.2-.2Zm0-10.4Zm.2-.2Z"],
                xs = function() {
                    return p("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 16 16",
                        width: "16",
                        height: "16"
                    }, p("path", {
                        fill: "#000",
                        fillOpacity: ".89",
                        d: ws[0]
                    }), p("path", {
                        fill: "#000",
                        fillOpacity: ".9",
                        fillRule: "evenodd",
                        d: ws[1],
                        clipRule: "evenodd"
                    }))
                };

            function ks(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var js, Ss, Cs, Ms = st.spacer.x5,
                Ps = et.div(hs || (hs = ks(["\n    &&& {\n        color: black;\n    }\n"]))),
                Os = et.div(ms || (ms = ks(["\n    &&& {\n        margin: 0 auto;\n        position: relative;\n        z-index: 1;\n        text-align: center;\n        flex-shrink: 0;\n        overflow: hidden;\n    }\n    div {\n        height: ", ";\n        width: 100%;\n        background-color: rgba(255, 255, 255, 0.9);\n        position: absolute;\n        bottom: -", ";\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        transition: bottom 100ms ease-in-out;\n\n        &:focus-visible,\n        &:has(:focus-visible) {\n            transition: none;\n        }\n\n        gap: ", ";\n        ", ";\n        color: ", ";\n    }\n\n    @media (prefers-reduced-motion) {\n        div {\n            transition: none;\n        }\n    }\n\n    img {\n        max-height: 200px;\n        max-width: 300px;\n        border-radius: 2px;\n    }\n\n    &:hover,\n    &:focus-visible,\n    &:has(:focus-visible) {\n        div {\n            bottom: 0;\n        }\n    }\n"])), Ms, Ms, st.spacer.x1, st.text.body2, (function(e) {
                    return e.theme.defaultText
                })),
                As = function(e) {
                    var n = e.imageAlt,
                        t = e.imagePath,
                        r = e.imageThumbnailPath,
                        o = dt(),
                        i = hj.features.hasFeature("survey.image_question"),
                        a = "string" == typeof t && t.length > 0 && "string" == typeof r && r.length > 0;
                    if (!i || !a) return null;
                    var l = Ki(t),
                        s = Ki(r);
                    return p(Os, {
                        theme: o
                    }, p("img", {
                        src: s,
                        alt: null != n ? n : ""
                    }), p(Ps, null, p(Pa, {
                        kind: "inline",
                        isExternal: !0,
                        href: l,
                        ariaLabel: hj.polls.translate("open_new_tab_aria")
                    }, hj.polls.translate("open_new_tab")), p(xs, null)))
                };

            function Is(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var zs, Es, Ts = et.label(js || (js = Is(["\n    flex: 1;\n    display: inline-block;\n\n    & > span {\n        border: 1px solid ", ";\n        cursor: pointer;\n    }\n\n    &:active span,\n    &:hover span {\n        border: ", ";\n    }\n\n    &:has(:focus-visible) span {\n        box-shadow: ", ";\n        outline: none;\n    }\n"])), (function(e) {
                    return e.theme.scaleDataPointBorder
                }), (function(e) {
                    var n = e.theme;
                    return "1px solid ".concat(n.scaleOutline, ";")
                }), (function(e) {
                    var n = e.theme;
                    return "0px 0px 0px 1px ".concat(n.background, ", 0px 0px 0px 3px ").concat(n.buttonOutline)
                })),
                Ns = et.span(Ss || (Ss = Is(["\n    &&& {\n        font-size: 0.875em; // 14px\n        border-radius: ", ";\n        background: ", ";\n        display: inline-flex;\n        justify-content: center;\n        align-items: center;\n        height: 40px;\n        flex-grow: 1;\n        color: ", ";\n        padding: 2px;\n        width: 100%;\n\n        ", "\n    }\n"])), st.radius.l, (function(e) {
                    return e.theme.background
                }), (function(e) {
                    return e.theme.scaleDataPointText
                }), (function(e) {
                    var n = e.isSelected,
                        t = e.theme;
                    return n && "color: ".concat(t.scaleDataPointTextSelected, ";\n                background: ").concat(t.scaleBackgroundSelected, ";\n                border: 3px solid ").concat(t.scaleOutline, ";\n            padding: 0px;\n            outline: none;\n        ")
                })),
                Ls = et.input(Cs || (Cs = Is(["\n    &&& {\n        position: absolute;\n        opacity: 0;\n        width: 0;\n        height: 0;\n    }\n"]))),
                Fs = function(e) {
                    var n = e.isSelected,
                        t = e.value,
                        r = e.onSelect,
                        o = e.groupName,
                        i = e.labelId,
                        a = dt();
                    return p(Ts, {
                        theme: a
                    }, p(Ls, {
                        "aria-describedby": i,
                        type: "radio",
                        value: t,
                        "aria-label": t,
                        name: o,
                        checked: n,
                        onClick: function() {
                            r(t)
                        }
                    }), p(Ns, {
                        isSelected: n,
                        theme: a,
                        "aria-hidden": "true"
                    }, t))
                };

            function Ds(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var Us, Bs, Rs, Hs, qs, $s = et.label(zs || (zs = Ds(["\n    &&& {\n        width: 100%;\n        padding: ", " 0;\n    }\n"])), st.spacer.x1),
                Zs = et.input(Es || (Es = Ds(["\n    &&& {\n        width: 100%;\n        height: ", ";\n        -webkit-appearance: none;\n        appearance: none;\n        background: transparent;\n        cursor: pointer;\n\n        background: #f1f2f6;\n        background: ", ";\n        border-radius: ", ";\n        transition: ", ";\n\n        ::-webkit-slider-runnable-track,\n        ::-moz-range-track {\n            height: ", ";\n            background: ", ";\n            border-radius: ", ";\n            transition: ", ";\n        }\n\n        ::-webkit-slider-thumb {\n            -webkit-appearance: none;\n            appearance: none;\n            margin-top: 0;\n            background-color: #fff;\n            border: 1px solid ", ";\n            border-radius: 50%;\n            width: 24px;\n            height: 24px;\n            filter: drop-shadow(0px 10px 15px rgba(16, 16, 16, 0.1)) drop-shadow(0px 4px 6px rgba(0, 0, 0, 0.03))\n                drop-shadow(0px 1px 3px rgba(0, 0, 0, 0.1));\n            transition: ", ";\n        }\n\n        :hover::-webkit-slider-thumb {\n            outline: 1px solid #838696;\n        }\n\n        :focus {\n            outline: none;\n        }\n\n        :focus-visible::-webkit-slider-thumb {\n            outline: 3px solid #5b72cb;\n            filter: none;\n        }\n\n        :focus-visible::-webkit-slider-thumb,\n        :focus-visible::-moz-range-thumb {\n            border: 1px solid #838696;\n        }\n    }\n"])), st.spacer.x1, (function(e) {
                    var n = e.progress,
                        t = e.theme,
                        r = e.isRTL;
                    return "linear-gradient(".concat(r ? "to left" : "to right", ", ").concat(t.scaleSliderFill, " ").concat(n, "%, ").concat(t.scaleSliderBackground, " ").concat(n, "%)")
                }), st.radius.m, st.animation.default, st.spacer.x1, (function(e) {
                    var n = e.progress,
                        t = e.theme,
                        r = e.isRTL;
                    return "linear-gradient(".concat(r ? "to left" : "to right", ", ").concat(t.scaleSliderFill, " ").concat(n, "%, ").concat(t.scaleSliderBackground, "  ").concat(n, "%)")
                }), st.radius.m, st.animation.default, (function(e) {
                    return e.theme.sliderThumbBorder
                }), st.animation.default),
                Ws = function(e) {
                    var n, t, r = e.value,
                        o = e.onSelect,
                        i = e.groupName,
                        a = e.labels,
                        l = "" === r || void 0 === r ? 0 : parseInt(r, 10),
                        s = 10 * l,
                        c = dt(),
                        u = 0 === l ? null === (n = a[0]) || void 0 === n ? void 0 : n.text : 10 === l ? null === (t = a[1]) || void 0 === t ? void 0 : t.text : "",
                        d = hj.widget.isActiveLanguageDirectionRtl;
                    return p($s, null, p(Zs, {
                        isRTL: d,
                        theme: c,
                        name: i,
                        type: "range",
                        min: "0",
                        max: "10",
                        step: "1",
                        progress: s,
                        value: l || 0,
                        onChange: function(e) {
                            o(e.currentTarget.value)
                        },
                        "aria-valuetext": "".concat(l, ", ").concat(u)
                    }))
                };

            function Gs(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return Vs(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? Vs(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Vs(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }

            function Xs(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var Js, Ks, Ys, Qs, ec = Array(11).fill("").map((function(e, n) {
                    return {
                        text: n
                    }
                })),
                nc = et.div(Us || (Us = Xs(["\n    && {\n        display: flex;\n        flex-direction: column;\n        gap: ", ";\n    }\n"])), st.spacer.x1),
                tc = et.div(Bs || (Bs = Xs(["\n    &&& {\n        display: flex;\n        justify-content: space-between;\n        gap: ", ";\n    }\n"])), st.spacer.x1),
                rc = et.span(Rs || (Rs = Xs(["\n    &&& {\n        font-size: 0.875em; // 14px\n        color: ", ";\n        max-width: 45%;\n        word-break: break-word;\n        text-align: ", ";\n    }\n\n    &&&& {\n        ", "\n    }\n"])), (function(e) {
                    return e.theme.textLight
                }), (function(e) {
                    return e.align
                }), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.scoreLabel
                })),
                oc = et.ul(Hs || (Hs = Xs(["\n    &&& {\n        display: flex;\n        flex-direction: row;\n        justify-content: space-between;\n        width: 100%;\n        padding: 0 -4px;\n\n        li {\n            font-size: 0.875em; // 14px\n            color: ", ";\n            padding: 0;\n            width: 20px;\n            text-align: center;\n        }\n    }\n"])), (function(e) {
                    return e.theme.textLight
                })),
                ic = et.div(qs || (qs = Xs(["\n    &&& {\n        display: flex;\n        justify-content: space-between;\n        ", ";\n    }\n"])), (function(e) {
                    return e.isNPS && "padding-left: ".concat(st.spacer.x0pt5)
                })),
                ac = function(e) {
                    var n = e.labelId,
                        t = e.question,
                        r = e.onChange,
                        o = dt(),
                        i = t.labels,
                        a = t.type,
                        l = function(e, n, t) {
                            if (n && !Array.isArray(n) && "number" == typeof n.length) {
                                var r = n.length;
                                return Vs(n, 2 < r ? 2 : r)
                            }
                            return e(n, 2)
                        }(Gs, W("")),
                        s = l[0],
                        c = l[1],
                        u = J((function() {
                            return i.map((function(e, n) {
                                return "hj-surveys-scale-option-label-".concat(n, "-").concat(hj.uuid())
                            }))
                        }), [i]),
                        d = J((function() {
                            var e = function(e) {
                                    return e === gt.RATING_5 ? 5 : e === gt.RATING_7 ? 7 : e === gt.NPS ? 10 : 0
                                }(a),
                                n = Array(e).fill(void 0);
                            return n[0] = u[0], n[e - 1] = u[1], n
                        }), [a, u]),
                        f = K((function(e) {
                            c(e);
                            var n = dr(a, e);
                            r(!0, {
                                answerText: e,
                                answerIndex: n
                            })
                        }), [a, r]);
                    return G((function() {
                        c("")
                    }), [t.uuid]), p(nc, {
                        "aria-labelledby": n,
                        role: "radiogroup"
                    }, p(tc, null, a === gt.NPS ? p(Ws, {
                        value: s,
                        groupName: t.uuid,
                        onSelect: f,
                        labels: i
                    }) : d.map((function(e, n) {
                        return p(Fs, {
                            groupName: t.uuid,
                            key: n,
                            onSelect: f,
                            isSelected: (n + 1).toString() === s,
                            value: (n + 1).toString(),
                            labelId: e
                        })
                    }))), a === gt.NPS && p(oc, {
                        theme: o
                    }, ec.map((function(e, n) {
                        return p("li", {
                            key: n,
                            value: n
                        }, e.text.toString())
                    }))), p(ic, {
                        isNPS: a === gt.NPS
                    }, i.map((function(e, n) {
                        return p(rc, {
                            key: n,
                            id: u[n],
                            theme: o,
                            title: e.text,
                            "aria-label": e.text,
                            align: 0 === n ? "left" : "right"
                        }, e.text)
                    }))))
                },
                lc = et.p(Js || (Js = function(e, n) {
                    return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(n)
                        }
                    }))
                }(["\n    &&& {\n        display: block;\n        color: ", " !important;\n        text-align: left;\n        ", ";\n    }\n\n    &&&& {\n        ", ";\n    }\n"])), (function(e) {
                    return e.theme.textLight
                }), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.survey
                }), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.questionDescription
                }));

            function sc(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var cc, uc = et.div(Ks || (Ks = sc(["\n    && {\n        display: flex;\n        text-align: left;\n        margin-right: ", ";\n    }\n"])), st.spacer.x1),
                dc = et.img(Ys || (Ys = sc(["\n    && {\n        max-height: 32px;\n        max-width: 100%;\n    }\n"]))),
                pc = function(e) {
                    var n = e.logo;
                    return p(uc, null, p(dc, {
                        "data-testid": "custom-footer-logo",
                        alt: "",
                        src: n
                    }))
                },
                fc = et.div(Qs || (Qs = sc(["\n    && {\n        margin-top: ", ";\n    }\n"])), st.spacer.x2),
                hc = function(e) {
                    return p(fc, null, p(pc, e))
                };

            function mc(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return _c(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _c(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function _c(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }
            var vc, yc, bc, gc, wc, xc = ((cc = {})[gt.RATING_5] = {
                    min: "1",
                    max: "5"
                }, cc[gt.REACTION] = {
                    min: "1",
                    max: "5"
                }, cc[gt.RATING_7] = {
                    min: "1",
                    max: "7"
                }, cc[gt.NPS] = {
                    min: "0",
                    max: "10"
                }, cc),
                kc = function(e) {
                    if (e && void 0 !== xc[e.type]) {
                        var n, t, r, o, i, a, l = {
                                scaleMin: null === (n = xc[e.type]) || void 0 === n ? void 0 : n.min,
                                scaleMax: null === (t = xc[e.type]) || void 0 === t ? void 0 : t.max,
                                scaleMinLabel: null === (r = e.labels) || void 0 === r || null === (o = r[0]) || void 0 === o ? void 0 : o.text,
                                scaleMaxLabel: null === (i = e.labels) || void 0 === i || null === (a = i[1]) || void 0 === a ? void 0 : a.text
                            },
                            s = Object.entries(l).reduce((function(e, n) {
                                var t = function(e, n, t) {
                                        if (n && !Array.isArray(n) && "number" == typeof n.length) {
                                            var r = n.length;
                                            return _c(n, 2 < r ? 2 : r)
                                        }
                                        return e(n, 2)
                                    }(mc, n),
                                    r = t[0],
                                    o = t[1],
                                    i = new RegExp("{{".concat(r, "}}"), "g");
                                return e.replace(i, null != o ? o : "")
                            }), hj.polls.translate("question_scale_aria"));
                        return "".concat(e.text, " ").concat(s)
                    }
                    return "".concat(e.text)
                };

            function jc(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var Sc, Cc, Mc, Pc = ((vc = {})[gt.TITLE_AND_DESCRIPTION] = function(e) {
                    var n = e.question,
                        t = dt();
                    return n.description ? p(lc, {
                        theme: t,
                        tabIndex: 0
                    }, p(Oa, {
                        text: n.description,
                        isInline: !0
                    })) : null
                }, vc[gt.SINGLE_OPEN_ENDED_MULTI_LINE] = pl, vc[gt.SINGLE_OPEN_ENDED_SINGLE_LINE] = pl, vc[gt.EMAIL] = pl, vc[gt.SINGLE_CLOSE_ENDED] = Hl, vc[gt.MULTIPLE_CLOSE_ENDED] = Hl, vc[gt.YES_NO] = Hl, vc[gt.RATING_5] = ac, vc[gt.RATING_7] = ac, vc[gt.NPS] = ac, vc[gt.REACTION] = function(e) {
                    var n = e.labelId,
                        t = e.question,
                        r = e.onChange,
                        o = e.hasInteracted,
                        i = t.reaction_style,
                        a = t.labels,
                        l = J((function() {
                            return a.map((function(e, n) {
                                return "hj-surveys-scale-option-label-".concat(n, "-").concat(hj.uuid())
                            }))
                        }), [a]),
                        s = us(ds, W(_s), 2),
                        c = s[0],
                        u = s[1],
                        d = us(ds, W(_s), 2),
                        f = d[0],
                        m = d[1],
                        _ = f > _s,
                        v = dt(),
                        y = us(ds, W(xt(v).isExternal), 2),
                        b = y[0],
                        g = y[1],
                        w = function(e) {
                            return "star" === i ? e <= f && c === _s : e === f
                        };
                    return i ? p(vs, {
                        "aria-labelledby": n,
                        role: "radiogroup"
                    }, p(ys, null, Array.apply(null, Array(5)).map((function(e, n) {
                        return p(cs, {
                            groupName: t.uuid,
                            score: n + 1,
                            key: n + 1,
                            isHighlighted: (a = n + 1, "star" === i ? a <= c : a === c),
                            onPreselection: function() {
                                return u(n + 1)
                            },
                            onResetPreselection: function() {
                                u(_s), g(!1)
                            },
                            onSelection: function() {
                                return function(e) {
                                    m(e), u(_s);
                                    var n = dr(gt.REACTION, e);
                                    r(!0, {
                                        answerText: e.toString(),
                                        answerIndex: n
                                    })
                                }(n + 1)
                            },
                            reactionStyle: i,
                            isSelected: w(n + 1),
                            greyOut: _ && !w(n + 1),
                            label: 0 === n ? l[0] : 4 === n ? l[1] : "",
                            hideFocus: b && !o
                        });
                        var a
                    }))), p(gs, null, a.map((function(e, n) {
                        return p(bs, {
                            key: n,
                            id: l[n],
                            "aria-label": e.text,
                            title: e.text,
                            theme: v,
                            alignment: 0 === n ? "left" : "right"
                        }, e.text)
                    })))) : p(h, null)
                }, vc),
                Oc = et.div(yc || (yc = jc(["\n    && {\n        display: flex;\n        align-items: center;\n        flex-direction: row-reverse;\n        ", "\n        margin-top: ", ";\n    }\n"])), (function(e) {
                    var n = e.withLogo;
                    return "justify-content: ".concat(n ? "space-between" : "flex-end", ";")
                }), st.spacer.x2),
                Ac = et.div(bc || (bc = jc(["\n    && {\n        ", "\n        display: flex;\n        flex-direction: row-reverse;\n        justify-content: flex-start;\n        align-items: center;\n        gap: ", ";\n\n        button {\n            width: 100%;\n\n            ", " {\n                width: auto;\n            }\n\n            ", "\n        }\n    }\n"])), (function(e) {
                    return e.fullWidth && "width: 100%;"
                }), st.spacer.x2, st.breakpoint.desktop, (function(e) {
                    return e.isPreviewMode ? "width: auto; ".concat(st.breakpoint.previewMobile, " { width: 100%; }") : ""
                })),
                Ic = et.h2(gc || (gc = jc(["\n    && {\n        top: 0;\n        z-index: 2;\n        display: block;\n        text-align: left;\n        font-size: 1em; // 16px\n        line-height: 1.5em; // 24px\n        font-weight: 500 !important;\n        margin: 0;\n        color: ", ";\n        overflow-wrap: break-word;\n        word-wrap: break-word;\n        background-color: ", ";\n    }\n\n    &&& {\n        ", ";\n    }\n\n    [dir='rtl'] && {\n        text-align: right;\n    }\n"])), (function(e) {
                    return e.theme.defaultText
                }), (function(e) {
                    return e.theme.background
                }), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.questionTitle
                })),
                zc = et.div(wc || (wc = jc(["\n    && {\n        display: flex;\n        flex-direction: column;\n        gap: ", ";\n        overflow-y: auto;\n        overflow-x: hidden;\n        padding: ", " ", ";\n        margin: -", " -", ";\n        background-color: ", ";\n    }\n"])), st.spacer.x1, st.spacer.x0pt5, st.spacer.x1pt5, st.spacer.x0pt5, st.spacer.x1pt5, (function(e) {
                    return e.theme.background
                })),
                Ec = function(e) {
                    var n, t, r, o = e.question,
                        i = e.isStepValid,
                        a = e.onQuestionSkipped,
                        l = e.onQuestionSubmitted,
                        s = e.onAnswerChange,
                        c = e.hideLogo,
                        u = e.logo,
                        d = e.forceMobile,
                        f = e.labelId,
                        m = dt(),
                        _ = Pc[o.type],
                        v = ft(sr()) || d,
                        y = o.type === gt.TITLE_AND_DESCRIPTION,
                        b = X(null),
                        g = !1 === c && null != u;
                    return G((function() {
                        var e;
                        y || null === (e = b.current) || void 0 === e || e.removeAttribute("tabindex")
                    }), [y]), p(h, null, p(zc, {
                        theme: m
                    }, p(Ic, {
                        id: f,
                        theme: m,
                        "aria-label": kc(o),
                        tabIndex: y ? 0 : void 0,
                        ref: b
                    }, p(Oa, {
                        text: o.text,
                        isInline: !0
                    })), !y && p(As, {
                        key: o.uuid,
                        imageAlt: o.image_alt,
                        imagePath: o.image_path,
                        imageThumbnailPath: o.image_thumbnail_path
                    }), p(_, {
                        key: o.uuid,
                        labelId: f,
                        question: o,
                        onChange: s,
                        onSubmit: l
                    }), y && p(As, {
                        key: o.uuid,
                        imageAlt: o.image_alt,
                        imagePath: o.image_path,
                        imageThumbnailPath: o.image_thumbnail_path
                    })), p(Oc, {
                        withLogo: g
                    }, p(Ac, {
                        isPreviewMode: sr(),
                        fullWidth: !g
                    }, p(pa, {
                        withCustomCSS: null === (n = m.customCSS) || void 0 === n ? void 0 : n.button,
                        isDisabled: !i,
                        onClick: l,
                        size: v ? "m" : "s",
                        ariaLabel: hj.polls.translate("next_aria")
                    }, hj.polls.translate("next")), !o.required && (v ? p(pa, {
                        withCustomCSS: null === (t = m.customCSS) || void 0 === t ? void 0 : t.skipButton,
                        kind: "ghost",
                        onClick: a
                    }, hj.polls.translate("skip")) : p(Pa, {
                        withCustomCSS: null === (r = m.customCSS) || void 0 === r ? void 0 : r.skipButton,
                        onClick: a,
                        as: "button",
                        kind: "inline"
                    }, hj.polls.translate("skip")))), g && p(pc, {
                        logo: u,
                        theme: m
                    })))
                };

            function Tc(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var Nc, Lc, Fc, Dc, Uc, Bc, Rc = function(e, n, t) {
                    var r = "desktop" === t ? "initial" : "none",
                        o = "mobile" === t ? "initial" : "none",
                        i = function(t) {
                            return n ? o : e ? r : t
                        };
                    return Gr(Sc || (Sc = Tc(["\n        display: ", ";\n\n        ", " {\n            display: ", ";\n        }\n    "])), i(o), st.breakpoint.desktop, i(r))
                },
                Hc = et.div(Cc || (Cc = Tc(["\n    && {\n        margin-top: ", ";\n        width: 100%;\n        text-align: center;\n        font-size: 0.875em; // 14px\n        color: ", ";\n        ", "\n    }\n"])), st.spacer.x6, (function(e) {
                    return e.theme.pageTextColor
                }), (function(e) {
                    var n = e.isPreviewMode,
                        t = e.forceMobilePreview;
                    return Rc(n, t, "desktop")
                })),
                qc = et.div(Mc || (Mc = Tc(["\n    && {\n        color: ", ";\n        margin-top: ", ";\n        font-size: 0.75em; // 12px\n        ", "\n    }\n"])), (function(e) {
                    return e.theme.defaultText
                }), st.spacer.x1pt5, (function(e) {
                    var n = e.isPreviewMode,
                        t = e.forceMobilePreview;
                    return Rc(n, t, "mobile")
                }));

            function $c(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var Zc, Wc, Gc, Vc, Xc = et.div(Lc || (Lc = $c(["\n    && {\n        width: 100%;\n        height: 100vh;\n        /* prefer dvh units if supported so mobile browser UI is accounted for */\n        height: 100dvh;\n        position: absolute;\n        top: 0;\n        left: 0;\n        flex-direction: column;\n\n        ", "\n        display: flex;\n    }\n"])), (function(e) {
                    return n = e.isPreviewMode, t = e.forceMobilePreview, r = "justify-content: center; align-items: center;", o = "justify-content: flex-end;", i = function(e) {
                        return t ? o : n ? r : e
                    }, Gr(Nc || (Nc = $c(["\n        ", "\n        ", " {\n            ", "\n        }\n    "])), i(o), st.breakpoint.desktop, i(r));
                    var n, t, r, o, i
                })),
                Jc = et.div(Bc || (Bc = $c(["\n    && {\n        background: white;\n        border-radius: ", " ", " 0 0;\n        box-shadow: ", ";\n        padding: ", " ", " ", ";\n        margin: auto;\n        overflow: auto;\n\n        * {\n            ", "\n            ", "\n        }\n\n        ", "\n        ", "\n        ", "\n    }\n"])), st.spacer.x1, st.spacer.x1, st.shadow.modal, st.spacer.x2pt5, st.spacer.x2pt5, st.spacer.x1pt5, st.text.fontFamily(), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.survey
                }), (function(e) {
                    return n = e.isPreviewMode, t = e.forceMobilePreview, r = "384px", o = "100%", i = function(e) {
                        return t ? o : n ? r : e
                    }, Gr(Fc || (Fc = $c(["\n        width: ", ";\n\n        ", " {\n            width: ", ";\n        }\n    "])), i(o), st.breakpoint.desktop, i(r));
                    var n, t, r, o, i
                }), (function(e) {
                    return n = e.isPreviewMode, t = e.forceMobilePreview, r = "".concat(st.spacer.x1), o = "".concat(st.spacer.x1, " ").concat(st.spacer.x1, " 0 0"), i = function(e) {
                        return t ? o : n ? r : e
                    }, Gr(Dc || (Dc = $c(["\n        border-radius: ", ";\n\n        ", " {\n            border-radius: ", ";\n        }\n    "])), i(o), st.breakpoint.desktop, i(r));
                    var n, t, r, o, i
                }), (function(e) {
                    return n = e.isPreviewMode, t = e.forceMobilePreview, r = "calc(100vh - 120px)", o = "100vh", i = function(e) {
                        return t ? o : n ? r : e
                    }, Gr(Uc || (Uc = $c(["\n        max-height: ", ";\n\n        ", " {\n            max-height: ", ";\n        }\n    "])), i(o), st.breakpoint.desktop, i(r));
                    var n, t, r, o, i
                })),
                Kc = function(e) {
                    var n = e.children,
                        t = e.labelId,
                        r = void 0 === t ? "" : t,
                        o = dt(),
                        i = {
                            isPreviewMode: sr(),
                            forceMobilePreview: e.isMobilePreview,
                            theme: o
                        };
                    return p(Xc, i, p("div", {
                        role: "dialog",
                        "aria-labelledby": r
                    }, p(Jc, i, n)), p(Hc, i, hj.polls.translate("password_warning")))
                },
                Yc = ue((function(e) {
                    var n = e.children,
                        t = e.labelId,
                        r = e.uniqueId,
                        o = e.isMobilePreview,
                        i = dt();
                    return p(Kc, {
                        isMobilePreview: o,
                        uniqueId: r,
                        labelId: t
                    }, n, p(qc, {
                        isPreviewMode: sr(),
                        forceMobilePreview: o,
                        theme: i
                    }, hj.polls.translate("password_warning")))
                }));

            function Qc(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var eu, nu, tu, ru, ou, iu, au, lu, su, cu = function(e, n, t, r, o) {
                    return n ? r : e ? o : t
                },
                uu = et.div(Wc || (Wc = Qc(["\n    && {\n        display: ", ";\n        flex-direction: column;\n        z-index: ", ";\n        background: ", ";\n        padding: ", " ", ";\n        overflow: hidden;\n\n        * {\n            ", "\n            ", "\n        }\n\n        ", "\n    }\n"])), (function(e) {
                    return e.isClosed ? "none" : "flex"
                }), st.maxIndex, (function(e) {
                    return e.backgroundColor
                }), st.spacer.x2, st.spacer.x2pt5, st.text.fontFamily(), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.survey
                }), (function(e) {
                    return n = e.isPreviewMode, t = e.forceMobilePreview, r = "0 0", o = "0 auto", i = "initial", a = "".concat(344, "px"), l = "".concat(st.spacer.x1), s = "".concat(st.shadow.desktop, ", 0px 4px 30px 0px rgba(0, 0, 0, 0.05)"), Gr(Zc || (Zc = Qc(["\n        margin: ", ";\n        max-width: ", ";\n        border-radius: ", ";\n        box-shadow: ", ";\n\n        ", " {\n            margin: ", ";\n            max-width: ", ";\n            border-radius: ", ";\n            box-shadow: ", ";\n        }\n    "])), cu(n, t, r, r, o), cu(n, t, i, i, a), cu(n, t, i, i, l), cu(n, t, i, i, s), st.breakpoint.desktop, cu(n, t, o, r, o), cu(n, t, a, i, a), cu(n, t, l, i, l), cu(n, t, s, i, s));
                    var n, t, r, o, i, a, l, s
                })),
                du = et.div(Vc || (Vc = Qc(["\n    && {\n        ", "\n    }\n"])), (function(e) {
                    return n = e.isPreviewMode, t = e.forceMobilePreview, r = "".concat(st.spacer.x2, " 0"), o = "".concat(st.spacer.x3, " 0"), Gr(Gc || (Gc = Qc(["\n        padding: ", ";\n\n        ", " {\n            padding: ", ";\n        }\n    "])), cu(n, t, r, r, o), st.breakpoint.desktop, cu(n, t, o, r, o));
                    var n, t, r, o
                })),
                pu = function(e) {
                    var n = e.isMobilePreview,
                        t = e.isClosed,
                        r = e.children,
                        o = e.labelId,
                        i = void 0 === o ? "" : o,
                        a = dt();
                    return p(du, {
                        isPreviewMode: sr(),
                        forceMobilePreview: n,
                        role: "dialog",
                        "aria-labelledby": i,
                        "aria-hidden": t
                    }, p(uu, {
                        backgroundColor: a.background,
                        isClosed: t,
                        position: a.position,
                        isPreviewMode: sr(),
                        forceMobilePreview: n,
                        theme: a
                    }, r))
                },
                fu = function(e) {
                    var n, t, r, o, i, a, l, s, c = e.all,
                        u = e.horizontal,
                        d = e.vertical,
                        p = e.left,
                        f = e.top,
                        h = e.right,
                        m = e.bottom,
                        _ = null !== (n = null !== (t = null != f ? f : d) && void 0 !== t ? t : c) && void 0 !== n ? n : "initial",
                        v = null !== (r = null !== (o = null != m ? m : d) && void 0 !== o ? o : c) && void 0 !== r ? r : "initial",
                        y = null !== (i = null !== (a = null != p ? p : u) && void 0 !== a ? a : c) && void 0 !== i ? i : "initial",
                        b = null !== (l = null !== (s = null != h ? h : u) && void 0 !== s ? s : c) && void 0 !== l ? l : "initial";
                    return "\n        margin-top: ".concat(_, "; \n        margin-bottom: ").concat(v, "; \n        margin-left: ").concat(y, "; \n        margin-right: ").concat(b, ";\n    ")
                };

            function hu(e, n) {
                return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(n)
                    }
                }))
            }
            var mu, _u = et.div(tu || (tu = hu(["\n    && {\n        background: ", ";\n        box-shadow: ", ";\n        padding: ", " ", " ", ";\n        margin: auto;\n        max-height: 100vh !important;\n        overflow: auto;\n        * {\n            ", "\n            ", "\n        }\n\n        ", "\n        ", "\n    }\n"])), (function(e) {
                    return e.theme.background
                }), st.shadow.modal, st.spacer.x2pt5, st.spacer.x2pt5, st.spacer.x1pt5, st.text.fontFamily(), (function(e) {
                    var n;
                    return null === (n = e.theme.customCSS) || void 0 === n ? void 0 : n.survey
                }), (function(e) {
                    return n = e.isPreviewMode, t = e.forceMobilePreview, r = "384px", o = "100%", i = function(e) {
                        return t ? o : n ? r : e
                    }, Gr(eu || (eu = hu(["\n        width: ", ";\n        ", " {\n            width: ", ";\n        }\n    "])), i(o), st.breakpoint.desktop, i(r));
                    var n, t, r, o, i
                }), (function(e) {
                    return n = e.isPreviewMode, t = e.forceMobilePreview, r = "".concat(st.spacer.x1), o = "".concat(st.spacer.x1, " ").concat(st.spacer.x1, " 0 0"), i = function(e) {
                        return t ? o : n ? r : e
                    }, Gr(nu || (nu = hu(["\n        border-radius: ", ";\n        ", " {\n            border-radius: ", ";\n        }\n    "])), i(o), st.breakpoint.desktop, i(r));
                    var n, t, r, o, i
                })),
                vu = et.div(ou || (ou = hu(["\n    && {\n        position: fixed;\n        top: 0;\n        left: 0;\n        z-index: ", ";\n        height: 100vh;\n        width: 100vw;\n        display: flex;\n        justify-content: center;\n        background: ", ";\n\n        ", "\n    }\n"])), st.maxIndex, st.colors.modal_overlay, (function(e) {
                    return n = e.isPreviewMode, t = e.forceMobilePreview, r = "center", o = function(e) {
                        return t ? "end" : n ? r : e
                    }, Gr(ru || (ru = hu(["\n        align-items: ", ";\n        ", " {\n            align-items: ", ";\n        }\n    "])), o("end"), st.breakpoint.desktop, o(r));
                    var n, t, r, o
                })),
                yu = et.dialog(au || (au = hu(["\n    && {\n        padding: 0;\n        border: none;\n        overflow: visible;\n        border-radius: ", ";\n        max-width: 100vw;\n        ", "\n\n        &::backdrop {\n            display: none;\n        }\n    }\n"])), st.spacer.x1, (function(e) {
                    return n = e.isPreviewMode, t = e.forceMobilePreview, r = "width: 100%; ".concat(fu({
                        all: "0",
                        top: "auto"
                    })), o = "width: fit-content; ".concat(fu({
                        all: "auto"
                    })), i = function(e) {
                        return t ? r : n ? o : e
                    }, Gr(iu || (iu = hu(["\n        ", "\n        ", " {\n            ", "\n        }\n    "])), i(r), st.breakpoint.desktop, i(o));
                    var n, t, r, o, i
                })),
                bu = et.div(lu || (lu = hu(["\n    && {\n        display: flex;\n        justify-content: end;\n        align-items: center;\n        height: ", ";\n    }\n"])), st.spacer.x4pt5),
                gu = et.button(su || (su = hu(["\n    && {\n        border: none;\n        border-radius: ", ";\n        background: none;\n        height: ", ";\n        width: ", ";\n        outline: none !important;\n\n        &:hover {\n            cursor: pointer;\n        }\n\n        &:focus-visible {\n            box-shadow: 0px 0px 0px 1px #ffffff, 0px 0px 0px 3px ", ";\n        }\n    }\n"])), st.spacer.x0pt5, st.spacer.x3, st.spacer.x3, (function(e) {
                    return e.theme.button
                })),
                wu = function(e) {
                    var n, t, r = e.children,
                        o = e.labelId,
                        i = void 0 === o ? "" : o,
                        a = e.isClosed,
                        l = e.onClose,
                        s = e.isMobilePreview,
                        c = {
                            isPreviewMode: sr(),
                            forceMobilePreview: s
                        },
                        u = dt(),
                        d = X(null),
                        f = !sr() && "function" == typeof HTMLDialogElement && "function" == typeof HTMLDialogElement.prototype.showModal,
                        h = X(),
                        m = X(!1),
                        _ = ao(null === (n = u.customCSS) || void 0 === n || null === (t = n.closeButton) || void 0 === t ? void 0 : t.color) || u.icon;
                    return G((function() {
                        f && setTimeout(hj.tryCatch((function() {
                            var e;
                            document.body.contains(d.current) && (m.current || d.current.showModal(), m.current = !0, sr() || (h.current instanceof IntersectionObserver && h.current.disconnect(), h.current = null !== (e = h.current) && void 0 !== e ? e : new IntersectionObserver((function(e) {
                                var n, t;
                                !0 !== (null === (n = e[0]) || void 0 === n ? void 0 : n.isIntersecting) && (null === (t = d.current) || void 0 === t || t.close(), l())
                            })), h.current.observe(d.current)))
                        }), "show-survey-modal"), 0)
                    }), [f]), a ? null : p(vu, {
                        forceMobilePreview: c.forceMobilePreview,
                        isPreviewMode: c.isPreviewMode
                    }, p(yu, {
                        as: f ? "dialog" : "div",
                        role: f ? "" : "dialog",
                        ref: d,
                        "aria-labelledby": i,
                        forceMobilePreview: c.forceMobilePreview,
                        isPreviewMode: c.isPreviewMode
                    }, p(_u, {
                        theme: u,
                        forceMobilePreview: c.forceMobilePreview,
                        isPreviewMode: c.isPreviewMode
                    }, p(bu, null, p(gu, {
                        theme: u,
                        onClick: l,
                        "aria-label": hj.polls.translate("close")
                    }, p(Xr, {
                        color: _
                    }))), r)))
                },
                xu = function(e, n) {
                    var t, r;
                    if (hj.isPreview) return !1;
                    var o = (null === (t = e.targeting) || void 0 === t ? void 0 : t.filter((function(e) {
                            return "url" === e.component
                        }))) || [],
                        i = null === (r = e.targeting) || void 0 === r ? void 0 : r.some((function(e) {
                            return "trigger" === e.component
                        })),
                        a = e.display_type === wt.EXTERNAL || e.display_type === wt.MOBILE_POPOVER,
                        l = i || a || !0 === hj.targeting.matchUrl(o, hj.currentUrl);
                    return hj.tryCatch((function() {
                        if (!l) throw new Error("Rendered survey out of URL targeting in ".concat(n, " with ID: ").concat(e.id))
                    }), "render-out-of-targeting")(), !l
                },
                ku = t(5104),
                ju = t.n(ku),
                Su = t(6228),
                Cu = t.n(Su),
                Mu = t(3399),
                Pu = t.n(Mu),
                Ou = t(8585),
                Au = t.n(Ou),
                Iu = function() {
                    return p(Wr, {
                        styles: [{
                            "@font-face": {
                                fontFamily: "roboto",
                                src: "url(".concat(Cu(), ") format('woff2'), url(").concat(ju(), ") format('woff')"),
                                fontWeight: "400",
                                fontStyle: "normal"
                            }
                        }, {
                            "@font-face": {
                                fontFamily: "roboto",
                                src: "url(".concat(Au(), ") format('woff2'), url(").concat(Pu(), ") format('woff')"),
                                fontWeight: "500",
                                fontStyle: "normal"
                            }
                        }]
                    })
                };

            function zu() {
                return zu = Object.assign ? Object.assign.bind() : function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var t = arguments[n];
                        for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r])
                    }
                    return e
                }, zu.apply(this, arguments)
            }

            function Eu(e, n, t) {
                if (n && !Array.isArray(n) && "number" == typeof n.length) {
                    var r = n.length;
                    return Nu(n, void 0 !== t && t < r ? t : r)
                }
                return e(n, t)
            }

            function Tu(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != t) {
                        var r, o, i, a, l = [],
                            s = !0,
                            c = !1;
                        try {
                            if (i = (t = t.call(e)).next, 0 === n) {
                                if (Object(t) !== t) return;
                                s = !1
                            } else
                                for (; !(s = (r = i.call(t)).done) && (l.push(r.value), l.length !== n); s = !0);
                        } catch (e) {
                            c = !0, o = e
                        } finally {
                            try {
                                if (!s && null != t.return && (a = t.return(), Object(a) !== a)) return
                            } finally {
                                if (c) throw o
                            }
                        }
                        return l
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return Nu(e, n);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? Nu(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Nu(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
                return r
            }
            var Lu = 0,
                Fu = 0,
                Du = et.form(mu || (mu = function(e, n) {
                    return n || (n = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(n)
                        }
                    }))
                }(["\n    && {\n        overflow: hidden;\n        display: flex;\n        flex-direction: column;\n        position: relative;\n        padding: 0 ", ";\n        margin: 0 -", ";\n        justify-content: center;\n        flex-grow: 1;\n    }\n"])), st.spacer.x2pt5, st.spacer.x2pt5);

            function Uu(e) {
                switch (e) {
                    case wt.EXTERNAL:
                    case wt.FULL_SCREEN:
                        return !1;
                    default:
                        return !0
                }
            }
            var Bu = function(e) {
                    var n, t = e.survey;
                    ! function(e) {
                        var n = function(e, n, t) {
                                if (n && !Array.isArray(n) && "number" == typeof n.length) {
                                    var r = n.length;
                                    return yt(n, 2 < r ? 2 : r)
                                }
                                return e(n, 2)
                            }(vt, W(bt)),
                            t = n[0],
                            r = n[1];
                        G((function() {
                            return _t.add((function() {
                                    r(bt())
                                }), e),
                                function() {
                                    return _t.remove(e)
                                }
                        }), [e])
                    }(t.id);
                    var r, o = dt(),
                        i = lr(o),
                        a = "once" === t.persist_condition,
                        l = xt(o),
                        s = l.isExternal,
                        c = l.isModal,
                        u = l.isPopover,
                        d = l.isButton,
                        f = l.isInline,
                        h = l.isBubble,
                        m = l.isMobilePopover,
                        _ = Eu(Tu, W((function() {
                            return "hotjar-survey-" + hj.uuid()
                        })), 1)[0],
                        v = Eu(Tu, W((function() {
                            return "hj-survey-lbl-".concat(Lu += 1)
                        })), 1)[0],
                        y = Eu(Tu, W((function() {
                            return "hj-survey-toggle-".concat(Fu += 1)
                        })), 1)[0],
                        b = Eu(Tu, W(!(null !== (n = t.preview) && void 0 !== n && n.forceExpanded) && (r = t.id, !hj.isPreview && hj.bridge.storage.items.POLL_MINIMIZED.exists(r) || d || h || u && ht(t.previewDevice, o.displayType))), 2),
                        g = b[0],
                        w = b[1],
                        x = Eu(Tu, W(!1), 2),
                        k = x[0],
                        j = x[1],
                        S = qr(t, k),
                        C = S.state,
                        M = S.actions,
                        P = C.isSubmitted,
                        O = C.answerValid,
                        A = C.hasInteracted,
                        I = C.question,
                        z = C.isFinalStep,
                        E = C.isClosed,
                        T = M.onQuestionSkipped,
                        N = M.onQuestionSubmitted,
                        L = M.setInteracted,
                        F = M.onAnswerChange,
                        D = M.onClose,
                        U = I && I.type === gt.TITLE_AND_DESCRIPTION,
                        B = Ki(t.logo_path || t.logo_url),
                        R = X(!1);
                    R.current || (R.current = !0, xu(t, "Survey component"));
                    var H = function() {
                            hj.bridge.storage.items.POLL_DONE.add(t.id)
                        },
                        q = function() {
                            if (m) D();
                            else {
                                if (sr() || function(e, n) {
                                        n ? hj.bridge.storage.items.POLL_MINIMIZED.add(e) : hj.bridge.storage.items.POLL_MINIMIZED.remove(e)
                                    }(t.id, !g), a) {
                                    if (g) return w(!1);
                                    H(), D()
                                } else w((function(e) {
                                    return !e
                                }));
                                sr() || setTimeout((function() {
                                    var e = document.getElementById(y);
                                    e && e.focus()
                                }))
                            }
                        };
                    G((function() {
                        sr() || (t.ask_for_consent && hj.request.getConsentGranted((function(e) {
                            j(e)
                        })), a && H(), hj.event.signal("poll.show", hj.widget.pollsData[t.id]))
                    }), [j, t]), G((function() {
                        sr() && z && L(!0)
                    }), [z]);
                    var $ = X(null),
                        Z = X(null),
                        V = X(null),
                        J = X(null),
                        K = X(null);
                    G((function() {
                        var e, n;
                        (A || (s || c) && !sr()) && null !== $.current && (e = $.current, n = function(e) {
                            var n = e.querySelectorAll(Zr);
                            if (0 !== n.length) {
                                var t = Array.from(n);
                                return t.sort($r), t[0]
                            }
                        }(e), null == n || n.focus())
                    }), [I]), G((function() {
                        var e;
                        U || null === (e = K.current) || void 0 === e || e.removeAttribute("tabindex")
                    }), [U]);
                    var Y = "phone" === t.previewDevice,
                        Q = !(sr() ? Y : ft()),
                        ee = null != B,
                        ne = p(Du, zu({}, g ? {
                            inert: !0
                        } : {}, {
                            onSubmit: function(e) {
                                return e.preventDefault()
                            },
                            ref: $
                        }), z ? p($a, {
                            theme: o,
                            showLegal: t.show_legal,
                            thankYouMessage: t.content.thankyou,
                            askForConsent: t.ask_for_consent,
                            isSubmitted: P,
                            surveyId: t.id,
                            showCloseButton: Uu(t.display_type),
                            onClose: D
                        }) : p(Ec, {
                            question: I,
                            isStepValid: I.type === gt.TITLE_AND_DESCRIPTION || O,
                            hideLogo: !Q,
                            logo: B,
                            onQuestionSkipped: T,
                            onQuestionSubmitted: N,
                            onAnswerChange: F,
                            forceMobile: Y,
                            labelId: v
                        }), ee && !Q && p(hc, {
                            logo: B,
                            theme: o
                        }));
                    return p("div", {
                        ref: i.ref,
                        lang: hj.polls.translate("lang") || "en",
                        id: _,
                        dir: hj.widget.isActiveLanguageDirectionRtl ? "rtl" : "ltr"
                    }, p(Iu, null), p("div", {
                        "data-testid": "survey-root",
                        ref: V
                    }, function() {
                        if (u || m) {
                            var e = m || (sr() ? "phone" === t.previewDevice : ft());
                            return p(Eo, {
                                question: I,
                                isMinimized: g,
                                isClosed: E,
                                isFinalStep: z,
                                showCloseButton: a || m,
                                updateMinimizedState: q,
                                isMobile: e,
                                showBorder: !m,
                                showBackdrop: !m,
                                labelId: v,
                                toggleId: y
                            }, ne)
                        }
                        return h ? p(ei, {
                            isMinimized: g,
                            isClosed: E,
                            isFinalStep: z,
                            isShowingOnce: a,
                            updateMinimizedState: q,
                            isMobilePreview: "phone" === t.previewDevice,
                            uniqueId: _,
                            labelId: v,
                            toggleId: y
                        }, ne) : d ? p(Ji, {
                            isMinimized: g,
                            isClosed: E,
                            isFinalStep: z,
                            isShowingOnce: a,
                            updateMinimizedState: q,
                            isMobilePreview: "phone" === t.previewDevice,
                            labelId: v,
                            toggleId: y,
                            buttonLabel: t.button_survey_label,
                            surveyBodyRef: J,
                            buttonRef: Z
                        }, ne) : s ? p(Yc, {
                            isMobilePreview: "phone" === t.previewDevice,
                            uniqueId: _,
                            labelId: v
                        }, ne) : f ? p(pu, {
                            isClosed: E,
                            isMobilePreview: "phone" === t.previewDevice,
                            labelId: v
                        }, ne) : c ? p(wu, {
                            onClose: D,
                            isMobilePreview: "phone" === t.previewDevice,
                            uniqueId: _,
                            labelId: v,
                            isClosed: E
                        }, ne) : p("div", null)
                    }()))
                },
                Ru = t(5090),
                Hu = t.n(Ru);

            function qu(e) {
                return qu = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, qu(e)
            }

            function $u(e, n) {
                for (var t = 0; t < n.length; t++) {
                    var r = n[t];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, Zu(r.key), r)
                }
            }

            function Zu(e) {
                var n = function(e, n) {
                    if ("object" != qu(e) || !e) return e;
                    var t = e[Symbol.toPrimitive];
                    if (void 0 !== t) {
                        var r = t.call(e, "string");
                        if ("object" != qu(r)) return r;
                        throw new TypeError("@@toPrimitive must return a primitive value.")
                    }
                    return String(e)
                }(e);
                return "symbol" == qu(n) ? n : String(n)
            }

            function Wu(e, n, t) {
                return n = Vu(n),
                    function(e, n) {
                        if (n && ("object" === qu(n) || "function" == typeof n)) return n;
                        if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                        return function(e) {
                            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return e
                        }(e)
                    }(e, Gu() ? Reflect.construct(n, t || [], Vu(e).constructor) : n.apply(e, t))
            }

            function Gu() {
                try {
                    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {})))
                } catch (e) {}
                return (Gu = function() {
                    return !!e
                })()
            }

            function Vu(e) {
                return Vu = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
                    return e.__proto__ || Object.getPrototypeOf(e)
                }, Vu(e)
            }

            function Xu(e, n) {
                return Xu = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, n) {
                    return e.__proto__ = n, e
                }, Xu(e, n)
            }
            var Ju = function(e) {
                function n(e) {
                    return function(e, n) {
                        if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function")
                    }(this, n), Wu(this, n, [e])
                }
                var t, r;
                return function(e, n) {
                    if ("function" != typeof n && null !== n) throw new TypeError("Super expression must either be null or a function");
                    e.prototype = Object.create(n && n.prototype, {
                        constructor: {
                            value: e,
                            writable: !0,
                            configurable: !0
                        }
                    }), Object.defineProperty(e, "prototype", {
                        writable: !1
                    }), n && Xu(e, n)
                }(n, e), t = n, (r = [{
                    key: "componentDidCatch",
                    value: function(e) {
                        hj.exceptions.log(e, this.props.moduleName)
                    }
                }, {
                    key: "render",
                    value: function() {
                        return this.props.children
                    }
                }]) && $u(t.prototype, r), Object.defineProperty(t, "prototype", {
                    writable: !1
                }), n
            }(m);

            function Ku(e) {
                return Ku = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, Ku(e)
            }
            var Yu = function(e) {
                return "survey_".concat(e)
            };

            function Qu(e, n) {
                if (hj.surveyImpressionsEndpoint && !hj.isPreview) {
                    var t = "".concat(hj.surveyImpressionsEndpoint, "?id=").concat(e, "&device=").concat(Ja(), "&survey_type=").concat(n);
                    hj.log.debug("poll id: ".concat(e, " recording impression."), "poll"), hj.ajax.get(t)
                } else hj.log.debug("poll id: ".concat(e, " skipping recording impression."), "poll")
            }

            function ed(n, t) {
                var r, o, a, c, u, d, f, m, _, v, y, b, g = (a = (r = n).background || "#ffffff", c = r.button_color || "#324FBE", u = rr(c), d = kt(c), f = "light" === r.skin, m = kt(a), _ = ar(a, u.colors, m ? 700 : 300), v = kt(_), y = kt(null !== (o = r.pageBackground) && void 0 !== o ? o : ""), b = r.custom_css ? io(r.custom_css) : null, {
                        skin: r.skin,
                        displayType: r.display_type,
                        position: r.position,
                        background: a,
                        overlay: "rgba(26, 25, 25, 0.7)",
                        button: u.colors[500],
                        buttonHover: _,
                        buttonOutline: ar(a, u.colors, m ? 600 : 400),
                        buttonText: d ? u.colors[999] : u.colors[0],
                        buttonTextHover: v ? u.colors[999] : u.colors[0],
                        buttonSecondaryText: m ? ar(a, u.colors, 500, 4.5) : u.colors[0],
                        ghostButton: "transparent",
                        ghostButtonText: f ? u.colors[999] : u.colors[0],
                        ghostButtonHover: u.greys[100],
                        defaultText: f ? u.colors[999] : u.colors[0],
                        textLight: f ? "rgba(0,0,0, 0.7)" : "rgba(255, 255, 255, 0.94)",
                        subtitle: f ? "#111" : "#FFF",
                        title: f ? u.colors[999] : u.colors[0],
                        disabled: u.greys[100],
                        disabledText: ar(a, u.greys, d ? 700 : 300, 2),
                        icon: ar(a, u.greys, 500),
                        iconHover: ar(a, u.greys, 700),
                        option: ar(a, u.colors, 500),
                        optionText: f ? u.colors[999] : u.colors[0],
                        optionBorder: ar(a, u.greys, 200),
                        optionBorderActive: ar(a, u.colors, 700),
                        optionBackgroundSelected: u.colors[100],
                        optionTextSelected: u.colors[999],
                        inputText: f ? u.colors[999] : u.colors[0],
                        inputPlaceholder: ar(a, u.greys, f ? 500 : 300, 4.5),
                        inputBorder: ar(a, u.greys, m ? 200 : 0),
                        inputBorderActive: ar(a, u.greys, 400),
                        inputOutline: ar(a, u.colors, 300),
                        scaleBackground: a,
                        scaleBackgroundHover: a,
                        scaleBackgroundSelected: u.colors[100],
                        scaleDataPointText: f ? u.colors[999] : u.colors[0],
                        scaleDataPointTextSelected: u.colors[999],
                        scaleDataPointBorder: ar(a, u.greys, 200),
                        scaleDataPointBorderHover: ar(a, u.greys, 500),
                        scaleDataPointBorderHoverOutline: ar(a, u.greys, 400),
                        scaleDataPointBorderActive: ar(a, u.greys, 200),
                        scaleOutline: ar(a, u.colors, 500),
                        scaleSliderBackground: u.greys[100],
                        scaleSliderFill: ar(a, u.colors, 500),
                        scaleSliderBorder: ar(a, u.greys, 100),
                        scaleSliderBorderHover: ar(a, u.greys, 400),
                        scaleSliderBorderFocus: ar(a, u.colors, 500),
                        sliderThumbBorder: ar(a, u.greys, m ? 400 : 600),
                        pageTextColor: y ? "rgba(0,0,0, 0.7)" : "rgba(255, 255, 255, 0.94)",
                        customCSS: b
                    }),
                    w = xt(g).isInline,
                    x = document.createElement("div");
                if (x.classList.add(mr), x.id = Yu(null == n ? void 0 : n.id), !xu(n, "renderSurveyWidget")) {
                    t.appendChild(x), hj.surveyImpressionsMoved && Qu(n.id, n.display_type), g.skin && x.classList.add("_hj-widget-theme-".concat(g.skin));
                    var k = [Hu().globalStyles, Hu().resetStyles, Hu()[hj.widget.activeLanguageDirection]];
                    w && k.push(Hu().inlineSurvey);
                    var j = k.join(" ");
                    ! function(n, t, r) {
                        var o, a, c;
                        e.__ && e.__(n, t), a = (o = r === i) ? null : r && r.__k || t.__k, n = p(h, null, [n]), c = [], P(t, (o ? t : r || t).__k = n, a || l, l, void 0 !== t.ownerSVGElement, r && !o ? [r] : a ? null : t.childNodes.length ? s.slice.call(t.childNodes) : null, c, r || l, o), O(c, n)
                    }(p(Ju, {
                        moduleName: "polls"
                    }, p(ut, {
                        theme: g
                    }, p("div", {
                        className: j
                    }, p(Bu, {
                        key: n.id,
                        survey: n
                    })))), x)
                }
            }
            var nd, td, rd = hj.tryCatch((function(e, n) {
                var t = "inline" === (null == e ? void 0 : e.display_type),
                    r = hj.features.hasFeature("survey.embeddable_widget");
                if (!t || r) {
                    var o, i = t ? e.parent_element_selector : n,
                        a = (o = i) instanceof HTMLElement || "object" === Ku(o) && 1 === o.nodeType && "object" === Ku(o.style) && "object" === Ku(o.ownerDocument) ? i : document.querySelector(i);
                    if (!xu(e, "renderSurvey")) return a && _r(a, ".".concat(mr)), (hj.isPreview || !t && a) && ed(e, a), t && i && !hj.isPreview && function(e, n) {
                        var t = new MutationObserver(r);

                        function r() {
                            var t = document.querySelector(n),
                                r = document.getElementById(Yu(null == e ? void 0 : e.id));
                            t && !r && (hj.surveyImpressionsMoved || Qu(e.id, e.display_type), ed(e, t))
                        }
                        setTimeout(hj.tryCatch((function() {
                            r(), t.observe(document.documentElement || document.body, {
                                attributes: !0,
                                attributeOldValue: !0,
                                childList: !0,
                                subtree: !0,
                                characterData: !0
                            }), hj.widget.registerObserverForInlineWidget(t)
                        }), "polls"), 250)
                    }(e, i), rd
                }
            }), "polls");
            hj.polls.translate = (nd = {
                af: {
                    next: "Volgende",
                    please_type_here: "Tik asb. hier ...",
                    reply: "Antwoort",
                    feedback: "Terugvoer",
                    close: "Sluit",
                    give_consent: "Ja seker",
                    decline_consent: "Nee dankie",
                    skip: "Slaan oor.",
                    password_warning: "Moenie wagwoorde invoer nie",
                    comment_label: "Voer 'n opmerking in"
                },
                ar: {
                    next: "التالى",
                    please_type_here: "الرجاء الكتابة هنا...",
                    reply: "رد",
                    consent: "ربط ردودك بالبيانات المتعلقة بزيارتك للموقع (ببيانات الجهاز المستخدم، بيانات الاستخدام ، ملفات تعريف الارتباط (الكوكيز)، والتفاعلات) سيساعدنا على تحسين الخدمة بشكل أسرع. هل توافق على القيام بذلك لزياراتك السابقة والمستقبلية؟",
                    comment_for_option: "التعليق على الخيار",
                    consent_more_information: "المزيد من المعلومات",
                    feedback: "رأي",
                    close: "أغلق",
                    skip: "تجاوز",
                    give_consent: "نعم بالتأكيد",
                    decline_consent: "ًلا شكرا",
                    password_warning: "أبداً لا تدخل كلمات المرور",
                    comment_label: "أدخل تعليق"
                },
                bg: {
                    next: "Следващия",
                    please_type_here: "Моля напишете Вашия отговор тук...",
                    reply: "Отговор",
                    consent: "Свързвайки вашата обратна връзка с данни свързани с посещенията на вашата страница (спрямо устройство, данни за потреблението, бизквитки, поведение и интеракции) ще ни помогне да подобрим услугата си. Съгласни ли сте да направим това за досегашните и бъдещите посещения на вашата страница?",
                    consent_more_information: "Повече информация",
                    feedback: "Обратна връзка",
                    close: "Затвори",
                    skip: "Пропусни",
                    give_consent: "Да, разбира се",
                    decline_consent: "Не благодаря",
                    password_warning: "Никога не въвеждайте пароли",
                    comment_label: "Въведете коментар"
                },
                ca: {
                    next: "Següent",
                    please_type_here: "Introdueix aquí...",
                    reply: "Respondre",
                    consent: "Connectant els teus comentaris amb les dades relacionades a les teves visites (específics del dispositiu, ús de dades, cookies, comportament i interaccions) ens ajudarà a millorar més rapidament. Podem comptar amb el teu consentiment per connectar-los, per a les teves anteriors i futures visites?",
                    consent_more_information: "Més informació",
                    feedback: "Comentaris",
                    close: "Tanca",
                    skip: "Omet",
                    give_consent: "Si, es clar",
                    decline_consent: "No gràcies",
                    password_warning: "Mai introdueixis contrasenyes",
                    comment_label: "Introdueix un comentari"
                },
                cs: {
                    next: "Další",
                    please_type_here: " Zde prosím odpovězte...",
                    reply: "Odpovědět",
                    consent: "Připojená zpětná vazba od vás spolu s údaji o vašich návštěvách (typ zařízení, využití dat, soubory cookies, chování a vzájemné interakce) nám pomůže se rychleji zlepšovat. Udělíte nám s tímto souhlas pro vaše předchozí a budoucí návštěvy?",
                    consent_more_information: "Další informace",
                    feedback: "Zpětná vazba",
                    close: "Zavřít",
                    skip: "Přeskočit",
                    give_consent: "Ano jistě",
                    decline_consent: "Ne, díky",
                    password_warning: "Nikdy nezadávejte hesla",
                    comment_label: "Zadejte komentář"
                },
                cy: {
                    next: "Nesaf",
                    please_type_here: "Teipiwch yma os gwelwch yn dda...",
                    reply: "Ateb",
                    feedback: "Adborth",
                    close: "Cau",
                    skip: "Symud Ymlaen",
                    give_consent: "Iawn siwr",
                    decline_consent: "Dim Diolch",
                    password_warning: "Peidiwch byth â rhoi cyfrinair",
                    comment_label: "Rhowch sylw"
                },
                da: {
                    next: "Næste",
                    please_type_here: "Skriv venligst her...",
                    reply: "Svar",
                    consent: "Hvis du forbinder din feedback med data som er relaterede til dine besøg (enhedsspecifikke, brugerdata, cookies, adfærd og interaktioner), kan vi hurtigere forbedre os. Giver du os tilladelse til at gøre dette for dine tidligere og kommende besøg?",
                    consent_more_information: "Flere oplysninger ",
                    feedback: "Feedback",
                    close: "Luk",
                    skip: "Spring over",
                    give_consent: "Ja sikkert",
                    decline_consent: "Nej tak",
                    password_warning: "Indtast aldrig adgangskoder",
                    comment_label: "Indtast en kommentar"
                },
                de: {
                    next: "Weiter",
                    please_type_here: "Bitte hier eingeben …",
                    reply: "Antworten",
                    consent: "Bevor Du gehst: Dürfen wir deine Antwort mit Daten (Gerät, Nutzung, Cookies, Verhalten und Interaktionen) zu deinen Besuchen verknüpfen? So können wir dir eine bessere Erfahrung bieten.",
                    surveyComplete: "Umfrage abgeschlossen",
                    this_field_is_required: "Eingabe erforderlich",
                    comment_for_option: "Kommentar zur Option",
                    open_new_tab: "In neuem Tab öffnen",
                    open_new_tab_aria: "Bild in neuem Tab öffnen",
                    show_survey: "Umfrage einblenden",
                    hide_survey: "Umfrage ausblenden",
                    close_survey: "Umfrage schließen",
                    made_with_hotjar: "Mit Hotjar ausgeführt",
                    made_with_hotjar_surveys: "Erstellt mit Hotjar Surveys",
                    consent_more_information: "Weitere Informationen",
                    privacy_policy: "Datenschutzrichtlinie",
                    feedback: "Feedback",
                    close: "Schließen",
                    skip: "Überspringen",
                    consent_more_information_url: "https://www.hotjarconsent.com/de.html",
                    try_hotjar: "Probiere Hotjar aus",
                    want_feedback_like_this: "Wünschst Du Feedback dieser Art?",
                    give_consent: "Ja, sicher",
                    decline_consent: "Nein, danke",
                    next_aria: "Nächste Frage",
                    password_warning: "Bitte gib niemals persönliche Daten oder Passwörter ein",
                    comment_label: "Einen Kommentar abgeben"
                },
                el: {
                    next: "Επόμενο",
                    please_type_here: "Παρακαλώ πληκτρολογήστε εδώ...",
                    reply: "Απάντηση",
                    consent: "Η σύνδεση των σχολίων σας με δεδομένα που σχετίζονται με τις επισκέψεις σας (δεδομένα σχετικά με τη συσκευή σας, δεδομένα χρήσης, cookies, συμπεριφορά και αλληλεπιδράσεις) θα μας βοηθήσει να βελτιωθούμε ταχύτερα. Μας δίνετε τη συναίνεσή σας να πραγματοποιήσουμε αυτή τη σύνδεση για προηγούμενες και επόμενες επισκέψεις σας;",
                    consent_more_information: "Περισσότερες πληροφορίες",
                    feedback: "Feedback",
                    close: "Κλείσιμο",
                    skip: "Παράλειψη",
                    give_consent: "Ναι σίγουρα",
                    decline_consent: "Οχι ευχαριστώ",
                    consent_more_information_url: "https://www.hotjarconsent.com/el.html",
                    password_warning: "Ποτέ μην εισάγετε κωδικούς πρόσβασης",
                    comment_label: "Εισαγάγετε ένα σχόλιο"
                },
                en: {
                    next: "Next",
                    please_type_here: "Please type here...",
                    reply: "Reply",
                    consent: "Before you go, can we connect your response with data (device, usage, cookies, behavior, and interactions) related to your visits? This will help us give you a better experience.",
                    surveyComplete: "Survey complete",
                    this_field_is_required: "This field is required",
                    comment_label: "Enter a comment",
                    comment_for_option: "Comment for option",
                    open_new_tab: "Open in new tab",
                    open_new_tab_aria: "Open image in a new tab",
                    show_survey: "Show survey",
                    hide_survey: "Hide survey",
                    close_survey: "Close survey",
                    made_with_hotjar: "Made with Hotjar",
                    made_with_hotjar_surveys: "Made with Hotjar Surveys",
                    consent_more_information: "More information",
                    privacy_policy: "Privacy Policy",
                    feedback: "Feedback",
                    close: "Close",
                    skip: "Skip",
                    consent_more_information_url: "https://www.hotjarconsent.com",
                    try_hotjar: "Try Hotjar",
                    want_feedback_like_this: "Want feedback like this?",
                    give_consent: "Yes, sure",
                    decline_consent: "No thanks",
                    next_aria: "Next question",
                    question_scale_aria: "Select an option from {{scaleMin}} to {{scaleMax}}, with {{scaleMin}} being {{scaleMinLabel}} and {{scaleMax}} being {{scaleMaxLabel}}",
                    enter_a_valid_email: "Enter a valid email",
                    password_warning: "Never enter passwords"
                },
                es: {
                    next: "Siguiente",
                    please_type_here: "Escribe aquí...",
                    reply: "Responder",
                    consent: "Antes de que te vayas, ¿podemos conectar tu respuesta con los datos (dispositivo, uso, cookies, comportamiento, interacciones) relacionados con tus visitas? Esto nos ayudará a darte una mejor experiencia.",
                    surveyComplete: "Encuesta completada",
                    this_field_is_required: "Este campo es obligatorio",
                    comment_for_option: "Comentario para opción",
                    open_new_tab: "Abrir en una pestaña nueva",
                    open_new_tab_aria: "Abrir imagen en una pestaña nueva",
                    show_survey: "Mostrar encuesta",
                    hide_survey: "Ocultar encuesta",
                    close_survey: "Cerrar encuesta",
                    made_with_hotjar: "Hecho con Hotjar",
                    made_with_hotjar_surveys: "Realizado con encuestas de Hotjar",
                    consent_more_information: "Más información",
                    privacy_policy: "Política de privacidad",
                    feedback: "Feedback",
                    close: "Cerrar",
                    skip: "Saltar",
                    consent_more_information_url: "https://www.hotjarconsent.com/es.html",
                    try_hotjar: "Prueba Hotjar",
                    want_feedback_like_this: "¿Quieres feedback como este?",
                    give_consent: "Sí, claro",
                    decline_consent: "No, gracias",
                    next_aria: "Siguiente pregunta",
                    password_warning: "Nunca ingreses contraseñas",
                    comment_label: "Introduce un comentario"
                },
                et: {
                    next: "Järgmine",
                    please_type_here: "Palun sisesta siia...",
                    reply: "Vasta",
                    feedback: "Tagasiside",
                    close: "Sulge",
                    skip: "Jäta vahele",
                    give_consent: "Jah muidugi",
                    decline_consent: "Ei aitäh",
                    password_warning: "Ärge kunagi sisestage paroole",
                    comment_label: "Sisestage kommentaar"
                },
                fa: {
                    next: "بعد",
                    please_type_here: "لطفا اینجا بنویسید",
                    reply: "پاسخ",
                    comment_for_option: "نظر برای گزینه",
                    feedback: "نظرسنجی",
                    close: "بستن",
                    skip: "رد کردن",
                    give_consent: "بله حتما",
                    decline_consent: "نه ممنون",
                    password_warning: "هرگز رمزهای عبور را وارد نکنید",
                    comment_label: "یک نظر وارد کنید"
                },
                fi: {
                    next: "Seuraava",
                    please_type_here: "Kirjoita tähän",
                    reply: "Vastaa",
                    consent: "Palautteesi yhdistäminen vierailuihisi liittyviin tietoihin (laitekohtaiset, käyttötiedot, evästeet, käyttäytyminen ja vuorovaikutus) auttaa meitä tekemään parannuksia nopeammin. Annatko meille suostumuksesi tehdä näin aiemmille sekä tuleville vierailuillesi?",
                    consent_more_information: "Lisää tietoja",
                    feedback: "Palaute",
                    close: "Sulje",
                    skip: "Ohita",
                    give_consent: "Toki",
                    decline_consent: "Ei kiitos",
                    consent_more_information_url: "https://www.hotjarconsent.com/fi.html",
                    password_warning: "Älä koskaan syötä salasanoja",
                    comment_label: "Kirjoita kommentti"
                },
                fr: {
                    next: "Suivant",
                    please_type_here: "Veuillez saisir du texte ici...",
                    reply: "Répondre",
                    consent: "Avant de partir, nous autorisez-vous à lier vos réponses aux données (appareil, utilisation, cookies, comportement et interactions) concernant vos visites ? Cela nous aiderait à vous offrir une meilleure expérience.",
                    surveyComplete: "Enquête terminée",
                    this_field_is_required: "Ce champ est obligatoire",
                    comment_for_option: "Commentaire pour l’option",
                    open_new_tab: "Ouvrir dans un nouvel onglet",
                    open_new_tab_aria: "Ouvrir l’image dans un nouvel onglet",
                    show_survey: "Afficher l’enquête",
                    hide_survey: "Masquer l’enquête",
                    close_survey: "Fermer l’enquête",
                    made_with_hotjar: "Créé avec Hotjar",
                    made_with_hotjar_surveys: "Réalisé avec Hotjar Surveys",
                    consent_more_information: "En savoir plus",
                    privacy_policy: "Politique de confidentialité",
                    feedback: "Feedback",
                    close: "Fermer",
                    skip: "Passer",
                    consent_more_information_url: "https://www.hotjarconsent.com/fr.html",
                    try_hotjar: "Essayez Hotjar",
                    want_feedback_like_this: "Vous souhaitez recevoir ce type de feedback ?",
                    give_consent: "Oui, bien sûr",
                    decline_consent: "Non, merci",
                    next_aria: "Question suivante",
                    password_warning: "N'entrez jamais de mots de passe",
                    comment_label: "Entrez un commentaire"
                },
                he: {
                    next: "הבא",
                    please_type_here: "הקלד כאן...",
                    reply: "תגובה",
                    consent: "חיבור המשוב שלך עם נתונים הקשורים לביקורים שלך (ספציפיים למכשיר, נתוני שימוש, קובצי cookie, התנהגות ואינטראקציות) יעזור לנו להשתפר מהר יותר. האם את/ה נותן/ת לנו את הסכמתך לעשות זאת לגבי ביקוריך בעבר ובעתיד?",
                    comment_for_option: "הערה לאופציה",
                    consent_more_information: "מידע נוסף",
                    feedback: "חוות דעת",
                    close: "סגור",
                    skip: "דלג",
                    give_consent: "כן בטח",
                    decline_consent: "לא תודה",
                    password_warning: "אל תזין אף פעם סיסמאות",
                    comment_label: "הכנס תגובה"
                },
                hr: {
                    next: "Sljedeći",
                    please_type_here: "Pišite ovdje",
                    reply: "Odgovor",
                    consent: "Povjezivanje vaših primjedbi i prijedloga sa podacima u vezi vaših posjeta (po uređaju: podaci o korišćenju, kolačići, ponašanje i interakcije) će nam pomoći u našem bržem unapređenju. Da li nam dajete dozvolu za to uraditi za vaše prijethodne i buduće posjete?",
                    consent_more_information: "Više podataka",
                    feedback: "Povratna informacija",
                    close: "Zatvori",
                    skip: "Preskoči",
                    give_consent: "Da naravno",
                    decline_consent: "Ne hvala",
                    password_warning: "Nikada ne unosite lozinke",
                    comment_label: "Unesite komentar"
                },
                hu: {
                    next: "Következő",
                    please_type_here: "Ide írhat...",
                    reply: "Válasz",
                    consent: "Az ön visszajelzésének és a látogatásával kapcsolatos adatainak (eszköztípus, felhasználási adatok, sütik, viselkedés és interakció) összekapcsolásával segíthet nekünk a gyorsabb fejlődésben. Hozzájárul ahhoz, hogy ezt megtegyük az ön előző és a jövőbeni látogatásai alkalmával?",
                    consent_more_information: "Több információ",
                    feedback: "Visszajelzés",
                    close: "Bezárás",
                    skip: "Átugrom",
                    give_consent: "Igen, persze",
                    decline_consent: "Nem köszönöm",
                    password_warning: "Soha ne írjon be jelszavakat",
                    comment_label: "Írjon be egy megjegyzést"
                },
                id: {
                    next: "Berikutnya",
                    please_type_here: "Silahkan ketik disini...",
                    reply: "Balasan",
                    feedback: "Umpan balik",
                    close: "Tutup",
                    skip: "Lewati",
                    give_consent: "Ya tentu",
                    decline_consent: "Tidak, terima kasih",
                    password_warning: "Jangan pernah memasukkan kata sandi",
                    comment_label: "Masukkan komentar"
                },
                it: {
                    next: "Prossima",
                    please_type_here: "Scrivi qui...",
                    reply: "Rispondi",
                    consent: "Collegare questo feedback ai dati relativi alle tue visite (dispositivo, utilizzo, cookie, comportamento e interazioni) ci aiuterà a migliorare più rapidamente. Ci dai il consenso a farlo per visite passate e future?",
                    surveyComplete: "Sondaggio completato",
                    this_field_is_required: "Questo campo è obbligatorio",
                    comment_for_option: "Commento per l'opzione",
                    open_new_tab: "Apri in una nuova scheda",
                    open_new_tab_aria: "Apri immagine in una nuova scheda",
                    show_survey: "Mostra sondaggio",
                    hide_survey: "Nascondi sondaggio",
                    close_survey: "Chiudi sondaggio",
                    made_with_hotjar: "Realizzato con Hotjar",
                    made_with_hotjar_surveys: "Realizzato con Hotjar Surveys",
                    consent_more_information: "Maggiori informazioni",
                    privacy_policy: "Politica sulla Privacy",
                    feedback: "Feedback",
                    close: "Chiudi",
                    skip: "Salta",
                    consent_more_information_url: "https://www.hotjarconsent.com/it.html",
                    try_hotjar: "Prova Hotjar",
                    want_feedback_like_this: "Desideri un feedback di questo tipo?",
                    give_consent: "Sì, certo",
                    decline_consent: "No grazie",
                    next_aria: "Prossima domanda",
                    comment_label: "Inserisci un commento",
                    password_warning: "Non inserire mai le password"
                },
                ja: {
                    next: "次",
                    please_type_here: "こちらにご記入ください...",
                    reply: "返信",
                    consent: "あなたのフィードバックとサイト訪問に関連するデータ（デバイスの仕様、利用時間データ、クッキー、行動、相互作用）を結び付けることが、私たちの改善スピードをより速くする助けとなります。あなたの以前の訪問と今後の訪問について、そのようにすることを承諾していただけますか？",
                    consent_more_information: "さらに詳しく",
                    feedback: "フィードバック",
                    close: "閉じる",
                    skip: "スキップ",
                    give_consent: "はい、もちろんです",
                    decline_consent: "結構です",
                    password_warning: "パスワードを入力しないでください",
                    comment_label: "コメントを入力してください"
                },
                ko: {
                    next: "다음",
                    please_type_here: "여기에 입력해주세요",
                    reply: "답변하기",
                    consent: "귀하의 피드백을 방문과 관련된 데이터 (장치별, 사용 데이터, 쿠키, 동작 및 상호 작용)와 연결해 주시면, 저희가 더 빨리 발전할 수 있습니다. 귀하의 이전과 미래의 방문에 대해 그렇게 해 주시는 것에 동의하시겠습니까?",
                    consent_more_information: "더 알아보기",
                    feedback: "피드백",
                    close: "닫기",
                    skip: "건너뛰기",
                    give_consent: "물론이지",
                    decline_consent: "고맙지 만 사양 할게",
                    password_warning: "절대로 비밀번호를 입력하지 마세요",
                    comment_label: "댓글을 입력하세요"
                },
                lt: {
                    next: "Kitas",
                    please_type_here: "Rašyti čia...",
                    reply: "Atsakyti",
                    consent: "Jūsų atsiliepimas ir duomenys susiję su jūsų apsilankymais (konkretūs įrenginiai, naudojimo duomenys, slapukai, elgesys ir veiksmai) padės mums tobulėti greičiau. Ar sutinkate su tokių duomenų issaugojimu jūsų praeities ir ateities apsilankymams.",
                    consent_more_information: "Daugiau informacijos",
                    feedback: "Atsiliepimai",
                    close: "Uždaryti",
                    skip: "Praleisti",
                    give_consent: "Taip, žinoma",
                    decline_consent: "Ne, ačiū",
                    password_warning: "Niekada neįveskite slaptažodžių",
                    comment_label: "Įveskite komentarą"
                },
                lv: {
                    next: "Nākamais",
                    please_type_here: "Lūdzu, ievadiet šeit...",
                    reply: "Atbilde",
                    feedback: "Atsauksme",
                    close: "Aizvērt",
                    skip: "Izlaist",
                    give_consent: "Jā, protams",
                    decline_consent: "Nē paldies",
                    password_warning: "Nekad neievadiet paroles",
                    comment_label: "Ievadiet komentāru"
                },
                mis: {
                    next: "Sljedeći",
                    please_type_here: "Pišite ovdje...",
                    reply: "Odgovori",
                    consent: "Povjezivanje vaših primjedbi i prijedloga sa podacima u vezi vaših posjeta (po uređaju: podaci o korišćenju, kolačići, ponašanje i interakcije) će nam pomoći da se brže unaprijedimo. Da li nam dajete dozvolu da to uradimo za vaše prijethodne i buduće posjete?",
                    consent_more_information: "Više podataka",
                    close: "Zatvori",
                    give_consent: "Da naravno",
                    decline_consent: "Ne hvala",
                    password_warning: "Nikada ne unosite lozinke",
                    comment_label: "Унесите коментар",
                    feedback: "Повратна информација",
                    skip: "Скип"
                },
                nb: {
                    next: "Neste",
                    please_type_here: "Skriv her...",
                    reply: "Svar",
                    consent: "Ved å knytte tilbakemeldingen din med data som er relatert til besøkene dine (enhetsspesifikt, bruksdata, informasjonskapsler, atferd og samhandlinger), hjelper det oss med å bli bedre raskere. Gir du oss ditt samtykke til å gjøre det med dine tidligere og fremtidige besøk?",
                    consent_more_information: "Mer informasjon",
                    feedback: "Tilbakemelding",
                    close: "Lukk",
                    skip: "Hopp over",
                    give_consent: "Ja sikkert",
                    decline_consent: "Nei takk",
                    password_warning: "Aldri skriv inn passord",
                    comment_label: "Skriv inn en kommentar"
                },
                nl: {
                    next: "Volgende",
                    please_type_here: "Jouw bericht...",
                    reply: "Reageer",
                    consent: "Door het verbinden van uw feedback met data die verband houdt met uw bezoek aan de site (specifiek voor een apparaat, gebruiksdata, cookies, gedrag en interacties) kunnen we sneller verbeteringen aanbrengen. Geeft u ons toestemming om dit te doen voor uw bezoeken in het verleden en in de toekomst?",
                    surveyComplete: "Enquête voltooid",
                    this_field_is_required: "Dit veld is verplicht",
                    comment_for_option: "Opmerking voor optie",
                    open_new_tab: "Openen in nieuw tabblad",
                    open_new_tab_aria: "Afbeelding openen in een nieuw tabblad.",
                    show_survey: "Toon enquête",
                    hide_survey: "Verberg enquête",
                    close_survey: "Enquête sluiten",
                    made_with_hotjar: "Gemaakt met Hotjar",
                    made_with_hotjar_surveys: "Gemaakt met Hotjar Surveys",
                    consent_more_information: "Meer informatie",
                    privacy_policy: "Privacybeleid",
                    feedback: "Feedback",
                    close: "Sluiten",
                    skip: "Overslaan",
                    consent_more_information_url: "https://www.hotjarconsent.com/nl.html",
                    try_hotjar: "Probeer Hotjar",
                    want_feedback_like_this: "Wilt u feedback zoals deze?",
                    give_consent: "Ja, zeker",
                    decline_consent: "Nee bedankt",
                    next_aria: "Volgende vraag",
                    password_warning: "Vul nooit wachtwoorden in",
                    comment_label: "Voer een opmerking in"
                },
                pl: {
                    next: "Dalej",
                    please_type_here: "Wpisz wiadomość...",
                    reply: "Odpowiedz",
                    consent: "Łączenie Twoich odpowiedzi z informacjami o Twoich wizytach na stronie (dot. używanego urządzenia, sposobu użytkowania strony, plików cookie, zachowania i interakcji) pozwoli nam na szybsze udoskonalenie się. Czy wyrażasz zgodę na łączenie tych danych z Twoich poprzednich i przyszłych wizyt?",
                    surveyComplete: "Ankieta ukończona",
                    this_field_is_required: "To pole jest wymagane",
                    comment_for_option: "Komentarz",
                    open_new_tab: "Otwórz w nowej zakładce",
                    open_new_tab_aria: "Otwórz obraz w nowej zakładce",
                    show_survey: "Pokaż ankietę",
                    hide_survey: "Ukryj ankietę",
                    close_survey: "Zamknij ankietę",
                    made_with_hotjar: "Stworzone za pomocą Hotjar",
                    made_with_hotjar_surveys: "Wykonano za pomocą ankiet Hotjar",
                    consent_more_information: "Więcej informacji",
                    privacy_policy: "Polityka Prywatności",
                    feedback: "Opinia",
                    close: "Zamknij",
                    skip: "Pomiń",
                    consent_more_information_url: "https://www.hotjarconsent.com/pl.html",
                    try_hotjar: "Wypróbuj Hotjar",
                    want_feedback_like_this: "Chcesz takiej opinii?",
                    give_consent: "Tak, oczywiście",
                    decline_consent: "Nie, dziękuję",
                    next_aria: "Następne pytanie",
                    password_warning: "Nigdy nie wpisuj haseł",
                    comment_label: "Wpisz komentarz"
                },
                pt_BR: {
                    next: "Seguinte",
                    please_type_here: "Escreva aqui...",
                    reply: "Responder",
                    consent: "Antes de você ir, podemos conectar sua resposta aos dados (dispositivo, uso, cookies, comportamento e interações) relacionados às suas visitas? Isso nos ajudará a proporcionar uma experiência melhor.",
                    surveyComplete: "Pesquisa concluída",
                    this_field_is_required: "Este campo é obrigatório",
                    comment_for_option: "Comentário para a opção",
                    open_new_tab: "Abrir em uma nova guia",
                    open_new_tab_aria: "Abrir imagem em uma nova guia",
                    show_survey: "Mostrar pesquisa",
                    hide_survey: "Ocultar pesquisa",
                    close_survey: "Fechar pesquisa",
                    made_with_hotjar: "Feito com o Hotjar",
                    made_with_hotjar_surveys: "Feito com Hotjar Surveys",
                    consent_more_information: "Saiba mais",
                    privacy_policy: "Política de privacidade",
                    feedback: "Feedback",
                    close: "Fechar",
                    skip: "Pular",
                    consent_more_information_url: "https://www.hotjarconsent.com/pt_br.html",
                    try_hotjar: "Experimente o Hotjar",
                    want_feedback_like_this: "Quer feedback como este?",
                    give_consent: "Sim, claro",
                    decline_consent: "Não, obrigado",
                    next_aria: "Próxima pergunta",
                    password_warning: "Nunca digite senhas",
                    comment_label: "Insira um comentário"
                },
                pt: {
                    next: "Seguinte",
                    please_type_here: "Por favor, escreva aqui ...",
                    reply: "Responder",
                    consent: "Ao associar o seu feedback aos dados das suas visitas (dispositivo, dados de utilização, cookies, comportamento e interações) ajuda-nos a melhorar a sua experiência com mais rapidez. Para o continuarmos a fazer, precisamos do seu consentimento relativo a visitas anteriores e futuras.",
                    consent_more_information: "Saber mais",
                    feedback: "Feedback",
                    close: "Fechar",
                    skip: "Ignorar",
                    give_consent: "Sim, claro",
                    decline_consent: "Não, obrigado",
                    consent_more_information_url: "https://www.hotjarconsent.com/pt.html",
                    password_warning: "Nunca insira senhas",
                    comment_label: "Insira um comentário"
                },
                ro: {
                    next: "Următoarea",
                    please_type_here: "Scrie aici...",
                    reply: "Răspunde",
                    consent: "Conectarea observațiilor și opiniilor dvs. cu datele rezultate din vizitele dvs. (dispozitive folosite, date de utilizare, fișiere cookie, comportament și interacțiuni) ne va ajuta să ne îmbunătățim serviciile mai rapid. Ne acordați consimțământul dvs. pentru a face acest lucru atât pentru vizitele dvs. anterioare, cât și pentru cele viitoare?",
                    consent_more_information: "Mai multe informații",
                    feedback: "Feedback",
                    close: "Închide",
                    skip: "Treci peste",
                    give_consent: "Da sigur",
                    decline_consent: "Nu, mulțumesc",
                    password_warning: "Nu introduceți niciodată parolele",
                    comment_label: "Introdu un comentariu"
                },
                ru: {
                    next: "Далее",
                    please_type_here: "Место для ввода...",
                    reply: "Ответить",
                    consent: "Связь ваших отзывов с данными о посещении вами сайта (данные об устройстве, сведения об использовании, файлы cookie, поведение и активность на сайте) поможет нам быстрее улучшить наши услуги. Даете ли вы нам свое согласие на использование данных о ваших предыдущих и будущих посещениях сайта?",
                    consent_more_information: "Дополнительная информация",
                    feedback: "Обратная связь",
                    close: "Закрыть",
                    skip: "Пропустить",
                    give_consent: "Да, конечно",
                    decline_consent: "Нет, спасибо",
                    consent_more_information_url: "https://www.hotjarconsent.com/ru.html",
                    password_warning: "Никогда не вводите пароли",
                    comment_label: "Введите комментарий"
                },
                sk: {
                    next: "Ďalšie",
                    please_type_here: "Začnite písať tu",
                    reply: "Odpovedať",
                    consent: "Prepojenie Vašej spätnej väzby s dátami súvisiacimi s Vašimi návštevami (špecifikácia zariadenia, využitie dát, správanie a interakcie) nám pomôže rýchlejšie sa zlepšovať. Dáte nám súhlas na to, aby sme tak spravili v prípade Vašich minulých aj budúcich návštev?",
                    consent_more_information: "Pre viac informácií kliknite sem",
                    feedback: "Váš názor",
                    close: "Zavrieť",
                    skip: "Preskočiť",
                    give_consent: "Áno samozrejme",
                    decline_consent: "Nie ďakujem",
                    password_warning: "Nikdy nezadávajte heslá",
                    comment_label: "Zadajte komentár"
                },
                sl: {
                    next: "Naslednji",
                    please_type_here: "Prosimo vnesite tukaj...",
                    reply: "Odgovori",
                    feedback: "Povratna informacija",
                    close: "Zapri",
                    skip: "Preskoči",
                    give_consent: "Ja seveda",
                    decline_consent: "Ne hvala",
                    password_warning: "Nikoli ne vnašajte gesel",
                    comment_label: "Vnesite komentar"
                },
                sq: {
                    next: "Tjetër",
                    please_type_here: "Ju lutem shkruani këtu...",
                    reply: "Përgjigju",
                    consent: "Lidhja midis vlerwsimit tuaj dhe infromacioneve qw kanw lidhje (nw lidhje) me vizitat tuaja(device-specific,…) do tw na ndihmonin tw permisohemi akoma mw shpejt. A do tw na jepni aprovimin tuaj pwr tw bwrw kwtw me vizitat tuaja tw mwparshme dhe me ato nw tw ardhmen?",
                    consent_more_information: "Më shumë informacion",
                    feedback: "Mendimi juaj",
                    close: "Mbyll",
                    skip: "Kalo",
                    give_consent: "Po sigurisht",
                    decline_consent: "Jo faleminderit",
                    consent_more_information_url: "https://www.hotjarconsent.com/sq.html",
                    password_warning: "Kurrë mos shkruani fjalëkalime",
                    comment_label: "Shkruani një koment"
                },
                sr: {
                    next: "Sledeći",
                    please_type_here: "Pišite ovde...",
                    reply: "Odgovori",
                    consent: "Povezivanje vaših primedbi i predloga sa podacima u vezi vaših poseta (po uređaju: podaci o korišćenju, kolačići, ponašanje i interakcije) će nam pomoći da se brže unapredimo. Da li nam dajete dozvolu da to uradimo za vaše prethodne i buduće posete?",
                    consent_more_information: "Više podataka",
                    feedback: "Povratna informacija",
                    close: "Zatvori",
                    skip: "Preskoči",
                    give_consent: "Da siguran",
                    decline_consent: "Ne hvala",
                    password_warning: "Nikada ne unosite lozinke",
                    comment_label: "Унесите коментар"
                },
                sv: {
                    next: "Nästa",
                    please_type_here: "Skriv här...",
                    reply: "Besvara",
                    consent: "Att koppla din feedback med data förknippade med dina besök (enhetsspecifik, användningsdata, cookies, beteende och interaktioner) hjälper oss att bli bättre snabbare. Ger du oss ditt tillstånd att göra detta för dina tidigare och framtida besök?",
                    surveyComplete: "Undersökning klar",
                    this_field_is_required: "Detta fält är obligatoriskt",
                    comment_for_option: "Kommentar för alternativ",
                    open_new_tab: "Öppna i ny flik",
                    open_new_tab_aria: "Öppna bilden i en ny flik",
                    show_survey: "Visa undersökning",
                    hide_survey: "Dölj undersökning",
                    close_survey: "Stäng undersökning",
                    made_with_hotjar: "Gjord med Hotjar",
                    made_with_hotjar_surveys: "Tillverkad med Hotjar Surveys",
                    consent_more_information: "Mer information",
                    privacy_policy: "Integritetspolicy",
                    feedback: "Feedback",
                    close: "Stäng",
                    skip: "Hoppa över",
                    consent_more_information_url: "https://www.hotjarconsent.com/sv.html",
                    try_hotjar: "Prova Hotjar",
                    want_feedback_like_this: "Vill du ha feedback som denna?",
                    give_consent: "Ja, visst",
                    decline_consent: "Nej tack",
                    next_aria: "Nästa fråga",
                    password_warning: "Ange aldrig lösenord",
                    comment_label: "Skriv en kommentar"
                },
                sw: {
                    next: "Ifuatayo",
                    please_type_here: "Tafadhali andika hapa...",
                    reply: "Jibu",
                    consent: "Kuhusisha maoni yako na data inayohusiana na ziara zako (kifaa unachotumia, data ya utumizi, mwenendo na jinsi ya matumizi) itatusaidia kujiboresha kwa kasi zaidi. Je, unatupa idhini yako kufanya hivyo kwa ziara zako za awali na zijazo?",
                    consent_more_information: "Maelezo zaidi",
                    feedback: "Mrejesho",
                    close: "Funga",
                    skip: "Ruka",
                    give_consent: "Ndiyo, hakika",
                    decline_consent: "Hapana, asante",
                    password_warning: "Usiingie nywila kamwe",
                    comment_label: "Weka maoni"
                },
                th: {
                    next: "ต่อไป",
                    please_type_here: "โปรดพิมพ์ที่นี่...",
                    reply: "ตอบ",
                    consent: "การเชื่อมโยงข้อเสนอแนะของคุณกับข้อมูลที่เกี่ยวข้องกับการเข้าชมของคุณ (เจาะจงอุปกรณ์, คุกกี้, พฤติกรรม และการโต้ตอบ) จะช่วยให้เราปรับปรุงได้อย่างรวดเร็วยิ่งขึ้น คุณต้องการยินยอมให้เรากระทำการดังกล่าวสำหรับการเข้าชมของคุณในก่อนหน้านี้และในอนาคตหรือไม่",
                    consent_more_information: "ข้อมูลเพิ่มเติม",
                    feedback: "ฟีดแบ็ค",
                    close: "ปิด",
                    skip: "ข้าม",
                    give_consent: "แน่นอน",
                    decline_consent: "ไม่เป็นไรขอบคุณ",
                    password_warning: "อย่าเคยป้อนรหัสผ่าน",
                    comment_label: "ใส่ความคิดเห็น"
                },
                tl: {
                    next: "Susunod",
                    please_type_here: "Dito po magsimulang magsulat...",
                    reply: "Tumugon",
                    consent: "Ang pag-uugnay ng iyong mga komento sa mga datos na may kaugnayan sa iyong mga pagbisita (para sa espesipikong aparato, mga datos sa paggamit, mga cookies, pag-uugali at pakikipag-ugnayan) ay makakatulong sa amin na humusay nang mas mabilis. Ibinibigay mo ba sa amin ang iyong pahintulot na gawin ito para sa iyong mga nakaraan at darating pang pagbisita?",
                    consent_more_information: "Karagdagang impormasyon",
                    feedback: "Feedback",
                    close: "Isara",
                    skip: "Laktawan",
                    give_consent: "Oo ba",
                    decline_consent: "Salamat nalang",
                    password_warning: "Huwag kailanman maglagay ng mga password",
                    comment_label: "Maglagay ng komento"
                },
                tr: {
                    next: "Sonraki",
                    please_type_here: "Cevabınızı buraya giriniz...",
                    reply: "Cevapla",
                    feedback: "Geribildirim",
                    close: "Kapat",
                    skip: "Atla",
                    give_consent: "Evet elbette",
                    decline_consent: "Hayır, teşekkürler",
                    password_warning: "Asla şifreler girme",
                    comment_label: "Bir yorum girin"
                },
                uk: {
                    next: "наступний",
                    please_type_here: "Місце для вводу...",
                    reply: "Відповісти",
                    consent: "Поєднання ваших відгуків із даними, пов'язаними з вашими візитами (дані про окремі пристрої, користування, файли-реп'яшки, поведінку та взаємодії), допоможе нам покращуватись швидше. Ви дозволяєте робити це щодо ваших попередніх та майбутніх візитів?",
                    consent_more_information: "Більше інформації",
                    feedback: "Зворотній зв'язок",
                    close: "Закрити",
                    give_consent: "Так, авжеж",
                    decline_consent: "Ні, дякую",
                    skip: "Пропустити",
                    password_warning: "Ніколи не вводьте паролі",
                    comment_label: "Введіть коментар"
                },
                vi: {
                    next: "Kế tiếp",
                    please_type_here: "Vui lòng nhập nội dung tại đây...",
                    reply: "Trả lời",
                    consent: "Kết nối phản hồi của bạn với dữ liệu liên quan đến các lần truy cập của bạn (thiết bị cụ thể, dữ liệu sử dụng, cookie, hành vi và tương tác) sẽ giúp chúng tôi cải thiện nhanh hơn. Bạn có đồng ý cho chúng tôi làm như vậy cho các lần truy cập trước và trong tương lai của bạn không?",
                    consent_more_information: "Thêm thông tin",
                    feedback: "Phản hồi",
                    close: "Đóng",
                    give_consent: "Vâng, chắc chắn rồi",
                    decline_consent: "Không, cám ơn",
                    skip: "Bỏ qua",
                    password_warning: "Đừng bao giờ nhập mật khẩu",
                    comment_label: "Nhập bình luận"
                },
                zh_CN: {
                    next: "下一个",
                    please_type_here: "请输入...",
                    reply: "回复",
                    consent: "为了运营和改善Hotjar的技术和服务，Hotjar 希望将您的反馈与您的访问相关数据相结合。您是否同意我们收集您在过去以及未来访问过程中产生的访问数据(包括设备信息、使用数据、Cookies、行为和互动数据）？",
                    consent_more_information: "更多信息",
                    feedback: "反馈",
                    close: "关闭",
                    skip: "跳过",
                    give_consent: "是的，当然",
                    decline_consent: "不，谢谢",
                    consent_more_information_url: "https://www.hotjarconsent.com/zh.html",
                    password_warning: "永远不要输入密码",
                    comment_label: "输入评论"
                },
                zh_TW: {
                    next: "下一個",
                    please_type_here: "請輸入...",
                    reply: "回覆",
                    consent: "將您的意見反應與您的造訪相關資料（所用的裝置、使用狀況資料、Cookie、行為與互動）做連結，將有助於我們更快速改善。您同意我們就您先前與之後的造訪來這麼做嗎？",
                    consent_more_information: "更多資訊",
                    feedback: "回饋",
                    close: "關閉",
                    skip: "跳過",
                    give_consent: "是的，當然",
                    decline_consent: "不，謝謝",
                    password_warning: "絕不輸入密碼",
                    comment_label: "輸入評論"
                }
            }, td = nd, {
                translate: function(e) {
                    try {
                        var n, t, r = null === (n = hj.widget) || void 0 === n ? void 0 : n.getActiveLanguage(),
                            o = null === (t = td[r]) || void 0 === t ? void 0 : t[e];
                        return null != o ? o : td.en[e]
                    } catch (e) {
                        hj.exceptions.log(new Error("Failed to translate: ".concat(e)))
                    }
                }
            }).translate, hj.widget.renderSurvey = function(e) {
                var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : document.body;
                _r(n, ".".concat("_hj-widget-iframe")), rd(e, n)
            }
        }()
}();